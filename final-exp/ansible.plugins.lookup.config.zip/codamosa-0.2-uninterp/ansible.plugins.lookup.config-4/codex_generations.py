

# Generated at 2022-06-17 12:15:50.709908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.sentinel import Sentinel
    import ansible.constants as C
    import os
    import sys
    import json


# Generated at 2022-06-17 12:15:55.795269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']
    variables = {}
    plugin_type = 'shell'
    plugin_name = 'sh'
    result = LookupModule().run(terms, variables, plugin_type=plugin_type, plugin_name=plugin_name)
    assert result == ['/tmp']

    # Test with missing plugin_type
    terms = ['remote_tmp']
    variables = {}
    plugin_type = 'shell'
    plugin_name = None
    try:
        result = LookupModule().run(terms, variables, plugin_type=plugin_type, plugin_name=plugin_name)
    except AnsibleOptionsError as e:
        assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(e)

    # Test with missing plugin

# Generated at 2022-06-17 12:16:07.422299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']) == ['root', ['/etc/ansible/roles']]
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'UNKNOWN']) == ['root', ['/etc/ansible/roles']]

    # Test with plugin_type and plugin_name

# Generated at 2022-06-17 12:16:16.810724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError):
        lookup_plugin.run(['remote_user'])

    # Test with invalid plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleLookupError):
        lookup_plugin.run(['remote_user'])

    # Test with invalid on_missing
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'on_missing': 'invalid'})
   

# Generated at 2022-06-17 12:16:26.034199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1516598836.46-140109858691590']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_plugin.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and plugin_name

# Generated at 2022-06-17 12:16:39.463966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 12:16:44.945476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')

# Generated at 2022-06-17 12:16:56.803398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    try:
        lookup_module.run(['UNKNOWN'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)

    # Test with missing plugin
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'missing'})
    try:
        lookup_module.run(['remote_tmp'])
    except AnsibleLookupError as e:
        assert 'Unable to load shell plugin "missing"' in to_native(e)

    # Test with missing setting in plugin


# Generated at 2022-06-17 12:17:08.848775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(terms=['remote_user', 'port'], variables={})
    assert result == ['', '']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(terms=['remote_tmp'], variables={})
    assert result == ['/tmp']

    # Test with global config
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:17:15.733251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_FLAGS']) == ['root', 'sudo', '-H']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_FLAGS', 'DEFAULT_BECOME_PASS']) == ['root', 'sudo', '-H', None]

# Generated at 2022-06-17 12:17:32.586477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.display import Display
    import os
    import json


# Generated at 2022-06-17 12:17:42.928890
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./lookup_plugins')
    lookup_loader.add_directory('./plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')

# Generated at 2022-06-17 12:17:54.901145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with plugin_type and plugin_name
    plugin_type = 'shell'
    plugin_name = 'sh'
    term = 'remote_tmp'
    lookup_obj = LookupModule()
    result = lookup_obj.run([term], plugin_type=plugin_type, plugin_name=plugin_name)
    assert result == [C.DEFAULT_REMOTE_TMP]

    # test with plugin_type and plugin_name
    plugin_type = 'connection'
    plugin_name = 'ssh'
    term = 'remote_user'
    lookup_obj = LookupModule()
    result = lookup_obj.run([term], plugin_type=plugin_type, plugin_name=plugin_name)
    assert result == [C.DEFAULT_REMOTE_USER]

    # test with plugin_type and plugin_name


# Generated at 2022-06-17 12:18:06.391412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1524287908.18-140587934190568']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp', 'executable'])

# Generated at 2022-06-17 12:18:11.567899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_user']) == ['root']
    assert lookup_module.run(['remote_user', 'port']) == ['root', None]
    assert lookup_module.run(['remote_user', 'port', 'unknown']) == ['root', None]
    assert lookup_module.run(['remote_user', 'port', 'unknown'], on_missing='warn') == ['root', None]
    assert lookup_module.run(['remote_user', 'port', 'unknown'], on_missing='skip') == ['root', None]
    assert lookup_module.run

# Generated at 2022-06-17 12:18:20.867476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:18:29.130094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import cliconf_loader
    from ansible.plugins.loader import httpapi_loader
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.loader import netconf_loader
    from ansible.plugins.loader import become_loader

    # Test for plugin_type and plugin_name

# Generated at 2022-06-17 12:18:41.138524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-tmp-1523341543.06-240984548554849']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_module.run(['remote_user', 'port']) == ['root', '22']

    # Test with plugin_type and plugin_name
    lookup_module = Look

# Generated at 2022-06-17 12:18:49.590438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:18:54.992874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for global config
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_ROLES_PATH']) == [C.DEFAULT_ROLES_PATH]
    assert lookup_module.run(['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER']) == [C.DEFAULT_ROLES_PATH, C.DEFAULT_BECOME_USER]

    # test for plugin config
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'sh'})

# Generated at 2022-06-17 12:19:19.722500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with invalid plugin_type
    terms = ['DEFAULT_BECOME_USER']
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms, plugin_type='invalid_plugin_type')
    # test with invalid plugin_name
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms, plugin_type='become', plugin_name='invalid_plugin_name')
    # test with invalid on_missing
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms, on_missing='invalid_on_missing')
    # test with invalid term

# Generated at 2022-06-17 12:19:30.111725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['executable']) == ['/bin/sh']

    # Test with invalid plugin_type and plugin_name
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'invalid'})

# Generated at 2022-06-17 12:19:40.645225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [u'$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp', 'remote_tmp'])
    assert result == [u'$HOME/.ansible/tmp', u'$HOME/.ansible/tmp']

    # Test with plugin_

# Generated at 2022-06-17 12:19:52.511116
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # test with plugin_type and plugin_name
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    # test with on_missing=error
    lookup_module.set_options(direct={'on_missing': 'error'})
    # test with on_missing=warn
    lookup_module.set_options(direct={'on_missing': 'warn'})
    # test with on_missing=skip
    lookup_module.set_options(direct={'on_missing': 'skip'})
    # test with on_missing=error
    lookup_module.set_options(direct={'on_missing': 'error'})
    # test with on_missing=warn

# Generated at 2022-06-17 12:20:03.310638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test with on_missing option set to error
    try:
        lookup.run(terms=['UNKNOWN'], variables=None, on_missing='error')
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in e.message
    # test with on_missing option set to warn
    lookup.run(terms=['UNKNOWN'], variables=None, on_missing='warn')
    # test with on_missing option set to skip
    lookup.run(terms=['UNKNOWN'], variables=None, on_missing='skip')
    # test with on_missing option set to invalid value

# Generated at 2022-06-17 12:20:12.499872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import unittest
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.plugins.loader import lookup_loader

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self._loader = lookup_loader

        def tearDown(self):
            pass

        def test_run(self):
            lookup_plugin = self._loader.get('config')

            # test with no terms

# Generated at 2022-06-17 12:20:24.242778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(terms=['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1527336935.4-247855185929094']

    # Test with invalid plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh1'})

# Generated at 2022-06-17 12:20:33.366526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={})
    lookup.run(terms=['DEFAULT_BECOME_USER'])
    lookup.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'])
    lookup.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={'playbook_dir': '/tmp'})
    lookup.run(terms=['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={'playbook_dir': '/tmp'}, on_missing='error')

# Generated at 2022-06-17 12:20:43.080241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name but invalid setting
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    try:
        lookup_plugin.run(['invalid_setting'])
    except AnsibleLookupError as e:
        assert 'was not defined' in to_native(e)

    # Test with plugin_

# Generated at 2022-06-17 12:20:44.423870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'])

# Generated at 2022-06-17 12:21:20.012084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lm = LookupModule()
    lm.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lm.run(['remote_tmp']) == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lm = LookupModule()
    lm.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lm.run(['remote_tmp']) == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lm = LookupModule()

# Generated at 2022-06-17 12:21:30.793529
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:21:41.689129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    from ansible.plugins.loader import LookupModule
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.errors import AnsibleOptionsError
    from ansible.utils.sentinel import Sentinel

    # Test case 1:
    # Test with invalid value of on_missing
    # Expected result: AnsibleOptionsError
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    kwargs = {'on_missing': 'invalid'}
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:21:43.403315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={})
    lookup.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')

# Generated at 2022-06-17 12:21:52.261898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import BOOLEANS_TRUE
    from ansible.module_utils.common.text.formatters import BOOLEANS_FALSE
    from ansible.module_utils.common.text.formatters import boolean
    from ansible.module_utils.common.text.formatters import to_bool
    from ansible.module_utils.common.text.formatters import to_nice_yaml

# Generated at 2022-06-17 12:22:03.438948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp']

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:22:13.570871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:22:22.968624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={})
    result = lookup.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error')
    assert result == ['/etc/ansible/roles:/usr/share/ansible/roles']

    result = lookup.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='warn')
    assert result == ['/etc/ansible/roles:/usr/share/ansible/roles']

    result = lookup.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='skip')
    assert result == ['/etc/ansible/roles:/usr/share/ansible/roles']


# Generated at 2022-06-17 12:22:29.334209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_

# Generated at 2022-06-17 12:22:37.124223
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:23:58.657218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_user'])
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_user', 'port'])
    assert result == ['root', None]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:24:11.043253
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:24:20.986669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables={}, on_missing='error', plugin_type='shell', plugin_name='sh')

# Generated at 2022-06-17 12:24:29.259054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with valid terms
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result = lookup_module.run(terms)
    assert result[0] == 'root'
    assert result[1] == ['/etc/ansible/roles']
    # Test with invalid terms
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'UNKNOWN']
    result = lookup_module.run(terms, on_missing='skip')
    assert result[0] == 'root'
    assert result[1] == ['/etc/ansible/roles']
    assert len(result) == 2
    # Test with invalid terms and on_missing='error'

# Generated at 2022-06-17 12:24:40.907133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:24:53.140809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == [u'/tmp/ansible-tmp-1489726371.8-147729857856000']

    # Test with missing plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={})
    assert lookup_plugin.run(['remote_tmp']) == [u'/tmp/ansible-tmp-1489726371.8-147729857856000']

    # Test with missing plugin_type and plugin_name
    lookup_plugin = Lookup

# Generated at 2022-06-17 12:25:05.533704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['remote_user'])

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['remote_user'])

    # Test with invalid on_missing
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'invalid'})

# Generated at 2022-06-17 12:25:13.157414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_user'])
    assert result == ['root']

    # Test with plugin_type and plugin_name and on_missing
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local', 'on_missing': 'skip'})
    result = lookup_module.run(['remote_user', 'remote_tmp'])
    assert result == ['root']

    # Test with plugin_type and plugin_name and on_missing
    lookup_module = Look

# Generated at 2022-06-17 12:25:22.774985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lu = LookupModule()
    lu.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lu.run(['remote_tmp']) == ['/tmp']

    # Test with plugin_type and plugin_name
    lu = LookupModule()
    lu.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lu.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lu = LookupModule()
    lu.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})

# Generated at 2022-06-17 12:25:30.676459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid parameters
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=["DEFAULT_BECOME_USER"], variables={}, on_missing="error")

    # Test with invalid parameters
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=["UNKNOWN_SETTING"], variables={}, on_missing="error")