

# Generated at 2022-06-17 12:15:41.455954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:15:52.947995
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:15:55.260463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:16:07.031087
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:16:16.432157
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:16:25.830146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupBase

    # Create a config object
    config = configparser.ConfigParser()
    config.readfp(StringIO(u'[defaults]\nroles_path = /path/to/roles\n'))

    # Create a lookup object
    lookup = lookup_loader.get('config')

    # Create a mock display object

# Generated at 2022-06-17 12:16:39.435823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a valid term
    lookup_obj = LookupModule()
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_obj.run(terms)
    assert result == ['root']

    # test with an invalid term
    terms = ['DEFAULT_BECOME_USER_INVALID']
    result = lookup_obj.run(terms)
    assert result == []

    # test with a valid term and invalid term
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_USER_INVALID']
    result = lookup_obj.run(terms)
    assert result == ['root']

    # test with a valid term and invalid term and on_missing=warn
    lookup_obj.set_options(direct={'on_missing': 'warn'})

# Generated at 2022-06-17 12:16:49.517177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'local'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'local'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_

# Generated at 2022-06-17 12:16:59.216806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupBase

    class MockConfigParser(configparser.ConfigParser):
        def __init__(self, *args, **kwargs):
            self.data = {}
            self.data['DEFAULT'] = {}
            self.data['DEFAULT']['roles_path'] = '/etc/ansible/roles'
            self.data['DEFAULT']['library'] = '/usr/share/ansible'
            self.data['DEFAULT']['module_utils'] = '/usr/share/ansible/module_utils'


# Generated at 2022-06-17 12:17:09.454386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError):
        lookup_plugin.run(terms=['remote_user'])

    # Test with invalid plugin_name
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleLookupError):
        lookup_plugin.run(terms=['remote_user'])

    # Test with invalid on_missing
    lookup_plugin.set_options(var_options=None, direct={'on_missing': 'invalid'})

# Generated at 2022-06-17 12:17:22.683622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-tmp-1516379957.46-140107836347926']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_module.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:17:32.586674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local', 'on_missing': 'error'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp']

    # Test with invalid plugin_type and plugin_name
    lookup_module.set_options(direct={'plugin_type': 'invalid_type', 'plugin_name': 'invalid_name', 'on_missing': 'error'})

# Generated at 2022-06-17 12:17:42.929704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_module.run(['remote_user', 'port'])
    assert result == ['root', '22']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
   

# Generated at 2022-06-17 12:17:54.900165
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_plugin.run(terms=['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # test with plugin_type and plugin_name but invalid setting
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    try:
        lookup_plugin.run(terms=['invalid_setting'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting invalid_setting' in to_

# Generated at 2022-06-17 12:18:06.348366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']) == ['root', ['/etc/ansible/roles']]
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'UNKNOWN']) == ['root', ['/etc/ansible/roles']]

# Generated at 2022-06-17 12:18:11.527249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:18:20.829541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'test_var': 'test_value'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['DEFAULT_REMOTE_TMP'])
    assert result == ['/tmp/ansible-${USER}']
    result = lookup_module.run(['DEFAULT_REMOTE_TMP', 'test_var'])
    assert result == ['/tmp/ansible-${USER}', 'test_value']
    result = lookup_module.run(['DEFAULT_REMOTE_TMP', 'test_var'], variables={'test_var': 'test_value_2'})

# Generated at 2022-06-17 12:18:28.150156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'], variables=None)
    assert result == ['/tmp/ansible-tmp-1512058983.18-140796723666836']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'], variables=None)

# Generated at 2022-06-17 12:18:40.843706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    terms = ['remote_user', 'port']
    variables = {}
    kwargs = {'plugin_type': 'connection', 'plugin_name': 'ssh'}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['root', 22]

    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']
    variables = {}
    kwargs = {'plugin_type': 'shell', 'plugin_name': 'sh'}
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['/tmp']

    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']


# Generated at 2022-06-17 12:18:49.332677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    assert lookup_module.run(['DEFAULT_BECOME_USER'], variables={}, on_missing='error') == ['root']

    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    assert lookup_module.run(['DEFAULT_BECOME_USER'], variables={}, on_missing='warn') == ['root']

    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    assert lookup_module.run(['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')

# Generated at 2022-06-17 12:19:13.194189
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_PASS']) == ['root', 'sudo', None]

# Generated at 2022-06-17 12:19:20.476242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    # Create a dummy lookup plugin
    class DummyLookupModule(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    # Create a dummy display
    display = Display()
    display.verbosity = 4
    display.columns = 80

    # Create a dummy lookup plugin loader

# Generated at 2022-06-17 12:19:27.264248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:19:36.275528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'invalid_plugin_name'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['invalid_config_setting'])

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid_plugin_name'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['invalid_config_setting'])

    # Test with invalid on_missing
    lookup_module = LookupModule()
   

# Generated at 2022-06-17 12:19:46.499132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1516226067.5-124433753059077']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])

# Generated at 2022-06-17 12:19:54.663632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='warn') == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='skip') == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='error') == ['root']
    assert lookup_module.run(terms=['DEFAULT_BECOME_USER'], on_missing='error', plugin_type='connection', plugin_name='local') == ['root']

# Generated at 2022-06-17 12:19:59.588969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    try:
        lookup_module.run(['UNKNOWN'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)

    # Test with missing setting and on_missing=warn
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'warn'})
    try:
        lookup_module.run(['UNKNOWN'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)

    # Test with missing setting and on_missing=

# Generated at 2022-06-17 12:20:09.020802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1523742685.82-25984-182709878703822']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_plugin.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin

# Generated at 2022-06-17 12:20:21.407262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_

# Generated at 2022-06-17 12:20:31.294665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_plugin.run(['accelerate']) == [C.ACCELERATE]
    assert lookup_plugin.run(['accelerate', 'accelerate_port']) == [C.ACCELERATE, C.ACCELERATE_PORT]
    assert lookup_plugin.run(['accelerate', 'accelerate_port', 'accelerate_timeout']) == [C.ACCELERATE, C.ACCELERATE_PORT, C.ACCELERATE_TIMEOUT]

# Generated at 2022-06-17 12:21:08.030804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(['remote_tmp'])
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup_module.run(['remote_tmp'])

# Generated at 2022-06-17 12:21:13.725152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:21:24.418736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1514240948.57-178077498838984']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp', 'remote_tmp'])

# Generated at 2022-06-17 12:21:33.766747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_ROLES_PATH']) == ['root', 'sudo', '/etc/ansible/roles:/usr/share/ansible/roles']

# Generated at 2022-06-17 12:21:43.397913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_PASS']) == ['root', 'sudo', None]
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_PASS'], on_missing='warn') == ['root', 'sudo', None]

# Generated at 2022-06-17 12:21:51.940372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'])
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:22:03.411200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:22:13.539409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:22:22.971098
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_user'])
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_user', 'port'])
    assert result == ['root', None]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:22:29.356137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp/ansible-tmp-1511336631.7-246909817670108']
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})

# Generated at 2022-06-17 12:23:49.529637
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512163952.11-185833971229079']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_module.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:23:59.564893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']
    ptype = 'shell'
    pname = 'sh'
    result = LookupModule().run(terms, plugin_type=ptype, plugin_name=pname)
    assert result == ['/tmp/ansible-tmp-1522348899.67-257726308973854']

    # Test with plugin_type and plugin_name
    terms = ['remote_user']
    ptype = 'connection'
    pname = 'ssh'
    result = LookupModule().run(terms, plugin_type=ptype, plugin_name=pname)
    assert result == ['root']

    # Test with plugin_type and plugin_name
    terms = ['remote_user']
    ptype = 'connection'

# Generated at 2022-06-17 12:24:11.889990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(direct={'on_missing': 'error'})
    assert lookup.run(['DEFAULT_BECOME_USER']) == [C.DEFAULT_BECOME_USER]
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']) == [C.DEFAULT_BECOME_USER, C.DEFAULT_ROLES_PATH]
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH'], variables={'DEFAULT_BECOME_USER': 'root'}) == ['root', C.DEFAULT_ROLES_PATH]

# Generated at 2022-06-17 12:24:22.241896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1
    # ptype and pname are not provided
    # missing is not provided
    # terms is a list of strings
    # expected result:
    #   a list of values of the keys in the config
    #   if the key is not found, raise AnsibleLookupError
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result == ['root', ['/etc/ansible/roles']]

    # Test case 2
    # ptype and pname are not provided
    # missing is provided
    # terms is a list of strings
    # expected result:
    #   a list of values of the keys in the config
    #   if the key is not found, raise Ans

# Generated at 2022-06-17 12:24:30.001903
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:24:39.709554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(terms=['remote_user'], variables=None, **{})
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(terms=['remote_user'], variables=None, **{})
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = Lookup

# Generated at 2022-06-17 12:24:52.093094
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:25:03.505139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(direct={})
    try:
        lookup_module.run(['DEFAULT_BECOME_USER'])
    except AnsibleOptionsError as e:
        assert 'on_missing' in to_native(e)

    # Test with invalid missing option
    lookup_module.set_options(direct={'on_missing': 'invalid'})
    try:
        lookup_module.run(['DEFAULT_BECOME_USER'])
    except AnsibleOptionsError as e:
        assert 'invalid' in to_native(e)

    # Test with invalid term
    lookup_module.set_options(direct={'on_missing': 'error'})

# Generated at 2022-06-17 12:25:12.547863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={})
    assert lookup.run(['DEFAULT_BECOME_USER'], variables={}, on_missing='error') == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER'], variables={}, on_missing='warn') == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER'], variables={}, on_missing='skip') == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo') == ['root']

# Generated at 2022-06-17 12:25:22.312219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # Input:
    # terms = ['DEFAULT_BECOME_USER']
    # variables = None
    # kwargs = {}
    # Expected output:
    # ret = ['root']
    terms = ['DEFAULT_BECOME_USER']
    variables = None
    kwargs = {}
    lookup_module = LookupModule()
    ret = lookup_module.run(terms, variables, **kwargs)
    assert ret == ['root']

    # Test case 2:
    # Input:
    # terms = ['DEFAULT_BECOME_USER']
    # variables = None
    # kwargs = {'on_missing': 'warn'}
    # Expected output:
    # ret = ['root']
    terms = ['DEFAULT_BECOME_USER']
    variables