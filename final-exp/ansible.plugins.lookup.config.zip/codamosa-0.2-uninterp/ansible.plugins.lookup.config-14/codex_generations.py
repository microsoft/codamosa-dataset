

# Generated at 2022-06-17 12:15:42.005565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')

# Generated at 2022-06-17 12:15:53.462442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms, variables={}, on_missing='error')
    assert result == ['root']

    # Test with an invalid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    terms = ['DEFAULT_BECOME_USER_INVALID']

# Generated at 2022-06-17 12:15:58.489625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['remote_tmp'], plugin_type='shell', plugin_name='sh') == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['remote_user', 'port'], plugin_type='connection', plugin_name='ssh') == [C.REMOTE_USER, C.DEFAULT_REMOTE_PORT]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:16:10.100243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_plugin.run(terms=['remote_user'])
    assert 'plugin_type' in to_native(excinfo.value)

    # Test with invalid plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_plugin.run(terms=['remote_user'])
   

# Generated at 2022-06-17 12:16:12.119621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(['DEFAULT_BECOME_USER'])
    assert result == ['root']

# Generated at 2022-06-17 12:16:19.592269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['DEFAULT_ROLES_PATH']) == [C.DEFAULT_ROLES_PATH]
    assert lookup_module.run(['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER']) == [C.DEFAULT_ROLES_PATH, C.DEFAULT_BECOME_USER]
    assert lookup_module.run(['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'], on_missing='warn') == [C.DEFAULT_ROLES_PATH, C.DEFAULT_BECOME_USER]

# Generated at 2022-06-17 12:16:22.538714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=["DEFAULT_BECOME_USER"], variables={}, on_missing='error')

# Generated at 2022-06-17 12:16:25.380800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:16:39.366922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'local'})
    terms = ['remote_tmp']
    result = lookup_module.run(terms)

# Generated at 2022-06-17 12:16:49.458329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config')

    lookup = lookup_loader.get('config')

    assert lookup.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_BECOME_PASS']) == ['root', 'sudo', None]

# Generated at 2022-06-17 12:17:08.808238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['remote_user'])

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['remote_user'])

    # Test with invalid on_missing
    lookup_module = LookupModule()
    lookup_module.set_options

# Generated at 2022-06-17 12:17:12.640018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=["DEFAULT_BECOME_USER"], variables=None, **{})

# Generated at 2022-06-17 12:17:19.368610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    variables = {}
    kwargs = {}
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct=kwargs)
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['root', ['/etc/ansible/roles']]

# Generated at 2022-06-17 12:17:27.076191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import cliconf_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import httpapi_loader
    from ansible.plugins.loader import inventory_loader
   

# Generated at 2022-06-17 12:17:31.398978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp/ansible-tmp-1517897175.33-140792647798872']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_plugin.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_plugin = Lookup

# Generated at 2022-06-17 12:17:39.745370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import mock

    if PY3:
        builtin_module = 'builtins'
    else:
        builtin_module = '__builtin__'

    with mock.patch(builtin_module + '.open', create=True) as mock_open:
        mock_open.side_effect = IOError()
        lookup_plugin = LookupModule()
        assert lookup_plugin.run(["test"], dict()) == []

# Generated at 2022-06-17 12:17:42.699827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=["DEFAULT_BECOME_USER"], variables=None, **{})

# Generated at 2022-06-17 12:17:54.705862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid terms
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result == ['root', ['roles/']]

    # Test with invalid terms
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'INVALID_TERM']
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result == ['root', ['roles/']]

    # Test with invalid terms and on_missing set to error
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'INVALID_TERM']
    lookup_module = LookupModule()
   

# Generated at 2022-06-17 12:18:02.927553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object
    lookup_module = LookupModule()

    # Create a list of terms
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']

    # Create a dict of variables
    variables = {}

    # Create a dict of kwargs
    kwargs = {}

    # Call the method run of class LookupModule
    result = lookup_module.run(terms, variables, **kwargs)

    # Assert the result
    assert result == ['root', '/etc/ansible/roles:/usr/share/ansible/roles']

# Generated at 2022-06-17 12:18:10.011462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    terms = ['UNKNOWN_SETTING']
    try:
        lookup_module.run(terms)
    except AnsibleLookupError:
        pass
    else:
        assert False, 'AnsibleLookupError should be raised'

    # Test with missing plugin
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'UNKNOWN_PLUGIN'})
    terms = ['remote_tmp']
    try:
        lookup_module.run(terms)
    except AnsibleLookupError:
        pass

# Generated at 2022-06-17 12:18:27.071778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={'ansible_connection': 'local'})
    assert lookup.run(['DEFAULT_ROLES_PATH']) == [C.DEFAULT_ROLES_PATH]
    assert lookup.run(['DEFAULT_ROLES_PATH'], on_missing='warn') == [C.DEFAULT_ROLES_PATH]
    assert lookup.run(['DEFAULT_ROLES_PATH'], on_missing='skip') == [C.DEFAULT_ROLES_PATH]
    assert lookup.run(['DEFAULT_ROLES_PATH'], on_missing='error') == [C.DEFAULT_ROLES_PATH]
    assert lookup.run(['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'])

# Generated at 2022-06-17 12:18:39.800075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['UNKNOWN_CONFIG']) == []

    # Test with plugin_type and plugin_name
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local', 'on_missing': 'error'})
    assert lookup_module.run(['executable']) == ['/bin/sh']
    assert lookup_module.run(['UNKNOWN_CONFIG']) == []

# Generated at 2022-06-17 12:18:48.655881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock object for the lookup plugin
    lookup_plugin = LookupModule()

    # Create a mock object for the display object
    display_obj = MockDisplay()

    # Set the display object in the lookup plugin
    lookup_plugin._display = display_obj

    # Create a mock object for the variables
    variables = {}

    # Create a mock object for the options
    options = {}

    # Set the options in the lookup plugin
    lookup_plugin.set_options(var_options=variables, direct=options)

    # Create a mock object for the terms
    terms = ['DEFAULT_BECOME_USER']

    # Call the run method of the lookup plugin
    result = lookup_plugin.run(terms, variables)

    # Assert the result
    assert result == ['root']

    # Create a mock object for the terms
   

# Generated at 2022-06-17 12:18:50.819074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:18:57.205392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin type
    try:
        LookupModule().run(terms=['foo'], plugin_type='invalid', plugin_name='invalid')
        assert False
    except AnsibleOptionsError:
        pass

    # Test with invalid plugin name
    try:
        LookupModule().run(terms=['foo'], plugin_type='shell', plugin_name='invalid')
        assert False
    except AnsibleLookupError:
        pass

    # Test with invalid on_missing
    try:
        LookupModule().run(terms=['foo'], on_missing='invalid')
        assert False
    except AnsibleOptionsError:
        pass

    # Test with invalid term
    try:
        LookupModule().run(terms=[1])
        assert False
    except AnsibleOptionsError:
        pass

    #

# Generated at 2022-06-17 12:19:01.397143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:19:09.843952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'invalid'})
    result = lookup_module.run(['remote_tmp'])
    assert result == []

    # Test with invalid plugin_type
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:19:19.411228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512115832.8-180989801240727']

    # test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_plugin.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # test with plugin_type and plugin_name

# Generated at 2022-06-17 12:19:23.140292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=["DEFAULT_BECOME_USER"], variables={}, on_missing="error")

# Generated at 2022-06-17 12:19:32.486835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    lookup_module.set_options(var_options=None, direct={'on_missing': 'warn'})
    lookup_module.set_options(var_options=None, direct={'on_missing': 'skip'})
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'local'})
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'ssh'})
    lookup_

# Generated at 2022-06-17 12:19:57.202844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']
    ptype = 'shell'
    pname = 'sh'
    variables = None
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, plugin_type=ptype, plugin_name=pname)
    assert result == ['/tmp/ansible-tmp-1518356082.11-248876990983945']

    # Test with plugin_type and plugin_name
    terms = ['remote_tmp']
    ptype = 'shell'
    pname = 'sh'
    variables = None
    lookup_module = LookupModule()
    result = lookup_module.run(terms, variables, plugin_type=ptype, plugin_name=pname)

# Generated at 2022-06-17 12:20:08.621581
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['remote_tmp'], plugin_type='shell', plugin_name='sh') == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['remote_tmp'], plugin_type='shell', plugin_name='sh') == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['remote_tmp'], plugin_type='shell', plugin_name='sh') == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
   

# Generated at 2022-06-17 12:20:20.958276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.sentinel import Sentinel

    # Create a dummy lookup plugin
    class DummyLookup(LookupBase):
        def run(self, terms, variables=None, **kwargs):
            return terms

    # Register the dummy lookup plugin
    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), 'lookup_plugins'))
    lookup_loader.add_plugin(DummyLookup)

    # Create a dummy ansible config

# Generated at 2022-06-17 12:20:30.957865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(terms=['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1520809906.8-279412991909823']

    # Test with plugin_type and plugin_name and on_missing
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh', 'on_missing': 'warn'})
    result = lookup_plugin.run(terms=['remote_tmp'])

# Generated at 2022-06-17 12:20:42.041543
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    lookup_module.set_options(var_options={'ansible_connection': 'local'})
    lookup_module.set_options(var_options={'ansible_python_interpreter': '/usr/bin/python'})
    lookup_module.set_options(var_options={'ansible_shell_type': 'csh'})
    lookup_module.set_options(var_options={'ansible_shell_executable': '/bin/csh'})
    lookup_module.set_options(var_options={'ansible_shell_executable': '/bin/csh'})

# Generated at 2022-06-17 12:20:50.563463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin name and type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with plugin name and type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_name': 'ssh', 'plugin_type': 'connection'})
    terms = ['remote_user', 'port']
    result = lookup_module.run(terms)
    assert result == ['root', 22]

    # Test with invalid plugin name and type
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:21:01.953936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.get_option = lambda x: 'error'
    lookup_module.get_plugin_option = lambda x: None
    lookup_module._display = lambda x: None
    lookup_module._display.warning = lambda x: None
    lookup_module._display.error = lambda x: None
    lookup_module._display.display = lambda x: None
    lookup_module._display.verbose = lambda x: None
    lookup_module._display.deprecated = lambda x, y: None
    lookup_module._display.deprecated_args = lambda x, y, z: None
    lookup_module._display.display_args = lambda x, y: None
    lookup_module._display.display

# Generated at 2022-06-17 12:21:13.545560
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512881071.17-245845120872635']

    # Test with invalid plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local1'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == []

    # Test with valid plugin_type and invalid plugin_name
    lookup_plugin = LookupModule()
   

# Generated at 2022-06-17 12:21:20.112812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:21:22.186645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(terms=['DEFAULT_BECOME_USER']) == ['root']

# Generated at 2022-06-17 12:21:58.177663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.six.moves import unittest
    from ansible.plugins.loader import lookup_loader

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.lookup = LookupModule()
            self.lookup.set_loader(lookup_loader)

        def tearDown(self):
            pass


# Generated at 2022-06-17 12:22:10.822064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'invalid_plugin_name'})
    try:
        lookup_module.run(terms=['invalid_term'])
    except AnsibleOptionsError as e:
        assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in to_native(e)

    # Test with invalid on_missing
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'invalid_on_missing'})

# Generated at 2022-06-17 12:22:22.247572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1517481881.49-170873528556943']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_module.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and plugin

# Generated at 2022-06-17 12:22:33.383587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_plugin.run(terms=['accelerate_port'], variables=None)
    assert result == [None]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_plugin.run(terms=['accelerate_port'], variables=None)
    assert result == [None]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:22:40.716002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options=None, direct={})
    assert lookup.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{}) == ['root']
    assert lookup.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{}) == ['/etc/ansible/roles:/usr/share/ansible/roles']
    assert lookup.run(terms=['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'], variables=None, **{}) == ['/etc/ansible/roles:/usr/share/ansible/roles', 'root']

# Generated at 2022-06-17 12:22:50.682548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']

    # Test with a invalid term
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    try:
        lookup_module.run(['UNKNOWN'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)

    # Test with a invalid term and on_missing set to 'warn'
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'warn'})

# Generated at 2022-06-17 12:22:58.789565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-151220-9079-1zjfjxr']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])

# Generated at 2022-06-17 12:23:06.663496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1
    # Test with missing option
    # Expected result: AnsibleOptionsError
    # Actual result: AnsibleOptionsError
    try:
        LookupModule().run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    except AnsibleOptionsError:
        pass
    else:
        assert False, 'Expected AnsibleOptionsError'

    # Test 2
    # Test with invalid option
    # Expected result: AnsibleOptionsError
    # Actual result: AnsibleOptionsError
    try:
        LookupModule().run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='invalid')
    except AnsibleOptionsError:
        pass
    else:
        assert False, 'Expected AnsibleOptionsError'

    # Test 3
    # Test

# Generated at 2022-06-17 12:23:16.907614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    try:
        lookup_module.run(['UNKNOWN'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)
    else:
        assert False, 'AnsibleLookupError not raised'

    # Test for missing plugin
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'UNKNOWN'})

# Generated at 2022-06-17 12:23:24.997190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    terms = ['remote_tmp']
    result = lookup_module.run(terms)
    assert result == ['/tmp/ansible-tmp-1513759941.02-285059805747983']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    terms = ['remote_user', 'port']
    result = lookup_module.run(terms)
    assert result == ['root', 22]

# Generated at 2022-06-17 12:24:30.344556
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:24:39.883282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./')
    lookup_loader.add_directory('./lookup_plugins')
    lookup_loader.add_directory('./lookup_plugins/config')
    lookup_loader.add_directory('./lookup_plugins/config/test')
    lookup_loader.add_directory('./lookup_plugins/config/test/unit')
    lookup_loader.add_directory('./lookup_plugins/config/test/unit/test_data')
    lookup_loader.add_directory('./lookup_plugins/config/test/unit/test_data/test_ansible_config')

# Generated at 2022-06-17 12:24:52.274282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp/ansible-tmp-1512051209.59-246600293613963']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    assert lookup_plugin.run(['remote_user', 'port']) == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_plugin = Lookup

# Generated at 2022-06-17 12:25:03.779256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:25:05.723146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')

# Generated at 2022-06-17 12:25:13.269779
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:25:22.890496
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case 1:
    # Test case with missing plugin_type and plugin_name
    # Expected result:
    # AnsibleOptionsError
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_name': 'ssh'})
    try:
        lookup_module.run(terms=['remote_user'])
    except AnsibleOptionsError as e:
        assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(e)

    # Test case 2:
    # Test case with missing on_missing
    # Expected result:
    # AnsibleOptionsError
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'test'})

# Generated at 2022-06-17 12:25:35.000377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_plugin.run(['remote_tmp']) == ['/tmp']

    # Test with on_missing=warn
    lookup_plugin.set_options(direct={'on_missing': 'warn'})
    assert lookup_plugin.run(['UNKNOWN']) == []

    # Test with on_missing=skip
    lookup_plugin.set_options(direct={'on_missing': 'skip'})
    assert lookup_plugin.run(['UNKNOWN']) == []

    # Test with on_missing=error
    lookup_plugin.set_options(direct={'on_missing': 'error'})