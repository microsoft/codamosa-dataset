

# Generated at 2022-06-17 12:15:50.947056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    plugin_type = 'connection'
    plugin_name = 'local'
    term = 'remote_tmp'
    terms = [term]
    variables = None
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct={'plugin_type': plugin_type, 'plugin_name': plugin_name})
    result = lookup_module.run(terms)
    assert result == ['/tmp/ansible-tmp-1520676629.95-242755685527094']

    # Test with plugin_type and plugin_name
    plugin_type = 'shell'
    plugin_name = 'sh'
    term = 'remote_tmp'
    terms = [term]
    variables = None
    lookup_module = Lookup

# Generated at 2022-06-17 12:15:57.177609
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='warn')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='skip')
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error', plugin_type='become', plugin_name='sudo')

# Generated at 2022-06-17 12:16:08.272691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='error')
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, on_missing='error')
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, on_missing='error')
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, on_missing='error')
    lookup_module.run(terms=['UNKNOWN'], variables=None, on_missing='skip')

# Generated at 2022-06-17 12:16:17.450559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1516058983.6-95726240693783']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_module.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule

# Generated at 2022-06-17 12:16:23.229151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(direct={})
    terms = ['DEFAULT_BECOME_USER']
    try:
        lookup_module.run(terms)
    except AnsibleOptionsError as e:
        assert 'on_missing' in e.message

    # Test with invalid option
    lookup_module.set_options(direct={'on_missing': 'invalid'})
    try:
        lookup_module.run(terms)
    except AnsibleOptionsError as e:
        assert 'invalid' in e.message

    # Test with invalid term
    lookup_module.set_options(direct={'on_missing': 'error'})
    terms = [1]

# Generated at 2022-06-17 12:16:25.882735
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})

# Generated at 2022-06-17 12:16:32.922529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={})
    lookup.set_options(var_options={}, direct={'on_missing': 'error'})
    lookup.set_options(var_options={}, direct={'on_missing': 'warn'})
    lookup.set_options(var_options={}, direct={'on_missing': 'skip'})
    lookup.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    lookup.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'local', 'on_missing': 'error'})

# Generated at 2022-06-17 12:16:41.693495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:16:50.069343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name and on_missing
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh', 'on_missing': 'warn'})
    result = lookup_plugin.run(['remote_tmp', 'UNKNOWN'])
    assert result == ['$HOME/.ansible/tmp']

    # Test with plugin_type and plugin

# Generated at 2022-06-17 12:16:59.659128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid_type', 'plugin_name': 'invalid_name'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(['invalid_config'])

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid_name'})
    with pytest.raises(AnsibleLookupError):
        lookup_module.run(['invalid_config'])

    # Test with invalid config
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:17:24.515552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH']) == ['/etc/ansible/roles:/usr/share/ansible/roles']

    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'warn'})
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH']) == ['/etc/ansible/roles:/usr/share/ansible/roles']

    # Test with missing option
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:17:32.527829
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test for missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    try:
        lookup_module.run(['UNKNOWN'])
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in str(e)
    else:
        assert False, 'AnsibleLookupError not raised'

    # test for missing plugin
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'UNKNOWN'})
    try:
        lookup_module.run(['remote_user'])
    except AnsibleLookupError as e:
        assert 'Unable to load connection plugin "UNKNOWN"' in str(e)

# Generated at 2022-06-17 12:17:42.868659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_user']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_user', 'port']) == ['root', None]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup

# Generated at 2022-06-17 12:17:50.175592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'local'})
    terms = ['executable']
    result = lookup_module.run(terms)
    assert result == ['/bin/sh']

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options

# Generated at 2022-06-17 12:18:00.197096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})

    # Test with invalid on_missing value
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='invalid')
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid' in to_native(e)

    # Test with invalid plugin_type value

# Generated at 2022-06-17 12:18:10.797778
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config/test')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config/test/test_data')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config/test/test_data/test_config')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config/test/test_data/test_config/test_config_data')

# Generated at 2022-06-17 12:18:20.426351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **None)
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **None)
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **None)
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **None)
    lookup_module.run(terms=['UNKNOWN'], variables=None, **None)

# Generated at 2022-06-17 12:18:27.885048
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with valid input
    result = lookup_module.run(['DEFAULT_BECOME_USER'], {})
    assert result == ['root']
    # Test with invalid input
    try:
        lookup_module.run(['DEFAULT_BECOME_USER'], {}, on_missing='invalid')
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid' in to_native(e)
    # Test with missing input

# Generated at 2022-06-17 12:18:40.726650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD']) == ['root', 'sudo']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_BECOME_METHOD', 'DEFAULT_ROLES_PATH']) == ['root', 'sudo', ['/etc/ansible/roles', '/usr/share/ansible/roles']]

# Generated at 2022-06-17 12:18:49.296999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_LookupModule_run: test run method of LookupModule class
    # Args:
    #    None
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # test run method of LookupModule class
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{}) == [C.DEFAULT_ROLES_PATH]
    assert lookup_module.run(terms=['DEFAULT_ROLES_PATH', 'DEFAULT_BECOME_USER'], variables=None, **{}) == [C.DEFAULT_ROLES_PATH, C.DEFAULT_BECOME_USER]

# Generated at 2022-06-17 12:19:25.705200
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:19:39.728942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']) == ['root', ['/etc/ansible/roles', '~/.ansible/roles', '/usr/share/ansible/roles']]
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'UNKNOWN']) == ['root', ['/etc/ansible/roles', '~/.ansible/roles', '/usr/share/ansible/roles']]

# Generated at 2022-06-17 12:19:46.061989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=["DEFAULT_BECOME_USER"], variables=None, **{})

# Generated at 2022-06-17 12:19:54.431717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']) == ['root', ['/etc/ansible/roles']]
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'UNKNOWN']) == ['root', ['/etc/ansible/roles']]

    # Test with on_missing=warn

# Generated at 2022-06-17 12:20:03.429946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    result = lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    assert result == ['root']

    # Test with an invalid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    result = lookup_module.run(terms=['UNKNOWN'], variables=None, **{})
    assert result == []

    # Test with an invalid term and on_missing set to 'error'
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'on_missing': 'error'})

# Generated at 2022-06-17 12:20:06.303960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'local'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_user'])
    assert result == [None]

# Generated at 2022-06-17 12:20:13.245524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(['remote_user'])
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'invalid_plugin_name'})

# Generated at 2022-06-17 12:20:24.840214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.get_option = lambda x: 'error'
    lookup_module.get_plugin_option = lambda x: None
    lookup_module._display = lambda x: None
    lookup_module._display.warning = lambda x: None
    lookup_module._display.error = lambda x: None
    lookup_module._display.display = lambda x: None
    lookup_module._display.verbosity = 0
    lookup_module._display.deprecated = lambda x, y, z: None
    lookup_module._display.deprecated_args = lambda x, y, z: None
    lookup_module._display.deprecated_warn = lambda x, y, z: None
    lookup_module._display

# Generated at 2022-06-17 12:20:33.829177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    terms = ['remote_user', 'port']
    variables = {}
    kwargs = {'plugin_type': 'connection', 'plugin_name': 'ssh'}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    terms = ['remote_tmp']
    variables = {}
    kwargs = {'plugin_type': 'shell', 'plugin_name': 'sh'}
    result = lookup_module.run(terms, variables, **kwargs)
    assert result == ['/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:20:43.240605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid input
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'on_missing': 'error'})
    result = lookup_module.run(terms=['DEFAULT_BECOME_USER'])
    assert result == ['root']

    # Test with invalid input
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'on_missing': 'error'})
    try:
        lookup_module.run(terms=['DEFAULT_BECOME_USER', 'UNKNOWN'])
        assert False
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)

    # Test with invalid input and on_missing=skip
    lookup_module = Look

# Generated at 2022-06-17 12:21:51.327118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1524573883.73-251398288839096']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_plugin.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:21:59.579572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.get_option = lambda x: 'error'
    lookup_module._display = lambda x: None
    lookup_module.run(['DEFAULT_BECOME_USER'])

# Generated at 2022-06-17 12:22:10.960912
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:22:16.283511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:22:23.923052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error', 'plugin_type': 'connection', 'plugin_name': 'local'})
    terms = ['executable']
    result = lookup_module.run(terms)
    assert result == ['/bin/sh']

    # Test with invalid plugin_type and plugin_name
    lookup_module = Look

# Generated at 2022-06-17 12:22:30.132592
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:22:37.581796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing option
    lookup_module = LookupModule()
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing=None)

    # Test with invalid option
    lookup_module = LookupModule()
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, on_missing='invalid')

    # Test with invalid term
    lookup_module = LookupModule()
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=[1], variables=None, on_missing='error')

    # Test with invalid plugin_type
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:22:47.636087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_plugin.run(['remote_user'])
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in str(excinfo.value)

    # Test with invalid plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup_plugin.run(['remote_user'])

# Generated at 2022-06-17 12:22:58.166807
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:23:01.560070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:25:06.186324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options(direct={'on_missing': 'error'})
    assert lookup.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']) == ['root', ['/etc/ansible/roles', '/usr/share/ansible/roles']]
    assert lookup.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'UNKNOWN']) == ['root', ['/etc/ansible/roles', '/usr/share/ansible/roles']]

# Generated at 2022-06-17 12:25:13.506738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with valid terms
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']
    result = lookup_module.run(terms)
    assert result == [C.DEFAULT_BECOME_USER, C.DEFAULT_ROLES_PATH]
    # Test with invalid term
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'UNKNOWN']
    result = lookup_module.run(terms)
    assert result == [C.DEFAULT_BECOME_USER, C.DEFAULT_ROLES_PATH]
    # Test with invalid term and on_missing=error
    terms = ['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'UNKNOWN']
    result

# Generated at 2022-06-17 12:25:22.519754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_ROLES_PATH']) == ['/etc/ansible/roles:/usr/share/ansible/roles']
    assert lookup_module.run(['RETRY_FILES_SAVE_PATH']) == ['/home/user/.ansible/retry']
    assert lookup_module.run(['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP']) == ['green', 'yellow', 'cyan']

# Generated at 2022-06-17 12:25:28.164626
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [u'$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [u'$HOME/.ansible/tmp']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()