

# Generated at 2022-06-17 12:15:40.128364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'local'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['executable'])
    assert result == ['/bin/sh']

# Generated at 2022-06-17 12:15:51.816456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid', 'plugin_name': 'ssh'})
    try:
        lookup_module.run(['remote_user'])
    except AnsibleOptionsError as e:
        assert 'Invalid plugin_type' in to_native(e)
    else:
        assert False, 'AnsibleOptionsError not raised'

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'invalid'})
    try:
        lookup_module.run(['remote_user'])
    except AnsibleOptionsError as e:
        assert 'Invalid plugin_name' in to_

# Generated at 2022-06-17 12:15:54.367217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:16:00.137463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'ansible_connection': 'local'}, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-${USER}']


# Generated at 2022-06-17 12:16:03.284798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables={}, on_missing='error')

# Generated at 2022-06-17 12:16:14.195926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-${USER}']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:16:20.788884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./lookup_plugins')
    lookup_loader.add_directory('./lookup_plugins/config')
    lookup_loader.add_directory('./lookup_plugins/config/test')
    lookup_loader.add_directory('./lookup_plugins/config/test/test_lookup_plugins')
    lookup_loader.add_directory('./lookup_plugins/config/test/test_lookup_plugins/test_lookup_plugins')
    lookup_loader.add_directory('./lookup_plugins/config/test/test_lookup_plugins/test_lookup_plugins/test_lookup_plugins')

# Generated at 2022-06-17 12:16:30.756579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with an invalid term
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    terms = ['DEFAULT_BECOME_USER', 'INVALID_TERM']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with a valid term and plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:16:32.320435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:16:39.201170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1513751110.08-241525590693835']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])

# Generated at 2022-06-17 12:17:01.210709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:17:10.507253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.connection.ssh as ssh
    import ansible.plugins.shell.sh as sh
    import ansible.plugins.cache.memory as memory
    import ansible.plugins.cache.redis as redis
    import ansible.plugins.cache.jsonfile as jsonfile
    import ansible.plugins.cache.yaml as yaml
    import ansible.plugins.cache.pickle as pickle
    import ansible.plugins.cache.base as base
    import ansible.plugins.cache.ini as ini
    import ansible.plugins.cache.toml as toml
    import ansible.plugins.cache.hashing as hashing
    import ansible.plugins.cache.sqlite as sqlite
    import ansible.plugins.cache.dict as dict
    import ans

# Generated at 2022-06-17 12:17:16.879480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with valid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [u'/tmp']

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh1'})
    result = lookup_module.run(['remote_tmp'])
    assert result == []

    # Test with invalid plugin_type and valid plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:17:26.966371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    terms = ['DEFAULT_BECOME_USER']
    result = lookup_module.run(terms)
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    terms = ['remote_user', 'port']
    result = lookup_module.run(terms)
    assert result == ['root', 22]

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:17:40.764506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.lookup.config as config_lookup
    import ansible.plugins.connection.ssh as ssh_connection
    import ansible.plugins.shell.sh as sh_shell
    import ansible.plugins.cache.memory as memory_cache
    import ansible.plugins.callback.default as default_callback
    import ansible.plugins.cliconf.network_cli as network_cli_cliconf
    import ansible.plugins.httpapi.httpapi as httpapi_httpapi
    import ansible.plugins.inventory.ini as ini_inventory
    import ansible.plugins.lookup.file as file_lookup
    import ansible.plugins.netconf.netconf as netconf_netconf
    import ansible.plugins.vars.vault as vault_

# Generated at 2022-06-17 12:17:50.525490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:18:00.508945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1510202655.3-12078-165775690065963']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_tmp'])

# Generated at 2022-06-17 12:18:11.041527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Create a mock for the class LookupBase
    class MockLookupBase(object):
        def __init__(self, *args, **kwargs):
            pass

        def set_options(self, *args, **kwargs):
            pass

        def get_option(self, *args, **kwargs):
            pass

    # Create a mock for the class C
    class MockC(object):
        def __init__(self, *args, **kwargs):
            pass

        def __getattr__(self, name):
            if name == 'DEFAULT_BECOME_USER':
                return 'root'

# Generated at 2022-06-17 12:18:20.355958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'invalid_plugin_type', 'plugin_name': 'invalid_plugin_name'})
    try:
        lookup_plugin.run(terms=['invalid_term'])
    except AnsibleOptionsError as e:
        assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in to_native(e)

    # Test with invalid plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'invalid_plugin_name'})

# Generated at 2022-06-17 12:18:27.831381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    lookup_module.run(['remote_tmp'])

    # Test with plugin_type and plugin_name and on_missing
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh', 'on_missing': 'skip'})
    lookup_module.run(['remote_tmp'])

    # Test with plugin_type and plugin_name and on_missing
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:18:52.404991
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:18:58.470788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1513164922.86-247599098241869']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])

# Generated at 2022-06-17 12:19:08.401113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == [u'/tmp/ansible-tmp-1512086607.3-144514646825983']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_plugin.run(['remote_user', 'port'])
    assert result == [u'root', 22]

    # Test with plugin_

# Generated at 2022-06-17 12:19:18.551737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:19:25.124404
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    try:
        lookup_module.run(['UNKNOWN'])
        assert False, 'AnsibleLookupError should be raised'
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in to_native(e)

    # Test with missing plugin
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'UNKNOWN'})

# Generated at 2022-06-17 12:19:39.530301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid plugin_type
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'invalid_type', 'plugin_name': 'invalid_name'})
    with pytest.raises(AnsibleOptionsError) as excinfo:
        lookup_module.run(terms=['invalid_term'])
    assert 'Both plugin_type and plugin_name are required, cannot use one without the other' in to_native(excinfo.value)

    # Test with invalid plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'invalid_name'})
    with pytest.raises(AnsibleLookupError) as excinfo:
        lookup_module.run

# Generated at 2022-06-17 12:19:52.248951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH']) == ['root', ['/etc/ansible/roles']]
    assert lookup_module.run(['DEFAULT_BECOME_USER', 'DEFAULT_ROLES_PATH', 'UNKNOWN']) == ['root', ['/etc/ansible/roles']]

    # Test with plugin_type and plugin_name

# Generated at 2022-06-17 12:20:03.284291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with plugin_type and plugin_name
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_user']) == ['root']
    # Test with plugin_type and plugin_name
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['remote_user', 'port']) == ['root', None]
    # Test with plugin_type and plugin_name
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module

# Generated at 2022-06-17 12:20:12.428840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lm = LookupModule()
    lm.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lm.run(terms=['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1517098981.75-249988357588760']

    # Test with plugin_type and plugin_name
    lm = LookupModule()
    lm.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lm.run(terms=['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with global config

# Generated at 2022-06-17 12:20:24.197208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock object for class LookupModule
    lookup_module = LookupModule()

    # Create a mock object for class LookupBase
    lookup_base = LookupBase()

    # Create a mock object for class C
    class C:
        DEFAULT_BECOME_USER = 'root'
        DEFAULT_ROLES_PATH = '/etc/ansible/roles'
        RETRY_FILES_SAVE_PATH = '/etc/ansible/retry'
        COLOR_OK = 'green'
        COLOR_CHANGED = 'yellow'
        COLOR_SKIP = 'blue'

    # Create a mock object for class plugin_loader
    class plugin_loader:
        class become_loader:
            @staticmethod
            def get(pname, class_only=True):
                return None


# Generated at 2022-06-17 12:21:04.946632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with invalid on_missing option
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'on_missing': 'invalid'})
    try:
        lookup_plugin.run(terms=['DEFAULT_ROLES_PATH'])
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid' in to_native(e)

    # Test with invalid plugin_type option
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'invalid'})

# Generated at 2022-06-17 12:21:16.304296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a valid term
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options={}, direct={})
    assert lookup_plugin.run(['DEFAULT_BECOME_USER']) == ['root']

    # Test with an invalid term
    lookup_plugin.set_options(var_options={}, direct={})
    assert lookup_plugin.run(['DEFAULT_BECOME_USER_INVALID']) == []

    # Test with an invalid term and on_missing set to error
    lookup_plugin.set_options(var_options={}, direct={'on_missing': 'error'})
    try:
        lookup_plugin.run(['DEFAULT_BECOME_USER_INVALID'])
    except AnsibleLookupError:
        pass
    else:
        assert False

# Generated at 2022-06-17 12:21:23.822170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1512856524.31-140581437444932']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])

# Generated at 2022-06-17 12:21:33.744573
# Unit test for method run of class LookupModule

# Generated at 2022-06-17 12:21:43.383738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing setting
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    terms = ['UNKNOWN']
    try:
        lookup_module.run(terms)
    except AnsibleLookupError as e:
        assert 'Unable to find setting UNKNOWN' in str(e)

    # Test with missing plugin
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error', 'plugin_type': 'shell', 'plugin_name': 'UNKNOWN'})
    try:
        lookup_module.run(terms)
    except AnsibleLookupError as e:
        assert 'Unable to load shell plugin "UNKNOWN"' in str(e)

    # Test with missing plugin_type
   

# Generated at 2022-06-17 12:21:52.108985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1513182436.87-264599078483431']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_plugin.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and plugin

# Generated at 2022-06-17 12:21:58.384938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})

# Generated at 2022-06-17 12:22:10.818390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:22:22.248344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_plugin.run(['remote_user'])
    assert result == ['root']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_plugin.run(['remote_user', 'port'])
    assert result == ['root', None]

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()

# Generated at 2022-06-17 12:22:28.878802
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    lookup_module.run(terms=['DEFAULT_BECOME_USER'], variables=None, **{})
    lookup_module.run(terms=['DEFAULT_ROLES_PATH'], variables=None, **{})
    lookup_module.run(terms=['RETRY_FILES_SAVE_PATH'], variables=None, **{})
    lookup_module.run(terms=['COLOR_OK', 'COLOR_CHANGED', 'COLOR_SKIP'], variables=None, **{})
    lookup_module.run(terms=['UNKNOWN'], variables=None, **{})

# Generated at 2022-06-17 12:23:51.148752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with missing option
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=['DEFAULT_BECOME_USER'])

    # Test with invalid setting identifier
    lookup_module.set_options(var_options=None, direct={'on_missing': 'error'})
    with pytest.raises(AnsibleOptionsError):
        lookup_module.run(terms=[None])

    # Test with invalid on_missing option
    lookup_module.set_options(var_options=None, direct={'on_missing': 'invalid'})

# Generated at 2022-06-17 12:24:00.638930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./lib/ansible/plugins/lookup')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/config')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/defaults')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/files')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/ini')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/json')
    lookup_loader.add_directory('./lib/ansible/plugins/lookup/password')

# Generated at 2022-06-17 12:24:08.844845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # test with plugin_type and plugin_name
    terms = ['remote_tmp']
    plugin_type = 'shell'
    plugin_name = 'sh'
    result = lookup.run(terms, plugin_type=plugin_type, plugin_name=plugin_name)
    assert result == ['/tmp/ansible-tmp-1519402751.47-251545482409822']
    # test without plugin_type and plugin_name
    terms = ['DEFAULT_BECOME_USER']
    result = lookup.run(terms)
    assert result == ['root']
    # test with invalid plugin_type and plugin_name
    terms = ['remote_tmp']
    plugin_type = 'shell'
    plugin_name = 'sh1'

# Generated at 2022-06-17 12:24:17.401862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    assert lookup_module.run(['accelerate_port']) == [None]
    assert lookup_module.run(['accelerate_port', 'accelerate_timeout']) == [None, 30]
    assert lookup_module.run(['accelerate_port', 'accelerate_timeout'], variables={'ansible_connection': 'local'}) == [None, 30]
    assert lookup_module.run(['accelerate_port', 'accelerate_timeout'], variables={'ansible_connection': 'ssh'}) == [None, 30]

# Generated at 2022-06-17 12:24:27.540465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-tmp-1518181161.6-251267754908764']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp/ansible-tmp-1518181161.6-251267754908764']

    # Test

# Generated at 2022-06-17 12:24:39.678045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:24:52.053213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'local'})
    result = lookup_module.run(['remote_tmp'])
    assert result == [C.DEFAULT_REMOTE_TMP]

    # Test with plugin_type and plugin_name
    lookup_module = Lookup

# Generated at 2022-06-17 12:25:03.462272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with no plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)
    assert lookup_module.run(['DEFAULT_BECOME_USER']) == ['root']

    # Test with plugin_type and plugin_name
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    assert lookup_module.run(['remote_tmp']) == ['/tmp']

    # Test with invalid plugin_type and plugin_name
    lookup_module = LookupModule()

# Generated at 2022-06-17 12:25:12.519677
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'shell', 'plugin_name': 'sh'})
    result = lookup_plugin.run(['remote_tmp'])
    assert result == ['/tmp/ansible-tmp-1513231518.2-253622342707933']

    # Test with plugin_type and plugin_name
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(var_options=None, direct={'plugin_type': 'connection', 'plugin_name': 'ssh'})
    result = lookup_plugin.run(['remote_user', 'port'])
    assert result == ['root', 22]

    # Test with plugin_type and plugin

# Generated at 2022-06-17 12:25:22.324686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={}, direct={})
    lookup_module.get_option = lambda x: 'error'
    lookup_module._display = lambda x: None
    lookup_module._get_plugin_config = lambda x, y, z, w: None
    lookup_module._get_global_config = lambda x: None

    # test with invalid on_missing value
    try:
        lookup_module.run(['DEFAULT_BECOME_USER'], {}, on_missing='invalid')
    except AnsibleOptionsError as e:
        assert '"on_missing" must be a string and one of "error", "warn" or "skip", not invalid' in str(e)

    # test with invalid term value