

# Generated at 2022-06-24 10:49:20.347121
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    # Test if it can correctly detect a datetime.date object
    type = DateFormat().is_native_type(datetime.date(2019, 7, 4))
    assert type == True

    # Test if it can correctly detect a datetime.time object
    type = DateFormat().is_native_type(datetime.time(12, 35, 56))
    assert type == False

    # Test if it can correctly detect a datetime.datetime object
    type = DateFormat().is_native_type(datetime.datetime(2019, 7, 4, 12, 35, 56))
    assert type == False

    # Test if it can correctly detect an int object
    type = DateFormat().is_native_type(5)
    assert type == False


# Generated at 2022-06-24 10:49:25.747360
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time = datetime.time(tzinfo= datetime.timezone.utc, hour=1, minute=19, second=56, microsecond=15000)
    time_format = TimeFormat()
    time_format.is_native_type(time)


# Generated at 2022-06-24 10:49:28.859389
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
  time = datetime.time(14, 25, 0)
  assert TimeFormat().serialize(time) == '14:25:00'


# Generated at 2022-06-24 10:49:30.547860
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert str(DateFormat().validate("2020-04-27")) == "2020-04-27"



# Generated at 2022-06-24 10:49:33.457386
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat = DateFormat()

    value = dateformat.validate("2019-11-25")
    assert value.year == 2019
    assert value.month == 11
    assert value.day == 25



# Generated at 2022-06-24 10:49:41.416819
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    uuid_obj = uuid.uuid4()
    assert isinstance(uuid_obj, uuid.UUID)
    assert isinstance(uuid_format.serialize(uuid_obj), str)


# Generated at 2022-06-24 10:49:45.451285
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    a = BaseFormat()
    with pytest.raises(NotImplementedError):
        a.validate(None)


# Generated at 2022-06-24 10:49:54.134563
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Creating a DateFormat to test
    format_to_test = DateFormat()
    # Test case 1
    assert format_to_test.validate('2016-10-11') == datetime.date(2016, 10, 11)
    # Test case 2
    assert format_to_test.validate('2016-10-11') == datetime.date(2016, 10, 11)
    # Test case 3
    assert format_to_test.validate('2016-10-11') == datetime.date(2016, 10, 11)
    # Test case 4
    assert format_to_test.validate('2016-10-11') == datetime.date(2016, 10, 11)


# Generated at 2022-06-24 10:49:58.114381
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    test_Date_object = datetime.date(2020, 4, 2)
    test_Date_object_expected = "2020-04-02"
    assert DateFormat().serialize(test_Date_object) == test_Date_object_expected



# Generated at 2022-06-24 10:50:09.392742
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate("00:00") == datetime.time(hour=0, minute=0)
    assert tf.validate("23:59:59.123456") == datetime.time(hour=23, minute=59, second=59, microsecond=123456)

    with pytest.raises(ValidationError) as exc:
        tf.validate("24:00")
    assert exc.value.code == 'invalid'

    with pytest.raises(ValidationError) as exc:
        tf.validate("00:00:70")
    assert exc.value.code == 'invalid'

    with pytest.raises(ValidationError) as exc:
        tf.validate("00:00:0Z")
    assert exc.value.code == 'format'



# Generated at 2022-06-24 10:50:19.482440
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    format = BaseFormat()

    assert format.is_native_type(None) is False
    assert format.is_native_type('2020-01-01') is False
    assert format.is_native_type(datetime.date(2020, 1, 1)) is False
    assert format.is_native_type(datetime.time(0, 0, 0)) is False
    assert format.is_native_type(datetime.datetime(2020, 1, 1, 0, 0, 0)) is False
    assert format.is_native_type(uuid.uuid4()) is False


# Generated at 2022-06-24 10:50:25.626766
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    expected = "2018-06-27T15:47:04.216000Z"
  
    # the value of parameter obj is an instance of class datetime.datetime.
    # the value of parameter obj has been converted to datetime.datetime.
    obj = datetime.datetime.strptime("2018-06-27T15:47:04.216000+00:00", "%Y-%m-%dT%H:%M:%S.%f%z")
    
    result = DateTimeFormat().serialize(obj)
    assert result == expected


# Generated at 2022-06-24 10:50:28.126492
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    print("Unit test for constructor of class BaseFormat")
    test_object = BaseFormat()
    print("Pass Unit test for constructor of class BaseFormat")

# Generated at 2022-06-24 10:50:31.434766
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class BaseFormat(BaseFormat):
        def is_native_type(self, value):
            return False
        def validate(self, value):
            return None
    assert BaseFormat().serialize(None) == None

# Generated at 2022-06-24 10:50:34.330310
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    if __name__ == "__main__":
        uuid_example = uuid.uuid4()
        uuid_example_string = str(uuid_example)
        assert str(uuid_example) == UUIDFormat().serialize(uuid_example)


# Generated at 2022-06-24 10:50:36.709408
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d = datetime.date(2020, 1, 1)
    type = DateFormat()
    assert (type.serialize(d) == '2020-01-01')



# Generated at 2022-06-24 10:50:40.307448
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    obj = DateFormat()

    assert obj.is_native_type(datetime.datetime(2020, 4, 29)) == False
    assert obj.is_native_type(datetime.date(2020, 4, 29)) == True


# Generated at 2022-06-24 10:50:43.369963
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    obj = datetime.date(year = 2020, month = 9, day = 22)
    assert date_format.serialize(obj) == '2020-09-22'
    obj = None
    assert date_format.serialize(obj) == None


# Generated at 2022-06-24 10:50:47.196461
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat().is_native_type(datetime.date(2020, 7, 14))
    assert DateFormat().is_native_type(datetime.date.today())


# Generated at 2022-06-24 10:50:51.652308
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat.is_native_type(1) == NotImplementedError
    assert BaseFormat.validate(1) == NotImplementedError
    assert BaseFormat.serialize(1) == NotImplementedError



# Generated at 2022-06-24 10:50:56.264841
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(10, 20, 30)
    assert TimeFormat().serialize(time) == "10:20:30"
    time = datetime.time(10, 20, 30, 400000)
    assert TimeFormat().serialize(time) == "10:20:30.400"

# Generated at 2022-06-24 10:51:00.046769
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test for valid datetime format
    result = DateTimeFormat().validate("2013-08-07T06:50:09Z")
    assert result == datetime.datetime(2013, 8, 7, 6, 50, 9, 0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-24 10:51:04.172678
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(10) == False

# Generated at 2022-06-24 10:51:09.548777
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    in_dateTime = datetime.datetime(2015, 9, 24, 8, 0)
    out_dateTime= datetime.datetime(2015, 9, 24, 8, 0)
    if DateTimeFormat().validate(in_dateTime) == out_dateTime:
        print("Passed")
    else:
        print("Failed")

test_DateTimeFormat()

# Generated at 2022-06-24 10:51:13.071265
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_form = UUIDFormat()
    uuid_form.validate("1b5700c2-f565-11e8-af5b-529269fb1459")


# Generated at 2022-06-24 10:51:15.935552
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    a_uuid = "abcdabcd-1234-5678-9012-1234abcd5678"
    assert UUIDFormat().serialize(a_uuid) == a_uuid

# Generated at 2022-06-24 10:51:21.466478
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(
        year=2020,
        month=7,
        day=8,
        hour=15,
        minute=21,
        second=32,
        microsecond=117000,
        tzinfo=datetime.timezone(datetime.timedelta(hours=0))
        )
    ) == '2020-07-08T15:21:32.117000'

# Generated at 2022-06-24 10:51:24.455894
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    UUIDFormat()

    try:
        UUIDFormat()
    except:
        assert False

# Generated at 2022-06-24 10:51:28.443212
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    datetimeFormat = DateTimeFormat()
    try:
        datetimeFormat.validate('2019-10-10T13:13:13')
    except ValidationError:
        pass
    else:
        assert False, "ValidationError did not occur."


# Generated at 2022-06-24 10:51:40.008577
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("2020-01-10") == datetime.date(2020, 1, 10)
    assert df.validate("  2020-1-01  ") == datetime.date(2020, 1, 1)
    with pytest.raises(ValidationError):
        df.validate("2020-01-10123")
    with pytest.raises(ValidationError):
        df.validate("2020-01-01aaa")
    with pytest.raises(ValidationError):
        df.validate("2020-01-00")
    with pytest.raises(ValidationError):
        df.validate("2020-02-30")


# Generated at 2022-06-24 10:51:50.337866
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem.fields import Format

    format = Format(DateTimeFormat)
    assert format.validate("2019-11-01T00:58:04.123Z") == datetime.datetime(
        year=2019, month=11, day=1, hour=0, minute=58, second=4, microsecond=123000, tzinfo=datetime.timezone.utc
    )
    assert format.validate("2019-11-01T00:58:04.12Z") == datetime.datetime(
        year=2019, month=11, day=1, hour=0, minute=58, second=4, microsecond=120000, tzinfo=datetime.timezone.utc
    )

# Generated at 2022-06-24 10:51:51.653253
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    obj = UUIDFormat()
    assert isinstance(obj, UUIDFormat)

# Generated at 2022-06-24 10:51:58.307591
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    with pytest.raises(ValidationError) as exc_info:
        t.validate("Not valid format")
    assert str(exc_info.value) == "Must be a valid time format."

    time = t.validate("12:30:45.678912")
    assert time.hour == 12
    assert time.minute == 30
    assert time.second == 45
    assert time.microsecond == 678912

    time = t.validate("12:30")
    assert time.hour == 12
    assert time.minute == 30

# Generated at 2022-06-24 10:51:59.349133
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    UUIDFormat()
    assert True


# Generated at 2022-06-24 10:52:01.896728
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dt = '2019-07-20T12:00:00Z'
    dt_format = DateTimeFormat()
    print(dt_format.validate(dt))


# Generated at 2022-06-24 10:52:04.381216
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    f = BaseFormat()
    # test that the function raises a NotImplementedError
    try:
        f.serialize(1)
        assert False
    except NotImplementedError:
        pass

# Generated at 2022-06-24 10:52:08.039816
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(1, 2)) == True
    assert time_format.is_native_type(1) == False
    assert time_format.is_native_type("asdf") == False



# Generated at 2022-06-24 10:52:09.532380
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat().validation_error("format").text == "Must be a valid format."


# Generated at 2022-06-24 10:52:17.319385
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj1 = datetime.datetime(2018, 11, 19, 15, 21, 48, 702817)
    obj2 = datetime.datetime(2019, 5, 9, 19, 3, 55, 937819)
    serialized1 = DateFormat().serialize(obj1)
    serialized2 = DateFormat().serialize(obj2)
    assert serialized1 == "2018-11-19"
    assert serialized2 == "2019-05-09"

# Generated at 2022-06-24 10:52:20.440886
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    # Test for the variable `errors`
    assert tf.errors == {'format': 'Must be a valid time format.', 'invalid': 'Must be a real time.'}

# Generated at 2022-06-24 10:52:23.829840
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uid = '35fc89a8-ee70-11e7-a390-68f728177d82'
    assert uuid.UUID(uid).hex == uuid.UUID(uid).bytes
    theUUIDFormat = UUIDFormat()
    assert theUUIDFormat.serialize(uuid.UUID(uid)) == uid


# Generated at 2022-06-24 10:52:26.211816
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dt1 = datetime.datetime(2010, 1, 19, 3, 14, 15)
    assert DateTimeFormat().is_native_type(dt1) == True


# Generated at 2022-06-24 10:52:29.884898
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf=TimeFormat()
    assert tf.serialize(datetime.time(12,20)) == "12:20:00"
    assert tf.serialize(datetime.time(12,20,34,123123)) == "12:20:34.123123"
    assert tf.serialize(None) == None

# Generated at 2022-06-24 10:52:33.169112
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    class test:
        format = '%Y-%m-%d'

    obj = datetime.datetime(2020, 2, 20)
    serialized_obj = DateFormat().serialize(obj)
    assert serialized_obj == '2020-02-20'


# Generated at 2022-06-24 10:52:42.435164
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("13:40:40") == datetime.time(hour=13, minute=40, second=40)
    assert time_format.validate("13:40:40.450450") == datetime.time(hour=13, minute=40, second=40, microsecond=450450)
    assert time_format.validate("13:40") == datetime.time(hour=13, minute=40)
    assert time_format.validate("13:40:40.450") == datetime.time(hour=13, minute=40, second=40, microsecond=450000)


# Generated at 2022-06-24 10:52:45.661328
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) is None


# Generated at 2022-06-24 10:52:48.152052
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuidObject = uuid.uuid4()
    obj = UUIDFormat()
    assert obj.serialize(uuidObject) == str(uuidObject)

# Generated at 2022-06-24 10:52:54.033776
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    # Test case 1
    d1 = datetime.date(2020, 2, 8)
    dateFormat = DateFormat()
    assert dateFormat.is_native_type(d1) == True
    # Test case 2
    d2 = datetime.date(2001, 12, 31)
    assert dateFormat.is_native_type(d2) == True



# Generated at 2022-06-24 10:52:57.895925
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True
    assert DateTimeFormat().is_native_type(datetime.time(1,1,1)) == False


# Generated at 2022-06-24 10:52:59.214585
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    def sample():
        time_format = TimeFormat()  # noqa
    sample()

# Generated at 2022-06-24 10:53:00.672735
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type("a") == False


# Generated at 2022-06-24 10:53:09.941808
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    timeFormat = TimeFormat()
    

    # Test with time
    time_obj = datetime.time(12, 30, 30)
    time_iso = timeFormat.serialize(time_obj)
    assert time_iso == "12:30:30", "serialize should return time in isoformat"

    # Test with time
    time_obj = datetime.time(12, 30, 30, 500000)
    time_iso = timeFormat.serialize(time_obj)
    assert time_iso == "12:30:30.500000", "serialize should return time in isoformat"


# Generated at 2022-06-24 10:53:12.854840
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    # test for unique conditions
    assert DateFormat().is_native_type(datetime.date.today())
    assert not DateFormat().is_native_type(10)
    return



# Generated at 2022-06-24 10:53:14.691570
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type(): 
    tf = TimeFormat() 
    assert tf.is_native_type('00:00:00') == False


# Generated at 2022-06-24 10:53:20.832634
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate('12:00') == datetime.time(12, 0)
    assert tf.validate('12:00:00') == datetime.time(12, 0)
    assert tf.validate('12:00:00.123456') == datetime.time(12, 0, 0, 123456)
    assert tf.validate('12:00:00.000001') == datetime.time(12, 0, 0, 1)

# Generated at 2022-06-24 10:53:27.642379
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
	test_obj = UUIDFormat()
	assert test_obj.errors["format"] == "Must be valid UUID format."
	assert test_obj.is_native_type(uuid.UUID("00000000-0000-0000-0000-000000000000")) == True
	assert test_obj.is_native_type("UUID4") == False
	assert test_obj.validate("00000000-0000-0000-0000-000000000000") == uuid.UUID("00000000-0000-0000-0000-000000000000")
	assert test_obj.validate("00000000-0000-0000-0000-") == uuid.UUID("00000000-0000-0000-0000-000000000000")
	assert test_obj.serialize(uuid.UUID("00000000-0000-0000-0000-000000000000")) == "00000000-0000-0000-0000-000000000000" #obj is

# Generated at 2022-06-24 10:53:35.532770
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-05-17T07:40") == datetime.datetime(2019, 5, 17, 7, 40)
    assert DateTimeFormat().validate("2019-05-17T07:40:00") == datetime.datetime(2019, 5, 17, 7, 40)
    assert DateTimeFormat().validate("2019-05-17T07:40:15") == datetime.datetime(2019, 5, 17, 7, 40, 15)
    assert DateTimeFormat().validate("2019-05-17T07:40:15.123456") == datetime.datetime(2019, 5, 17, 7, 40, 15, 123456)

# Generated at 2022-06-24 10:53:37.001576
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(1) == True


# Generated at 2022-06-24 10:53:46.629669
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    fmt = TimeFormat()
    
    # test with a valid time input
    value = "16:11:24"
    time = fmt.validate(value)
    assert time.hour == 16
    assert time.minute == 11
    assert time.second == 24
    
    # test with a time input not in 24 hour format
    value = "4:11:24"
    time = fmt.validate(value)
    assert time.hour == 4
    assert time.minute == 11
    assert time.second == 24
    
    # test with a invalid time input
    value = "10:11:67"
    try:
        fmt.validate(value)
    except ValidationError:
        return
    
    assert False
    

# Generated at 2022-06-24 10:53:57.669952
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_format = TimeFormat()
    # case 1
    try:
        time_format.validate('12:30')
    except ValidationError as e:
        assert 0
    # case 2
    try:
        time_format.validate('26:30')
        assert 0
    except ValidationError as e:
        assert 1
    # case 3
    try:
        time_format.validate('12:123')
        assert 0
    except ValidationError as e:
        assert 1
    # case 4
    try:
        time_format.validate('12:30:60')
        assert 0
    except ValidationError as e:
        assert 1


# Generated at 2022-06-24 10:53:59.434604
# Unit test for constructor of class DateFormat
def test_DateFormat():
    x = DateFormat()
    assert isinstance(x, DateFormat)


# Generated at 2022-06-24 10:54:03.015470
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    with pytest.raises(ValidationError):
        format.validate(value="not a valid UUID")



# Generated at 2022-06-24 10:54:04.674904
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())



# Generated at 2022-06-24 10:54:06.103576
# Unit test for constructor of class BaseFormat

# Generated at 2022-06-24 10:54:16.962903
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()
    assert format.validate('2014-12-31T00:00:00Z') == datetime.datetime(2014, 12, 31, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert format.validate('2014-12-31T00:00:00-08:00') == datetime.datetime(2014, 12, 31, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=-8)))
    assert format.validate('2014-12-31T00:00:00-0800') == datetime.datetime(2014, 12, 31, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=-8)))

# Generated at 2022-06-24 10:54:19.036378
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    bf = BaseFormat()
    with pytest.raises(NotImplementedError):
        bf.validate("otro")


# Generated at 2022-06-24 10:54:28.699391
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()
    assert timeformat.validate("09:11") == datetime.time(9, 11)
    assert timeformat.validate("09:11:55") == datetime.time(9, 11, 55)
    assert timeformat.validate("09:11:55.000054") == datetime.time(9, 11, 55, 54)
    assert timeformat.validate("09:11:55.0000540") == datetime.time(9, 11, 55, 54)
    assert timeformat.validate("09:11:55.0000543") == datetime.time(9, 11, 55, 54)



# Generated at 2022-06-24 10:54:33.305374
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    error_message = "Must be valid UUID format."
    uuid_invalid_format = UUIDFormat()
    # invalid UUID format
    assert uuid_invalid_format.validate("8b464e") == ValidationError(text=error_message, code='format')


# Generated at 2022-06-24 10:54:36.278743
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    uuid_val = '00000000-0000-0000-0000-000000000000'
    uuid_obj = uuid.UUID(uuid_val)
    assert uuid_format.serialize(uuid_obj) == uuid_val

# Generated at 2022-06-24 10:54:39.841476
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    try:
        BaseFormat.validate(None,0)
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-24 10:54:45.434475
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("1999-12-31") == datetime.date(1999, 12, 31)
    assert DateFormat().validate("2000-01-01") == datetime.date(2000, 1, 1)
    assert DateFormat().validate("2000-12-31") == datetime.date(2000, 12, 31)
    assert DateFormat().validate("2001-01-01") == datetime.date(2001, 1, 1)


# Generated at 2022-06-24 10:54:49.379253
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_obj = UUIDFormat()
    assert uuid_obj.is_native_type(12345) == False
    assert uuid_obj.is_native_type(uuid.UUID('12345678-1234-5678-1234-567812345678')) == True

# Generated at 2022-06-24 10:54:53.848520
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    pass



# Generated at 2022-06-24 10:54:58.054340
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # posive test case
    date = DateFormat()
    assert date.validate('2018-10-25') == datetime.date(2018, 10, 25)
    # negative test case
    try:
        date.validate('2019-02-29')
    except ValidationError as e:
        assert e.code == 'invalid'
    # another negative test case
    try:
        date.validate('2019-02')
    except ValidationError as e:
        assert e.code == 'format'


# Generated at 2022-06-24 10:55:00.507807
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert isinstance(DateTimeFormat(name="test"), DateTimeFormat)

# Generated at 2022-06-24 10:55:02.804249
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    bf = BaseFormat()
    with pytest.raises(NotImplementedError):
        bf.is_native_type(5)


# Generated at 2022-06-24 10:55:03.981964
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    print("test_DateTimeFormat")
    assert DateTimeFormat()
    return True

# Generated at 2022-06-24 10:55:05.925223
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    # Expecting that everything is fine!
    UUIDFormat()


# Generated at 2022-06-24 10:55:13.547848
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    # Test with valid arguments
    b = BaseFormat()

    # Test with invalid arguments
    with pytest.raises(NotImplementedError):
        assert b.is_native_type(3)
    with pytest.raises(NotImplementedError):
        assert b.validate(3)
    with pytest.raises(NotImplementedError):
        assert b.serialize(3)



# Generated at 2022-06-24 10:55:15.884271
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    data = '2020-10-15'
    validate = DateFormat()
    assert validate.validate(data) == datetime.date(2020, 10, 15)


# Generated at 2022-06-24 10:55:21.949848
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(year=2010, month=6, day=10, hour=13, minute=20, second=10, microsecond =0, tzinfo=None)
    obj1 = UNIXDateTimeFormat()
    assert obj1.serialize(obj) == "2010-06-10T13:20:10Z"

# Generated at 2022-06-24 10:55:23.360479
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    fmt = TimeFormat()
    fmt.validate('12:00:00.000000')

# Generated at 2022-06-24 10:55:31.923022
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert DateFormat().serialize(datetime.date(2019, 2, 11)) == "2019-02-11"
    assert TimeFormat().serialize(datetime.time(23, 59)) == "23:59:00+00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 2, 11, 23, 59)) == "2019-02-11T23:59:00+00:00"
    assert UUIDFormat().serialize(uuid.UUID('a165f338-53d7-45ec-a9bd-dcacb2e20d65')) == "a165f338-53d7-45ec-a9bd-dcacb2e20d65"

# Generated at 2022-06-24 10:55:33.840457
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    test_format = BaseFormat()
    assert test_format.errors == {}


# Generated at 2022-06-24 10:55:42.023056
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    fmt = UUIDFormat()
    uuid_valid = uuid.uuid4()
    uuid_invalid = "1a2f1be544aa4db3b6a2dd6dc8b69f9b"
    assert fmt.is_native_type(uuid_valid)
    assert fmt.is_native_type(uuid_invalid)
    assert fmt.validate(uuid_valid) == uuid_valid
    assert uuid.UUID(fmt.validate(uuid_invalid)) == uuid_invalid
    assert fmt.serialize(uuid_valid) == str(uuid_valid)
    assert fmt.serialize(uuid_invalid) == uuid_invalid

# Generated at 2022-06-24 10:55:43.539723
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True

# Generated at 2022-06-24 10:55:56.193809
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    from datetime import datetime, timezone
    from time import time
    from pytz import timezone
    import uuid
    from typesystem import String
    from typesystem.integer import Integer
    from typesystem.number import Number
    from typesystem.formats import DateTimeFormat
    from typesystem.object import Object, Field
    from typesystem.schema import Schema

    # create class
    class Test(Object):
        id = Integer(primary_key=True)
        name = String(required=True)
        created_at = DateTimeFormat()

    obj = Test.create({"id": 1, "name": "John", "created_at": datetime.utcnow()})
    assert obj.created_at.replace(tzinfo=timezone.utc).isoformat() == obj.serialize()["created_at"]

# Generated at 2022-06-24 10:55:59.089851
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    date = datetime.datetime.now()
    date = date.replace(microsecond=0)
    assert DateTimeFormat().is_native_type(date)

# Generated at 2022-06-24 10:56:00.282250
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    test_obj = UUIDFormat()


# Generated at 2022-06-24 10:56:04.654647
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    obj = DateTimeFormat().validate("2020-05-28T18:00:18Z")
    assert obj == datetime.datetime(2020, 5, 28, 18, 0, 18, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-24 10:56:15.062415
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    try:
        UUIDFormat().validate('35f2b9c9')
    except Exception as e:
        assert str(e) == 'Must be valid UUID format.'
    try:
        UUIDFormat().validate('35f2b9c9-f3b0')
    except Exception as e:
        assert str(e) == 'Must be valid UUID format.'
    try:
        UUIDFormat().validate('35f2b9c9-f3b0-41ed-8a6f-')
    except Exception as e:
        assert str(e) == 'Must be valid UUID format.'

# Generated at 2022-06-24 10:56:25.925488
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert(isinstance(DateTimeFormat().validate("2020-03-10T12:00:00"), datetime.datetime))
    assert(DateTimeFormat().validate("2020-03-10T12:00:00") == datetime.datetime(2020, 3, 10, 12, 0, 0))
    assert(DateTimeFormat().validate("2020-03-10T12:00:00+00:00") == datetime.datetime(2020, 3, 10, 12, 0, 0, tzinfo=datetime.timezone.utc))
    assert(DateTimeFormat().validate("2020-03-10T12:00:00-05:00") == datetime.datetime(2020, 3, 10, 12, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=-5))))

# Generated at 2022-06-24 10:56:37.724360
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    f = DateTimeFormat()
    a = f.validate("2020-06-02T03:04:05.123456+07:30")
    print(a)
    assert a == datetime.datetime(2020, 6, 2, 3, 4, 5, 123456, \
        datetime.timezone(datetime.timedelta(seconds=27000)))
    b = f.validate("2020-06-02T03:04:05Z")
    print(b)
    assert b == datetime.datetime(2020, 6, 2, 3, 4, 5, 0, datetime.timezone.utc)
    c = f.validate("2020-06-02T03:04:05+07:30")
    print(c)

# Generated at 2022-06-24 10:56:45.057383
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    format = UUIDFormat()
    # Test serialize succeeds when UUID is valid
    obj = uuid.UUID('78d6a5e3-f741-11e8-adc0-fa7ae01bbebc')
    assert format.is_native_type(obj)
    assert format.serialize(obj) == '78d6a5e3-f741-11e8-adc0-fa7ae01bbebc'

# Generated at 2022-06-24 10:56:47.265209
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    bf = BaseFormat()
    assert bf.is_native_type(None) is False

# Generated at 2022-06-24 10:56:55.426845
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    import uuid
    UUID_REGEX = re.compile(
        r"[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}"
    )
    s = uuid.uuid4()
    s = str(s)
    # Verify the format of the string is uuid
    assert(UUID_REGEX.match(s))
    # The output of the validate method is a class uuid.UUID
    assert(type(UUIDFormat().validate(s)) == uuid.UUID)


# Generated at 2022-06-24 10:57:03.230626
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    a = BaseFormat()
    b = a.validation_error("invalid")
    assert(b.code == "invalid")
    assert(b.text == "Invalid value.")
    assert(b.path == "")



# Generated at 2022-06-24 10:57:05.004088
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    BaseFormat()


# Generated at 2022-06-24 10:57:07.396179
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate('272d919e-cfe5-481a-8d25-0a86a34c6002')

# Generated at 2022-06-24 10:57:15.491562
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat().validate("2020-03-04T12:34:43.234400")
    assert DateTimeFormat().validate("2020-03-04T12:34:43.234400+09:00")
    assert DateTimeFormat().validate("2020-03-04T12:34:43.234400Z")
    assert DateTimeFormat().validate("2020-03-04T12:34:43+09:00")

# Generated at 2022-06-24 10:57:24.511767
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTime = "2020-03-25T00:00:00+08:00"
    result = DateTimeFormat().validate(dateTime)
    assert result == datetime.datetime(2020, 3, 25, tzinfo=datetime.timezone(datetime.timedelta(hours=8)))

    dateTime1 = "2020-03-25T00:00:00Z"
    result1 = DateTimeFormat().validate(dateTime1)
    assert result1 == datetime.datetime(2020, 3, 25, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-24 10:57:27.097106
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    obj = datetime.time(23, 59, 59, 999999)
    assert time_format.serialize(obj) == '23:59:59.999999'


# Generated at 2022-06-24 10:57:32.440985
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    # test_UUIDFormat_serialize_is_callable
    assert callable(UUIDFormat().serialize)

    # test_UUIDFormat_serialize_returns_str
    assert isinstance(UUIDFormat().serialize(obj = uuid.UUID('{123e4567-e89b-12d3-a456-426655440000}')), str)

    # test_UUIDFormat_serialize_returns_none
    assert UUIDFormat().serialize(obj = None) is None


# Generated at 2022-06-24 10:57:39.098142
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    u1 = uuid.uuid4()
    u2 = UUIDFormat().validate(u1)
    assert u1 == u2 is True
    u2 = UUIDFormat().validate(str(u1))
    assert u1 == u2 is True
    u2 = UUIDFormat().validate(u1.hex)
    assert u1 == u2 is True


FORMATS: typing.Dict[str, typing.Type[BaseFormat]] = {
    "date": DateFormat,
    "datetime": DateTimeFormat,
    "time": TimeFormat,
    "uuid": UUIDFormat,
}

__all__ = list(FORMATS.keys())

# Generated at 2022-06-24 10:57:42.743166
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time(3,56)) == True
    assert TimeFormat().is_native_type(7) == False


# Generated at 2022-06-24 10:57:43.747559
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert UUIDFormat()


# Generated at 2022-06-24 10:57:53.028582
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class BaseFormat_test(BaseFormat):
        errors = {}

    baseformat_test = BaseFormat_test()
    baseformat_test.errors['code_a'] = 'Error code a is written'
    with pytest.raises(NotImplementedError):
        baseformat_test.validate(None)
    with pytest.raises(NotImplementedError):
        baseformat_test.is_native_type(None)
    with pytest.raises(NotImplementedError):
        baseformat_test.serialize(None)
    assert isinstance(baseformat_test.validation_error('code_a'), ValidationError)



# Generated at 2022-06-24 10:57:55.789086
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    date_time = datetime.datetime(2019, 5, 2, 11, 34, 57)
    assert date_time_format.serialize(date_time) == '2019-05-02T11:34:57'
    
    

# Generated at 2022-06-24 10:58:00.377182
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert UUIDFormat().validate("abcdef01-234-11e4-a4f4-123b93f75cba") == uuid.UUID("abcdef01-234-11e4-a4f4-123b93f75cba")

test_UUIDFormat_validate()

# Generated at 2022-06-24 10:58:01.272788
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    assert bf.errors == {}


# Generated at 2022-06-24 10:58:05.792001
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    this_format = TimeFormat()
    time = datetime.time(22, 33, 44, 500000)
    actual = this_format.serialize(time)
    assert actual == '22:33:44.500000'


# Generated at 2022-06-24 10:58:07.578702
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date.today()) == True


# Generated at 2022-06-24 10:58:12.724993
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    # test invalid format
    value = "1234-56-78T12:34:56.78+90:00"
    match = DATETIME_REGEX.match(value)
    assert match == None



# Generated at 2022-06-24 10:58:22.960328
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
	date_time = DateTimeFormat()
	regex = DATETIME_REGEX
	# Valid case
	value = datetime.datetime(2020,2,2,20,20,20,20,datetime.timezone.utc)
	assert value == date_time.validate(value.isoformat())
	# Invalid case
	value = datetime.datetime(2020,2,2,20,20,20,20,datetime.timezone.utc)
	assert date_time.validation_error("invalid") == date_time.validate(value)
	# Format case
	value = datetime.datetime(2020,2,2,20,20,20,20,datetime.timezone.utc)

# Generated at 2022-06-24 10:58:25.724213
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuidformat = UUIDFormat()
    assert type(uuidformat.validate('c5c69877-3427-4701-bab7-fac3b07a9b9d')) is uuid.UUID


# Generated at 2022-06-24 10:58:26.690034
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    a = DateTimeFormat()
    return a

# Generated at 2022-06-24 10:58:28.350173
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    base_format = BaseFormat()
    assert base_format.serialize(None) == None


# Generated at 2022-06-24 10:58:35.705824
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # test variable
    errors = {
        "format": "Must be a valid date format.",
        "invalid": "Must be a real date.",
    }
    # test instance
    bf = BaseFormat()
    bf.errors = errors
    code = "format"
    # check expected result
    assert(bf.validation_error(code) == ValidationError(text="Must be a valid date format.", code=code))


# Generated at 2022-06-24 10:58:38.897687
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    assert time_format.serialize(datetime.time(12, 4)) == "12:04:00"



# Generated at 2022-06-24 10:58:42.052218
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    dfmt = DateFormat()
    assert dfmt.serialize(datetime.date.today()) == datetime.date.today().isoformat()
    assert dfmt.serialize(None) == None



# Generated at 2022-06-24 10:58:51.217113
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time = DateTimeFormat()
    assert date_time.validate('2016-10-12T11:23:45Z') == datetime(2016, 10, 12, 11, 23, 45, tzinfo=datetime.timezone.utc)
    assert date_time.validate('2016-10-12T11:23:45+05:00') == datetime(2016, 10, 12, 11, 23, 45, tzinfo=datetime.timezone(datetime.timedelta(hours=5)))
    assert date_time.validate('2016-10-12T11:23:45-05:00') == datetime(2016, 10, 12, 11, 23, 45, tzinfo=datetime.timezone(datetime.timedelta(hours=-5)))

# Generated at 2022-06-24 10:58:55.885523
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize(uuid.UUID('123e4567-e89b-12d3-a456-426614174000')) == '123e4567-e89b-12d3-a456-426614174000'

# Generated at 2022-06-24 10:59:06.490260
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    u = UUIDFormat()
    # Test validation_error
    assert (u.validation_error("format").text == "Must be valid UUID format.")
    # Test is_native_type
    assert (u.is_native_type(uuid.uuid1()) == True)
    # Test validate
    assert (str(u.validate("5163c55a-5e1a-11ea-8e66-0242ac130003")) == "5163c55a-5e1a-11ea-8e66-0242ac130003")
    # Test serialize
    assert (u.serialize(uuid.uuid1()) == str(uuid.uuid1()))

# Generated at 2022-06-24 10:59:17.666827
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from datetime import datetime
    from .base import ValidationError

    class TestFormat(DateTimeFormat):
            pass

    try:
        TestFormat().validate('2020-01-31')
    except ValidationError:
        print('Exception thrown for invalid datetime format')

    # TODO: Add invalid datetime format

    try:
        TestFormat().validate('2020-01-31T21:17:56.123456')
    except ValidationError:
        print('Exception thrown for invalid datetime format')

    try:
        TestFormat().validate('2020-01-31T21:17:56.123456Z')
    except ValidationError:
        print('Exception thrown for invalid datetime format')
