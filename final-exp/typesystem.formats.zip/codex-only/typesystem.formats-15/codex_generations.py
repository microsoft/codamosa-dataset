

# Generated at 2022-06-24 10:49:17.044808
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(DateFormat.is_native_type(datetime.date)) == True

# Generated at 2022-06-24 10:49:20.719471
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    a = DateFormat()
    assert a.serialize(None) == None
    assert a.serialize(datetime.date(2020, 5, 15)) == '2020-05-15'
    assert a.serialize(datetime.date(2020, 7, 18)) == '2020-07-18'



# Generated at 2022-06-24 10:49:23.817401
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    assert str(uuid.uuid4()) == uuid_format.serialize(uuid.uuid4())

# Generated at 2022-06-24 10:49:30.335035
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    
    tt = datetime.date(2019, 3, 3)
    tt = DateFormat()
    assert tt.serialize(tt) == "2019-03-03"
    fg = date.today()
    tt = DateFormat()
    assert tt.serialize(fg) == "2020-02-21"
    assert tt.serialize(None) == None
    

# Generated at 2022-06-24 10:49:35.067229
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    TimeFormat_instance = TimeFormat()
    date1 = TimeFormat_instance.validate("12:59:59")
    date2 = TimeFormat_instance.validate("12:59")
    date3 = TimeFormat_instance.validate("12")
    assert date1 == datetime.time(12,59,59)
    assert date2 == datetime.time(12,59)
    assert date3 == datetime.time(12)


# Generated at 2022-06-24 10:49:45.546908
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    # Construct a test_UUIDFormat object
    test_UUIDFormat_obj = UUIDFormat()

    # For this test, the input argument is None
    obj = None
    output = test_UUIDFormat_obj.serialize(obj)
    assert output is None

    # For this test, the input argument is an empty string
    obj = ''
    expected = "00000000-0000-0000-0000-000000000000"
    output = test_UUIDFormat_obj.serialize(obj)
    assert output == expected

    # For this test, the input argument is a valid UUID
    obj = '12345678-0000-0000-0000-000000000000'
    expected = "12345678-0000-0000-0000-000000000000"
    output = test_UUIDFormat_obj.serialize(obj)
    assert output == expected

# Generated at 2022-06-24 10:49:49.511359
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    fmt = BaseFormat()
    fmt.errors["id1"] = "error"
    try:
        fmt.validate(12)
    except ValidationError as e:
        assert e.code == "id1"
        assert e.text == "error"
    else:
        assert False

# Generated at 2022-06-24 10:49:50.075161
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    pass

# Generated at 2022-06-24 10:49:56.437999
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d = DateFormat()
    try :
        d2 = d.serialize(None)
        assert d2 == None
    except :
        assert False

    try :
        date = datetime.date(2019,9,12)
        d2 = d.serialize(date)
        assert d2 == "2019-09-12"
    except :
        assert False

    try :
        date = datetime.date(2019,13,12)
        d2 = d.serialize(date)
        assert False
    except :
        assert True

test_DateFormat_serialize()


# Generated at 2022-06-24 10:50:00.726401
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(second=1)
    serialize = TimeFormat()
    # TimeFormat() must return a string
    assert serialize.serialize(time) == '00:00:01'

# Generated at 2022-06-24 10:50:02.652303
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    obj = DateFormat()
    assert obj.serialize('2020-09-15') == '2020-09-15'

# Generated at 2022-06-24 10:50:04.199546
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time = TimeFormat()
    assert time.is_native_type(datetime.time(hour=12, minute=20, second=45, microsecond=10000))


# Generated at 2022-06-24 10:50:09.478340
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    test = '2020-05-18T15:11:50.704701'
    dt = DateTimeFormat()
    result = dt.validate(test)
    assert result.isoformat() == '2020-05-18T15:11:50.704701'


# Generated at 2022-06-24 10:50:16.223303
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    print("Testing constructor of class UUIDFormat")
    import os,sys
    current_folder = os.getcwd()
    sys.path.insert(1, f'{current_folder}/app/schema')
    from schema import MainSchema
    schema_instance = MainSchema()
    assert type(schema_instance) is MainSchema
    assert isinstance(schema_instance, MainSchema) == True

# Generated at 2022-06-24 10:50:20.824673
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    bf = BaseFormat()
    bf.errors = {'error': 'formaterror'}
    assert bf.validation_error('error') == ValidationError(text='formaterror',code='error')

# Generated at 2022-06-24 10:50:22.993083
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert str(uuid.uuid4()) == (UUIDFormat().serialize(uuid.uuid4()))

# Generated at 2022-06-24 10:50:24.919725
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    f = DateFormat()
    assert f.serialize(obj=datetime.date(2020, 1, 1)) == '2020-01-01'

# Generated at 2022-06-24 10:50:36.023715
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime(2019, 2, 1))
    assert not DateTimeFormat().is_native_type('')
    assert not DateTimeFormat().is_native_type(0)
    assert not DateTimeFormat().is_native_type(False)
    assert not DateTimeFormat().is_native_type({})
    assert not DateTimeFormat().is_native_type(())
    assert not DateTimeFormat().is_native_type(datetime.date(2019, 2, 1))
    assert not DateTimeFormat().is_native_type(datetime.time(1,2,3))
    assert not DateTimeFormat().is_native_type(datetime.datetime(2019, 2, 1).date())

# Generated at 2022-06-24 10:50:39.833912
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    thetime = datetime.time()
    thetime2 = datetime.datetime.now()
    thetime3 = "thetime"
    assert TimeFormat().is_native_type(thetime) == True
    assert TimeFormat().is_native_type(thetime2) == False
    assert TimeFormat().is_native_type(thetime3) == False


# Generated at 2022-06-24 10:50:40.779590
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    fmt = UUIDFormat()
    assert fmt


# Generated at 2022-06-24 10:50:46.678019
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
  test = DateFormat()
  # test1
  obj = datetime.date(2019, 12, 31)
  expected = "2019-12-31"
  assert test.serialize(obj) == expected
  # test2
  obj = datetime.date(1919, 12, 31)
  expected = "1919-12-31"
  assert test.serialize(obj) == expected
  # test3
  obj = datetime.date(1, 12, 31)
  expected = "0001-12-31"
  assert test.serialize(obj) == expected
  # test4
  obj = datetime.date(2000, 2, 29)
  expected = "2000-02-29"
  assert test.serialize(obj) == expected
  # test5

# Generated at 2022-06-24 10:50:50.836338
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    f1 = UUIDFormat()
    f2 = UUIDFormat()
    print(f1.is_native_type)
    print(f2.validate)
test_UUIDFormat()

# Generated at 2022-06-24 10:50:53.077809
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time()
    tf = TimeFormat()
    assert tf.serialize(obj) == "00:00:00"

# Generated at 2022-06-24 10:50:56.410309
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    b = BaseFormat()
    try:
        b.validation_error("format")
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 10:50:57.481705
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(12)) == '12:00:00'


# Generated at 2022-06-24 10:50:58.322122
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None

# Generated at 2022-06-24 10:50:59.415369
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    ex = BaseFormat()
    assert ex.serialize(1) == None


# Generated at 2022-06-24 10:51:04.113405
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date = DateFormat()
    print(date)


# Generated at 2022-06-24 10:51:06.354393
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    df.validate('2019-10-22')


# Generated at 2022-06-24 10:51:11.175219
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time1 = TimeFormat().validate("1:20:39")
    time2 = TimeFormat().validate("1:20")
    time3 = TimeFormat().validate("012039")
    assert time1 == datetime.time(1,20,39)
    assert time2 == datetime.time(1,20)
    assert time3 == datetime.time(1,20,39)


# Generated at 2022-06-24 10:51:14.808929
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date = datetime.datetime(2020, 8, 29, 12, 12, 12, 121212)
    dateString = "2020-08-29T12:12:12.121212"

    validator = DateTimeFormat()
    result = validator.serialize(date)

    assert result == dateString

# Generated at 2022-06-24 10:51:17.195088
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    with pytest.raises(Exception) as excinfo:
        TimeFormat(errors={"format": "Now"})

    assert str(excinfo.value) == "Now"

# Generated at 2022-06-24 10:51:19.677750
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date.today()
    date_format = DateFormat()
    date_format.serialize(date)

# Generated at 2022-06-24 10:51:22.199167
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    # noinspection PyTypeChecker
    assert date.validate("2020-03-10") == datetime.date(2020, 3, 10)



# Generated at 2022-06-24 10:51:25.963786
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    test_list = [datetime.datetime.now()]

    for item in test_list:
        assert DateTimeFormat().is_native_type(item)==True



# Generated at 2022-06-24 10:51:27.837971
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    TF1 = TimeFormat()
    assert TF1.is_native_type(datetime.time(23, 0)) == True

# Generated at 2022-06-24 10:51:37.856362
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem import DateTime

    type = DateTime()

    value = type.validate("2005-08-15T15:52:01+00:00")
    assert value == datetime.datetime(2005, 8, 15, 15, 52, 1, tzinfo=datetime.timezone.utc)

    value = type.validate("2005-08-15T15:52:01")
    assert value == datetime.datetime(2005, 8, 15, 15, 52, 1)

    value = type.validate("2005-08-15T15:52")
    assert value == datetime.datetime(2005, 8, 15, 15, 52)

    value = type.validate("2005-08-15T15")
    assert value == datetime.datetime(2005, 8, 15, 15)


# Generated at 2022-06-24 10:51:41.323233
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = UUIDFormat()
    assert isinstance(obj.serialize(uuid.uuid4()), str)


# Generated at 2022-06-24 10:51:45.274571
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
  """
  Test validate method of class DateFormat.
  """
  do_test_DateFormat_validate(DateFormat(), datetime.date(2012, 4, 27), "2012-04-27")


# Generated at 2022-06-24 10:51:56.499185
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(8, 15, 30, 123456)) == True
    assert time_format.is_native_type("2018-10-15") == False
    assert time_format.is_native_type("08:15:30") == False
    assert time_format.is_native_type("08:15:30.123456") == False
    assert time_format.is_native_type(datetime.datetime(2018, 10, 15, 8, 15, 30, 123456)) == False
    assert time_format.is_native_type(datetime.date(2018, 10, 15)) == False
    assert time_format.is_native_type(uuid.uuid4()) == False


# Generated at 2022-06-24 10:52:03.195452
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    format_obj = UUIDFormat()

    assert not format_obj.is_native_type("hello")
    assert not format_obj.is_native_type(1)
    assert not format_obj.is_native_type(object())
    assert not format_obj.is_native_type(uuid.uuid3(uuid.NAMESPACE_URL, "hello"))
    assert format_obj.is_native_type(uuid.uuid1())


# Generated at 2022-06-24 10:52:07.741675
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    tf.validate("00:00")
    tf.validate("00:60")
    tf.validate("24:00")
    tf.validate("15:33")
    tf.validate("15:33:15")
    tf.validate("15:33:15.123456")
    tf.validate("15:33:15.123")



# Generated at 2022-06-24 10:52:09.267713
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    obj = DateTimeFormat()
    assert isinstance(obj,BaseFormat), 'It is not instance of BaseFormat.'

# Generated at 2022-06-24 10:52:13.713967
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    value = "b"
    is_native_type = BaseFormat.is_native_type(value)
    assert is_native_type == False


# Generated at 2022-06-24 10:52:15.415954
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uid = uuid.uuid4()
    assert UUIDFormat().serialize(uid) == str(uid)


# Generated at 2022-06-24 10:52:20.047703
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    with pytest.raises(ValidationError) as exc:
        UUIDFormat().validate('a-b-c-d-e')
    assert exc.value.code == 'format'

# Generated at 2022-06-24 10:52:22.523013
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    dateformat = DateFormat()
    date = dateformat.validate('2020-06-10')
    assert dateformat.serialize(date) == '2020-06-10'
    assert dateformat.serialize(None) == None


# Generated at 2022-06-24 10:52:23.067017
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    BaseFormat()

# Generated at 2022-06-24 10:52:26.532123
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    msg = ValidationError(text='test', code='code')
    class BaseFormatMock(BaseFormat):
        def validation_error(self, code):
            return msg
    bfm = BaseFormatMock()
    assert bfm.validation_error('code') == msg

# Generated at 2022-06-24 10:52:29.830573
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    date_time_format = DateTimeFormat()

    # Test with a null value
    assert date_time_format.is_native_type(None) == False

    # Test with a datetime value
    val = datetime.datetime.now()
    assert date_time_format.is_native_type(val) == True


# Generated at 2022-06-24 10:52:31.142096
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None


# Generated at 2022-06-24 10:52:36.434552
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem.date_time import DateTimeFormat
    from typesystem.exceptions import ValidationError

    test_value = DateTimeFormat()
    # test_value.validate({'year': 2})

    try:
        assert test_value.validate({'year': 2})
    except ValidationError:
        pass

    test_value.validate('1999-01-01T00:00:00+00:00')
    # print('Method validate of class DateTimeFormat PASSED')



# Generated at 2022-06-24 10:52:39.275689
# Unit test for constructor of class DateFormat
def test_DateFormat():
    df = DateFormat()
    assert (df.validate('2015-03-03') == datetime.date(2015, 3, 3))


# Generated at 2022-06-24 10:52:44.944564
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    class Temp(BaseFormat):
        pass
    tmp = Temp()
    assert tmp.errors == {}


# Generated at 2022-06-24 10:52:47.971603
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid1 = uuid.uuid4()
    uuid2 = "1234"
    instance = UUIDFormat()
    assert instance.is_native_type(uuid1) == True
    assert instance.is_native_type(uuid2) == False
    

# Generated at 2022-06-24 10:52:58.869637
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    print("Unit Test for method validate of DateTimeFormat")
    dtf = DateTimeFormat()
    assert dtf.validate("") == "Must be a valid datetime format."
    assert dtf.validate("0123-05-03") == "Must be a valid datetime format."
    assert dtf.validate("0123-05-03T22") == "Must be a valid datetime format."
    assert dtf.validate("20123-02-03T10:11:12.12Z") == "Must be a real datetime."
    assert dtf.validate("2020-02-29T10:11:12.12Z") == "Must be a real datetime."
    assert dtf.validate("2020-02-31T10:11:12.12Z") == "Must be a real datetime."

# Generated at 2022-06-24 10:53:00.751153
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    u = UUIDFormat()
    assert isinstance(u, UUIDFormat)


# Generated at 2022-06-24 10:53:12.335110
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    # Setup:
    a = datetime.datetime(2020, 7, 31, 13, 37, 42, 251693)
    b = datetime.datetime(2020, 7, 31, 13, 37, 42, 251693, datetime.timezone.utc)
    c = datetime.datetime(2020, 7, 31, 13, 37, 42, 251693, datetime.timezone.utc)
    d = datetime.date(2020, 7, 31)
    e = datetime.time(13, 37, 42, 251693)
    f = '1234-56-78T90:12'
    g = '12345678'
    h = datetime.timedelta(days=1)
    i = datetime.timezone.utc

# Generated at 2022-06-24 10:53:15.278384
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    a = UUIDFormat().serialize(uuid.UUID("3fa85f64-5717-4562-b3fc-2c963f66afa6"))
    assert a == "3fa85f64-5717-4562-b3fc-2c963f66afa6"

# Generated at 2022-06-24 10:53:24.475936
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 2, 3, 4, 5, 6)) == "2019-01-02T03:04:05.000006"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 2, 3, 4, 5, 6, tzinfo=datetime.timezone.utc)) == "2019-01-02T03:04:05.000006Z"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 2, 3, 4, 5, 6, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))) == "2019-01-02T03:04:05.000006+02:00"

# Generated at 2022-06-24 10:53:25.972730
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True
    assert DateTimeFormat().is_native_type(1) == False

# Generated at 2022-06-24 10:53:31.313381
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uf = UUIDFormat()
    assert uf.is_native_type(None) == False
    assert uf.is_native_type(1) == False
    assert uf.is_native_type("1") == False
    assert uf.is_native_type(uuid.UUID("0f4d4171-90cf-43b3-b9b2-6c9f670e7776")) == True


# Generated at 2022-06-24 10:53:34.729004
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert isinstance(BaseFormat().is_native_type, NotImplementedError)


# Generated at 2022-06-24 10:53:39.072280
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.datetime.now().time())

# Generated at 2022-06-24 10:53:40.830193
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat.is_native_type(BaseFormat(), 10) == True

# Generated at 2022-06-24 10:53:45.553719
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert (DateFormat.serialize(datetime.datetime.now().date()) == datetime.datetime.now().date().isoformat())
    assert DateFormat.serialize(None) == None

# Generated at 2022-06-24 10:53:47.089472
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    d = DateFormat()
    d.validate("1996-10-10")


# Generated at 2022-06-24 10:53:58.567163
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert datetime.datetime(2019, 4, 17, 12, 30) == DateTimeFormat().validate("2019-04-17T12:30")
    assert datetime.datetime(2019, 4, 18, 0, 0, 1) == DateTimeFormat().validate("2019-04-18T00:00:01")
    assert datetime.datetime(2019, 4, 18, 0, 0, 1, 123000) == DateTimeFormat().validate("2019-04-18T00:00:01.123")
    assert datetime.datetime(2019, 4, 18, 0, 0, 1, 123456) == DateTimeFormat().validate("2019-04-18T00:00:01.123456")

# Generated at 2022-06-24 10:54:04.472694
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
	value_1 = datetime.datetime(2020,5,13,0,0)
	value_2 = "2020-05-13"
	ret_1 = DateFormat().is_native_type(value_1)
	ret_2 = DateFormat().is_native_type(value_2)
	assert ret_1 == True
	assert ret_2 == False


# Generated at 2022-06-24 10:54:07.200819
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    expected_value = "Subclass BaseFormat"
    actual_value = BaseFormat.__subclasses__()
    assert actual_value == expected_value, "Actual value is not equal to expected value."


# Generated at 2022-06-24 10:54:10.415627
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    assert t.validate('00:00:00.520000') == datetime.time(0, 0, 0, 520000)


# Generated at 2022-06-24 10:54:14.611186
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    d = DateTimeFormat()
    assert d.validate(value = '2019-01-01T01:01:01Z') == datetime.datetime(2019, 1, 1, 1, 1, 1, 0, datetime.timezone.utc)
    

# Generated at 2022-06-24 10:54:16.011495
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    e = BaseFormat()
    assert e.errors == {}


# Generated at 2022-06-24 10:54:18.615776
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    t = datetime.time(15, 10)
    t_str = tf.serialize(t)
    assert(t_str == "15:10:00")

# Generated at 2022-06-24 10:54:22.716635
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
	x = "550e8400-e29b-41d4-a716-446655440000"
	assert str(x) == UUIDFormat().serialize(x)



# Generated at 2022-06-24 10:54:27.088128
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize(uuid.UUID("1e29aa9a-51ef-4aaf-b68f-d8d2c018cc92")) == "1e29aa9a-51ef-4aaf-b68f-d8d2c018cc92"

# Generated at 2022-06-24 10:54:31.413238
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class DerivedFormat(BaseFormat):
        errors = {
            "error_code": "Error text with {name} substitution."
        }

    obj = DerivedFormat()
    error = obj.validation_error("error_code")
    
    assert error.text == "Error text with {name} substitution."
    assert error.code == "error_code"


# Generated at 2022-06-24 10:54:37.601338
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    value = datetime.datetime.now()
    assert isinstance(value, datetime.datetime)
    format = DateTimeFormat()
    assert format.is_native_type(value)


# Generated at 2022-06-24 10:54:40.852755
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    try:
        assert BaseFormat().validate(None)
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 10:54:43.506789
# Unit test for constructor of class DateFormat
def test_DateFormat():
    # Test for constructor when no argument is sent
    assert isinstance(DateFormat(), DateFormat)
    # Test for constructor when null value is sent
    assert isinstance(DateFormat(None), DateFormat)


# Generated at 2022-06-24 10:54:45.429255
# Unit test for constructor of class DateFormat
def test_DateFormat():
  DateFormat()


# Generated at 2022-06-24 10:54:51.558355
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
	# This is a normal test
    u = UUIDFormat()
    assert (u.is_native_type(uuid.UUID("f5e5d5dc-c1b8-4b12-83ce-e4e2c2f8d4b4")))
	# This is a bad test
    assert (u.is_native_type("f5e5d5dc-c1b8-4b12-83ce-e4e2c2f8d4b4"))
test_UUIDFormat()


# Generated at 2022-06-24 10:54:54.205850
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    t = datetime.datetime.now(datetime.timezone.utc)
    f = DateTimeFormat()
    assert f.serialize(t) == t.isoformat()

# Generated at 2022-06-24 10:54:56.020534
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    format = TimeFormat()
    time = datetime.datetime.now().time().isoformat()
    assert format.serialize(time) == time


# Generated at 2022-06-24 10:54:57.458336
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base_format = BaseFormat()
    assert base_format is not None


# Generated at 2022-06-24 10:55:01.879531
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format = BaseFormat()
    
    # Test with error code "format"
    with pytest.raises(NotImplementedError):
        format.validation_error("format")
        

# Generated at 2022-06-24 10:55:03.638899
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    assert 'abc' == BaseFormat().validate('abc')


# Generated at 2022-06-24 10:55:12.889797
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    for value in [True, 123, "2016-05-15T16:34:00.263453Z", None]:
        r = DateTimeFormat().is_native_type(value)
        assert r is False
    for value in [
        datetime.date.today(),
        datetime.date(2016,5,15),
        datetime.time(),
        datetime.time(16,34,00,263453),
        datetime.datetime.now(),
        datetime.datetime(2016,5,15,16,34,00,263453),
        datetime.datetime(2016,5,15,16,34,00,263453,tzinfo=datetime.timezone.utc),
    ]:
        r = DateTimeFormat().is_native_type(value)
        assert r is True

# Generated at 2022-06-24 10:55:19.854771
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time = datetime.datetime(2020, 5, 9, 17, 52)
    assert (DateTimeFormat().serialize(date_time) == "2020-05-09T17:52:00")
    date_time = datetime.datetime(2020, 5, 9, 17, 52, 12, 123456)
    assert (DateTimeFormat().serialize(date_time) == "2020-05-09T17:52:12.123456")
    date_time = datetime.datetime(2020, 5, 9, 17, 52, 12, 123456, datetime.timezone.utc)
    assert (DateTimeFormat().serialize(date_time) == "2020-05-09T17:52:12.123456Z")

# Generated at 2022-06-24 10:55:25.289463
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    from typesystem.error import ValidationError
    assert(UUIDFormat().validate("1f2d8d94-a0ab-11e9-8b99-c8d3ff3a6382") == uuid.UUID("1f2d8d94-a0ab-11e9-8b99-c8d3ff3a6382"))
    try:
        UUIDFormat().validate("1f2d8d94a0ab11e98b99c8d3ff3a6382")
    except ValidationError as e:
        assert(e.code == "format")


# Generated at 2022-06-24 10:55:28.032466
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    base_format = BaseFormat()
    with pytest.raises(NotImplementedError):
        base_format.validate(1)


# Generated at 2022-06-24 10:55:28.774933
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    raise NotImplementedError()


# Generated at 2022-06-24 10:55:32.679165
# Unit test for constructor of class DateFormat
def test_DateFormat():
    format = DateFormat()
    format.is_native_type(datetime.date(2000, 1, 1)) # True
    format.validate("2000-01-01") # datetime.date(2000, 1, 1)
    format.serialize(datetime.date(2000, 1, 1)) # "2000-01-01"


# Generated at 2022-06-24 10:55:36.826138
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    format = UUIDFormat()
    value = '2ebbdc40-4e4a-4c4b-84f4-c4b7eff9c99d'
    assert format.is_native_type(value)

# Generated at 2022-06-24 10:55:38.139803
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    f = BaseFormat()
    assert isinstance(f, BaseFormat)



# Generated at 2022-06-24 10:55:43.430962
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    val = "2020-12-25T19:14:10-06:00"
    datetime_type = DateTimeFormat()
    result = datetime_type.validate(val)

    assert result.isoformat() == "2020-12-25T19:14:10-06:00"



# Generated at 2022-06-24 10:55:48.981306
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u = UUIDFormat()
    assert u.validate('2cf8ffbd-62b1-48ff-96a2-f8ccb5a5f5a5') == '2cf8ffbd-62b1-48ff-96a2-f8ccb5a5f5a5'

# Generated at 2022-06-24 10:55:53.029685
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_str = '2021-07-12'
    assert date_format.validate(date_str) == datetime.date(2021,7,12)


# Generated at 2022-06-24 10:56:04.792993
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    from typesystem.base import ValidationError
    from typesystem import Field, Structure
    from datetime import datetime

    class BaseFormatTestStructure(Structure):
        field1 = Field(str, format='const', const='const')

    t = BaseFormatTestStructure()
    t.validate({'field1': 'const'})
    try:
        t.validate({'field1': 'const_1'})
        assert False
    except ValidationError:
        assert True

    class BaseFormatTestStructure(Structure):
        field1 = Field(str, format='date')
        field2 = Field(str, format='time')
        field3 = Field(str, format='datetime')
        field4 = Field(str, format='uuid')

    t = BaseFormatTestStructure()
    t.validate

# Generated at 2022-06-24 10:56:07.171558
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    baseformat = BaseFormat()
    baseformat.is_native_type(10)

# Unit tests for three methods in class BaseFormat

# Generated at 2022-06-24 10:56:16.235896
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():

    # Test for timezone_str is 'Z'
    match = DATETIME_REGEX.match("2019-03-03T09:59Z")
    groups = match.groupdict()
    tzinfo_str = groups.pop("tzinfo")
    if tzinfo_str == "Z":
        tzinfo = datetime.timezone.utc
    kwargs = {k: int(v) for k, v in groups.items() if v is not None}
    date_time = datetime.datetime(**kwargs, tzinfo=tzinfo)

    assert date_time.isoformat() == "2019-03-03T09:59:00+00:00"

    # Test for timezone_str is '+00:00'

# Generated at 2022-06-24 10:56:17.856709
# Unit test for constructor of class DateFormat
def test_DateFormat():
    d = DateFormat()


# Generated at 2022-06-24 10:56:20.474723
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())


# Generated at 2022-06-24 10:56:26.481393
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # given
    dt = datetime.datetime(2012, 4, 5, 6, 7, 8, 9)
    f = DateTimeFormat()
    # when
    r = f.serialize(dt)
    # then
    assert r == "2012-04-05T06:07:08.000009"

# Generated at 2022-06-24 10:56:31.046286
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    uuid_format = UUIDFormat()
    assert uuid_format.serialize(None) == None
    assert isinstance(uuid_format.serialize(uuid.uuid1()), str)

# Generated at 2022-06-24 10:56:32.533207
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        BaseFormat().validate(1)


# Generated at 2022-06-24 10:56:34.423059
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert isinstance(TimeFormat().is_native_type(datetime.time(0)),bool)


# Generated at 2022-06-24 10:56:40.223233
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Datetime with timezone utc
    obj = datetime.datetime(2020, 4, 28, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(obj) == "2020-04-28T00:00:00+00:00"

    # Datetime without timezone
    obj = datetime.datetime(2020, 4, 28)
    assert str(DateTimeFormat().serialize(obj).split('.')[0][:-3]) == "2020-04-28T00:00:00"


# Generated at 2022-06-24 10:56:43.165664
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uf = UUIDFormat()
    assert uf.is_native_type("192a35a0-7bd2-4c15-ae59-c8ccaf0d14e2")


# Generated at 2022-06-24 10:56:53.836897
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetimeFormat = DateTimeFormat()
    assert datetimeFormat.validate("2019-09-14T05:10:19.14Z") == datetime.datetime(2019, 9, 14, 5, 10, 19, 140000, tzinfo=datetime.timezone.utc)
    assert datetimeFormat.validate("2019-09-14T05:10:19.14+05:00") == datetime.datetime(2019, 9, 14, 5, 10, 19, 140000, tzinfo=datetime.timezone(datetime.timedelta(hours=5)))

# Generated at 2022-06-24 10:56:55.032014
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dateTimeFormat = DateTimeFormat()
    dateTimeFormat.__name__

# Generated at 2022-06-24 10:56:56.377811
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        BaseFormat().validate(None)


# Generated at 2022-06-24 10:56:58.792100
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    # is_native_type method should always return True for an instance of
    # BaseFormat
    base_format = BaseFormat()
    assert base_format.is_native_type(base_format)


# Generated at 2022-06-24 10:57:02.457226
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    test_format = BaseFormat()
    error_code = 'unit_test'
    assert test_format.validation_error(error_code).code == error_code


# Generated at 2022-06-24 10:57:05.273960
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) is True

# Generated at 2022-06-24 10:57:06.695977
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time is not None


# Generated at 2022-06-24 10:57:18.747371
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # for method validate of class DateTimeFormat
    my_DateTimeFormat = DateTimeFormat()
    string1 = '2019-06-23T15:25:15Z'
    print(my_DateTimeFormat.validate(string1))   # 2019-06-23 15:25:15+00:00
    string2 = '2019-6-23 15:25:15'
    print(my_DateTimeFormat.validate(string2))   # 2019-06-23 15:25:15
    # end of method validate of class DateTimeFormat
    # for method serialize of DateTimeFormat
    datetime1 = datetime.datetime(2019, 12, 13, 13, 13, 13)
    print(my_DateTimeFormat.serialize(datetime1))   # 2019-12-13T13:13:13
    datetime

# Generated at 2022-06-24 10:57:21.800644
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    expected = datetime.time(0, 1, 2, 123456)
    value = "00:01:02.123456"
    tf = TimeFormat()
    assert tf.validate(value) == expected


# Generated at 2022-06-24 10:57:28.456967
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_obj = datetime.datetime(2019, 7, 29, 12, 12, 12)
    datetime_obj_zone = datetime.datetime(2019, 7, 29, 12, 12, 12, tzinfo=datetime.timezone.utc)
    dt = DateTimeFormat()

    # Test with a datetime object without zone
    assert dt.serialize(datetime_obj) == '2019-07-29T12:12:12'

    # Test with a datetime object with zone
    assert dt.serialize(datetime_obj_zone) == '2019-07-29T12:12:12Z'

# Generated at 2022-06-24 10:57:30.056529
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time

assert test_TimeFormat()

# Generated at 2022-06-24 10:57:37.177139
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    assert tf.is_native_type(datetime.datetime.now().time()) == True
    assert tf.is_native_type(datetime.time(hour=1,minute=1,second=1)) == True
    assert tf.is_native_type(datetime.time(hour=1,minute=1,second=1).isoformat()) == False
    assert tf.is_native_type(datetime.datetime(year=2019, month=12, day=12, hour=1,minute=1,second=1, microsecond=1)) == False

# Generated at 2022-06-24 10:57:43.473139
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    obj = DateTimeFormat()

    assert obj.validate('2016-03-03') == datetime.date(2016, 3, 3)

    assert obj.validate('23:14:00.000000') == datetime.time(23, 14)

    assert obj.validate('2016-03-03T23:14:00.000000') == datetime.datetime(2016, 3, 3, 23, 14)
    assert obj.validate('2016-03-03T23:14:00.000000Z') == datetime.datetime(2016, 3, 3, 23, 14, tzinfo=datetime.timezone.utc)
    #assert obj.validate('2016-03-03T23:14:00.000000-03:00') == datetime.datetime(2016, 3, 3, 23, 14, tzinfo=

# Generated at 2022-06-24 10:57:47.987842
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert DateFormat().is_native_type(None) == False
    assert DateFormat().is_native_type("2020-06-06") == False
    assert DateFormat().is_native_type(datetime.date(2020, 6, 6)) == True


# Generated at 2022-06-24 10:57:50.603153
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    from datetime import time
    result = TimeFormat().validate('12:34:56.123456')
    assert result == time(12,34,56,123456)

# Generated at 2022-06-24 10:57:52.862243
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) is True

# Unit tests for method validate of class DateTimeFormat

# Generated at 2022-06-24 10:57:54.386884
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    #  This test does not need to be implemented because all of the classes
    #  that inherit from BaseFormat have their own validate method.

    pass


# Generated at 2022-06-24 10:58:01.496117
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.UUID('4b639e2d-7a65-4355-a7ba-c2f6f7b6dfc9'))
    assert UUIDFormat().is_native_type(uuid.uuid4())
    assert not UUIDFormat().is_native_type('4b639e2d-7a65-4355-a7ba-c2f6f7b6dfc9')


# Generated at 2022-06-24 10:58:02.910025
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    BF = BaseFormat()
    with pytest.raises(NotImplementedError):
        BF.validate("ab")


# Generated at 2022-06-24 10:58:04.450814
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
	assert TimeFormat().is_native_type(datetime.time())


# Generated at 2022-06-24 10:58:09.784199
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base = BaseFormat()
    assert base.errors == {}
    assert base.validation_error("format") == ValidationError(
        text="Must be a valid date format.", code="format"
    )
    assert str(base.validation_error("format")) == (
        "Must be a valid date format."
    )

# Generated at 2022-06-24 10:58:17.837966
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    format_test = UUIDFormat();
    assert format_test.is_native_type('c9bf9e57-1685-4c89-bafb-ff5af830be8a') == True
    assert format_test.is_native_type('c9bf9e57-168h-4c89-bafb-ff5af830be8a') == False

# Generated at 2022-06-24 10:58:20.303129
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(15, 12, 2, 5)) == True


# Generated at 2022-06-24 10:58:26.044552
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    format = TimeFormat()
    result = format.validate(value='07:00:00')
    expected = datetime.time(7, 0, 0)
    assert result == expected


# Generated at 2022-06-24 10:58:29.181282
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    t = TimeFormat()
    assert(isinstance(t, TimeFormat))
    assert(t.errors=={'format': 'Must be a valid time format.', 'invalid': 'Must be a real time.'})


# Generated at 2022-06-24 10:58:40.291507
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_format = DateTimeFormat()
    obj = datetime.datetime(year=2020,
                            month=5,
                            day=9,
                            hour=22,
                            minute=49,
                            second=54,
                            tzinfo=datetime.timezone.utc)
    obj2 = datetime.datetime(year=2020,
                            month=5,
                            day=9,
                            hour=22,
                            minute=49,
                            second=54,
                            tzinfo=datetime.timezone(datetime.timedelta(hours=-4)))

# Generated at 2022-06-24 10:58:42.471188
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) is True


# Generated at 2022-06-24 10:58:44.645514
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert isinstance(UUIDFormat().serialize(uuid.uuid4()), str)

# Generated at 2022-06-24 10:58:47.137303
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    date_time_format = DateTimeFormat()
    assert date_time_format.is_native_type(datetime.datetime.now()) == True



# Generated at 2022-06-24 10:58:50.258777
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = DateFormat()

    assert date.serialize(datetime.date(2020, 3, 1)) == "2020-03-01"
    assert date.serialize(None) == None


# Generated at 2022-06-24 10:58:52.665848
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    assert dateFormat.validate('1999-3-3') == datetime.date(1999, 3, 3)

# Generated at 2022-06-24 10:59:02.239817
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert(UUIDFormat().is_native_type(uuid.uuid4()))
    assert(UUIDFormat().is_native_type(uuid.UUID('{12345678-1234-5678-1234-567812345678}')))
    assert(not UUIDFormat().is_native_type('f47ac10b-58cc-4372-a567-0e02b2c3d479'))
    assert(not UUIDFormat().is_native_type(123))
    assert(not UUIDFormat().is_native_type(0.12345))
    assert(not UUIDFormat().is_native_type(False))

# Generated at 2022-06-24 10:59:06.018626
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(2018, 2, 20)) is True
    assert date_format.is_native_type("2018-02-20") is False



# Generated at 2022-06-24 10:59:07.992266
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat() is not None


# Generated at 2022-06-24 10:59:10.848468
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    d = datetime.datetime.now()
    date = DateTimeFormat()
    assert date.is_native_type(d) == True

# Generated at 2022-06-24 10:59:18.937832
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    uuid_data = {
        "valid1": "11111111-1111-1111-1111-111111111111",
        "valid2": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
        "invalid1": "11111111-1111-1111-1111-11111111111",
        "invalid2": "11111111111111111111111111111111111111",
    }
    for case, uuid_str in uuid_data.items():
        print("case:", case)
        try:
            uuid1 = format.validate(uuid_str)
        except ValidationError:
            pass
        else:
            print("uuid1:", uuid1)
