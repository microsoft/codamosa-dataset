

# Generated at 2022-06-24 10:49:13.280274
# Unit test for constructor of class DateFormat
def test_DateFormat():
    a = DateFormat()
    assert a.errors == {'format': 'Must be a valid date format.', 'invalid': 'Must be a real date.'}


# Generated at 2022-06-24 10:49:18.459136
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    print("Test function: validate")
    format = UUIDFormat()

    try:
        # Wrong input
        format.validate("qwerty-qwerty-qwerty-qwerty-qwerty")
    except ValidationError as e:
        print("\tCheck error: format: OK")
        assert e.code == "format"
    else:
        assert False, "Something is wrong with the input"

# Generated at 2022-06-24 10:49:20.600045
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    obj = dtf.validate('2019-09-22 17:25:00+08:00')
    print(obj)

if __name__ == "__main__":
    test_DateTimeFormat_validate()

# Generated at 2022-06-24 10:49:25.239389
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dateTime = DateTimeFormat()
    dateTime.validate("2020-01-01T20:30")
    dateTime.validate("2020-01-01T00:00Z")
    dateTime.validate("2020-01-01T00:00+02")
    dateTime.validate("2020-01-01T00:00+0200")
    dateTime.validate("2020-01-01T00:00-02:30")
    assert str(dateTime.validate("2020-01-01T00:00-02:30")) == "2020-01-01 00:00:00+02:30", "1"
    assert str(dateTime.validate("2020-01-01T00:00+02:30")) == "2020-01-01 00:00:00+02:30", "2"
   

# Generated at 2022-06-24 10:49:34.906291
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2018-12-06T21:19:08.000000+01:00") == datetime.datetime(2018, 12, 6, 21, 19, 8, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert dt.validate("2018-12-06T20:19:08.000000+00:00") == datetime.datetime(2018, 12, 6, 20, 19, 8, tzinfo=datetime.timezone.utc)
    assert dt.validate("2018-12-06T20:19:08.000000Z") == datetime.datetime(2018, 12, 6, 20, 19, 8, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-24 10:49:41.796091
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    format = DateFormat()
    assert isinstance(format.serialize(None), type(None))
    assert isinstance(format.serialize(datetime.date(2018, 12, 3)), str)
    assert format.serialize(datetime.date(2018, 12, 3)) == "2018-12-03"


# Unit tests for method serialize of class TimeFormat

# Generated at 2022-06-24 10:49:45.935249
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    # TimeFormat()
    try:
        TimeFormat()
    except Exception:
        assert False
    assert True


# Generated at 2022-06-24 10:49:47.276494
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(None) == None


# Generated at 2022-06-24 10:49:48.575350
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    BaseFormat().serialize(1)

# Generated at 2022-06-24 10:49:53.059899
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time = TimeFormat()
    assert time.is_native_type("12:00") == False
    assert time.is_native_type("12:00:00") == False
    assert time.is_native_type("12:00:00.00") == False
    assert time.is_native_type(1234567) == False
    assert time.is_native_type(True) == False
    assert time.is_native_type(None) == False
    assert time.is_native_type(datetime.time(12, 00)) == True
    assert time.is_native_type(datetime.time(12, 00, 00)) == True
    assert time.is_native_type(datetime.time(12, 00, 00, 0)) == True


# Generated at 2022-06-24 10:49:55.079283
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date.today()) == datetime.date.today().isoformat()
    assert DateFormat().serialize(None) == None


# Generated at 2022-06-24 10:49:58.848075
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    obj = datetime.datetime(2018, 1, 1, 1, 1, 1, 1, tzinfo=datetime.timezone.utc)
    value = DateTimeFormat().is_native_type(obj)
    assert value == True


# Generated at 2022-06-24 10:50:00.822351
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()


# Generated at 2022-06-24 10:50:04.101428
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    date_time = datetime.datetime.now()

    value = date_time_format.serialize(date_time)
    assert value.endswith("Z")

# Generated at 2022-06-24 10:50:12.025566
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    import uuid
    u = UUIDFormat()
    assert u.is_native_type(uuid.uuid4())
    assert isinstance(u.validate(str(uuid.uuid4())), uuid.UUID)
    assert isinstance(u.serialize(uuid.uuid4()), str)
    try:
        u.validate('abc123')
    except ValidationError:
        assert True
    else:
        assert False

test_UUIDFormat_validate()


# Generated at 2022-06-24 10:50:15.560696
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    # Arrange
    format = TimeFormat()
    value = datetime.time()
    # Act
    result = format.is_native_type(value)
    # Assert
    assert result == True

# Generated at 2022-06-24 10:50:26.916875
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    import mock
    import typesystem_mock.field_format as field_format

    test_TimeFormat = field_format.TimeFormat()

    with mock.patch.object(test_TimeFormat, "validate"):
        test_TimeFormat.validate.return_value = mock.MagicMock(
            hour = 9,
            minute = 12,
            second = 8,
            microsecond = 225,
            isoformat = lambda : '09:12:08.002225'
        )
        obj = test_TimeFormat.validate('09:12:08.002225')
        assert test_TimeFormat.serialize(obj) == '09:12:08.002225'


# Generated at 2022-06-24 10:50:30.414270
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class DateFormat2(BaseFormat):
        errors = {}
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, datetime.date)
        def validate(self, value: typing.Any) -> datetime.date:
            return value

    date = datetime.date.today()
    dateFormat = DateFormat2()
    assert dateFormat.validate(date) == date


# Generated at 2022-06-24 10:50:35.311021
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    baseFormat = BaseFormat() 
    try:
        baseFormat.validate(None)
    except NotImplementedError as e:
        assert(str(e) == "Must be a real datetime.")

# Unit tests for method is_native_type of class BaseFormat

# Generated at 2022-06-24 10:50:36.811418
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate('2020-04-19') == datetime.date(2020, 4, 19) 


# Generated at 2022-06-24 10:50:39.864449
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    date_one = "2020-01-10"
    date_two = True
    assert date_format.is_native_type(date_one) == False
    assert date_format.is_native_type(date_two) == False


# Generated at 2022-06-24 10:50:42.444576
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2018, 10, 30)
    date_obj = DateFormat()
    assert date_obj.serialize(date) == "2018-10-30"


# Generated at 2022-06-24 10:50:49.234404
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    my_date = datetime.date(2019, 11, 1)
    assert DateFormat().is_native_type(my_date) == True
    my_date = datetime.time(10, 3, 55)
    assert DateFormat().is_native_type(my_date) == False
    my_date = datetime.datetime(2019, 11, 1, 10, 3, 55)
    assert DateFormat().is_native_type(my_date) == False
    my_date = "2019-11-01"
    assert DateFormat().is_native_type(my_date) == False
    my_date = "2019-11-01T10:03:55"
    assert DateFormat().is_native_type(my_date) == False
    my_date = "2019-11-01T10:03:55"


# Generated at 2022-06-24 10:50:51.013349
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    datetimeObj = datetime.datetime(2019, 9, 19)
    date = datetimeObj.date()
    result = DateFormat()
    error = result.validate('2019-09-19')
    assert(date == error)


# Generated at 2022-06-24 10:50:53.808790
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dateTimeFormat = DateTimeFormat()
    val = dateTimeFormat.is_native_type(datetime.datetime.now())
    print(val)


# Generated at 2022-06-24 10:50:55.405338
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert isinstance(tf, TimeFormat)


# Generated at 2022-06-24 10:50:58.969530
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert str(UUIDFormat().serialize(uuid.UUID('12345678-1234-5678-1234-567812345678'))) == '12345678-1234-5678-1234-567812345678'



# Generated at 2022-06-24 10:51:00.422492
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    dateformat = DateFormat()
    date = datetime.date(2019, 1, 1)
    assert dateformat.serialize(date) == "2019-01-01"

# Generated at 2022-06-24 10:51:04.447592
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtf = DateTimeFormat()
    assert dtf


# Generated at 2022-06-24 10:51:08.034200
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    format = UUIDFormat()
    assert format.is_native_type('3dbb27c9-d0a2-4c39-96a4-0e4d4e0ed8a4')

# Generated at 2022-06-24 10:51:12.156035
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
	format = DateTimeFormat()


# Generated at 2022-06-24 10:51:15.372841
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    val = DateTimeFormat().validate('2019-12-06T14:32:52.923194')
    assert isinstance(val, datetime.datetime)
    assert val == datetime.datetime(2019, 12, 6, 14, 32, 52, 923194)


# Generated at 2022-06-24 10:51:24.162036
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(None) is None
    assert DateFormat().serialize(datetime.date.today()) == '2020-12-26'
    assert DateTimeFormat().serialize(datetime.datetime.now()) == '2020-12-26T11:44:44.979346+02:00'
    assert DateTimeFormat().serialize(datetime.datetime.now()) == '2020-12-26T11:44:44.979346+02:00'
    assert TimeFormat().serialize(datetime.datetime.now()) == '11:44:44.979346'
    assert UUIDFormat().serialize(uuid.uuid4()) == 'e1d68a29-2782-471e-a7b0-d8b2c440a043'

# Generated at 2022-06-24 10:51:28.200903
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time.is_native_type('12:45')
    assert time.validate('12:45')
    assert time.serialize(time.validate('12:45'))
    print("Unit test TimeFormat successful")


# Generated at 2022-06-24 10:51:39.137933
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():

    valid_values = [datetime.datetime(2019, 9, 29, 20, 14, 0, 0), datetime.datetime(2019, 9, 29, 20, 14, 0, 0, tzinfo=datetime.timezone.utc)]

    valid_values = [datetime.date(2019, 9, 29), datetime.time(20, 14, 0), datetime.datetime(2019, 9, 29, 20, 14, 0, 0)]

    for val in valid_values:
        is_native_type = DateTimeFormat().is_native_type(val)
        assert(is_native_type)


# Generated at 2022-06-24 10:51:39.876542
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtf = DateTimeFormat()
    assert dtf is not None


# Generated at 2022-06-24 10:51:43.616741
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    datef = DateFormat()
    assert isinstance(datef.validate("2018-08-01"), datetime.date)
    with pytest.raises(ValidationError):
        datef.validate("01-08-2018")


# Generated at 2022-06-24 10:51:50.009374
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(12, 10)) == True
    assert time_format.is_native_type(datetime.time(15, 12, 20)) == True
    assert time_format.is_native_type(datetime.datetime.now()) == False
    assert time_format.is_native_type(12) == False
    assert time_format.is_native_type("12:10") == False

# Generated at 2022-06-24 10:51:53.779476
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestFormat(BaseFormat):
        errors = {
            "format": "Must be a valid date format.",
            "invalid": "Must be a real date.",
        }

    testFormat = TestFormat()
    testValue = testFormat.validation_error("format").code
    assert testValue == "format"
    print("Test BaseFormat.validation_error passed")


# Generated at 2022-06-24 10:51:58.010573
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    with pytest.raises(NotImplementedError):
        BaseFormat().is_native_type(None)
    with pytest.raises(NotImplementedError):
        BaseFormat().validate(None)
    with pytest.raises(NotImplementedError):
        BaseFormat().serialize(None)


# Generated at 2022-06-24 10:52:01.651780
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    answe = {"Day": "1", "Month": "1", "Year": "2020"}
    mydate = DateFormat()
    mydate.validate("2020-1-1")
    assert type(answe) == type(mydate)


# Generated at 2022-06-24 10:52:03.834024
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate(): 
    tf_test1 = TimeFormat()
    assert tf_test1.validate('00:00') == datetime.time(0, 0)


# Generated at 2022-06-24 10:52:12.349312
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2010, 4, 5, 9, 30, 30, 25000, tzinfo=datetime.timezone(datetime.timedelta(hours=8), "Beijing Time"))) == "2010-04-05T09:30:30.025000+08:00"
    assert DateTimeFormat().serialize(datetime.datetime(2010, 4, 5, 9, 30, 30, 25000, tzinfo=datetime.timezone(datetime.timedelta(hours=8)))) == "2010-04-05T09:30:30.025000+08:00"

# Generated at 2022-06-24 10:52:17.524193
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # GIVEN: obj of type datetime
    obj = datetime.datetime.now()
    # WHEN: Declare a class DateTimeFormat
    class DateTimeFormat1(DateTimeFormat):
        pass
    dtf = DateTimeFormat1()
    # THEN: It should serialize the obj to its isoformat
    assert obj.isoformat() == dtf.serialize(obj)
    # WHEN: obj is None
    # THEN: None is returned
    assert None == dtf.serialize(None)

# Generated at 2022-06-24 10:52:20.833992
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(2019, 2, 1)
    #assert DateFormat.serialize(obj) == '2019-02-01'  -- no sera igual
    #                                                     a la hora de probarlo
    return DateFormat.serialize(obj)


# Generated at 2022-06-24 10:52:21.891197
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None


# Generated at 2022-06-24 10:52:24.371600
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
  time_format = TimeFormat()
  obj = datetime.time(12, 12, 12, 12)
  assert time_format.serialize(obj) == '12:12:12.000012'


# Generated at 2022-06-24 10:52:26.250472
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    obj = BaseFormat()
    assert obj.validation_error("format") == ValidationError(text=None,code="format")
    

# Generated at 2022-06-24 10:52:27.796851
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidFormat = UUIDFormat()
    assert uuidFormat is not None


# Generated at 2022-06-24 10:52:32.567358
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_test = "ffffffff-ffff-ffff-ffff-ffffffffffff"
    uuid_test_wrong = "ffffffff-ffff"
    x = UUIDFormat()
    y = x.validate(uuid_test)
    z = x.validate(uuid_test_wrong)
    assert isinstance(y, uuid.UUID)
    assert isinstance(z, str)

# Generated at 2022-06-24 10:52:34.925217
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert UUIDFormat.__init__ is not None


# Generated at 2022-06-24 10:52:36.652310
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    assert BaseFormat().validation_error("test") == ValidationError(text="", code="test")


# Generated at 2022-06-24 10:52:38.687143
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat().__class__.__name__=='DateFormat'


# Generated at 2022-06-24 10:52:45.335286
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Cover 3 cases:
    #      1. Date has invalid format
    #      2. Date is real date but out of range
    #      3. Date is valid date
    date = "2017-12-31T20:56:00.0000"

    # Case 1: Date has invalid format
    with pytest.raises(ValidationError):
        DateTimeFormat().validate("abc123")

    # Case 2: Date is real date but out of range
    with pytest.raises(ValidationError):
        DateTimeFormat().validate("1900-12-31T20:56:00.0000")

    # Case 3: Date is valid date
    try:
        assert DateTimeFormat().validate(date) is not None
    except ValidationError:
        assert False

# Generated at 2022-06-24 10:52:47.554662
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    value = datetime.time(microsecond=0)
    assert(TimeFormat().is_native_type(value))


# Generated at 2022-06-24 10:52:53.046163
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    obj = DateTimeFormat()
    value = '2020-07-27T09:30:00+02:00'
    assert obj.validate(value) == datetime.datetime(2020, 7, 27, 9, 30, 0, tzinfo=datetime.timezone(datetime.timedelta(seconds=7200)))


# Generated at 2022-06-24 10:53:03.565359
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat(): 
    # Test successful case
    dt_format = DateTimeFormat()
    assert dt_format.validate("2018-11-23T12:34:56.123456+01:00") == \
        datetime.datetime(2018, 11, 23, 12, 34, 56, 123456)
    assert dt_format.validate("2018-11-23T12:34:56+01:00") == \
        datetime.datetime(2018, 11, 23, 12, 34, 56)
    assert dt_format.validate("2018-11-23T12:34:56") == \
        datetime.datetime(2018, 11, 23, 12, 34, 56)

# Generated at 2022-06-24 10:53:12.148655
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    assert df.is_native_type(None) == False
    assert df.is_native_type(15) == False
    assert df.is_native_type(10.55) == False
    assert df.is_native_type([1, 2, 3]) == False
    assert df.is_native_type(datetime.datetime(2019, 1, 30)) == True
    assert df.is_native_type(datetime.date(2019, 1, 30)) == True
    assert df.is_native_type(datetime.time(1, 30)) == False
    assert df.is_native_type(datetime.timedelta(days=365)) == False
    assert df.is_native_type(datetime.timezone()) == False


# Generated at 2022-06-24 10:53:15.932598
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()

    assert date_format.is_native_type(datetime.date(2018, 12, 21))
    assert not date_format.is_native_type(datetime.datetime(2018, 12, 21, 12, 12))



# Generated at 2022-06-24 10:53:20.124842
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert issubclass(BaseFormat, BaseFormat)
    assert issubclass(DateFormat, BaseFormat)
    assert issubclass(TimeFormat, BaseFormat)
    assert issubclass(DateTimeFormat, BaseFormat)
    assert issubclass(UUIDFormat, BaseFormat)



# Generated at 2022-06-24 10:53:22.099026
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert(uuid_format.is_native_type(uuid.uuid4()))

# Generated at 2022-06-24 10:53:27.998779
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Test case: serialize an object with attribute obj is not None
    obj = datetime.date(2012, 12, 12)
    dateformat = DateFormat()
    assert dateformat.serialize(obj) == "2012-12-12"
    # Test case: serialize an object with attribute obj is None
    obj = None
    dateformat = DateFormat()
    assert dateformat.serialize(obj) == None
    

# Generated at 2022-06-24 10:53:32.385975
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    t = DateTimeFormat()
    obj : datetime.datetime = datetime.datetime(2018, 10, 17, 12, 10, 11, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))
    value = t.serialize(obj)
    assert value == '2018-10-17T12:10:11+02:00'
#----------------------------------------------------------------------

# Generated at 2022-06-24 10:53:36.743851
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    a_uuid = uuid.UUID(int=7)
    assert uuid_format.serialize(a_uuid) == '00000000-0000-0001-0000-000000000007'


# Generated at 2022-06-24 10:53:43.244612
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    dateformat = DateFormat()
    assert(dateformat.is_native_type(datetime.date.today()))
    expected = "2020-05-01"
    obj = datetime.date(2020, 5, 1)
    assert(dateformat.serialize(obj) == expected)


# Generated at 2022-06-24 10:53:45.132657
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    assert BaseFormat().validation_error('format') == ValidationError(
        text='Must be a valid datetime format.',
        code = 'format')


# Generated at 2022-06-24 10:53:46.581733
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    format=TimeFormat()
    assert format.is_native_type(datetime.time())==True


# Generated at 2022-06-24 10:53:50.413259
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    format = UUIDFormat()
    value = uuid.uuid1()
    assert format.is_native_type(value) is True

# Generated at 2022-06-24 10:53:56.528076
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    sut = UUIDFormat()
    # idempotent
    assert (sut.is_native_type(uuid.uuid4()) == True)
    assert (sut.is_native_type(uuid.uuid4()) == True)    
    with pytest.raises(NotImplementedError):
        sut.validate(uuid.uuid4())


# Generated at 2022-06-24 10:53:58.345239
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat.errors == {}
    BaseFormat()


# Generated at 2022-06-24 10:54:02.836591
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    native_instance = datetime.datetime.now()
    native_obj_type = isinstance(native_instance, datetime.datetime)
    assert native_obj_type == DateTimeFormat().is_native_type(native_instance)


# Generated at 2022-06-24 10:54:07.548391
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuidStr = '22bba8ad-f988-4e74-b91d-d8e0ade600c7'
    uuidObject = uuid.UUID(uuidStr)
    checkUUIDFormat = UUIDFormat()
    assert checkUUIDFormat.is_native_type(uuidStr) # False
    assert checkUUIDFormat.is_native_type(uuidObject) # True



# Generated at 2022-06-24 10:54:09.055551
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    test = BaseFormat()
    try:
        test.validate({})
    except ValidationError as e:
        assert e.code == "format"


# Generated at 2022-06-24 10:54:13.952513
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(year=2019, month=6, day=8, hour=22, minute=12, second=22, tzinfo=datetime.timezone.utc)
    expected = "2019-06-08T22:12:22Z"
    assert(expected == DateTimeFormat().serialize(dt))

# Generated at 2022-06-24 10:54:14.786783
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    UUIDFormat()

# Generated at 2022-06-24 10:54:26.217029
# Unit test for constructor of class DateFormat
def test_DateFormat():
    # Test that is_native_type(date) returns True
    dateFormat = DateFormat()
    date = datetime.date(2014, 3, 31)
    assert dateFormat.is_native_type(date) == True

    # Test that is_native_type(time) returns False
    time = datetime.time(16, 23, 50)
    assert dateFormat.is_native_type(time) == False

    # Test that is_native_type(datetime) returns False
    dt = datetime.datetime(2014, 3, 31, 16, 23, 50)
    assert dateFormat.is_native_type(dt) == False

    # Test that is_native_type(int) returns False
    assert dateFormat.is_native_type(5) == False

    # Test that is_native_type(float) returns

# Generated at 2022-06-24 10:54:30.633204
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date.today())
    assert not date_format.is_native_type(datetime.datetime.today())
    assert not date_format.is_native_type(datetime.time(0, 0))
    assert not date_format.is_native_type(42)


# Generated at 2022-06-24 10:54:34.488924
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    try:
        format.validate("12345678-1234-5678-1234-567812345678")
    except ValidationError as e:
        assert e.args == ('Must be valid UUID format.', 'format')

# Generated at 2022-06-24 10:54:37.665519
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    value = '6c84fb90-12c4-11e1-840d-7b25c5ee775a'
    validation_result = uuid_format.validate(value)
    assert validation_result == uuid.UUID(value)

# Generated at 2022-06-24 10:54:40.894101
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date: datetime.date = DateFormat().validate("2020-05-12")
    assert date.strftime('%Y-%m-%d') == "2020-05-12"

# Generated at 2022-06-24 10:54:43.252616
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    with pytest.raises(NotImplementedError):
        # Coverage for exceptions handling
        serialized = BaseFormat().serialize(None)


# Generated at 2022-06-24 10:54:47.910580
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    x = datetime.time(15, 8, 24, 100000)
    assert x.isoformat() == '15:08:24.100000'
    y = TimeFormat().serialize(x)
    assert x.isoformat() == y


# Generated at 2022-06-24 10:54:52.417821
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    class DateFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, datetime.date)
    x = DateFormat()
    assert x.is_native_type(datetime.date(2020, 1, 1)) == True


# Generated at 2022-06-24 10:54:53.835493
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(None) == None


# Generated at 2022-06-24 10:54:54.510414
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat()

# Generated at 2022-06-24 10:55:03.706070
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # pylint: disable=E1101
    tzutc = datetime.timezone.utc
    tz1h = datetime.timezone(datetime.timedelta(hours=1))
    tz3min = datetime.timezone(datetime.timedelta(minutes=3))
    # pylint: enable=E1101


# Generated at 2022-06-24 10:55:07.023417
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    field = DateTimeFormat()
    try:
        field.validate("2020-03-03T10:00:12.123456Z")
    except Exception as e:
        assert False
        



# Generated at 2022-06-24 10:55:08.604773
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    x = BaseFormat()
    print(x.validation_error("format"))


# Generated at 2022-06-24 10:55:16.725422
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    from typesystem.formats import TimeFormat
    from datetime import time
    x = TimeFormat()
    assert(x.serialize(time(hour=0, minute=0, second=0)) == '00:00:00')
    assert(x.serialize(time(hour=0, minute=0, second=1)) == '00:00:01')
    assert(x.serialize(time(hour=0, minute=1, second=1)) == '00:01:01')
    assert(x.serialize(time(hour=1, minute=1, second=1)) == '01:01:01')


# Generated at 2022-06-24 10:55:25.767015
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    p = UUIDFormat()
    assert p.validate("3568a12f-e72d-11e9-9c1e-0cc47a220db7") == uuid.UUID("3568a12f-e72d-11e9-9c1e-0cc47a220db7")
    assert p.validate("3568a12f-e72d-11e9-9c1e-0cc47a220db7") != uuid.UUID("3568a12f-e72d-11e9-9c1e-0cc47a220db8")


# Generated at 2022-06-24 10:55:34.353107
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    datetimeformat = DateTimeFormat()
    assert datetimeformat.is_native_type(datetime.datetime.now()) is True
    assert datetimeformat.validate("2020-10-05T12:30:00Z") == datetime.datetime(
        year=2020, month=10, day=5, hour=12, minute=30, second=0, tzinfo=datetime.timezone.utc
    )
    assert datetimeformat.validate("2020-10-05T12:30:00.00Z") == datetime.datetime(
        year=2020, month=10, day=5, hour=12, minute=30, second=0, tzinfo=datetime.timezone.utc
    )

# Generated at 2022-06-24 10:55:44.779143
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from datetime import timedelta, datetime
    from uuid import UUID

    assert DateTimeFormat().validate("2020-12-12T09:11:24.000Z") == datetime(2020, 12, 12, 9, 11, 24, tzinfo=timedelta(hours=0))
    assert DateTimeFormat().validate("2020-12-12T09:11:24.000+08:00") == datetime(2020, 12, 12, 9, 11, 24, tzinfo=timedelta(hours=8))
    assert DateTimeFormat().validate("2020-12-12T09:11:24") == datetime(2020, 12, 12, 9, 11, 24, tzinfo=timedelta(hours=0))
    assert DateTimeFormat().validate("2020-12-12T09:11") == dat

# Generated at 2022-06-24 10:55:50.625355
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuidFormat = UUIDFormat()
    assert 'b4c4b4eb-b214-4e4c-ac46-b5199ac9d971' == uuidFormat.serialize(uuid.UUID('b4c4b4eb-b214-4e4c-ac46-b5199ac9d971'))

# Generated at 2022-06-24 10:55:53.748736
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert isinstance(UUIDFormat().validate("3f1cc3f2-8b3e-41df-a053-e66b58f0d906"), uuid.UUID)


# Generated at 2022-06-24 10:55:56.634867
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    format_ = BaseFormat()
    with pytest.raises(NotImplementedError):
        format_.validate(None)


# Generated at 2022-06-24 10:55:57.296807
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    asser

# Generated at 2022-06-24 10:55:58.666888
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    assert bf


# Generated at 2022-06-24 10:56:05.607038
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    """ 
        Testing serialize method of DateTimeFormat class 
    """
    # Valid example
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 19, 23, 1, 25, 123456)) == "2019-01-19T23:01:25.123456"
    # Invalid example
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 19, 23, 1, 25)) == "2019-01-19T23:01:25"

# Generated at 2022-06-24 10:56:16.904773
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    """
    Test the method is_native_type of class DateFormat
    """
    df = DateFormat()

    assert df.is_native_type(None) == False
    assert df.is_native_type(False) == False
    assert df.is_native_type("2020/01/24") == False
    assert df.is_native_type("2020-01-24") == False
    assert df.is_native_type(datetime.date.today()) == True
    assert df.is_native_type(datetime.datetime.now()) == False
    assert df.is_native_type(datetime.time.now()) == False



# Generated at 2022-06-24 10:56:26.720004
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # test 1
    fmt = DateFormat()
    value = "2020-01-01"
    try:
        res = fmt.validate(value)
        assert(res.year == 2020 and res.month == 1 and res.day == 1)
    except ValidationError:
        assert(ValueError)

    # test 2
    fmt = DateFormat()
    value = "2020-13-01"
    try:
        fmt.validate(value)
    except ValidationError:
        assert(isinstance(fmt.validation_error("format"), ValidationError))

    # test 3
    fmt = DateFormat()
    value = "200001-01-01"

# Generated at 2022-06-24 10:56:33.074754
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class CustomFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, int)

    format = CustomFormat()
    assert format.is_native_type(1) == True
    assert format.is_native_type("1") == False



# Generated at 2022-06-24 10:56:37.074442
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    base_format = BaseFormat()
    try:
        base_format.is_native_type('abc')

        # AssertError: AssertionError: True is not false
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 10:56:40.342587
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    is_native_type = UUIDFormat().is_native_type
    assert is_native_type(uuid.UUID("12345678-1234-5678-1234-567812345678"))
    assert not is_native_type(123)



# Generated at 2022-06-24 10:56:42.548271
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate('2020-01-31T14:26:37.037+02:00')



# Generated at 2022-06-24 10:56:45.209584
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    # Case 1
    TimeFormat_object = TimeFormat()
    assert isinstance(TimeFormat_object.serialize(None), str)


# Generated at 2022-06-24 10:56:53.756149
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    
    datetime_format = DateTimeFormat()
    
    assert datetime_format.is_native_type(datetime.datetime.now())
    assert not datetime_format.is_native_type(datetime.date.today())
    assert not datetime_format.is_native_type(datetime.time())

    assert datetime_format.serialize(datetime.datetime.now()) is not None
    assert datetime_format.serialize(datetime.date.today()) is None
    assert datetime_format.serialize(datetime.time()) is None
    
    
    
    
    
    
    
    



# Generated at 2022-06-24 10:56:55.574357
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2020, 1, 1)) == '2020-01-01'

# Generated at 2022-06-24 10:57:01.934382
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type('2019-11-05T14:59:09+00:00') == True
    assert DateTimeFormat().is_native_type('2019-11-05 14:59:09+00:00') == True
    assert DateTimeFormat().is_native_type('2019-11-05 14:59:09+0000') == True
    assert DateTimeFormat().is_native_type('2019-11-05 14:59:09') == True
    assert DateTimeFormat().is_native_type('2019-11-05 14:59:09.123456') == True
    assert DateTimeFormat().is_native_type('2019-11-05T14:59:09.123') == True
    assert DateTimeFormat().is_native_type('2019-11-05T14:59') == True
   

# Generated at 2022-06-24 10:57:09.965106
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    time = datetime.datetime(2020, 5, 9, 13, 30, 30, 0)
    assert date_time_format.serialize(time) == "2020-05-09T13:30:30"

    time = datetime.datetime(2020, 5, 9, 13, 30, 30, 0, datetime.timezone.utc)
    res = date_time_format.serialize(time)
    assert res == "2020-05-09T13:30:30Z"

# Generated at 2022-06-24 10:57:14.343070
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2018, 1, 1)) is True
    assert DateFormat().is_native_type(datetime.datetime(2018, 1, 1)) is False


# Generated at 2022-06-24 10:57:20.293855
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format = DateTimeFormat()
    assert format.is_native_type(datetime.datetime.now()) is True
    assert format.is_native_type(object()) is False
    assert format.is_native_type(1) is False


# Generated at 2022-06-24 10:57:30.981804
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    
    obj = DateTimeFormat()

    assert obj.validate('2016-12-31T15:41:00') == datetime.datetime(2016, 12, 31, 15, 41)
    assert obj.validate('2016-12-31T15:41:00.003') == datetime.datetime(2016, 12, 31, 15, 41, 0, 30000)
    assert obj.validate('2016-12-31T15:41:00Z') == datetime.datetime(2016, 12, 31, 15, 41, tzinfo=datetime.timezone.utc)
    # TODO: we should handle timezones
    assert obj.validate('2016-12-31T15:41:00+01:00') == datetime.datetime(2016, 12, 31, 15, 41)

    raised = False

# Generated at 2022-06-24 10:57:32.283315
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    base = BaseFormat()
    assert(base.serialize(None) == None)

# Generated at 2022-06-24 10:57:35.317758
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime(2018, 10, 6)) == True
    assert DateTimeFormat().is_native_type(datetime.date(2018, 10, 6)) == False

# Generated at 2022-06-24 10:57:42.085520
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    obj = UUIDFormat()
    result = obj.validate(value="35c16565-5f5a-4a4b-9a3a-d0a247e4c02f")
    assert result == uuid.UUID("35c16565-5f5a-4a4b-9a3a-d0a247e4c02f")

    try:
        obj.validate(value="35c16565-5f5a-4a4b-9a3a-d0a247e4c02f1")
    except ValidationError as err:
        print(err)


# Unise test for method is_native_type of class UUIDFormat

# Generated at 2022-06-24 10:57:47.255949
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    with pytest.raises(ValidationError):
        uuid_format.validate("")
    with pytest.raises(ValidationError):
        uuid_format.validate("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")
    with pytest.raises(ValidationError):
        uuid_format.validate("{aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa}")
    with pytest.raises(ValidationError):
        uuid_format.validate("aaaaaaaaaaaaaaa")
    with pytest.raises(ValidationError):
        uuid_format.validate("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaaaaaa")

# Generated at 2022-06-24 10:57:48.868468
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2019,5,5)) == "2019-05-05"


# Generated at 2022-06-24 10:57:55.524761
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2011-02-14T15:10:29Z") == datetime.datetime(2011, 2, 14, 15, 10, 29, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2012-04-13T14:07:46-00:00") == datetime.datetime(2012, 4, 13, 14, 7, 46, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2010-04-14T14:07:46-05:00") == datetime.datetime(2010, 4, 14, 14, 7, 46, 0, datetime.timezone(-datetime.timedelta(hours=5, minutes=0)))

# Generated at 2022-06-24 10:57:56.421980
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    test = BaseFormat()
    errors = {}
    expected = None
    assert test.errors == expected
    

# Generated at 2022-06-24 10:58:02.705068
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    tf.validate("12:34:56")
    tf.validate("12:34:56.123456")
    assert tf.validate("12:34:56.123456").microsecond == 123456


if __name__ == "__main__":  # pragma: no cover
    test_TimeFormat_validate()

# Generated at 2022-06-24 10:58:04.823280
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.datetime.now()
    value = DateFormat().serialize(obj)
    assert value is not None


# Generated at 2022-06-24 10:58:07.269340
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(2020, 7, 4)
    assert DateFormat().serialize(obj) == '2020-07-04'


# Generated at 2022-06-24 10:58:11.628642
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date = '2020-05-18T06:38:34.000000' 
    assert isinstance(DateTimeFormat().validate(date),datetime.datetime)


# Generated at 2022-06-24 10:58:22.268381
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtf = DateTimeFormat()
    # test validity of argument for method validate
    assert dtf.validate('2021-05-25T11:18:33.189Z') == datetime.datetime(2021, 5, 25, 11, 18, 33, 189000)
    # test invalid argument for method validate
    try:
        assert dtf.validate('2021-05-25T11:18:33.189000Z') == datetime.datetime(2021, 5, 25, 11, 18, 33, 189000)
    except Exception:
        pass
    # test serialization of datetime object
    dt = datetime.datetime(2021, 5, 25, 11, 18, 33, 189000)

# Generated at 2022-06-24 10:58:24.991234
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2020, 1, 7)) == "2020-01-07"
    assert DateFormat().serialize(datetime.date(20, 1, 7)) == "0020-01-07"

# Generated at 2022-06-24 10:58:29.398944
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = uuid.UUID('886313e1-3b8a-5372-9b90-0c9aee199e5d')
    assert UUIDFormat().serialize(obj) == "886313e1-3b8a-5372-9b90-0c9aee199e5d"

# Generated at 2022-06-24 10:58:33.527045
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    format = TimeFormat()
    assert not format.is_native_type("12:23")
    assert format.is_native_type(datetime.time(12, 23))


# Generated at 2022-06-24 10:58:37.284591
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Create a date time object to test
    dateTime = datetime.datetime.now()
    
    # Test if the method serialize of the class DateTimeFormat returns the correct string
    assert dateTime.isoformat() == DateTimeFormat().serialize(dateTime)

# Generated at 2022-06-24 10:58:41.638661
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    """
    This unit test checks if every format has a validation_error method
    """
    assert(hasattr(DateFormat(), "validation_error"))
    assert(hasattr(TimeFormat(), "validation_error"))
    assert(hasattr(DateTimeFormat(), "validation_error"))
    assert(hasattr(UUIDFormat(), "validation_error"))
    return True

# Generated at 2022-06-24 10:58:51.068011
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    x = UUIDFormat()
    assert x.is_native_type('ae83e664-3ae3-4cc7-b6de-1d7ae5af5f1f') == isinstance('ae83e664-3ae3-4cc7-b6de-1d7ae5af5f1f', uuid.UUID)
    assert x.is_native_type('ae83e6643ae34cc7b6de1d7ae5af5f1f') == isinstance('ae83e6643ae34cc7b6de1d7ae5af5f1f', uuid.UUID)

# Generated at 2022-06-24 10:58:57.144952
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    assert isinstance(tf, BaseFormat)

    obj1 = datetime.datetime.now()
    obj2 = datetime.datetime.now().time()

    assert tf.is_native_type(obj1) == False
    assert tf.is_native_type(obj2) == True


# Generated at 2022-06-24 10:58:59.643921
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(None) == None
    assert DateFormat().serialize(datetime.date(2019,4,4)) == '2019-04-04'



# Generated at 2022-06-24 10:59:05.963170
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_string = '89e9d2b5-07c5-4e84-8bcf-c7d0f0a730f3'
    assert UUIDFormat().validate(uuid_string) == uuid.UUID(uuid_string)
    uuid_string = '89e9d2b5-07c5-4e84-8bcf-c7d0f0a730f'
    with pytest.raises(ValidationError):
        UUIDFormat().validate(uuid_string)


# Generated at 2022-06-24 10:59:11.073021
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2020, 6, 1)) == "2020-06-01"
    assert date_format.serialize(None) == None
