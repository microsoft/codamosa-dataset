

# Generated at 2022-06-24 10:49:13.501908
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format = DateTimeFormat()
    assert format.is_native_type(datetime.datetime(2017, 1, 1)) == True


# Generated at 2022-06-24 10:49:21.956578
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.datetime(2019,11,14,10,00))=='10:00:00'

# Generated at 2022-06-24 10:49:25.950590
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class MyFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return value == "Some value"
    assert MyFormat().is_native_type("Some value")

# Generated at 2022-06-24 10:49:30.743700
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():  # pragma: no cover
    base_format = BaseFormat()
    with pytest.raises(NotImplementedError) as excinfo:
        base_format.serialize(None)
    assert excinfo.value.args[0] == 'serialize not implement'
# test_BaseFormat_serialize


# Generated at 2022-06-24 10:49:35.413412
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    baseFormat = BaseFormat()
    assert baseFormat.is_native_type('abc') == False
    assert baseFormat.is_native_type(1) == False
    assert baseFormat.is_native_type(1.1) == False
    assert baseFormat.is_native_type(True) == False
    assert baseFormat.is_native_type({}) == False
    assert baseFormat.is_native_type([]) == False
    

# Generated at 2022-06-24 10:49:41.032832
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    schema = DateFormat()
    date = schema.validate("2000-01-01")
    if date.year > 2000 or date.month > 1 or date.day > 1:
        raise ValueError("year month or day is false")

test_DateFormat_validate()


# Generated at 2022-06-24 10:49:53.637912
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    datetime1 = datetime.datetime(year=2010, month=10, day=10, hour=12, minute=11, second=30, microsecond=2000)
    datetime2 = datetime.datetime(year=2010, month=10, day=10, hour=12, minute=11, second=30)
    datetime3 = datetime.datetime(year=2010, month=10, day=10, hour=12, minute=11)
    datetime4 = datetime.datetime(year=2010, month=10, day=10, hour=12)
    datetime5 = datetime.datetime(year=2010, month=10, day=10)

    assert DateTimeFormat().is_native_type(datetime1) == True
    assert DateTimeFormat().is_native_type(datetime2) == True


# Generated at 2022-06-24 10:49:59.755493
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dateformat = DateTimeFormat()
    assert dateformat.serialize(datetime.datetime(2020,11,6)) == "2020-11-06T00:00:00"
    assert dateformat.serialize(None) == None
    assert dateformat.serialize(datetime.datetime(2020,11,6,12,34,56)) == "2020-11-06T12:34:56"
    assert dateformat.serialize(datetime.datetime(2020,11,6,12,34,56,123456)) == "2020-11-06T12:34:56.123456"

# Generated at 2022-06-24 10:50:09.987631
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T12:12:12Z") == datetime.datetime(2019, 1, 1, 12, 12, 12, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T12:12:12+08:00") == datetime.datetime(2019, 1, 1, 12, 12, 12, tzinfo=datetime.timezone(datetime.timedelta(hours=8)))
    assert DateTimeFormat().validate("2019-01-01T12:12:12-08:00") == datetime.datetime(2019, 1, 1, 12, 12, 12, tzinfo=datetime.timezone(datetime.timedelta(hours=-8)))

# Generated at 2022-06-24 10:50:18.375020
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    fmt = DateFormat()
    assert fmt.is_native_type(datetime.date(2021,2,3))
    assert not fmt.is_native_type(100)
    assert not fmt.is_native_type(datetime.datetime(2021,2,3))
    assert not fmt.is_native_type(datetime.time(12,34))
    assert not fmt.is_native_type(uuid.uuid4())

# Generated at 2022-06-24 10:50:20.263706
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime.now())==datetime.datetime.now().isoformat()

# Generated at 2022-06-24 10:50:30.607484
# Unit test for method validate of class DateTimeFormat

# Generated at 2022-06-24 10:50:34.710139
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time(hour=1, minute=30)) == True
    assert TimeFormat().is_native_type(None) == False


# Generated at 2022-06-24 10:50:36.708429
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2019-10-17") == datetime.date(2019, 10, 17)


# Generated at 2022-06-24 10:50:44.571049
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    format = DateFormat()

    assert format.is_native_type(None) is False
    assert format.is_native_type(datetime.date.today()) is True
    assert format.is_native_type(datetime.datetime.today()) is False
    assert format.is_native_type(datetime.time.now()) is False
    assert format.is_native_type(12345) is False
    assert format.is_native_type([]) is False
    assert format.is_native_type({}) is False
    assert format.is_native_type(True) is False
    assert format.is_native_type(False) is False



# Generated at 2022-06-24 10:50:46.112035
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    base = BaseFormat()
    with pytest.raises(NotImplementedError):
        base.is_native_type('a')


# Generated at 2022-06-24 10:50:49.294448
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    assert df.is_native_type(datetime.date(2019, 10, 21)) == True



# Generated at 2022-06-24 10:51:00.131624
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    obj_DateFormat = DateFormat()
    obj_TimeFormat = TimeFormat()
    obj_DateTimeFormat = DateTimeFormat()
    obj_UUIDFormat = UUIDFormat()

    assert obj_DateFormat.is_native_type(datetime.date(2018, 8, 1))
    assert not obj_DateFormat.is_native_type(datetime.datetime(2018, 8, 1))
    assert not obj_DateFormat.is_native_type(1)

    assert obj_TimeFormat.is_native_type(datetime.time(1, 2, 3))
    assert not obj_TimeFormat.is_native_type(1)

    assert obj_DateTimeFormat.is_native_type(
        datetime.datetime(2018, 8, 1, 1, 2, 3)
    )
    assert obj_DateTime

# Generated at 2022-06-24 10:51:06.726750
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    from datetime import datetime
    from typesystem import DateTime

    value = datetime.now()
    format = DateTimeFormat()

    assert isinstance(format, DateTimeFormat)
    assert isinstance(format.validate(str(value.isoformat())), datetime)
    assert isinstance(format.serialize(value), str)


# Generated at 2022-06-24 10:51:10.992610
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(None) is None
    assert TimeFormat().serialize("12:00:00") == "12:00:00"
    assert TimeFormat().serialize("12:00:00.125555") == "12:00:00.125555"
    assert TimeFormat().serialize("12:00:00") == "12:00:00"

# Generated at 2022-06-24 10:51:12.107380
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) is None

# Generated at 2022-06-24 10:51:15.470635
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = "57d9f473-a5e5-4d59-99a0-7a8f6e96e7a2"
    assert UUIDFormat().serialize(obj) == obj

# Generated at 2022-06-24 10:51:21.008208
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    from typesystem.base import ValidationError
    from typesystem.format import UUIDFormat
    s = UUIDFormat()
    assert(isinstance(s.validate('110e8400-e29b-11d4-a716-446655440000'),uuid.UUID))
    try:
        s.validate('123')
    except ValidationError as e:
        assert(e.code == 'format')


# Generated at 2022-06-24 10:51:23.707302
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_instance = UUIDFormat()
    assert uuid_instance.validate("00000000-0000-0000-0000-000000000000") == uuid.UUID("00000000-0000-0000-0000-000000000000")


# Generated at 2022-06-24 10:51:27.463828
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    x = DateTimeFormat()
    assert x.is_native_type(datetime.datetime.now()) == True
    assert x.is_native_type(datetime.datetime.now().isoformat()) == False


# Generated at 2022-06-24 10:51:28.489804
# Unit test for method validation_error of class BaseFormat

# Generated at 2022-06-24 10:51:33.994686
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time(12, 23, 22, 123)
    time_format = TimeFormat()
    assert time_format.serialize(obj) == '12:23:22.000123'

# Generated at 2022-06-24 10:51:40.367232
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():

    from typesystem.base import ValidationError
    
    bf = BaseFormat()
    bf.errors = {
        "format": "Must be a valid date format.",
        "invalid": "Must be a real date.",
    }
    bf.__dict__.update({"age": "2"})

    ve = bf.validation_error("format")
    assert isinstance(ve, ValidationError)
    assert ve.code == "format"
    assert ve.text == "Must be a valid date format."

    ve = bf.validation_error("invalid")
    assert isinstance(ve, ValidationError)
    assert ve.code == "invalid"
    assert ve.text == "Must be a real date."


# Generated at 2022-06-24 10:51:47.840105
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    now = datetime.datetime.now().time()
    now_string = now.isoformat()
    time_format = TimeFormat()
    # Test the function is_native_type
    native = time_format.is_native_type(now)
    assert native == True
    # Test the function validate
    validate = time_format.validate(now_string)
    assert validate == now
    # Test the function serialize
    serialize = time_format.serialize(now)
    assert serialize == now_string

# Generated at 2022-06-24 10:51:49.930906
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dateTimeFormat = DateTimeFormat()
    assert dateTimeFormat.is_native_type(datetime.datetime.now()) is True
    assert dateTimeFormat.is_native_type(datetime.date.today()) is False
    assert dateTimeFormat.is_native_type(datetime.time()) is False



# Generated at 2022-06-24 10:51:53.905994
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    # Arrange
    uuid1 = "efa3cb3d-c595-4ed7-a2f6-1eb2b1ad26b7"
    uuid_format_instance = UUIDFormat()

    # Act
    result1 = uuid_format_instance.is_native_type(uuid1)

    # Assert
    assert result1 == True



# Generated at 2022-06-24 10:51:54.894500
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base = BaseFormat()  # type: ignore
    assert type(base) == BaseFormat
    assert base.errors == {}


# Generated at 2022-06-24 10:52:02.389880
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    # A string with length of 36 should return True
    uf = UUIDFormat()
    assert uf.is_native_type('6ba7b810-9dad-11d1-80b4-00c04fd430c8') == True
    # A string with length unequal to 36 should return False
    assert uf.is_native_type('6ba7b810-9dad-11d1-80b4-00c04fd430c') == False
    # A string with length of 36 contains illegal char should return False
    assert uf.is_native_type('gba7b810-9dad-11d1-80b4-00c04fd430c8') == False



# Generated at 2022-06-24 10:52:04.555302
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = "2019-09-09T12:00:00.000000Z"
    assert DateTimeFormat().serialize(obj) == "2019-09-09T12:00:00Z"

# Generated at 2022-06-24 10:52:15.172481
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuidformat_obj = UUIDFormat()
    result1 = uuidformat_obj.is_native_type(uuid.UUID('a78f8aef-0ee3-47a3-b11e-f8c89d9cf450'))
    assert result1 == True
    result2 = uuidformat_obj.is_native_type(datetime.datetime.utcnow())
    assert result2 == False
    result3 = uuidformat_obj.is_native_type('a78f8aef-0ee3-47a3-b11e-f8c89d9cf450')
    assert result3 == False
    result4 = uuidformat_obj.is_native_type(1)
    assert result4 == False

# Generated at 2022-06-24 10:52:16.698161
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert isinstance(tf, TimeFormat)


# Generated at 2022-06-24 10:52:21.516843
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    t = TimeFormat()
    assert t.is_native_type(datetime.time(12,30,30)) is True
    assert t.is_native_type(datetime.date(2021,12,30)) is False
    assert t.is_native_type(datetime.datetime(2021,12,30,12,30,30)) is False
    assert t.is_native_type('2021-12-30') is False



# Generated at 2022-06-24 10:52:24.250498
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time()) == True
    assert time_format.is_native_type(datetime.datetime.now()) == False


# Generated at 2022-06-24 10:52:27.425284
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
	date = DateFormat()
	# value = date.serialize(datetime.date(2020, 1, 1))
	# assert value == "2020-01-01"
	value = date.serialize(datetime.datetime.now())
	assert value == "2020-01-03"

# Generated at 2022-06-24 10:52:28.661679
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()



# Generated at 2022-06-24 10:52:29.791895
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    format_time = TimeFormat()
    match = TIME_REGEX.match("21:34:05.567123")


# Generated at 2022-06-24 10:52:30.753035
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert isinstance(data.DateTimeFormat(), datetime.datetime)


# Generated at 2022-06-24 10:52:36.209452
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = UUIDFormat()
    string = 'b7bfaf2c-08e1-4b28-b6d5-86aab8ae0fb9'
    obj = uuid.UUID(string)
    assert u.serialize(obj) == 'b7bfaf2c-08e1-4b28-b6d5-86aab8ae0fb9'

# Generated at 2022-06-24 10:52:37.002736
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    a =DateTimeFormat()
    assert a

# Generated at 2022-06-24 10:52:38.436164
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime(2018,11,7,15,45,52))


# Generated at 2022-06-24 10:52:41.108736
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    timeFormat = TimeFormat()
    time = datetime.time(10, 10, 10, 123456)
    assert timeFormat.serialize(time) == "10:10:10.123456"

# Generated at 2022-06-24 10:52:45.938692
# Unit test for constructor of class DateFormat
def test_DateFormat():
    df = DateFormat()
    assert df.is_native_type(None) == False


# Generated at 2022-06-24 10:52:46.867576
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert isinstance(BaseFormat(), BaseFormat)

# Generated at 2022-06-24 10:52:49.320265
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    baseFormat = BaseFormat()
    x = {"a": 1}
    assert baseFormat.is_native_type(x) == True


# Generated at 2022-06-24 10:52:50.783552
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
  time = datetime.time(23, 45)
  time_format = TimeFormat()
  time_format.serialize(time)

# Generated at 2022-06-24 10:52:56.133130
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    x = DateFormat()
    x.validate("2020-02-02")
    assert x.validate("2020-02-02") == datetime.date(2020, 2, 2)
    assert x.is_native_type(x.validate("2020-02-02")) == True
    assert x.serialize(x.validate("2020-02-02")) == "2020-02-02"


# Generated at 2022-06-24 10:52:59.062698
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    base_format = BaseFormat()
    try:
        base_format.is_native_type([])
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 10:53:09.941411
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    #default
    from io import StringIO

    old_stdout = sys.stdout
    result = StringIO()
    sys.stdout = result

    DateTimeFormat().serialize(datetime.datetime.now())
    sys.stdout = old_stdout
    # assert result.getvalue() == 'None\n'
    print(result.getvalue())
    getval = result.getvalue()
    assert getval == 'None\n'

    # minimum
    DateTimeFormat().serialize(datetime.datetime(year=1970, month=1, day=1))

test_DateTimeFormat_validate()
test_DateTimeFormat_is_native_type()
test_DateTimeFormat_serialize()


# Generated at 2022-06-24 10:53:12.087158
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    obj = UUIDFormat()
    print(obj.is_native_type(value=None))
test_UUIDFormat()


# Generated at 2022-06-24 10:53:22.924373
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTime = DateTimeFormat()
    dateTime.validate("2017-01-01T00:00:00")
    dateTime.validate("2017-01-01T00:00:00+00:00")
    dateTime.validate("2017-01-01T00:00:00-08:51")
    dateTime.validate("2017-01-01T00:00:00.000000")
    dateTime.validate("2017-01-01T00:00:00.000000+00:00")
    dateTime.validate("2017-01-01T00:00:00.000000-08:51")
    try:
        dateTime.validate("2018/01/01T00:00:00.000000-08:51")
    except ValueError as e:
        assert "format" in str(e)

# Generated at 2022-06-24 10:53:29.642388
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Test 1: Testing serialize method of class DateFormat
    expected_result_1 = None
    actual_result_1 = DateFormat().serialize(None)
    assert actual_result_1 == expected_result_1
    print("\nTest 1: Testing serialize method of class DateFormat")
    print("- Input: None")
    print("- Expected output: None")
    print("- Actual output: " + str(actual_result_1))
    print("- Test status: Pass\n")


# Generated at 2022-06-24 10:53:36.693767
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    x = UUIDFormat()
    # Tests for all valid UUIDs
    # Compiling a list of valid UUIDs
    listOfNumbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    listOfLetters = ['a', 'b', 'c', 'd', 'e', 'f']
    validUUIDV4 = []
    for i in range(0, 36):
        if i in [8, 12, 16, 20]:
            validUUIDV4.append("-")
        elif i in [14, 18, 22, 26]:
            validUUIDV4.append("4")
        else:
            validUUIDV4.append("{}".format(random.choice(listOfNumbers)))
    # Function calling

# Generated at 2022-06-24 10:53:38.348895
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():    
    assert DateTimeFormat().is_native_type(datetime.datetime.now())
    

# Generated at 2022-06-24 10:53:40.375574
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    my_time = TimeFormat()
    value = my_time.validate("00:10")
    assert value == datetime.time(0,10)
    value = my_time.v

# Generated at 2022-06-24 10:53:45.114474
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    try:
        uuid_format.validate("e1377d9c-7a7f-4cfe-bded-04a2a7b3e545")
    except Exception:
        assert False, "Should not raise error."
    try:
        uuid_format.validate("e1377d9c7a7f4c")
    except Exception:
        assert False, "No error should be thrown."


# Generated at 2022-06-24 10:53:48.624358
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    val = UUIDFormat()
    assert val.serialize(None) == None
    assert val.serialize(uuid.UUID("09a0a9a1-c529-4705-be45-013f3e3f6b33")) == "09a0a9a1-c529-4705-be45-013f3e3f6b33"


# Generated at 2022-06-24 10:53:50.916496
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type('123') == False


# Generated at 2022-06-24 10:53:53.590875
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():

    value = datetime.date(2020, 10, 10)
    assert DateFormat().is_native_type(value)



# Generated at 2022-06-24 10:54:06.951882
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_f = UUIDFormat()
    uuid_obj = uuid.UUID('b53a66d1-0aaa-4f02-93a2-0f66635b606a')
    uuid_hex = str(uuid_obj)
    assert uuid_f.serialize(uuid_obj) == str(uuid_obj) #Unit test for method "serialize" of class UUIDFormat

    uuid_obj2 = uuid.UUID('b53a66d1-0aaa-4f02-93a2-0f66635b606a')
    assert uuid_f.is_native_type(uuid_obj2) # Unit test for method "is_native_type" of class UUIDFormat


# Generated at 2022-06-24 10:54:11.120779
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    try:
        BaseFormat().validate(1)
        assert False, 'BaseFormat validation should raise NotImplementedError.'
    except NotImplementedError:
        pass


# Generated at 2022-06-24 10:54:11.726228
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    pass

# Generated at 2022-06-24 10:54:17.046053
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Case 1: Time value is correct
    case1 = "05:55"
    tf1 = TimeFormat()
    assert tf1.validate(case1) == datetime.time(5,55,0)

    # Case 2: Time value is wrong, contains second and microsecond
    case2 = "27:22.1000"
    tf2 = TimeFormat()
    assert tf2.validate(case2) == datetime.time(27,22,0,100000)



# Generated at 2022-06-24 10:54:19.454664
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(1, 1, 1)
    date_format = DateFormat()
    date_format.serialize(date)

# Generated at 2022-06-24 10:54:22.380454
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    import typesystem
    field = typesystem.DateTime(format="datetime")
    value = "2020-05-26T12:46:34"
    result = field.deserialize(value)

    assert result.year == 2020
    assert result.month == 5
    assert result.day == 26
    assert result.hour == 12
    assert result.minute == 46
    assert result.second == 34
    assert result.microsecond == 0

# Generated at 2022-06-24 10:54:25.070121
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2018, 6, 13)) == '2018-06-13'


# Generated at 2022-06-24 10:54:30.015456
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # input value is valid date
    obj = DateFormat()
    assert obj.validate("2020-01-01") == datetime.date(2020, 1, 1)
    # input value is invalid date
    obj = DateFormat()
    try: 
        obj.validate("123-02-01")
    except ValidationError as e:
        assert e.code == "invalid"


# Generated at 2022-06-24 10:54:32.109747
# Unit test for constructor of class DateFormat
def test_DateFormat():
    a = DateFormat()
    assert isinstance(a, DateFormat)


# Generated at 2022-06-24 10:54:39.258704
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    df = DateFormat()
    assert df.is_native_type(datetime.date(1999, 12, 31)) == True
    assert df.is_native_type(datetime.date(2000, 2, 29)) == True
    assert df.is_native_type(datetime.date(2001, 1, 1)) == True
    assert df.is_native_type(datetime.date(2002, 1, 1)) == True
    tf = TimeFormat()
    assert tf.is_native_type(datetime.time(0,0,0)) == True
    assert tf.is_native_type(datetime.time(12,59,59,0)) == True
    assert tf.is_native_type(datetime.time(12,59,59,0)) == True
    dtf = DateTimeFormat()
    assert dtf

# Generated at 2022-06-24 10:54:43.134805
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time = datetime.time(hour=22, minute=10, second=21, microsecond=123456, tzinfo=None)
    #assert TimeFormat.is_native_type(time) == True #error
    assert TimeFormat().is_native_type(time) == True


# Generated at 2022-06-24 10:54:52.328613
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Case 1: test for one value
    dtf = DateTimeFormat()
    dt = datetime.datetime(2020, 1, 1, 5, 17, 14, 1000)
    assert(dtf.serialize(dt) == "2020-01-01T05:17:14.001000Z")

    # Case 2: test for one value
    dtf = DateTimeFormat()
    dt = datetime.datetime(2020, 1, 1, 5, 17, 14, 1000, datetime.timezone(datetime.timedelta(hours=-8)))
    assert(dtf.serialize(dt) == "2020-01-01T05:17:14.001000-08:00")

# Generated at 2022-06-24 10:54:54.838518
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d = datetime.date(2018, 10, 11)
    date = DateFormat().serialize(d)
    assert date == "2018-10-11"


# Generated at 2022-06-24 10:54:57.852946
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert isinstance(datetime.time(2, 3), datetime.time)

    assert time_format.is_native_type(datetime.time(2, 3))



# Generated at 2022-06-24 10:55:06.211629
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    df = DateTimeFormat()
    value = df.validate("2019-01-01T10:10:10Z")
    assert value == datetime.datetime(2019, 1, 1, 10, 10, 10, tzinfo=datetime.timezone.utc)
    assert df.is_native_type(value)
    assert not df.is_native_type("2019-01-01T10:10:10Z")
    assert df.serialize(value) == "2019-01-01T10:10:10Z"
    assert df.serialize(datetime.datetime(2019, 1, 1, 10, 10, 10, tzinfo=datetime.timezone.utc)) == "2019-01-01T10:10:10Z"


# Generated at 2022-06-24 10:55:13.874212
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type(): # pragma: no cover
    format = DateTimeFormat()
    assert format.is_native_type(datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)) == True
    assert format.is_native_type(datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))) == True
    assert format.is_native_type(datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone.utc).replace(tzinfo=None)) == True
    assert format.is_native_type(datetime.datetime(2020, 1, 1, 12, 0, 0)) == True
    assert format.is_native

# Generated at 2022-06-24 10:55:19.699450
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    test_types = {
        "some_non_native_type": 1,
        "date": datetime.date(1, 1, 1),
        "time": datetime.time(),
        "datetime": datetime.datetime.now(),
        "uuid": uuid.uuid4(),
    }
    baseformat = BaseFormat()
    for type_str, test_type in test_types.items():
        result = baseformat.is_native_type(test_type)
        if type_str != "some_non_native_type":
            assert result == True, "check type {} with method is_native_type".format(type_str)
        else:
            assert result == False, "check type {} with method is_native_type".format(type_str)


# Generated at 2022-06-24 10:55:20.853579
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat(error=None);
    

# Generated at 2022-06-24 10:55:25.054978
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert(time_format.is_native_type(datetime.time(12, 30))) == True
    assert(time_format.is_native_type(datetime.date(2020,1,1))) == False


# Generated at 2022-06-24 10:55:27.789619
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    format = TimeFormat()
    time = datetime.time(10, 2, 5, 0)
    assert format.serialize(time) == "10:02:05"

# Generated at 2022-06-24 10:55:35.619477
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate('16:00') #Value was correct. The program will not raise any error.
    time_format.validate('16:00:00') #Value was correct. The program will not raise any error.
    time_format.validate('16:00:00.000000') #Value was correct. The program will not raise any error.
    time_format.validate('16:00:00.000000000') #Value was correct. The program will not raise any error.
    time_format.validate('16:00:00.123456') #Value was correct. The program will not raise any error.
    time_format.validate('16:00:00.1234567') #Value was correct. The program will not raise any error.

# Generated at 2022-06-24 10:55:38.051162
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    UUIDFormat().validate("c9bf9e57-1685-4c89-bafb-ff5af830be8a")


# Generated at 2022-06-24 10:55:41.440131
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # type: () -> typing.Any
    assert True == True

# Generated at 2022-06-24 10:55:43.146868
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) is None


# Generated at 2022-06-24 10:55:46.763055
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    d = BaseFormat()
    with pytest.raises(NotImplementedError):
        d.is_native_type('2020-02-02')


# Generated at 2022-06-24 10:55:52.701036
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    from typesystem.base import ValidationError
    a = BaseFormat()
    assert a.validation_error('format') == ValidationError(text='Must be a valid date format.', code='format')
    assert a.validation_error('invalid') == ValidationError(text='Must be a real date.', code='invalid')



# Generated at 2022-06-24 10:56:04.451265
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    # valid case
    assert t.validate("03:44:44.123456") == datetime.time(3,44,44,123456)
    assert t.validate("03:44:44.123") == datetime.time(3,44,44,123000)
    assert t.validate("03:44:44") == datetime.time(3,44,44)
    assert t.validate("03:44") == datetime.time(3,44)
    # invalid case
    try:
        t.validate("2:34")
    except ValidationError:
        pass
    else:
        assert False
    try:
        t.validate("2.34")
    except ValidationError:
        pass
    else:
        assert False


# Generated at 2022-06-24 10:56:17.824987
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert DateFormat().serialize(datetime.date(2020, 1, 10)) == '2020-01-10'
    assert TimeFormat().serialize(datetime.time(12, 0, 1)) == '12:00:01'
    assert TimeFormat().serialize(datetime.time(12, 0)) == '12:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 10, 12, 0, 1)) == '2020-01-10T12:00:01'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 10, 12, 0, 1, tzinfo=datetime.timezone.utc)) == '2020-01-10T12:00:01Z'

# Generated at 2022-06-24 10:56:29.644684
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    # test is_native_type method of class DateTimeFormat
    assert DateTimeFormat().is_native_type(datetime.datetime.now())
    assert not DateTimeFormat().is_native_type(datetime.datetime.now().date())
    assert not DateTimeFormat().is_native_type(datetime.datetime.now().time())

    # test is_native_type method of class DateFormat
    assert DateFormat().is_native_type(datetime.datetime.now().date())
    assert not DateFormat().is_native_type(datetime.datetime.now())
    assert not DateFormat().is_native_type(datetime.datetime.now().time())

    # test is_native_type method of class TimeFormat
    assert TimeFormat().is_native_type(datetime.datetime.now().time())

# Generated at 2022-06-24 10:56:31.401681
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(None) == None


# Generated at 2022-06-24 10:56:33.369711
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    instance = DateFormat()
    assert instance.serialize(None) == None


# Generated at 2022-06-24 10:56:37.113702
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    import typesystem
    tf = typesystem.TimeFormat()
    time1 = tf.validate('18:55:55')
    time2 = tf.validate('18:55:55.123456')
    assert time1 == datetime.time(18,55,55)
    assert time2 == datetime.time(18,55,55,123456)

# Generated at 2022-06-24 10:56:38.310078
# Unit test for constructor of class DateFormat
def test_DateFormat():
    df = DateFormat()
    assert isinstance(df, DateFormat)


# Generated at 2022-06-24 10:56:46.160301
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # create test object
    t1 = datetime.datetime(2017, 5, 3, 11, 32)
    t2 = datetime.datetime(2017, 5, 3, 11, 32, 0, tzinfo=datetime.timezone.utc)

    # create instance of class
    dt = DateTimeFormat()

    # compare results
    assert dt.serialize(t1) == '2017-05-03T11:32:00'
    assert dt.serialize(t2) == '2017-05-03T11:32:00Z'

# Generated at 2022-06-24 10:56:55.507471
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    import datetime
    # Test 1
    obj = datetime.datetime(2000, 12, 31, tzinfo=datetime.timezone.utc)
    value = obj.isoformat()
    if value.endswith("+00:00"):
        value = value[:-6] + "Z"
    assert value == '2000-12-31T00:00:00Z'
    # Test 2
    obj = datetime.datetime(2001, 1, 1, tzinfo=datetime.timezone.utc)
    value = obj.isoformat()
    if value.endswith("+00:00"):
        value = value[:-6] + "Z"
    assert value == '2001-01-01T00:00:00Z'
    # Test 3

# Generated at 2022-06-24 10:56:57.163493
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    obj = '2020-08-05'
    assert DateFormat().serialize(obj) == '2020-08-05'

# Generated at 2022-06-24 10:57:05.747414
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dateObj = dateutil.parser.parse("2020-02-02T00:00:05+00:00")
    assert DateTimeFormat().serialize(dateObj) == "2020-02-02T00:00:05Z"
    dateObj = dateutil.parser.parse("2020-02-02T00:00:05-00:00")
    assert DateTimeFormat().serialize(dateObj) == "2020-02-02T00:00:05Z"

# Generated at 2022-06-24 10:57:07.306155
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid1()) == True


# Generated at 2022-06-24 10:57:13.344101
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    new_UUIDFormat = UUIDFormat()
    temp_uuid = uuid.uuid4()
    assert new_UUIDFormat.is_native_type(temp_uuid) == True
    print('UUIDFormat.is_native_type passed')


# Generated at 2022-06-24 10:57:15.630938
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    obj = UUIDFormat(errors = {"format": "Must be valid UUID format."})
    assert isinstance(obj, UUIDFormat)


# Generated at 2022-06-24 10:57:25.500644
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    input_method_name = 'name'
    input_value = 'value'
    output_error_message = 'value is not a valid {0}'.format(input_method_name)

    class BaseFormat:
        errors: typing.Dict[str, str] = {'format': '{0} is not a valid {0}'.format(input_method_name)}

        def validation_error(self, code: str) -> ValidationError:
            text = self.errors[code].format(input_method_name, input_value)
            return ValidationError(text=text, code=code)

    output_error = BaseFormat().validation_error('format')
    assert output_error_message == output_error.text
    assert input_method_name == output_error.code


# Generated at 2022-06-24 10:57:31.908753
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt_format = DateTimeFormat()
    dt = dt_format.validate("2019-06-18T15:26:30.456789Z")
    assert dt.year == 2019
    assert dt.month == 6
    assert dt.day == 18
    assert dt.hour == 15
    assert dt.minute == 26
    assert dt.second == 30
    assert dt.microsecond == 456789
    assert dt.tzinfo == datetime.timezone.utc

# Generated at 2022-06-24 10:57:40.846697
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # test day is invalid
    try:
        DateFormat().validate("2020-02-32")
    except ValidationError as error:
        assert error.args[0] == "Must be a real date."

    # test month is invalid
    try:
        DateFormat().validate("2020-13-01")
    except ValidationError as error:
        assert error.args[0] == "Must be a real date."

    # test year is invalid
    try:
        DateFormat().validate("2022-03-31")
    except ValidationError as error:
        assert error.args[0] == "Must be a real date."

    # test value is not a string

# Generated at 2022-06-24 10:57:45.472494
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert(UUIDFormat().serialize(uuid.UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')) == 'f47ac10b-58cc-4372-a567-0e02b2c3d479')

# Generated at 2022-06-24 10:57:55.311631
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    bf = TimeFormat()

    assert bf.validate('14:30:59') == datetime.time(14, 30, 59)
    assert bf.validate('14:30:59.123456') == datetime.time(14, 30, 59, 123456)
    assert bf.validate('14:30:59.1') == datetime.time(14, 30, 59, 100000)
    assert bf.validate('14:30:59.12') == datetime.time(14, 30, 59, 120000)
    assert bf.validate('14:30:59.123') == datetime.time(14, 30, 59, 123000)
    assert bf.validate('14:30:59.1234') == datetime.time(14, 30, 59, 123400)
   

# Generated at 2022-06-24 10:57:56.869750
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        b = BaseFormat()
        b.validate("")


# Generated at 2022-06-24 10:57:59.306320
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    bf = BaseFormat()
    result = bf.validate("")
    assert result == 'NotImplementedError'


# Generated at 2022-06-24 10:58:11.461239
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None
    assert DateTimeFormat().serialize(datetime.datetime(year=2020, month=12, day=15, hour=17, minute=24, second=38, tzinfo=pytz.utc)) == '2020-12-15T17:24:38'
    assert DateFormat().serialize(datetime.datetime(year=2020, month=12, day=15)) == '2020-12-15'
    assert TimeFormat().serialize(datetime.time(hour=12, tzinfo=pytz.utc)) == '12:00:00'

# Generated at 2022-06-24 10:58:20.924818
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date0=date1=datetime.datetime.today()
    date0=date0.replace(hour=0, minute=0, second=0, microsecond=0)
    date1=date1.replace(hour=0, minute=0, second=0, microsecond=0)
    date0=datetime.datetime.strftime(date0, '%Y-%m-%d')
    date1=datetime.datetime.strftime(date1, '%Y-%m-%d')
    object_date=DateFormat()
    assert object_date.validate(date0)==date1


# Generated at 2022-06-24 10:58:28.344749
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    """
    Test case for validate method of class DateTimeFormat
    :return:
    """
    obj = DateTimeFormat()
    assert obj.validate('1997-01-01T01:01:01Z') == datetime.datetime(year=1997, month=1, day=1, hour=1, minute=1, second=1, tzinfo=datetime.timezone.utc)
    assert obj.validate('1997-01-01T01:01:01+01:00') == datetime.datetime(year=1997, month=1, day=1, hour=1, minute=1, second=1, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-24 10:58:39.974713
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    from typesystem.base import IntegerType, Number, Text

    class TestFormat(BaseFormat):
        def serialize(self, obj: typing.Any) -> typing.Union[str, None]:
            assert isinstance(obj, (int, float))
            return str(obj)

    class NumberField(Number):
        format: typing.ClassVar[BaseFormat] = TestFormat()

    class TextField(Text):
        format: typing.ClassVar[BaseFormat] = TestFormat()

    class IntField(IntegerType):
        format: typing.ClassVar[BaseFormat] = TestFormat()

    class Test:
        field_number: NumberField = NumberField()
        field_text: TextField = TextField()
        field_int: IntField = IntField()


# Generated at 2022-06-24 10:58:43.633449
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat().is_native_type() == False
    assert BaseFormat().validate() == NotImplementedError
    assert BaseFormat().serialize() == NotImplementedError


# Generated at 2022-06-24 10:58:48.767883
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()
    print(timeformat.validate('12:30:59.000000'))
    print(timeformat.validate('12:30:59.000000Z'))



# Generated at 2022-06-24 10:58:50.766319
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    t = datetime.date.today()
    date_format = DateFormat()
    assert date_format.serialize(t) == t.isoformat()

# Generated at 2022-06-24 10:58:55.318787
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # Case 1: Correct call (no error)
    # Expected result: ValidationError
    assert BaseFormat().validation_error('format') == ValidationError(
        text='Must be a valid date format.', code='format')
    # Case 2: Incorrect call
    # Expected result: ValidationError
    assert BaseFormat().validation_error('format') != ValidationError(
        text='asd', code='asd')



# Generated at 2022-06-24 10:58:59.309680
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtf = DateTimeFormat()
    date = datetime.date.today()
    assert dtf.is_native_type(date) is True
    assert dtf.is_native_type(1) is False

# Unit tests for method validate of class DateTimeFormat

# Generated at 2022-06-24 10:59:04.449360
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    check = BaseFormat()

    assert check.is_native_type("abc") == True
    assert check.is_native_type("") == True
    assert check.is_native_type("13") == True
    assert check.is_native_type("123456") == True
    assert check.is_native_type("13.13") == True
    assert check.is_native_type("0.123456") == True



# Generated at 2022-06-24 10:59:06.562487
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    str(None)
    BaseFormat().serialize(None)
    assert BaseFormat().serialize(None) is None

# Generated at 2022-06-24 10:59:10.848972
# Unit test for constructor of class DateFormat
def test_DateFormat():
    form = DateFormat()
    assert form.errors == {
        "format": "Must be a valid date format.",
        "invalid": "Must be a real date.",
    }
