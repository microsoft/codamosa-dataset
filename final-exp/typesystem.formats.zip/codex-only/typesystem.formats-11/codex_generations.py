

# Generated at 2022-06-24 10:49:13.089586
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Testing for null
    assert DateFormat().serialize(None) == None

    # Testing for value
    assert DateFormat().serialize(datetime.date(2010, 4, 5)) == '2010-04-05'


# Generated at 2022-06-24 10:49:20.755914
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    l1 = [
        datetime.time(1,1,1),
        datetime.time(1,1,1,1),
    ]
    l2 = [
        datetime.date(1,1,1),
        datetime.datetime(1,1,1),
        "date",
        1,
    ]
    for i in l1:
        assert TimeFormat().is_native_type(i), "{} musst be a datetime.time".format(i)
    for i in l2:
        assert not TimeFormat().is_native_type(i), "{} musst not be a datetime.time".format(i)



# Generated at 2022-06-24 10:49:22.679526
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    d = datetime.date(2019, 11, 27)
    format1 = DateFormat()
    assert format1.is_native_type(d)
    assert not format1.is_native_type(d.isoformat())

# Test of method validate class DateFormat

# Generated at 2022-06-24 10:49:33.687998
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-12-31T23:33:59.678Z") == datetime.datetime(2019, 12, 31, 23, 33, 59, 678000, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-12-31T23:33:59Z") == datetime.datetime(2019, 12, 31, 23, 33, 59, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-12-31T23:33:59") == datetime.datetime(2019, 12, 31, 23, 33, 59)
    assert DateTimeFormat().validate("2019-12-31T23:33") == datetime.datetime(2019, 12, 31, 23, 33, 0)
   

# Generated at 2022-06-24 10:49:40.566566
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format = BaseFormat()
    format.errors = {
        "invalid": "Must be a valid number."
    }
    assert format.validation_error("invalid").text == "Must be a valid number."


# Generated at 2022-06-24 10:49:46.519306
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    import pytest
    obj = pytest
    assert isinstance(obj, uuid.UUID)
    value = UUIDFormat().serialize(obj)
    assert isinstance(value, str)

# Generated at 2022-06-24 10:49:51.157899
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2000-1-1") == datetime.date(2000, 1, 1)
    with raises(ValidationError) as exc:
        DateFormat().validate("2000-01-01T14:00:20.123456")
    assert exc.value.code == "format"


# Generated at 2022-06-24 10:49:54.020502
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = datetime.datetime.now().time()
    time_format = TimeFormat()
    assert time_format.is_native_type(time) == True
    print("Test for TimeFormat constructor is passed")


# Generated at 2022-06-24 10:49:55.109568
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) is None


# Generated at 2022-06-24 10:49:56.185804
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    obj = BaseFormat()
    assert(obj.errors == {})


# Generated at 2022-06-24 10:49:58.702069
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = uuid.uuid4()
    obj = UUIDFormat()
    assert obj.serialize(u) == str(u)

# Generated at 2022-06-24 10:50:08.979207
# Unit test for constructor of class DateFormat
def test_DateFormat():
    dateFormat = DateFormat()
    # Case 1: Valid Date
    assert (dateFormat.validate("2017-07-21")==datetime.date(2017, 7, 21))

    # Case 2: Invalid Date
    try:
        assert (dateFormat.validate("2-07-21")==datetime.date(2017, 7, 21))
    except:
        print('Validation Error: Invalid Date format')

    # Case 3: Random String
    try:
        assert (dateFormat.validate("jdhufsn")==datetime.date(2017, 7, 21))
    except:
        print('Validation Error: Invalid Date format')

# Unit Test for constructor of class TimeFormat

# Generated at 2022-06-24 10:50:21.805345
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()

    assert format.validate(
        "00000000-0000-0000-0000-000000000000") == uuid.UUID("00000000-0000-0000-0000-000000000000")
    assert format.validate(
        "00000001-0000-0000-0000-000000000000") == uuid.UUID("00000001-0000-0000-0000-000000000000")
    assert format.validate(
        "0000000a-0000-0000-0000-000000000000") == uuid.UUID("0000000a-0000-0000-0000-000000000000")

    assert format.validate(
        "00000000-0001-0000-0000-000000000000") == uuid.UUID("00000000-0001-0000-0000-000000000000")
    assert format.validate(
        "00000000-0002-0000-0000-000000000000") == uuid.UUID

# Generated at 2022-06-24 10:50:23.843127
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True


# Generated at 2022-06-24 10:50:33.048666
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize(uuid.UUID("00000000-0000-0000-0000-000000000000")) == "00000000-0000-0000-0000-000000000000"
    assert UUIDFormat().serialize(uuid.UUID("00000000-0000-0000-0000-000000000001")) == "00000000-0000-0000-0000-000000000001"
    assert UUIDFormat().serialize(uuid.UUID("00000000-0000-0000-0000-000000000002")) == "00000000-0000-0000-0000-000000000002"
    assert UUIDFormat().serialize(uuid.UUID("00000000-0000-0000-0000-000000000003")) == "00000000-0000-0000-0000-000000000003"


# Generated at 2022-06-24 10:50:36.150491
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time = TimeFormat()
    assert time.is_native_type(datetime.time(11, 59, 59))
    assert not time.is_native_type("bla")


# Generated at 2022-06-24 10:50:40.149426
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    st = "2019-2-1"
    t = DateFormat.validate(DateFormat(), st)
    print(t)

    st = "12:30"
    t = TimeFormat.validate(TimeFormat(), st)
    print(t)

    st = "2019-2-1T12:30"
    t = DateTimeFormat.validate(DateTimeFormat(), st)
    print(t)

# Generated at 2022-06-24 10:50:45.232892
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    def BaseFormatSubclass_is_native_type(self, value: typing.Any) -> bool:
        return True

    BaseFormat_subclass = typing.cast(
        typing.Type[BaseFormat],
        type('BaseFormatSubclass', (BaseFormat,), {'is_native_type': BaseFormatSubclass_is_native_type}),
    )
    base_format = BaseFormat_subclass()
    assert base_format.is_native_type(None)


# Generated at 2022-06-24 10:50:47.094232
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()
    assert b.errors == {}



# Generated at 2022-06-24 10:50:51.169025
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    format_types = [DateFormat(), TimeFormat(), DateTimeFormat(), UUIDFormat()]
    for format_type in format_types:
        assert format_type.is_native_type(None) == False


# Generated at 2022-06-24 10:50:53.537521
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    obj_fmt = DateFormat()
    assert(obj_fmt.is_native_type('2020-10-20')) == True


# Generated at 2022-06-24 10:50:59.587718
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(None) == True
    assert TimeFormat().is_native_type(0.0) == False
    assert TimeFormat().is_native_type("00:00:00") == False
    assert TimeFormat().is_native_type(datetime.time(0, 0, 0)) == True
    assert TimeFormat().is_native_type(datetime.time(10, 0, 1, 1000)) == True



# Generated at 2022-06-24 10:51:12.347428
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test with the param 'value' valid, the result must be a instance of datetime.datetime
    value = "2019-04-02T11:15:10.572618+00:00"
    result = DateTimeFormat().validate(value)
    assert isinstance(result, datetime.datetime)

    # Test with the param 'value' valid, the result must be a instance of datetime.datetime
    value = "2019-04-02T11:15:10+02:00"
    result = DateTimeFormat().validate(value)
    assert isinstance(result, datetime.datetime)

    # Test with the param 'value' valid, the result must be a instance of datetime.datetime
    value = "2019-04-02T11:15:10"

# Generated at 2022-06-24 10:51:15.914301
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value = '2020-02-11T10:00:00.000000-05:00'
    result = DateTimeFormat().validate(value)
    expected = datetime.datetime(2020, 2, 11, 10, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(0, -18000))) 
    assert result == expected

# Generated at 2022-06-24 10:51:25.604462
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    TEST_TIME = '12:00:00.123456'
    TEST_TIME_FORMAT = TIME_REGEX.match(TEST_TIME)
    groups = TEST_TIME_FORMAT.groupdict()
    if groups["microsecond"]:
        groups["microsecond"] = groups["microsecond"].ljust(6, "0")
    kwargs = {k: int(v) for k, v in groups.items() if v is not None}
    try:
        return datetime.time(tzinfo=None, **kwargs)
    except ValueError:
        raise self.validation_error("invalid")
    assert groups[1] == TEST_TIME_FORMAT.group(1)
    assert groups[2] == TEST_TIME_FORMAT.group(2)
    assert groups[3] == TEST_TIME_

# Generated at 2022-06-24 10:51:36.128335
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_format = TimeFormat();
    assert time_format.is_native_type("12:34:56.123456") is False
    assert time_format.is_native_type("12:34:56") is False
    assert time_format.is_native_type("12:34") is False
    assert time_format.is_native_type("12") is False
    assert time_format.is_native_type("1a:34:56") is False
    assert time_format.is_native_type(datetime.time(12,34,56)) is True
    assert time_format.is_native_type(datetime.time(12)) is True
    assert time_format.validate("12:34:56.123456") == datetime.time(12,34,56,123456)
    assert time_format

# Generated at 2022-06-24 10:51:40.320242
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    class BaseFormatTest(BaseFormat):
        errors = {
            "format": "Must be a valid date format.",
            "invalid": "Must be a real date.",
        }
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, datetime.date)

    test_bf = BaseFormatTest()
    assert test_bf.is_native_type("") == False
    assert test_bf.is_native_type(datetime.date.today()) == True


# Generated at 2022-06-24 10:51:42.493924
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    print(TimeFormat())
    print(TimeFormat.errors)
    print(TimeFormat.validation_error())

# Generated at 2022-06-24 10:51:51.652460
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type("2019-09-23T10:24:00+02:00") == False
    assert DateTimeFormat().is_native_type("2019-09-23T10:24:00") == False
    assert DateTimeFormat().is_native_type("2019-09-23T10:24") == False
    assert DateTimeFormat().is_native_type("2019-09-23") == False
    assert DateTimeFormat().is_native_type("2019-09") == False
    assert DateTimeFormat().is_native_type("2019-09-23T10:24:00.123") == False

    assert DateTimeFormat().is_native_type(datetime.datetime.utcfromtimestamp(0)) == True

# Generated at 2022-06-24 10:51:53.035223
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(str) == True

# Generated at 2022-06-24 10:51:56.911196
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    dt = '2019-01-03'
    df = DateFormat()
    assert isinstance(df.is_native_type(dt), bool)
    assert df.is_native_type(dt) == False


# Generated at 2022-06-24 10:52:00.697996
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    f = BaseFormat()
    error = f.validation_error(code="error")
    assert str(error) == "error"
    assert error.code == "error"


# Generated at 2022-06-24 10:52:06.799520
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(2020, 10, 10))
    assert not date_format.is_native_type(datetime.datetime(2020, 10, 10, 10, 10))
    assert not date_format.is_native_type(datetime.time(10, 10))
    assert not date_format.is_native_type(datetime.datetime(2020, 10, 10, 10, 10).date())
    assert not date_format.is_native_type("2020-10-10")


# Generated at 2022-06-24 10:52:11.067591
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        class TestFormat(BaseFormat):
            errors = {
                "format": "Must be a valid date format.",
                "invalid": "Must be a real date.",
            }
        test_obj = TestFormat()
        value = "2019-10-22"
        test_obj.validate(value)

# Generated at 2022-06-24 10:52:13.909376
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(uuid.uuid4())

# Generated at 2022-06-24 10:52:20.236115
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    timeformat = TimeFormat()
    timeValue = datetime.time(10, 20, 30, 400000)
    nativeType = timeformat.is_native_type(timeValue)
    assert nativeType == True

# Generated at 2022-06-24 10:52:21.313419
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert type(TimeFormat()) is TimeFormat


# Generated at 2022-06-24 10:52:22.098473
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    a=TimeFormat()


# Generated at 2022-06-24 10:52:24.101012
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    x = TimeFormat()
    assert not x.is_native_type('a')
    

# Generated at 2022-06-24 10:52:24.993013
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()


# Generated at 2022-06-24 10:52:26.498802
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    format = BaseFormat()
    assert format.validate(5) == '5'
    assert format.validate('str') == 'str'

# Generated at 2022-06-24 10:52:30.603957
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert isinstance(DateFormat().is_native_type(2),bool)
    assert isinstance(TimeFormat().is_native_type(2),bool)
    assert isinstance(DateTimeFormat().is_native_type(2),bool)
    assert isinstance(UUIDFormat().is_native_type(2),bool)


# Generated at 2022-06-24 10:52:32.201452
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time(0))


# Generated at 2022-06-24 10:52:39.411894
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uid = uuid.UUID("5c5f5a5a-2c2c-5e5e-2c2c-5a5a5f5c5c5c")
    assert UUIDFormat().serialize(uid) == '5c5f5a5a-2c2c-5e5e-2c2c-5a5a5f5c5c5c'


# Generated at 2022-06-24 10:52:44.490145
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()


# Generated at 2022-06-24 10:52:46.784640
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(2018, 1, 1)
    dateformat = DateFormat()
    assert dateformat.serialize(obj) == '2018-01-01'


# Generated at 2022-06-24 10:52:48.561325
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtfm = DateTimeFormat()
    assert dtfm.is_native_type(datetime.datetime.now())==True


# Generated at 2022-06-24 10:52:54.634834
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    myinput = uuid.UUID('6d2a04c7-6a10-4b07-8e3f-b731cfb1d0e7')
    myformat = UUIDFormat()
    assert myformat.serialize(myinput) == '6d2a04c7-6a10-4b07-8e3f-b731cfb1d0e7'


# Generated at 2022-06-24 10:53:01.141514
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    assert tf.is_native_type(None)
    assert tf.is_native_type(datetime.time(10,0,0))
    assert not tf.is_native_type("10:00:00")
    assert not tf.is_native_type(datetime.datetime(2020, 10, 6, 23, 15, 0))
    assert not tf.is_native_type(datetime.date(2020, 10, 6))


# Generated at 2022-06-24 10:53:03.007820
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat


# Generated at 2022-06-24 10:53:08.699903
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class MyFormat(BaseFormat):
        errors = {"foo": "Foo error"}
        def __init__(self, foo: str) -> None:
            self.foo = foo

    format = MyFormat("bar")
    error = format.validation_error("foo")
    assert error.code == "foo"
    assert error.text == "Foo error"



# Generated at 2022-06-24 10:53:11.689386
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = "2020-07-29"
    assert date == DateFormat().validate(date).isoformat()
    with pytest.raises(ValidationError):
        DateFormat().validate("2020-07-40")



# Generated at 2022-06-24 10:53:12.681704
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat()


# Generated at 2022-06-24 10:53:16.149799
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(uuid.UUID('123e4567-e89b-12d3-a456-426655440000'))



# Generated at 2022-06-24 10:53:17.216655
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    UUIDFormat()


# Generated at 2022-06-24 10:53:19.159485
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    baseformat = BaseFormat()
    assert baseformat.errors == {}
    assert baseformat.validation_error('format').error_data == {'text': 'Must be a valid date format.', 'code': 'format'}


# Generated at 2022-06-24 10:53:21.934302
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    # Testing the BaseFormat constructor 
    # Case 1: When creating object.
    # Case 2: When no object is created.
    try:
        obj = BaseFormat()
    except:
        obj = None
    # Case 1: When creating object
    assert obj is not None

    # Case 2: When no object is created
    assert obj is not None


# Generated at 2022-06-24 10:53:23.660711
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat.is_native_type(datetime.date.today()) == True


# Generated at 2022-06-24 10:53:26.929164
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    a=BaseFormat()
    try:
        a.serialize(1)
    except NotImplementedError:
        print('test_BaseFormat_serialize pass!')


# Generated at 2022-06-24 10:53:29.926643
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        BaseFormat().validate(None)

    with pytest.raises(NotImplementedError):
        BaseFormat().is_native_type(None)

    with pytest.raises(NotImplementedError):
        BaseFormat().serialize(None)


# Generated at 2022-06-24 10:53:32.310615
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
	class Test1(DateFormat):
		def __init__(self):
			pass
			
	test1 = Test1()
	assert test1.validate(value="2019-01-10") == datetime.date(2019, 1, 10)


# Generated at 2022-06-24 10:53:35.858742
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    
    tf = TimeFormat()
    assert isinstance(tf, TimeFormat)

    print("\n[*] Test for constructor of class TimeFormat : Passed")


# Generated at 2022-06-24 10:53:40.593912
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    a = BaseFormat()
    try:
        a.validate(10)
    except NotImplementedError:
        assert True
    except:
        assert False



# Generated at 2022-06-24 10:53:48.902710
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    """
    Test that the method validation_error returns the expected errors
    """
    # Test a valid error
    bf = BaseFormat()
    bf.__dict__ = {"format": "somevalue"}
    msg = bf.validation_error("format")
    assert msg.text == "Must be a valid date format."

    # Test that an invalid error returns an exception
    bf = BaseFormat()
    error_raised = False
    try:
        msg = bf.validation_error("blah")
    except KeyError:
        error_raised = True
    assert error_raised == True
    assert msg is None



# Generated at 2022-06-24 10:53:53.215266
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(2017, 8, 18)
    obj_date_format = DateFormat()
    assert obj_date_format.serialize(obj) == '2017-08-18'


# Generated at 2022-06-24 10:54:02.926359
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = UUIDFormat()

    assert '1234abcd-12ab-34cd-56ef-1234567890ab' == u.serialize(uuid.UUID("1234abcd-12ab-34cd-56ef-1234567890ab"))
    assert u.serialize(True) is None
    assert u.serialize("123") is None
    assert u.serialize(1234) is None

# Generated at 2022-06-24 10:54:04.594314
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    assert t.validate('12:30') == datetime.time(12, 30)

# Generated at 2022-06-24 10:54:11.529780
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()

    assert uuid_format.is_native_type('11111111-1111-1111-1111-111111111111') is True
    assert uuid_format.is_native_type('4d3b7c98-1e0b-4f9a-ad6d-c1e8e8b48d23') is True
    assert uuid_format.is_native_type('d3a3cb2b-8a1a-4563-b77d-caa0b8f35b99') is True
    assert uuid_format.is_native_type('d3a3cb2b8a1a4563b77dcaa0b8f35b99') is False
    assert uuid_format.is_native_type(123) is False
    assert uuid

# Generated at 2022-06-24 10:54:16.441050
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtf = DateTimeFormat()
    print(dtf.errors)
    #print(dtf.validate('2019-12-26T13:03'))
    print(dtf.serialize(datetime.datetime(2019, 12, 26, 13, 3)))
    print(dtf.serialize(datetime.datetime.now()))

if __name__ == "__main__":
    test_DateTimeFormat()

# Generated at 2022-06-24 10:54:18.354294
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    with pytest.raises(NotImplementedError):
        BaseFormat().serialize("")


# Generated at 2022-06-24 10:54:20.564636
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    datetimeFormat = DateTimeFormat()
    assert isinstance(datetimeFormat, DateTimeFormat)

# Generated at 2022-06-24 10:54:21.578965
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize('obj') == 'obj'

# Generated at 2022-06-24 10:54:27.891440
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    # test method DateFormat.is_native_type with None
    value = None
    d = DateFormat()
    result = d.is_native_type(value)
    assert result == False

    # test method DateFormat.is_native_type with valid date format
    value = '2020-01-02'
    result = d.is_native_type(value)
    assert result == False


# Generated at 2022-06-24 10:54:29.641570
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time()) == True


# Generated at 2022-06-24 10:54:33.224166
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    bf = BaseFormat()
    assert bf.validation_error("format") == ValidationError(error_code= "format",
                                                            error_detail= "Must be a valid date format.")



# Generated at 2022-06-24 10:54:35.786376
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    obj = UUIDFormat()
    match = obj.validate("8c4f1a42-b69e-11ea-b3de-0242ac130004")
    assert isinstance(match, uuid.UUID)


# Generated at 2022-06-24 10:54:42.444519
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    field = DateFormat()
    assert field.validate('1999-1-1') == datetime.date(1999, 1, 1)
    assert field.validate('1999-01-01') == datetime.date(1999, 1, 1)
    assert field.validate('9999-12-31') == datetime.date(9999, 12, 31)
    assert field.validate('0000-01-01') == datetime.date(0, 1, 1)


# Generated at 2022-06-24 10:54:47.792211
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    format = BaseFormat()
    assert callable(format.is_native_type)
    assert callable(format.validate)
    assert callable(format.serialize)
    assert callable(format.validation_error)
    assert isinstance(format.errors, dict)


# Generated at 2022-06-24 10:54:50.628950
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    dateFormat = DateFormat()
    assert not dateFormat.is_native_type(5)
    assert dateFormat.is_native_type(datetime.date(2019, 9, 21))


# Generated at 2022-06-24 10:54:53.546175
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert(BaseFormat.is_native_type(None) == False)
    assert(BaseFormat.validate(None) == None)
    assert(BaseFormat.serialize(None) == None)


# Generated at 2022-06-24 10:54:55.618121
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    time1 = format.validate(uuid.uuid4())
    print(time1)


# Generated at 2022-06-24 10:55:01.122992
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_fmt = UUIDFormat()
    uuid_fmt.is_native_type('87076d0a-faf2-3466-b859-3e726fde6a34')
    uuid_fmt.validate('87076d0a-faf2-3466-b859-3e726fde6a34')
    uuid_fmt.serialize(uuid.uuid4())

# Generated at 2022-06-24 10:55:03.827631
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time.now()) is True
    assert TimeFormat().is_native_type(datetime.time.now().isoformat()) is False

# Generated at 2022-06-24 10:55:07.854041
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # Test code here
    pass

# Generated at 2022-06-24 10:55:13.045772
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    test_obj = DateTimeFormat()
    
    assert test_obj.is_native_type(datetime.datetime.now())
    assert test_obj.is_native_type(datetime.datetime.now(tz=datetime.timezone(datetime.timedelta(hours=1))))
    assert test_obj.is_native_type(datetime.datetime.utcnow())
    assert test_obj.is_native_type(datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc))

# Generated at 2022-06-24 10:55:14.001084
# Unit test for constructor of class DateFormat
def test_DateFormat():
    format = DateFormat()


# Generated at 2022-06-24 10:55:15.648212
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    p = TimeFormat()
    print(p.validate("10:10:10.6"))


# Generated at 2022-06-24 10:55:20.153474
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    my_date = datetime.date(2017, 10, 31)
    assert isinstance(my_date, datetime.date)

    my_time = datetime.time(12, 30, 59, tzinfo=None)
    assert isinstance(my_time, datetime.time)

    my_datetime = datetime.datetime(2017, 10, 31, 12, 30, 59)
    assert isinstance(my_datetime, datetime.datetime)

    my_uuid = uuid.uuid4()
    assert isinstance(my_uuid, uuid.UUID)

# Generated at 2022-06-24 10:55:22.878943
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf=TimeFormat()
    with pytest.raises(Exception):
        tf.validate("12:00:00.000000")

# Generated at 2022-06-24 10:55:24.678890
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        BaseFormat().validate("")


# Generated at 2022-06-24 10:55:29.694754
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuidFormat = UUIDFormat()
    assert uuidFormat.is_native_type(uuid.UUID("f47ac10b-58cc-4372-a567-0e02b2c3d479"))
    assert not uuidFormat.is_native_type(12)
    assert not uuidFormat.is_native_type({'id': 12})


# Generated at 2022-06-24 10:55:39.170078
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # object DateFormat
    df = DateFormat()
    # case 1
    value = "2020-11-14"
    assert df.validate(value) == datetime.date(2020,11,14)
    # case 2
    value = "2020-11-31"
    #assert df.validate(value) == ValidationError(text='Must be a real date.', code='invalid')
    # case 3
    value = "2020-1-1"
    #assert df.validate(value) == ValidationError(text='Must be a valid date format.', code='format')

# Generated at 2022-06-24 10:55:46.056173
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    try:
        uuid_format.validate('Dea955b6-cac6-4f6d-aa6a-4f4b06a73ab5')
    except ValidationError as e:
        print(e)

test_UUIDFormat_validate()

# Generated at 2022-06-24 10:55:51.251425
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    f = DateTimeFormat()
    validate_1 = f.validate("2019-04-22T15:03")
    assert datetime.datetime(2019, 4, 22, 15, 3) == validate_1
    validate_2 = f.validate("2019-04-22T15:03:01")
    assert datetime.datetime(2019, 4, 22, 15, 3, 1) == validate_2
    validate_3 = f.validate("2019-04-22T15:03:01.123456")
    assert datetime.datetime(2019, 4, 22, 15, 3, 1, 123456) == validate_3
    validate_4 = f.validate("2019-04-22T15:03:01.123456Z")

# Generated at 2022-06-24 10:55:59.543257
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    match = TIME_REGEX.match('19:37')	
    if not match:
        assert_same(time.validation_format("format"),"Must be a valid time format")
    groups = match.groupdict()
    if groups["microsecond"]:
        groups["microsecond"] = groups["microsecond"].ljust(6, "0")
    kwargs = {k: int(v) for k, v in groups.items() if v is not None}
    try:
        assert_same(time.validation_error("invalid"),"Must be a real time")
    except ValueError:
        assert_same(time.validation_error("invalid"),"Must be a real time")


# Generated at 2022-06-24 10:56:02.732681
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    native_uuid = uuid.uuid4()
    result = UUIDFormat().is_native_type(native_uuid)
    assert result == True


# Generated at 2022-06-24 10:56:05.739073
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 6, 8)
    date_format = DateFormat()
    assert date_format.serialize(date) == "2020-06-08"



# Generated at 2022-06-24 10:56:08.576847
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time = datetime.time(hour=12, minute=30)
    assert TimeFormat().is_native_type(time) == True

# Generated at 2022-06-24 10:56:17.055934
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    isinstance(DateFormat().validate("1985-11-07"), datetime.date)
    isinstance(TimeFormat().validate("11:02:05"), datetime.time)
    isinstance(DateTimeFormat().validate("1985-11-07T11:02:05+01:00"), datetime.datetime)
    isinstance(UUIDFormat().validate("e0a0caf8-d8df-48e0-a62b-c5854a9e7edf"), uuid.UUID)


# Generated at 2022-06-24 10:56:19.100545
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(23, 59, 59)) == "23:59:59"

# Generated at 2022-06-24 10:56:25.537263
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    test_obj = uuid.UUID("12345678-1234-5678-1234-567812345678")
    test_instance = UUIDFormat()
    result = test_instance.serialize(test_obj)
    assert result == "12345678-1234-5678-1234-567812345678", result


# Generated at 2022-06-24 10:56:27.501214
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat.errors["format"] == "Must be a valid time format."


# Generated at 2022-06-24 10:56:33.371022
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    try:
        date_format.validate("2019-05-25")
    except ValidationError:
        assert False
    try:
        date_format.validate("2019-05-2")
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-24 10:56:34.217659
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert isinstance(DateFormat(), DateFormat)



# Generated at 2022-06-24 10:56:35.774505
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    if(type(uuid_format) is UUIDFormat):
        return True
    else:
        return False

# Generated at 2022-06-24 10:56:38.075716
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    base_format = BaseFormat()
    #Raises a NotImplementedError exception
    base_format.validate("12/12/2000")


# Generated at 2022-06-24 10:56:42.391861
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat.errors == {
        "format": "Must be a valid date format.",
        "invalid": "Must be a real date.",
    }


# Generated at 2022-06-24 10:56:45.388157
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    date = datetime.date(2018, 8, 16)
    assert df.serialize(date) == "2018-08-16"


# Generated at 2022-06-24 10:56:48.334338
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    value = "11:34"
    fmt = TimeFormat()
    result = fmt.validate(value)
    assert result.isoformat() == "11:34:00"

# Generated at 2022-06-24 10:56:50.847786
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dtf = DateTimeFormat()

# Generated at 2022-06-24 10:56:57.720646
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
	# valid date
	date = "1969-05-18"
	assert DateFormat().validate(date) == datetime.date(1969, 5, 18)
	# invalid date format
	with pytest.raises(ValidationError):
		DateFormat().validate("1969-5-18")
	# invalid date (month & day)
	with pytest.raises(ValidationError):
		DateFormat().validate("1969-15-32")


# Generated at 2022-06-24 10:57:04.150463
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    a = UUIDFormat()
    assert a.serialize(uuid.UUID('cb1b06a7-c9db-429d-8374-91232c7c23a3')) == "cb1b06a7-c9db-429d-8374-91232c7c23a3"


# Generated at 2022-06-24 10:57:08.527746
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class TestFormat(BaseFormat):
        def validate(self, value: typing.Any) -> str:
            return "val " + str(value)


    tf = TestFormat()
    assert tf.validate("1") == "val 1"
    assert tf.validate(2) == "val 2"



# Generated at 2022-06-24 10:57:20.261547
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    class Foo:
        bar = DateTimeFormat()

    foo = Foo()
    try :
        foo.bar.validate("2020-07-02T15:30:00Z")
    except ValidationError as err:
        print(err)

    try :
        foo.bar.validate("2020-07-02T15:30:00+02:00")
    except ValidationError as err:
        print(err)

    try :
        foo.bar.validate("2020-07-02T15:30:00")
    except ValidationError as err:
        print(err)

    try :
        foo.bar.validate("2020-07-02T15:30:00.3+02:00")
    except ValidationError as err:
        print(err)


# Generated at 2022-06-24 10:57:24.518127
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    fmt = TimeFormat()
    
    assert fmt.validate("15:30") == datetime.time(15, 30)
    assert fmt.validate("15:30:12") == datetime.time(15, 30, 12)
    assert fmt.validate("15:30:12.1234") == datetime.time(15, 30, 12, 123400)


# Generated at 2022-06-24 10:57:27.800095
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dateTimeFormatObject = DateTimeFormat()
    assert dateTimeFormatObject.is_native_type(datetime.datetime.now()) is True
    assert dateTimeFormatObject.is_native_type(str.lower) is False
    assert dateTimeFormatObject.is_native_type(None) is False

# Generated at 2022-06-24 10:57:29.134753
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    obj = DateTimeFormat()
    return obj


# Generated at 2022-06-24 10:57:38.092294
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(2019, 1, 1)) == True
    assert date_format.is_native_type(datetime.time(12, 1, 1)) == False
    assert date_format.is_native_type(datetime.datetime(2019, 1, 1, 12, 1, 1)) == False
    assert date_format.is_native_type(uuid.uuid4()) == False

    with pytest.raises(NotImplementedError):
        date_format.validate("2019-01-01")

    with pytest.raises(NotImplementedError):
        date_format.serialize(datetime.date.today())


# Generated at 2022-06-24 10:57:41.344338
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    string = "09:32:03.003005"
    TimeFormat().validate(string)


# Generated at 2022-06-24 10:57:52.469038
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize('20201206') == '20201206'
    assert BaseFormat().serialize('20201206 15:23:11') == '20201206 15:23:11'
    assert BaseFormat().serialize('20201206 15:23:11 +0800') == '20201206 15:23:11 +0800'
    assert BaseFormat().serialize('20201206 15:23:11.000000') == '20201206 15:23:11.000000'
    assert BaseFormat().serialize('20201206 15:23:11.000001') == '20201206 15:23:11.000001'
    assert BaseFormat().serialize('20201206 15:23:11.123456') == '20201206 15:23:11.123456'

# Generated at 2022-06-24 10:57:53.219209
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base = BaseFormat()
    

# Generated at 2022-06-24 10:58:03.851243
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():

    # assert True
    assert TimeFormat().validate('20:13:23') == datetime.time(20, 13, 23)
    assert TimeFormat().validate('20:13:23.000000') == datetime.time(20, 13, 23)
    assert TimeFormat().validate('20:13:23.166666') == datetime.time(20, 13, 23, 166666)
    assert TimeFormat().validate('5:13:23.166666') == datetime.time(5, 13, 23, 166666)
    assert TimeFormat().validate('5:13:23.1666661') == datetime.time(5, 13, 23, 166666)
    assert TimeFormat().validate('5:13:23.1666') == datetime.time(5, 13, 23, 166600)
    assert TimeFormat

# Generated at 2022-06-24 10:58:07.313726
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid = uuid.uuid1()
    assert UUIDFormat().serialize(uuid) == str(uuid)
# End of unit test for method serialize of class UUIDFormat



# Generated at 2022-06-24 10:58:16.365849
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_1 = uuid.uuid4()
    uuid_2 = '6c5ff6ab-ae09-4d97-9b9d-a7caddeaf871'
    uuid_3 = '6c5ff6ab-ae09-4d97'
    uuid_4 = None
    uuid_5 = 123
    uuid_6 = [1, 2, 3]
    uuid_7 = {'a': 1, 'b': 2}

    obj = UUIDFormat()
    assert(obj.is_native_type(uuid_1) is True)
    assert(obj.is_native_type(uuid_2) is False)
    assert(obj.is_native_type(uuid_3) is False)

# Generated at 2022-06-24 10:58:18.705639
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime(2018, 1, 2, 3, 4, 5, 6))
    assert not DateTimeFormat().is_native_type("2018-01-02T03:04:05.000006Z")


# Generated at 2022-06-24 10:58:31.665713
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    formatUUID = UUIDFormat()
    uuid1 = uuid.UUID('5f5b5cce-9a89-45a1-9b2f-a6c43bc6fa1e')
    uuid2 = uuid.UUID('fffb5cce-9a89-45a1-9b2f-a6c43bc6fa1e')
    assert formatUUID.serialize(uuid1) == '5f5b5cce-9a89-45a1-9b2f-a6c43bc6fa1e'
    assert formatUUID.serialize(uuid2) == 'fffb5cce-9a89-45a1-9b2f-a6c43bc6fa1e'


# Generated at 2022-06-24 10:58:36.465246
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
   time = TimeFormat() # created an object of class TimeFormat
   assert time.validate('12:10:00') == datetime.time(12, 10) # validating the value 12:10:00
   assert time.validate('12:10:30.123') == datetime.time(12, 10, 30, 123000) # validating the value 12:10:30.123
   assert time.validate('03:30') == datetime.time(3, 30) # validating the value 03:30
   assert time.validate('18:30:00') == datetime.time(18, 30) # validating the value 18:30:00
   assert time.validate('03:30:00.123456') == datetime.time(3, 30, 0, 123456) # validating the value 03:30:00.123

# Generated at 2022-06-24 10:58:41.745736
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uf1 = UUIDFormat()
    uf2 = UUIDFormat()
    assert uf1 != uf2, "UUIDFormat's constructor creates different instances"
    assert isinstance(uf1, BaseFormat), "UUIDFormat is not a subclass of BaseFormat"
    assert uf1.errors.get("format") == "Must be valid UUID format.", "UUIDFormat.errors does not contain the expected keys and values"


# Generated at 2022-06-24 10:58:46.832131
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    test_object = DateFormat()
    assert test_object.serialize(datetime.date(2016, 12, 31)) == "2016-12-31"
    assert test_object.serialize(datetime.date(2016, 1, 1)) == "2016-01-01"
    assert test_object.serialize(None) == None


# Generated at 2022-06-24 10:58:50.591611
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    result = df.is_native_type(datetime.date.today())
    assert result == True
    result = df.is_native_type(datetime.date.today().isoformat()) == False
    assert result == True


# Generated at 2022-06-24 10:58:52.401512
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    a=BaseFormat()
    with pytest.raises(NotImplementedError):
        a.serialize(2)


# Generated at 2022-06-24 10:58:55.623711
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    assert df.is_native_type(datetime.date(2019,2,2))



# Generated at 2022-06-24 10:58:56.965609
# Unit test for constructor of class DateFormat
def test_DateFormat():
    d = DateFormat()



# Generated at 2022-06-24 10:58:59.454094
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class Temp(BaseFormat): pass
    
    temp = Temp()
    assert temp.serialize(None) == None
    assert temp.serialize(0) == None


# Generated at 2022-06-24 10:59:01.937276
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    baseformat = BaseFormat()

# Generated at 2022-06-24 10:59:06.725436
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    from typesystem.base import Time as BaseTime
    try:
        from typesystem.datetime import Time
    except:
        print("Can't test, because module typesystem.datetime is not exist.")
        return
    time_format = Time()
    assert hasattr(time_format, 'is_native_type')
    assert time_format.is_native_type(datetime.time())
    assert not time_format.is_native_type(BaseTime())


# Generated at 2022-06-24 10:59:12.151030
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    # This is a red test
    time = datetime.datetime.now().time().isoformat()
    if time.endswith("+00:00"):
        time = time[:-6] + "Z"
    assert time == TimeFormat().serialize(datetime.datetime.now().time())
