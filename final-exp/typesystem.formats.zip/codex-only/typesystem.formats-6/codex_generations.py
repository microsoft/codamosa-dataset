

# Generated at 2022-06-24 10:49:15.467199
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    """Test method TimeFormat.serialize()"""
    import datetime
    time = datetime.time(14, 30, 45, 25000)
    time_format = TimeFormat()
    assert time_format.serialize(time) == "14:30:45.025000"

# Generated at 2022-06-24 10:49:18.042565
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    b = BaseFormat()
    try:
        b.is_native_type(123)
    except NotImplementedError:
        return True
    assert False


# Generated at 2022-06-24 10:49:20.601063
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    a = TimeFormat()
    assert isinstance(a, TimeFormat)


# Generated at 2022-06-24 10:49:23.414251
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    t = TimeFormat().is_native_type(datetime.datetime.today())
    assert t == True


# Generated at 2022-06-24 10:49:29.570958
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(1) == 1
    assert BaseFormat().serialize('abc') == 'abc'
    assert BaseFormat().serialize([1, 2]) == [1, 2]
    assert BaseFormat().serialize({'a': 1}) == {'a':1}
    assert BaseFormat().serialize(None) is None

# Generated at 2022-06-24 10:49:32.333454
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base_format = BaseFormat()
    test_dict = {'test':1}
    base_format.__dict__.update(test_dict)
    assert base_format.__dict__ == test_dict


# Generated at 2022-06-24 10:49:37.213426
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    # with pytest.raises(NotImplementedError):
    #    bf = BaseFormat()

    # with pytest.raises(NotImplementedError):
    #    bf = BaseFormat()
    #    bf.is_native_type('')

    # with pytest.raises(NotImplementedError):
    #    bf = BaseFormat()
    #    bf.validate('')

    # with pytest.raises(NotImplementedError):
    #    bf = BaseFormat()
    #    bf.serialize('')
    pass



# Generated at 2022-06-24 10:49:38.345044
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat()


# Generated at 2022-06-24 10:49:44.516900
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    # BaseFormat.is_native_type is an abstract method, so we cannot create an instance of BaseFormat
    # to verify its behavior. For unit tests, we use the class DateFormat as a substitute.
    assert DateFormat().is_native_type(datetime.date(2020, 1, 2))
    assert not DateFormat().is_native_type(datetime.datetime(2020, 1, 2))
    assert not DateFormat().is_native_type('2020-01-02')


# Generated at 2022-06-24 10:49:47.390231
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    time = datetime.time(13,10,30,0)
    assert tf.serialize(time) == "13:10:30"

# Generated at 2022-06-24 10:49:54.774886
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert DateFormat().serialize("2020-10-01") == "2020-10-01"
    assert TimeFormat().serialize("13:13:13") == "13:13:13"
    assert DateTimeFormat().serialize("2020-10-01T13:13:13Z") == "2020-10-01T13:13:13Z"
    assert UUIDFormat().serialize("68dfc2d2-e9aa-11ea-adc1-0242ac120002") == "68dfc2d2-e9aa-11ea-adc1-0242ac120002"

# Generated at 2022-06-24 10:49:57.133394
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    item = TimeFormat()
    assert item.serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == "00:00:00"


# Generated at 2022-06-24 10:50:03.095353
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    d = DateFormat()
    #assert d.validate('2020-05-01') == datetime.date(2020, 5, 1)
    assert d.validate('2021-05-01') == datetime.date(2021, 5, 1)
    try:
        assert d.validate('2021-05')
    except:
        assert True

# Generated at 2022-06-24 10:50:11.352163
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj_1 = datetime.datetime(year=2020, month=4, day=20, hour=20, minute=20, second=20, microsecond=20, tzinfo=datetime.timezone(datetime.timedelta(hours=0, minutes=0)))
    obj_2 = datetime.datetime(year=2020, month=4, day=20, hour=20, minute=20, second=20, microsecond=20, tzinfo=datetime.timezone(datetime.timedelta(hours=10, minutes=0)))
    obj_3 = datetime.datetime(year=2020, month=4, day=20, hour=20, minute=20, second=20, microsecond=20, tzinfo=datetime.timezone(datetime.timedelta(hours=0, minutes=10)))

   

# Generated at 2022-06-24 10:50:13.502496
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate('2019-03-07') == datetime.date(2019, 3, 7)

# Generated at 2022-06-24 10:50:16.753538
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    date = '2021-07-21'
    result = dateFormat.validate(date)
    assert result == datetime.date(2021, 7, 21)


# Generated at 2022-06-24 10:50:20.303469
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    obj = BaseFormat()
    with pytest.raises(NotImplementedError):
        obj.validate(1)


# Generated at 2022-06-24 10:50:26.133362
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    times = [datetime.time(5,6,7), datetime.time(23,45,4,100000), datetime.time(23,45,4,100100)]
    expected_results = ['05:06:07', '23:45:04.100000', '23:45:04.100100']

    for i in range(3):
        assert TimeFormat().serialize(times[i]) == expected_results[i]

# Generated at 2022-06-24 10:50:26.853875
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
	assert isinstance(UUIDFormat(), UUIDFormat)

# Generated at 2022-06-24 10:50:31.382912
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-11-10") == datetime.date(2020, 11, 10)
    assert DateTimeFormat().validate("2020-11-10T15:13:26") == datetime.datetime(2020, 11, 10, 15, 13, 26)


# Generated at 2022-06-24 10:50:40.636262
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    from typesystem.base import Type, ValidationError
    from typesystem.compat import ForwardRef
    from tests.validators.shorthands import (
        Array,
        Boolean,
        Dictionary,
        Integer,
        Number,
        String,
    )

    class Person(Type):
        __annotations__ = {"name": String}
        name = String

    class Pet(Type):
        __annotations__ = {"name": String, "owner": ForwardRef("Person")}
        name = String
        owner = ForwardRef("Person")

    class PersonSchema(Type):
        __annotations__ = {
            "id": UUIDFormat,
            "age": Integer,
            "name": String,
            "pets": Array[Pet],
        }
        id = UUIDFormat
        age = Integer
        name = String

# Generated at 2022-06-24 10:50:44.203936
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert UUIDFormat().validate('1beac04a-f0ae-470b-90fa-e449fecdc0ba') == uuid.UUID('1beac04a-f0ae-470b-90fa-e449fecdc0ba')
    try:
        UUIDFormat().validate('1beac04a')
    except ValidationError as e:
        assert e.code == 'format'


# Generated at 2022-06-24 10:50:47.398217
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2019, 1, 2)) == "2019-01-02"


# Generated at 2022-06-24 10:50:51.795046
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    bf.validation_error('format')
    bf.is_native_type(1)
    bf.validate(1)
    bf.serialize(1)


# Generated at 2022-06-24 10:51:00.603300
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-02-01") == datetime.date(2019, 2, 1)

    with pytest.raises(ValidationError) as err:
        date_format.validate("2019-02-00")

    assert err.value.code == "invalid"
    assert err.value.text == "Must be a real date."

    with pytest.raises(ValidationError) as err:
        date_format.validate("2019-02")

    assert err.value.code == "format"
    assert err.value.text == "Must be a valid date format."


# Generated at 2022-06-24 10:51:05.212657
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    BaseTest = BaseFormat()
    try:
        assert BaseTest.validate("")
    except NotImplementedError:
        pass


# Generated at 2022-06-24 10:51:08.167489
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()

# Generated at 2022-06-24 10:51:14.906297
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    print("Testing TimeFormat...")
    time = datetime.time(hour=12, minute=45, second=27, microsecond=1234)
    timeString = time.isoformat()
    try:
        t = TimeFormat()
        t.validate(timeString)
        print("-> Everything seems to be OK")
    except ValidationError as e:
        print("-> Error: " + e.text)


# Generated at 2022-06-24 10:51:17.727581
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    d = DateFormat()

    assert d.is_native_type(datetime.date(2020,5,5)) == True
    assert d.is_native_type("2020-05-05") == False


# Generated at 2022-06-24 10:51:20.382754
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(1913, 1, 13)) == "1913-01-13"


# Generated at 2022-06-24 10:51:21.490294
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    new = DateTimeFormat()
    assert isinstance(new, DateTimeFormat)

# Generated at 2022-06-24 10:51:26.718175
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class MyFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, str)
    my_format = MyFormat()
    assert my_format.is_native_type('abc') is True



# Generated at 2022-06-24 10:51:28.850270
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("2019-05-06") == datetime.date(2019, 5, 6)


# Generated at 2022-06-24 10:51:32.842469
# Unit test for constructor of class DateFormat
def test_DateFormat():
	d = datetime.date(year=2019, month=10, day=2)
	valid_date = DateFormat()
	same_date = valid_date.validate('2019-10-02')
	assert type(same_date) == type(d)


# Generated at 2022-06-24 10:51:38.744622
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    output = UUIDFormat().serialize('66c052a3-d9e9-4d3b-92a4-4e4c4e4d3a7f')
    assert output, '66c052a3-d9e9-4d3b-92a4-4e4c4e4d3a7f'

# Generated at 2022-06-24 10:51:42.029830
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = datetime.time(5,30,20)
    f = TimeFormat()
    assert f.validate(time.isoformat()) == time

# Generated at 2022-06-24 10:51:44.908398
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(18, 4, 32))



# Generated at 2022-06-24 10:51:46.499510
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    base_object = BaseFormat()
    assert base_object.is_native_type("") == False


# Generated at 2022-06-24 10:51:52.020936
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert df.serialize(datetime.date(2002, 6, 3)) == "2002-06-03"
    assert df.serialize(None) == None


# Generated at 2022-06-24 10:51:53.416249
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(True)

# Generated at 2022-06-24 10:51:56.664795
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    """
    Test that the constructor of TimeFormat works as expected.
    """
    timeFormat = TimeFormat()
    assert timeFormat is not None


# Generated at 2022-06-24 10:52:06.495622
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2012-01-19T18:39:48.266697Z") == datetime.datetime(2012, 1, 19, 18, 39, 48, 266697, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2012-01-19T18:39:48.266697") == datetime.datetime(2012, 1, 19, 18, 39, 48, 266697)
    assert DateTimeFormat().validate("2012-01-19T18:39:48") == datetime.datetime(2012, 1, 19, 18, 39, 48)
    assert DateTimeFormat().validate("2012-01-19T18:39") == datetime.datetime(2012, 1, 19, 18, 39)


# Generated at 2022-06-24 10:52:17.640083
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate(): # pragma : no cover
    tf = TimeFormat()
    assert tf.validate("10:06:30.654321") == datetime.time(10,6,30,654321)
    assert tf.validate("10:06:30") == datetime.time(10,6,30)
    assert tf.validate("10:06:30.6543") == datetime.time(10,6,30,654300)
    assert tf.validate("10:06:30.654321Z") == datetime.datetime(1900,1,1,10,6,30,654321, tzinfo=datetime.timezone.utc)
    assert tf.validate("10:06") == datetime.time(10,6)

# Generated at 2022-06-24 10:52:25.606428
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    # Test with an instance of datetime
    new_DateTimeFormat = DateTimeFormat()
    expectedOutput = True
    assert new_DateTimeFormat.is_native_type(datetime.datetime(year=2019, month=5, day=5)) == expectedOutput
    # Test with random string
    new_DateTimeFormat = DateTimeFormat()
    expectedOutput = False
    assert new_DateTimeFormat.is_native_type("gwvbvwb") == expectedOutput
    # Test with random string
    new_DateTimeFormat = DateTimeFormat()
    expectedOutput = False
    assert new_DateTimeFormat.is_native_type("gwvbvwb") == expectedOutput
    # Test with an instance of datetime
    new_DateTimeFormat = DateTimeFormat()
    expectedOutput = True
    assert new_DateTimeFormat

# Generated at 2022-06-24 10:52:26.858389
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date = datetime.date(2020, 5, 30)
    assert DateFormat().is_native_type(date) == True


# Generated at 2022-06-24 10:52:35.468810
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    from typesystem.fields import Time
    timefield = Time()
    value = "00:00:01"
    timefield.validate(value)
    value = "00:00:01.00"
    timefield.validate(value)
    value = "00:00:01.00"
    timefield.validate(value)
    value = "00:00:01.123456"
    timefield.validate(value)
    value = "00:00:01.123"
    timefield.validate(value)
    value = "00:00:01.123"
    timefield.validate(value)
    value = "00:00:01.12345"
    timefield.validate(value)
    value = "00:00:01.12345"

# Generated at 2022-06-24 10:52:44.247315
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    timestring = "10:12:11.123456"
    value = time_format.validate(timestring)
    assert isinstance(value, datetime.time)
    assert value.isoformat() == timestring

    timestring = "10:12:11"
    value = time_format.validate(timestring)
    assert isinstance(value, datetime.time)
    assert value.isoformat() == timestring

    timestring = "10:12"
    value = time_format.validate(timestring)
    assert isinstance(value, datetime.time)
    assert value.isoformat() == timestring

    timestring = "10"
    value = time_format.validate(timestring)

# Generated at 2022-06-24 10:52:47.774682
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date.today())
    assert not DateFormat().is_native_type("1")
    assert not DateFormat().is_native_type(datetime.time.now())


# Generated at 2022-06-24 10:52:53.648226
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    test_format = UUIDFormat()
    uuid_invalid = "78781e72-b2d2-11e8-9f32-f2801f1b9fd1"
    uuid_invalid_is_native = test_format.is_native_type(uuid_invalid)
    assert uuid_invalid_is_native


# Generated at 2022-06-24 10:53:04.074486
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Input for function "validate" of class TimeFormat would be str
    # Sets the limit of the number of digits in the minute and second
    for i in range(0,60): # Range for minutes 00 to 59
        for j in range(0,60): # Range for seconds 00 to 59
            # Creates a string of the form hh:mm:ss
            str_time = '{:02d}:{:02d}:{:02d}'.format(i,j,i)
            # Call the function validate method of class TimeFormat
            time = TimeFormat().validate(str_time)
            # Assert the return type of function validate to be of datetime.time
            assert isinstance(time,datetime.time)
            # Assert the hours and seconds to be equal to the hour and seconds in the input string
            assert time.hour

# Generated at 2022-06-24 10:53:12.682723
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    #check Z case
    dtf = DateTimeFormat()
    assert dtf.validate('2018-01-01T00:00:00Z') == datetime.datetime(2018,1,1,0,0,0,tzinfo=datetime.timezone.utc)
    #check + case
    dtf = DateTimeFormat()
    assert dtf.validate('2018-01-01T00:00:00+08:00') == datetime.datetime(2018,1,1,0,0,0,tzinfo=datetime.timezone(datetime.timedelta(hours = 8)))
    #check - case
    dtf = DateTimeFormat()

# Generated at 2022-06-24 10:53:13.507888
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert True

# Generated at 2022-06-24 10:53:16.043754
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format = DateTimeFormat()
    test_date = datetime.datetime.now()
    assert format.is_native_type(test_date) == True


# Generated at 2022-06-24 10:53:18.674870
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime.now()
    value = DateTimeFormat().serialize(obj)
    assert value == obj.isoformat()
    assert value.endswith("Z")

# Generated at 2022-06-24 10:53:24.027016
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    obj_datetime = datetime.datetime.now()
    obj_date = datetime.date.today()
    obj_time = datetime.time.now()

    date_time = DateTimeFormat()
    assert date_time.is_native_type(obj_datetime) == True
    assert date_time.is_native_type(obj_date) == False
    assert date_time.is_native_type(obj_time) == False


# Generated at 2022-06-24 10:53:27.310529
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format = DateFormat()
    assert format.validation_error("format").code == "format"
    assert format.validation_error("format").text == "Must be a valid date format."


# Generated at 2022-06-24 10:53:35.331082
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    instances = [
        DateFormat(),
        TimeFormat(),
        DateTimeFormat(),
        UUIDFormat(),
    ]

    result = [
        instances[0].validate('2018-01-01'),
        instances[1].validate('12:00:00'),
        instances[2].validate('2018-01-01T12:00:00'),
        instances[3].validate('39e3e966-81a6-43ae-8bdc-ea7aacb04ba6'),
    ]


# Generated at 2022-06-24 10:53:40.107369
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuidFormat = UUIDFormat()
    assert uuidFormat.is_native_type("387e76f4-d30f-4d9b-9a4a-b4a74e8577f3")
    assert not uuidFormat.is_native_type("387e76f4-dgof-4d9b-9a4a-b4a74e8577f3")

# Generated at 2022-06-24 10:53:44.802115
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date.today()) == True


# Generated at 2022-06-24 10:53:47.320880
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    object = UUIDFormat()
    obj = uuid.UUID('d0a44a38-8faa-11ea-bc55-0242ac130003')
    assert object.serialize(obj) == 'd0a44a38-8faa-11ea-bc55-0242ac130003'

# Generated at 2022-06-24 10:53:57.122690
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    sut = TimeFormat()
    assert sut.serialize(None) == None
    assert sut.serialize(datetime.time(tzinfo=None, hour=22, minute=11)) == '22:11:00'
    assert sut.serialize(datetime.time(tzinfo=None, hour=22, minute=11, second=14)) == '22:11:14'
    assert sut.serialize(datetime.time(tzinfo=None, hour=22, minute=11, second=12, microsecond=12)) == '22:11:12.000012'


# Generated at 2022-06-24 10:54:07.578578
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Arrange
    datetimeFormat = DateTimeFormat()
    datetimeString1 = "2020-04-20T06:22:50.916123Z"
    datetimeString2 = "2020-04-20T06:22:50.916123+00:00"
    datetimeString3 = "2020-04-20T06:22:50.916123+07:00"
    datetimeString4 = "2020-04-20T06:22:50.916123-07:00"
    datetimeString5 = "2020-04-20T06:22:50.916123+0000"
    datetimeString6 = "2020-04-20T06:22:50.916123+0700"

    datetimeString7 = "2020-04-20T06:22:50.916123"
    datetimeString8

# Generated at 2022-06-24 10:54:08.220198
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    obj = DateTimeFormat()


# Generated at 2022-06-24 10:54:10.141703
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    obj = BaseFormat()
    assert not obj.is_native_type(None)



# Generated at 2022-06-24 10:54:13.558722
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    test_date_format = DateFormat()
    obj = datetime.date(2020, 1, 1)
    assert test_date_format.serialize(obj) == '2020-01-01'


# Generated at 2022-06-24 10:54:21.811368
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtf = DateTimeFormat()

    assert dtf.is_native_type(datetime.datetime(2020, 1, 1, 1, 1, 1))
    assert not dtf.is_native_type({})
    assert not dtf.is_native_type(())
    assert not dtf.is_native_type([])
    assert not dtf.is_native_type("20200101T010101")
    assert not dtf.is_native_type(20200101010101)
    assert not dtf.is_native_type(20200101010101.10)


# Generated at 2022-06-24 10:54:26.541228
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
  someFormat = BaseFormat()
  assert someFormat.validate("aString") == "aString" # Pass
  try:
    assert someFormat.validate(int(10)) == 10 # Fail
  except NotImplementedError:
    pass # Expected


# Generated at 2022-06-24 10:54:27.877410
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    # create instance of class
    obj_BaseFormat = BaseFormat()
    # assert that validates that a value is of the native type
    assert obj_BaseFormat.is_native_type(None) == False


# Generated at 2022-06-24 10:54:29.851521
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    try:
        BaseFormat.serialize(10)
        assert False
    except NotImplementedError:
        assert True



# Generated at 2022-06-24 10:54:31.701067
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    timefmt = TimeFormat()

# Generated at 2022-06-24 10:54:34.260526
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()
    assert b.errors == {}
    assert b.validation_error("error").text == "{}"
    assert b.validation_error("error").code == "error"


# Generated at 2022-06-24 10:54:36.786190
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    bf = BaseFormat()
    assert bf.errors == {}
    assert bf.validation_error('format') is not None
    assert bf.validation_error('format').code == 'format'


# Generated at 2022-06-24 10:54:40.634625
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()
    value = "2020-01-01T20:00:00+08:00"

    assert isinstance(format.validate(value), datetime.datetime)

# Generated at 2022-06-24 10:54:42.679071
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    fmt = DateFormat()
    assert fmt.serialize(datetime.date(2020, 6, 1)) == '2020-06-01'


# Generated at 2022-06-24 10:54:53.163537
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    x = DateTimeFormat()
    # test if is_native_type() works correctly
    assert x.is_native_type(datetime.datetime.now()) == True
    assert x.is_native_type(datetime.datetime.now().date()) == False
    assert x.is_native_type(datetime.datetime.now().time()) == False
    # test if validate() works correctly
    assert x.validate('2019-10-10T00:00:00Z') == datetime.datetime(2019, 10, 10, 0, 0, 0, tzinfo = datetime.timezone.utc)

# Generated at 2022-06-24 10:54:56.545824
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuidFormat = UUIDFormat()
    assert isinstance(uuidFormat.validate('6e38d6cd-cd31-49c6-b9b9-1a7c56aebfce'), uuid.UUID)



# Generated at 2022-06-24 10:54:57.942033
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    test_obj = datetime.datetime.now().time()

    assert TimeFormat().serialize(test_obj) == test_obj.isoformat()

# Generated at 2022-06-24 10:55:01.039771
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert DateFormat().validate("2019-12-31") == datetime.date(2019, 12, 31)



# Generated at 2022-06-24 10:55:05.281935
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class TestBaseFormat(BaseFormat):
        def serialize(self, obj: typing.Any) -> typing.Union[str, None]:
            if obj is None:
                return None
            else:
                return str(obj)

    assert TestBaseFormat().serialize(1) == "1"
    assert TestBaseFormat().serialize(None) is None


# Generated at 2022-06-24 10:55:11.100432
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    test_uuid = uuid.UUID(int=1)
    assert '00000000-0000-0001-0000-000000000000' == UUIDFormat().serialize(test_uuid)
    test_uuid = uuid.UUID(int=2)
    assert '00000000-0000-0002-0000-000000000000' == UUIDFormat().serialize(test_uuid)
    test_uuid = uuid.UUID(int=3)
    assert '00000000-0000-0003-0000-000000000000' == UUIDFormat().serialize(test_uuid)

# Generated at 2022-06-24 10:55:12.541028
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    try:
        BaseFormat.validate(123)
    except NotImplementedError:
        assert True

# Generated at 2022-06-24 10:55:14.796236
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0)) == '2019-01-01T00:00:00'



# Generated at 2022-06-24 10:55:16.556916
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime(2009, 3, 30, 13, 2, 13))


# Generated at 2022-06-24 10:55:23.643247
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    class UUIDFormatTest(UUIDFormat):
        def __init__(self, value: str):
            super(UUIDFormatTest, self).__init__()
            self.value = value
    uft = UUIDFormatTest('b99c5f28-0a6a-11ea-b58a-68a86d1fba1f')
    assert uft.is_native_type(uft.value)


# Generated at 2022-06-24 10:55:33.019990
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    date_format = DateFormat(value=None)
    assert date_format.serialize(datetime.date(2000, 12, 31)) == "2000-12-31"
    assert date_format.serialize(None) == None

    datetime_format = DateTimeFormat()
    assert datetime_format.serialize(datetime.datetime(2000, 12, 31, 13, 30)) == "2000-12-31T13:30:00"
    assert datetime_format.serialize(datetime.datetime(2000, 12, 31, 13, 30, tzinfo=datetime.timezone.utc)) == "2000-12-31T13:30:00Z"
    assert datetime_format.serialize(None) == None

    time_format = TimeFormat()

# Generated at 2022-06-24 10:55:42.282945
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    val_dateformat = DateTimeFormat()
    # valid datetimes
    val_dateformat.validate('2020-08-08T14:13:32Z')
    val_dateformat.validate('2020-08-08T14:13:32+00:00')
    val_dateformat.validate('2020-08-08T14:13:32+04:00')
    val_dateformat.validate('2020-08-08T14:13:32.123456Z')
    val_dateformat.validate('2020-08-08T14:13:32.123456+04:00')
    # invaild datetimes
    val_dateformat.validate('2020-08-08T14:13Z')

# Generated at 2022-06-24 10:55:53.244872
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    value_1 = "12345678-1234-5678-1234-567812345678"
    uuid_format_1 = UUIDFormat()
    assert str(uuid_format_1.validate(value_1)) == value_1

    value_2 = "12345678-1234-5678-1234-56781234567"
    uuid_format_2 = UUIDFormat()
    try:
        uuid_format_2.validate(value_2)
    except ValidationError as ex:
        assert ex.code == 'format'
    else:
        assert False, 'Expected ValidationError not thrown'


# Generated at 2022-06-24 10:55:56.961659
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    value = "2020-01-01"
    assert date_format.validate(value) == datetime.date(2020, 1, 1)


# Generated at 2022-06-24 10:55:59.935843
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    instance = TimeFormat()
    assert instance.is_native_type(datetime.time()) == True
    assert instance.is_native_type("abc") == False


# Generated at 2022-06-24 10:56:03.409485
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(hour=1, minute=2, second=3, microsecond=123456)
    assert TimeFormat().serialize(time) == '01:02:03.123456'



# Generated at 2022-06-24 10:56:06.611903
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert isinstance(tf, TimeFormat)
    assert tf.errors.get('format') == "Must be a valid time format."
    assert tf.errors.get('invalid') == "Must be a real time."



# Generated at 2022-06-24 10:56:13.171728
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    u = UUIDFormat()
    assert(re.match(UUID_REGEX, "c9bf9e57-1685-4c89-bafb-ff5af830be8a"))
    assert(type(u.validate("c9bf9e57-1685-4c89-bafb-ff5af830be8a")) == uuid.UUID) # Check if the function validate() works

# Generated at 2022-06-24 10:56:18.866243
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuidFormat = UUIDFormat()
    assert str(uuidFormat.validate('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert str(uuidFormat.validate('12345678123456781234567812345678')) == '12345678-1234-5678-1234-567812345678'
    assert str(uuidFormat.validate('urn:uuid:12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'


# Generated at 2022-06-24 10:56:24.399987
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    value = '2020-05-08'
    print(dateFormat.validate(value))
    # value = '2020-05-29'
    # print(dateFormat.validate(value))


test_DateFormat_validate()


# Generated at 2022-06-24 10:56:27.294208
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(None) is True
    assert BaseFormat().is_native_type(1) is True
    assert BaseFormat().is_native_type("1") is True


# Generated at 2022-06-24 10:56:33.125276
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2020, 1, 1)) == True
    assert DateFormat().is_native_type("2000-12-02") == False
    assert DateFormat().is_native_type(datetime.datetime(2020, 1, 1)) == False


# Generated at 2022-06-24 10:56:41.420214
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    errors: typing.Dict[str, str] = {}
    errors.update({
        "format": "Must be valid UUID format."
    })
    assert errors == UUIDFormat.errors
    value: typing.Any = "52f6dfef-0a9b-4f83-aa15-2a2b723bebb0"
    u = "52f6dfef-0a9b-4f83-aa15-2a2b723bebb0"
    uuid_regex = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}")
    match = uuid

# Generated at 2022-06-24 10:56:44.561018
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    # BaseFormat does not have a serialize method.
    # Its children will have one.
    with pytest.raises(NotImplementedError):
        base_format = BaseFormat()
        base_format.serialize(None)


# Generated at 2022-06-24 10:56:54.489818
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    test = DateTimeFormat()
    assert test.serialize(datetime.datetime(2020, 1, 1, 1, 1, 1)) == "2020-01-01T01:01:01"
    assert test.serialize(datetime.datetime(2020, 1, 1, 1, 1, 1, 1)) == "2020-01-01T01:01:01.000001"
    assert test.serialize(datetime.datetime(2020, 1, 1, 1, 1, 1, 1, tzinfo=datetime.timezone.utc)) == "2020-01-01T01:01:01.000001Z"

# Generated at 2022-06-24 10:57:00.505100
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(1,2,3)) == "01:02:03"
    assert TimeFormat().serialize(datetime.time(1,2,3,4)) == "01:02:03.000004"
    assert TimeFormat().serialize(datetime.time(1,2)) == "01:02:00"
    assert TimeFormat().serialize(datetime.time(1,2,3,4, tzinfo=datetime.timezone.utc)) == "01:02:03.000004"



# Generated at 2022-06-24 10:57:06.208263
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestingFormat(BaseFormat):
        errors = {"format": "Text {value}"}

    # Unit test for getting value of variable
    instance = TestingFormat()
    assert instance.validation_error("format").text == "Text {value}"
    instance.__dict__['value'] = 'test'
    assert instance.validation_error("format").text == "Text test"


# Generated at 2022-06-24 10:57:07.854553
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())



# Generated at 2022-06-24 10:57:13.108047
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date = DateFormat()
    assert date.errors['format'] == 'Must be a valid date format.'
    assert date.errors['invalid'] == 'Must be a real date.'



# Generated at 2022-06-24 10:57:14.182868
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    format = UUIDFormat()

# Generated at 2022-06-24 10:57:15.625191
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidfmt = UUIDFormat()


# Generated at 2022-06-24 10:57:17.354770
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    obj_name=BaseFormat()
    assert obj_name.errors == {}


# Generated at 2022-06-24 10:57:19.677925
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
	#obj = uuid.UUID
	assert UUIDFormat().serialize(str(uuid.uuid1())) == str(uuid.uuid1())

# Generated at 2022-06-24 10:57:25.639013
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    # test case 1: True
    val1 = TimeFormat()
    assert val1.is_native_type(datetime.time(14, 23, 18, 269787))

    # test case 2: False
    assert not val1.is_native_type(123)
    assert not val1.is_native_type(123.456)
    assert not val1.is_native_type('abc')
    assert not val1.is_native_type(True)
    assert not val1.is_native_type(None)


# Generated at 2022-06-24 10:57:35.012820
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dt = datetime.datetime(2019, 9, 27, 15, 0, 0, 0)
    dtf = DateTimeFormat()

    assert dtf.is_native_type(dt)

    assert dtf.validate("2019-09-27T15:00:00") == dt
    assert dtf.validate("2019-09-27T15:00") == datetime.datetime(2019, 9, 27, 15, 0, 0, 0)
    assert dtf.validate("2019-09-27T15") == datetime.datetime(2019, 9, 27, 15, 0, 0, 0)
    assert dtf.validate("2019-09-27") == datetime.datetime(2019, 9, 27, 0, 0, 0, 0)


# Generated at 2022-06-24 10:57:36.356527
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    assert bf.errors == {}


# Generated at 2022-06-24 10:57:39.064917
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    hour = int(input('hour : '))
    minute = int(input('minute : '))
    second = int(input('second : '))
    datetime = DateTimeFormat()
    print(datetime.validate(hour + ":" + minute + ":" + second))

# Generated at 2022-06-24 10:57:41.296907
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date = DateFormat()
    assert isinstance(date, DateFormat)


# Generated at 2022-06-24 10:57:52.051056
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # test 1
    d1 = DateFormat()
    assert d1.validate("2016-05-25") == datetime.date(2016, 5, 25)
    # test 2
    try:
        assert d1.validate("2016-05-45")
    except ValidationError:
        assert True
    # test 3
    try:
        assert d1.validate("45-05-25")
    except ValidationError:
        assert True
    # test 4
    try:
        assert d1.validate("2016-15-25")
    except ValidationError:
        assert True
    # test 5
    try:
        assert d1.validate("2016-05-25-15-25")
    except ValidationError:
        assert True


# Generated at 2022-06-24 10:57:52.496808
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    UUIDFormat()

# Generated at 2022-06-24 10:57:54.063264
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    baseFormat = BaseFormat()
    try:
        baseFormat.is_native_type("a")
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 10:57:55.807833
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert not DateTimeFormat().is_native_type(0)
    assert DateTimeFormat().is_native_type(datetime.datetime.now())


# Generated at 2022-06-24 10:58:07.403340
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    # Case 1: Wrong timestamp format
    try:
        DateTimeFormat(name='test').validate("wrong_timestamp_format")
    except ValidationError:
        assert True
    else:
        assert False
    
    # Case 2: Wrong option name
    try:
        DateTimeFormat(name='test', wrong='wrong').validate("2008-01-01T10:10:10")
    except TypeError:
        assert True
    else:
        assert False
    
    # Case 3: Right timestamp format
    datetime.datetime(2008, 1, 1, 10, 10, 10).isoformat() == DateTimeFormat(name='test').validate("2008-01-01T10:10:10")


# Generated at 2022-06-24 10:58:13.114865
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert str(UUIDFormat().validate("a6f5d6a5-6a5a-56a5-65aa-5a65a65a5a6f")) == "a6f5d6a5-6a5a-56a5-65aa-5a65a65a5a6f"
    try:
        UUIDFormat().validate("ansfhsk-skfhks-skjfhks-skfhsk")
        assert 1 == 0
    except ValidationError:
        pass

# Generated at 2022-06-24 10:58:22.714587
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    from typesystem import Generic
    from typesystem.errors import ValidationError
    from typesystem.formats import DateTimeFormat
    import datetime

    class CustomFormat(DateTimeFormat):
        errors = {"name_too_long": "Name value is too long."}
    native_format = DateTimeFormat()
    custom_format = CustomFormat()

    # Expected errors
    try:
        native_format.validate("2018-05-23")
    except ValidationError as err:
        assert err.text == "Must be a valid datetime format."
        assert err.code == "format"
    else:
        assert False, "native_format.validate with invalid value should raise ValidationError"

    try:
        custom_format.validate("2018-05-23")
    except ValidationError as err:
        assert err

# Generated at 2022-06-24 10:58:25.083490
# Unit test for constructor of class DateFormat
def test_DateFormat():
    d_format = DateFormat()
    return


# Generated at 2022-06-24 10:58:26.954413
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    assert BaseFormat().validation_error('format') == ValidationError(text='Must be valid date format.', code='format')

# Generated at 2022-06-24 10:58:29.312764
# Unit test for constructor of class DateFormat
def test_DateFormat():
    try:
        i = 5
        assert i == 1
    except AssertionError:
        print('AssertionError: i != 1')


# Generated at 2022-06-24 10:58:32.063775
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None



# Generated at 2022-06-24 10:58:38.881378
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    print("Unit test for constructor of class UUIDFormat")
    uuid1 = uuid.uuid4()
    print("The first random UUID: ", uuid1)
    uuid2 = uuid.uuid4()
    print("The second random UUID: ", uuid2)
    uuid3 = uuid.uuid4()
    print("The third random UUID: ", uuid3)
    uuid4 = uuid.uuid4()
    print("The fourth random UUID: ", uuid4)


# Generated at 2022-06-24 10:58:40.971839
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    expected = True
    assert DateFormat().is_native_type(datetime.date(2019, 5, 17)) == expected


# Generated at 2022-06-24 10:58:50.801449
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    # First check the is_native_type method of class DateFormat
    dat_format = DateFormat()
    obj_date = datetime.date(2012, 12, 12)
    if dat_format.is_native_type(obj_date) == True:
        print('pass')
    else:
        print('fail')
    # Then check the is_native_type method of class TimeFormat
    tim_format = TimeFormat()
    obj_time = datetime.time(12, 12, 12)
    if tim_format.is_native_type(obj_time) == True:
        print('pass')
    else:
        print('fail')
    # Finally check the is_native_type method of class DateTimeFormat
    dat_tim_format = DateTimeFormat()

# Generated at 2022-06-24 10:58:53.559153
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    value = datetime.date.today()
    res = DateFormat().serialize(value)
    assert res == value.isoformat()

# Generated at 2022-06-24 10:58:56.041712
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    f = BaseFormat()
    assert not f.is_native_type("a")


# Generated at 2022-06-24 10:58:57.693833
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert(str(UUIDFormat()) == "<UUIDFormat>")


# Generated at 2022-06-24 10:59:06.444961
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format=DateTimeFormat()
    assert format.validate("1998-04-02T13:00:00+13:00").isoformat()=="1998-04-02T13:00:00+13:00"
    # assert format.validate("1998-04-02T13:00:00+13")
    assert format.validate("1998-04-02T13:00:00Z").isoformat()=="1998-04-02T13:00:00+00:00"
    #assert format.validate("1998-04-02T13:00:00")
    assert format.validate("1998-04-02T13:00Z").isoformat()=="1998-04-02T13:00:00+00:00"

# Generated at 2022-06-24 10:59:10.327749
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestFormat(BaseFormat):
        errors = {
            "format": "Must be a valid time format."
        }
        def validation_error(self, code: str) -> ValidationError:
            text = self.errors[code].format(**self.__dict__)# Teste
            return ValidationError(text=text, code=code)
    t= TestFormat()
    assert t.validation_error('format')==ValidationError(text='Must be a valid time format.', code='format')


# Generated at 2022-06-24 10:59:14.369870
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():

    fmt = DateTimeFormat()
    value = '2019-07-23T13:05:25Z'

    print("value: ", value)
    result_datetime = fmt.validate(value)
    print("result_datetime: ", result_datetime)