

# Generated at 2022-06-24 10:49:14.424395
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = uuid.uuid4()
    str(obj)
    obj = str(obj)
    UUIDFormat().serialize(obj)
    return True

# Generated at 2022-06-24 10:49:18.862993
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base_format = BaseFormat()
    base_format.errors = {'format': 'Must be a valid date format.'}
    try:
        raise base_format.validation_error('format')
    except ValidationError as validation_error:
        assert 'Must be a valid date format.' == validation_error.text


# Generated at 2022-06-24 10:49:20.309097
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert str(uuid.uuid4()) == UUIDFormat().serialize(uuid.uuid4())

# Generated at 2022-06-24 10:49:23.206745
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time(9, 16, 2, 5)
    assert TimeFormat().serialize(obj) == '09:16:02'

# Generated at 2022-06-24 10:49:28.859263
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    assert dateFormat.validate("1995-06-06") == datetime.date(1995, 6, 6)
    assert dateFormat.validate("1995-06-06") != datetime.date(1995, 5, 6)



# Generated at 2022-06-24 10:49:33.488474
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    fmt = UUIDFormat()
    assert fmt.validate("a7f1e33c-a06a-11ea-bb37-0242ac130002") == "a7f1e33c-a06a-11ea-bb37-0242ac130002"
    assert fmt.validate("a7f1e33ca06a11eabb370242ac130002") == "a7f1e33ca06a11eabb370242ac130002"


# Generated at 2022-06-24 10:49:38.694835
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(1) == False


# Generated at 2022-06-24 10:49:43.615543
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(1,1,1))

# Generated at 2022-06-24 10:49:46.980899
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date = datetime.date(year=2020, month=7, day=15)
    date_format = DateFormat()
    assert date_format.is_native_type(date) == True


# Generated at 2022-06-24 10:49:48.808222
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    BaseFormat.serialize(None, None)
    assert True



# Generated at 2022-06-24 10:49:51.469541
# Unit test for constructor of class DateFormat
def test_DateFormat():
    test_case = DateFormat()
    assert isinstance(test_case, DateFormat)

# Unit tests for is_native_type function of class DateFormat

# Generated at 2022-06-24 10:49:53.677572
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    assert tf.is_native_type(datetime.time(hour=15, minute=20, second=30))



# Generated at 2022-06-24 10:49:59.285907
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test = DateTimeFormat()
    assert test.validate('2020-01-01T00:00:00.001Z') == datetime.datetime(2020,1,1,0,0,0,1000,tzinfo=datetime.timezone.utc)
    assert test.validate('2020-01-01T00:00:00Z') == datetime.datetime(2020,1,1,0,0,0,tzinfo=datetime.timezone.utc)
    assert test.validate('2020-01-01T00:00:00+08:00') == datetime.datetime(2020,1,1,8,0,0,tzinfo=datetime.timezone(datetime.timedelta(hours=8)))

# Generated at 2022-06-24 10:50:09.960872
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
   assert TIME_REGEX.match('16:01:00')
   assert TIME_REGEX.match('16:01:10')
   assert TIME_REGEX.match('16:01:10.123456')
   assert TIME_REGEX.match('16:01:10.1234')
   assert TIME_REGEX.match('16:01:10.123')
   assert TIME_REGEX.match('16:01:10.12')
   assert TIME_REGEX.match('16:01:10.1')
   assert TIME_REGEX.match('16:01:10.1234')
   assert TIME_REGEX.match('16:01')
   assert not TIME_REGEX.match('16:01:1')
   assert not TIME_REGEX.match('16:01:00.123457')


# Generated at 2022-06-24 10:50:15.009252
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem.base import ValidationError

    assert DateTimeFormat().validate('2020-06-10T00:00:00Z') == datetime.datetime(2020,6,10,0,0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-24 10:50:18.587794
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = datetime.datetime.now().strftime("%H:%M:%S")
    result = TimeFormat().validate(time)
    assert time == result.isoformat()

# Generated at 2022-06-24 10:50:20.773517
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    b = BaseFormat()
    with pytest.raises(NotImplementedError):
        b.validate("Hi!!!")


# Generated at 2022-06-24 10:50:24.005881
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    time_obj = datetime.time(hour=15, minute=12, second=46)
    assert time_format.serialize(time_obj) == '15:12:46'

# Generated at 2022-06-24 10:50:25.557762
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2019,5,5)) == True



# Generated at 2022-06-24 10:50:26.138308
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    pass

# Generated at 2022-06-24 10:50:30.474062
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    test_obj = datetime.date.today()
    test_obj_str = test_obj.strftime("%Y-%m-%d")
    test_DateFormat = DateFormat()
    assert test_DateFormat.serialize(test_obj) == test_obj_str


# Generated at 2022-06-24 10:50:32.240004
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    UUIDFormat()


# Generated at 2022-06-24 10:50:35.312885
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    valid_UUID_string = "73e96f87-95ef-4b8c-bef0-e3325b082f15"
    value = UUIDFormat().validate(value = valid_UUID_string)
    assert isinstance(value, uuid.UUID)


# Generated at 2022-06-24 10:50:37.579310
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True, "Function is_native_type does not work properly"


# Generated at 2022-06-24 10:50:40.002754
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    obj = DateFormat()
    assert obj.validate("2018-12-25") == datetime.date(2018, 12, 25)

# Generated at 2022-06-24 10:50:42.893670
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    # Arrange
    sut = UUIDFormat()
    obj = uuid.uuid4()
    # Act
    act = sut.serialize(obj)
    # Assert
    assert act == str(obj)


# Generated at 2022-06-24 10:50:45.522820
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    # Create an object of class DateTimeFormat
    date_time_format = DateTimeFormat()
    # Call the function validate of the class DateTimeFormat
    date_time_format.validate('2020-04-30T12:00:00-04:00')

# Generated at 2022-06-24 10:50:51.025394
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    datetime_string = '2020-02-18T13:24:10.720109Z'
    datetime_format = DateTimeFormat()
    datetime_test = datetime_format.validate(datetime_string)
    assert type(datetime_test) == datetime.datetime


# Generated at 2022-06-24 10:50:54.212890
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    date_obj = datetime.date(2019, 10, 3)
    assert date_format.serialize(date_obj) == '2019-10-03'


# Generated at 2022-06-24 10:50:55.865897
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat.errors == {}
    assert BaseFormat().errors == {}

# Generated at 2022-06-24 10:50:58.610845
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    target = DateFormat().validate('2020-05-10')
    actual = DateFormat().serialize(target)
    expected = '2020-05-10'
    assert actual == expected

# Generated at 2022-06-24 10:50:59.885576
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date.today()
    date_format = DateFormat()
    assert date_format.serialize(date) == date.isoformat()


# Generated at 2022-06-24 10:51:06.928707
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    # when obj is a string
    assert UUIDFormat().serialize('ddddd') == 'ddddd'
    # when obj is a UUID object
    assert UUIDFormat().serialize(uuid.UUID('12345678-1234-5678-1234-567812345678')) == '12345678-1234-5678-1234-567812345678'

# Generated at 2022-06-24 10:51:16.692563
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()

    time = tf.validate("12:34:56")
    assert isinstance(time, datetime.time)
    assert time.hour == 12
    assert time.minute == 34
    assert time.second == 56

    with pytest.raises(ValidationError) as e:
        tf.validate("12:34:56.7890")
    assert e.value.code == "format"

    with pytest.raises(ValidationError) as e:
        tf.validate("12:34:56.789")
    assert e.value.code == "invalid"

    with pytest.raises(ValidationError) as e:
        tf.validate("12:34:56.789012")
    assert e.value.code == "invalid"


# Generated at 2022-06-24 10:51:19.637700
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    test = UUIDFormat()
    test = UUIDFormat(errors = {"format": "Must be valid UUID format."})
    assert test.errors == {"format": "Must be valid UUID format."}


# Generated at 2022-06-24 10:51:22.885659
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid = '482fa256-8c98-46ae-b564-f39095e9eb12'
    UUID = uuid.UUID(uuid)
    uuid_format = UUIDFormat()
    validation = uuid_format.validate(uuid)
    assert UUID == validation
    
    

# Generated at 2022-06-24 10:51:26.418729
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid1 = uuid.uuid4()
    uuidFormat = UUIDFormat()
    assert uuidFormat.is_native_type(uuid1) == True



# Generated at 2022-06-24 10:51:29.372054
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(2018, 3, 2)
    date_format = DateFormat()
    assert date_format.serialize(obj) == "2018-03-02"


# Generated at 2022-06-24 10:51:32.973581
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    x = '2d8ebebf-d9bd-4273-b7f2-1c6b7e2895b2'
    y = UUIDFormat()
    y.validate(x)


# Generated at 2022-06-24 10:51:37.054749
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base = BaseFormat()
    base.errors = {"invalid": "Error message."}

    try:
        raise base.validation_error("invalid")
    except ValidationError as e:
        assert str(e) == "Error message."
        assert e.code == "invalid"

# Generated at 2022-06-24 10:51:40.556894
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    """ assert method serialize of class TimeFormat return obj in string format """
    time = datetime.time(12, 9, 13, 0)
    assert TimeFormat().serialize(time) == "12:09:13"

# TESTS FOR CLASS DateFormat

# Generated at 2022-06-24 10:51:44.267388
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid = uuid.uuid4()
    str_uuid = str(uuid)
    formatter = UUIDFormat()
    assert formatter.serialize(uuid) == str_uuid


# Generated at 2022-06-24 10:51:48.450037
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    
    assert df.serialize( datetime.date(year=2020, month=4, day=25) ) == "2020-04-25"

# Generated at 2022-06-24 10:51:53.752282
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type('0f49b146-0c11-42e2-86b8-57b1b93c9a9f') == True
    assert UUIDFormat().is_native_type(None) == False
    assert UUIDFormat().is_native_type(1) == False
    assert UUIDFormat().is_native_type(1.5) == False



# Generated at 2022-06-24 10:51:56.046810
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time


# Generated at 2022-06-24 10:52:00.072432
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    """
    The method is_native_type of BaseFormat returns True if the type of the
    parameter is datetime.time.
    """
    time_format = TimeFormat()

    time = datetime.time()

    output = time_format.is_native_type(time)

    assert output == True


# Generated at 2022-06-24 10:52:03.865666
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    # test a valid input
    assert dateFormat.validate("2020-01-01") == datetime.date(2020, 1, 1)
    # test a non-valid input
    try:
        dateFormat.validate("2020")
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-24 10:52:07.425063
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    value = '22909f23-c671-4d6c-8fca-e45ded61e4e4'
    expected = uuid.UUID(value)
    instance = UUIDFormat()
    actual = instance.validate(value)
    assert expected == actual


# Generated at 2022-06-24 10:52:15.549203
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    UUID_REGEX = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}")
    uuid_format = UUIDFormat()
    match = UUID_REGEX.match('f5369c1c-cd63-44af-aaef-710e8bd1ab32')
    if not match:
        raise uuid_format.validation_error("format")
    else:
        match.group(0)
        if not match.group(0):
            raise uuid_format.validation_error("format")

# Generated at 2022-06-24 10:52:21.682555
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    format_ = TimeFormat()
    assert(format_.is_native_type(datetime.time(12, 0, 30)))
    assert(not format_.is_native_type(datetime.date(2020, 1, 1)))
    assert(not format_.is_native_type(datetime.datetime(2020, 1, 1, 12, 0, 30)))
    assert(not format_.is_native_type(uuid.uuid4()))


# Generated at 2022-06-24 10:52:29.428814
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = datetime.time(12, 34, 56, 7890)
    # Default time, timezone is None.
    value_1 = TimeFormat().validate("12:34:56.078900")
    assert value_1 == time
    # Time with timezone
    value_2 = TimeFormat().validate("12:34:56.000001Z")
    assert value_2.isoformat() == time.isoformat() + "+00:00"
    value_3 = TimeFormat().validate("12:34:56.078900+12:45")
    assert value_3.isoformat() == time.isoformat() + "+12:45"
    value_4 = TimeFormat().validate("12:34:56.078900-01:00")
    assert value_4.isoformat() == time.isoformat()

# Generated at 2022-06-24 10:52:31.822667
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_value = uuid.uuid4()
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(uuid_value)

# Generated at 2022-06-24 10:52:36.829639
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    t = datetime.time(23, 30, 30, 123456, tzinfo=datetime.timezone.utc)
    t2 = tf.serialize(t)
    assert t2 == "23:30:30.123456+00:00"


# Generated at 2022-06-24 10:52:38.754821
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    format = DateFormat()
    assert format.serialize(None) == None
    assert format.serialize(datetime.date(2046, 8, 11)) == "2046-08-11"


# Generated at 2022-06-24 10:52:45.747431
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj =  datetime.datetime(year=2017, month=8, day=10, hour=12, minute=20)
    assert DateTimeFormat().serialize(obj) == "2017-08-10T12:20:00"

# Generated at 2022-06-24 10:52:56.683512
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate("00:00:00")
    assert tf.validate("00:00")
    assert tf.validate("00:00:00.12345")
    assert tf.validate("00:00:00.123456")
    assert tf.validate("00:00:00.1234560")
    assert tf.validate("00:00:00.12345600")
    assert tf.validate("00:00:00.123456000")
    assert tf.validate("00:00:00.1234560000")
    assert tf.validate("00:00:00.12345600000")
    assert tf.validate("00:00:00.123456000000")
    assert tf.validate("23:59:59.999999")
    assert tf.validate

# Generated at 2022-06-24 10:53:01.224902
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class BaseFormat_test(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return True

    bf = BaseFormat_test()
    with pytest.raises(NotImplementedError):
        bf.validate("test")


# Generated at 2022-06-24 10:53:06.179336
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf=TimeFormat()
    t = datetime.time(tzinfo=None,microsecond=45) # tzinfo - exception
    assert tf.is_native_type(t)

#Unit test for method serialize of class TimeFormat

# Generated at 2022-06-24 10:53:14.547381
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    case1_value = '2019-08-12T19:03:17+00:00'
    case2_value = '2019-8-12T19:03:17+00:00'
    case3_value = '0001-01-01T00:00:00'
    case4_value = '2019-09-03T17:03:17.123456789+02:00'
    case5_value = '2019-09-03T17:03:17.1234+02:00'
    case6_value = '2019-09-03T17:03:17.12+02:00'
    case7_value = '2019-09-03T17:03:17.1+02:00'

# Generated at 2022-06-24 10:53:19.245898
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    instance = BaseFormat()
    errors = {"format": "Must be a valid date format."}
    instance.errors = errors
    code = "format"
    actual = instance.validation_error(code)
    expected = ValidationError(text="Must be a valid date format.", code="format")
    assert actual == expected


# Generated at 2022-06-24 10:53:20.909271
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    bf = BaseFormat()
    assert not bf.is_native_type(True)


# Generated at 2022-06-24 10:53:23.328649
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    dt = datetime.date(2020, 6, 22)
    assert df.is_native_type(dt) == True


# Generated at 2022-06-24 10:53:25.821019
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid1 = uuid.uuid1()
    assert str(uuid1) == UUIDFormat().serialize(uuid1) 



# Generated at 2022-06-24 10:53:27.087127
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    res = tf.is_native_type(datetime.time(4,30))
    assert res == True


# Generated at 2022-06-24 10:53:29.307627
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtf = DateTimeFormat()
    assert dtf.is_native_type(datetime.datetime.now()) == True
    assert dtf.is_native_type(datetime.time.now()) == False


# Generated at 2022-06-24 10:53:35.232240
# Unit test for method serialize of class DateTimeFormat

# Generated at 2022-06-24 10:53:36.826380
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base = BaseFormat()
    assert base.is_native_type(None)  == False

# Generated at 2022-06-24 10:53:40.193957
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-24 10:53:45.203984
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    t = datetime.time(14, 30, 30)
    assert TimeFormat().serialize(t) == '14:30:30'

# Generated at 2022-06-24 10:53:48.042538
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u1 = uuid.uuid4()
    u2 = uuid.uuid4()
    assert(UUIDFormat().serialize(u1) == str(u1) and UUIDFormat().serialize(u2) == str(u2))


# Generated at 2022-06-24 10:53:53.453898
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    date_format = DateTimeFormat()
    assert date_format.is_native_type(datetime.datetime.now()) == True
    assert date_format.is_native_type('2020-07-04 14:50:00') == False


# Generated at 2022-06-24 10:54:06.951521
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
	import datetime
	date_format = DateFormat()
	assert date_format.validate('2020-01-30') == datetime.date(2020, 1, 30)
	assert date_format.validate('2020-12-30') == datetime.date(2020, 12, 30)
	assert date_format.validate('2002-12-30') == datetime.date(2002, 12, 30)
	#
	try:
		date_format.validate('01-27-2002')
	except:
		pass
	else:
		assert False
	#
	try:
		date_format.validate('2020-1-29')
	except:
		pass
	else:
		assert False
	#

# Generated at 2022-06-24 10:54:13.198138
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert not uuid_format.is_native_type("e07aee50-d351-11ea-b3de-0242ac130002")
    assert uuid_format.is_native_type(uuid.UUID("e07aee50-d351-11ea-b3de-0242ac130002"))


# Generated at 2022-06-24 10:54:16.112778
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    value = uuid.uuid4()
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(value)



# Generated at 2022-06-24 10:54:21.339848
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uf = UUIDFormat()
    try:
        uf.validate("")
    except ValidationError as err:
        assert err.code == "format"
    try:
        uf.validate("12345678901234567890123456789012")
    except ValidationError as err:
        assert err.code == "format"



# Generated at 2022-06-24 10:54:25.405765
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(9)) == True
    assert time_format.is_native_type(0) == False


# Generated at 2022-06-24 10:54:27.891037
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    obj = BaseFormat()
    #print(obj.validation_error())
    #print(obj.validation_error.__annotations__)


# Generated at 2022-06-24 10:54:29.926944
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    try:
        BaseFormat.validate(None, 'str')
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 10:54:36.058183
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    from typesystem.fields import Date
    from typesystem.format import DateFormat
    assert DateFormat().is_native_type(datetime.date.today()) == True
    assert DateFormat().validate('2019-12-12') == datetime.date(2019, 12, 12)
    try:
        assert DateFormat().validate('2019-12-40')
    except ValidationError as e:
        assert e.code == 'invalid'
        assert e.text == 'Must be a real date.'


# Generated at 2022-06-24 10:54:41.538501
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = uuid.UUID('ba61c5f5-0062-4ac7-a83b-f85b09a9b52f')
    assert 'ba61c5f5-0062-4ac7-a83b-f85b09a9b52f' == UUIDFormat().serialize(obj)


# Generated at 2022-06-24 10:54:47.026009
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtf = DateTimeFormat()
    # Case 1: value is None
    assert dtf.is_native_type(None) == True
    # Case 2: value is not None
    assert dtf.is_native_type(datetime.datetime.now()) == True


# Generated at 2022-06-24 10:54:49.725251
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    
    # Method of class BaseFormat can not be tested, it is abstract.
    
    assert True == True
    
    

# Generated at 2022-06-24 10:54:51.421031
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()
    print("test_BaseFormat......")
    return b


# Generated at 2022-06-24 10:55:01.163562
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()
    validate = timeformat.validate
    def test(value, exp):
        value = validate(value)
        assert value == exp, "assertion failed for value '%s', expected '%s'" % (value, exp)
    test('0100', datetime.time(1))
    test('0100:00', datetime.time(1))
    test('0100:30', datetime.time(1, 30))
    test('0100:30:00', datetime.time(1, 30))
    test('0100:30:45', datetime.time(1, 30, 45))
    test('0100:30:45.7', datetime.time(1, 30, 45, 700000))
    test('0100:30:45.123456', datetime.time(1, 30, 45, 123456))

# Generated at 2022-06-24 10:55:03.949875
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    test_date = datetime.date(year=2015, month=10, day=11)
    assert DateFormat().validate("2015-10-11") == test_date


# Generated at 2022-06-24 10:55:06.226046
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())


# Generated at 2022-06-24 10:55:13.300413
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    with open("test_DateTimeFormat_validate_result.txt", "r") as file1:
        with open("test_DateTimeFormat_validate_result_expected.txt", "r") as file2:
            lines1 = file1.readlines()
            lines2 = file2.readlines()
            if len(lines1) != len(lines2):
                print("Error")
            line_count = 0
            for i in lines1:
                line_count += 1
                try:
                    result = datetime_format.validate(i)
                    print("Line: " + str(line_count) + "     " + "Result: " + str(result))
                except Exception:
                    pass

# Generated at 2022-06-24 10:55:17.338821
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    # Create an instance of class TimeFormat
    time_format = TimeFormat()
    assert isinstance(time_format, TimeFormat)

    # Create a time
    from datetime import time
    time1 = time(2, 20, 10, 10)

    # Test the method
    assert time_format.is_native_type(time1) == True



# Generated at 2022-06-24 10:55:19.756222
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    instance = UUIDFormat()
    assert instance.errors == {"format": "Must be valid UUID format."}


# Generated at 2022-06-24 10:55:25.474574
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class MyFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, bool)

    my_format = MyFormat()
    assert my_format.is_native_type(True) is True
    assert my_format.is_native_type(False) is True
    assert my_format.is_native_type(100) is False
    assert my_format.is_native_type("") is False
    assert my_format.is_native_type([]) is False
    assert my_format.is_native_type(()) is False
    assert my_format.is_native_type({}) is False

# Generated at 2022-06-24 10:55:29.377295
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    # test for a valid time
    tf.validate("13:37") == datetime.time(13,37)
    # test for a invalid time
    tf.validate("13:37:13") == ValidationError("Must be a real time.")

# Generated at 2022-06-24 10:55:38.481870
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    method_under_test = UUIDFormat.validate
    # test valid UUID
    uuid_valid = "cc8a14e6-cf19-49e5-b2fb-822f937d7f17"
    assert isinstance(method_under_test(UUIDFormat(), uuid_valid), uuid.UUID)
    # test invalid UUID
    uuid_invalid = "not_valid"
    with pytest.raises(ValidationError):
        method_under_test(UUIDFormat(), uuid_invalid)

# Generated at 2022-06-24 10:55:42.118008
# Unit test for constructor of class DateFormat
def test_DateFormat():
    with pytest.raises(NotImplementedError):
        d = DateFormat()


# Generated at 2022-06-24 10:55:47.866562
# Unit test for constructor of class DateFormat
def test_DateFormat():
    d = DateFormat()
    assert d.is_native_type(datetime.date(2020, 1, 1))
    assert not d.is_native_type(datetime.datetime(2020, 1, 1, 1, 1, 1))
    assert not d.is_native_type(datetime.time(1, 1, 1))



# Generated at 2022-06-24 10:55:50.271637
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2020, 2, 28)) == True


# Generated at 2022-06-24 10:55:53.020977
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    f = TimeFormat()
    assert f.validate('01:02:03') == datetime.time(1, 2, 3)

# Generated at 2022-06-24 10:55:58.339228
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(None) == False
    assert DateFormat().is_native_type(None) == False
    assert TimeFormat().is_native_type(None) == False
    assert DateTimeFormat().is_native_type(None) == False
    assert UUIDFormat().is_native_type(None) == False


# Generated at 2022-06-24 10:56:02.576583
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    a = TimeFormat()
    assert isinstance(a, BaseFormat)

    assert a.is_native_type(datetime.time.utcnow()) == True
    assert a.is_native_type("1234") == False


# Generated at 2022-06-24 10:56:06.263687
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format_ = DateTimeFormat()
    assert not format_.is_native_type(None)
    assert not format_.is_native_type('2019-12-09T14:29:02+00:00')
    assert format_.is_native_type(datetime.datetime.now())

# Generated at 2022-06-24 10:56:15.815805
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    import datetime
    time_format = TimeFormat()
    value = "12:00:00"
    time = time_format.validate(value)
    assert isinstance(time, datetime.time)
    assert time.hour == 12
    assert time.minute == 0
    assert time.second == 0

    # time
    value = "00:12:59"
    time = time_format.validate(value)
    assert isinstance(time, datetime.time)
    assert time.hour == 0
    assert time.minute == 12
    assert time.second == 59

    # time with milliseconds
    value = "12:00:00.123"
    time = time_format.validate(value)
    assert isinstance(time, datetime.time)
    assert time.hour == 12

# Generated at 2022-06-24 10:56:20.801176
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    format = DateFormat()
    assert format.is_native_type(datetime.date(year=2019, month=2, day=14)) is True
    assert format.is_native_type(datetime.datetime(year=2019, month=2, day=14)) is False


# Generated at 2022-06-24 10:56:23.759027
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert type(TimeFormat()) is TimeFormat


# Generated at 2022-06-24 10:56:26.775489
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    d = datetime.datetime(2015, 1, 1, 12, 0, 0, 0)
    df = DateTimeFormat()
    assert df.is_native_type(d) == True


# Generated at 2022-06-24 10:56:33.506466
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    import pytest
    from typesystem.base import ValidationError
    
    format = BaseFormat()

    # raise NotImplementedError()
    with pytest.raises(NotImplementedError):
        format.validate("test")
    
    # return ValidationError
    assert isinstance(format.validation_error("test"), ValidationError)


# Generated at 2022-06-24 10:56:36.301201
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    if(str(type(uuid_format)) != '<class \'typesystem.formats.UUIDFormat\'>'):
        print("Error in construction of UUIDFormat")


# Generated at 2022-06-24 10:56:39.825762
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    from datetime import date

    param = date(2020,2,2)
    format = DateFormat()
    actual = format.serialize(param)
    expected = '2020-02-02'
    assert actual == expected, "Expected %s, got %s" % (expected, actual)


# Generated at 2022-06-24 10:56:47.908831
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("00:00:00") == datetime.time(0, 0)
    assert time.validate("00:00:10") == datetime.time(0, 0, 10)
    assert time.validate("00:00:10.123456") == datetime.time(0, 0, 10, 123456)
    assert time.validate("00:00:10.123") == datetime.time(0, 0, 10, 123000)
    assert time.validate("00:00:10.12345") == datetime.time(0, 0, 10, 1234500)
    assert time.validate("00:00:10.1234567") == datetime.time(0, 0, 10, 1234567)

    # Check error "invalid"

# Generated at 2022-06-24 10:56:50.017791
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())



# Generated at 2022-06-24 10:56:54.323178
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    # set up objects
    test = BaseFormat()
    valid_string = 'a'
    invalid_string = 'b'

    # test validate function
    assert test.validate(valid_string) is None
    assert test.validate(invalid_string) is None



# Generated at 2022-06-24 10:56:55.784545
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time.is_native_type(datetime.time)



# Generated at 2022-06-24 10:57:03.919498
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():

    def test_method():
        try:
            raise NotImplementedError()
        except NotImplementedError:
            exc = sys.exc_info()
            try:
                raise TestException() from exc
            except TestException:
                assert sys.exc_info()[1].__cause__ is exc[1]
            else:
                assert False, 'Expected TestException to be raised'

    class TestException(Exception):
        pass

    def test_method():
        try:
            raise NotImplementedError()
        except NotImplementedError:
            exc = sys.exc_info()
            try:
                raise TestException() from exc
            except TestException:
                assert sys.exc_info()[1].__cause__ is exc[1]

# Generated at 2022-06-24 10:57:06.527676
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    value = date_time_format.validate("2020-01-01T01:01:01.101000Z")
    print(value)
    assert value.year == 2020
    assert value.month == 1
    assert value.day == 1
    assert value.hour == 1
    assert value.minute == 1
    assert value.second == 1
    assert value.microsecond == 101000


if __name__ == "__main__":
    test_DateTimeFormat_validate()

# Generated at 2022-06-24 10:57:13.979253
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    from typesystem.base import ValidationError
    class Format(BaseFormat):
        def is_native_type(self, value):
            return isinstance(value, int)
        def validate(self, value):
            return value
    format = Format()
    with pytest.raises(ValidationError):
        format.validate(1.1)
    assert format.validate(5) == 5


# Generated at 2022-06-24 10:57:18.793294
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time(2, 3)
    assert TimeFormat().serialize(obj) == "02:03:00"
    obj = datetime.time(2, 3, 4, 555000)
    assert TimeFormat().serialize(obj) == "02:03:04.555000"
    obj = None
    assert TimeFormat().serialize(obj) == None

# Generated at 2022-06-24 10:57:27.424382
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    from typesystem.base import ValidationError
    from typesystem.formats import UUIDFormat
    from uuid import UUID
    from bson import ObjectId
    # Test for valid input
    uuid_sample = 'c6a007b6-b48c-4a6a-9525-d3384a1a2c2b'
    uuid_obj = UUIDFormat().validate(uuid_sample)
    assert isinstance(uuid_obj, UUID)

# Generated at 2022-06-24 10:57:31.152582
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    format = TimeFormat()
    value = "01:59:59"
    # ass_now = format.validate(value)
    # assert ass_now == datetime.time(1, 59, 59)
    # format.validate("25:59:59")



# Generated at 2022-06-24 10:57:33.013531
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat().errors == {"format": "Must be a valid time format.", "invalid": "Must be a real time."}


# Generated at 2022-06-24 10:57:41.200522
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value1 = datetime.datetime.fromtimestamp(1564521151).strftime("%Y-%m-%d %H:%M:%S")
    value2 = datetime.datetime.fromtimestamp(1564521151).strftime("%Y-%m-%d %H:%M:%S.0")
    value3 = datetime.datetime.fromtimestamp(1564521151).strftime("%Y-%m-%d %H:%M:%S.000000")
    value4 = datetime.datetime.fromtimestamp(1564521151).strftime("%Y-%m-%d %H:%M:%S+09:00")

# Generated at 2022-06-24 10:57:44.496181
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2020-03-29")
    assert date.year == 2020
    assert date.month == 3
    assert date.day == 29


# Generated at 2022-06-24 10:57:53.191796
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # test 1
    try:
        test = DateFormat().validate('2015-11-15')
    except:
        raise AssertionError("Expected '2015-11-15' but it raised an exception")
    # test 2
    try:
        test = DateFormat().validate('')
    except:
        pass
    else:
        raise AssertionError("Expected '' to raise an exception")
    # test 3
    try:
        test = DateFormat().validate('[(*)')
    except:
        pass
    else:
        raise AssertionError("Expected '[(*)' to raise an exception")


# Generated at 2022-06-24 10:58:03.721280
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:45:56")
    time_format.validate("12:45:56.756010")
    time_format.validate("12:45:56.75601")
    time_format.validate("12:45:56.756")
    time_format.validate("12:45:56.75")
    time_format.validate("12:45:56.7")
    with pytest.raises(ValidationError):
        time_format.validate("12:45:56.7560")
    with pytest.raises(ValidationError):
        time_format.validate("12:45:56.75600")

# Generated at 2022-06-24 10:58:04.963721
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    a = DateTimeFormat()

# Generated at 2022-06-24 10:58:15.996982
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value1 = "2019-08-06T15:30:42.000000+00:00"
    value2 = "2019-08-06T15:30:42.000000Z"
    value3 = "2019-08-06T15:30:42.000000-04:00"

    datetime_format1 = DateTimeFormat()
    datetime_format2 = DateTimeFormat()
    datetime_format3 = DateTimeFormat()

    assert datetime_format1.validate(value1) == datetime.datetime(2019, 8, 6, 15, 30, 42, tzinfo=datetime.timezone.utc)
    assert datetime_format2.validate(value2) == datetime.datetime(2019, 8, 6, 15, 30, 42, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-24 10:58:23.506165
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    d = DateFormat()
    datetime1 = datetime.date(2019, 10, 14)
    assert d.is_native_type(datetime1)==True
    datetime2 = datetime.time(1, 1, 1)
    assert d.is_native_type(datetime2)==False
    datetime3 = datetime.datetime(2019, 10, 14, 1, 1, 1, 1)
    assert d.is_native_type(datetime3)==False
    datetime4 = uuid.UUID('323b54bd-e7aa-4818-ac3d-963b8e502018')
    assert d.is_native_type(datetime4)==False


# Generated at 2022-06-24 10:58:28.037552
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    DF = DateFormat()
    assert DF.is_native_type(datetime.date(2015, 6, 29)) == True
    assert DF.is_native_type(datetime.datetime(2015, 6, 29, 5, 2, 1)) == False


# Generated at 2022-06-24 10:58:31.366389
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
  assert TimeFormat().validate("12:10:35") == datetime.time(12,10,35)

# Generated at 2022-06-24 10:58:40.484399
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    assert tf.is_native_type(datetime.datetime(2020, 12, 31, 19, 26, 35, 524000))
    assert not tf.is_native_type(datetime.date(2020, 12, 31))
    assert not tf.is_native_type(datetime.time(19, 26, 35, 524000))
    assert not tf.is_native_type(datetime.datetime(2020, 12, 31, 19, 26, 35, 524000, tzinfo=None))
    assert tf.is_native_type(datetime.datetime(2020, 12, 31, 19, 26, 35, 524000, tzinfo=datetime.timezone.utc))


# Generated at 2022-06-24 10:58:50.528799
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # GIVEN
    dt = datetime.datetime(2017, 10, 10, 17, 54, 34, 5432)
    # WHEN
    obj = DateTimeFormat().serialize(dt)
    # THEN
    assert obj == '2017-10-10T17:54:34.005432'

    # GIVEN
    dt = datetime.datetime(2017, 10, 10, 17, 54, 34, 5432, datetime.timezone.utc)
    # WHEN
    obj = DateTimeFormat().serialize(dt)
    # THEN
    assert obj == '2017-10-10T17:54:34.005432Z'

    # GIVEN

# Generated at 2022-06-24 10:58:51.744580
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()
    assert b.errors == {}



# Generated at 2022-06-24 10:58:55.013148
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uf = UUIDFormat()
    assert uf.validate(str(uuid.uuid4())) == uuid.UUID

# Generated at 2022-06-24 10:59:02.021001
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    t = BaseFormat()
    assert t.is_native_type(datetime.date(2018, 12, 30)) is False
    assert t.is_native_type(datetime.time(1, 59, 59)) is False
    assert t.is_native_type(datetime.datetime(2018,12,30,23,59,59,999999)) is False	
    assert t.is_native_type(uuid.UUID("12345678-1234-5678-1234-567812345678")) is False		


# Generated at 2022-06-24 10:59:04.174109
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    from typesystem.base import ValidationError

    base = BaseFormat()
    try:
        base.validate(1)
    except NotImplementedError:
        assert True
    finally:
        assert False



# Generated at 2022-06-24 10:59:06.661286
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    time_format = UUIDFormat()
    time_format.validate("6f3e6d1a-e005-405c-b6ac-965f79c6ad69")

# Generated at 2022-06-24 10:59:09.697213
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    value = str(uuid.uuid4())
    format = UUIDFormat()
    assert format.is_native_type(value)


# Generated at 2022-06-24 10:59:13.621416
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    format = DateFormat()
    assert format.serialize(datetime.datetime(2019, 10, 2, 0, 0)) == "2019-10-02"
    assert format.serialize(None) == None

