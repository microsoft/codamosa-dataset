

# Generated at 2022-06-24 10:49:21.236190
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem import datetime

    datetime_format = DateTimeFormat()
    assert datetime_format.validate("2019-06-21T12:34:56") == datetime.datetime(2019, 6, 21, 12, 34, 56)
    assert datetime_format.validate("2019-06-21T12:34:56.123") == datetime.datetime(2019, 6, 21, 12, 34, 56, 123000)
    assert datetime_format.validate("2019-06-21T12:34:56.123456") == datetime.datetime(2019, 6, 21, 12, 34, 56, 123456)

# Generated at 2022-06-24 10:49:31.249154
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    # Test: should return a valid UUID object
    value = "d5aba02c-856f-45e9-938c-f5bda5e22079"
    assert (uuid_format.validate(value) == uuid.UUID(value))
    # Test: should raise a ValidationError exception
    value = "d5aba02c-856f-45e9-938c-f5bda5e2207"
    try:
        uuid_format.validate(value)
    except ValidationError as e:
        assert (e.code == "format")


# Generated at 2022-06-24 10:49:38.101974
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_t = datetime.time(10, 50, 30, 100000)
    time_f = datetime.time(12, 30, 0)
    date_t = datetime.date(2020, 4, 1)
    date_t_str = "2020-04-01"

    time_format = TimeFormat()

    # Test for a time object
    assert time_format.is_native_type(time_t) is True

    # Test for a time object
    assert time_format.is_native_type(time_f) is True

    # Test for a date object
    assert time_format.is_native_type(date_t) is False

    # Test for a date object string
    assert time_format.is_native_type(date_t_str) is False



# Generated at 2022-06-24 10:49:43.174149
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert UUIDFormat().validate("3e80c753-97d3-412c-b9f9-c88a16eb46e7") == uuid.UUID("3e80c753-97d3-412c-b9f9-c88a16eb46e7")
    with pytest.raises(ValidationError):
        UUIDFormat().validate("b52a4ad4-4ec4-42e8-98a5")

# Generated at 2022-06-24 10:49:46.358027
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    date = datetime.date(2020, 3, 21)
    assert date_format.is_native_type(date) is True


# Generated at 2022-06-24 10:49:53.353541
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    assert UUID_REGEX.match(uuid_format.serialize(uuid.UUID('94ec1bcf-1b87-4ffd-97cc-c021ff8dceb0')))
    assert str(uuid_format.validate('94ec1bcf-1b87-4ffd-97cc-c021ff8dceb0')) == '94ec1bcf-1b87-4ffd-97cc-c021ff8dceb0'

# Generated at 2022-06-24 10:50:01.410761
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    # Create object for BaseFormat
    bFormat = BaseFormat()
    assert bFormat.errors == {}

    assert bFormat.validation_error("format") == ValidationError(code='format', text="")
    try:
        bFormat.is_native_type("value")
    except:
        assert True

    try:
        bFormat.validate("value")
    except:
        assert True

    try:
        bFormat.serialize("value")
    except:
        assert True


# Generated at 2022-06-24 10:50:09.333555
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(2018, 12, 31)) == True
    assert date_format.is_native_type(datetime.date(2019, 1, 1)) == True
    # assert date_format.is_native_type(datetime.date(2018, 12, 31)) == True
    # assert date_format.is_native_type(datetime.date(2018, 12, 31)) == True
    # assert date_format.is_native_type(datetime.date(2018, 12, 31)) == True


# Generated at 2022-06-24 10:50:11.111633
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # TODO: implement test
    pass

# Generated at 2022-06-24 10:50:13.662132
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert df.serialize(datetime.date(2000, 8, 16)) == "2000-08-16"


# Generated at 2022-06-24 10:50:23.485948
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    format = UUIDFormat()
    test_data = 'c4638340-d5e5-11ea-87d0-0242ac130003'
    test_invalid = 'c4638340d5e511ea87d00242ac130003'
    assert format.validate(test_data) == uuid.UUID(test_data)
    assert format.validate(test_invalid) == uuid.UUID(test_invalid)
    assert format.serialize(uuid.UUID('c4638340-d5e5-11ea-87d0-0242ac130003')) == 'c4638340-d5e5-11ea-87d0-0242ac130003'

# Generated at 2022-06-24 10:50:24.715785
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat.is_native_type(BaseFormat) == True


# Generated at 2022-06-24 10:50:35.805643
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    errors = {"format": "Must be valid UUID format."}
    obj = UUIDFormat(errors)
    value = "d606f93d-8b26-4b0d-b4a1-4e4c4b0e3c0a"
    assert isinstance(obj.validate(value), uuid.UUID)
    value = "d606f93d-8b26-4b0d-b4a1-4e4c4b0e3c0b"
    assert isinstance(obj.validate(value), uuid.UUID)
    value = "d606f93d-8b26-4b0d-b4a1-4e4c4b0e3c0c"
    assert isinstance(obj.validate(value), uuid.UUID)

#

# Generated at 2022-06-24 10:50:38.405846
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    format = BaseFormat()
    with pytest.raises(NotImplementedError):
        format.serialize(None)


# Unittest for method is_native_type of class BaseFormat

# Generated at 2022-06-24 10:50:39.706124
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate('18:00:00') == datetime.time(hour=18)


# Generated at 2022-06-24 10:50:42.284131
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    input = "1994-11-05"
    output = datetime.date(1994, 11, 5)
    assert df.validate(input) == output



# Generated at 2022-06-24 10:50:50.934000
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    time_format = TimeFormat()
    assert isinstance(time_format.validation_error("foo"), ValidationError)
    assert isinstance(time_format.validation_error("format"), ValidationError)
    assert isinstance(time_format.validation_error("invalid"), ValidationError)

    uuid_format = UUIDFormat()
    assert isinstance(uuid_format.validation_error("foo"), ValidationError)
    assert isinstance(uuid_format.validation_error("format"), ValidationError)


# Generated at 2022-06-24 10:50:52.312480
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    date_time_format = DateTimeFormat()
    assert date_time_format is not None

# Generated at 2022-06-24 10:50:57.321938
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    a = DateTimeFormat()
    assert(a.is_native_type(datetime.date(2020, 3, 3))) == True
    assert(a.is_native_type(datetime.time(2020, 3, 3))) == True
    assert(a.is_native_type(datetime.datetime(2020, 3, 3))) == True


# Generated at 2022-06-24 10:51:01.815158
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetimeFormat_instance = DateTimeFormat()
    # test case 1: value's format is right
    value_case_1 = '2014-12-14T10:40:19.18040+08:00'
    result_case_1 = datetimeFormat_instance.validate(value_case_1)
    assert result_case_1.isoformat() == '2014-12-14T10:40:19.180400+08:00'
    # test case 2: value's format is wrong
    value_case_2 = '2014-12-14T10:40:19.18040'
    result_case_2 = datetimeFormat_instance.validate(value_case_2)
    assert result_case_2.isoformat() == '2014-12-14T10:40:19.180400'
    

# Generated at 2022-06-24 10:51:05.729880
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    b = BaseFormat()
    obj = '1234567-1234567-1234567'
    try:
        b.serialize(obj)
    except NotImplementedError as e:
        print(e)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 10:51:15.931574
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    d1 = DateTimeFormat()
    t0 = datetime.datetime(2019, 12, 25, 12, 30, 30, 0, datetime.timezone.utc)
    t1 = datetime.datetime(2019, 12, 25, 12, 30, 30, 0, None)
    t2 = datetime.datetime(2019, 12, 25, 12, 30, 30, 0, -datetime.timedelta(hours=1))
    t3 = datetime.datetime(2019, 12, 25, 12, 30, 30, 0, datetime.timedelta(0, 3600))
    t4 = datetime.datetime(2019, 12, 25, 12, 30, 30, 1000, datetime.timezone.utc)

# Generated at 2022-06-24 10:51:17.639130
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
	val_obj = UUIDFormat()
	assert isinstance(val_obj, UUIDFormat)

# Generated at 2022-06-24 10:51:22.012691
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidPara = '3c10a1e7-00b2-4cf4-b1e4-cb4ce4ba8dac'
    uuidFormatTest = UUIDFormat()
    assert uuidFormatTest.validate(uuidPara) == uuid.UUID(uuidPara)


# Generated at 2022-06-24 10:51:28.624771
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    myDateFormat = DateFormat()
    assert myDateFormat.validate('2018-01-17') == datetime.date(2018,1,17)
    assert myDateFormat.validate('2018-12-25') == datetime.date(2018,12,25)
    #exception
    with pytest.raises(ValidationError) as exception:
        myDateFormat.validate(None)


# Generated at 2022-06-24 10:51:32.617779
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format = BaseFormat()
    errors = {'code': 'Must be a valid date format.'}
    format.errors = errors
    assert format.validation_error("code") == ValidationError(text='Must be a valid date format.', code='code')


# Generated at 2022-06-24 10:51:36.798414
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class BaseFormat_test(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return True
    base_test = BaseFormat_test()
    assert base_test.is_native_type(object())


# Generated at 2022-06-24 10:51:40.103025
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    str_time = "03:58:21.652767"
    time_obj = TimeFormat().validate(str_time)
    assert TimeFormat().is_native_type(time_obj) == True
    

# Generated at 2022-06-24 10:51:46.998028
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_format = DateTimeFormat()
    assert date_format.serialize(datetime.datetime(2019, 1, 1)) == '2019-01-01T00:00:00'
    assert date_format.serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2019-01-01T00:00:00+00:00'


# Generated at 2022-06-24 10:51:54.632941
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    obj = DateFormat()
    assert not obj.is_native_type(2019)
    assert not obj.is_native_type(1)
    assert not obj.is_native_type(0)
    assert not obj.is_native_type([])
    assert not obj.is_native_type(None)
    assert obj.is_native_type(datetime.date(2019, 1, 1))
    assert obj.is_native_type(datetime.date(1, 1, 1))
    assert obj.is_native_type(datetime.date(0, 0, 0))


# Generated at 2022-06-24 10:52:01.373458
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time = "2020-02-05T18:23:14"
    format = DateTimeFormat()
    assert format.validate(date_time) == datetime.datetime(2020, 2, 5, 18, 23, 14)
    # assert format.validate(date_time).isoformat(timespec='seconds') == date_time
    # assert datetime.datetime( 2020, 2, 5, 18, 23, 14).isoformat(timespec='seconds') == date_time
    # assert format.validate(date_time).isoformat(timespec='microseconds') == date_time


# Generated at 2022-06-24 10:52:03.393341
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_str = "01:00:00.000002"
    time_format = TimeFormat()
    try:
        out_time = time_format.validate(time_str)
    except Exception as e:
        print(e)
    else:
        print(out_time)
        print(out_time.microsecond)
        print(out_time.tzinfo)


# Generated at 2022-06-24 10:52:11.466810
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    fmt = UUIDFormat()
    v = uuid.UUID('ce867d95-e264-43fe-bcec-8c1e58b9d9f6')
    assert(fmt.is_native_type(v) is True)
    assert(fmt.is_native_type('ce867d95-e264-43fe-bcec-8c1e58b9d9f6') is False)
    assert(fmt.is_native_type(uuid.uuid1()) is True)
    assert(fmt.is_native_type(uuid.uuid3(uuid.NAMESPACE_DNS, 'python.org')) is True)
    assert(fmt.is_native_type(uuid.uuid4()) is True)

# Generated at 2022-06-24 10:52:16.165537
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2020, 9, 5)) == True
    assert DateFormat().is_native_type(datetime.date(2021, 5, 6)) == True


# Generated at 2022-06-24 10:52:20.860790
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():

    assert UUIDFormat().serialize(None) is None

    assert str(UUIDFormat().serialize(uuid.uuid4())) == "89d9d9a7-e620-4b19-a2a2-d846e62cc78a"


# Generated at 2022-06-24 10:52:24.393115
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # generate a test date
    test_date = datetime.date(2001, 9, 11)

    # create the DateFormat instance
    date_format = DateFormat()

    # test the date format
    assert date_format.serialize(test_date) == "2001-09-11"

    # tests when the date is None
    assert date_format.serialize(None) == "None"



# Generated at 2022-06-24 10:52:26.607033
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(hour=0, minute=33, second=30)
    assert TimeFormat().serialize(time) == "00:33:30"



# Generated at 2022-06-24 10:52:28.174708
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    bf = BaseFormat()
    assert bf.serialize(None) is None


# Generated at 2022-06-24 10:52:36.166566
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    # True cases
    assert BaseFormat()
    assert BaseFormat().errors
    assert BaseFormat().is_native_type('1234')
    assert BaseFormat().validate('1234')
    assert BaseFormat().serialize('1234')

    # False cases
    try:
        assert BaseFormat().is_native_type([])
        assert False
    except NotImplementedError:
        assert True

    try:
        assert BaseFormat().validate([])
        assert False
    except NotImplementedError:
        assert True

    try:
        assert BaseFormat().serialize([])
        assert False
    except NotImplementedError:
        assert True

    # Test more constructor of class BaseFormat
    base_format1 = BaseFormat()
    base_format1.errors = {"test error": "test error message"}
    assert base

# Generated at 2022-06-24 10:52:40.117869
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    # DateTimeFormat
    dtf = DateTimeFormat()
    
    # Construct class DateTimeFormat successfully
    try:
        dtf = DateTimeFormat()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-24 10:52:46.452854
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    # Correct
    obj = BaseFormat()
    if(obj.is_native_type("") == True):
        print("Test instance BaseFormat OK")
    else:
        print("Test instance BaseFormat ERROR")


# Generated at 2022-06-24 10:52:50.096321
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class CustomFormat(BaseFormat):
        pass
    a = CustomFormat()
    with pytest.raises(NotImplementedError):
        a.validate(1)


# Generated at 2022-06-24 10:52:51.877237
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())

# Generated at 2022-06-24 10:52:53.339061
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())

# Generated at 2022-06-24 10:52:59.794556
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    # tests below should raise NotImplementedError
    base_format = BaseFormat()
    with pytest.raises(NotImplementedError):
        base_format.validate('value')
    with pytest.raises(NotImplementedError):
        base_format.is_native_type('value')
    with pytest.raises(NotImplementedError):
        base_format.serialize(None)


# Generated at 2022-06-24 10:53:03.439452
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    formatter = DateFormat()
    assert formatter.serialize(datetime.date(1999, 1, 1)) == '1999-01-01'


# Generated at 2022-06-24 10:53:11.990709
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    valid_time_value = (
        '10:15',
        '10:15:30',
        '10:15:30.000100',
        '10:15:30.000100Z',
        '22:15:30.999999-02:00',
    )
    for valid_time in valid_time_value:
        time_format.validate(valid_time)

    # Error in format

# Generated at 2022-06-24 10:53:18.555631
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat.is_native_type(None, None) == False
    assert BaseFormat.is_native_type(None, 1) == False
    assert BaseFormat.is_native_type(None, "abc") == False
    assert BaseFormat.is_native_type(None, True) == False
    assert BaseFormat.is_native_type(None, 3.14) == False
    assert BaseFormat.is_native_type(None, [1, 2, 3]) == False
    assert BaseFormat.is_native_type(None, ["a", "b", "c"]) == False
    assert BaseFormat.is_native_type(None, [1, "a", 3.14]) == False
    assert BaseFormat.is_native_type(None, [1, "a", "b", 3.14]) == False

# Generated at 2022-06-24 10:53:19.579395
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    BaseFormat.serialize(None)


# Generated at 2022-06-24 10:53:22.264287
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    UUIDFormat().is_native_type(uuid.UUID("5b5f6e91-6c9d-4b13-8459-1a1bf6f66dc6"))


# Generated at 2022-06-24 10:53:23.730926
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    bf = BaseFormat()
    bf.is_native_type(1)


# Generated at 2022-06-24 10:53:27.404406
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    u = uuid.UUID("123e4567-e89b-12d3-a456-426655440000");
    uf = UUIDFormat()
    assert (uf.is_native_type(u) == True)

# Generated at 2022-06-24 10:53:30.560541
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    sample_format = BaseFormat()
    assert not sample_format.is_native_type(1)
    # Check if is_native_type from sample_format is a function
    assert callable(sample_format.is_native_type)


# Generated at 2022-06-24 10:53:34.558289
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None
    assert BaseFormat().serialize(2) == 2
    assert BaseFormat().serialize("test") == "test"
    assert BaseFormat().serialize([1, 2, 3]) == [1, 2, 3]
    assert BaseFormat().serialize({"a": 1, "b": 2}) == {"a": 1, "b": 2}
 

# Generated at 2022-06-24 10:53:46.498034
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    timeformat = TimeFormat();
    time_str = "23:59:59.999999"
    assert isinstance(timeformat.validate(time_str), datetime.time)
    time_str = "23:59:59"
    assert isinstance(timeformat.validate(time_str), datetime.time)
    time_str = "23:59"
    assert isinstance(timeformat.validate(time_str), datetime.time)
    time_str = "0:0:0"
    assert isinstance(timeformat.validate(time_str), datetime.time)
    time_str = "12:1:1.999999"
    assert isinstance(timeformat.validate(time_str), datetime.time)

# Generated at 2022-06-24 10:53:48.306415
# Unit test for constructor of class DateFormat
def test_DateFormat():
    format = DateFormat()
    d1 = format.validate('2016-01-01')
    assert d1 == datetime.date(2016, 1, 1)
    

# Generated at 2022-06-24 10:53:50.795816
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    timeFormat = TimeFormat()

print(test_TimeFormat())

# Generated at 2022-06-24 10:53:55.606242
# Unit test for method serialize of class DateTimeFormat

# Generated at 2022-06-24 10:54:00.240327
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class StrFormat(BaseFormat):
        def validate(self, value: typing.Any) -> str:
            return str(value)
    value = StrFormat().validate(12)
    assert (value == '12')


# Generated at 2022-06-24 10:54:07.016244
# Unit test for constructor of class DateFormat
def test_DateFormat():
	# Arrange
	valid_date = datetime.date(2018, 7, 11)
	invalid_date = datetime.date(2018, 2, 30)

	# Act
	date_format = DateFormat()

	# Assert
	assert date_format.is_native_type(valid_date) == True
	assert date_format.is_native_type(invalid_date) == False
	assert date_format.validate(valid_date) == valid_date


# Generated at 2022-06-24 10:54:14.775507
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type("") == False
    assert BaseFormat().is_native_type(None) == False
    assert BaseFormat().is_native_type(1) == False
    assert BaseFormat().is_native_type(1.1) == False
    assert BaseFormat().is_native_type(True) == False
    assert BaseFormat().is_native_type({}) == False
    assert BaseFormat().is_native_type([]) == False
    assert BaseFormat().is_native_type(()) == False
    assert BaseFormat().is_native_type(set()) == False
    assert BaseFormat().is_native_type(datetime.datetime.now()) == False
    assert BaseFormat().is_native_type(datetime.date.today()) == False

# Generated at 2022-06-24 10:54:26.262997
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time.is_native_type(datetime.time(1)) == True
    assert time.is_native_type(datetime.time()) == True
    assert time.is_native_type("") == False
    assert time.is_native_type(True) == False
    assert time.is_native_type(12) == False
    assert time.is_native_type(12.3) == False
    assert time.is_native_type(datetime.datetime(2020, 2, 13)) == False
    assert time.is_native_type(datetime.datetime(2020, 2, 13, 1, 0, 0, 0)) == False
    assert time.is_native_type(datetime.datetime(2020, 2, 13, 0, 0, 0, 0)) == False

# Generated at 2022-06-24 10:54:29.048292
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_instance = uuid.UUID(int=0)
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(uuid_instance) is True


# Generated at 2022-06-24 10:54:30.582534
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None



# Generated at 2022-06-24 10:54:32.854404
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    base = BaseFormat()

    assert base.serialize("value") == "value"



# Generated at 2022-06-24 10:54:36.642611
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime(2020, 2, 2, 2, 2, 2, 2)) == True
    assert DateTimeFormat().is_native_type(datetime.date(2020, 2, 2)) == False
    assert DateTimeFormat().is_native_type(datetime.time(2, 2, 2, 2)) == False


# Generated at 2022-06-24 10:54:41.831159
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    x = UUIDFormat()
    assert x.is_native_type(uuid.uuid1()) == True
    assert x.is_native_type(123) == False
    assert x.is_native_type(1.23) == False
    assert x.is_native_type('hi') == False


# Generated at 2022-06-24 10:54:46.090271
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(2019, 1, 30)
    expected = '2019-01-30'
    assert DateFormat().serialize(obj) == expected



# Generated at 2022-06-24 10:54:50.956445
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    value_1 = (1, "b", [4.4, "pass"])
    value_2 = uuid.uuid4()

    assert UUIDFormat().is_native_type(value_1) == False
    assert UUIDFormat().is_native_type(value_2) == True


# Generated at 2022-06-24 10:54:52.366001
# Unit test for constructor of class DateFormat
def test_DateFormat():
	df = DateFormat()
	assert df is not None



# Generated at 2022-06-24 10:54:57.998225
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    # happy path
    assert date_format.validate("2020-04-23") == datetime.date(2020, 4, 23)

    # test when the format is invalid 
    try:
        date_format.validate("20-04-23")
    except ValidationError as e:
        assert e.code == "format"
        assert str(e) == "Must be a valid date format."

    # test when the date is invalid
    try:
        date_format.validate("2020-04-32")
    except ValidationError as e:
        assert e.code == "invalid"
        assert str(e) == "Must be a real date."



# Generated at 2022-06-24 10:55:00.508882
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    x = UUIDFormat()
    assert isinstance(x, UUIDFormat)

# Generated at 2022-06-24 10:55:02.447549
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    fmt = UUIDFormat()
    ud = uuid.uuid4()
    assert fmt.serialize(ud) == str(ud)

# Generated at 2022-06-24 10:55:10.712403
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
      f = DateTimeFormat()
      s_datetime = "2010-06-02T07:03:03"
      s_datetime2 = "2010-06-02T07:03:03Z"
      s_datetime3 = "2010-06-02T07:03:03+00:00"
      s_datetime4 = "2010-06-02T07:03:03+01:00"
      s_datetime5 = "2010-06-02T07:03:03-05:00"
      s_datetime6 = "2010-06-02T07:03:03.000"
      s_datetime7 = "2010-06-02T07:03:03.123+01:00"

# Generated at 2022-06-24 10:55:17.074558
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    expected = True
    actual = TimeFormat().is_native_type("00:41:45.358110")
    assert expected == actual


# Generated at 2022-06-24 10:55:22.148386
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    expect = datetime.datetime(2019, 1, 5, 17, 19, tzinfo=datetime.timezone.utc)
    dtf = DateTimeFormat()
    assert dtf.validate("2019-01-05T17:19Z") == expect

# Generated at 2022-06-24 10:55:24.726907
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time(1, 2, 3, 400000)
    assert TimeFormat().serialize(obj) == '01:02:03.400000'


# Generated at 2022-06-24 10:55:27.435908
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2020, 1, 1)) == '2020-01-01'
    assert DateFormat().serialize(None) == None


# Generated at 2022-06-24 10:55:29.239315
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        BaseFormat().validate("")



# Generated at 2022-06-24 10:55:32.755301
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class TypeFormat(BaseFormat):
        def is_native_type(self, value):
            return True
        def validate(self, value):
            pass
        def serialize(self, obj):
            pass

    format = TypeFormat()
    assert format.is_native_type("test") == True

# Generated at 2022-06-24 10:55:37.293013
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    d = datetime.datetime(year=2019, month=1, day=1, hour=1, minute=30, second=0, microsecond=0)
    obj = DateTimeFormat()
    assert obj.serialize(d) == '2019-01-01T01:30:00'

# Generated at 2022-06-24 10:55:40.950164
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat() is not None


# Generated at 2022-06-24 10:55:46.056091
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateTimeFormat()
assert date.validate("2019-01-01") == datetime.datetime.strptime("2019-01-01", "%Y-%m-%d")
assert date.validate("2019-25-01") #None


# Generated at 2022-06-24 10:55:57.311024
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    obj = UUIDFormat()
    assert obj.is_native_type("1e998c06-c81b-11e9-8e52-f46d047c8e99") == True
    assert obj.is_native_type("1e998c06c81b11e98") == False
    assert obj.is_native_type("1e998c06c81b11e98e52") == False
    assert obj.is_native_type("1e998c06c81b11e98e52f") == False
    assert obj.is_native_type("1e998c06c81b11e98e52f4") == False
    assert obj.is_native_type("1e998c06c81b11e98e52f46") == False

# Generated at 2022-06-24 10:56:01.441673
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    UUIDF = UUIDFormat()
    assert type(UUIDF.validate("ff2791f3-c7cc-4f6c-b2b9-31399a9a818e")) == uuid.UUID


# Generated at 2022-06-24 10:56:03.312478
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    with pytest.raises(NotImplementedError):
        BaseFormat().serialize(None)

# Generated at 2022-06-24 10:56:06.534505
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = uuid.UUID('12cb053f-4a46-4d17-8b24-e6e0c6d9b6ee')
    print(UUIDFormat().serialize(u))


# Generated at 2022-06-24 10:56:10.726805
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
	obj = TimeFormat()
	assert obj.errors == {"format": "Must be a valid time format.", "invalid": "Must be a real time."}


# Generated at 2022-06-24 10:56:20.092348
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    format = BaseFormat()
    assert format.is_native_type(str)
    assert format.is_native_type(int)
    assert format.is_native_type(float)
    assert format.is_native_type(dict)
    assert format.is_native_type(list)
    assert format.is_native_type(type)
    assert format.is_native_type(None)


# Generated at 2022-06-24 10:56:26.264808
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    F = BaseFormat()
    F.errors = {
        "format": "Must be a valid date format.",
    }
    assert F.validation_error("format").text == "Must be a valid date format."
    assert F.validation_error("format").code == "format"


# Generated at 2022-06-24 10:56:30.105711
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    test1 = DateTimeFormat()
    assert test1.errors == {"format": "Must be a valid datetime format.", "invalid": "Must be a real datetime."}


# Generated at 2022-06-24 10:56:37.906127
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat = DateFormat()
    assert dateformat.validate('2019-10-01') == datetime.date(2019, 10, 1)
    try:
        dateformat.validate('2019-10-40')
        assert False, 'Validation Error not raised'
    except ValidationError as ve:
        assert ve.code == 'invalid'

    try:
        dateformat.validate('2019-10-01t')
        assert False, 'Validation Error not raised'
    except ValidationError as ve:
        assert ve.code == 'format'



# Generated at 2022-06-24 10:56:41.516715
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():  
    date_time_format = DateTimeFormat()
    assert(date_time_format is not None)

# Generated at 2022-06-24 10:56:48.922957
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    from typesystem import types
    from typesystem.base import ValidationError

    class TestSchema(types.Schema):
        name = types.String()
        age = types.Integer()

    with pytest.raises(NotImplementedError):
        schema = TestSchema(
            {"name": "Test", "age": "20"},
            format="[{name} is {age} years old]",
        )
        schema.validate()



# Generated at 2022-06-24 10:56:51.308042
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-02-06") == datetime.date(2020, 2, 6)


# Generated at 2022-06-24 10:56:56.317674
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class MyFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, datetime.date)
    assert MyFormat().is_native_type(datetime.date(2020, 3, 3)) == True

# Generated at 2022-06-24 10:56:59.652413
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class MyBaseFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, datetime.date)
    format = MyBaseFormat()
    assert format.is_native_type("2000-01-01") == False
    assert format.is_native_type(datetime.date(2000, 1, 1)) == True


# Generated at 2022-06-24 10:57:02.240386
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    value_true = "1985-12-22"
    assert DateFormat().is_native_type(value_true) == 0


# Generated at 2022-06-24 10:57:05.405901
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(12, 34, 36, 789)) == '12:34:36.000789'

# Generated at 2022-06-24 10:57:11.286827
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    Time = TimeFormat()
    normal_time = datetime.datetime(hour=1, minute=2)
    normal_string = "01:02"
    normal_int = 3600
    normal_float = 3600.0
    normal_list = [1, 2]
    normal_dict = {1: 2}
    normal_set = {1, 2}
    normal_tuple = (1, 2)
    normal_bool = False

    assert Time.is_native_type(normal_time) is True
    assert Time.is_native_type(normal_string) is False
    assert Time.is_native_type(normal_int) is False
    assert Time.is_native_type(normal_float) is False
    assert Time.is_native_type(normal_list) is False
    assert Time.is_

# Generated at 2022-06-24 10:57:12.294199
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():

    uuid_format = UUIDFormat()
    print(uuid_format.errors)

test_UUIDFormat()

# Generated at 2022-06-24 10:57:21.642293
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    assert dateFormat.validate('2020-10-05') == datetime.date(2020, 10, 5)
    assert dateFormat.validate('2019-12-03') == datetime.date(2019, 12, 3)
    assert dateFormat.validate('2018-11-01') == datetime.date(2018, 11, 1)
    assert dateFormat.validate('1819-10-01') == datetime.date(1819, 10, 1)
    with pytest.raises(ValidationError):
        assert dateFormat.validate('1-1-1')
    with pytest.raises(ValidationError):
        assert dateFormat.validate('1-13-1')

# Generated at 2022-06-24 10:57:27.861345
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    from typesystem.exceptions import ValidationError
    uuid = "fd817811-df06-4e0d-83cc-4b3a0e91ccda"
    uuidFormat = UUIDFormat()
    assert uuidFormat.serialize(uuid.UUID(uuid)) == uuid
    uuid = "fd817811-df06"
    try:
        uuidFormat.validate(uuid)
        assert False
    except ValidationError as e:
        assert True

# Generated at 2022-06-24 10:57:30.142488
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    fmt = UUIDFormat()
    value = uuid.uuid4()
    expected = True

    assert fmt.is_native_type(value) == expected


# Generated at 2022-06-24 10:57:37.612174
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem.base import ValidationError

    fmt = DateTimeFormat()
    # Raised error when input a wrong number of hour
    try:
        fmt.validate(value='2019-03-06T24:59:2Z')
    except ValidationError as e:
        print(e)

    # Raised error when no year
    try:
        fmt.validate(value='03-06T24:59:2Z')
    except ValidationError as e:
        print(e)

    # Success
    print(fmt.validate(value='2019-03-06T24:59:02Z'))

# Generated at 2022-06-24 10:57:41.103306
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())==True


# Generated at 2022-06-24 10:57:44.392896
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dateTimeFormat = DateTimeFormat()
    dateTimeObject = datetime.datetime.now()
    assert dateTimeFormat.is_native_type(dateTimeObject) is True


# Generated at 2022-06-24 10:57:46.146237
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    d_format = DateTimeFormat()
    return d_format


# Generated at 2022-06-24 10:57:49.630531
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class TestFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return False
        def validate(self, value: typing.Any) -> typing.Union[typing.Any, ValidationError]:
            assert False
    obj = TestFormat()
    with pytest.raises(NotImplementedError):
        obj.validate("test")


# Generated at 2022-06-24 10:57:57.773217
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_datetime = datetime.datetime.now()
    result = DateTimeFormat().validate(
        """{0}-{1}-{2}T{3}:{4}:{5}+00:00""".format(
            test_datetime.year,
            test_datetime.month,
            test_datetime.day,
            test_datetime.hour,
            test_datetime.minute,
            test_datetime.second
        )
    )
    assert datetime.datetime.now().year == result.year
    assert datetime.datetime.now().month == result.month
    assert datetime.datetime.now().day == result.day
    assert datetime.datetime.now().hour == result.hour
    assert datetime.datetime.now().minute == result.minute

# Generated at 2022-06-24 10:57:59.485658
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()
    format.validate('2020-01-01')



# Generated at 2022-06-24 10:58:10.158166
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    my_time = datetime.time()
    my_date = datetime.date(2000, 2, 3)
    my_datetime = datetime.datetime.now()
    my_uuid_object = uuid.uuid4()
    
    assert DateFormat().is_native_type(my_date) == True
    assert TimeFormat().is_native_type(my_time) == True
    assert DateTimeFormat().is_native_type(my_datetime) == True
    assert UUIDFormat().is_native_type(my_uuid_object) == True

test_BaseFormat_is_native_type()


# Generated at 2022-06-24 10:58:15.910435
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    value = '2001-12-31T14:54:12.587587Z'
    obj = datetime.datetime(2001,12,31,14,54,12,587587)
    assert DateTimeFormat().serialize(obj) == value


# Generated at 2022-06-24 10:58:22.491145
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    match = TIME_REGEX.match("19:32")
    if not match:
        raise self.validation_error("format")

    groups = match.groupdict()
    if groups["microsecond"]:
        groups["microsecond"] = groups["microsecond"].ljust(6, "0")

    kwargs = {k: int(v) for k, v in groups.items() if v is not None}
    try:
        return datetime.time(tzinfo=None, **kwargs)
    except ValueError:
        raise self.validation_error("invalid")

# Generated at 2022-06-24 10:58:24.606571
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(tzinfo=None, hour=9, minute=12, second=23)) == "09:12:23"


# Generated at 2022-06-24 10:58:28.215840
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj_date = datetime.date.today()
    
    date_format = DateFormat()
    iso_date = date_format.serialize(obj_date)

    assert iso_date == '2020-11-03'


# Generated at 2022-06-24 10:58:33.066782
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = '123e4567-e89b-42d3-a456-556642440000'
    fmt = UUIDFormat()
    assert fmt.serialize(obj) == str(obj)

# Generated at 2022-06-24 10:58:39.143851
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    # True test
    try:
        a = datetime.datetime.now()
        b = DateTimeFormat()
        assert b.is_native_type(a) == True
    except:
        assert 1 == 0

    # False test
    try:
        a = 'hello'
        b = DateTimeFormat()
        assert b.is_native_type(a) == False
    except:
        assert 1 == 0


# Generated at 2022-06-24 10:58:49.543206
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    format = DateTimeFormat()
    assert format.is_native_type(datetime.datetime.now()) == True
    assert format.is_native_type('2019-01-01T03:00:00Z') == False
    assert format.validate('2019-01-01T03:00:00Z') == datetime.datetime(year=2019, month=1, day=1,
                                                                        hour=3, minute=0, second=0,
                                                                        tzinfo=datetime.timezone(0))

# Generated at 2022-06-24 10:58:53.314025
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    native_value = datetime.datetime.now()
    string_value = '2020-04-14T11:12:13.123456Z'
    format = DateTimeFormat()
    assert format.is_native_type(native_value) == True
    assert format.is_native_type(string_value) == False


# Generated at 2022-06-24 10:58:54.840222
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    base = BaseFormat()
    with pytest.raises(NotImplementedError):
        base.serialize("test")

# Generated at 2022-06-24 10:59:02.767890
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    # Create UUIDFormat object
    uuidf = UUIDFormat()
    # Create uuid from string
    uuid_test = uuid.UUID('550e8400-e29b-41d4-a716-446655440000')
    # Result
    r = uuidf.serialize(uuid_test)
    assert r == '550e8400-e29b-41d4-a716-446655440000'

# Generated at 2022-06-24 10:59:06.376574
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    data = UUIDFormat()
    input_uuid_obj = uuid.uuid4()
    output = data.serialize(input_uuid_obj)
    assert output == str(input_uuid_obj)

# Generated at 2022-06-24 10:59:15.610903
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat.errors == {}

    # Test validation_error()
    inst = BaseFormat()
    with pytest.raises(NotImplementedError):
        inst.validation_error('code')

    # Test is_native_type()
    with pytest.raises(NotImplementedError):
        inst.is_native_type('value')

    # Test validate()
    with pytest.raises(NotImplementedError):
        inst.validate('value')

    # Test serialize()
    with pytest.raises(NotImplementedError):
        inst.serialize('obj')

