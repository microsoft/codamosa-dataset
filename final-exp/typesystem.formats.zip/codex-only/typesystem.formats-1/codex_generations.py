

# Generated at 2022-06-24 10:49:19.628560
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2004, 7, 2))
    assert DateFormat().is_native_type(datetime.date.fromisoformat('2019-12-21')) #fromisoformat(...) is added in Python 3.7

    assert not DateFormat().is_native_type(datetime.datetime(2004, 7, 2, 12, 12, 12))



# Generated at 2022-06-24 10:49:20.755731
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert isinstance(TimeFormat(), TimeFormat)


# Generated at 2022-06-24 10:49:24.031129
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    assert tf.is_native_type("2019-10-16T11:00:00") == False
    assert tf.is_native_type("11:00:00") == True
    assert tf.is_native_type("11:00:00+00:00") == True
    assert tf.is_native_type("2019-10-16") == False
    assert tf.is_native_type("2019-10-16T11:00:00+00:00") == False


# Generated at 2022-06-24 10:49:34.516947
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert not TimeFormat().is_native_type(None)
    assert not TimeFormat().is_native_type(True)
    assert not TimeFormat().is_native_type(False)
    assert not TimeFormat().is_native_type(0)
    assert not TimeFormat().is_native_type(1)
    assert not TimeFormat().is_native_type(0.1)
    assert not TimeFormat().is_native_type("")
    assert not TimeFormat().is_native_type("a")
    assert not TimeFormat().is_native_type(())
    assert not TimeFormat().is_native_type([])
    assert not TimeFormat().is_native_type({})
    assert not TimeFormat().is_native_type(datetime.date)
    assert not TimeFormat().is_native_type(datetime.datetime)

# Generated at 2022-06-24 10:49:45.506268
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat().validate("2019-01-01T01:01:01Z") == datetime.datetime(2019, 1, 1, 1, 1, 1, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T01:01:01+01:00") == datetime.datetime(2019, 1, 1, 1, 1, 1, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert DateTimeFormat().validate("2019-01-01T01:01:01-01:00") == datetime.datetime(2019, 1, 1, 1, 1, 1, tzinfo=datetime.timezone(datetime.timedelta(hours=-1)))

# Generated at 2022-06-24 10:49:50.493680
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    # Test for different cases
    assert DateFormat().is_native_type(datetime.date(2001, 1, 1)) == True
    assert DateFormat().is_native_type(datetime.time(1, 1, 1)) == False
    assert DateFormat().is_native_type(datetime.datetime(2001, 1, 1)) == False



# Generated at 2022-06-24 10:49:56.255310
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()
    time = timeformat.validate("01:23:34")
    assert isinstance(time, datetime.time)
    assert time.hour == 1
    assert time.minute == 23
    assert time.second == 34
    assert time.microsecond == 0

    with pytest.raises(ValidationError):
        timeformat.validate("01:23:34:45")

    with pytest.raises(ValidationError):
        timeformat.validate("aa:23:34")



# Generated at 2022-06-24 10:49:58.443795
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    format = BaseFormat()
    assert format.is_native_type('test') == False

# Generated at 2022-06-24 10:50:02.471194
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4()) == True
    assert UUIDFormat().is_native_type(str(uuid.uuid4())) == False


# Generated at 2022-06-24 10:50:05.133498
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    dt = date.validate("2020-04-26")
    assert dt == datetime.date(2020, 4, 26)


# Generated at 2022-06-24 10:50:07.411509
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    pass


# Generated at 2022-06-24 10:50:12.375245
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    today = datetime.date.today().isoformat()
    assert date_format.serialize(today) == today
    assert date_format.serialize(None) is None


# Generated at 2022-06-24 10:50:20.986529
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    time = datetime.datetime.now().time()
    chars = str(time).split(":") # split time in individual chars
    time_str = time.isoformat() # time in string format
    if len(chars[2]) > 6: # convert chars[2] to 6 chars
        chars[2] = chars[2][:6]
    
    assert tf.serialize(time) == f'{chars[0]}:{chars[1]}:{chars[2]}'

# Generated at 2022-06-24 10:50:23.142371
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    bf = BaseFormat()

    assert(not bf.is_native_type('1'))


# Generated at 2022-06-24 10:50:24.715973
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    format = BaseFormat()
    assert format.validate(0) == 0


# Generated at 2022-06-24 10:50:35.807241
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time = datetime.datetime(year=2019, month=6, day=10, hour=23, minute=59, second=59)
    datetimeFormat = DateTimeFormat()
    assert datetimeFormat.validate("2019-06-10T23:59:59") == date_time
    assert datetimeFormat.validate("2019-06-10T23:59:59Z") == date_time
    assert datetimeFormat.validate("2019-06-10T23:59:59.345000") == date_time
    assert datetimeFormat.validate("2019-06-10T23:59:59.345000Z") == date_time
    assert datetimeFormat.validate("2019-06-10T23:59:59.345") == date_time

# Generated at 2022-06-24 10:50:36.732709
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert isinstance(UUIDFormat(), BaseFormat)


# Generated at 2022-06-24 10:50:37.750203
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat()



# Generated at 2022-06-24 10:50:39.827779
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    f1 = BaseFormat()
    f2 = BaseFormat()

    assert f1 is not f2



# Generated at 2022-06-24 10:50:41.066533
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(None) == None


# Generated at 2022-06-24 10:50:42.605651
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2020, 3, 20))


# Generated at 2022-06-24 10:50:48.158105
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # initialize a instance of DateTimeFormat
    date_time_format = DateTimeFormat()

    # test with a datetime object
    test_datetime = datetime.datetime(year=2020, month=6, day=6, hour=6, minute=6, second=6)
    assert date_time_format.serialize(obj=test_datetime) == "2020-06-06T06:06:06", "should be valid"

    # test with None
    assert date_time_format.serialize(obj=None) is None, "None should be serialized to None"

    # test with other object
    try:
        date_time_format.serialize(obj=10)
    except AssertionError as e:
        e_str = str(e)

# Generated at 2022-06-24 10:50:59.717063
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    # time with hour and minute
    value = "12:30"
    time = time_format.validate(value)
    assert time.hour == 12
    assert time.minute == 30
    assert time.second == 0
    assert time.microsecond == 0

    # time with hour, minute and second
    value = "12:30:20"
    time = time_format.validate(value)
    assert time.hour == 12
    assert time.minute == 30
    assert time.second == 20
    assert time.microsecond == 0

    # time with hour, minute, second and microsecond
    value = "12:30:20.123456"
    time = time_format.validate(value)
    assert time.hour == 12
    assert time.minute == 30

# Generated at 2022-06-24 10:51:01.377552
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    a = TimeFormat()
    print(a)


if __name__ == "__main__":  # pragma: no cover
    test_TimeFormat()

# Generated at 2022-06-24 10:51:02.973919
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    x:BaseFormat = BaseFormat()
    try:
        x.validate("123")
    except NotImplementedError:
        print("Test Passed")


# Generated at 2022-06-24 10:51:05.771972
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    f = TimeFormat()
    assert f.is_native_type(datetime.time(1, 2, 3))


# Generated at 2022-06-24 10:51:10.801496
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    class Test_DateFormat(DateFormat):
        def __init__(self, nullable: bool = None):
            self.nullable = nullable

    date_format = Test_DateFormat(nullable=True)
    assert date_format.serialize(datetime.datetime.today()) == datetime.datetime.today().date().isoformat()
    assert date_format.serialize(None) == None



# Generated at 2022-06-24 10:51:17.939460
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    r = re.compile(r"(?P<year>\d{4})-(?P<month>\d{1,2})-(?P<day>\d{1,2})[T ](?P<hour>\d{1,2}):(?P<minute>\d{1,2})(?::(?P<second>\d{1,2})(?:\.(?P<microsecond>\d{1,6})\d{0,6})?)?(?P<tzinfo>Z|[+-]\d{2}(?::?\d{2})?)?")
    m = r.match('2018-12-12T12:12:12+09:00')
    #print(m)
    print(m.groupdict())
    groups = m.groupdict()

# Generated at 2022-06-24 10:51:21.624336
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class BaseFormat_subclass(BaseFormat):
        pass
    @assert_exception(NotImplementedError, msg="BaseFormat.validate(): not implemented")
    def test():
        BaseFormat_subclass().validate('string_value')
    test()

# Generated at 2022-06-24 10:51:28.804835
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()

    assert date_format.validate("2019-10-22") == datetime.date(2019, 10, 22)

    with pytest.raises(ValidationError) as exc_info:
        date_format.validate("2019-22-10")
    assert exc_info.value.text == "Must be a real date."
    assert exc_info.value.code == "invalid"
        

# Generated at 2022-06-24 10:51:32.089240
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class MyFormat(BaseFormat):
        pass

    f = MyFormat()

    with pytest.raises(NotImplementedError):
        f.is_native_type(None)


# Generated at 2022-06-24 10:51:38.886909
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert(DateFormat().is_native_type("datetime.date") == False)
    assert(TimeFormat().is_native_type("datetime.time")== False)
    assert(DateTimeFormat().is_native_type("datetime.datetime")== False)
    assert(UUIDFormat().is_native_type("uuid.UUID") == False)


# Generated at 2022-06-24 10:51:46.626741
# Unit test for constructor of class DateFormat
def test_DateFormat():
    df = DateFormat()
    assert df.errors["format"] == "Must be a valid date format."
    assert df.errors["invalid"] == "Must be a real date."
    assert df.is_native_type(datetime.date(2014, 3, 4)) == True
    assert len(df.validate("2021-11-22")) == 10
    assert len(df.serialize(datetime.date(2014, 3, 4))) == 10


# Generated at 2022-06-24 10:51:47.477584
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert isinstance(DateTimeFormat(), DateTimeFormat)

# Generated at 2022-06-24 10:51:52.427243
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = uuid.uuid1()
    assert isinstance(obj, uuid.UUID)
    obj_str = str(obj)
    assert isinstance(obj_str, str)
    assert UUIDFormat().serialize(obj) == obj_str

# Generated at 2022-06-24 10:51:54.770103
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    obj = DateTimeFormat()
    assert isinstance(obj.validate("2013-12-06T10:10:10Z"), datetime.datetime)
    assert obj.serialize(datetime.datetime(2013,12,6,10,10,10)) == "2013-12-06T10:10:10Z"


# Generated at 2022-06-24 10:51:57.315024
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    my_format = BaseFormat()
    my_format.errors['code'] = ''
    error = my_format.validation_error('code')
    assert error.code == 'code'


# Generated at 2022-06-24 10:52:00.778813
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat().errors == {}
    assert BaseFormat().validation_error('format') == ValidationError(text='Must be a valid date format.', code='format')
    
    

# Generated at 2022-06-24 10:52:06.477582
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    timeFormat = TimeFormat()
    class Time:
        """
        This class is for unit test only
        """
        hour = 12
        minute = 00
        second = 00
    time1 = datetime.time(hour=12, minute=00, second=00)
    time2 = Time
    assert timeFormat.is_native_type(time1)
    assert not timeFormat.is_native_type(time2)


# Generated at 2022-06-24 10:52:07.777365
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    test_format = BaseFormat()
    assert test_format is not None


# Generated at 2022-06-24 10:52:09.713735
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    fmt = DateFormat()
    value = fmt.serialize(datetime.date(2019, 4, 20))
    assert value == "2019-04-20"

# Generated at 2022-06-24 10:52:11.789602
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    d = datetime.date(2013,5,5)
    assert df.serialize(d) == '2013-05-05'


# Generated at 2022-06-24 10:52:13.869441
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    isoFormat = '2020-02-15T09:30:00+00:00'
    assert DateTimeFormat().is_native_type(isoFormat)


# Generated at 2022-06-24 10:52:18.699099
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base = BaseFormat()
    assert isinstance(base, BaseFormat)


# Generated at 2022-06-24 10:52:24.618734
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    value = "23:59:59.999999"
    result = TimeFormat().validate(value)
    assert result == datetime.time(hour=23, minute=59, second=59, microsecond=999999)
    value = "23:59:59"
    result = TimeFormat().validate(value)
    assert result == datetime.time(hour=23, minute=59, second=59)
    value = "23:59"
    result = TimeFormat().validate(value)
    assert result == datetime.time(hour=23, minute=59)
    value = "23"
    result = TimeFormat().validate(value)
    assert result == datetime.time(hour=23)

# Generated at 2022-06-24 10:52:26.334577
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    bf = BaseFormat()
    bf.is_native_type = lambda x : False
    try:
        bf.validate("")
    except Exception:
        pass
    else:
        assert False

# Generated at 2022-06-24 10:52:29.719110
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert isinstance(UUIDFormat().validate('00000000-0000-0000-0000-000000000000'), uuid.UUID)
    assert UUIDFormat().serialize(uuid.UUID('00000000-0000-0000-0000-000000000000')) == '00000000-0000-0000-0000-000000000000'

# Generated at 2022-06-24 10:52:31.009303
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time())


# Generated at 2022-06-24 10:52:38.644401
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    # test that valid UUIDs validate successfully
    uuid_format = UUIDFormat()
    for i in range(5):
        assert uuid_format.validate(str(uuid.uuid4())) is not None
    
    # test that invalid UUIDs raise ValidationError
    with pytest.raises(ValidationError):
        uuid_format.validate("")
    with pytest.raises(ValidationError):
        uuid_format.validate("abc")
    with pytest.raises(ValidationError):
        uuid_format.validate("0"*32)
    with pytest.raises(ValidationError):
        uuid_format.validate("0"*31)

# Generated at 2022-06-24 10:52:46.532045
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class BaseFormatTest(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, str)

        def validate(self, value: typing.Any) -> str:
            return value

    assert BaseFormatTest().serialize(None) == None
    assert BaseFormatTest().serialize("") == ""

# Generated at 2022-06-24 10:52:53.243985
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class TestFormat(BaseFormat):
        errors = {"no_implemented": "Should not be called"}

        def is_native_type(self, value):
            return False

    # Check method validate
    # Given a BaseFormat instance
    f = TestFormat()
    # When validate is called
    # Then raises a NotImplementedError
    with pytest.raises(NotImplementedError):
        f.validate("")


# Generated at 2022-06-24 10:52:55.337998
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    obj = BaseFormat()
    assert obj.is_native_type(value=None) == False


# Generated at 2022-06-24 10:52:56.261735
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    BaseFormat().validation_error('format')

# Generated at 2022-06-24 10:53:06.097541
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 5, 12, 13, 25, 30, 0, tzinfo=None)) == '2020-05-12T13:25:30'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 5, 12, 13, 25, 30, 123456, tzinfo=None)) == '2020-05-12T13:25:30.123456'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 5, 12, 13, 25, 30, 0, datetime.timezone.utc)) == '2020-05-12T13:25:30Z'

# Generated at 2022-06-24 10:53:09.427812
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format = DateTimeFormat()

    try:
        assert format.is_native_type(datetime.datetime(2019, 10, 21, 11, 47, 28, 895353))
    except AssertionError:
        assert False



# Generated at 2022-06-24 10:53:13.588226
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid1 = uuid.uuid4()
    uuid2 = uuid.uuid4()
    uuid_format = UUIDFormat()
    assert uuid_format.validate(uuid1) == uuid1
    assert uuid_format.validate(uuid2) == uuid2

# Generated at 2022-06-24 10:53:23.205462
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate('2018-07-20T16:38:34+00:00') == datetime.datetime(2018, 7, 20, 16, 38, 34, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate('2019-04-15T00:37:11Z') == datetime.datetime(2019, 4, 15, 0, 37, 11, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate('2019-10-13T13:50:19+05:30') == datetime.datetime(2019, 10, 13, 13, 50, 19, tzinfo=datetime.timezone(datetime.timedelta(hours=5, minutes=30)))

# Generated at 2022-06-24 10:53:25.769010
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    res = DateFormat().validate('2020-12-22')
    assert res == datetime.date(2020, 12, 22)


# Generated at 2022-06-24 10:53:29.733681
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize("8b1a9953-c8b0-4011-981a-e8c26ac2d90c") \
            == "8b1a9953-c8b0-4011-981a-e8c26ac2d90c"

# Generated at 2022-06-24 10:53:31.901492
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    # UUIDFormat.is_native_type return True if value is NOT a uuid.UUID object
    my_object = UUIDFormat()
    assert my_object.is_native_type(uuid.uuid4()) == True

# Generated at 2022-06-24 10:53:35.586165
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    # case 1
    testBaseFormat = BaseFormat()
    assert testBaseFormat.serialize(None) == None

    # case 2
    class testClass(BaseFormat):
        def serialize(self, obj: typing.Any) -> typing.Union[str, None]:
            pass
            return None
    testBaseFormat = testClass()
    assert testBaseFormat.serialize(None) == None


# Generated at 2022-06-24 10:53:38.468584
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    x = datetime.date(2500,2,3)
    y = DateFormat()
    z = y.serialize(x)
    assert z=='2500-02-03'

# Generated at 2022-06-24 10:53:39.636514
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert tf != None


# Generated at 2022-06-24 10:53:44.329539
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert None == df.serialize(None)
    assert '2020-03-01' == df.serialize(datetime.date(2020, 3, 1))


# Generated at 2022-06-24 10:53:46.239257
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate('12:12:12') == datetime.time(12, 12, 12)


# Generated at 2022-06-24 10:53:53.819671
# Unit test for constructor of class DateFormat
def test_DateFormat():
    test = DateFormat()        # ValueError: Missing at least one argument: format, invalid
    test = DateFormat(errors = {"format":"Must be a valid date format."})  # TypeError: 'dict' object is not callable
    test = DateFormat(errors = {"format":"","invalid":""})
    assert test.errors["format"] == ""
    assert test.errors["invalid"] == ""
    

# Generated at 2022-06-24 10:53:57.612582
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert(isinstance(TimeFormat(), TimeFormat))
    

# Generated at 2022-06-24 10:54:05.604041
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(None) == False
    assert BaseFormat().is_native_type(3) == False
    assert BaseFormat().is_native_type("hola") == False
    assert BaseFormat().is_native_type(True) == False
    assert BaseFormat().is_native_type([]) == False
    assert BaseFormat().is_native_type({}) == False
    assert BaseFormat().is_native_type(()) == False
    assert BaseFormat().is_native_type(3.3) == False



# Generated at 2022-06-24 10:54:10.275948
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert tf.errors == {
        "format": "Must be a valid time format.",
        "invalid": "Must be a real time.",
    }

# Generated at 2022-06-24 10:54:15.097700
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(
        year=2020, month=1, day=1,
        hour=0, minute=0, second=0,
        tzinfo=datetime.timezone.utc,
    )
    assert DateTimeFormat().serialize(dt) == '2020-01-01T00:00:00Z'

# Generated at 2022-06-24 10:54:17.684871
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format = BaseFormat()

    with pytest.raises(NotImplementedError):
        format.validation_error(code='format') # pragma: no cover


# Generated at 2022-06-24 10:54:19.885582
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base_format_object = BaseFormat()
    assert base_format_object.errors == {}


# Generated at 2022-06-24 10:54:25.498356
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    timeFormat = TimeFormat()
    assert isinstance(timeFormat, BaseFormat)
    assert not timeFormat.is_native_type(1)
    with pytest.raises(NotImplementedError): timeFormat.validate(1)
    with pytest.raises(NotImplementedError): timeFormat.serialize(1)


# Generated at 2022-06-24 10:54:33.767237
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():

    # Test TimeFormat with incorrect values
    time_format = TimeFormat()
    assert (time_format.validate("99:99:99,999999") == time_format.validation_error("invalid"))
    assert (time_format.validate("99:99:99,99999999") == time_format.validation_error("invalid"))
    assert (time_format.validate("99:99:99,99999999") == time_format.validation_error("invalid"))
    assert (time_format.validate("25:00") == time_format.validation_error("invalid"))
    assert (time_format.validate("15:99") == time_format.validation_error("invalid"))

# Generated at 2022-06-24 10:54:39.096992
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    fmt = UUIDFormat()
    assert fmt.validate("12345678-1234-5678-1234-567812345678") == uuid.UUID("12345678-1234-5678-1234-567812345678") # type: ignore
    try:
        fmt.validate("123")
    except ValidationError as e:
        assert e.code == "format"
        assert e.text == "Must be valid UUID format."
    else:
        raise RuntimeError("ValidationError expected")


# Generated at 2022-06-24 10:54:41.458450
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    date = datetime.date(2020, 10, 10)
    assert df.serialize(date) == "2020-10-10"



# Generated at 2022-06-24 10:54:52.329243
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():        
    # Test for object DateFormat
    # Case 1: value is not a string
    d = DateFormat()
    with pytest.raises(ValidationError) as e:
        d.validate(123)
    assert e.value.code == 'format'
    assert e.value.text == 'Must be a valid date format.'
    
    # Case 2: value is a real date format
    date = datetime.date(2020, 1, 2)
    assert d.validate('2020-01-02') == date
    
    # Case 3: value is not a real date format
    with pytest.raises(ValidationError) as e:
        d.validate('2020-01-3')
    assert e.value.code == 'invalid'    
    
    # Test for object TimeFormat
    # Case 1:

# Generated at 2022-06-24 10:54:53.806790
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    base_format = BaseFormat()
    with pytest.raises(NotImplementedError):
        base_format.validate(1)


# Generated at 2022-06-24 10:54:58.323580
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    #arrange
    date_format_expected = str('2020-01-01')
    #act
    date_format_result = DateFormat().is_native_type(date_format_expected)
    #assert
    date_format_expected = True
    assert date_format_result == date_format_expected


# Generated at 2022-06-24 10:55:00.544797
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize(None) == str(None)


# Generated at 2022-06-24 10:55:07.186562
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    d = DateTimeFormat()
    assert d.validate('2018-12-31T15:29:00.4Z') == datetime.datetime(2018, 12, 31, 15, 29, 0, 400000, tzinfo = datetime.timezone.utc)

# Generated at 2022-06-24 10:55:10.525767
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    def fun0(x) -> bool:
        return isinstance(x, datetime.time)

    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(0, 0)) == fun0(datetime.time(0, 0))


# Generated at 2022-06-24 10:55:18.243976
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    # arrange
    from uuid import uuid4

# Generated at 2022-06-24 10:55:22.785819
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    timeFormat = TimeFormat()
    time = datetime.time(tzinfo=None, hour=2, minute=2)
    res = timeFormat.is_native_type(time)
    assert res == True


# Generated at 2022-06-24 10:55:28.224441
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert(UUIDFormat().validate("00000000-0000-0000-0000-000000000000") == uuid.UUID('00000000-0000-0000-0000-000000000000'))
    assert(UUIDFormat().validate("01234567-89ab-cdef-0123-456789abcdef") == uuid.UUID('01234567-89ab-cdef-0123-456789abcdef'))

# Generated at 2022-06-24 10:55:28.867760
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    pass

# Generated at 2022-06-24 10:55:30.884403
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uf = UUIDFormat()
    assert uf.errors == {"format": "Must be valid UUID format."}


# Generated at 2022-06-24 10:55:35.507526
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    x = UUIDFormat()
    test_uuid = uuid.uuid4()
    assert x.serialize(test_uuid) == '{}'.format(test_uuid)



# Generated at 2022-06-24 10:55:38.647137
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    t1 = UUIDFormat()
    assert t1.is_native_type(uuid.uuid4()) == True
    assert t1.is_native_type(datetime.datetime.now()) == False


# Generated at 2022-06-24 10:55:40.778594
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    obj = TimeFormat()
    assert obj


# Generated at 2022-06-24 10:55:49.188990
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    a = DateTimeFormat()
    assert a.validate("2017-01-01T00:00:00") == datetime.datetime(2017, 1, 1)
    assert a.validate("2017-01-01T23:59:59") == datetime.datetime(2017, 1, 1, 23, 59, 59)
    assert a.validate("2017-01-01T23:59:59.123456") == datetime.datetime(2017, 1, 1, 23, 59, 59, 123456)
    assert a.validate("2017-01-01T23:59:59Z") == datetime.datetime(2017, 1, 1, 23, 59, 59, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-24 10:55:51.439576
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(None) is True
    

# Generated at 2022-06-24 10:55:52.134658
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert True

# Generated at 2022-06-24 10:56:04.172489
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uf = UUIDFormat()
    uuid1 = uf.validate("78e22e7c-5c5b-41a3-bd5d-f9dfff55d8ee")
    assert str(uuid1) == "78e22e7c-5c5b-41a3-bd5d-f9dfff55d8ee"

    uuid2 = uf.validate("78e22e7c5c5b41a3bd5df9dfff55d8ee")
    assert str(uuid2) == "78e22e7c-5c5b-41a3-bd5d-f9dfff55d8ee"


# Generated at 2022-06-24 10:56:06.497684
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    fmt = DateTimeFormat()
    bool_inpt = fmt.is_native_type(datetime.datetime.now())
    assert bool_inpt == True


# Generated at 2022-06-24 10:56:17.852410
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()
    format.validate("2020-03-18")
    with pytest.raises(ValidationError):
        format.validate("13-03-2020")
    with pytest.raises(ValidationError):
        format.validate("2020-03-51")
    with pytest.raises(ValidationError):
        format.validate("2020-13-04")
    with pytest.raises(ValidationError):
        format.validate("200-11-10")
    with pytest.raises(ValidationError):
        format.validate("3020-11-10")
    with pytest.raises(ValidationError):
        format.validate("123")
    with pytest.raises(ValidationError):
        format.validate("")


# Generated at 2022-06-24 10:56:25.024948
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    data_test = [['2020-06-09'], ['2020-06-09', '2020-06-12'], ['2020-06-09', '2020-06-12', '2020-06-13']]
    expected = [datetime.date(2020, 6, 9), datetime.date(2020, 6, 9), datetime.date(2020, 6, 9)]
    for idx in range(len(data_test)):
        actual = DateFormat().validate(data_test[idx])
        assert expected[idx] == actual


# Generated at 2022-06-24 10:56:33.027408
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetimeformat = DateTimeFormat()
    # Test for a valid date time string
    assert datetimeformat.validate('2019-11-26T13:03:35.741Z') is not None
    assert datetimeformat.validate('2019-11-26T13:03:35.74+00:00') is not None
    assert datetimeformat.validate('2019-11-26T13:03:35.74+13:00') is not None
    assert datetimeformat.validate('2019-11-26T13:03:35.74+13:01') is not None
    assert datetimeformat.validate('2019-11-26T13:03:35.74+13:01:00') is not None

# Generated at 2022-06-24 10:56:34.549652
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    try:
        UUIDFormat()
    except:
        assert False
    assert True


# Generated at 2022-06-24 10:56:37.541353
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(13, 27, 4)
    tf = TimeFormat()
    time_string = tf.serialize(time)
    assert time_string == "13:27:04"

# Generated at 2022-06-24 10:56:40.458247
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    from typesystem.base import ValidationError
    from typesystem.exceptions import ValidationError
    BaseFormat1 = BaseFormat()
    try:
        raise BaseFormat1.validation_error("format")
    except:
        pass


# Generated at 2022-06-24 10:56:41.821769
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    a = BaseFormat()
    assert isinstance(a, BaseFormat)


# Generated at 2022-06-24 10:56:44.338665
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    with pytest.raises(NotImplementedError):
        BaseFormat().serialize(None)


# Generated at 2022-06-24 10:56:49.564554
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    # GIVEN
    class BaseFormat_Test(BaseFormat):
        pass
    
    # WHEN
    base_format_obj = BaseFormat_Test()
    
    # THEN
    with pytest.raises(NotImplementedError):
        base_format_obj.serialize(15.2)



# Generated at 2022-06-24 10:56:50.718572
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now())



# Generated at 2022-06-24 10:56:54.559621
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # DateFormat class testing with actual date
    date_object = datetime.date(2020, 5, 22)
    # result: string with date in ISO format
    assert DateFormat().serialize(date_object) == "2020-05-22"

    # DateFormat class testing with None value
    assert DateFormat().serialize(None) == None


# Generated at 2022-06-24 10:56:56.140737
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dateTimeFormat = DateTimeFormat()
    assert dateTimeFormat != None


# Generated at 2022-06-24 10:56:56.713104
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    assert 1 == 1

# Generated at 2022-06-24 10:57:06.686788
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    class CoolFormat(BaseFormat):
        errors = {
            "format": "Must be a valid datetime format.",
            "invalid": "Must be a real datetime.",
        }

    cool_format = CoolFormat()
    validation_error = cool_format.validation_error('invalid')
    assert validation_error.code == 'invalid', "test"
    assert validation_error.text == 'Must be a real datetime.', "test"
    #assert cool_format.is_native_type(value) == str(value), "test"
    #assert cool_format.serialize(value) == str(value), "test"



# Generated at 2022-06-24 10:57:15.028386
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
        from typesystem.format import DateTimeFormat
        from datetime import datetime
        dt = datetime.utcnow()
        assert dt.tzname() == 'UTC'
        fmt = DateTimeFormat()
        assert fmt.serialize(dt) == dt.isoformat() + 'Z'
        dt = datetime.now()
        assert dt.tzname() != 'UTC'
        assert fmt.serialize(dt) == dt.isoformat()

# Generated at 2022-06-24 10:57:19.093945
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    dateformat = DateFormat()
    assert dateformat.is_native_type(datetime.date.today()) == True
    

# Generated at 2022-06-24 10:57:27.981281
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format_obj = DateTimeFormat()

    assert format_obj.is_native_type(datetime.datetime.now()) == True
    assert format_obj.is_native_type(datetime.date.today()) == False
    assert format_obj.is_native_type(datetime.datetime.now().time()) == False
    assert format_obj.is_native_type(datetime.datetime.now().date()) == False
    assert format_obj.is_native_type(datetime.datetime.today()) == True


# Generated at 2022-06-24 10:57:30.769001
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_format = TimeFormat()
    assert time_format.errors["format"] == "Must be a valid time format."
    assert time_format.errors["invalid"] == "Must be a real time."


# Generated at 2022-06-24 10:57:32.862281
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    with pytest.raises(ValueError):
        UUIDFormat().validate("ffffffff-ffff-ffff-ffff-ffffffffffff")


# Generated at 2022-06-24 10:57:36.453584
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormatValidator = TimeFormat()

    timeString = '12:35:59.036534'
    assert timeFormatValidator.validate(timeString).isoformat() == timeString
    timeString = '12:35:59'
    assert timeFormatValidator.validate(timeString).isoformat() == timeString

# Generated at 2022-06-24 10:57:38.993627
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.datetime.now().time())
    assert not TimeFormat().is_native_type(datetime.datetime.now())


# Generated at 2022-06-24 10:57:41.643508
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2020,3,19)) == "2020-03-19"

# Generated at 2022-06-24 10:57:52.735213
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    t = TimeFormat()

# Generated at 2022-06-24 10:57:54.694687
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    u = UUIDFormat()
    assert u.is_native_type('4e1c4bd7-8a4b-4e66-aeeb-c53d8ae95f3c') == True



# Generated at 2022-06-24 10:57:56.474413
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    instance=UUIDFormat()
    instance2=UUIDFormat()
    assert type(instance.serialize(instance2))==str


# Generated at 2022-06-24 10:57:58.467442
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    with pytest.raises(NotImplementedError):
        BaseFormat().serialize(None)



# Generated at 2022-06-24 10:57:59.825055
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(str()) == False


# Generated at 2022-06-24 10:58:10.169970
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    hours = "01"
    minutes = "02"
    seconds = "03"
    microseconds = "456789"
    m = "0"
    l = "9"
    time = "{0}:{1}:{2}.{3}{4}".format(hours, minutes, seconds, m, l)
    time = time_format.validate(time)
    assert time == datetime.time(1, 2, 3, 456789)
    # assert time == datetime.time(1, 2, 3, 456789)



# Generated at 2022-06-24 10:58:14.678560
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    instance = UUIDFormat()
    assert instance.is_native_type(uuid.uuid4()) == True


# Generated at 2022-06-24 10:58:22.990983
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    with open('./data/serialize.json') as f:
        data = json.load(f)

    assert BaseFormat().serialize(data[0]['obj']) == data[0]['result']
    assert BaseFormat().serialize(data[1]['obj']) == data[1]['result']
    assert BaseFormat().serialize(data[2]['obj']) == data[2]['result']
    assert BaseFormat().serialize(data[3]['obj']) == data[3]['result']
    assert BaseFormat().serialize(data[4]['obj']) == data[4]['result']
    assert BaseFormat().serialize(data[5]['obj']) == data[5]['result']


# Generated at 2022-06-24 10:58:27.991268
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuidFormat = UUIDFormat()
    uuid1 = uuid.UUID('12345678-1234-5678-1234-567812345678')
    uuid2 = str(uuid1)
    assert(uuidFormat.serialize(uuid1) == uuid2)

# Generated at 2022-06-24 10:58:31.664808
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    test_format = BaseFormat()
    
    test_format.errors = {
        "test_code": "Test text"
    }

    test_result = test_format.validation_error("test_code")
    assert test_result.text == "Test text"
    assert test_result.code == "test_code"



# Generated at 2022-06-24 10:58:35.313919
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime.strptime("2019-11-20", "%Y-%m-%d")) == "2019-11-20T00:00:00"
    assert DateTimeFormat().serialize(None) == None


# Generated at 2022-06-24 10:58:37.594857
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(year=2020, month=4, day=20)) == "2020-04-20"


# Generated at 2022-06-24 10:58:44.557763
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    a = UUIDFormat()
    b = a.serialize(uuid.UUID(""))
    assert b == ""
    c = a.serialize(uuid.UUID("ffa19f54-d0c0-11ea-8f53-acde48001122"))
    assert c == "ffa19f54-d0c0-11ea-8f53-acde48001122"
    d = a.serialize("ffa19f54-d0c0-11ea-8f53-acde48001122")
    assert d == "ffa19f54-d0c0-11ea-8f53-acde48001122"
    e = a.serialize(None)
    assert e == None


# Generated at 2022-06-24 10:58:49.923370
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert UUIDFormat().validate('d50c8aac-b78d-4e24-b3c4-4aa56fe4ee55') == uuid.UUID('d50c8aac-b78d-4e24-b3c4-4aa56fe4ee55')
    

# Generated at 2022-06-24 10:58:57.691095
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    import datetime
    from typesystem.formats import DateTimeFormat

    datetime_format = DateTimeFormat()
    assert datetime_format.serialize(datetime.datetime(2020, 2, 13, 13, 13, 13)) == '2020-02-13T13:13:13'
    assert datetime_format.serialize(datetime.datetime(2020, 2, 13, 13, 13, 13, 0, datetime.timezone.utc)) == '2020-02-13T13:13:13Z'
    assert datetime_format.serialize(datetime.datetime(2020, 2, 13, 13, 13, 13, 0, datetime.timezone(datetime.timedelta(hours=1)))) == '2020-02-13T13:13:13+01:00'

# Generated at 2022-06-24 10:58:59.411425
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    x=UUIDFormat()
    y=x.is_native_type(uuid.uuid4())
    assert y == True


# Generated at 2022-06-24 10:59:02.767551
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    fm = BaseFormat()

# Generated at 2022-06-24 10:59:03.698749
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) is None

# Generated at 2022-06-24 10:59:08.074043
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class BaseFormat(BaseFormat):
        pass

    base_format = BaseFormat()

    try:
        base_format.is_native_type(123)
        assert False
    except NotImplementedError:
        assert True

    try:
        base_format.is_native_type("123")
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 10:59:12.539568
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(19, 8, 46, tzinfo=datetime.timezone(-datetime.timedelta(hours=8)))
    timeFormat = TimeFormat()
    assert timeFormat.serialize(time) == "11:08:46+00:00"

# Generated at 2022-06-24 10:59:15.318339
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():

    time = TimeFormat()

    assert time.is_native_type(datetime.time(10, 2, 3))
    assert not time.is_native_type(datetime.date(2010, 2, 3))