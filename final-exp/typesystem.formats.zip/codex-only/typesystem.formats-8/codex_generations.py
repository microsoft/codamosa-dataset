

# Generated at 2022-06-24 10:49:19.509381
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_format = DateTimeFormat()

    obj1 = datetime.datetime(2019, 1, 14, 17, 0, 8, 942000)
    assert datetime_format.serialize(obj1) == "2019-01-14T17:00:08.942"

    obj2 = datetime.datetime(2019, 1, 14, 17, 0, 8, 942000, tzinfo=datetime.timezone.utc)
    assert datetime_format.serialize(obj2) == "2019-01-14T17:00:08.942Z"

    obj3 = datetime.datetime(2019, 1, 14, 17, 0, 8, 942000, tzinfo=datetime.timezone(datetime.timedelta(hours=-1)))

# Generated at 2022-06-24 10:49:22.927113
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 10, 12)
    date_format = DateFormat()
    assert date_format.serialize(date) == date.isoformat()


# Generated at 2022-06-24 10:49:25.678836
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True
    

# Generated at 2022-06-24 10:49:28.773609
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat.validate('2018-02-01') == datetime.date(2018, 2, 1)


# Generated at 2022-06-24 10:49:34.871541
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtf = DateTimeFormat()
    assert dtf.is_native_type(datetime.date(1,1,1)) == True
    assert dtf.is_native_type(datetime.datetime(1,1,1,1,1,1)) == True
    assert dtf.is_native_type(datetime.time(1,1,1)) == True
    assert dtf.is_native_type(datetime.timedelta(1,1)) == False
    assert dtf.is_native_type("date") == False


# Generated at 2022-06-24 10:49:38.703171
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    base = BaseFormat()
    assert base.is_native_type() == NotImplemented


# Generated at 2022-06-24 10:49:42.982623
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class TempFormat(BaseFormat):
        def is_native_type(self, value):
            return True

        def validate(self, value):
            return value

    temp = TempFormat()
    assert temp.serialize(None) is None
    assert temp.serialize(1) == '1'
    assert temp.serialize(3.141592653589793) == '3.141592653589793'

# Generated at 2022-06-24 10:49:48.631167
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class BaseFormat_is_native_type(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, dict)
    with pytest.raises(NotImplementedError) as excinfo:
        BaseFormat_is_native_type().validate('Test')
    with pytest.raises(NotImplementedError) as excinfo:
        BaseFormat_is_native_type().serialize('Test')
    assert BaseFormat_is_native_type().errors == {
    }
    assert BaseFormat_is_native_type().is_native_type('Test') == False


# Generated at 2022-06-24 10:49:50.278454
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        BaseFormat().validate("")


# Generated at 2022-06-24 10:49:52.562804
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.datetime.now().time())


# Generated at 2022-06-24 10:49:57.594763
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    testDate = datetime.datetime(2020, 6, 9)
    testTime = datetime.time(12, 45)
    testDateTime = datetime.datetime(2020, 6, 9, 12, 45)

    dateFmt = DateFormat()
    timeFmt = TimeFormat()
    dateTimeFmt = DateTimeFormat()

    assert dateTimeFmt.is_native_type(testDateTime)
    assert not dateTimeFmt.is_native_type(testTime)
    assert not dateTimeFmt.is_native_type(testDate)


# Generated at 2022-06-24 10:50:07.172642
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    D = DateFormat()
    assert D.is_native_type(datetime.date(2020, 5, 6)) == True
    assert D.is_native_type(datetime.time(5, 6, 7)) == False
    assert D.is_native_type(datetime.datetime(2020, 5, 6, 5, 6, 7)) == False
    assert D.is_native_type(5) == False
    assert D.is_native_type("2020-05-06") == False
    assert D.is_native_type(None) == False


# Generated at 2022-06-24 10:50:19.115335
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-02-29")
    date_format.validate("1999-08-09")
    date_format.validate("2000-01-01")
    try:
        date_format.validate("2020-02-30")
    except ValidationError as e:
        assert e.code == "invalid"

    try:
        date_format.validate("2020-13-13")
    except ValidationError as e:
        assert e.code == "format"

    try:
        date_format.validate("2020-12-")
    except ValidationError as e:
        assert e.code == "format"



# Generated at 2022-06-24 10:50:21.969271
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    ans = TimeFormat().serialize(datetime.time(13, 11, 12, tzinfo=datetime.timezone.utc))
    assert ans == "13:11:12+00:00"

# Generated at 2022-06-24 10:50:25.136855
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(2018, 6, 26)
    test_object = DateFormat()
    check_value = test_object.serialize(obj)
    expected_value = '2018-06-26'
    assert check_value == expected_value


# Generated at 2022-06-24 10:50:32.575276
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
  native_types_mapping = {datetime.date: DateFormat, datetime.time: TimeFormat,\
                          datetime.datetime: DateTimeFormat, uuid.UUID: UUIDFormat}
  for native_type, format_class in native_types_mapping.items():
    assert format_class().is_native_type(native_type())
    assert not DateTimeFormat().is_native_type(native_type)

# Unit tests for methods validate and validation_error
# of class BaseFormat

# Generated at 2022-06-24 10:50:35.411465
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d = DateFormat()
    mydate = d.validate('2019-04-15')

    assert d.serialize(mydate) == '2019-04-15'


# Generated at 2022-06-24 10:50:37.658704
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize("2020-08-17") == "2020-08-17"
    assert DateFormat().serialize(None) == None


# Generated at 2022-06-24 10:50:41.779212
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dtf = DateTimeFormat()
    datetime_obj = datetime.datetime(2020, 3, 3, 3, 3, 3, tzinfo=datetime.timezone.utc)
    assert dtf.serialize(datetime_obj) == "2020-03-03T03:03:03Z"

# Generated at 2022-06-24 10:50:43.492734
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 11, 6, 0)) == '2020-01-01T11:06:00'



# Generated at 2022-06-24 10:50:46.477727
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    d = DateTimeFormat()
    assert d.is_native_type(datetime.datetime.now()) == True
    assert d.is_native_type(datetime.time.now()) == False
    assert d.is_native_type(datetime.date.today()) == False


# Generated at 2022-06-24 10:50:48.977836
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
	time_format = TimeFormat()
	assert time_format.validate("08:00") is not None


# Generated at 2022-06-24 10:50:50.036870
# Unit test for constructor of class DateFormat
def test_DateFormat():
    DateFormat()


# Generated at 2022-06-24 10:50:58.610687
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    a = TimeFormat()
    b = a.validate("12:00")
    assert(b.hour == 12)
    assert(b.minute == 0)

    c = a.validate("12:00:03")
    assert(c.hour == 12)
    assert(c.minute == 0)
    assert(c.second == 3)

    d = a.validate("12:00:03.007")
    assert(d.hour == 12)
    assert(d.minute == 0)
    assert(d.second == 3)
    assert(d.microsecond == 7)



# Generated at 2022-06-24 10:50:59.880463
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    val = DateTimeFormat()
    assert isinstance(val, DateTimeFormat)

# Generated at 2022-06-24 10:51:02.916678
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    
    # Test is None
    obj = None
    result = TimeFormat().serialize(obj)
    assert result is None
    
    # Test is not None
    obj = datetime.time(10,9,8,7)
    result = TimeFormat().serialize(obj)
    assert result == "10:09:08.000007"

# Generated at 2022-06-24 10:51:08.080159
# Unit test for constructor of class DateFormat
def test_DateFormat():
    d = DateFormat(**{"errors": {"format": "must be a valid date format.", "invalid": "must be a real date."}})
    assert d.errors["format"] == "must be a valid date format."
    assert d.errors["invalid"] == "must be a real date."


# Generated at 2022-06-24 10:51:17.446971
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_test = TimeFormat()
    assert time_test.is_native_type("") == False
    assert time_test.is_native_type("1") == False
    assert time_test.is_native_type("0") == False
    assert time_test.is_native_type(1) == False
    assert time_test.is_native_type(True) == False
    assert time_test.is_native_type(False) == False
    assert time_test.is_native_type([]) == False
    assert time_test.is_native_type(None) == False
    assert time_test.is_native_type({}) == False
    assert time_test.is_native_type(datetime.datetime.now()) == False

# Generated at 2022-06-24 10:51:18.251776
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    timeFormat = TimeFormat()
    assert not timeFormat is None, "TimeFormat constructor failed"



# Generated at 2022-06-24 10:51:20.229403
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().validate(str(uuid.uuid4())) == str(uuid.uuid4())

# Generated at 2022-06-24 10:51:28.202112
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    df=DateTimeFormat()
    # datetime format: YYYY-MM-DDTHH:MM:SS.ssssss+HH:MM
    value="2020-05-17T22:23:00+02:00"
    ans=datetime.datetime(2020,5,17,22,23,0,0,datetime.timezone(datetime.timedelta(hours=2)))
    assert ans==df.validate(value)
    # datetime format: YYYY-MM-DDTHH:MM:SS.ssssss
    value="2020-05-17T22:23:00"
    ans=datetime.datetime(2020,5,17,22,23,0,0)
    assert ans==df.validate(value)
    # datetime format: YYYY-MM-DDTH

# Generated at 2022-06-24 10:51:30.264104
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2020, 1, 1)) == '2020-01-01'


# Generated at 2022-06-24 10:51:32.369130
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    actual = TimeFormat().is_native_type(datetime.time())
    assert actual == True


# Generated at 2022-06-24 10:51:36.519711
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format=DateFormat()
    assert date_format.serialize(datetime.date(2020, 2, 14)) == '2020-02-14'
    assert date_format.serialize(None) == None


#Unit test for method serialize of class TimeFormat

# Generated at 2022-06-24 10:51:39.348151
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dt = datetime.datetime.now()
    date = datetime.date.today()
    time_ = datetime.time()
    df = DateTimeFormat()
    assert df.is_native_type(dt)
    assert not df.is_native_type(date)
    assert not df.is_native_type(time_)

# Generated at 2022-06-24 10:51:43.840426
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
	'''
	Create format for DateTime
	'''
	test_DateTime = DateTimeFormat()

	assert test_DateTime.errors == {'format': 'Must be a valid datetime format.', 'invalid': 'Must be a real datetime.'}


# Generated at 2022-06-24 10:51:48.407607
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time(3,0,0,0)
    assert TimeFormat().serialize(obj) == "03:00:00.000000" 

if __name__ == "__main__":
    test_TimeFormat_serialize()

# Generated at 2022-06-24 10:51:58.126363
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
	assert UUIDFormat().is_native_type(uuid.UUID("6519e103-b432-42fb-b5f8-7b1c990b2dd7")) == True
	assert UUIDFormat().is_native_type(uuid.UUID("6519e103-b432-42fb-b5f8-7b1c990b2dd")) == False
	assert UUIDFormat().is_native_type(uuid.uuid4()) == True
	assert UUIDFormat().is_native_type(uuid.UUID("6519e103-b432-42fb-b5f8-7b1c990b2dd")) == False

# Generated at 2022-06-24 10:52:02.954458
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uf = UUIDFormat()
    id = uf.serialize(uuid.UUID("6445c4c0-4660-4f4f-bf5a-a539eab5d5c5"))
    assert id == "6445c4c0-4660-4f4f-bf5a-a539eab5d5c5"


# Generated at 2022-06-24 10:52:04.095280
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    assert bf.errors == {}

# Generated at 2022-06-24 10:52:08.752839
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    class MyUUIDFormat(UUIDFormat):
        def __init__(self, *args, **kwargs):
            super(MyUUIDFormat, self).__init__(*args, **kwargs)
    UUID1 = uuid.uuid4()
    a = MyUUIDFormat(default=UUID1)
    assert a.serialize(UUID1) == str(UUID1)

# Generated at 2022-06-24 10:52:18.936667
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format1 = DateFormat()
    date_format1.validate("2019-03-08")
    date_format1.validate("2019-3-8")
    date_format1.validate("2019-3-08")
    date_format1.validate("2019-03-8")
    #date_format1.validate("2019-03-8-")
    #date_format1.validate("2019-03-8+")
    #date_format1.validate("2019-03-8T")
    #date_format1.validate("2019-03-08T")
    #date_format.validate("2019-03-08-")
    #date_format.validate("2019-03-08+")
    #date_format.validate("2019-03-08T")

#

# Generated at 2022-06-24 10:52:20.509251
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    BaseFormat.errors = {"any": "any"}
    assert BaseFormat().validation_error("any").code == "any"

# Generated at 2022-06-24 10:52:21.309893
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    s = UUIDFormat()
    return s

# Generated at 2022-06-24 10:52:24.021351
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    d = DateTimeFormat()
    assert d.validate("2020-05-10T20:00:00+05:30") == datetime.datetime(2020, 5, 10,20,0,0,tzinfo=datetime.timezone(datetime.timedelta(hours=5.5)))


# Generated at 2022-06-24 10:52:25.224225
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    f = BaseFormat()
    assert f.validation_error("a") is not None

# Generated at 2022-06-24 10:52:26.446112
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_object = TimeFormat()
    assert time_object != None

# Generated at 2022-06-24 10:52:28.701578
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    time = datetime.time(12, 30, 30)
    assert time_format.serialize(time) == "12:30:30"

# Generated at 2022-06-24 10:52:31.739609
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    input = "12:12:12.333333"
    time_format = TimeFormat()
    result = time_format.validate(input)
    assert result == datetime.time(12, 12, 12, 333333)


# Generated at 2022-06-24 10:52:32.607867
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat.errors == {}


# Generated at 2022-06-24 10:52:38.644053
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    # Parameters
    obj = uuid.UUID('d0c84ace-e6f8-c9a9-41a0-af5b6c8e4426')
    # Procedure call
    isNative = UUIDFormat().is_native_type(obj)
    # Verification
    assert isNative

# Generated at 2022-06-24 10:52:40.992431
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    value = datetime.time(10,0,0)
    output = TimeFormat().serialize(value)
    assert output == "10:00:00"


# Generated at 2022-06-24 10:52:50.426115
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_format = DateTimeFormat()
    str_result = datetime_format.serialize(datetime.datetime(2020, 2, 10, 15, 4, 55, 888000, tzinfo=datetime.timezone(datetime.timedelta(hours=8), "Nanjing Standard Time")))
    assert str_result == "2020-02-10T07:04:55.888000Z"


# Generated at 2022-06-24 10:52:53.735148
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    t = datetime.time(12, 34, 56, 123456)
    tf = TimeFormat()
    assert tf.serialize(t) == "12:34:56.123456"


# Generated at 2022-06-24 10:52:56.489067
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uf = UUIDFormat()
    a = uuid.uuid4()
    b = uf.validate(str(a))

    assert a == b

# Generated at 2022-06-24 10:52:59.620708
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    instance = BaseFormat()
    try:
        instance.serialize(None)
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-24 10:53:02.790190
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uf = UUIDFormat()
    assert uf.serialize(uuid.uuid4()) is not None


# Generated at 2022-06-24 10:53:09.205605
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt_format = DateTimeFormat()
    date_time = "2020-08-01T17:50:00.000000+08:00"
    try:
        result = dt_format.validate(date_time)
        print(result)
    except ValidationError as err:
        print(err.code)
        print(err.text)
    except Exception as err:
        print(err)


# Generated at 2022-06-24 10:53:11.709636
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    result = time_format.validate('00:00:00')
    assert result == datetime.time(0, 0)



# Generated at 2022-06-24 10:53:13.091566
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_format = TimeFormat()
    assert time_format


# Generated at 2022-06-24 10:53:22.894809
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dtf = DateTimeFormat()
    assert dtf.serialize(datetime.datetime(2020,10,10,0,0,0,0,tzinfo=datetime.timezone.utc)) == "2020-10-10T00:00:00+00:00"
    assert dtf.serialize(datetime.datetime(2020,10,10,0,0,0,0,tzinfo=datetime.timezone(datetime.timedelta(hours=5)))) == "2020-10-10T00:00:00+05:00"

# Generated at 2022-06-24 10:53:25.464557
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        fmt = BaseFormat()
        fmt.validate(1)


# Generated at 2022-06-24 10:53:26.078539
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert False

# Generated at 2022-06-24 10:53:26.929439
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert isinstance(TimeFormat(), TimeFormat)


# Generated at 2022-06-24 10:53:29.733651
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.datetime.strptime('03:45:00', '%H:%M:%S')
    assert TimeFormat().serialize(obj) == '03:45:00'

# Generated at 2022-06-24 10:53:34.749388
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = datetime.time(12, 10)
    assert TimeFormat().validate("12:10") == time
    assert TimeFormat().validate("12:10:12") == datetime.time(12, 10, 12)
    assert TimeFormat().validate("12:10:12.123456") == datetime.time(12, 10, 12, 123456)
    assert TimeFormat().validate("12:10:12.123") == datetime.time(12, 10, 12, 123000)



# Generated at 2022-06-24 10:53:42.766129
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    from datetime import datetime, time

    t = TimeFormat()

    # Check object None
    assert t.serialize(None) is None

    # Check object is time
    assert t.serialize(time(3, 4, 5)) == '03:04:05'

# Generated at 2022-06-24 10:53:43.739001
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    bf.errors = {}



# Generated at 2022-06-24 10:53:46.122327
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    f = TimeFormat()
    assert f.serialize(datetime.time(hour=12, minute=34, second=56)) == "12:34:56"



# Generated at 2022-06-24 10:53:51.268532
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    base_format = BaseFormat()
    with pytest.raises(NotImplementedError, match = "^.* should be implemented in child class."):
        base_format.is_native_type("aaa")



# Generated at 2022-06-24 10:53:54.697256
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    df = BaseFormat()
    try:
        df.validate()
    except NotImplementedError as ne:
        assert True
    else:
        assert False


# Generated at 2022-06-24 10:53:58.993093
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat().errors == {"format": "Must be a valid time format.", "invalid": "Must be a real time."}

# Generated at 2022-06-24 10:54:07.458582
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert issubclass(UUIDFormat, BaseFormat)
    assert UUIDFormat.is_native_type(None) is False
    assert UUIDFormat.is_native_type("abcdef") is False
    assert UUIDFormat.is_native_type("abcdef-abcdef-abcdef-abcdef") is False
    assert UUIDFormat.is_native_type("abcdef-abcdef-abcdef-abcdef-abcdef") is False
    assert UUIDFormat.is_native_type("00000000-0000-0000-0000-000000000000") is False
    assert UUIDFormat.is_native_type(uuid.UUID("00000000-0000-0000-0000-000000000000"))


# Generated at 2022-06-24 10:54:08.364802
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat()

# Generated at 2022-06-24 10:54:09.785065
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(2017, 1, 1)
    df = DateFormat()
    assert df.serialize(obj) == "2017-01-01"


# Generated at 2022-06-24 10:54:13.556823
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    class TestDateFormat(DateFormat):
        pass
    tdf = TestDateFormat()
    test = tdf.serialize(datetime.date(2019, 5, 20))
    assert test == '2019-05-20'


# Generated at 2022-06-24 10:54:21.436044
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    print("unit test for constructor of class UUIDFormat")
    u1 = UUIDFormat()
    print(u1.errors)

    print("unit test for function is_native_type")
    u = uuid.uuid4()
    print(u1.is_native_type(u))

    print("unit test for function validate")
    try:
        print(u1.validate("123"))
    except ValidationError:
        print("error")

    print("unit test for function serialize")
    print(u1.serialize(u))


# Generated at 2022-06-24 10:54:29.519866
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time(10, 29, 0, 20)) == True
    assert TimeFormat().is_native_type(datetime.datetime(10, 29, 0, 20)) == False
    assert TimeFormat().is_native_type(datetime.timedelta(10, 10)) == False
    assert TimeFormat().is_native_type(datetime.date(10, 29, 0)) == False
    assert TimeFormat().is_native_type(datetime.timezone(datetime.timedelta(10, 10))) == False


# Generated at 2022-06-24 10:54:34.982711
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    dateFormat = DateFormat()
    # value is instance of datetime.date
    value = datetime.date(2000,1,1)
    assert dateFormat.is_native_type(value) == True
    
    # value is not instance of datetime.date
    value = "2000-01-01"
    assert dateFormat.is_native_type(value) == False


# Generated at 2022-06-24 10:54:37.224812
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert tf.errors == {
        "format": "Must be a valid time format.",
        "invalid": "Must be a real time.",
    }


# Generated at 2022-06-24 10:54:39.183130
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    UUIDFormat().validate("1234")


# Generated at 2022-06-24 10:54:45.495605
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    print('========= test: DateTimeFormat serialize =========')
    datetime = '1900-01-01T02:30:00Z'
    dt = DateTimeFormat().validate(datetime)
    serialize = DateTimeFormat().serialize(dt)
    print(dt)
    print(serialize)
    print(DateTimeFormat().is_native_type(dt))
    print(DateTimeFormat().is_native_type(serialize))
    print(type(dt))
    print(type(serialize))


# Generated at 2022-06-24 10:54:49.424494
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    A = TimeFormat()
    B = A.validate("23:59:59.999999")
    assert str(B) == "23:59:59.999999"
    with pytest.raises(ValidationError):
        A.validate("24:00:00")


# Generated at 2022-06-24 10:54:52.366026
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = UUIDFormat().serialize(1)
    # Test for function type conversion
    assert type(obj) == str
    # Test function output
    assert obj == "1"



# Generated at 2022-06-24 10:55:01.891946
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # make sure we can pass through a valid date time
    dt = datetime.datetime.now()
    dt_string = dt.isoformat()
    dt_2 = DateTimeFormat().validate(dt_string)
    assert dt_2 == dt

    dt_string = "2014-06-16T17:03:14.4999Z"
    dt_2 = DateTimeFormat().validate(dt_string)
    assert dt_2 == datetime.datetime(2014, 6, 16, 17, 3, 14, 4999, tzinfo=datetime.timezone.utc)

    dt_string = "2014-06-16T17:03:14.499905-05:00"
    dt_2 = DateTimeFormat().validate(dt_string)

# Generated at 2022-06-24 10:55:02.724223
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidFormat = UUIDFormat()

# Generated at 2022-06-24 10:55:07.521093
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    fmt = UUIDFormat()
    fmt.validate('f8736c3e-b2a8-47a9-9d87-d5f5e5ff5c84')
    try:
        fmt.validate('1')
    except ValidationError as e:
        assert e.args[0] == 'Must be valid UUID format.'
        assert e.args[1] == 'format'



# Generated at 2022-06-24 10:55:09.028940
# Unit test for constructor of class DateFormat
def test_DateFormat():
	datef = DateFormat()
	assert datef is not None, "datef should not be empty"


# Generated at 2022-06-24 10:55:12.601035
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert df.serialize(None) is None
    assert df.serialize(datetime.date(2020, 4, 1)) == "2020-04-01"


# Generated at 2022-06-24 10:55:15.135435
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format = DateTimeFormat()
    assert datetime.datetime(2020,9,9) == format.is_native_type(datetime.datetime(2020,9,9))


# Generated at 2022-06-24 10:55:16.648669
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    assert isinstance(uuid_format, BaseFormat)

# Generated at 2022-06-24 10:55:18.645257
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    a = BaseFormat()
    assert a.serialize("hello") is None



# Generated at 2022-06-24 10:55:23.970580
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date = datetime.date(2010, 2, 8)
    print("-----")
    print("The original date is:", date)
    format_date = DateFormat.validate("2010-02-08")
    print("The format date is", format_date)
    assert format_date == date


# Generated at 2022-06-24 10:55:31.805560
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtf = DateTimeFormat()
    assert dtf.is_native_type(datetime.datetime.now()) is True
    assert dtf.is_native_type(datetime.date.today()) is False
    assert dtf.is_native_type(datetime.time()) is False
    assert dtf.is_native_type(datetime.datetime.now().date()) is False
    assert dtf.is_native_type(datetime.datetime.now().time()) is False
    assert dtf.is_native_type('2020-08-02T15:30:22.542000+00:00') is False
    

# Generated at 2022-06-24 10:55:36.963516
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    t1 = UUIDFormat()
    assert t1.serialize(uuid.uuid4()) != None
    assert t1.is_native_type(uuid.uuid4()) == True
    assert t1.validate('12345678-9abc-def0-1234-56789abcdef0') != None

# Generated at 2022-06-24 10:55:38.606137
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    b = BaseFormat()
    assert b.is_native_type(1) == False


# Generated at 2022-06-24 10:55:44.224535
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    
    d = DateFormat()
    assert d.is_native_type(datetime.date.today()) == True
    assert d.is_native_type(datetime.datetime.today()) == False
    

# Generated at 2022-06-24 10:55:47.019057
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()
    # b.is_native_type()
    # b.validate()
    # b.serialize()
    assert b

# Generated at 2022-06-24 10:55:49.293759
# Unit test for constructor of class DateFormat
def test_DateFormat():
    my_DateFormat = DateFormat()
    assert str(my_DateFormat) == "<DateFormat()>"



# Generated at 2022-06-24 10:55:56.447482
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    # time_format.validate("12:50") # error
    time_format.validate("12:50:00")
    time_format.validate("12:50:00.000000")
    time_format.validate("12:50:00.123456")
    # time_format.validate("12:50:00.1234567") # error
    time_format.validate("12:50:00.123456")

# Generated at 2022-06-24 10:55:58.751471
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert df.serialize(datetime.date(2020, 7, 20)) == '2020-07-20'

# Generated at 2022-06-24 10:56:06.178800
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    # Test cases where String value is a valid datetime format
    assert isinstance(DateTimeFormat().validate("2006-10-25T08:15:30"), datetime.datetime)
    assert isinstance(DateTimeFormat().validate("2006-10-25T08:15:30Z"), datetime.datetime)
    assert isinstance(DateTimeFormat().validate("2006-10-25T08:15:30+11:00"), datetime.datetime)
    assert isinstance(DateTimeFormat().validate("2006-10-25T08:15:30+11"), datetime.datetime)
    assert isinstance(DateTimeFormat().validate("2006-10-25T08:15:30-11:00"), datetime.datetime)

# Generated at 2022-06-24 10:56:10.726946
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("1971-04-21") == datetime.date(1971, 4, 21)

test_DateFormat_validate()

#Unit test for method validate of class TimeFormat

# Generated at 2022-06-24 10:56:13.214500
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert isinstance(DateFormat().is_native_type("2020-02-02"), bool)


# Generated at 2022-06-24 10:56:19.307446
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    uuid1 = 'd5b5eed5-12c5-4f15-a603-0c7d9fc61a02'
    uuid2 = 'e3b3f542-7e10-4dfb-9c9d-cbdb1fa82836'
    uuid3 = '049b77c4-c4e4-4d4a-8569-44ee970a4faf'
    uuid4 = '6ce2bf24-bc48-41d9-ba04-6e8c6f588440'
    uuid5 = '8a75b0ab-e39e-4caa-a857-c2393d6128a1'

# Generated at 2022-06-24 10:56:26.176974
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()
    assert timeformat.validate("10:00") == datetime.time(10)
    assert timeformat.validate("10:00:00") == datetime.time(10)
    assert timeformat.validate("10:00:00.123456") == datetime.time(10,0,0,123456)    


# Generated at 2022-06-24 10:56:29.640798
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():

    uuidFormat = UUIDFormat()

    assert uuidFormat is not None
    assert isinstance(uuidFormat, BaseFormat)


# Generated at 2022-06-24 10:56:35.141846
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format=UUIDFormat()
    x='faab2a83-ce3e-4d5a-865d-744e6e5b9c41'
    assert uuid_format.serialize(x)=='faab2a83-ce3e-4d5a-865d-744e6e5b9c41'



# Generated at 2022-06-24 10:56:40.830757
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    input_output = [
        # Valid format
        [datetime.datetime(2020, 1, 4, 1, 2, 3),True],
        # Invalid format
        [datetime.datetime(2020, 1, 4, 1, 2, 3, 1234567), False]
    ]

    test = DateTimeFormat()
    for case in input_output:
        assert test.is_native_type(case[0]) == case[1]


# Generated at 2022-06-24 10:56:44.677558
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize(uuid.UUID('d445ddda-4b7a-4c01-932a-59d1c0028397')).replace('-', '') == 'd445ddda4b7a4c01932a59d1c0028397'

# Generated at 2022-06-24 10:56:46.862601
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert(UUIDFormat().is_native_type(uuid.uuid4()))


# Generated at 2022-06-24 10:56:55.998315
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t1 = TimeFormat()
    assert(t1.validate("00:00") == datetime.time(0,0))
    assert(t1.validate("00:00:01") == datetime.time(0,0,1))
    assert(t1.validate("00:00:01.23456789") == datetime.time(0,0,1,234567))
    assert(t1.validate("23:59:59.999999") == datetime.time(23,59,59,999999))
    assert(t1.validate("23:59:59.9999999") == datetime.time(23,59,59,999999))
    # check errors
    with pytest.raises(ValidationError):
        t1.validate("0")

# Generated at 2022-06-24 10:57:03.671572
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    test = UUIDFormat()
    obj = test.validate('fe2f54fa-f55b-48a8-867c-6fbc34bc8742')
    assert isinstance(obj, uuid.UUID)
#Unit test for serialize method of class UUIDFormat

# Generated at 2022-06-24 10:57:07.959586
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    input = '2019-12-12'
    output = datetime.date(2019, 12, 12)
    assert df.validate(input) == output


# Generated at 2022-06-24 10:57:13.716743
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    test_format = TimeFormat()
    assert isinstance(datetime.datetime.now().time(), datetime.time)
    assert test_format.is_native_type(datetime.datetime.now().time()) # Should pass


# Generated at 2022-06-24 10:57:15.622664
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    print(tf.is_native_type(True))


# Generated at 2022-06-24 10:57:17.195983
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    print("test DateFormat.serialize()")
    d = datetime.date(2020,1,1)
    df = DateFormat()
    result = df.serialize(d)
    assert result == "2020-01-01"


# Generated at 2022-06-24 10:57:18.482426
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidFormat = UUIDFormat()
    assert True or False


# Generated at 2022-06-24 10:57:20.422754
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_instance = datetime.date(2020, 1, 1)
    assert DateFormat().serialize(date_instance) == "2020-01-01"

# Generated at 2022-06-24 10:57:26.923221
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    new_date = datetime.date(2019, 10, 25)
    assert df.validate('2019-10-25') == new_date
    assert df.serialize(df.validate('2019-10-25')) == '2019-10-25'
    assert df.serialize(new_date) == '2019-10-25'
    assert df.validate('2019-10-25').year == 2019
    assert df.validate('2019-10-25').month == 10
    assert df.validate('2019-10-25').day == 25


# Generated at 2022-06-24 10:57:28.105108
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert str(BaseFormat()) == "<BaseFormat>"

# Generated at 2022-06-24 10:57:32.455581
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class BaseT(BaseFormat):
        def is_native_type(self, value):
            return isinstance(value, type(None))

        def validate(self, value):
            return value

    base = BaseT()
    assert base.serialize(None) == None
    assert base.serialize("abc") == "abc"

# Generated at 2022-06-24 10:57:36.301189
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date = datetime.datetime(year=2019, month=4, day=22, hour=9, minute=0)
    date_str = '2019-04-22T09:00:00Z'
    datetime_f = DateTimeFormat()
    serialized = datetime_f.serialize(date)
    assert serialized == date_str

# Generated at 2022-06-24 10:57:39.748532
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    assert isinstance(uuid_format, BaseFormat)

    assert not isinstance(uuid_format, DateTimeFormat)
    assert not isinstance(uuid_format, DateFormat)
    assert not isinstance(uuid_format, TimeFormat)


# Generated at 2022-06-24 10:57:41.585678
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    x = UUIDFormat()
    print(x)

# Generated at 2022-06-24 10:57:48.250833
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    # Test is_native_type() for class DateFormat using value datetime.date (YYYY-MM-DD)
    str1 = '2020-01-01'
    df = DateFormat()
    assert df.is_native_type(str1) == True
    
# Test is_native_type() for class DateFormat using value datetime.datetime (YYYY-MM-DD HH:MM:SS.NNNNNN)

# Generated at 2022-06-24 10:57:53.192330
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidFormat=UUIDFormat()
    assert isinstance(uuidFormat, UUIDFormat)

# No unit test for function validate because it only calls the function validation_error which can not be tested
# No unit test for function is_native_type because it is a method of a class and that class can not be instanciated
# No unit test for function serialize because it only returns a string

# Generated at 2022-06-24 10:57:57.945622
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    fmt = TimeFormat()
    assert fmt.serialize(None) is None
    assert fmt.serialize(datetime.time(23, 15, 23)) == "23:15:23"
    assert fmt.serialize(datetime.time(23, 15, 23, 123456)) == "23:15:23.123456"
    assert fmt.serialize(datetime.time(23, 15, 23, 1234567)) == "23:15:23.123456"
    assert fmt.serialize(datetime.time(23, 15, 23, 12345678)) == "23:15:23.123456"

# Generated at 2022-06-24 10:58:08.987623
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    d = DateFormat()
    assert d.is_native_type(datetime.date.today()) == True
    assert d.is_native_type(datetime.datetime.now()) == False
    assert d.is_native_type(datetime.timedelta(days=1)) == False
    assert d.is_native_type(str(datetime.date.today())) == False
    assert d.is_native_type(int(datetime.date.today().strftime("%d"))) == False
    assert d.is_native_type(float(datetime.date.today().strftime("%d"))) == False

# Unit tests for method validate of class DateFormat

# Generated at 2022-06-24 10:58:13.537880
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert isinstance(TimeFormat(), TimeFormat)


# Generated at 2022-06-24 10:58:16.462309
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    print(time)


# Generated at 2022-06-24 10:58:19.874921
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    u = UUIDFormat()
    res = u.validate("6ccd780c-baba-1026-9564-0040f4311e29")
    assert isinstance(res, uuid.UUID) == True


# Generated at 2022-06-24 10:58:21.263257
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    # Test when obj is None
    BaseFormat().serialize(None) ==  None


# Generated at 2022-06-24 10:58:24.838938
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    # create a test object
    time_format = TimeFormat()
    
    # create a time object
    time_obj = datetime.time()
    print(time_obj.isocalendar())
    #test if time object is native type
    assert(time_format.is_native_type(time_obj) == True)


# Generated at 2022-06-24 10:58:27.298454
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    print("Testing UUIDFormat constructor")
    # Check if it's instantiated correctly
    uuid_format = UUIDFormat()
    assert isinstance(uuid_format, UUIDFormat), "Unable to instantiate UUIDFormat"



# Generated at 2022-06-24 10:58:28.450628
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    bf = BaseFormat()
    assert bf.is_native_type(0) == True


# Generated at 2022-06-24 10:58:40.140241
# Unit test for method validate of class TimeFormat

# Generated at 2022-06-24 10:58:46.067786
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(None) is None, "TimeFormat().serialize(None) is None"

    # call serialize() method of class TimeFormat
    assert TimeFormat().serialize(datetime.time(12, 30, 20)) == '12:30:20', "TimeFormat().serialize(datetime.time(12, 30, 20)) is '12:30:20'"

# Generated at 2022-06-24 10:58:49.724886
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class MyFormat(BaseFormat):
        errors = {"format": "Must be a valid date time format."}
    
    date_format = MyFormat()
    error = date_format.validation_error("format")
    assert error.text == "Must be a valid date time format."
    assert error.code == "format"

# Generated at 2022-06-24 10:58:56.445794
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format1 = UUIDFormat()

    uuid_str = '12345678-1234-5678-1234-567812345678'

    try:
        assert format1.validate('12345678-1234-5678-1234-567812345678') == uuid.UUID(uuid_str)
    except ValidationError:
        assert False


# Generated at 2022-06-24 10:58:58.289049
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now())


# Generated at 2022-06-24 10:59:01.177619
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # type: () -> None
    d1 = datetime.date(year=1, month=1, day=1)
    assert DateFormat().serialize(d1) == d1.isoformat()

# Generated at 2022-06-24 10:59:02.825999
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    new_UUIDFormat=UUIDFormat()
    assert isinstance(new_UUIDFormat, UUIDFormat)

# Generated at 2022-06-24 10:59:06.943264
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(object())
    assert UUIDFormat().is_native_type(datetime.datetime.now())
    assert UUIDFormat().is_native_type(uuid.uuid4())
    assert not UUIDFormat().is_native_type("123")


# Generated at 2022-06-24 10:59:14.004391
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uid = UUIDFormat()
    try:
        str_uuid = "9b66ac0f-d8c3-4d98-a3ae-3cde8f40c2f9"
        uuid.UUID(str_uuid)
    except ValueError:
        pass
    try:
        val = uid.validate(str_uuid)
        assert(val)
    except:
        assert(False)