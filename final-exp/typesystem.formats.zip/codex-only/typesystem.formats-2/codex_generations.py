

# Generated at 2022-06-24 10:49:18.220615
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat.is_native_type(None) == NotImplementedError
    assert BaseFormat.validate(None) == NotImplementedError
    assert BaseFormat.serialize(None) == NotImplementedError


# Generated at 2022-06-24 10:49:21.633502
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.datetime(2020, 1, 1)) == True
    assert DateFormat().is_native_type(datetime.datetime(2020, 1, 1, 0, 0, 1)) == True
    assert DateFormat().is_native_type(datetime.time(0, 0)) == False


# Generated at 2022-06-24 10:49:23.833018
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():

    dtf = DateTimeFormat()
    dt = dtf.validate("2020-06-25T13:10:45.12345678+02:00")
    return (dt.isoformat())

if __name__ == "__main__":
    _return = test_DateTimeFormat_validate()
    print(_return)

# Generated at 2022-06-24 10:49:26.426286
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = "1:59"
    assert datetime.time(1, 59) == TimeFormat().validate(time)


# Generated at 2022-06-24 10:49:29.881322
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.datetime.now().time()
    f = TimeFormat()
    assert f.serialize(time) == time.isoformat()

# Generated at 2022-06-24 10:49:31.539122
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    x = DateTimeFormat()
    assert x
    assert isinstance(x, DateTimeFormat)


# Generated at 2022-06-24 10:49:34.479344
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_obj = uuid.uuid4()
    uuid_data = str(uuid_obj)
    result = UUIDFormat().validate(uuid_data)
    assert result == uuid_obj


# Generated at 2022-06-24 10:49:44.101170
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class BaseFormatTest:
        errors1 = {}

        def validation_error(self, code: str) -> ValidationError:
            try:
                return ValidationError(self.errors1[code])
            except KeyError:
                return ValidationError("")

    base_format_test: BaseFormatTest = BaseFormatTest()

    try:
        error: ValidationError = base_format_test.validation_error("error")
        print(error.code)
    except KeyError as e:
        assert False



# Generated at 2022-06-24 10:49:45.977287
# Unit test for constructor of class DateFormat
def test_DateFormat():
    d = DateFormat()
    assert isinstance(d, DateFormat)


# Generated at 2022-06-24 10:49:49.551869
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time = TimeFormat()
    assert time.is_native_type(1) == False
    assert time.is_native_type(None) == False
    assert time.is_native_type(datetime.time(1)) == True


# Generated at 2022-06-24 10:49:55.317186
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    t = datetime.time(10, 30, 00, tzinfo=datetime.timezone.utc)
    timeformat = TimeFormat()
    assert timeformat.serialize(t) == '10:30:00+00:00'
    t = datetime.time(10, 30, 00, tzinfo=datetime.timezone(-datetime.timedelta(hours=7)))
    assert timeformat.serialize(t) == '10:30:00-07:00'


# Generated at 2022-06-24 10:50:04.327765
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Testing a valid datetime
    today = datetime.date.today()
    date_format = DateFormat()
    assert date_format.validate(today.isoformat()) == today
    # Testing an invalid datetime
    try:
        date_format.validate("20-06-2002")
        assert False, "ValidationError not raised"
    except ValidationError:
        pass
    # Testing a bad formatted datetime
    try:
        date_format.validate("20/06/2002")
        assert False, "ValidationError not raised"
    except ValidationError:
        pass



# Generated at 2022-06-24 10:50:08.684990
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 2, 11)
    date_format = DateFormat()
    assert date_format.serialize(date) == '2020-02-11'


# Generated at 2022-06-24 10:50:15.334563
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    value = "21:39:35.048071"
    result = tf.validate(value)
    assert isinstance(result, datetime.time)
    assert result.isoformat() == value

    with pytest.raises(ValidationError) as exc_info:
        tf.validate("9" + value[1:])
    assert exc_info.value.code == "format"
    assert str(exc_info.value) == "Must be a valid time format."

    with pytest.raises(ValidationError) as exc_info:
        tf.validate("9:99:99")
    assert exc_info.value.code == "invalid"
    assert str(exc_info.value) == "Must be a real time."


# Generated at 2022-06-24 10:50:16.427499
# Unit test for constructor of class DateFormat
def test_DateFormat():
    dateformat = DateFormat()


# Generated at 2022-06-24 10:50:24.820706
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    # Test return is True if the input is datetime.date instance
    test_obj = DateFormat()
    assert test_obj.is_native_type(datetime.date(2020, 1, 1)) == True

    # Test return is False if the input is not a datetime.date instance
    test_obj = DateFormat()
    assert test_obj.is_native_type("2020-01-01") == False

    # Test return is False if the input is not a datetime.date instance
    test_obj = DateFormat()
    assert test_obj.is_native_type(2020) == False


# Generated at 2022-06-24 10:50:31.434887
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class TestFormat(BaseFormat):
        def validate(self, value: typing.Any) -> typing.Union[typing.Any, ValidationError]:
            if value == 'a':
                return value
            else:
                raise self.validation_error("invalid")

    format = TestFormat()
    assert format.validate('a') == 'a'
    try:
        format.validate('b')
        assert False
    except ValidationError as e:
        assert e.code == 'invalid'


# Generated at 2022-06-24 10:50:32.214518
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    timeFormat = TimeFormat()

# Generated at 2022-06-24 10:50:35.175924
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    baseFormat = BaseFormat()
    with pytest.raises(NotImplementedError):
        baseFormat.is_native_type("not important")


# Generated at 2022-06-24 10:50:37.132819
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    formato = DateTimeFormat()
    valor = datetime.date(1943, 3, 13)
    assert(formato.is_native_type(valor) == True)


# Generated at 2022-06-24 10:50:41.992723
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    print(__name__)
    print(TimeFormat.__name__)
    print(TimeFormat.validate.__name__)
    print(TimeFormat.validate.__doc__)
    test = TimeFormat()
    print(test)
    print(test.validate('21:16:00'))
    print(test.validate('21:16:00.123456'))

# Generated at 2022-06-24 10:50:44.147085
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    assert time_format.validate("01:12:34.567890") == datetime.time(1, 12, 34, 567890)

# Generated at 2022-06-24 10:50:44.955151
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat() is not None


# Generated at 2022-06-24 10:50:55.501896
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    xxx = TimeFormat()
    assert xxx.validate("12:24:58")
    # assert xxx.validate("12:24:58.123456")
    assert xxx.validate("12:24:58.123")
    assert xxx.validate("::")
    assert xxx.validate("::.")
    assert xxx.validate("::.123")
    assert xxx.validate("12:")
    assert xxx.validate("12::")
    assert xxx.validate("12:24:")
    assert xxx.validate("12:24:58.1234567")
    return True


# Generated at 2022-06-24 10:51:02.688277
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    """
    Test if the serialize method of the class DateTimeFormat
    works with valid format and invalid format data

    :return:
    """

    d = DateTimeFormat()
    # Following sample is a valid date format
    value = d.validate("2010-02-12T02:15:30.999999")

    assert d.serialize(value) == "2010-02-12T02:15:30.999999Z"

    # Following sample is a invalid date format
    try:
        d.validate("2010-02-1202:15")
    except Exception as e:
        msg = e.args[0]
        assert msg == "Must be a valid datetime format."

# Generated at 2022-06-24 10:51:09.892994
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():

    # test_has_native_type
    native_date = datetime.date(2019, 12, 25)
    date_format = DateFormat()
    assert date_format.is_native_type(native_date) is True

    # test_not_has_native_type
    non_native_date = datetime.date(2019, 12, 26)
    date_format = DateFormat()
    assert date_format.is_native_type(non_native_date) is False


# Generated at 2022-06-24 10:51:10.721798
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    s = TimeFormat()


# Generated at 2022-06-24 10:51:16.264274
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    dates = [[2020, 6, 1],
             [2019, 6, 1],
             [None, None, None],
             [9999, 12, 31],
             [2000, 1, 1]]

    for a, b, c in dates:
        if None not in [a, b, c]:
            var = datetime.date(a, b, c)
        else:
            var = None
        serialized_var = DateFormat().serialize(var)
        assert isinstance(serialized_var, str)


# Generated at 2022-06-24 10:51:17.153204
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    fo = TimeFormat()


# Generated at 2022-06-24 10:51:22.012682
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # test for a real date
    validator = DateFormat()
    value = validator.validate("1914-11-18")
    assert value == datetime.date(1914, 11, 18)

    # test for an invalid date
    with pytest.raises(ValidationError):
        validator.validate("1914-11-a")


# Generated at 2022-06-24 10:51:27.096512
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    assert uuid_format.serialize('2a61ccdc-572d-11ea-bc55-0242ac130003') == '2a61ccdc-572d-11ea-bc55-0242ac130003'

# Generated at 2022-06-24 10:51:29.226236
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    try:
        TimeFormat()
    except NotImplementedError:
        print("Constructor of class TimeFormat successfully instantiated")


# Generated at 2022-06-24 10:51:31.933471
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    bf = BaseFormat()
    assert bf.serialize(None) == None


# Generated at 2022-06-24 10:51:38.694563
# Unit test for constructor of class DateFormat
def test_DateFormat():
    DATE_REGEX = re.compile(r"(?P<year>\d{4})-(?P<month>\d{1,2})-(?P<day>\d{1,2})$")
    assert DATE_REGEX.match("2019-02-13") == True


# Generated at 2022-06-24 10:51:49.850562
# Unit test for method validate of class BaseFormat

# Generated at 2022-06-24 10:51:53.053762
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    obj = BaseFormat()
    code="code2"
    text = obj.errors[code].format("x", "y", "z")
    a = obj.validation_error("code2")
    assert a.text == text
    assert a.code == code

# Generated at 2022-06-24 10:51:55.151207
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    obj=UUIDFormat()
    assert isinstance(obj,UUIDFormat)

# Generated at 2022-06-24 10:51:57.373554
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) is True
    assert DateTimeFormat().is_native_type("foo") is False


# Generated at 2022-06-24 10:52:06.666973
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat().is_native_type(datetime.date.today()) == True
    assert DateFormat().is_native_type(datetime.datetime.now()) == False
    assert DateFormat().is_native_type("") == False
    assert DateFormat().is_native_type("2020-03-04") == False
    assert DateFormat().serialize(datetime.date.today()) == datetime.date.today().isoformat()
    assert DateFormat().serialize(None) == None
    assert DateFormat().validate("2020-03-04") == datetime.date(2020, 3, 4)
    assert DateFormat().validate("2020-5-5") == datetime.date(2020, 5, 5)
    assert DateFormat().validate("2020-5-5") == datetime.date(2020, 5, 5)


# Generated at 2022-06-24 10:52:14.949887
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
	tf1 = TimeFormat()
	assert tf1.errors == {
		'format': 'Must be a valid time format.',
		'invalid': 'Must be a real time.'
	}

	try:
		tf1.validate('23:34:56.123456Z')
	except:
		pass
	else:
		raise AssertionError('TimeFormat.validate() did not work as expected')

	try:
		tf1.validate('23:34:56.123456+01:00')
	except:
		pass
	else:
		raise AssertionError('TimeFormat.validate() did not work as expected')

	try:
		tf1.validate('23:34:56.123456-01')
	except:
		pass

# Generated at 2022-06-24 10:52:17.841761
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    BaseFormat()

# Generated at 2022-06-24 10:52:21.133599
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid1())
    assert not UUIDFormat().is_native_type('359431da-5e7e-11ea-bc55-0242ac130003')
    assert not UUIDFormat().is_native_type(1)


# Generated at 2022-06-24 10:52:22.948143
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class SpecificFormat(BaseFormat):
        errors = {"format": "Specific format error"}

    assert SpecificFormat().validation_error('format').text == 'Specific format error'

# Generated at 2022-06-24 10:52:27.054960
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    datetimestr = "2019-10-15T00:00:00.00Z"
    value = datetime_format.validate(datetimestr)
    print(datetime.datetime.now())
    print(value)

# test_DateTimeFormat_validate()

# Generated at 2022-06-24 10:52:29.760814
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type("8d3a25a3-f19f-4fd9-8db7-e9add93496e9") == False


# Generated at 2022-06-24 10:52:34.282360
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    class CheckDateTime(DateTimeFormat):
        pass
    # Check when value is a datetime.datetime
    value = datetime.datetime.now()
    assert CheckDateTime().is_native_type(value)
    # Check when value is not a datetime.datetime
    value = datetime.date.today()
    assert not CheckDateTime().is_native_type(value)


# Generated at 2022-06-24 10:52:36.795388
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date.today()) == datetime.date.today().isoformat()



# Generated at 2022-06-24 10:52:40.325655
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    t.validate("11:09")
    t.validate("11:09:09")
    t.validate("11:09:09.09")

# Generated at 2022-06-24 10:52:49.841914
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    class BaseFormatTest(BaseFormat):
        pass

    # Verify that the errors dictionary is created
    assert BaseFormatTest.errors == {}

    # Test the validation_error function
    BaseFormatTest.errors = {"format" : "Bad format."}
    format_test = BaseFormatTest()
    assert format_test.validation_error("format") == ValidationError("Bad format.", "format")

    # Test the is_native_type function
    with pytest.raises(NotImplementedError):
        format_test.is_native_type(1)

    # Test the validate function
    with pytest.raises(NotImplementedError):
        format_test.validate(1)

    # Test the serialize function

# Generated at 2022-06-24 10:52:51.182444
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(10,11,12,13)) == "10:11:12.000013"


# Generated at 2022-06-24 10:53:01.426023
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2017-03-23T02:05:34") == datetime.datetime(2017, 3, 23, 2, 5, 34)
    assert date_time_format.validate("2017-03-23T02:05:34.123456") == datetime.datetime(2017, 3, 23, 2, 5, 34, 123456)
    assert date_time_format.validate("2017-03-23T02:05:34.1234567") == datetime.datetime(2017, 3, 23, 2, 5, 34, 123456)

# Generated at 2022-06-24 10:53:04.269527
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert isinstance(DateTimeFormat().is_native_type(datetime.date()),bool)
    

# Generated at 2022-06-24 10:53:05.779073
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    assert bf is not None
    assert bf.errors == {}


# Generated at 2022-06-24 10:53:08.829876
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d = datetime.date(year=2019, month=1, day=1)
    f = DateFormat()
    assert f.serialize(d) == '2019-01-01'


# Generated at 2022-06-24 10:53:12.004361
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # Assign
    uf = UUIDFormat()

    # Act
    # Assert
    assert uf.validation_error("format") == ValidationError(text="Must be valid UUID format.", code="format")


# Generated at 2022-06-24 10:53:13.209653
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert test_UUIDFormat.__name__ == "test_UUIDFormat"

# Generated at 2022-06-24 10:53:16.620597
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat = DateFormat()
    try:
        dateformat.validate('2020-05-11')
    except Exception as err:
        assert err.text == 'Must be a real date.'
        assert err.code == 'invalid'


# Generated at 2022-06-24 10:53:19.625798
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class Format(BaseFormat):
        errors = {"format": "Must be valid format."}

    format = Format()
    assert format.validation_error("format").text == "Must be valid format."


# Generated at 2022-06-24 10:53:26.536172
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    assert datetime_format.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))
    assert datetime_format.validate("2020-10-30T00:00:00Z") == datetime.datetime(2020, 10, 30, 0, 0, 0, 0, datetime.timezone.utc)
    assert datetime_format.validate("2020-10-30T00:00:00") == datetime.datetime(2020, 10, 30, 0, 0, 0, 0, None)


# Generated at 2022-06-24 10:53:29.013224
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    date = datetime.date(2019, 3, 2)
    assert isinstance(date, datetime.date)
    assert date == datetime.date(2019, 3, 2)

# Generated at 2022-06-24 10:53:31.026607
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = uuid.uuid4()
    uf = UUIDFormat()
    assert(uf.serialize(u) == str(u))

# Generated at 2022-06-24 10:53:40.342797
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(1, 2, 3, 4)
    assert TimeFormat().serialize(time) == '01:02:03.000004'
    time = datetime.time(1, 2, 3)
    assert TimeFormat().serialize(time) == '01:02:03'
    time = datetime.time(1, 2)
    assert TimeFormat().serialize(time) == '01:02'
    time = datetime.time(1)
    assert TimeFormat().serialize(time) == '01:00'
    time = datetime.time(0)
    assert TimeFormat().serialize(time) == '00:00'


# Generated at 2022-06-24 10:53:45.844069
# Unit test for method serialize of class DateTimeFormat

# Generated at 2022-06-24 10:53:57.899224
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    fmt = TimeFormat()

    obj = fmt.validate("18:42")
    assert isinstance(obj, datetime.time)

    obj = fmt.validate("18:42:11")
    assert isinstance(obj, datetime.time)

    obj = fmt.validate("18:42:11.123")
    assert isinstance(obj, datetime.time)

    obj = fmt.validate("18:42:11.123123")
    assert isinstance(obj, datetime.time)

    obj = fmt.validate("18:42:11.123456")
    assert isinstance(obj, datetime.time)

    with pytest.raises(ValidationError):
        # Invalid time
        fmt.validate("18:42:99")


# Generated at 2022-06-24 10:54:02.534721
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    assert tf.serialize(datetime.time(11,41,42)) == '11:41:42'

    assert tf.serialize(None) ==None
    #assert tf.serialize() == None



# Generated at 2022-06-24 10:54:04.906860
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidFormat = UUIDFormat()
    assert isinstance(uuidFormat, BaseFormat)

# Unit test of method is_native_type for class UUIDFormat

# Generated at 2022-06-24 10:54:07.633236
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    baseformat = BaseFormat()
    try:
        baseformat.validation_error("")
    except Exception as error:
        assert str(error) == "validation_error() not implemented."


# Generated at 2022-06-24 10:54:14.458996
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # If value is invalid, raise validation_error function
    test1 = TimeFormat()
    assert test1.validate("23:11:00") == datetime.time(23, 11)
    try:
        test1.validate("error")
    except Exception as e:
        assert e.code == "format"
    try:
        test1.validate("50:11:00")
    except Exception as e:
        assert e.code == "invalid"

# Generated at 2022-06-24 10:54:17.414623
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    bf = BaseFormat()
    try:
        bf.validate("abcd")
    except Exception as ex:
        assert type(ex) == NotImplementedError


# Generated at 2022-06-24 10:54:21.529564
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class Format(BaseFormat):
        errors = {"format": "Must be valid format."}

    fmt = Format()
    err = fmt.validation_error("format")
    assert err.text == "Must be valid format."
    assert err.code == "format"

# Generated at 2022-06-24 10:54:25.602382
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    class_uuid = UUIDFormat()
    uuid_call = uuid.uuid4()
    assert class_uuid.is_native_type(uuid_call) == True


# Generated at 2022-06-24 10:54:26.589190
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat()



# Generated at 2022-06-24 10:54:30.015688
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base_format = BaseFormat()
    validation_error = base_format.validation_error("format")
    print(validation_error)
    assert validation_error.text == "Must be a valid format."
    assert validation_error.code == "format"


# Generated at 2022-06-24 10:54:34.411461
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize('0c455875-28ff-4f1e-a1b2-3ad9aae8d8a0') == '0c455875-28ff-4f1e-a1b2-3ad9aae8d8a0'


# Generated at 2022-06-24 10:54:39.608534
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    value = UUIDFormat().serialize(uuid.UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert value == '123e4567-e89b-12d3-a456-426655440000'

# Generated at 2022-06-24 10:54:45.370674
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    executor = UUIDFormat()
    assert executor.is_native_type('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa') == True
    assert executor.validate('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa') == 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
    assert executor.serialize('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa') == 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'



# Generated at 2022-06-24 10:54:53.879390
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    tz = datetime.timezone(datetime.timedelta(hours=+1))
    time1 = datetime.time(23, 59, 59, 999999, tz)
    ans1 = "23:59:59.999999+01:00"
    assert tf.serialize(time1) == ans1

    tz = datetime.timezone(datetime.timedelta(hours=-2))
    time2 = datetime.time(1, 2, 3, 456, tz)
    ans2 = "01:02:03.000456-02:00"
    assert tf.serialize(time2) == ans2

    time3 = datetime.time(1, 2, 3, 456, None)
    ans3 = "01:02:03.000456"
   

# Generated at 2022-06-24 10:54:57.597178
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(None) is None
    assert DateTimeFormat().serialize(datetime.datetime(2019,10,9,1,30)) == "2019-10-09T01:30:00" # return value is string


# Generated at 2022-06-24 10:55:00.750298
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class MyFormat(BaseFormat):
        native_type = int
    f = MyFormat()
    assert f.is_native_type(10)
    assert not f.is_native_type(10.0)


# Generated at 2022-06-24 10:55:04.183837
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    startDate = datetime.date(2020, 4, 5)
    startDate_serialized = df.serialize(startDate)
    assert startDate_serialized == '2020-04-05'


# Generated at 2022-06-24 10:55:06.779211
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    myformat = UUIDFormat()
    assert myformat.serialize(uuid.uuid4()) == str(uuid.uuid4())



# Generated at 2022-06-24 10:55:15.459854
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    # We should be able to construct from a valid string
    TimeFormat().validate('12:00:00')

    # We should be able to construct from a valid 
    with pytest.raises(ValidationError):
        TimeFormat().validate('12:60:00')
    
    # We should be able to construct from a valid string
    with pytest.raises(ValidationError):
        TimeFormat().validate('abc')
    
    # We should be able to construct from a valid string
    with pytest.raises(ValidationError):
        TimeFormat().validate('12:00:00:00')


# Generated at 2022-06-24 10:55:16.512088
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    s="09:30:00"
    f=TimeFormat()
    f.validate(s)

test_TimeFormat()


# Generated at 2022-06-24 10:55:19.211855
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    base_format = BaseFormat()
    with pytest.raises(NotImplementedError):
        base_format.validate(1)


# Generated at 2022-06-24 10:55:28.670266
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    value = "2020-04-15T12:45:21.476438Z"
    obj = datetime.datetime.strptime(value, '%Y-%m-%dT%H:%M:%S.%fZ')
    assert DateTimeFormat().serialize(obj) == value
    value = "2020-04-15T12:45:21.476438-04:00"
    obj = datetime.datetime.strptime(value, '%Y-%m-%dT%H:%M:%S.%f%z')
    assert DateTimeFormat().serialize(obj) == value


# Generated at 2022-06-24 10:55:30.014396
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uid = UUIDFormat()
    assert uid == uid


# Generated at 2022-06-24 10:55:33.173392
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    assert BaseFormat().validation_error('format') == ValidationError(text='Must be a valid date format.', code='format')


# Generated at 2022-06-24 10:55:35.070158
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(1)

# Generated at 2022-06-24 10:55:37.919750
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    timeFormat1 = TimeFormat()
    assert timeFormat1.errors == {
        "format": "Must be a valid time format.",
        "invalid": "Must be a real time.",
    }


# Generated at 2022-06-24 10:55:40.684175
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base_format = BaseFormat()
    assert base_format.errors == {}

# Generated at 2022-06-24 10:55:43.287263
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date_format = DateFormat()
    assert date_format.errors == {"format": "Must be a valid date format.", "invalid": "Must be a real date."}


# Generated at 2022-06-24 10:55:46.056574
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2019, 7, 5)) == True


# Generated at 2022-06-24 10:55:48.764596
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format_ = BaseFormat()
    msg = "msg"
    code = "code"
    error = format_.validation_error(code)
    assert error.code == code
    assert error.text == msg


# Generated at 2022-06-24 10:55:54.494936
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u = datetime.date(2020, 1, 1)
    assert u.isoformat() == "2020-01-01"

    l = datetime.date(2020, 1, 1)
    assert l.isoformat() == "2020-01-01"

    n = datetime.date(2020, 1, 1)
    assert n.isoformat() == "2020-01-01"

# Generated at 2022-06-24 10:55:56.906799
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat()
    assert DateFormat().is_native_type(datetime.date(2020, 1, 15))

# Generated at 2022-06-24 10:56:02.300592
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2020, 1, 31, 12, 23, 34, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(obj) == "2020-01-31T12:23:34Z"
    assert DateTimeFormat().serialize(None) == None

# Generated at 2022-06-24 10:56:04.299365
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    formato = DateFormat()
    exp1 = True
    obj1 = datetime.date(2004, 4, 1)
    assert formato.is_native_type(obj1) == exp1



# Generated at 2022-06-24 10:56:14.548912
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    test_empty                       = DateTimeFormat().serialize(x=None)
    test_date_from_iso_string_utc    = DateTimeFormat().serialize(x="2006-01-02T15:04:05.000000Z")
    test_date_from_iso_string_offset = DateTimeFormat().serialize(x="2006-01-02T15:04:05.000000+03:00")
    test_date_from_datetime          = DateTimeFormat().serialize(x=datetime.datetime(2006, 1, 2, 15, 4, 5))

    assert test_empty                   == None 
    assert test_date_from_iso_string_utc== "2006-01-02T15:04:05Z"

# Generated at 2022-06-24 10:56:19.273784
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(None) == False
    assert uuid_format.is_native_type(uuid.uuid4()) == True


# Generated at 2022-06-24 10:56:30.244128
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    """
    Unit test for method validate of class BaseFormat
    """
    print("Unit test for method validate of class BaseFormat")
    # Element to be tested
    param = {"type": "string"}
    # Error code to be tested
    error_code = "format"
    # Error message to be tested
    error_mesg = 'Must be a valid string.'

    # Call to the method validate
    result = BaseFormat.validate(param)

    # Test if the method validate has returned an error
    assert type(result) is ValidationError

    # Test if the error code is the expected
    assert result.code == error_code

    # Test if the error message is the expected
    assert result.text == error_mesg

    # Test if the error message is the expected

# Generated at 2022-06-24 10:56:39.450937
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    def is_native_type(value: typing.Any) -> typing.Any:
        assert value is not None
        return isinstance(value, datetime.time)

    def validate(value: typing.Any) -> datetime.time:
        assert value is not None
        return datetime.datetime.strptime(value, '%H:%M:%S').time()

    def serialize(obj):
        assert obj is not None
        return obj.isoformat()

    time = TimeFormat()
    assert time.is_native_type == is_native_type
    assert time.validate == validate
    assert time.serialize == serialize


# Generated at 2022-06-24 10:56:41.729630
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(
        uuid.UUID("00010203-0405-0607-0809-0a0b0c0d0e0f")
    )



# Generated at 2022-06-24 10:56:47.705395
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    from typesystem.base import ValidationError
    from typesystem.exceptions import Format

    code = "format"
    text = "Must be valid a date format."
    validation_error = Format.validation_error(code)
    assert isinstance(validation_error, ValidationError)
    assert validation_error.code == code
    assert validation_error.text == text


# Generated at 2022-06-24 10:56:56.586724
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    format = TimeFormat()

    value = format.validate("00:50:12.789Z")
    assert value.tzinfo == datetime.timezone.utc
    assert value.microsecond == 789000

    value = format.validate("00:50:12.789-05:30")
    assert value.tzinfo == datetime.timezone(datetime.timedelta(hours=-5, minutes=-30))
    assert value.microsecond == 789000

    value = format.validate("00:50:12.789+05:30")
    assert value.tzinfo == datetime.timezone(datetime.timedelta(hours=5, minutes=30))
    assert value.microsecond == 789000

    value = format.validate("00:50:12.789+05")
    assert value.tzinfo

# Generated at 2022-06-24 10:57:03.694977
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    value = "4dcd98e6-b40c-4a6c-8d3a-6a3a5ca7b34e"
    uuidformat = UUIDFormat()
    result = uuidformat.validate(value)
    assert isinstance(result, uuid.UUID)


# Generated at 2022-06-24 10:57:08.191979
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidFormat = UUIDFormat()
    uuid_value = uuid.uuid4()
    assert uuidFormat.validate(str(uuid_value)) == uuid_value
    assert uuidFormat.serialize(uuid_value) == str(uuid_value)
    assert uuidFormat.is_native_type(uuid_value) is True

# Generated at 2022-06-24 10:57:20.139090
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # negative test cases
    dt_format = DateFormat()
    try:
        dt_format.validate("10-22-20")
        assert False
    except ValidationError:
        assert True
    try:
        dt_format.validate("1990-20")
        assert False
    except ValidationError:
        assert True
    try:
        dt_format.validate("1990-20-10")
        assert False
    except ValidationError:
        assert True
    try:
        dt_format.validate("1990-10-20 22:22:22")
        assert False
    except ValidationError:
        assert True
    try:
        dt_format.validate("abc")
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-24 10:57:30.846465
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    test_cases = {
        'a': ValidationError,
        '2019-1-1': ValidationError,
        '2019-01-1': datetime.date(2019,1,1),
    }
    for test_case in test_cases:
        try:
            value = test_cases[test_case]
            res = DateFormat().validate(test_case)
            if isinstance(value,ValidationError):
                print(f'Test case failed: {test_case}')
            else:
                if value != res:
                    print(f'Test case failed: {test_case}')
        except:
            if not isinstance(value,ValidationError):
                print(f'Test case failed: {test_case}')

# Generated at 2022-06-24 10:57:37.189323
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("2017-01-01") == datetime.date(2017, 1, 1)
    assert df.validate("2017-02-28") == datetime.date(2017, 2, 28)
    assert df.validate("2016-02-29") == datetime.date(2016, 2, 29)
    assert df.validate("2000-02-29") == datetime.date(2000, 2, 29)
    assert df.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert df.validate("2019-12-31") == datetime.date(2019, 12, 31)


# Generated at 2022-06-24 10:57:49.613305
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # First test when value is a valid format
    date_time_format = DateTimeFormat()
    # test without timezone

# Generated at 2022-06-24 10:57:52.335483
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    input = datetime.datetime.now()
    output = DateTimeFormat().is_native_type(input)
    assert(output == True)


# Generated at 2022-06-24 10:57:55.310358
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf1 = TimeFormat()
    assert(tf1.is_native_type(datetime.time(15, 8, 27, 100000)))
    assert(not tf1.is_native_type(datetime.date(2019, 10, 18)))


# Generated at 2022-06-24 10:58:01.659406
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    # 創建一個DateTimeFormat的實例
    dt_format = DateTimeFormat()
    
    # 確認是否為一個合法的日期時間格式
    assert dt_format.validate("2020-01-03 12:10:22") == datetime.datetime(2020, 1, 3, 12, 10, 22)
    # 確認是否為一個合法的日期時間格式
    assert not dt_format.validate("2020-01-03 12:10:")
    # 確認是否為一個合法的日期時間

# Generated at 2022-06-24 10:58:04.501565
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date.today()) == True



# Generated at 2022-06-24 10:58:07.443935
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat.is_native_type(None)
    assert BaseFormat.is_native_type.__doc__ == 'is_native_type(value: typing.Any) -> bool\n\n    Must be implemented by subclasses.'


# Generated at 2022-06-24 10:58:12.505798
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    """
    test_UUIDFormat_serialize is a unit test for method serialize of class UUIDFormat
    """
    uuid_format = UUIDFormat()
    my_uuid = uuid.uuid4()
    assert uuid_format.serialize(my_uuid) == str(my_uuid)
    assert uuid_format.serialize(uuid.uuid4()) != str(my_uuid)


# Generated at 2022-06-24 10:58:15.484125
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
  # Check that the type is different than the base class
  assert(type(UUIDFormat()) != BaseFormat)


# Generated at 2022-06-24 10:58:18.062640
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    assert(uuid_format.serialize(uuid.uuid4()))


# Generated at 2022-06-24 10:58:21.984153
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    a = UUIDFormat()
    b = uuid.uuid4()
    c = "3b3a381c-6463-40a1-82e7-b5be5c5ffda2"
    assert a.is_native_type(b) == True
    assert a.is_native_type(c) == False


# Generated at 2022-06-24 10:58:26.735810
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    sample_date_time_string = "2019-06-16T15:59:20.327Z"
    sample_date_time_object = datetime.datetime(
        year=2019, month=6, day=16, hour=15, minute=59, second=20, microsecond=327000
    ).replace(tzinfo=datetime.timezone.utc)

    assert DateTimeFormat().serialize(sample_date_time_object) == sample_date_time_string

# Generated at 2022-06-24 10:58:28.177494
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    format = BaseFormat()
    str_test = "test"
    assert format.validate(str_test) == str_test


# Generated at 2022-06-24 10:58:30.248471
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b= BaseFormat()
    assert b.errors == {}

# Generated at 2022-06-24 10:58:34.999061
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat.is_native_type(datetime.time(12,34,56)) == True
    assert TimeFormat.is_native_type(datetime.date(1900, 9, 14)) == False
    assert TimeFormat.is_native_type(datetime.datetime.utcnow()) == False


# Generated at 2022-06-24 10:58:38.459707
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    import prueba2
    test = prueba2.BaseFormat()
    assert test.serialize(None) == None
    assert test.serialize(0) == 0
    assert test.serialize(b'0') == b'0'


# Generated at 2022-06-24 10:58:42.639975
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    from typesystem.types import Integer

    x = Integer(1, 100)
    try:
        x.validate(0)
    except ValidationError as e:
        assert e.code == "min_value"
    else:
        raise Exception("AssertionError")

# Generated at 2022-06-24 10:58:44.371296
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    format = TimeFormat()
    assert isinstance(format, BaseFormat)

# Generated at 2022-06-24 10:58:48.365705
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    # Test positive case
    try:
        a = TimeFormat()
    except:
        assert False
    
    # Test negative case
    try:
        a = TimeFormat()
    except Exception:
        assert False
    else:
        assert True

# Unit tests for is_native_type method of class TimeFormat

# Generated at 2022-06-24 10:58:49.251088
# Unit test for constructor of class DateFormat
def test_DateFormat():
    df = DateFormat()
    assert df


# Generated at 2022-06-24 10:58:50.850990
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date = DateFormat()
    print(date.validate("2020-01-27"))


# Generated at 2022-06-24 10:58:57.323231
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat().validate("1999-12-31T23:59:59.123456Z") == datetime.datetime(1999, 12, 31, 23, 59, 59, 123456)
    assert DateTimeFormat().validate("1999-12-31T23:59:59Z") == datetime.datetime(1999, 12, 31, 23, 59, 59)

# Generated at 2022-06-24 10:58:58.703328
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()
    assert isinstance(b, BaseFormat)


# Generated at 2022-06-24 10:59:07.000421
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    #Test for method validate(value: typing.Any) -> datetime.time
    time = TimeFormat()
    assert time.validate("10:20:30.123456")
    assert time.validate("00:00:00.1000000")
    assert time.validate("00:00:00.100000")
    assert time.validate("00:00:00.10000")
    assert time.validate("00:00:00.1000")
    assert time.validate("00:00:00.100")
    assert time.validate("00:00:00.10")
    assert time.validate("00:00:00.1")
    assert time.validate("00:00:00")
    assert time.validate("00:00")
    assert time.validate("00")

# Generated at 2022-06-24 10:59:09.585287
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    # FIXME: Need add assert here
    print("FIXME: Need add assert here")


# Generated at 2022-06-24 10:59:12.197615
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("1995-05-01") == datetime.date(1995, 5, 1)


# Generated at 2022-06-24 10:59:15.002310
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dateTimeFormat = DateTimeFormat()
    # Create a random datetime object
    dateTime = datetime.datetime.now()
    assert dateTimeFormat.is_native_type(dateTime)
