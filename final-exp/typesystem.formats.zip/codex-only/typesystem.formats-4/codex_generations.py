

# Generated at 2022-06-24 10:49:13.677315
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    format = BaseFormat()
    assert format.validate(None) == None

# Generated at 2022-06-24 10:49:18.806213
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    fmt = DateTimeFormat()
    dt = datetime.datetime(2019, 1, 15, 9, 0, 0, 0, datetime.timezone.utc)
    assert fmt.serialize(dt) == "2019-01-15T09:00:00+00:00"

# Generated at 2022-06-24 10:49:31.291181
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    f = TimeFormat()
    # Assert that the method serialize returns a string
    assert isinstance(f.serialize(datetime.time(12, 30, 45)), str)
    # Assert that the method serialize returns a string only if the parameter is not None
    assert f.serialize(None) is None
    # Assert that the method serialize returns the string with format hh:mm[:ss[.uuuuuu]][+HH:MM]
    assert f.serialize(datetime.time(12, 30, 45)) == "12:30:45"
    assert f.serialize(datetime.time(12, 30)) == "12:30"
    assert f.serialize(datetime.time(12)) == "12:00"

# Generated at 2022-06-24 10:49:35.160493
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # Arrange
    errors = {}
    errors["format"] = "Must be valid"
    errors["invalid"] = "Must be real"
    code = "test"
    base_format = BaseFormat()

    # Act
    base_format.errors = errors
    base_format.validation_error(code)

    # Assert
    assert base_format.validation_error("test") is not None


# Generated at 2022-06-24 10:49:40.047267
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    a = BaseFormat()
    try:
        a.validate("test")
    except NotImplementedError:
        pass
    assert True


# Generated at 2022-06-24 10:49:53.354144
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    from typesystem.base import Field
    from typesystem.fields import String

    field = Field(format="uuid")

    # Assert that a uuid is validated properly
    uuid_str = "5a2462e0-4c4e-4a4b-9d8b-8e2a2bdb0dfb"
    expected = uuid.UUID(uuid_str)
    result = field.validate(uuid_str)
    assert result == expected
    
    # Assert that a UUID object is validated properly
    uuid_ = uuid.UUID(uuid_str)
    result = field.validate(uuid_)
    assert result == expected
    
    # Assert that a string that is not a uuid raises a ValidationError

# Generated at 2022-06-24 10:49:55.226577
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    a = BaseFormat()
    assert a.is_native_type(1) == False

# Generated at 2022-06-24 10:50:05.264878
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    u1 = uuid.uuid4()
    u2 = uuid.UUID(int=0xFFFF)
    u3 = uuid.UUID('{00001111-2222-3333-4444-555566667777}')
    
    assert not UUIDFormat().is_native_type(str(u1))
    assert not UUIDFormat().is_native_type(str(u2))
    assert not UUIDFormat().is_native_type(str(u3))

    assert UUIDFormat().is_native_type(u1)
    assert UUIDFormat().is_native_type(u2)
    assert UUIDFormat().is_native_type(u3)


# Generated at 2022-06-24 10:50:08.682495
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    f = BaseFormat()
    if __name__ != '__main__':
        pytest.fail("expect ValueError", pytrace=False)


# Generated at 2022-06-24 10:50:21.643713
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dtf = DateTimeFormat()
    # test invalid, raise exception
    dt = datetime.datetime(2020,3,3,12,30,tzinfo=datetime.timezone(datetime.timedelta(hours=1,minutes=0)))
    try:
        dtf.serialize(dt)
        assert False
    except AssertionError:
        pass
    # test valid
    dt = datetime.datetime(2020,3,3,12,30,tzinfo=datetime.timezone.utc)
    res = dtf.serialize(dt)
    assert res == "2020-03-03T12:30:00Z"

# Generated at 2022-06-24 10:50:24.048679
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    if not isinstance(TimeFormat().is_native_type(datetime.time()), bool):
        raise AssertionError()


# Generated at 2022-06-24 10:50:25.254436
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtFormat = DateTimeFormat()
    

# Generated at 2022-06-24 10:50:32.732851
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_to_test = "5e5d5b5a-4d4c-4b4a-4e4d-4c4b4a4f4e4d"
    assert UUIDFormat().validate(uuid_to_test) == uuid.UUID(uuid_to_test)


DATE_FORMAT = DateFormat()
TIME_FORMAT = TimeFormat()
DATETIME_FORMAT = DateTimeFormat()
UUID_FORMAT = UUIDFormat()

# Generated at 2022-06-24 10:50:33.823565
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    a = UUIDFormat()
    

# Generated at 2022-06-24 10:50:36.017319
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
  try:
    BaseFormat().validate("")
  except NotImplementedError:
    return True
  else:
    return False


# Generated at 2022-06-24 10:50:40.538200
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert isinstance(uuid_format, BaseFormat)
    assert isinstance(uuid_format.errors, dict)
    assert uuid_format.validate("c9bf9e57-1685-4c89-bafb-ff5af830be8a") == uuid.UUID("c9bf9e57-1685-4c89-bafb-ff5af830be8a")


# Generated at 2022-06-24 10:50:47.941088
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # 1
    value = "2019-01-12T21:00:14.0Z"
    test_obj = DateTimeFormat()
    result = test_obj.validate(value)
    answer = datetime.datetime(2019, 1, 12, 21, 0, 14, 0, datetime.timezone.utc)
    assert result == answer

    # 2
    value = "2019-01-12T21:00:14.123Z"
    test_obj = DateTimeFormat()
    result = test_obj.validate(value)
    answer = datetime.datetime(2019, 1, 12, 21, 0, 14, 123000, datetime.timezone.utc)
    assert result == answer

    # 3
    value = "2019-01-12T21:00:14.123456Z"
   

# Generated at 2022-06-24 10:50:51.557163
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    base_format = BaseFormat()
    with pytest.raises(NotImplementedError):
        base_format.serialize('obj')


# Generated at 2022-06-24 10:51:01.578723
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    UUID1 = "180f47ec-205d-4bc1-81b4-7f8e8451042b"
    UUID2 = "180f47ec-205d-4bc1-81b4-7f8e8451042h"
    UUID3 = "8ulywejh-v5hw-mgkt-6yf8-knpk6w7rshov"

    # We expect this to be a valid format of UUID
    assert UUIDFormat().is_native_type(UUID1)
    # We expect this to be not a valid format of UUID
    assert not UUIDFormat().is_native_type(UUID2)
    # We expect this to be not a valid format of UUID
    assert not UUIDFormat().is_native_type(UUID3)

# Generated at 2022-06-24 10:51:05.022689
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat
    assert df.serialize(None) == None
    assert df.serialize(datetime.date(2020, 10, 11)) == '2020-10-11'


# Generated at 2022-06-24 10:51:08.958391
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    
    from typesystem.base import Type
    from typesystem import types
    import datetime
    from typing import Optional, Union, Any

    time = datetime.datetime(2020, 1, 6, 10, 23, 56, 703867)
    time_format = types.Time.format("%H:%M:%S.%f")
    timef = types.Time(format=time_format)
    result = timef.serialize(time)
    assert result == '10:23:56.703867'

# Generated at 2022-06-24 10:51:12.627797
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat.is_native_type == NotImplemented

test_BaseFormat_is_native_type()

# Unit Test for method validate of class BaseFormat

# Generated at 2022-06-24 10:51:15.782082
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(12, 34)
    assert time.isoformat() == "12:34:00"
    assert TimeFormat().serialize(time) == "12:34:00"


# Generated at 2022-06-24 10:51:17.111858
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    assert isinstance(BaseFormat().validate(""), ValidationError)



# Generated at 2022-06-24 10:51:19.836236
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    assert DateFormat().validate("2020-05-20") == datetime.date(2020, 5, 20)


# # Unit test for method validate of class DateFormat

# Generated at 2022-06-24 10:51:22.952109
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format = DateTimeFormat()
    assert format.is_native_type(datetime.datetime(2019, 1, 1, 0, 0, 0))
    assert not format.is_native_type('2019-01-01T00:00:00+00:00')

# Generated at 2022-06-24 10:51:30.604304
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    format = TimeFormat()

    assert format.validate("10:10:10") == datetime.time(10, 10, 10)
    assert format.validate("10:10") == datetime.time(10, 10)
    assert format.validate("10:10:10.00123") == datetime.time(10, 10, 10, 123)
    assert format.validate("10:10:10.00123456789") == datetime.time(10, 10, 10, 123456)



# Generated at 2022-06-24 10:51:39.149014
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2000, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=-5)))
    format = DateTimeFormat()
    assert format.serialize(obj) == '2000-01-01T05:00:00+00:00'

    obj = datetime.datetime(2000, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=-5, minutes=-30)))
    assert format.serialize(obj) == '2000-01-01T04:30:00+00:00'

    obj = datetime.datetime(2000, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=5)))

# Generated at 2022-06-24 10:51:40.499436
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(12, 30, 00, 000000)
    obj = TimeFormat()
    actual = obj.serialize(time)
    expected = "12:30:00"
    assert expected == actual

# Generated at 2022-06-24 10:51:41.602888
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    u = UUIDFormat()

# Generated at 2022-06-24 10:51:48.513738
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()
    assert format.validate("2020-06-01T12:15") == datetime.datetime(2020, 6, 1, 12, 15)
    assert format.validate("2020-06-01T12:15Z") == datetime.datetime(2020, 6, 1, 12, 15, tzinfo=datetime.timezone.utc)
    assert format.validate("2020-06-01T12:15:16") == datetime.datetime(2020, 6, 1, 12, 15, 16)
    assert format.validate("2020-06-01T12:15:16.123") == datetime.datetime(2020, 6, 1, 12, 15, 16, 123000)
    assert format.validate("2020-06-01T12:15:16.123456") == dat

# Generated at 2022-06-24 10:51:51.652459
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(1,1,1)) == True
    assert date_format.is_native_type(None) == False
    assert date_format.is_native_type(1) == False


# Generated at 2022-06-24 10:51:54.400925
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid1())
    assert UUIDFormat().is_native_type(uuid.uuid4())



# Generated at 2022-06-24 10:51:56.958534
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    datetime_format = DateTimeFormat()
    assert datetime_format.is_native_type(datetime.datetime.now())
    assert not datetime_format.is_native_type(datetime.date.today())

# Generated at 2022-06-24 10:52:01.364349
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    bf = BaseFormat()
    bf.errors['format'] = 'error test'
    print(bf.errors)
    print(bf.validation_error('format'))
if __name__ == "__main__":
    test_BaseFormat_validation_error()

# Generated at 2022-06-24 10:52:05.129939
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    print("test method validate of class TimeFormat")
    t1 = TimeFormat()
    try:
        t1.validate("00:00:00.000")
        print("Successful in test method validate of class TimeFormat")
    except:
        print("Failed in test method validate of class TimeFormat")


# Generated at 2022-06-24 10:52:08.201394
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    basef = BaseFormat()
    try:
        assert basef.is_native_type('2019-12-19') is False
    except NotImplementedError:
        print('test_BaseFormat_is_native_type is ok')


# Generated at 2022-06-24 10:52:16.266909
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    Time = TimeFormat()
    assert True == Time.is_native_type(datetime.time())
    assert True == Time.is_native_type(datetime.time(tzinfo=None))
    assert False == Time.is_native_type(None)
    assert False == Time.is_native_type(datetime.date(2020, 10, 10))
    assert False == Time.is_native_type(datetime.datetime(2020, 10, 10))
    assert False == Time.is_native_type(datetime.datetime(2020, 10, 10, tzinfo=None))
    assert False == Time.is_native_type(datetime.timedelta())

    assert datetime.time(hour=12, minute=10, second=15) == Time.validate("12:10:15")
    assert datetime

# Generated at 2022-06-24 10:52:18.999816
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    assert df.is_native_type(datetime.date(2010, 1, 1))
    assert not df.is_native_type(datetime.datetime(2010, 1, 1, 1, 1, 1))


# Generated at 2022-06-24 10:52:25.345775
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    date_text = date.validate('2020-05-07')
    assert date_text == datetime.date(2020, 5, 7), \
        'Test date failed'
    # Test for the default conditions
    try:
        date.validate('2020-99-99')
        assert False, \
            'Test raise error failed'
    except ValidationError:
        pass
    # Test for the default conditions
    try:
        date.validate('-2020-05-07')
        assert False, \
            'Test raise error failed'
    except ValidationError:
        pass
    # Test for the default conditions
    try:
        date.validate('2020-05')
        assert False, \
            'Test raise error failed'
    except ValidationError:
        pass

# Unit

# Generated at 2022-06-24 10:52:27.625968
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format = BaseFormat()
    assert format.validation_error('format') == ValidationError(text='Must be a valid date format.', code='format')


# Generated at 2022-06-24 10:52:29.977484
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time(1, 2, 3)
    time_format = TimeFormat()
    assert time_format.serialize(obj) == "01:02:03"

# Generated at 2022-06-24 10:52:31.273050
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    f = UUIDFormat()
    assert isinstance(f, BaseFormat)

# Generated at 2022-06-24 10:52:36.338300
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format_type = DateTimeFormat()
    value = "2018-05-03T03:26:23"
    expected = datetime.datetime(year = 2018, month = 5, day = 3, hour = 3, minute = 26, second = 23)
    assert format_type.validate(value) == expected

# Generated at 2022-06-24 10:52:38.373612
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None


# Generated at 2022-06-24 10:52:45.354453
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value1 = "2020-02-02T15:15:15Z"
    value2 = "2020-02-02T15:15:15+05:30"
    value3 = "2020-02-02T15:15:15.123Z"
    value4 = "2020-02-02T15:15:15.123456Z"
    value5 = "2020-02-02T15:15:15.1234567Z"
    assert DateTimeFormat().validate(value1) == datetime.datetime(2020, 2, 2, 15, 15, 15, 0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-24 10:52:56.093011
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("01:23") == datetime.time(hour=1, minute=23)
    assert TimeFormat().validate("01:23:45") == datetime.time(hour=1, minute=23, second=45)
    assert TimeFormat().validate("01:23:45.678912") == datetime.time(hour=1, minute=23, second=45, microsecond=678912)
    assert TimeFormat().validate("01:23:45.6789") == datetime.time(hour=1, minute=23, second=45, microsecond=678900)
    assert TimeFormat().validate("01:23:45.678") == datetime.time(hour=1, minute=23, second=45, microsecond=678000)

# Generated at 2022-06-24 10:53:05.311792
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    # Test for method validate of class DateFormat at line 10
    assert date_format.validate("2020-01-09").__class__ == type(datetime.date(2020, 1, 9)) 
    
    try:
        date_format.validate("2020-01-32")
    except ValidationError as ve:
        assert ve.code == 'invalid'
        assert ve.text == 'Must be a real date.'
    
    try:
        date_format.validate("2020-01-01T09:00:00")
    except ValidationError as ve:
        assert ve.code == 'format'
        assert ve.text == 'Must be a valid date format.'
    
    

# Generated at 2022-06-24 10:53:07.809704
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    test = BaseFormat()
    test_error = test.validation_error("test_code")
    assert test_error.code == "test_code"

# Generated at 2022-06-24 10:53:10.090992
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    base_format = BaseFormat()
    with pytest.raises(NotImplementedError):
        base_format.is_native_type(None)


# Generated at 2022-06-24 10:53:12.030429
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    value = 12345
    uuidFormat = UUIDFormat()
    assert uuidFormat.is_native_type(value) == False


# Generated at 2022-06-24 10:53:13.904719
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    value = uuid.uuid4()
    assert UUIDFormat().is_native_type(value)



# Generated at 2022-06-24 10:53:14.870923
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    newBaseFormat = BaseFormat()

# Generated at 2022-06-24 10:53:17.618482
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    # check an exception when the native type is not datetime.time
    assert TimeFormat().is_native_type(datetime.datetime.now()) == False


# Generated at 2022-06-24 10:53:24.135041
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate('01:00') == datetime.time(1)
    assert TimeFormat().validate('01:00:00') == datetime.time(1, 0)
    assert TimeFormat().validate('01:00:00.000000') == datetime.time(1, 0, 0)
    assert TimeFormat().validate('01:00:00.000001') == datetime.time(1, 0, 0, 1)
    assert TimeFormat().validate('12:34:56.123456') == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-24 10:53:27.072101
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormat = TimeFormat()
    time_string = '08:15:27'
    assert timeFormat.validate(time_string) == datetime.time(8,15,27)

# Generated at 2022-06-24 10:53:31.271526
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class testFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return True
        def validate(self, value: typing.Any) -> typing.Any:
            return value
    serialize_test = testFormat()
    assert serialize_test.serialize(None) == None

# Generated at 2022-06-24 10:53:39.128287
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    val = '23:59:59.999999'
    expected = datetime.time(23, 59, 59, 999999)
    actual = time.validate(val)

    error_code = 'format'
    error_text = 'Must be a valid time format.'
    with pytest.raises(ValidationError) as err:
        time.validate('')
    assert err.value.code == error_code
    assert err.value.text == error_text

# Generated at 2022-06-24 10:53:45.812790
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    test_cases = [["2020-10-20",datetime.date(2020,10,20)],
                  ["2020-10-02",datetime.date(2020,10,2)],
                  ["2020-10-2",datetime.date(2020,10,2)]]
    for test_case in test_cases:
        date_format = DateFormat()
        date = date_format.validate(test_case[0])
        assert date == test_case[1]


# Generated at 2022-06-24 10:53:57.898730
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    for test in [
        "2018-10-07T17:16:52.020",
        "2018-10-07T17:16:52.020180",
        "2018-10-07T17:16:52.020Z",
        "2018-10-07T17:16:52.020+01:00",
        "2018-10-07T17:16:52.020-03:30",
        "2018-10-07T17:16:52.020+01",
        "2018-10-07T17:16:52.020-0330",
        "2018-10-07T17:16:52.020+1",
        "2018-10-07T17:16:52.020-330",
    ]:
        print(DateTimeFormat().validate(test))

# Unit

# Generated at 2022-06-24 10:53:59.105384
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat()


# Generated at 2022-06-24 10:53:59.745433
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    assert 1 == 1

# Generated at 2022-06-24 10:54:01.929234
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = uuid.uuid4()
    format = UUIDFormat()
    assert u.hex == format.serialize(u)



# Generated at 2022-06-24 10:54:05.118908
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(year=2019, month=9, day=3)
    format = DateFormat()
    actual = format.serialize(date)
    expected = date.isoformat()
    assert actual == expected


# Generated at 2022-06-24 10:54:11.886763
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid = UUIDFormat()
    uuid.validate('afa7c929-e2b7-4b79-b4e4-3f55c4f4586b')
    try:
        uuid.validate('afa7c929e2b74b79b4e43f55c4f4586b')
    except ValidationError:
        pass
    assert uuid.serialize(uuid.validate('afa7c929-e2b7-4b79-b4e4-3f55c4f4586b')) == 'afa7c929-e2b7-4b79-b4e4-3f55c4f4586b'

# Generated at 2022-06-24 10:54:14.128012
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(5, 5)) == "05:05:00"
    

# Generated at 2022-06-24 10:54:16.446789
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():  
    dateobject = datetime.datetime.now()
    assert DateTimeFormat().is_native_type(dateobject)


# Generated at 2022-06-24 10:54:17.782897
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) is None


# Generated at 2022-06-24 10:54:20.372277
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    x = DateFormat()
    x.validate('1970-1-1')
    x.validate('1970-01-01')

# Generated at 2022-06-24 10:54:23.968019
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert datetime.date(2002, 2, 2).isoformat() == df.serialize(df.validate('2002-02-02'))

# Generated at 2022-06-24 10:54:25.791277
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    format1 = BaseFormat()
    assert format1.is_native_type([]) == False



# Generated at 2022-06-24 10:54:31.851099
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    dateType = UUIDFormat()
    test1 = dateType.validate("ccd01cdb-4981-46f0-8abb-921c8114c7bd")
    print(test1)
    assert isinstance(test1, uuid.UUID)
    test2 = dateType.validate("abcdefgh-4981-46f0-8abb-921c8114c7")
    print(test2)
    assert isinstance(test2, uuid.UUID)
    assert test1 != test2


# Generated at 2022-06-24 10:54:41.017745
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert not TimeFormat().is_native_type(datetime.datetime(2020, 10, 4)) # teste de classe de base
    assert TimeFormat().is_native_type(datetime.time(10, 10, 10, 10)) # teste de objeto pertencente a classe
    assert not TimeFormat().is_native_type(10) # teste de objeto não pertencente a classe


# Generated at 2022-06-24 10:54:46.208887
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # Make sure the format string is processed
    errors = {"invalid": "Invalid value: {value}"}
    impl = BaseFormat()
    impl.errors = errors
    impl.value = "example"
    with pytest.raises(ValidationError) as excinfo:
        impl.validation_error("invalid")
    assert excinfo.value.text == "Invalid value: example"
    assert excinfo.value.code == "invalid"


# Generated at 2022-06-24 10:54:49.421218
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    f1=BaseFormat()
    g1=ValidationError(text="Must be a valid date format.",code="format")
    assert f1.validation_error("format")==g1

# Generated at 2022-06-24 10:54:50.475257
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    obj = TimeFormat()
    assert obj is not None

# Generated at 2022-06-24 10:54:55.264370
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    from datetime import time
    f = TimeFormat()
    value = f.is_native_type(time(12, 34, 56, 78))
    assert value == True


# Generated at 2022-06-24 10:54:56.744308
# Unit test for constructor of class DateFormat
def test_DateFormat():
    a = DateFormat()
    print(a)


# Generated at 2022-06-24 10:54:58.507804
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    assert isinstance(uuid_format, BaseFormat)


# Generated at 2022-06-24 10:55:07.095230
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()

    assert dt.validate("2014-01-01T01:01:01Z") == datetime.datetime(2014,1,1,1,1,1,0, datetime.timezone.utc)
    assert dt.validate("2014-01-01T01:01:01Z") != datetime.datetime(2014,1,1,1,1,1,1, datetime.timezone.utc)
    #
    assert dt.validate("2014-01-01T01:01:01+01:00") == datetime.datetime(2014,1,1,1,1,1,0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-24 10:55:10.459926
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class TestFormat(BaseFormat):
        def validate(self, value: typing.Any) -> typing.Union[typing.Any, ValidationError]:
            return value
    
    obj = TestFormat()
    assert obj.validate("Hello") == "Hello"
    

# Generated at 2022-06-24 10:55:12.541111
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    d = datetime.datetime.now()
    dt = DateTimeFormat()
    assert dt.is_native_type(d) == True


# Generated at 2022-06-24 10:55:16.073200
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize(uuid.UUID("7ae2c3d3-735e-4b6f-b057-84b8f7e64568")) == "7ae2c3d3-735e-4b6f-b057-84b8f7e64568"

# Generated at 2022-06-24 10:55:21.304136
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(hour=23, minute=24, second=5, microsecond=1000)
    time_str = "23:24:05.001000"

    time_format = TimeFormat()
    assert time_format.serialize(time) == time_str


# Generated at 2022-06-24 10:55:24.578707
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2018, 2, 21, 12, 12, 12, 12)
    assert DateTimeFormat().serialize(obj) == "2018-02-21T12:12:12.000012"

# Generated at 2022-06-24 10:55:30.323255
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    
    class Class1(datetime.datetime):
        """
        This is a class that inherit datetime.datetime
        """
        def __init__(self):
            pass
            # super(Class1, self).__init__()
    d1 = Class1()
    d2 = DateTimeFormat()
    
    
    
    


if __name__ == "__main__":
    test_DateTimeFormat()

# Generated at 2022-06-24 10:55:34.202753
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    value = '3b3dc1cf-c841-11e9-b1f1-0800200c9a66'
    assert UUIDFormat().is_native_type(value)



# Generated at 2022-06-24 10:55:39.367080
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert (DateTimeFormat().serialize(datetime.datetime(2015, 1, 1, tzinfo=datetime.timezone.utc)) == '2015-01-01T00:00:00+00:00')
    dt = datetime.datetime.utcnow()
    assert (DateTimeFormat().serialize(dt) == dt.isoformat())

# Generated at 2022-06-24 10:55:40.929262
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(1) == False


# Generated at 2022-06-24 10:55:44.882863
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class BaseFormatTemp(BaseFormat):
        errors = {"format": "BaseFormatTemp error message."}
    base_format = BaseFormatTemp()
    result = base_format.validation_error(code="format").text
    assert result == "BaseFormatTemp error message."
    assert base_format.validation_error(code="format").code == "format"


# Generated at 2022-06-24 10:55:49.403320
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    expected = "NotImplementedError"

    format = BaseFormat()
    try:
        result = format.is_native_type("")
    except NotImplementedError as err:
        result = str(err)
    
    assert expected == result
    

# Generated at 2022-06-24 10:55:52.882036
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b1 = BaseFormat()
    b1.errors = {"a": "b"}
    assert b1.errors == {"a": "b"}


# Generated at 2022-06-24 10:55:54.332955
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert tf



# Generated at 2022-06-24 10:55:55.178266
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    assert True

# Generated at 2022-06-24 10:55:56.856090
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time()) == True


# Generated at 2022-06-24 10:55:58.666900
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    base = BaseFormat()
    assert base.is_native_type("a") == False


# Generated at 2022-06-24 10:56:05.712398
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    # case 1: input is date type
    date1 = date(2020, 2, 20)
    format1 = DateFormat()
    if format1.is_native_type(date1) != True:
        print("test case 1 of method is_native_type of Class DateFormat failed")
    else:
        print("test case 1 of method is_native_type of Class DateFormat success")

    # case 2: input is not date type
    format2 = DateFormat()
    if format2.is_native_type("abc") != False:
        print("test case 2 of method is_native_type of Class DateFormat failed")
    else:
        print("test case 2 of method is_native_type of Class DateFormat success")



# Generated at 2022-06-24 10:56:13.065946
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    # To execute this unit test, the command line is:
    #  python3 -m pytest:

    class TestFormat(BaseFormat):
        errors = {"format": "Must be a text format."}

    format = TestFormat()

    with pytest.raises(NotImplementedError) as exc_info:
        format.validate("a text")
    assert exc_info.match(r"^Must be a text format.$")
    return



# Generated at 2022-06-24 10:56:19.010155
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    obj = time_format.validate('00:10:00')
    assert isinstance(obj, datetime.time)
    assert obj.hour == 0
    assert obj.minute == 10
    assert obj.second == 0

    time_format = TimeFormat()
    obj = time_format.validate('00:10:00.000000')
    assert isinstance(obj, datetime.time)
    assert obj.hour == 0
    assert obj.minute == 10
    assert obj.second == 0

    # invalid format
    time_format = TimeFormat()
    try:
        time_format.validate('00:10')
        assert 0
    except ValidationError:
        assert 1


# Generated at 2022-06-24 10:56:25.860809
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt_format = DateTimeFormat()

    dt = dt_format.validate('2020-06-25T12:30:15+00:00')
    expected_dt = datetime.datetime( 2020, 6, 25, 12, 30, 15, tzinfo=datetime.timezone.utc )
    assert dt == expected_dt



# Generated at 2022-06-24 10:56:29.635854
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtf = DateTimeFormat()
    u = datetime.datetime.now()
    assert dtf.is_native_type(u)


# Generated at 2022-06-24 10:56:40.097682
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class MyFormat(BaseFormat):
        errors = {
            "format": "Must be a valid format.",
            "invalid": "Must be a real object.",
        }

    mf = MyFormat()

    with pytest.raises(NotImplementedError):
        mf.validate('x')

    with pytest.raises(NotImplementedError):
        mf.validate(None)

    with pytest.raises(NotImplementedError):
        mf.validate('x')

    with pytest.raises(NotImplementedError):
        mf.validate(1)

    with pytest.raises(NotImplementedError):
        mf.validate(1.1)


# Generated at 2022-06-24 10:56:47.967199
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # test_DateFormat_validate_normal
    result = DateFormat().validate("2020-01-01")
    assert str(result) == "2020-01-01"
    result = DateFormat().validate("1-1-1")
    assert str(result) == "0001-01-01"
    # test_DateFormat_validate_wrong
    try:
        result = DateFormat().validate("2020-01-011")
    except ValidationError as e:
        assert e.code == "format"
        assert e.text == "Must be a valid date format."
    try:
        result = DateFormat().validate("2020-13-32")
    except ValidationError as e:
        assert e.code == "invalid"
        assert e.text == "Must be a real date."
        
# Unit test

# Generated at 2022-06-24 10:56:56.717104
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_str = 'b453736c-a5a5-4d6e-9fef-b6f87b6b0fe7'
    uuid_obj = uuid.UUID(uuid_str)
    uuid_format = UUIDFormat()
    uuid_validate = uuid_format.validate(uuid_str)
    assert isinstance(uuid_validate, uuid.UUID)
    assert uuid_validate == uuid_obj
    # invalid uuid string
    num_str = '12345'
    uuid_validate = uuid_format.validate(num_str)
    assert isinstance(uuid_validate, ValidationError)
    assert uuid_validate.code == 'format'
    # use uuid object
    uuid_valid

# Generated at 2022-06-24 10:57:01.479766
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    import datetime
    from typesystem.formats import DateTimeFormat
    df = DateTimeFormat()
    dt_obj = datetime.datetime.now()
    assert df.is_native_type(dt_obj)


# Generated at 2022-06-24 10:57:05.606771
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) is None


# Generated at 2022-06-24 10:57:08.278160
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    test_uuid = '9a0b3ec3-59c0-4d1b-a78d-7f69c58d85e7'
    rt = UUIDFormat().validate(test_uuid)
    assert type(rt) == uuid.UUID

# Generated at 2022-06-24 10:57:13.344527
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    fmt = DateTimeFormat()
    value = fmt.serialize(datetime.datetime.now())
    assert isinstance(value, str)
    assert fmt.validate(value) == datetime.datetime.now()

# Generated at 2022-06-24 10:57:16.417809
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    test_format = BaseFormat()
    error = test_format.validation_error("format")
    #  returns ValidationError
    assert type(error) == ValidationError


# Generated at 2022-06-24 10:57:23.728819
# Unit test for method is_native_type of class BaseFormat

# Generated at 2022-06-24 10:57:25.302444
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert(DateFormat().is_native_type(datetime.date(2019, 11, 9)))


# Generated at 2022-06-24 10:57:33.158475
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    obj = DateFormat()
    assert obj.is_native_type(datetime.date(2018, 11, 12)) is True
    assert obj.is_native_type(datetime.date(2018, 2, 21)) is True
    assert obj.is_native_type(datetime.date(2018, 12, 30)) is True
    assert obj.is_native_type(datetime.time(13, 55)) is False
    assert obj.is_native_type(datetime.time(12, 6, 15)) is False
    assert obj.is_native_type(datetime.time(12, 6, 15, 20)) is False
    assert obj.is_native_type(datetime.datetime(2018, 12, 30)) is False

# Generated at 2022-06-24 10:57:35.422419
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    format = TimeFormat()
    assert format.is_native_type(datetime.time()) == True
    assert format.is_native_type(datetime.datetime) == False


# Generated at 2022-06-24 10:57:38.805911
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    dateValue = dateTimeFormat.validate("2020-09-10T16:32:00Z")
    assert dateValue == datetime.datetime(2020,9,10,16,32,00,tzinfo=datetime.timezone.utc)

# Generated at 2022-06-24 10:57:46.091080
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert isinstance(DateTimeFormat(), DateTimeFormat)
    assert DateTimeFormat.errors["format"] == "Must be a valid datetime format."
    assert DateTimeFormat.errors["invalid"] == "Must be a real datetime."
    dtf = DateTimeFormat()
    assert isinstance(dtf.validation_error("format"), ValidationError)
    assert isinstance(dtf.validation_error("invalid"), ValidationError)


# Generated at 2022-06-24 10:57:47.832469
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat().errors.get('format') == 'Must be a valid datetime format.'

# Generated at 2022-06-24 10:57:52.792889
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dtf = DateFormat()
    # Valid format
    assert dtf.validate('2018-11-29').strftime('%Y-%m-%d') == '2018-11-29'
    # Invalid format
    with pytest.raises(ValidationError, match="Must be a valid date format."):
        dtf.validate('2018-11-290')
    # Invalid date
    with pytest.raises(ValidationError, match="Must be a real date."):
        dtf.validate('2018-02-30')


# Generated at 2022-06-24 10:57:56.480192
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    format = DateTimeFormat()
    datetime_str = '2019-08-23T13:52:48+02:00'
    datetime_obj = format.validate(datetime_str)
    datetime_s = format.serialize(datetime_obj)
    assert datetime_s == '2019-08-23T13:52:48+02:00'

# Generated at 2022-06-24 10:58:04.552531
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    try:
        BaseFormat().validate( None )
    except NotImplementedError:
        assert True
    else:
        assert False
    try:
        BaseFormat().is_native_type( None )
    except NotImplementedError:
        assert True
    else:
        assert False
    try:
        BaseFormat().serialize( None )
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 10:58:12.165315
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time(0,0,0,0)) == True
    assert TimeFormat().is_native_type(datetime.datetime.now()) == False
    assert TimeFormat().is_native_type(datetime.date.today()) == False
    assert TimeFormat().is_native_type(datetime.timedelta(microseconds=1)) == False
    assert TimeFormat().is_native_type(10) == False



# Generated at 2022-06-24 10:58:14.937752
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4()) == True


# Generated at 2022-06-24 10:58:17.059971
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2019, 11, 30))=='2019-11-30'

# Generated at 2022-06-24 10:58:18.325270
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time()
    assert TimeFormat().serialize(obj) == obj.isoformat()


# Generated at 2022-06-24 10:58:22.473816
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    # Test for valid input for a datetime object
    datetime_obj = datetime.datetime(2010, 12, 12, 12, 12, 12, 000000)
    assert DateTimeFormat().is_native_type(datetime_obj)

    # Test for invalid input
    assert not DateTimeFormat().is_native_type('2010-12-12 12:12:12')


# Generated at 2022-06-24 10:58:32.314740
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_format = DateTimeFormat()
    assert datetime_format.is_native_type(datetime.datetime(2019, 5, 16, 17, 6, 5))
    assert not datetime_format.is_native_type(datetime.time(2019, 5, 16, 17, 6, 5))

    assert datetime_format.serialize(None) is None
    assert datetime_format.serialize(datetime.datetime(2019, 5, 16, 17, 6, 5)) == '2019-05-16T17:06:05'
    assert datetime_format.serialize(datetime.datetime(2019, 5, 16, 17, 6, 5, tzinfo=datetime.timezone.utc)) == '2019-05-16T17:06:05Z'
    assert datetime_format.serialize

# Generated at 2022-06-24 10:58:36.578178
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format = UUIDFormat()
    value = 'f2d036b7-b63a-40c7-83b2-ca108d7a217f'
    assert (uuid_format.validate(value) == uuid.UUID(value))


# Generated at 2022-06-24 10:58:39.574104
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        x = BaseFormat()
        x.validate(1234)


# Generated at 2022-06-24 10:58:45.782131
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuidA = UUIDFormat()
    assert uuidA.serialize("4d5a5cf8-5c5d-4e27-a9e3-832d09f1cba7") == "4d5a5cf8-5c5d-4e27-a9e3-832d09f1cba7"
    

UUID = UUIDFormat()

# Generated at 2022-06-24 10:58:53.062104
# Unit test for constructor of class DateFormat
def test_DateFormat():
    a = DateFormat()
    assert a.is_native_type(datetime.date(2018, 1, 1)) == True
    assert isinstance(a.validate("2018-01-01"),datetime.date) == True
    a.validate("2018-01-03") == "2018-01-03"
    a.validate("2018-01-03") == "2018-01-03"
    assert a.serialize(datetime.date(2018, 1, 1)) == "2018-01-01"
    assert a.serialize(None) == None



# Generated at 2022-06-24 10:58:54.874933
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    value = ['1', 'b', 'c']
    x = BaseFormat()
    assert x.serialize(value) == value


# Generated at 2022-06-24 10:58:57.123773
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(15, 8, 20, 555)
    formatted_time = TimeFormat().serialize(time)
    assert formatted_time == '15:08:20.000555'

# Generated at 2022-06-24 10:59:06.035480
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    # Should return false for all types
    assert BaseFormat().is_native_type(1) == False
    assert BaseFormat().is_native_type(1.0) == False
    assert BaseFormat().is_native_type('a') == False
    assert BaseFormat().is_native_type(True) == False
    assert BaseFormat().is_native_type([]) == False
    assert BaseFormat().is_native_type({}) == False
    assert BaseFormat().is_native_type(()) == False
    assert BaseFormat().is_native_type(set()) == False
    assert BaseFormat().is_native_type(datetime.datetime.now()) == False
    assert BaseFormat().is_native_type(datetime.date.today()) == False
    assert BaseFormat().is_native_type(datetime.time()) == False
   

# Generated at 2022-06-24 10:59:11.499325
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuidformat = UUIDFormat()
    testUUID = uuid.uuid4()
    testString: str = uuidformat.serialize(testUUID)
    print(testString)
    assert isinstance(testString, str)
    assert testString == testString.lower()

# Generated at 2022-06-24 10:59:13.125156
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    print("test_TimeFormat")
    t = TimeFormat()
