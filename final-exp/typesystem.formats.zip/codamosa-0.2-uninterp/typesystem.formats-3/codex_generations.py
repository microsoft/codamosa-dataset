

# Generated at 2022-06-18 12:13:23.023760
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:13:30.078636
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=8)))) == '2020-01-01T00:00:00+08:00'

# Generated at 2022-06-18 12:13:38.799364
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("d8a2a0a1-c8d3-4c3b-b2a2-a9c1f8b7c8d3")
    uuid_format.validate("d8a2a0a1c8d34c3bb2a2a9c1f8b7c8d3")
    uuid_format.validate("D8A2A0A1-C8D3-4C3B-B2A2-A9C1F8B7C8D3")
    uuid_format.validate("D8A2A0A1C8D34C3BB2A2A9C1F8B7C8D3")

# Generated at 2022-06-18 12:13:46.768953
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:13:54.018411
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:14:04.085595
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00.000001Z'

# Generated at 2022-06-18 12:14:09.882668
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") != datetime.date(2019, 1, 2)
    assert date_format.validate("2019-01-01") != datetime.date(2019, 2, 1)
    assert date_format.validate("2019-01-01") != datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:14:20.374648
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123456Z")
    time_format.validate("12:34:56.12345Z")

# Generated at 2022-06-18 12:14:29.825533
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == date_format.validate("2020-1-1")
    assert date_format.validate("2020-01-01") == date_format.validate("2020-01-1")
    assert date_format.validate("2020-01-01") == date_format.validate("2020-1-01")
    assert date_format.validate("2020-01-01") == date_format.validate("2020-01-01")
    assert date_format.validate("2020-01-01") == date_format.validate("2020-1-1")

# Generated at 2022-06-18 12:14:39.073818
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:14:55.473031
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:15:06.415055
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:15:18.660165
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:15:28.233358
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-12-31")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-29")

# Generated at 2022-06-18 12:15:39.952310
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 12, 0, 0, 0)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:00:00"
    dt = datetime.datetime(2020, 1, 1, 12, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:00:00Z"
    dt = datetime.datetime(2020, 1, 1, 12, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:00:00+02:00"

# Generated at 2022-06-18 12:15:42.746683
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:15:53.090515
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)

# Generated at 2022-06-18 12:16:04.465979
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:30:00")
    time_format.validate("12:30:00.123456")
    time_format.validate("12:30:00.123")
    time_format.validate("12:30:00.12")
    time_format.validate("12:30:00.1")
    time_format.validate("12:30:00.1234")
    time_format.validate("12:30:00.12345")
    time_format.validate("12:30:00.1234567")
    time_format.validate("12:30:00.12345678")
    time_format.validate("12:30:00.123456789")

# Generated at 2022-06-18 12:16:08.609534
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)


# Generated at 2022-06-18 12:16:12.808175
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2021, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:16:19.634522
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)


# Generated at 2022-06-18 12:16:31.529875
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:16:39.678718
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:16:50.981843
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-01-01T00:00:00Z"
    assert DateTimeFormat().validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)

    # Test case 2
    value = "2019-01-01T00:00:00+00:00"
    assert DateTimeFormat().validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)

    # Test case 3
    value = "2019-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:16:52.421228
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:17:00.004543
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.123")
    time_format.validate

# Generated at 2022-06-18 12:17:08.689961
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('12:00') == datetime.time(12, 0)
    assert time_format.validate('12:00:00') == datetime.time(12, 0)
    assert time_format.validate('12:00:00.000000') == datetime.time(12, 0)
    assert time_format.validate('12:00:00.000001') == datetime.time(12, 0, 0, 1)
    assert time_format.validate('12:00:00.000010') == datetime.time(12, 0, 0, 10)
    assert time_format.validate('12:00:00.000100') == datetime.time(12, 0, 0, 100)

# Generated at 2022-06-18 12:17:21.028770
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:17:32.395378
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:17:36.963801
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test with valid date
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)

    # Test with invalid date
    with pytest.raises(ValidationError):
        date.validate("2020-13-01")


# Generated at 2022-06-18 12:17:53.694106
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:18:04.128889
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1:
    # Input:
    #   value = "2020-01-01T00:00:00Z"
    # Expected output:
    #   datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    value = "2020-01-01T00:00:00Z"
    expected_output = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual_output = DateTimeFormat().validate(value)
    assert actual_output == expected_output

    # Test case 2:
    # Input:
    #   value = "2020-01-01T00:00:00+00:00"
    # Expected output:
    #  

# Generated at 2022-06-18 12:18:15.902882
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")

# Generated at 2022-06-18 12:18:27.856864
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0)) == '2020-01-01T12:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)) == '2020-01-01T12:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T12:00:00+01:00'

# Generated at 2022-06-18 12:18:37.518412
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.12345")

# Generated at 2022-06-18 12:18:48.368168
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")

# Generated at 2022-06-18 12:19:01.169943
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-01-01T00:00:00Z"
    expected = datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2019-01-01T00:00:00+01:00"
    expected = datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3
    value = "2019-01-01T00:00:00-01:00"
    expected = datetime

# Generated at 2022-06-18 12:19:11.118973
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:19:22.478611
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:19:34.627585
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:19:47.046276
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2020-03-01") == datetime.date(2020, 3, 1)
    assert date_format.validate("2020-03-31") == datetime.date(2020, 3, 31)
    assert date_format.validate("2020-04-01") == datetime.date(2020, 4, 1)

# Generated at 2022-06-18 12:19:57.439155
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2021, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2019, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 3)

# Generated at 2022-06-18 12:20:08.363223
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert date_time_format.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert date_time_format.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:20:17.659228
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-12-31")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")

# Generated at 2022-06-18 12:20:28.435519
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:20:37.689687
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2021, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2019, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 3)

# Generated at 2022-06-18 12:20:49.497832
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # test case 1
    value = '2019-01-01T00:00:00Z'
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # test case 2
    value = '2019-01-01T00:00:00+00:00'
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # test case 3
    value = '2019-01-01T00:00:00+01:00'
    date_time_

# Generated at 2022-06-18 12:21:01.724986
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2021-02-28") == datetime.date(2021, 2, 28)
    assert date_format.validate("2022-02-28") == datetime.date(2022, 2, 28)
    assert date_format.validate("2023-02-28") == datetime.date(2023, 2, 28)
    assert date_format.validate("2024-02-29")

# Generated at 2022-06-18 12:21:10.360405
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-12-31T23:59:59Z") == datetime.datetime(2019, 12, 31, 23, 59, 59, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-12-31T23:59:59+00:00") == datetime.datetime(2019, 12, 31, 23, 59, 59, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-12-31T23:59:59+01:00") == datetime.datetime(2019, 12, 31, 23, 59, 59, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:21:18.667105
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:21:26.584843
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-01-01")


# Generated at 2022-06-18 12:21:36.797000
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:21:38.631792
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2020-01-01")
    assert date == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:21:46.824155
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T12:00:00+02:00"

# Generated at 2022-06-18 12:21:49.156868
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:21:57.123034
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123456Z")
    time_format.validate("12:34:56.123456+01:00")

# Generated at 2022-06-18 12:22:06.849873
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:22:16.541892
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    assert dateTimeFormat.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dateTimeFormat.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dateTimeFormat.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:22:27.583944
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:22:34.680483
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert dt.validate("2019-01-01T00:00:00+0100") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:22:54.255672
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1)
    assert time.validate("12:00:00.000010") == datetime.time(12, 0, 0, 10)
    assert time.validate("12:00:00.000100") == datetime.time(12, 0, 0, 100)
    assert time.validate("12:00:00.001000") == datetime.time(12, 0, 0, 1000)

# Generated at 2022-06-18 12:23:02.118261
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))