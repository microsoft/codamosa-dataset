

# Generated at 2022-06-18 12:13:22.950147
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:13:30.024476
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(obj) == "2020-01-01T00:00:00Z"
    obj = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))
    assert DateTimeFormat().serialize(obj) == "2020-01-01T00:00:00+01:00"
    obj = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-1)))

# Generated at 2022-06-18 12:13:32.870942
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2020, 1, 1)) == "2020-01-01"
    assert date_format.serialize(None) == None


# Generated at 2022-06-18 12:13:38.248613
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert date.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert date.validate("2020-01-01") != datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:13:40.880337
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2020, 1, 1)) == "2020-01-01"
    assert date_format.serialize(None) == None


# Generated at 2022-06-18 12:13:48.977436
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-01-01T00:00:00Z"
    expected = datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2019-01-01T00:00:00+01:00"
    expected = datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3
    value = "2019-01-01T00:00:00-01:00"
    expected = datetime

# Generated at 2022-06-18 12:13:55.609224
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.")
    time_format.validate("12:00:00")
    time_format.validate("12:00")
    time_format.validate("12:00:00.1234567")

# Generated at 2022-06-18 12:14:05.422751
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    assert dateTimeFormat.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dateTimeFormat.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert dateTimeFormat.validate("2019-01-01T00:00:00+01") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert dateTime

# Generated at 2022-06-18 12:14:07.590824
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2019-01-01') == datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:14:18.358468
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:14:32.362072
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-01-01T00:00:00Z"
    assert DateTimeFormat().validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    # Test case 2
    value = "2019-01-01T00:00:00+00:00"
    assert DateTimeFormat().validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    # Test case 3
    value = "2019-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:14:41.496072
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00+00:00"
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)

    # Test case 2
    value = "2020-01-01T00:00:00Z"
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)

    # Test case 3
    value = "2020-01-01T00:00:00"
    date_time_format = DateTimeFormat()
   

# Generated at 2022-06-18 12:14:47.614300
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:14:59.368639
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("00:00:00")
    time_format.validate("00:00:00.000000")
    time_format.validate("00:00:00.000001")
    time_format.validate("00:00:00.000010")
    time_format.validate("00:00:00.000100")
    time_format.validate("00:00:00.001000")
    time_format.validate("00:00:00.010000")
    time_format.validate("00:00:00.100000")
    time_format.validate("00:00:01.000000")
    time_format.validate("00:01:00.000000")
    time_format.validate("01:00:00.000000")

# Generated at 2022-06-18 12:15:02.375209
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    time = datetime.time(hour=12, minute=30, second=45)
    assert time_format.serialize(time) == '12:30:45'


# Generated at 2022-06-18 12:15:09.963079
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123456Z")
    time_format.validate("12:34:56.123456+01:00")

# Generated at 2022-06-18 12:15:21.896340
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate('12345678-1234-5678-1234-567812345678') == uuid.UUID('12345678-1234-5678-1234-567812345678')
    assert uuid_format.validate('12345678123456781234567812345678') == uuid.UUID('12345678-1234-5678-1234-567812345678')
    assert uuid_format.validate('12345678-1234-5678-1234-56781234567') == uuid.UUID('12345678-1234-5678-1234-56781234567')

# Generated at 2022-06-18 12:15:30.081823
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:15:41.567774
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:15:52.339075
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:16:06.915832
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")

# Generated at 2022-06-18 12:16:17.283818
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")

# Generated at 2022-06-18 12:16:19.864397
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate('2020-01-01') == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:16:31.794143
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-01-01T00:00:00Z"
    assert DateTimeFormat().validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    # Test case 2
    value = "2019-01-01T00:00:00+00:00"
    assert DateTimeFormat().validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    # Test case 3
    value = "2019-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:16:39.802054
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("12345678-1234-5678-1234-567812345678") == uuid.UUID("12345678-1234-5678-1234-567812345678")
    assert uuid_format.validate("12345678123456781234567812345678") == uuid.UUID("12345678-1234-5678-1234-567812345678")
    assert uuid_format.validate("123456781234-5678-1234-567812345678") == uuid.UUID("12345678-1234-5678-1234-567812345678")

# Generated at 2022-06-18 12:16:51.135300
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:16:59.265760
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2019-01-01T00:00:00Z")
    date_time_format.validate("2019-01-01T00:00:00+00:00")
    date_time_format.validate("2019-01-01T00:00:00-00:00")
    date_time_format.validate("2019-01-01T00:00:00+01:00")
    date_time_format.validate("2019-01-01T00:00:00-01:00")
    date_time_format.validate("2019-01-01T00:00:00+01:30")
    date_time_format.validate("2019-01-01T00:00:00-01:30")
   

# Generated at 2022-06-18 12:17:03.179887
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("9a9f5d3a-a5d7-4f5f-a7a5-e5d7f5f7a5e5")


# Generated at 2022-06-18 12:17:13.667834
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")

# Generated at 2022-06-18 12:17:24.400703
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:17:38.292026
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:17:40.029788
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:17:51.424218
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-04-01T10:00:00Z"
    assert DateTimeFormat().validate(value) == datetime.datetime(2019, 4, 1, 10, 0, 0, tzinfo=datetime.timezone.utc)
    # Test case 2
    value = "2019-04-01T10:00:00+00:00"
    assert DateTimeFormat().validate(value) == datetime.datetime(2019, 4, 1, 10, 0, 0, tzinfo=datetime.timezone.utc)
    # Test case 3
    value = "2019-04-01T10:00:00+01:00"

# Generated at 2022-06-18 12:18:02.361658
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.1234567") == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-18 12:18:07.230848
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-12-31T23:59:59.999999Z") == datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-12-31T23:59:59.999999+00:00") == datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-18 12:18:18.932427
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.1234567") == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-18 12:18:30.727472
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:18:33.289121
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:18:38.018937
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == date_format.validate("2020-01-01")
    assert date_format.validate("2020-01-01") != date_format.validate("2020-01-02")


# Generated at 2022-06-18 12:18:49.081403
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:19:04.365460
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-02-02") == datetime.date(2020, 2, 2)
    assert date_format.validate("2020-02-02") != datetime.date(2020, 2, 3)
    assert date_format.validate("2020-02-02") != datetime.date(2020, 2, 1)
    assert date_format.validate("2020-02-02") != datetime.date(2020, 1, 2)
    assert date_format.validate("2020-02-02") != datetime.date(2019, 2, 2)
    assert date_format.validate("2020-02-02") != datetime.date(2021, 2, 2)

# Generated at 2022-06-18 12:19:13.839824
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)

# Generated at 2022-06-18 12:19:24.776859
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2020-01-01T00:00:00Z")
    date_time_format.validate("2020-01-01T00:00:00+00:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
    date_time_format.validate("2020-01-01T00:00:00+01:30")
    date_time_format.validate("2020-01-01T00:00:00+01")
    date_time_format.validate("2020-01-01T00:00:00-01:00")
    date_time_format.validate("2020-01-01T00:00:00-01:30")
    date_

# Generated at 2022-06-18 12:19:27.210614
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:19:39.198936
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("23:59:59.999999") == datetime.time(23, 59, 59, 999999)
    assert time_format.validate("23:59:59.999999") == datetime.time(23, 59, 59, 999999)
    assert time_format.validate("23:59:59.999999") == datetime.time(23, 59, 59, 999999)
    assert time_format.validate("23:59:59.999999") == datetime.time(23, 59, 59, 999999)
    assert time_format.validate("23:59:59.999999") == datetime.time(23, 59, 59, 999999)
    assert time_format.validate("23:59:59.999999") == dat

# Generated at 2022-06-18 12:19:48.983515
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)
    assert time_format

# Generated at 2022-06-18 12:19:59.722531
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.1234567") == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-18 12:20:10.645732
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-02-28") == datetime.date(2019, 2, 28)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2021-02-28") == datetime.date(2021, 2, 28)
    assert date_format.validate("2022-02-28") == datetime.date(2022, 2, 28)
    assert date_format.validate("2023-02-28") == dat

# Generated at 2022-06-18 12:20:19.022982
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2020-01-01T00:00:00Z")
    date_time_format.validate("2020-01-01T00:00:00.000000Z")
    date_time_format.validate("2020-01-01T00:00:00+00:00")
    date_time_format.validate("2020-01-01T00:00:00.000000+00:00")
    date_time_format.validate("2020-01-01T00:00:00-00:00")
    date_time_format.validate("2020-01-01T00:00:00.000000-00:00")

# Generated at 2022-06-18 12:20:29.792841
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:20:41.148051
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:20:53.312947
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:21:04.849229
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate('12:30:00')
    time_format.validate('12:30:00.123456')
    time_format.validate('12:30:00.123')
    time_format.validate('12:30:00.12')
    time_format.validate('12:30:00.1')
    time_format.validate('12:30:00.1234')
    time_format.validate('12:30:00.12345')
    time_format.validate('12:30:00.1234567')
    time_format.validate('12:30:00.12345678')
    time_format.validate('12:30:00.123456789')

# Generated at 2022-06-18 12:21:07.887376
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:21:12.434014
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)


# Generated at 2022-06-18 12:21:24.661043
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:21:34.870027
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('00:00:00') == datetime.time(0, 0)
    assert time_format.validate('00:00:00.000000') == datetime.time(0, 0)
    assert time_format.validate('00:00:00.000001') == datetime.time(0, 0, 0, 1)
    assert time_format.validate('00:00:00.000010') == datetime.time(0, 0, 0, 10)
    assert time_format.validate('00:00:00.000100') == datetime.time(0, 0, 0, 100)
    assert time_format.validate('00:00:00.001000') == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:21:42.998379
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('12:00:00') == datetime.time(12, 0, 0)
    assert time_format.validate('12:00:00.123456') == datetime.time(12, 0, 0, 123456)
    assert time_format.validate('12:00:00.123') == datetime.time(12, 0, 0, 123000)
    assert time_format.validate('12:00:00.12') == datetime.time(12, 0, 0, 120000)
    assert time_format.validate('12:00:00.1') == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:21:52.347672
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:21:59.358213
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00")
    time_format.validate("12:00")
    time_format.validate("12")
    time_format.validate("12:00:00.000000Z")
    time_format.validate("12:00:00Z")
    time_format.validate("12:00Z")
    time_format.validate("12Z")
    time_format.validate("12:00:00.000000+01:00")
    time_format.validate("12:00:00+01:00")
    time_format.validate("12:00+01:00")
    time_format.validate("12+01:00")
    time

# Generated at 2022-06-18 12:22:09.659404
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:22:20.680792
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-31") == datetime.date(2020, 1, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2020-03-31") == datetime.date(2020, 3, 31)
    assert date_format.validate("2020-04-30") == datetime.date(2020, 4, 30)
    assert date_format.validate("2020-05-31") == datetime.date(2020, 5, 31)

# Generated at 2022-06-18 12:22:29.930065
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:22:31.495568
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")


# Generated at 2022-06-18 12:22:41.921272
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2020-01-01T00:00:00Z")
    date_time_format.validate("2020-01-01T00:00:00+00:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
    date_time_format.validate("2020-01-01T00:00:00+01:30")
    date_time_format.validate("2020-01-01T00:00:00+01:30")
    date_time_format.validate("2020-01-01T00:00:00-01:30")
    date_time_format.validate("2020-01-01T00:00:00.123456Z")
   

# Generated at 2022-06-18 12:22:53.587413
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123456Z")
    time_format.validate("12:34:56.123Z")
    time_format.validate("12:34:56Z")
    time_format.validate("12:34Z")
    time_format.validate("12Z")
    time_format.validate("12:34:56.123456+01:00")

# Generated at 2022-06-18 12:23:01.803115
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert DateFormat().validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert DateFormat().validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert DateFormat().validate('2020-01-01') != datetime.date(2021, 1, 1)
    assert DateFormat().validate('2020-01-01') != datetime.date(2021, 2, 1)
    assert DateFormat().validate('2020-01-01') != datetime.date(2021, 2, 2)
    assert DateFormat().validate('2020-01-01') != datetime.date(2021, 2, 3)
    assert DateFormat().valid