

# Generated at 2022-06-18 12:13:18.749322
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2020-05-01T12:00:00Z") == datetime.datetime(2020, 5, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2020-05-01T12:00:00+02:00") == datetime.datetime(2020, 5, 1, 12, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))

# Generated at 2022-06-18 12:13:27.114973
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1:
    # Input: value = "2020-01-01T00:00:00Z"
    # Expected output: datetime.datetime(2020, 1, 1, 0, 0, tzinfo=datetime.timezone.utc)
    value = "2020-01-01T00:00:00Z"
    expected_output = datetime.datetime(2020, 1, 1, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate(value) == expected_output

    # Test case 2:
    # Input: value = "2020-01-01T00:00:00+00:00"
    # Expected output: datetime.datetime(2020, 1, 1, 0, 0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-18 12:13:32.818098
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T12:00:00+02:00"

# Generated at 2022-06-18 12:13:35.023012
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:13:42.191191
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("123e4567-e89b-12d3-a456-426655440000") == uuid.UUID("123e4567-e89b-12d3-a456-426655440000")
    assert uuid_format.validate("123e4567e89b12d3a456426655440000") == uuid.UUID("123e4567e89b12d3a456426655440000")
    assert uuid_format.validate("123e4567e89b12d3a456426655440000") == uuid.UUID("123e4567e89b12d3a456426655440000")

# Generated at 2022-06-18 12:13:50.354519
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("10:20:30.123456") == datetime.time(10, 20, 30, 123456)
    assert time_format.validate("10:20:30") == datetime.time(10, 20, 30)
    assert time_format.validate("10:20") == datetime.time(10, 20)
    assert time_format.validate("10") == datetime.time(10)
    assert time_format.validate("10:20:30.123") == datetime.time(10, 20, 30, 123000)
    assert time_format.validate("10:20:30.12345") == datetime.time(10, 20, 30, 12345)

# Generated at 2022-06-18 12:13:56.573530
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:14:06.168381
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2020-01-01T00:00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0)
    assert dt.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:14:15.109628
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test for valid datetime
    datetime_format = DateTimeFormat()
    assert datetime_format.validate("2020-01-01T00:00:00") == datetime.datetime(2020, 1, 1)
    assert datetime_format.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, tzinfo=datetime.timezone.utc)
    assert datetime_format.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:14:25.759674
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert DateTimeFormat().validate("2019-01-01T00:00:00-01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=-1)))

# Generated at 2022-06-18 12:14:42.035434
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-12-31T23:59:59.999999Z"
    expected = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert expected == actual

    # Test case 2
    value = "2019-12-31T23:59:59.999999+01:00"
    expected = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    actual = DateTimeFormat().validate(value)
    assert expected == actual

    # Test case 3

# Generated at 2022-06-18 12:14:48.045143
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-1-1") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-1") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-1-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-12-3") == datetime.date(2020, 12, 3)

# Generated at 2022-06-18 12:14:59.868101
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.123456789")
    time_format.validate("12:00:00.12345678")
   

# Generated at 2022-06-18 12:15:08.615101
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-01-01")
    date_format.validate("2019-12-31")
    date_format.validate("0001-01-01")
    date_format.validate("9999-12-31")
    date_format.validate("2019-01-01")
    date_format.validate("2019-12-31")
    date_format.validate("0001-01-01")
    date_format.validate("9999-12-31")
    date_format.validate("2019-01-01")
    date_format.validate("2019-12-31")
    date_format.validate("0001-01-01")
    date_format.validate("9999-12-31")

# Generated at 2022-06-18 12:15:21.068089
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:15:29.626647
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00+00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:15:41.188130
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-1-1") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-1") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-1-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-12-3") == datetime.date(2019, 12, 3)

# Generated at 2022-06-18 12:15:43.576719
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:15:53.653631
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:16:05.383989
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:16:17.543136
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)

# Generated at 2022-06-18 12:16:29.758169
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12345") == datetime.time(12, 0, 0, 12345)
    assert time_format.validate("12:00:00.1234567") == datetime.time(12, 0, 0, 123456)

# Generated at 2022-06-18 12:16:36.365230
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") != datetime.date(2019, 1, 2)
    assert date_format.validate("2019-01-01") != datetime.date(2019, 2, 1)
    assert date_format.validate("2019-01-01") != datetime.date(2018, 1, 1)


# Generated at 2022-06-18 12:16:47.374180
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2020-03-01") == datetime.date(2020, 3, 1)
    assert date_format.validate("2020-04-01") == datetime.date(2020, 4, 1)
    assert date_format.validate("2020-05-01") == datetime.date(2020, 5, 1)
    assert date_format.validate("2020-06-01") == datetime.date(2020, 6, 1)

# Generated at 2022-06-18 12:16:56.990891
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-12-31")
    date_format.validate("0001-01-01")
    date_format.validate("9999-12-31")
    date_format.validate("2020-01-01")
    date_format.validate("2020-12-31")
    date_format.validate("0001-01-01")
    date_format.validate("9999-12-31")
    date_format.validate("2020-01-01")
    date_format.validate("2020-12-31")
    date_format.validate("0001-01-01")
    date_format.validate("9999-12-31")

# Generated at 2022-06-18 12:17:07.371393
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.")
    time_format.validate("12:00:00")
    time_format.validate("12:00")
    time_format.validate("12")
    time_format.validate("12:00:00.1234567")

# Generated at 2022-06-18 12:17:19.788124
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-12-31")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-31")
    date_format.validate("2019-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-03-31")
    date_format.validate("2020-04-30")
    date_format.validate("2020-05-31")
    date_format.validate("2020-06-30")
    date_format.validate("2020-07-31")
    date_format.validate("2020-08-31")
    date_format.validate("2020-09-30")

# Generated at 2022-06-18 12:17:27.448912
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date.validate("2019-02-28") == datetime.date(2019, 2, 28)
    assert date.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date.validate("2020-02-29") == datetime.date(2020, 2, 29)

# Generated at 2022-06-18 12:17:30.010236
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")


# Generated at 2022-06-18 12:17:40.501227
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:17:47.110926
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)


# Generated at 2022-06-18 12:17:51.166054
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-12-31") != datetime.date(2019, 12, 30)


# Generated at 2022-06-18 12:18:02.142186
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)
    assert time_format.validate("12:34:56.1") == datetime.time(12, 34, 56, 100000)

# Generated at 2022-06-18 12:18:12.806134
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:18:25.338481
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:18:35.785528
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:18:45.906537
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.1234567") == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-18 12:18:58.866301
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test case 1
    date_format = DateFormat()
    value = "2020-01-01"
    expected = datetime.date(2020, 1, 1)
    actual = date_format.validate(value)
    assert actual == expected

    # Test case 2
    date_format = DateFormat()
    value = "2020-01-32"
    try:
        date_format.validate(value)
    except ValidationError as e:
        assert e.code == "invalid"
    else:
        assert False

    # Test case 3
    date_format = DateFormat()
    value = "2020-01-01T00:00:00"
    try:
        date_format.validate(value)
    except ValidationError as e:
        assert e.code == "format"

# Generated at 2022-06-18 12:19:09.461755
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(obj) == "2020-01-01T00:00:00Z"

    obj = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))
    assert DateTimeFormat().serialize(obj) == "2020-01-01T00:00:00+01:00"

    obj = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-1)))

# Generated at 2022-06-18 12:19:20.410206
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # test for obj is None
    assert DateTimeFormat().serialize(None) == None

    # test for obj is not None
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"

# Generated at 2022-06-18 12:19:34.470184
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:19:44.798669
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1000)) == '2020-01-01T00:00:00.001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1000000)) == '2020-01-01T00:00:00.001000'

# Generated at 2022-06-18 12:19:54.690873
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:20:05.814462
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test case 1
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    # Test case 2
    date_format.validate("2020-01-01")
    # Test case 3
    date_format.validate("2020-01-01")
    # Test case 4
    date_format.validate("2020-01-01")
    # Test case 5
    date_format.validate("2020-01-01")
    # Test case 6
    date_format.validate("2020-01-01")
    # Test case 7
    date_format.validate("2020-01-01")
    # Test case 8
    date_format.validate("2020-01-01")
    # Test case 9
    date_format.validate("2020-01-01")
   

# Generated at 2022-06-18 12:20:15.783210
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:20:27.055215
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:20:33.736179
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)


# Generated at 2022-06-18 12:20:39.731744
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:20:51.612823
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)

# Generated at 2022-06-18 12:21:03.659067
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:21:19.118948
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0)) == "2019-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2019-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2019-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:21:28.672468
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-04-01") == datetime.date(2020, 4, 1)
    assert date_format.validate("2020-04-01") != datetime.date(2020, 4, 2)
    assert date_format.validate("2020-04-01") != datetime.date(2020, 4, 3)
    assert date_format.validate("2020-04-01") != datetime.date(2020, 4, 4)
    assert date_format.validate("2020-04-01") != datetime.date(2020, 4, 5)
    assert date_format.validate("2020-04-01") != datetime.date(2020, 4, 6)

# Generated at 2022-06-18 12:21:32.741687
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 4, 1, 12, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-04-01T12:00:00Z"

# Generated at 2022-06-18 12:21:41.836542
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:21:51.072853
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:21:58.494298
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12345") == datetime.time(12, 0, 0, 12345)
    assert time_format.validate("12:00:00.1234") == datetime.time(12, 0, 0, 123400)

# Generated at 2022-06-18 12:22:07.887556
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56")
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234567")
    time_format.validate("12:34:56.12345678")
    time_format.validate("12:34:56.123456789")

# Generated at 2022-06-18 12:22:17.397278
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('00:00:00') == datetime.time(0, 0, 0)
    assert time_format.validate('00:00:00.000000') == datetime.time(0, 0, 0)
    assert time_format.validate('00:00:00.000001') == datetime.time(0, 0, 0, 1)
    assert time_format.validate('00:00:00.000010') == datetime.time(0, 0, 0, 10)
    assert time_format.validate('00:00:00.000100') == datetime.time(0, 0, 0, 100)
    assert time_format.validate('00:00:00.001000') == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:22:28.335337
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("10:00:00") == datetime.time(10, 0, 0)
    assert time_format.validate("10:00:00.123456") == datetime.time(10, 0, 0, 123456)
    assert time_format.validate("10:00:00.123") == datetime.time(10, 0, 0, 123000)
    assert time_format.validate("10:00:00.12") == datetime.time(10, 0, 0, 120000)
    assert time_format.validate("10:00:00.1") == datetime.time(10, 0, 0, 100000)

# Generated at 2022-06-18 12:22:37.563082
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:22:56.182935
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'