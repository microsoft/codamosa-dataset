

# Generated at 2022-06-18 12:13:18.795510
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)
    assert time_format.validate("12:34:56.1") == datetime.time(12, 34, 56, 100000)

# Generated at 2022-06-18 12:13:27.144676
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00.000001Z'

# Generated at 2022-06-18 12:13:35.829800
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2020-01-01T00:00:00+01:00"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3
    value = "2020-01-01T00:00:00-01:00"
    expected = datetime

# Generated at 2022-06-18 12:13:42.713544
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dtf = DateTimeFormat()
    assert dtf.serialize(datetime.datetime.now()) is not None
    assert dtf.serialize(datetime.datetime.now()) is not None
    assert dtf.serialize(datetime.datetime.now()) is not None
    assert dtf.serialize(datetime.datetime.now()) is not None
    assert dtf.serialize(datetime.datetime.now()) is not None
    assert dtf.serialize(datetime.datetime.now()) is not None
    assert dtf.serialize(datetime.datetime.now()) is not None
    assert dtf.serialize(datetime.datetime.now()) is not None
    assert dtf.serialize(datetime.datetime.now()) is not None

# Generated at 2022-06-18 12:13:50.913971
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2020-01-01T00:00:00")
    date_time_format.validate("2020-01-01T00:00:00Z")
    date_time_format.validate("2020-01-01T00:00:00+00:00")
    date_time_format.validate("2020-01-01T00:00:00-00:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
    date_time_format.validate("2020-01-01T00:00:00-01:00")
    date_time_format.validate("2020-01-01T00:00:00+01")

# Generated at 2022-06-18 12:14:01.384452
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:14:03.856170
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2020, 1, 1)) == "2020-01-01"


# Generated at 2022-06-18 12:14:12.619360
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)
    assert time_format.validate("12:34:56.1") == datetime.time(12, 34, 56, 100000)

# Generated at 2022-06-18 12:14:15.373605
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 1, 1)
    date_format = DateFormat()
    assert date_format.serialize(date) == "2020-01-01"


# Generated at 2022-06-18 12:14:25.995691
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T12:00:00+02:00"

# Generated at 2022-06-18 12:14:46.292589
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2019, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 1, 1, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 1, 1, 1, 1, 1)
    assert date_format.validate

# Generated at 2022-06-18 12:14:57.807503
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:15:07.438969
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("d4f6e8d1-b3e3-4c3c-a9c8-b9b9d4f6e8d1") == uuid.UUID("d4f6e8d1-b3e3-4c3c-a9c8-b9b9d4f6e8d1")
    assert uuid_format.validate("d4f6e8d1b3e34c3ca9c8b9b9d4f6e8d1") == uuid.UUID("d4f6e8d1b3e34c3ca9c8b9b9d4f6e8d1")

# Generated at 2022-06-18 12:15:14.608420
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("1d8b2c9c-f8d5-4b1d-8f2b-7e9d9c9f7d8b") == uuid.UUID("1d8b2c9c-f8d5-4b1d-8f2b-7e9d9c9f7d8b")


# Generated at 2022-06-18 12:15:25.251058
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    dtf = DateTimeFormat()
    assert dtf.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 2
    value = "2020-01-01T00:00:00"
    dtf = DateTimeFormat()
    assert dtf.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0)

    # Test case 3
    value = "2020-01-01T00:00:00.123456"
    dtf = DateTimeFormat()

# Generated at 2022-06-18 12:15:29.820500
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("b4c0b1cb-f0c8-4e13-8d15-9b8a8f5c9d3a") == uuid.UUID("b4c0b1cb-f0c8-4e13-8d15-9b8a8f5c9d3a")


# Generated at 2022-06-18 12:15:41.330196
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:15:52.142953
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:16:00.533762
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time = date_time_format.validate("2019-12-31T23:59:59.999999Z")
    assert date_time.year == 2019
    assert date_time.month == 12
    assert date_time.day == 31
    assert date_time.hour == 23
    assert date_time.minute == 59
    assert date_time.second == 59
    assert date_time.microsecond == 999999
    assert date_time.tzinfo == datetime.timezone.utc


# Generated at 2022-06-18 12:16:03.345389
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:16:16.011932
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.1234567")
    time_format.validate("12:00:00.12345678")

# Generated at 2022-06-18 12:16:27.089565
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:16:30.680499
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:16:39.254451
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("00:00:00")
    time_format.validate("00:00:00.000000")
    time_format.validate("00:00:00.000001")
    time_format.validate("00:00:00.000010")
    time_format.validate("00:00:00.000100")
    time_format.validate("00:00:00.001000")
    time_format.validate("00:00:00.010000")
    time_format.validate("00:00:00.100000")
    time_format.validate("00:00:01.000000")
    time_format.validate("00:01:00.000000")
    time_format.validate("01:00:00.000000")

# Generated at 2022-06-18 12:16:50.568191
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-12-31")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")

# Generated at 2022-06-18 12:16:53.369665
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2020-01-01")
    assert date.year == 2020
    assert date.month == 1
    assert date.day == 1


# Generated at 2022-06-18 12:17:00.496231
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00.000001Z'

# Generated at 2022-06-18 12:17:03.076480
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:17:13.667593
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:17:24.420490
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:17:39.624987
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:17:50.851172
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-12-31T23:59:59.999999Z"
    expected = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2019-12-31T23:59:59.999999+00:00"
    expected = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3

# Generated at 2022-06-18 12:18:01.861034
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2019-10-10T10:10:10.123456Z")
    date_time_format.validate("2019-10-10T10:10:10.123456+00:00")
    date_time_format.validate("2019-10-10T10:10:10.123456+01:00")
    date_time_format.validate("2019-10-10T10:10:10.123456-01:00")
    date_time_format.validate("2019-10-10T10:10:10.123456+01")
    date_time_format.validate("2019-10-10T10:10:10.123456-01")

# Generated at 2022-06-18 12:18:12.464998
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-02-28") == datetime.date(2019, 2, 28)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)

# Generated at 2022-06-18 12:18:20.565744
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert date.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert date.validate("2020-01-01") != datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:18:22.823316
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:18:25.955097
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2020-01-01")
    assert date == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:18:36.239459
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-12-31")
    date_format.validate("2020-01-31")
    date_format.validate("2020-02-29")
    date_format.validate("2020-02-28")
    date_format.validate("2020-02-01")
    date_format.validate("2020-02-02")
    date_format.validate("2020-02-03")
    date_format.validate("2020-02-04")
    date_format.validate("2020-02-05")
    date_format.validate("2020-02-06")
    date_format.validate("2020-02-07")

# Generated at 2022-06-18 12:18:46.392086
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0)) == '2019-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2019-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2019-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:18:59.413552
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T00:00:00Z"

    dt = datetime.datetime(2020, 1, 1, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert DateTimeFormat().serialize(dt) == "2020-01-01T00:00:00+01:00"

    dt = datetime.datetime(2020, 1, 1, tzinfo=datetime.timezone(datetime.timedelta(hours=-1)))
    assert DateTimeFormat().serialize(dt) == "2020-01-01T00:00:00-01:00"

# Generated at 2022-06-18 12:19:05.928467
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:19:13.608318
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56")
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234567")
    time_format.validate("12:34:56.12345678")
    time_format.validate("12:34:56.123456789")

# Generated at 2022-06-18 12:19:24.575097
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:19:36.605472
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:19:46.831117
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:19:57.182857
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:20:08.155863
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1234)) == "2020-01-01T00:00:00.001234"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 123456)) == "2020-01-01T00:00:00.123456"

# Generated at 2022-06-18 12:20:17.529321
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-31") == datetime.date(2020, 1, 31)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2019-02-28") == datetime.date(2019, 2, 28)
    assert date_format.validate("2019-02-29") == datetime.date(2019, 2, 29)

# Generated at 2022-06-18 12:20:28.333297
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:20:37.632770
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.12345") == datetime.time(12, 0, 0, 12345)
    assert time_format.validate("12:00:00.1234") == datetime.time(12, 0, 0, 123400)
    assert time_format

# Generated at 2022-06-18 12:20:53.266238
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)

# Generated at 2022-06-18 12:21:04.803126
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)
    assert time_format.validate("12:34:56.1") == datetime.time(12, 34, 56, 100000)

# Generated at 2022-06-18 12:21:17.513109
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12345") == datetime.time(12, 0, 0, 12345)

# Generated at 2022-06-18 12:21:27.683580
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:21:38.137024
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("23:59:59") == datetime.time(23, 59, 59)
    assert time_format.validate("23:59:59.999999") == datetime.time(23, 59, 59, 999999)
    assert time_format.validate("23:59:59.999999999") == datetime.time(23, 59, 59, 999999)
    assert time_format.validate("23:59:59.999999999999") == datetime.time(23, 59, 59, 999999)
    assert time_format.validate("23:59:59.99999999999999") == datetime.time(23, 59, 59, 999999)
    assert time_format.validate("23:59:59.9999999999999999") == dat

# Generated at 2022-06-18 12:21:46.158990
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)

# Generated at 2022-06-18 12:21:54.928589
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:22:04.805866
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:22:14.076216
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2019, 1, 1, 12, 0, 0, 0)
    assert DateTimeFormat().serialize(dt) == '2019-01-01T12:00:00'
    dt = datetime.datetime(2019, 1, 1, 12, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == '2019-01-01T12:00:00Z'
    dt = datetime.datetime(2019, 1, 1, 12, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert DateTimeFormat().serialize(dt) == '2019-01-01T12:00:00+01:00'

# Generated at 2022-06-18 12:22:25.444801
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:22:42.356014
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2019, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 1, 1, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 1, 1, 1, 1, 1)


# Generated at 2022-06-18 12:22:54.037193
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"