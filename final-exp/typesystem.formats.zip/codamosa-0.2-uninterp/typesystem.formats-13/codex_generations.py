

# Generated at 2022-06-18 12:13:18.935063
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test for case:
    #   value = '2019-01-01T00:00:00Z'
    #   expected = datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    value = '2019-01-01T00:00:00Z'
    expected = datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test for case:
    #   value = '2019-01-01T00:00:00+00:00'
    #   expected = datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.

# Generated at 2022-06-18 12:13:27.267458
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:13:32.904805
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234567")
    time_format.validate("12:00:00.12345678")

# Generated at 2022-06-18 12:13:40.975236
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:13:49.106697
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:13:55.717653
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:14:05.455571
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("123e4567-e89b-12d3-a456-426655440000") == uuid.UUID("123e4567-e89b-12d3-a456-426655440000")
    assert uuid_format.validate("123e4567e89b12d3a456426655440000") == uuid.UUID("123e4567e89b12d3a456426655440000")
    assert uuid_format.validate("123e4567e89b12d3a456426655440000") == uuid.UUID("123e4567e89b12d3a456426655440000")

# Generated at 2022-06-18 12:14:07.591049
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:14:10.909122
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:00:00Z"

# Generated at 2022-06-18 12:14:21.319305
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate('2020-01-01T00:00:00') == datetime.datetime(2020, 1, 1, 0, 0, 0)
    assert dtf.validate('2020-01-01T00:00:00Z') == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate('2020-01-01T00:00:00+01:00') == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:14:37.842340
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:14:45.011787
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:14:55.599275
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-12-31T12:34:56.123456Z"
    datetime_format = DateTimeFormat()
    result = datetime_format.validate(value)
    assert result == datetime.datetime(2019, 12, 31, 12, 34, 56, 123456, datetime.timezone.utc)

    # Test case 2
    value = "2019-12-31T12:34:56.123456+01:00"
    datetime_format = DateTimeFormat()
    result = datetime_format.validate(value)
    assert result == datetime.datetime(2019, 12, 31, 12, 34, 56, 123456, datetime.timezone(datetime.timedelta(hours=1)))

    # Test case 3

# Generated at 2022-06-18 12:15:06.534574
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-12-31T23:59:59.999999Z") == datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-12-31T23:59:59.999999+00:00") == datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-12-31T23:59:59.999999+01:00") == datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:15:18.767378
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T12:00:00Z"
    datetime_format = DateTimeFormat()
    result = datetime_format.validate(value)
    assert result == datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 2
    value = "2020-01-01T12:00:00+01:00"
    datetime_format = DateTimeFormat()
    result = datetime_format.validate(value)
    assert result == datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

    # Test case 3

# Generated at 2022-06-18 12:15:28.310079
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:15:40.055281
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = '2020-03-20T10:00:00Z'
    format = DateTimeFormat()
    assert format.validate(value) == datetime.datetime(2020, 3, 20, 10, 0, 0, 0, datetime.timezone.utc)
    # Test case 2
    value = '2020-03-20T10:00:00+00:00'
    format = DateTimeFormat()
    assert format.validate(value) == datetime.datetime(2020, 3, 20, 10, 0, 0, 0, datetime.timezone.utc)
    # Test case 3
    value = '2020-03-20T10:00:00+01:00'
    format = DateTimeFormat()

# Generated at 2022-06-18 12:15:51.058102
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:16:02.265633
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-12-31T23:59:59.999999Z"
    expected_result = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    result = DateTimeFormat().validate(value)
    assert result == expected_result

    # Test case 2
    value = "2019-12-31T23:59:59.999999+01:00"
    expected_result = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    result = DateTimeFormat().validate(value)
    assert result == expected_result

    # Test case 3

# Generated at 2022-06-18 12:16:12.834877
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert DateFormat().validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert DateFormat().validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert DateFormat().validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert DateFormat().validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert DateFormat().validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert DateFormat().validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:16:26.088019
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:16:37.028536
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:16:48.321494
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:16:57.644146
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:17:00.900958
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2019-12-31') == datetime.date(2019, 12, 31)


# Generated at 2022-06-18 12:17:08.997087
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")
    date_format.validate("2019-10-10")

# Generated at 2022-06-18 12:17:21.294229
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0)) == '2020-01-01T12:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T12:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T12:00:00+01:00'

# Generated at 2022-06-18 12:17:32.919598
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:17:36.736318
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T00:00:00Z"

# Generated at 2022-06-18 12:17:40.124662
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)


# Generated at 2022-06-18 12:17:54.144820
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate

# Generated at 2022-06-18 12:18:04.509193
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:18:16.317382
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.123456789")
    time_format.validate("12:34:56.12345678")
    time_format.validate

# Generated at 2022-06-18 12:18:28.383831
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234567")

# Generated at 2022-06-18 12:18:34.068952
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:18:44.400058
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.1234567") == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-18 12:18:57.101743
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1)
    assert time_format.validate("12:00:00.000010") == datetime.time(12, 0, 0, 10)
    assert time_format.validate("12:00:00.000100") == datetime.time(12, 0, 0, 100)
    assert time_format.validate("12:00:00.001000") == datetime.time(12, 0, 0, 1000)


# Generated at 2022-06-18 12:19:00.827094
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:19:10.885407
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:19:14.049321
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:19:29.185480
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00")
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.1234567")
    time_format.validate("12:00:00.12345678")
    time

# Generated at 2022-06-18 12:19:41.149350
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:19:50.840420
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:20:01.618444
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('12:00:00') == datetime.time(12, 0, 0)
    assert time_format.validate('12:00:00.123456') == datetime.time(12, 0, 0, 123456)
    assert time_format.validate('12:00') == datetime.time(12, 0)
    assert time_format.validate('12:00:00.123') == datetime.time(12, 0, 0, 123000)
    assert time_format.validate('12:00:00.12') == datetime.time(12, 0, 0, 120000)
    assert time_format.validate('12:00:00.1') == datetime.time(12, 0, 0, 100000)
    assert time_format

# Generated at 2022-06-18 12:20:12.551482
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2020-01-01T00:00:00Z")
    date_time_format.validate("2020-01-01T00:00:00+00:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
   

# Generated at 2022-06-18 12:20:25.157006
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    assert date_time_format.serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00+00:00"
    assert date_time_format.serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T00:00:00+02:00"

# Generated at 2022-06-18 12:20:35.500069
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.123456789")
    time_format.validate("12:34:56.12345678")
    time_format.validate

# Generated at 2022-06-18 12:20:46.619576
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T12:00:00+01:00"

# Generated at 2022-06-18 12:20:58.759781
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-1-1") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-1") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-1-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-12-3") == datetime.date(2020, 12, 3)

# Generated at 2022-06-18 12:21:08.634033
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0)) == '2019-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == '2019-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == '2019-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:21:26.242028
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:21:36.435321
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:21:38.848276
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time = time_format.validate('12:34:56.123456')
    assert time.hour == 12
    assert time.minute == 34
    assert time.second == 56
    assert time.microsecond == 123456


# Generated at 2022-06-18 12:21:47.189747
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2019-12-31T23:59:59.999999Z")
    date_time_format.validate("2019-12-31T23:59:59.999999+00:00")
    date_time_format.validate("2019-12-31T23:59:59.999999+01:00")
    date_time_format.validate("2019-12-31T23:59:59.999999-01:00")
    date_time_format.validate("2019-12-31T23:59:59.999999+01:30")
    date_time_format.validate("2019-12-31T23:59:59.999999-01:30")

# Generated at 2022-06-18 12:21:54.635233
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:22:04.422479
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-12-31")
    date_format.validate("0001-01-01")
    date_format.validate("9999-12-31")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")

# Generated at 2022-06-18 12:22:11.366680
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:22:13.806998
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:22:25.159154
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:22:33.063237
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2020-01-01T00:00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0)
    assert dtf.validate("2020-01-01T00:00:00.123456") == datetime.datetime(2020, 1, 1, 0, 0, 0, 123456)
    assert dtf.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-18 12:22:48.332376
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-1)))) == "2020-01-01T00:00:00-01:00"

# Generated at 2022-06-18 12:22:58.887898
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)