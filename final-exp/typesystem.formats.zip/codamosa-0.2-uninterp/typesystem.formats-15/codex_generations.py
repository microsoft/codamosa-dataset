

# Generated at 2022-06-18 12:13:13.234212
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 1234)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 12)

# Generated at 2022-06-18 12:13:22.327750
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")

# Generated at 2022-06-18 12:13:29.802385
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-31") == datetime.date(2019, 1, 31)
    assert date_format.validate("2019-02-28") == datetime.date(2019, 2, 28)
    assert date_format.validate("2019-02-29") == datetime.date(2019, 2, 29)
    assert date_format.validate("2019-03-01") == datetime.date(2019, 3, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)

# Generated at 2022-06-18 12:13:38.542489
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2020, 2, 2, 2, 2, 2, 2, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(obj) == "2020-02-02T02:02:02.000002+00:00"

    obj = datetime.datetime(2020, 2, 2, 2, 2, 2, 2, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert DateTimeFormat().serialize(obj) == "2020-02-02T02:02:02.000002+01:00"

    obj = datetime.datetime(2020, 2, 2, 2, 2, 2, 2, tzinfo=datetime.timezone(datetime.timedelta(hours=-1)))

# Generated at 2022-06-18 12:13:41.051712
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(hour=12, minute=34, second=56, microsecond=123456)
    assert TimeFormat().serialize(time) == "12:34:56.123456"


# Generated at 2022-06-18 12:13:49.180793
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:13:55.768833
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("00000000-0000-0000-0000-000000000000") == uuid.UUID("00000000-0000-0000-0000-000000000000")
    assert uuid_format.validate("11111111-1111-1111-1111-111111111111") == uuid.UUID("11111111-1111-1111-1111-111111111111")
    assert uuid_format.validate("22222222-2222-2222-2222-222222222222") == uuid.UUID("22222222-2222-2222-2222-222222222222")
    assert uuid_format.validate("33333333-3333-3333-3333-333333333333") == uuid.UUID("33333333-3333-3333-3333-333333333333")


# Generated at 2022-06-18 12:14:05.529691
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2020-01-01T00:00:00+01:00"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3
    value = "2020-01-01T00:00:00-01:00"
    expected = datetime

# Generated at 2022-06-18 12:14:14.097302
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")
    uuid_format.validate("1b4e28ba-2fa1-11d2-883f-0016d3cca427")

# Generated at 2022-06-18 12:14:25.025247
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:14:39.074657
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:14:45.870888
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00+00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-1)))) == "2020-01-01T00:00:00-01:00"

# Generated at 2022-06-18 12:14:56.968605
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem.base import ValidationError
    from typesystem.formats import DateTimeFormat
    date_time_format = DateTimeFormat()
    try:
        date_time_format.validate('2019-01-01T00:00:00Z')
    except ValidationError:
        assert False
    try:
        date_time_format.validate('2019-01-01T00:00:00+00:00')
    except ValidationError:
        assert False
    try:
        date_time_format.validate('2019-01-01T00:00:00+01:00')
    except ValidationError:
        assert False
    try:
        date_time_format.validate('2019-01-01T00:00:00+01:30')
    except ValidationError:
        assert False

# Generated at 2022-06-18 12:15:07.101807
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test for valid datetime format
    value = "2020-01-01T00:00:00Z"
    assert DateTimeFormat().validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test for invalid datetime format
    value = "2020-01-01T00:00:00"
    with pytest.raises(ValidationError):
        DateTimeFormat().validate(value)

    # Test for valid datetime format with timezone
    value = "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:15:19.417547
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 123456)) == "2020-01-01T00:00:00.123456"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1234567)) == "2020-01-01T00:00:00.123456"

# Generated at 2022-06-18 12:15:28.757528
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.")
    time_format.validate("12:00:00")
    time_format.validate("12:00")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")

# Generated at 2022-06-18 12:15:40.455396
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56")
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.12345")

# Generated at 2022-06-18 12:15:51.406518
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0)) == "2019-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 1)) == "2019-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == "2019-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:16:02.632517
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate

# Generated at 2022-06-18 12:16:13.268987
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.123456789")
    time_format.validate("12:00:00.12345678")

# Generated at 2022-06-18 12:16:27.598194
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:16:37.963281
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate('2020-01-01T00:00:00Z') == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate('2020-01-01T00:00:00+00:00') == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate('2020-01-01T00:00:00+01:00') == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:16:49.189501
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test with valid datetime
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime

# Generated at 2022-06-18 12:16:58.292612
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:17:07.911448
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:17:20.319277
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:17:27.749796
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert tf.validate("12:34:56") == datetime.time(12, 34, 56)
    assert tf.validate("12:34") == datetime.time(12, 34)
    assert tf.validate("12") == datetime.time(12)
    assert tf.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert tf.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)
    assert tf.validate("12:34:56.1") == datetime.time(12, 34, 56, 100000)
   

# Generated at 2022-06-18 12:17:39.247503
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:17:50.205492
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:18:01.548284
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:18:13.214623
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2019-12-31') == datetime.date(2019, 12, 31)
    with pytest.raises(ValidationError):
        date_format.validate('2019-13-31')
    with pytest.raises(ValidationError):
        date_format.validate('2019-12-32')
    with pytest.raises(ValidationError):
        date_format.validate('2019-12-31T12:00:00')
    with pytest.raises(ValidationError):
        date_format.validate('2019-12-31 12:00:00')


# Generated at 2022-06-18 12:18:25.679454
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T12:00:00+01:00"

# Generated at 2022-06-18 12:18:30.774124
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Test for obj is None
    assert DateTimeFormat().serialize(None) == None
    # Test for obj is not None
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'


# Generated at 2022-06-18 12:18:39.402592
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:30:00") == datetime.time(12, 30, 0)
    assert time_format.validate("12:30:00.123456") == datetime.time(12, 30, 0, 123456)
    assert time_format.validate("12:30:00.123") == datetime.time(12, 30, 0, 123000)
    assert time_format.validate("12:30:00.12") == datetime.time(12, 30, 0, 120000)
    assert time_format.validate("12:30:00.1") == datetime.time(12, 30, 0, 100000)

# Generated at 2022-06-18 12:18:51.558811
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dtf = DateTimeFormat()
    assert dtf.serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert dtf.serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T12:00:00+01:00"
    assert dtf.serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1, minutes=30)))) == "2020-01-01T12:00:00+01:30"

# Generated at 2022-06-18 12:19:03.478824
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dtf = DateTimeFormat()
    assert dtf.serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == '2020-01-01T00:00:00+00:00'
    assert dtf.serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'
    assert dtf.serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-1)))) == '2020-01-01T00:00:00-01:00'
    assert dtf.serial

# Generated at 2022-06-18 12:19:12.429204
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:19:19.225556
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date.validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert date.validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert date.validate('2020-01-01') != datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:19:30.718297
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:19:38.064746
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert df.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert df.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert df.validate("2020-01-01") != datetime.date(2021, 1, 1)


# Generated at 2022-06-18 12:19:50.139980
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:20:00.886253
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123456Z")
    time_format.validate("12:34:56.12345Z")

# Generated at 2022-06-18 12:20:11.837495
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.")
    time_format.validate("12:00:00")
    time_format.validate("12:00")
    time_format.validate("12")
    time_format.validate("12:00:00.1234567")
    time_format.validate("12:00:00.12345678")

# Generated at 2022-06-18 12:20:19.568260
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-11-11T11:11:11.111111Z"
    expected = datetime.datetime(2019, 11, 11, 11, 11, 11, 111111, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2019-11-11T11:11:11.111111+11:11"
    expected = datetime.datetime(2019, 11, 11, 11, 11, 11, 111111, tzinfo=datetime.timezone(datetime.timedelta(hours=11, minutes=11)))
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3

# Generated at 2022-06-18 12:20:25.157893
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("00:00:00") == datetime.time(0, 0, 0)
    assert TimeFormat().validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert TimeFormat().validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert TimeFormat().validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert TimeFormat().validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert TimeFormat().validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)

# Generated at 2022-06-18 12:20:35.498820
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2019-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2019-01-01T00:00:00+01:00"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-1)))) == "2019-01-01T00:00:00-01:00"

# Generated at 2022-06-18 12:20:46.614023
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.000001")
    time_format.validate("12:00:00.000010")
    time_format.validate("12:00:00.000100")
    time_format.validate("12:00:00.001000")
    time_format.validate("12:00:00.010000")
    time_format.validate("12:00:00.100000")
    time_format.validate("12:00:01.000000")
    time_format.validate("12:01:00.000000")
    time_format.validate("13:00:00.000000")

# Generated at 2022-06-18 12:20:51.134954
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == '2020-01-01T00:00:00+00:00'

# Generated at 2022-06-18 12:21:03.173452
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:21:15.374703
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    dateTimeFormat.validate("2019-01-01T00:00:00Z")
    dateTimeFormat.validate("2019-01-01T00:00:00+00:00")
    dateTimeFormat.validate("2019-01-01T00:00:00-00:00")
    dateTimeFormat.validate("2019-01-01T00:00:00+01:00")
    dateTimeFormat.validate("2019-01-01T00:00:00-01:00")
    dateTimeFormat.validate("2019-01-01T00:00:00+01:00")
    dateTimeFormat.validate("2019-01-01T00:00:00-01:00")

# Generated at 2022-06-18 12:21:27.829601
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:21:38.278961
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234567")
    time_format.validate("12:00:00.12345678")

# Generated at 2022-06-18 12:21:46.337240
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1)
    assert time_format.validate("12:00:00.000010") == datetime.time(12, 0, 0, 10)
    assert time_format.validate("12:00:00.000100") == datetime.time(12, 0, 0, 100)
    assert time_format.validate("12:00:00.001000") == datetime.time(12, 0, 0, 1000)


# Generated at 2022-06-18 12:21:55.084768
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:22:04.998110
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T12:00:00+02:00"

# Generated at 2022-06-18 12:22:14.636863
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123456Z")
    time_format.validate("12:34:56Z")
    time_format.validate("12:34Z")
    time_format.validate("12Z")
    time_format.validate("12:34:56.123456+01:00")
    time_format.validate("12:34:56+01:00")
    time_format.validate("12:34+01:00")
    time_format.validate("12+01:00")

# Generated at 2022-06-18 12:22:25.859475
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00.000001Z'

# Generated at 2022-06-18 12:22:33.841934
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T00:00:00+02:00"

# Generated at 2022-06-18 12:22:44.613620
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:22:56.235584
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1)
    assert time_format.validate("12:00:00.000010") == datetime.time(12, 0, 0, 10)
    assert time_format.validate("12:00:00.000100") == datetime.time(12, 0, 0, 100)