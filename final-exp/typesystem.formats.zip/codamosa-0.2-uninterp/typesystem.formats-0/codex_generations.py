

# Generated at 2022-06-18 12:13:17.755129
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2020-01-01T00:00:00Z")
    date_time_format.validate("2020-01-01T00:00:00+00:00")
    date_time_format.validate("2020-01-01T00:00:00-00:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
    date_time_format.validate("2020-01-01T00:00:00-01:00")
    date_time_format.validate("2020-01-01T00:00:00+01:30")
    date_time_format.validate("2020-01-01T00:00:00-01:30")
   

# Generated at 2022-06-18 12:13:26.355164
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:13:35.708442
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == '2020-01-01T00:00:00+00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-1)))) == '2020-01-01T00:00:00-01:00'

# Generated at 2022-06-18 12:13:42.663889
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:13:45.131494
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("123e4567-e89b-12d3-a456-426655440000")


# Generated at 2022-06-18 12:13:52.835830
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-01-01T00:00:00Z"
    expected = datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2019-01-01T00:00:00+01:00"
    expected = datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3
    value = "2019-01-01T00:00:00-01:00"
    expected = datetime

# Generated at 2022-06-18 12:14:02.993848
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:14:12.127050
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-2-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2020-2-28") == datetime.date(2020, 2, 28)
    assert date_format.validate("2020-2-30") == datetime.date(2020, 2, 30)
    assert date_format.validate("2020-2-31") == datetime.date(2020, 2, 31)

# Generated at 2022-06-18 12:14:22.809915
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:14:25.431888
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 1, 1)
    date_format = DateFormat()
    assert date_format.serialize(date) == "2020-01-01"


# Generated at 2022-06-18 12:14:42.656848
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate('12:00:00')
    time_format.validate('12:00:00.000000')
    time_format.validate('12:00:00.123456')
    time_format.validate('12:00:00.123')
    time_format.validate('12:00:00.12')
    time_format.validate('12:00:00.1')
    time_format.validate('12:00:00.1234')
    time_format.validate('12:00:00.12345')
    time_format.validate('12:00:00.1234567')
    time_format.validate('12:00:00.12345678')

# Generated at 2022-06-18 12:14:47.016139
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    time_obj = datetime.time(hour=12, minute=34, second=56, microsecond=123456)
    assert time_format.serialize(time_obj) == '12:34:56.123456'

# Generated at 2022-06-18 12:14:54.425339
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)


# Generated at 2022-06-18 12:15:05.431013
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(hour=12, minute=34, second=56)) == "12:34:56"
    assert TimeFormat().serialize(datetime.time(hour=12, minute=34, second=56, microsecond=123456)) == "12:34:56.123456"
    assert TimeFormat().serialize(datetime.time(hour=12, minute=34, second=56, microsecond=123)) == "12:34:56.000123"
    assert TimeFormat().serialize(datetime.time(hour=12, minute=34, second=56, microsecond=1)) == "12:34:56.000001"
    assert TimeFormat().serialize(datetime.time(hour=12, minute=34, second=56, microsecond=0)) == "12:34:56"

# Generated at 2022-06-18 12:15:17.119877
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert tf.validate("12:34:56") == datetime.time(12, 34, 56)
    assert tf.validate("12:34") == datetime.time(12, 34)
    assert tf.validate("12") == datetime.time(12)
    assert tf.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert tf.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)

# Generated at 2022-06-18 12:15:27.081915
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(hour=12, minute=30, second=45)
    assert TimeFormat().serialize(time) == "12:30:45"

    time = datetime.time(hour=12, minute=30, second=45, microsecond=123456)
    assert TimeFormat().serialize(time) == "12:30:45.123456"

    time = datetime.time(hour=12, minute=30, second=45, microsecond=123)
    assert TimeFormat().serialize(time) == "12:30:45.000123"

    time = datetime.time(hour=12, minute=30, second=45, microsecond=1)
    assert TimeFormat().serialize(time) == "12:30:45.000001"


# Generated at 2022-06-18 12:15:38.635524
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate('12:00:00')
    time_format.validate('12:00:00.000000')
    time_format.validate('12:00')
    time_format.validate('12:00:00.123456')
    time_format.validate('12:00:00.12345')
    time_format.validate('12:00:00.1234')
    time_format.validate('12:00:00.123')
    time_format.validate('12:00:00.12')
    time_format.validate('12:00:00.1')
    time_format.validate('12:00:00.1234567')
    time_format.validate('12:00:00.12345678')
    time

# Generated at 2022-06-18 12:15:49.982244
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.000001")
    time_format.validate("12:00:00.000010")
    time_format.validate("12:00:00.000100")
    time_format.validate("12:00:00.001000")
    time_format.validate("12:00:00.010000")
    time_format.validate("12:00:00.100000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.1234567")

# Generated at 2022-06-18 12:16:00.925042
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:16:11.743162
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:16:24.599072
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.")
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.123456")

# Generated at 2022-06-18 12:16:36.011177
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # test case 1
    value = "2020-01-01T00:00:00Z"
    expected_result = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate(value) == expected_result

    # test case 2
    value = "2020-01-01T00:00:00+00:00"
    expected_result = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate(value) == expected_result

    # test case 3
    value = "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:16:46.846158
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:16:56.600682
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.000001")
    time_format.validate("12:00:00.000010")
    time_format.validate("12:00:00.000100")
    time_format.validate("12:00:00.001000")
    time_format.validate("12:00:00.010000")
    time_format.validate("12:00:00.100000")
    time_format.validate("12:00:00.999999")
    time_format.validate("12:00:00.999999")

# Generated at 2022-06-18 12:17:06.979468
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:17:19.588462
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test 1
    value = "2019-01-01T00:00:00Z"
    datetime_format = DateTimeFormat()
    assert datetime_format.validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test 2
    value = "2019-01-01T00:00:00+01:00"
    datetime_format = DateTimeFormat()
    assert datetime_format.validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

    # Test 3
    value = "2019-01-01T00:00:00-01:00"
    datetime_

# Generated at 2022-06-18 12:17:27.335469
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    dateTimeFormat = DateTimeFormat()
    assert dateTimeFormat.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 2
    value = "2020-01-01T00:00:00+00:00"
    dateTimeFormat = DateTimeFormat()
    assert dateTimeFormat.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 3
    value = "2020-01-01T00:00:00+01:00"
    dateTimeFormat = DateTimeFormat()
    assert date

# Generated at 2022-06-18 12:17:38.937948
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:17:49.692480
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:18:01.065241
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.")
    time_format.validate("12:00:00")
    time_format.validate("12:00:")

# Generated at 2022-06-18 12:18:16.575228
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:18:28.579202
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = '2020-01-01T00:00:00Z'
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 2
    value = '2020-01-01T00:00:00+00:00'
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 3
    value = '2020-01-01T00:00:00+01:00'
    date_time_

# Generated at 2022-06-18 12:18:38.019443
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2020-01-01T00:00:00+00:00"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3
    value = "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:18:49.079375
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:19:01.876245
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)

# Generated at 2022-06-18 12:19:11.603504
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1)
    assert time_format.validate("12:00:00.000010") == datetime.time(12, 0, 0, 10)
    assert time_format.validate("12:00:00.000100") == datetime.time(12, 0, 0, 100)
    assert time_format.validate("12:00:00.001000") == datetime.time(12, 0, 0, 1000)


# Generated at 2022-06-18 12:19:23.100353
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:19:35.219464
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)
    assert time_format.validate("12:34:56.1") == datetime.time(12, 34, 56, 100000)

# Generated at 2022-06-18 12:19:45.525908
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:19:55.661770
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2019-01-01T00:00:00Z")
    date_time_format.validate("2019-01-01T00:00:00+00:00")
    date_time_format.validate("2019-01-01T00:00:00+01:00")
    date_time_format.validate("2019-01-01T00:00:00+01:30")
    date_time_format.validate("2019-01-01T00:00:00-01:00")
    date_time_format.validate("2019-01-01T00:00:00-01:30")
    date_time_format.validate("2019-01-01T00:00:00.123456Z")
   

# Generated at 2022-06-18 12:20:11.463208
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)
    assert time_format.validate("12:34:56.1") == datetime.time(12, 34, 56, 100000)

# Generated at 2022-06-18 12:20:19.412848
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1)
    assert time_format.validate("12:00:00.000010") == datetime.time(12, 0, 0, 10)
    assert time_format.validate("12:00:00.000100") == datetime.time(12, 0, 0, 100)
    assert time_format.validate("12:00:00.001000") == datetime.time(12, 0, 0, 1000)


# Generated at 2022-06-18 12:20:30.166629
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:12:12") == datetime.time(12, 12, 12)
    assert time_format.validate("12:12:12.123456") == datetime.time(12, 12, 12, 123456)
    assert time_format.validate("12:12:12.123") == datetime.time(12, 12, 12, 123000)
    assert time_format.validate("12:12:12.12") == datetime.time(12, 12, 12, 120000)
    assert time_format.validate("12:12:12.1") == datetime.time(12, 12, 12, 100000)

# Generated at 2022-06-18 12:20:38.707270
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:20:50.395458
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:21:02.598365
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:21:13.540895
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:21:25.504807
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.12345")

# Generated at 2022-06-18 12:21:35.476609
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)
    assert time_format

# Generated at 2022-06-18 12:21:41.390579
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    with pytest.raises(ValidationError):
        time_format.validate("12:34:56.1234567")
    with pytest.raises(ValidationError):
        time_format.validate("12:34:56.12345")

# Generated at 2022-06-18 12:21:54.140432
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1)
    assert time.validate("12:00:00.000010") == datetime.time(12, 0, 0, 10)
    assert time.validate("12:00:00.000100") == datetime.time(12, 0, 0, 100)
    assert time.validate("12:00:00.001000") == datetime.time(12, 0, 0, 1000)

# Generated at 2022-06-18 12:22:03.777819
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.1234567")
    time_format.validate("12:34:56.12345678")

# Generated at 2022-06-18 12:22:11.050795
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('00:00:00') == datetime.time(0, 0)
    assert time_format.validate('00:00:00.000000') == datetime.time(0, 0)
    assert time_format.validate('00:00:00.000001') == datetime.time(0, 0, 0, 1)
    assert time_format.validate('00:00:00.000010') == datetime.time(0, 0, 0, 10)
    assert time_format.validate('00:00:00.000100') == datetime.time(0, 0, 0, 100)
    assert time_format.validate('00:00:00.001000') == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:22:22.304788
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:22:27.265152
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-01")

# Generated at 2022-06-18 12:22:34.479360
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 1234)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 12)

# Generated at 2022-06-18 12:22:41.130907
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:22:53.056662
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:23:01.504403
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)