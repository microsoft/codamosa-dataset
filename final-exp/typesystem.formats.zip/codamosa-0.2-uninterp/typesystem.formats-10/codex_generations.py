

# Generated at 2022-06-18 12:13:14.732701
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time.validate("12:34") == datetime.time(12, 34)
    assert time.validate("12") == datetime.time(12)
    assert time.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)
    assert time.validate("12:34:56.1") == datetime.time(12, 34, 56, 100000)
   

# Generated at 2022-06-18 12:13:23.645488
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:13:30.492883
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2020-01-01T00:00:00+00:00"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3
    value = "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:13:39.138174
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2020-01-01T00:00:00Z")
    date_time_format.validate("2020-01-01T00:00:00+00:00")
    date_time_format.validate("2020-01-01T00:00:00+01:00")
    date_time_format.validate("2020-01-01T00:00:00-01:00")
    date_time_format.validate("2020-01-01T00:00:00+01")
    date_time_format.validate("2020-01-01T00:00:00-01")
    date_time_format.validate("2020-01-01T00:00:00")
    date_time_format.validate

# Generated at 2022-06-18 12:13:47.214714
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:13:54.339432
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00")
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.123456789")
    time_format.validate("12:00:00.12345678")
   

# Generated at 2022-06-18 12:13:57.760055
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    time = datetime.time(hour=12, minute=34, second=56, microsecond=123456)
    assert time_format.serialize(time) == "12:34:56.123456"

# Generated at 2022-06-18 12:14:07.122707
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:14:17.873673
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1, minutes=30)))) == "2020-01-01T00:00:00+01:30"

# Generated at 2022-06-18 12:14:27.305998
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-12-31") != datetime.date(2019, 12, 30)
    assert date_format.validate("2019-12-31") != datetime.date(2019, 12, 32)
    assert date_format.validate("2019-12-31") != datetime.date(2019, 11, 31)
    assert date_format.validate("2019-12-31") != datetime.date(2020, 12, 31)
    assert date_format.validate("2019-12-31") != datetime.date(2019, 12, 31, 12, 0, 0, 0)

# Generated at 2022-06-18 12:14:34.225220
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2019, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2019-01-01T12:00:00Z"

# Generated at 2022-06-18 12:14:37.676709
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2020-01-01")
    assert isinstance(date, datetime.date)
    assert date.year == 2020
    assert date.month == 1
    assert date.day == 1


# Generated at 2022-06-18 12:14:44.862802
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2019-02-29") == datetime.date(2019, 2, 29)
    assert date_format.validate("2019-02-28") == datetime.date(2019, 2, 28)
    assert date_format.validate("2019-02-27") == datetime.date(2019, 2, 27)

# Generated at 2022-06-18 12:14:55.599296
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)

# Generated at 2022-06-18 12:15:06.534459
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:15:18.765872
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")

# Generated at 2022-06-18 12:15:28.309281
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2020-01-01T00:00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0)
    assert date_time_format.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2020-01-01T00:00:00+01:00")

# Generated at 2022-06-18 12:15:40.002456
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:15:51.010818
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:15:53.336079
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    dateFormat = DateFormat()
    assert dateFormat.serialize(datetime.date(2020, 1, 1)) == '2020-01-01'


# Generated at 2022-06-18 12:16:07.767801
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate

# Generated at 2022-06-18 12:16:18.017780
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.123456789")
    time_format.validate("12:34:56.12345678")
    time_format.validate

# Generated at 2022-06-18 12:16:30.327965
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")

# Generated at 2022-06-18 12:16:39.030843
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")
    uuid_format.validate("12345678-1234-5678-1234-567812345678")

# Generated at 2022-06-18 12:16:50.372413
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:16:58.808028
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = '2019-12-31T23:59:59.999999Z'
    result = DateTimeFormat().validate(value)
    assert result == datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)

    # Test case 2
    value = '2019-12-31T23:59:59.999999+00:00'
    result = DateTimeFormat().validate(value)
    assert result == datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)

    # Test case 3
    value = '2019-12-31T23:59:59.999999+01:00'
    result = DateTimeFormat().valid

# Generated at 2022-06-18 12:17:08.157030
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:17:20.558420
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("8d4c4b4f-b8d2-4e6d-b9c5-a9e7f3d8a8b7")
    uuid_format.validate("8d4c4b4f-b8d2-4e6d-b9c5-a9e7f3d8a8b7")
    uuid_format.validate("8d4c4b4f-b8d2-4e6d-b9c5-a9e7f3d8a8b7")
    uuid_format.validate("8d4c4b4f-b8d2-4e6d-b9c5-a9e7f3d8a8b7")


# Generated at 2022-06-18 12:17:27.873941
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("00000000-0000-0000-0000-000000000000")
    uuid_format.validate("11111111-1111-1111-1111-111111111111")
    uuid_format.validate("22222222-2222-2222-2222-222222222222")
    uuid_format.validate("33333333-3333-3333-3333-333333333333")
    uuid_format.validate("44444444-4444-4444-4444-444444444444")
    uuid_format.validate("55555555-5555-5555-5555-555555555555")
    uuid_format.validate("66666666-6666-6666-6666-666666666666")
    uuid_format.valid

# Generated at 2022-06-18 12:17:39.337430
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.000001")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.1234567")
    time_format.validate("12:00:00.12345678")
    time_format.validate("12:00:00.123456789")
    time_format.validate("12:00:00.1234567890")
    time_format.validate("12:00:00.12345678901")
    time_format.validate("12:00:00.123456789012")
    time

# Generated at 2022-06-18 12:17:51.951014
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:18:02.824183
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2019-01-01T00:00:00Z")
    date_time_format.validate("2019-01-01T00:00:00+00:00")
    date_time_format.validate("2019-01-01T00:00:00+01:00")
    date_time_format.validate("2019-01-01T00:00:00+01:30")
    date_time_format.validate("2019-01-01T00:00:00-01:00")
    date_time_format.validate("2019-01-01T00:00:00-01:30")
    date_time_format.validate("2019-01-01T00:00:00")
    date_time_

# Generated at 2022-06-18 12:18:04.518180
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2020-01-01")
    assert date.year == 2020
    assert date.month == 1
    assert date.day == 1


# Generated at 2022-06-18 12:18:16.316393
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:18:28.329777
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:18:37.879168
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00")
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.1234567")
    time_format.validate("12:00:00.12345678")
    time

# Generated at 2022-06-18 12:18:48.831232
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00+00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T00:00:00+02:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2, minutes=30)))) == "2020-01-01T00:00:00+02:30"
    assert DateTimeFormat().serialize

# Generated at 2022-06-18 12:19:01.605680
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:19:11.160241
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 12, 30, 45, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:30:45Z"

    dt = datetime.datetime(2020, 1, 1, 12, 30, 45, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:30:45+02:00"

    dt = datetime.datetime(2020, 1, 1, 12, 30, 45)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:30:45"

# Generated at 2022-06-18 12:19:20.465332
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")


# Generated at 2022-06-18 12:19:27.065096
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2019-01-01") == datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:19:35.274287
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:19:45.570513
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:19:55.714924
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:20:06.703795
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:20:16.522253
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:20:27.631440
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-12-01") == datetime.date(2019, 12, 1)
    assert date_format.validate("2019-12-01") == datetime.date(2019, 12, 1)
    assert date_format.validate("2019-12-01") == datetime.date(2019, 12, 1)
    assert date_format.validate("2019-12-01") == datetime.date(2019, 12, 1)
    assert date_format.validate("2019-12-01") == datetime.date(2019, 12, 1)
    assert date_format.validate("2019-12-01") == datetime.date(2019, 12, 1)

# Generated at 2022-06-18 12:20:37.211514
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test for valid datetime
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:20:48.923468
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.1234567")
    time_format.validate("12:34:56.12345678")

# Generated at 2022-06-18 12:20:52.358183
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    value = "2020-01-01"
    assert date_format.validate(value) == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:21:06.084819
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2020-01-01T00:00:00+00:00"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3
    value = "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:21:08.549171
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate('2020-01-01T00:00:00Z')

# Generated at 2022-06-18 12:21:11.629104
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:21:23.827827
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)

# Generated at 2022-06-18 12:21:32.890147
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.")
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.")
    time_format.validate("12:00:00.1")

# Generated at 2022-06-18 12:21:41.933535
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2021-02-28") == datetime.date(2021, 2, 28)
    assert date_format.validate("2021-03-01") == datetime.date(2021, 3, 1)
    assert date_format.validate("2021-03-31") == datetime.date(2021, 3, 31)
    assert date_format.validate("2021-04-01")

# Generated at 2022-06-18 12:21:51.182007
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:21:58.583396
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:22:00.304958
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")


# Generated at 2022-06-18 12:22:09.131163
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:30:00")
    time_format.validate("12:30:00.123456")
    time_format.validate("12:30:00.123")
    time_format.validate("12:30:00.12")
    time_format.validate("12:30:00.1")
    time_format.validate("12:30:00.1234")
    time_format.validate("12:30:00.12345")
    time_format.validate("12:30:00.1234567")
    time_format.validate("12:30:00.12345678")
    time_format.validate("12:30:00.123456789")

# Generated at 2022-06-18 12:22:25.445091
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-04-01T00:00:00Z"
    expected = datetime.datetime(2019, 4, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2019-04-01T00:00:00+05:30"
    expected = datetime.datetime(2019, 4, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=5, minutes=30)))
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3
    value = "2019-04-01T00:00:00+0530"
    expected

# Generated at 2022-06-18 12:22:33.247853
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    # Test case 1
    value = "12:34:56.123456"
    expected = datetime.time(12, 34, 56, 123456)
    actual = time_format.validate(value)
    assert actual == expected
    # Test case 2
    value = "12:34:56.12345"
    expected = datetime.time(12, 34, 56, 12345)
    actual = time_format.validate(value)
    assert actual == expected
    # Test case 3
    value = "12:34:56.1234"
    expected = datetime.time(12, 34, 56, 123400)
    actual = time_format.validate(value)
    assert actual == expected
    # Test case 4
    value = "12:34:56.123"

# Generated at 2022-06-18 12:22:43.861107
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:22:55.558159
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    # Test for valid time format
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    # Test for invalid time format
    with pytest.raises(ValidationError):
        time_format.validate("12:34:56.1234567")