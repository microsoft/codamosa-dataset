

# Generated at 2022-06-18 12:13:19.623259
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T00:00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0)
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-18 12:13:21.640674
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 1, 1)
    assert DateFormat().serialize(date) == '2020-01-01'


# Generated at 2022-06-18 12:13:29.257056
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2019-01-01T00:00:00.000000Z")
    date_time_format.validate("2019-01-01T00:00:00.000000+00:00")
    date_time_format.validate("2019-01-01T00:00:00.000000-00:00")
    date_time_format.validate("2019-01-01T00:00:00.000000+00")
    date_time_format.validate("2019-01-01T00:00:00.000000-00")
    date_time_format.validate("2019-01-01T00:00:00.000000+01:00")

# Generated at 2022-06-18 12:13:36.457161
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")


# Generated at 2022-06-18 12:13:43.108036
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11")
    uuid_format.validate("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11")
    uuid_format.validate("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11")
    uuid_format.validate("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11")
    uuid_format.validate("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11")
    uuid

# Generated at 2022-06-18 12:13:51.280560
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    result = DateTimeFormat().validate(value)
    assert result == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 2
    value = "2020-01-01T00:00:00+01:00"
    result = DateTimeFormat().validate(value)
    assert result == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

    # Test case 3
    value = "2020-01-01T00:00:00-01:00"
    result = DateTimeFormat().validate(value)

# Generated at 2022-06-18 12:14:01.673132
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:14:10.737316
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:14:21.145320
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:14:30.458749
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('00:00:00') == datetime.time(0, 0)
    assert time_format.validate('00:00:00.000000') == datetime.time(0, 0)
    assert time_format.validate('00:00:00.000001') == datetime.time(0, 0, 0, 1)
    assert time_format.validate('00:00:00.000010') == datetime.time(0, 0, 0, 10)
    assert time_format.validate('00:00:00.000100') == datetime.time(0, 0, 0, 100)
    assert time_format.validate('00:00:00.001000') == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:14:48.170883
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-31") == datetime.date(2020, 1, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2020-03-31") == datetime.date(2020, 3, 31)
    assert date_format.validate("2020-04-30") == datetime.date(2020, 4, 30)
    assert date_format.validate("2020-05-31") == datetime.date(2020, 5, 31)

# Generated at 2022-06-18 12:14:59.950943
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:15:05.891676
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T00:00:00+02:00"

# Generated at 2022-06-18 12:15:17.758862
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:15:21.404475
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 12, 0, 0, 0)
    dt_format = DateTimeFormat()
    assert dt_format.serialize(dt) == "2020-01-01T12:00:00"

# Generated at 2022-06-18 12:15:23.991813
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2020, 1, 1)) == "2020-01-01"


# Generated at 2022-06-18 12:15:26.031355
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 2, 20)
    assert DateFormat().serialize(date) == "2020-02-20"


# Generated at 2022-06-18 12:15:36.903429
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time = DateTimeFormat()
    assert date_time.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:15:48.156982
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")
    date_format.validate("2019-01-01")

# Generated at 2022-06-18 12:15:51.372882
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 1, 1)
    date_format = DateFormat()
    assert date_format.serialize(date) == '2020-01-01'


# Generated at 2022-06-18 12:16:03.589226
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate('2019-01-01') == datetime.date(2019, 1, 1)
    assert date.validate('2019-01-01') != datetime.date(2019, 1, 2)
    assert date.validate('2019-01-01') != datetime.date(2019, 2, 1)
    assert date.validate('2019-01-01') != datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:16:14.383974
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00.000001Z'

# Generated at 2022-06-18 12:16:25.115889
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T12:00:00+02:00"

# Generated at 2022-06-18 12:16:29.653684
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T00:00:00Z"

# Generated at 2022-06-18 12:16:38.684733
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:16:41.770003
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2020, 1, 1, 12, 0, 0, 0)
    assert DateTimeFormat().serialize(obj) == "2020-01-01T12:00:00"


# Generated at 2022-06-18 12:16:52.836833
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 12, 30, 45, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:30:45Z"

    dt = datetime.datetime(2020, 1, 1, 12, 30, 45, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:30:45+02:00"

    dt = datetime.datetime(2020, 1, 1, 12, 30, 45, tzinfo=datetime.timezone(datetime.timedelta(hours=2, minutes=30)))

# Generated at 2022-06-18 12:17:03.739756
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-02-28") == datetime.date(2019, 2, 28)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2020-02-30") == datetime.date(2020, 2, 30)
    assert date_format.validate("2020-02-31") == datetime.date(2020, 2, 31)

# Generated at 2022-06-18 12:17:13.829473
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test case 1
    date_format = DateFormat()
    value = '2019-01-01'
    expected = datetime.date(2019, 1, 1)
    actual = date_format.validate(value)
    assert actual == expected

    # Test case 2
    date_format = DateFormat()
    value = '2019-01-32'
    expected = ValidationError(text='Must be a real date.', code='invalid')
    actual = date_format.validate(value)
    assert actual == expected

    # Test case 3
    date_format = DateFormat()
    value = '2019-01-01T00:00:00Z'
    expected = ValidationError(text='Must be a valid date format.', code='format')
    actual = date_format.validate(value)

# Generated at 2022-06-18 12:17:24.473392
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-01-01")
    date_format.validate("2020-01-31")
    date_format.validate("2020-02-29")
    date_format.validate("2020-03-31")
    date_format.validate("2020-04-30")
    date_format.validate("2020-05-31")
    date_format.validate("2020-06-30")
    date_format.validate("2020-07-31")
    date_format.validate("2020-08-31")
    date_format.validate("2020-09-30")
    date_format.validate("2020-10-31")
    date_format.validate("2020-11-30")

# Generated at 2022-06-18 12:17:30.953676
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 12, 0, 0, 0)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:00:00"


# Generated at 2022-06-18 12:17:41.117469
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == '2020-01-01T00:00:00+00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-1)))) == '2020-01-01T00:00:00-01:00'

# Generated at 2022-06-18 12:17:52.318486
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00.000001Z'

# Generated at 2022-06-18 12:18:03.124655
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:18:07.667037
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)

# Generated at 2022-06-18 12:18:11.123862
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-01-01T12:00:00Z"

# Generated at 2022-06-18 12:18:23.449447
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:18:34.370520
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-1)))) == "2020-01-01T00:00:00-01:00"

# Generated at 2022-06-18 12:18:44.535830
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:18:57.211263
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate('12:00:00')
    time_format.validate('12:00:00.000000')
    time_format.validate('12:00')
    time_format.validate('12:00:00.000000')
    time_format.validate('12:00:00.123456')
    time_format.validate('12:00:00.123456')
    time_format.validate('12:00:00.123456')
    time_format.validate('12:00:00.123456')
    time_format.validate('12:00:00.123456')
    time_format.validate('12:00:00.123456')
    time_format.validate('12:00:00.123456')
    time

# Generated at 2022-06-18 12:19:11.200612
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:19:22.588163
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-01-01T00:00:00Z"
    datetime_format = DateTimeFormat()
    assert datetime_format.validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 2
    value = "2019-01-01T00:00:00+00:00"
    datetime_format = DateTimeFormat()
    assert datetime_format.validate(value) == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 3
    value = "2019-01-01T00:00:00+01:00"
    datetime_format = DateTimeFormat

# Generated at 2022-06-18 12:19:34.782315
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:19:45.123075
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 2
    value = "2020-01-01T00:00:00+00:00"
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 3
    value = "2020-01-01T00:00:00+01:00"
    date_time_

# Generated at 2022-06-18 12:19:47.143422
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")


# Generated at 2022-06-18 12:19:57.550631
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T12:00:00+01:00"

# Generated at 2022-06-18 12:20:08.519102
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T12:00:00+01:00"

# Generated at 2022-06-18 12:20:17.753633
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2019-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2019-01-01T00:00:00+02:00"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2, minutes=30)))) == "2019-01-01T00:00:00+02:30"

# Generated at 2022-06-18 12:20:28.486324
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0)) == '2019-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2019-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2019-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:20:37.718036
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:20:54.252475
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:21:05.481424
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 123456)) == "2020-01-01T00:00:00.123456"

# Generated at 2022-06-18 12:21:12.549943
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:21:24.758183
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:21:34.869314
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:21:36.391252
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(obj) == "2020-01-01T00:00:00Z"


# Generated at 2022-06-18 12:21:43.157618
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, datetime.timezone.utc)) == '2020-01-01T00:00:00.000001Z'

# Generated at 2022-06-18 12:21:52.484105
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.1234567") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123456789") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.12345678") == datetime.time

# Generated at 2022-06-18 12:21:59.462058
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 1234)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 12)

# Generated at 2022-06-18 12:22:08.579173
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:22:30.004161
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0)) == '2019-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == '2019-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))) == '2019-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:22:36.316683
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)


# Generated at 2022-06-18 12:22:47.727632
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00.000001Z'

# Generated at 2022-06-18 12:22:50.923470
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
