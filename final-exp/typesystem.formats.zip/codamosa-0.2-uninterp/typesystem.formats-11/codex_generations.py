

# Generated at 2022-06-18 12:13:18.246196
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:13:26.711025
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:13:35.747483
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:13:42.664606
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2019-02-29") == datetime.date(2019, 2, 29)
    assert date_format.validate("2020-02-28") == datetime.date(2020, 2, 28)
    assert date_format.validate("2019-02-28") == datetime.date(2019, 2, 28)

# Generated at 2022-06-18 12:13:50.841085
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2020-01-01T00:00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0)
    assert date_time_format.validate("2020-01-01T00:00:00.000000") == datetime.datetime(2020, 1, 1, 0, 0, 0)
    assert date_time_format.validate("2020-01-01T00:00:00.123456") == datetime.datetime(2020, 1, 1, 0, 0, 0, 123456)

# Generated at 2022-06-18 12:13:56.896933
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:14:06.403420
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2019-02-29") == datetime.date(2019, 2, 29)
    assert date_format.validate("2018-02-29") == datetime.date(2018, 2, 29)
    assert date_format.validate("2017-02-29") == datetime.date(2017, 2, 29)

# Generated at 2022-06-18 12:14:09.169053
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("123e4567-e89b-12d3-a456-426655440000")


# Generated at 2022-06-18 12:14:19.738277
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0)) == "2020-01-01T12:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T12:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 12, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T12:00:00+02:00"

# Generated at 2022-06-18 12:14:29.204520
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1)
    assert time_format.validate("12:00:00.000010") == datetime.time(12, 0, 0, 10)
    assert time_format.validate("12:00:00.000100") == datetime.time(12, 0, 0, 100)
    assert time_format.validate("12:00:00.001000") == datetime.time(12, 0, 0, 1000)


# Generated at 2022-06-18 12:14:42.718409
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:14:47.056169
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    time = datetime.time(hour=12, minute=34, second=56, microsecond=789)
    assert time_format.serialize(time) == "12:34:56.000789"


# Generated at 2022-06-18 12:14:58.750027
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:15:02.194327
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(hour=10, minute=20, second=30, microsecond=123456)
    time_format = TimeFormat()
    assert time_format.serialize(time) == "10:20:30.123456"

# Generated at 2022-06-18 12:15:09.880448
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:15:21.895098
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:15:27.212255
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:15:30.249074
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2020-01-01T00:00:00Z")


# Generated at 2022-06-18 12:15:41.754729
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    assert time_format.serialize(datetime.time(hour=1, minute=2, second=3, microsecond=4)) == "01:02:03.000004"
    assert time_format.serialize(datetime.time(hour=1, minute=2, second=3)) == "01:02:03"
    assert time_format.serialize(datetime.time(hour=1, minute=2)) == "01:02"
    assert time_format.serialize(datetime.time(hour=1)) == "01:00"
    assert time_format.serialize(datetime.time(hour=1, microsecond=4)) == "01:00:00.000004"
    assert time_format.serialize(datetime.time(minute=2, microsecond=4))

# Generated at 2022-06-18 12:15:52.494098
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-12-31T23:59:59.999999Z"
    expected = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert expected == actual

    # Test case 2
    value = "2019-12-31T23:59:59.999999+00:00"
    expected = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert expected == actual

    # Test case 3

# Generated at 2022-06-18 12:16:07.047220
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:16:17.369482
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:16:29.417379
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:16:38.537437
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:16:41.179341
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:16:52.343232
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:16:59.955013
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:17:08.690779
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Test case 1
    time_format = TimeFormat()
    time_format.validate("10:10:10")
    # Test case 2
    time_format.validate("10:10:10.123456")
    # Test case 3
    time_format.validate("10:10:10.123")
    # Test case 4
    time_format.validate("10:10:10.12")
    # Test case 5
    time_format.validate("10:10:10.1")
    # Test case 6
    time_format.validate("10:10:10.")
    # Test case 7
    time_format.validate("10:10:10")
    # Test case 8
    time_format.validate("10:10")
    # Test case 9

# Generated at 2022-06-18 12:17:21.029292
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:17:28.116773
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234567")
    time_format.validate("12:34:56.12345678")
    time_format.validate("12:34:56.123456789")
    time_format.validate("12:34:56.1234567890")
    time_format.validate("12:34:56.12345678901")

# Generated at 2022-06-18 12:17:41.279754
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:17:52.544279
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2019-01-01T00:00:00Z")
    date_time_format.validate("2019-01-01T00:00:00+00:00")
    date_time_format.validate("2019-01-01T00:00:00+01:00")
    date_time_format.validate("2019-01-01T00:00:00-01:00")
    date_time_format.validate("2019-01-01T00:00:00+01")
    date_time_format.validate("2019-01-01T00:00:00-01")
    date_time_format.validate("2019-01-01T00:00:00")
    date_time_format.validate

# Generated at 2022-06-18 12:17:54.585094
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-01-01")


# Generated at 2022-06-18 12:18:04.914952
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2021, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2021, 1, 2)
    assert date_format.validate("2020-01-01") != datetime.date(2021, 2, 1)

# Generated at 2022-06-18 12:18:16.682225
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.1234567") == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-18 12:18:18.780667
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-01-01")


# Generated at 2022-06-18 12:18:30.586762
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:18:39.276937
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:18:50.431469
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:19:03.146185
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:30:00") == datetime.time(12, 30, 0)
    assert time_format.validate("12:30:00.123456") == datetime.time(12, 30, 0, 123456)
    assert time_format.validate("12:30:00.123") == datetime.time(12, 30, 0, 123000)
    assert time_format.validate("12:30:00.12") == datetime.time(12, 30, 0, 120000)
    assert time_format.validate("12:30:00.1") == datetime.time(12, 30, 0, 100000)

# Generated at 2022-06-18 12:19:15.374458
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("13:37:00") == datetime.time(13, 37, 0)
    assert time_format.validate("13:37:00.123456") == datetime.time(13, 37, 0, 123456)
    assert time_format.validate("13:37:00.123") == datetime.time(13, 37, 0, 123000)
    assert time_format.validate("13:37") == datetime.time(13, 37)
    assert time_format.validate("13:37:00.123456789") == datetime.time(13, 37, 0, 123456)

# Generated at 2022-06-18 12:19:26.480156
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)

# Generated at 2022-06-18 12:19:38.551905
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)

# Generated at 2022-06-18 12:19:48.393381
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12345") == datetime.time(12, 0, 0, 12345)
    assert time_format.validate("12:00:00.1234") == datetime.time(12, 0, 0, 123400)

# Generated at 2022-06-18 12:19:59.079958
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)
    assert date_format.validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert date_format.validate("2019-02-28") == datetime.date(2019, 2, 28)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2020-02-30") == datetime.date(2020, 2, 30)
    assert date_format.validate("2020-02-31") == datetime.date(2020, 2, 31)

# Generated at 2022-06-18 12:20:09.971639
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("00:00:00")
    time_format.validate("00:00:00.000000")
    time_format.validate("00:00:00.123456")
    time_format.validate("00:00:00.12345")
    time_format.validate("00:00:00.1234")
    time_format.validate("00:00:00.123")
    time_format.validate("00:00:00.12")
    time_format.validate("00:00:00.1")
    time_format.validate("00:00:00.123456")
    time_format.validate("00:00:00.12345")
    time_format.validate("00:00:00.1234")

# Generated at 2022-06-18 12:20:18.597108
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)

# Generated at 2022-06-18 12:20:29.435123
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)
    assert time_format

# Generated at 2022-06-18 12:20:38.142947
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:20:41.053569
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:20:57.301360
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:21:07.739230
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:21:20.474215
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time.validate("00:00:00.123456") == datetime.time(0, 0, 0, 123456)
    assert time.validate("00:00:00.123") == datetime.time(0, 0, 0, 123000)
    assert time.validate("00:00:00.12") == datetime.time(0, 0, 0, 120000)
    assert time.validate("00:00:00.1") == datetime.time(0, 0, 0, 100000)

# Generated at 2022-06-18 12:21:29.358151
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:21:39.560472
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:21:48.238654
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('12:00:00') == datetime.time(12, 0, 0)
    assert time_format.validate('12:00:00.123456') == datetime.time(12, 0, 0, 123456)
    assert time_format.validate('12:00:00.123') == datetime.time(12, 0, 0, 123000)
    assert time_format.validate('12:00:00.12') == datetime.time(12, 0, 0, 120000)
    assert time_format.validate('12:00:00.1') == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:21:50.323685
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:21:58.570672
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1000)
    assert time_format.validate("12:00:00.00001") == datetime.time(12, 0, 0, 10000)
    assert time_format.validate("12:00:00.0001") == datetime

# Generated at 2022-06-18 12:22:07.958274
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)
    assert time.validate("12:34:56.1") == datetime.time(12, 34, 56, 100000)
    assert time.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)

# Generated at 2022-06-18 12:22:17.445465
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12")
    time_format.validate("12:34:56.1")
    time_format.validate("12:34:56.1234")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.12345")

# Generated at 2022-06-18 12:22:32.892378
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)

# Generated at 2022-06-18 12:22:35.348577
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:22:46.648956
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)


# Generated at 2022-06-18 12:22:57.684732
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate(value) == expected

    # Test case 2
    value = "2020-01-01T00:00:00+00:00"
    expected = datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate(value) == expected

    # Test case 3
    value = "2020-01-01T00:00:00+01:00"