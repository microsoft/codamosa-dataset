

# Generated at 2022-06-18 12:13:03.920111
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 1, 1)
    date_format = DateFormat()
    assert date_format.serialize(date) == "2020-01-01"


# Generated at 2022-06-18 12:13:11.621081
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11") == uuid.UUID("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11")
    assert uuid_format.validate("a0eebc999c0b4ef8bb6d6bb9bd380a11") == uuid.UUID("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11")

# Generated at 2022-06-18 12:13:20.793142
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == "2020-01-01T00:00:00+00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == "2020-01-01T00:00:00+02:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2, minutes=30)))) == "2020-01-01T00:00:00+02:30"
    assert DateTimeFormat().serialize

# Generated at 2022-06-18 12:13:28.660978
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)

# Generated at 2022-06-18 12:13:37.644026
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(12, 34, 56, 789000)) == '12:34:56.789'
    assert TimeFormat().serialize(datetime.time(12, 34, 56, 789)) == '12:34:56.000789'
    assert TimeFormat().serialize(datetime.time(12, 34, 56)) == '12:34:56'
    assert TimeFormat().serialize(datetime.time(12, 34)) == '12:34:00'
    assert TimeFormat().serialize(datetime.time(12)) == '12:00:00'
    assert TimeFormat().serialize(datetime.time(12, 34, 56, 789000, tzinfo=datetime.timezone.utc)) == '12:34:56.789Z'

# Generated at 2022-06-18 12:13:43.743957
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.000001") == datetime.time(12, 0, 0, 1)
    assert time_format.validate("12:00:00.000010") == datetime.time(12, 0, 0, 10)
    assert time_format.validate("12:00:00.000100") == datetime.time(12, 0, 0, 100)

# Generated at 2022-06-18 12:13:51.862581
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2019-12-31T23:59:59.999999Z"
    expected = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 2
    value = "2019-12-31T23:59:59.999999+00:00"
    expected = datetime.datetime(2019, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # Test case 3

# Generated at 2022-06-18 12:14:02.382187
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00.000001Z'

# Generated at 2022-06-18 12:14:11.562930
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # test case 1
    value = '2020-02-10T11:00:00+00:00'
    expected = datetime.datetime(2020, 2, 10, 11, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # test case 2
    value = '2020-02-10T11:00:00Z'
    expected = datetime.datetime(2020, 2, 10, 11, 0, 0, tzinfo=datetime.timezone.utc)
    actual = DateTimeFormat().validate(value)
    assert actual == expected

    # test case 3
    value = '2020-02-10T11:00:00-05:00'

# Generated at 2022-06-18 12:14:13.618790
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2020, 1, 1)) == '2020-01-01'


# Generated at 2022-06-18 12:14:22.281912
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:14:24.543257
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:14:30.638429
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2021, 1, 1)


# Generated at 2022-06-18 12:14:33.855722
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 4, 30)
    date_format = DateFormat()
    assert date_format.serialize(date) == "2020-04-30"


# Generated at 2022-06-18 12:14:42.198826
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:14:47.288951
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    time_obj = datetime.time(hour=12, minute=30, second=45, microsecond=123456)
    assert time_format.serialize(time_obj) == '12:30:45.123456'


# Generated at 2022-06-18 12:14:51.178938
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2020, 1, 1)) == '2020-01-01'
    assert date_format.serialize(None) == None


# Generated at 2022-06-18 12:15:02.374752
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2021, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2019, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 0)

# Generated at 2022-06-18 12:15:08.999369
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(12, 34, 56)) == '12:34:56'
    assert TimeFormat().serialize(datetime.time(12, 34, 56, 789)) == '12:34:56.000789'
    assert TimeFormat().serialize(datetime.time(12, 34, 56, 789, tzinfo=datetime.timezone.utc)) == '12:34:56.000789+00:00'
    assert TimeFormat().serialize(datetime.time(12, 34, 56, 789, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '12:34:56.000789+01:00'

# Generated at 2022-06-18 12:15:21.404263
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date.validate("2020-01-31") == datetime.date(2020, 1, 31)
    assert date.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date.validate("2020-03-31") == datetime.date(2020, 3, 31)
    assert date.validate("2020-04-30") == datetime.date(2020, 4, 30)
    assert date.validate("2020-05-31") == datetime.date(2020, 5, 31)
    assert date.validate("2020-06-30") == datetime.date(2020, 6, 30)

# Generated at 2022-06-18 12:15:25.596150
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2020, 1, 1)) == "2020-01-01"


# Generated at 2022-06-18 12:15:28.115560
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 1, 1)
    date_format = DateFormat()
    assert date_format.serialize(date) == '2020-01-01'


# Generated at 2022-06-18 12:15:33.553981
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:15:44.530586
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))) == '2020-01-01T00:00:00+02:00'

# Generated at 2022-06-18 12:15:54.282038
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:16:06.125199
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0)) == "2019-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == "2019-01-01T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2019-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:16:16.532175
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000000") == datetime.time(0, 0)
    assert time_format.validate("00:00:00.000001") == datetime.time(0, 0, 0, 1)
    assert time_format.validate("00:00:00.000010") == datetime.time(0, 0, 0, 10)
    assert time_format.validate("00:00:00.000100") == datetime.time(0, 0, 0, 100)
    assert time_format.validate("00:00:00.001000") == datetime.time(0, 0, 0, 1000)
    assert time_

# Generated at 2022-06-18 12:16:27.799457
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:16:38.055580
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # test case 1
    value = "2019-10-10T10:10:10.123456Z"
    datetime_format = DateTimeFormat()
    datetime_format.validate(value)
    # test case 2
    value = "2019-10-10T10:10:10.123456+00:00"
    datetime_format = DateTimeFormat()
    datetime_format.validate(value)
    # test case 3
    value = "2019-10-10T10:10:10.123456+01:00"
    datetime_format = DateTimeFormat()
    datetime_format.validate(value)
    # test case 4
    value = "2019-10-10T10:10:10.123456-01:00"
    datetime_format = DateTimeFormat()
    dat

# Generated at 2022-06-18 12:16:49.294221
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:17:03.783124
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56.12345")
    time_format.validate("12:34:56.1234567")
    time_format.validate("12:34:56.12345678")
    time_format.validate("12:34:56.123456789")
    time_format.validate("12:34:56.1234567890")
    time_format.validate("12:34:56.12345678901")

# Generated at 2022-06-18 12:17:13.932454
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-12-31") == datetime.date(2020, 12, 31)
    assert date_format.validate("2020-02-29") == datetime.date(2020, 2, 29)
    assert date_format.validate("2021-02-28") == datetime.date(2021, 2, 28)
    assert date_format.validate("2021-03-01") == datetime.date(2021, 3, 1)
    assert date_format.validate("2021-03-31") == datetime.date(2021, 3, 31)
    assert date_format.validate("2021-04-01")

# Generated at 2022-06-18 12:17:17.895538
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:17:26.319142
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:17:38.201421
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:17:48.389401
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:17:51.218464
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:18:02.187420
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)
    assert time_format.validate("12:34:56.1234") == datetime.time(12, 34, 56, 123400)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12") == datetime.time(12, 34, 56, 120000)

# Generated at 2022-06-18 12:18:07.057715
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.123456")

# Generated at 2022-06-18 12:18:18.786094
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == "2020-01-01T00:00:00.000001"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1, tzinfo=datetime.timezone.utc)) == "2020-01-01T00:00:00.000001Z"

# Generated at 2022-06-18 12:18:36.003775
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:18:46.089923
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)

# Generated at 2022-06-18 12:18:59.089981
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)

# Generated at 2022-06-18 12:19:09.685897
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2020-01-01T00:00:00Z") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dt.validate("2020-01-01T00:00:00+01:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:19:12.351911
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-18 12:19:23.411908
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.123456")
    time_format.validate("12:00:00.123")
    time_format.validate("12:00:00.12")
    time_format.validate("12:00:00.1")
    time_format.validate("12:00:00.1234")
    time_format.validate("12:00:00.12345")
    time_format.validate("12:00:00.1234567")
    time_format.validate("12:00:00.12345678")
    time_format.validate("12:00:00.123456789")

# Generated at 2022-06-18 12:19:35.561286
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:19:45.844810
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:19:48.217029
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-01-01") == datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:19:58.878621
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2018-12-31T23:59:59.999999Z") == datetime.datetime(2018, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    assert dt.validate("2018-12-31T23:59:59.999999+01:00") == datetime.datetime(2018, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:20:11.197952
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2019, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2021, 1, 1)


# Generated at 2022-06-18 12:20:14.751626
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-10-10") == datetime.date(2020, 10, 10)
    assert date_format.validate("2020-10-10") != datetime.date(2020, 10, 11)


# Generated at 2022-06-18 12:20:21.008411
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:20:27.929363
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2019, 1, 1)


# Generated at 2022-06-18 12:20:37.396191
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-01-01') == datetime.date(2020, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 1, 2)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 2, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2021, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2019, 1, 1)
    assert date_format.validate('2020-01-01') != datetime.date(2020, 12, 1)

# Generated at 2022-06-18 12:20:49.181136
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == '2020-01-01T00:00:00+00:00'
    dt = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=2)))
    assert DateTimeFormat().serialize(dt) == '2020-01-01T00:00:00+02:00'
    dt = datetime.datetime(2020, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=-2)))

# Generated at 2022-06-18 12:21:01.414351
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # test case 1
    value = "2020-01-01T00:00:00Z"
    assert DateTimeFormat().validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # test case 2
    value = "2020-01-01T00:00:00+00:00"
    assert DateTimeFormat().validate(value) == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # test case 3
    value = "2020-01-01T00:00:00+01:00"

# Generated at 2022-06-18 12:21:10.174247
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.1234567") == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-18 12:21:22.516791
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("00:00:00")
    time_format.validate("00:00:00.000000")
    time_format.validate("00:00:00.000001")
    time_format.validate("00:00:00.000010")
    time_format.validate("00:00:00.000100")
    time_format.validate("00:00:00.001000")
    time_format.validate("00:00:00.010000")
    time_format.validate("00:00:00.100000")
    time_format.validate("00:00:01.000000")
    time_format.validate("00:01:00.000000")
    time_format.validate("01:00:00.000000")

# Generated at 2022-06-18 12:21:30.253149
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1)) == '2020-01-01T00:00:00.000001'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 123456)) == '2020-01-01T00:00:00.123456'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 1234567)) == '2020-01-01T00:00:00.123456'

# Generated at 2022-06-18 12:21:50.167989
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2019-01-01T00:00:00Z") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+00:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert dt.validate("2019-01-01T00:00:00+01:00") == datetime.datetime(2019, 1, 1, 0, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-18 12:21:57.782418
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 2)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 2, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2021, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2019, 1, 1)
    assert date_format.validate("2020-01-01") != datetime.date(2020, 1, 3)

# Generated at 2022-06-18 12:22:07.339044
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:34:56.123456")
    time_format.validate("12:34:56.123")
    time_format.validate("12:34:56")
    time_format.validate("12:34")
    time_format.validate("12")
    time_format.validate("12:34:56.1234567")
    time_format.validate("12:34:56.12345678")
    time_format.validate("12:34:56.123456789")
    time_format.validate("12:34:56.1234567890")
    time_format.validate("12:34:56.12345678901")

# Generated at 2022-06-18 12:22:17.072925
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00:00")
    time_format.validate("12:00:00.000000")
    time_format.validate("12:00:00.000001")
    time_format.validate("12:00:00.000010")
    time_format.validate("12:00:00.000100")
    time_format.validate("12:00:00.001000")
    time_format.validate("12:00:00.010000")
    time_format.validate("12:00:00.100000")
    time_format.validate("12:00:01.000000")
    time_format.validate("12:01:00.000000")
    time_format.validate("13:00:00.000000")

# Generated at 2022-06-18 12:22:28.041249
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert time_format.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert time_format.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert time_format.validate("12:00:00.1") == datetime.time(12, 0, 0, 100000)

# Generated at 2022-06-18 12:22:34.977381
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2020-01-01T00:00:00Z'
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-01-01T00:00:00+01:00'

# Generated at 2022-06-18 12:22:46.217461
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    value = "2020-01-01T00:00:00Z"
    result = DateTimeFormat().validate(value)
    assert result == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test case 2
    value = "2020-01-01T00:00:00+01:00"
    result = DateTimeFormat().validate(value)
    assert result == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

    # Test case 3
    value = "2020-01-01T00:00:00-01:00"
    result = DateTimeFormat().validate(value)

# Generated at 2022-06-18 12:22:57.328637
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)
    assert time_format.validate("12:34:56.123") == datetime.time(12, 34, 56, 123000)
    assert time_format.validate("12:34:56.12345") == datetime.time(12, 34, 56, 12345)