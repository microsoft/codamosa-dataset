

# Generated at 2022-06-26 10:20:40.389349
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u_u_i_d_format_0 = UUIDFormat()
    obj = uuid.UUID('3e2e9a8a-a3b0-4dae-a239-f8cc8f89c10a')
    expected = '3e2e9a8a-a3b0-4dae-a239-f8cc8f89c10a'
    result = u_u_i_d_format_0.validate(obj)
    assert expected == result


# Generated at 2022-06-26 10:20:47.962252
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    u_u_i_d_format_0 = UUIDFormat()
    try:
        u_u_i_d_format_0.validate(str(2))
    except ValidationError as exc:
        assert exc.code == "format"
    else:
        raise AssertionError("Test failed.")

# Generated at 2022-06-26 10:20:49.783421
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2001-01-01") == datetime.datetime(2001, 1, 1)


# Generated at 2022-06-26 10:20:51.966556
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("2019-01-31T10:00:00Z")


# Generated at 2022-06-26 10:21:03.753315
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    value_0 = "02:35:32.654321"
    try:
        time_format_0.validate(value_0)
    except ValidationError as e1:
        print(e1.text)
        print(e1.code)
    value_1 = "02:35:32.654321"
    try:
        time_format_0.validate(value_1)
    except ValidationError as e2:
        print(e2.text)
        print(e2.code)
    value_2 = "02:35:32.654321"
    try:
        time_format_0.validate(value_2)
    except ValidationError as e3:
        print(e3.text)

# Generated at 2022-06-26 10:21:12.688480
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    case_0 = DateFormat()
    try:
        case_0.validate("2020-10-24")
    except Exception as e:
        print(e)
    try:
        case_0.validate(None)
    except Exception as e:
        print(e)
    try:
        case_0.validate(4.2)
    except Exception as e:
        print(e)

# Generated at 2022-06-26 10:21:19.113986
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    u_u_i_d_format_0 = UUIDFormat()
    u_u_i_d_format_0.validate('abcdefab-cdef-1234-abcd-ef0123456789')


# Generated at 2022-06-26 10:21:21.731420
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("00:00:00.000000")


# Generated at 2022-06-26 10:21:27.228034
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    str_0 = "2018-01-01T01:01:01.11+01:10"
    assert date_time_format_0.validate(str_0) == datetime.datetime(2018, 1, 1, 1, 1, 1, 110000, tzinfo=datetime.timezone(datetime.timedelta(hours=1, minutes=10)))


# Generated at 2022-06-26 10:21:37.465395
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate('12:34') == datetime.time(12, 34, tzinfo=None)
    assert time_format_0.validate('12:34:56.123456') == datetime.time(12, 34, 56, 123456, tzinfo=None)
    try:
        time_format_0.validate('12:34:56,123456')
        raise AssertionError()
    except ValidationError as e:
        assert e.text == 'Must be a real time.'


# Generated at 2022-06-26 10:21:48.521306
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()

    obj_0 = None
    res = time_format.serialize(obj_0)
    assert res is None

    obj_1 = datetime.time(3, 59, 2, 12345)
    res = time_format.serialize(obj_1)
    assert res == "03:59:02.012345"

    return


# Generated at 2022-06-26 10:21:53.795836
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()

    assert date_format_0.serialize(datetime.date(1, 1, 1)) == "0001-01-01"

    assert date_format_0.serialize(None) == None


# Generated at 2022-06-26 10:21:59.833334
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    """
    Test case for serialize of class TimeFormat
    """
    time_format_0 = TimeFormat()
    datetime_0 = datetime.time(hour=0, minute=0, second=0, microsecond=0)
    assert time_format_0.serialize(datetime_0) == "00:00:00"


# Generated at 2022-06-26 10:22:02.994147
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()

    assert time_format_0.serialize(datetime.time(hour=1, minute=2, second=3, microsecond=4)) == '01:02:03.000004'


# Generated at 2022-06-26 10:22:08.780925
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    date_time_0 = datetime.datetime(year=2019, month=10, day=3, hour=19, minute=52, second=27, microsecond=821088)
    result = date_format_0.serialize(date_time_0)
    assert result == "2019-10-03"


# Generated at 2022-06-26 10:22:14.611297
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    str_0 = '23:32:54.232379'
    time_format_0 = TimeFormat()
    datetime_0 = datetime.datetime.strptime(str_0, "%H:%M:%S.%f")
    time_0 = datetime.time(hour=23, minute=32, second=54, microsecond=232379)
    str_1 = time_format_0.serialize(time_0)
    str_2 = '23:32:54.232379'
    assert (str_1 == str_2)

# Generated at 2022-06-26 10:22:25.503595
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    v_0: datetime.datetime = date_time_format_0.validate("2019-07-06T10:45:00Z")
    v_1: datetime.datetime = date_time_format_0.validate("2019-07-06T10:45:00+00:00")
    v_2: datetime.datetime = date_time_format_0.validate("2019-07-06T10:45:00-05:00")
    v_3: datetime.datetime = date_time_format_0.validate("2019-07-06T10:45:00-05")

# Generated at 2022-06-26 10:22:28.138661
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    time_format_0.serialize()
    assert time_format_0.serialize() == None


# Generated at 2022-06-26 10:22:32.142503
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    renderer_context_0 = {}
    obj_0 = None
    value_0 = time_format_0.serialize(obj_0)
    assert value_0 is None


# Generated at 2022-06-26 10:22:36.689393
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = datetime.datetime.strptime("1997-01-01T01:01:01Z","%Y-%m-%dT%H:%M:%SZ")
    assert date_time_format_0.serialize(date_time_0) == "1997-01-01T01:01:01Z"


# Generated at 2022-06-26 10:22:41.145500
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    time_format_0.validate("19:30:00")



# Generated at 2022-06-26 10:22:53.243594
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    d_t_f_0 = DateTimeFormat()
    assert d_t_f_0.validate("2020-10-03T12:29:28.12345+08:00")
    assert d_t_f_0.validate("2020-03-03T14:10:28.12345+00:00")
    assert d_t_f_0.validate("2020-03-03T14:10:28.12345+00")
    assert d_t_f_0.validate("2020-03-03T14:10:28.12345+02:00")
    assert d_t_f_0.validate("2020-03-03T14:10:28+00:00")

# Generated at 2022-06-26 10:22:55.192764
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    date_0 = datetime.date(2008, 11, 3)

    assert date_format_0.serialize(date_0) == "2008-11-03"


# Generated at 2022-06-26 10:22:58.913587
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()

    # Assert
    assert date_time_format_0.serialize(None) == None


# Generated at 2022-06-26 10:23:01.785962
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    input_var_0 = date(2010, 1, 1)
    date_format_0 = DateFormat()
    assert date_format_0.serialize(input_var_0) == "2010-01-01"


# Generated at 2022-06-26 10:23:05.778453
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert date_format_0.validate("2001-12-12") == datetime.date(2001, 12, 12)


# Generated at 2022-06-26 10:23:17.934239
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    print("test_DateFormat_validate")

# Generated at 2022-06-26 10:23:20.830310
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    with pytest.raises(ValidationError):
        date_format_0.validate('1985-02-39')



# Generated at 2022-06-26 10:23:26.994282
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    t = DateTimeFormat()
    dt = datetime.datetime(2017, 1, 1, tzinfo=datetime.timezone.utc)
    assert t.serialize(dt) == "2017-01-01T00:00:00Z"
    dt = datetime.datetime(2017, 1, 1, 0, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert t.serialize(dt) == "2017-01-01T00:00:00Z"
    dt = datetime.datetime(2017, 1, 1, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert t.serialize(dt) == "2017-01-01T00:00:00+01:00"

# Generated at 2022-06-26 10:23:29.116827
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("23:59")
    except ValidationError:
        pass


# Generated at 2022-06-26 10:23:34.895791
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_0 = time_format_0.validate("23:56:22.7")
    assert isinstance(time_0, datetime.time)


# Generated at 2022-06-26 10:23:40.296217
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    date_0 = datetime.date(year=datetime.MINYEAR, month=1, day=1)
    assert date_format_0.serialize(date_0) == date_0.isoformat()


# Generated at 2022-06-26 10:23:47.408343
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_0 = time_format_0.validate("23:59:59.999999")
    assert time_0, datetime.time(23, 59, 59, 999999)
    time_0 = time_format_0.validate("23:59:59.9999999")
    assert time_0, datetime.time(23, 59, 59, 999999)
    date_format_0 = DateFormat()
    date_0 = date_format_0.validate(None)
    assert date_0, None
    datetime_format_0 = DateTimeFormat()
    datetime_0 = datetime_format_0.validate("2018-08-01T12:01:02.000+08:00")

# Generated at 2022-06-26 10:23:55.894840
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    d_t_f_0 = DateTimeFormat()
    d_t_f_1 = DateTimeFormat()

    with pytest.raises(NotImplementedError, match=r"^.*$"):
        d_t_f_0.validate("string")


# Generated at 2022-06-26 10:24:10.666439
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    u_u_i_d_format_0 = UUIDFormat()
    u_u_i_d_format_1 = UUIDFormat()
    u_u_i_d_format_2 = UUIDFormat()
    u_u_i_d_format_3 = UUIDFormat()
    u_u_i_d_format_4 = UUIDFormat()
    u_u_i_d_format_5 = UUIDFormat()
    u_u_i_d_format_6 = UUIDFormat()
    u_u_i_d_format_7 = UUIDFormat()
    u_u_i_d_format_8 = UUIDFormat()
    u_u_i_d_format_9 = UUIDFormat()
    u_u_i_d_format_10 = UUIDFormat()
   

# Generated at 2022-06-26 10:24:17.470647
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Check that the regex matches a valid date format
    match = DATE_REGEX.match("2075-01-15")
    assert match is not None

    # Check that the regex fails when given an invalid date format
    match = DATE_REGEX.match("2075-1-15")
    assert match is None

    # Check that the regex fails when given an invalid date format
    match = DATE_REGEX.match("2075/1/15")
    assert match is None

    # Define a DateFormat object.
    date_format_0 = DateFormat()

    # Validates a string into a python datetime.date type.
    value = date_format_0.validate("2075-01-15")

    # Check that the string was validated into the correct type.
    assert isinstance(value, datetime.date)

# Generated at 2022-06-26 10:24:21.869460
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate(value='')
    except ValidationError as e:
        traceback.print_exc(file=sys.stdout)
        assert e.code == 'format'


# Generated at 2022-06-26 10:24:27.593212
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    from datetime import date
    obj = date(2021, 3, 3)

    expected = '2021-03-03'

    result = DateFormat().serialize(obj)

    assert result == expected


# Generated at 2022-06-26 10:24:29.746922
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()


# Generated at 2022-06-26 10:24:37.216902
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Test case with default arguments
    u_u_i_d_format_0 = UUIDFormat()
    # Test case with arguments
    u_u_i_d_format_1 = UUIDFormat()

# Generated at 2022-06-26 10:24:47.562769
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dt = datetime.datetime(2017, 11, 25, 1, 36, 52, 156484)
    dt_fmt = DateFormat()
    assert dt_fmt.validate(dt.isoformat()) == dt.date()
    assert dt_fmt.validate("2017-11-25") == dt.date()



# Generated at 2022-06-26 10:24:55.447563
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()

    with pytest.raises(ValidationError) as excinfo:
        datetime_format_0.validate("2016-03-03T03:03:03Z")

    assert excinfo.value.code == "invalid"


# Generated at 2022-06-26 10:24:57.717095
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("12:34:56")
    except ValidationError:
        pass


# Generated at 2022-06-26 10:25:01.522453
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetimeformat_0 = DateTimeFormat()
    with pytest.raises(ValidationError):
        datetimeformat_0.validate("")

# Generated at 2022-06-26 10:25:10.086254
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("12:00:00") == datetime.time(12)
    assert TimeFormat().validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert TimeFormat().validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert TimeFormat().validate("12:00") == datetime.time(12)


# Generated at 2022-06-26 10:25:21.554251
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():

    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    time_format_2 = TimeFormat()
    time_format_3 = TimeFormat()
    time_format_4 = TimeFormat()
    time_format_5 = TimeFormat()
    time_format_6 = TimeFormat()

    time_0 = time_format_0.validate("01:02:03.123456")
    time_1 = time_format_1.validate("01:02:03.123456.123456")
    time_2 = time_format_2.validate("01:02:03.123456")
    time_3 = time_format_3.validate("01:02:03")
    time_4 = time_format_4.validate("01:02")
    time_5 = time_

# Generated at 2022-06-26 10:25:28.973796
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("00:12:00")

    time_format_1 = TimeFormat()
    time_format_1.validate("12:00")

    time_format_2 = TimeFormat()
    time_format_2.validate("12:00Z")

    time_format_3 = TimeFormat()
    time_format_3.validate("12:00Z")


# Generated at 2022-06-26 10:25:35.574447
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    T_i_m_e_format_0 = TimeFormat()
    assert T_i_m_e_format_0.validate('23:60') == datetime.time(23, 60)


# Generated at 2022-06-26 10:25:44.266492
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    d_a_t_e_time_format_0 = DateTimeFormat()
    assert d_a_t_e_time_format_0.validate("2020-11-20T14:31:29.159436+00:00") == datetime.datetime(
        2020, 11, 20, 14, 31, 29, 159436, tzinfo=datetime.timezone.utc
    ), "Expected timezone to be +00:00"

# Generated at 2022-06-26 10:25:47.577903
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t_i_m_e_format_0 = TimeFormat()
    t_i_m_e_0 = t_i_m_e_format_0.validate("23:02:59")



# Generated at 2022-06-26 10:26:00.411078
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate(str)
    except ValidationError as e_0:
        pass
    try:
        time_format_0.validate('25:48:79.668933')
    except ValidationError as e_0:
        pass
    try:
        time_format_0.validate('02:40:40')
    except ValidationError as e_0:
        pass


# Generated at 2022-06-26 10:26:09.172472
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    with pytest.raises(ValidationError) as excinfo:
        date_format_0.validate("2017-01")
    assert excinfo.value.code == "format"
    assert excinfo.value.text == "Must be a valid date format."

    with pytest.raises(ValidationError) as excinfo:
        date_format_0.validate("2017-01-00")
    assert excinfo.value.code == "invalid"
    assert excinfo.value.text == "Must be a real date."


# Generated at 2022-06-26 10:26:15.397739
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    assert (
        date_format_0.validate("2020-01-01") == datetime.date(2020, 1, 1)
    )



# Generated at 2022-06-26 10:26:21.669416
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    value_0 = "2011-12-03"
    return_value_0 = date_format_0.validate(value_0)
    assert isinstance(return_value_0, datetime.date)
    return_value_1 = date_format_0.validate(value_0)
    assert isinstance(return_value_1, datetime.date)


# Generated at 2022-06-26 10:26:34.620232
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    u_u_i_d_format_0 = UUIDFormat()
    date_time_format_0 = DateTimeFormat()
    u_u_i_d_format_0.errors["format"] = "Must be valid UUID format."
    date_time_format_1 = DateTimeFormat()
    date_time_format_0.errors["format"] = "Must be a valid datetime format."
    date_time_format_2 = DateTimeFormat()
    date_time_format_1.errors["invalid"] = "Must be a real datetime."
    date_time_format_3 = DateTimeFormat()
    value_0 = date_time_format_2.validate("2020-08-15T09:44:14.846038+00:00")

# Generated at 2022-06-26 10:26:38.210254
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_format_value_0 = datetime.datetime(2019, 6, 15, 14, 47, 45, 0)
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate(date_time_format_format_value_0) is None


# Generated at 2022-06-26 10:26:45.694013
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert (date_time_format_0.validate("2018-12-18T21:00:00.000003+01:00")) == datetime.datetime(2018, 12, 18, 21, 0, 0, 3, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))


# Generated at 2022-06-26 10:26:57.340654
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Setup
    date_format_0 = DateFormat()
    date_format_0.errors = {"format": "Must be a valid date format.", "invalid": "Must be a real date."}

    time_format_0 = TimeFormat()
    time_format_0.errors = {"format": "Must be a valid time format.", "invalid": "Must be a real time."}

    date_time_format_0 = DateTimeFormat()
    date_time_format_0.errors = {"format": "Must be a valid datetime format.", "invalid": "Must be a real datetime."}

    # Testing

# Generated at 2022-06-26 10:27:10.720089
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test case 1:
    d_o_b = '2019-04-30'
    dateformat = DateFormat()
    expectedOutput = datetime.date(2019, 4, 30)
    assert dateformat.validate(d_o_b) == expectedOutput
    # Test case 2:
    dateformat2 = DateFormat()
    d_o_b2 = '2019-06-100'
    expectedError = dateformat2.validation_error('invalid')
    assert dateformat2.validate(d_o_b2) == expectedError
    # Test case 3:
    dateformat3 = DateFormat()
    d_o_b3 = '123456789'
    expectedError = dateformat3.validation_error('format')
    assert dateformat3.validate(d_o_b3) == expectedError

# Generated at 2022-06-26 10:27:18.833345
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("2011-11-11T11:11:11.111111Z")
    date_time_format_0.validate("2011-11-11T11:11:11.111111+01:00")


# Generated at 2022-06-26 10:27:26.958809
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Source code with tests for method validate of class DateFormat
  
    date_format_0 = DateFormat()
    date = "2020-09-12"
    assert date_format_0.validate(date) == datetime.date(2020, 9, 12)


# Generated at 2022-06-26 10:27:37.007530
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    # input argumant validation
    with pytest.raises(TypeError):
        date_time_format_0.validate("")

    with pytest.raises(TypeError):
        date_time_format_0.validate("")

    with pytest.raises(TypeError):
        date_time_format_0.validate("w")

    with pytest.raises(TypeError):
        date_time_format_0.validate("w")

    with pytest.raises(TypeError):
        date_time_format_0.validate("x")

    with pytest.raises(TypeError):
        date_time_format_0.validate("x")

    with pytest.raises(TypeError):
        date_time_

# Generated at 2022-06-26 10:27:40.298037
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat_obj = TimeFormat()
    assert (timeformat_obj.validate("13:20:00") == datetime.time(13, 20, 0))


# Generated at 2022-06-26 10:27:47.847346
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate('5:5')
    except ValidationError:
        pass
    else:
        print('ExpectedValidationError not raised')


# Generated at 2022-06-26 10:27:48.670208
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    pass


# Generated at 2022-06-26 10:27:55.493181
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    value_0 = "2020-01-19T10:00:00.123456Z"
    ret_0 = date_time_format_0.validate(value_0)
    expected_0 = datetime.datetime(2020, 1, 19, 10, 0, 0, 123456)
    assert ret_0 == expected_0


# Generated at 2022-06-26 10:28:07.469192
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_1 = DateFormat()
    date_format_2 = DateFormat()
    date_format_3 = DateFormat()
    date_format_4 = DateFormat()
    date_format_5 = DateFormat()
    date_format_6 = DateFormat()
    date_format_7 = DateFormat()
    date_format_8 = DateFormat()
    date_format_9 = DateFormat()
    date_format_10 = DateFormat()
    date_format_11 = DateFormat()
    date_format_12 = DateFormat()
    date_format_13 = DateFormat()
    date_format_14 = DateFormat()
    date_format_15 = DateFormat()
    date_format_16 = DateFormat()
    date_format_17 = DateFormat()
   

# Generated at 2022-06-26 10:28:18.072790
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    expected_value = datetime.datetime(2011, 1, 21, 18, 5, 59, 880121)
    datetimeformat_0 = DateTimeFormat()
    value = datetimeformat_0.validate("2011-01-21T18:05:59.880121")

    assert expected_value == value


# Generated at 2022-06-26 10:28:24.169415
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    u_u_i_d_format_0 = UUIDFormat()
    # Test if an exception is thrown for an incorrect value
    with pytest.raises(ValidationError):
        time_format_0.validate("00:00:00")


# Generated at 2022-06-26 10:28:28.898655
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    value_0 = "2020-07-07T27:25:28.939769+00:00"
    # ValueError: time data '2020-07-07T27:25:28.939769+00:00' does not match format '%Y-%m-%dT%H:%M:%S.%fZ'
    try:
        date_time_format_0.validate(value_0)
    except ValueError:
        print("ValueError")


# Generated at 2022-06-26 10:28:36.451951
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate('2019-06-16')


# Generated at 2022-06-26 10:28:50.739928
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    # AssertionError
    try:
        date_format_0.validate("h")
    except Exception as exc:
        assert isinstance(exc, AssertionError)
        assert exc.args[0] == "Must be a valid date format."
    else:
        raise Exception("expected AssertionError")
    # AssertionError
    try:
        date_format_0.validate("2001-13-01")
    except Exception as exc:
        assert isinstance(exc, AssertionError)
        assert exc.args[0] == "Must be a real date."
    else:
        raise Exception("expected AssertionError")
    # AssertionError

# Generated at 2022-06-26 10:29:01.313289
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate("2020-11-26")
    except Exception:
        raise ValueError("ValueError")

    try:
        date_format_0.validate("2020-02-31")
    except Exception:
        raise ValueError("ValueError")

    try:
        date_format_0.validate("2020-02-2")
    except Exception:
        raise ValueError("ValueError")

    try:
        date_format_0.validate("2020 02 02")
    except Exception:
        raise ValueError("ValueError")



# Generated at 2022-06-26 10:29:10.337279
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test raise error in method validate
    date_format_0 = DateFormat()
    # Variable to store the result of the test
    result = None

    test_date_validate = [
        "2019-12-04",
        "2019-02-29",
        "2017-12-04",
        "2019-12-30",
        "2019-12-31",
        "2019-04-30",
        "2021-08-31",
        "2019-04-31",
        "2019-04-32",
        "2019-13-31",
        "2019-05-32",
    ]

# Generated at 2022-06-26 10:29:13.175720
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat_validate_0 = DateTimeFormat()
    dateTimeFormat_validate_0.validate('2018-12-20T21:03:06.380163Z')


# Generated at 2022-06-26 10:29:18.872981
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_object_0 = datetime.date(year=2020, month=6, day=30)

    date_format_0 = DateFormat()

    obj = date_format_0.validate(value=date_object_0.isoformat())

    assert obj == date_object_0


# Generated at 2022-06-26 10:29:30.262635
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    test_case_0 = "2020"
    test_case_1 = "2020-01"
    test_case_2 = "2020-01-02"
    test_case_3 = "2020-01-02T01"
    test_case_4 = "2020-01-02T01:00"
    test_case_5 = "2020-01-02T01:00:01"
    test_case_6 = "2020-01-02T01:00:01.1"
    test_case_7 = "2020-01-02T01:00:01.2345"
    test_case_8 = "2020-01-02T01:00:01.23456"

# Generated at 2022-06-26 10:29:32.068409
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    u_u_i_d_format_0 = UUIDFormat()
    TimeFormat.validate(u_u_i_d_format_0)


# Generated at 2022-06-26 10:29:42.705885
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert (date_time_format_0.validate("2018-11-30T02:16") == datetime.datetime(2018, 11, 30, 2, 16, 0, 0, datetime.timezone.utc))
    assert (date_time_format_0.validate("2018-11-30T02:16:27Z") == datetime.datetime(2018, 11, 30, 2, 16, 27, 0, datetime.timezone.utc))
    assert (date_time_format_0.validate("2018-11-30T02:16:27.153388Z") == datetime.datetime(2018, 11, 30, 2, 16, 27, 153388, datetime.timezone.utc))

# Generated at 2022-06-26 10:29:56.463778
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    argument_0 = "2019-12-31"
    argument_1 = "2018-04-30"
    argument_2 = "2019-15-42"
    expected_0 = datetime.date(2019, 12, 31)
    expected_1 = datetime.date(2018, 4, 30)


# Generated at 2022-06-26 10:30:01.698472
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    assert time_format_0.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-26 10:30:08.502218
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    field_0 = date_format_0.validate('2010-10-20')
    assert isinstance(field_0, datetime.date)
    assert str(field_0) == '2010-10-20'

    try:
        field_0 = date_format_0.validate('2010-10-20T20:10:10Z')
        raise AssertionError
    except ValidationError as e:
        assert str(e) == 'Must be a valid date format.'

    try:
        field_0 = date_format_0.validate('2010-02-29')
        raise AssertionError
    except ValidationError as e:
        assert str(e) == 'Must be a real date.'


# Generated at 2022-06-26 10:30:19.619615
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    string_0 = "17:15:05"
    time_0 = time_format_0.validate(string_0)
    assert time_0.strftime('%H:%M:%S') == "17:15:05"

    time_format_1 = TimeFormat()
    string_1 = "17:15:05.000"
    time_1 = time_format_1.validate(string_1)
    assert time_1.strftime('%H:%M:%S.%f') == "17:15:05.000000"

    time_format_2 = TimeFormat()
    string_2 = "17:15:05.123456"
    time_2 = time_format_2.validate(string_2)