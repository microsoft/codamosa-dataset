

# Generated at 2022-06-26 10:20:40.539339
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    from typesystem.base import ValidationError
    from formats import UUIDFormat

    uuid_format_0 = UUIDFormat()
    assert_exc(ValidationError, uuid_format_0.validate, ("fdc1e0b5-618a-4e9d-a50c-f97caa5e5c53"))


# Generated at 2022-06-26 10:20:46.099569
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    """
    Test case for validate of class TimeFormat
    """

    TimeFormat_instance = TimeFormat()
    value = datetime.datetime.now().time()
    TimeFormat_instance.validate(value)

# Generated at 2022-06-26 10:20:52.913380
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format_1 = UUIDFormat()

    value = "a7d528a3-8930-4d6f-8a7a-962e09a1a4c4"

    result = uuid_format_1.validate(value)
    assert result == uuid.UUID("a7d528a3-8930-4d6f-8a7a-962e09a1a4c4")



# Generated at 2022-06-26 10:20:59.407410
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Assign parameter
    time_format = TimeFormat()
    value = "10:00:00"

    # Execute the method under test
    result = time_format.validate(value)

    # Verify the results
    assert result == datetime.time(10, 0)



# Generated at 2022-06-26 10:21:01.046122
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2019, 4, 25, 15, 19)
    date_time_format = DateTimeFormat()
    try:
        date_time_format.serialize(dt)
        assert False
    except:
        assert True



# Generated at 2022-06-26 10:21:02.737704
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    res = df.validate('2016-01-07')
    assert res == datetime.date(2016, 1, 7)


# Generated at 2022-06-26 10:21:10.356156
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    base_format_0 = BaseFormat()
    format_0 = TimeFormat()
    time_0 = datetime.time(hour=0, minute=0)
    str_0 = format_0.serialize(time_0)
    assert isinstance(str_0, str)
    assert str_0 == "00:00:00"



# Generated at 2022-06-26 10:21:13.230439
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2004-12-24")


# Generated at 2022-06-26 10:21:18.614999
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate(value = "12:00:00") == datetime.time(12, 0)


# Generated at 2022-06-26 10:21:25.488254
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Assume
    value_0 = '2100-07-05'
    value_1 = '2020-07-05'
    # Action
    dateformat_0 = DateFormat()
    dateformat_1 = DateFormat()
    # Assert
    assert dateformat_0.validate(value_0) == datetime.date(2100, 7, 5)
    try:
        dateformat_1.validate(value_1)
        assert False
    except:
        assert True


# Generated at 2022-06-26 10:21:34.114448
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    try:
        str_0 = "2019-12-29T00:00:00Z"
        date_time_format_0.validate(str_0)
    except ValidationError:
        pass
    try:
        str_0 = "2019-12-29T00:00:00.008Z"
        date_time_format_0.validate(str_0)
    except ValidationError:
        pass
    try:
        str_0 = "2019-12-29T00:00:00.008"
        date_time_format_0.validate(str_0)
    except ValidationError:
        pass

# Generated at 2022-06-26 10:21:37.067597
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert isinstance(time_format_0, BaseFormat)


# Generated at 2022-06-26 10:21:39.173254
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    date_format_0.serialize(datetime.date(1, 1, 1))


# Generated at 2022-06-26 10:21:43.805239
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    format = DateTimeFormat()
    
    # testcase 1
    obj = datetime.datetime.now()
    output = format.serialize(obj)


# Generated at 2022-06-26 10:21:48.886012
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    base_format_1 = DateTimeFormat()
    assert base_format_1.validate("2019-12-09T20:04:57.748922Z") == datetime.datetime(2019, 12, 9, 20, 4, 57, 748922, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-26 10:22:01.770578
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()

    # case 0: valid format, valid datetime
    with pytest.raises(NotImplementedError):
        datetime_format.validate("2019-01-01T00:00:00.000000")
    # case 1: invalid format, valid datetime
    with pytest.raises(NotImplementedError):
        datetime_format.validate("2019-01-01 00:00:00.000000")
    # case 2: valid format, invalid datetime
    with pytest.raises(NotImplementedError):
        datetime_format.validate("2019-02-31T00:00:00.000000")
    # case 3: invalid format, invalid datetime

# Generated at 2022-06-26 10:22:12.481528
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_DateTimeFormat_validate_0 = DateTimeFormat()
    test_DateTimeFormat_validate_0.validate("2018-11-15T17:13:32.123456Z") == datetime.datetime(2018, 11, 15, 17, 13, 32, 123456, tzinfo=datetime.timezone.utc)
    test_DateTimeFormat_validate_0.validate("2018-11-15T17:13:32.123Z") == datetime.datetime(2018, 11, 15, 17, 13, 32, 123000, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-26 10:22:18.813465
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize(): 
    date_format_0 = DateFormat() 
    obj_0_0 = datetime.date(2020, 12, 9)
    assert date_format_0.serialize(obj=obj_0_0) == "2020-12-09"


# Generated at 2022-06-26 10:22:22.130592
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate('-1:00')
    except ValidationError as exc:
        print(exc)


# Generated at 2022-06-26 10:22:25.748084
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    print("Testing serialize of DateFormat")
    date_format_0 = DateFormat()
    date_0 = datetime.date(year=2000, month=5, day=5)
    date_format_0.serialize(date_0)
    # The following assertion fails
    assert date_format_0.serialize(date_0) == "2000-05-05"
    # The following assertion fails
    assert date_format_0.serialize(date_0) == "2000-5-5"


# Generated at 2022-06-26 10:22:34.376187
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format_0 = DateTimeFormat()
    with pytest.raises(NotImplementedError):
        date_format_0.validate('value')


# Generated at 2022-06-26 10:22:37.180704
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format_0 = DateTimeFormat()
    assert None == format_0.validate(input_0)



# Generated at 2022-06-26 10:22:45.659023
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    dateTime1 = dateTimeFormat.validate("2018-05-31T21:06Z")
    assert dateTime1 == datetime.datetime(2018, 5, 31, 21, 6, 0, tzinfo=datetime.timezone.utc)
    dateTime2 = dateTimeFormat.validate("2018-05-31T21:06:30Z")
    assert dateTime2 == datetime.datetime(2018, 5, 31, 21, 6, 30, tzinfo=datetime.timezone.utc)
    dateTime3 = dateTimeFormat.validate("2018-05-31T21:06:30.456789Z")

# Generated at 2022-06-26 10:22:48.997598
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetimeformat_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(2017, 1, 11)
    str_0 = datetimeformat_0.serialize(datetime_0)
    assert str_0 == "2017-01-11T00:00:00"


# Generated at 2022-06-26 10:23:01.139893
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    # datetime
    try:
        assert (date_time_format_0.validate("2020-01-02") == datetime.datetime(2020, 1, 2))
    except:
        assert (False)
    try:
        assert (date_time_format_0.validate("2020-01-02T00:00:00") == datetime.datetime(2020, 1, 2))
    except:
        assert (False)
    try:
        assert (date_time_format_0.validate("2020-01-02T00:00:00Z") == datetime.datetime(2020, 1, 2))
    except:
        assert (False)

# Generated at 2022-06-26 10:23:03.495900
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()


# Generated at 2022-06-26 10:23:06.777023
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_0 = DateTimeFormat()
    date_time_0.validate("2020-05-23T19:06:00Z")

# Generated at 2022-06-26 10:23:09.657342
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()


# Generated at 2022-06-26 10:23:12.560028
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    # time_format.validate()


# Generated at 2022-06-26 10:23:20.718659
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    value = DateFormat().validate("2019-05-10")
    assert value.year == 2019
    assert value.month == 5
    assert value.day == 10

    value = DateFormat().validate("2019-05-10")
    assert value.year == 2019
    assert value.month == 5
    assert value.day == 10



# Generated at 2022-06-26 10:23:37.671085
# Unit test for method validate of class DateTimeFormat

# Generated at 2022-06-26 10:23:43.322142
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("10:20:30.123456") == datetime.time(10, 20, 30,123456)


# Generated at 2022-06-26 10:23:58.961686
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormat_0 = TimeFormat()
    timeFormat_0.validate("00:00:00")
    timeFormat_0.validate("23:59:59")
    timeFormat_0.validate("00:00:10")
    timeFormat_0.validate("23:59:11")
    timeFormat_0.validate("00:10:00")
    timeFormat_0.validate("23:11:00")
    timeFormat_0.validate("10:00:00")
    timeFormat_0.validate("11:59:59")
    timeFormat_0.validate("00:00:00.000")
    timeFormat_0.validate("23:59:59.001")
    timeFormat_0.validate("00:00:00.100")
    timeFormat_0.valid

# Generated at 2022-06-26 10:24:12.034514
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtfmt = DateTimeFormat()

    assert dtfmt.validate("2018-10-20T18:13:29.123+00:00") == datetime.datetime(
        2018, 10, 20, 18, 13, 29, 123000, tzinfo=datetime.timezone.utc
    )

    assert dtfmt.validate("2018-10-20T18:13:29+00:00") == datetime.datetime(
        2018, 10, 20, 18, 13, 29, tzinfo=datetime.timezone.utc
    )

    assert dtfmt.validate("2018-10-20T18:13:29") == datetime.datetime(
        2018, 10, 20, 18, 13, 29
    )


# Generated at 2022-06-26 10:24:16.158755
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate('1994-03-31')
    except ValidationError:
        pass


# Generated at 2022-06-26 10:24:20.413960
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    with pytest.raises(NotImplementedError, match="Please implement this method."):
        date_format_0.validate(value=None)


# Generated at 2022-06-26 10:24:25.458866
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    TimeFormat_0 = TimeFormat()
    assert TimeFormat_0.validate('00:00').isoformat() == '00:00:00'
    try:
        print(TimeFormat_0.validate('24:00'))
    except ValidationError as e:
        assert 'invalid' in e.code
    try:
        print(TimeFormat_0.validate(''))
    except ValidationError as e:
        assert 'format' in e.code

# Generated at 2022-06-26 10:24:26.988224
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate("12:00") == datetime.time(12)

# Generated at 2022-06-26 10:24:31.548612
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    # raises error : must be a valid date format
    with pytest.raises(ValidationError):
        time_format.validate("hello")


# Generated at 2022-06-26 10:24:35.473855
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    date_time_format_0.validate('2018-03-26T21:08:36Z')



# Generated at 2022-06-26 10:24:41.591415
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat_0 = DateTimeFormat()
    dateTimeFormat_0.validate("2012-12-12")


# Generated at 2022-06-26 10:24:46.856565
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate("2020-11-09")
        assert False
    except ValidationError as ex:
        assert str(ex) == "Must be a real date."


# Generated at 2022-06-26 10:24:52.716004
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat_0 = DateFormat()
    try:
        dateFormat_0.validate("2073-12-27")
    except ValidationError as e:
        assert e.code == "invalid"


# Generated at 2022-06-26 10:24:57.844902
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_ref = DateFormat()
    date_format_ref.validate("2017-02-01")
    assert date_format_ref.validate("2017-02-01") == datetime.date(2017, 2, 1)


# Generated at 2022-06-26 10:25:07.662016
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_object = DateTimeFormat()
    date_object1_validate = date_object.validate('2019-10-23T11:50:31.000Z')
    date_object1_serialize = date_object.serialize(date_object1_validate)
    assert date_object1_serialize == '2019-10-23T11:50:31.000000Z'


# Generated at 2022-06-26 10:25:14.412797
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2019-01-01")
    date_format_0.validate("+01:00")



# Generated at 2022-06-26 10:25:17.986498
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date = date_format_0.validate("2018-01-01")
    assert date.year == 2018 and date.month == 1 and date.day == 1



# Generated at 2022-06-26 10:25:21.776880
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    value = "2020-07-07"
    obj0 = DateFormat()
    assert obj0.validate(value) == datetime.date(2020, 7, 7)
    value = "2020-01-07"
    with pytest.raises(ValidationError):
        obj0.validate(value)


# Generated at 2022-06-26 10:25:24.812969
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate(["2015-05-21"])


# Generated at 2022-06-26 10:25:29.381191
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    try:
        # this method should raise ValidationError
        d_fmt = DateFormat()
        d_fmt.validate("a")
    except ValidationError:
        print("DateFormat.validate message: ", d_fmt.validation_error("format").message)


# Generated at 2022-06-26 10:25:34.172523
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value="1900-02-31T00:00:00+00:00"
    dateTimeFormat = DateTimeFormat()
    dateTime = dateTimeFormat.validate(value)
    assert dateTime == datetime.datetime(1900,2,28,16,0)
	

# Generated at 2022-06-26 10:25:43.783084
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTime_format = DateTimeFormat()
    assert (
        dateTime_format.validate("2018-10-26T20:07:15.074811Z")
        == datetime.datetime(2018,10, 26, 20, 7, 15, 74811, datetime.timezone.utc)
    )
    assert (
        dateTime_format.validate("2018-10-26T20:07:15.074811-04:00")
        == datetime.datetime(2018,10, 26, 20, 7, 15, 74811, datetime.timezone(datetime.timedelta(hours=-4)))
    )

# Generated at 2022-06-26 10:25:46.917389
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    with pytest.raises(NotImplementedError):
        date_format_0.validate("")


# Generated at 2022-06-26 10:25:50.934448
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():

    # Case 0
    # Expected result: Exception
    try:
        date_format_0 = DateFormat()
        date_format_0.validate("")
    except Exception:
        pass
    else:
        raise AssertionError('Method validate() should throw exception.')


# Generated at 2022-06-26 10:25:55.201342
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate('2019-01-01')
        assert True
    except:
        assert False


# Generated at 2022-06-26 10:25:59.879478
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate("2020-03-30")
        raise AssertionError("Must raise a ValidationError")
    except ValidationError as e:
        assert e.code == "format"


# Generated at 2022-06-26 10:26:03.234191
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate("2019-09-28")
    except Exception as e:
        print((e))
    else: assert False


# Generated at 2022-06-26 10:26:06.774752
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    string_2 = '2021-07-17'
    date_format_0.validate(string_2)



# Generated at 2022-06-26 10:26:11.515809
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    test_object_date_1 = DateFormat()
    test_input_value_1 = '2013-10-01'
    actual_value_1 = test_object_date_1.validate(test_input_value_1)
    assert actual_value_1 == datetime.date(2013, 10, 1)


# Generated at 2022-06-26 10:26:15.038017
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2019-11-04")


# Generated at 2022-06-26 10:26:20.102737
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    val = time_format_0.validate('12:24:43.420000')
    assert val == datetime.time(12, 24, 43, 420000)


# Generated at 2022-06-26 10:26:27.970238
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    try:
        datetime_format_0.validate("2016-05-15")
        print("DateTimeFormat test 1 passed.")
    except ValidationError as ve:
        print("DateTimeFormat test 1 failed.")


# Generated at 2022-06-26 10:26:35.051779
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    # Unit test for method is_native_type of class DateFormat
    assert df.is_native_type(datetime.date(2020, 1, 20))  # type: ignore
    assert not df.is_native_type(datetime.date.today())
    # Unit test for method serialize of class DateFormat
    assert df.serialize(datetime.date(2020, 2, 20)) == "2020-02-20"
    assert df.validate("2020-01-20") == datetime.date(2020, 1, 20)


# Generated at 2022-06-26 10:26:41.971849
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Create an instance of class DateFormat
    dateFormat = DateFormat()

    # Call method validate of class DateFormat
    assert dateFormat.validate("2018-01-01") == datetime.date(2018, 1, 1)

    try:
        dateFormat.validate("2018-01-40")
        assert False
    except ValidationError as e:
        assert e.code == "invalid"

    try:
        dateFormat.validate("2018-40-01")
        assert False
    except ValidationError as e:
        assert e.code == "format"

    try:
        dateFormat.validate("2018-01")
        assert False
    except ValidationError as e:
        assert e.code == "format"

    test_case_0()


# Generated at 2022-06-26 10:26:50.080875
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    validator_0 = DateFormat()
    assert validator_0.validate("1099-12-31") == datetime.date(1099, 12, 31), "Test Case: test_DateFormat_validate_0, Message: error message"
    assert validator_0.validate("0000-04-13") == datetime.date(0, 4, 13), "Test Case: test_DateFormat_validate_1, Message: error message"
    assert validator_0.validate("1053-10-30") == datetime.date(1053, 10, 30), "Test Case: test_DateFormat_validate_2, Message: error message"

# Generated at 2022-06-26 10:26:53.143934
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    # put your code here
    # function validate of class DateFormat should return a value of type ValidationError
    assert isinstance(date_format_0.validate("2345-06-06"), ValidationError)


# Generated at 2022-06-26 10:27:00.467998
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate('2012-10-18')
    date_time_format_0.validate('2011-05-12T03:30:11')

    try:
        date_time_format_0.validate('2011-05-12T03:30')
    except Exception as e:
        e.args[0] == 'Must be a valid datetime format.'


# Generated at 2022-06-26 10:27:07.409776
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_0 = datetime.time(3, 6)
    value_0 = time_0.isoformat()
    time_1 = time_format_0.validate(value_0)
    assert time_0.isoformat() == time_1.isoformat()


# Generated at 2022-06-26 10:27:12.675735
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    input_value = '1999-01-01'
    expected_output = datetime.date(1999, 1, 1)
    assert date_format_0.validate(input_value) == expected_output, 'Test Case Failed : test_DateFormat_validate'


# Generated at 2022-06-26 10:27:17.765076
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    try:
        date_format_0.validate("")
    except ValidationError as e:
        assert e.code == "format"
    else:
        assert False


# Generated at 2022-06-26 10:27:21.623467
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)



# Generated at 2022-06-26 10:27:33.939065
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    try:
        from typesystem.base import ValidationError
        time_format_1.validate(None)
    except ValidationError as e:
        pass

    try:
        from typesystem.base import ValidationError
        time_format_1.validate(None)
    except ValidationError as e:
        pass

    try:
        from typesystem.base import ValidationError
        time_format_0.validate('wrong time')
    except ValidationError as e:
        pass

    time_format_0.validate('17:04')
    time_format_1.validate('04:17:00')
    time_format_0.validate('04:17:00')

# Generated at 2022-06-26 10:27:39.167224
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate("")
    except ValidationError as err:
        assert err.text == "Must be a valid date format."



# Generated at 2022-06-26 10:27:42.293337
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    value = "2020-06-03T17:48:41.816589Z"
    assert(isinstance(dateTimeFormat.validate(value), datetime.datetime))


# Generated at 2022-06-26 10:27:46.414474
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('12:00:00.000000')


# Generated at 2022-06-26 10:28:00.966703
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Create an instance of DateFormat
    date_format_0 = DateFormat()
    # Create a real date
    real_date = datetime.date(2015, 12, 12)
    # Create a string that represents a date
    string_date = str(real_date)
    # Use method validate on the string representing the date
    result = date_format_0.validate(string_date)
    # Check that result is equal to the real date
    assert result == real_date
    # Create a string that represents an invalid date
    string_invalid_date = "abc"
    # Check that a ValidationError is raised
    try:
        date_format_0.validate(string_invalid_date)
    except ValidationError:
        pass


# Generated at 2022-06-26 10:28:09.328259
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    date_time_0 = date_time_format_0.validate("2019-06-08T03:01:00Z")
    assert date_time_0.year == 2019
    assert date_time_0.month == 6
    assert date_time_0.day == 8
    assert date_time_0.hour == 3
    assert date_time_0.second == 0
    assert date_time_0.microsecond == 0
    assert date_time_0.tzinfo == datetime.timezone.utc
    assert date_time_0.isoformat() == "2019-06-08T03:01:00+00:00"


# Generated at 2022-06-26 10:28:13.551147
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # given
    time_format_0 = TimeFormat()
    time_format_0.validation_error = MagicMock()
    time_format_0.validation_error.return_value = Mock()

    # when
    result = time_format_0.validate("14:00")
    
    # then
    assert result.isoformat() == "14:00:00"



# Generated at 2022-06-26 10:28:19.704260
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt_format_0 = DateTimeFormat()
    str_0 = "2020-03-14T08:31:09.494241Z"
    try:
        datetime_0 = dt_format_0.validate(str_0)
    except Exception as exc:
        raise AssertionError("Failed to invoke validate on DateTimeFormat: {0}", exc)


# Generated at 2022-06-26 10:28:23.350101
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("5478-02-19")


# Generated at 2022-06-26 10:28:39.332097
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    # Test case where the value is a valid datetime format and the proper
    #  datetime is returned.
    try:
        date_time_format_0.validate("2019-04-11T18:00:00")
    except:
        raise AssertionError("Unable to validate valid datetime format")

    # Test case where the value is not a valid datetime format and the proper
    #  exception is raised.
    try:
        date_time_format_0.validate("invalid-datetime-format")
    except ValidationError:
        pass
    except:
        raise AssertionError("Incorrect error type")



# Generated at 2022-06-26 10:28:46.107258
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    with pytest.raises(NotImplementedError):
        date_time_format_0.validate("value_0")


# Generated at 2022-06-26 10:28:54.536605
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    validator_0 = DateTimeFormat()
    value_0 = "2020-03-27T03:46:25.040112Z"
    value_0 = validator_0.validate(value_0)
    assert isinstance(value_0, datetime.datetime)


# Generated at 2022-06-26 10:29:03.233207
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    _test_value = datetime.datetime(2019, 1, 1)
    expected_validation_error_0 = ValidationError(text="Must be a valid datetime format.", code="format")
    try:
        assert not date_time_format_0.validate(_test_value)
    except ValidationError as exc:
        assert exc.to_dict() == expected_validation_error_0.to_dict()


# Generated at 2022-06-26 10:29:10.710075
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_1 = DateTimeFormat()
    date_time_format_2 = DateTimeFormat()
    date_time_format_3 = DateTimeFormat()
    date_time_format_4 = DateTimeFormat()
    date_time_format_5 = DateTimeFormat()
    date_time_format_6 = DateTimeFormat()
    date_time_format_7 = DateTimeFormat()
    date_time_format_8 = DateTimeFormat()
    date_time_format_9 = DateTimeFormat()
    date_time_format_10 = DateTimeFormat()
    date_time_format_11 = DateTimeFormat()
    date_time_format_12 = DateTimeFormat()
    date_time_format_13 = DateTimeFormat()
    date_

# Generated at 2022-06-26 10:29:12.378361
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    base_format_0 = DateTimeFormat()
    with pytest.raises(NotImplementedError):
        base_format_0.validate(value=None)


# Generated at 2022-06-26 10:29:15.661303
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate(None)
    except ValidationError as e:
        assert 'Must be a valid date format.' == str(e)
    else:
        assert False # pragma: no cover


# Generated at 2022-06-26 10:29:28.578313
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test Case 0
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("2019-01-02T01:02:01.123456Z")
    date_time_format_0.validate("2019-01-02T01:02:01Z")
    date_time_format_0.validate("2019-01-02T01:02:01+02:00")
    date_time_format_0.validate("2019-01-02T01:02:01-02:00")
    date_time_format_0.validate("2019-01-02T01:02:01.123456")
    date_time_format_0.validate("2019-01-02T01:02:01")

# Generated at 2022-06-26 10:29:34.897768
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat_0 = DateFormat()
    dateformat_0.validate("2019-02-28")
    dateformat_0.validate("2019-02-29")


# Generated at 2022-06-26 10:29:42.653642
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test case where datetime_str is valid date format
    date_format_0 = DateFormat()
    datetime_str_0 = "2010-10-10"
    expected_output = datetime.date(2010, 10, 10)
    actual_output = date_format_0.validate(datetime_str_0)
    assert actual_output == expected_output

    # Test case where datetime_str is invalid date format
    datetime_str_0 = "2010-10-10T10:10:10"
    try:
        date_format_0.validate(datetime_str_0)
    except ValidationError as e:
        if e.code == "format":
            pass
        else:
            raise AssertionError('ValidationError not raised with correct code')
    else:
        raise Assert

# Generated at 2022-06-26 10:29:51.225247
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():

    c = DateFormat()
    # No arguments
    try:
        c.validate()
    except TypeError as e:
        assert isinstance(e, TypeError)



# Generated at 2022-06-26 10:29:58.914832
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = "2020-01-01"
    datetime_date_0 = date_format_0.validate(str_0)
    str_1 = "2020-01-32"
    try:
        datetime_date_1 = date_format_0.validate(str_1)
    except ValidationError as e:
        assert e.code == "invalid"
        assert e.text == "Must be a real date."
    str_2 = "2020 01 01"
    try:
        datetime_date_2 = date_format_0.validate(str_2)
    except ValidationError as e:
        assert e.code == "format"
        assert e.text == "Must be a valid date format."


# Generated at 2022-06-26 10:30:02.795212
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format_0 = DateTimeFormat()
    # date_format_0.validate('2001-02-03T04:05:06.000007-08:00')


# Generated at 2022-06-26 10:30:05.547122
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    base_format_1 = TimeFormat()
    assert isinstance(base_format_1.validate(''), datetime.time)


# Generated at 2022-06-26 10:30:08.453193
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    # Call method validate with argument '2012-04-23T18:25:43.511Z'
    date_time_format_0.validate('2012-04-23T18:25:43.511Z')



# Generated at 2022-06-26 10:30:15.210738
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    base_format_0 = DateFormat()
    assert base_format_0.validate('2020-03-03') is not None
    try:
        base_format_0.validate('2020-03-02')
        assert False
    except ValidationError:
        pass
