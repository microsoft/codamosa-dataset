

# Generated at 2022-06-26 10:20:34.378042
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    value = "00:00:00.000000"
    expected = datetime.time(0, 0)
    assert expected == time_format_0.validate(value)


# Generated at 2022-06-26 10:20:38.041820
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    date_time_format_1.validate("2020-07-23T15:55:21Z")


# Generated at 2022-06-26 10:20:42.193682
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.serialize(datetime.datetime(2019, 12, 10, 18, 57, 37, 826730, tzinfo=datetime.timezone.utc)) == "2019-12-10T18:57:37.826730Z"



# Generated at 2022-06-26 10:20:50.494760
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    value_0 : str = "02:00"
    date_time_0 = time_format_0.validate(value_0)
    print(type(date_time_0))
    assert(isinstance(date_time_0, datetime.time))



# Generated at 2022-06-26 10:20:59.204224
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # check if the format of the time is correct
    time_format_0 = TimeFormat()
    time_format_0.validate('12:33:45.454545')
    # check if the format of the time is incorrect
    time_format_1 = TimeFormat()
    time_format_1.validate('12:33:45')


# Generated at 2022-06-26 10:21:04.636268
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:30:59.999999") == datetime.time(hour=12, minute=30,second=59,microsecond=999999)
    #assert ValidationError("Format") == time_format.validate("12")
    #assert ValidationError("Format") == time_format.validate("12:30")
    #assert ValidationError("Format") == time_format.validate("12:30:59:999999")
    #assert ValidationError("Invalid") == time_format.validate("12:99:00")


# Generated at 2022-06-26 10:21:10.800850
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case where value is None
    date_time_format_1 = DateTimeFormat()
    try:
        date_time_format_1.validate(None)
    except ValueError:
        pass
    else:
        assert False, 'ExpectedException not raised'
    # Test case where value is an empty string
    date_time_format_2 = DateTimeFormat()
    try:
        date_time_format_2.validate('')
    except ValueError:
        pass
    else:
        assert False, 'ExpectedException not raised'
    # Test case where value is a valid date
    date_time_format_3 = DateTimeFormat()
    result_3 = date_time_format_3.validate('1997-07-16T19:20+01:00')

# Generated at 2022-06-26 10:21:19.919920
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    # Happy case 1
    value = "13:13"
    expect = datetime.time(hour=13, minute=13)
    result = time_format.validate(value)
    assert result == expect

    # Happy case 2
    value = "13:13:13"
    expect = datetime.time(hour=13, minute=13, second=13)
    result = time_format.validate(value)
    assert result == expect

    # Happy case 3
    value = "13:13:13.123456"
    expect = datetime.time(hour=13, minute=13, second=13, microsecond=123456)
    result = time_format.validate(value)
    assert result == expect

    # Happy case 4

# Generated at 2022-06-26 10:21:31.154267
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.serialize(datetime.datetime(year=2019, month=8, day=9, hour=17, minute=26, second=22, microsecond=420000, tzinfo=datetime.timezone.utc)) == "2019-08-09T17:26:22.004000Z"
    assert date_time_format_0.serialize(datetime.datetime(year=2008, month=11, day=11, hour=23, minute=2, second=14, microsecond=634000, tzinfo=datetime.timezone.utc)) == "2008-11-11T23:02:14.634000Z"

# Generated at 2022-06-26 10:21:38.500293
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    test_date_time_0 = datetime.datetime(year=2018, month=10, day=12, hour=16, minute=26, second=36)
    result_date_time_0 = date_time_format_0.serialize(obj=test_date_time_0)
    assert result_date_time_0 == "2018-10-12T16:26:36"



# Generated at 2022-06-26 10:21:57.117803
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate(date_format_0)
    assert date_format_0.validate("2019-02-23") == datetime.date(2019, 2, 23)
    assert date_format_0.validate("2019-2-23") == datetime.date(2019, 2, 23)
    assert date_format_0.validate("2019-02-3") == datetime.date(2019, 2, 3)
    assert date_format_0.validate("2019-2-3") == datetime.date(2019, 2, 3)
    assert date_format_0.validate("19-02-23") == datetime.date(19, 2, 23)

# Generated at 2022-06-26 10:22:01.849163
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    UUIDFormat_instance_0 = UUIDFormat()
    try:
        UUIDFormat_instance_0.validate('34ffb427-5ba0-4e8f-bfac-9c5b62cabf23')
    except ValidationError as exc:
        assert exc.code == 'format'
        assert exc.text == 'Must be valid UUID format.'


# Generated at 2022-06-26 10:22:04.694795
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    try :
        date_time_format_0 = DateTimeFormat()
        date_time_format_1 = DateTimeFormat()
    except  Exception as expected:
        assert type(expected) is ValidationError




# Generated at 2022-06-26 10:22:11.704858
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_obj = datetime.datetime(2020, 1, 2, 3, 4, 5, 6, datetime.timezone(datetime.timedelta(7,0,0)))
    date_time_format_0 = DateTimeFormat()
    datetime_serialized = date_time_format_0.serialize(datetime_obj)
    assert datetime_serialized == "2020-01-02T03:04:05.000006+07:00"


# Generated at 2022-06-26 10:22:21.060278
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    val = "2020-02-13"
    expected_result = datetime.date(2020, 2, 13)
    result = DateFormat().validate(val)
    assert result == expected_result

    val = "2020-02-29"
    expected_result = ValidationError("Must be a real date.", "invalid")
    result = DateFormat().validate(val)
    assert result == expected_result


# Generated at 2022-06-26 10:22:31.400348
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    with pytest.raises(NotImplementedError):
        date_format_0.validate("")

    date_format_1 = DateFormat()
    with pytest.raises(NotImplementedError):
        date_format_1.validate(1.1)

    date_format_2 = DateFormat()
    with pytest.raises(NotImplementedError):
        date_format_2.validate(1)

    date_format_3 = DateFormat()
    with pytest.raises(NotImplementedError):
        date_format_3.validate(1.0)

    date_format_4 = DateFormat()
    with pytest.raises(NotImplementedError):
        date_format_4.validate(True)




# Generated at 2022-06-26 10:22:38.713175
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    date_time_format_1 = DateTimeFormat()
    date_time_format_2 = DateTimeFormat()
    date_time_format_3 = DateTimeFormat()
    date_time_format_4 = DateTimeFormat()
    date_time_format_5 = DateTimeFormat()
    date_time_format_6 = DateTimeFormat()
    date_time_format_7 = DateTimeFormat()
    date_time_format_8 = DateTimeFormat()
    date_time_format_9 = DateTimeFormat()
    date_time_format_10 = DateTimeFormat()
    date_time_format_11 = DateTimeFormat()
    date_time_format_12 = DateTimeFormat()
    date_time_format_13 = DateTimeFormat()
    date_

# Generated at 2022-06-26 10:22:42.890602
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    from freezegun import freeze_time
    date_time_format_0 = DateTimeFormat()
    with freeze_time("2019-03-03"):
        assert date_time_format_0.serialize(datetime.datetime.now()) == "2019-03-03T00:00:00"


# Generated at 2022-06-26 10:22:46.648692
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()

# Generated at 2022-06-26 10:22:49.077337
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()

    assert date_time_format.validate("2012-01-14T21:30:45.00Z") == datetime.datetime(2012, 1, 14, 21, 30, 45)


# Generated at 2022-06-26 10:22:57.059679
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate('2:30:10')
    except ValidationError:
        pass  # expected


# Generated at 2022-06-26 10:23:02.900459
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    year = 1975
    month = 12
    day = 6
    hour = 18
    minute = 12
    second = 57
    microsecond = 0
    datetime_0 = datetime.datetime(year=year, month=month, day=day, hour=hour, minute=minute, second=second, microsecond=microsecond)
    assert time_format_0.validate(datetime_0.time()) == datetime_0.time()


# Generated at 2022-06-26 10:23:06.779277
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert date_format_0.validate('2018-09-24') == datetime.date(2018, 9, 24)


# Generated at 2022-06-26 10:23:18.262752
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Test of serialize method where obj is None and obj is an instance of datetime
    def mock_serialize_0(self, obj):
        if obj is None:
            return None
        assert isinstance(obj, datetime.datetime)
        value = obj.isoformat()
        if value.endswith("+00:00"):
            value = value[:-6] + "Z"
        return value
    def mock_serialize_1(self, obj):
        if obj is None:
            return None
        assert isinstance(obj, datetime.datetime)
        value = obj.isoformat()
        if value.endswith("+00:00"):
            value = value[:-6] + "Z"
        return value
    # Mock object
    obj = datetime.datetime.now()
    mock

# Generated at 2022-06-26 10:23:25.909422
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():

    date_time_format_0 = DateTimeFormat()

    date_time_format_0.validate("2019-04-22T06:52:52")
    date_time_format_0.validate("2019-05-11T21:35:01.0003")
    date_time_format_0.validate("2019-06-07T07:08:32+02:00")
    date_time_format_0.validate("2019-11-17T04:47:58.123515")
    date_time_format_0.validate("2019-12-05T23:00:59+02:30")
    date_time_format_0.validate("2019-12-22T08:00:54.123+00:00")

# Generated at 2022-06-26 10:23:38.689857
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    # The case when "time" is valid
    time_valid = time_format_0.validate("12:34:56.789012")
    time_valid = time_format_0.validate("12:34:56.789012")
    time_valid = time_format_0.validate("12:34:56.789012")
    time_valid = time_format_0.validate("12:34:56")
    # The case when "time" is invalid
    try:
        time_format_0.validate("12:34:56.7890122")
        raise Exception("Test failed: the case when 'time' is invalid")
    except ValidationError as e:
        assert e.code == "format"

# Generated at 2022-06-26 10:23:46.427520
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    format1 = TimeFormat()

    # Valid case
    time1 = format1.validate('12:00')
    assert time1.hour == 12
    assert time1.minute == 0

    # Valid case
    time2 = format1.validate('23:59')
    assert time2.hour == 23
    assert time2.minute == 59

    # Error case
    try:
        format1.validate('24:00')
    except ValidationError:
        pass
    else:
        assert False

    # Error case
    try:
        format1.validate('12:60')
    except ValidationError:
        pass
    else:
        assert False


# Generated at 2022-06-26 10:23:49.016149
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020/06/06")


# Generated at 2022-06-26 10:23:57.766221
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    expected = datetime.datetime(year=2000, month=1, day=1, hour=0, minute=0, second=0, tzinfo=None)
    actual = date_time_format_0.validate("2000-01-01T00:00:00")
    assert actual == expected


# Generated at 2022-06-26 10:24:11.635457
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # case 1: date_format_0: date_format_0 is a DateFormat instance
    date_time_format_0 = DateFormat()
    # case 1.1: fail validation: not a valid format
    try:
        date_time_format_0.validate("2020-02-29T12:00:00Z")
        print("Test 1.1.1: pass")
    except ValidationError:
        print("Test 1.1.1: fail")
    # case 1.2: pass validation: a valid format
    try:
        date_time_format_0.validate("2020-11-01")
        print("Test 1.2.1: pass")
    except:
        print("Test 1.2.1: fail")
    # case 1.3: fail validation: non-real date

# Generated at 2022-06-26 10:24:22.788511
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_time_format_0 = DateTimeFormat()

    expected = datetime.datetime(2012, 12, 21, 12, 21)
    assert expected == date_time_format_0.validate("2012-12-21T12:21")

    expected = datetime.datetime(2012, 12, 21, 12, 21)
    assert expected == date_time_format_0.validate("2012-12-21 12:21")


# Generated at 2022-06-26 10:24:35.773444
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    # Test case: test if valid time format raise a validation error
    # Expected: raise a ValidationError
    try:
        time_format_0.validate('24:00:00')
    except ValidationError:
        pass
    else:
        assert False

    # Test case: test if invalid time format raise a validation error
    # Expected: raise a ValidationError
    try:
        time_format_0.validate('24:00:00')
    except ValidationError:
        pass
    else:
        assert False

    # Test case: test if raise a validation error with valid time format
    # Expected: raise a ValidationError
    try:
        time_format_0.validate('23:59:59')
    except ValidationError:
        assert False

# Generated at 2022-06-26 10:24:43.489940
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    try:
        date_time_format_0.validate(None)
        assert False
    except Exception as e:
        assert isinstance(e, ValidationError)
        assert e.code == "format"
        assert e.text == "Must be a valid datetime format."


# Generated at 2022-06-26 10:24:51.638396
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_1 = DateTimeFormat()

    value_0 = datetime.datetime(year=1, month=1, day=1)
    value_1 = datetime.time(hour=1, minute=1)
    value_2 = datetime.timezone(datetime.timedelta(hours=1, minutes=1))
    value_3 = datetime.timedelta(microseconds=1, seconds=1, minutes=1, hours=1)

    date_time_format_0.validate(value_0)
    date_time_format_0.validate(value_1)
    date_time_format_0.validate(value_2)
    date_time_format_0.validate(value_3)
    date_

# Generated at 2022-06-26 10:24:59.503780
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-05-31") == datetime.date(2020, 5, 31)
    assert date_format.validate("2001-10-05") == datetime.date(2001, 10, 5)
    assert date_format.validate("2001-10-05") == datetime.date(2001, 10, 5)
    assert date_format.validate("2001-10-05") == datetime.date(2001, 10, 5)
    assert date_format.validate("2001-10-05") == datetime.date(2001, 10, 5)
    assert date_format.validate("2001-10-05") == datetime.date(2001, 10, 5)


# Generated at 2022-06-26 10:25:06.725988
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_0 = date_format_0.validate("7048-21-61")
    assert date_0.year == 1970
    assert date_0.day == 21
    assert date_0.month == 8

# Generated at 2022-06-26 10:25:10.617836
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    val_0 = date_format_0.validate("2020-07-01")
    assert val_0 == datetime.date(2020, 7, 1)

    try:
        date_format_0.validate("2020-1-1")
    except Exception as e:
        assert isinstance(e, ValidationError)



# Generated at 2022-06-26 10:25:12.343878
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2017-08-10")



# Generated at 2022-06-26 10:25:17.735305
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2020-06-28") == datetime.date(2020, 6, 28)
    assert DateFormat().validate("2020-01-01") == datetime.date(2020, 1, 1)
    assert DateFormat().validate("1000-01-01") == datetime.date(1000, 1, 1)


# Generated at 2022-06-26 10:25:23.936790
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("2020-07-04T15:51:52+07:00")
    date_time_format_0.validate("2020-07-04T15:51:52")
    date_time_format_0.validate("2020-07-04T15:51:52Z")
    date_time_format_0.validate("2020-07-04T15:51:52.123")
    date_time_format_0.validate("2020-07-04T15:51:52.123456")


# Generated at 2022-06-26 10:25:29.077362
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = '23:59:59'
    time_format = TimeFormat()
    assert time_format.validate(time) == datetime.time(23,59,59)


# Generated at 2022-06-26 10:25:32.834917
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate(value=None)


# Generated at 2022-06-26 10:25:43.470440
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df1 = DateFormat()
    assert df1.validate("2005-11-22") == datetime.date(2005, 11, 22)
    assert df1.validate("2005-11-22").isoformat() == "2005-11-22"
    assert df1.validate("2005-2-2") == datetime.date(2005, 2, 2)
    assert df1.validate("2005-2-2").isoformat() == "2005-02-02"
    assert df1.validate("2005-01-02").isoformat() == "2005-01-02"
    assert df1.validate("2005-1-2").isoformat() == "2005-01-02"
    assert df1.validate("2005-01-2").isoformat() == "2005-01-02"
    assert df1.validate

# Generated at 2022-06-26 10:25:47.483512
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    iso_format = '2018-12-03T03:12:59Z'
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate(iso_format).isoformat() == iso_format

# Generated at 2022-06-26 10:25:54.891934
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    time_format_2 = TimeFormat()
    time_format_3 = TimeFormat()

    time_format_0.validate("16:32:50.999999")
    time_format_1.validate("15:01:13")
    time_format_2.validate("15:01")
    time_format_3.validate("15")


# Generated at 2022-06-26 10:26:03.878344
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        assert str(date_format_0.validate("2018-01-02")) == "2018-01-02"
    except AssertionError:
        raise AssertionError("DateFormat validate doesn't work properly")
    try:
        assert str(date_format_0.validate("2018-01-32")) == "2018-01-32"
    except AssertionError:
        pass
    try:
        assert str(date_format_0.validate("")) == ""
    except AssertionError:
        pass


# Generated at 2022-06-26 10:26:08.937539
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    assert date_time_format_1.validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020, 1, 1, 0, 0, 0, 0, None)


# Generated at 2022-06-26 10:26:20.199956
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Create a test class for DateTimeFormat
    # Test for valid case
    valid_test = {
        "date": datetime.date(2001,1,1),
        "date_str": "2001-01-01"
    }
    assert DateFormat().validate(valid_test["date_str"]) == valid_test["date"]
    # Test for invalid case
    invalid_test = {
        "date_str_format_error": "2001-01",
        "date_str_value_error": "2002-02-30"
    }
    try:
        DateFormat().validate(invalid_test["date_str_format_error"])
    except ValidationError as e:
        assert e.code == "format"

# Generated at 2022-06-26 10:26:34.290215
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1
    test_case_1_value = "2020-02-29T00:00:00.000000Z"
    print("\n")
    print("Testing: validate")
    print("Value: ", test_case_1_value)
    test_case_1_obj = DateTimeFormat().validate(value=test_case_1_value)
    assert isinstance(test_case_1_obj, datetime.datetime)
    assert(test_case_1_obj.isoformat() + "Z" == test_case_1_value)
    print("Result: ", test_case_1_obj.isoformat() + "Z")
    print("Expected: ", test_case_1_value)

# Generated at 2022-06-26 10:26:37.306276
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    expected = datetime.date(2020, 12, 31)
    got = date_format_0.validate("2020-12-31")
    assert got == expected


# Generated at 2022-06-26 10:26:39.914239
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    pass
    raise NotImplementedError() 


# Generated at 2022-06-26 10:26:49.515544
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    dt1 = date_time_format_0.validate('2015-09-17T03:04:00Z')
    assert dt1 == datetime.datetime(2015, 9, 17, 3, 4, tzinfo=datetime.timezone.utc)
    dt2 = date_time_format_0.validate('2015-03-17T03:04:00-04:00')
    assert dt2 == datetime.datetime(2015, 3, 17, 3, 4, tzinfo=datetime.timezone(datetime.timedelta(hours=-4)))
    dt3 = date_time_format_0.validate('2015-03-17T03:04:00+04:00')

# Generated at 2022-06-26 10:26:58.134587
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    data0 = "invalid"
    data1 = "2019-01-01"
    data2 = "2019-01-01T01:01"
    data3 = "2019-01-01T01:01:01"
    data4 = "2019-01-01T01:01:01.123"
    data5 = "2019-01-01T01:01:01.123456"
    data6 = "2019-01-01T01:01:01+01:00"
    data7 = "2019-01-01T01:01:01Z"
    data8 = "2019-01-01T01:01:01.123+01:00"
    data9 = "2019-01-01T01:01:01.123Z"

# Generated at 2022-06-26 10:27:02.868761
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate("00:00:00.000000")


# Generated at 2022-06-26 10:27:08.723950
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Case 0: Validate a correct date: 2020-10-01
    date_format_0 = DateFormat()
    date_0 = date_format_0.validate('2020-10-01')

    assert isinstance(date_0, datetime.date)

# Unit Test for method is_native_type of class DateFormat

# Generated at 2022-06-26 10:27:12.373635
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('12:11:58')


# Generated at 2022-06-26 10:27:17.359354
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    ret_val = date_time_format_0.validate("2019-02-28T00:00:00.00+00:00")
    assert isinstance(ret_val, datetime.datetime)


# Generated at 2022-06-26 10:27:26.282118
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():

    date_time_format_0 = DateTimeFormat()
    result_0 = date_time_format_0.validate("2018-01-02T03:04:05Z")
    result_1 = date_time_format_0.validate("2018-01-02T03:04:05.123456Z")
    result_2 = date_time_format_0.validate("2018-01-02T03:04:05.123Z")
    result_3 = date_time_format_0.validate("2018-01-02T03:04:05+00:00")
    result_4 = date_time_format_0.validate("2018-01-02T03:04:05.123456+00:00")

# Generated at 2022-06-26 10:27:30.386127
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("07:28:00.000000-05:00")
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-26 10:27:44.620325
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    value = "2010-04-03T18:53:23+08:00"
    print(date_time_format_1.validate(value))

    value = "2010-04-03T18:53:23"
    print(date_time_format_1.validate(value))

    value = "2010-04-03T18:53:23-08:00"
    print(date_time_format_1.validate(value))

    value = "2010-04-03T18:53:23.3+08:00"
    print(date_time_format_1.validate(value))

    value = "2010-04-03T18:53:23.35+08:00"

# Generated at 2022-06-26 10:27:54.505452
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    # Test for argument format
    assert date_format_0.validate('-1-1-1') == datetime.date(datetime.MINYEAR, 1, 1)
    # Test for argument invalid
    with pytest.raises(ValidationError) as err:
        date_format_0.validate('2016-02-29')
    assert err.value.code == 'invalid'
    


# Generated at 2022-06-26 10:28:00.637314
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value = "2015-05-23T20:43:19.926404"
    assert DateTimeFormat().validate(value) == datetime.datetime(2015, 5, 23, 20, 43, 19, 926404)


# Generated at 2022-06-26 10:28:03.608909
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = "2019-05-01"
    date_format_0 = DateFormat()
    date_format_0.validate(date)



# Generated at 2022-06-26 10:28:09.097820
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_1 = DateFormat()
    date_format_2 = DateFormat()
    date_format_3 = DateFormat()

    try:
        result_0 = date_format_1.validate("0")
    except ValidationError:
        pass

    try:
        result_0 = date_format_2.validate("1")
    except ValidationError:
        pass

    try:
        result_0 = date_format_3.validate("2")
    except ValidationError:
        pass


# Generated at 2022-06-26 10:28:13.429777
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    input_value = '2019-09-15'
    try:
        result_value = date_time_format_1.validate(input_value)
    except ValidationError:
        print('ValidationError caught')
        print('Description: Must be a real datetime.')
        print('Error Code: invalid')


# Generated at 2022-06-26 10:28:17.765209
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    string_obj_0 = date_time_format_0.validate("2020-07-27T04:27:09Z")
    assert string_obj_0 > 0
    assert isinstance(string_obj_0, datetime.datetime)


# Generated at 2022-06-26 10:28:29.580682
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-5-5") == datetime.date(2019, 5, 5)
    assert date_format.validate("2019-5-5") == datetime.date(2019, 5, 5)
    assert date_format.validate("2019-5-5") == datetime.date(2019, 5, 5)
    assert date_format.validate("2019-5-5") == datetime.date(2019, 5, 5)
    assert date_format.validate("2019-5-5") == datetime.date(2019, 5, 5)
    assert date_format.validate("2019-5-5") == datetime.date(2019, 5, 5)

# Generated at 2022-06-26 10:28:48.348715
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_1 = DateFormat()
    date_format_2 = DateFormat()
    date_format_3 = DateFormat()
    date_format_4 = DateFormat()
    date_format_5 = DateFormat()
    date_format_6 = DateFormat()
    date_format_7 = DateFormat()
    date_format_8 = DateFormat()
    date_format_9 = DateFormat()
    date_format_10 = DateFormat()
    date_format_11 = DateFormat()

    try:
        date_format_0.validate("")
    except ValidationError as v:
        pass

    try:
        date_format_1.validate("2100-01-01")
    except ValidationError as v:
        pass


# Generated at 2022-06-26 10:29:02.751116
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_1 = DateFormat()
    date_format_2 = DateFormat()
    date_format_3 = DateFormat()
    date_format_4 = DateFormat()
    date_format_5 = DateFormat()
    date_format_6 = DateFormat()
    date_format_7 = DateFormat()
    date_format_8 = DateFormat()
    date_format_9 = DateFormat()
    date_format_10 = DateFormat()
    date_format_11 = DateFormat()
    date_format_12 = DateFormat()
    date_format_13 = DateFormat()
    date_format_14 = DateFormat()
    date_format_15 = DateFormat()
    date_format_16 = DateFormat()
    date_format_17 = DateFormat()
   

# Generated at 2022-06-26 10:29:12.235173
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    value_0 = "2016-01-02T15:04:05.123456Z"
    datetime_0 = datetime.datetime(2016, 1, 2, 15, 4, 5, 123456, tzinfo=datetime.timezone.utc)
    assert date_time_format_0.validate(value_0) == datetime_0
    # Verify error is raised for invalid value
    with pytest.raises(ValidationError) as error_info_0:
        date_time_format_0.validate("invalid")
    assert error_info_0.value.code == "format"
    assert str(error_info_0.value) == "Must be a valid datetime format."


# Generated at 2022-06-26 10:29:23.814988
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    print("TEST START: TimeFormat validate")
    time_format_0 = TimeFormat()
    time_value_0 = time_format_0.validate("00:00:10.00000000")
    assert time_value_0.isoformat() == "00:00:10"
    print("TEST END: TimeFormat validate")



# Generated at 2022-06-26 10:29:24.993103
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert True


# Generated at 2022-06-26 10:29:39.208258
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    string_test_0 = "2019-12-30"
    format_test_0 = DateFormat()
    value_test_0 = format_test_0.validate(string_test_0)
    assert isinstance(value_test_0, datetime.date)
    assert value_test_0.isoformat() == '2019-12-30'
    string_test_1 = "2019-12-30"
    format_test_1 = DateFormat()
    value_test_1 = format_test_1.validate(string_test_1)
    assert isinstance(value_test_1, datetime.date)
    assert value_test_1.isoformat() == '2019-12-30'
    string_test_2 = "2019-12-30"
    format_test_2 = DateFormat()
   

# Generated at 2022-06-26 10:29:45.324928
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_2 = TimeFormat()
    expected = datetime.time(tzinfo=None, hour=22, minute=44)
    actual = time_format_2.validate("22:44")
    assert expected == actual


# Generated at 2022-06-26 10:29:53.402037
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    time_value_0 = time_format_0.validate("12:12:12.123456")

    time_value_1 = time_format_0.validate("12:12:12.12345")
    assert time_value_1 == time_value_0


# Generated at 2022-06-26 10:29:58.488740
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
   x = DateTimeFormat()
   try: 
       x.validate(None)
       assert False, "Expected ValueError exception to be raised"
   except ValueError as e:
       assert str(e) == "The format is invalid"


# Generated at 2022-06-26 10:30:06.316661
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    expected_return_value_0: typing.Union[datetime.time, ValidationError] = datetime.time(
        15, 18, 24, tzinfo=None
    )
    actual_return_value_0 = time_format_0.validate(
        value="15:18:24"
    )
    assert actual_return_value_0 == expected_return_value_0
    assert actual_return_value_0.hour == 15
    assert actual_return_value_0.minute == 18
    assert actual_return_value_0.second == 24


# Generated at 2022-06-26 10:30:11.952066
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-02-01")
    with pytest.raises(ValidationError):
        date_format.validate("01/02/2020")
    with pytest.raises(ValidationError):
        date_format.validate("01/02")
    with pytest.raises(ValidationError):
        date_format.validate("32/02/2020")
    with pytest.raises(ValidationError):
        date_format.validate("2020/02/03")
    with pytest.raises(ValidationError):
        date_format.validate("35/8/2020")
