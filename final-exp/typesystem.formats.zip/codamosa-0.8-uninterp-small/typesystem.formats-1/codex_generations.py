

# Generated at 2022-06-26 10:20:29.766386
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    date_format_1 = DateFormat()

    # test 1
    value = "2019-03-12"
    value_obj = datetime.date(2019, 3, 12)
    result = date_format_0.validate(value)
    assert result == value_obj


# Generated at 2022-06-26 10:20:39.575487
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():    
    obj = UUIDFormat()
    assert obj.validate("1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed") == uuid.UUID("1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed")

    # test with wrong format
    with pytest.raises(ValidationError):
        obj.validate("aovpox")



# Generated at 2022-06-26 10:20:44.785897
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    serialized_date = DateTimeFormat().serialize(datetime.datetime(2017, 1, 1, 0, 0))
    assert serialized_date == '2017-01-01T00:00:00'

# Generated at 2022-06-26 10:20:52.073396
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    begin_date = '2019-01-01'
    try:
        date_time_format_0.validate(begin_date)
    except Exception as e:
        print('exception:', e)
        assert False
    else:
        assert True

if __name__ == '__main__':
    test_case_0()
    test_DateTimeFormat_validate()

# Generated at 2022-06-26 10:21:01.243295
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    
    with pytest.raises(ValidationError):
        date_time_format_0.validate('2068-03-25T07:41:45.419414')
    
    with pytest.raises(ValidationError):
        date_time_format_0.validate('2099-04-01T07:41:45.419414')


# Generated at 2022-06-26 10:21:09.157452
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    # Compare values of attribute serialize of DateTimeFormat with expected value
    assert date_time_format_0.serialize(datetime.datetime(1970, 1, 1, 0, 0, 0, 0)) == "1970-01-01T00:00:00"
    assert date_time_format_0.serialize(datetime.datetime(2020, 1, 1, 0, 0, 30, 0)) == "2020-01-01T00:00:30"
    assert date_time_format_0.serialize(datetime.datetime(2020, 1, 1, 0, 0, 0, 500000)) == "2020-01-01T00:00:00.500000"

# Generated at 2022-06-26 10:21:14.916828
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2020-01-31")
    date_format_0.validate("2020-12-31")
    date_format_0.validate("1999-01-31")
    date_format_0.validate("2020-12-31")
    date_format_0.validate("2019-12-31")


# Generated at 2022-06-26 10:21:19.678487
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_time_format_0 = DateFormat()
    assert date_time_format_0.validate(b"2019-12-03")


# Generated at 2022-06-26 10:21:25.172580
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    AssertionError_0 = AssertionError()
    datetime_0 = datetime.datetime.now()
    str_0 = date_time_format_0.serialize(datetime_0)
    try:
        assert str_0
    except AssertionError:
        raise AssertionError_0


# Generated at 2022-06-26 10:21:36.429131
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    x = TimeFormat()
    assert x.serialize(datetime.time(0, 0, 0)) == "00:00:00"
    assert x.serialize(datetime.time(10, 0, 0)) == "10:00:00"
    assert x.serialize(datetime.time(10, 58, 33)) == "10:58:33"
    assert x.serialize(datetime.time(10, 58, 33, 665000)) == "10:58:33.665000"
    assert x.serialize(datetime.time(10, 58, 33, 665)) == "10:58:33.000665"
    assert x.serialize(None) == None


# Generated at 2022-06-26 10:21:47.717556
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("18:35:59")
    except ValidationError as e:
        assert e.text == "Must be a valid time format."
        assert e.code == "format"
    else:
        assert False


# Generated at 2022-06-26 10:21:58.878063
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Create a value to validate
    value_0 = "1999-12-31T23:59:59.999999"

    # Create a DateTimeFormat object
    date_time_format_0 = DateTimeFormat()

    # Call the validate method
    output = date_time_format_0.validate(value_0)

    # Check that the output equals the expected output
    assert output == datetime.datetime(1999, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-26 10:22:11.256385
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Case #1 (valid)
    assert DateTimeFormat().validate('2020-12-22T18:47:06-06:00') == datetime.datetime(2020, 12, 22, 18, 47, 6, tzinfo=datetime.timezone(datetime.timedelta(-1, 68400)))

    # Case #2 (valid)
    assert DateTimeFormat().validate('2020-12-22T18:47:06Z') == datetime.datetime(2020, 12, 22, 18, 47, 6, tzinfo=datetime.timezone.utc)

    # Case #3 (invalid)
    try:
        DateTimeFormat().validate('2020-12-22T18:47:06-0600')
        assert False
    except ValidationError:
        assert True

    # Case #4

# Generated at 2022-06-26 10:22:24.586937
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    # Validating time
    time_format_0.validate("13:37")
    time_format_0.validate("01:59")
    time_format_0.validate("23:59")
    time_format_0.validate("00:00")
    time_format_0.validate("13:37:00")
    time_format_0.validate("13:37:00.0000")
    time_format_0.validate("13:37:00.123456")
    time_format_0.validate("13:37:00.1234")
    time_format_0.validate("13:37:00.123")
    time_format_0.validate("13:37:00.12")
    time_format_0.valid

# Generated at 2022-06-26 10:22:29.355107
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    time_0 = datetime.time(14, 5)
    str_0 = time_format_0.serialize(time_0)
    assert str_0 == "14:05:00"


# Generated at 2022-06-26 10:22:43.021937
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("01:30:01.123456") == datetime.time(1, 30, 1, 123456)
    assert time_format.validate("01:30") == datetime.time(1, 30)
    assert time_format.validate("5") == datetime.time(5)
    assert time_format.validate("5:5") == datetime.time(5, 5)
    assert time_format.validate("5:5:5.5:5") == datetime.time(5, 5, 5, 5)

    # Verify exception is raised for invalid inputs
    try:
        time_format.validate("25:60:00")
    except ValidationError as e:
        assert e.code == 'invalid'


# Generated at 2022-06-26 10:22:50.568556
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('12:34') == datetime.time(12,34)
    assert time_format.validate('12:34:56') == datetime.time(12,34,56)
    assert time_format.validate('12:34:56.123123') == datetime.time(12,34,56,123123)


# Generated at 2022-06-26 10:22:53.212712
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_1 = "00:01:02.003000"
    datetime_time_0 = time_format_0.validate(str_1)
    assert datetime_time_0.second == 2


# Generated at 2022-06-26 10:22:58.031484
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    try:
        time_format_0 = TimeFormat()
        time_format_0.validate("12:00")
        time_format_0.validate("12:00:12")
    except Exception:
        assert False



# Generated at 2022-06-26 10:23:02.382042
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    value = "2013-11-14T14:58:18Z"
    expected = datetime.datetime(2013, 11, 14, 14, 58, 18, tzinfo=datetime.timezone.utc)
    actual = date_time_format_0.validate(value)
    assert expected == actual


# Generated at 2022-06-26 10:23:09.362297
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    time_format_2 = TimeFormat()

# Generated at 2022-06-26 10:23:13.923598
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    # ValueError: time data '2018' does not match format '%Y-%m-%d %H:%M:%S'
    with pytest.raises(ValueError, match="does not match"):
        date_time_format_0.validate('2018')


# Generated at 2022-06-26 10:23:18.855984
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    with pytest.raises(NotImplementedError):
        time_format_0.validate('10:10:10')


# Generated at 2022-06-26 10:23:24.438082
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    result = date_time_format_0.validate("2019-04-09T12:15:27.000")

    assert result == datetime.datetime(2019, 4, 9, 12, 15, 27, 0), "Test case 0, expected result = datetime.datetime(2019, 4, 9, 12, 15, 27, 0), actual result = "+ result


# Generated at 2022-06-26 10:23:36.746162
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.serialize('') == None
    assert date_time_format_0.serialize('2000-06-26') == '2000-06-26'
    assert date_time_format_0.serialize('2001-03-12T23:57:35.1234+05:00') == '2001-03-12T23:57:35.1234+05:00'
    assert date_time_format_0.serialize('2020-08-28T13:24:07Z') == '2020-08-28T13:24:07Z'


# Generated at 2022-06-26 10:23:48.184419
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    format = TimeFormat()
    assert format.serialize(datetime.time(hour=12, minute=30)) == '12:30:00'
    assert format.serialize(datetime.time(hour=12, minute=30, second=16)) == '12:30:16'
    assert format.serialize(datetime.time(hour=12, minute=30, second=16, microsecond=123456)) == '12:30:16.123456'

    assert format.serialize(datetime.time(hour=12, minute=30, second=16, microsecond=123456, tzinfo=datetime.timezone.utc)) == '12:30:16.123456Z'

# Generated at 2022-06-26 10:23:50.493374
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    date_time_format = DateTimeFormat()
    value = date_time_format.serialize(None)
    assert value is None, "The value should be None"


# Generated at 2022-06-26 10:23:58.235147
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.serialize(datetime.datetime(
        datetime.MINYEAR, 1, 1, tzinfo=datetime.timezone.utc)) == '0001-01-01T00:00:00+00:00'


# Generated at 2022-06-26 10:24:00.308320
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate("2019-01-01")
    except ValidationError as e:
        assert e.code == "format"
        assert e.text == "Must be a valid date format."



# Generated at 2022-06-26 10:24:04.850087
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    try:
        date_time_format_0.serialize(None)
    except NotImplementedError:
        pass

# Generated at 2022-06-26 10:24:22.749198
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()

# Generated at 2022-06-26 10:24:30.824960
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = datetime.datetime.fromtimestamp(100000)
    str_0 = date_time_format_0.serialize(date_time_0)
    assert str_0 == '1970-01-02T02:46:40'



# Generated at 2022-06-26 10:24:35.732792
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    dateFormat.validate("2019-01-01")


# Generated at 2022-06-26 10:24:39.427098
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # TODO: Figure out how to test class methods
    # TODO: Implement test for DateTimeFormat validate method
    pass


# Generated at 2022-06-26 10:24:47.717657
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_validate_0 = DateTimeFormat()
    date_time_format_validate_1 = DateTimeFormat()

    date_time_format_validate_0.validate('')
# Parameter 'value' has datatype string, can not be converted to datetime.datetime
    date_time_format_validate_1.validate('0')
# Parameter 'value' has datatype string, can not be converted to datetime.datetime


# Generated at 2022-06-26 10:24:53.916258
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    a = TimeFormat()  # true 1
    assert a.validate('16:05:13.000314') == datetime.time(16, 5, 13, 314000)
    

# Generated at 2022-06-26 10:24:57.069130
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-09-01")



# Generated at 2022-06-26 10:25:09.643346
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    date_format_0.validate("1985-06-04")
    date_format_0.validate("1985-04-30")
    date_format_0.validate("1885-04-03")

    with pytest.raises(ValidationError):
        date_format_0.validate("")

    with pytest.raises(ValidationError):
        date_format_0.validate("02-02-2020")

    with pytest.raises(ValidationError):
        date_format_0.validate("1985/06/04")


# Generated at 2022-06-26 10:25:13.724556
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    try:
        assert str(datetime.datetime.now().isoformat()) == DateTimeFormat().serialize(datetime.datetime.now())
        assert None == DateTimeFormat().serialize(None)
    except Exception as e:
        raise RuntimeError("Failed to serialize datetime format: {}".format(str(e)))



# Generated at 2022-06-26 10:25:23.088779
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    time_format_2 = TimeFormat()
    time_format_3 = TimeFormat()
    time_format_4 = TimeFormat()
    time_format_5 = TimeFormat()
    time_format_6 = TimeFormat()
    time_format_7 = TimeFormat()
    time_format_8 = TimeFormat()
    time_format_9 = TimeFormat()
    time_format_10 = TimeFormat()
    time_format_11 = TimeFormat()
    time_format_12 = TimeFormat()
    time_format_13 = TimeFormat()
    time_format_14 = TimeFormat()
    time_format_15 = TimeFormat()
    time_format_16 = TimeFormat()
    time_format_17 = TimeFormat()
   

# Generated at 2022-06-26 10:25:34.392113
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Case 1
    date_time_format_1 = DateTimeFormat()
    datetime_1 = datetime.datetime(
        2001, 2, 3, 4, 5, 6, 7, tzinfo=datetime.timezone(datetime.timedelta(hours=-1))
    )
    serialize_1 = date_time_format_1.serialize(datetime_1)
    str_1 = '2001-02-03T04:05:06.000007-01:00'
    assert serialize_1 == str_1
    # Case 2
    date_time_format_2 = DateTimeFormat()
    datetime_2 = datetime.datetime(2001, 2, 3, 4, 5, 6, 7, tzinfo=datetime.timezone.utc)
    serialize_2 = date_

# Generated at 2022-06-26 10:25:37.819412
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'N<0nT6T1'
    datetime_0 = time_format_0.validate(str_0)


# Generated at 2022-06-26 10:25:47.821003
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.serialize(None) is None
    datetime_0 = datetime.datetime(1970, 11, 2, 1, 2, 3)
    datetime_1 = datetime.datetime(1970, 11, 2, 1, 2, 3)
    assert date_time_format_0.serialize(datetime_0) == datetime_1.isoformat()
    datetime_0 = datetime.datetime(1970, 11, 2, 1, 2, 3, tzinfo=datetime.timezone.utc)
    datetime_1 = datetime.datetime(1970, 11, 2, 1, 2, 3, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-26 10:25:52.318166
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'LG>Z4VJoa'
    time_0 = time_format_0.validate(str_0)
    assert time_0.isoformat() == '00:00:00'



# Generated at 2022-06-26 10:26:03.374088
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Test with a regular time string
    time_format = TimeFormat()
    time_string = "22:31:11"
    assert time_string == time_format.serialize(time_format.validate(time_string))
    # Test with an irregular time string
    time_string = "12"
    try:
        time_format.validate(time_string)
        assert False
    except ValidationError:
        assert True
        # Test with a time string that represents time after December 31, 9999 23:59:59
    time_string = "99:99:99"
    try:
        time_format.validate(time_string)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-26 10:26:09.172889
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    str_1 = '1N2j;i?N7'
    expected_result_0 = datetime.date(2020, 3, 19)
    # validate
    result_0 =  date_format_1.validate(str_1)
    assert result_0 == expected_result_0



# Generated at 2022-06-26 10:26:19.325484
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_2 = DateTimeFormat()
    datetime_2 = datetime.datetime(year=1989, month=5, day=3, hour=2, minute=35, second=14, microsecond=313021)
    str_2 = date_time_format_2.serialize(datetime_2)
    assert str_2 == str('1989-05-03T02:35:14.313021')



# Generated at 2022-06-26 10:26:28.683154
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    datetime_0 = datetime.datetime(1991, 4, 29, 23, 28, 42, tzinfo=datetime.timezone.utc)
    str_0 = 'N?+nb3tJ'
    time_0 = time_format_0.validate(str_0)


# Generated at 2022-06-26 10:26:33.055998
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'Vvx\\oH\\'
    datetime_0 = time_format_0.validate(str_0)
    assert datetime_0.tzname() == None


# Generated at 2022-06-26 10:26:41.930942
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    str_0 = 'LG>Z4VJoa'
    datetime_0 = date_time_format_0.validate(str_0)



# Generated at 2022-06-26 10:26:50.101232
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '8I.a,S{}n.K'
    time_0 = time_format_0.validate(str_0)
    str_1 = '+'
    time_1 = time_format_0.validate(str_1)
    str_2 = 'Ar`;^ff'
    time_2 = time_format_0.validate(str_2)


# Generated at 2022-06-26 10:26:53.403089
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'ZD?P=@m#sM'
    try:
        time_format_0.validate(str_0)
    except:
        pass
    else:
        assert False, 'Could not trigger exception.'


# Generated at 2022-06-26 10:26:57.116004
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '93X8&'
    time_0 = time_format_0.validate(str_0)


# Generated at 2022-06-26 10:27:05.839262
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    str_0 = 'h8><yTtzF'
    datetime_0 = date_time_format_0.validate(str_0)
    string_0 = date_time_format_0.serialize(datetime_0)
    assert string_0 == 'h8><yTtzF'


# Generated at 2022-06-26 10:27:09.653895
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = '+OgBNMk4}'
    with pytest.raises(ValidationError):
        date_0 = date_format_0.validate(str_0)


# Generated at 2022-06-26 10:27:15.475815
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '2:4'
    
    try:
        time_format_0.validate(str_0);
    except:
        print("Test case failed")
    

# Generated at 2022-06-26 10:27:18.836887
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'jEkHfPZeo'
    time_0 = time_format_0.validate(str_0)
    assert isinstance(time_0, datetime.time) == True


# Generated at 2022-06-26 10:27:21.623468
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = 'UPYz+o\x7fIx'
    datetime_0 = date_format_0.validate(str_0)


# Generated at 2022-06-26 10:27:25.111949
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    str_0 = 'LG>Z4VJoa'
    datetime_0 = date_time_format_0.validate(str_0)


# Generated at 2022-06-26 10:27:29.272909
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'QRE8Z4VJoa'
    time_0 = time_format_0.validate(str_0)


# Generated at 2022-06-26 10:27:36.915612
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = 'Q!7I+'
    date_format_0.validate(str_0)


# Generated at 2022-06-26 10:27:41.144510
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    # String value = 'LG>Z4VJoa'
    str_0 = 'LG>Z4VJoa'
    datetime_0 = date_time_format_0.validate(str_0)
    # String value = '2017-07-13T10:45:27Z'
    str_0 = '2017-07-13T10:45:27Z'
    datetime_0 = date_time_format_0.validate(str_0)

# Generated at 2022-06-26 10:27:49.034693
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'yUEt8D<'
    time_0 = time_format_0.validate(str_0)
    # AssertionError raised in 2 cases:
    # 1. The date time is not of the correct format
    # 2. The date time does not exist in reality
    result = "H/KG;cg[C"


# Generated at 2022-06-26 10:27:55.448443
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    str_1 = '2007-04-05T14:30:59.000Z'
    datetime_1 = date_time_format_1.validate(str_1)
    assert datetime_1.isoformat() == '2007-04-05T14:30:59+00:00'


# Generated at 2022-06-26 10:28:04.650001
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    from datetime import datetime
    str_0 = '2018-10-17T18:32:57.282000Z'
    datetime_0 = datetime.strptime(str_0, '%Y-%m-%dT%H:%M:%S.%fZ')
    str_1 = date_time_format_0.serialize(datetime_0)
    assert(str_1 == str_0)



# Generated at 2022-06-26 10:28:18.555802
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_1 = DateFormat()
    date_format_2 = DateFormat()
    date_format_3 = DateFormat()

    date_str_0 = 'EJX9S\')j+'
    date_0 = date_format_0.validate(date_str_0)

    date_str_1 = '^_\x0e\x13\x03*\x11)'
    date_1 = date_format_1.validate(date_str_1)

    date_str_2 = 'q>Y\x1fZ\x04\x0e$'
    with pytest.raises(ValueError):
        date_2 = date_format_2.validate(date_str_2)


# Generated at 2022-06-26 10:28:23.395876
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '3OyOId\nIg}'
    time_0 = time_format_0.validate(str_0)


# Generated at 2022-06-26 10:28:28.544329
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(0, 0, 0, 0, 0)
    str_0 = "0-00-00T00%3A00%3A00Z"
    result = date_time_format_0.serialize(datetime_0)
    assert result == str_0

test_case_0()

# Generated at 2022-06-26 10:28:32.124442
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    obj_0 = datetime.datetime.now()
    str_0 = date_time_format_0.serialize(obj_0)


# Generated at 2022-06-26 10:28:39.975016
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'o\xf7\x00i\xe0\x1e\x01'
    time_0 = time_format_0.validate(str_0)

# Generated at 2022-06-26 10:28:51.147976
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(1970, 8, 7, 23, 38, 6)
    str_0 = date_time_format_0.serialize(datetime_0)
    assert str_0 == '1970-08-07T23:38:06'

# Generated at 2022-06-26 10:28:55.584492
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'L-0qr{r^'
    time_0 = time_format_0.validate(str_0)

# Test for method serialize of class TimeFormat

# Generated at 2022-06-26 10:29:03.400060
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    str_0 = 'uV7vI-LB0'
    try:
        date_time_format_0.validate(str_0)
    except Exception as e:
        print(e)
    str_0 = '2016-06-17T22:28:32+00:00'
    try:
        date_time_format_0.validate(str_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 10:29:07.916250
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    with raises(ValidationError) as excinfo:
        date_format_0 = DateFormat()
        str_0 = 'q3)j`Q$@[B'
        date_format_0.validate(str_0)
    assert excinfo.value.code == 'format'


# Generated at 2022-06-26 10:29:15.902528
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(2010, 1, 1, 23, 59, 59, 999999)
    datetime_1 = datetime.datetime(2010, 1, 1, 23, 59, 59, 999999, tzinfo=datetime.timezone.utc)
    str_0 = '2010-01-01T23:59:59.999999Z'
    assert date_time_format_0.serialize(datetime_1) == str_0
    str_1 = '2010-01-01T23:59:59.999999'
    assert date_time_format_0.serialize(datetime_0) == str_1


# Generated at 2022-06-26 10:29:28.768925
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'IOPC!r%ZT9'
    time_0 = time_format_0.validate(str_0)
    assert isinstance(time_0, datetime.time)
    str_1 = '1/<$1e"0'
    time_1 = time_format_0.validate(str_1)
    assert isinstance(time_1, datetime.time)
    str_2 = 'V>9^"`]n'
    time_2 = time_format_0.validate(str_2)
    assert isinstance(time_2, datetime.time)
    str_3 = '1>nn"d'
    time_3 = time_format_0.validate(str_3)

# Generated at 2022-06-26 10:29:34.984700
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'fdZl'
    datetime_0 = time_format_0.validate(str_0)



# Generated at 2022-06-26 10:29:37.599959
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = 'A,d+r'
    datetime_0 = time_format_0.validate(str_0).isoformat()



# Generated at 2022-06-26 10:29:44.188170
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_1 = DateTimeFormat()
    datetime_0 = datetime.datetime.utcnow()
    str_0 = date_time_format_1.serialize(datetime_0)
    assert str_0.endswith('Z')


date_format_0 = DateFormat()

str_0 = 't(D},t'

date_0 = date_format_0.validate(str_0)

date_1 = date_format_0.serialize(date_0)

assert date_1 is None

date_format_1 = DateFormat()

str_1 = 'B6w,(k4'

date_2 = date_format_1.validate(str_1)

assert date_2 is None

date_format_2 = DateFormat()

# Generated at 2022-06-26 10:29:50.719965
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    str_0 = 'LG>Z4VJoa'
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.serialize(str_0) == 'LG>Z4VJoa'
