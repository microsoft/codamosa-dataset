

# Generated at 2022-06-26 10:20:40.502098
# Unit test for method validate of class DateFormat

# Generated at 2022-06-26 10:20:50.015106
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_0 = datetime.time(hour=15, minute=39, microsecond=946110)
    try:
        assert time_format_0.validate("18:12") == time_0
    except AssertionError as e:
        print(e)
        raise AssertionError("Test 0 of method validate of class TimeFormat failed")


# Generated at 2022-06-26 10:20:53.797456
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_object_0 = datetime.datetime( 2016, 2, 29, 12, 59, 59, 999999, datetime.timezone(datetime.timedelta(0, 0)) )
    string_object_0 = datetime_object_0.isoformat()

    assert string_object_0 == '2016-02-29T12:59:59.999999+00:00'


# Generated at 2022-06-26 10:21:03.824028
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    with pytest.raises(ValidationError):
        date_time_format_0.validate("invaliddatetime")
    with pytest.raises(ValidationError):
        date_time_format_0.validate("2020-20-20T20:20:20.20Z")
    assert date_time_format_0.validate("2020-01-01T20:20:20Z") == datetime.datetime(2020, 1, 1, 20, 20, 20, 0, datetime.timezone.utc)
    with pytest.raises(ValidationError):
        date_time_format_0.validate("2020-20-20")



# Generated at 2022-06-26 10:21:15.961325
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = datetime.datetime(2012, 12, 12, 12, 12, 12, 121212)
    assert date_time_format_0.serialize(date_time_0) == '2012-12-12T12:12:12.121212+00:00'
    date_time_0 = datetime.datetime(1999, 6, 15, 9, 45, 0, 0)
    assert date_time_format_0.serialize(date_time_0) == '1999-06-15T09:45:00+00:00'
    date_time_0 = datetime.datetime(1995, 5, 28, 21, 46, 0, 0)
    assert date_time_format_0.serialize(date_time_0)

# Generated at 2022-06-26 10:21:18.186569
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate(1)
    except ValidationError:
        pass
    except:
        print("Exception occured when testing DateFormat.validate()")
        traceback.print_exc()


# Generated at 2022-06-26 10:21:29.926675
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    #Validate a datetime string with no timezone
    assert date_time_format_0.validate("2018-02-13T10:00:00") == datetime.datetime(2018, 2, 13, 10, 0, 0, tzinfo=None)
    #Validate a datetime string with utc
    assert date_time_format_0.validate("2018-02-13T10:00:00Z") == datetime.datetime(2018, 2, 13, 10, 0, 0, tzinfo=datetime.timezone.utc)
    #Validate a datetime string with negative offset

# Generated at 2022-06-26 10:21:37.216803
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    validate_time_result = time_format.validate(
        value = "2019-07-21T10:40:41.123456-02:00"
        )
    assert validate_time_result == datetime.time(hour=10, minute=40, second=41, microsecond=123456, tzinfo=datetime.timezone(datetime.timedelta(seconds=7200)))

# Generated at 2022-06-26 10:21:41.014287
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert date_format_0.validate("2004-12-31") == datetime.date(2004, 12, 31)
    assert date_format_0.validate("2006-01-01") == datetime.date(2006, 1, 1)


# Generated at 2022-06-26 10:21:46.107062
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = "12:30"
    result = TimeFormat().validate(time)
    assert isinstance(result,datetime.time)
    assert result == datetime.time(12,30)


# Generated at 2022-06-26 10:22:04.104086
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    assert date_time_format_0.validate('2019-03-26T21:33:45.123456') == datetime.datetime(2019, 3, 26, 21, 33, 45, 123456)
    assert date_time_format_0.validate('2019-03-26T21:33:45.123') == datetime.datetime(2019, 3, 26, 21, 33, 45, 123000)
    assert date_time_format_0.validate('2019-03-26T21:33:45.12') == datetime.datetime(2019, 3, 26, 21, 33, 45, 120000)

# Generated at 2022-06-26 10:22:11.543472
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    # Case 0
    datetime_0 = datetime.datetime(
        1987, 5, 27, 11, 2, 0, 816253, tzinfo=datetime.timezone.utc
    )
    expected_result = "1987-05-27T11:02:00.816253+00:00"
    result = date_time_format_0.serialize(datetime_0)
    assert result == expected_result


# Generated at 2022-06-26 10:22:18.585688
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_1 = DateTimeFormat()
    assert date_time_format_1.serialize(datetime.datetime(2020, 11, 6, 1, 55, 39, 604218)) == '2020-11-06T01:55:39.604218'


# Generated at 2022-06-26 10:22:22.813654
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    date_time_format_0 = DateTimeFormat()
    try:
        date_time_format_0.validate("2019-02-18T11:16:33")
        print("valid")
    except:
        print("wrong")


# Generated at 2022-06-26 10:22:32.036312
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    date_time_format_0.validate("2019-10-25T12:00:00")

    date_time_format_0.validate("2019-10-25 12:00:00Z")

    date_time_format_0.validate("2019-10-25T12:00:00+02:00")

    try:
        date_time_format_0.validate("2019-10-25 12:00:00Z+02")
    except ValidationError as e:
        assert e.code == "format"

    try:
        date_time_format_0.validate("2019-10-25 12:00:00+02")
    except ValidationError as e:
        assert e.code == "format"


# Generated at 2022-06-26 10:22:38.017908
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = "00:00:01"
    time_0 = time_format_0.validate(str_0)
    assert time_0 == datetime.time(second=1)


# Generated at 2022-06-26 10:22:42.278736
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate("2002-10-27T15:21:36") == datetime.datetime(2002, 10, 27, 15, 21, 36, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-26 10:22:44.412755
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = date_time_format_0.validate("2019-07-13T00:33:00+05:30")
    asser

# Generated at 2022-06-26 10:22:54.254422
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    assert t.validate("21:11:21.1234") == datetime.time(
        hour=21, minute=11, second=21, microsecond=123400
    )
    assert t.validate("21:11") == datetime.time(hour=21, minute=11)
    assert t.validate("21") == datetime.time(hour=21)
    assert t.validate("21:11:21.123") == datetime.time(
        hour=21, minute=11, second=21, microsecond=123000
    )
    # assert time_format_0.validate("21:11:21.12345") == datetime.time(
    #     hour=21, minute=11, second=21, microsecond=12345
    # )
    assert t

# Generated at 2022-06-26 10:22:58.031475
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    result = date_time_format_0.serialize('')
    assert result == None


# Generated at 2022-06-26 10:23:05.168916
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test case
    fmt = DateFormat()
    fmt.validate("2020-12-20")

    # Test case
    fmt = DateFormat()
    fmt.validate("2020-12-20")


# Generated at 2022-06-26 10:23:14.845655
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():

  # Test case with no exception
  uuid_format_0 = UUIDFormat()
  uuid_format_0.validate('d6c9bd6b-e6e2-4d5c-8d6a-a6a19f6c9a6d')

  # Test case with exception
  uuid_format_1 = UUIDFormat()
  with pytest.raises(ValidationError) as exc_info:
    uuid_format_1.validate('d6c9bd6b-e6e2-4d5c-8d6a-a6a19f6c9a6')
  assert "Must be valid UUID format." == str(exc_info.value)



# Generated at 2022-06-26 10:23:16.773732
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    date_time_format_0 = UUIDFormat()
    date_time_format_0.validate('123e4567-e89b-12d3-a456-426655440000')

# Generated at 2022-06-26 10:23:23.405765
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("00:00:00.00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00.0") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00:00") == datetime.time(0, 0, 0)
    assert time_format.validate("00:00") == datetime.time(0, 0)


# Generated at 2022-06-26 10:23:28.899395
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format_0 = UUIDFormat()
    try:
        uuid_format_0.validate("a")
    except ValidationError:
        assert True
    except:
        assert False


# Generated at 2022-06-26 10:23:33.902360
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("abc")
    except ValidationError:
        pass
    else:
        assert False, "Expected ValidationError exception to be raised"


# Generated at 2022-06-26 10:23:45.713648
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format_0 = UUIDFormat()
    str_literal_0 = uuid_format_0.validate("a07a7e84-eea8-4464-a69e-9cbbd8edf7a0")
    assert isinstance(str_literal_0, uuid.UUID)
    assert str_literal_0 == uuid.UUID(
        "a07a7e84-eea8-4464-a69e-9cbbd8edf7a0"
    )

    with pytest.raises(ValidationError) as excinfo:
        uuid_format_0.validate("a07a7e84-eea8-4464-a69e-9cbbd8edf7b0")


# Generated at 2022-06-26 10:23:47.906292
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("-1:0")



# Generated at 2022-06-26 10:23:56.332229
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    # testcase 0
    uuid_format_0 = UUIDFormat()
    value_0 = "a5b5f8e5-9b5a-4cf0-9bcc-d28dee6b74e6"
    uuid.UUID(value_0)


# Generated at 2022-06-26 10:24:02.579626
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()

    arg_0 = None

    result_0 = date_time_format_0.serialize(arg_0)

    assert result_0 is None


# Generated at 2022-06-26 10:24:12.262716
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    import datetime

    obj = datetime.datetime(2020, 5, 28, 9, 33, 46, 53600, tzinfo=datetime.timezone(datetime.timedelta(hours=+5)))
    date_time_format_0 = DateTimeFormat()
    expected_out_0 = '2020-05-28T09:33:46.536000+05:00'
    out_0 = date_time_format_0.serialize(obj)
    assert out_0 == expected_out_0


# Generated at 2022-06-26 10:24:18.248367
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0_validate_0 = date_time_format_0.validate("2015-01-01T00:01:00Z")
    assert(date_time_format_0_validate_0 == datetime.datetime(2015, 1, 1, 0, 1, tzinfo=datetime.timezone.utc))
    date_time_format_0_validate_1 = date_time_format_0.validate("2015-01-01T00:01:00+00:00")
    assert(date_time_format_0_validate_1 == datetime.datetime(2015, 1, 1))

# Generated at 2022-06-26 10:24:26.907564
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2019-12-31")

    assert_raises(
        ValidationError,
        lambda: date_format_0.validate("2019-13-31"),
        "Must be a real date.",
        "invalid",
    )

    assert_raises(
        ValidationError,
        lambda: date_format_0.validate("2019-12-32"),
        "Must be a real date.",
        "invalid",
    )

    assert_raises(
        ValidationError,
        lambda: date_format_0.validate("2019-12"),
        "Must be a valid date format.",
        "format",
    )


# Generated at 2022-06-26 10:24:36.750876
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    # Test case 0
    #  test format:
    s0 = "2015-12-25T17:00:00Z"
    r0 = date_time_format.validate(s0)

    r0_expected = datetime.datetime(2015, 12, 25, 17, 0, 0, 0, datetime.timezone.utc)
    assert r0 == r0_expected
    #  test format:
    s0 = "2015-12-25T17:00:00+10:00"
    r0 = date_time_format.validate(s0)

    r0_expected = datetime.datetime(2015, 12, 25, 7, 0, 0, 0, datetime.timezone(datetime.timedelta(hours=10)))

# Generated at 2022-06-26 10:24:40.857304
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    value_0 = "2018-07-13"

    date_format_0.validate(value_0)


# Generated at 2022-06-26 10:24:46.121448
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    test_datetime_0 = datetime.datetime.utcnow()
    assert date_time_format_0.serialize(test_datetime_0) is not None

# Generated at 2022-06-26 10:24:55.974905
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    # Check for serialize for the datetime object
    datetime_obj = datetime.datetime.now()
    assert date_time_format_0.serialize(datetime_obj) == datetime_obj.isoformat()
    # Check for serialize for the null datetime object
    datetime_obj = None
    assert date_time_format_0.serialize(datetime_obj) == None


# Generated at 2022-06-26 10:25:04.533646
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()

    # test case 1
    value = "2018-01-31T14:03:03"
    match = DATETIME_REGEX.match(value)
    groups = match.groupdict()
    tzinfo_str = groups.pop("tzinfo")
    date: datetime.datetime = df.validate(value)
    assert date.isoformat() == value
    assert date.tzinfo == None
    # test case 2
    value = "2018-01-31T14:03:03+02:00"
    match = DATETIME_REGEX.match(value)
    groups = match.groupdict()
    tzinfo_str = groups.pop("tzinfo")
    date: datetime.datetime = df.validate(value)
    assert date.isoformat() == value

# Generated at 2022-06-26 10:25:11.811899
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    case_0_test_0 = datetime.datetime(1, 2, 3, 4, 5, 1, 0)
    case_0_expected_0 = '0001-02-03T04:05:01'
    case_0_actual_0 = DateTimeFormat().serialize(case_0_test_0)
    assert case_0_actual_0 == case_0_expected_0

    case_1_test_0 = datetime.datetime(1, 2, 3, 4, 5, 1)
    case_1_expected_0 = '0001-02-03T04:05:01'
    case_1_actual_0 = DateTimeFormat().serialize(case_1_test_0)
    assert case_1_actual_0 == case_1_expected_0


# Generated at 2022-06-26 10:25:17.377758
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate("20:30:31") == datetime.time(20, 30, 31)
    assert time_format_0.validate("10:20:30.123456") == datetime.time(
        10, 20, 30, 123456
    )


# Generated at 2022-06-26 10:25:30.986003
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    # test case for string
    try:
        date_format_0.validate("2015-06-11")
    except ValidationError as e:
        print(e)

    # test case for float
    try:
        date_format_0.validate(5.5)
    except ValidationError as e:
        print(e)

    # test case for int
    try:
        date_format_0.validate(5)
    except ValidationError as e:
        print(e)

    # test case for bool
    try:
        date_format_0.validate(True)
    except ValidationError as e:
        print(e)

    # test case for none

# Generated at 2022-06-26 10:25:37.830518
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    print("Testing validate method of DateTimeFormat class...")

    # Test case 0
    date_time_format_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(2014, 5, 22, 15, 0, tzinfo=datetime.timezone.utc)
    result_0 = date_time_format_0.validate(str(datetime_0))
    assert str(result_0) == "2014-05-22 15:00:00+00:00"

    # Test case 1
    date_time_format_1 = DateTimeFormat()
    datetime_1 = datetime.datetime(2014, 5, 22, 15, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=6)))
    result_1 = date_time_format_1.validate

# Generated at 2022-06-26 10:25:42.072891
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    value_0 = "2019-10-25"

    result_0 = date_format_0.validate(value_0)

    assert isinstance(result_0, datetime.date)
    assert result_0.year == 2019
    assert result_0.month == 10
    assert result_0.day == 25



# Generated at 2022-06-26 10:25:46.571924
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    date = date_time_format_1.validate('2020-11-02T15:49:52.924865-03:00')
    assert isinstance(date, datetime.datetime)


# Generated at 2022-06-26 10:25:54.736529
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate('00:00') == datetime.time(0)
    assert time_format_0.validate('23:59') == datetime.time(23,59)
    assert time_format_0.validate('23:59:59') == datetime.time(23,59,59)
    assert time_format_0.validate('23:59:59.999876') == datetime.time(23,59,59,999876)


# Generated at 2022-06-26 10:25:58.718373
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    assert date_time_format_0.validate("2000-10-10T10:10:10Z") is not None



# Generated at 2022-06-26 10:26:09.923489
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("12:00")
    time_format_0.validate("12:00:00")
    time_format_0.validate("12:00:00.00")
    time_format_0.validate("12:00:00.00")
    time_format_0.validate("12:00:00.000000")
    time_format_0.validate("12:00:00.00000000")
    time_format_0.validate("12:00:00.0000000000")
    time_format_0.validate("12:00:00.000000")
    time_format_0.validate("12:00:00.000")
    time_format_0.validate("12:00:00.000000000000")
    time

# Generated at 2022-06-26 10:26:16.936895
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate("2020-05-24T18:25:56.646021Z") == datetime.datetime(2020, 5, 24, 18, 25, 56)

# Generated at 2022-06-26 10:26:20.899860
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    input_0_0 = "time"
    time_format_0.validate(input_0_0)


# Generated at 2022-06-26 10:26:34.500900
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_1 = DateTimeFormat()
    date_format_2 = TimeFormat()
    date_format_3 = UUIDFormat()

    try:
        date_format_0.validate("2000-01-01T00:00:00.000Z")
        assert False
    except ValidationError as e:
        assert str(e) == "Must be a valid date format."

    try:
        date_format_1.validate("2000-01-01")
        assert True
    except ValidationError as e:
        assert False

    try:
        date_format_2.validate("2000-01-01")
        assert False
    except ValidationError as e:
        assert str(e) == "Must be a valid time format."


# Generated at 2022-06-26 10:26:42.731722
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-05-11T18:15:00Z") == datetime.datetime(
        2019, 5, 11, 18, 15, tzinfo=datetime.timezone.utc
    )


# Generated at 2022-06-26 10:26:47.878741
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    value = "12:23:02"
    try:
        r = time.validate(value)
        assert "12:23:02" == r.isoformat()
    except ValidationError:
        assert False


# Generated at 2022-06-26 10:26:52.509293
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():

    assert True


# # Unit test for method is_native_type of class TimeFormat

# Generated at 2022-06-26 10:26:56.547685
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_validate_0 = time_format_0.validate("00:00:00")



# Generated at 2022-06-26 10:26:58.758477
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('12:05:34')
    time_format_0.validate('16:20:59')


# Generated at 2022-06-26 10:27:11.255453
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    assert time_format_0.validate('') == datetime.time(0, 0)
    assert time_format_0.validate(' ') == datetime.time(0, 0)
    assert time_format_0.validate('a') == datetime.time(0, 0)
    assert time_format_0.validate('0') == datetime.time(0, 0)
    assert time_format_0.validate('12') == datetime.time(0, 12)
    assert time_format_0.validate('12:34') == datetime.time(12, 34)
    assert time_format_0.validate('12:34:56') == datetime.time(12, 34, 56)

# Generated at 2022-06-26 10:27:15.918583
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("")
    except ValidationError:
        pass
    except Exception:
        raise Exception


# Generated at 2022-06-26 10:27:16.770832
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()


# Generated at 2022-06-26 10:27:19.969260
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate("13:12:11.123456") == datetime.time(13, 12, 11, 123456)
    assert time_format_0.validate("13:12:11") == datetime.time(13, 12, 11)
    assert time_format_0.validate("13:12") == datetime.time(13, 12)
    raise Exception("Not Implemented Exception")


# Generated at 2022-06-26 10:27:24.773345
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("12:34:56.7890")



# Generated at 2022-06-26 10:27:29.406729
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    try:
        test_case_0()
    except:
        raise


# Generated at 2022-06-26 10:27:38.264751
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    with raises(ValidationError) as err_info_0:
        time_format_0.validate("")
    assert str(err_info_0.value) == "Must be a valid time format."


# Generated at 2022-06-26 10:27:40.073621
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Wrire the unit test code
    return


# Generated at 2022-06-26 10:27:50.641996
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    test_instance = TimeFormat()

    assert test_instance.validate("12:00:23.123456") == datetime.time(
        hour=12, minute=0, second=23, microsecond=123456
    )

    assert test_instance.validate("12:00:23.123") == datetime.time(
        hour=12, minute=0, second=23, microsecond=123000
    )

    assert test_instance.validate("12:00:23") == datetime.time(hour=12, minute=0, second=23)

    assert test_instance.validate("12:00") == datetime.time(hour=12, minute=0)



# Generated at 2022-06-26 10:28:04.331108
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_0 = time_format_0.validate("00:00:00.000000+00:00")
    assert time_0 == datetime.time(0, 0, 0, 0)
    time_1 = time_format_0.validate("10:00:00.000000+00:00")
    assert time_1 == datetime.time(10, 0, 0, 0)
    time_2 = time_format_0.validate("10:59:59.000000+00:00")
    assert time_2 == datetime.time(10, 59, 59, 0)
    time_3 = time_format_0.validate("00:00:00.000000+01:00")

# Generated at 2022-06-26 10:28:10.623656
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = "14:16"
    time_format_0.validate(str_0)


# Generated at 2022-06-26 10:28:16.462060
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    # TODO: add test and test cases for method validate of class DateFormat


# Generated at 2022-06-26 10:28:21.712895
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_1 = DateTimeFormat()
    date_time_format_0.validate(date_time_format_1)


# Generated at 2022-06-26 10:28:24.603092
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    value_0 = date_format_0.validate("2000-01-01")

    time_format_0 = TimeFormat()
    assert time_format_0.validate("00:00:00") == datetime.time(0, 0)


# Generated at 2022-06-26 10:28:30.839333
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("")
    except ValidationError as e:
        import logging
        logging.exception(e)

    try:
        time_format_0.validate("")
    except ValidationError as e:
        import logging
        logging.exception(e)

    try:
        time_format_0.validate("")
    except ValidationError as e:
        import logging
        logging.exception(e)


# Generated at 2022-06-26 10:28:39.193645
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate(time_format_0)


# Generated at 2022-06-26 10:28:50.184619
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    with pytest.raises(ValidationError) as exc_info:
        time_format.validate("abc")

    assert exc_info.value.text == "Must be a valid time format."

    with pytest.raises(ValidationError) as exc_info:
        time_format.validate("24:00:00")

    assert exc_info.value.text == "Must be a real time."

    assert time_format.validate("00:00:00") == datetime.time(0, 0)


# Generated at 2022-06-26 10:29:03.165017
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    """
    The purpose of this test is to validate that any string that
    matches the pattern for a valid DateFormat will be created
    with no errors.

    This means that the object parsed into the function should be
    a valid date as formatted.
    """

    date_format = DateFormat()

    date_str = "1999-02-28"
    date_object = date_format.validate(date_str)
    assert isinstance(date_object, datetime.date)
    assert date_object.year == 1999
    assert date_object.month == 2
    assert date_object.day == 28
    assert date_object.isoformat() == date_str

    date_str = "2020-9-01"
    date_object = date_format.validate(date_str)

# Generated at 2022-06-26 10:29:07.075570
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test for method validate of class DateFormat
    time_format_1 = DateFormat()
    optional_1 = time_format_1.serialize(time_format_1)


# Generated at 2022-06-26 10:29:11.427070
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # init
    input_value_0 = "2019-07-29"
    expected_output_0 = datetime.date(input_value_0)
    # run test and verify expectations
    assert expected_output_0 == DateFormat().validate(input_value_0)


# Generated at 2022-06-26 10:29:18.413226
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = "17:23:59"
    datetime_time_0 = time_format_0.validate(str_0)
    str_1 = "00:59:00"
    datetime_time_1 = time_format_0.validate(str_1)
    str_2 = "17:23"
    datetime_time_2 = time_format_0.validate(str_2)
    str_3 = "17:23:59.123456"
    datetime_time_3 = time_format_0.validate(str_3)
    str_4 = "17:23:59.1234"
    datetime_time_4 = time_format_0.validate(str_4)

# Generated at 2022-06-26 10:29:21.369748
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()


# Generated at 2022-06-26 10:29:24.034680
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    value_0 = time_format_0.validate(value_0)
    assert value_0 is None

# Generated at 2022-06-26 10:29:27.822079
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format_0 = DateFormat()
    timestamp_0 = date_format_0.validate(date_format_0)



# Generated at 2022-06-26 10:29:40.678102
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Create TimeFormat object
    time_format_0 = TimeFormat()

    # Error
    try:
        time_format_0.validate('')
    except ValidationError:
        pass

    # Error
    try:
        time_format_0.validate('S;5nE')
    except ValidationError:
        pass

    # Error
    try:
        time_format_0.validate('-')
    except ValidationError:
        pass

    # Error
    try:
        time_format_0.validate('-@')
    except ValidationError:
        pass

    # Error
    try:
        time_format_0.validate('-A')
    except ValidationError:
        pass

    # Error

# Generated at 2022-06-26 10:29:55.710487
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_1 = time_format_0.validate("123")


# Generated at 2022-06-26 10:30:06.346133
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Instance to test
    time_format_1 = TimeFormat()
    # Check method
    assert time_format_1.validate(" ") == datetime.time(0, 0)
    # Check method
    assert time_format_1.validate(" ") == datetime.time(0, 0)
    # Check method
    assert time_format_1.validate(" ") == datetime.time(0, 0)
    # Check method
    assert time_format_1.validate(" ") == datetime.time(0, 0)
    # Check method
    assert time_format_1.validate(" ") == datetime.time(0, 0)
    # Check method
    assert time_format_1.validate(" ") == datetime.time(0, 0)
    # Check method

# Generated at 2022-06-26 10:30:12.144688
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = "not a real time"

    with pytest.raises(ValidationError):
        time_format_0.validate(str_0)

