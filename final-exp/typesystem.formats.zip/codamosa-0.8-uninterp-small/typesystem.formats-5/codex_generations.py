

# Generated at 2022-06-26 10:20:37.004366
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = date_time_format_0.validate("2015-03-05T09:56:59.000Z")
    assert isinstance(date_time_0, datetime.datetime)
    assert date_time_0.isoformat() == "2015-03-05T09:56:59+00:00"


# Generated at 2022-06-26 10:20:41.829471
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    # test_TimeFormat_validate() is expected to raise a ValidationError
    with pytest.raises(ValidationError) as excinfo:
        time_format_0.validate("23:28:19")
    assert str(excinfo.value) == "Must be a real time."


# Generated at 2022-06-26 10:20:51.273476
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Naming of variables below is based on the method's signature
    d_t_f_0 = DateTimeFormat()
    v_0 = "2001-01-31T12:34:56.123456"

    expected_0 = datetime.datetime(2001, 1, 31, 12, 34, 56, 123456)
    assert d_t_f_0.validate(v_0) == expected_0


# Generated at 2022-06-26 10:20:52.633248
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()

    date_format_0.serialize(None)


# Generated at 2022-06-26 10:21:01.220683
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()

    # Test a valid ISO8601 format
    value = "2020-02-02T11:23:00+01:00"
    assert datetime_format_0.validate(value).isoformat() == value
    assert datetime_format_0.validate(value + "Z").isoformat() == value + "Z"

    # Test a valid ISO8601 format with microseconds
    value = "2020-02-02T11:23:00.1234+01:00"
    assert datetime_format_0.validate(value).isoformat() == value
    assert datetime_format_0.validate(value + "Z").isoformat() == value + "Z"

    # Test a valid ISO8601 format with omitted second and microseconds

# Generated at 2022-06-26 10:21:04.537250
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert date_format_0.validate("2019-06-25") == datetime.date(2019, 6, 25)


# Generated at 2022-06-26 10:21:10.386233
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u_u_i_d_format_0 = UUIDFormat()
    # Test 1
    try:
        u_u_i_d_format_0.validate("2f8ea4ef-296e-47cf-b8e6-2f6e8418a3ff")
        assert True  # pragma: no cover
    except ValidationError as e:
        assert False

    # Test 2
    try:
        u_u_i_d_format_0.validate("2f8ea4ef-296e-47cf-b8e6-2f6e8418a3f")
        assert False
    except ValidationError as e:
        assert True  # pragma: no cover



# Generated at 2022-06-26 10:21:12.004465
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2018, 7, 31)) == '2018-07-31'


# Generated at 2022-06-26 10:21:16.709841
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert type(date_time_format_0.validate('2020-03-01T02:01:22Z')) == datetime.datetime


# Generated at 2022-06-26 10:21:19.319302
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat_validate_instance0 = TimeFormat()
    timeformat_validate_instance0.validate("15:00:00")


# Generated at 2022-06-26 10:21:27.082338
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    u_u_i_d_format_1 = DateTimeFormat()
    d_t_1 = datetime.datetime(2017, 1, 1, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=-1)))
    u_u_i_d_format_1.serialize(d_t_1)


# Generated at 2022-06-26 10:21:30.231427
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2020-01-03")


# Generated at 2022-06-26 10:21:41.293556
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    format_instance = TimeFormat()

    value = "04:05:06.123456"
    expected = datetime.time(4, 5, 6, 123456)
    assert format_instance.validate(value) == expected

    value = "04:05:06.12"
    expected = datetime.time(4, 5, 6, 120000)
    assert format_instance.validate(value) == expected

    value = "04:05:06.12"
    expected = datetime.time(4, 5, 6, 120000)
    assert format_instance.validate(value) == expected

    value = "04:05:06.12"
    expected = datetime.time(4, 5, 6, 120000)
    assert format_instance.validate(value) == expected


# Generated at 2022-06-26 10:21:44.519757
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    obj_0 = datetime.date(
        2016, 6, 23,
    )
    assert date_format_0.serialize(obj_0) == '2016-06-23'



# Generated at 2022-06-26 10:21:47.646687
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    assert date_format_0.serialize(obj=None) == None


# Generated at 2022-06-26 10:22:01.612548
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_case_id = 'C782912'

    # Input data
    value = '2017-12-01T05:56:41.879327+01:00'
    date_time_format_1 = DateTimeFormat()

    # Expected output
    expected = datetime.datetime(2017, 12, 1, 5, 56, 41, 879327,
        tzinfo=datetime.timezone(datetime.timedelta(seconds=3600)))
    actual = None

    # Unit test
    try:
        actual = date_time_format_1.validate(value)
        assert expected == actual
    except Exception as e:
        print('FAILED: test_DateTimeFormat_validate at line 103, ' +
            test_case_id + ': ' + str(e))

# Unit

# Generated at 2022-06-26 10:22:02.710640
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2019-04-15")


# Generated at 2022-06-26 10:22:10.464716
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    str_0 = "2019-04-24T11:14:26.372289+00:00"
    result = datetime_format_0.validate(str_0)
    assert result.microsecond == 372289
    assert result.weekday() == 2
    assert result.hour == 11
    assert result.minute == 14
    assert result.second == 26
    assert result.year == 2019
    assert result.month == 4
    assert result.day == 24


# Generated at 2022-06-26 10:22:17.744423
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    timeformat_1 = TimeFormat()
    time_2 = timeformat_1.validate("13:13")
    time_3 = timeformat_1.serialize(time_2)
    assert time_3 == "13:13:00"


# Generated at 2022-06-26 10:22:21.406321
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    obj_0 = None
    serialize_0 = date_format_0.serialize(obj=obj_0)
    assert serialize_0 == None


# Generated at 2022-06-26 10:22:33.867198
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    #Arrange
    dateTimeFormat = DateTimeFormat()
    date_0 = datetime.datetime(2015, 5, 5, 0, 0)
    date_1 = datetime.datetime(2010, 1, 1, 1, 1)
    date_2 = datetime.datetime(2011, 2, 2, 2, 2)
    date_3 = datetime.datetime(2012, 3, 3, 3, 3)
    date_4 = datetime.datetime(2013, 4, 4, 4, 4)
    date_5 = datetime.datetime(2014, 5, 5, 5, 5)
    #Act
    expected_1 = "2015-05-05T00:00:00"
    actual_1 = dateTimeFormat.serialize(date_0)

# Generated at 2022-06-26 10:22:36.389071
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    the_date_format_0 = DateFormat()
    try:
        the_date_format_0.validate('a value')
    except ValidationError:
        return
    raise Exception('ValidationError not raised')


# Generated at 2022-06-26 10:22:45.376202
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    ret = date_time_format_0.serialize(None)
    assert ret is None
    date_0 = datetime.datetime(2001, 5, 24, 17, 9, 34, 655000, datetime.timezone.utc)
    ret = date_time_format_0.serialize(date_0)
    assert ret == "2001-05-24T17:09:34.655000+00:00"
    date_0 = datetime.datetime(1970, 5, 24, 17, 9, 48, 136000, datetime.timezone.utc)
    ret = date_time_format_0.serialize(date_0)
    assert ret == "1970-05-24T17:09:48.136000+00:00"
    date

# Generated at 2022-06-26 10:22:50.864397
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    u_u_i_d_format_0 = UUIDFormat()
    obj_0 = "2010-07-14"
    # Serialize the value
    obj_0 = DateFormat.serialize(obj_0)
    # Verify the serialized value
    print(obj_0)

# Generated at 2022-06-26 10:22:55.676542
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    date_0: datetime.date = datetime.date(2019, 11, 27)
    assert date_format_0.serialize(date_0) == '2019-11-27'


# Generated at 2022-06-26 10:22:59.863157
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    obj = datetime.date(3, 3, 17)
    assert date_format_0.serialize(obj) == "0003-03-17"


# Generated at 2022-06-26 10:23:13.000914
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    # The str input is a valid datetime format recognized by the regex DATETIME_REGEX.
    a_str = '2019-01-01T01:01:01.123000Z'
    # The expected return value is a datetime object with a timezone of UTC.
    expected_ret_val_0 = datetime.datetime(2019, 1, 1, 1, 1, 1, 123000, datetime.timezone.utc)
    # Call method to be tested.
    ret_val_0 = date_time_format_0.validate(a_str)
    # The return value should be equal to the expected return value.
    assert ret_val_0 == expected_ret_val_0


# Generated at 2022-06-26 10:23:18.227862
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    # return str
    assert isinstance(date_time_format_0.serialize(None), str)



# Generated at 2022-06-26 10:23:22.077287
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    time_0 = datetime.datetime.now()
    time_0.strftime("%Y-%m-%dT%H:%M:%S.%fZ")




# Generated at 2022-06-26 10:23:25.400685
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat_0 = DateFormat()


# Generated at 2022-06-26 10:23:37.871917
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    value0 = "14:30:59.500000"
    value = time_format.validate(value0)
    assert value.hour == 14, f"actual output: {value.hour}, expected output: {14}"
    assert value.second == 59, f"actual output: {value.second}, expected output: {59}"
    assert value.minute == 30, f"actual output: {value.minute}, expected output: {30}"
    assert value.microsecond == 500000, f"actual output: {value.microsecond}, expected output: {500000}"


# Generated at 2022-06-26 10:23:44.116327
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_time_0 = date_format_0.validate("2020-01-01")
    except Exception as e:
        print(f"error({type(e).__name__}): {e}")


# Generated at 2022-06-26 10:23:56.386705
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t_i_m_e_format_0 = TimeFormat()
    t_i_m_e_0 = datetime.time(hour = 0, minute = 0, second = 0, microsecond = 0)
    assert t_i_m_e_format_0.validate("00:00:00") == t_i_m_e_0
    assert t_i_m_e_format_0.validate("00:00") == t_i_m_e_0


# Generated at 2022-06-26 10:24:11.024797
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    # Test the value 2019-08-22
    try:
        value_0 = date_format_0.validate("2019-08-22")
        assert value_0 == datetime.date(2019, 8, 22)
    except Exception as e:
        raise AssertionError(e)

    # Test the value 2019-09-31
    try:
        date_format_0.validate("2019-09-31")
        raise AssertionError("ValueError not raised.")
    except ValueError:
        pass

    # Test the value 2019-08
    try:
        date_format_0.validate("2019-08")
        raise AssertionError("ValidationError not raised.")
    except ValidationError:
        pass


# Generated at 2022-06-26 10:24:15.488268
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '19:31:05'
    assert time_format_0.is_native_type(datetime.time(19, 31, 5)) == False
    try:
        if time_format_0.is_native_type(datetime.time(19, 31, 5)):
            raise Exception
        time_format_0.validate(str_0)
        assert True
    except:
        assert False


# Generated at 2022-06-26 10:24:25.842239
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test 1: Assert that an invalid datetime string raises an error.
    try:
        datetime_format_0 = DateTimeFormat()
        datetime_format_0.validate("2019-09-21T15:51:45.Z")
    except ValidationError:
        pass
    else:
        assert False, "Expected ValidationError to be raised."

    # Test 2: Assert that a valid datetime string does not raise an error.
    try:
        datetime_format_0 = DateTimeFormat()
        datetime_format_0.validate("2019-09-21T15:51:45.000Z")
    except ValidationError:
        assert False, "Unexpected ValidationError to be raised."

    # Test 3: Assert that a valid datetime-aware string does not raise an error.
   

# Generated at 2022-06-26 10:24:34.441350
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    obj_0 = datetime.datetime(1937, 11, 14, 10, 32, 45, 530000, tzinfo=datetime.timezone(datetime.timedelta(seconds=7200)))
    actual_0 = date_time_format_0.serialize(obj_0)
    expected_0 = '1937-11-14T10:32:45.530000+02:00'

    assert actual_0 == expected_0


# Generated at 2022-06-26 10:24:39.901305
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    c = TimeFormat()

    # Test one: valid format
    try:
        value = "12:34"
        c.validate(value)
        assert True
    except ValidationError:
        assert False

    # Test two: invalid format
    try:
        value = "12:34:56:78"
        c.validate(value)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-26 10:24:50.574338
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    f = TimeFormat()

    value = "23:12:01"
    ret = f.validate(value)
    assert isinstance(ret, datetime.time)

    value = "23:12"
    ret = f.validate(value)
    assert isinstance(ret, datetime.time)

    value = "23"
    ret = f.validate(value)
    assert isinstance(ret, datetime.time)

    value = "23:12:01.1234"
    ret = f.validate(value)
    assert isinstance(ret, datetime.time)

    with pytest.raises(ValidationError):
        f.validate("24:12")

    with pytest.raises(ValidationError):
        f.validate("23:60")


# Generated at 2022-06-26 10:24:58.819438
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Test if method raises ValueError with default argument
    # This test case has been generated from the code fragment
    # dttime = datetime.datetime(2018, 12, 18, tzinfo=datetime.timezone.utc)
    # obj = DateTimeFormat().serialize(dttime)
    # assert obj == "2018-12-18T00:00:00Z"
    dttime_0 = datetime.datetime(2018, 12, 18, tzinfo=datetime.timezone.utc)
    obj_0 = DateTimeFormat().serialize(dttime_0)
    assert obj_0 == "2018-12-18T00:00:00Z"


# Generated at 2022-06-26 10:25:10.482525
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    v_0 = "10:10:10.000000"
    m_0 = time_format_0.validate(v_0)
    assert m_0 == datetime.time(10, 10, 10)

    time_format_1 = TimeFormat()
    v_1 = "10:10:10"
    m_1 = time_format_1.validate(v_1)
    assert m_1 == datetime.time(10, 10, 10)


# Generated at 2022-06-26 10:25:16.695174
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    d_t_f_0 = DateTimeFormat()
    dt_0 = datetime.datetime(2020, 12, 31, 12, 59, 59, 876543);
    assert d_t_f_0.serialize(dt_0) == "2020-12-31T12:59:59.876543"


# Generated at 2022-06-26 10:25:24.491241
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    #
    # W głównych wersjach jeśli jest podawany datetime bez czasu
    # jest on wpisywany jako 0:00:00
    #
    assert date_time_format_0.serialize(datetime.datetime.fromisoformat(
        '2011-11-11T00:00:00'
    )) == '2011-11-11T00:00:00Z'
    assert date_time_format_0.serialize(datetime.datetime.fromisoformat(
        '2011-11-11T00:00:00.000000'
    )) == '2011-11-11T00:00:00Z'

# Generated at 2022-06-26 10:25:33.974082
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate("2000-01-01T00:00:00Z") == datetime.datetime(2000, 1, 1, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format_0.validate("2000-01-01T00:00:00.000000Z") == datetime.datetime(2000, 1, 1, 0, 0, tzinfo=datetime.timezone.utc)
    assert date_time_format_0.validate("2000-01-01T00:00:00.010000Z") == datetime.datetime(2000, 1, 1, 0, 0, 0, 10000, tzinfo=datetime.timezone.utc)
    assert date_time

# Generated at 2022-06-26 10:25:37.348987
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    variable_0 = DateTimeFormat()
    variable_1 = variable_0.serialize( "2016-07-16T17:23:15.639141243-04:00" )
    variable_2 = variable_0.serialize( None )
    variable_3 = variable_0.serialize( "2017-09-17T12:01:35+01:00" )


# Generated at 2022-06-26 10:25:39.853691
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    print(date_time_format_0.validate("test_value"))


# Generated at 2022-06-26 10:25:40.750034
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert True


# Generated at 2022-06-26 10:25:43.266610
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_1 = TimeFormat()

    args_count_0 = ("ten")
    with raises(ValidationError):
        time_format_1.validate(*args_count_0)


# Generated at 2022-06-26 10:25:49.283399
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = datetime.datetime(
        year=year_0, month=month_0, day=day_0, hour=hour_0, minute=minute_0, tzinfo=tzinfo_0
    )
    string_0 = date_time_format_0.serialize(b_0)



# Generated at 2022-06-26 10:25:51.325013
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    exc = None
    try:
        date_format_0.validate("19:05:30")
    except Exception as err:
        exc = err

    assert isinstance(exc, ValidationError)


# Generated at 2022-06-26 10:25:58.033948
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dateTimeFormat_0 = DateTimeFormat()
    dateTime_0 = dateTime.datetime(1979, 6, 1, 4, 5, 6)
    str_0 = dateTimeFormat_0.serialize(dateTime_0)



# Generated at 2022-06-26 10:26:06.130135
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dateTimeFormat_0 = DateTimeFormat()
    # Expected: datetime.datetime(2004, 10, 23, 0, 0, 1, 0)
    str_0 = '2004-10-23T01:00:01'
    datetime_0 = dateTimeFormat_0.validate(str_0)
    str_1 = dateTimeFormat_0.serialize(datetime_0)
    assert str_1.isoformat() == '2004-10-23T01:00:01+01:00'


# Generated at 2022-06-26 10:26:17.850994
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '15:00:00'
    time_0 = time_format_0.validate(str_0)
    str_1 = '9:55:57.317845'
    time_1 = time_format_0.validate(str_1)
    str_2 = '15:00:00'
    time_2 = time_format_0.validate(str_2)
    str_3 = '25:00:00'
    try:
        time_format_0.validate(str_3)
    except ValidationError as e:
        str_4 = e.code
    str_5 = '9:55:57.317845'
    time_5 = time_format_0.validate(str_5)
    str

# Generated at 2022-06-26 10:26:24.646369
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = ';'
    try:
        time_0 = time_format_0.validate(str_0)
    except ValidationError as err:
        time_format_0_err = err
    assert time_format_0_err.code in ['format']
    assert time_format_0_err.text == 'Must be a valid time format.'
    try:
        assert time_format_0.validate('14:21:49.000123') == datetime.time(14, 21, 49, 123)
    except ValidationError as err:
        time_format_1_err = err
    assert time_format_1_err is None

# Generated at 2022-06-26 10:26:28.481148
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = date_time_format_0.validate(';')



# Generated at 2022-06-26 10:26:36.633104
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '23:59:17.4570'
    time_0 = time_format_0.validate(str_0)
    print(time_0)
    assert time_0.year == 1900
    assert time_0.month == 1
    assert time_0.day == 1
    assert time_0.hour == 23
    assert time_0.minute == 59
    assert time_0.second == 17
    assert time_0.microsecond == 4570
    str_1 = '12:01:03'
    time_1 = time_format_0.validate(str_1)
    print(time_1)
    assert time_1.year == 1900
    assert time_1.month == 1
    assert time_1.day == 1
    assert time

# Generated at 2022-06-26 10:26:39.031885
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = ';'
    assertRaises(ValidationError, time_format_0.validate, str_0)


# Generated at 2022-06-26 10:26:44.632219
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(2000, 3, 1, 0, 0)
    str_0 = date_time_format_0.serialize(datetime_0)


# Generated at 2022-06-26 10:26:48.502872
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '"'
    assert time_format_0.is_native_type(str_0) == False


test_case_0()
test_TimeFormat_validate()

# Generated at 2022-06-26 10:26:57.227860
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    date_time = date_time_format.validate('2019-07-23T12:34:56.123456Z')
    assert(date_time_format.serialize(date_time) == "2019-07-23T12:34:56.123456Z")


# Generated at 2022-06-26 10:27:01.438677
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test type change of DateFormat
    date_format_0 = DateFormat()
    str_0 = '2017-11-23'
    date_0 = date_format_0.validate(str_0)

    assert isinstance(date_0, datetime.date) == True



# Generated at 2022-06-26 10:27:07.552914
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = ';'
    try:
        time_0 = time_format_0.validate(str_0)
    except ValidationError as e:
        assert str(e) == "Must be a valid time format."


# Generated at 2022-06-26 10:27:10.091492
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = 'a'
    with pytest.raises(ValidationError):
        date_0 = date_format_0.validate(str_0)



# Generated at 2022-06-26 10:27:21.805562
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():

    datetime_format_0 = DateTimeFormat()
    
    str_0 = 'a'
    result_0 = datetime_format_0.validate(str_0)
    
    # test_case_0:
    # No assertion

    # test_case_1:
    # No assertion

    # test_case_2:
    # No assertion

    # test_case_3:
    # No assertion

    # test_case_4:
    # No assertion

    # test_case_5:
    # No assertion

    # test_case_6:
    # No assertion

    # test_case_7:
    # No assertion

    # test_case_8:
    # No assertion

    # test_case_9:
    # No assertion

    # test_case_10:
    # No assertion

# Generated at 2022-06-26 10:27:24.397143
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    global str_0
    global time_0
    try:
        test_case_0()
        assert False
    except ValidationError:
        pass
    assert True


# Generated at 2022-06-26 10:27:28.666850
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Tests for method validate of class DateTimeFormat
    date_format_0 = DateFormat()
    str_0 = ';'
    date_0 = date_format_0.is_native_type(str_0)



# Generated at 2022-06-26 10:27:33.382129
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    str_0 = ';'

    try:
        time_0 = time_format_0.validate(str_0)
    except ValidationError as e:
        val_err = e

    # assert val_err.code == "format"
    # assert val_err.text == "Must be a valid time format."



# Generated at 2022-06-26 10:27:36.899064
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = 'is1'
    date_0 = date_format_0.validate(str_0)
    assert(date_0 == datetime.date(2000, 1, 1))



# Generated at 2022-06-26 10:27:41.553330
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '15:16:17'
    time_0 = time_format_0.validate(str_0)
    assert time_0.minute == 16
    assert time_0.second == 17
    assert time_0.hour == 15

# Generated at 2022-06-26 10:27:44.475630
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    str_0 = '2017-12-25'
    datetime_0 = datetime_format_0.validate(str_0)


# Generated at 2022-06-26 10:27:52.484315
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Setup
    obj = TimeFormat()
    
    # Exercise
    obj.validate(value=None)
    
    # Verify
    
    
    # Cleanup - N/A



# Generated at 2022-06-26 10:27:56.433749
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = ';'
    try:
        date_0 = date_format_0.validate(str_0)
        raise AssertionError('validate failed')
    except ValidationError:
        pass


# Generated at 2022-06-26 10:28:08.163204
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    try:
        time_format_0 = TimeFormat()
        str_0 = ';'
        time_0 = time_format_0.validate(str_0)
        assert False
    except ValidationError as ve:
        assert str(ve) == 'Must be a valid time format.'
    try:
        time_format_1 = TimeFormat()
        str_1 = '12:34:56.7a'
        time_1 = time_format_1.validate(str_1)
        assert False
    except ValidationError as ve:
        assert str(ve) == 'Must be a valid time format.'

# Generated at 2022-06-26 10:28:12.002667
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_case_0()

# Generated at 2022-06-26 10:28:18.011558
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    expected = datetime.datetime(2020, 6, 30, 0, 0)
    actual = dtf.validate('2020-06-30')
    assert actual == expected



# Generated at 2022-06-26 10:28:22.565339
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    str_0 = ';'
    datetime_0 = datetime_format_0.validate(str_0)



# Generated at 2022-06-26 10:28:25.172569
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = date_time_format_0.serialize(datetime.datetime.now())


# Generated at 2022-06-26 10:28:25.834533
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert True


# Generated at 2022-06-26 10:28:39.610204
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '12:00:00'
    time_0 = time_format_0.validate(str_0)
    time_1 = time_format_0.validate(str_0)
    time_2 = time_format_0.validate(str_0)
    time_3 = time_format_0.validate(str_0)
    time_4 = time_format_0.validate(str_0)
    time_5 = time_format_0.validate(str_0)
    time_6 = time_format_0.validate(str_0)
    time_7 = time_format_0.validate(str_0)
    time_8 = time_format_0.validate(str_0)
    time_9

# Generated at 2022-06-26 10:28:45.894710
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = ';'
    date_0 = date_format_0.validate(str_0)


# Generated at 2022-06-26 10:28:54.858759
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    instance = DateTimeFormat()
    instance.validate(str_1)


# Generated at 2022-06-26 10:29:05.801103
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    str_0 = '2018-12-05'
    date_0 = date_format.validate(str_0)
    assert(date_0.isocalendar() == (2018, 49, 4))
    
    str_1 = '2017-01-01'
    date_1 = date_format.validate(str_1)

    str_2 = '2018-11-15'
    date_2 = date_format.validate(str_2)
    assert(date_2.isocalendar() == (2018, 46, 4))

    str_3 = '2018-12-05'
    date_3 = date_format.validate(str_3)
    assert(date_3.isocalendar() == (2018, 49, 4))


# Generated at 2022-06-26 10:29:10.633814
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = "2010-10-10"
    date_0 = date_format_0.validate(str_0)


# Generated at 2022-06-26 10:29:14.688667
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    str_0 = ';'
    date_time_0 = date_time_format_0.validate(str_0)
    # assert date_time_0.isoformat() == '2020-04-13T12:49:05.068114'


# Generated at 2022-06-26 10:29:27.908462
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_1 = DateTimeFormat()
    str_0 = datetime.datetime(1921, 11, 13, 9, 21, 45, 535000).isoformat()
    datetime_0 = datetime_format_1.validate(str_0)
    tzinfo_0 = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
    assert datetime_0.tzinfo == tzinfo_0
    str_1 = datetime.datetime(2022, 1, 13, 9, 21, 45, 535000).isoformat()
    datetime_1 = datetime_format_1.validate(str_1)
    assert datetime_1.tzinfo is None
    str_2 = ';'

# Generated at 2022-06-26 10:29:40.752346
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '20:00:00'
    time_0 = time_format_0.validate(str_0)
    assert isinstance(time_0, datetime.time)
    str_1 = '20:00'
    time_1 = time_format_0.validate(str_1)
    assert isinstance(time_1, datetime.time)
    str_2 = ' '
    try:
        time_2 = time_format_0.validate(str_2)
    except ValidationError as e:

        assert "Must be a valid time format" in str(e)
    str_3 = '20m00'

# Generated at 2022-06-26 10:29:44.332718
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    str_0 = ';'
    exception_0 = None
    try:
        date_time_format_0.validate(str_0)
    except ValidationError as e_0:
        exception_0 = e_0
    assert exception_0 is not None


# Generated at 2022-06-26 10:29:52.781851
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = '15:17:47.541151'
    time_0 = time_format_0.validate(str_0)
    assert str_0 == '15:17:47.541151'
    assert time_0 == '15:17:47.541151'


# Generated at 2022-06-26 10:29:57.240478
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    str_0 = '|'
    datetime_0 = datetime_format_0.validate(str_0)


# Generated at 2022-06-26 10:30:01.370510
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTime_format_0 = DateTimeFormat()
    str_0 = "; "
    dateTime_0 = dateTime_format_0.validate(str_0)
