

# Generated at 2022-06-26 10:20:29.141356
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u_u_i_d_format_0 = UUIDFormat()
    try:
        u_u_i_d_format_0.validate('9cd9efa0-1c7b-4b6f-bbcf-a282325f7baf')
    except ValidationError:
        pass


# Generated at 2022-06-26 10:20:41.893567
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert isinstance(time_format_0, TimeFormat)

    try:
        time_format_0.validate("00:00:00")
    except ValidationError:
        pass

    try:
        time_format_0.validate("00:00:00.12345")
    except ValidationError:
        pass

    try:
        time_format_0.validate("invalid time")
    except ValidationError:
        pass

    try:
        time_format_0.validate("invalid time")
    except ValidationError:
        pass

    try:
        time_format_0.validate("44:44:44.4444")
    except ValidationError:
        pass


# Generated at 2022-06-26 10:20:47.604698
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    print('Test case 0')
    time_format_0 = TimeFormat()
    obj_0 = None
    response_0 = time_format_0.serialize(obj_0)


# Generated at 2022-06-26 10:20:51.746126
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Setup mock objects
    datetime_datetime_obj_0 = datetime.datetime()

    date_time_format_0 = DateTimeFormat()

    # Execute method
    assert date_time_format_0.validate(datetime_datetime_obj_0) == datetime_datetime_obj_0

    # Execute method
    assert date_time_format_0.validate("2019-01-01T01:01:01+09:00") == datetime.datetime(
        2019, 1, 1, 1, 1, 1, tzinfo=datetime.timezone(datetime.timedelta(hours=9))
    )


# Generated at 2022-06-26 10:20:57.064982
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    d_t_f_0 = DateTimeFormat()
    assert d_t_f_0.serialize(datetime.datetime(1, 1, 1, 1, 1)) == "0001-01-01T01:01Z"



# Generated at 2022-06-26 10:21:01.512899
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat_1 = DateFormat()
    date_0 = dateformat_1.validate("1969-07-20")
    assert str(date_0).upper() == "1969-07-20"


# Generated at 2022-06-26 10:21:10.115429
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0: str = "12:30:00.000000"
    time_1 = time_format_0.validate(str_0)
    assert time_1.hour == 12
    assert time_1.minute == 30
    assert time_1.second == 0
    assert time_1.microsecond == 0


# Generated at 2022-06-26 10:21:15.798797
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('15:04')


# Generated at 2022-06-26 10:21:17.496099
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    obj_0 = datetime.time(0, 0, 0)
    ret_0 = time_format_0.serialize(obj_0)
    assert ret_0 == "00:00:00"


# Generated at 2022-06-26 10:21:21.764887
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()

    date_0 = datetime.date(year=2020, month=8, day=28)

    date_format_0.serialize(date_0)



# Generated at 2022-06-26 10:21:34.088193
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate(value="2020-01-10")


# Generated at 2022-06-26 10:21:38.240075
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate("10:30:00") == datetime.time(10, 30, 00, 000000)



# Generated at 2022-06-26 10:21:43.947503
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    value = "2020-05-20"
    is_instance_value = isinstance(value, str)
    assert is_instance_value
    date_format_0.validate(value)


# Generated at 2022-06-26 10:21:50.494970
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(2019, 7, 16, 3, 34, 19, tzinfo=datetime.timezone.utc)
    string_0 = date_time_format_0.serialize(datetime_0)
    print(string_0)

    datetime_1 = datetime.datetime.now(datetime.timezone.utc)
    string_1 = date_time_format_0.serialize(datetime_1)
    print(string_1)


# Generated at 2022-06-26 10:22:02.955415
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert date_format_0.is_native_type(None) == False
    date_format_1 = DateFormat()
    date_format_2 = DateFormat()
    date_format_2.validate(None)
    date_format_3 = DateFormat()
    assert type(date_format_3.validate('2019-01-01')) == datetime.datetime
    assert type(date_format_3.validate('2019-11-26')) == datetime.datetime
    try:
        date_format_3.validate('2019-12-31')
    except ValidationError:
        pass
    date_format_4 = DateFormat()
    assert type(date_format_4.validate('2019-01-01')) == datetime.datetime


# Generated at 2022-06-26 10:22:12.629842
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    d_a_t_e_t_i_m_e_format_0 = DateTimeFormat()
    assert d_a_t_e_t_i_m_e_format_0.validate("2073-01-01T14:35:17.000000Z") == datetime.datetime(2073, 1, 1, 14, 35, 17, 0, datetime.timezone.utc)
    assert d_a_t_e_t_i_m_e_format_0.validate("2074-01-01T14:35:17.000000Z") == datetime.datetime(2074, 1, 1, 14, 35, 17, 0, datetime.timezone.utc)


# Generated at 2022-06-26 10:22:13.721281
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat_0 = TimeFormat()


# Generated at 2022-06-26 10:22:25.092513
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    cases = [
        ("1974-03-02T14:15:00Z", "1974-03-02 14:15:00+00:00"),
        ("1974-03-02T14:15:00.123456Z", "1974-03-02 14:15:00.123456+00:00"),
        ("1974-03-02T14:15:00.123456-01:23", "1974-03-02 14:15:00.123456-01:23"),
        ("1974-03-02T14:15:00-01:23", "1974-03-02 14:15:00-01:23"),
        ("1974-03-02T14:15:00.123456-01", "1974-03-02 14:15:00.123456-01:00"),
    ]


# Generated at 2022-06-26 10:22:35.198133
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat.validate('2020-08-24T19:12:06.250957Z') == datetime.datetime(
        2020, 8, 24, 19, 12, 6, 250957, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat.validate('2020-08-24T19:12:06.250957+00:00') == datetime.datetime(
        2020, 8, 24, 19, 12, 6, 250957, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-26 10:22:37.675367
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()

    # Edge cases
    # /
    u_u_i_d_format_1 = UUIDFormat()

    # Offset 1
    # /
    u_u_i_d_format_1 = UUIDFormat()


# Generated at 2022-06-26 10:22:52.201360
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = date_time_format_0.validate("2019-02-20T15:33:49.286298Z")
    assert date_time_0.year == 2019
    assert date_time_0.month == 2
    assert date_time_0.day == 20
    assert date_time_0.hour == 15
    assert date_time_0.minute == 33
    assert date_time_0.second == 49
    assert date_time_0.microsecond == 286298
    assert str(date_time_0.tzinfo) == "UTC"


# Generated at 2022-06-26 10:23:00.421741
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("0:4:6.4")
    try:
        time_format_0.validate("37:4:6.4")
    except:
        pass
    try:
        time_format_0.validate("-5:-5:-5")
    except:
        pass
    time_format_0.validate("5:5:5.5Z")

# Generated at 2022-06-26 10:23:11.853960
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('01:30:01')
    time_format_0.validate('12:00:00')
    time_format_0.validate('00:30:00')
    time_format_0.validate('01:30:01.604')
    time_format_0.validate('13:04')
    time_format_0.validate('00:00')
    time_format_0.validate('00')
    time_format_0.validate('00:00:00')
    

# Generated at 2022-06-26 10:23:22.276474
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    with pytest.raises(ValidationError) as exception:
        date_format_0.validate(
            "2018-07-13"
        )
        if exception.error.code == 'format':
            pass
    with pytest.raises(ValidationError) as exception:
        date_format_0.validate(
            "2018-07-11"
        )
        if exception.error.code == 'invalid':
            pass


# Generated at 2022-06-26 10:23:26.870760
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    dt = datetime.datetime(2018, 9, 5, 19, 0, 9)
    timeformat_0 = TimeFormat()
    time_0 = timeformat_0.validate('19:00:09')

    assert time_0 == dt.time()


# Generated at 2022-06-26 10:23:32.809646
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Given
    time_format_0 = TimeFormat()

    # When
    time_format_0.validate("23:59:59")

    # Then
    pass



# Generated at 2022-06-26 10:23:40.436879
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Create a new instance of TimeFormat
    time_format_0 = TimeFormat()
    # Call the validate method of the instance with string "05:22:45"
    time_format_0.validate("05:22:45")
    # Expected result: datetime.time(5, 22, 45)


# Generated at 2022-06-26 10:23:44.418043
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    with raises(ValidationError):
        try:
            date_format_0.validate(value="2019-13-13")
        except Exception as e:
            print(e)
            raise


# Generated at 2022-06-26 10:23:57.687173
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate('2014-06-29T21:43:00+00:00') is not None
    assert date_time_format_0.validate('2014-06-29T21:43:00+01:00') is not None
    assert date_time_format_0.validate('2014-06-29T21:43:00-01:00') is not None
    assert date_time_format_0.validate('2014-06-29T21:43:00Z') is not None


# Generated at 2022-06-26 10:24:02.851255
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat_0 = DateFormat()
    assert dateformat_0.validate("2000-12-14") == datetime.date(2000, 12, 14)


# Generated at 2022-06-26 10:24:13.539227
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    value_0 = date_time_format_0.validate("2011-11-09T16:49:30.516Z")
    try:
        value_1 = date_time_format_0.validate("2011-11-09T16:49:30+04:00")
    except ValidationError as error_1:
        print(error_1._message)
        print(error_1._code)


# Generated at 2022-06-26 10:24:25.038932
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    test_value_0 = datetime.datetime(1998, 12, 1, 3, 9, 16, 436528)
    value_0 = date_time_format_0.serialize(test_value_0)
    assert value_0 == "1998-12-01T03:09:16.436528"
    test_value_1 = datetime.datetime.fromtimestamp(((datetime.datetime.now().timestamp()) - 685), pytz.timezone("Europe/Rome"))
    value_1 = date_time_format_0.serialize(test_value_1)
    assert value_1 == test_value_1.isoformat()
    test_value_2 = None
    value_2 = date_time_format_0.serialize

# Generated at 2022-06-26 10:24:29.213234
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate('2019-12-31')


# Generated at 2022-06-26 10:24:38.876402
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    # AssertionError
    try:
        date_time_format_0.validate("2024-12-30 22:40:00.929058+00:00")
    except AssertionError:
        pass
    # ValueError
    try:
        date_time_format_0.validate("2024-12-30 22:40:00.929058+00:00")
    except ValueError:
        pass


# Generated at 2022-06-26 10:24:49.693342
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    d_t_format_0 = DateTimeFormat()
    dt_0 = datetime.datetime(
        year=1, month=1, day=1, hour=1, minute=1, second=1, microsecond=1
    )
    assert d_t_format_0.serialize(dt_0) == "0001-01-01T01:01:01.000001"
    dt_1 = datetime.datetime(
        year=2, month=2, day=2, hour=2, minute=2, second=2, microsecond=2
    )
    assert d_t_format_0.serialize(dt_1) == "0002-02-02T02:02:02.000002"


# Generated at 2022-06-26 10:24:59.850696
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate("24:00:00.000000") != None
    assert time_format_0.validate("00:60:00.000000") != None
    assert time_format_0.validate("00:00:60.000000") != None
    assert time_format_0.validate("00:00:00.000000") != None
    assert time_format_0.validate("00:00:00.1000000") != None
    assert time_format_0.validate("00:00:00.000000") != None
    assert time_format_0.validate("00:00:00.000000") != None


# Generated at 2022-06-26 10:25:08.242663
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()  # type: DateTimeFormat
    date_time_0 = date_time_format_0.validate('2001-01-01T01:01:01.000000Z')
    str_0 = date_time_format_0.serialize(date_time_0)


# Generated at 2022-06-26 10:25:21.476032
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Set up a test for method DateTimeFormat.validate of class DateTimeFormat
    # Test with all valid inputs
    datetimeformat0 = DateTimeFormat()
    assert datetimeformat0.validate("2010-01-01T01:01:01") == datetime.datetime(2010, 1, 1, 1, 1, 1)

    # Test with all valid inputs
    datetimeformat1 = DateTimeFormat()
    assert datetimeformat1.validate("2010-01-01T01:01:01-05:00") == datetime.datetime(2010, 1, 1, 1, 1, 1, tzinfo=datetime.timezone(-datetime.timedelta(hours=5), -300))

    # Test with all valid inputs
    datetimeformat2 = DateTimeFormat()

# Generated at 2022-06-26 10:25:25.239071
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()

    with pytest.raises(ValidationError):
        datetime_format_0.validate("/test_cases/no_file_here")


# Generated at 2022-06-26 10:25:30.074819
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    print('Test TimeFormat validation')
    time = TimeFormat()
    error = None
    try: 
        time.validate('06:09:15')
    except Exception as e:
        error = e
    if error:
        print('Test TimeFormat validation failed')
    else:
        print('Test TimeFormat validation passed')


# Generated at 2022-06-26 10:25:36.231563
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("")



# Generated at 2022-06-26 10:25:41.934429
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    # for test coverage of condition if not match: raise self.validation_error("format")
    try:
        time_format_0.validate('20:00:00.123456')
    except ValidationError as e:
        assert e.code == 'format', 'expected ValidationError with code "format" to be raised.'
    else:
        assert False, 'expected ValidationError'


# Generated at 2022-06-26 10:25:53.769047
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    # str -> datetime.datetime
    assert date_time_format_0.validate("2020-04-01T12:33:59.418234Z") == datetime.datetime(2020, 4, 1, 12, 33, 59, 418234)
    assert date_time_format_0.validate("2020-04-01T12:33:59.418234") == datetime.datetime(2020, 4, 1, 12, 33, 59, 418234)
    assert date_time_format_0.validate("2020-04-01T12:33:59") == datetime.datetime(2020, 4, 1, 12, 33, 59)

# Generated at 2022-06-26 10:25:58.615070
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    d_t_f1 = DateTimeFormat()
    assert d_t_f1.validate('2020-10-15 10:00:21') == datetime.datetime(2020, 10, 15, 10, 0, 21)
# test_case_0()

# Generated at 2022-06-26 10:26:06.334111
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():

    date_format_0 = DateFormat()

    result = date_format_0.validate("2000-01-01")
    assert isinstance(result, datetime.date)
    assert result.isoformat() == "2000-01-01"

    result = date_format_0.validate("2000-01-32")
    assert isinstance(result, ValidationError)
    assert result.code == "invalid"
    assert result.text == "Must be a real date."


# Generated at 2022-06-26 10:26:18.280795
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = date_time_format_0.validate("2019-07-04T06:39:12")
    assert date_time_0 == datetime.datetime(2019, 7, 4, 6, 39, 12)
    assert type(date_time_0) == datetime.datetime
    date_time_0 = date_time_format_0.validate("2019-07-04T06:39:12Z")
    assert date_time_0 == datetime.datetime(2019, 7, 4, 6, 39, 12)
    assert date_time_0.utcoffset() == datetime.timedelta(0)

# Generated at 2022-06-26 10:26:32.874229
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = "00:05:33"
    datetime_0 = datetime.time(tzinfo=None, hour=0, minute=5, second=33)
    try:
        assert datetime_0 == time_format_0.validate(str_0)
    except AssertionError as e:
        raise AssertionError(e)
    str_1 = "01:05:33.99999"
    datetime_1 = datetime.time(tzinfo=None, hour=1, minute=5, second=33, microsecond=99999)
    try:
        assert datetime_1 == time_format_0.validate(str_1)
    except AssertionError as e:
        raise AssertionError(e)



# Generated at 2022-06-26 10:26:44.630345
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_0 = date_format_0.validate("2015-01-25")
    print(date_0)
    date_1 = date_format_0.validate("2015-01-32")
    print(date_1)
    date_2 = date_format_0.validate("2015-01-01")
    print(date_2)


# Generated at 2022-06-26 10:26:53.608210
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    DateFormat_validate_args = [
                ('2014-12-30',),
                ('0000-00-00',),
                ('2014-02-29',),
                ('2014-12-31',)
               ]
    DateFormat_validate_kwargs = [
                {},
                {},
                {},
                {}
               ]
    DateFormat_validate_answer = [
                 ((datetime.date(year=2014, month=12, day=30),), {}),
                 ((datetime.date(year=0, month=1, day=1),), {}),
                 ((datetime.date(year=2014, month=2, day=29),), {}),
                 ((datetime.date(year=2014, month=12, day=31),), {}),
                ]


# Generated at 2022-06-26 10:27:02.770775
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()

    assert time.validate("01:02:03") == datetime.time(1, 2, 3)
    assert time.validate("01:02:03.456") == datetime.time(1, 2, 3, 456000)
    assert time.validate("01:02:03.4") == datetime.time(1, 2, 3, 400000)
    assert time.validate("01:02:03.4456") == datetime.time(1, 2, 3, 4456)
    assert time.validate("01:02:03.4456999") == datetime.time(1, 2, 3, 445699)
    assert time.validate("01:02:03.0") == datetime.time(1, 2, 3)

# Generated at 2022-06-26 10:27:06.923055
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat_0 = TimeFormat()
    try:
        timeformat_0.validate("11:23:18.123948")
    except Exception as e:
        assert False
        return

    assert True


# Generated at 2022-06-26 10:27:21.274227
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_1 = DateTimeFormat()
    date_time_format_2 = DateTimeFormat()
    date_time_format_3 = DateTimeFormat()
    date_time_format_4 = DateTimeFormat()
    date_time_format_5 = DateTimeFormat()
    date_time_format_6 = DateTimeFormat()
    date_time_format_7 = DateTimeFormat()
    date_time_format_8 = DateTimeFormat()
    date_time_format_9 = DateTimeFormat()
    date_time_format_10 = DateTimeFormat()
    date_time_format_11 = DateTimeFormat()
    date_time_format_12 = DateTimeFormat()
    date_time_format_13 = DateTimeFormat()
    date_

# Generated at 2022-06-26 10:27:25.425777
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("123-12-34T56:78:90")


# Generated at 2022-06-26 10:27:29.406781
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    try:
        date_format_0 = DateFormat()
        date_format_0.validate("")
        raise Exception("Exception should be thrown")
    except ValidationError:
        pass


# Generated at 2022-06-26 10:27:38.170157
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    v_validate_value_0 = time_format_0.validate("16:14:28")
    assert isinstance(v_validate_value_0, datetime.time) == True
    assert v_validate_value_0.hour == 16
    assert v_validate_value_0.minute == 14
    assert v_validate_value_0.second == 28
    assert v_validate_value_0.microsecond == 0
    assert v_validate_value_0.tzinfo == None
    v_validate_value_1 = time_format_0.validate("16:14:28.123456")
    assert isinstance(v_validate_value_1, datetime.time) == True
    assert v_validate_value_1.hour

# Generated at 2022-06-26 10:27:42.053391
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_1 = date_format_0.validate("2019-01-01")
    assert date_1.year == 2019
    assert date_1.month == 1
    assert date_1.day == 1


# Generated at 2022-06-26 10:27:51.144760
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test with value '2018-12-31T12:59:59.999999-10:00'
    d_t_f_0 = DateTimeFormat()
    try:
        d_t_f_0.validate('2018-12-31T12:59:59.999999-10:00')
    except ValidationError:
        assert False
    # Test with value '2000-01-01T00:30:00+00:30'
    d_t_f_1 = DateTimeFormat()
    try:
        d_t_f_1.validate('2000-01-01T00:30:00+00:30')
    except ValidationError:
        assert False
    # Test with value '2001-12-31T23:58:59.999999-11:00'
    d_t_

# Generated at 2022-06-26 10:28:04.569056
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # 1. Define test cases
    # 1.1. Valid value
    test_data_valid_1 = (
        "2003-12-13",
        datetime.date(year=2003, month=12, day=13)
    )

    # 1.2. Invalid value
    test_data_invalid_1 = (
        "2003-12",
        "Must be a valid date format."
    )

    test_data_invalid_2 = (
        "2003/12/13",
        "Must be a valid date format."
    )

    test_data_invalid_3 = (
        "2003-10-31",
        "Must be a real date."
    )

    # 2. Run test cases

    # Test DateFormat.validate with valid data

# Generated at 2022-06-26 10:28:11.176852
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    '''Validate format of string to check if it is a valid date'''
    date1 = "2017-01-01"
    date2 = "2017-01-31"
    date3 = "2017-01-35"
    date4 = "2017-01"
    date5 = "2017-01-0133"
    date6 = "2017-01-01-01"
    date7 = "2017-01-01T00:00:00.000000"
    
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(2017,1,1))
    assert date_format.validate(date1) == datetime.date(2017,1,1)
    assert date_format.validate(date2) == datetime.date(2017,1,31)

# Generated at 2022-06-26 10:28:16.584616
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate(value = "2019-10-11")


# Generated at 2022-06-26 10:28:22.355109
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate('2019-06-20T17:59:15.580843')


# Generated at 2022-06-26 10:28:26.873855
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    try:
        date_time_format_0.validate("2004-09-21T15:31:42.123456")
    except ValidationError as e:
        assert e.code == "format"
        assert str(e) == "Must be a valid datetime format."

# Generated at 2022-06-26 10:28:30.528512
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("-23:37::37.732")
    except ValidationError as e:
        pass
    else:
        raise AssertionError("AssertionError: ValidationError not raised")




# Generated at 2022-06-26 10:28:48.958505
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtformat = DateTimeFormat()
    assert dtformat.validate("2018-03-03T03:03:03.123456Z") == datetime.datetime(2018, 3, 3, 3, 3, 3, 123456)
    assert dtformat.validate("2018-03-03T03:03:03Z") == datetime.datetime(2018, 3, 3, 3, 3, 3, 0)
    assert dtformat.validate("2018-03-03T03:03:03.6Z") == datetime.datetime(2018, 3, 3, 3, 3, 3, 600000)
    assert dtformat.validate("2018-03-03T03:03:03+00:00") == datetime.datetime(2018, 3, 3, 3, 3, 3)
    assert dtformat

# Generated at 2022-06-26 10:29:02.811077
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    x = DateFormat()

    with pytest.raises(ValidationError) as exc_info:
        x.validate(None)

    exc_info.match(r"^Must be a valid date format.$")

    with pytest.raises(ValidationError) as exc_info:
        x.validate(object())

    exc_info.match(r"^Must be a valid date format.$")

    with pytest.raises(ValidationError) as exc_info:
        x.validate("Foo")

    exc_info.match(r"^Must be a valid date format.$")

    with pytest.raises(ValidationError) as exc_info:
        x.validate("2017-01-00")

    exc_info.match(r"^Must be a valid date format.$")


# Generated at 2022-06-26 10:29:05.256601
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("2020-05-08T19:24:43.282388Z")


# Generated at 2022-06-26 10:29:16.241260
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = "not a date"
    try:
        date_format_0.validate(str_0)
        assert False       # shouldn't be reached
    except ValidationError:
        pass

    str_0 = "20180430"
    try:
        date_format_0.validate(str_0)
        assert False       # shouldn't be reached
    except ValidationError:
        pass

    str_0 = "2018/30/45"
    try:
        date_format_0.validate(str_0)
        assert False       # shouldn't be reached
    except ValidationError:
        pass

    str_0 = "2018-30"

# Generated at 2022-06-26 10:29:19.740763
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2022-11-13")


# Generated at 2022-06-26 10:29:25.381723
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Method validate of class DateFormat should raise an exception when the input is an invalid date
    date_format_0 = DateFormat()
    with pytest.raises(ValidationError):
        date_format_0.validate("2001-02-30")


# Generated at 2022-06-26 10:29:27.466878
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()


# Generated at 2022-06-26 10:29:40.268016
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    d_t_f = DateTimeFormat()
    print(d_t_f.validate("2019-05-09T08:46:16.986070"))
    print(d_t_f.validate("2019-05-09T08:46:16.986Z"))
    print(d_t_f.validate("2019-05-09T08:46:16.986+05:00"))
    print(d_t_f.validate("2019-05-09T08:46:16.986+0500"))


# Generated at 2022-06-26 10:29:46.376915
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    result = date_format_0.validate("2019-04-12")
    assert result == datetime.date(2019, 4, 12)
    result = date_format_0.validate("2020-02-03")
    assert result == datetime.date(2020, 2, 3)
    result = date_format_0.validate("2020-06-07")
    assert result == datetime.date(2020, 6, 7)
    result = date_format_0.validate("2020-12-31")
    assert result == datetime.date(2020, 12, 31)
    result = date_format_0.validate("2020-09-30")
    assert result == datetime.date(2020, 9, 30)

# Generated at 2022-06-26 10:29:55.295346
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    date.validate('2019-01-01')
    try:
        date.validate('2019--01-01')
        raise AssertionError
    except ValidationError as e:
        assert e.code == 'format'
    try:
        date.validate('2019-01-32')
        raise AssertionError
    except ValidationError as e:
        assert e.code == 'invalid'



# Generated at 2022-06-26 10:30:04.299870
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Input: u = "2020-01-01T00:00:00+00:00"
    # Output: datetime.datetime(2020, 1, 1, 0, 0, tzinfo=datetime.timezone.utc)
    datetime_format_0 = DateTimeFormat()
    u = "2020-01-01T00:00:00+00:00"
    assert datetime_format_0.validate(u) == datetime.datetime(2020, 1, 1, 0, 0, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-26 10:30:08.341301
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test arguments
    value = "2010-05-12"

    # Call method
    result = DateFormat().validate(value)

    # Test result
    assert isinstance(result, datetime.date)
    assert result.year == 2010
    assert result.month == 5
    assert result.day == 12


# Generated at 2022-06-26 10:30:10.344539
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    time_format_0.validate('12:03:01')


# Generated at 2022-06-26 10:30:19.944300
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    assert date_format_0.is_native_type(datetime.date(2019, 8, 27))
    assert not date_format_0.is_native_type(datetime.time())
    assert not date_format_0.is_native_type(datetime.datetime(2019, 8, 27))
    assert not date_format_0.is_native_type(uuid.UUID('123e4567-e89b-12d3-a456-426655440000'))
    assert date_format_0.serialize(datetime.date(2019, 8, 27)) == "2019-08-27"

    assert date_format_0.validate("2019-08-27") == datetime.date(2019, 8, 27)