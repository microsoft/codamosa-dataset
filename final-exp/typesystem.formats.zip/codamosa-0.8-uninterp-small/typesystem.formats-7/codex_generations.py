

# Generated at 2022-06-26 10:20:29.525826
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("yy:zx:zz:yy:yy")
        assert False, "Expected error."
    except ValidationError as e:
        assert e.code == "format", "Unexpected error code."



# Generated at 2022-06-26 10:20:34.656705
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format_0 = UUIDFormat()
    uuid_format_0.validate('2a8f0c59-f6ce-4e9f-b96e-88a22f49e3b1')



# Generated at 2022-06-26 10:20:40.538982
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    try:
        uuid_format = UUIDFormat()
        uuid.UUID('d85dfd50-29fd-4e9b-ad3d-94e295c3ed3a')
    except ValidationError:
        print("Error: UUID not valid.")

# Generated at 2022-06-26 10:20:53.492888
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.is_native_type(datetime.time(hour=3, minute=20, second=28, microsecond=453003))
    time_format_0.validate("15:20:28.4")
    time_format_0.validate("15:20:28.453003")
    time_format_0.validate("15:20:28.4530")
    time_format_0.validate("15:20:28.453")
    time_format_0.validate("15:20:28.45")
    time_format_0.validate("15:20:28.4")
    time_format_0.validate("15:20:28")
    time_format_0.validate("15:20")


# Generated at 2022-06-26 10:21:00.527447
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 9, 3, 44, 36, 947475, tzinfo=datetime.timezone(datetime.timedelta(0, 3600), 'CEST'))) == '2019-01-09T03:44:36.947475+01:00'


# Generated at 2022-06-26 10:21:05.727662
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
	date = DateTimeFormat()
	datetime_format = date.validate("2019-08-20T15:23:12.321111Z")
	assert datetime_format == datetime.datetime(2019, 8, 20, 15, 23, 12, 321111, tzinfo=datetime.timezone.utc)



# Generated at 2022-06-26 10:21:08.507383
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_format_0 = DateTimeFormat()
    datetime_format_0.serialize(None)


# Generated at 2022-06-26 10:21:12.384973
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_formatter_1 = DateTimeFormat()
    datetime_formatter_1.serialize(datetime.datetime(2020, 10, 5, 7, 51, 0))

# Generated at 2022-06-26 10:21:25.457151
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    data = [
        '03-01-2019',
        '03-01-2019T08:00:00Z',
        '03-01-2019T08:00:00.000000',
        '03-01-2019T08:00:00',
        '03-01-2019T08:00:00.000000Z',
        '03-01-2019T08:00:00+05:00',
        '03-01-2019T08:00:00.000000-05:00',
    ]

    for case in data:
        datetime_format = DateTimeFormat()
        res = datetime_format.validate(case)
        print(res)

if __name__ == '__main__':
    test_DateTimeFormat_validate()

# Generated at 2022-06-26 10:21:31.108955
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    # Case 0
    assert df.serialize(datetime.date(2020, 2, 1)) == "2020-02-01"
    # Case 1
    assert df.serialize(None) == None



# Generated at 2022-06-26 10:21:41.259015
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()

    assert date_format.validate("2000-01-01") == datetime.date(2000, 1, 1)



# Generated at 2022-06-26 10:21:47.567355
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_0 = date_format_0.validate("2019-10-10")
    assert date_0 == datetime.date(2019, 10, 10)

# Unit tests regarding the errors thrown by method validate of class DateFormat

# Generated at 2022-06-26 10:21:50.051032
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert True



# Generated at 2022-06-26 10:21:54.620986
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    with pytest.raises(ValidationError):
        time_format_0.validate("16:00:10.110101")


# Generated at 2022-06-26 10:22:05.447691
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    #setup
    datetime_format = DateTimeFormat()
    #execution
    assert datetime_format.validate("2020-01-01T00:00:00.000000Z") == datetime.datetime(2020,1,1,0,0)
    assert datetime_format.validate("2020-01-01T00:00:00.000000+00:00") == datetime.datetime(2020,1,1,0,0)
    assert datetime_format.validate("2020-01-01T00:00:00.000000-00:00") == datetime.datetime(2020,1,1,0,0)

# Generated at 2022-06-26 10:22:13.501060
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("20:00:00.000000")
    time_format_0.validate("20:00")
    time_format_0.validate("20:00:00.00000000000000")
    time_format_0.validate("20:00:00.000000000000000000")
    time_format_0.validate("20:00:00.00000000000000000000000000")
    time_format_0.validate("20:0")
    time_format_0.validate("2:00:00.000000")
    time_format_0.validate("2:00")
    time_format_0.validate("2:00:00.00000000000000")
    time_format_0.validate("2:00:00.000000000000000000")
    time_format

# Generated at 2022-06-26 10:22:24.995024
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_1 = TimeFormat()

    assert time_format_1.validate("23:59:59.999999") == datetime.time(23, 59, 59, 999999)
    assert time_format_1.validate("23:59:59.99999") == datetime.time(23, 59, 59, 99999)
    assert time_format_1.validate("23:59:59.9999") == datetime.time(23, 59, 59, 9999)
    assert time_format_1.validate("23:59:59.999") == datetime.time(23, 59, 59, 999)
    assert time_format_1.validate("23:59:59.99") == datetime.time(23, 59, 59, 99)

# Generated at 2022-06-26 10:22:35.132866
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate('05:30:20.000001') == datetime.time(5, 30, 20, 1, tzinfo=None)
    assert time_format_0.validate('05:30:20.0000') == datetime.time(5, 30, 20, 0, tzinfo=None)
    assert time_format_0.validate('05:30:20') == datetime.time(5, 30, 20, tzinfo=None)
    assert time_format_0.validate('05:30') == datetime.time(5, 30, tzinfo=None)
    # TypeError test
    with pytest.raises(TypeError):
        time_format_0.validate(1)

# Generated at 2022-06-26 10:22:40.684933
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_1 = TimeFormat()

    test_obj1 =  datetime.time(10, 2)
    assert time_format_1.serialize(obj = test_obj1) == test_obj1.isoformat()

    test_obj2 = None
    assert time_format_1.serialize(obj = test_obj2) == None

    test_obj3 = datetime.time(22, 2, 4)
    assert time_format_1.serialize(obj = test_obj3) == test_obj3.isoformat()

    test_obj4 = datetime.time(23, 2, 1, 3)
    assert time_format_1.serialize(obj = test_obj4) == test_obj4.isoformat()



# Generated at 2022-06-26 10:22:42.744167
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # TODO: Implement unit test
    pass


# Generated at 2022-06-26 10:22:47.718703
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    time_format_0 = TimeFormat()
    optional_0 = time_format_0.validate(time_format_0)


# Generated at 2022-06-26 10:22:52.937379
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    optional_0 = time_format_0.serialize(None)
    expected_0 = None
    assert optional_0 == expected_0
    try:
        optional_0 = time_format_0.serialize(datetime.datetime(0, 0, 0, 0, 0, 0))
    except ValidationError:
        pass
    except Exception:
        pass


# Generated at 2022-06-26 10:22:55.949728
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate(date_format_0)


# Generated at 2022-06-26 10:23:03.891077
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_1 = date_format_0.validate('2001-01-01')
    date_format_2 = date_format_0.validate('2019-10-29')
    date_format_3 = date_format_0.validate('2001-01-01')
    date_format_4 = date_format_0.validate('2019-10-29')
    date_format_5 = date_format_0.validate('2001-01-01')
    date_format_6 = date_format_0.validate('2019-10-29')
    date_format_7 = date_format_0.validate('2001-01-01')


# Generated at 2022-06-26 10:23:06.499818
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    startTime = time.perf_counter()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    endTime = time.perf_counter()
    print("Time elapsed:", endTime - startTime)


# Generated at 2022-06-26 10:23:12.684870
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test Data
    value_0 = '2018-01-01'
    datetime_0 = datetime.datetime(2018, 1, 1)
    date_0 = datetime.date(2018, 1, 1)

    # Execution
    date_format_0 = DateFormat()
    assert date_format_0.validate(value_0) == date_0


# Generated at 2022-06-26 10:23:25.131081
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat() #type: TimeFormat
    try:
        time_format_1 = time_format_0.validate('NULL')
        assert False
    except ValidationError:
        assert True

    try:
        time_format_2 = time_format_0.validate('NULL NULL')
        assert False
    except ValidationError:
        assert True

    try:
        time_format_3 = time_format_0.validate('2020-03-03 00:00:00')
        assert False
    except ValidationError:
        assert True

    try:
        time_format_4 = time_format_0.validate('1:1:1:1:1:1')
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-26 10:23:29.902789
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate(date_format_0)


# Generated at 2022-06-26 10:23:42.888436
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate('09:48:00')
    assert type(time_format_0.validate('09:48:00')) is datetime.time
    assert time_format_0.validate('09:48:00.123123')
    assert type(time_format_0.validate('09:48:00.123123')) is datetime.time
    assert time_format_0.validate('09:48:00.123')
    assert type(time_format_0.validate('09:48:00.123')) is datetime.time
    assert time_format_0.validate('09:48:00.12')

# Generated at 2022-06-26 10:23:52.817056
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:04") == datetime.time(12, 4)
    assert time_format.validate("01:10:01") == datetime.time(1, 10, 1)
    assert time_format.validate("01:10:01.000000") == datetime.time(1, 10, 1)
    assert time_format.validate("01:10:01.123456") == datetime.time(1, 10, 1, 123456)

    try:
        time_format.validate("20:60")
    except ValidationError as exc:
        assert exc.code == "invalid"
    else:
        assert False, "expected ValidationError"


# Generated at 2022-06-26 10:24:04.491665
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    """Validate format of Date string."""
    date_format = DateFormat()
    # valid date
    assert date_format.validate("2018-02-12") == datetime.date(2018, 2, 12)
    
    # invalid date
    with pytest.raises(ValidationError):
        date_format.validate("2018-12-32")
    
    # invalid format
    with pytest.raises(ValidationError):
        date_format.validate("2018/12/32")
"""
Unit test for method validate of class TimeFormat
"""

# Generated at 2022-06-26 10:24:10.140258
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    df = DateTimeFormat()
    # raises ValidationError: '2014-05-28T23:15:00' is not a valid time.
    try:
        df.validate('2014-05-28T23:15:00')
    except ValidationError as e:
        print (e.message)
    else:
        assert (False)


# Generated at 2022-06-26 10:24:17.854126
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2018, 10, 15, 12, 30, 45, 450000)
    serialized_obj = DateTimeFormat().serialize(obj)
    assert serialized_obj == "2018-10-15T12:30:45.450000"


# Generated at 2022-06-26 10:24:19.653352
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():

    object_0 = DateFormat()
    expected = datetime.date(2019, 3, 30)
    assert object_0.validate("2019-03-30") == expected



# Generated at 2022-06-26 10:24:25.278642
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    optional_0 = time_format_0.serialize(time_format_0)


# Generated at 2022-06-26 10:24:30.051571
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate(date_format_0)
    except:
        pass


# Generated at 2022-06-26 10:24:37.289507
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Given
    date = datetime.datetime.now()
    dateformat = DateTimeFormat()
    # When
    result = dateformat.serialize(date)
    # Then
    assert result == date.isoformat()

# Generated at 2022-06-26 10:24:41.756826
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    input_value = "2005-01-01"
    output_value = date_format_0.validate(input_value)
    assert isinstance(output_value, datetime.date)
    assert output_value.year == 2005
    assert output_value.month == 1
    assert output_value.day == 1


# Generated at 2022-06-26 10:24:47.834223
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    @params(
        param(
            "2000-01-01",
            datetime.date(2000, 1, 1),
        ),
    )
    def test(value: str, expected_result: datetime.date):
        date_format_0 = DateFormat()
        result = date_format_0.validate(value)
        assert result == expected_result


# Generated at 2022-06-26 10:24:50.576482
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_0 = date_format_0.validate(date_format_0)


# Generated at 2022-06-26 10:24:57.478161
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    try:
        raise NotImplementedError()
    except:
        print("Exception: %s" % sys.exc_info()[1])


# Generated at 2022-06-26 10:25:02.566424
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    my_timeformat = TimeFormat()
    my_time_0 = my_timeformat.validate("13:30.")
    optional_0 = my_timeformat.serialize(my_time_0)


# Generated at 2022-06-26 10:25:14.107405
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    optional_0 = time_format_0.serialize(time_format_0.validate("12:34:56.789012"))
    assert optional_0 == "12:34:56.789012"
    optional_1 = time_format_0.serialize(time_format_0.validate("12:34:56.78901"))
    assert optional_1 == "12:34:56.789010"
    optional_2 = time_format_0.serialize(time_format_0.validate("12:34:56"))
    assert optional_2 == "12:34:56"
    optional_3 = time_format_0.serialize(time_format_0.validate("12:34"))
    assert optional_3 == "12:34:00"
    optional

# Generated at 2022-06-26 10:25:18.455039
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    # Initialisation of variable being_tested_0 of type TimeFormat
    being_tested_0 = TimeFormat()

    # Selection of an arbitrary method for variable optional_0 of type TimeFormat
    optional_0 = being_tested_0.serialize(being_tested_0)

# Generated at 2022-06-26 10:25:21.673326
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    optional_0 = time_format_0.serialize(time_format_0)
    pass


# Generated at 2022-06-26 10:25:26.745583
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    sample_0 = "datetime.datetime(2006, 4, 1, 0, 0)"
    with pytest.raises(NotImplementedError):
        date_format_0.validate(sample_0)



# Generated at 2022-06-26 10:25:29.602897
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    str_1 = '2020-01-01'
    date_1 = date_format_1.validate(str_1)


# Generated at 2022-06-26 10:25:36.272517
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    # Positive
    datetime_format_0.validate("2019-01-01T00:00:00Z")

############################################################################
##
##  Unit testing for class DateFormat
##
############################################################################



# Generated at 2022-06-26 10:25:39.118330
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    if False:  # pragma: no cover
        time_format_0.serialize()


# Generated at 2022-06-26 10:25:41.903483
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    time_format_1 = time_format_0.serialize(time_format_0[0])


# Generated at 2022-06-26 10:25:45.677671
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_validate_0 = DateFormat()
    date_format_validate_validate_0 = date_format_validate_0.validate("")
    assert date_format_validate_validate_0



# Generated at 2022-06-26 10:25:48.038174
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    datetime_format_0.validate(str())


# Generated at 2022-06-26 10:25:54.682159
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # GIVEN
    given_validation_error = ValidationError(t.test)
    time_format_0 = TimeFormat()
    given_value = 'h:mm:ss'
    # WHEN
    time_format_0.validate(given_value)
    # THEN
    # exception was raised
    assert time_format_0.validate(given_value)


# Generated at 2022-06-26 10:25:59.354391
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Input parameters
    value_0 = '1:2:3.123456'

    # Act
    time_format_0 = TimeFormat()
    result_1 = time_format_0.validate(value_0)

    # Assert
    assert True


# Generated at 2022-06-26 10:26:03.487345
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    try:
        assert date_time_format_0.validate(date_time_format_0, datetime.datetime)
    except AssertionError:
        raise Exception("Expected an exception.")

# Generated at 2022-06-26 10:26:07.007992
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("1992-09-23")  # noqa: F841


# Generated at 2022-06-26 10:26:17.065970
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    # Testing exception raised for invalid type
    try:
        date_format_0.validate(4)
    except ValidationError:
        pass

    # Testing exception raised for invalid format
    try:
        date_format_0.validate("2020-05-12 11:01:37")
    except ValidationError:
        pass

    # Testing exception raised for invalid date
    try:
        date_format_0.validate("2020-13-12")
    except ValidationError:
        pass

    # Testing correct date
    date_format_0.validate("2020-05-12")



# Generated at 2022-06-26 10:26:20.070638
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    value_0 = date_time_format_0.validate("2020-03-08T15:37:08.593724534+05:53")


# Generated at 2022-06-26 10:26:26.682950
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Must be a real time.
    time_format_0 = TimeFormat()
    assert_equal(time_format_0.validate(time_format_0), time_format_0)


# Generated at 2022-06-26 10:26:29.187927
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2001-02-03")


# Generated at 2022-06-26 10:26:34.217868
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    expected_0 = '2019-05-25'
    actual_0 = date_format_0.validate(expected_0)
    assert actual_0 == expected_0



# Generated at 2022-06-26 10:26:39.362435
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    instance = TimeFormat()
    # Test with a valid format
    value = '08:00:00'
    result = instance.validate(value)
    if result == None:
        raise Exception
    # Test with an invalid format
    value = '08:00:00:00'
    try:
        instance.validate(value)
    except ValidationError:
        pass
    else:
        raise Exception


# Generated at 2022-06-26 10:26:43.290148
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtformat = DateTimeFormat()
    validated_0 = dtformat.validate(dtformat)
    assert type(validated_0) == datetime.datetime



# Generated at 2022-06-26 10:26:52.919109
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    value_0 = time_format_0.validate("00:00:00")
    assert isinstance(value_0, datetime.time)
    value_1 = time_format_0.validate("23:59:59.123456")
    assert isinstance(value_1, datetime.time)
    exception_0 = ValueError()
    try:
        time_format_0.validate("")
    except ValueError:
        exception_0 = ValidationError("", "format", [], "Must be a valid time format.")
    assert isinstance(exception_0, ValidationError)
    exception_1 = ValueError()
    try:
        time_format_0.validate("24:00:00")
    except ValueError:
        exception_1 = Validation

# Generated at 2022-06-26 10:26:57.186530
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    time_format_1 = TimeFormat()
    value_1 = '10'
    with pytest.raises(Exception):
        time_format_1.validate(value_1)


# Generated at 2022-06-26 10:27:01.884039
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    time_format_0 = TimeFormat()
    optional_0 = time_format_0.serialize(time_format_0)


# Generated at 2022-06-26 10:27:05.063233
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_0 = date_format_0.validate(date_format_0)


# Generated at 2022-06-26 10:27:21.237919
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Tests are generated from the following rules:
    # Tests are randomly generated (up to a maximum number) with the following
    # constraints:
    # - Alphanumeric input includes all 10 digits and the 26 letters a-z.
    # - Numeric input only includes the digits 0-9.
    # - Length of inputs are between 1 and 10 characters.
    # - Strings used for inputs are randomly chosen from a set of thousands of
    #   real life inputs.
    # - Field names are randomly chosen from a set of thousands of real life
    #   field names.
    # - Field values are randomly chosen from a set of thousands of real life
    #   field values.
    utc = datetime.timezone(datetime.timedelta(0))
    date_times: typing.List[typing.Tuple[datetime.datetime, str]]

# Generated at 2022-06-26 10:27:26.072227
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Argument type
    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    optional_0 = time_format_0.validate(time_format_1)

    # Argument type
    time_format_2 = TimeFormat()
    time_format_3 = TimeFormat()
    optional_1 = time_format_2.validate(time_format_3)



# Generated at 2022-06-26 10:27:36.592942
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test with valid pattern
    test_case_0_input = "2019-07-05T17:24:51.266000+08:00"
    test_case_0_expected_output = datetime.datetime(
        2019, 7, 5, 17, 24, 51, 266000, datetime.timezone(datetime.timedelta(hours=8))
    )
    test_case_0_actual_output = DateTimeFormat().validate(test_case_0_input)
    assert test_case_0_actual_output == test_case_0_expected_output

    # Test with valid pattern
    test_case_1_input = "2019-07-07T17:24:51Z"

# Generated at 2022-06-26 10:27:47.524889
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_0 = time_format_0.validate(time_format_0)
    assert time_0 == time_format_0


# Generated at 2022-06-26 10:27:54.650785
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test w/ missing value
    assert DateFormat().validate("") == ""

    # Test w/ valid value
    assert DateFormat().validate("2019-10-31") == "2019-10-31 00:00:00"

    # Test w/ invalid value
    with pytest.raises(ValidationError):
        DateFormat().validate("2019-10-32")


# Generated at 2022-06-26 10:27:57.443459
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate(time_format_0)
    except ValidationError:
        pass


# Generated at 2022-06-26 10:28:04.110685
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_1 = TimeFormat()

    # Call method(s) to be tested
    with pytest.raises(ValueError) as excinfo:
        time_format_1.validate(None)

    assert "81d" in str(excinfo.value)



# Generated at 2022-06-26 10:28:07.432209
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("00:00:00.000000")
    time_format_0.validate("00:00:00.000000")
    time_format_0.validate("00:00:00.000000")


# Generated at 2022-06-26 10:28:17.599633
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    result_0 = time_format_0.validate(time_format_0)

    time_format_1 = TimeFormat()
    optional_0 = time_format_1.validate(time_format_1)


# Generated at 2022-06-26 10:28:23.535330
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    expected_result_0 = datetime.datetime.now()
    datetime_format_0 = DateTimeFormat()
    actual_result_0 = datetime_format_0.validate(datetime_format_0)
    assert actual_result_0 == expected_result_0


# Generated at 2022-06-26 10:28:31.640153
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    """
    Test validate method
    :return:
    """
    datetime_format_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(year=2019, month=11, day=11, tzinfo=timezone.utc)
    datetime_1 = datetime.datetime(year=2019, month=11, day=11, hour=0, minute=11)
    datetime_2 = datetime.datetime(year=2019, month=11, day=11, hour=0, minute=11, second=11)
    datetime_3 = datetime.datetime(year=2019, month=11, day=11, hour=0, minute=11, second=11, microsecond=11)



# Generated at 2022-06-26 10:28:32.761355
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    DateFormat()


# Generated at 2022-06-26 10:28:50.514516
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():

    with pytest.raises(AssertionError) as ex_0:
        with pytest.raises(ValidationError) as ex_1:
            time_format_0 = DateFormat()
            optional_0 = time_format_0.validate(time_format_0)
        assert ex_1.value.code == "invalid"

    with pytest.raises(AssertionError) as ex_0:
        with pytest.raises(ValidationError) as ex_1:
            time_format_0 = DateFormat()
            optional_0 = time_format_0.validate(time_format_0)
        assert ex_1.value.code == "format"

    assert ex_0.value.args[0] == "Must be a real date."


# Generated at 2022-06-26 10:29:01.509363
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("09:27:00.123456") == datetime.time(
        9, 27, 0, 123456
    )



# Generated at 2022-06-26 10:29:05.694591
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    # Test with valid arguments
    date_time_format_0.validate("2020-10-23T10:32:41Z")

    # Test with invalid arguments
    try:
        date_time_format_0.validate("2020-10-23T10:32:41Z")
    except Exception:
        pass
    else:
        assert False



# Generated at 2022-06-26 10:29:10.634619
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Verify that ValueError is raised when value is None
    with pytest.raises(ValueError):
        datetime_format = DateTimeFormat()
        datetime_format.validate(None)

# Generated at 2022-06-26 10:29:13.469091
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    time_format_0 = TimeFormat()
    obj_0 = time_format_0.validate("12:34:26")
    assert obj_0 == datetime.time(12, 34, 26)


# Generated at 2022-06-26 10:29:16.555455
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    datetime_format_0.validate("2152-04-13 13:32:11.680688")



# Generated at 2022-06-26 10:29:21.225091
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate(date_format_0)


# Generated at 2022-06-26 10:29:29.266123
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    str_0 = '2000-02-29'
    try:
        date_format_0.validate(str_0)
    except ValidationError as error_1:
        pass



# Generated at 2022-06-26 10:29:36.413842
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("123:123:123.123456Z")
    except ValidationError as e:
        assert str(e) == "Must be a valid time format."


# Generated at 2022-06-26 10:29:39.607344
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    input_0 = None
    result_0 = date_time_format.validate(input_0)
    assert result_0 == datetime.datetime(1970, 1, 1, 0, 0, 0)

# Generated at 2022-06-26 10:29:42.035999
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    datetime_time_0 = datetime.time(second=35, hour=5, minute=54)
    # time_format_0.validate(datetime_time_0)


# Generated at 2022-06-26 10:30:00.036012
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    test_object_0 = DateFormat()
    try:
        test_object_0.validate(value=int())
    except:
        pass
    else:
        raise TypeError()



# Generated at 2022-06-26 10:30:03.564483
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    try:
        date_format_0 = DateFormat()
        date_format_0.validate("")
    except ValidationError:
        pass
    except:
        print("unexpected exception")

# Generated at 2022-06-26 10:30:07.756971
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    datetime_0 = time_format_0.validate(datetime.datetime(datetime.datetime.now().year, 1, 1, 11, 11))
    optional_0 = time_format_0.serialize(datetime_0)

# Generated at 2022-06-26 10:30:16.235301
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    #define dateformat class instance
    dateformat = DateFormat()

    #validate inputs, ensuring that the correct error message is returned
    try:
        dateformat.validate("2020-02-22")
    except ValidationError as e:
        assert e.code == "invalid"
        assert e.text == "Must be a real date."
    else:
        raise AssertionError("Should not be reached")

