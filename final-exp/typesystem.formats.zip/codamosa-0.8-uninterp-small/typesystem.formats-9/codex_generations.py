

# Generated at 2022-06-26 10:20:34.697246
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    try:
        date_format_1.validate("2020-09-08")
    except Exception as e:
        assert e.__class__.__name__ == "Invalid"


# Generated at 2022-06-26 10:20:37.742974
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime.utcnow()) == datetime.datetime.utcnow().isoformat()
    assert DateTimeFormat().serialize(datetime.datetime.now()) == datetime.datetime.now().isoformat().replace(":", "")



# Generated at 2022-06-26 10:20:40.940209
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    print("test_DateFormat_validate")
    df = DateFormat()
    result = df.validate("2020-12-01")
    print(result)


# Generated at 2022-06-26 10:20:47.879205
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    
    res = time_format_0.validate('13:30:29')
    assert isinstance(res, datetime.time)
    assert res == datetime.time(13, 30, 29)


# Generated at 2022-06-26 10:20:53.032701
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dateTime_format_0 = DateTimeFormat()
    dateTime_format_0.serialize(datetime.datetime(2018,1,1,0,0,0,0,datetime.timezone.utc))
    dateTime_format_0.serialize(datetime.datetime(2018,1,1,0,0,0,0,datetime.timezone.utc))


# Generated at 2022-06-26 10:20:59.329476
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_format_0 = DateTimeFormat()
    test_data_0 = datetime.datetime(2020, 8, 30, 9, 30, 30)
    expect_result_0 = '2020-08-30T09:30:30'
    result_0 = date_format_0.serialize(test_data_0)
    assert result_0 == expect_result_0

# Generated at 2022-06-26 10:21:03.601384
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_format_0 = DateTimeFormat()
    if (datetime_format_0.serialize(datetime.datetime(2018, 1, 1, 11, 12, 13, 141516, datetime.timezone(datetime.timedelta(0)))) == '2018-01-01T11:12:13.141516+00:00'):
        return False
    else:
        return True

# Generated at 2022-06-26 10:21:09.369265
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    value_0 = datetime.date()
    value_1 = date_format_0.serialize(value_0)
    assert value_1 == value_0.isoformat()


# Generated at 2022-06-26 10:21:20.137307
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_1 = DateFormat()
    date_format_2 = DateFormat()
    date_format_3 = DateFormat()
    date_format_4 = DateFormat()
    date_format_5 = DateFormat()
    date_format_6 = DateFormat()
    date_format_7 = DateFormat()
    date_format_8 = DateFormat()
    date_format_9 = DateFormat()
    date_format_10 = DateFormat()
    date_format_11 = DateFormat()
    date_format_12 = DateFormat()
    date_format_13 = DateFormat()
    date_format_14 = DateFormat()
    date_format_15 = DateFormat()
    date_format_16 = DateFormat()
    date_format_17 = DateFormat()
   

# Generated at 2022-06-26 10:21:31.357575
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    # Positive tests

    # 1. valid date format
    try:
        assert str(date_format_0.validate("2017-12-13")) == "2017-12-13"
    except ValidationError:
        # Shouldn't get here
        assert False

    # 2. invalid year
    try:
        date_format_0.validate("201700-12-13")
    except ValidationError:
        pass
    else:
        # Shouldn't get here
        assert False

    # 3. invalid month
    try:
        date_format_0.validate("2017-00-13")
    except ValidationError:
        pass
    else:
        # Shouldn't get here
        assert False

    # 4. invalid day

# Generated at 2022-06-26 10:21:41.841154
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format_0 = DateTimeFormat()
    date_time_0 = date_format_0.validate("2013-04-24T00:14:31.324798Z") # noqa
    assert date_time_0 == datetime.datetime(2013, 4, 24, 0, 14, 31, 324798, tzinfo=datetime.timezone.utc)

    date_time_1 = date_format_0.validate("2009-12-24T20:00:00-08:00") # noqa
    assert date_time_1 == datetime.datetime(2009, 12, 24, 20, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=-8)))


# Generated at 2022-06-26 10:21:51.263048
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    try:
        assert date_time_format_0.validate("2013-02-01T11:59:14.214519+08:00") == datetime.datetime(2013, 2, 1, 11, 59, 14, 214519, tzinfo=datetime.timezone(datetime.timedelta(0, 28800)))
    except:
        raise AssertionError("validate of DateTimeFormat fail at test case 0")
    try:
        assert date_time_format_0.validate("2013-02-01T11:59:14.214519Z") == datetime.datetime(2013, 2, 1, 11, 59, 14, 214519, tzinfo=datetime.timezone.utc)
    except:
        raise Ass

# Generated at 2022-06-26 10:21:55.442723
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    # Call method validate of class DateTimeFormat
    try:
        date_time_format_0.validate('2020-08-12T13:13:13.000000Z')
    except Exception as e:
        assert False, "Test Failed: test_DateTimeFormat_validate()"



# Generated at 2022-06-26 10:21:57.436670
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    _DateTimeFormat = DateTimeFormat()
    _date_format_validate = _DateTimeFormat.validate("2019-01-01T12:00:00")
    assert _date_format_validate == datetime.datetime(2019, 1, 1, 12, 0, 0)

# Generated at 2022-06-26 10:22:04.861456
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    str_0 = '2018-11-28T08:26:40.718475'
    datetime_0 = date_time_format_0.validate(str_0)
    # print(datetime_0)
    assert not (datetime_0 == None)


# Generated at 2022-06-26 10:22:14.438636
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    #case 1:
    date_time_format = DateTimeFormat()
    try:
        date_time_format.validate("123456")
    except ValidationError:
        print("Invalid date!")
    #case 2: check if exception is thrown
    date_time_format = DateTimeFormat()
    try:
        date_time_format.validate("2019-12-12T12:12:12Z")
    except ValidationError:
        print("Invalid date!")
    #case 3: check return value
    date_time_format = DateTimeFormat()
    res = date_time_format.validate("2019-12-12T12:12:12Z")
    assert res.isoformat() == "2019-12-12T12:12:12+00:00"
    #case 4: check return value


# Generated at 2022-06-26 10:22:20.625251
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format = DateTimeFormat()
    value = '2018-01-01T01:01:01:01+01:00'
    r = date_format.validate(value)
    print(r)


if __name__ == '__main__':
    test_DateTimeFormat_validate()

# Generated at 2022-06-26 10:22:25.402318
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    d = datetime.datetime(2019, 7, 3, 15, 41, 34, 322980)
    t = time_format_0.validate(d)
    print(t)


# Generated at 2022-06-26 10:22:28.799894
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    with raises(ValidationError):
        date_time_format_0.validate("1234567890")


# Generated at 2022-06-26 10:22:33.863723
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test1
    datetime_format_0 = DateTimeFormat()
    value = datetime_format_0.validate("2020-01-01T00:00:00Z")
    assert value == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test2
    datetime_format_1 = DateTimeFormat()
    value = datetime_format_1.validate("2020-01-01T00:00:00+00:00")
    assert value == datetime.datetime(2020, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)

    # Test3
    datetime_format_2 = DateTimeFormat()

# Generated at 2022-06-26 10:22:44.580268
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    value = ""

    code = "format"

    match = TIME_REGEX.match(value)
    assert match is None

    text = time_format_0.errors[code].format(**time_format_0.__dict__)
    time_format_0_validate_0 = ValidationError(text, code)

    dt = time_format_0.validate(value)

    x = isinstance(dt, ValidationError)
    assert x == True
    x = isinstance(dt, datetime.time)
    assert x == False
    x = isinstance(dt, Exception)
    assert x == True


# Generated at 2022-06-26 10:22:51.050269
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    try:
        time_format_0.validate("07:10:43.123456")
    except ValidationError as ve:
        assert str(ve) == "Must be a real time."
    else:
        assert False, "Expected ValidationError to be raised."


test_TimeFormat_validate()

# Generated at 2022-06-26 10:23:00.767683
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    assert time_format_0.validate("20:03:20.000000") == datetime.time(20, 3, 20)
    assert time_format_0.validate("20:03:20.400000") == datetime.time(20, 3, 20, 400000)
    assert time_format_0.validate("20:03:20") == datetime.time(20, 3, 20)
    assert time_format_0.validate("00:30") == datetime.time(0, 30)



# Generated at 2022-06-26 10:23:13.693623
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    valid_uuid1 = "3b54f507-27fb-47b6-bfb6-9752ded18b13"
    valid_uuid2 = "d39efa8b-e0f5-49c5-8d72-d34c656f9f9c"
    invalid_uuid = "d39efa8b-e0f5-49c5-8d72-d34c656f9f9"
    assert uuid_format.validate(valid_uuid1) == uuid.UUID(valid_uuid1)
    assert uuid_format.validate(valid_uuid2) == uuid.UUID(valid_uuid2)
    assert uuid_format.validate(invalid_uuid) == uuid

# Generated at 2022-06-26 10:23:25.439333
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("2020-03-14T15:32:54.008340+02:00").isoformat() == "2020-03-14T15:32:54.008340+02:00"
    assert date_time_format.validate("2020-03-14T15:32:54.008340").isoformat() == "2020-03-14T15:32:54.008340"
    assert date_time_format.validate("2020-03-14T15:32:54+02:00").isoformat() == "2020-03-14T15:32:54+02:00"

# Generated at 2022-06-26 10:23:37.014825
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    # Test case with valid UUID
    try:
        uuid_format.validate("f47ac10b-58cc-4372-a567-0e02b2c3d479")
    except ValidationError:
        assert False, "UUID is valid"

    # Test case with invalid UUID
    try:
        uuid_format.validate("F47AC10B-58CC-4372-A567-0E02B2C3D479")
        assert False, "UUID is invalid"
    except ValidationError:
        pass


# Generated at 2022-06-26 10:23:39.514754
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    expected = datetime.time(hour=0, minute=1, second=1, microsecond=0)
    actual = time_format_0.validate("00:01:01")
    assert actual == expected


# Generated at 2022-06-26 10:23:45.039672
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_1 = TimeFormat()
    time_data = time_format_1.validate("23:12")
    assert time_data.hour == 23
    assert time_data.minute == 12


time_format_1 = TimeFormat()
time_data = time_format_1.validate("23:12")
assert time_data.hour == 23
assert time_data.minute == 12



# Generated at 2022-06-26 10:24:00.537759
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_0 = time_format_0.validate("15:30:14.999999")
    assert time_0.hour == 15
    assert time_0.minute == 30
    assert time_0.second == 14
    assert time_0.microsecond == 999999
    
    time_1 = time_format_0.validate("15:30:14.009999")
    assert time_1.hour == 15
    assert time_1.minute == 30
    assert time_1.second == 14
    assert time_1.microsecond == 999
    
    time_2 = time_format_0.validate("15:30:14.009")
    assert time_2.hour == 15
    assert time_2.minute == 30
    assert time_2.second == 14


# Generated at 2022-06-26 10:24:12.719412
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Private function "validate" should be called
    # Private function "validation_error" should be called
    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    time_format_2 = TimeFormat()
    time_format_3 = TimeFormat()
    time_format_4 = TimeFormat()
    time_format_5 = TimeFormat()
    ret_val_0 = time_format_0.validate("00:00:00")
    ret_val_1 = time_format_1.validate("01:01:01")
    ret_val_2 = time_format_2.validate("23:59:59")
    ret_val_3 = time_format_3.validate("00:00:00.123456")
    ret_val_4 = time_format_4

# Generated at 2022-06-26 10:24:21.218630
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    fmt = DateTimeFormat()
    value = "2019-09-20T14:56:14Z"
    assert fmt.validate(value) == datetime.datetime(2019, 9, 20, 14, 56, 14, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-26 10:24:28.019114
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    result = date_format_1.validate('2019-4-3')
    expected = datetime.date(2019, 4, 3)
    assert result == expected


# Generated at 2022-06-26 10:24:31.831871
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-26 10:24:48.387552
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    match = DATETIME_REGEX.match('2020-10-31T20:35:20.1234+10:00')
    if not match:
        raise ValidationError(text='Must be a valid datetime format.', code='format')
    groups = match.groupdict()
    if groups['microsecond']:
        groups['microsecond'] = groups['microsecond'].ljust(6, '0')
    tzinfo_str = groups.pop('tzinfo')
    if tzinfo_str == 'Z':
        tzinfo = datetime.timezone.utc
    elif tzinfo_str is not None:
        offset_mins = int(tzinfo_str[-2:]) if len(tzinfo_str) > 3 else 0
       

# Generated at 2022-06-26 10:24:50.384050
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Wrong type
    assert_raises(ValidationError, DateFormat().validate, 5.4)


# Generated at 2022-06-26 10:24:56.102232
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate('not a date')
    except ValidationError as e:
        assert str(e) == 'Must be a valid date format.'
        assert e.code is 'format'
    else:
        assert 0


# Generated at 2022-06-26 10:24:58.922987
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate(12)
    except:
        pass
    else:
        raise AssertionError('expected raise but not')


# Generated at 2022-06-26 10:25:12.116655
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    time_format_0.validate('12:30')
    time_format_0.validate('12:30:12')
    time_format_0.validate('12:30:12.1234')
    time_format_0.validate('12:30:12.123456')
    time_format_0.validate('12:30:12.123455')
    time_format_0.validate('12:30:12.123454')
    time_format_0.validate('12:30:12.123453')
    time_format_0.validate('12:30:12.123452')
    time_format_0.validate('12:30:12.123451')

    with pytest.raises(ValidationError):
        time_

# Generated at 2022-06-26 10:25:14.535605
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()

    res = date_format.validate("2020-10-05")

    assert isinstance(res, datetime.date)


# Generated at 2022-06-26 10:25:23.490655
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    if date_format_0.validate("1348-09-06"):
        pass
    if date_format_0.validate("1348-09-06"):
        pass
    if date_format_0.validate("1348-09-06"):
        pass
    if date_format_0.validate("1348-09-06"):
        pass
    if date_format_0.validate("1348-09-06"):
        pass
    if date_format_0.validate("1348-09-06"):
        pass
    if date_format_0.validate("1348-09-06"):
        pass
    if date_format_0.validate("1348-09-06"):
        pass

# Generated at 2022-06-26 10:25:35.903004
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(2080, 5, 1, 16, 50, 23, 273036)
    date_time_format_0.validate(str(datetime_0))
    date_time_format_0.validate(str(datetime.datetime(2080, 5, 1, 16, 50, 23, 273036, tzinfo=datetime.timezone(datetime.timedelta(0, 3600)))))
    date_time_format_0.validate(datetime.datetime(2080, 5, 1, 16, 50, 23, 273036))

# Generated at 2022-06-26 10:25:38.669610
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    fmt = TimeFormat()
    fmt.validate('abc')
    # Test will fail if the code is not reached
    assert True
    

# Generated at 2022-06-26 10:25:43.958117
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate("2020-11-24")
    except ValidationError as e:
        print(e.text)
    try:
        date_format_0.validate("2020-11-25")
    except ValidationError as e:
        print(e.text)
    try:
        date_format_0.validate("2020-11-26")
    except ValidationError as e:
        print(e.text)


# Generated at 2022-06-26 10:25:46.412645
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    assert date_format_0.validate('2019-01-01') == datetime.date(2019, 1, 1)

    try:
        date_format_0.validate('2019-01-32')
    except ValidationError as e:
        assert e.code == 'invalid'


# Generated at 2022-06-26 10:25:49.283667
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():

    obj = DateFormat()
    value = "2020-09-13"
    output = obj.validate(value)
    assert output == datetime.date(2020, 9, 13)



# Generated at 2022-06-26 10:25:50.553457
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2019-09-06")


# Generated at 2022-06-26 10:26:03.234896
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate('2017-01-31')
    date_format_0.validate('2000-02-29')
    date_format_0.validate('2005-02-28')
    date_format_0.validate('2000-03-31')
    try:
        date_format_0.validate('2017-02-30')
    except ValidationError as e:
        assert e.args[0] == 'Must be a real date.'
    try:
        date_format_0.validate('2017-04-0')
    except ValidationError as e:
        assert e.args[0] == 'Must be a valid date format.'

# Generated at 2022-06-26 10:26:04.786688
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()


# Generated at 2022-06-26 10:26:07.780057
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate('2018-2-2')


# Generated at 2022-06-26 10:26:14.595619
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # create an object of the class to test
    time_format = TimeFormat()
    # test with a valid time value
    assert time_format.validate('07:00') == datetime.time(7, 0)
    # test with a invalid time value
    try:
        time_format.validate('07:00:60')
    except ValidationError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 10:26:24.781309
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    assert date_format_0.validate("2018-12-31") == datetime.date(2018, 12, 31)
    assert date_format_0.validate("2018-02-29") == datetime.date(2018, 2, 29)

    exception1 = date_format_0.validate("2018-12-")
    assert isinstance(exception1, ValidationError)
    assert exception1.code == "format"
    assert f'Must be a valid date format.' in exception1.text

    exception2 = date_format_0.validate("2018-13-31")
    assert isinstance(exception2, ValidationError)
    assert exception2.code == "invalid"
    assert f'Must be a real date.' in exception2.text

    exception3 = date

# Generated at 2022-06-26 10:26:30.485788
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    try:
        val_0 = datetime_format_0.validate(0.0)
    except Exception as e:
        val_0 = e

    assert isinstance(val_0, ValidationError)


# Generated at 2022-06-26 10:26:33.723313
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("2019-08-21T15:31:35.397172-05:00")



# Generated at 2022-06-26 10:26:39.647081
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # sample data
    date_time_format_0 = DateTimeFormat()
    string_0 = "2020-05-23T12:30:00-04:00"
    expected = datetime.datetime(2020, 5, 23, 12, 30, 00, tzinfo=datetime.timezone(datetime.timedelta(hours=-4)))
    actual = date_time_format_0.validate(string_0)
    print(f'Expected: {expected}\nActual: {actual}')
    assert expected == actual


# Generated at 2022-06-26 10:26:49.400100
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    time_format_2 = TimeFormat()
    time_format_3 = TimeFormat()
    time_format_4 = TimeFormat()
    time_format_5 = TimeFormat()
    time_format_6 = TimeFormat()
    time_format_7 = TimeFormat()
    time_format_8 = TimeFormat()
    time_format_9 = TimeFormat()
    time_format_10 = TimeFormat()
    time_format_11 = TimeFormat()
    time_format_12 = TimeFormat()
    time_format_13 = TimeFormat()
    time_format_14 = TimeFormat()
    time_format_15 = TimeFormat()
    time_format_16 = TimeFormat()
    time_format_17 = TimeFormat()
   

# Generated at 2022-06-26 10:27:01.964057
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_0 = date_time_format_0.validate("2017-08-07T12:30:53Z")
    assert date_time_0 == datetime.datetime(2017, 8, 7, 12, 30, 53, tzinfo=datetime.timezone.utc)
    date_time_0 = date_time_format_0.validate("2017-08-07T12:30:53-10:00")
    assert date_time_0 == datetime.datetime(2017, 8, 7, 12, 30, 53, tzinfo=datetime.timezone(datetime.timedelta(hours=-10)))

# Generated at 2022-06-26 10:27:06.077537
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    test_cases = [
        ("2020-01-01", datetime.date(2020, 1, 1)),
        ("2020-10-10", datetime.date(2020, 10, 10)),
        ("1-1-1", datetime.date(1, 1, 1)),
    ]

    for case, result in test_cases:
        assert date_format_0.validate(case) == result


# Generated at 2022-06-26 10:27:10.251929
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    result = time_format_0.validate("12:23:34.789")
    assert result is not None
    assert (result.hour == 12)
    assert (result.minute == 23)
    assert (result.second == 34)
    assert (result.microsecond == 789000)


# Generated at 2022-06-26 10:27:15.385352
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format_0 = DateTimeFormat()
    date_format_0.validate('2020-04-19T05:32:30+02:00')

# Generated at 2022-06-26 10:27:19.516829
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    value_0 = ""
    with pytest.raises(ValidationError):
        assert time_format_0.validate(value_0) == ValidationError


# Generated at 2022-06-26 10:27:27.553690
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    result = date_format.validate("0001-01-01")
    assert result.year == 1
    assert result.month == 1
    assert result.day == 1

    result = date_format.validate("2017-01-03")
    assert result.year == 2017
    assert result.month == 1
    assert result.day == 3


# Generated at 2022-06-26 10:27:35.890578
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    # Test case #0
    time = time_format.validate("19:30:59")
    assert time.hour == 19
    assert time.minute == 30
    assert time.second == 59

    # Test case #1
    time = time_format.validate("19:30")
    assert time.hour == 19
    assert time.minute == 30
    assert time.second == 0

    # Test case #2
    time = time_format.validate("19")
    assert time.hour == 19
    assert time.minute == 0
    assert time.second == 0


# Generated at 2022-06-26 10:27:41.227883
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    date_time_0 = datetime.datetime.now()

    s = date_time_0.strftime("%H:%M")

    assert isinstance(time_format_0.validate(s), datetime.time)


# Generated at 2022-06-26 10:27:43.887275
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2020-04-08") == datetime.date(2020,4,8)


# Generated at 2022-06-26 10:27:52.680844
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate(date_time_format_0)
    date_time_format_0.validate(date_time_format_0)
    date_time_format_0.validate(date_time_format_0)
    date_time_format_0.validate(date_time_format_0)


# Generated at 2022-06-26 10:28:05.171134
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        y = date_format_0.is_native_type({})
        assert False
    except AssertionError:
        pass
    try:
        y = date_format_0.serialize(2)
        assert False
    except AssertionError:
        pass
    except NotImplementedError:
        try:
            y = date_format_0.validate(3)
            assert False
        except AssertionError:
            pass
        except NotImplementedError:
            try:
                y = date_format_0.validate('2020-08-01')
            except AssertionError:
                pass
            except NotImplementedError:
                pass


# Generated at 2022-06-26 10:28:18.789612
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    with pytest.raises(ValidationError) as e:
        date_format_0.validate('9999-99-99')
    assert e.value.code == 'format'
    with pytest.raises(ValidationError) as e:
        date_format_0.validate('9999-01-32')
    assert e.value.code == 'invalid'
    with pytest.raises(ValidationError) as e:
        date_format_0.validate('2018-a-12')
    assert e.value.code == 'format'
    date_format_1 = DateFormat()
    date_format_1.validate('2018-01-12')


# Generated at 2022-06-26 10:28:22.759524
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('15:35:22')


# Generated at 2022-06-26 10:28:31.640793
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    # Case 1: valid date time
    date_time_value = date_time_format.validate("2016-04-29T12:57:42")
    assert date_time_value.year == 2016
    assert date_time_value.month == 4
    assert date_time_value.day == 29
    assert date_time_value.hour == 12
    assert date_time_value.minute == 57
    assert date_time_value.second == 42
    assert date_time_value.microsecond == 0
    assert date_time_value.tzinfo == None

    # Case 2: valid date time with micro second
    date_time_value = date_time_format.validate("2016-04-29T12:57:42.123456")
    assert date_time_value

# Generated at 2022-06-26 10:28:49.841979
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    res = time_format.validate("00:00:00")

    assert res is not None
    assert isinstance(res, datetime.time)
    assert res.hour == 0
    assert res.minute == 0
    assert res.second == 0
    assert res.microsecond == 0
    assert res.tzinfo is None

    res = time_format.validate("00:00:00.123456")

    assert res is not None
    assert isinstance(res, datetime.time)
    assert res.hour == 0
    assert res.minute == 0
    assert res.second == 0
    assert res.microsecond == 123456
    assert res.tzinfo is None

    with pytest.raises(ValidationError):
        time_format.validate("0:0:0")



# Generated at 2022-06-26 10:29:01.217213
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    with pytest.raises(NotImplementedError):
        datetime_format_0.serialize("")


# Generated at 2022-06-26 10:29:09.381378
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    value_0_1 = '2019-01-01'
    result_0_1 = date_format_1.validate(value_0_1)
    expected_result_0_1 = datetime.date(2019, 1, 1)
    assert expected_result_0_1 == result_0_1
    with pytest.raises(ValidationError) as error_0_1:
        value_0_2 = '2019-01-32'
        date_format_1.validate(value_0_2)
    excepted_error_message_0_1 = 'Must be a real date.'
    assert excepted_error_message_0_1 == str(error_0_1.value)


# Generated at 2022-06-26 10:29:13.590152
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    # Testing for any exceptions raised
    ret = time_format.validate("2019-06-07T08:09:10.1234")

    assert isinstance(ret, datetime.time)
    assert ret == datetime.time(8, 9, 10, 123400)



# Generated at 2022-06-26 10:29:19.086951
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    assert datetime_format.validate("1980-05-02T08:00:00.000000Z") == datetime.datetime(1980,5,2,8,0,0,0,tzinfo=datetime.timezone.utc)


# Generated at 2022-06-26 10:29:29.252806
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test case 1
    date_format_0 = DateFormat()
    assert date_format_0.validate("2020-05-01") == datetime.date(2020, 5, 1)

    # Test case 2
    date_format_1 = DateFormat()
    try:
        date_format_1.validate("20200501")
    except ValidationError:
        pass
    else:
        assert False

    # Test case 3
    date_format_2 = DateFormat()
    try:
        date_format_2.validate("2020-1-1")
    except ValidationError:
        pass
    else:
        assert False



# Generated at 2022-06-26 10:29:35.434944
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    assert date_format_1.validate('2018-01-01') == datetime.date(2018, 1, 1)


# Generated at 2022-06-26 10:29:41.463181
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    datetime_format_0.validate("2006-01-02T15:04:05.999999Z")
    datetime_format_0.validate("2006-01-02T15:04:05.999999+01:00")
    datetime_format_0._validation_error_code = "format"
    with pytest.raises(ValidationError):
        datetime_format_0.validate("2006-01-02T15:04:05.999999+01")

# Generated at 2022-06-26 10:29:46.116614
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = typesystem.DateFormat()
    date = dateFormat.validate("1995-02-26")
    assert date.year == 1995
    assert date.month == 2
    assert date.day == 26


# Generated at 2022-06-26 10:29:51.112641
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("11:12:13") == datetime.time(11, 12, 13)


# Generated at 2022-06-26 10:29:55.768740
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("10:11:33+05:00")


# Generated at 2022-06-26 10:30:08.429009
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate("1942-02-18T11:13:46") == datetime.datetime(
        1942, 2, 18, 11, 13, 46, tzinfo=datetime.timezone.utc
    )



# Generated at 2022-06-26 10:30:16.641636
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert date_format_0.validate("2017-11-02")==datetime.date(2017, 11, 2)
    assert date_format_0.validate("2016-02-29")==datetime.date(2016, 2, 29)
    assert date_format_0.validate("2015-14-15")==datetime.date(2015, 2, 15)
