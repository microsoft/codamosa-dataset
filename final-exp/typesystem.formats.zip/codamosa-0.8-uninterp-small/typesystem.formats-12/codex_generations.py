

# Generated at 2022-06-26 10:20:40.037014
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_format_0 = DateTimeFormat()
    obj = datetime.datetime.today().replace(microsecond=0)
    # print(date_format_0.serialize(obj))
    assert date_format_0.serialize(obj) == obj.isoformat()



# Generated at 2022-06-26 10:20:45.518887
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    # Test passing a wrong type
    with pytest.raises(TypeError):
        date_time_format_0.validate("")

# Generated at 2022-06-26 10:20:54.815081
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    # Test 0: Invalid input
    try:
        date_format_0.validate("")
        raise AssertionError("assert failure: Expected to fail")
    except ValidationError:
        pass

    # Test 1: Invalid input
    try:
        date_format_0.validate("2019-9")
        raise AssertionError("assert failure: Expected to fail")
    except ValidationError:
        pass

    # Test 2: Invalid input
    try:
        date_format_0.validate("2019-13-09")
        raise AssertionError("assert failure: Expected to fail")
    except ValidationError:
        pass

    # Test 3: Invalid input

# Generated at 2022-06-26 10:21:04.490914
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        # The method validate of class TimeFormat is supposed to raise a ValidationError
        # when it receives a string whose length is less than 6
        # The method validate of the class TimeFormat is supposed to raise a ValidationError
        # when its first character is not a digit
        time_format_0.validate('a:00')
        assert False
    except ValidationError:
        assert True
    try:
        # The method validate of class TimeFormat is supposed to raise a ValidationError
        # when it receives a string with second number greater than 59
        time_format_0.validate('00:60')
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-26 10:21:07.623980
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_test_value = 'dbe9d3e0-b45f-4f7f-a98a-41e5e8c3d564'
    assert uuid_format.validate(uuid_test_value) == uuid.UUID(uuid_test_value)


# Generated at 2022-06-26 10:21:12.770208
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format_0 = UUIDFormat()
    uuid_format_0.validate("9e9a583a-a59c-4b07-a744-fb684cfebb10")



# Generated at 2022-06-26 10:21:20.417403
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():

    # Create UUIDFormat object
    # Input data
    UUID = '7b39e506-31d0-11e9-b210-d663bd873d93'


    uuid_format_0 = UUIDFormat( )
    uuid_format_0.validate(UUID)

# Generated at 2022-06-26 10:21:25.200602
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    data = "0a8448a2-b19d-4af4-bdb8-90c671357934"
    uuid_format = UUIDFormat()

    value = uuid_format.validate(data)

    assert isinstance(value, uuid.UUID)


# Generated at 2022-06-26 10:21:35.743153
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    test_TimeFormat = TimeFormat()
    assert test_TimeFormat.validate('00:00:00') is not None
    assert test_TimeFormat.validate('23:55:55') is not None
    assert test_TimeFormat.validate('00:00:00.000000') is not None
    assert test_TimeFormat.validate('00:00:00.1234') is not None
    assert test_TimeFormat.validate('00:00:00.123456') is not None
    assert test_TimeFormat.validate('23:55:55.123456') is not None


# Generated at 2022-06-26 10:21:39.373185
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00")
    time_format.validate("12:30:04")
    time_format.validate("12:30:04.1234")
    time_format.validate("12:30:04.123456")
    time_format.validate("12:30:04.1234567")


# Generated at 2022-06-26 10:21:49.826943
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # setup
    date_time_format = DateTimeFormat()

    # exercise
    with pytest.raises(ValidationError):
        date_time_format.validate("")

    # assert
    assert date_time_format.validate("2019-01-01T00:00:00.123000Z") == datetime.datetime(
        2019, 1, 1, 0, 0, 0, 123000, tzinfo=datetime.timezone.utc
    )

# Generated at 2022-06-26 10:21:58.567108
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # caso positivo
    time_format_0 = TimeFormat()

    resultado_0 = time_format_0.validate("02:01")
    assert resultado_0 == datetime.time(hour=2, minute=1)

    # caso negativo
    with pytest.raises(ValidationError):
        resultado_1 = time_format_0.validate("dvscxg")


# Generated at 2022-06-26 10:22:07.038936
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2020-02-10")
    date_format_0.validate("2020-02-10")
    try:
        date_format_0.validate("2020-02-30")
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-26 10:22:15.360668
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert [date_format_0.validate("2020-01-23")] == [datetime.date(2020,1,23)]
    assert [date_format_0.validate("1901-07-20")] == [datetime.date(1901,7,20)]
    assert [date_format_0.validate("0000-01-01")] == [datetime.date(0,1,1)]
    assert [date_format_0.validate("2020-12-31")] == [datetime.date(2020,12,31)]
    assert [date_format_0.validate("0000-01-01")] == [datetime.date(0,1,1)]

# Generated at 2022-06-26 10:22:26.523337
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # test_case_0
    date_format_0 = DateTimeFormat()
    assert date_format_0.validate("2010-12-16") == datetime.datetime(2010, 12, 16)

    # test_case_1
    date_format_1 = DateTimeFormat()
    assert date_format_1.validate("1990-01-01T01:01:01") == datetime.datetime(1990, 1, 1, 1, 1, 1)

    # test_case_2
    date_format_2 = DateTimeFormat()
    assert date_format_2.validate("2020-12-12T12:12:12.121212") == datetime.datetime(2020, 12, 12, 12, 12, 12, 121212)

    # test_case_3
    date_format_3

# Generated at 2022-06-26 10:22:36.515435
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1: Valid datetime string in format "YYYY-MM-DD HH:MM:SS.ssssss
    datetime_format_0 = DateTimeFormat()
    expected_output_1_1 = datetime.datetime(2019, 10, 16, 10, 11, 12, 123456, datetime.timezone.utc)
    assert datetime_format_0.validate("2019-10-16 10:11:12.123456") == expected_output_1_1

    # Test case 2: Valid datetime string in format "YYYY-MM-DD HH:MM:SS.ssssssZ"
    datetime_format_1 = DateTimeFormat()

# Generated at 2022-06-26 10:22:38.828955
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dtf = DateTimeFormat()
    assert dtf.serialize(datetime.datetime(2019, 3, 27, 0, 52, 25, tzinfo=datetime.timezone.utc)) == "2019-03-27T00:52:25Z"

# Generated at 2022-06-26 10:22:40.108173
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    expected_result=None
    assert DateTimeFormat().serialize(None)==expected_result


# Generated at 2022-06-26 10:22:46.010841
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime_format = DateTimeFormat()
    obj = datetime.datetime.now()
    actual_output = datetime_format.serialize(obj)
    expected_output = obj.isoformat()
    assert expected_output == actual_output



# Generated at 2022-06-26 10:22:52.579259
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    import datetime
    date_format_0 = DateFormat()
    date_time_format_0 = DateTimeFormat()
    date_instance_0 = datetime.date(2018,6,25)
    assert date_time_format_0.is_native_type(date_instance_0) == False
    assert date_format_0.validate("2018-06-25") == datetime.date(2018,6,25)

#Unit test for method serialize of class DateFormat

# Generated at 2022-06-26 10:22:59.515012
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format = DateTimeFormat()

    value = date_format.validate("2019-01-30T22:12:00Z")


# Generated at 2022-06-26 10:23:01.817082
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    assert (date_format_0.serialize(datetime.date(2036, 6, 24)) == '2036-06-24')


# Generated at 2022-06-26 10:23:04.099796
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    input_1 = "2017-01-01T01:01:01"
    output_1 = date_time_format.validate(input_1)
    assert type(output_1) == datetime.datetime
    assert output_1 == datetime.datetime(2017, 1, 1, 1, 1, 1)



# Generated at 2022-06-26 10:23:08.408399
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format_1 = DateTimeFormat()
    date_format_1.validate('2020-02-01T04:01:23+01:00')
    assert True


# Generated at 2022-06-26 10:23:13.032300
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()

    assert date_format_0.serialize(None) is None
    assert date_format_0.serialize(datetime.date(2010, 10, 10)) == '2010-10-10'


# Generated at 2022-06-26 10:23:20.524820
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate('11:22:33')
    except Exception as e:
        print('Validation Error ' + e)
        assert (str(e) == 'Must be a real time.')



# Generated at 2022-06-26 10:23:23.005941
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_1 = DateFormat()
    assert date_format_1.serialize(datetime.date(1992, 3, 2)) == '1992-03-02'


# Generated at 2022-06-26 10:23:26.895104
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    result = time_format.validate("12:45:15")
    assert isinstance(result, datetime.time)
    assert result.hour == 12
    assert result.minute == 45
    assert result.second == 15



# Generated at 2022-06-26 10:23:41.911859
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format_0 = DateFormat()
    date_format_1 = DateFormat()
    date_format_2 = DateFormat()
    date_format_3 = DateFormat()
    date_format_4 = DateFormat()
    date_format_5 = DateFormat()
    date_format_6 = DateFormat()
    date_format_7 = DateFormat()
    date_format_8 = DateFormat()
    date_format_9 = DateFormat()
    date_format_10 = DateFormat()
    date_format_11 = DateFormat()
    date_format_12 = DateFormat()
    date_format_13 = DateFormat()
    date_format_14 = DateFormat()
    date_format_15 = DateFormat()
    date_format_16 = DateFormat()
    date_format_17 = DateFormat()
   

# Generated at 2022-06-26 10:23:44.710922
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    actual = time_format_0.validate('00:06:00.000000')
    assert actual == datetime.time(0, 6)


# Generated at 2022-06-26 10:23:54.457561
# Unit test for method serialize of class DateTimeFormat

# Generated at 2022-06-26 10:23:58.650006
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate("2017-12-07T23:59:07.575000Z") == "2017-12-07T23:59:07.575000+00:00"


# Generated at 2022-06-26 10:24:05.908099
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.serialize(datetime.datetime(2020, 11, 17, 16, 32, 45, tzinfo=datetime.timezone.utc)) == "2020-11-17T16:32:45Z"

# Generated at 2022-06-26 10:24:07.914124
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_0 = time_format_0.validate('11:15:30')
    assert time_0 == datetime.time(11, 15, 30)



# Generated at 2022-06-26 10:24:23.102479
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test data
    test_data_0 = {
        "datetime": "1998-12-28 10:30:10",
        "datetime_with_millisecond": "1998-12-28 10:30:10.123",
        "datetime_with_microsecond": "1998-12-28 10:30:10.123456",
        "datetime_with_timezone": "1998-12-28 10:30:10-02:00",
        "datetime_with_hours_timezone": "1998-12-28T10:30:10-02",
        "datetime_with_utc": "1998-12-28T10:30:10.123Z",
    }

    date_time_format = DateTimeFormat()

    for key in test_data_0:
        assert date_time_format

# Generated at 2022-06-26 10:24:28.103998
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-12-31")
    date_format.validate("2018-01-01")


# Generated at 2022-06-26 10:24:32.758683
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    format_instance = DateTimeFormat()
    asse

# Generated at 2022-06-26 10:24:43.954017
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Setup
    instance = DateTimeFormat()

    # Object
    obj = datetime.datetime(2012, 3, 23, 21, 58, 25, 78439, datetime.timezone.utc)
    expected_output = obj.isoformat()

    # Exercise
    actual_output = instance.serialize(obj)

    # Verify
    assert actual_output == expected_output

# Generated at 2022-06-26 10:24:46.762314
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    df0 = TimeFormat()
    assert df0.validate("12:34:56.0000") == datetime.time(12, 34, 56, 0)

# Generated at 2022-06-26 10:24:58.837760
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate('00:00:00') == datetime.time(0, 0)
    assert tf.validate('00:00:03') == datetime.time(0, 0, 3)
    assert tf.validate('12:00:03') == datetime.time(12, 0, 3)

    assert tf.validate('00:00:00.000000') == datetime.time(0, 0)
    assert tf.validate('00:00:00.000001') == datetime.time(0, 0)
    assert tf.validate('00:00:00.000010') == datetime.time(0, 0)
    assert tf.validate('00:00:00.000100') == datetime.time(0, 0)

# Generated at 2022-06-26 10:25:13.349943
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    # test case 0: None object
    assert date_time_format.serialize(None) == None
    # test case 1: invalid datatype object
    with pytest.raises(AssertionError) as raised_exception:
        date_time_format.serialize(datetime.time(1, 1))
    assert raised_exception.type == AssertionError
    assert str(raised_exception.value) == 'assert isinstance(obj, datetime.datetime)'

    assert date_time_format.serialize(datetime.datetime(2020, 1, 1, 1, 1, 1, 1, datetime.timezone.utc)) == '2020-01-01T01:01:01.000001+00:00'

# Generated at 2022-06-26 10:25:22.928892
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("10:25") == datetime.time(10, 25)
    assert time_format.validate("10:25:36") == datetime.time(10, 25, 36)
    assert time_format.validate("10:25:36.471234") == datetime.time(10, 25, 36, 471_234)
    assert time_format.validate("10:25:36.471234+10:30") == datetime.time(10, 25, 36, 471_234, tzinfo=datetime.timezone(datetime.timedelta(hours=10, minutes=30)))

# Generated at 2022-06-26 10:25:28.932018
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Setup
    obj = datetime.datetime(2020, 9, 23, 22, 51, 9, 459867)
    expected = "2020-09-23T22:51:09.459867"

    # Exercise
    date_time_format_instance = DateTimeFormat()
    actual = date_time_format_instance.serialize(obj)

    # Verify
    assert actual == expected



# Generated at 2022-06-26 10:25:31.558636
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate('2016-10-05') == datetime.date(2016, 10, 5)


# Generated at 2022-06-26 10:25:38.127336
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    fmt = DateTimeFormat()

    # test_case_0
    data = "2000-01-01T00:00:00Z"
    expected = datetime.datetime(2000, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)
    assert fmt.validate(data) == expected

    # test_case_1
    data = "2000-01-01T00:00:00.1Z"
    expected = datetime.datetime(2000, 1, 1, 0, 0, 0, 100000, datetime.timezone.utc)
    assert fmt.validate(data) == expected

    # test_case_2
    data = "2000-01-01T00:00:00.12Z"

# Generated at 2022-06-26 10:25:45.473864
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    """Tests that the validate method of class DateTimeFormat accepts ISO-8601 strings
    and returns a datetime object.
    """
    # test valid ISO-8601 string
    datetime_format_0 = DateTimeFormat()
    date_time_0 = datetime_format_0.validate("2008-04-19T12:11:10.000Z")
    assert(date_time_0.hour == 12 and date_time_0.minute == 11 and date_time_0.second == 10 and date_time_0.microsecond == 0)
    assert(date_time_0.tzinfo == datetime.timezone.utc)

    date_time_1 = datetime_format_0.validate("2008-04-19T12:11:10.000000Z")

# Generated at 2022-06-26 10:25:48.757542
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime.utcnow()
    iso = DateTimeFormat().serialize(obj)
    dt = DateTimeFormat().validate(iso)
    assert obj == dt


# Generated at 2022-06-26 10:26:01.478588
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('17:00:00')
    time_format_0.validate('17:00')
    time_format_0.validate('17:00:00.000')
    time_format_0.validate('17:00:00.000Z')
    time_format_0.validate('17:00:00.000000Z')
    time_format_0.validate('17:00:00.000000+01:00')
    time_format_0.validate('17:00:00.000000+01')
    time_format_0.validate('17:00:00.000000-01:00')
    time_format_0.validate('17:00:00.000000-01')



# Generated at 2022-06-26 10:26:12.445892
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # test case 1: check error message
    tF1 = TimeFormat()
    try:
        tF1.validate("00:00:00:00:00:00")
    except ValidationError as e:
        assert e.text=="Must be a valid time format."

    # test case 2: custom error message for invalid time
    tF2 = TimeFormat()
    tF2.errors['invalid'] = "It is invalid"
    try:
        tF2.validate("00:00:00:00:00")
    except ValidationError as e:
        assert e.text=="It is invalid"

    # test case 3: custom error message for invalid format
    tF3 = TimeFormat()
    tF3.errors['format'] = "It is invalid"

# Generated at 2022-06-26 10:26:22.012580
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test for case 0
    date_format_0 = DateFormat()
    value = "2018-07-18"
    assert date_format_0.validate(value) == datetime.date(2018,7,18)

    # Test for case 1
    date_format_1 = DateFormat()
    value = "2018-07-83"
    try:
        date_format_1.validate(value)
    except ValidationError as e:
        assert e.code == "invalid"

    # Test for case 2
    date_format_2 = DateFormat()
    value = "2018-13-18"
    try:
        date_format_2.validate(value)
    except ValidationError as e:
        assert e.code == "invalid"


# Generated at 2022-06-26 10:26:35.097065
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_0 = datetime.time(12, 25, 54)
    time_format_0.validate(time_0)
    time_1 = datetime.time(19, 18, 58)
    time_format_0.validate(time_1)
    time_2 = datetime.time(13, 20, 33)
    time_format_0.validate(time_2)
    time_3 = datetime.time(16, 29, 33)
    time_format_0.validate(time_3)
    time_4 = datetime.time(10, 32, 11)
    time_format_0.validate(time_4)
    time_5 = datetime.time(11, 30, 48)

# Generated at 2022-06-26 10:26:40.931947
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Test case 1
    date_time_format_1 = DateTimeFormat()
    test_date_time = datetime.datetime(2020, 1, 25, 0, 0, 0)
    assert date_time_format_1.serialize(test_date_time) == "2020-01-25T00:00:00"
    # Test case 2
    # Test case 3
    # Test case 4
    # Test case 5
    # Test case 6
    # Test case 7
    # Test case 8
    # Test case 9
    # Test case 10
    # Test case 11



# Generated at 2022-06-26 10:26:46.426977
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    datetime_0 = datetime.datetime(year=2019, month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
    date_time_format_0.serialize(obj=datetime_0)


# Generated at 2022-06-26 10:26:49.055009
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    TimeFormat()

# Generated at 2022-06-26 10:26:57.307933
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetimeformat = DateTimeFormat()
    assert datetimeformat.validate(value='2018-08-06T09:00:00+02:00') == datetime.datetime(2018,8,6,9,0,0,0,datetime.timezone(datetime.timedelta(seconds=7200)))


# Generated at 2022-06-26 10:27:02.018914
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("08:15:30.123456")



# Generated at 2022-06-26 10:27:08.009331
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    obj = datetime.datetime(2020, 1, 15, 12, 12, 12, 12)
    response = date_time_format.serialize(obj)
    assert response == "2020-01-15T12:12:12.000012"


# Generated at 2022-06-26 10:27:16.358598
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate('2018-08-05T18:23:00+02:00') == datetime.datetime(2018, 8, 5, 18, 23, tzinfo=datetime.timezone(datetime.timedelta(0, 7200)))


# Generated at 2022-06-26 10:27:23.006993
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    """
    Test case for method validate of class DateTimeFormat
    
    """
    # create object of class DateTimeFormat
    date_time_format_0 = DateTimeFormat()

    # validate if method validate of class DateTimeFormat throws ValidationError
    try:
        date_time_format_0.validate("2015-01-01T01:02:03Z")
    except ValidationError as exception_0:
        print(exception_0.code)
    except Exception as exception_0:
        raise AssertionError("Unexpected exception")


# Generated at 2022-06-26 10:27:34.924682
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("00:00:00")
    time_format_0.validate("00:00:00.0")
    time_format_0.validate("00:00:00.00")
    time_format_0.validate("00:00:00.000")
    time_format_0.validate("00:00:00.0000")
    time_format_0.validate("00:00:00.00000")
    time_format_0.validate("00:00:00.000000")
    time_format_0.validate("00:00:00.0000000")
    time_format_0.validate("00:00:00.00000000")
    time_format_0.validate("00:00:00.000000000")

# Generated at 2022-06-26 10:27:46.252665
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():

    # 1
    dt_1 = datetime.datetime(year=2019, month=1, day=1, tzinfo=datetime.timezone.utc)
    date_format_1 = DateTimeFormat()
    date_format_1.serialize(dt_1) # should equal "2019-01-01T00:00:00Z"

    # 2
    dt_2 = datetime.datetime(year=2019, month=1, day=1, tzinfo=datetime.timezone(datetime.timedelta(seconds=3600)))
    date_format_2 = DateTimeFormat()
    date_format_2.serialize(dt_2) # should equal "2019-01-01T00:00:00+01:00"

    # 3
    dt_3 = datetime.datetime

# Generated at 2022-06-26 10:27:49.116482
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # for code coverage
    date_time_format_0 = DateTimeFormat()
    result = date_time_format_0.validate('2006-10-25')
    assert result == datetime.date(2006, 10, 25)



# Generated at 2022-06-26 10:27:51.929491
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt_0 = DateTimeFormat()
    dt_1 = dt_0.serialize(datetime.now())

# Generated at 2022-06-26 10:27:56.029771
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    try:
        date_format_0 = TimeFormat()
        date_format_0.validate("2020-08-07 21:12:33")
    except ValidationError:
        pass
    else:
        assert False, "Should have thrown a ValidationError"


# Generated at 2022-06-26 10:28:07.872882
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    #create an instance of class DateTimeFormat
    DateTimeFormat_serialize_test_0 = DateTimeFormat()
    #call method serialize in class DateTimeFormat
    DateTimeFormat_serialize_test_0.serialize(obj=None)
    DateTimeFormat_serialize_test_0.serialize(obj= datetime.datetime(2020, 1, 5, 9, 33, 4, 5))
    DateTimeFormat_serialize_test_0.serialize(obj= datetime.datetime(2020, 1, 5, 9, 33, 4, 5, datetime.timezone(datetime.timedelta(seconds=0))))

# Generated at 2022-06-26 10:28:20.961089
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    case_0 = datetime.datetime.utcfromtimestamp(1591612357).replace(tzinfo=datetime.timezone.utc)
    expected_value_0 = "2020-06-08T00:05:57Z"
    case_1 = datetime.datetime.utcfromtimestamp(1591612360).replace(tzinfo=datetime.timezone.utc)
    expected_value_1 = "2020-06-08T00:06:00Z"
    case_2 = datetime.datetime.utcfromtimestamp(1591612361).replace(tzinfo=datetime.timezone.utc)
    expected_value_2 = "2020-06-08T00:06:01Z"

# Generated at 2022-06-26 10:28:27.510949
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert time_format.validate("12:00:00.000111") == datetime.time(12, 0, 0, 111)
    assert time_format.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    with pytest.raises(AssertionError):
        time_format.validate("24:00")

# Generated at 2022-06-26 10:28:45.949360
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtfmt = DateTimeFormat()
    dt = dtfmt.validate('2019-06-21T12:21:07.948644+03:00')
    assert dt.tzname() == 'MSK'
    assert dt.time() == datetime.time(12, 21, 7, 948644, tzinfo=datetime.timezone(datetime.timedelta(seconds=10800)))
    assert dt.utcoffset() == datetime.timedelta(seconds=10800)
    dt = dtfmt.validate('2019-06-21T12:21:07.948644+0300')
    assert dt.tzname() == 'MSK'

# Generated at 2022-06-26 10:29:01.646848
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_0 = TimeFormat()
    assert time_0.validate("20:13:13") == datetime.time(20, 13, 13)
    assert time_0.validate("23:59:59") == datetime.time(23, 59, 59)
    with pytest.raises(ValidationError):
        time_0.validate("aaa")
    with pytest.raises(ValidationError):
        time_0.validate("00:00:60")
    with pytest.raises(ValidationError):
        time_0.validate("00:60:06")
    with pytest.raises(ValidationError):
        time_0.validate("24:00:00")


# Generated at 2022-06-26 10:29:04.621796
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    a = DateTimeFormat()
    assert a.validate("2017-01-01T00:00:00Z") == datetime.datetime(2017, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)



# Generated at 2022-06-26 10:29:10.634124
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    obj = datetime.datetime(year=2018, month=10, day=11)
    date_time_format_0.serialize(obj)

# Generated at 2022-06-26 10:29:13.468703
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat();
    time_type_0 = time_format_0.validate("00:10:15");
    print(time_type_0);


# Generated at 2022-06-26 10:29:15.288216
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    DateFormat().validate('2019-09-30')


# Generated at 2022-06-26 10:29:17.450823
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2000-11-12")

# Generated at 2022-06-26 10:29:21.557283
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    date_format_1.validate("2020-01-01")


# Generated at 2022-06-26 10:29:30.542935
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format_0 = DateTimeFormat()

    date_format_0.validate("2018-10-31")

    date_format_0.validate("2018-10-31T00:00:00")

    date_format_0.validate("2018-10-31T00:00:00+02:00")

    date_format_0.validate("2018-10-31T00:00:00.123456+02:00")

    date_format_0.validate("2018-10-31T00:00:00+0000")

    date_format_0.validate("2018-10-31T00:00:00+00:00")

    date_format_0.validate("2018-10-31T00:00:00Z")


# Generated at 2022-06-26 10:29:32.609212
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    from typesystem.base import Format

    date_time_format = DateTimeFormat()

    date_time_format.serialize("2019-02-01T11:22:33")



# Generated at 2022-06-26 10:29:41.901275
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format_0 = DateTimeFormat()

    assert date_format_0.validate('2015-05-23T08:00:00') == datetime.datetime(2015, 5, 23, 8, 0, 0)
    assert date_format_0.validate('2015-05-23T08:00:30+02:00') == datetime.datetime(2015, 5, 23, 8, 0, 30, tzinfo=datetime.timezone(datetime.timedelta(seconds=7200)))
    assert date_format_0.validate('2015-05-23T08:00:30Z') == datetime.datetime(2015, 5, 23, 8, 0, 30, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-26 10:29:48.895722
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_format_0 = DateTimeFormat()
    date_format_0.serialize(None)
    date_format_0.serialize('2019-09-24T15:22:35.028020')



# Generated at 2022-06-26 10:30:04.966967
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    assert datetime_format_0.validate('2000-01-01T17:00:00Z') == datetime.datetime(2000, 1, 1, 17, 0, 0, tzinfo=datetime.timezone.utc)
    assert datetime_format_0.validate('2000-01-01T17:00:00+00:00') == datetime.datetime(2000, 1, 1, 17, 0, 0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-26 10:30:15.105182
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("2018-10-01T14:15:00-05:00")
    date_time_format_0.validate("2018-10-01T14:15:00Z")
