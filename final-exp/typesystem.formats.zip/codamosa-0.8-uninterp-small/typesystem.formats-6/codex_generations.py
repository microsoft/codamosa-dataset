

# Generated at 2022-06-26 10:20:34.378586
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    value = "2020-01-01"
    assert date_format_0.validate(value) == datetime.date(2020, 1, 1)


# Generated at 2022-06-26 10:20:37.426693
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
	date_time_format_0 = DateTimeFormat()
	value='2000-04-30T10:45:00'
	expected_result=datetime.datetime(2000, 4, 30, 10, 45, 0)
	assert date_time_format_0.validate(value)==expected_result


# Generated at 2022-06-26 10:20:44.321182
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
     date_time_format_0 = DateTimeFormat()

     with pytest.raises(AssertionError) as excinfo:
         date_time_format_0.serialize(None)
     assert "obj is None" in str(excinfo.value)

     with pytest.raises(AssertionError) as excinfo:
         date_time_format_0.serialize("2019-01-30T22:28:46.867")
     assert "isinstance" in str(excinfo.value)

     assert date_time_format_0.serialize(datetime.datetime(2019, 1, 30, 22, 28, 46, 867)) == "2019-01-30T22:28:46.867"


# Generated at 2022-06-26 10:20:51.164995
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    expected = uuid.UUID("c9bf9e57-1685-4c89-bafb-ff5af830be8a")
    actual = UUIDFormat().validate("c9bf9e57-1685-4c89-bafb-ff5af830be8a")

    assert actual == expected


# Generated at 2022-06-26 10:20:59.407713
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2020-12-31")
    date_format.validate("2020-12-31")
    date_format.validate("2020-1-31")
    date_format.validate("2020-11-31")
    date_format.validate("2000-12-31")


# Generated at 2022-06-26 10:21:02.537943
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    obj = datetime.datetime(2020, 5, 8, 20, 56, 11)
    string = time_format_0.serialize(obj)
    assert string == "20:56:11"


# Generated at 2022-06-26 10:21:15.550128
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Case 1
    date_time_format_1 = DateTimeFormat()
    value_1 = '20200611T20:08:39.560113Z'
    res_1 = date_time_format_1.validate(value_1)
    assert res_1 == datetime.datetime(2020, 6, 11, 20, 8, 39, 560113, tzinfo=datetime.timezone.utc)

    # Case 2
    date_time_format_2 = DateTimeFormat()
    value_2 = '2020-04-30T17:15:56.031731+02:00'
    res_2 = date_time_format_2.validate(value_2)

# Generated at 2022-06-26 10:21:19.915898
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(2019, 4, 4)) == "2019-04-04"


# Generated at 2022-06-26 10:21:24.732292
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    value = "some value"

    try:
        date_time_format_0.validate(value)
    except ValidationError as err:
        assert str(err) == "Must be a valid datetime format."




# Generated at 2022-06-26 10:21:37.046957
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate('2018-10-27T13:49:51.184299Z') == \
    datetime.datetime(2018, 10, 27, 13, 49, 51, 184299)
    assert date_time_format.validate('2018-10-27T13:49:51.184299+01:00') == \
    datetime.datetime(2018, 10, 27, 13, 49, 51, 184299, tzinfo=datetime.timezone(datetime.timedelta(0, 3600)))
    assert date_time_format.validate('2018-10-27T13:49:51.184Z') == \
    datetime.datetime(2018, 10, 27, 13, 49, 51, 184000)


# Generated at 2022-06-26 10:21:46.569215
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    obj = datetime.time(hour=15, minute=37, second=56)
    time_format_0.serialize(obj)



# Generated at 2022-06-26 10:21:56.075829
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate('00:00:00.000000') == datetime.time(0, 0)
    assert TimeFormat().validate('00:00:00') == datetime.time(0, 0)
    assert TimeFormat().validate('00:00') == datetime.time(0, 0)
    assert TimeFormat().validate('00') == datetime.time(0, 0)
    assert TimeFormat().validate('01:00:00.000000') == datetime.time(1, 0)
    assert TimeFormat().validate('02:00:00') == datetime.time(2, 0)
    assert TimeFormat().va

# Generated at 2022-06-26 10:22:06.464305
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("00:00:00")
    time_format_0.validate("23:59:59")
    time_format_0.validate("00:00:00.1")
    time_format_0.validate("23:59:59.1")
    time_format_0.validate("00:00:00.12")
    time_format_0.validate("23:59:59.12")
    time_format_0.validate("00:00:00.123")
    time_format_0.validate("23:59:59.123")
    time_format_0.validate("00:00:00.123456")
    time_format_0.validate("23:59:59.123456")



# Generated at 2022-06-26 10:22:09.124699
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format0 = DateFormat()
    assert date_format0.serialize(None) == None

# Generated at 2022-06-26 10:22:15.530753
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    with pytest.raises(ValidationError) as excinfo:
        date_time_format_0.validate("invalid-date")
    assert excinfo.value.code == 'format'

# Generated at 2022-06-26 10:22:20.888114
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('23:59')

    time_format_1 = TimeFormat()
    with pytest.raises(ValidationError):
        time_format_1.validate('')


# Generated at 2022-06-26 10:22:29.924639
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Create an instance of TimeFormat
    time_format = TimeFormat()

    # Assert it is a TimeFormat object
    assert isinstance(time_format, TimeFormat)

    # Input an incorrect input
    assert time_format.validate(
        "test"
    ) == ValidationError(text='Must be a valid time format.', code='format')

    # Input an incorrect time format
    assert time_format.validate(
        "25:00"
    ) == ValidationError(text='Must be a real time.', code='invalid')

    # Input a correct time format
    assert time_format.validate(
        "01:00"
    ) == datetime.time(1, 0)



# Generated at 2022-06-26 10:22:34.293072
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_0 = TimeFormat()
    time_format_0.serialize(datetime.time())


# Generated at 2022-06-26 10:22:39.529748
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("22:28:31.555")
    except ValidationError as e:
        assert e.code == 'invalid'
    

# Generated at 2022-06-26 10:22:52.054439
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    print('Unit test of validate. ')
    time_format_1 = TimeFormat()
    time_format_2 = TimeFormat()
    time_format_3 = TimeFormat()

    try:
        assert time_format_1.is_native_type(datetime.time(1,1,1)) == True
    except Exception:
        print('TimeFormat failed to pass native test. ')
    try:
        assert time_format_2.is_native_type(datetime.time(0,0,0)) == True
    except Exception:
        print('TimeFormat failed to pass native test. ')
    try:
        assert time_format_3.is_native_type(datetime.time(0,1,1)) == True
    except Exception:
        print('TimeFormat failed to pass native test. ')


   

# Generated at 2022-06-26 10:22:59.715472
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    '''
    TimeFormat = TimeFormat()
    # TimeFormat.validate('00:01:00.000001')
    # A = TimeFormat.validate('00:01:00.000001')
    '''
    # pass

# Generated at 2022-06-26 10:23:06.639344
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    # When
    value_as_date_time_format_1 = date_time_format_1.validate("2001-01-01T01:01:01")
    # Then
    assert value_as_date_time_format_1 == datetime.datetime(
        2001, 1, 1, 1, 1, tzinfo=datetime.timezone.utc
    )

    date_time_format_2 = DateTimeFormat()
    # When
    value_as_date_time_format_2 = date_time_format_2.validate("2001-01-01T01:01:01Z")
    # Then

# Generated at 2022-06-26 10:23:18.219486
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    value_0 = "11:12:15.568078"
    assert isinstance(time_format_0.validate(value_0), datetime.time) is True
    value_1 = "11:12"
    assert type(time_format_0.validate(value_1)) == datetime.time
    value_2 = "11:12:5"
    assert type(time_format_0.validate(value_2)) == datetime.time
    value_3 = "11:12:5."
    assert type(time_format_0.validate(value_3)) == datetime.time
    value_4 = "11:12:5.0"
    assert type(time_format_0.validate(value_4)) == datetime.time
   

# Generated at 2022-06-26 10:23:21.264386
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate('15:50:10') == datetime.time(15, 50, 10, tzinfo=None)



# Generated at 2022-06-26 10:23:30.636996
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    """Test validate"""

    t = DateTimeFormat()
    # ImportError: cannot import name DateTimeFormat
    result = DateTimeFormat()
    assert result == t
    # TypeError: validate() missing 1 required positional argument: 'value'
    value = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = DateTimeFormat().validate(value)
    assert isinstance(result, datetime.datetime)
    # ValidationError: Must be a real datetime.
    value = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = DateTimeFormat().validate(value)
    assert isinstance(result, datetime.datetime)
    # ValidationError: Must be a valid datetime format.

# Generated at 2022-06-26 10:23:43.708117
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()

    assert time_format_0.validate("12:00:00") == datetime.time(12, 0, 0)
    assert time_format_1.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)

    try:
        time_format_0.validate("12:00")
        return False
    except ValidationError:
        pass

    try:
        time_format_1.validate("12:00:60")
        return False
    except ValidationError:
        pass

    try:
        time_format_1.validate("12:00:00.7")
        return False
    except ValidationError:
        pass

    return True


# Generated at 2022-06-26 10:23:57.568257
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert isinstance(time_format.validate("18:48"), datetime.time)
    assert isinstance(time_format.validate("18:48:39"), datetime.time)
    assert time_format.validate("18:48:39") == datetime.time(18, 48, 39)

    assert time_format.validate("18:48:39.123456") == datetime.time(18, 48, 39, 123456)

    with pytest.raises(ValidationError):
        time_format.validate("18:48:39:123456")


# Generated at 2022-06-26 10:24:05.339677
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate("2019-12-31T15:13:13Z") == datetime.datetime(2019, 12, 31, 15, 13, 13, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-26 10:24:14.575959
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    with pytest.raises(ValidationError):
        date_time_format_1.validate(value="2020-01-01T01")
    assert date_time_format_1.validate(value="2020-01-01T01:01") == datetime.datetime(
        2020, 1, 1, 1, 1
    )
    assert date_time_format_1.validate(value="2020-01-01T01:01:01") == datetime.datetime(
        2020, 1, 1, 1, 1, 1
    )

# Generated at 2022-06-26 10:24:19.385508
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    value_0 = "00:00:00"
    value_1 = time_format_0.validate(value_0)


# Generated at 2022-06-26 10:24:23.253560
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2002-1-1")


# Generated at 2022-06-26 10:24:25.333904
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("1991-07-11T20:34:00") == datetime.datetime(1991, 7, 11, 20, 34, 0)


# Generated at 2022-06-26 10:24:36.477756
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem import DateTime

    format = DateTimeFormat()
    assert format.is_native_type(datetime.datetime.now())
    assert format.validate("2011-01-01T01:01:01.001Z") == datetime.datetime(
        2011, 1, 1, 1, 1, 1, 1000, tzinfo=datetime.timezone.utc
    )
    assert format.validate("2011-01-01T01:01:01.001+01:00") == datetime.datetime(
        2011, 1, 1, 1, 1, 1, 1000, tzinfo=datetime.timezone(datetime.timedelta(hours=1))
    )

# Generated at 2022-06-26 10:24:49.318409
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    assert str(date_time_format_1.validate("2010-01-01T00:00:00Z")) == "2010-01-01 00:00:00+00:00"
    assert str(date_time_format_1.validate("2010-01-01T01:23:45Z")) == "2010-01-01 01:23:45+00:00"
    assert str(date_time_format_1.validate("2010-01-01T01:23:45.123456Z")) == "2010-01-01 01:23:45.123456+00:00"

# Generated at 2022-06-26 10:24:56.016258
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_time_format_0 = DateFormat()
    try:
        date_time_format_0.validate('1005-1-1')
    except ValidationError:
        pass
    else:
        raise Exception('DateFormat.validate(value) should raise ValidationError when value isnt a valid date format string.')


# Generated at 2022-06-26 10:24:58.587517
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate("2019-01-12") == datetime.date(2019, 1, 12)


# Generated at 2022-06-26 10:25:09.512060
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validation_error("format")
    data = '2018-01-01T00:00:00Z'
    value = date_time_format_0.validate(value=data)
    assert isinstance(value, datetime.datetime)
    assert value.year == 2018
    assert value.month == 1
    assert value.day == 1
    assert value.hour == 0
    assert value.minute == 0
    assert value.second == 0


# Generated at 2022-06-26 10:25:21.554193
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test for method validate of class DateTimeFormat
    # Tests for validating a Datetime object
    date_format_0 = DateFormat()
    time_format_0 = TimeFormat()
    date_time_format_0 = DateTimeFormat()
    dt = datetime.datetime.now()
    dt_string = date_time_format_0.serialize(dt)
    date_time = date_time_format_0.validate(dt_string)
    assert dt == date_time

    # Test for method validate of class DateTimeFormat
    # Tests for validating call with a None object
    date_format_0 = DateFormat()
    time_format_0 = TimeFormat()
    date_time_format_0 = DateTimeFormat()
    date_time_obj = date_time_format_0.validate

# Generated at 2022-06-26 10:25:30.033027
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert date_format_0.validate("2020-06-25") == datetime.date(2020, 6, 25)
    assert date_format_0.validate("2900-05-20") == datetime.date(2900, 5, 20)

    assert date_format_0.validate("2020-06-25T") == datetime.date(2020, 6, 25)
    assert date_format_0.validate("2900-05-20 ") == datetime.date(2900, 5, 20)


# Generated at 2022-06-26 10:25:33.221796
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    a = TimeFormat()
    a.validate('0:0Z')


# Generated at 2022-06-26 10:25:39.599713
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetimeformat = DateTimeFormat()
    datetimeformat.validate('2026-03-27T19:58:49+00:00')

# Generated at 2022-06-26 10:25:49.982489
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('14:51:44.935000')
    time_format_0.validate('14:51:44.935')
    time_format_0.validate('14:51:44')
    time_format_0.validate('14:51')
    time_format_0.validate('14')
    # Test if the input is not a valid time format
    with pytest.raises(ValidationError) as excinfo:
        time_format_0.validate('14:51:44.9350000')
    assert excinfo.value.code == 'format'
    # Test if the input is a valid time format but not a valid time
    with pytest.raises(ValidationError) as excinfo:
        time_format

# Generated at 2022-06-26 10:25:54.684871
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()

    try:
        date_format.validate('sdfsdfs')
        assert False
    except ValidationError:
        pass

    date_format.validate('2000-01-02')



# Generated at 2022-06-26 10:26:06.960823
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    with raises(ValidationError):
        date_time_format_0.validate('2018-06-02T23:59:00.000000+0100')
    with raises(ValidationError):
        date_time_format_0.validate('2018-02-29T23:59:00.000000')
    with raises(ValidationError):
        date_time_format_0.validate('2018-2-29T23:59:00.000000')
    with raises(ValidationError):
        date_time_format_0.validate('2018-06-32T23:59:00.000000')
    with raises(ValidationError):
        date_time_format_0.validate('2018-14-32T23:59:00.000000+00')
   

# Generated at 2022-06-26 10:26:18.771159
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    test_value_1 = "01:01"
    output = time_format.validate(test_value_1)
    assert output == datetime.time(1, 1)
    test_value_2 = "01:01:01"
    output = time_format.validate(test_value_2)
    assert output == datetime.time(1, 1, 1)
    test_value_3 = "01:01:01.000000"
    output = time_format.validate(test_value_3)
    assert output == datetime.time(1, 1, 1)
    test_value_4 = "01:01:01.01"
    output = time_format.validate(test_value_4)

# Generated at 2022-06-26 10:26:24.050356
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()
    date_time_format_1.validate("2019-01-01T01:01:01Z") == datetime.datetime(2019, 1, 1, 1, 1, 1, tzinfo=datetime.timezone.utc)
    date_time_format_1.validate("2019-01-01T01:01:01.000001Z") == datetime.datetime(2019, 1, 1, 1, 1, 1, 1, tzinfo=datetime.timezone.utc)
    date_time_format_1.validate("2019-01-01T01:01:01+00:00") == datetime.datetime(2019, 1, 1, 1, 1, 1, tzinfo=datetime.timezone.utc)
    date_

# Generated at 2022-06-26 10:26:33.457898
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    test_object_0 = DateFormat()
    try:
        print(test_object_0.validate('2019-05-01'))
    except Exception as err:
        print(repr(err))
    try:
        print(test_object_0.validate('2019-45-01'))
    except Exception as err:
        print(repr(err))
    try:
        print(test_object_0.validate('201-05-01'))
    except Exception as err:
        print(repr(err))


# Generated at 2022-06-26 10:26:36.212008
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    with pytest.raises(ValidationError):
        date_format_0.validate("20.1.02")


# Generated at 2022-06-26 10:26:48.501773
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    def test_DateTimeFormat_validate_0():
        date_time_format_0 = DateTimeFormat()
        value_0 = '2018-11-17T02:14:00'
        val_0 = date_time_format_0.validate(value_0)

    def test_DateTimeFormat_validate_1():
        date_time_format_0 = DateTimeFormat()
        value_0 = '2018-11-17T02:14:00-08:00'
        val_0 = date_time_format_0.validate(value_0)

    def test_DateTimeFormat_validate_2():
        date_time_format_0 = DateTimeFormat()
        value_0 = '2018-11-17T02:14:00Z'
        val_0 = date_time_format_

# Generated at 2022-06-26 10:26:55.339371
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate('2016-03-01')
    except ValidationError:
        pass
    else:
        assert False


# Generated at 2022-06-26 10:27:11.255475
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    value = "00:15:00"
    actual = time_format.validate(value)
    assert isinstance(actual, datetime.time)
    assert "00:15:00" == actual.isoformat()

    value = "00:15:00.000000"
    actual = time_format.validate(value)
    assert isinstance(actual, datetime.time)
    assert "00:15:00" == actual.isoformat()

    with pytest.raises(ValidationError) as e_info:
        value = "15:00"
        time_format.validate(value)
    assert "Must be a valid time format." == str(e_info.value)


# Generated at 2022-06-26 10:27:13.957139
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    str_0 = "16:27:02"
    time_1 = time_format_0.validate(str_0)


# Generated at 2022-06-26 10:27:19.888637
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    test_TimeFormat_validate_0()
    test_TimeFormat_validate_1()
    test_TimeFormat_validate_2()
    test_TimeFormat_validate_3()
    test_TimeFormat_validate_4()
    test_TimeFormat_validate_5()
    test_TimeFormat_validate_6()

# Test with default value

# Generated at 2022-06-26 10:27:28.330592
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    assert date_time_format_0.validate("2017-08-24T13:35:00.000100+01:00") == datetime.datetime(2017, 8, 24, 13, 35, 0, 100, tzinfo=datetime.timezone(datetime.timedelta(0, 3600)))



# Generated at 2022-06-26 10:27:33.561831
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    s = "2019-03-13"
    expected_result0 = datetime.date(2019, 3, 13)

    actual_result0 = date_format_0.validate(s)
    assert expected_result0 == actual_result0, 'Expect to get {}, but get {} instead'.format(expected_result0, actual_result0)



# Generated at 2022-06-26 10:27:36.118090
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    try:
        value = ' '
        date_format.validate(value)
        assert False
    except:
        assert True

# Generated at 2022-06-26 10:27:39.525514
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('00:30:00') == datetime.time(0, 30, 0)

# Generated at 2022-06-26 10:27:47.301390
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_1 = DateTimeFormat()
    date_time_format_2 = DateTimeFormat()
    date_time_format_3 = DateTimeFormat()
    date_time_format_4 = DateTimeFormat()
    date_time_format_5 = DateTimeFormat()
    date_time_format_6 = DateTimeFormat()
    date_time_format_7 = DateTimeFormat()
    date_time_format_8 = DateTimeFormat()
    date_time_format_9 = DateTimeFormat()
    date_time_format_10 = DateTimeFormat()
    date_time_format_11 = DateTimeFormat()
    date_time_format_0.validate("2020-06-04T16:53:29.330312Z")
   

# Generated at 2022-06-26 10:28:02.528975
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2018-01-01T12:00:00.000000") == datetime.datetime(2018, 1, 1, 12,
                                                                                        tzinfo=datetime.timezone.utc)
    assert DateFormat().validate("2018-01-01") == datetime.date(2018, 1, 1)
    assert TimeFormat().validate("12:00:00.000000") == datetime.time(12, tzinfo=datetime.timezone.utc)
    assert UUIDFormat().validate("d33d1bfb-9590-4dfa-8438-faf820a2f261") == uuid.UUID(
        'd33d1bfb-9590-4dfa-8438-faf820a2f261')

# Generated at 2022-06-26 10:28:12.405646
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    # AssertionError: Failed due to unexpected exception (Invalid time format)
    try:
        assert time_format_0.validate("25:02:09") == ValueError()
    except AssertionError:
        raise AssertionError("Failed due to unexpected exception (Invalid time format)")


# Generated at 2022-06-26 10:28:25.987310
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    with pytest.raises(ValidationError) as e0:
        date_format_0.validate('12/31/2018')
    assert e0.match('Must be a valid date format\.')
    with pytest.raises(ValidationError) as e1:
        date_format_0.validate('2018-99-31')
    assert e1.match('Must be a real date\.')

    date_format_0.validate('2018-12-31')



# Generated at 2022-06-26 10:28:31.454151
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    d = DateFormat()
    value = "2019-10-10"
    ret = d.validate(value)
    assert ret == datetime.date(2019, 10, 10)

    try:
        ret = d.validate("2019-20-10")
        assert False
    except ValidationError:
        pass

    try:
        ret = d.validate("2019-20-10-11")
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-26 10:28:46.882743
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    # Test Case 1
    match_0 = DATE_REGEX.match("2025-12-01")
    if not match_0:
        raise self.validation_error("format")

    kwargs_0 = {k: int(v) for k, v in match_0.groupdict().items()}
    try:
        date_format_0.validate("2025-12-01")
    except ValidationError:
        print("Exception caught.")
    else:
        print("Test case passed")


# Generated at 2022-06-26 10:28:53.896053
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.validate('2019') == datetime.datetime(2019, 1, 1, 0, 0)
    assert date_time_format_0.validate('2019-10') == datetime.datetime(2019, 10, 1, 0, 0)
    assert date_time_format_0.validate('2019-10-07') == datetime.datetime(2019, 10, 7, 0, 0)
    assert date_time_format_0.validate('2019-10-07T18:49:30') == datetime.datetime(2019, 10, 7, 18, 49, 30)
    assert date_time_format_0.validate('2019-10-07T18:49:30.123456Z') == datetime.datetime

# Generated at 2022-06-26 10:29:07.142844
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_1 = DateTimeFormat()

    # case 1
    res = date_time_format_1.validate('2019-01-04T11:12:30')
    assert(res == datetime.datetime(2019, 1, 4, 11, 12, 30))

    # case 2
    res = date_time_format_1.validate('2019-01-04T11:12:30Z')
    assert(res == datetime.datetime(2019, 1, 4, 11, 12, 30, tzinfo=datetime.timezone.utc))

    # case 3
    res = date_time_format_1.validate('2018-04-12T18:02:21.5+00:00')

# Generated at 2022-06-26 10:29:09.903272
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate("2019-08-15")



# Generated at 2022-06-26 10:29:11.256178
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_DateTimeFormat_validate_0()


# Generated at 2022-06-26 10:29:18.344790
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Case0: simple test
    date_time_format_0 = DateTimeFormat()
    value_0 = '2020-02-18T10:11:12.000000Z'
    result_0 = date_time_format_0.validate(value_0)
    assert isinstance(result_0, datetime.datetime) == True
    assert result_0 == datetime.datetime(2020, 2, 18, 10, 11, 12, tzinfo=datetime.timezone.utc)

    # Case1: simple test
    date_time_format_1 = DateTimeFormat()
    value_1 = '2020-01-01T01:00:00+01:00'
    result_1 = date_time_format_1.validate(value_1)

# Generated at 2022-06-26 10:29:26.274398
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    str_0 = "2019-01-01T01:02:03Z"

    datetime_0 = date_time_format_0.validate(str_0)

    # Test if datetime_0 is instance of datetime.datetime
    if not isinstance(datetime_0, datetime.datetime):
        raise AssertionError


# Generated at 2022-06-26 10:29:28.498585
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert time_format_0.validate('23:20') == datetime.time(23, 20)


# Generated at 2022-06-26 10:29:38.434562
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate((1))
    except ValidationError as raised_exception:
        assert raised_exception.code == 'format'
        assert raised_exception.text == 'Must be a valid date format.'


# Generated at 2022-06-26 10:29:50.679954
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()

    str_0 = "2019-01-02T01:02:03.123456Z"
    datetime_0 = datetime.datetime(2019, 1, 2, 1, 2, 3, 123456, datetime.timezone.utc)

    validate_0 = date_time_format_0.validate(str_0)

    assert datetime_0 == validate_0


# Generated at 2022-06-26 10:29:58.682063
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test the DateFormat validation and parse error
    date_format_0 = DateFormat()
    expected = "Must be a real date."
    try:
        date_format_0.validate("2050-12-23-")
    except ValidationError as e:
        assert str(e) == expected


# Generated at 2022-06-26 10:30:05.420370
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_time_format_0 = DateTimeFormat()

    # Case 0
    input = "2019-12-29"
    expected = datetime.date(2019, 12, 29)
    actual = date_time_format_0.validate(input)
    assert expected == actual

    # Case 1
    input = "2001-1-1"
    expected = datetime.date(2001, 1, 1)
    actual = date_time_format_0.validate(input)
    assert expected == actual


# Generated at 2022-06-26 10:30:15.253802
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate('15:12:51.160293')
    time_format_0.validate('15:12:51.160293')
    time_format_0.validate('15:12:51')
    time_format_0.validate('15:12')
    time_format_0.validate('15')
    time_format_0.validate('15:12:51.160293')
