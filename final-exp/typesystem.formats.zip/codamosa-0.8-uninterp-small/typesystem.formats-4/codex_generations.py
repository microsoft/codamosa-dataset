

# Generated at 2022-06-26 10:20:32.071744
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    try:
        date_time_format_0.validate("2007-01-02T12:23:45.999999+01:00")
    except ValidationError as e:
        assert e.code == "invalid"
    try:
        date_time_format_0.validate("2007-01-02T12:23:45.999999+01:00")
    except ValidationError as e:
        assert e.code == "invalid"
    try:
        date_time_format_0.validate("2007-01-02T12:23:45.999999+01:00")
    except ValidationError as e:
        assert e.code == "invalid"


# Generated at 2022-06-26 10:20:42.570320
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format_1 = TimeFormat()
    assert time_format_1.serialize(None) is None
    assert time_format_1.serialize(datetime.time(11, 44, 19, 474000)) == "11:44:19.474000"
    assert time_format_1.serialize(datetime.time(11, 44, 19)) == "11:44:19"
    assert time_format_1.serialize(datetime.time(11, 44)) == "11:44"
    assert time_format_1.serialize(datetime.time(5)) == "00:05"
    assert time_format_1.serialize(datetime.time(0)) == "00:00"


# Generated at 2022-06-26 10:20:54.293794
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    """Unit test.
    """

    date_format_1 = DateFormat()

    # Test to check a value that raises a ValidationError
    value_1 = "1988-02-29"

    with pytest.raises(ValidationError) as e:
        date_format_1.validate(value_1)

    assert str(e.value) == "Must be a real date."
    assert e.value.code == "invalid"

    # Test to check when a value is a valid date format
    value_3 = "1988-02-28"
    assert type(date_format_1.validate(value_3)) == datetime.date

    # Test to check when a value is a invalid date format
    value_4 = "02-29-1988"


# Generated at 2022-06-26 10:21:00.180674
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format_0 = DateTimeFormat()
    date_time_format_0.validate("2018-09-20T18:56:40.444444+00:00")
    # Valid iso8601 format (including micros)



# Generated at 2022-06-26 10:21:04.755261
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTime_format_0 = DateTimeFormat()
    assert dateTime_format_0.validate('2016-04-19T06:40:45Z') == datetime.datetime(2016, 4, 19, 6, 40, 45, tzinfo=datetime.timezone.utc)
    assert dateTime_format_0.validate('2016-04-19T06:40:45+00:00Z') == datetime.datetime(2016, 4, 19, 6, 40, 45, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-26 10:21:09.802022
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert date_format_0._validate("2020-01-01") == datetime.date(2020, 1, 1)

    date_format_1 = DateFormat()
    try:
        date_format_1._validate("2020-01-32")
        assert False
    except ValidationError as e:
        assert e.code == "invalid"

    date_format_2 = DateFormat()
    try:
        date_format_2._validate("2020-01")
        assert False
    except ValidationError as e:
        assert e.code == "format"


# Generated at 2022-06-26 10:21:13.601803
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()

    assert tf.validate("12:45:09.123456") == datetime.time(12, 45, 9, 123456)
    assert tf.validate("12:45:00") == datetime.time(12, 45)
    assert tf.validate("12:45") == datetime.time(12, 45)
    assert tf.validate("12") == datetime.time(12)
    with pytest.raises(ValidationError):
        tf.validate("abc")



# Generated at 2022-06-26 10:21:21.343582
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():

    df = DateTimeFormat()
    val = df.serialize(
        datetime.datetime(2018, 12, 25, 23, 5, 0, 0, datetime.timezone.utc)
    )
    assert val == "2018-12-25T23:05:00Z"



# Generated at 2022-06-26 10:21:27.138946
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format_0 = DateTimeFormat()
    assert date_time_format_0.serialize(None) == None
    assert date_time_format_0.serialize("") == ""
    assert date_time_format_0.serialize("") == ""
    assert date_time_format_0.serialize("") == ""
    assert date_time_format_0.serialize("") == ""
    assert date_time_format_0.serialize("") == ""
    assert date_time_format_0.serialize("") == ""
    assert date_time_format_0.serialize("") == ""

# Generated at 2022-06-26 10:21:30.944553
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(None) == None
    assert DateFormat().serialize(datetime.date.today()) == datetime.date.today().isoformat()



# Generated at 2022-06-26 10:21:46.185450
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    obj = UUIDFormat()
    assert obj.validate("d878bee4-6a4a-11ea-bc55-0242ac130003")
    assert "d878bee4-6a4a-11ea-bc55-0242ac130003" == obj.serialize("d878bee4-6a4a-11ea-bc55-0242ac130003")


# Generated at 2022-06-26 10:21:49.815217
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format_obj = UUIDFormat()
    assert uuid_format_obj.validate("c7b16d69-b6e3-3fa9-a7e9-9bdc61f12b72") == uuid.UUID("c7b16d69-b6e3-3fa9-a7e9-9bdc61f12b72")

# Generated at 2022-06-26 10:21:52.337382
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-26 10:21:57.150496
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    dt = datetime.date(2017, 9, 15)
    assert date_format_0.serialize(dt) == str(dt)


# Generated at 2022-06-26 10:22:10.076676
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    assert date_format_0.serialize(datetime.date(1969, 12, 31)) == '1969-12-31'
    assert date_format_0.serialize(datetime.date(1969, 12, 31)) == '1969-12-31'
    assert date_format_0.serialize(datetime.date(1999, 12, 31)) == '1999-12-31'
    assert date_format_0.serialize(datetime.date(2017, 12, 31)) == '2017-12-31'
    assert date_format_0.serialize(datetime.date(2018, 12, 31)) == '2018-12-31'
    assert date_format_0.serialize(datetime.date(2020, 12, 31)) == '2020-12-31'

# Generated at 2022-06-26 10:22:23.974254
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    date_time = date_time_format.validate('2020-04-01T12:23:30Z')

    date_time_serialized = date_time_format.serialize(date_time)

    assert date_time_serialized == '2020-04-01T12:23:30Z'

    date_time_format = DateTimeFormat()
    date_time = date_time_format.validate('2020-04-01T12:23:30.123456-02:00')

    date_time_serialized = date_time_format.serialize(date_time)

    assert date_time_serialized == '2020-04-01T12:23:30.123456-02:00'

    date_time_format = DateTimeFormat()
    date_

# Generated at 2022-06-26 10:22:29.567097
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate("2020-02-22")
    except ValidationError as e:
        assert e.code == "format"
        assert e.text == "Must be a valid date format."
    else:
        assert False, "Didn't raise ValidationError"


# Generated at 2022-06-26 10:22:36.538791
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_1 = DateFormat()
    assert date_format_1.serialize(datetime.date(year=1, month=1, day=1)) == "0001-01-01"
    assert date_format_1.serialize(None) == None



# Generated at 2022-06-26 10:22:38.796414
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Create an instance of DateFormat
    date_format_0 = DateFormat()
    # Create a null datetime value
    obj = None
    # Compare serialize result with expected value
    assert date_format_0.serialize(obj) is None


# Generated at 2022-06-26 10:22:45.193540
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    import datetime
    date_format_0 = DateTimeFormat()
    v = date_format_0.validate("2020-04-08T12:00:00Z")
    assert isinstance(v, datetime.datetime)
    assert type(v) == datetime.datetime
    assert v.year == 2020
    assert v.month == 4
    assert v.day == 8
    assert v.hour == 12
    assert v.minute == 0
    assert v.second == 0
    assert v.microsecond == 0
    assert v.tzinfo.utcoffset(None) == datetime.timedelta(0)

# Generated at 2022-06-26 10:22:49.152831
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    assert date_format_0.serialize(datetime.date(year=2019, month=1, day=1)) == "2019-01-01"


# Generated at 2022-06-26 10:23:01.378627
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    """
    1. Valid date(s)
    2. Invalid date(s) format
    3. Invalid date(s)
    """
    date_format_0 = DateFormat()
    assert date_format_0.validate('2018-12-15') == datetime.date(2018, 12, 15)

    try:
        date_format_0.validate('2018-12-32')
    except ValidationError as error:
        assert error.code == 'invalid'
    else:
        raise Exception('Expected an exception, but no exception was raised.')

    try:
        date_format_0.validate('2018-13-13')
    except ValidationError as error:
        assert error.code == 'invalid'
    else:
        raise Exception('Expected an exception, but no exception was raised.')



# Generated at 2022-06-26 10:23:02.653953
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2018-09-18") == datetime.date(2018, 9, 18)


# Generated at 2022-06-26 10:23:05.947142
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("00:00:00")


# Generated at 2022-06-26 10:23:10.559989
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_1 = DateFormat()
    assert date_format_1.serialize(datetime.date(2020, 5, 21)) == "2020-05-21"


# Generated at 2022-06-26 10:23:22.817020
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_fmt = TimeFormat()
    assert time_fmt.validate('12:05') == datetime.time(12, 5)
    assert time_fmt.validate('12') == datetime.time(12)
    assert time_fmt.validate('12:05:15') == datetime.time(12, 5, 15)
    assert time_fmt.validate('12:05:15.123456') == datetime.time(12, 5, 15, 123456)
    assert time_fmt.validate('12:05:15.000001') == datetime.time(12, 5, 15, 1)


# Generated at 2022-06-26 10:23:30.729284
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    test_values = [
        ('2018-11-23', datetime.date(2018, 11, 23)),
        ('2018-02-28', datetime.date(2018, 2, 28)),
        ('2018-12-32', ValidationError),
        ('2018-13-01', ValidationError),
        ('18-11-23', ValidationError),
        ('2018-11', ValidationError),
        ('2018', ValidationError),
        ('', ValidationError),
    ]

    date_format_0 = DateFormat()

    for value, result in test_values:
        if result == ValidationError:
            with pytest.raises(ValidationError):
                date_format_0.validate(value)
        else:
            assert date_format_0.validate(value) == result


# Generated at 2022-06-26 10:23:34.450268
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    obj = datetime.date(1981, 6, 15)
    assert date_format_0.serialize(obj) == '1981-06-15'

# Generated at 2022-06-26 10:23:41.777332
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    datetime_0 = datetime_format_0.validate("2019-03-07T12:15:14.600900")
    assert datetime_0 == datetime.datetime(year=2019,month=3,day=7,hour=12,minute=15,second=14,microsecond=600900)


# Generated at 2022-06-26 10:23:49.336400
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    args = [""]
    error = ValidationError(code='format', text='Must be a valid date format.')
    res = date_format_0.validate(*args)
    assert res == error
    args = ["2015-03-03"]
    res = date_format_0.validate(*args)
    assert res == datetime.date(2015, 3, 3)
    args = ["2015-13-03"]
    error = ValidationError(code='invalid', text='Must be a real date.')
    res = date_format_0.validate(*args)
    assert res == error


# Generated at 2022-06-26 10:23:52.762255
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate('2019-01-04')



# Generated at 2022-06-26 10:23:58.193424
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    date_time_string = "2020-04-20T12:00:00Z"
    datetime_format_0.validate(date_time_string)
    assert datetime_format_0.validate(date_time_string)


# Generated at 2022-06-26 10:23:59.993445
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_1 = TimeFormat()
    time_format_1.validate("19:30")
    time_format_1.validate("19:30:20")


# Generated at 2022-06-26 10:24:04.548856
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    assert date_format_0.validate("2017-06-15") == datetime.date(2017, 6, 15)


# Generated at 2022-06-26 10:24:14.255029
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    # Test case validate_0
    try:
        time_format_0.validate("22:14")
    except ValidationError:
        assert True

    # Test case validate_1
    try:
        time_format_0.validate("22:00:00")
    except ValidationError:
        assert True

    # Test case validate_2
    try:
        time_format_0.validate('22:00:00"')
    except ValidationError:
        assert True

    # Test case validate_3
    try:
        time_format_0.validate("22:00:00:00")
    except ValidationError:
        assert True

    # Test case validate_4

# Generated at 2022-06-26 10:24:25.366521
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    try:
        time_format_0.validate("-26:29")
    except ValidationError:
        pass
    try:
        time_format_0.validate("-2:60")
    except ValidationError:
        pass
    try:
        time_format_0.validate("-2:2:60")
    except ValidationError:
        pass
    try:
        time_format_0.validate("-2:2:2.60000000")
    except ValidationError:
        pass
    try:
        time_format_0.validate("23:10:10.60000000")
    except ValidationError:
        pass
    time_format_0.validate("-2:2:2.6000000")
    time_format_0

# Generated at 2022-06-26 10:24:32.955940
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_1 = DateFormat()
    res1 = date_format_1.serialize(datetime.date(2020, 1, 1))
    assert res1 == "2020-01-01"

    date_format_2 = DateFormat()
    res2 = date_format_2.serialize(None)
    assert res2 == None



# Generated at 2022-06-26 10:24:43.331049
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Assert: check is None
    dt_str = "2020-03-19"
    dt_obj = datetime.datetime.strptime(dt_str, "%Y-%m-%d")
    obj = DateFormat()
    assert dt_str == obj.serialize(dt_obj)
    assert None == obj.serialize(None)


# Generated at 2022-06-26 10:24:46.729446
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    str_1 = date_format_0.serialize(datetime.date(2017, 10, 10))


# Generated at 2022-06-26 10:24:59.332281
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_1 = DateFormat()
    date_format_2 = DateFormat()
    date_format_2.serialize(None)
    date_format_3 = DateFormat()
    date_format_3.serialize(datetime.date(2020, 8, 1))
    date_format_4 = DateFormat()
    date_format_4.serialize(datetime.date(2020, 3, 23))
    date_format_5 = DateFormat()
    date_format_5.serialize(datetime.date(2020, 10, 1))
    date_format_6 = DateFormat()
    date_format_6.serialize(datetime.date(2020, 5, 2))
    date_format_7 = DateFormat()
    date_format_7.serialize(datetime.date(2020, 5, 4))

# Generated at 2022-06-26 10:25:07.510171
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    result = date_format_0.serialize(obj = datetime.date(2035, 3, 19))
    assert result == "2035-03-19"


# Generated at 2022-06-26 10:25:16.882110
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    print("Start test_DateFormat_serialize()")
    f = DateFormat()
    date = f.validate("2011-01-01")
    date_str = f.serialize(date)
    assert date_str == "2011-01-01"

    assert f.serialize(None) == None

    print("Done test_DateFormat_serialize()")



# Generated at 2022-06-26 10:25:24.592267
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()

    # case 0
    assert datetime.date(year=2020, month=1, day=1) == date_format_0.validate("2020-01-01")

    # case 1
    try:
        date_format_0.validate("2020-1-1")
    except ValidationError as e:
        assert "format" == e.code
        assert "Must be a valid date format." == e.text
    else:
        assert False, "Failed to raise an exception."

    # case 2
    try:
        date_format_0.validate("2020-1-0")
    except ValidationError as e:
        assert "invalid" == e.code
        assert "Must be a real date." == e.text

# Generated at 2022-06-26 10:25:31.884922
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    tests = [
        (datetime.date(2019, 12, 12), "2019-12-12"),
        (datetime.date(1, 1, 1), "0001-01-01"),
        (datetime.date(9999, 12, 31), "9999-12-31"),
        (datetime.date(2019, 2, 28), "2019-02-28"),
        (datetime.date(2020, 2, 29), "2020-02-29"),
    ]

    for test in tests:
        assert DateFormat().serialize(test[0]) == test[1]


# Generated at 2022-06-26 10:25:33.937642
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_0 = DateFormat()
    str_0 = date_format_0.serialize(datetime.date.today())
    assert str_0 is not None


# Generated at 2022-06-26 10:25:43.752765
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_1 = DateFormat()
    try:
        date_format_1.serialize(None)
    except AssertionError as e:
        if e.args[0] != "obj cannot be None":
            raise AssertionError("Unexpected AssertionError: %s" % e.args[0])
    else:
        raise AssertionError("AssertionError expected.")
    try:
        date_format_1.serialize(date_format_1)
    except AssertionError as e:
        if e.args[0] != "obj must be of type datetime.date":
            raise AssertionError("Unexpected AssertionError: %s" % e.args[0])
    else:
        raise AssertionError("AssertionError expected.")


# Generated at 2022-06-26 10:25:46.526475
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate(time_format_0)
    assert True

# Generated at 2022-06-26 10:25:49.059461
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format_1 = DateFormat()
    assert date_format_1.serialize(datetime.date(2020, 11, 18)) == "2020-11-18"


# Generated at 2022-06-26 10:25:52.423523
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    assert date_format.serialize(datetime.date(1970, 1, 1)) == "1970-01-01"


# Generated at 2022-06-26 10:26:04.362064
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-05-24T20:41:38Z") == datetime.datetime(
        2019, 5, 24, 20, 41, 38, tzinfo=datetime.timezone.utc
    )
    assert DateTimeFormat().validate("2019-05-24T20:41:38") == datetime.datetime(
        2019, 5, 24, 20, 41, 38
    )
    assert DateTimeFormat().validate("2019-05-24T20:41:38+00:00") == datetime.datetime(
        2019, 5, 24, 20, 41, 38, tzinfo=datetime.timezone.utc
    )

# Generated at 2022-06-26 10:26:10.923420
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    value_0 = "18:53:11.735609"
    try:
        assert time_format_0.validate(value_0) is not None
    except ValidationError as e:
        assert False, "Expected not to throw error: " + str(e)


# Generated at 2022-06-26 10:26:18.701514
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format = DateTimeFormat()
    datetime_validate = date_format.validate("2019-06-24T13:02:00.000000-05:00")
    assert isinstance(datetime_validate, datetime.datetime)
    assert datetime_validate.day == 24
    assert datetime_validate.year == 2019


# Generated at 2022-06-26 10:26:32.411208
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    try:
        # Case 1
        date_time_format.validate("2020-07-27T08:57:52+00:00")

        # Case 2
        date_time_format.validate("2020-07-27T08:57:52Z")

        # Case 3
        date_time_format.validate("2020-07-27T08:57:52+07:00")

        # Case 4
        date_time_format.validate("2020-07-27T08:57:52.123456+07:00")

    except ValidationError:
        # Case 5
        raise Exception("DateTimeFormat: test validate failed")


# Generated at 2022-06-26 10:26:37.951139
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate('2012-12-10')

# Generated at 2022-06-26 10:26:43.289745
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_2 = DateFormat()
    try:
        date_format_2.validate('2020-11-04')
        return True
    except:
        return False



# Generated at 2022-06-26 10:26:50.811531
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("21:20:23")
    time_format_0.validate("08:00")
    time_format_0.validate("19:20:33.100100")
    time_format_0.validate("11:00:00.000001")
    time_format_0.validate("12:00:00.001000")
    time_format_0.validate("11:00:00.999999")
    time_format_0.validate("11:00:00.000000")


# Generated at 2022-06-26 10:26:53.797352
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()

    # case 0
    try:
        time_format_0.validate("13:13:13")
    except ValidationError:
        pass
    else:
        raise ValueError("should get a  ValidationError")



# Generated at 2022-06-26 10:26:58.185450
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(
        "2019-10-31T23:05:08"
    ).isoformat() == "2019-10-31T23:05:08"


# Generated at 2022-06-26 10:27:11.037326
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    # Case 1: Value is not string.
    with pytest.raises(ValidationError) as e:
        dtf.validate(12)
    assert e.value.code == "format"

    # Case 2: Value has a correct format but invalid date.
    with pytest.raises(ValidationError) as e:
        dtf.validate("2018-13-13T00:00:00Z")
    assert e.value.code == "invalid"

    # Case 3: Value is a valid date.
    dt = dtf.validate("2018-02-13T00:00:00Z")
    assert isinstance(dt, datetime.datetime)
    assert dt.year == 2018
    assert dt.month == 2
    assert dt.day == 13

# Generated at 2022-06-26 10:27:17.706208
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    from unittest.mock import patch
    method = 'DateFormat.validate'
    target_class = DateFormat
    assert not hasattr(target_class, "validate")
    with patch(method, return_value="A"):
        value = DateFormat()
        result = DateFormat().validate(value)
        assert result == "A"


# Generated at 2022-06-26 10:27:22.924670
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    var_value = "2020-07-28"
    result = date_format_1.validate(var_value)
    assert result == datetime.date(2020, 7, 28)


# Generated at 2022-06-26 10:27:34.894235
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():

    time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    time_format_2 = TimeFormat()

    time_str_0 = "19:59:22"
    time_str_1 = "19:59"
    time_str_2 = "19:59:22.962290"

    time_0 = time_format_0.validate(time_str_0)
    time_1 = time_format_1.validate(time_str_1)
    time_2 = time_format_2.validate(time_str_2)

    assert(type(time_0) == datetime.time)
    assert(type(time_1) == datetime.time)
    assert(type(time_2) == datetime.time)


# Generated at 2022-06-26 10:27:44.072030
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime = DateTimeFormat()
    assert datetime.validate("2000-10-31T01:30:00") == datetime.validate("2000-10-31T01:30:00Z")
    assert datetime.validate("2000-10-31T01:30:00-04:00") == datetime.validate("2000-10-31T01:30:00-04:00")
    #assert datetime.validate("2000-10-31T01:30:00") == datetime.validate("2000-10-31T01:30:00.000000")


# Generated at 2022-06-26 10:27:47.787139
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("13:03:03.123")


# Generated at 2022-06-26 10:27:51.278458
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("18:59:29.599000")



# Generated at 2022-06-26 10:27:55.986269
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    t1 = tf.validate("03:14:15")
    assert isinstance(t1, datetime.time)

    t2 = tf.validate("03:14:15.678901")
    assert isinstance(t2, datetime.time)


# Generated at 2022-06-26 10:28:01.222500
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # time_format_0 = TimeFormat()
    time_format_1 = TimeFormat()
    time_format_1.validate("12:12:00")

# Generated at 2022-06-26 10:28:09.439714
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():

    # create TimeFormat object
    time_format = TimeFormat()

    # test if is_native_type method works properly
    assert not time_format.is_native_type(datetime.datetime(2019,1,1,12,0,0))

    # test if an input in the wrong format raises a ValidationError
    with pytest.raises(ValidationError):
        time_format.validate("abc")

    # test if an input with the right format returns the right datetime object
    assert time_format.validate('12:00:00.000000') == datetime.time(12,00,0)

    # test if an input with too many numbers raises a ValidationError
    with pytest.raises(ValidationError):
        time_format.validate('23:59:59.123456')

# Generated at 2022-06-26 10:28:14.881409
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        value = date_format_0.validate("2018-01-02")
    except ValidationError:
        pass
    date_format_0.validate("2018-01-02")
    try:
        value = date_format_0.validate("2018-01-02")
    except ValidationError:
        pass
    try:
        value = date_format_0.validate("2018-01-02")
    except ValidationError:
        pass



# Generated at 2022-06-26 10:28:21.792137
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_value = '23:00:59'
    if time_format_0.is_native_type(time_value):
        assert True
    else:
        assert False
    assert type(time_format_0.validate(time_value)) == datetime.time


# Generated at 2022-06-26 10:28:27.437284
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    # TODO assert the exception type
    with pytest.raises(ValidationError):
        # TODO assert the exception message
        time_format.validate('00:00:60')


# Generated at 2022-06-26 10:28:45.841323
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    date_format_1 = TimeFormat()
    date_format_2 = TimeFormat()
    date_format_3 = TimeFormat()
    date_format_4 = TimeFormat()
    date_format_5 = TimeFormat()
    date_format_6 = TimeFormat()
    date_format_7 = TimeFormat()
    date_format_8 = TimeFormat()
    date_format_9 = TimeFormat()
    date_format_10 = TimeFormat()
    date_format_11 = TimeFormat()
    date_format_12 = TimeFormat()

    time_0 = datetime.time(0, 0, 0)
    time_1 = datetime.time(12, 0, 0)
    time_2 = datetime.time(12, 0, 0, 0)

# Generated at 2022-06-26 10:28:52.346635
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    with pytest.raises(NotImplementedError):
        time_format_0.validate("")


# Generated at 2022-06-26 10:28:54.803839
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("23:65")


# Generated at 2022-06-26 10:28:57.813474
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format =  DateFormat()
    date_format.validate('2018-03-20') 


# Generated at 2022-06-26 10:29:02.492879
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    test_string = "19:26:00.123123"
    assert time_format_0.validate(test_string) == datetime.time(19, 26, 0, 123123)
    return None


# Generated at 2022-06-26 10:29:08.132365
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    time_format_0.validate("00:00:00")
    time_format_0.validate("00:00:00.00")
    time_format_0.validate("00:00:00.000000")
    time_format_0.validate("00:00")
    time_format_0.validate("00:00.00")
    time_format_0.validate("00:00.000000")

# Generated at 2022-06-26 10:29:10.757985
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    assert (time_format_0.validate('07:03:20.550000') == datetime.time(7, 3, 20, 550000))


# Generated at 2022-06-26 10:29:13.175671
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format_0 = DateTimeFormat()
    date_time_0 = format_0.validate('2020-11-08T21:58:47.946150Z')


# Generated at 2022-06-26 10:29:16.508625
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    date_format_1.validate("2020-12-06")


# Unit Test for method serialize of class DateFormat

# Generated at 2022-06-26 10:29:26.846331
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format_0 = TimeFormat()
    data_value_0 = "01:02"
    time_0 = time_format_0.validate(data_value_0)
    assert time_0.hour == 1
    assert time_0.isoformat() == "01:02:00"
    assert time_format_0.is_native_type(time_0) is True


# Generated at 2022-06-26 10:29:40.142364
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    with pytest.raises(ValidationError) as err_info:
        date_format_0.validate('20002-00-43')
    assert err_info.value.text == 'Must be a real date.'
    assert err_info.value.code == 'invalid'
    with pytest.raises(ValidationError) as err_info:
        date_format_0.validate('2019-03-3')
    assert err_info.value.text == 'Must be a valid date format.'
    assert err_info.value.code == 'format'
    with pytest.raises(ValidationError) as err_info:
        date_format_0.validate('2019-00-61')

# Generated at 2022-06-26 10:29:49.415505
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format_0 = DateTimeFormat()
    expected = datetime.datetime(2017, 12, 12, 12, 12, 12, tzinfo=datetime.timezone.utc)
    assert datetime_format_0.validate("2017-12-12T12:12:12Z").__eq__(expected)



# Generated at 2022-06-26 10:29:53.794564
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2015-05-30")
    date_format_0.validate("2007-01-05")
    date_format_0.validate("2015-12-05")
    date_format_0.validate("1948-05-20")
    date_format_0.validate("2004-03-03")
    date_format_0.validate("2002-05-30")
    date_format_0.validate("2001-02-01")
    date_format_0.validate("2014-04-13")
    date_format_0.validate("2009-03-27")
    date_format_0.validate("2014-05-23")
    # TODO - impl tests.
    #raise Exception("Test not implemented

# Generated at 2022-06-26 10:30:00.720010
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2019-10-05') == datetime.date(2019, 10, 5)
    try:
        date_format.validate('2019-10-51')
        assert False
    except ValidationError as e:
        assert e.code == 'invalid'


# Generated at 2022-06-26 10:30:02.962819
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    u"""
    Test DateFormat's validate method.
    """
    # 1. No assert is needed.



# Generated at 2022-06-26 10:30:07.444955
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_1 = DateFormat()
    assert str(date_format_1.validate("2020-02-11")) == "2020-02-11"
    assert str(date_format_1.validate("2020-02-11")) != "2020-02-12"


# Generated at 2022-06-26 10:30:12.467102
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate('2017-10-21')
    date_format_0.validate('2018-11-19')


# Generated at 2022-06-26 10:30:15.552788
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    date_format_0.validate("2020-01-02")


# Generated at 2022-06-26 10:30:29.330459
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_0 = DateFormat()
    try:
        date_format_0.validate("Hello World")
    except ValidationError as err:
        # Check that thrown error code and error text are correct
        assert err.code == "format"
        assert err.text == 'Must be a valid date format.'
    try:
        date_format_0.validate("2020-05-32")
    except ValidationError as err:
        # Check that thrown error code and error text are correct
        assert err.code == "invalid"
        assert err.text == 'Must be a real date.'
    try:
        date_format_0.validate("2020-05-31")
    except ValidationError as err:
        # Check that no error was thrown
        assert True