

# Generated at 2022-06-22 05:57:10.988055
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuidFormat = UUIDFormat()
    result = uuidFormat.serialize(uuid.UUID(int=0))
    assert result == "00000000-0000-0000-0000-000000000000"

# Generated at 2022-06-22 05:57:15.866849
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    # Setup
    format_ = BaseFormat()  # type: BaseFormat

    # Exercise
    try:
        # Verify
        with pytest.raises(NotImplementedError):
            format_.validate(None)
    except Exception as exception:
        pytest.fail("Expected: NotImplementedError\nActual: %s" % type(exception).__name__)



# Generated at 2022-06-22 05:57:17.818217
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert isinstance(TimeFormat(), TimeFormat)


# Generated at 2022-06-22 05:57:20.662140
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    time_format = DateTimeFormat().validate('2019-12-06 12:26:30.928421')
    print(time_format)

if __name__ == "__main__":
    test_DateTimeFormat_validate()

# Generated at 2022-06-22 05:57:21.999671
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    base_formate = BaseFormat()
    base_formate.validate('base_formate')

# Generated at 2022-06-22 05:57:32.758355
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    res = datetime_format.validate('2020-07-15T12:22:35.123544+07:00')
    assert res == datetime.datetime(2020,7,15,12,22,35,123544,tzinfo=datetime.timezone(datetime.timedelta(0,25200)))
    res = datetime_format.validate('2020-07-15T12:22:35.00000000+07:00')
    assert res == datetime.datetime(2020,7,15,12,22,35,0,tzinfo=datetime.timezone(datetime.timedelta(0,25200)))
    res = datetime_format.validate('2020-07-15T12:22:35.123+07:00')

# Generated at 2022-06-22 05:57:34.064593
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    fmt = BaseFormat()
    obj = fmt.serialize("date")
    assert obj is None


# Generated at 2022-06-22 05:57:40.651955
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    native_time = datetime.time(hour=23, minute=30)
    non_native_time = "23:30:00"
    assert time_format.is_native_type(native_time) == True
    assert time_format.is_native_type(non_native_time) == False


# Generated at 2022-06-22 05:57:48.434339
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base_obj = BaseFormat()

    base_obj.errors = {
        "code": "Must be a valid code format.",
        "invalid": "Must be a real code",
    }

    try:
        base_obj.validation_error("code")
        base_obj.validation_error("invalid")
    except Exception:
        assert False # pragma: no cover
    else:
        assert True # pragma: no cover

# Unit tests for method is_native_type of class DateFormat

# Generated at 2022-06-22 05:57:51.124488
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():

    test_date_format = DateFormat()
    assert test_date_format.serialize(datetime.date(2020,1,1)) == '2020-01-01'
    assert test_date_format.serialize(None) == None


# Generated at 2022-06-22 05:58:00.584823
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
  assert UUIDFormat().is_native_type(uuid.UUID('7bd34395-b2f7-4624-9c12-e9cf6b3c8ed0'))
  assert not UUIDFormat().is_native_type('7bd34395-b2f7-4624-9c12-e9cf6b3c8ed0')


# Generated at 2022-06-22 05:58:03.355362
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = uuid.uuid4()
    uf = UUIDFormat()
    assert isinstance(uf.serialize(u), str)

# Generated at 2022-06-22 05:58:08.267832
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    baseFormat = BaseFormat()
    assert baseFormat.validation_error(code="invalid") == ValidationError(text="", code="invalid")
    assert baseFormat.validation_error(code="format") == ValidationError(text="", code="format")


# Generated at 2022-06-22 05:58:18.426504
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time(hour=13, minute=37, second=42)) is True
    assert TimeFormat().is_native_type(datetime.time(hour=13, minute=37, second=42, microsecond=123456)) is True
    assert TimeFormat().is_native_type(datetime.time(hour=13, minute=37, second=42, tzinfo=datetime.timezone.utc)) is True
    assert TimeFormat().is_native_type(13) is False
    assert TimeFormat().is_native_type("13:37:42") is False
    assert TimeFormat().is_native_type("13:37:42.123") is False


# Generated at 2022-06-22 05:58:20.890702
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat.__name__ == "DateFormat"


# Generated at 2022-06-22 05:58:23.894419
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    baseformat = BaseFormat()
    result = baseformat.validation_error("format")
    assert result.text == "Must be a valid date format."


# Generated at 2022-06-22 05:58:31.440513
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # pass
    dtf = DateTimeFormat()
    date_string = "2018-07-29T12:13:17.002927Z"
    assert dtf.validate(date_string) == datetime.datetime(2018, 7, 29, 12, 13, 17, 2927)
    # error
    date_string = "2018-07-29T12:13:17Z"
    assert dtf.validate(date_string) == datetime.datetime(2018, 7, 29, 12, 13, 17, 0)
    date_string = "2018-07-29T12:13:17.0029"
    assert dtf.validate(date_string) == datetime.datetime(2018, 7, 29, 12, 13, 17, 290000)

# Generated at 2022-06-22 05:58:39.928400
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    # Test 1: Test is_native_type with correct type
    dateformat = DateFormat()
    date = datetime.date.today()
    native_type = dateformat.is_native_type(date) 
    print("Test 1: Test is_native_type with correct type")
    print("dateformat.is_native_type(date) = " + str(native_type))
    print("Expected result: True")
    print()
    # Test 2: Test is_native_type with incorrect type
    datetimeformat = DateTimeFormat()
    date = datetime.date.today()
    native_type = datetimeformat.is_native_type(date)
    print("Test 2: Test is_native_type with incorrect type")

# Generated at 2022-06-22 05:58:43.738748
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(None) == False
    assert TimeFormat().is_native_type(1) == False


# Generated at 2022-06-22 05:58:50.692513
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    value_date = '2020-02-10'
    date = DateFormat()
    date.validate(value_date)
    assert True


# Generated at 2022-06-22 05:58:58.901157
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    fmt = UUIDFormat()
    assert fmt.is_native_type(uuid.uuid4())
    assert not fmt.is_native_type('35e8d2b3-a3e3-48d8-9053-958a84b33329')


# Generated at 2022-06-22 05:59:01.046832
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True


# Generated at 2022-06-22 05:59:05.487253
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
   test_uuid = uuid.uuid4()
   test_uuid_str = str(test_uuid)
   test_UUIDFormat = UUIDFormat()
   result = test_UUIDFormat.serialize(test_uuid)
   assert result == test_uuid_str

# Generated at 2022-06-22 05:59:07.791061
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        format = BaseFormat()
        format.validate(value= 1)


# Generated at 2022-06-22 05:59:13.977672
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid = 'f77305e4-d62a-4bc4-9c6d-ba860b4c0106'
    uuid2 = 'f77305e4-d62a-4bc4-9c6d-ba860b4c0107'
    assert UUIDFormat().validate(uuid) == uuid
    assert UUIDFormat().validate(uuid) != uuid2

# Generated at 2022-06-22 05:59:17.727095
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    import typesystem.format
    dtf = typesystem.format.DateTimeFormat()
    value = dtf.validate("2018-12-04T15:48:00.123+02:00")
    assert isinstance(value, datetime.datetime)


# Generated at 2022-06-22 05:59:19.800544
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime(2020, 9, 1, 0, 0, 0))


# Generated at 2022-06-22 05:59:21.839491
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    datetime_format.validate("2019-03-06T16:22:04.895618")

# Generated at 2022-06-22 05:59:31.258075
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    test_case = [
        [(uuid.uuid4()), (str(uuid.uuid4()))],
        [(uuid.uuid1()), (str(uuid.uuid1()))],
        [(uuid.uuid3(uuid.uuid4(), "some random text")), (str(uuid.uuid3(uuid.uuid4(), "some random text")))],
        [(uuid.uuid5(uuid.NAMESPACE_DNS, "max.com")), (str(uuid.uuid5(uuid.NAMESPACE_DNS, "max.com")))]
    ]
    for obj, expected in test_case:
        assert expected == UUIDFormat().serialize(obj)

# Generated at 2022-06-22 05:59:35.112652
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d = datetime.date(2020, 5, 15)
    test_instance = DateFormat()
    assert test_instance.serialize(d) == "2020-05-15"

# Generated at 2022-06-22 05:59:48.894789
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    value = "datetime.datetime(2020, 7, 3, 10, 10, tzinfo=datetime.timezone(datetime.timedelta(0, 3600)))"
    assert DateTimeFormat().serialize(eval(value))== "2020-07-03T10:10:00+01:00"
    value = "datetime.datetime(2020, 7, 3, 10, 10, tzinfo=datetime.timezone(datetime.timedelta(0)))"
    assert DateTimeFormat().serialize(eval(value))== "2020-07-03T10:10:00Z"
    value = "datetime.datetime(2020, 7, 3, 10, 10)"
    assert DateTimeFormat().serialize(eval(value))== "2020-07-03T10:10:00"

# Generated at 2022-06-22 05:59:54.631508
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidStr = "1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed"
    f = UUIDFormat()
    uuidObj = uuid.UUID(uuidStr)
    assert f.validate(uuidStr) == uuidObj


# Generated at 2022-06-22 05:59:58.417558
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
	d = DateFormat()
	assert d.is_native_type(datetime.date(2020, 2, 10)) == True
	assert d.is_native_type(datetime.date(2020, 2, 100)) == False


# Generated at 2022-06-22 06:00:11.008071
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # timezone is not supported for Python version pre 3.6 at this time so we
    # do not test this specific functionality
    time_format = TimeFormat()
    time_string = "12:34:56.789"
    time_object = datetime.time(12, 34, 56, 789000)
    time_format.validate(time_string)
    assert time_format.validate(time_string) == time_object
    assert time_format.validate("12:34:56.789012") == datetime.time(12, 34, 56, 789012)
    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.valid

# Generated at 2022-06-22 06:00:18.826054
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    instance = DateFormat()

    with pytest.raises(ValidationError) as context:
        instance.validate("2020/12/25")

    assert context.value.text == 'Must be a valid date format.'

    with pytest.raises(ValidationError) as context:
        instance.validate("2020-13-25")

    assert context.value.text == 'Must be a real date.'

    value = instance.validate('2020-12-25')
    assert value.year == 2020
    assert value.month == 12
    assert value.day == 25



# Generated at 2022-06-22 06:00:22.172614
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format = BaseFormat()
    format.errors = {"format": "Must be valid format."}
    assert format.validation_error("format").code == "format"
    assert format.validation_error("format").text == "Must be valid format."

# Generated at 2022-06-22 06:00:29.372870
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    f = TimeFormat()
    try:
        f.serialize(4)
    except AssertionError:
        assert True
    else:
        assert False
    try:
        f.serialize(4.5)
    except AssertionError:
        assert True
    else:
        assert False
    try:
        f.serialize(None)
    except AssertionError:
        assert True
    else:
        assert False
    f.serialize(datetime.time())
    assert True

# Generated at 2022-06-22 06:00:38.837534
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat = DateFormat()

    match_str_good = "2019-09-03"
    match_str_bad = "09-03-2019"
    match_str_bad2 = "03/09/2019"

    assert dateformat.validate(match_str_good)
    try:
        dateformat.validate(match_str_bad)
        assert False
    except ValidationError as error:
        assert error.code == "format"
    try:
        dateformat.validate(match_str_bad2)
        assert False
    except ValidationError as error:
        assert error.code == "format"


# Generated at 2022-06-22 06:00:44.285102
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat.is_native_type('1985-05-20') == True
    assert DateFormat.is_native_type('2019-04-31') == False
    assert DateFormat.is_native_type('1985-05-20T08:00:00') == False
    assert DateFormat.is_native_type("") == False
    assert DateFormat.is_native_type(1) == False

    assert DateFormat.validate('1985-05-20') == datetime.date(1985, 5, 20) 
    assert DateFormat.validate("") == None

    assert DateFormat.serialize(datetime.date(1985, 5, 20)) ==  '1985-05-20'
    assert DateFormat.serialize("") == None


# Generated at 2022-06-22 06:00:52.535147
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    format = TimeFormat()
    assert len(format.errors) == 2
    assert format.errors['format'] == "Must be a valid time format."
    assert format.errors['invalid'] == "Must be a real time."

# Generated at 2022-06-22 06:00:56.018775
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True


# Generated at 2022-06-22 06:01:07.486243
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    v = '12:30:29'
    assert t.validate(v) == datetime.time(hour=12, minute=30, second=29)
    v = '12:30:29.123456'
    assert t.validate(v) == datetime.time(hour=12, minute=30, second=29, microsecond=123456)
    v = '12:30'
    assert t.validate(v) == datetime.time(hour=12, minute=30)
    v = '12'
    with pytest.raises(ValidationError):
        t.validate(v)
    v = '12:30:at'
    with pytest.raises(ValidationError):
        t.validate(v)

# Generated at 2022-06-22 06:01:11.918192
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dateTime = DateTimeFormat()
    dateTime.validate("2019-12-21T00:00:00Z")
    assert dateTime.validation_error("format") == "Must be a valid datetime format."
    assert dateTime.validation_error("invalid") == "Must be a real datetime."

# Generated at 2022-06-22 06:01:23.898135
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    # Test 1: testing with valid UUID
    UUIDFormat.errors = {"format": "Must be valid UUID format."}
    assert str(UUIDFormat().validate('76a8fa4c-a79a-4fe2-8c8d-cfd6f7b54a85')) == '76a8fa4c-a79a-4fe2-8c8d-cfd6f7b54a85'
    
    # Test 2: testing with invalid UUID
    UUIDFormat.errors = {"format": "Must be valid UUID format."}
    with pytest.raises(ValidationError) as exception_info:
        UUIDFormat().validate('76a8fa4-a79a-4fe2-8c8d-cfd6f7b54a85')
    assert exception_

# Generated at 2022-06-22 06:01:25.718537
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    assert BaseFormat.validate(BaseFormat, 'Format test')


# Generated at 2022-06-22 06:01:33.701438
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Case: Value is None.
    # Expect: None.
    d = DateFormat()
    d1 = d.serialize(None)
    assert d1 is None
    # Case: Value is not None.
    # Expect: A string.
    d2 = d.serialize(datetime.date(2020, 5, 8))
    assert d2 == '2020-05-08'
    assert isinstance(d2,str)


# Generated at 2022-06-22 06:01:38.151335
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    id = uuid.uui

# Generated at 2022-06-22 06:01:46.374742
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(None) == None
    assert TimeFormat().serialize(datetime.time(12, 0, 0)) == '12:00:00'
    assert TimeFormat().serialize(datetime.time(12, 2, 0)) == '12:02:00'
    assert TimeFormat().serialize(datetime.time(12, 2, 55)) == '12:02:55'
    assert TimeFormat().serialize(datetime.time(12, 2, 55, 678)) == '12:02:55.000000'
    assert TimeFormat().serialize(datetime.time(12, 2, 55, 678000)) == '12:02:55.678000'
    assert TimeFormat().serialize(datetime.time(12, 2, 55, 678123)) == '12:02:55.678123'

# Generated at 2022-06-22 06:01:50.019875
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
	assert BaseFormat.errors == {}
	assert BaseFormat.is_native_type('a') == False
	assert BaseFormat.validate('a') == None
	assert BaseFormat.serialize('a') == None


# Generated at 2022-06-22 06:01:57.111194
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    test_time = datetime.time(hour = 20, minute = 0, second = 0, microsecond = 0)
    str_time = time_format.serialize(test_time)
    assert(str_time == "20:00:00")
 

# Generated at 2022-06-22 06:02:00.551819
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert isinstance(UUIDFormat(), UUIDFormat)

# Generated at 2022-06-22 06:02:02.014134
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    UUIDFormat()


# Generated at 2022-06-22 06:02:05.987893
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    """
    Test case for DateFormat serialize method
    """

    DateFormat_obj = DateFormat()
    test_obj = datetime.date(2020, 5, 11)
    assert isinstance(test_obj, datetime.date)
    test_output = DateFormat_obj.serialize(test_obj)
    assert test_output == '2020-05-11'

# Generated at 2022-06-22 06:02:10.116802
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate('550e8400-e29b-41d4-a716-446655440000')


# Generated at 2022-06-22 06:02:14.725288
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    f = BaseFormat()
    assert not f.is_native_type(None)
    assert not f.is_native_type(123)
    assert not f.is_native_type('abc')


# Generated at 2022-06-22 06:02:22.752936
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("12:01") == datetime.time(12, 1)
    assert time.validate('12:01:01') == datetime.time(12, 1, 1)
    assert time.validate('12:01:01.000001') == datetime.time(12, 1, 1, 1)
    # matches the first 6 characters
    assert time.validate('12:01:01.123456789') == datetime.time(12, 1, 1, 123456)
    # assert time.validate('12:01:01.123456789').replace(microsecond=123456) == datetime.time(12, 1, 1, 123456)

# Generated at 2022-06-22 06:02:28.556616
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    native_test_1 = datetime.datetime(2020, 3, 1, 15, 23)
    native_test_2 = datetime.datetime(2021, 4, 2, 16, 24)
    assert DateTimeFormat().is_native_type(native_test_1) == True and DateTimeFormat().is_native_type(native_test_2) == True


# Generated at 2022-06-22 06:02:30.526437
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime) == True


# Generated at 2022-06-22 06:02:31.951902
# Unit test for constructor of class DateFormat
def test_DateFormat():
    df = DateFormat()
    print(df)


# Generated at 2022-06-22 06:02:44.111679
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj1 = datetime.date(2019,12,31)
    obj2 = datetime.date(2022,12,31)
    obj3 = datetime.date(2020,12,31)
    obj4 = datetime.date(2021,12,31)
    obj5 = datetime.date(2023,12,31)
    obj6 = datetime.date(2024,12,31)
    obj7 = datetime.date(2025,12,31)
    obj8 = datetime.date(2026,12,31)
    obj9 = datetime.date(2027,12,31)
    obj10 = datetime.date(2028,12,31)
    obj11 = datetime.date(2029,12,31)

# Generated at 2022-06-22 06:02:59.079385
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Arrange
    date_format = DateFormat()
    valid_date = datetime.date(2020, 4, 15)
    invalid_date = '2020-01-03'

    # Act
    value1 = date_format.serialize(valid_date)
    value2 = date_format.serialize(invalid_date)
    # Assert
    assert value1 == '2020-04-15'
    assert value2 is None


# Generated at 2022-06-22 06:03:02.845447
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.datetime(2020, 1, 1, 12, 0, 0, 0)
    assert TimeFormat().serialize(obj) == '12:00:00'
    assert TimeFormat().serialize(None) == None


# Generated at 2022-06-22 06:03:09.479771
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    f = UUIDFormat()
    s = f.serialize(uuid.UUID('42ab0af7-9b00-4d13-9c45-a0fd878c10d1'))
    assert s == '42ab0af7-9b00-4d13-9c45-a0fd878c10d1'


# Generated at 2022-06-22 06:03:13.531912
# Unit test for constructor of class DateFormat
def test_DateFormat():
    astring = "2019-01-02"
    dateFormat = DateFormat()
    assert dateFormat.validate(astring) == datetime.date(2019,1,2)



# Generated at 2022-06-22 06:03:20.600777
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    is_native_type = DateTimeFormat().is_native_type
    assert not is_native_type(None)
    assert not is_native_type("")
    assert not is_native_type(10)
    assert not is_native_type(datetime.date(2020, 1, 1))
    assert not is_native_type(datetime.time(12, 0, 0))
    assert is_native_type(datetime.datetime(2020, 1, 1, 12, 0, 0))


# Generated at 2022-06-22 06:03:25.191341
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    my_date_class = DateFormat()
    assert my_date_class.is_native_type(datetime.date(2019, 8, 20))
    assert not my_date_class.is_native_type(datetime.date(2019, 8, 21))


# Generated at 2022-06-22 06:03:34.475423
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    from typesystem.base import Message
    from typesystem.base import Field
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Array
    from typesystem.fields import Dict
    from typesystem.fields import DateTime
    from datetime import datetime, timedelta
    from typesystem.base import OutgoingType
    class Person(OutgoingType):
        name = String()
        age = Integer(minimum=1)
        registered = DateTime()

    person = Person(name="name", age=1, registered=datetime.now() + timedelta(hours=2))

    assert isinstance(person.serialize(), dict)

# Generated at 2022-06-22 06:03:39.654461
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    #Given
    value = datetime.datetime(2020,  6,  18,  18,  1,  2,  3,  tzinfo=None)
    value_cls = DateTimeFormat()
    #When
    result = value_cls.is_native_type(value)
    #Then
    assert result == True


# Generated at 2022-06-22 06:03:50.776846
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format=UUIDFormat()
    print(uuid_format.validate("faa959e9-b9d8-4346-b2c5-0a27a1d49775"))
    print(uuid_format.validate("faa959e9-b9d8-4346-b2c5-0a27a1d4977f"))
    # print(uuid_format.validate("faa959e9b9d84346b2c50a27a1d49775"))
    # print(uuid_format.validate("faa959e9-b9d8-4346-b2c5-0a27a1d49775-b2c5-0a27a1d49775"))

# Generated at 2022-06-22 06:03:54.464810
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
	try:
		BaseFormat.validate()
		assert False, "This code should not be executed"
	except NotImplementedError:
		pass
		

# Generated at 2022-06-22 06:04:13.876435
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Scenario 1:
    try:
        value_1 = '2022-05-30T10:00:00.000000Z'
        dt_1 = DateTimeFormat().validate(value_1)
        assert dt_1.isoformat() == '2022-05-30T10:00:00+00:00'
    except Exception as e:
        print('Fail in DateTimeFormat_validate() - scenario 1:', e)
        pass

    # Scenario 2:

# Generated at 2022-06-22 06:04:23.131061
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("6c84fb90-12c4-11e1-840d-7b25c5ee775a") == uuid.UUID("6c84fb90-12c4-11e1-840d-7b25c5ee775a")
    assert uuid_format.validate("6c84fb90-12c4-11e1-840d-7b25c5ee775a") != "6c84fb90-12c4-11e1-840d-7b25c5ee775a"


# Generated at 2022-06-22 06:04:28.490708
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = '2020-04-22'
    date_format = DateFormat()
    date_obj = date_format.validate(date)
    assert isinstance(date_obj, datetime.date)


# Generated at 2022-06-22 06:04:30.697954
# Unit test for constructor of class DateFormat
def test_DateFormat():
    df = DateFormat()
    assert df != None


# Generated at 2022-06-22 06:04:32.385187
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    a = BaseFormat()
    assert not a.is_native_type(1)


# Generated at 2022-06-22 06:04:35.802226
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4()) == True



# Generated at 2022-06-22 06:04:38.656891
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_format = TimeFormat()
    assert time_format.errors == {"format": "Must be a valid time format.", "invalid": "Must be a real time."}

# Generated at 2022-06-22 06:04:41.429489
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    times = [datetime.time()]

    time = TimeFormat()

    assert time.is_native_type(times[0])

# Generated at 2022-06-22 06:04:46.918905
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeVal=DateTimeFormat()
    dateTimeVal.validate("2018-12-31T23:59:59Z")


# Generated at 2022-06-22 06:04:48.390954
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat()

# Generated at 2022-06-22 06:05:09.786879
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert str(UUIDFormat().serialize("3c6e0b8a-9c5a-47ea-b478-6b67c5b08ef1")) == "3c6e0b8a-9c5a-47ea-b478-6b67c5b08ef1"



# Generated at 2022-06-22 06:05:14.847314
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uid = uuid.UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')
    result = UUIDFormat().serialize(uid)
    assert result == 'f47ac10b-58cc-4372-a567-0e02b2c3d479'

# Generated at 2022-06-22 06:05:19.207552
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("2019-12-01") == datetime.date(2019, 12, 1)

# Generated at 2022-06-22 06:05:21.944058
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    x = uuid.uuid4()
    assert isinstance(x, uuid.UUID)
    assert UUIDFormat().is_native_type(x)


# Generated at 2022-06-22 06:05:23.952725
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():

    t1 = DateTimeFormat()
    assert isinstance(t1, BaseFormat)

# Generated at 2022-06-22 06:05:27.503885
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    time_format = DateTimeFormat()
    assert time_format.errors == {
        "format": "Must be a valid datetime format.",
        "invalid": "Must be a real datetime.",
    }


# Generated at 2022-06-22 06:05:28.813057
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat() is not None


# Generated at 2022-06-22 06:05:31.384425
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    date = '2020-08-05'
    assert date_format.is_native_type(date) is False


# Generated at 2022-06-22 06:05:38.075287
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    result = date.validate('2020-02-22')
    assert result == datetime.date(2020, 2, 22)


# Generated at 2022-06-22 06:05:41.589340
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert str(TimeFormat().validate('00:00:00.000000')) == '00:00:00'
    # assert TimeFormat().validate('00:00:00.000000') == datetime.time(0, 0)

# Generated at 2022-06-22 06:06:30.690803
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()

    today = datetime.date.today()
    assert str(format.validate(today.isoformat())) == str(today)
    

# Generated at 2022-06-22 06:06:39.983781
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    date_time_format = DateTimeFormat()
    date_time = datetime.datetime(2019, 9, 26, 4, 5, 6, 7, tzinfo=datetime.timezone.utc)
    assert date_time_format.is_native_type(date_time) == True
    date = datetime.date(2019, 9, 26)
    assert date_time_format.is_native_type(date) == False
    time = datetime.time(4, 5, 6)
    assert date_time_format.is_native_type(time) == False


# Generated at 2022-06-22 06:06:43.251418
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate('01:02') == datetime.time(1,2)


# Generated at 2022-06-22 06:06:46.747330
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    assert df.is_native_type(datetime.date.today()) == True
    assert df.is_native_type('2020-10-12') == False
    return True


# Generated at 2022-06-22 06:06:49.582359
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    date = datetime.date(2019, 12, 28)
    assert date_format.serialize(date) == '2019-12-28'

# Generated at 2022-06-22 06:06:50.408619
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    a = BaseFormat()

# Generated at 2022-06-22 06:06:54.431338
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    date_time_format = DateTimeFormat()
    assert date_time_format.is_native_type(datetime.datetime.now()) is True
    assert date_time_format.is_native_type(datetime.date.today()) is False
    assert date_time_format.is_native_type(datetime.datetime.utcnow()) is True



# Generated at 2022-06-22 06:07:02.723378
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    is_native_type = DateTimeFormat().is_native_type
    assert is_native_type(datetime.datetime(2019, 10, 11, 12, 34, 45))
    assert not is_native_type(datetime.date(2019, 10, 11))
    assert not is_native_type(datetime.time(12, 34, 45))
    assert not is_native_type(datetime.timedelta(days=10))
    assert not is_native_type("2019-10-11")
    assert not is_native_type("2019-10-11T12:34:45Z")

