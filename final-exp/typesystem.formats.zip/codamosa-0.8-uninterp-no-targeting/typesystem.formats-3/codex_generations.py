

# Generated at 2022-06-22 05:57:18.486084
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuidfmt = UUIDFormat()
    try:
        assert uuidfmt.validate('0123456789abcdef0123456789abcdef') is not None
    except Exception as ex:
        print(ex)
    try:
        uuidfmt.validate('1-2345-6789')
    except Exception as ex:
        assert str(ex) == 'Must be valid UUID format.'
    try:
        uuidfmt.validate('0123456789abcdef0123456789abcdef0')
    except Exception as ex:
        assert str(ex) == 'Must be valid UUID format.'

# Generated at 2022-06-22 05:57:20.953032
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    from typesystem.base import Format

    # TimeFormat()
    # assert TimeFormat().is_native_type(datetime.now())
    # assert TimeFormat().is_native_type(datetime.now().time())

# Generated at 2022-06-22 05:57:21.999106
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    format = TimeFormat()
    format.serialize(None) == None

# Generated at 2022-06-22 05:57:24.655379
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
  with raises(NotImplementedError):
    BaseFormat().validate('../')


# Generated at 2022-06-22 05:57:30.551827
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 8, 31)
    assert DateFormat().serialize(date) == "2020-08-31"


# Generated at 2022-06-22 05:57:32.145443
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat()


# Generated at 2022-06-22 05:57:35.579997
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        BaseFormat().validate(None)


# Generated at 2022-06-22 05:57:42.163811
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class Base_Format(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return True
        
        def serialize(self, obj: typing.Any) -> typing.Union[str, None]:
            return str(obj)

    x = Base_Format()
    assert x.serialize(1) == '1'

# Generated at 2022-06-22 05:57:45.597589
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    test_format = BaseFormat()
    try:
        test_format.validate("")
    except NotImplementedError:
        return True
    else:
        return False


# Generated at 2022-06-22 05:57:56.303056
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert None == UUIDFormat().serialize(None)
    assert "00000000-0000-0000-0000-000000000000" == UUIDFormat().serialize(UUIDFormat().validate("00000000-0000-0000-0000-000000000000"))
    assert "6628831a-cbd7-40d9-aa4c-4b4c4f4b4e4f" == UUIDFormat().serialize(UUIDFormat().validate("6628831a-cbd7-40d9-aa4c-4b4c4f4b4e4f"))

# Generated at 2022-06-22 05:58:11.290439
# Unit test for method validate of class TimeFormat

# Generated at 2022-06-22 05:58:18.626002
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    UUID_1 = "3a794884-08ea-42b7-b6d4-525cc13198f8"
    UUID_2 = "3a794884-08ea-42b7-b6d4-525cc13198f8z"
    assert UUIDFormat().validate(UUID_1) == uuid.UUID(UUID_1)
    try:
        UUIDFormat().validate(UUID_2)
    except ValidationError:
        assert True
    else:
        assert False



# Generated at 2022-06-22 05:58:20.030161
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert isinstance(UUIDFormat(),BaseFormat)


# Generated at 2022-06-22 05:58:26.524243
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    str = '2018-09-04T23:17:39.892965Z'
    t = DateTimeFormat()
    a = t.is_native_type(str)
    b = t.validate(str)
    c = t.serialize(str)
    assert a == False
    assert b == datetime.datetime(2018,9,4,23,17,39,892965,datetime.timezone.utc)
    assert c == str

# Generated at 2022-06-22 05:58:36.606654
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    def test_valid_date_time(string, kwargs):
        date_time = DateTimeFormat()
        dt = date_time.validate(string)
        assert dt == datetime.datetime(**kwargs)

    test_valid_date_time("2018-1-1T1:1:1Z", {"year": 2018, "month": 1, "day": 1, "hour": 1, "minute": 1, "second": 1, "tzinfo": datetime.timezone.utc})
    test_valid_date_time("2018-1-1T1:1Z", {"year": 2018, "month": 1, "day": 1, "hour": 1, "minute": 1, "second": 0, "tzinfo": datetime.timezone.utc})

# Generated at 2022-06-22 05:58:37.451163
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert isinstance(UUIDFormat(), UUIDFormat)



# Generated at 2022-06-22 05:58:38.521431
# Unit test for constructor of class DateFormat
def test_DateFormat():
    d = DateFormat()


# Generated at 2022-06-22 05:58:47.819745
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("00:00:00.000000") == datetime.time(0, 0, 0)
    assert TimeFormat().validate("00:00:00.999999") == datetime.time(0, 0, 0, 999999)
    assert TimeFormat().validate("00:00:00.999990") == datetime.time(0, 0, 0, 999999)
    assert TimeFormat().validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert TimeFormat().validate("12:34:56") == datetime.time(12, 34, 56)
    assert TimeFormat().validate("23:59") == datetime.time(23, 59)

# Generated at 2022-06-22 05:58:57.660629
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    value = "11:05:00.123456"
    assert time_format.validate(value) == datetime.time(hour=11, minute=5, second=0, microsecond=123456)
    value = "11:05:00"
    assert time_format.validate(value) == datetime.time(hour=11, minute=5, second=0)
    value = "11:05:00Z"
    assert time_format.validate(value) == datetime.time(hour=11, minute=5, second=0)
    value = "11:05:00+08:00"

# Generated at 2022-06-22 05:59:00.226026
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    assert BaseFormat().validate(6) == 6


# Generated at 2022-06-22 05:59:17.448032
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    # test 1
    value = "2019-12-31T23:59:59Z"
    dt = DateTimeFormat() 
    check = datetime.datetime(2019, 12, 31, 23, 59, 59, tzinfo=datetime.timezone.utc)
    assert dt.validate(value) == check


# Generated at 2022-06-22 05:59:20.138440
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    import datetime
    from typesystem.fields.datetime_formats import DateTimeFormat

    dt = datetime.datetime(2020, 7, 11, 20, 54, 4, 430015)
    fmt = DateTimeFormat()
    assert fmt.validate(fmt.serialize(dt)) == dt

    print('OK')

test_DateTimeFormat()

# Generated at 2022-06-22 05:59:21.482332
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()
    assert b 


# Generated at 2022-06-22 05:59:23.530380
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020, 2,29)
    assert Serialize(date) == "2020-02-29"


# Generated at 2022-06-22 05:59:33.458320
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate('2018-12-31T15:59:59') == datetime.datetime(2018, 12, 31, 15, 59, 59)
    assert DateTimeFormat().validate('2018-12-31T15:59:59.999999') == datetime.datetime(2018, 12, 31, 15, 59, 59, 999999)
    assert DateTimeFormat().validate('2018-12-31T15:59:59.99999') == datetime.datetime(2018, 12, 31, 15, 59, 59, 99999)
    assert DateTimeFormat().validate('2018-12-31T15:59:59.9999') == datetime.datetime(2018, 12, 31, 15, 59, 59, 9999)

# Generated at 2022-06-22 05:59:35.972181
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime.now()) == "2020-02-04T00:00:00"

# Generated at 2022-06-22 05:59:37.243828
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert isinstance(DateTimeFormat(), BaseFormat)

# Generated at 2022-06-22 05:59:47.600346
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    a = DateTimeFormat()
    assert a.serialize(datetime.datetime(
        2018, 3, 3, 3, 3, 3, tzinfo=datetime.timezone.utc)) == "2018-03-03T03:03:03Z"
    assert a.serialize(datetime.datetime(
        2018, 3, 3, 3, 3, 3, tzinfo=datetime.timezone(
            datetime.timedelta(hours=1, minutes=30)))) == "2018-03-03T03:03:03+01:30"
    assert a.serialize(None) is None

# Generated at 2022-06-22 05:59:52.943008
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    rst = TimeFormat()
    assert isinstance(rst, TimeFormat)


# Generated at 2022-06-22 06:00:00.463284
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("23:59:59.999999") == datetime.time(23, 59, 59, 999999)
    assert TimeFormat().validate("23:59:59.999999Z") == datetime.time(23, 59, 59, 999999)
    assert TimeFormat().validate("23:59:59") == datetime.time(23, 59, 59)
    assert TimeFormat().validate("23:59") == datetime.time(23, 59)


# Generated at 2022-06-22 06:00:10.263126
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize("f0e4c2f76c58916ec258f246851bea091d14d4247a2fc3e18694461b1816e13b") == "f0e4c2f76c58916ec258f246851bea091d14d4247a2fc3e18694461b1816e13b"

# Generated at 2022-06-22 06:00:16.019146
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    with pytest.raises(ValidationError):
        DateFormat().validate("2019-01-20")



# Generated at 2022-06-22 06:00:24.571140
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Method validate of class DateTimeFormat does not raise a ValidationError if the value is datetime.datetime
    value_1 = datetime.datetime.now()
    assert DateTimeFormat().validate(value_1) == value_1

    # Method validate of class DateTimeFormat raises a ValidationError if the value is not datetime.datetime
    value_2 = "17-11-1994"
    try:
        DateTimeFormat().validate(value_2)
    except ValidationError:
        pass
    else:
        raise ValueError("Method validate of class DateTimeFormat does not raise a ValidationError")

# Integration test for method serialize of class DateTimeFormat

# Generated at 2022-06-22 06:00:26.598394
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time())



# Generated at 2022-06-22 06:00:29.193240
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    # Test 1: Has validation_error method
    base_format = BaseFormat()

    with pytest.raises(NotImplementedError):
        base_format.validate('value')


# Generated at 2022-06-22 06:00:34.519971
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    native_type = uuid.UUID("{12345678-1234-5678-1234-567812345678}")
    non_native_type = 1
    assert UUIDFormat().is_native_type(native_type) == True
    assert UUIDFormat().is_native_type(non_native_type) == False


# Generated at 2022-06-22 06:00:39.722134
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time(11, 11, 11)
    tf = TimeFormat()
    res = tf.serialize(obj)
    assert res == "11:11:11"
    obj = datetime.time(11, 11)
    res = tf.serialize(obj)
    assert res == "11:11:00"


# Generated at 2022-06-22 06:00:46.786640
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.UUID('12345678-1234-5678-1234-567812345678')) == True
    assert UUIDFormat().is_native_type('12345678-1234-5678-1234-567812345678') == False



# Generated at 2022-06-22 06:00:53.038919
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    uuid_value = '16fd2706-8baf-433b-82eb-8c7fada847da'
    assert uuid_format.serialize(uuid_value) == uuid_value

# Generated at 2022-06-22 06:00:56.478009
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    try:
        b = BaseFormat()
        b.validate('abc')
    except NotImplementedError:
        pass
    else:
        assert False, 'BaseFormat.validate() not raise NotImplementedError'


# Generated at 2022-06-22 06:01:00.565843
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat()


# Generated at 2022-06-22 06:01:04.625882
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    d = datetime.datetime(2017, 2, 13)
    assert DateTimeFormat().serialize(d) == "2017-02-13T00:00:00"

# Generated at 2022-06-22 06:01:15.903785
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    DateF = DateFormat()
    with pytest.raises(ValidationError) as e_info:
        DateF.validate(value="2019-12-32")
    assert e_info.type == ValidationError
    assert e_info.value.text == "Must be a valid date format."
    assert e_info.value.code == "format"

    with pytest.raises(ValidationError) as e_info:
        DateF.validate(value="2019-13-12")
    assert e_info.type == ValidationError
    assert e_info.value.text == "Must be a real date."
    assert e_info.value.code == "invalid"

    assert DateF.validate(value="2019-11-30") == datetime.date(2019, 11, 30)


# Unit test

# Generated at 2022-06-22 06:01:19.594566
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():

    formatertest = DateTimeFormat()
    assert formatertest.validate(datetime.datetime(2011, 11, 11, 11, 11, 11, 11)) == datetime.datetime(2011, 11, 11, 11, 11, 11, 11)

# Generated at 2022-06-22 06:01:27.717508
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidformat = UUIDFormat()
    assert uuidformat.validate("b5e2ef49-77cd-4cdd-8526-e7f3e3ea4d2e") == uuid.UUID("b5e2ef49-77cd-4cdd-8526-e7f3e3ea4d2e")



# Generated at 2022-06-22 06:01:30.679606
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuidfmt = UUIDFormat()
    try:
        assert not uuidfmt.is_native_type('1234-1234-1234')
    finally:
        del uuidfmt


# Generated at 2022-06-22 06:01:31.810913
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2019-07-31") == datetime.date(2019, 7, 31)



# Generated at 2022-06-22 06:01:35.689716
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    a = datetime.datetime.now()
    b = datetime.date.today()
    f = DateTimeFormat()
    assert f.is_native_type(a) == True
    assert f.is_native_type(b) == False


# Generated at 2022-06-22 06:01:36.648007
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert UUIDFormat().__init__() == None

# Generated at 2022-06-22 06:01:40.085190
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert (DateFormat.errors == {'format': 'Must be a valid date format.', 'invalid': 'Must be a real date.'})

test_DateFormat()



# Generated at 2022-06-22 06:01:44.337802
# Unit test for constructor of class DateFormat
def test_DateFormat():
    test = DateFormat()
    assert test



# Generated at 2022-06-22 06:01:48.904451
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date.today())
    assert TimeFormat().is_native_type(datetime.time(0, 0))
    assert DateTimeFormat().is_native_type(datetime.datetime(2019, 1, 1))
    assert UUIDFormat().is_native_type(uuid.uuid4())

# Generated at 2022-06-22 06:01:50.402339
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    format = UUIDFormat()
    assert format is not None

# Generated at 2022-06-22 06:01:55.420631
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == 1
    assert DateTimeFormat().is_native_type(datetime.date.today()) != 1



# Generated at 2022-06-22 06:01:58.505518
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    obj = datetime.datetime.now()
    value = date_time_format.serialize(obj)
    assert isinstance(value, str)


# Generated at 2022-06-22 06:01:59.413400
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    return 


# Generated at 2022-06-22 06:02:00.587971
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat()


# Generated at 2022-06-22 06:02:05.315047
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time(hour=10, minute=10, second=10)
    format = TimeFormat()
    assert format.serialize(obj) == "10:10:10"
    assert format.serialize(None) == None

# Generated at 2022-06-22 06:02:16.125538
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    fmt = TimeFormat()
    assert fmt.validate("01:00:01.101010") == datetime.time(1, 0, 1, 101010)
    fmt = TimeFormat()
    assert fmt.validate("01:00:01") == datetime.time(hour=1, minute=0, second=1)
    fmt = TimeFormat()
    assert fmt.validate("01:00") == datetime.time(hour=1, minute=0)
    fmt = TimeFormat()
    assert fmt.validate("01") == datetime.time(hour=1)


# Generated at 2022-06-22 06:02:21.731843
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date = DateFormat()
    assert date.is_native_type(datetime.date(2020, 3, 5))
    assert not date.is_native_type(datetime.time(2020, 3, 5))
    assert not date.is_native_type(datetime.datetime(2020, 3, 5))
    assert not date.is_native_type(uuid.uuid4())


# Generated at 2022-06-22 06:02:35.669435
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(uuid.uuid4())
    assert not uuid_format.is_native_type('5b5e8b5d-7c20-4a51-b876-8d61e7ac2d49')
    assert not uuid_format.is_native_type([])
    assert not uuid_format.is_native_type({})
    assert not uuid_format.is_native_type(True)
    assert not uuid_format.is_native_type(0.0)
    assert not uuid_format.is_native_type(0)
    assert not uuid_format.is_native_type(datetime.datetime.now())
    assert not uuid_format.is_native_type

# Generated at 2022-06-22 06:02:40.280639
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    fmt = TimeFormat()
    assert fmt.is_native_type(datetime.datetime.now().time())
    assert fmt.is_native_type(datetime.time())


# Generated at 2022-06-22 06:02:51.968963
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    # Integer Type
    assert (not UUIDFormat().is_native_type(123))
    # Long Type

# Generated at 2022-06-22 06:02:54.042484
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    b = BaseFormat()
    assert b.serialize(None) == None

# Generated at 2022-06-22 06:02:57.023422
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    timeFormat_test_obj = TimeFormat()
    assert timeFormat_test_obj.is_native_type(datetime.time()) == True


# Generated at 2022-06-22 06:02:59.940263
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    bf = BaseFormat()
    with pytest.raises(NotImplementedError):
        bf.is_native_type("")


# Generated at 2022-06-22 06:03:09.633186
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    # time_format.validate("08:21:05.567890")
    # time_format.validate("08:21:05.5678")
    time_format.validate("08:21:05")
    # time_format.validate("08:21:05.567890Z")
    time_format.validate("08:21")

    # time_format.validate("08:21:05.567890+00:00")
    # time_format.validate("08:21:05.5678+00:00")
    time_format.validate("08:21:05+00:00")
    time_format.validate("08:21+00:00")
    # time_format.validate("08:21:05.567890-

# Generated at 2022-06-22 06:03:12.389882
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    a = UUIDFormat()
    assert a.is_native_type(uuid.uuid4()) == True


# Generated at 2022-06-22 06:03:18.215325
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestFormat(BaseFormat):
        errors = {
            "format": "'{value}' must be a valid format.",
            "invalid": "Must be a real value.",
        }
    assert TestFormat().validation_error("format").text == "'{value}' must be a valid format."
    assert TestFormat().validation_error("format").code == 'format'


# Generated at 2022-06-22 06:03:29.538616
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_format.validate("e3890a62-6eec-4515-8c09-977d7e62a3c3")
    uuid_format.validate("6ba7b810-9dad-11d1-80b4-00c04fd430c8")
    uuid_format.validate("6ba7b811-9dad-11d1-80b4-00c04fd430c8")

    with pytest.raises(ValidationError, match="Must be valid UUID format."):
        uuid_format.validate("e3890a62-6eea-4515-8c09-977d7e62a3c3")

# Generated at 2022-06-22 06:03:38.581821
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    t = TimeFormat()
    assert t.errors == {
        "format": "Must be a valid time format.",
        "invalid": "Must be a real time.",
    }

# Generated at 2022-06-22 06:03:42.844826
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    d = DateTimeFormat()
    #print(d)
    #print(d.errors)
    #print(d.validation_error("format"))
    assert d.validate('20-11-2019') == "20-11-2019"

# Generated at 2022-06-22 06:03:49.622649
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base_format = BaseFormat()
    base_format.errors = {
        "format": "Must be a valid date format.",
        "invalid": "Must be a real date.",
    }

    assert(base_format.validation_error("format").code == "format" 
            and base_format.validation_error("format").text == "Must be a valid date format.")


# Generated at 2022-06-22 06:03:54.405249
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    from datetime import time
    from typesystem.format import TimeFormat
    
    
    # Create a TimeFormat object
    time_format = TimeFormat()
    
    # Check object
    assert isinstance(time_format, TimeFormat)


# Generated at 2022-06-22 06:03:57.063929
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    value = "754460c1-7b4e-4f40-b755-dac09c37a68a"
    assert UUIDFormat().serialize(value) == value

# Generated at 2022-06-22 06:04:00.298257
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u = UUIDFormat()
    assert u.validate("12345678-1234-5678-1234-567812345678") == uuid.UUID("12345678-1234-5678-1234-567812345678")
    return "test passed"

# Generated at 2022-06-22 06:04:01.832740
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    base_format = BaseFormat()
    assert base_format.is_native_type(None) == False


# Generated at 2022-06-22 06:04:05.131998
# Unit test for constructor of class DateFormat
def test_DateFormat():
    dateformat = DateFormat()
    assert dateformat.validate("2019-06-11") == datetime.date(2019,6,11)


# Generated at 2022-06-22 06:04:08.380997
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
  
  try:
    validTest = TimeFormat()
  except NotImplementedError:
    print("Test #1 passed, default TimeFormat constructor should not be implemented")


# Generated at 2022-06-22 06:04:13.136934
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    input_DateFormat_1 = DateFormat()
    expect_DateFormat_1 = "2020-08-30"
    actual_DateFormat_1 = input_DateFormat_1.serialize(datetime.date(2020, 8, 30))
    assert expect_DateFormat_1 == actual_DateFormat_1


# Generated at 2022-06-22 06:04:33.221060
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid1 = uuid.uuid4()
    uuid2 = uuid.uuid4()
    uuid3 = uuid.uuid4()
    uuid4 = uuid.uuid4()
    obj1 = UUIDFormat()
    assert obj1.is_native_type(uuid1) == True
    assert obj1.is_native_type(uuid2) == True
    assert obj1.is_native_type(uuid3) == True
    assert obj1.is_native_type(uuid4) == True


# Generated at 2022-06-22 06:04:37.049588
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    assert tf.serialize(None) == None
    dt = datetime.time()
    assert tf.serialize(dt) == dt.isoformat()


# Generated at 2022-06-22 06:04:48.399240
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
  dtf = DateTimeFormat()
  assert dtf.is_native_type(datetime.datetime(2020,7,13,13,0,0,0)) # True
  assert dtf.is_native_type(datetime.date(2020,7,13)) # False
  assert dtf.is_native_type(datetime.time(13,0,0,0)) # False

  assert dtf.validate("2020-07-13T13:00:00+00:00") == datetime.datetime(2020,7,13,13,0,0,0)
  assert dtf.validate("2020-07-13T13:00:00Z") == datetime.datetime(2020,7,13,13,0,0,0)

# Generated at 2022-06-22 06:04:51.079384
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2020-01-01")
    assert date == datetime.date(2020, 1, 1)


# Generated at 2022-06-22 06:04:55.572545
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    assert datetime_format.validate('2020-02-09T23:22:35.141414+00:00') == datetime.datetime(2020, 2, 9, 23, 22, 35, 141414, tzinfo=datetime.timezone.utc)



# Generated at 2022-06-22 06:05:04.371926
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()

    # Unit test for case with seconds and microseconds
    time = '14:25:54.001'
    assert tf.validate(time) == datetime.time(14, 25, 54, 1000)

    # Unit test for case with seconds only
    time = '14:25:54'
    assert tf.validate(time) == datetime.time(14, 25, 54)

    # Unit test for case without seconds
    time = '14:25'
    assert tf.validate(time) == datetime.time(14, 25)

test_TimeFormat_validate()

# Generated at 2022-06-22 06:05:06.088808
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True


# Generated at 2022-06-22 06:05:08.481434
# Unit test for constructor of class DateFormat
def test_DateFormat():
  df = DateFormat()
  assert df is not None
  

# Generated at 2022-06-22 06:05:10.885784
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    t = TimeFormat()
    assert t.serialize(datetime.datetime.now().time()) is not None


# Generated at 2022-06-22 06:05:16.520918
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    test = DateTimeFormat()
    test.is_native_type(datetime.datetime(1970, 1, 1)) == True
    test.validate('1970-01-01T00:00:00+00:00') == datetime.datetime(1970, 1, 1)
    test.validate('1970-01-01T00:00:00') == datetime.datetime(1970, 1, 1)
    test.serialize('1970-01-01T00:00:00+00:00') == '1970-01-01T00:00:00Z'

test_DateTimeFormat()

# Generated at 2022-06-22 06:05:33.700880
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    B = BaseFormat()
    with pytest.raises(NotImplementedError) as e:
        B.serialize(None)
        assert 'NotImplementedError' in str(e)



# Generated at 2022-06-22 06:05:36.393984
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date.today()) == True


# Generated at 2022-06-22 06:05:41.683111
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    import datetime as dt
    Date = DateFormat()
    b = Date.validate('2000-12-31')
    assert b == dt.date(2000,12,31)
    with pytest.raises(ValidationError):
        Date.validate('2000-13-31')
    
    

# Generated at 2022-06-22 06:05:44.427007
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date.today())
    assert not DateFormat().is_native_type('1991-08-12')


# Generated at 2022-06-22 06:05:47.687418
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtf = DateTimeFormat()
    assert dtf.is_native_type(datetime.datetime(2019, 11, 20))
    assert not dtf.is_native_type(datetime.time(10, 11))


# Generated at 2022-06-22 06:05:51.109900
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dformat = DateFormat()
    value = '2020-01-01'
    d = dformat.validate(value)
    assert(value==d.isoformat())


# Generated at 2022-06-22 06:05:54.540331
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate("12:00:00") == datetime.time(12, 0)
    assert tf.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)

# Generated at 2022-06-22 06:05:59.015120
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    d = DateTimeFormat()
    assert(isinstance(d, DateTimeFormat))


# Generated at 2022-06-22 06:06:01.656970
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize("Banana") == "Banana"


# Generated at 2022-06-22 06:06:09.171336
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Test the validation of a valid time format '09:30:59'
    format = TimeFormat()
    time = format.validate('09:30:59')
    expected_time = datetime.time(9, 30, 59)
    assert time == expected_time

    # Test the validation of an invalid time format '09:30:66'
    with pytest.raises(ValidationError):
        format.validate('09:30:66')


# Generated at 2022-06-22 06:06:33.020813
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    value = "15:51"
    time = time_format.validate(value)
    assert time == datetime.time(15, 51)

    value = "15:51:11"
    time = time_format.validate(value)
    assert time == datetime.time(15, 51, 11)

    value = "15:51:11.11"
    time = time_format.validate(value)
    assert time == datetime.time(15, 51, 11, 110000)

    value = "15:51:11.1111"
    time = time_format.validate(value)
    assert time == datetime.time(15, 51, 11, 111100)

    value = "15:51:11.1111111"

# Generated at 2022-06-22 06:06:34.810726
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert isinstance(DateFormat(), DateFormat)


# Generated at 2022-06-22 06:06:35.983189
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert UUIDFormat() is not None

# Generated at 2022-06-22 06:06:40.495529
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    UUID = UUIDFormat()
    assert UUID.is_native_type("7d3b03f3-7c04-4c4d-8e27-4c91e928b1c1") == False
    assert UUID.is_native_type(uuid.uuid4()) == True



# Generated at 2022-06-22 06:06:41.728331
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat


# Generated at 2022-06-22 06:06:45.209670
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.datetime(2018, 10, 1))
    assert not DateFormat().is_native_type(10)


# Generated at 2022-06-22 06:06:46.802979
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert repr(DateFormat().serialize(None)) == "None"


# Generated at 2022-06-22 06:06:50.020119
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_test = TimeFormat()
    assert time_test.errors['format'] == "Must be a valid time format."
    assert time_test.errors['invalid'] == "Must be a real time."


# Generated at 2022-06-22 06:06:52.822685
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    d = BaseFormat()
    try:
        d.is_native_type(3)
        assert False, "should have thrown an error"
    except NotImplementedError:
        pass
