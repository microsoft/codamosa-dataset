

# Generated at 2022-06-22 05:57:19.509488
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class BaseFormat(BaseFormat):
        errors = {
            "format": "Must be a valid date format.",
            "invalid": "Must be a real date.",
        }

    base_format = BaseFormat()

    assert base_format.validation_error("format").text == "Must be a valid date format."


# Generated at 2022-06-22 05:57:22.486661
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.utcnow())
    assert not DateTimeFormat().is_native_type("datetime.datetime.utcnow()")
    assert not DateTimeFormat().is_native_type(datetime.date.today())


# Generated at 2022-06-22 05:57:25.546512
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    a = BaseFormat()
    assert a.is_native_type(1) == False
    assert a.is_native_type(None) == True


# Generated at 2022-06-22 05:57:30.789554
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    test = DateFormat()
    a = datetime.date(2000, 12,26)

    assert test.serialize(a) == "2000-12-26"

# Generated at 2022-06-22 05:57:35.214335
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    obj = TimeFormat()
    assert isinstance(obj, TimeFormat)

# Function to test is_native_type method of class TimeFormat

# Generated at 2022-06-22 05:57:42.512068
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2006-10-25T15:26:27.000005") == datetime.datetime(2006, 10, 25, 15, 26, 27, 5, tzinfo=None)
    assert DateTimeFormat().validate("2006-10-25T15:26:27") == datetime.datetime(2006, 10, 25, 15, 26, 27, tzinfo=None)
    assert DateTimeFormat().validate("2006-10-25T15:26:27Z") == datetime.datetime(2006, 10, 25, 15, 26, 27, tzinfo=datetime.timezone.utc)



# Generated at 2022-06-22 05:57:48.458773
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    # Case 1 - Given value is an instance of datetime.date, it must return True
    value = datetime.datetime.now()
    assert DateTimeFormat().is_native_type(value)

    # Case 2 - Given value is not an instance of datetime.date, it must return False
    value = 'datetime(2020, 4, 28, 10, 0, 0)'
    assert DateTimeFormat().is_native_type(value) == False

# Generated at 2022-06-22 05:57:50.208330
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(1) == False
    assert DateFormat().is_native_type('example') == False
    assert DateFormat().is_native_type(datetime.date.today()) == True


# Generated at 2022-06-22 05:57:58.516377
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    from typesystem import UUID
    uuidFormat = UUIDFormat()
    obj = "bb683a36-fc1c-11e9-9bbf-00163e0c3d3b"
    assert uuidFormat.serialize(obj) == "bb683a36-fc1c-11e9-9bbf-00163e0c3d3b"
    

# Generated at 2022-06-22 05:58:04.060587
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    
    # Init
    date_time_format = DateTimeFormat()
    
    # Test 1
    assert date_time_format.is_native_type(datetime.datetime.now()) == True

    # Test 2
    assert date_time_format.is_native_type(datetime.date(2019, 3, 16)) == False
    assert date_time_format.is_native_type(datetime.time(23, 9, 59)) == False
    assert date_time_format.is_native_type(12345) == False


# Generated at 2022-06-22 05:58:12.038893
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    assert tf.is_native_type("00:00:01") == False


# Generated at 2022-06-22 05:58:22.865909
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    '''
    This method will test the functionality of the validate method of the DateTimeFormat class.
    '''
    # testing timezone no change
    time_to_test = "2020-03-28T09:30:00"
    DateTimeFormat().validate(time_to_test)
    # testing timezone change
    time_to_test = "2020-03-28T09:30:00+00:00"
    DateTimeFormat().validate(time_to_test)
    # testing if method raises error
    # testing if method raises error
    time_to_test = "2020-03-29T09:30:00"
    # testing if method raises error

# Generated at 2022-06-22 05:58:25.736539
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    assert (tf.is_native_type(datetime.time(12,13,14))) == True


# Generated at 2022-06-22 05:58:36.124472
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert DateFormat.is_native_type(DateFormat(),datetime.datetime.now().date())
    assert not DateFormat.is_native_type(DateFormat(),datetime.datetime.now())
    assert TimeFormat.is_native_type(TimeFormat(),datetime.datetime.now().time())
    assert not TimeFormat.is_native_type(TimeFormat(),datetime.datetime.now())
    assert DateTimeFormat.is_native_type(DateTimeFormat(),datetime.datetime.now())
    assert not DateTimeFormat.is_native_type(DateTimeFormat(),datetime.date.today())
    assert UUIDFormat.is_native_type(UUIDFormat(),uuid.uuid1())
    assert not UUIDFormat.is_native_type(UUIDFormat(),datetime.datetime.now())



# Generated at 2022-06-22 05:58:40.304814
# Unit test for constructor of class DateFormat
def test_DateFormat():
    today = datetime.date.today()
   
    # Test for working of __init__()
    df = DateFormat()
    assert df.errors == {"format": "Must be a valid date format.", "invalid": "Must be a real date."}


# Generated at 2022-06-22 05:58:41.322996
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert UUIDFormat()


# Generated at 2022-06-22 05:58:42.562886
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None

# Generated at 2022-06-22 05:58:44.401400
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    b = BaseFormat()
    with pytest.raises(NotImplementedError):
        b.validate(3)


# Generated at 2022-06-22 05:58:49.004882
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base = BaseFormat()
    assert type(base) == 'BaseFormat'


# Generated at 2022-06-22 05:58:52.136878
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2019, 12, 13)) is True
    assert DateFormat().is_native_type(datetime.datetime(2019, 12, 13, 1, 2, 3, 4)) is False


# Generated at 2022-06-22 05:59:01.232571
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    import datetime
    time = datetime.time(12, 14, 20)
    timeFormat = TimeFormat()
    assert timeFormat.serialize(time) == '12:14:20'


# Generated at 2022-06-22 05:59:03.943857
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    value = '13:22'
    assert time.validate(value) == datetime.time(13, 22, 0)

# Generated at 2022-06-22 05:59:06.364418
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    obj = uuid.UUID(int=0)
    UUIDFormat.is_native_type(obj)


# Generated at 2022-06-22 05:59:10.142637
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
	from datetime import datetime
	from typesystem import DateTimeFormat

	dt = datetime.now()
	format = DateTimeFormat()
	assert format.is_native_type(dt) == True


# Generated at 2022-06-22 05:59:14.446748
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()

    assert bf.errors == { "format": "Must be a valid date format.", "invalid": "Must be a real date."}
    assert bf.validation_error("format") == ValidationError(text="Must be a valid date format.", code="format")


# Generated at 2022-06-22 05:59:16.549784
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    instance = TimeFormat()
    res = instance.validate('12:33:31.454543')
    print(res)


# Generated at 2022-06-22 05:59:19.177812
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(17, 29, 31, 123456)
    assert TimeFormat().serialize(time) == "17:29:31.123456"

# Generated at 2022-06-22 05:59:22.485827
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    import datetime
    from typesystem.format import TimeFormat
    tf = TimeFormat()
    time = datetime.time(12, 30, 50)
    assert tf.is_native_type(time) == True


# Generated at 2022-06-22 05:59:25.591166
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Test serialize
    format = DateFormat()
    obj = datetime.date(2020, 1, 1)
    assert format.serialize(obj) == "2020-01-01"

    # Test None serialize
    assert format.serialize(None) == None

# Generated at 2022-06-22 05:59:27.991916
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = uuid.uuid1()
    uf = UUIDFormat()
    assert uf.serialize(obj) == str(obj)

# Generated at 2022-06-22 05:59:33.868330
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    base = BaseFormat()
    with pytest.raises(NotImplementedError):
        base.validate(None)


# Generated at 2022-06-22 05:59:35.286694
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4()) == True


# Generated at 2022-06-22 05:59:46.365075
# Unit test for constructor of class DateFormat
def test_DateFormat():
    d = DateFormat()
    assert d.is_native_type(datetime.date(2020,9,11))
    assert not d.is_native_type("Hello")
    assert d.errors == DateFormat.errors
    assert d.validation_error("format").text == "Must be a valid date format."
    assert d.validation_error("format").code == "format"
    assert d.validation_error("invalid").text == "Must be a real date."
    assert d.validation_error("invalid").code == "invalid"
    assert type(d.validate("2020-9-11")) == datetime.date
    assert d.serialize(datetime.date(2020,9,11)) == "2020-09-11"
    assert d.serialize(None) == None


# Generated at 2022-06-22 05:59:48.249394
# Unit test for constructor of class DateFormat
def test_DateFormat():
    a = DateFormat()
    b = DateFormat()
    assert a == b


# Generated at 2022-06-22 05:59:53.798477
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_obj = uuid.uuid4()
    uuid_format = UUIDFormat()
    assert (uuid_format.is_native_type(uuid_obj) == True)


# Generated at 2022-06-22 05:59:55.434088
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    return uuid_format

# Generated at 2022-06-22 05:59:58.832446
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(2019, 6, 3)
    assert DateFormat().serialize(obj) == "2019-06-03"

# Generated at 2022-06-22 06:00:07.126713
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    fmt = TimeFormat()
    x = fmt.is_native_type(datetime.time(12,34,56))
    assert x == True
    m = fmt.validate("12:34:56")
    assert m == datetime.time(12,34,56)
    n = fmt.serialize(datetime.time(12,34,56))
    assert n == "12:34:56"
    assert fmt.validate("12:34:56:12") == None


# Generated at 2022-06-22 06:00:11.216647
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    dateformat = DateFormat()
    assert dateformat.is_native_type(datetime.date.today()) == True
    assert dateformat.is_native_type(datetime.datetime.now()) == False


# Generated at 2022-06-22 06:00:14.195091
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    with pytest.raises(ValidationError):
        dtf.validate("2020-11-23T15:43:12.123456Z")

# Generated at 2022-06-22 06:00:18.969706
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert(BaseFormat().is_native_type(1) == True)


# Generated at 2022-06-22 06:00:23.168948
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format = DateTimeFormat()
    assert format.is_native_type(datetime.datetime(2016, 4, 30, 13, 38, 5, 948553))
    assert not format.is_native_type("2018-04-03 15:01:12")
    assert not format.is_native_type(None)



# Generated at 2022-06-22 06:00:34.843354
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    now = datetime.datetime(2020, 8, 10, 15, 20, 45)
    assert DateTimeFormat().validate('2020-08-10T15:20:45') == now
    assert DateTimeFormat().validate('2020-08-10T15:20:45Z') == now
    assert DateTimeFormat().validate('2020-08-10T15:20:45.000000') == now
    assert DateTimeFormat().validate('2020-08-10T15:20:45.000000Z') == now
    assert DateTimeFormat().validate('2020-08-10T15:20:45+00:00') == now
    assert DateTimeFormat().validate('2020-08-10T15:20:45+00:00.000000') == now

# Generated at 2022-06-22 06:00:42.211274
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()

# Generated at 2022-06-22 06:00:46.734505
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    test = TimeFormat()
    expected = datetime.time(11, 59, tzinfo=None)
    actual = test.validate("11:59")
    assert actual == expected


# Generated at 2022-06-22 06:00:49.238610
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    time_class = TimeFormat()
    native_time = datetime.time(12,0,0,0)
    outcome = time_class.is_native_type(native_time)
    assert outcome



# Generated at 2022-06-22 06:00:52.884128
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime.fromtimestamp(0, datetime.timezone.utc)).endswith("+00:00")



# Generated at 2022-06-22 06:01:01.369223
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 7, 12, 16, 35, 59, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-07-12T16:35:59Z"
    dt = datetime.datetime(2020, 7, 12, 16, 35, 59, 501000, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2020-07-12T16:35:59.501Z"
    dt = datetime.datetime(2020, 7, 12, 16, 35, 59, 501000, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))

# Generated at 2022-06-22 06:01:05.155488
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date = DateFormat()
validateErrors = [
    #Testing errors in line 12
    {"code": "format", "text": 'Must be a valid date format.'},
    {"code": "invalid", "text": 'Must be a real date.'}
]

# Generated at 2022-06-22 06:01:09.230149
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    obj = UUIDFormat()
    value = "78980c84-12f3-5d11-9e5d-c5a5a5c2b60a"
    assert obj.validate(value) == uuid.UUID(value)

# Generated at 2022-06-22 06:01:14.719077
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    date = datetime.date(2018, 6, 4)

    assert date_format.is_native_type(date) == True



# Generated at 2022-06-22 06:01:21.202001
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uf = UUIDFormat()
    serialized = uf.serialize(uuid.UUID("8c22b52d-60f1-4a54-b8c6-e5fe5e250149"))
    assert serialized == "8c22b52d-60f1-4a54-b8c6-e5fe5e250149"

# Generated at 2022-06-22 06:01:25.718537
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    date_time_format = DateTimeFormat()
    print(type(date_time_format))

# Generated at 2022-06-22 06:01:31.638057
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(2019, 1, 1)) == True
    assert date_format.is_native_type(datetime.date(2019, -1, 1)) == False



# Generated at 2022-06-22 06:01:34.349351
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d = datetime.date(2019, 11, 17)
    df = DateFormat()
    df.serialize(d)
    assert(True)


# Generated at 2022-06-22 06:01:40.477659
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidfmt = UUIDFormat()

    class MyUUID(uuid.UUID):
        pass

    myuuid = MyUUID()
    assert uuidfmt.is_native_type(myuuid) == True

# Generated at 2022-06-22 06:01:48.165941
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt1 = datetime.datetime(year=2019, month=4, day=23, hour=12, minute=34, second=56, tzinfo=datetime.timezone.utc)
    # dt2 = datetime.datetime(year=2019, month=4, day=23, hour=12, minute=34, second=56, tzinfo=datetime.timezone(timedelta(hours=7)))
    dtf = DateTimeFormat()
    assert dtf.serialize(dt1) == "2019-04-23T12:34:56Z"

# Generated at 2022-06-22 06:01:51.865737
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    new_obj = datetime.datetime(year=2020, month=8, day=17, tzinfo=datetime.timezone.utc)
    dtf = DateTimeFormat()
    assert str(new_obj) == "2020-08-17 00:00:00+00:00"
    assert dtf.serialize(new_obj) == "2020-08-17T00:00:00+00:00"



# Generated at 2022-06-22 06:01:57.899056
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base = BaseFormat()
    base.errors = {"format": "error"}
    base.__dict__ = {"a": 1, "b": 2}
    # assert value
    assert(base.validation_error("format") == ValidationError(text="error", code="format"))
    

# Generated at 2022-06-22 06:02:05.310887
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date = datetime.date(2000, 1, 1)
    date_format = DateFormat()
    assert date_format.is_native_type(date) == True
    assert date_format.is_native_type("2000-01-01") == False


# Generated at 2022-06-22 06:02:11.996729
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    x = UUIDFormat()
    assert x.is_native_type(uuid.uuid4())
    assert x.is_native_type(uuid.uuid1())



# Generated at 2022-06-22 06:02:24.565465
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    # Test UUIDFormat.validate with a well-formatted UUID string
    uuid_str = "1ef878c0-b30c-4e89-8986-22f31b5e5368"
    assert UUIDFormat().validate(uuid_str) == uuid.UUID(uuid_str)

    # Test UUIDFormat.validate with an empty string
    assert UUIDFormat().validate("") == uuid.UUID("")

    # Test UUIDFormat.validate with an invalid UUID string
    uuid_str = "1ef878c0-b30c-4e89-8986-22f31b5e5368a"

# Generated at 2022-06-22 06:02:28.435992
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat.validate("11:05:00")
    assert time.hour == 11
    assert time.minute == 5
    assert time.second == 0


# Generated at 2022-06-22 06:02:30.377219
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    with raises(NotImplementedError):
        BaseFormat().validation_error('format')


# Generated at 2022-06-22 06:02:33.409953
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-02-27T00:00:00+00:00") == datetime.datetime(2019,2,27,00,00,00)


# Generated at 2022-06-22 06:02:36.148510
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    bf = BaseFormat()
    bf.validate(0)
    assert True


# Generated at 2022-06-22 06:02:40.387138
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base = BaseFormat()
    assert base.is_native_type(1) == False
    #  assert base.validate(1) == ValidationError
    assert base.serialize(1) == None


# Generated at 2022-06-22 06:02:41.823512
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert tf

# Generated at 2022-06-22 06:02:45.312322
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    test_class = BaseFormat()
    assert test_class.validation_error("test_code") == ValidationError(text = "test_text", code = "test_code")


# Generated at 2022-06-22 06:02:55.567379
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class CustomFormat(BaseFormat):
        errors = {"format": "Must be valid custom format."}

        def is_native_type(self, value: typing.Any) -> bool:
            return True

        def validate(self, value: typing.Any) -> typing.Any:
            raise NotImplementedError()

        def serialize(self, obj: typing.Any) -> typing.Any:
            raise NotImplementedError()

    f = CustomFormat()
    assert f.validation_error("format").code == "format"
    assert f.validation_error("format").text == "Must be valid custom format."

# Unit tests for method is_native_type of class DateFormat

# Generated at 2022-06-22 06:03:02.183219
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class BaseFormatImpl(BaseFormat):
        def validate(self, value: typing.Any) -> typing.Union[typing.Any, ValidationError]:
            return value

    base_format = BaseFormatImpl()
    assert base_format.validate({}) == {}

# Generated at 2022-06-22 06:03:06.149243
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class Test(BaseFormat):
        errors = {'err': 'some message'}
    val = Test()
    err = val.validation_error('err')
    assert isinstance(err, ValidationError)
    assert err.text, 'some message'


# Generated at 2022-06-22 06:03:09.214412
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    df = DateTimeFormat()
    assert isinstance(df, DateTimeFormat)
    assert isinstance(df.__dict__, dict)


# Generated at 2022-06-22 06:03:14.352370
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    a = datetime.date(year=2020, month=11, day=29)
    format_ = DateFormat()
    result = format_.serialize(a)
    # print(result)
    assert result == '2020-11-29'
    

# Generated at 2022-06-22 06:03:17.217148
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time.is_native_type("12:59:59")
    assert time.is_native_type("12:59:59.123456")



# Generated at 2022-06-22 06:03:28.428784
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    input = '2020-01-01'
    f = DateTimeFormat()
    assert f.validate(input) == datetime.datetime(2020, 1, 1, 0, 0)
    input = '2020-06-01'
    f = DateTimeFormat()
    assert f.validate(input) == datetime.datetime(2020, 6, 1, 0, 0)
    input = '2000-01-01'
    f = DateTimeFormat()
    assert f.validate(input) == datetime.datetime(2000, 1, 1, 0, 0)
    input = '2020-01-02'
    f = DateTimeFormat()
    assert f.validate(input) == datetime.datetime(2020, 1, 2, 0, 0)
    input = '2019-12-07'
    f = Date

# Generated at 2022-06-22 06:03:32.066113
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    dt = datetime.datetime.today()
    d  = dt.date()
    assert DateFormat().serialize(d) == d.isoformat()


# Generated at 2022-06-22 06:03:36.765389
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    format = DateTimeFormat()
    assert format.serialize(datetime.datetime(2019, 3, 14, 0, 0, 0, 0, datetime.timezone.utc)) == "2019-03-14T00:00:00Z"



# Generated at 2022-06-22 06:03:39.009498
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())


# Generated at 2022-06-22 06:03:43.315212
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtfmt = DateTimeFormat()
    assert(isinstance(datetime.datetime.now(), datetime.datetime))
    assert(dtfmt.is_native_type(datetime.datetime.now()) == True)


# Generated at 2022-06-22 06:03:47.429486
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == ''


# Generated at 2022-06-22 06:04:01.053547
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    f = TimeFormat()
    f.validate('07:07:07')
    f.validate('07:07:07.000001')
    f.validate('07:07:07.123456')
    f.validate('07:07:07.123')
    f.validate('07:07:07.12')
    f.validate('07:07:07.1')
    f.validate('07:07:07.12345')
    f.validate('07:07:07.1234')
    f.validate('07:07:07.1234567')
    f.validate('07:07:07.12345678')
    f.validate('07:07:07.123456789')
    f.validate('07:07:07.1234567890')


# Generated at 2022-06-22 06:04:05.695472
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    try:
        result = uuid_format.validate("110e8400-e29b-11d4-a716-446655440000")
        assert True
    except ValidationError as e:
        assert False

# Generated at 2022-06-22 06:04:08.338197
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    x = DateFormat.validate('1995-4-4')
    assert type(x) == datetime.date


# Generated at 2022-06-22 06:04:10.844918
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    value = datetime.datetime(2019, 5, 21)
    assert time_format.is_native_type(value) == False



# Generated at 2022-06-22 06:04:15.167315
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    test1 = UUIDFormat().is_native_type(1)
    assert test1 == False

    test2 = UUIDFormat().is_native_type(uuid.uuid4())
    assert test2 == True


# Generated at 2022-06-22 06:04:26.852883
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    with pytest.raises(ValidationError):
        time_format.validate('abc')
    with pytest.raises(ValidationError):
        time_format.validate('01:12:34')
    with pytest.raises(ValidationError):
        time_format.validate('01:12:34:35:56:67')
    with pytest.raises(ValidationError):
        time_format.validate('01:12:34.12345678')
    with pytest.raises(ValidationError):
        time_format.validate('ABC:12:34')
    with pytest.raises(ValidationError):
        time_format.validate('00:ABC:34')
    with pytest.raises(ValidationError):
        time_

# Generated at 2022-06-22 06:04:30.641420
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2020,1,1))
    assert not DateFormat().is_native_type(datetime.datetime(2020,1,1))


# Generated at 2022-06-22 06:04:35.451490
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base_format = BaseFormat()
    base_format.errors = {
        "format" : "Must be a valid time format.",
    }
    code = "format"

    text = base_format.errors[code].format(**base_format.__dict__)
    assert text == base_format.errors[code].format()
    assert not base_format.validation_error(code).code
    assert not base_format.validation_error(code).text
    assert base_format.validation_error(code).code == code
    assert base_format.validation_error(code).text == text


# Generated at 2022-06-22 06:04:40.888282
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u1 = uuid.uuid4()
    u2 = uuid.uuid4()
    u1_str = str(u1)
    u2_str = str(u2)
    
    assert UUIDFormat().validate(u1_str) == u1
    assert UUIDFormat().validate(u2_str) == u2

# Generated at 2022-06-22 06:04:51.546066
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value = "2019-07-01T12:34:56"
    dtf = DateTimeFormat()
    test_time = dtf.validate(value)
    assert test_time.year == 2019
    assert test_time.month == 7
    assert test_time.day == 1
    assert test_time.hour == 12
    assert test_time.minute == 34
    assert test_time.second == 56
    assert test_time.microsecond == 0



# Generated at 2022-06-22 06:04:53.506198
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert type(df.serialize('2020-02-11')) == str


# Generated at 2022-06-22 06:04:56.737887
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    obj = BaseFormat()
    with pytest.raises(NotImplementedError):
        obj.serialize(None)

# Generated at 2022-06-22 06:04:59.452764
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time = TimeFormat()
    assert time.is_native_type(datetime.time(10, 2, 1, 2)) == True


# Generated at 2022-06-22 06:05:01.450794
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date = datetime.date.today()
    date_format = DateFormat()

    assert date_format.is_native_type(date) == True



# Generated at 2022-06-22 06:05:04.197381
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert UUIDFormat()



# Generated at 2022-06-22 06:05:12.401752
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    d1 = datetime.datetime.now()
    d2 = datetime.date.today()
    d3 = datetime.time()
    d4 = datetime.datetime.now().replace(tzinfo=datetime.timezone.utc)

    assert DateTimeFormat().is_native_type(d1)
    assert not DateTimeFormat().is_native_type(d2)
    assert not DateTimeFormat().is_native_type(d3)
    assert DateTimeFormat().is_native_type(d4)


# Generated at 2022-06-22 06:05:15.256565
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    res = DateTimeFormat().validate('2020-05-20T09:00:00.000000Z')
    assert isinstance(res, datetime.datetime)



# Generated at 2022-06-22 06:05:19.257818
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid1 = UUIDFormat()
    uuid2 = UUIDFormat()
    assert uuid1.__dict__ == uuid2.__dict__

# Generated at 2022-06-22 06:05:23.498479
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    # GIVEN - An instance of BaseFormat
    bf = BaseFormat()
    # WHEN - We test is_native_type(value)
    # THEN - It returns False
    assert bf.is_native_type('a') == False


# Generated at 2022-06-22 06:05:29.106955
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    the_obj = datetime.datetime.strptime("2020-04-23T12:34:56+01:00", "%Y-%m-%dT%H:%M:%S%z")
    assert DateTimeFormat().serialize(the_obj) == "2020-04-23T12:34:56+01:00"



# Generated at 2022-06-22 06:05:33.744191
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidFormat = UUIDFormat()
    uuidFormat.validate("122e6c66-e072-4c67-a1a2-c064375bff06")
    return

# Generated at 2022-06-22 06:05:39.340951
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    testBaseFormat = BaseFormat()
    testBaseFormat.errors['format'] = "Must be valid format."
    assert testBaseFormat.validation_error('format').code == 'format'
    assert testBaseFormat.validation_error('format').text == 'Must be valid format.'


# Generated at 2022-06-22 06:05:49.539898
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True
    assert DateTimeFormat().is_native_type(datetime.date.today()) == False
    assert DateTimeFormat().is_native_type(datetime.time(hour=9, minute=0, second=0)) == False
    assert DateTimeFormat().is_native_type("2020-05-26T16:43:11.434") == False


# Generated at 2022-06-22 06:05:51.826745
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type("") == False

# Generated at 2022-06-22 06:06:01.181371
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    print("\n\n")
    print(" ==== DateFormat ==== ")
    print("\nTesting method validate of class DateFormat")
    print("\nValid date 2018-02-04")
    print("DateFormat.validate('2018-02-04'): ")
    print(dateFormat.validate('2018-02-04'))
    print("\nNot valid date '200-01-01'")
    print("DateFormat.validate('200-01-01'): ")
    try:
        datetime.datetime(2017, 2, 11)
        dateFormat.validate('200-01-01')
    except ValidationError as e:
        print(e)
    print("\nNot valid date '2018-07-40'")

# Generated at 2022-06-22 06:06:04.611220
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now())
    assert not DateTimeFormat().is_native_type(1)


# Generated at 2022-06-22 06:06:10.959460
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # create an instance of `DateFormat`
    dt_format = DateFormat()
    assert dt_format is not None

    # invalid value
    try:
        dt_format.validate("2019-1-1")
    except ValidationError:
        pass

    # valid value
    dt_format.validate("2019-01-01")
    assert 1 == 1


# Generated at 2022-06-22 06:06:13.286551
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    t=TimeFormat()
    a=datetime.time()
    assert t.is_native_type(a)


# Generated at 2022-06-22 06:06:25.151502
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-02-13T15:20:31.211345Z") == datetime.datetime(2019, 2, 13, 15, 20, 31, 211345, tzinfo=datetime.timezone.utc)

    assert DateTimeFormat().validate("2019-02-13T15:20:31.211345+03:00") == datetime.datetime(2019, 2, 13, 15, 20, 31, 211345, tzinfo=datetime.timezone(datetime.timedelta(hours=3)))


# Generated at 2022-06-22 06:06:28.861783
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    assert time_format.serialize(datetime.time(13, 56, 56, 563423)) == "13:56:56.563423"

# Generated at 2022-06-22 06:06:37.569965
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_input_validate = ["2020-06-26 12:00:00.345678Z", "2020-06-26 12:00:00.345678+08:00", "2020-06-26 12:00:00.345678+0800", "2020-06-26 12:00:00.345678-08:00", "2020-06-26 12:00:00.345678-0800"]
    
    for i in test_input_validate:
        assert isinstance(DateTimeFormat().validate(i), datetime.datetime)


# Generated at 2022-06-22 06:06:41.138369
# Unit test for constructor of class DateFormat
def test_DateFormat():
    dformat = DateFormat()
    assert(dformat != None)


# Generated at 2022-06-22 06:06:43.318448
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    test_BaseFormat=BaseFormat()
    with pytest.raises(NotImplementedError):
        test_BaseFormat.validate("")


# Generated at 2022-06-22 06:06:48.604008
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_validate = date_time_format.validate('2019-08-15T09:52:07+00:00')
    assert re.match(r"2019-08-15 09:52:07\+00:00", str(date_time_validate))

# Generated at 2022-06-22 06:06:49.704546
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    pass


# Generated at 2022-06-22 06:06:52.802449
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.UUID('fb36c6a8-6a5c-4eec-a2a6-8f31df915f6a')) == True


# Generated at 2022-06-22 06:06:54.580508
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    assert BaseFormat().validate()

# Generated at 2022-06-22 06:06:57.986830
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    d = DateTimeFormat()
    assert d.is_native_type(datetime.datetime.now())
    assert not d.is_native_type(datetime.datetime.now().date())
    assert not d.is_native_type('a')
