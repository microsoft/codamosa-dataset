

# Generated at 2022-06-22 05:57:14.526893
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date = "2019-06-11T21:17:36"
    datetime_format = DateTimeFormat()
    datetime_format.validate(date)

# Generated at 2022-06-22 05:57:15.735862
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    tf.validate('10:30:00')

# Generated at 2022-06-22 05:57:19.467309
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now())
    assert not DateTimeFormat().is_native_type(None)
    assert not DateTimeFormat().is_native_type("abc")


# Generated at 2022-06-22 05:57:20.918022
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time1 = TimeFormat()
    time2 = TimeFormat()
    assert time1 == time2


# Generated at 2022-06-22 05:57:22.205157
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2019, 1, 7)) == True
    

# Generated at 2022-06-22 05:57:28.877695
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    from typesystem.base import Field
    from typesystem.enums import serialize_type
    uid = UUIDFormat()
    assert str(uid.serialize(uuid.uuid4())) == uuid.uuid4().hex
    assert serialize_type(Field(format_type=uid, serialized_name="test", attr_name="test")) == {"serialized_name": "test", "format_type": "uuid"}

# Generated at 2022-06-22 05:57:30.790220
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
	#test whether the constructor will fail due to the
	#necessary input parameters
    try:
        BaseFormat()
    except:
        pass
	

# Generated at 2022-06-22 05:57:40.617571
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestFormat(BaseFormat):
        errors = {
            "format": "Must be valid format.",
            "invalid": "Must be real.",
        }

    fmt = TestFormat()

    value = fmt.validation_error('format')
    assert value == ValidationError(text='Must be valid format.', code='format')

    value = fmt.validation_error('invalid')
    assert value == ValidationError(text='Must be real.', code='invalid')


# Generated at 2022-06-22 05:57:41.611172
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert(isinstance(DateTimeFormat(), BaseFormat))

# Generated at 2022-06-22 05:57:43.680739
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert isinstance(BaseFormat.serialize(int), int)

# Generated at 2022-06-22 05:57:57.100102
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date = "1994-01-20"
    datetest = DateFormat()
    assert datetest.validate(date) == datetime.date(1994, 1, 20), "date format error"
    assert datetest.serialize(datetest.validate(date)) == date, "date format error"


# Generated at 2022-06-22 05:57:59.910887
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    # Testing with valid input
    # assert TimeFormat().serialize('00:00:00') == '00:00:00'
    pass

# Generated at 2022-06-22 05:58:06.290793
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    dateformat = DateFormat()
    assert dateformat.is_native_type(value=datetime.date.today()) == True
    assert dateformat.is_native_type(value=datetime.time(0,0,0)) == False
    assert dateformat.is_native_type(value=datetime.datetime.today()) == False


# Generated at 2022-06-22 05:58:13.880204
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat = DateFormat()
    date = dateformat.validate("2002-02-02")
    assert date.year == 2002
    assert date.month == 2
    assert date.day == 2
    assert date.day == 2
    with pytest.raises(ValidationError):
        dateformat.validate("02-02-2002")
    with pytest.raises(ValidationError):
        dateformat.validate("2020-17-01")


# Generated at 2022-06-22 05:58:18.407130
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # Create class instance
    base_format = BaseFormat()
    # Assign attribute for errors
    base_format.errors = {'format': '{format}'}
    # Check result
    result = base_format.validation_error('format')
    assert isinstance(result, ValidationError)
    assert result.text == '{format}'
    assert result.code == 'format'


# Generated at 2022-06-22 05:58:24.979003
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    val = BaseFormat()
    print('\n' + 'type(val) = ' + str(type(val)))
    if type(val) is BaseFormat:
        print('\n' + 'val = ' + str(val))
        print('\n' + 'val.serialize(None) = ' + str(val.serialize(None)))
    else:
        print('\n' + 'Value val is not an instance of BaseFormat')


# Generated at 2022-06-22 05:58:31.249517
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_obj = DateFormat()
    assert date_obj.is_native_type(datetime.date(2020, 3, 26))
    assert not date_obj.is_native_type(datetime.time(18, 0))
    assert not date_obj.is_native_type(datetime.datetime(2020, 3, 26, 18, 0, 0))


# Generated at 2022-06-22 05:58:33.499900
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    # Test valid case
    result = tf.validate('00:00')
    assert result == datetime.time(hour=0, minute=0)

# Generated at 2022-06-22 05:58:36.412388
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    with pytest.raises(NotImplementedError):
        format = BaseFormat()
        format.serialize(obj = 0)


# Generated at 2022-06-22 05:58:39.428333
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert not date_format.is_native_type(datetime.datetime(2020, 3, 4))
    assert date_format.is_native_type(datetime.date(2020, 3, 4))


# Generated at 2022-06-22 05:58:45.008780
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    assert df.is_native_type(datetime.date(2020,1,1)) == True
    assert df.is_native_type("2020-01-01") == False


# Generated at 2022-06-22 05:58:56.393979
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    test_values = [
        {
            "input": None,
            "expected_output": None,
        },
        {
            "input": uuid.UUID("550e8400-e29b-41d4-a716-446655440000"),
            "expected_output": "550e8400-e29b-41d4-a716-446655440000",
        },
    ]
    for test_value in test_values:
        actual_output = UUIDFormat().serialize(test_value["input"])
        assert actual_output == test_value["expected_output"], f"{actual_output} != {test_value['expected_output']}"


# Generated at 2022-06-22 05:58:58.911872
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat() is not None

# Generated at 2022-06-22 05:59:02.317151
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format = BaseFormat()

    error = format.validation_error("format")
    assert error.text == "Invalid format."
    assert error.code == "format"



# Generated at 2022-06-22 05:59:06.977035
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # Prerequisites
    class Format(BaseFormat):
        errors = {"format": "Must be valid {name} format."}

    format = Format()
    # Action
    text = format.validation_error("format")

    assert text.text == "Must be valid {name} format."


# Generated at 2022-06-22 05:59:12.349084
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize(uuid.UUID('1a6a6022-72f7-4dcf-a8f9-96f9bd1b64ef')) == '1a6a6022-72f7-4dcf-a8f9-96f9bd1b64ef'


# Generated at 2022-06-22 05:59:14.403011
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    BaseFormat.serialize(None)

# Generated at 2022-06-22 05:59:17.121527
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format =DateFormat()
    with pytest.raises(NotImplementedError):
        date_format.validate("2020-10-23")


# Generated at 2022-06-22 05:59:25.997183
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    # define input parameters and expected results
    param1 = 'a'
    param2 = 1
    param3 = '1'
    param4 = 'true'
    param5 = True
    param6 = [1,2,3]
    param7 = [1,2,3,4]
    param8 = 'true'
    param9 = 'false'
    param10 = 'true'
    param11 = [1,2,3,4]
    param12 = {'a':'b'}
    param13 = 'a'
    param14 = '2020-01-01'
    param15 = '00:01:02'
    param16 = '2020-01-01T00:01:02'
    param17 = '2020-01-01 00:01:02'

# Generated at 2022-06-22 05:59:30.899501
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert(uuid_format.is_native_type(uuid.UUID("some-id")) == True)
    assert(uuid_format.is_native_type("some-id") == False)
    assert(uuid_format.is_native_type(None) == False)


# Generated at 2022-06-22 05:59:41.616983
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    fmt = DateTimeFormat()
assert isinstance(fmt, BaseFormat)


# Generated at 2022-06-22 05:59:43.576958
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d_serialize = DateFormat().serialize("2018-09-17")
    assert d_serialize == "2018-09-17"


# Generated at 2022-06-22 05:59:52.638436
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    from typesystem.format.uuid import UUIDFormat
    import uuid
    basic_value = UUIDFormat()
    result1 = basic_value.serialize(uuid.UUID('12345678-1234-5678-1234-567812345678'))
    assert result1 == '12345678-1234-5678-1234-567812345678'
    result2 = basic_value.serialize(uuid.UUID('45678123-1234-5678-1234-567812345678'))
    assert result2 == '45678123-1234-5678-1234-567812345678'


# Generated at 2022-06-22 05:59:55.883621
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    try:
        BaseFormat.validate(BaseFormat, 1)
    except NotImplementedError as e:
        assert True
    except Exception:
        assert False



# Generated at 2022-06-22 06:00:01.969741
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    TIME_REGEX = re.compile(
        r"(?P<hour>\d{1,2}):(?P<minute>\d{1,2})"
        r"(?::(?P<second>\d{1,2})(?:\.(?P<microsecond>\d{1,6})\d{0,6})?)?"
    )


# Generated at 2022-06-22 06:00:06.633579
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Initialize objects for testing
    date = datetime.date(year=2020, month=2, day=28)
    dateFormat = DateFormat()
    output = dateFormat.serialize(date)
    assert output == date.isoformat()


# Generated at 2022-06-22 06:00:10.742575
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time = time_format.validate("11:42:23")
    assert isinstance(time, datetime.time)
    assert time.hour == 11
    assert time.minute == 42
    assert time.second == 23

# Generated at 2022-06-22 06:00:23.498677
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    serialize_test = TimeFormat()
    time = datetime.time(1, 2, 3)
    assert serialize_test.serialize(time) == "01:02:03"
    time = datetime.time(1, 2, 3, 456000)
    assert serialize_test.serialize(time) == "01:02:03.456000"
    time = datetime.time(1, 2, 3, 456)
    assert serialize_test.serialize(time) == "01:02:03.000456"
    time = datetime.time(0, 0, 0, 0)
    assert serialize_test.serialize(time) == "00:00:00"


# Generated at 2022-06-22 06:00:29.430567
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_format = TimeFormat()
    assert time_format.is_native_type("10:15:30") == False
    assert time_format.is_native_type(datetime.time(10, 15, 30)) == True
    assert time_format.validate("10:15:30") == datetime.time(10, 15, 30)
    assert str(time_format.validate("10:15:30")) == "10:15:30"
    assert time_format.serialize("10:15:30") == "10:15:30"

# Generated at 2022-06-22 06:00:34.302436
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    d = DateFormat()
    # given: a native type datetime.date
    date = datetime.date.today()
    # when: is_native_type is called
    res = d.is_native_type(date)
    # then: is_native_type must return True
    assert res == True


# Generated at 2022-06-22 06:00:45.393015
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.UUID('067e6162-3b6f-4ae2-a171-2470b63dff00'))


# Generated at 2022-06-22 06:00:54.095478
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    def check_date(date_value):
        result = DateFormat().is_native_type(date_value)
        assert result == True
    date_value1 = datetime.date.today()
    date_value2 = "2019-06-25"
    check_date(date_value1)
    check_date(date_value2)


# Generated at 2022-06-22 06:00:57.381064
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    TIME = "20:00:00"
    TIME_FORMAT = TimeFormat()
    print(TIME_FORMAT.validate(TIME))
    assert isinstance(TIME_FORMAT.validate(TIME), datetime.time)


# Generated at 2022-06-22 06:01:05.010190
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    if not isinstance(UUIDFormat().serialize('c6ff2e6d-50bc-48f6-8aa8-0b82f3c0a976'), str):
        raise AssertionError()


# Generated at 2022-06-22 06:01:11.917868
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    from typesystem.base import ValidationError
    from typesystem.format import DateFormat

    expected_date = datetime.date(2018, 11, 11)
    test_date_format = DateFormat()

    assert test_date_format.validate("2018-11-11") == expected_date

    # test case failure
    with pytest.raises(ValidationError):
        test_date_format.validate("2018-11-11 wrong")


# Generated at 2022-06-22 06:01:13.771025
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat.is_native_type(1) == False



# Generated at 2022-06-22 06:01:19.029887
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuidFormat = UUIDFormat()
    testStr = 'a8a6a277-664c-40a8-b843-b1abf01e1849'
    assert (uuidFormat.validate(testStr) == uuid.UUID('a8a6a277-664c-40a8-b843-b1abf01e1849'))

# Generated at 2022-06-22 06:01:21.534033
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format_ = BaseFormat()
    with pytest.raises(NotImplementedError):
        format_.validation_error("any_code")



# Generated at 2022-06-22 06:01:25.879604
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    obj = UUIDFormat()
    assert(obj.is_native_type('f2493f32-be2a-46d9-bab1-8e85cccaed85') == True)
    assert(obj.is_native_type('f2493f32-be2a-46d9-bab1-lalala') == False)


# Generated at 2022-06-22 06:01:30.889367
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    bf.validation_error("error")
    assert bf.errors == {}
    assert bf.is_native_type("") == False


# Generated at 2022-06-22 06:01:40.913973
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    validator = UUIDFormat()
    # Return True for UUID object
    assert validator.is_native_type(uuid.uuid4())
    # Return False for non-UUID object 
    assert validator.is_native_type(1) == False


# Generated at 2022-06-22 06:01:42.122771
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    expected = UUIDFormat()
    assert expected is not None

# Generated at 2022-06-22 06:01:50.825316
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate(): 
    from datetime import datetime
    from typesystem.fields import String
    from typesystem.formats import UUIDFormat
    from typesystem.exceptions import ValidationError
    
    uuid_format = UUIDFormat()    
    
    result = uuid_format.validate("31504a8f-c523-4f88-982f-b939d2cbd071")
    assert isinstance(result, uuid.UUID)

    try:
        uuid_format.validate("32504a8f-c523-4f88-982f-b939d2cbd071")
        assert False
    except ValidationError as error:
        assert error.text == "Must be valid UUID format." 


# Generated at 2022-06-22 06:02:00.929669
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    test_cases = [
        ("2019-10-04T00:00:00Z", datetime.datetime(2019, 10, 4, 0, 0, 0, tzinfo=datetime.timezone.utc)),
        ("2019-04-10T17:51:28+02:00", datetime.datetime(2019, 4, 10, 17, 51, 28, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))),
        ("2019-10-05T01:00:00+07:00", datetime.datetime(2019, 10, 5, 1, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=7)))),
        (None, None),
    ]
    for expected, input in test_cases:
        assert expected == DateTime

# Generated at 2022-06-22 06:02:10.777653
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
	date_format_object = DateFormat()
	assert date_format_object.is_native_type(datetime.date(2018, 7, 1)) == True	
	assert date_format_object.is_native_type(datetime.date(2018, 7, 8)) == True
	assert date_format_object.is_native_type(datetime.date(2000, 12, 30)) == True
	assert date_format_object.is_native_type(datetime.date.today()) == True
	assert date_format_object.is_native_type(datetime.datetime(2018, 7, 1)) == False
	assert date_format_object.is_native_type(datetime.datetime(2018, 7, 11)) == False

# Generated at 2022-06-22 06:02:11.893286
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    assert BaseFormat.validate(0) ==  0

# Generated at 2022-06-22 06:02:16.999845
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate("20:50:58")== datetime.time(20, 50, 58)
    assert tf.validate("20:50")== datetime.time(20, 50)

# Generated at 2022-06-22 06:02:19.674000
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    x = DateFormat()
    y = datetime.date(2019, 3, 13)
    assert x.serialize(y) == y.isoformat()


# Generated at 2022-06-22 06:02:24.102665
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    target = DateTimeFormat()
    value = datetime.datetime(year=22,month=10,day=22,hour=1,minute=22,second=23,microsecond = 100000)
    expected = value.isoformat()
    result = target.serialize(value)
    assert result == expected


# Generated at 2022-06-22 06:02:27.430621
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():    
    assert DateFormat().validate("2015-01-01") == datetime.date(2015, 1, 1)



# Generated at 2022-06-22 06:02:39.905534
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    bf = BaseFormat()
    with pytest.raises(NotImplementedError):
        bf.validation_error('Invalid_code')

# Generated at 2022-06-22 06:02:41.264417
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now()) == True

# Generated at 2022-06-22 06:02:50.607700
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert not UUIDFormat().is_native_type("01234567-89ab-cdef-0123-456789abcdef")
    assert isinstance(UUIDFormat().validate("01234567-89ab-cdef-0123-456789abcdef"), uuid.UUID)
    assert UUIDFormat().is_native_type(UUIDFormat().validate("01234567-89ab-cdef-0123-456789abcdef"))
    assert not UUIDFormat().is_native_type("0123456789abcdef0123456789abcdef")


# Generated at 2022-06-22 06:02:56.405420
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time = DateTimeFormat()
    assert date_time.validate('2019-12-31T12:30:19Z') == datetime.datetime(2019, 12, 31, 12, 30, 19, tzinfo=datetime.timezone.utc)
    assert date_time.validate('2019-12-31T12:30:19+01:00') == datetime.datetime(2019, 12, 31, 12, 30, 19, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert date_time.validate('2019-12-31T12:30:19+0100') == datetime.datetime(2019, 12, 31, 12, 30, 19, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    assert date_

# Generated at 2022-06-22 06:02:59.833838
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    format = UUIDFormat()
    test_uuid = uuid.uuid1()
    serialized = format.serialize(test_uuid)
    assert(serialized == str(test_uuid))

# Generated at 2022-06-22 06:03:10.176266
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_date_format = DateTimeFormat()
    result = test_date_format.validate(value='2008-09-03T20:56:35.450686Z')
    assert isinstance(result,datetime.datetime)
    assert result.year == 2008
    assert result.month == 9
    assert result.day == 3
    assert result.hour == 20
    assert result.minute == 56
    assert result.second == 35
    assert result.microsecond == 450686
    assert result.tzinfo == datetime.timezone.utc



# Generated at 2022-06-22 06:03:17.370300
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    # Create an instance of UUIDFormat
    a = UUIDFormat()
    # assert that the serialize method returns the right value
    assert a.serialize(uuid.UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')) == 'f47ac10b-58cc-4372-a567-0e02b2c3d479'


# Generated at 2022-06-22 06:03:22.431437
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uf = UUIDFormat()
    assert uf.validate("5ca1ab1e-98c7-11da-a72b-0800200c9a66") == uuid.UUID("5ca1ab1e-98c7-11da-a72b-0800200c9a66")


# Generated at 2022-06-22 06:03:28.335544
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert str(TimeFormat().serialize(datetime.time(4,4,4))) == '04:04:04'
    assert str(TimeFormat().serialize(datetime.time(4,4,4,4))) == '04:04:04.000004'
    assert str(TimeFormat().serialize(datetime.time(4,4))) == '04:04:00'


# Generated at 2022-06-22 06:03:29.537478
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()


# Generated at 2022-06-22 06:03:45.968208
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    val=TimeFormat()
    assert val.validate('11:55:55')==datetime.time(11,55,55)
    try:
        val.validate('25:12:34') #invalid 
    except ValidationError as e:
        assert str(e) == 'Must be a real time.'
    try:
        val.validate('25:12:34.123456') #invalid 
    except ValidationError as e:
        assert str(e) == 'Must be a real time.'
    try:
        val.validate('25:12:34abcde') #invalid 
    except ValidationError as e:
        assert str(e) == 'Must be a valid time format.'


# Generated at 2022-06-22 06:03:47.956493
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dateTimeFormat = datetimeFormat.DateTimeFormat()
    assert dateTimeFormat is not None


# Generated at 2022-06-22 06:03:57.645463
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date.today()) == True
    assert date_format.is_native_type(datetime.time(hour=7, minute=23)) == False
    assert date_format.is_native_type(datetime.datetime.today()) == False
    assert date_format.is_native_type(uuid.uuid4()) == False


# Generated at 2022-06-22 06:04:02.339829
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    format = TimeFormat()

    assert not format.is_native_type(1)
    assert not format.is_native_type(datetime.date.today())
    assert not format.is_native_type(datetime.datetime.now())
    assert not format.is_native_type(datetime.datetime.now().time())


# Generated at 2022-06-22 06:04:07.015563
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    dateTimeFormat.validate("2020-02-20T10:30:59+00:00")
    dateTimeFormat.validate("2020-02-20T10:30:59Z")



# Generated at 2022-06-22 06:04:11.706256
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuidFormat = UUIDFormat()
    value = uuid.uuid4()
    assert uuidFormat.is_native_type(value) == True
    value = 1
    assert uuidFormat.is_native_type(value) == False


# Generated at 2022-06-22 06:04:23.567559
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    assert format.validate('1d0c09a0-0a93-11ea-8f9c-0242ac110005') == uuid.UUID('1d0c09a0-0a93-11ea-8f9c-0242ac110005')
    assert format.validate('1d0c09a0-0a93-11ea-8f9c-0242ac110006') == uuid.UUID('1d0c09a0-0a93-11ea-8f9c-0242ac110006')

# Generated at 2022-06-22 06:04:29.030044
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time.validate("14:30") == datetime.time(14, 30)
    assert time.validate("14:30:59") == datetime.time(14, 30, 59)
    assert time.validate("14:30:59.000234") == datetime.time(14, 30, 59, 234)



# Generated at 2022-06-22 06:04:31.992880
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(10, 20, 30)) == True


# Generated at 2022-06-22 06:04:42.069657
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTime = DateTimeFormat()
    try:
        dateTime.validate("2020-04-27T18:44:00.123Z")
        dateTime.validate("2020-04-27T18:44:00.123+07:00")
        dateTime.validate("2020-04-27T18:44:00.123")
        dateTime.validate("2020-04-27")
        dateTime.validate("18:44:00.123")
    except ValidationError:
        assert False, "DateTimeFormat.validate should validate right format"

# Generated at 2022-06-22 06:04:49.436709
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    fmt = BaseFormat()
    value = fmt.validate('123')
    assert value == '123'


# Generated at 2022-06-22 06:04:50.053993
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    a=BaseFormat()

# Generated at 2022-06-22 06:04:51.182062
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert tf is not None

# Generated at 2022-06-22 06:05:02.753535
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert datetime.datetime(2015, 2, 3, 4, 5, 6, tzinfo=datetime.timezone.utc).isoformat() == "2015-02-03T04:05:06+00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2015, 2, 3, 4, 5, 6, tzinfo=datetime.timezone.utc)) == "2015-02-03T04:05:06Z"
    assert DateTimeFormat().serialize(datetime.datetime(2015, 2, 3, 4, 5, 6, tzinfo=datetime.timezone(datetime.timedelta(hours=3)))) == "2015-02-03T04:05:06+03:00"

# Generated at 2022-06-22 06:05:06.271162
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(hour=23, minute=59, second=59)
    fmt = TimeFormat()
    serialized = fmt.serialize(time)
    assert serialized == "23:59:59"


# Generated at 2022-06-22 06:05:12.130931
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.UUID("10000000-0000-0000-0000-000000000000")) == True
    assert UUIDFormat().is_native_type("10000000-0000-0000-0000-000000000000") == False
    assert UUIDFormat().is_native_type("") == False


# Generated at 2022-06-22 06:05:20.944055
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid = "123e4567-e89b-12d3-a456-426655440000"
    uuid_format = UUIDFormat()
    assert uuid_format.serialize(uuid) == str(uuid)



# Generated at 2022-06-22 06:05:27.568881
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    BaseFormat_format = BaseFormat()
    #assert BaseFormat_format.is_native_type('2019-01-02') == True
    #assert BaseFormat_format.is_native_type('2019-01-02') == True
    #assert BaseFormat_format.is_native_type('2019-01-02') == True
    #assert BaseFormat_format.is_native_type('2019-01-02') == True

# Generated at 2022-06-22 06:05:33.781163
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize(uuid.UUID("0a5dd08c-ff72-4d5f-b5e0-f57c47d25f9c")) == "0a5dd08c-ff72-4d5f-b5e0-f57c47d25f9c"
   

# Generated at 2022-06-22 06:05:34.747069
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat()


# Generated at 2022-06-22 06:05:43.173570
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    testcase = BaseFormat()
    assert testcase.is_native_type(None) == False


# Generated at 2022-06-22 06:05:49.151895
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tFormat = TimeFormat()
    value = "12:00"
    assert tFormat.validate(value) is not None
    assert tFormat.validate(value) == datetime.time(12, 00)
    assert tFormat.is_native_type(tFormat.validate(value)) == True
    assert tFormat.serialize(tFormat.validate(value)) == "12:00:00"
    
    
    
    
    
#test for constructor of DateFormat

# Generated at 2022-06-22 06:05:54.589494
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(uuid.uuid4()) == True
    assert uuid_format.is_native_type('2bce9c90-3bab-4465-a7b0-e5c5d5b034be') == False


# Generated at 2022-06-22 06:05:59.557419
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
  time_format = TimeFormat()
  assert time_format.is_native_type(datetime.time())


# Generated at 2022-06-22 06:06:07.548187
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(12, 1, 2, 34567)) == "12:01:02.034567"
    assert TimeFormat().serialize(datetime.time(12, 1, 2)) == "12:01:02"
    assert TimeFormat().serialize(datetime.time(12, 1)) == "12:01"
    assert TimeFormat().serialize(datetime.time(12)) == "12:00"
    assert TimeFormat().serialize(datetime.time(0)) == "00:00"
    assert TimeFormat().serialize(None) is None

# Generated at 2022-06-22 06:06:11.535702
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    test = '9f7e1c51-fb55-4a17-b3fb-7d3b2e2c879b'
    instance = UUIDFormat()
    assert str(instance.validate(test)) == test


# Generated at 2022-06-22 06:06:16.737924
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    date_time_format = DateTimeFormat()
    date_time_format.format('2019-04-25T14:48:22.786073Z')
    assert date_time_format.validate('2019-04-25T14:48:22.786073Z')==datetime.datetime(2019,4,25,14,48,22,786073)

# Generated at 2022-06-22 06:06:24.086647
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    type_date=DateFormat()
    assert type_date.is_native_type(datetime.date(2020,9,9))==True
    assert type_date.is_native_type(datetime.datetime(2020,9,9))==False
    assert type_date.is_native_type("2020-09-09")==False
    assert type_date.is_native_type(9)==False


# Generated at 2022-06-22 06:06:33.316484
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()
    assert format
    assert format.validate("2019-06-01T12:10:31.123456Z")
    assert format.validate("2019-06-01T12:10:31.123456+09:00")
    assert format.validate("2019-06-01T12:10:31.123456-09:00")
    assert format.validate("2019-06-01T12:10:31Z")
    assert format.validate("2019-06-01T12:10:31+09:00")
    assert format.validate("2019-06-01T12:10:31-09:00")
    assert format.validate("2019-06-01T12:10Z")
    assert format.validate("2019-06-01T12:10+09:00")

# Generated at 2022-06-22 06:06:35.826547
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate('12:25:30.1237')

# Generated at 2022-06-22 06:06:46.536303
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    df = DateTimeFormat()
    assert df.validate("2005-08-09T18:31:42Z") == datetime.datetime(year=2005,month=8,day=9,hour=18,minute=31,second=42,tzinfo=datetime.timezone.utc)

# Generated at 2022-06-22 06:06:48.839163
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time(hour=11, minute=21)) == True


# Generated at 2022-06-22 06:06:52.503075
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u = UUIDFormat()
    uuid_ = u.validate("8faffd00-d7fb-4444-9c7f-d6f3c7d1b664")
    assert isinstance(uuid_, uuid.UUID)
