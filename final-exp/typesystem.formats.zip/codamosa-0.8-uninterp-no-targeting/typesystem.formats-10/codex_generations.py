

# Generated at 2022-06-22 05:57:19.792272
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_1 = uuid.uuid4()
    uuid_2 = uuid.uuid4()
    uuid_3 = uuid.uuid4()
    uuid_4 = uuid.uuid4()
    uuid_5 = uuid.uuid4()
    uuid_6 = uuid.uuid4()
    uuid_7 = uuid.uuid4()
    uuid_8 = uuid.uuid4()
    uuid_9 = uuid.uuid4()
    uuid_10 = uuid.uuid4()
    
    assert UUIDFormat().serialize(uuid_1) != None
    assert UUIDFormat().serialize(uuid_2) != None
    assert UUIDFormat().serialize(uuid_3) != None

# Generated at 2022-06-22 05:57:21.501808
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert str(DateFormat().serialize(obj=datetime.date.today())) == datetime.date.today().isoformat()


# Generated at 2022-06-22 05:57:23.974128
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(BaseFormat(), "") == ""


# Generated at 2022-06-22 05:57:32.021816
# Unit test for constructor of class TimeFormat
def test_TimeFormat():

    time = TimeFormat()

    assert time.is_native_type(datetime.time(1, 2, 3))
    assert not time.is_native_type(datetime.date(1, 2, 3))

    assert time.validate("00:00") == datetime.time(0)
    assert time.validate("00:00:00") == datetime.time(0)
    assert time.validate("00:00:00.000000") == datetime.time(0)

    assert time.serialize(datetime.time(0)) == "00:00:00"



# Generated at 2022-06-22 05:57:33.654513
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2018, 1, 1)) == '2018-01-01'



# Generated at 2022-06-22 05:57:40.266127
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    '''Validation Error BaseFormat'''
    error_code = "error_code"
    error_msg = "error_msg"
    format = BaseFormat()
    format.errors[error_code] = error_msg
    with pytest.raises(ValidationError):
        format.validation_error(error_code)


# Generated at 2022-06-22 05:57:41.239027
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(None) is None

# Generated at 2022-06-22 05:57:43.181918
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    x = DateTimeFormat() # If a class is instantiated, then the constructor works
    assert True == True


# Generated at 2022-06-22 05:57:54.167409
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    a = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"}

# Generated at 2022-06-22 05:57:59.223605
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuidformat = UUIDFormat()
    try:
        uuidformat.validate("1234")
    except ValidationError:
        assert True
    
    try:
        uuidformat.validate("1a12b1e1-d637-11ea-aec6-9801a718d74a")
    except ValidationError:
        assert False
    

# Generated at 2022-06-22 05:58:17.028360
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt_format = DateTimeFormat()
    date1 = dt_format.validate('2018-07-09 08:04:00+02:00')
    date2 = dt_format.validate('2018-07-09 08:04:00+00:00')
    date3 = dt_format.validate('2018-07-09 08:04:00')
    date4 = dt_format.validate('2018-07-09 08:04:00Z')
    date5 = dt_format.validate('2018-07-09T08:04:00+02:00')
    date6 = dt_format.validate('2018-07-09T08:04:00+00:00')
    date7 = dt_format.validate('2018-07-09T08:04:00')


# Generated at 2022-06-22 05:58:24.341134
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date1 = DateFormat()
    date2 = DateFormat()

    assert date1.is_native_type("2013-10-20") == False
    assert date1.is_native_type(datetime.date(2013, 10, 20)) == True

    assert isinstance(date1.validate("2013-10-20"), datetime.date)
    assert isinstance(date2.validate("2013-10-20"), datetime.date)

    assert date1.serialize(datetime.date(2013, 10, 20)) == "2013-10-20"
    assert date2.serialize(datetime.date(2013, 10, 20)) == "2013-10-20"


# Generated at 2022-06-22 05:58:33.289772
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
	dtf = DateTimeFormat()
	assert dtf.is_native_type(datetime.datetime(2020, 6, 18, 11, 0, 0)) == True
	assert dtf.is_native_type(datetime.datetime(2020, 6, 18, 11, 0, 0, tzinfo=datetime.timezone.utc)) == True
	assert dtf.is_native_type(datetime.date(2020, 6, 18)) == False
	assert dtf.is_native_type(1.2) == False


# Generated at 2022-06-22 05:58:34.821020
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()

# Unit tests for methods of class DateFormat

# Generated at 2022-06-22 05:58:46.093155
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    type_1 = datetime.date(2019, 9, 5)
    type_2 = datetime.time()
    type_3 = datetime.datetime()
    type_4 = uuid.UUID("73d9237c-a6e7-474d-bae5-849c0a6ac710")
    
    date_formate = DateFormat()
    time_formate = TimeFormat()
    datetime_formate = DateTimeFormat()
    uuid_formate = UUIDFormat()
    
    result_1 = date_formate.is_native_type(type_1)
    result_2 = date_formate.is_native_type(type_2)
    result_3 = date_formate.is_native_type(type_3)
    result_4 = date_formate

# Generated at 2022-06-22 05:58:54.374597
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtFormat = DateTimeFormat()
    assert dtFormat.is_native_type('2020-01-16T20:55:55.105+01:00') == False
    assert dtFormat.is_native_type(datetime.datetime(2020, 1, 16, 20, 55, 55, 105, datetime.timezone(datetime.timedelta(0, 3600)))) == True
    # assert dtFormat.validate('2020-01-16T20:55:55.105+01:00') == datetime.datetime(2020, 1, 16, 20, 55, 55, 105, datetime.timezone(datetime.timedelta(0, 3600)))

# Generated at 2022-06-22 05:58:59.915452
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    errors = {"test_error1": "test_text1"}
    test_format = BaseFormat()
    test_format.errors = errors

    try:
        test_format.validation_error("test_error1")
    except ValidationError as e:
        assert e.code == "test_error1"
        assert str(e) == errors["test_error1"]
    else:
        assert False


# Generated at 2022-06-22 05:59:02.174983
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    assert BaseFormat.validate(10) is None


# Generated at 2022-06-22 05:59:09.381923
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    from typesystem.base import Type
    from datetime import time
    t = TimeFormat()
    t_instance = time()
    t_serialized = t.serialize(t_instance)
    # call serialize in class Type
    assert(t.serialize == Type.serialize)
    # check return type
    assert(isinstance(t_serialized, str))
    # check serialized output
    assert(t_serialized == t_instance.isoformat())

# Generated at 2022-06-22 05:59:13.775768
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    instance = DateFormat()
    assert instance.validate("1950-02-29") == datetime.date(1950, 2, 29)

# Generated at 2022-06-22 05:59:20.339953
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat().errors['format'] == 'Must be  a valid date format.'
    assert DateFormat().errors['invalid'] == 'Must be a real date.'



# Generated at 2022-06-22 05:59:21.560681
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    f = BaseFormat()
    assert f is not None

# Generated at 2022-06-22 05:59:26.157662
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuidVal = uuid.UUID('6d876a3b-1356-4f7d-b875-8d4c4e4e0405')
    result = UUIDFormat().serialize(uuidVal)
    assert result == '6d876a3b-1356-4f7d-b875-8d4c4e4e0405'



# Generated at 2022-06-22 05:59:28.225732
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4()) is True


# Generated at 2022-06-22 05:59:30.535178
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dt = DateTimeFormat()
    assert dt.is_native_type('2019-08-08') == False


# Generated at 2022-06-22 05:59:35.169334
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.datetime.now().date()) == True
    assert date_format.is_native_type(datetime.datetime.now()) == False


# Generated at 2022-06-22 05:59:43.382151
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_value = "f3a1aecb-a7b0-48bb-a7b8-b52d50f09ccd"
    try:
        uuid_format.validate(uuid_value)
    except ValidationError:
        assert False
    try:
        uuid_format.validate("a1aecb-a7b0-48bb-a7b8-b52d50f09ccd")
        assert False
    except ValidationError:
        pass
    
    
        

# Generated at 2022-06-22 05:59:44.146670
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert 1

# Generated at 2022-06-22 05:59:47.902685
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    a = DateFormat()
    assert a.is_native_type(datetime.date(1999,1,1)) == True
    assert a.is_native_type(datetime.date(2100,12,31)) == True


# Generated at 2022-06-22 05:59:53.556987
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    format = DateTimeFormat()
    assert format.is_native_type(datetime.datetime.today()) is True

#####################################################################################


# Generated at 2022-06-22 05:59:57.442295
# Unit test for constructor of class DateFormat
def test_DateFormat():
    df = DateFormat()
    assert type(df) is DateFormat


# Generated at 2022-06-22 06:00:09.883384
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
	format = TimeFormat()
	value1 = "09:56:20"
	value2 = "09:56:20+01:00"
	value3 = "09:56:20.312573"
	value4 = "09:56:20.312573Z"
	value5 = "09:56:20.312573+01:00"
	value6 = "09:56:20.312573-01:00"


# Generated at 2022-06-22 06:00:20.310718
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    obj_datetime = datetime.datetime(2020, 3, 14, 14, 52, 50)
    obj_date = datetime.date(2020, 3, 14)
    obj_time = datetime.time(14, 52, 50)
    obj_other = 3.14
    # Create an object of class DateTimeFormat
    obj_DateTimeFormat = DateTimeFormat()
    # Test method
    assert(obj_DateTimeFormat.is_native_type(obj_datetime) == True)
    assert(obj_DateTimeFormat.is_native_type(obj_date) == False)
    assert(obj_DateTimeFormat.is_native_type(obj_time) == False)
    assert(obj_DateTimeFormat.is_native_type(obj_other) == False)


# Generated at 2022-06-22 06:00:22.958228
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    value = TimeFormat().validate("19:05:34.9")
    assert value.hour == 19
    assert value.minute == 5
    assert value.second == 34
    assert value.microsecond == 900000

# Generated at 2022-06-22 06:00:24.352427
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(10, 15, 20)
    assert TimeFormat().serialize(time) == "10:15:20"

# Generated at 2022-06-22 06:00:27.147438
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(uuid.uuid4())


# Generated at 2022-06-22 06:00:28.612048
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    f = BaseFormat()
    assert f.serialize(None) is None

# Generated at 2022-06-22 06:00:40.238189
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()

    time = timeformat.validate('12:21:00')
    correct_time = datetime.time(hour=12, minute=21)
    assert time == correct_time

    with pytest.raises(ValidationError):
        time = timeformat.validate('06:34:67')
    
    with pytest.raises(ValidationError):
        time = timeformat.validate('')

    with pytest.raises(ValidationError):
        time = timeformat.validate('daras')

    with pytest.raises(ValidationError):
        time = timeformat.validate('')

    with pytest.raises(ValidationError):
        time = timeformat.validate('21:12:')


# Generated at 2022-06-22 06:00:42.850088
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    assert dateFormat.validate("1999-08-06") == datetime.date(1999, 8, 6)


# Generated at 2022-06-22 06:00:45.759274
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    import datetime
    time = "09:12:00"
    obj = TimeFormat().validate(time)
    assert obj == datetime.time(hour=9, minute=12, second=00)



# Generated at 2022-06-22 06:00:56.211547
# Unit test for method validate of class DateFormat

# Generated at 2022-06-22 06:01:01.393892
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    val = "b7ccb40f-9dd8-46c6-beb3-2b3bd3b184ff"
    u = UUIDFormat()
    print(u.validate(val))



# Generated at 2022-06-22 06:01:09.786766
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    class DateTests(unittest.TestCase):
        # Test invalid formats
        def test_invalid_format(self):
            formatter = DateFormat()
            invalid_dates = [
                "not a date",
                "",
                "foo",
                "2020/01/01",
                "2020-00-01",
                "2020-13-01",
                "2020-01-00",
                "2020-01-32",
                "2020-1-1",
                "2020-01-1",
                "2020-01-01 00:00:00",
                "2020-01-01 00:00:00 A",
                "2020-01-01 00:00:00Z",
                "2020-01-01 00:00:00.000000",
            ]


# Generated at 2022-06-22 06:01:12.983290
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuidObj = UUIDFormat()
    uuidId = uuid.uuid4()
    output = uuidId.hex
    assert uuidObj.serialize(uuidId) == output


# Generated at 2022-06-22 06:01:18.560722
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestClass(BaseFormat):
        errors = {"test_code": "Must be a valid test format."}

    test_class = TestClass()
    test_error = test_class.validation_error("test_code")
    assert test_error.code == "test_code"
    assert test_error.text == "Must be a valid test format."


# Generated at 2022-06-22 06:01:21.098600
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    a = datetime.time(12,55,55,555555)
    assert time_format.serialize(a) == a.isoformat()

# Generated at 2022-06-22 06:01:26.033773
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    try:
        error = False
        f = UUIDFormat()
    except:
        error = True
    assert error == False



# Generated at 2022-06-22 06:01:30.518760
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base_format=BaseFormat()
    assert base_format.validation_error("format")==ValidationError(text="Must be a valid date format.", code="format")


# Generated at 2022-06-22 06:01:32.511993
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now())



# Generated at 2022-06-22 06:01:39.494572
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    t = TimeFormat()
    assert not t.is_native_type(None)
    assert t.is_native_type(datetime.time(12, 23, 45))
    assert t.is_native_type(datetime.time(12, 23, 45, 678))
    assert not t.is_native_type(12)
    assert not t.is_native_type(datetime.date(2019, 12, 23))
    assert not t.is_native_type(datetime.datetime(2019, 12, 23, 12, 23, 45))


# Generated at 2022-06-22 06:01:44.477700
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    bf = BaseFormat()
    bf.validation_error("format")

# Generated at 2022-06-22 06:01:48.049859
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    uuid_obj = uuid.uuid4()
    assert uuid_format.is_native_type(uuid_obj) == True
    assert uuid_format.is_native_type('123') == False


# Generated at 2022-06-22 06:01:58.417978
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # case 1: The date time is valid.
    dateTime = "2020-05-27T10:00:00Z"
    assert datetime.datetime(2020, 5, 27, 10, 0, 0, tzinfo=datetime.timezone.utc) == DateTimeFormat().validate(dateTime)

    # case 2: The date time is valid but tzinfo is not valid.
    dateTime = "2020-05-27T10:00:00+2:00"
    assert datetime.datetime(2020, 5, 27, 8, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=2))) == DateTimeFormat().validate(dateTime)

    # case 3: The date time is valid but tzinfo is not valid.

# Generated at 2022-06-22 06:02:03.567806
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat();
    return uuid_format

# Generated at 2022-06-22 06:02:11.357785
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate('1992-1-1') == datetime.date(1992, 1, 1)
    assert df.validate('1992-1-1') != datetime.date(1993, 1, 1)


# Generated at 2022-06-22 06:02:17.628958
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    value_true='13:45:01'
    value_false='13'
    format=TimeFormat()
    try:
         format.validate(value_true)
    except:
        assert False
    try:
         format.validate(value_false)
    except:
        assert True
    assert format.errors['format']=='Must be a valid time format.'

#Unit test for constructor of class DateTimeFormat

# Generated at 2022-06-22 06:02:21.115681
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date.today()) is True
    assert date_format.is_native_type(datetime.datetime.now()) is False


# Generated at 2022-06-22 06:02:29.235032
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2020, 6, 26)) == True
    assert TimeFormat().is_native_type(datetime.time(15, 59)) == True
    assert DateTimeFormat().is_native_type(datetime.datetime(2015,11,28,15,59)) == True
    assert UUIDFormat().is_native_type(uuid.UUID('067e6162-3b6f-4ae2-a171-2470b63dff00')) == True

# Generated at 2022-06-22 06:02:32.440607
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class TestFormat(BaseFormat):
        def validate(self, value: typing.Any) -> typing.Union[typing.Any, ValidationError]:
            raise NotImplementedError

    with pytest.raises(NotImplementedError):
        TestFormat().validate(1)


# Generated at 2022-06-22 06:02:37.841281
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()
    assert b.errors == {}
    assert b.validation_error("code") == ValidationError(text = "format", code="code")
    assert b.is_native_type(1) == True
    assert b.validate(1) == "Must be a valid date format."
    assert b.serialize(1) == "Must be a valid date format."

# Unit tests for constructor of class DateFormat

# Generated at 2022-06-22 06:02:54.096757
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_object = uuid.UUID('b3c3de98-d6f1-11ea-a24a-a6c5e4d066c7')
    format_object = UUIDFormat()
    assert format_object.serialize(uuid_object) == 'b3c3de98-d6f1-11ea-a24a-a6c5e4d066c7'


# Generated at 2022-06-22 06:03:01.557855
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate('2018-11-07T00:13:24Z') == datetime.datetime(2018, 11, 7, 0, 13, 24, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate('2018-11-07T00:13:24+05:00') == datetime.datetime(2018, 11, 7, 0, 13, 24, tzinfo=datetime.timezone(datetime.timedelta(hours=5)))

# Generated at 2022-06-22 06:03:02.730141
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time is not None

# Generated at 2022-06-22 06:03:09.037077
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('00:00:00.000') == datetime.time(0, 0)
    assert time_format.validate('23:59:59.2358') == datetime.time(23, 59, 59, 235800)
    assert time_format.validate('23:59:59') == datetime.time(23, 59, 59)
    assert time_format.validate('23:59') == datetime.time(23, 59)

# Generated at 2022-06-22 06:03:12.551463
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    obj = datetime.time(19, 50, 0, 0)
    assert tf.serialize(obj) == '19:50:00'



# Generated at 2022-06-22 06:03:15.079819
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(year=2020,month=8,day=15)
    dateformat = DateFormat()
    assert dateformat.serialize(date) == '2020-08-15'


# Generated at 2022-06-22 06:03:17.123748
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    fmt = BaseFormat()
    with pytest.raises(NotImplementedError):
        fmt.is_native_type(1)


# Generated at 2022-06-22 06:03:23.788003
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tf = TimeFormat()
    assert tf.is_native_type(datetime.time(12, 20))
    assert not tf.is_native_type(datetime.datetime(2019, 4, 10, 12, 20))

    assert tf.is_native_type(tf.validate("12:20"))
    assert not tf.is_native_type(tf.validate("2019-4-10 12:20"))


# Generated at 2022-06-22 06:03:24.874221
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()

# Generated at 2022-06-22 06:03:33.113751
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    date_time_format = DateTimeFormat()
    assert date_time_format.validate("1986-03-03T03:03:03Z") == datetime.datetime(1986, 3, 3, 3, 3, 3, tzinfo=datetime.timezone.utc)
    assert date_time_format.validate("1986-03-03T03:03:03-05:00") == datetime.datetime(1986, 3, 3, 3, 3, 3, tzinfo=datetime.timezone(datetime.timedelta(hours=-5)))

# Generated at 2022-06-22 06:03:43.150619
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    print("\nUnit test for constructor of class DateTimeFormat")
    print(DateTimeFormat())


# Generated at 2022-06-22 06:03:44.192697
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidmap = UUIDFormat()


# Generated at 2022-06-22 06:03:48.300013
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    with pytest.raises(NotImplementedError):
        BaseFormat().is_native_type(1.0)
        BaseFormat().validate(1.0)
        BaseFormat().serialize(1.0)


# Generated at 2022-06-22 06:03:58.817562
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    format = DateTimeFormat()
    mock_datetime = datetime.datetime(
        year=2020,
        month=6,
        day=14,
        hour=6,
        minute=2,
        second=33,
        microsecond=0,
        tzinfo=datetime.timezone(datetime.timedelta(hours=-5)),
    )
    expected_value = '2020-06-14T06:02:33-05:00'
    assert format.serialize(mock_datetime) == expected_value


# Generated at 2022-06-22 06:04:10.873103
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert UUIDFormat().validate("89b23781-aa09-4e30-9dc9-ab8b79d36787") == uuid.UUID("89b23781-aa09-4e30-9dc9-ab8b79d36787")
    assert UUIDFormat().validate("89b23781-aa09-4e30-9dc9-ab8b79d36787") == uuid.UUID("89b23781-aa09-4e30-9dc9-ab8b79d36787")
    # assert UUIDFormat().validate("89b23781-aa09-4e30-9dc9-ab8b79d36787") == uuid.UUID("89b23781-aa09-4e30-9dc9-ab8b79d3678") # Assertion

# Generated at 2022-06-22 06:04:23.081634
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid1 = "1587b7d9-e858-4fda-a5f5-5c5cd848e7e6"
    uuid2 = "0"
    uuid3 = "hahahahahahahahahahahahahahahahaha"
    uuid4 = "1587b7d9-e858-4fda-a5f5-5c5cd848e7e"
    uuid5 = "1587b7d9-e858-4fda-a5f5-5c5cd848e7e6a"
    uuid_validate_test1 = UUIDFormat()
    uuid_validate_test2 = UUIDFormat()
    uuid_validate_test3 = UUIDFormat()
    uuid_validate_test4 = UUIDFormat

# Generated at 2022-06-22 06:04:35.258351
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    format_ = DateTimeFormat()
    assert format_.serialize(None) == None
    assert format_.serialize("2018-07-20T13:18:28.460847+00:00") == "2018-07-20T13:18:28.460847Z"
    assert format_.serialize("2018-07-20T13:18:28.460847Z") == "2018-07-20T13:18:28.460847Z"
    assert format_.serialize("2018-07-20T13:18:28.460847+01:00") == "2018-07-20T13:18:28.460847+01:00"

# Generated at 2022-06-22 06:04:38.711228
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time(1,2,3))
    assert not TimeFormat().is_native_type('datetime.time(1,2,3)')


# Generated at 2022-06-22 06:04:42.732932
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(1,1,1,1,1,1,1, datetime.timezone.utc)) == "0001-01-01T01:01:01.000001Z"

# Generated at 2022-06-22 06:04:52.238121
# Unit test for constructor of class DateFormat
def test_DateFormat():
    x = DateFormat()
    assert x.errors["format"] == "Must be a valid date format."
    assert x.errors["invalid"] == "Must be a real date."
    assert x.is_native_type(datetime.date(2020,1,10)) == True
    assert x.is_native_type(datetime.date(2020,1,10)) == True
    assert x.serialize(datetime.date(2020,1,10)) == "2020-01-10"
    assert x.validate("2020-01-10") == datetime.date(2020,1,10)
    assert x.validate("2020-01-10") == datetime.date(2020,1,10)

# Generated at 2022-06-22 06:05:09.192528
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = TimeFormat()
    assert time.serialize(datetime.time(15,30)) == "15:30:00"

# Generated at 2022-06-22 06:05:21.290552
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestFormat(BaseFormat):
        errors = {"error_code": "Error Message"}

        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, datetime.date)

        def validate(self, value: typing.Any) -> datetime.date:
            match = DATE_REGEX.match(value)
            if not match:
                raise self.validation_error("format")

            kwargs = {k: int(v) for k, v in match.groupdict().items()}
            try:
                return datetime.date(**kwargs)
            except ValueError:
                raise self.validation_error("invalid")

        def serialize(self, obj: typing.Any) -> typing.Union[str, None]:
            if obj is None:
                return

# Generated at 2022-06-22 06:05:24.608645
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    with pytest.raises(NotImplementedError):
        BaseFormat().is_native_type(0)


# Generated at 2022-06-22 06:05:26.548869
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    fmt = BaseFormat()
    fmt.__dict__ == {}
    fmt.errors == {}


# Generated at 2022-06-22 06:05:28.832575
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    base = BaseFormat()
    with pytest.raises(NotImplementedError):
        base.validate("")


# Generated at 2022-06-22 06:05:32.649276
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    bf = BaseFormat()
    with raises(NotImplementedError):
        bf.validate(None)


# Generated at 2022-06-22 06:05:40.529318
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_obj = datetime.time(12, 45, 3, 5)
    time_format_obj = TimeFormat()
    time_string = time_format_obj.serialize(time_obj)
    assert time_string == '12:45:03.000005'

# Generated at 2022-06-22 06:05:44.130738
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    format = DateTimeFormat()
    print(format)


# Generated at 2022-06-22 06:05:49.041875
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    result = dtf.validate("2019-01-02")
    expected = datetime.datetime(2019, 1, 2, tzinfo=datetime.timezone.utc)
    assert result == expected



# Generated at 2022-06-22 06:05:51.656559
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time()) == True
    assert TimeFormat().is_native_type(0) == False


# Generated at 2022-06-22 06:06:25.401012
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2010-10-10') == datetime.date(2010,10,10)


# Generated at 2022-06-22 06:06:27.720568
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    format = BaseFormat()
    assert format.is_native_type(None) == False
    assert format.is_native_type(1) == True


# Generated at 2022-06-22 06:06:28.944685
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    b=BaseFormat()
    assert b.validation_error('a')==ValidationError(text='a', code='a')



# Generated at 2022-06-22 06:06:40.371244
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()

    assert dt.validate("2019-03-08T15:16:17Z") == datetime.datetime(
        year=2019,
        month=3,
        day=8,
        hour=15,
        minute=16,
        second=17,
        tzinfo=datetime.timezone.utc,
    )

    assert dt.validate("2019-03-08T15:16:17+10:30") == datetime.datetime(
        year=2019,
        month=3,
        day=8,
        hour=15,
        minute=16,
        second=17,
        tzinfo=datetime.timezone(datetime.timedelta(hours=10, minutes=30)),
    )


# Generated at 2022-06-22 06:06:50.971631
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    real_date = datetime.date(2019, 5, 20)

    data = dict(real_date = real_date, 
                format_da = DateFormat(),
                format_ti = TimeFormat(),
                format_dt = DateTimeFormat(),
                format_uu = UUIDFormat())

    assert data['format_da'].serialize(data['real_date']) == '2019-05-20'
    assert data['format_ti'].serialize(data['real_date']) == None
    assert data['format_dt'].serialize(data['real_date']) == None
    assert data['format_uu'].serialize(data['real_date']) == None


# Generated at 2022-06-22 06:06:57.358691
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    new_date = datetime.datetime(2020, 2, 22, 2, 27, 2)
    date_format = DateTimeFormat()
    date_string = date_format.serialize(new_date)
    assert date_string == "2020-02-22T02:27:02"