

# Generated at 2022-06-22 05:57:11.882938
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    fmt = DateTimeFormat()
    assert fmt.errors == {'format': 'Must be a valid datetime format.',
                          'invalid': 'Must be a real datetime.'}
    assert fmt.validation_error('format') == ValidationError(
        text='Must be a valid datetime format.', code='format')
    assert fmt.validation_error('invalid') == ValidationError(
        text='Must be a real datetime.', code='invalid')


# Generated at 2022-06-22 05:57:13.408078
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uf = UUIDFormat()
    assert uf is not None


# Generated at 2022-06-22 05:57:14.176441
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()
    assert not tf.is_native_type(100)


# Generated at 2022-06-22 05:57:17.817458
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time_format = DateTimeFormat()
    date_time_obj = datetime.datetime.utcnow()
    assert date_time_format.serialize(date_time_obj) == date_time_obj.isoformat()

# Generated at 2022-06-22 05:57:21.257203
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    date_time_format = DateTimeFormat()
    assert date_time_format.is_native_type(datetime.datetime())
    assert not date_time_format.is_native_type(datetime.time())
    assert not date_time_format.is_native_type(datetime.date.today())

# Generated at 2022-06-22 05:57:27.716082
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
	assert UUIDFormat().validate("d67a1e90-b5b5-4d08-9633-f1c0be36e828") == uuid.UUID('d67a1e90-b5b5-4d08-9633-f1c0be36e828')


# Generated at 2022-06-22 05:57:37.035160
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    value_time = datetime.datetime.now()
    value_time = value_time.time()
    value_time_str = value_time.isoformat()
    value_other = None
    assert time_format.is_native_type(value_time) == True
    assert time_format.is_native_type(value_time_str) == False
    assert time_format.is_native_type(value_other) == False


# Generated at 2022-06-22 05:57:41.146944
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.time(12,0,1)) == True
    assert time_format.is_native_type(datetime.datetime.now()) == False



# Generated at 2022-06-22 05:57:46.644400
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class A(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return value == '1'
    a = A()
    assert a.is_native_type('1') == True
    assert a.is_native_type('2') == False

# Generated at 2022-06-22 05:57:50.976265
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class TestFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return value == 'test'
        def validate(self, value: typing.Any) -> typing.Union[typing.Any, ValidationError]:
            return value
    test = TestFormat()
    assert test.is_native_type('test')
    assert test.validate('test') == 'test'

# Generated at 2022-06-22 05:57:59.223310
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uf = UUIDFormat()
    assert uf.validate('123e4567-e89b-12d3-a456-426655440000') == uuid.UUID('123e4567-e89b-12d3-a456-426655440000')



# Generated at 2022-06-22 05:58:00.597817
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(BaseFormat, 1) == ""

# Generated at 2022-06-22 05:58:01.958144
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf=TimeFormat()
    assert isinstance(tf, BaseFormat)

# Generated at 2022-06-22 05:58:05.987746
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    result = uuid_format.is_native_type(uuid.uuid4())
    assert result


# Generated at 2022-06-22 05:58:08.813352
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    test_date = "2018-03-03"
    result = date_format.is_native_type(test_date)
    assert(result == False)


# Generated at 2022-06-22 05:58:11.048165
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime.utcnow())

# Generated at 2022-06-22 05:58:16.516513
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    # Test if eceptions are raised when calling virtual methods
    with pytest.raises(NotImplementedError):
        BaseFormat().is_native_type(1)
    with pytest.raises(NotImplementedError):
        BaseFormat().validate(1)
    with pytest.raises(NotImplementedError):
        BaseFormat().serialize(1)


# Generated at 2022-06-22 05:58:27.242205
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2016-03-28T00:00:00") == datetime.datetime(2016,3,28,0,0,0)
    assert DateTimeFormat().validate("2016-03-28T00:00:00Z") == datetime.datetime(2016,3,28,0,0,0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2016-03-28T00:00:00.000000") == datetime.datetime(2016,3,28,0,0,0)
    assert DateTimeFormat().validate("2016-03-28T00:00:00+00:00") == datetime.datetime(2016,3,28,0,0,0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-22 05:58:34.678983
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    value = "11111111-1111-1111-1111-111111111111"
    assert(isinstance(format.validate(value), uuid.UUID))
    value = "11111111-1111-1111-1111-1111111111111"
    try:
        format.validate(value)
    except ValidationError:
        print("ValidationError")
    else:
        assert(False)


# Generated at 2022-06-22 05:58:37.147569
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuidFormat = UUIDFormat()
    assert type(uuidFormat) == UUIDFormat


# Generated at 2022-06-22 05:58:50.204606
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    bf = BaseFormat()
    bf.errors['format']='Must be a valid date format.'
    bf.errors['invalid']='Must be a real date.'
    assert bf.validation_error('format').code == 'format'
    assert bf.validation_error('format').text == 'Must be a valid date format.'


# Generated at 2022-06-22 05:58:51.567742
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    try:
        x = TimeFormat()
        assert True
    except:
        assert False

# Generated at 2022-06-22 05:58:56.074635
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    bf = BaseFormat()
    bf.errors = {
        "format": "Must be a valid date format.",
        "invalid": "Must be a real date.",
    }
    bf.__dict__ = {'code': 'invalid', 'text': 'Must be a real date.'}
    bf.validation_error('invalid')


# Generated at 2022-06-22 05:59:00.720791
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat().errors == {
        "format": "Must be a valid date format.",
        "invalid": "Must be a real date."
    }


# Generated at 2022-06-22 05:59:07.587216
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    fmt = DateFormat()
    assert fmt.is_native_type(datetime.date(2020, 4, 4))
    assert not fmt.is_native_type(datetime.time(13, 40, 5))
    assert not fmt.is_native_type(datetime.datetime(2020, 4, 4, 1, 2, 3))
    assert not fmt.is_native_type(1)
    assert not fmt.is_native_type("2020-03-03")


# Generated at 2022-06-22 05:59:18.474859
# Unit test for constructor of class DateFormat
def test_DateFormat():
    class TestDateFormat(DateFormat):
        errors = {"format": "Must be a valid date format.",
                  "invalid": "Must be a real date."}
        def is_native_type(self, value):
            return isinstance(value, datetime.date)
        def validate(self, value):
            match = DATE_REGEX.match(value)
            if not match:
                raise self.validation_error("format")
            kwargs = {k: int(v) for k, v in match.groupdict().items()}
            try:
                return datetime.date(**kwargs)
            except ValueError:
                raise self.validation_error("invalid")
        def serialize(self, obj):
            if obj is None:
                return None

# Generated at 2022-06-22 05:59:19.799389
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
     BaseFormat.serialize("any object", None)


# Generated at 2022-06-22 05:59:23.649701
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    assert bf.errors == {}
    assert bf.validation_error("code") == None
    assert bf.is_native_type("value") == False
    assert bf.validate("value") == None
    assert bf.serialize("obj") == None


# Generated at 2022-06-22 05:59:26.078696
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    dateFormat = DateFormat()
    assert dateFormat.serialize(None) is None
    assert dateFormat.serialize(datetime.date(2000, 1, 1)) == "2000-01-01"

# Generated at 2022-06-22 05:59:29.330273
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date_format = DateFormat()
    date_format.validation_error("format")
    date_format.validation_error("invalid")
    assert date_format.__dict__ == {}



# Generated at 2022-06-22 05:59:34.147795
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime.utcnow())

# Generated at 2022-06-22 05:59:42.532868
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    assert datetime_format.validate("2020-09-06T12:50:47.321534+05:30") == datetime.datetime(2020, 9, 6, 12, 50, 47, 321534, tzinfo=datetime.timezone(datetime.timedelta(seconds=19800)))
    assert datetime_format.validate("2020-09-06T12:50:47.321534Z") == datetime.datetime(2020, 9, 6, 12, 50, 47, 321534, tzinfo=datetime.timezone.utc)



# Generated at 2022-06-22 05:59:46.364866
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    bf = BaseFormat()
    bf.errors = {'code': 'error'}
    assert bf.validation_error('code') == ValidationError(
        'error', code='code')


# Generated at 2022-06-22 05:59:48.572847
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = datetime.date.today()
    value = date.isoformat()
    goodFormat = DateFormat()
    goodDate = goodFormat.validate(value)
    assert goodDate == date

# Generated at 2022-06-22 05:59:52.438924
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime(2019, 5, 7, 14, 32, 15)) == True
    assert DateTimeFormat().is_native_type(datetime.time(21, 50, 55, 123456)) == False


# Generated at 2022-06-22 05:59:56.512154
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
	# Create a BaseFormat
	fmt = BaseFormat()

	# Check that is_native_type method returns False
	assert(not fmt.is_native_type(1))

	return True

test_TimeFormat_is_native_type()

# Generated at 2022-06-22 05:59:58.320830
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate('07:00:00') == datetime.time(7, 0)

# Generated at 2022-06-22 05:59:59.914561
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    result = BaseFormat()
    with pytest.raises(NotImplementedError):
        result.validate('bastien')


# Generated at 2022-06-22 06:00:03.330595
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    from typesystem.types import Date

    assert Date().validate('2018-12-31') == datetime.date(2018, 12, 31)



# Generated at 2022-06-22 06:00:05.022863
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_format = TimeFormat()
    assert time_format is not None


# Generated at 2022-06-22 06:00:11.252298
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    testTimeFormat = TimeFormat()


# Generated at 2022-06-22 06:00:12.740808
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    assert uuid_format is not None

# Generated at 2022-06-22 06:00:19.928095
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_formatter = UUIDFormat()
    sample_uuid = "5011c79e-41b2-4f16-b8f8-b56d0b7e3db0"
    assert uuid_formatter.validate(sample_uuid) == uuid.UUID(sample_uuid)
    

# Generated at 2022-06-22 06:00:21.385534
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat().is_native_type(1) == True


# Generated at 2022-06-22 06:00:32.769641
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    res = DateTimeFormat()

# Generated at 2022-06-22 06:00:34.518892
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    now = datetime.datetime.utcnow()
    assert now.isoformat() == DateTimeFormat().serialize(now)


# Generated at 2022-06-22 06:00:38.800928
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    d = DateFormat()
    valid_date = "2020-08-04"
    invalid_date = "2020-08-04000"
    assert d.validate(valid_date) == datetime.date(2020, 8, 4)
    assert str(d.validate(invalid_date)) == "ValueError"


# Generated at 2022-06-22 06:00:43.427093
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(None) == None
    assert isinstance(DateTimeFormat().serialize(datetime.datetime.now(tz=datetime.timezone.utc)), str)
    assert isinstance(DateTimeFormat().serialize(datetime.datetime.now(tz=datetime.timezone.utc)), str)



# Generated at 2022-06-22 06:00:48.265971
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    import unittest
    import unittest.mock
    # Arrange
    base_format = BaseFormat()
    obj = 'value'
    # Act
    result = base_format.serialize(obj)
    # Assert
    assert unittest.mock.call(obj) == result, \
    'The function BaseFormat.serialize() does not return a value'


# Generated at 2022-06-22 06:00:55.007122
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    format_UUID = UUIDFormat()
    obj = uuid.UUID('d67269eb-5a5e-4d7f-bf3d-2a6cde72e8aa')
    assert format_UUID.serialize(obj) == 'd67269eb-5a5e-4d7f-bf3d-2a6cde72e8aa'


# Generated at 2022-06-22 06:01:07.585689
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date.today())
    assert not date_format.is_native_type(datetime.datetime.now())
    assert not date_format.is_native_type(datetime.time())
    assert not date_format.is_native_type(datetime.timedelta())


# Generated at 2022-06-22 06:01:12.422038
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2000, 1, 1)) == True
    assert DateFormat().is_native_type(None) == False
    assert DateFormat().is_native_type(100) == False
    assert DateFormat().is_native_type('2000-01-01') == False


# Generated at 2022-06-22 06:01:16.078217
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    test1_BaseFormat_validate_true = BaseFormat()
    try:
        test1_BaseFormat_validate_true.validate("33")
        raise Exception("TypeError did not occur")
    except TypeError:
        pass

# Generated at 2022-06-22 06:01:26.150031
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    df = DateTimeFormat()
    # normal input
    assert df.validate('1990-11-01T00:00:00') == datetime.datetime(1990, 11, 1, 0, 0, 0)
    assert df.validate('1990-11-01T00:00:00Z') == datetime.datetime(1990, 11, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert df.validate('1990-11-01T00:00:00+02:00') == datetime.datetime(1990, 11, 1, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))

# Generated at 2022-06-22 06:01:31.890678
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    uuid_test = '0000111122223333444455556666777788889999'
    assert uuid_format.validate(uuid_test) == uuid.UUID(uuid_test)

# Generated at 2022-06-22 06:01:39.884759
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert UUIDFormat().validate("524bd9f9-b67d-4ec3-b3e1-a8248c6034f1") == uuid.UUID("524bd9f9-b67d-4ec3-b3e1-a8248c6034f1")
    

# Generated at 2022-06-22 06:01:41.333679
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    t = TimeFormat()
    assert isinstance(t, TimeFormat)


# Generated at 2022-06-22 06:01:43.510453
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date_format = DateFormat()
    #print(date_format)


# Generated at 2022-06-22 06:01:44.832268
# Unit test for constructor of class DateFormat
def test_DateFormat():
  f=DateFormat()
  assert isinstance(f, DateFormat)


# Generated at 2022-06-22 06:01:49.114543
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
	assert UUIDFormat().is_native_type(uuid.uuid4()) == True
	assert UUIDFormat().is_native_type("random str") == False


# Generated at 2022-06-22 06:01:54.876259
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_format_test = TimeFormat()
    assert time_format_test.errors["format"] == "Must be a valid time format."
    assert time_format_test.errors["invalid"] == "Must be a real time."


# Generated at 2022-06-22 06:01:57.974003
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    error_obj = BaseFormat().validation_error("format")
    assert error_obj.text == "Must be a valid format."
    assert error_obj.code == "format"


# Generated at 2022-06-22 06:02:04.881562
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    format = BaseFormat()
    assert isinstance(format, BaseFormat)

    with pytest.raises(NotImplementedError):
        format.serialize('2019-04-01')


# Generated at 2022-06-22 06:02:14.850318
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t1 = TimeFormat()
    assert t1.validate("09:25:30") == datetime.time(9, 25, 30)
    assert t1.validate("03:25:00") == datetime.time(3, 25)
    assert t1.validate("09:25") == datetime.time(9, 25)
    assert t1.validate("09:25:30.456789") == datetime.time(9, 25, 30, 456789)

# Generated at 2022-06-22 06:02:16.289532
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert isinstance(DateFormat(), DateFormat)


# Generated at 2022-06-22 06:02:24.869663
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    timeFormat = UUIDFormat()
    result = timeFormat.validate('a8b9d9bb-5fd6-4b47-a8b9-d9bb5fd6a8b9')
    assert result == uuid.UUID('a8b9d9bb-5fd6-4b47-a8b9-d9bb5fd6a8b9')
    assert timeFormat.serialize(result) == 'a8b9d9bb-5fd6-4b47-a8b9-d9bb5fd6a8b9'
    assert timeFormat.is_native_type(result) == True

# Generated at 2022-06-22 06:02:27.372970
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(1) == False


# Generated at 2022-06-22 06:02:29.866199
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    a = BaseFormat()
    with pytest.raises(NotImplementedError):
        a.serialize('foo')


# Generated at 2022-06-22 06:02:30.984570
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert BaseFormat().is_native_type("") == None

# Generated at 2022-06-22 06:02:32.095248
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.datetime.now().time())

# Generated at 2022-06-22 06:02:47.431897
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestFormat(BaseFormat):
        def __init__(self, error_code):
            self.error_code = error_code
        def validation_error(self, code):
            if self.error_code == "format":
                text = self.errors[code].format(**self.__dict__)
                return ValidationError(text=text, code=code)
            else:
                text = self.errors[code]
                return ValidationError(text=text, code=code)
    # Asserts for the case that error_code is format
    test_format = TestFormat("format")
    with pytest.raises(ValidationError, match="Must be a valid time format"):
        test_format.validation_error('format')
    # Asserts for the case that error_code is invalid
    test_

# Generated at 2022-06-22 06:02:50.799860
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(None) is None

# Generated at 2022-06-22 06:02:52.490262
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    obj = DateTimeFormat()
    assert(isinstance(obj, BaseFormat))


# Generated at 2022-06-22 06:02:54.348062
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    base_format = BaseFormat()
    assert base_format.serialize(1) == None

# Generated at 2022-06-22 06:02:55.969263
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat().serialize(None) == None


# Generated at 2022-06-22 06:02:58.024644
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(None) == False


# Generated at 2022-06-22 06:03:00.916174
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
	date_format = DateFormat()
	result = date_format.validate("2019-01-01")
	assert result == datetime.date(2019, 1, 1)



# Generated at 2022-06-22 06:03:05.827954
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00Z") is not None
    assert DateTimeFormat().validate("2020-01-01T00:00:00") is not None


# Generated at 2022-06-22 06:03:13.478582
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuidFormat = UUIDFormat()
    uuid = uuidFormat.validate("e8b8ccd9-2f2a-4dc6-8ec8-e11a2775b6c2")
    expected_uuid = uuid.UUID("e8b8ccd9-2f2a-4dc6-8ec8-e11a2775b6c2")
    assert uuid == expected_uuid



# Generated at 2022-06-22 06:03:17.218036
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj_1 = UUIDFormat()
    with pytest.raises(AssertionError):
        obj_1.serialize(None)
    assert obj_1.serialize(uuid.uuid4()) == str(uuid.uuid4())

# Generated at 2022-06-22 06:03:27.629674
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_form = UUIDFormat()
    assert isinstance(uuid_form, BaseFormat) == True



# Generated at 2022-06-22 06:03:32.668118
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    bf = BaseFormat()
    res1 = bf.serialize(1)
    assert res1 == NotImplementedError
    res2 = bf.serialize(None)
    assert res2 == None
    res3 = bf.serialize(1.2)
    assert res3 == NotImplementedError


# Generated at 2022-06-22 06:03:35.778197
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_time = datetime.datetime.now()
    format_1 = DateTimeFormat()
    assert format_1.serialize(date_time) == date_time.isoformat()

# Generated at 2022-06-22 06:03:41.203771
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    test_uuid = uuid.uuid4()
    format = UUIDFormat()
    assert format.is_native_type(test_uuid)
    assert not format.is_native_type(1)
    assert not format.is_native_type("1")
    assert not format.is_native_type(None)


#  Unit test for method validate of class UUIDFormat

# Generated at 2022-06-22 06:03:49.381810
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    from typesystem.formatters import BaseFormat


    class MyFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, int)
        
        def validate(self, value: typing.Any) -> int:
            return int(value)

        def serialize(self, obj: typing.Any) -> typing.Union[str, None]:
            return str(obj)

    myfmt = MyFormat()
    assert myfmt.serialize(1234) == "1234"
    assert myfmt.serialize(None) == None



# Generated at 2022-06-22 06:04:00.072836
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    date_format_instance = DateFormat()
    time_format_instance = TimeFormat()
    date_time_format_instance = DateTimeFormat()
    uuid_format_instance = UUIDFormat()
    assert date_format_instance.is_native_type(datetime.date(2018, 3, 31))
    assert time_format_instance.is_native_type(datetime.time(19, 47, 59))
    assert date_time_format_instance.is_native_type(datetime.datetime(2018, 4, 2, 19, 47, 59))
    assert uuid_format_instance.is_native_type(uuid.uuid4())


# Generated at 2022-06-22 06:04:02.838855
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    # Test with obj = None
    BaseFormat().serialize(None)

    # Test without exception
    with pytest.raises(NotImplementedError):
        BaseFormat().serialize(1)


# Generated at 2022-06-22 06:04:13.750452
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    dt = dtf.validate("2019-01-02T03:04:05")
    dt = dtf.validate("2019-01-02T03:04:05.200")
    dt = dtf.validate("2019-01-02T03:04:05.200Z")
    dt = dtf.validate("2019-01-02T03:04:05+09:00")
    assert (dt.year, dt.mon, dt.mday, dt.hour, dt.min, dt.sec, dt.tzinfo.utcoffset(dt)) == (2019, 1, 2, 3, 4, 5, datetime.timedelta(hours=9))



# Generated at 2022-06-22 06:04:22.632555
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    UUID_format = UUIDFormat()
    msg = UUID_format.validate("b2ac2c02-9b98-4d87-b7da-c1ccc8d77da3")
    assert msg == uuid.UUID("b2ac2c02-9b98-4d87-b7da-c1ccc8d77da3")
    
    try:
        msg = UUID_format.validate("Wrong_UUID")
    except AssertionError as e:
        assert len(e.args) > 0
    

# Generated at 2022-06-22 06:04:35.200816
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert not TimeFormat().is_native_type(99)
    assert not TimeFormat().is_native_type(True)
    assert not TimeFormat().is_native_type(None)
    assert not TimeFormat().is_native_type("2020-06-06T20:32:00")
    assert not TimeFormat().is_native_type(datetime.date.today())
    assert TimeFormat().is_native_type(datetime.time())
    assert TimeFormat().is_native_type(datetime.time(20, 32))
    assert TimeFormat().is_native_type(datetime.time(20, 32, 45))
    assert TimeFormat().is_native_type(datetime.time(20, 32, 45, 687654))

# Generated at 2022-06-22 06:04:45.158839
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    assert time_format.is_native_type(None) is False
    assert time_format.is_native_type(datetime.time(0, 0, 0, 0)) is True
    assert time_format.is_native_type("0:00") is False


# Generated at 2022-06-22 06:04:48.260124
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat.is_native_type(BaseFormat,12) == False


# Generated at 2022-06-22 06:04:49.673850
# Unit test for constructor of class DateFormat
def test_DateFormat():
    dateFormat = DateFormat()
    assert dateFormat


# Generated at 2022-06-22 06:04:51.762929
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    try:
        bfm = BaseFormat()
    except NotImplementedError:
        pass


# Generated at 2022-06-22 06:04:54.528477
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    is_instance = DateTimeFormat().is_native_type(datetime.datetime.now())
    assert isinstance(is_instance, bool) and is_instance is True


# Generated at 2022-06-22 06:04:59.333055
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert UUIDFormat().validate("29e6f9ac-2cf2-11eb-a20e-81c0d6e693b6") == uuid.UUID("29e6f9ac-2cf2-11eb-a20e-81c0d6e693b6")

# Generated at 2022-06-22 06:05:02.548795
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    dateFormat = DateFormat()
    assert not dateFormat.is_native_type("2019-11-07")
    assert dateFormat.is_native_type(datetime.date(2019, 11, 11))


# Generated at 2022-06-22 06:05:11.616316
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u1 = uuid.UUID('67c87654-aed9-11e8-9f32-f2801f1b9fd1')
    u2 = uuid.UUID('67c87654-aed9-11e8-9f32-f2801f1b9fd0')
    # check the length of the random uuid
    assert len(str(u1)) == len(str(u2)) == 36  
    # test the serialize 
    assert UUIDFormat().serialize(u1) == '67c87654-aed9-11e8-9f32-f2801f1b9fd1'
    assert UUIDFormat().serialize(u2) == '67c87654-aed9-11e8-9f32-f2801f1b9fd0'



# Generated at 2022-06-22 06:05:14.054199
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert DateTimeFormat().is_native_type(datetime.datetime.now())

# Generated at 2022-06-22 06:05:28.014040
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem.fields import DateTime

    assert DateTime.validate("2019-10-01T13:13:13") == datetime.datetime(2019,10,1,13,13,13)
    assert DateTime.validate("2019-10-01T13:13:13Z") == datetime.datetime(2019,10,1,13,13,13,tzinfo=datetime.timezone.utc)
    assert DateTime.validate("2019-10-01T13:13:13+05:30") == datetime.datetime(2019,10,1,13,13,13,tzinfo=datetime.timezone(datetime.timedelta(hours=5,minutes=30)))
    assert DateTime.validate("2019-10-01T13:13:13-05:30") == datetime

# Generated at 2022-06-22 06:05:45.509065
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat.validation_error("format") == ValidationError("format")
    assert BaseFormat.is_native_type("") == False
    assert BaseFormat.is_native_type(1) == False
    assert BaseFormat.is_native_type(1.0) == False
    assert BaseFormat.is_native_type([]) == False
    assert BaseFormat.is_native_type({}) == False
    assert BaseFormat.is_native_type(()) == False
    assert BaseFormat.is_native_type(set()) == False
    assert BaseFormat.is_native_type(frozenset()) == False
    assert BaseFormat.is_native_type(True) == False
    assert BaseFormat.is_native_type(False) == False
    assert BaseFormat.is_native_type(None) == False

# Generated at 2022-06-22 06:05:47.497759
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert isinstance(TimeFormat(), BaseFormat)


# Generated at 2022-06-22 06:05:58.440728
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    value1 = "2019-01-01"
    value2 = "2019-13-32"
    value3 = "2019-01-32"
    value4 = "2019-01-01Z"
    value5 = "20190101"
    date = DateFormat()
    
    try:
        date.validate(value1)
    except ValidationError as e:
        print(e)
    try:
        date.validate(value2)
    except ValidationError as e:
        print(e)
    try:
        date.validate(value3)
    except ValidationError as e:
        print(e)
    try:
        date.validate(value4)
    except ValidationError as e:
        print(e)

# Generated at 2022-06-22 06:06:04.628790
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    print(DateTimeFormat().serialize(datetime.datetime.strptime("2020-08-06T09:03:30", '%Y-%m-%dT%H:%M:%S')))
    print(DateTimeFormat().serialize(datetime.datetime(2021, 10, 7, 10, 4, 31)))
    print(DateTimeFormat().serialize(None))



# Generated at 2022-06-22 06:06:06.544940
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert issubclass(UUIDFormat, BaseFormat)


# Generated at 2022-06-22 06:06:09.570821
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuidf = UUIDFormat()
    uuid1 = uuid.uuid1()
    assert uuidf.is_native_type(uuid1) == True



# Generated at 2022-06-22 06:06:10.896942
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    os.system("python testBaseFormat.py")

# Generated at 2022-06-22 06:06:15.686476
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    test_class = BaseFormat()
    expected_value = ValidationError(text='text.format()', code='code')
    test_class.errors = {'code': 'text.format({})'}
    actual_value = test_class.validation_error('code')
    assert expected_value == actual_value



# Generated at 2022-06-22 06:06:26.950924
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    assert df.is_native_type(datetime.datetime(year=2018, month=12, day=23, hour=11, minute=22, second=33, microsecond=440)) == True
    assert df.is_native_type(datetime.time(hour=11, minute=22, second=33, microsecond=440)) == False
    assert df.is_native_type(datetime.datetime.now()) == True
    assert df.is_native_type(datetime.date(year=2018, month=12, day=23)) == True
    assert df.is_native_type(datetime.time()) == False
    assert df.is_native_type(datetime.date.today()) == True


# Generated at 2022-06-22 06:06:29.928933
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = "15:07:35.569"
    time_format = TimeFormat()
    time_format.validate(time)
    assert time_format.serialize(time) == time


# Generated at 2022-06-22 06:06:38.612620
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    from datetime import datetime
    assert TimeFormat().is_native_type(datetime(hour=0, minute=0, second=0))
    assert not TimeFormat().is_native_type(datetime(year=0, month=0, day=0))


# Generated at 2022-06-22 06:06:42.725798
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate('1999-12-31') == datetime.date(1999,12,31)


# Generated at 2022-06-22 06:06:45.988858
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    d = DateTimeFormat()
    assert(d, "Value must be a valid datetime format.")
    assert(d.is_native_type("Value must be a real datetime."))
    assert(d.validate("Value must be a valid datetime format."))
    assert(d.serialize("Value must be a real datetime."))

# Generated at 2022-06-22 06:06:50.539019
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(12, 34, 56, 999888)
    # assert TimeFormat().serialize(time) == "12:34:56.999888" # Expected result
    assert TimeFormat().serialize(time) == "12:34:56.999888" # Expected result
