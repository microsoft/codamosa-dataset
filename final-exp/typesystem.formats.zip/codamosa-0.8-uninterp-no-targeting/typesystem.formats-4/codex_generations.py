

# Generated at 2022-06-22 05:57:12.433949
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    class TestUUIDFormat(UUIDFormat):
        pass
    assert TestUUIDFormat()



# Generated at 2022-06-22 05:57:14.941758
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base_format = BaseFormat()
    base_format.errors = {"code": "text"}
    assert base_format.validation_error("code").text == "text"



# Generated at 2022-06-22 05:57:20.574754
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    attr = UUIDFormat()
    uid = uuid.UUID('6a7a8f3d-f7fd-47b9-8b5d-d5f46c0f5a67')
    assert attr.serialize(uid) == '6a7a8f3d-f7fd-47b9-8b5d-d5f46c0f5a67'


# Generated at 2022-06-22 05:57:21.905099
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    t = BaseFormat()

    assert t.is_native_type(1) == True


# Generated at 2022-06-22 05:57:24.655219
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tt = TimeFormat()
    tt.validate("10:20:30.1234")

# Generated at 2022-06-22 05:57:33.070992
# Unit test for constructor of class DateFormat
def test_DateFormat():
    # Case 1: Testing the return type of function validate() of class DateFormat
    assert isinstance(DateFormat().validate("2020-02-21"), datetime.date)

    # Case 2: Testing the return type of function serialize() of class DateFormat
    assert isinstance(DateFormat().serialize("2020-02-21"), str)


# Generated at 2022-06-22 05:57:37.403002
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtf = DateTimeFormat()
    match = dtf.validate('2019-09-10T24:00:59.000000+00:00')
    assert match.hour == 24

# Generated at 2022-06-22 05:57:39.336791
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date.today()) is not None

# Generated at 2022-06-22 05:57:41.052784
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2020, 5, 15)) == True


# Generated at 2022-06-22 05:57:50.544773
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestFormat(BaseFormat):
        errors = {"invalid": "Invalid {param} for {type}."}

    t = TestFormat()
    try:
        t.validation_error("invalid")
        assert False, "test failed. Expected to be false."
    except ValidationError as e:
        assert e.code is 'invalid'
        assert e.text is 'Invalid param for type.'
    try:
        t.validation_error("invalid", param='test', type ='test')
        assert False, "test failed. Expected to be false."
    except ValidationError as e:
        assert e.code is 'invalid'
        assert e.text is 'Invalid test for test.'


# Generated at 2022-06-22 05:57:57.595693
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date.today()) == True
    assert date_format.is_native_type(datetime.date.today().isoformat()) == False
    assert date_format.is_native_type(None) == False


# Generated at 2022-06-22 05:58:00.488637
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    date = datetime.date(year=2020, month=1, day=1)
    assert date_format.serialize(date) == "2020-01-01"


# Generated at 2022-06-22 05:58:05.988416
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert UUIDFormat().validate('65bc3343-d1c1-4961-97fc-16e8d2cdfa61') == uuid.UUID('65bc3343-d1c1-4961-97fc-16e8d2cdfa61')


# Generated at 2022-06-22 05:58:08.813374
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj1 = datetime.date(2019, 6, 30)
    obj2 = None

    assert DateFormat().serialize(obj1) == obj1.isoformat()
    assert DateFormat().serialize(obj2) == None

# Generated at 2022-06-22 05:58:15.675970
# Unit test for constructor of class DateFormat
def test_DateFormat():
    d = DateFormat()
    assert d.is_native_type(datetime.date(2018, 9, 28)) == True
    #assert type(d.validate("2018-09-28") == datetime.date)
    assert d.serialize(datetime.date(2018, 9, 28)) == "2018-09-28"
    return True


# Generated at 2022-06-22 05:58:26.194973
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    test_value = uuid.uuid1()
    test_string = "123e4567-e89b-12d3-a456-426655440000"

    test = UUIDFormat()
    assert test.is_native_type(test_value) == True
    assert test.validate(test_string) is not None
    assert test.serialize(test_value) is not None
    assert test.validate(test_value) == test_value
    assert test.serialize(test_string) is not None
    assert test.serialize(test_string) == test_string

# Generated at 2022-06-22 05:58:27.611739
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert type(TimeFormat()).__name__ == 'TimeFormat'


# Generated at 2022-06-22 05:58:31.401958
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    format = BaseFormat()
    with pytest.raises(NotImplementedError):
        format.validate(3)


# Generated at 2022-06-22 05:58:35.286143
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 7, 24, 12, 12, 12, 1234)
    print(dt)
    dt_serialize = DateTimeFormat().serialize(dt)
    print(dt_serialize)
    assert isinstance(dt_serialize,str)


# Generated at 2022-06-22 05:58:41.033027
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date_format = DateFormat()
    with pytest.raises(NotImplementedError):
        date_format.is_native_type("")
    with pytest.raises(NotImplementedError):
        date_format.validate("")
    with pytest.raises(NotImplementedError):
        date_format.serialize("")


# Generated at 2022-06-22 05:58:49.098953
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
  assert TimeFormat().is_native_type(datetime.time)


# Generated at 2022-06-22 05:58:51.367014
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    try:
        BaseFormat().serialize(None)
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-22 05:58:57.952480
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    a = DateTimeFormat()
    c = datetime.datetime(2020, 4, 20, 23, 53)
    assert a.is_native_type(c) == True
    a = DateFormat()
    c = datetime.date(2020, 4, 20)
    assert a.is_native_type(c) == True
    a = TimeFormat()
    c = datetime.time(23, 53)
    assert a.is_native_type(c) == True
    a = UUIDFormat()
    c = uuid.uuid1()
    assert a.is_native_type(c) == True


# Generated at 2022-06-22 05:59:02.817182
# Unit test for constructor of class DateFormat
def test_DateFormat():
    errors_expect = {
        "format": "Must be a valid date format.",
        "invalid": "Must be a real date.",
    }
    date_instance = DateFormat()

    assert date_instance.errors == errors_expect


# Generated at 2022-06-22 05:59:06.567998
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    from typesystem.fields import Date
    date = Date(format="date")
    data = date.serialize(None)
    assert data == None
    data = date.serialize("2020-03-23")
    assert data == "2020-03-23"

# Generated at 2022-06-22 05:59:08.892677
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    d = datetime.date.today()
    assert df.is_native_type(d)


# Generated at 2022-06-22 05:59:11.405677
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert isinstance(TimeFormat(), TimeFormat)
    # Unit test for is_native_type method of class TimeFormat

# Generated at 2022-06-22 05:59:19.300742
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time.is_native_type((0, 0)) == False
    assert time.is_native_type(1) == False
    assert time.is_native_type(datetime.time(0, 0)) == True
    assert time.validate(datetime.time(0, 0)) == datetime.time(0, 0)
    assert time.serialize(datetime.time(0, 0)) == '00:00:00'
#Unit test for constructor of class DateFormat

# Generated at 2022-06-22 05:59:20.653994
# Unit test for constructor of class DateFormat
def test_DateFormat():
	assert(DATE_REGEX.match("2019-12-15"))


# Generated at 2022-06-22 05:59:24.315334
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    valid_sample = uuid.uuid4()
    invalid_sample = 1

    test_object = UUIDFormat()

    assert test_object.is_native_type(valid_sample) == True
    assert test_object.is_native_type(invalid_sample) == False


# Generated at 2022-06-22 05:59:29.430543
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    time_format = TimeFormat()
    value = datetime.time(12,1)
    assert time_format.is_native_type(value) == True


# Generated at 2022-06-22 05:59:33.499699
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class subBaseFormat(BaseFormat):
        def is_native_type(self, value : typing.Any) -> bool:
            return True
    
    assert subBaseFormat().is_native_type('Hello') == True

# Generated at 2022-06-22 05:59:35.610116
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
	date_format = DateFormat()
	assert not date_format.is_native_type(2)


# Generated at 2022-06-22 05:59:46.678288
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type("91a7e9e0-f37d-45a8-821e-2a74db1a57d7") == False
    assert uuid_format.is_native_type("91a7e9e0f37d45a8821e2a74db1a57d7") == False
    assert uuid_format.is_native_type("91A7E9E0F37D45A8821E2A74DB1A57D7") == False
    assert uuid_format.is_native_type("g1a7e9e0-f37d-45a8-821e-2a74db1a57d7") == False

# Generated at 2022-06-22 05:59:57.591319
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    utc = datetime.timezone.utc
    tz = datetime.timezone(datetime.timedelta(hours=1), 'CET')

# Generated at 2022-06-22 06:00:01.209898
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date_format = DateFormat()
    date1 = date_format.serialize(datetime.date(2019, 11, 25))
    date2 = date_format.serialize(None)
    assert date1 == '2019-11-25'
    assert date2 is None


# Generated at 2022-06-22 06:00:03.035247
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    DateFormat().validate("1990-10-1")



# Generated at 2022-06-22 06:00:15.145548
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # test first condition
    assert DateTimeFormat().serialize(None) == None

    # test second condition
    dt = datetime.datetime.now()
    assert isinstance(DateTimeFormat().serialize(dt), str)

    # test third condition
    dt = datetime.datetime(2019, 9, 5, 1, 15, 9, 123456, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(dt) == "2019-09-05T01:15:08.123456+00:00"

    # test forth condition
    dt = datetime.datetime(2019, 9, 5, 1, 15, 9, 123456)
    assert DateTimeFormat().serialize(dt) == "2019-09-05T01:15:08.123456"

# Unit test

# Generated at 2022-06-22 06:00:19.149901
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
	try:
		BaseFormat().validate('test')
	except NotImplementedError as e:
		assert str(e) == 'BaseFormat.validate() is not implemented.'

# Generated at 2022-06-22 06:00:24.063483
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    time = datetime.time(11, 5, 29, 123456)
    time2 = datetime.time(11, 5, 29, 123456, tzinfo=datetime.timezone.utc)

    assert(tf.serialize(time) == "11:05:29.123456")
    assert(tf.serialize(time2) == "11:05:29.123456Z")


# Generated at 2022-06-22 06:00:26.783721
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    pass


# Generated at 2022-06-22 06:00:29.482619
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    value = datetime.datetime(2018, 11, 27, 2, 42, 2, 8)
    assert(DateTimeFormat().is_native_type(value))


# Generated at 2022-06-22 06:00:39.358166
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class BaseFormat(BaseFormat):
        def __init__(self, value):
            self.value = value
    # Test invalid
    def test_invalid():
        baseFormat = BaseFormat('x')
        try:
            baseFormat.validate('y')
        except NotImplementedError:
            assert True
        else:
            assert False
    test_invalid()
    # Test valid
    def test_valid():
        baseFormat = BaseFormat('x')
        try:
            baseFormat.validate('x')
        except NotImplementedError:
            assert False
        else:
            assert True
    test_valid()


# Generated at 2022-06-22 06:00:47.693865
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    try:
        uuid_format.validate('test')
    except ValidationError as e:
        assert e.code == 'format'
    else:
        assert False, 'ValidationError should be raised'

    u = uuid_format.validate('123e4567-e89b-12d3-a456-426655440000')
    assert isinstance(u, uuid.UUID)


# Generated at 2022-06-22 06:00:51.064479
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uf = UUIDFormat()
    assert uf.is_native_type(1) == False

# Generated at 2022-06-22 06:00:56.253366
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2019, 12, 25))
    assert DateFormat().is_native_type(datetime.date(2019, 12, 25))
    assert DateTimeFormat().is_native_type(datetime.datetime.now())
    assert UUIDFormat().is_native_type(uuid.uuid4())



# Generated at 2022-06-22 06:01:00.841022
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_data = uuid.uuid4()
    uuid_format = UUIDFormat()
    assert uuid_format.validate(uuid_data) == uuid_data

# Generated at 2022-06-22 06:01:05.691846
# Unit test for constructor of class DateFormat
def test_DateFormat():
    # example 
    d1 = datetime.date(2020, 4, 9)
    # create object of DateFormat
    string = d1.isoformat()
    date_format = DateFormat()
    assert date_format.is_native_type(d1) == True
    assert date_format.validate(string) == d1
    assert date_format.serialize(d1) == string


# Generated at 2022-06-22 06:01:06.421221
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat() is not None

# Generated at 2022-06-22 06:01:09.908850
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_fmt = DateFormat()
    now = datetime.date.today()
    assert date_fmt.is_native_type(now)
    assert date_fmt.is_native_type('2018-03-03') == False

# Generated at 2022-06-22 06:01:23.788987
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    """

    :return:
    """

# Generated at 2022-06-22 06:01:27.033036
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    # cast to str from object
    testTime = TimeFormat()

    testTimeObject = datetime.time(1, 2, 3, 4)

    assert testTime.serialize(testTimeObject) == "01:02:03.000004"

# Generated at 2022-06-22 06:01:31.687272
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    BaseFormat().serialize(obj=1)
    BaseFormat().serialize(obj=None)
    BaseFormat().serialize(obj=1.0)
    assert BaseFormat().serialize(obj="")==""


# Generated at 2022-06-22 06:01:42.767104
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()
    assert format.validate("2017-12-31") == datetime.date(2017, 12, 31)
    assert format.validate("2017-2-31") == datetime.date(2017, 2, 31)
    assert format.validate("2017-2-1") == datetime.date(2017, 2, 1)
    assert format.validate("2017-2-2") == datetime.date(2017, 2, 2)
    assert format.validate("2017-12-1") == datetime.date(2017, 12, 1)
    assert format.validate("2017-1-1") == datetime.date(2017, 1, 1)
    

# Generated at 2022-06-22 06:01:48.900468
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 10, 16, tzinfo=datetime.timezone.utc)) == "2020-10-16T00:00:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 10, 16, tzinfo=datetime.timezone(datetime.timedelta(hours=5)))) == "2020-10-16T00:00:00+05:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 10, 16, tzinfo=datetime.timezone(datetime.timedelta(hours=11)))) == "2020-10-16T00:00:00+11:00"


# Generated at 2022-06-22 06:01:54.321173
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type("2020-01-27") == False
    assert date_format.is_native_type(datetime.date(2020, 1, 27)) == True

# Generated at 2022-06-22 06:02:05.155845
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    obj = DateTimeFormat()
    assert obj.is_native_type(None) is False
    assert obj.is_native_type(1) is False
    assert obj.is_native_type("2020-03-03T03:03:03Z") is False
    assert obj.is_native_type(datetime.datetime(2020, 2, 5, 2, 1, 2, 5555)) is True
    assert obj.is_native_type(datetime.datetime(2020, 2, 5, 2, 1, 2)) is True
    assert obj.is_native_type(datetime.datetime(2020, 2, 5, 2, 1)) is True
    assert obj.is_native_type(datetime.datetime(2020, 2, 5, 2, 1, tzinfo=0)) is True
    assert obj.is_

# Generated at 2022-06-22 06:02:09.117239
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    str1 = "12:02:00.000000"
    obj = TimeFormat()
    assert obj.serialize(str1) == str1

# Generated at 2022-06-22 06:02:14.722180
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    """
    Function to test the serialize method of class DateFormat
    """
    date = datetime.datetime(2020, 2, 29)
    date = date.date()
    assert DateFormat().serialize(date) == date.isoformat()


# Generated at 2022-06-22 06:02:26.691044
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test case 1: 
    testCase = DateFormat()
    try:
        validation = testCase.validate("2020-02-30")
    except ValueError:
        exception = "invalid"
    assert exception == "invalid"
    # Test case 2: 
    testCase = DateFormat()
    try:
        validation = testCase.validate("2020-2-2")
    except ValueError:
        exception = testCase.validation_error("format")
    assert exception == "Must be a valid date format."
    # Test case 3: 
    testCase = DateFormat()
    try:
        validation = testCase.validate("30/2/2020")
    except ValueError:
        exception = testCase.validation_error("format")
    assert exception == "Must be a valid date format."

#

# Generated at 2022-06-22 06:02:29.520422
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    UUIDFormat()


# Generated at 2022-06-22 06:02:32.842089
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():

        print('test_UUIDFormat_serialize')
        a = datetime.datetime.now()
        obj = uuid.uuid4()
        s = UUIDFormat().serialize(obj)

        print(obj)
        print(s)

        b = datetime.datetime.now()
        print(b-a)

# Generated at 2022-06-22 06:02:44.500339
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    str1 = "2020-03-20T12:00:00"
    str2 = "2020-03-20T12:00:00Z"
    str3 = "2020-03-20T12:00:00-05:00"
    obj1 = datetime.datetime.strptime(str1, '%Y-%m-%dT%H:%M:%S')
    obj2 = datetime.datetime.strptime(str2, '%Y-%m-%dT%H:%M:%SZ')
    obj3 = datetime.datetime.strptime(str3, '%Y-%m-%dT%H:%M:%S%z')
    assert DateTimeFormat().serialize(obj1) == "2020-03-20T12:00:00"

# Generated at 2022-06-22 06:02:56.209903
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateformat = DateTimeFormat()
    # invalid format
    value = "2016-08-09T10:11:12Z"
    # should have raise
    with pytest.raises(ValidationError, match="Must be a valid datetime format."):
        dateformat.validate(value)

    # valid format
    value = "2016-08-09T10:11:12.123456Z"
    result = dateformat.validate(value)
    assert result == datetime.datetime(2016, 8, 9, 10, 11, 12, 123456, tzinfo=datetime.timezone.utc)
    # should have raise

# Generated at 2022-06-22 06:03:00.487317
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    d = datetime.date(2020, 11, 7)
    assert DateFormat().is_native_type(d)
    d_str = "2021-11-07"
    assert not DateFormat().is_native_type(d_str)


# Generated at 2022-06-22 06:03:04.967175
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat.validate(TimeFormat(), "12:00:00") == datetime.time(12, 0, 0)
    assert TimeFormat.validate(TimeFormat(), "12:34:56.123456") == datetime.time(12, 34, 56, 123456)


# Generated at 2022-06-22 06:03:07.956380
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = "00:30:00.000000"
    format_time = TimeFormat()
    assert format_time.validate(time) == datetime.time(0, 30, 0, 0)


# Generated at 2022-06-22 06:03:12.661467
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    """Test for TimeFormat.serialize()."""
    format = TimeFormat()
    value = format.serialize(datetime.time(hour=1, minute=2, second=3, microsecond=4))
    assert value == "01:02:03.000004"

# Generated at 2022-06-22 06:03:14.083968
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat()


# Generated at 2022-06-22 06:03:15.627572
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    format1 = UUIDFormat()
    assert format1 is not None

# Generated at 2022-06-22 06:03:20.592351
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    f=TimeFormat() ;
    flag=f.is_native_type(datetime.time(hour=12,minute=12,second=12,microsecond=12))
    assert flag == True



# Generated at 2022-06-22 06:03:24.721995
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    d = DateTimeFormat()
    # dt = datetime.datetime.now()
    assert d.errors == {"format": "Must be a valid datetime format.",
                        "invalid": "Must be a real datetime."}

# Generated at 2022-06-22 06:03:31.406183
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    format_a = BaseFormat()
    format_b = DateFormat()
    format_c = TimeFormat()
    format_d = DateTimeFormat()
    format_e = UUIDFormat()
    assert format_a.is_native_type(None) == False
    assert format_b.is_native_type(None) == False
    assert format_c.is_native_type(None) == False
    assert format_d.is_native_type(None) == False
    assert format_e.is_native_type(None) == False


# Generated at 2022-06-22 06:03:34.116499
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4())
    assert not UUIDFormat().is_native_type(datetime.datetime.now())


# Generated at 2022-06-22 06:03:39.709178
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    f = UUIDFormat()
    uuid = f.validate("3dcdc7b0-8e6d-4d38-9db4-b4df4bce4cdf")
    assert f.serialize(uuid) == "3dcdc7b0-8e6d-4d38-9db4-b4df4bce4cdf"



# Generated at 2022-06-22 06:03:47.274552
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert DateFormat().is_native_type(datetime.date(2020, 5, 1)) == True
    assert TimeFormat().is_native_type(datetime.time(hour=16, minute=23, second=44)) == True
    assert DateTimeFormat().is_native_type(datetime.datetime(2020, 5, 1, hour=16, minute=23, second=44)) == True
    assert UUIDFormat().is_native_type(uuid.uuid4()) == True


# Generated at 2022-06-22 06:03:53.930336
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
	
	# A function to test the constructor of UUIDFormat
	def valid_UUIDFormat():
		return UUIDFormat()
		
	assert valid_UUIDFormat is not None
	

# Generated at 2022-06-22 06:03:57.026752
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.datetime.now().date()
    date_format = DateFormat()
    date_string = date_format.serialize(date)
    assert date_string == date.isoformat()


# Generated at 2022-06-22 06:03:59.307162
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    obj = BaseFormat()
    assert obj.serialize(None) is None

# Generated at 2022-06-22 06:04:02.697971
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    BaseFormat().is_native_type("")
    BaseFormat().is_native_type([])
    BaseFormat().is_native_type({})
    BaseFormat().is_native_type(())


# Generated at 2022-06-22 06:04:08.614405
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    with pytest.raises(NotImplementedError):
        BaseFormat().is_native_type(int(1))


# Generated at 2022-06-22 06:04:13.393277
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    date = datetime.datetime.now()
    time = TimeFormat()
    assert time.is_native_type(date) == True
    assert time.validate(date.time()) == date.time()
    assert time.serialize(date.time()) == date.time().isoformat()


# Generated at 2022-06-22 06:04:17.878655
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_string = "12345678-1234-5678-1234-567812345678"
    uuid_obj = uuid.UUID(uuid_string)
    assert UUIDFormat().is_native_type(uuid_obj) is True

# Generated at 2022-06-22 06:04:20.199150
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(12, 30)
    result = TimeFormat().serialize(time)
    assert result == '12:30:00'

# Generated at 2022-06-22 06:04:23.567829
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    assert TimeFormat().is_native_type(datetime.time(12, 30)) == True
    assert TimeFormat().is_native_type("12:30") == False



# Generated at 2022-06-22 06:04:30.645467
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    df = DateTimeFormat()
    test1 = df.validate('2020-04-03T03:30:22.123456+02:00')
    test2 = df.validate('2020-04-03T03:30:22.123456Z')
    test3 = df.validate('2020-04-03T03:30:22Z')
    test4 = df.validate('2020-04-03T03:30:22')
    print(test1, test2, test3, test4)

# Generated at 2022-06-22 06:04:33.344931
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    date = datetime.datetime(2001, 11, 12, 14, 15, 16, 123456)

    assert TimeFormat().serialize(date.time()) == '14:15:16.123456'

# Generated at 2022-06-22 06:04:39.357199
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    fmt = DateFormat()

    # Test good format
    assert fmt.validate('2020-01-02') == datetime.date(2020, 1, 2)

    # Test bad format
    with pytest.raises(ValidationError) as excinfo:
        fmt.validate('2020-01-32')

    assert excinfo.value.code == 'invalid'


# Generated at 2022-06-22 06:04:43.863620
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    print("test_DateTimeFormat_validate")
    dateTimeFormat = DateTimeFormat()
    try:
        dateTimeFormat.validate('2014-12-01T13:01:23Z')
    except:
        print("error")
        assert False
    else:
        assert True

# Generated at 2022-06-22 06:04:47.148382
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert DateTimeFormat().validate("2014-05-12T03:45:45.123345") == datetime.datetime(2014, 5, 12, 3, 45, 45, 123345)

# Generated at 2022-06-22 06:04:53.150608
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    format_base = BaseFormat()
    with pytest.raises(NotImplementedError):
        format_base.validate(1)



# Generated at 2022-06-22 06:05:00.817255
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    A = UUIDFormat()
    assert A.is_native_type(uuid.UUID("70a296ff-dfc8-4eea-a63c-eb7a50a2c4a3"))
    assert A.validate("70a296ff-dfc8-4eea-a63c-eb7a50a2c4a3") == uuid.UUID("70a296ff-dfc8-4eea-a63c-eb7a50a2c4a3")


# Generated at 2022-06-22 06:05:05.357542
# Unit test for constructor of class DateFormat
def test_DateFormat():
    date = datetime.date(2020, 3, 16)
    date_format = DateFormat()
    expected_value = date
    value = date_format.is_native_type(date)
    assert value == expected_value


# Generated at 2022-06-22 06:05:06.040299
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    pass

# Generated at 2022-06-22 06:05:07.744190
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtf = DateTimeFormat()
    assert dtf

# Generated at 2022-06-22 06:05:11.611316
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    print("Test validation_error")
    # Given
    class MyFormat(BaseFormat):
        errors = {
            "format": "Must be valid.",
        }

    # When
    my_format = MyFormat()

    # Then
    assert my_format.errors == {"format": "Must be valid."}
    assert my_format.validation_error("format").text == "Must be valid."
    assert my_format.validation_error("format").code == "format"


# Generated at 2022-06-22 06:05:14.472242
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    dt = datetime.date(2019,1,1)
    assert df.serialize(dt) == "2019-01-01"


# Generated at 2022-06-22 06:05:19.206766
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d = DateFormat()
    return d.serialize(datetime.date(2020,1,1)) == "2020-01-01"


# Generated at 2022-06-22 06:05:25.460319
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    test = UUIDFormat()
    assert test.serialize("98b2eca2-e4f4-4b4d-a3cf-d4582f9b0eab") == "98b2eca2-e4f4-4b4d-a3cf-d4582f9b0eab"

if __name__ == "__main__":
    test_UUIDFormat_serialize()

# Generated at 2022-06-22 06:05:28.197552
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormatValid = TimeFormat()
    timeFormatInvalid1 = TimeFormat()
    timeFormatInvalid2 = TimeFormat()


test_TimeFormat_validate()


# Generated at 2022-06-22 06:05:53.732472
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_1 = uuid.UUID('{123e4567-e89b-12d3-a456-426655440000}')
    uuid_2 = uuid.UUID('123e4567-e89b-12d3-a456-426655440000')
    uuid_3 = '123e4567-e89b-12d3-a456-426655440000'
    uuid_4 = 123
    uuid_5 = '{123e4567-e89b-12d3-a456-4266554400'
    uuid_6 = 'a123e4567-e89b-12d3-a456-426655440000'   
    test1 = UUIDFormat()
    print(test1.validate(uuid_1))
    print

# Generated at 2022-06-22 06:05:56.474838
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    obj = TimeFormat()
    assert obj.is_native_type(datetime.time())
    assert not obj.is_native_type(None)


# Generated at 2022-06-22 06:06:00.091775
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    test_value = "2011-05-16T20:22:19"
    test = DateTimeFormat()
    test.validate(test_value)
    assert test.validate(test_value) == datetime.datetime(2011, 5, 16, 20, 22, 19)

# Generated at 2022-06-22 06:06:04.341534
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uf = UUIDFormat()
    value = uf.validate("184e08ce-c2e7-47ac-acda-7f8d9b8510e6")
    assert type(value) == uuid.UUID


# Generated at 2022-06-22 06:06:08.685257
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    date.validate('2019-01-01')
    date.validate('2019-2-1')
    try:
        date.validate('2019-13-01')
    except:
        print('Validate Date Format Passed')


# Generated at 2022-06-22 06:06:10.281990
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
  assert BaseFormat().validation_error('code') is not None


# Generated at 2022-06-22 06:06:12.862563
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    assert BaseFormat().validation_error('invalid') == ValidationError(text= 'invalid', code='invalid')


# Generated at 2022-06-22 06:06:24.747946
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(0, 0, 0)) == '00:00:00'
    assert TimeFormat().serialize(datetime.time(0, 0, 0, 0)) == '00:00:00'
    assert TimeFormat().serialize(datetime.time(0, 0, 0, 1)) == '00:00:00.000001'
    assert TimeFormat().serialize(datetime.time(0, 0, 0, 100)) == '00:00:00.000100'
    assert TimeFormat().serialize(datetime.time(0, 0, 0, 1000)) == '00:00:00.001000'
    assert TimeFormat().serialize(datetime.time(0, 0, 0, 10000)) == '00:00:00.010000'

# Generated at 2022-06-22 06:06:26.527976
# Unit test for constructor of class DateFormat
def test_DateFormat():
    a = DateFormat()
    assert isinstance(a.errors, dict)


# Generated at 2022-06-22 06:06:31.782671
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_format = UUIDFormat()
    assert isinstance(uuid_format, BaseFormat)


# Generated at 2022-06-22 06:06:47.327970
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert isinstance(UUIDFormat(), UUIDFormat)

if __name__ == "__main__":
    test_UUIDFormat()
    print("DONE")

# Generated at 2022-06-22 06:06:55.754233
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    test_object1 = datetime.date(1999, 1, 1)
    test_object2 = "1999-02-02"
    test_object3 = datetime.time(7, 53)
    test_object4 = datetime.datetime(1999, 1, 1)
    test_object5 = uuid.UUID('123e4567-e89b-12d3-a456-426655440000')
    object1 = DateFormat()
    object2 = TimeFormat()
    object3 = DateTimeFormat()
    object4 = UUIDFormat()
    assert object1.is_native_type(test_object1) == True # test if the method returns the correct value
    assert object1.is_native_type(test_object2) == False # test if the method returns the correct value
    assert object1.is_

# Generated at 2022-06-22 06:06:59.081098
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    format_test = BaseFormat()
    with pytest.raises(NotImplementedError):
        format_test.is_native_type(5)
