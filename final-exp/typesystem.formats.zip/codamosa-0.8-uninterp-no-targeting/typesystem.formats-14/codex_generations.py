

# Generated at 2022-06-22 05:57:12.599289
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert DateFormat().validate("1956-5-5") == datetime.date(1956, 5, 5)
    assert DateFormat().validate("1111-11-11") == datetime.date(1111, 11, 11)


# Generated at 2022-06-22 05:57:21.938683
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    import datetime
    # create an instance of class DateTimeFormat
    obj_DateTimeFormat=DateTimeFormat()
    # check that obj_DateTimeFormat is a instance of class DateTimeFormat
    assert isinstance(obj_DateTimeFormat, DateTimeFormat), "An instance of class DateTimeFormat was not created"
    # check the output of method is_native_type, when the input parameter is a instace of datetime
    assert obj_DateTimeFormat.is_native_type(value=datetime.datetime(2010,6,29,6,44,44)) == True, "the output of method is_native_type is incorrect"
    # check the output of method is_native_type, when the input parameter is a instace of int

# Generated at 2022-06-22 05:57:25.421977
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    test_1 = BaseFormat()
    try:
        test_1.validation_error("test")
    except NotImplementedError:
        pass


# Generated at 2022-06-22 05:57:30.752877
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date = datetime.date(2020,8,30)
    format = DateFormat()
    assert format.serialize(date) == '2020-08-30'

# Generated at 2022-06-22 05:57:33.306068
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class TestBaseFormat(BaseFormat):
        def is_native_type(self, value):
            return True

        def validate(self, value):
            return 1
        
    assert TestBaseFormat().serialize(1) == None


# Generated at 2022-06-22 05:57:40.938294
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    test_obj_1 = datetime.time(12, 59, 59)
    test_obj_2 = None
    time_format = TimeFormat()
    try:
        assert time_format.serialize(test_obj_1) == '12:59:59'
        assert time_format.serialize(test_obj_2) == None
        print('Pass')
    except AssertionError:
        print('Fail')


# Generated at 2022-06-22 05:57:49.764119
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    DTF = DateTimeFormat()
    # Test that a valid datetime is recognized
    assert DTF.is_native_type("2020-06-05T19:48:50.297630") == True
    # Test that some invalid datetimes are not recognized
    assert DTF.is_native_type("2020-06-05T19:48:50.297630Z") == False
    assert DTF.is_native_type("2020-99-05T19:48:50.297630") == False
    assert DTF.is_native_type("2020-06-05T99:48:50.297630") == False


# Generated at 2022-06-22 05:57:59.608571
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    # Case 1: Raise ValidationError with code is format
    with pytest.raises(ValidationError) as e:
        tf.validate("abc12")
    assert e.value.code == "format"
    # Case 2: Raise ValidationError with code is invalid
    with pytest.raises(ValidationError) as e:
        tf.validate("26:00")
    assert e.value.code == "invalid"
    # Case 3: Convert a time string to datetime.time
    time_str = "23:15:29"
    time = tf.validate(time_str)
    assert time.strftime("%H:%M:%S") == time_str


# Generated at 2022-06-22 05:58:05.384050
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    a = UUIDFormat()
    text = "b17c23cb-6a88-49b7-8a32-2a7880105b70"
    b = a.validate(text)
    assert b == uuid.UUID(text)

# Generated at 2022-06-22 05:58:17.494329
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    values = [
        "15:30:00",
        "15:30:00.123456",
        "15:30:00.12",
        "15:30:00.1",
        "15:30:00.0",
        "15:30:00.000000000000",
        "15:30:59.999999",
        "15:30:59.9999",
        "15:30:59.999",
        "15:30:59.99",
        "15:30:59.9",
        "15:30:59",
        "15:30:1",
        "15:30:0",
        "15:30",
        "15:1",
        "15:0",
        "15",
    ]


# Generated at 2022-06-22 05:58:28.268180
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class MyFormat(BaseFormat):
        errors = {
            "format": "Must be a valid time format.",
            "invalid": "Must be a real time.",
        }

    mf = MyFormat()
    value1 = mf.validation_error("format")
    assert value1.text == "Must be a valid time format."
    assert value1.code == "format"
    value2 = mf.validation_error("invalid")
    assert value2.text == "Must be a real time."
    assert value2.code == "invalid"


# Generated at 2022-06-22 05:58:31.757407
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2018, 6, 3, 12, 30)) == '2018-06-03T12:30:00'

# Generated at 2022-06-22 05:58:39.142105
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    test1 = "b9cfd33c-e5a5-5d5c-b5fb-a5a5a5a5a5a5"
    test2 = "b9cfd33c-e5a5-5d5c-b5fb-a5a5a5a5a5a56"
    uf = UUIDFormat()
    match1 = UUID_REGEX.match(test1)
    assert match1 is not None
    uf.validate(test1)
    match2 = UUID_REGEX.match(test2)
    assert match2 is None
    uf.validate(test2)

# Generated at 2022-06-22 05:58:41.707493
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    errors = ["error_code"]
    BaseFormat.errors = errors
    assert BaseFormat.validation_error(BaseFormat, "error_code") in errors


# Generated at 2022-06-22 05:58:43.708008
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    instance = BaseFormat()
    instance.errors = {}
    assert instance.errors == {}


# Generated at 2022-06-22 05:58:49.528886
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    d = DateTimeFormat().validate('2019-04-01T00:00:00Z')
    assert d == datetime.datetime(2019, 4, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)



# Generated at 2022-06-22 05:58:54.099852
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value = "2019-05-01T12:00:00Z"
    dt_fmt = DateTimeFormat()
    result = dt_fmt.validate(value)
    print(result)

if __name__ == "__main__":
    test_DateTimeFormat_validate()

# Generated at 2022-06-22 05:58:57.924622
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    assert BaseFormat().validation_error('value') == ValidationError(text='Must be a BaseFormat type.', code='value')


# Generated at 2022-06-22 05:59:02.815750
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    obj = UUIDFormat()
    assert obj.is_native_type(uuid.uuid4())
    assert not obj.is_native_type(uuid.uuid4().int)
    assert not obj.is_native_type(uuid.uuid4().hex)

# Generated at 2022-06-22 05:59:03.996083
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
	UUIDFormat()

# Generated at 2022-06-22 05:59:10.288888
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    assert isinstance(DateTimeFormat(), DateTimeFormat)

# Generated at 2022-06-22 05:59:12.580888
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    format_ = BaseFormat()
    with pytest.raises(NotImplementedError):
        format_.validate("1")


# Generated at 2022-06-22 05:59:21.925297
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    assert TimeFormat().serialize(datetime.time(12,30,45,123456)) == "12:30:45.123456"
    assert TimeFormat().serialize(datetime.time(12,30,45,123450)) == "12:30:45.123450"
    assert TimeFormat().serialize(datetime.time(12,30,45,123400)) == "12:30:45.123400"
    assert TimeFormat().serialize(datetime.time(12,30,45,123000)) == "12:30:45.123000"
    assert TimeFormat().serialize(datetime.time(12,30,45,120000)) == "12:30:45.120000"

# Generated at 2022-06-22 05:59:24.563866
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    bf.errors['f1']='f1 is true'
    assert bf.validation_error('f1').text=='f1 is true'


# Generated at 2022-06-22 05:59:26.810671
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    input_validate = ["1"]
    assert DateFormat().validate(input_validate) is not None


# Generated at 2022-06-22 05:59:29.282296
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    obj = datetime.time()
    expected = '00:00:00'
    assert TimeFormat().serialize(obj) == expected

# Generated at 2022-06-22 05:59:31.159412
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    f = BaseFormat()
    assert isinstance(f.validate(""), ValidationError)


# Generated at 2022-06-22 05:59:34.998782
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    dtObj = datetime.datetime.now()
    dateTimeFmt = DateTimeFormat()
    assert dateTimeFmt.is_native_type(dtObj)



# Generated at 2022-06-22 05:59:37.338341
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    result = time.validate("13:01")
    assert result.time() == 13*60*60+1*60

# Generated at 2022-06-22 05:59:37.976865
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    x = BaseFormat()

# Generated at 2022-06-22 05:59:48.959444
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2019-1-1') == datetime.date(2019,1,1)
    assert date_format.validate('2019-10-1') == datetime.date(2019,10,1)
    assert date_format.validate('2019-10-11') == datetime.date(2019,10,11)
    print("Success!")


# Generated at 2022-06-22 05:59:56.667438
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    assert format.validate("680124a5-5b4d-4e07-8eea-c092f74b0c14") == uuid.UUID("680124a5-5b4d-4e07-8eea-c092f74b0c14")
    with pytest.raises(ValidationError):
        format.validate("")
    with pytest.raises(ValidationError):
        format.validate("123")


# Generated at 2022-06-22 06:00:09.067539
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    # Test default implementation of serialize method
    # This can be executed with pytest in dir "tests/"
    from typesystem.base import BaseFormat
    class MyFormat(BaseFormat):
        def validate(self, value):
            # Assumed validate to return the same value for test purposes
            return value
    myFormat = MyFormat()
    # Test serialization of integer
    assert myFormat.serialize(2) == '2'
    # Test serialization of float
    assert myFormat.serialize(1.1) == '1.1'
    # Test serialization of string
    assert myFormat.serialize("string") == 'string'
    # Test serialization of tuple
    assert myFormat.serialize((1,2)) == '(1, 2)'
    # Test serialization of list

# Generated at 2022-06-22 06:00:10.657734
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(None) == None


# Generated at 2022-06-22 06:00:12.111258
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()

# Generated at 2022-06-22 06:00:14.797304
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize('00000000-0000-0000-0000-000000000012') == '00000000-0000-0000-0000-000000000012'


# Generated at 2022-06-22 06:00:18.929568
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    format = BaseFormat()
    with pytest.raises(NotImplementedError):
        format.validate("11:11:11")



# Generated at 2022-06-22 06:00:23.660516
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    bf = BaseFormat()
    bf.validate = object()
    # this line would fail without __dict__ having been populated by metaclass - see comment in typesystem.metaclasses
    assert bf.__dict__['validate'] is bf.validate
    with pytest.raises(NotImplementedError):
        bf.serialize(1234)


# Generated at 2022-06-22 06:00:29.824081
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    # Make sure is_native_type returns true for datetime objects
    date_object = datetime.datetime.now()
    assert DateTimeFormat().is_native_type(date_object) == True

    # Make sure is_native_type returns false for things that are not datetimes
    string_object = 'hello'
    assert DateTimeFormat().is_native_type(string_object) == False



# Generated at 2022-06-22 06:00:34.042668
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    a = uuid.UUID('12345678-1234-5678-1234-567812345678')
    assert uuid_format.is_native_type(a)
    assert not uuid_format.is_native_type(1)



# Generated at 2022-06-22 06:00:45.518787
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    # test for validate
    test_datetime = '2018-12-15T02:55:55.555555Z'
    assert DateTimeFormat().validate(test_datetime) == datetime.datetime(2018, 12, 15, 2, 55, 55, 555555, tzinfo=datetime.timezone.utc)
    # test for serialize
    test_datetime = '2019-04-12T15:48:55Z'
    assert DateTimeFormat().serialize(DateTimeFormat().validate(test_datetime)) == test_datetime

# Generated at 2022-06-22 06:00:56.208407
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class TestFormat(BaseFormat):
        errors = {"format": "Must be in format {}."}

    instance = TestFormat()

    error = instance.validation_error("format")
    assert isinstance(error, ValidationError)
    assert error.code == "format"
    assert error.text == "Must be in format {}."

    error = instance.validation_error("invalid")
    assert isinstance(error, ValidationError)
    assert error.code == "invalid"
    assert error.text == "invalid"

# Generated at 2022-06-22 06:01:01.693226
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    a = DateTimeFormat()
    assert a.is_native_type(datetime.datetime.now()) == True
    assert a.is_native_type(datetime.time()) == False
    assert a.is_native_type(datetime.date.today()) == False

# Generated at 2022-06-22 06:01:09.456613
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_test = uuid.UUID('{00010203-0405-0607-0809-0a0b0c0d0e0f}')
    uuid_format_test = UUIDFormat()
    if uuid_format_test.is_native_type(uuid_test) == True:
        print("Unit test for UUIDFormat constructor passed")
    else:
        print("Unit test for UUIDFormat constructor failed")


# Generated at 2022-06-22 06:01:11.042986
# Unit test for constructor of class DateFormat
def test_DateFormat():
    print('df=DateFormat()')
    
    

# Generated at 2022-06-22 06:01:13.191045
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    obj = DateTimeFormat()
    assert obj.is_native_type(datetime.datetime.now()) is True

# Generated at 2022-06-22 06:01:15.647149
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
	assert UUIDFormat().is_native_type(uuid.uuid4())==True
	assert UUIDFormat().is_native_type("")==False


# Generated at 2022-06-22 06:01:18.606768
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2020, 3, 4)) == "2020-03-04"
    assert not DateFormat().serialize(None)



# Generated at 2022-06-22 06:01:21.490546
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    format = UUIDFormat()
    assert format.is_native_type(uuid.UUID('{00010203-0405-0607-0809-0a0b0c0d0e0f}'))

# Generated at 2022-06-22 06:01:32.066946
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    #Unit test for method serialize of class TimeFormat
    time1 = datetime.time(12, 45, 34, 12)
    time2 = datetime.time(12, 45, 34, 12000)
    time3 = datetime.time(0, 0, 0, 0)
    time4 = datetime.time(23, 59, 59, 999999)
    time5 = datetime.time(12, 0, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    time6 = datetime.time(12, 45, 34, 12000, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))

# Generated at 2022-06-22 06:01:39.585436
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    o = UUIDFormat()
    o.is_native_type()

UUIDFormat = UUIDFormat()
DateTimeFormat = DateTimeFormat()
DateFormat = DateFormat()
TimeFormat = TimeFormat()

# Generated at 2022-06-22 06:01:49.808510
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class TestFormat1(BaseFormat):
        def is_native_type(self, value):
            return isinstance(value, str)
    class TestFormat2(BaseFormat):
        def is_native_type(self, value):
            return isinstance(value, int)
    class TestFormat3(BaseFormat):
        def is_native_type(self, value):
            return isinstance(value, float)
    class TestFormat4(BaseFormat):
        def is_native_type(self, value):
            return isinstance(value, bool)
    class TestFormat5(BaseFormat):
        def is_native_type(self, value):
            return isinstance(value, list)
    class TestFormat6(BaseFormat):
        def is_native_type(self, value):
            return isinstance(value, dict)
   

# Generated at 2022-06-22 06:01:56.170296
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # hour12:00:00:00.000000
    time = TimeFormat()
    try:
        value = '00:00:00.000000'
        assert time.validate(value) == datetime.time(0, 0, 0, 0)
    except Exception as err:
        print('Tests for TimeFormat validate function is failed. Error is : ', err)
    else:
        print('Tests for TimeFormat validate function is successful!')


# Generated at 2022-06-22 06:02:00.632577
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    # BaseFormat class is not callable
    with pytest.raises(TypeError):
        BaseFormat()
    # BaseFormat class is not callable, 
    # it is an abstract base class and can not be instantiated
    with pytest.raises(TypeError):
        BaseFormat().validation_error("format")



# Generated at 2022-06-22 06:02:02.834724
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert UUIDFormat().serialize(uuid.uuid4()) == str(uuid.uuid4())

# Generated at 2022-06-22 06:02:07.594235
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    format1 = UUIDFormat()
    print(format1)

# Generated at 2022-06-22 06:02:11.497991
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    try:
        BaseFormat().validate('string')
    except NotImplementedError:
        pass
    else:
        assert False  # pragma: no cover



# Generated at 2022-06-22 06:02:23.320772
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    a=TimeFormat()
    assert a.validate("12:11:12.123456") == datetime.time(12,11,12,123456)
    assert a.validate("12:11:12") == datetime.time(12,11,12)
    assert a.validate("12:11") == datetime.time(12,11)
    assert a.validate("12") == datetime.time(12)
    with pytest.raises(ValidationError):
        a.validate("20:11:12")
    with pytest.raises(ValidationError):
        a.validate("12:60:12")
    with pytest.raises(ValidationError):
        a.validate("12:11:90")


# Generated at 2022-06-22 06:02:29.072808
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    fmt = DateTimeFormat()
    assert fmt.is_native_type(datetime.datetime(2013, 1, 1, 11, 11, 11)) == True
    assert fmt.is_native_type(u'2013-01-01T11:11:11Z') == False


# Generated at 2022-06-22 06:02:30.619639
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uf = UUIDFormat()
    print(uf)

# test_UUIDFormat()

# Generated at 2022-06-22 06:02:41.127433
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    # No value(s) given
    try:
        DateTimeFormat()
    except Exception as e:
        assert str(e) == "__init__() missing 1 required positional argument: 'value'"

    # All params given
    DateTimeFormat("format", "invalid")

    # Invalid param given
    try:
        DateTimeFormat("bla")
    except Exception as e:
        assert str(e) == "__init__() takes from 1 to 2 positional arguments but 3 were given"

    # Invalid value(s) given
    try:
        DateTimeFormat("", "")
    except Exception as e:
        assert str(e) == "__init__() takes from 1 to 2 positional arguments but 0 were given"

    # Identical values given

# Generated at 2022-06-22 06:02:43.564859
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert isinstance(DateFormat(), DateFormat)


# Generated at 2022-06-22 06:02:47.602751
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    b = BaseFormat()
    assert b.is_native_type(None) == NotImplementedError
    assert b.validate(None) == NotImplementedError
    assert b.serialize(None) == NotImplementedError


# Generated at 2022-06-22 06:02:57.302011
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Case 1: Check if input is a valid datetime format
    value = "2020-09-19T12:23Z"
    datetime_format = DateTimeFormat()
    try:
        datetime = datetime_format.validate(value)
        assert True
    except ValidationError:
        assert False
    except Exception as ex:
        assert False, ex

    # Case 2: Check if input is a valid datetime format
    value = "2020-09-19T12:23+08:00"
    datetime_format = DateTimeFormat()
    try:
        datetime = datetime_format.validate(value)
        assert True
    except ValidationError:
        assert False
    except Exception as ex:
        assert False, ex

    # Case 3: Check if input is a valid datetime format

# Generated at 2022-06-22 06:03:01.505695
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2018, 1, 1)).endswith("+00:00") == False
    assert DateTimeFormat().serialize(datetime.datetime(2018, 1, 1)).endswith("Z")


# Generated at 2022-06-22 06:03:05.945823
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_hex = "503e57a7-f40a-4090-8c57-9b7e69c9760b"
    uuid_obj = uuid.UUID(uuid_hex)

    assert UUIDFormat().serialize(uuid_obj) == uuid_hex

# Generated at 2022-06-22 06:03:09.765269
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = uuid.uuid4()
    fmt = UUIDFormat()
    assert fmt.serialize(u) == str(u)
    assert fmt.serialize(None) == None


# Generated at 2022-06-22 06:03:12.113935
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    assert BaseFormat.is_native_type(str(3.14), 3.14) == True


# Generated at 2022-06-22 06:03:23.944339
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormat = TimeFormat()
    # Check missing second
    time = timeFormat.validate("12:59")
    assert time.hour == 12 and time.minute == 59 and time.second == 0 and time.microsecond == 0 and time.tzinfo == None
    # Check missing second and microsecond
    time = timeFormat.validate("12:59:00")
    assert time.hour == 12 and time.minute == 59 and time.second == 0 and time.microsecond == 0 and time.tzinfo == None
    # Check missing microsecond
    time = timeFormat.validate("12:59:00.123456")
    assert time.hour == 12 and time.minute == 59 and time.second == 0 and time.microsecond == 123456 and time.tzinfo == None
    # Check missing microsecond and tzinfo

# Generated at 2022-06-22 06:03:27.785267
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    date1 = DateFormat()
    date2 = date1.serialize(None)
    date3 = date1.serialize(datetime.date(2020, 6, 13))
    assert date2 == None
    assert date3 == '2020-06-13'



# Generated at 2022-06-22 06:03:32.728222
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    result = uuid_format.validate(123)
    assert result == '123'

# Generated at 2022-06-22 06:03:34.205550
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base = BaseFormat()
    assert isinstance(base, BaseFormat)


# Generated at 2022-06-22 06:03:41.272425
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time_format = TimeFormat() 
    # Test is_native_type(value: typing.Any) -> bool
    assert(time_format.is_native_type(datetime.time(6, 58, 43, 923120)))
    # Test serialize(self, obj: typing.Any) -> typing.Union[str, None]:
    assert(time_format.serialize(datetime.time(6, 58, 43, 923120)) == "6:58:43.923120")



# Generated at 2022-06-22 06:03:43.246846
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    d = datetime.time(23,59,59,999)
    assert TimeFormat().serialize(d)

# Generated at 2022-06-22 06:03:53.580577
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(2000,1,1))
    assert not date_format.is_native_type(datetime.datetime(2000,1,1,1,1,1))
    assert not date_format.is_native_type(datetime.datetime(2000,1,1))
    assert not date_format.is_native_type(datetime.time(1,1,1,1))
    assert not date_format.is_native_type(None)
    assert not date_format.is_native_type("string")
    assert not date_format.is_native_type(5)


# Generated at 2022-06-22 06:03:57.473749
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    base_format = BaseFormat()
    assert base_format.validation_error('format') == NotImplementedError
    assert base_format.validation_error('invalid') == NotImplementedError


# Generated at 2022-06-22 06:04:01.880287
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    dummy_obj = datetime.time(12, 30, 30)
    
    assert time_format.serialize(dummy_obj) == "12:30:30"


# Generated at 2022-06-22 06:04:13.655530
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    t1 = datetime(2019,1,1,0,0,0,0,tzinfo=None)
    t2 = datetime(2019,1,1,0,0,0,0,tzinfo=timezone.utc)
    t3 = datetime(2019,1,1,12,30,30,0,tzinfo=timezone(timedelta(hours=-5)))
    t4 = datetime(2019,1,1,12,30,30,0,tzinfo=timezone(timedelta(hours=-7,minutes=-30)))
    t5 = datetime(2019,1,1,12,30,30,0,tzinfo=timezone(timedelta(hours=5,minutes=30)))

# Generated at 2022-06-22 06:04:18.135370
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    print("test_UUIDFormat_is_native_type")
    uuidFormat = UUIDFormat()
    ret = uuidFormat.is_native_type(uuid.uuid1())
    print(ret)
    assert ret == False



# Generated at 2022-06-22 06:04:20.045255
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    assert str(uuid.uuid4()) == UUIDFormat().serialize(uuid.uuid4())



# Generated at 2022-06-22 06:04:27.685918
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    f = UUIDFormat()
    assert f.is_native_type(uuid.uuid4())
    assert not f.is_native_type(4)
    assert not f.is_native_type(None)



# Generated at 2022-06-22 06:04:29.681608
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    result = DateTimeFormat()
    assert result is not None


# Generated at 2022-06-22 06:04:33.991377
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid = UUIDFormat()

    uuid1 = uuid.validate('4737ca4e-4b3a-4e2f-aecb-42c184e8e298')
    assert(str(uuid1) == '4737ca4e-4b3a-4e2f-aecb-42c184e8e298')

# Generated at 2022-06-22 06:04:36.573053
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    datetime_format = DateTimeFormat()
    assert datetime_format.is_native_type(datetime.datetime.now())


# Generated at 2022-06-22 06:04:49.789089
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    uuid_f = UUIDFormat()
    # Should return error for invalid UUID format.
    with pytest.raises(ValidationError):
        uuid_f.validate('b3682bf1-7991-48a6-b5e5-5bb5a5c5e5db')

    # Should return UUID(version=1, node=uid, time=ttime, clock_seq=cseq) if valid UUID format.
    new_uuid_f = uuid_f.validate('b3682bf1-7991-48a6-b5e5-5bb5a5c5e5d')
    assert isinstance(new_uuid_f, uuid.UUID)
    assert new_uuid_f.version == 1

# Generated at 2022-06-22 06:04:52.560192
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    # test case
    time = datetime.time(hour=1, minute=1)
    x = TimeFormat()
    assert x.is_native_type(time)



# Generated at 2022-06-22 06:04:53.601829
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat.errors is None


# Generated at 2022-06-22 06:05:00.385028
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    """
    Tests the method validate of class BaseFormat.

    #TODO For the moment this test can't pass.
    """
    class BaseFormatTester(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            raise NotImplementedError()  # pragma: no cover

    baseformat = BaseFormatTester()

    with pytest.raises(NotImplementedError):
        baseformat.validate("")



# Generated at 2022-06-22 06:05:03.146974
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(2020, 1, 11)) == True


# Generated at 2022-06-22 06:05:12.077197
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class MyFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return True
        def validate(self, value: typing.Any) -> typing.Any:
            return value
    my_format = MyFormat()
    assert my_format.serialize(None) is None
    assert my_format.serialize("") == "", "Expected '' (empty string)"
    assert my_format.serialize("abc") == "abc"
    assert my_format.serialize("abc") != "ABC", "Wanted abc, got ABC"


# Generated at 2022-06-22 06:05:24.139919
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("1999-12-31T23:59:59.999999-01:00") == datetime.datetime(
        1999, 12, 31, 23, 59, 59, 999999, tzinfo=datetime.timezone(datetime.timedelta(hours=-1))
    )

# Generated at 2022-06-22 06:05:29.349135
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2019, 12, 29, 12, 34, 56, tzinfo=datetime.timezone.utc) #object 
    obj_string = DateTimeFormat().serialize(obj) #object string
    assert (obj_string == "2019-12-29T12:34:56+00:00") #assert 


# Generated at 2022-06-22 06:05:33.968383
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    test_format = BaseFormat()
    try:
        test_format.validate("")
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-22 06:05:39.151112
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)


# Generated at 2022-06-22 06:05:50.151019
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u = UUIDFormat()
    test_values = {'2a9d6eb0-3e3f-4d81-bb8e-ceb796924eef': True,
                   '2a9d6eba-3e3f-4d81-bb8e-ceb796924eef': False}
    for test_value, expected_result in test_values.items():
        with pytest.raises(ValidationError):
            u.validate(test_value) == expected_result

# Generated at 2022-06-22 06:05:52.636601
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    tm = datetime.time()
    fmt = TimeFormat()
    assert fmt.is_native_type(tm)


# Generated at 2022-06-22 06:05:57.610450
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
	import typesystem
	import json
	from typesystem.fields import *
	from typesystem.formats import *
	class Person(typesystem.Schema):
		name = String(format=StringFormat.slug)
	person = Person(name='user_one')
	assert person.serialize(person.name) == 'user_one'
	

# Generated at 2022-06-22 06:05:58.548824
# Unit test for constructor of class DateFormat
def test_DateFormat():
    obj = DateFormat()
    return obj

# Generated at 2022-06-22 06:06:02.037473
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    obj = UUIDFormat()
    assert obj.errors == {"format": "Must be valid UUID format."}


# Generated at 2022-06-22 06:06:05.360436
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    time = datetime.date(2020, 5, 2)
    obj = DateFormat()
    assert obj.serialize(time) == "2020-05-02"


# Generated at 2022-06-22 06:06:14.088795
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    myFormat = BaseFormat()
    with pytest.raises(NotImplementedError):
        myFormat.validate(1)


# Generated at 2022-06-22 06:06:16.381299
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        newBaseFormat = BaseFormat()
        newBaseFormat.validate("")


# Generated at 2022-06-22 06:06:23.739686
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    base_format = BaseFormat()
    assert base_format.errors == {}
    assert base_format.validation_error("format") == "format"
    assert base_format.is_native_type("value") == NotImplementedError()
    assert base_format.validate("value") == NotImplementedError()
    assert base_format.serialize("obj") == NotImplementedError()


# Generated at 2022-06-22 06:06:24.746879
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    assert isinstance(UUIDFormat(), UUIDFormat)

# Generated at 2022-06-22 06:06:30.355445
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert(df.serialize(datetime.date(2019, 1, 1)) == '2019-01-01')
    assert(df.serialize(datetime.date(2019, 1, 2)) == '2019-01-02')
    assert(df.serialize(datetime.date(2018, 12, 31)) == '2018-12-31')
    assert(df.serialize(None) == None)


# Generated at 2022-06-22 06:06:39.021709
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
	date = datetime.date(day=17, month=5, year=2020)
	time = datetime.time(hour=1, minute=56,second=12)
	datetimee = datetime.datetime(day=1, month=1, year=2020,
								 hour=1, minute=12,second=12,microsecond=123123)

	dateFormat = DateFormat()
	assert dateFormat.is_native_type(date) == True
	assert dateFormat.is_native_type(time) == False
	assert dateFormat.is_native_type(datetimee) == False


# Generated at 2022-06-22 06:06:45.579551
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    from typesystem.base import ValidationError
    base = BaseFormat()
    base.errors["error_code"] = "error_message"
    assert base.validation_error("error_code").code == 'error_code'
    assert base.validation_error("error_code").text == 'error_message'


# Generated at 2022-06-22 06:06:55.513066
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    test_value = [datetime.fromisoformat('2020-01-06T09:27:15.123456+01:00'), '2020-01-06T09:27:15.123456+01:00', False, 999, 3.5]
    test_result = [True, False, False, False, False]

    assert len(test_value) == len(test_result), "test value len not equal the test result len"
    for idx in range(0, len(test_value)):
        dtf = DateTimeFormat()
        assert dtf.is_native_type(test_value[idx]) is test_result[idx], f"is_native_type of {test_value[idx]} should be {test_result[idx]}"
