

# Generated at 2022-06-22 05:57:09.818549
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert time.is_native_type(datetime.time(10, 55, 12)) == True

# Generated at 2022-06-22 05:57:13.407250
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class test(BaseFormat):
        def validate(self, value: typing.Any) -> typing.Union[typing.Any, ValidationError]:
            return "hello"
    a=test()
    assert a.validate("abc")=="hello"


# Generated at 2022-06-22 05:57:15.993396
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    import datetime
    from typesystem.format import DateFormat
    assert DateFormat().serialize(datetime.date(2018, 4, 12)) == '2018-04-12'


# Generated at 2022-06-22 05:57:19.052815
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    new_UUIDFormat = UUIDFormat()
    assert new_UUIDFormat.errors == {"format": "Must be valid UUID format."}


# Generated at 2022-06-22 05:57:20.217369
# Unit test for constructor of class DateFormat
def test_DateFormat():
    assert isinstance(DateFormat, object)
test_DateFormat()


# Generated at 2022-06-22 05:57:21.607960
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtf = DateTimeFormat()
    assert isinstance(dtf, BaseFormat)


# Generated at 2022-06-22 05:57:29.514802
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    """Unit test for method is_native_type of class TimeFormat"""
    obj = TimeFormat()
    value = ''
    assert not obj.is_native_type(value)
    value = False
    assert not obj.is_native_type(value)
    value = '00:00'
    assert not obj.is_native_type(value)
    value = datetime.time(0,0,0)
    assert obj.is_native_type(value)

# Generated at 2022-06-22 05:57:36.490882
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class Temp1(BaseFormat):
        errors = {}
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, int)

        def validate(self, value: typing.Any) -> int:
            return int(value)

        def serialize(self, obj: typing.Any) -> str:
            return str(obj)

    class Temp2(BaseFormat):
        errors = {}
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, str)

        def validate(self, value: typing.Any) -> str:
            return str(value)

        def serialize(self, obj: typing.Any) -> str:
            return str(obj)

    assert(Temp1().is_native_type('5'))
   

# Generated at 2022-06-22 05:57:42.221350
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    test_data = ["2020-01-02", "1990-02-01", "2020-12-31"]
    for date in test_data:
        assert date_format.validate(date) == datetime.datetime.strptime(date, "%Y-%m-%d")


# Generated at 2022-06-22 05:57:44.158736
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert str(BaseFormat()) == '<typesystem.formats.BaseFormat object at 0x10c7e9508>'

# Generated at 2022-06-22 05:57:54.073269
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    date_format = DateFormat()
    assert date_format.is_native_type(datetime.date(2020, 7, 21))


# Generated at 2022-06-22 05:58:01.639473
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    format = BaseFormat()

    format.errors = {'code1': 'the text'}
    assert format.validation_error('code1').text == 'the text'
    assert format.validation_error('code1').code == 'code1'

    # code2 does not exist in errors dictionary
    with pytest.raises(Exception):
        format.validation_error('code2')

    format.errors = {'code3': 'text with {value}'}
    assert format.validation_error('code3').text == 'text with {value}'
    assert format.validation_error('code3').code == 'code3'


# Generated at 2022-06-22 05:58:06.074637
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()

# Generated at 2022-06-22 05:58:07.985690
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        BaseFormat().validate(None)


# Generated at 2022-06-22 05:58:19.350360
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    test_cases = [
        (None, False),
        (True, False),
        (1, False),
        (1.0, False),
        ("test_string", False),
        (datetime.datetime.now(), False),
        (datetime.datetime.now().date(), False),
        (datetime.datetime.now().time(), False),
        ({"key1":1, "key2":2}, False),
        ((1,2,3), False),
        ([1,2,3], False),
        (uuid.uuid4(), True),
    ]
    uuidformat = UUIDFormat()
    for test_case, expected_output in test_cases:
        output = uuidformat.is_native_type(test_case)
        assert output == expected_output


# Generated at 2022-06-22 05:58:24.347181
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = uuid.UUID('6fa459ea-ee8a-3ca4-894e-db77e160355e')
    myObj = UUIDFormat()

    assert myObj.serialize(obj) == '6fa459ea-ee8a-3ca4-894e-db77e160355e'

# Generated at 2022-06-22 05:58:30.864011
# Unit test for constructor of class DateFormat
def test_DateFormat():
    objectDateFormat = DateFormat()
    assert objectDateFormat.is_native_type(datetime.date(2013, 2, 3))
    assert objectDateFormat.validate("2013-2-3")
    assert objectDateFormat.serialize(datetime.date(2013, 2, 3)) == "2013-02-03"


# Generated at 2022-06-22 05:58:33.056870
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    bf = BaseFormat()

    with pytest.raises(NotImplementedError):
        bf.validate("")


# Generated at 2022-06-22 05:58:40.603473
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    
    # Initialize class BaseFormat with variable 'test'
    a = BaseFormat()

    # testing def validation_error(self, code: str) -> ValidationError:, ValidationError class has 2 parameters, text and code.
    try:
        # 3 cases of test: pass, raise error with 2 parameters, raise error with one parameter.
        a.validation_error('test')
    except ValidationError:
        print('Test pass')

# Generated at 2022-06-22 05:58:47.871099
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    # GIVEN
    # mock datetime.datetime
    class Mock_datetime():
        def __init__(self, *args, **kwargs):
            self.__class__ = datetime.datetime
            datetime.datetime.__init__(self, *args, **kwargs)

    value = "2001-01-01T00:00:00.000Z"
    # WHEN
    result = DateTimeFormat().is_native_type(Mock_datetime(value))
    # THEN
    assert (result)


# Generated at 2022-06-22 05:58:59.838020
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    obj = uuid.uuid1()
    obj2 = uuid.uuid4()
    obj3 = uuid.uuid5(uuid.NAMESPACE_DNS, 'example.com')
    assert UUIDFormat().serialize(obj) == str(obj)
    assert UUIDFormat().serialize(obj2) == str(obj2)
    assert UUIDFormat().serialize(obj3) == str(obj3)

# Generated at 2022-06-22 05:59:03.423724
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    df = DateTimeFormat()
    d = datetime.datetime(2019, 10, 17)
    assert df.is_native_type(d)
    assert not df.is_native_type("2019-10-17")


# Generated at 2022-06-22 05:59:07.483357
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    assert not DateFormat().is_native_type(None)
    assert not DateFormat().is_native_type(1)
    assert not DateFormat().is_native_type("string")
    assert DateFormat().is_native_type(datetime.date.today())


# Generated at 2022-06-22 05:59:12.497538
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    # Prepare test data
    date_format = DateFormat()
    fake_date = datetime.date(2019, 1, 1)
    # Execute test method
    result = date_format.is_native_type(fake_date)
    # Assert result
    assert result == True


# Generated at 2022-06-22 05:59:15.149374
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    obj = datetime.date(1994, 1, 2)
    result = DateFormat().serialize(obj)
    assert result == "1994-01-02"


# Generated at 2022-06-22 05:59:18.028029
# Unit test for constructor of class DateFormat
def test_DateFormat():
    format = DateFormat()
    assert format.errors == {'format': 'Must be a valid date format.', 
                             'invalid': 'Must be a real date.'}    
    

# Generated at 2022-06-22 05:59:21.113958
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    date_format = DateFormat()
    today = datetime.date.today()
    assert date_format.is_native_type(today) == True
    assert date_format.is_native_type(today.isoformat()) == False


# Generated at 2022-06-22 05:59:31.505358
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    date = DateFormat()
    date_correct = date.is_native_type(datetime.date(2020, 7, 11))
    assert date_correct == True, \
        "Should be True. Unit test for method is_native_type of class DateFormat completed."
    print("Unit test for method is_native_type of class DateFormat completed.")
    time = TimeFormat()
    time_correct = time.is_native_type(datetime.time(10, 10, 10, 10))
    assert time_correct == True, \
        "Should be True. Unit test for method is_native_type of class TimeFormat completed."
    print("Unit test for method is_native_type of class TimeFormat completed.")
    datetime = DateTimeFormat()

# Generated at 2022-06-22 05:59:34.820027
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    with pytest.raises(NotImplementedError):
        format = BaseFormat()
        format.validation_error("abc")


# Generated at 2022-06-22 05:59:42.066093
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()

    assert(uuid_format.is_native_type(uuid.uuid4()))

    assert(not uuid_format.is_native_type(datetime.datetime.utcnow()))
    assert(not uuid_format.is_native_type(datetime.date.today()))
    assert(not uuid_format.is_native_type('random string'))
    assert(not uuid_format.is_native_type(123))


# Generated at 2022-06-22 05:59:56.355627
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    from datetime import datetime
    from datetime import timezone

    ################################################################################################
        ### Testcase 1
        ################################################################################################
    argument1 = datetime(2020, 4, 1, 14, 5, 36, 100000, timezone.utc) #argument: date time with timezone
    expected1 = "2020-04-01T14:05:36.000100Z"
    ################################################################################################
    returned1 = DateTimeFormat().serialize(argument1) #the method under test
    ################################################################################################
        ### Testcase 2
        ################################################################################################
    argument2 = datetime(2020, 4, 1, 14, 5, 36, 100000, tzinfo=None) #argument: date time without timezone

# Generated at 2022-06-22 05:59:59.901622
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    t1 = TimeFormat()
    assert t1.is_native_type(datetime.time(12, 30)) == True
    assert t1.is_native_type('12:30') == False



# Generated at 2022-06-22 06:00:02.872859
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert isinstance(time, BaseFormat)
    assert isinstance(time, TimeFormat)


# Generated at 2022-06-22 06:00:05.218413
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert BaseFormat.serialize(None) == None

# Generated at 2022-06-22 06:00:08.737457
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuidobj = uuid.uuid4()
    u = UUIDFormat().is_native_type(uuidobj)
    assert u == True


# Generated at 2022-06-22 06:00:11.928505
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    # Test for validate_integer

    with pytest.raises(TypeError):
        BaseFormat()



# Generated at 2022-06-22 06:00:23.784323
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    value = None
    expected = None
    fmt = UUIDFormat()
    actual = fmt.serialize(value)
    assert expected == actual

    value = "f96c3abb-3b64-4faf-ac1e-7c8a940f6941"
    expected = "f96c3abb-3b64-4faf-ac1e-7c8a940f6941"
    fmt = UUIDFormat()
    actual = fmt.serialize(value)
    assert expected == actual

    value = "1"
    fmt = UUIDFormat()
    try:
        actual = fmt.serialize(value)
    except ValueError:
        pass
    else: 
        assert False


# Generated at 2022-06-22 06:00:26.257054
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    bf = BaseFormat()
    assert isinstance(bf, BaseFormat)


# Generated at 2022-06-22 06:00:28.926945
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = uuid.uuid4()
    uuid_format = UUIDFormat()
    s = uuid_format.serialize(u)
    assert u in s

# Generated at 2022-06-22 06:00:33.814389
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    print("= test_TimeFormat_is_native_type=")
    time_format = TimeFormat()
    assert time_format.is_native_type(datetime.datetime.now().time()) == True
    assert time_format.is_native_type("12:56") == False


# Generated at 2022-06-22 06:00:39.651250
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    assert uuid_format.serialize(uuid.uuid4()) == '5a7c57a5-f72d-4c6f-9388-ca96a2dd74f3'

# Generated at 2022-06-22 06:00:48.112423
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uut = UUIDFormat()
    bad_value = '1234-5678-90ab-cdef-0987654321'
    good_value = '12345678-9012-3456-7890-123456789abc'
    assert uut.validate(good_value) == uuid.UUID(good_value)
    try:
        uut.validate(bad_value)
    except ValidationError:
        pass
    else:
        assert False



# Generated at 2022-06-22 06:00:51.333195
# Unit test for constructor of class BaseFormat
def test_BaseFormat():
    assert BaseFormat.errors == {}
    assert type(BaseFormat) == type
    assert BaseFormat.__name__ == 'BaseFormat'
    assert BaseFormat.__doc__ == None
    assert BaseFormat.__module__ == 'builtins'


# Generated at 2022-06-22 06:00:59.099056
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    u1 = uuid.UUID('12345678-1234-5678-1234-567812345678')
    u2 = uuid.UUID('12345678-1234-5678-1234-56781234')
    u3 = uuid.UUID('123456781234-5678-1234-5678123478')
    u4 = UUIDFormat()
    assert u4.is_native_type(u1) == True
    assert u4.is_native_type(u2) == True
    assert u4.is_native_type(u3) == True


# Generated at 2022-06-22 06:01:07.850530
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    import unittest
    from typesystem.base import ValidationError

    class Test(unittest.TestCase):
        def test_validate(self):
            d = DateFormat()
            # this raises a ValidationError
            with self.assertRaises(ValidationError):
                d.validate("2019-13-30")

            # this shouldn't raise a ValidationError
            date_object = d.validate("2019-04-30")
            self.assertEqual(date_object.year, 2019)
            self.assertEqual(date_object.month, 4)
            self.assertEqual(date_object.day, 30)

    unittest.main()


# Generated at 2022-06-22 06:01:10.388930
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    b = BaseFormat()
    assert b.validation_error("test") == ValidationError(text="test", code="test")


# Generated at 2022-06-22 06:01:12.126028
# Unit test for constructor of class UUIDFormat
def test_UUIDFormat():
    f = UUIDFormat()
    assert isinstance(f, BaseFormat)


# Generated at 2022-06-22 06:01:12.780126
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    assert TimeFormat()

# Generated at 2022-06-22 06:01:15.991047
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    class MyFormat(BaseFormat):
        pass

    myformat = MyFormat()
    with pytest.raises(NotImplementedError):
        myformat.validate(1)


# Generated at 2022-06-22 06:01:19.339179
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    assert uuid_format.serialize(uuid.uuid4()) == str(uuid.uuid4())
test_UUIDFormat_serialize()


# Generated at 2022-06-22 06:01:34.162512
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    date_time = '2019-12-13T13:13:13.123456Z'

    # Test validate function
    date_time_format = DateTimeFormat()
    assert date_time_format.validate(date_time) == datetime.datetime(
        2019, 12, 13, 13, 13, 13, 123456, datetime.timezone.utc
    )
    try:
        date_time_format.validate('2019-12-13T13:13:13')
    except ValidationError as error:
        assert error.code == 'format'
        assert error.text == 'Must be a valid datetime format.'


# Generated at 2022-06-22 06:01:40.001379
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    data = "2020-07-31T14:48:00"
    dateTimeFormat = DateTimeFormat()
    datetime = dateTimeFormat.validate(data)
    assert datetime.year == 2020


# Generated at 2022-06-22 06:01:49.897217
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('1988-06-06') == datetime.date(1988, 6, 6)
    print('Test 1 OK')
    assert date_format.validate('1988-13-06') == datetime.date(1988, 6, 6)
    print('Test 2 OK')
    try:
        assert date_format.validate('1988-06-35') == datetime.date(1988, 6, 6)
    except:
        print('Test 3 OK')
    try:
        assert date_format.validate('1988-06-06-06') == datetime.date(1988, 6, 6)
    except:
        print('Test 4 OK')

print('Unit test for method validate of class DateFormat:')
test_DateFormat_validate()



# Generated at 2022-06-22 06:01:51.750690
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    time_object = datetime.datetime.now()
    time_format = DateTimeFormat()


# Generated at 2022-06-22 06:01:53.965051
# Unit test for method is_native_type of class BaseFormat
def test_BaseFormat_is_native_type():
    class testFormat(BaseFormat):
        pass
    current_format = testFormat()
    assert current_format.is_native_type("blah") == False

# Generated at 2022-06-22 06:02:04.277106
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    # All fields
    assert time.validate('12:34:56.123456') == datetime.time(12, 34, 56, 123456)
    # minute
    assert time.validate('12:34:00') == datetime.time(12, 34, 00, 00)
    # hour
    assert time.validate('12:00:00') == datetime.time(12, 00, 00, 00)

    # Errors
    try:
        # Not time
        assert time.validate('12:00:00.123456') == datetime.time(12,00,00,123456)
    except:
        pass

# Generated at 2022-06-22 06:02:18.126139
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    assert (DateTimeFormat().is_native_type(datetime.datetime(
        2020, 6, 20, 18, 45, 59, tzinfo=datetime.timezone(datetime.timedelta(hours=1))
    ))) == True
    assert (DateTimeFormat().is_native_type(datetime.datetime(
        2020, 6, 20, 18, 45, 59
    ))) == True
    assert (DateTimeFormat().is_native_type(datetime.datetime(
        2020, 6, 20, 18, 45, tzinfo=datetime.timezone(datetime.timedelta(hours=1))
    ))) == True

# Generated at 2022-06-22 06:02:23.701607
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():

    f = BaseFormat()

    with pytest.raises(NotImplementedError):
        f.validate('abc')



# Generated at 2022-06-22 06:02:27.104821
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    assert df.is_native_type(datetime.datetime.now().date())


# Generated at 2022-06-22 06:02:31.649528
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date = datetime.datetime(2020, 5, 8, 11, tzinfo = datetime.timezone(datetime.timedelta(hours=-5)))
    assert DateTimeFormat().serialize(date) == '2020-05-08T11:00:00-05:00'


# Generated at 2022-06-22 06:02:39.953736
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    base_format = BaseFormat()

    with pytest.raises(NotImplementedError):
        base_format.validate("value")



# Generated at 2022-06-22 06:02:51.573668
# Unit test for method is_native_type of class DateTimeFormat
def test_DateTimeFormat_is_native_type():
    """
    >>> isinstance(datetime.datetime(2020,6,2,9,30,11), datetime.datetime)
    True

    # native_type
    >>> DateTimeFormat().is_native_type(datetime.datetime(2020,6,2,9,30,11))
    True

    # not native_type
    >>> DateTimeFormat().is_native_type(datetime.time(9,30,11))
    False
    >>> DateTimeFormat().is_native_type(datetime.date(2020,6,2))
    False
    >>> DateTimeFormat().is_native_type('2020-06-02T09:30:11')
    False
    >>> DateTimeFormat().is_native_type(123123123123123)
    False

    """
    pass


# Generated at 2022-06-22 06:03:03.490820
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dtf = DateTimeFormat()
    obj = datetime.datetime(2018, 8, 23, 12, 8, 52)
    obj2 = datetime.datetime(2018, 8, 23, 12, 8, 52, 345000)
    obj3 = datetime.datetime(2018, 8, 23, 12, 8, 52, tzinfo=datetime.timezone(datetime.timedelta(hours=-4)))
    obj4 = datetime.datetime(2018, 8, 23, 15, 8, 52, tzinfo=datetime.timezone.utc)
    assert dtf.serialize(obj) == "2018-08-23T12:08:52"
    assert dtf.serialize(obj2) == "2018-08-23T12:08:52.345"

# Generated at 2022-06-22 06:03:07.098552
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4()) == True
    assert UUIDFormat().is_native_type(uuid.uuid4()) != datetime.date.today()    



# Generated at 2022-06-22 06:03:18.714055
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    from typesystem.base import ValidationError

    fmt = UUIDFormat()
    cases = (
        "067e6162-3b6f-4ae2-a171-2470b63dff00",
        "067e6162-3b6f-4ae2-a171-2470b63dff00",
        "067e6162-3b6f-4ae2-a171-2470b63dff00",
    )
    for case in cases:
        fmt.validate(case)


# Generated at 2022-06-22 06:03:22.535030
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    DATE_REGEX = re.compile(r"(?P<year>\d{4})-(?P<month>\d{1,2})-(?P<day>\d{1,2})$")


# Generated at 2022-06-22 06:03:24.774292
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type(): 
    assert DateFormat().is_native_type(datetime.date(2019, 5, 16)) == True


# Generated at 2022-06-22 06:03:27.834204
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(2018, 1, 2, 14, 30)
    assert DateTimeFormat().serialize(obj) == '2018-01-02T14:30:00'


# Generated at 2022-06-22 06:03:30.809189
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    value = datetime.date(year = 2020, month = 1, day = 2)
    assert(DateFormat().serialize(value) == '2020-01-02')



# Generated at 2022-06-22 06:03:31.976418
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    t1 = DateTimeFormat()


# Generated at 2022-06-22 06:03:40.861842
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    format = DateTimeFormat()
    obj = datetime.datetime(2018, 2, 12, 15, 8, 59, 0)
    assert format.serialize(obj) == "2018-02-12T15:08:59"

# User test for method validate of class DateTimeFormat

# Generated at 2022-06-22 06:03:49.339528
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    print ('Testing for DateTimeFormat')
    match = DATETIME_REGEX.match(value)
    assert isinstance(match,match.__class__)
    assert isinstance(tzinfo_str,tzinfo_str.__class__)
    assert isinstance(offset_mins,offset_mins.__class__)
    assert isinstance(offset_hours,offset_hours.__class__)
    assert isinstance(delta,delta.__class__)
    assert isinstance(tzinfo,tzinfo.__class__)
    assert isinstance(kwargs,kwargs.__class__)
    assert isinstance(groups,groups.__class__)


# Generated at 2022-06-22 06:03:54.639979
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    Date = DateFormat()
    today = datetime.date.today()
    today_str = today.strftime('%Y-%m-%d')
    serialized = Date.serialize(today)
    assert today_str == serialized

# Test for method serialize of class TimeFormat

# Generated at 2022-06-22 06:04:00.087372
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    with pytest.raises(NotImplementedError):
        BaseFormat().serialize(None)


# Generated at 2022-06-22 06:04:03.471837
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    assert UUIDFormat().is_native_type(uuid.uuid4()) == True
    assert UUIDFormat().is_native_type(DATE_REGEX) == False


# Generated at 2022-06-22 06:04:13.328543
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    try:
        assert dateFormat.validate("2020-05-34") == datetime.date(2020, 5, 34)
    except ValueError:
        print("Value Error")
        assert True
    try:
        assert dateFormat.validate("2020-05") == datetime.date(2020, 5, "")
    except ValueError:
        print("Value Error")
        assert True
    try:
        assert dateFormat.validate("2020") == datetime.date(2020, "", "")
    except ValueError:
        print("Value Error")
        assert True
    print("Unit test for method validate of class DateFormat is passed")


# Generated at 2022-06-22 06:04:17.819211
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuidFormat = UUIDFormat()
    result = uuidFormat.validate('00000000-0000-0000-0000-000000000000')
    expected = uuid.UUID('00000000-0000-0000-0000-000000000000')
    assert result == expected


# Generated at 2022-06-22 06:04:23.028163
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    timeFormat = TimeFormat()
    assert timeFormat.is_native_type(datetime.time.min)
    assert not timeFormat.is_native_type(datetime.datetime.min)
    assert not timeFormat.is_native_type("abc")


# Generated at 2022-06-22 06:04:28.490552
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    a = UUIDFormat()
    assert isinstance(a.serialize("f2365e44-a7ec-4a34-b7e1-79d21ad7a001"), str)

# Generated at 2022-06-22 06:04:31.807812
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    u = uuid.UUID('0123456789abcdef0123456789abcdef')
    assert isinstance(UUIDFormat().serialize(u), str)


# Generated at 2022-06-22 06:04:38.958398
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    test_obj = datetime.datetime(2016, 5, 3, 10, 1, 10, 10, datetime.timezone.utc)
    d = DateTimeFormat()
    value = d.serialize(test_obj)
    assert value == "2016-05-03T10:01:10.000010Z"

# Generated at 2022-06-22 06:04:45.675218
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class BaseFormatTest:
        def __init__(self):
            # serialize(obj: typing.Any) -> typing.Union[str, None]
            self.__bftest1 = BaseFormat()

        def test1(self, obj: typing.Any) -> typing.Union[str, None]:
            return self.__bftest1.serialize(obj)

    obj = BaseFormatTest()
    print(obj.test1(None))

# Generated at 2022-06-22 06:04:47.523041
# Unit test for constructor of class DateFormat
def test_DateFormat():
    print("Test DateFormat constructor")
    DateFormat()
    print("\t PASSED")


# Generated at 2022-06-22 06:04:56.792801
# Unit test for method validate of class UUIDFormat

# Generated at 2022-06-22 06:04:57.824944
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    tf = TimeFormat()



# Generated at 2022-06-22 06:04:58.470470
# Unit test for constructor of class DateFormat
def test_DateFormat():
    pass

# Generated at 2022-06-22 06:05:02.951604
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    f = UUIDFormat()
    assert f.is_native_type(uuid.uuid4()) == True
    assert f.is_native_type('1234') == False
    assert f.is_native_type(datetime.datetime.now()) == False


# Generated at 2022-06-22 06:05:10.837186
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # tzinfo_str == 'Z'
    value = "2020-11-20T12:30:00.000000Z"
    obj = DateTimeFormat().validate(value)
    assert DateTimeFormat().serialize(obj) == value

    # tzinfo_str != 'Z'
    value = "2020-11-20T12:30:00.000000+05:30"
    obj = DateTimeFormat().validate(value)
    assert DateTimeFormat().serialize(obj) == value

# Generated at 2022-06-22 06:05:16.277637
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class FoobarFormat(BaseFormat):
        errors = {
            "format": "Must be a valid Foobar format.",
            "invalid": "Must be a real Foobar.",
        }
    f = FoobarFormat()
    print(f.validation_error('format'))
    print(f.validation_error('invalid'))


# Generated at 2022-06-22 06:05:21.154237
# Unit test for method serialize of class UUIDFormat
def test_UUIDFormat_serialize():
    uuid_format = UUIDFormat()
    test_str = str(uuid.uuid4())
    assert uuid_format.serialize(test_str) == str(uuid.UUID(test_str))


# Generated at 2022-06-22 06:05:30.754017
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert uuid_format.is_native_type(str(uuid.uuid4()))
    assert not uuid_format.is_native_type(datetime.datetime.utcnow().isoformat())
    assert not uuid_format.is_native_type(datetime.date.today().isoformat())
    assert not uuid_format.is_native_type(datetime.time(hour=0, minute=0, second=0).isoformat())


# Generated at 2022-06-22 06:05:33.661161
# Unit test for method is_native_type of class DateFormat
def test_DateFormat_is_native_type():
    df = DateFormat()
    assert(df.is_native_type(datetime.date(2019, 12, 31))) == True


# Generated at 2022-06-22 06:05:43.107087
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    uuid_format = UUIDFormat()
    assert(uuid_format.is_native_type("1b8f62a1-26e0-48c7-a28b-f817a7aeea2a") == False)
    assert(uuid_format.is_native_type(uuid.UUID("1b8f62a1-26e0-48c7-a28b-f817a7aeea2a")) == True)


# Generated at 2022-06-22 06:05:46.349594
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    # arranges
    from typesystem.base import Time
    time_format = TimeFormat()  
    expected = False
    # act
    actual = time_format.is_native_type(Time())
    # assert
    assert expected == actual

# Generated at 2022-06-22 06:05:50.892847
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Passing
    assert DateFormat().validate('2000-01-01') == datetime.date(2000, 1, 1)
    # Failing
    with pytest.raises(ValidationError):
        DateFormat().validate('10-10-2000')


# Generated at 2022-06-22 06:05:54.741279
# Unit test for method is_native_type of class TimeFormat
def test_TimeFormat_is_native_type():
    t = TimeFormat()
    assert t.is_native_type(None) == False
    assert t.is_native_type("12:34:56") == False
    assert t.is_native_type(datetime.time()) == True


# Generated at 2022-06-22 06:05:59.563350
# Unit test for method validation_error of class BaseFormat
def test_BaseFormat_validation_error():
    class DerivativeOfBaseFormat(BaseFormat):
        errors = {"testcode": "testtext"}

    b = DerivativeOfBaseFormat()

    try:
        b.validation_error("testcode")
    except ValidationError as e:
        assert e.text == "testtext"
        assert e.code == "testcode"


# Generated at 2022-06-22 06:06:02.975890
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    try:
        BaseFormat.serialize(None, None)
    except NotImplementedError:
        pass
    else:
        assert False

# Generated at 2022-06-22 06:06:04.881560
# Unit test for method is_native_type of class UUIDFormat
def test_UUIDFormat_is_native_type():
    UUIDFormat().is_native_type(uuid.uuid4())
    
#Unit test for method validate of class UUIDFormat

# Generated at 2022-06-22 06:06:14.929621
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    assert DateFormat().serialize(datetime.date(2020,9,5)) == "2020-09-05"
    assert TimeFormat().serialize(datetime.time(12,3,1)) == "12:03:01"
    assert DateTimeFormat().serialize(datetime.datetime(2020,9,5,12,3,1)) == "2020-09-05T12:03:01"
    assert UUIDFormat().serialize(uuid.UUID('c9bf9e57-1685-4c89-bafb-ff5af830be8a')) == "c9bf9e57-1685-4c89-bafb-ff5af830be8a"
    

# Generated at 2022-06-22 06:06:29.522975
# Unit test for method serialize of class BaseFormat
def test_BaseFormat_serialize():
    class DemoFormat(BaseFormat):
        errors = {"format": "Must be valid Demo format."}
        value = 0
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, int)

        def validate(self, value: typing.Any) -> typing.Union[int, ValidationError]:
            if value == 1:
                return self.value
            raise self.validation_error("format")
        
        def serialize(self, obj: typing.Any) -> typing.Union[str, None]:
            return 'value' + str(obj)
    
    demo_object = DemoFormat()
    assert demo_object.serialize(demo_object.value) == "value0"
    assert demo_object.serialize(1) == "value0"
    assert demo_object

# Generated at 2022-06-22 06:06:32.797465
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():
    with pytest.raises(NotImplementedError):
        _ = BaseFormat().validate(None)


# Generated at 2022-06-22 06:06:40.573051
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test_DateTimeFormat_validate() method that returns datetime object

    # Input: Value to be tested having timezone
    value = '2019-12-07 10:00:00+05:30'
    # Output: Output datetime object

# Generated at 2022-06-22 06:06:42.390497
# Unit test for constructor of class TimeFormat
def test_TimeFormat():
    time = TimeFormat()
    assert isinstance(time, TimeFormat)


# Generated at 2022-06-22 06:06:45.580700
# Unit test for constructor of class DateTimeFormat
def test_DateTimeFormat():
    dt = datetime.datetime.now()
    s = dt.isoformat()
    f = DateTimeFormat()
    assert s == f.serialize(dt)

# Generated at 2022-06-22 06:06:54.664497
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()
    assert timeformat.validate("12:35:22") == datetime.time(12, 35, 22)
    assert timeformat.validate("12:35:22.123") == datetime.time(12, 35, 22, 123000)
    # Error format
    with pytest.raises(ValidationError) as errinfo:
        timeformat.validate("12:35:22.123456789")
    assert str(errinfo.value) == "Must be a valid time format."
    # Error invalid
    with pytest.raises(ValidationError) as errinfo:
        timeformat.validate("24:00:00")
    assert str(errinfo.value) == "Must be a real time."



# Generated at 2022-06-22 06:06:59.969374
# Unit test for method validate of class BaseFormat
def test_BaseFormat_validate():

    # Test BaseFormat.validate method in case of None value
    with pytest.raises(NotImplementedError):
        base_format = BaseFormat()
        base_format.validate(None)

    # Test BaseFormat.validate method in case of not None value
    with pytest.raises(NotImplementedError):
        base_format = BaseFormat()
        base_format.validate('')
