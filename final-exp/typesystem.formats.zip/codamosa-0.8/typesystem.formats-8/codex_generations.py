

# Generated at 2022-06-12 15:39:30.692234
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    assert t.validate("12:00") == datetime.time(12, 0, 0)
    assert t.validate("12:00:00.000000") == datetime.time(12, 0, 0)
    assert t.validate("12:00:00.123456") == datetime.time(12, 0, 0, 123456)
    assert t.validate("12:00:00") == datetime.time(12, 0, 0)
    assert t.validate("12:00:00.123") == datetime.time(12, 0, 0, 123000)
    assert t.validate("12:00:00.12") == datetime.time(12, 0, 0, 120000)
    assert t.validate("12:00:00.1") == datetime.time

# Generated at 2022-06-12 15:39:42.730956
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Positive Testcase#1
    value = "2000-01-31T12:34:56Z"
    format = DateTimeFormat()
    obj = format.validate(value)
    assert isinstance(obj,datetime.datetime)
    assert obj == datetime.datetime(2000,1,31,12,34,56,0,datetime.timezone.utc)
    
    # Positive Testcase#2
    value = "2000-01-31T12:34:56.123456"
    obj = format.validate(value)
    assert isinstance(obj,datetime.datetime)
    assert obj == datetime.datetime(2000,1,31,12,34,56,123456)
    
    # Positive Testcase#3

# Generated at 2022-06-12 15:39:45.244005
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    from typesystem.formats import TimeFormat

    obj = datetime.time(hour=1)
    obj_ = TimeFormat().serialize(obj)

    assert isinstance(obj_, str)



# Generated at 2022-06-12 15:39:48.492775
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    time_obj = datetime.time()
    assert tf.serialize(time_obj) == time_obj.isoformat()



# Generated at 2022-06-12 15:39:53.560371
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    check_DateTimeFormat_serialize = DateTimeFormat()
    obj = datetime.datetime(year=12,
                            month=1,
                            day=2,
                            hour=3,
                            minute=4,
                            second=5,
                            microsecond=6,
                            tzinfo=None)
    value = check_DateTimeFormat_serialize.serialize(obj)
    assert value == "12-01-02T03:04:05.000006"

# Generated at 2022-06-12 15:39:58.220304
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert UUIDFormat().validate("e5d5c9b5-c740-4bb3-8b00-4d0f734c26a3").__str__() == "e5d5c9b5-c740-4bb3-8b00-4d0f734c26a3"


# Generated at 2022-06-12 15:40:01.141559
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
	time = TimeFormat()
	assert time.validate("12:34:56.123456") == datetime.time(12,34,56,123456)
	

# Generated at 2022-06-12 15:40:08.149638
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1)) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 1, 2, 3, 4000)) == "2020-01-01T01:02:03.004000"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 1, 1, 2, 3, 4, datetime.timezone.utc)) == "2020-01-01T01:02:03.004000Z"

# Generated at 2022-06-12 15:40:10.729260
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat = DateFormat()
    date = dateformat.validate('2019-07-29')
    assert date.year == 2019
    assert date.month == 7
    assert date.day == 29


# Generated at 2022-06-12 15:40:14.269586
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    value = "07:12:52.000123456"
    time_format = TimeFormat()
    assert time_format.validate(value) == datetime.time(7,12,52,123456)



# Generated at 2022-06-12 15:40:23.555133
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d1 = datetime.date(2020,8,3)
    d2 = None
    format = DateFormat()
    
    assert format.serialize(d1) == '2020-08-03'
    assert format.serialize(d2) == None


# Generated at 2022-06-12 15:40:27.309362
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    import datetime
    with pytest.raises(ValidationError):
        d=DateFormat()
        x=d.validate("2020-09-32")
    assert True

# Generated at 2022-06-12 15:40:29.156164
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate('2020-01-01') == datetime.date(2020, 1, 1)
    

# Generated at 2022-06-12 15:40:32.775149
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()

# Generated at 2022-06-12 15:40:39.994823
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    fmt = DateTimeFormat()
    datetime_str = '2017-05-15T08:27:18Z'
    datetime = fmt.validate(value=datetime_str)
    expected_result = datetime.datetime(2017, 5, 15, 8, 27, 18, tzinfo=datetime.timezone.utc)
    assert datetime == expected_result


# Generated at 2022-06-12 15:40:42.276951
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_format.validate('2018-06-01')
    date_format.validate('2020-01-31')
    date_format.validate('2019-12-31')
    date_format.validate('2020-02-29')


# Generated at 2022-06-12 15:40:43.687288
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    obj = df.validate("2020-12-20")
    # The test serialize method
    assert df.serialize(obj) == "2020-12-20"


# Generated at 2022-06-12 15:40:48.927584
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value = '2020-02-02T07:54:20.590590'
    match = DATETIME_REGEX.match(value)
    groups = match.groupdict()
    tzinfo_str = groups.pop("tzinfo")
    kwargs = {k: int(v) for k, v in groups.items() if v is not None}
    print(kwargs)
    print(tzinfo_str)

if __name__ == '__main__':
    test_DateTimeFormat_validate()

# Generated at 2022-06-12 15:41:00.210126
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt_format = DateTimeFormat()
    text = "2020-05-06T00:00:00Z"
    datetime = dt_format.validate(text)
    assert datetime.year == 2020
    assert datetime.month == 5
    assert datetime.day == 6
    assert datetime.hour == 0
    assert datetime.minute == 0
    assert datetime.second == 0
    assert datetime  == datetime.replace(tzinfo=datetime.astimezone().tzinfo)

    text = "2021-02-03T04:05:06.123+07:00"
    datetime = dt_format.validate(text)
    assert datetime.year == 2021
    assert datetime.month == 2
    assert datetime.day == 3
    assert datetime.hour == 4
   

# Generated at 2022-06-12 15:41:08.411671
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test date format with random date
    date_format = DateFormat()
    date_value = date_format.validate("2020-03-08")
    assert isinstance(date_value, datetime.date)

    # Test date format with invalid date
    with pytest.raises(ValidationError):
        date_format.validate("2020-13-08")

    # Test date format with invalid date
    with pytest.raises(ValidationError):
        date_format.validate("2020-03-32")

    # Test date format with invalid format
    with pytest.raises(ValidationError):
        date_format.validate("2020/03/08")



# Generated at 2022-06-12 15:41:16.594064
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
	date_time = DateTimeFormat()

	assert date_time.validate("2019-03-15T00:12:34") == datetime.datetime(2019, 3, 15, 0, 12, 34, 0)
	assert date_time.validate("2019-03-15T00:12:34Z") == datetime.datetime(2019, 3, 15, 0, 12, 34, 0, datetime.timezone.utc)
	assert date_time.validate("2019-03-15T00:12:34+02:00") == datetime.datetime(2019, 3, 15, 0, 12, 34, 0, datetime.timezone(datetime.timedelta(hours=2)))

# Generated at 2022-06-12 15:41:27.110498
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    cast = DateTimeFormat()
    assert cast.validate('2019-02-22T00:00:00Z') == datetime.datetime(2019, 2, 22, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert cast.validate('2019-02-22T00:00:00') == datetime.datetime(2019, 2, 22, 0, 0)
    assert cast.validate('2019-02-22T00:00:00.1') == datetime.datetime(2019, 2, 22, 0, 0, 0, 100000)
    assert cast.validate('2019-02-22T00:00:00Z') == datetime.datetime(2019, 2, 22, 0, 0, 0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-12 15:41:33.484218
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_datetime = datetime.datetime(2009, 12, 31, 10, 10, 31)
    test_datetime_str = test_datetime.isoformat()
    assert test_datetime_str == "2009-12-31T10:10:31"

    assert DateTimeFormat().validate(test_datetime_str) == test_datetime


test_datetime_str_tz = "2013-12-14T23:16:05-05:00"



# Generated at 2022-06-12 15:41:38.634700
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("15:00") == datetime.time(15, 0)
    assert time.validate("15:00:00") == datetime.time(15, 0)
    assert time.validate("15:00:00.000000") == datetime.time(15, 0)
    assert time.validate("15:00:00.000001") == datetime.time(15, 0, 0, 1)

# Generated at 2022-06-12 15:41:44.181351
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    value = DateFormat()
    match = DATE_REGEX.match("2019-12-30")
    kwargs = {k: int(v) for k, v in match.groupdict().items()}
    try:
        expected = datetime.date(**kwargs)
    except ValueError:
        pass
    actual = value.validate("2019-12-30")
    assert expected == actual



# Generated at 2022-06-12 15:41:52.451211
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
	time_format = TimeFormat()
	assert time_format.validate('12:23') == datetime.time(12,23)
	assert time_format.validate('12:23:34.123456') == datetime.time(12,23,34,123456)
	#assert time_format.validate('25:23') == 'Must be a real time'
	#assert time_format.validate('12:60') == 'Must be a real time'
	#assert time_format.validate('12:23:60') == 'Must be a real time'
	#assert time_format.validate('12:23:34:123456') == 'Must be a valid time format'

# Generated at 2022-06-12 15:42:02.131611
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    def assert_valid_time(value):
        assert TimeFormat().validate(value) == datetime.time(value.hour, value.minute, value.second, value.microsecond)

    assert_valid_time(datetime.time(12, 34, 56, 7890))
    assert_valid_time(datetime.time(12, 34, 56, 7890, tzinfo=datetime.timezone.utc))
    assert_valid_time(datetime.time(12, 34, 56))
    assert_valid_time(datetime.time(12, 34))
    assert_valid_time(datetime.time(12))

    assert TimeFormat().validate("12:34:56.789") == datetime.time(12, 34, 56, 789000)



# Generated at 2022-06-12 15:42:09.506848
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    from_string_datetime = datetime.datetime.strptime('2018-12-21T17:00:00+01:00', '%Y-%m-%dT%H:%M:%S%z')
    date_format = DateTimeFormat()
    date_format.serialize(from_string_datetime)
    assert date_format.serialize(from_string_datetime) == '2018-12-21T17:00:00+01:00'



# Generated at 2022-06-12 15:42:14.607769
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Given
    time = TimeFormat()


    # When
    result = time.validate("23:59:59.999999")


    # Then
    assert result == datetime.time(hour=23, minute=59, second=59, microsecond=999999)



# Generated at 2022-06-12 15:42:19.692968
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019,11,19,15,10,12,tzinfo=datetime.timezone.utc)) == '2019-11-19T15:10:12Z'


# Generated at 2022-06-12 15:42:26.925788
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():

    time_format = TimeFormat()
    time_format.validate("00:00:00")
    time_format.validate("00:00:00.01")


# Generated at 2022-06-12 15:42:38.715617
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    print("\nTest method validate of class DateTimeFormat")
    formatter = DateTimeFormat()

# Generated at 2022-06-12 15:42:41.820823
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    datefmt = DateFormat()
    date = datefmt.validate("2020-12-24")
    assert type(date) == datetime.date
    assert date.year == 2020
    assert date.month == 12
    assert date.day == 24


# Generated at 2022-06-12 15:42:45.537677
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
	assert DateFormat().validate('2017-05-17') == datetime.date(2017, 5, 17)


# Generated at 2022-06-12 15:42:49.037575
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    result = time_format.validate('12:30')
    assert result == datetime.time(hour=12, minute=30)



# Generated at 2022-06-12 15:42:59.417361
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_obj = TimeFormat()
    assert time_obj.validate('19:00') == datetime.time(19,00)
    assert time_obj.validate('19:00:10') == datetime.time(19,00,10)
    assert time_obj.validate('19:00:10.123') == datetime.time(19,00,10,123000)
    assert time_obj.validate('19:00:10.1234') == datetime.time(19,00,10,123400)
    assert time_obj.validate('19:00:10.123456') == datetime.time(19,00,10,123456)
    assert time_obj.validate('19:00:10.1234567') == datetime.time(19,00,10,123456)

# Generated at 2022-06-12 15:43:01.287726
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    a = DateTimeFormat()
    print(a.validate(value="2018-10-29T10:00:00Z"))

# Generated at 2022-06-12 15:43:06.021980
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    obj_DateTimeFormat = DateTimeFormat()
    assert obj_DateTimeFormat.validate("2012-09-24T10:10:10Z") == datetime.datetime(2012, 9, 24, 10, 10, 10, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-12 15:43:17.811219
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # time is in AM 
    assert TimeFormat().validate("00:00:00")
    # time is in PM 
    assert TimeFormat().validate("12:00:00")
    # time has 1 digit in hours
    assert TimeFormat().validate("1:00:00")
    # time has 1 digit in minutes
    assert TimeFormat().validate("01:1:00")
    # time has 1 digit in seconds
    assert TimeFormat().validate("01:01:1")
    # time has 1 digit in microseconds
    assert TimeFormat().validate("01:01:01.1")
    # time has 6 digits in microseconds
    assert TimeFormat().validate("01:01:01.100000")
    # time has 12 hours 
    assert TimeFormat().validate("12:00:00.000000")
   

# Generated at 2022-06-12 15:43:22.148946
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = datetime.datetime.now()
    time_str = time.strftime('%Y-%m-%d %H:%M:%S')
    time_format = TimeFormat()
    assert time_format.validate(time_str).isoformat() == time.time().isoformat()

# Generated at 2022-06-12 15:43:34.182900
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt_format = DateTimeFormat()
    datetime = dt_format.validate('2020-01-13T00:00:00.00Z')
    assert isinstance(datetime, datetime.datetime)
    assert datetime.year == 2020
    assert datetime.month == 1
    assert datetime.day == 13
    assert datetime.hour == 0
    assert datetime.minute == 0
    assert datetime.second == 0
    assert datetime.microsecond == 0
    assert datetime.tzinfo == datetime.timezone.utc

    datetime = dt_format.validate('2020-01-13T00:00:00+07:00')
    assert datetime.tzinfo.utcoffset(datetime) == datetime.timedelta(hours=7)



# Generated at 2022-06-12 15:43:36.493913
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    formatter = TimeFormat()
    formatter.validate('12:34:56')



# Generated at 2022-06-12 15:43:48.904630
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
	tf = TimeFormat()
	ret1 = isinstance(tf.validate("13:31:00"), datetime.time)
	if ret1 == False:
		raise Exception("return type mismatch")
	elif ret1 == True :
		print("testcase passed")
		print("return type match")
		
	try :
		tf.validate("13:61:00.00")
		print("return value mismatch")
		raise Exception("return value mismatch")
	except ValidationError as ex:
		ret2 = tf.is_native_type(ex.value)
		if ret2 == True:
			print("testcase passed")
			print("return value match")
		elif ret2 == False:
			print("return value mismatch")
			raise Exception

# Generated at 2022-06-12 15:43:53.169545
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    '''
    Test validate method in class DateFormat
    '''
    test_date = DateFormat()
    assert test_date.validate('2020-06-04') == datetime.date(2020, 6, 4)


# Generated at 2022-06-12 15:44:00.378818
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # For the time format of regex, it does not contain decimal point. So, it must be integer.
    # The the input of validate method must be integer type if it is valid time format.
    # Invalid time format can pass the test.
    tf = TimeFormat()
    input_1 = '12:34:56'
    output_1 = tf.validate(input_1)
    assert output_1.hour == 12
    assert output_1.minute == 34
    assert output_1.second == 56
    input_2 = '12:34'
    output_2 = tf.validate(input_2)
    assert output_2.hour == 12
    assert output_2.minute == 34
    input_3 = '12:34:56.'
    output_3 = tf.validate(input_3)
    assert output_3

# Generated at 2022-06-12 15:44:12.793505
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem.base import ValidationError
    from typesystem.formats import DateTimeFormat

    dt_str = "2019-01-01T01:01:01"
    assert DateTimeFormat().validate(dt_str)

    dt_str = "2019-01-01T01:01:01Z"
    assert DateTimeFormat().validate(dt_str)

    dt_str = "2019-01-01T01:01:01+01:00"
    assert DateTimeFormat().validate(dt_str)

    dt_str = "2019-01-01T01:01:01+0100"
    assert DateTimeFormat().validate(dt_str)

    dt_str = "2019-01-01T01:01:01-0700"

# Generated at 2022-06-12 15:44:15.699559
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    print(datetime_format.validate('2013-03-21T20:28:11'))



# Generated at 2022-06-12 15:44:19.766150
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2019-09-24") == datetime.date(2019, 9, 24)
    assert date_format.validate("2019-09-24") == datetime.date(2019, 9, 24)



# Generated at 2022-06-12 15:44:22.425665
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate('2019-01-01') == datetime.date(2019, 1, 1)


# Generated at 2022-06-12 15:44:33.340661
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf1 = TimeFormat()
    tf2 = TimeFormat()
    tf3 = TimeFormat()
    tf4 = TimeFormat()
    tf5 = TimeFormat()
    tf6 = TimeFormat()
    tf7 = TimeFormat()
    tf8 = TimeFormat()
    tf9 = TimeFormat()
    
    assert tf1.validate("12:00") == datetime.time(12, 0)
    assert tf2.validate("00:12") == datetime.time(0, 12)
    assert tf3.validate("12:12") == datetime.time(12,12)
    assert tf4.validate("12:12:12") == datetime.time(12, 12, 12)

# Generated at 2022-06-12 15:44:44.929552
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    ## case 1
    value = "09:07:14.123456"
    format = TimeFormat()
    assert format.validate(value) == datetime.datetime(2019, 11, 11, 9, 7, 14, 123456).time()

    ## case 2
    value = "09:07:14"
    format = TimeFormat()
    assert format.validate(value) == datetime.datetime(2019, 11, 11, 9, 7, 14).time()

    ## case 3
    value = "09:07"
    format = TimeFormat()
    assert format.validate(value) == datetime.datetime(2019, 11, 11, 9, 7).time()

    ## case 4
    value = "09:07:14.12345"
    format = TimeFormat()
    assert format.validate(value)

# Generated at 2022-06-12 15:44:47.524594
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    TimeFormat().validate("12:30:00")
    TimeFormat().validate("12:30:12.10")
    TimeFormat().validate("12:30:12.123456")

# Generated at 2022-06-12 15:44:51.773153
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2018-10-12T20:25:34+05:00") == datetime.datetime(2018, 10, 12, 20, 25, 34, tzinfo=datetime.timezone(datetime.timedelta(hours=5)))

# Generated at 2022-06-12 15:44:54.992362
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    assert dateFormat.validate('2019-03-15') == datetime.date(2019, 3, 15)


# Generated at 2022-06-12 15:45:01.999840
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    test_time_format = TimeFormat()
    assert test_time_format.validate('23:24:21') == datetime.time(23, 24, 21)
    assert test_time_format.validate('23:24') == datetime.time(23, 24)
    assert test_time_format.validate('23:24:21.123456') == datetime.time(23, 24, 21, 123456)
    assert test_time_format.validate('23:24:21.1234567') == datetime.time(23, 24, 21, 123456)
    assert test_time_format.validate('23:24:21.1') == datetime.time(23, 24, 21, 100000)


# Generated at 2022-06-12 15:45:04.776129
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()
    assert format.validate("2016-07-12T06:55:10") == datetime.datetime(2016, 7, 12, 6, 55, 10)
    assert format.validate("2016-07-12T06:55:10.123456") == datetime.datetime(2016, 7, 12, 6, 55, 10, 123456)


# Generated at 2022-06-12 15:45:10.174698
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    DT = DateTimeFormat()
    try:
        DT.validate('2105-02-22T10:18:23Z')
    except ValidationError:
        failed = True
    else:
        failed = False
    assert failed == False

# Generated at 2022-06-12 15:45:11.893222
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dat = DateFormat()
    assert dat.validate("2020-11-17") == datetime.date(2020,11,17)
    assert dat.validate("2020-11-17") is not None


# Generated at 2022-06-12 15:45:13.425479
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem.typing import DateTime

    date_format = DateTime(format="date-time")
    date_format.validate(value="2020-01-01T15:34:05Z")



# Generated at 2022-06-12 15:45:14.485033
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2222-12-31T23:59:59.999999") is None

# Generated at 2022-06-12 15:45:24.937545
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    df.validate('2019-01-13')
    df.validate('2019-02-11')
    df.validate('2019-12-01')
    df.validate('2019-12-31')
    df.validate('0001-01-01')
    df.validate('9999-12-31')


# Generated at 2022-06-12 15:45:34.700783
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Define a valid date
    date_valide = "1990-03-03"
    # Define a valid date in an other format
    date_valide2 = "03-03-1990"

    # Define an invalid date
    date_invalide = "3-3-90"

    # Define a class with the same format
    class TestDateFormat(BaseFormat):
        def is_native_type(self, value: typing.Any) -> bool:
            return isinstance(value, datetime.date)

        def validate(self, value: typing.Any) -> datetime.date:
            match = DATE_REGEX.match(value)
            if not match:
                raise ValidationError(
                    text="Must be a valid date format.", code="format"
                )


# Generated at 2022-06-12 15:45:38.480095
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    str_value = "2020-04-23T11:26:00+09:00"
    test_DateTimeFormat = DateTimeFormat()
    print(test_DateTimeFormat.validate(str_value))


# Generated at 2022-06-12 15:45:46.215048
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()
    assert format.validate('2001-02-03') == datetime.date(2001, 2, 3)
    assert format.validate('') == datetime.date(2001, 2, 3)
    assert format.validate('2001') == datetime.date(2001, 2, 3)
    with pytest.raises(ValidationError):
        format.validate(None)
    val = datetime.date(2001,2,3)
    assert format.validate(val) == datetime.date(2001, 2, 3)


# Generated at 2022-06-12 15:45:48.229994
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate('12:34:56') == datetime.time(12,34,56)


# Generated at 2022-06-12 15:45:51.075011
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # When input is normal string
    obj = TimeFormat()
    result = obj.validate('12:34:56.789')
    # Then
    assert result.isoformat() == '12:34:56.789000'
    # When input is not normal string
    try:
        obj = TimeFormat()
        obj.validate('100:100:100.100100')
    except ValidationError as e:
        # Then
        assert str(e) == 'Must be a real time.'

# Generated at 2022-06-12 15:45:57.838693
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert isinstance(date.validate("2020-05-16"),datetime.date)
    try:
        date.validate("2020-12-50")
    except ValidationError as e:
        assert e.code == "invalid"
        assert e.text == "Must be a real date."
        #print(e.code)
        #print(e.text)
    try:
        date.validate("2020-12-50:00")
    except ValidationError as e:
        assert e.code == "format"
        assert e.text == "Must be a valid date format."
        #print(e.code)
        #print(e.text)


# Generated at 2022-06-12 15:46:07.544557
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    print('test_DateTimeFormat_validate')
    try:
        datetime = DateTimeFormat().validate('2019-12-17T14:53:53+02:00')
        assert isinstance(datetime, datetime.datetime)
        assert datetime.year == 2019
        assert datetime.month == 12
        assert datetime.day == 17
        assert datetime.hour == 14
        assert datetime.minute == 53
        assert datetime.second == 53
    except Exception as e:
        print(e)
        raise e


# Generated at 2022-06-12 15:46:09.964630
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    date = dateFormat.validate("2019-02-28")
    assert isinstance(date, datetime.date)


# Generated at 2022-06-12 15:46:16.253059
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value = '2006-02-02T08:12:26Z'
    #assert isinstance(datetime.datetime.isoformat(), object)
    assert isinstance(value, object)
    message = 'The test passed'
    assert True, message


# Generated at 2022-06-12 15:46:27.441142
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    #Input test
    value = "2019-1-1"
    print("Method validate of Class DateFormat Input test:", value)
    #Expected output
    output_test = datetime.date(2019, 1, 1)
    print("Expected Output: ", output_test)
    #Actual output
    format = DateFormat()
    output_actual = format.validate(value)
    print("Actual Output: ", output_actual)
    #Test
    assert output_actual == output_test


# Generated at 2022-06-12 15:46:29.884205
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    assert t.validate('15:45:45.10') == datetime.time(15, 45, 45, 10000)



# Generated at 2022-06-12 15:46:31.983012
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    obj = TimeFormat()
    assert obj.validate("00:00:00") == datetime.time(0,0)

# Generated at 2022-06-12 15:46:38.367616
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-07-06T23:14:31.228946Z") == datetime.datetime(2020, 7, 6, 23, 14, 31, 228946)
    assert DateTimeFormat().validate("2020-07-06T23:14:31.228946+02:30") == datetime.datetime(2020, 7, 6, 23, 14, 31, 228946)
    assert DateTimeFormat().validate("2020-07-06T23:14:31.228946") == datetime.datetime(2020, 7, 6, 23, 14, 31, 228946)

# Generated at 2022-06-12 15:46:43.293056
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value = "2019-06-27T11:00:00+00:00"
    tp = DateTimeFormat()
    datetime_obj = tp.validate(value)
    assert datetime_obj.date() == datetime.date(2019, 6, 27)
    assert datetime_obj.time() == datetime.time(11, 00, 00)
    assert datetime_obj.tzinfo == datetime.timezone.utc


# Generated at 2022-06-12 15:46:54.677823
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    import datetime
    time1 = datetime.time(hour=10, minute=20, second=30, microsecond=40)
    fmt1 = TimeFormat()
    t11 = fmt1.validate("10:20:30.000040")
    assert t11 == time1
    t12 = fmt1.validate("10:20:30")
    assert t12 == time1
    t13 = fmt1.validate("10:20")
    assert t13 == time1
    time2 = datetime.time(hour=10, minute=20, second=30, microsecond=40000)
    t21 = fmt1.validate("10:20:30.4")
    assert t21 == time2
    t22 = fmt1.validate("10:20:30.004")
    assert t22 == time2
   

# Generated at 2022-06-12 15:47:01.290064
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # re.compile(r"(?P<hour>\d{1,2}):(?P<minute>\d{1,2})(?::(?P<second>\d{1,2})(?:\.(?P<microsecond>\d{1,6})\d{0,6})?)?")
    time_format = TimeFormat()
    assert time_format.validate("15:06:03.123456") == datetime.time(hour=15, minute=6, second=3, microsecond=123456)
    assert time_format.validate("15:05") == datetime.time(hour=15, minute=5)
    assert time_format.validate("15") == datetime.time(hour=15)
    assert time_format.validate("15:06:03.12345")

# Generated at 2022-06-12 15:47:13.712840
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():

    import datetime
    from typesystem.formats import DateTimeFormat
    from typesystem.types import String
    from typesystem.errors import ValidationError

    year = 2020
    month = 2
    day = 15
    hour = 8
    minute = 30
    second = 0
    microsecond = 0
    tzinfo = datetime.timezone.utc

    class MyDateTime(DateTimeFormat, String):
        pass

    # Valid datetime format
    value = "2020-02-15T08:30:00Z"
    assert isinstance(MyDateTime(value=value).validate(value), datetime.datetime)

    # Invalid datetime format
    value = "2020-Month-DayT08:30:00Z"

# Generated at 2022-06-12 15:47:19.527540
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    d = DateFormat()
    assert d.validate('1994-12-31') == datetime.date(1994, 12, 31)
    try:
        d.validate('1995-13-32')
        assert False
    except ValidationError:
        assert True
    try:
        d.validate('1995-12-32')
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-12 15:47:23.284710
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    time = timezone.now().isoformat()
    dateTimeFormat = DateTimeFormat()
    dateTimeFormat.validate(time)
    time = timezone.now().isoformat() + 'Z'
    dateTimeFormat.validate(time)


# Generated at 2022-06-12 15:47:36.357341
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = "23:11"
    result = TimeFormat().validate(time)
    assert isinstance(result, datetime.time)
    assert result.strftime("%H:%M") == "23:11"

    time = "23:11:02"
    result = TimeFormat().validate(time)
    assert isinstance(result, datetime.time)
    assert result.strftime("%H:%M:%S") == "23:11:02"

    time = "23:11:02.123456"
    result = TimeFormat().validate(time)
    assert isinstance(result, datetime.time)
    assert result.strftime("%H:%M:%S.%f")[:13] == "23:11:02.123"


# Generated at 2022-06-12 15:47:39.308362
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = "12:56"
    actual = TimeFormat().validate(time)
    expected = datetime.time(12, 56)
    assert actual == expected


# Generated at 2022-06-12 15:47:44.987535
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    assert date.validate("xxxx-xx-xx") == Exception("Must be a valid date format.")
    assert date.validate("0199-10-13") == Exception("Must be a real date.")
    assert date.validate("2019-10-10") == datetime.date(2019, 10, 10)


# Generated at 2022-06-12 15:47:56.807251
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    formatter = DateTimeFormat()
    # assert(formatter.validate('1994-11-05T08:15:30-05:00')==datetime.datetime(1994,11,5,8,15,30,tzinfo=datetime.timezone(-datetime.timedelta(0,18000))))
    assert(
        formatter.validate("1994-11-05T08:15:30-05:00")
        == datetime.datetime(1994,11,5,8,15,30,tzinfo=datetime.timezone(-datetime.timedelta(hours=5)))
    )

if __name__ == "__main__":
    test_DateTimeFormat_validate();
    print(uuid.uuid4())

# Generated at 2022-06-12 15:48:01.964371
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    # Case 1
    value = "15:01:00"
    datetime_result = tf.validate(value)
    assert isinstance(datetime_result, datetime.time)
    assert datetime_result == datetime.time(15,1,0)

    # Case 2
    value = "15:01:12.001234"
    datetime_result = tf.validate(value)
    assert isinstance(datetime_result, datetime.time)
    assert datetime_result == datetime.time(15,1,12,1234)


# Generated at 2022-06-12 15:48:05.910871
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    test_data = [
        ("2019-10-23", datetime.date(2019, 10, 23)),
        ("2019-1-23", datetime.date(2019, 1, 23)),
        ("2019-01-1", datetime.date(2019, 1, 1)),
    ]

    for param, expected in test_data:
        assert dateFormat.validate(param) == expected



# Generated at 2022-06-12 15:48:09.710792
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    expected = datetime.date(2020, 12, 19)
    test_value = "2020-12-19"
    assert DateFormat().validate(test_value) == expected

# Generated at 2022-06-12 15:48:14.834647
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    d = DateTimeFormat()
    # test valid data datetime
    assert d.validate("2019-12-11T15:30:00.000001Z") == datetime.datetime(2019, 12, 11, 15, 30, 0, 1, datetime.timezone.utc)
    assert d.validate("1912-02-11T15:30:00.000001Z") == datetime.datetime(1912, 2, 11, 15, 30, 0, 1, datetime.timezone.utc)
    assert d.validate("1912-02-11T15:30:00.000001+00:00") == datetime.datetime(1912, 2, 11, 15, 30, 0, 1, datetime.timezone.utc)

# Generated at 2022-06-12 15:48:22.918744
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # datetime string without timezone
    date_str = "2016-05-22T14:58:56.123456"
    date_time = DateTimeFormat().validate(date_str)
    assert date_time.strftime("%Y-%m-%dT%H:%M:%S.%f") == date_str[:-3] + "000"

    # datetime string with timezone hours only
    date_str = "2016-05-22T16:58:56.123456+02"
    date_time = DateTimeFormat().validate(date_str)
    assert date_time.strftime("%Y-%m-%dT%H:%M:%S.%f") == date_str[:-3] + "000"

    # datetime string with timezone hours/minutes


# Generated at 2022-06-12 15:48:31.387247
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()
    input1 = "19:23"
    expected_output = datetime.time(19, 23)
    assert timeformat.validate(input1) == expected_output

    input2 = "19:23:32"
    expected_output = datetime.time(19, 23, 32)
    assert timeformat.validate(input2) == expected_output

    input3 = "19:23:32.123"
    expected_output = datetime.time(19, 23, 32, 123000)
    assert timeformat.validate(input3) == expected_output

    input4 = "19:23:32.1237"
    expected_output = datetime.time(19, 23, 32, 123000)
    assert timeformat.validate(input4) == expected_output

    #unit test

# Generated at 2022-06-12 15:48:39.413766
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    basic = DateFormat()
    assert basic.validation_error("invalid") == ValidationError(
        text="Must be a real date.", code="invalid"
    )
    

# Generated at 2022-06-12 15:48:44.073142
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    my_class = DateTimeFormat()
    value1 = my_class.validate("2019-07-22T00:00:00+00:00")
    assert value1 == datetime.datetime(2019,7,22,0,0,0,tzinfo=datetime.timezone.utc)


# Generated at 2022-06-12 15:48:50.398872
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    print("Test for method validate of class DateFormat\n")
    my_date = DateFormat()
    input_date = "2020-09-08"
    output_date = "2020-09-08"
    my_date.validate(input_date)
    print(my_date.validate(input_date))
    print(output_date)


# Generated at 2022-06-12 15:49:02.554835
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    df = DateTimeFormat()
    result = df.validate("2020-07-09T12:24:36.018000")
    assert result == datetime.datetime(2020, 7, 9, 12, 24, 36, 18000)

    result = df.validate("2020-07-09T12:24:36.018")
    assert result == datetime.datetime(2020, 7, 9, 12, 24, 36, 18000)

    result = df.validate("2020-07-09T12:24:36")
    assert result == datetime.datetime(2020, 7, 9, 12, 24, 36)

    result = df.validate("2020-07-09T12:24:36.018+02:00")

# Generated at 2022-06-12 15:49:06.432791
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    schema = DateFormat()
    obj = schema.validate("2019-10-09")
    assert isinstance(obj, datetime.date)

    with pytest.raises(ValidationError):
        schema.validate("2019")

    with pytest.raises(ValidationError):
        schema.validate("2019-14-09")
