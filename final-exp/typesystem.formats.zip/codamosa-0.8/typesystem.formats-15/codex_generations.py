

# Generated at 2022-06-12 15:39:28.126976
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    myUUID_format = UUIDFormat()
    assert myUUID_format.validate("f4aa5567-2f4d-4b3e-b789-23b794a5e33e") == uuid.UUID("f4aa5567-2f4d-4b3e-b789-23b794a5e33e")
    assert myUUID_format.validate("F4AA5567-2F4D-4B3E-B789-23B794A5E33E") == uuid.UUID("f4aa5567-2f4d-4b3e-b789-23b794a5e33e")


# Generated at 2022-06-12 15:39:29.961803
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('12:23:45.678901') == datetime.time(12,23,45,678901)

# Generated at 2022-06-12 15:39:39.076153
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format=TimeFormat()
    time=time_format.validate("12:32:10")
    assert time.hour == 12
    assert time.minute == 32
    assert time.second == 10
    assert time.tzinfo == None
    time=time_format.validate("12:32:10.123456")
    assert time.hour == 12
    assert time.minute == 32
    assert time.second == 10
    assert time.microsecond == 123456
    assert time.tzinfo == None

# Generated at 2022-06-12 15:39:42.320689
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("12:00")
    time_format.validate("12:00:56")
    time_format.validate("12:00:56.1234567")

# Generated at 2022-06-12 15:39:45.452063
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()
    time = timeformat.validate("19:12")
    assert(time.hour == 19)
    assert(time.minute == 12)
    assert(time.second == 0)
    assert(time.microsecond == 0)


# Generated at 2022-06-12 15:39:50.357822
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uf = UUIDFormat()
    uf.validate("a5a6be5c-b9a9-4980-932c-6083a2c7561f")
    # uf.validate("a5a6be5c-b9a9-4980-932c-6083a2c7561") # will raise error

# Generated at 2022-06-12 15:39:59.470248
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date = DateTimeFormat()

    example = date.validate('2019-02-15T13:53:02Z')
    assert example == datetime.datetime(2019, 2, 15, 13, 53, 2, tzinfo=datetime.timezone.utc)
    
    example2 = date.validate('2019-02-15T22:30:00+09:00')
    assert example2 == datetime.datetime(2019, 2, 15, 22, 30, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=9)))
    
    example3 = date.validate('2019-04-30 12:00:00')
    assert example3 == datetime.datetime(2019, 4, 30, 12, 0, 0)


# Generated at 2022-06-12 15:40:07.349439
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 15, 15, 29, tzinfo=datetime.timezone.utc)) == "2020-01-15T15:29:00Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 15, 15, 29, tzinfo=datetime.timezone(datetime.timedelta(hours=+7)))) == "2020-01-15T15:29:00+07:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 15, 15, 29, tzinfo=datetime.timezone(datetime.timedelta(hours=-11)))) == "2020-01-15T15:29:00-11:00"

# Generated at 2022-06-12 15:40:10.069052
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    testvalue = "00000000-0000-0000-0000-000000000000"
    uuidvalue = UUIDFormat().validate(testvalue)
    assert isinstance(uuidvalue, uuid.UUID)


# Generated at 2022-06-12 15:40:14.674998
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    data = ["1970-01-01", "1970-01-01T00:00:00", "1970-01-01T00:00:00Z", "1970-01-01T00:00:00+00:00"]
    for i in data:
        assert datetime.datetime.fromisoformat(i) == DateTimeFormat().validate(i)

# Generated at 2022-06-12 15:40:24.621595
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_obj = datetime.time(8,30)
    result = TimeFormat.serialize(time_obj)
    return result



# Generated at 2022-06-12 15:40:27.801741
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2017-10-24")
    assert date.isoformat() == "2017-10-24"


# Generated at 2022-06-12 15:40:31.187347
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    import datetime
    ValidDate = datetime.date(2000, 1, 1)
    print(ValidDate)
    df = DateFormat()
    assert (df.validate("2000-01-01")) == ValidDate
    print(df.validate("2000-01-01"))


# Generated at 2022-06-12 15:40:32.522013
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    assert dateFormat.validate("2018-06-12") == datetime.date(2018, 6, 12)

# Generated at 2022-06-12 15:40:37.000315
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    assert dateFormat.validate("2002-09-24") == datetime.date(2002, 9, 24)


# Generated at 2022-06-12 15:40:42.003083
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    try:
        assert date_format.validate("2018-12-15")
        assert date_format.validate("2018-1-1")
        assert date_format.validate("2018-12-05")
        assert date_format.validate("2018-12-05")
        assert date_format.validate("2018-12-25")
    except ValidationError:
        print("DateFormat: Wrong date as input")


# Generated at 2022-06-12 15:40:47.193260
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    format = TimeFormat()
    assert format.validate("23:59:59.999999") == datetime.time(hour=23, minute=59, second=59, microsecond=999999)
    assert format.validate("23:59:59") == datetime.time(hour=23, minute=59, second=59)
    assert format.validate("23:59") == datetime.time(hour=23, minute=59)



# Generated at 2022-06-12 15:40:49.982718
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    expected = datetime.date(2019,1,10)
    date_str = '2019-01-10'
    actual = DateFormat().validate(date_str)
    assert expected == actual


# Generated at 2022-06-12 15:41:01.486910
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # create a DateFormat instance
    date_format = DateFormat()
    
    # input test data
    test_data = [
        ('2020-1-1', datetime.date(2020, 1, 1)),  # test case 1
        ('2020-2-29', datetime.date(2020, 2, 29)),  # test case 2
        ('2019-2-29', ValidationError),  # test case 3
        ('2019-1-32', ValidationError),  # test case 4
        ('2021-1-1', ValidationError),  # test case 5
        ('2000-1-1', datetime.date(2000, 1, 1)),  # test case 6
        ('0000-1-1', ValidationError),  # test case 7
    ]

    # test class DateFormat

# Generated at 2022-06-12 15:41:03.949036
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    Date_format = DateFormat()
    assert Date_format.validate("2020-02-14") == datetime.date(2020, 2, 14)


# Generated at 2022-06-12 15:41:12.772461
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("10:00:00") == datetime.time(hour=10,minute=0,second=0)
    assert TimeFormat().validate("12:00:00.000") == datetime.time(hour=12,minute=0,second=0)
    assert TimeFormat().validate("10:00:00.00001") == datetime.time(hour=10,minute=0,second=0, microsecond=10000)
    assert TimeFormat().validate("10:00:00.000010") == datetime.time(hour=10,minute=0,second=0, microsecond=10000)
    

# Generated at 2022-06-12 15:41:25.370574
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    import datetime

    time = datetime.time(hour=10)
    d = TimeFormat()
    assert d.serialize(time) == "10:00:00"

    time = datetime.time(hour=10, minute=20, second=30)
    d = TimeFormat()
    assert d.serialize(time) == "10:20:30"

    time = datetime.time(hour=10, microsecond=123456)
    d = TimeFormat()
    assert d.serialize(time) == "10:00:00.123456"

    time = datetime.time(hour=10, minute=11, second=12, microsecond=123456)
    d = TimeFormat()
    assert d.serialize(time) == "10:11:12.123456"


# Generated at 2022-06-12 15:41:28.802328
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    try:
        assert time_format.validate("asdf") == ValidationError
    except ValidationError:
        assert True


# Generated at 2022-06-12 15:41:35.945098
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
	tf = TimeFormat()
	try:
		assert tf.validate('11:50:00.00000') == (datetime.time(11, 50, 0, 0))
		assert tf.validate('17:13:00') == (datetime.time(17, 13))
		assert tf.validate('22:01') == (datetime.time(22, 1))
	except Exception as err:
		print ('Test failed: Error message:', err.args[0])

test_TimeFormat_validate()


# Generated at 2022-06-12 15:41:40.551189
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    date_str = "2019-04-12"
    assert date.serialize(date.validate(date_str)) == date_str


# Generated at 2022-06-12 15:41:49.900753
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    test_time = '17:15:45.123456'
    value = tf.validate(test_time)
    assert value.hour == 17
    assert value.minute == 15
    assert value.second == 45
    assert value.microsecond == 123456
    with pytest.raises(ValidationError) as error:
        value = tf.validate('17:15:45.123456')
    with pytest.raises(ValidationError) as error:
        value = tf.validate('17:15:45')
    with pytest.raises(ValidationError) as error:
        value = tf.validate('17:15')
    with pytest.raises(ValidationError) as error:
        value = tf.validate('17')


# Generated at 2022-06-12 15:41:55.157810
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
        time=datetime.time(3,6,2,2)
        timef=TimeFormat()
        time_string=timef.serialize(time)
        assert(time_string=='03:06:02.000002')

# Generated at 2022-06-12 15:42:00.069970
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value ="2020-10-23T18:38:18.422156+01:00"
    assert DateTimeFormat().validate(value)==datetime.datetime(2020, 10, 23, 18, 38, 18, 422156, tzinfo=datetime.timezone(datetime.timedelta(seconds=3600)))

# Generated at 2022-06-12 15:42:02.480641
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    value = time_format.validate("14:20:10.123494")
    assert value == datetime.time(14, 20, 10, 123494)


# Generated at 2022-06-12 15:42:08.429344
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time_format = TimeFormat()
    assert time_format.serialize(datetime.datetime(1900, 1, 1, 12, 12, 12)) == '12:12:12'
    assert time_format.serialize(datetime.datetime(1900, 1, 1, 12, 12, 12, 120000)) == '12:12:12.120000'
    assert time_format.serialize(datetime.datetime(1900, 1, 1, 12, 12, 12, 12)) == '12:12:12.000012'
    assert time_format.serialize(datetime.datetime(1900, 1, 1, 12, 12, 12, 12, tzinfo=datetime.timezone.utc)) == '12:12:12.000012Z'

# Generated at 2022-06-12 15:42:14.184097
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeobj = TimeFormat()
    timeobj.validate("24:00:00")


# unit test for method serialize of class TimeFormat

# Generated at 2022-06-12 15:42:18.918584
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    dt = dtf.validate('2019-05-20T18:30:29Z')
    print(dt)


# Generated at 2022-06-12 15:42:20.889913
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("19:14:34")
    assert True


# Generated at 2022-06-12 15:42:28.637356
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate('24:00:00') == datetime.time(hour=24)
    assert time.validate('00:00:00') == datetime.time(hour=0)
    assert time.validate('00:00:00.000000') == datetime.time(hour=0)
    assert time.validate('00:00:00.000001') == datetime.time(hour=0, microsecond=10)
    assert time.validate('00:00:00.000010') == datetime.time(hour=0, microsecond=100)
    assert time.validate('00:00:00.000100') == datetime.time(hour=0, microsecond=1000)

# Generated at 2022-06-12 15:42:34.879865
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    try:
        date.validate("2018-02-29")
    except:
        pass
    else:
        assert False

    try:
        date.validate("2020-04-30")
    except:
        assert False
    else:
        pass


# Generated at 2022-06-12 15:42:40.235546
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    class V(BaseFormat):
        def is_native_type(self, value):
            return value

        def error(self, code, **kwargs):
            return "error " + code

    v = V()
    assert v.is_native_type('12:34') == True
    assert (v.error('format', value='12:34')) == 'error format'
    assert v.validate('12:34') == '12:34'

# Generated at 2022-06-12 15:42:46.945179
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate('11:35:29') 
    assert tf.validate('11:35:29.999999') 
    assert tf.validate('11:35') 
    assert tf.validate('11:35:') 
    assert tf.validate('11:35:29.99999') 
    assert not tf.validate('11:35:29.zzzzz') 
    assert not tf.validate('1:35:29') 
    assert not tf.validate('11:5:29') 
    assert not tf.validate('11:35:4') 
    assert not tf.validate('11:35:29.99999d') 
    assert tf.validate('24:00:00') 

# Generated at 2022-06-12 15:42:50.203858
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    dateinfo = date.validate("2019-08-29")
    assert dateinfo == datetime.date(2019, 8, 29)

# Generated at 2022-06-12 15:42:55.657455
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("12:00:00.123456") == datetime.time(
        12, 0, 0, 123456
    )
    assert TimeFormat().validate("10:20:30") == datetime.time(10, 20, 30)
    assert TimeFormat().validate("10:20") == datetime.time(10, 20)
    assert TimeFormat().validate("10") == da

# Generated at 2022-06-12 15:42:59.902871
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat().validate("2019-01-23")
    assert isinstance(date, datetime.date)
    assert date.year == 2019
    assert date.month == 1
    assert date.day == 23

    # Error format
    with pytest.raises(ValidationError) as e:
        DateFormat().validate("2018-01-32")
    assert e.value.code == "format"
    assert e.value.text == "Must be a valid date format."

    # Error invalid
    with pytest.raises(ValidationError) as e:
        DateFormat().validate("2018-02-31")
    assert e.value.code == "invalid"
    assert e.value.text == "Must be a real date."



# Generated at 2022-06-12 15:43:09.175977
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test case 1: valid date and time
    date_time: str = "2018-12-24T08:30:00+01:00"
    format_class: DateTimeFormat = DateTimeFormat()
    result: datetime.datetime = format_class.validate(date_time)
    expected_result: datetime.datetime = datetime.datetime(2018, 12, 24, 8, 30, 0, 0, datetime.timezone(datetime.timedelta(hours=1)))
    assert result == expected_result

    # Test case 2: invalid date and time
    date_time: str = "2018-13-24T08:30:00+01:00"
    format_class: DateTimeFormat = DateTimeFormat()
    expected_exception: Exception

# Generated at 2022-06-12 15:43:10.640222
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    value='2020-02-02'
    date=DateFormat()
    date.validate(value)
    return True

test_DateFormat_validate()


# Generated at 2022-06-12 15:43:13.366279
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("1900-01-01") == datetime.date(1900, 1, 1)
    assert DateFormat().validate("1900-01-01") == datetime.date(1900, 1, 1)


# Generated at 2022-06-12 15:43:18.390690
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    f = DateFormat()
    #test on format
    with pytest.raises(ValidationError):
        f.validate("2019/01/28")
    #test on invalid
    with pytest.raises(ValidationError):
        f.validate("2019-05-32")


# Generated at 2022-06-12 15:43:20.792266
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf=TimeFormat()
    assert tf.validate('12:12:00')==datetime.time(12, 12, 0)

# Generated at 2022-06-12 15:43:24.329218
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat().validate('00:00:30.012345')
    assert isinstance(time, datetime.time)
    assert time.minute == 0
    assert time.second == 30
    assert time.microsecond == 12345

# Generated at 2022-06-12 15:43:34.183594
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()
    obj = format.validate("2020-02-16T15:03:03.501Z")
    assert obj.year == 2020
    assert obj.month == 2
    assert obj.day == 16
    assert obj.hour == 15
    assert obj.minute == 3
    assert obj.second == 3
    assert obj.microsecond == 501000
    assert obj.tzinfo != None

    obj = format.validate("2020-02-16T15:03:03.501+08:00")
    assert obj.year == 2020
    assert obj.month == 2
    assert obj.day == 16
    assert obj.hour == 15
    assert obj.minute == 3
    assert obj.second == 3
    assert obj.microsecond == 501000
    assert obj.tzinfo != None

    obj = format.valid

# Generated at 2022-06-12 15:43:41.776984
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-01-01T00:00:00+00:00") == datetime.datetime(2020,1,1,0,0,tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-01-01") == datetime.datetime(2020,1,1,0,0,0,0)

# Generated at 2022-06-12 15:43:52.896639
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()

    obj1 = "2019-01-31T09:48Z"
    expected1 = datetime.datetime(2019, 1, 31, 9, 48, 0, tzinfo=datetime.timezone.utc)
    assert format.validate(obj1) == expected1

    obj2 = "2019-01-31T09:48:21Z"
    expected2 = datetime.datetime(2019, 1, 31, 9, 48, 21, tzinfo=datetime.timezone.utc)
    assert format.validate(obj2) == expected2

    obj3 = "2019-01-31T09:48:21.010Z"

# Generated at 2022-06-12 15:43:57.154553
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate('2020-01-01T12:00:00Z') == datetime.datetime(2020, 1, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-12 15:44:04.044035
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate("17:45:55.123")
    time_format.validate("17:45:55.123456")
    time_format.validate("17:45:55")
    time_format.validate("17:45")
    # time_format.validate("17:45:55.1234")
    # time_format.validate("17:45:55.1234567")


# Generated at 2022-06-12 15:44:06.030351
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date = DateTimeFormat()
    date.validate("2019-08-15T12:43Z")

# Generated at 2022-06-12 15:44:17.517823
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_format.validate("2019-10-23T14:46:00")
    time_format = TimeFormat()
    time_format.validate("14:46:00")
    date_format = DateFormat()
    date_format.validate("2019-10-23")
    uuid_format = UUIDFormat()
    uuid_format.validate("6ba7b810-9dad-11d1-80b4-00c04fd430c8")
    # test bad format
    try:
        date_time_format.validate("2019/10/23T14:46:00")
    except:
        pass
    try:
        time_format.validate("14:46")
    except:
        pass

# Generated at 2022-06-12 15:44:27.232774
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    from typesystem.base import ValidationError
    from typesystem.formats.datetime import DateFormat

    test_date_format = DateFormat()
    # Check example of good date format
    assert test_date_format.validate(
        "2000-12-01"
    ) == datetime.date(year=2000, month=12, day=1)

    # Check example of bad date format
    try:
        test_date_format.validate("2000-13-01")
    except ValidationError as e:
        assert e.code == "invalid"

    # Check example of bad date format
    try:
        test_date_format.validate("2000-01-32")
    except ValidationError as e:
        assert e.code == "invalid"

    # Check example of good format with just non-zero

# Generated at 2022-06-12 15:44:35.976488
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test for valid datetime input
    dt_format = DateTimeFormat()
    dt_validate_result = dt_format.validate('2015-06-04T21:36:21+07:00')
    assert dt_validate_result == datetime.datetime(2015, 6, 4, 21, 36, 21, 0, datetime.timezone(datetime.timedelta(0, 25200)))

    # Test for invalid datetime input
    try:
        dt_validate_result = dt_format.validate('2015-06-04T21:36:21')
        assert False
    except:
        assert True
        

# Generated at 2022-06-12 15:44:45.348875
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    f = DateTimeFormat()
    assert f.validate('2020-03-27T07:00:00.000Z') == datetime.datetime(2020, 3, 27, 7, 0, 0)
    assert f.validate('2020-03-27T07:00:00.000111Z') == datetime.datetime(2020, 3, 27, 7, 0, 0, 111)
    assert f.validate('2020-03-27T07:00:00.001Z') == datetime.datetime(2020, 3, 27, 7, 0, 0, 1000)
    assert f.validate('2020-03-27T07:00:00.111111Z') == datetime.datetime(2020, 3, 27, 7, 0, 0, 111111)

# Generated at 2022-06-12 15:44:47.615096
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert isinstance(DateTimeFormat().validate('2016-02-20T16:20Z'), datetime.datetime)


# Generated at 2022-06-12 15:44:58.200184
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value = DateTimeFormat()
    assert isinstance(value.validate("2020-12-10T13:50:00+00:00"), datetime.datetime)
    assert isinstance(value.validate("2020-12-10T13:50:00"), datetime.datetime)
    assert isinstance(value.validate("2020-12-10T13:50:00+03:00"), datetime.datetime)
    assert isinstance(value.validate("2020-12-10T13:50:00-03:00"), datetime.datetime)
    assert isinstance(value.validate("2020-12-10T13:50:00+03"), datetime.datetime)
    assert isinstance(value.validate("2020-12-10T13:50:00-03"), datetime.datetime)
   

# Generated at 2022-06-12 15:45:02.689168
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    try:
        datetime_format.validate("2020-11-19T16:20:34.123469+08:00")
    except ValidationError:
        assert False

# Generated at 2022-06-12 15:45:11.224704
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    '''
    Test case:
        obj = DateTimeFormat()
        value1 = "2018-10-06T13:47:09.068Z"
        print(obj.validate(value1))
        value2 = "2018-10-06T13:47:09.068+00:00"
        print(obj.validate(value2))
        value3 = "2018-10-06T13:47:09.068-07:00"
        print(obj.validate(value3))
    '''
    obj = DateTimeFormat()
    value1 = "2018-10-06T13:47:09.068Z"
    value2 = "2018-10-06T13:47:09.068+00:00"

# Generated at 2022-06-12 15:45:21.788054
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate("2021-01-01") == datetime.date(year=2021, month=1, day=1)
    assert date_format.validate("2021-01-32") == datetime.date(year=2021, month=2, day=1)
    assert date_format.validate("1989-02-29") == datetime.date(year=1989, month=2, day=28)


# Generated at 2022-06-12 15:45:25.039991
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    result = time.validate("05:34:00.123456")
    assert isinstance(result, datetime.time)

# Generated at 2022-06-12 15:45:34.774753
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Input
    value = "2017-12-13T13:13:13"
    date_time_format = DateTimeFormat()

    try:
        date_time_format.validate(value)
    except ValidationError as e:
        print("Error (%s)" % str(e))
    else:
        print("Valid")

    value = "2017-2-13T13:13:13"
    try:
        date_time_format.validate(value)
    except ValidationError as e:
        print("Error (%s)" % str(e))
    else:
        print("Valid")

    value = "2017-12-13 13:13+08:00"

# Generated at 2022-06-12 15:45:45.633068
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    fmt = DateTimeFormat()
    assert fmt.validate('2019-12-01T16:46:50Z') == datetime.datetime(2019,12,1,16,46,50,0,datetime.timezone.utc)
    assert fmt.validate('2019-12-01T16:46:50+00:00') == datetime.datetime(2019,12,1,16,46,50,0,datetime.timezone.utc)
    assert fmt.validate('2019-12-01T16:46:50+03:00') == datetime.datetime(2019,12,1,16,46,50,0,datetime.timezone(datetime.timedelta(hours=3)))

# Generated at 2022-06-12 15:45:48.108297
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    assert dateFormat.validate("2019-01-01") == datetime.date(year=2019, month=1, day=1)


# Generated at 2022-06-12 15:45:56.394479
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Datetime instance as input
    dt = datetime.datetime(2020, 3, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)
    obj = DateTimeFormat()
    assert obj.validate(dt) == dt

    # String instance as input
    dt = obj.validate("2020-03-01T12:00:00Z")
    assert dt == datetime.datetime(2020, 3, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)
    dt = obj.validate("2020-03-01T12:00:00.123456Z")
    assert dt == datetime.datetime(2020, 3, 1, 12, 0, 0, 123456, tzinfo=datetime.timezone.utc)
   

# Generated at 2022-06-12 15:46:09.138224
# Unit test for method validate of class DateTimeFormat

# Generated at 2022-06-12 15:46:19.358865
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    start_datetime = datetime.datetime(2020, 1,1)
    end_datetime = datetime.datetime(2020, 1,31)
    date_format = DateTimeFormat()
    assert date_format.validate('2020-01-01T00:00:00') == start_datetime
    assert date_format.validate('2020-01-31T00:00:00') == end_datetime
    assert date_format.validate('2020-01-31T23:59:59') == (end_datetime + datetime.timedelta(hours=23,minutes=59,seconds=59))


# Generated at 2022-06-12 15:46:20.766316
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    TimeFormat.validate('12:34.567890') 


# Generated at 2022-06-12 15:46:24.295050
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2019-06-07") == datetime.date(2019, 6, 7)  # type: ignore


# Generated at 2022-06-12 15:46:36.447808
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    time = "10:00:12"
    date = "2020-10-10"
    datetime = "2020-10-10T10:00:12"
    
    dtf = DateTimeFormat()
    # test time format
    result = dtf.validate(time)
    assert result == datetime.datetime.strptime('10:00:12', '%H:%M:%S')
    # test date format
    result = dtf.validate(date)
    assert result == datetime.datetime.strptime('2020-10-10', '%Y-%m-%d')
    # test datetime format
    result = dtf.validate(datetime)

# Generated at 2022-06-12 15:46:41.275736
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    assert time_format.validate("00:00:00") == datetime.time(0)
    assert time_format.validate("00:00:00.123456") == datetime.time(0, 0, 0, 123456)


# Generated at 2022-06-12 15:46:46.717031
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dt = DateFormat()
    assert dt.validate("2020-10-10") == datetime.date(2020, 10, 10)
    assert dt.validate("2020-10-11") == datetime.date(2020, 10, 11)

test_DateFormat_validate()


# Generated at 2022-06-12 15:46:52.052564
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    date = dateFormat.validate("2019-02-27")
    listDate = [date.year,date.month,date.day]
    assert(listDate == [2019,2,27])
    assert(dateFormat.validate("2019-02-27") == datetime.date(2019,2,27))


# Generated at 2022-06-12 15:46:57.669626
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()

    assert tf.validate("22:30:10") == datetime.time(hour=22, minute=30, second=10)
    assert tf.validate("22:30:10.3") == datetime.time(hour=22, minute=30, second=10, microsecond=300000)
    assert tf.validate("22:30") == datetime.time(hour=22, minute=30)
    assert tf.validate("10") == datetime.time(hour=10)



# Generated at 2022-06-12 15:47:03.393397
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time1 = '20:00:01.000001'
    time2 = '20:00:01.123456'
    time3 = '20:00:01'
    time4 = '20:00:01.12345'
    time5 = '20:00:01.1234567'
    time6 = '20:00:01.1234567890'
    time7 = '20:00:01.1234567890Z'

    assert TimeFormat().validate(time1).isoformat() == time1
    assert TimeFormat().validate(time2).isoformat() == time2
    assert TimeFormat().validate(time3).isoformat() == time3
    assert TimeFormat().validate(time4).isoformat() == time4
    assert TimeFormat().validate(time5).isoformat() == time5
   

# Generated at 2022-06-12 15:47:16.035096
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    input_values = ['11:00', '11:00:00', '11:00:00.000000', '11:00:00.000001',
                    '11:00:00.999999', '11:00:00.123456', '23:59:59.999999',
                    '00:00:00.000000']
    expected_results = ['11:00:00', '11:00:00', '11:00:00', '11:00:00.000001',
                        '11:00:00.999999', '11:00:00.123456', '23:59:59.999999',
                        '00:00:00']
    for i, in_val in enumerate(input_values):
        obj = TimeFormat()
        out_val = str(obj.validate(in_val))
       

# Generated at 2022-06-12 15:47:18.873652
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    with pytest.raises(NotImplementedError):
        dateformat_obj = DateFormat()
        dateformat_obj.validate('2019-06-01')


# Generated at 2022-06-12 15:47:27.474088
# Unit test for method validate of class DateTimeFormat

# Generated at 2022-06-12 15:47:36.545260
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    import datetime
    res = DateTimeFormat().validate('2000-01-01T00:00:00-01:00')
    expect(res.isoformat()).to(equal('2000-01-01T01:00:00'))
    res = DateTimeFormat().validate('2019-07-24T17:00:00')
    expect(res.isoformat()).to(equal('2019-07-24T17:00:00'))
    res = DateTimeFormat().validate('2019-07-24T17:00:00Z')
    expect(res.isoformat()).to(equal('2019-07-24T17:00:00'))
    # expect(DateTimeFormat().validate('2019-07-24T17:00:00')).to(equal(datetime.datetime(2019, 7, 24

# Generated at 2022-06-12 15:47:54.879524
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    values = [
        ("2014-01-01T01:23", datetime(2014, 1, 1, 1, 23)),
        ("2014-01-01T01:23:45", datetime(2014, 1, 1, 1, 23, 45)),
        ("2014-01-01T01:23:45.678901", datetime(2014, 1, 1, 1, 23, 45, 678901)),
        ("2014-01-01T01:23:45Z", datetime(2014, 1, 1, 1, 23, 45, tzinfo=pytz.UTC)),
        ("2014-01-01T01:23:45+00:00", datetime(2014, 1, 1, 1, 23, 45, tzinfo=pytz.UTC)),
    ]


# Generated at 2022-06-12 15:48:03.025057
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    from typesystem.base import ValidationError
    from typesystem.formats import DateFormat
    # validation date format
    date = DateFormat()
    assert date.validate('2001-07-15') == datetime.date(2001,7,15)
    # value error
    try:
        date.validate('2001-40-40')
    except ValidationError as e:
        print(e)
        assert e.code == 'invalid'

    # format error
    try:
        date.validate('2001/07/15')
    except ValidationError as e:
        print(e)
        assert e.code == 'format'


# Generated at 2022-06-12 15:48:14.196877
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():

    # Test case 1: Date is valid
    dateTime = datetime.datetime.now().date()
    dateTimeStr = dateTime.isoformat()
    dateTimeFormat = DateFormat()
    assert dateTimeFormat.is_native_type(dateTime)
    validDate = dateTimeFormat.validate(dateTimeStr)
    assert validDate == dateTime
    assert dateTimeFormat.is_native_type(validDate)

    # Test case 2: Date is not valid
    invalidDateStr = "2019-18-17"
    assert invalidDateStr != dateTimeStr
    try:
        dateTimeFormat.validate(invalidDateStr)
    except ValidationError as e:
        assert e.code == "format"



# Generated at 2022-06-12 15:48:16.147119
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    with pytest.raises(NotImplementedError):
        assert df.validate(1,1)


# Generated at 2022-06-12 15:48:20.164687
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    value = '2020-01-01'
    assert isinstance(value, str)
    try:
        value = DateFormat().validate(value)
        # value is either a datetime.date or a ValidationError
        assert isinstance(value, datetime.date)
    except ValidationError:
        assert False
    return



# Generated at 2022-06-12 15:48:24.171478
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    expected = datetime.time(23, 59, 59, 999999)
    assert expected == tf.validate('23:59:59.999999')



# Generated at 2022-06-12 15:48:33.156347
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()
    assert format.is_native_type(datetime.date(2019, 10, 25)) is True
    assert format.is_native_type(datetime.datetime(2019, 10, 25)) is False
    assert format.is_native_type(datetime.time(0, 1, 2)) is False
    try:
        format.validate("hello")
        assert False is True
    except ValidationError as e:
        assert str(e) == "Must be a valid date format."
        assert e.code == "format"
    try:
        format.validate('2019-13-99')
        assert False is True
    except ValidationError as e:
        assert str(e) == "Must be a real date."
        assert e.code == "invalid"

# Generated at 2022-06-12 15:48:36.713120
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    start = datetime.date(2020, 6, 2)
    format = "YYYY-MM-DD"
    str_start = start.strftime(format)
    test_case = DateFormat()
    assert(test_case.validate(str_start) == start)


# Generated at 2022-06-12 15:48:43.844593
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # On crée l'object DateTimeFormat
    date_format = DateTimeFormat()

    # Test passes si la valeur rentrée est en bon format
    assert date_format.validate('2019-05-15T16:00:00.000000')
    # Test passes si le format n'est pas bon
    with pytest.raises(ValidationError):
        assert date_format.validate('2019-05-15T16:00:00.000000.000000')
    # Test passes si le format n'est pas bon
    with pytest.raises(ValidationError):
        assert date_format.validate('2019-05-15 16:00:00.000000')
    # Test passes si le format n'est pas bon

# Generated at 2022-06-12 15:48:56.610038
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    class TestDateFormat(DateFormat):
        errors = {
            "format": "Must be a valid date format.",
            "invalid": "Must be a real date.",
        }
    df = TestDateFormat()
    try:
        result = df.validate("1992-10-01")
        assert (result == datetime.date(1992, 10, 1))
    except ValidationError:
        assert False
    try:
        result = df.validate("1992-10-01")
        assert (result == datetime.date(1992, 10, 1))
    except ValidationError:
        assert False
    try:
        result = df.validate("1992-10-31")
        assert False
    except ValidationError:
        assert (df.validation_error("invalid").code == "invalid")

# Generated at 2022-06-12 15:49:07.842561
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format_test = DateFormat()
    assert date_format_test.validate('2001-01-01')== datetime.date(2001,1,1)
