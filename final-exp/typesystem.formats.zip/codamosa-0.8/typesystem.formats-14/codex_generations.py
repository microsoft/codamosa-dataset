

# Generated at 2022-06-12 15:39:17.510872
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    value_date = "2020-12-28"
    obj = datetime.datetime.strptime(value_date, "%Y-%m-%d")
    result = DateFormat().serialize(obj)
    assert value_date == result


# Generated at 2022-06-12 15:39:18.796364
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(None) == None


# Generated at 2022-06-12 15:39:24.687297
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = datetime.datetime(
        year=2009, month=11, day=26, hour=22, minute=11, second=21, microsecond=585966, tzinfo=datetime.timezone.utc
    )
    assert DateTimeFormat().serialize(obj) == "2009-11-26T22:11:21.585966Z"

# Generated at 2022-06-12 15:39:28.196955
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    datef = DateFormat()
    # Test for invalid data
    with pytest.raises(ValidationError):
        datef.validate("")
    # Test for valid data
    assert datef.validate("2017-03-22") == datetime.date(2017, 3, 22)


# Generated at 2022-06-12 15:39:29.461524
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    d1 = DateFormat()
    assert d1.serialize(None) == None


# Generated at 2022-06-12 15:39:39.135556
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert str(tf.validate("12:02:59.10")) == "12:02:59.100000"
    assert str(tf.validate("12:02:59.1023")) == "12:02:59.102300"
    assert str(tf.validate("12:02:59.102345")) == "12:02:59.102345"
    assert str(tf.validate("12:02:59.1023456")) == "12:02:59.102345"



# Generated at 2022-06-12 15:39:43.551454
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():

    # This method should return obj.isoformat() when obj is not null
    time_format = TimeFormat()
    obj = datetime.time()
    assert time_format.serialize(obj) == obj.isoformat()

    # This method should return None when obj is null
    obj = None
    assert time_format.serialize(obj) == None



# Generated at 2022-06-12 15:39:45.948228
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(1997,11,4)) == "1997-11-04"
    assert DateFormat().serialize(None) == None



# Generated at 2022-06-12 15:39:52.787320
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    format = DateTimeFormat()
    datetime_with_no_tz = datetime.datetime(year=2019, month=5, day=20, tzinfo=None).isoformat()
    datetime_with_tz = datetime.datetime(year=2019, month=5, day=20, tzinfo=datetime.timezone.utc).isoformat()

    assert format.serialize(datetime_with_no_tz) is None
    assert format.serialize(datetime_with_tz) == "2019-05-20T00:00:00+00:00"

# Generated at 2022-06-12 15:40:01.518512
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    utc_format = DateTimeFormat().serialize(datetime.datetime(2020, 7, 22, 22, 0, 0, tzinfo=datetime.timezone.utc))
    assert utc_format == "2020-07-22T22:00:00Z"
    non_utc_format = DateTimeFormat().serialize(datetime.datetime(2020, 7, 22, 22, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=5, minutes=30))))
    assert non_utc_format == "2020-07-22T22:00:00+05:30"

# Generated at 2022-06-12 15:40:16.797851
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(None) == None
    assert DateTimeFormat().serialize(datetime.datetime(1900, 1, 1)) == "1900-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(1900, 1, 1, 3)) == "1900-01-01T03:00:00"
    assert DateTimeFormat().serialize(datetime.datetime(1900, 1, 1, 3, 10)) == "1900-01-01T03:10:00"
    assert DateTimeFormat().serialize(datetime.datetime(1900, 1, 1, 3, 10, 20)) == "1900-01-01T03:10:20"
    assert DateTimeFormat().serialize(datetime.datetime(1900, 1, 1, 3, 10, 20, 30))

# Generated at 2022-06-12 15:40:24.312249
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(None) == None
    assert DateTimeFormat().serialize(datetime.datetime.fromisoformat("2020-01-01T00:00")) == "2020-01-01T00:00:00"
    assert DateTimeFormat().serialize(datetime.datetime.fromisoformat("2020-01-01T00:00:00.000000")) == "2020-01-01T00:00:00.000000"
    assert DateTimeFormat().serialize(datetime.datetime.fromisoformat("2020-01-01T00:00Z")) == "2020-01-01T00:00:00Z"

# Generated at 2022-06-12 15:40:33.244488
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    validate = DateTimeFormat(
    ).validate
    assert validate('2020-09-30T16:46:08') == datetime.datetime(year=2020, month=9, day=30, hour=16, minute=46, second=8)
    assert validate('2020-09-30T16:46:08Z') == datetime.datetime(year=2020, month=9, day=30, hour=16, minute=46, second=8, tzinfo=datetime.timezone.utc)
    assert validate('2020-09-30T16:46:08-07:00') == datetime.datetime(year=2020, month=9, day=30, hour=16, minute=46, second=8, tzinfo=datetime.timezone(datetime.timedelta(hours=-7)))
    assert validate

# Generated at 2022-06-12 15:40:35.623267
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    print("DateFormat")
    print("-----------")
    d = DateFormat()
    val1 = d.validate("2020-01-02")
    assert val1 == datetime.date(2020, 1, 2)


# Generated at 2022-06-12 15:40:39.131920
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date = datetime.datetime(2020, 3, 14, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(date) == '2020-03-14T00:00:00Z'

# Generated at 2022-06-12 15:40:42.268232
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    test_date_time = datetime.datetime(2019, 2, 12, 23, 37, 2, 999995, tzinfo=None)
    result = DateTimeFormat().serialize(test_date_time)
    assert result == "2019-02-12T23:37:02.999995"



# Generated at 2022-06-12 15:40:44.862937
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    from datetime import date
    assert df.serialize(date(2020, 10, 10)) == "2020-10-10"


# Generated at 2022-06-12 15:40:46.619536
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 1, 1)) == "2019-01-01T00:00:00"

# Generated at 2022-06-12 15:40:56.932510
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2020, 1, 1, 0, 40, 1, tzinfo=datetime.timezone.utc)
    assert dt.isoformat() == '2020-01-01T00:40:01+00:00'

    obj = DateTimeFormat()
    assert obj.serialize(dt) == '2020-01-01T00:40:01Z'

    dt = datetime.datetime(2020, 1, 1, 0, 40, 1, tzinfo=datetime.timezone(datetime.timedelta(hours=8)))
    assert dt.isoformat() == '2020-01-01T00:40:01+08:00'

    assert obj.serialize(dt) == '2020-01-01T00:40:01+08:00'

# Generated at 2022-06-12 15:41:01.385027
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uf = UUIDFormat()
    uf.validate("35f9b6f4-d2b2-3ccb-962f-845d7c05e29c")


# Generated at 2022-06-12 15:41:09.603396
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
	df = DateFormat()
	assert df.validate("2018-12-05") == datetime.date(2018, 12, 5)


# Generated at 2022-06-12 15:41:17.336085
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # TestCase 1
    obj = DateTimeFormat()
    value = "2020-07-07T18:19:21.00000Z"
    assert obj.is_native_type(obj.validate(value)) == True
    # TestCase 2
    obj = DateTimeFormat()
    value = "2020-07-07T18:19:21.00000Z"
    assert obj.validate(value) == datetime.datetime(2020, 7, 7, 18, 19, 21, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-12 15:41:19.830574
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate('2020-07-17') == datetime.date(2020, 7, 17)


# Generated at 2022-06-12 15:41:29.863170
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate('2024-01-01T00:00:00') == datetime.datetime(2024,1,1,0,0,0)
    assert dtf.validate('2024-01-01T00:00:00+01:00') == datetime.datetime(2024,1,1,0,0,0,tzinfo=datetime.timezone(datetime.timedelta(hours=1)))
    with pytest.raises(ValidationError) as excinfo: dtf.validate('2024-01-01 00:00:00')
    with pytest.raises(ValidationError) as excinfo: dtf.validate('2024-01-01T00:00:00Z')

# Generated at 2022-06-12 15:41:36.802797
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test for case Z
    format = DateTimeFormat()
    out = format.validate("2011-11-11T00:00:00Z")
    assert out == datetime.datetime(2011, 11, 11, tzinfo=datetime.timezone.utc)

    # Test for case +00:00
    out = format.validate("2011-11-11T00:00:00+00:00")
    assert out == datetime.datetime(2011, 11, 11, tzinfo=datetime.timezone.utc)

    # Test for case +05:00
    out = format.validate("2011-11-11T00:00:00+05:00")

# Generated at 2022-06-12 15:41:47.635825
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Line 2
    assert DateTimeFormat().validate("2019-09-16T08:00:00+08:00") == datetime.datetime(
        2019, 9, 16, 8, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=8))
    )
    # Line 3
    assert DateTimeFormat().validate("2019-09-16T00:00:00") == datetime.datetime(
        2019, 9, 16, tzinfo=datetime.timezone.utc
    )
    # Line 4
    assert DateTimeFormat().validate("2019-09-16T08:00:00") == datetime.datetime(
        2019, 9, 16, 8, 0
    )
    # Line 18
    with pytest.raises(ValueError):
        DateTime

# Generated at 2022-06-12 15:41:54.808413
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt_format = DateTimeFormat()

    # Test valid datetime format
    value = dt_format.validate("2014-02-03T02:40:01.111812+00:00")
    assert value.year == 2014
    assert value.month == 2
    assert value.day == 3
    assert value.hour == 2
    assert value.minute == 40
    assert value.second == 1
    assert value.microsecond == 111812
    assert value.tzinfo.utcoffset(value).seconds == 0

    value = dt_format.validate("2014-02-03T02:40:01+00:00")
    assert value.year == 2014
    assert value.month == 2
    assert value.day == 3
    assert value.hour == 2
    assert value.minute == 40
    assert value

# Generated at 2022-06-12 15:42:01.092738
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime.strptime("2020-02-14T11:00:00+00:00", "%Y-%m-%dT%H:%M:%S%z")
    assert dt.isoformat() == "2020-02-14T11:00:00+00:00"
    format_ = DateTimeFormat()
    assert format_.serialize(dt) == "2020-02-14T11:00:00Z"

# Generated at 2022-06-12 15:42:02.280845
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    pass


# Generated at 2022-06-12 15:42:06.271477
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    from datetime import datetime
    from .format import DateTimeFormat
    obj = datetime(2020, 11, 23, 22, 43, 25, 786332)
    assert DateTimeFormat().serialize(obj) == '2020-11-23T22:43:25.786332'

# Generated at 2022-06-12 15:42:11.533611
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Test for None
    test = DateFormat()
    assert test.serialize(None) is None
    # Test for datetime.date
    date = datetime.date(2018, 3, 18)
    assert test.serialize(date) == "2018-03-18"


# Generated at 2022-06-12 15:42:14.931932
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert df.serialize(datetime.datetime.today()) == datetime.datetime.today().date().isoformat()

# Generated at 2022-06-12 15:42:17.452936
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    dt = datetime.datetime(2018, 12, 25, 0, 0, 0, 0)
    assert DateTimeFormat().serialize(dt) == "2018-12-25T00:00:00"

# Generated at 2022-06-12 15:42:21.018309
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = DateFormat()
    try:
        date.validate("2000-1-1")
        assert False
    except ValidationError as e:
        assert e.code == "invalid"



# Generated at 2022-06-12 15:42:24.011740
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate('2018-02-01T19:30Z') == datetime.datetime(2018, 2, 1, 19, 30, 0, 0, datetime.timezone.utc)


# Generated at 2022-06-12 15:42:26.052756
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    dt = DateFormat()
    assert dt.serialize(datetime.date(2020, 1, 1)) == '2020-01-01'


# Generated at 2022-06-12 15:42:32.911755
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    obj = DateTimeFormat()
    assert obj.validate(value="2020-02-29T00:00:00Z") == datetime.datetime(
        2020, 2, 29, 0, 0, 0, tzinfo=datetime.timezone.utc
    )
    assert obj.validate(value="2020-02-29T00:00:00") == datetime.datetime(2020, 2, 29, 0, 0, 0)

# Generated at 2022-06-12 15:42:37.525042
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # Given
    date_format = DateFormat()
    # When
    result = date_format.serialize(
        datetime.date(year=2020, month=9, day=17)
    )
    # Then
    assert result == '2020-09-17'


# Generated at 2022-06-12 15:42:43.452916
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()
    assert format.validate('2019-10-25') == datetime.date(2019, 10, 25)
    try:
        assert format.validate('2019-10-35')
    except ValueError:
        assert ValueError
    try:
        assert format.validate('2019-13-25')
    except ValueError:
        assert ValueError
    try:
        assert format.validate('2019-10-25-15:33:44')
    except ValueError:
        assert ValueError

# Generated at 2022-06-12 15:42:55.320982
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2017-10-12T13:14:15.000123Z") == datetime.datetime(
        2017, 10, 12, 13, 14, 15, 123, tzinfo=datetime.timezone.utc
    )
    assert dtf.validate("2017-10-12T13:14:15.000123+00:00") == datetime.datetime(
        2017, 10, 12, 13, 14, 15, 123, tzinfo=datetime.timezone.utc
    )

# Generated at 2022-06-12 15:43:00.651467
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    datetime = datetime.datetime(2018, 1, 1, 12, 12, 12)
    datetime_Z = DateTimeFormat().serialize(datetime)
    assert datetime_Z == "2018-01-01T12:12:12Z"


# Generated at 2022-06-12 15:43:05.278405
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    df = DateFormat()
    assert df.serialize(datetime.date(2019, 3, 1)) == '2019-03-01'
    assert df.serialize(datetime.date(2990, 5, 9)) == '2990-05-09'
    assert df.serialize(datetime.date(2, 11, 4)) == '0002-11-04'
    assert df.serialize(None) == None


# Generated at 2022-06-12 15:43:10.740218
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    # obj is datetime.date
    date = datetime.date(year=2020, month=2, day=1)
    date_string = "2020-02-01"
    df = DateFormat()
    assert df.serialize(date) == date_string
    # obj is None
    assert df.serialize(None) == None



# Generated at 2022-06-12 15:43:17.709678
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    #Case1:input= None
    assert not DateTimeFormat().serialize(None)
    #Case2:input = datetime.datetime(2017, 1, 27, 8, 23, 00, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(datetime.datetime(2017, 1, 27, 8, 23, 00, tzinfo=datetime.timezone.utc)) == '2017-01-27T08:23:00Z'
    #Case3:input = '2017-01-27T08:23:00Z'
    assert DateTimeFormat().serialize('2017-01-27T08:23:00Z') == '2017-01-27T08:23:00Z'
    #Case4:input = datetime.datetime.today()

# Generated at 2022-06-12 15:43:24.245513
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    my_dict = {
        "001": ["2020-02-02"],
        "002": ["2099-12-31"],
        "003": ["1090-01-02"],
        "004": ["6553-07-05"],
        "005": ["1011-09-01"],
        "006": ["2020-2-2"],
        "007": ["2020-02"]
    }

    for test_code, test_case in my_dict.items():
        try:
            result = DateFormat().validate(test_case[0])
        except Exception as e:
            result = e

        verify = result == None

        print("Test case " + str(test_code) + " " + str(verify) + " " + str(type(result)))



# Generated at 2022-06-12 15:43:27.618360
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    """Test of method DateFormate.validate"""
    Date = DateFormat()
    assert Date.validate('2017-04-01') == datetime.date(2017,4,1)


# Generated at 2022-06-12 15:43:30.416625
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date = datetime.datetime(2020, 2, 1, 18, 10)
    assert DateTimeFormat().serialize(date) == "2020-02-01T18:10:00"


# Generated at 2022-06-12 15:43:31.943764
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()
    assert format.validate("2020-10-10") == datetime.datetime(2020,10,10)


# Generated at 2022-06-12 15:43:33.634196
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    assert DateFormat().serialize(datetime.date(2020, 1, 2)) == "2020-01-02"
    assert DateFormat().serialize(None) is None


# Generated at 2022-06-12 15:43:38.321278
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2017, 10, 29, 11, 48, 58, tzinfo=datetime.timezone.utc)) == '2017-10-29T11:48:58+00:00'

# Generated at 2022-06-12 15:43:54.679604
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate('13:00') == datetime.time(13, 0)
    assert tf.validate('13:00:00') == datetime.time(13, 0)
    assert tf.validate('13:00:00.0') == datetime.time(13, 0)
    assert tf.validate('13:00:00.1') == datetime.time(13, 0, 0, 100000)
    assert tf.validate('13:00:00.1234567') == datetime.time(13, 0, 0, 123456)

    # test error-cases
    with pytest.raises(ValidationError) as ve:
        tf.validate('13:00:-00.123')
    assert 'Must be a real time' in str(ve.value)

   

# Generated at 2022-06-12 15:44:01.810550
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Init data
    date_time_format = DateTimeFormat()
    date_time = datetime.datetime(2020, 2, 29, 22, 52, 19, 746696)
    date_time_string = date_time.isoformat()
    
    # Execute method serialize
    result = date_time_format.serialize(date_time)

    # Then result is expected value
    assert result == date_time_string

# Generated at 2022-06-12 15:44:12.326575
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    DTF = DateTimeFormat()

    time_obj = datetime.datetime.now()
    time_obj = time_obj.replace(tzinfo=datetime.timezone.utc)

    time_str = DTF.serialize(time_obj)
    assert time_str == "2020-06-18T12:15:37.133000+00:00"

    time_obj = time_obj.astimezone(datetime.timezone(datetime.timedelta(hours=3)))
    time_str = DTF.serialize(time_obj)
    assert time_str == "2020-06-18T12:15:37.133000+03:00"

# Generated at 2022-06-12 15:44:23.122713
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    f = DateTimeFormat()
    assert f.validate('2018-01-01T12:00') == datetime.datetime(2018, 1, 1, 12, 0)
    assert f.validate('2018-01-01T12:00:00.10') == datetime.datetime(2018, 1, 1, 12, 0, 0, 100000)
    assert f.validate('2018-01-01T12:00Z') == datetime.datetime(2018, 1, 1, 12, 0, tzinfo=datetime.timezone.utc)
    assert f.validate('2018-01-01T12:00+02') == datetime.datetime(2018, 1, 1, 12, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=+2)))

# Generated at 2022-06-12 15:44:34.017443
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test with UTC
    df = DateTimeFormat()
    assert df.validate('2018-06-07T10:00:00Z') == datetime.datetime(2018, 6, 7, 10, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert df.validate('2018-06-07T10:00:00.000000Z') == datetime.datetime(2018, 6, 7, 10, 0, 0, 0, tzinfo=datetime.timezone.utc)
    assert df.validate('2018-06-07T10:00:00.1Z') == datetime.datetime(2018, 6, 7, 10, 0, 0, 100000, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-12 15:44:43.759285
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    str_ = "2017-11-13 18:46:56.786568+09:00"
    dt = datetime.datetime.strptime(str_, "%Y-%m-%d %H:%M:%S.%f%z")
    res = DateTimeFormat().serialize(dt)
    assert res == "2017-11-13T18:46:56.786568+09:00"

    str_ = "2017-11-13 18:46:56.786568+00:00"
    dt = datetime.datetime.strptime(str_, "%Y-%m-%d %H:%M:%S.%f%z")
    res = DateTimeFormat().serialize(dt)

# Generated at 2022-06-12 15:44:47.434754
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    a = datetime.datetime(2019,2,2,12,12,12)
    result = DateTimeFormat().serialize(a)
    assert result == '2019-02-02T12:12:12'
    return 'Test Passed'


# Generated at 2022-06-12 15:44:58.161856
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # valid cases
    value = "2020-09-18T08:18:17"
    date_obj = DateTimeFormat().validate(value)
    assert str(date_obj) == value

    value = "2020-09-18T08:18:17Z"
    date_obj = DateTimeFormat().validate(value)
    assert str(date_obj) == value

    value = "2020-09-18T08:18:17+08:00"
    date_obj = DateTimeFormat().validate(value)
    assert str(date_obj) == value

    # invalid cases
    with pytest.raises(ValidationError):
        DateTimeFormat().validate("2020-09-18")


# Generated at 2022-06-12 15:45:04.344939
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_format = DateTimeFormat()

    # Valid date
    assert date_format.validate("2020-07-21T05:12:36+08:00") == datetime.datetime(2020, 7, 21, 5, 12, 36, tzinfo=datetime.timezone(datetime.timedelta(hours=8)))

    # Invalid date
    try:
        date_format.validate("2020-07-21T05:12:36")
    except ValidationError as e:
        assert e.text == "Must be a real datetime."
        assert e.code == "invalid"

    # Invalid date format
    try:
        date_format.validate("2020-07-21T")
    except ValidationError as e:
        assert e.text == "Must be a valid datetime format."

# Generated at 2022-06-12 15:45:11.968755
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():

    # Case test 1
    obj = DateTimeFormat()
    assert obj.validate("2019-06-01T00:01:02.34Z") == datetime.datetime(
        2019, 6, 1, 0, 1, 2, 340000, tzinfo=datetime.timezone.utc
    )

    # Case test 2
    obj = DateTimeFormat()
    assert obj.validate("2019-06-01T00:01:02Z") == datetime.datetime(
        2019, 6, 1, 0, 1, 2, tzinfo=datetime.timezone.utc
    )

    # Case test 3
    obj = DateTimeFormat()

# Generated at 2022-06-12 15:45:27.703680
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    from typesystem.core.time import TimeFormat
    from datetime import time
    
    assert TimeFormat().validate('12:00') == time(12)
    assert TimeFormat().validate('12:00:23') == time(12, 0, 23)
    assert TimeFormat().validate('12:00:23.12') == time(12, 0, 23, 120000)
    assert TimeFormat().validate('12:00:23.1234') == time(12, 0, 23, 123400)
    assert TimeFormat().validate('12:00:23.123456') == time(12, 0, 23, 123456)
    assert TimeFormat().validate('12:00:23.1234567') == time(12, 0, 23, 123456)

# Generated at 2022-06-12 15:45:32.831496
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    date_object = datetime.datetime.strptime('2020-01-01T01:00:00Z','%Y-%m-%dT%H:%M:%SZ')
    date_format = DateTimeFormat()
    date_string = date_format.serialize(date_object)
    assert date_string == '2020-01-01T01:00:00Z'

# Generated at 2022-06-12 15:45:34.018101
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    obj = DateFormat()
    print(obj.validate("1988-05-06"))
    

# Generated at 2022-06-12 15:45:37.143947
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    print(df.validate("2011-11-11"))
# Output: 2011-11-11


# Generated at 2022-06-12 15:45:38.556978
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    # regex match return None, then raise an error
    with pytest.raises(ValidationError):
        time.validate("2020-09-30")

# Generated at 2022-06-12 15:45:46.251942
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    fmt = DateTimeFormat()
    dt = fmt.validate('2018-04-12T11:06:42Z')
    dt = fmt.validate('2018-04-12T11:06:42+07:00')
    dt = fmt.validate('2018-04-12T11:06:42.928000Z')
    dt = fmt.validate('2018-04-12T11:06:42.928000')
    dt = fmt.validate('2018-04-12T11:06:42.928+07:00')

# Generated at 2022-06-12 15:45:50.201820
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    test = DateTimeFormat()
    expected ="2017-05-03T03:56:15.1337Z"
    dt = datetime.datetime(2017, 5, 3, 3, 56, 15, 133700, tzinfo=datetime.timezone.utc)
    actual = test.serialize(dt)
    assert expected == actual

if __name__ == "__main__":
    test_DateTimeFormat_serialize()

# Generated at 2022-06-12 15:45:53.732553
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(
        datetime.datetime(year=2018, month=1, day=1, hour=0, minute=0, second=0, tzinfo=datetime.timezone.utc)
    ) == "2018-01-01T00:00:00Z"

# Generated at 2022-06-12 15:45:57.043164
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    test_time_value = "12:30"
    value = time.validate(test_time_value)
    assert isinstance(value, datetime.time)
    assert value == datetime.time(12, 30)
    assert value.isoformat() == test_time_value


# Generated at 2022-06-12 15:46:01.336191
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = "00:00:00.123400"
    assert TimeFormat().validate(time) == datetime.time(0, 0, 0, 123400)

# Generated at 2022-06-12 15:46:09.848376
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate("12:30:59") == datetime.time(
        12, 30, 59
    )

# Generated at 2022-06-12 15:46:21.508140
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert (DateTimeFormat().serialize(datetime.datetime(2018, 12, 12, 3, 36, 7, 247016)) == "2018-12-12T03:36:07.247016+00:00")
    assert (DateTimeFormat().serialize(datetime.datetime(2018, 12, 12, 3, 36, 7)) == "2018-12-12T03:36:07+00:00")
    assert (DateTimeFormat().serialize(datetime.datetime(2018, 12, 12, 3, 36)) == "2018-12-12T03:36:00+00:00")
    assert (DateTimeFormat().serialize(datetime.datetime(2018, 12, 12, 3)) == "2018-12-12T03:00:00+00:00")

# Generated at 2022-06-12 15:46:33.293617
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    validation_error_format = "Must be a valid datetime format."
    validation_error_invalid = "Must be a real datetime."
    error_format_expected = ValidationError(text=validation_error_format, code="format")
    error_invalid_expected = ValidationError(text=validation_error_invalid, code="invalid")
    datetime_valid = "2020-02-02T04:04:04Z"
    datetime_valid_without_microseconds = "2020-02-02T04:04:04"
    datetime_valid_with_microseconds = "2020-02-02T04:04:04.123456"
    datetime_valid_with_local_timezone = "2020-02-02T04:04:04.123456+01:00"
    datetime_

# Generated at 2022-06-12 15:46:36.953644
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime.utcnow()) is not None
    assert DateTimeFormat().serialize(datetime.datetime.now()) is not None
    assert DateTimeFormat().serialize(None) is None

# Generated at 2022-06-12 15:46:40.537087
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2019, 11, 6, 17, 16)) == '2019-11-06T17:16:00'

# Generated at 2022-06-12 15:46:47.107833
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    test_case = "2020-04-15T19:36:18.341355+03:00"
    assert date_time_format.validate(test_case) == datetime.datetime.strptime(test_case, '%Y-%m-%dT%H:%M:%S.%f%z')

# Generated at 2022-06-12 15:46:50.888244
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    test = datetime.datetime(2019, 10, 5, 15, 23, 47)
    df = DateTimeFormat()
    assert df.serialize(test) == "2019-10-05T15:23:47"

# Generated at 2022-06-12 15:46:58.851147
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat.serialize(datetime.datetime(2020, 10, 20, 10, 10)) == "2020-10-20T10:10:00"
    assert DateTimeFormat.serialize(datetime.datetime(2020, 10, 20, 10, 10,2,112358)) == "2020-10-20T10:10:02.112358"
    assert DateTimeFormat.serialize(datetime.datetime(2020, 10, 20, 10, 10,2,112358,tzinfo=datetime.timezone(datetime.timedelta(hours=6)))) == "2020-10-20T16:10:02.112358+06:00"

# Generated at 2022-06-12 15:47:03.367302
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    assert t.validate("00:42:42") == datetime.time(0, 42, 42)
    assert t.validate("23:57:59.789") == datetime.time(23, 57, 59, 789000)



# Generated at 2022-06-12 15:47:06.859361
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    assert t.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-12 15:47:22.400840
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormat = TimeFormat()
    time_string = '12:25'
    time_obj = timeFormat.validate(time_string)
    assert time_obj is not None

# Generated at 2022-06-12 15:47:25.932516
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    value = dtf.validate("2019-12-01T05:34:09.99Z")
    # print(value)
    assert value == datetime.datetime(2019, 12, 1, 5, 34, 9, 99000)



# Generated at 2022-06-12 15:47:29.138908
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime.now()) is not None
    assert DateTimeFormat().serialize(None) is None

# Generated at 2022-06-12 15:47:31.803687
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2020-12-28")
    assert date == datetime.datetime(year=2020, month=12, day=28)


# Generated at 2022-06-12 15:47:35.008278
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_time = "2019-09-06T17:20:00"
    data_time = datetime.datetime(2019, 9, 6, 17, 20, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate(test_time) == data_time


# Generated at 2022-06-12 15:47:41.866362
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Test for correct value of parameter value.
    # TimeFormat class must return datetime.time object.
    f = TimeFormat()
    assert isinstance(f.validate("23:59:59"), datetime.time)
    # Test for incorrect value of parameter value.
    # TimeFormat class must return ValidationError.
    with pytest.raises(ValidationError):
        f.validate("fail")


# Generated at 2022-06-12 15:47:54.185089
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateFormat().serialize(datetime.date(year=2018, month=12, day=13)) == '2018-12-13'
    assert TimeFormat().serialize(datetime.time(hour=14, minute=22)) == '14:22'
    assert DateTimeFormat().serialize(datetime.datetime(year=2018, month=12, day=13, hour=14, minute=22)) == '2018-12-13T14:22:00'
    assert DateTimeFormat().serialize(datetime.datetime(year=2018, month=12, day=13, hour=14, minute=22, second=33)) == '2018-12-13T14:22:33'
    assert UUIDFormat().serialize(uuid.UUID(int=0)) == '00000000-0000-0000-0000-000000000000'



# Generated at 2022-06-12 15:48:03.583105
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2020-04-27T23:56:46.332482") == datetime.datetime(2020, 4, 27, 23, 56, 46, 332482)
    assert DateTimeFormat().validate("2020-04-27T23:56:46.332482Z") == datetime.datetime(2020, 4, 27, 23, 56, 46, 332482, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate("2020-04-27T23:56:46.332482+00:00") == datetime.datetime(2020, 4, 27, 23, 56, 46, 332482, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-12 15:48:11.632659
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date1 = DateFormat()
    date2 = date1.validate("2019-05-01")
    assert isinstance(date2, datetime.date)
    assert date2.year == 2019
    assert date2.month == 5
    assert date2.day == 1

    try:
        date1.validate("2019-05-01T00-00-00")
        assert False, "Should raise Error"
    except:
        assert True, "Should raise Error"


# Generated at 2022-06-12 15:48:20.365033
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020,3,18,12,15,36, tzinfo=datetime.timezone.utc)) == '2020-03-18T12:15:36+00:00'
    assert DateTimeFormat().serialize(datetime.datetime(2020,3,18,12,15,36)) == '2020-03-18T12:15:36'
    assert DateTimeFormat().serialize(datetime.datetime(2020,3,18,12,15,36,tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == '2020-03-18T12:15:36+01:00'

# Generated at 2022-06-12 15:48:40.606826
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    from typesystem.base import String
    from typesystem.fields import Field

    assert String(format=TimeFormat()).validate("12:00:00") == datetime.time(12)
    assert String(format=TimeFormat()).validate("12:30:00") == datetime.time(12, 30)
    assert String(format=TimeFormat()).validate("12:30:59") == datetime.time(12, 30, 59)
    assert String(format=TimeFormat()).validate("12:30:59.123456") == datetime.time(12, 30, 59, 123456)
    assert String(format=TimeFormat()).validate("12:30:59.123") == datetime.time(12, 30, 59, 123000)

# Generated at 2022-06-12 15:48:47.201243
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    time_str = '2020-05-14 14:39:28+03:00'
    dt_format = DateTimeFormat()
    dt = dt_format.validate(time_str)
    assert dt == datetime.datetime(2020, 5, 14, 14, 39, 28, tzinfo=datetime.timezone(datetime.timedelta(0, 10800)))


# Generated at 2022-06-12 15:48:57.168508
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Test for valid value
    valid_time_value = "12:23:45.123456"
    valid_time_format = TimeFormat()
    assert isinstance(valid_time_format.validate(valid_time_value), datetime.time)

    # Test for invalid value
    invalid_time_value = "12:23:45.1234567"
    invalid_time_format = TimeFormat()
    try:
        invalid_time_format.validate(invalid_time_value)
    except ValidationError as ve:
        assert ve.code == "invalid"
    else:
        assert False

# Generated at 2022-06-12 15:49:01.373831
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # arrange
    time_string = '23:59:59'
    tf = TimeFormat()

    # act
    result = tf.validate(time_string)

    # assert
    assert result == datetime.time(23,59,59)



# Generated at 2022-06-12 15:49:02.476086
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    f = DateFormat
    with pytest.raises(NotImplementedError):
        f.validate("0000-00-00")
