

# Generated at 2022-06-12 15:39:29.582171
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
	time_format = TimeFormat()
	times = [
		'13:00',
		'13:00:25',
		'13:00:25.1234',
		'13:00:25.123456',
	]
	for time in times:
		result = time_format.validate(time)
		assert result.hour == 13
		assert result.minute == 0
		assert result.second == 25
		assert result.microsecond == 123456


# Generated at 2022-06-12 15:39:33.382390
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    df = DateTimeFormat()
    value = df.validate(value='')
    assert value == ''


# Generated at 2022-06-12 15:39:43.730889
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2030-01-01T01:02:03.045678+02:00").isoformat() == "2030-01-01T01:02:03.045678+02:00"
    assert DateTimeFormat().validate("2030-01-01T01:02:03+05:30").isoformat() == "2030-01-01T01:02:03+05:30"
    assert DateTimeFormat().validate("2030-01-01T01:02:03-05:30").isoformat() == "2030-01-01T01:02:03-05:30"
    assert DateTimeFormat().validate("2030-01-01T01:02:03Z").isoformat()         == "2030-01-01T01:02:03+00:00"

# Generated at 2022-06-12 15:39:46.573652
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    # Arrange
    obj = datetime.datetime.now()

    # Act
    serialized = DateTimeFormat().serialize(obj)

    # Assert
    assert serialized == obj.isoformat()

# Generated at 2022-06-12 15:39:52.486610
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    # test valid
    value_in = '12:03:33.123456'
    exp_out = datetime.time(12, 3, 33, 123456)
    act_out = tf.validate(value_in)
    assert act_out == exp_out
    # test invalid
    value_in = '12:03:33.123456.123456'
    tf.validate(value_in)
    assert False

# Generated at 2022-06-12 15:39:55.061846
# Unit test for method serialize of class DateFormat
def test_DateFormat_serialize():
    format_ = DateFormat()
    obj = datetime.date(2020, 1, 1)
    assert format_.serialize(obj) == '2020-01-01'


# Generated at 2022-06-12 15:40:00.146978
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    ts = '12:00:00.123456'
    ts1 = '12:00:00.12345'
    ts2 = '12:00:00.123'
    assert t.validate(ts)
    assert t.validate(ts1)
    assert t.validate(ts2)

# Generated at 2022-06-12 15:40:04.945744
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    time = datetime.time(hour=13, minute=45, second=12)
    assert TimeFormat().serialize(time) == '13:45:12'
    assert TimeFormat().serialize(datetime.time(hour=13, minute=45)) == '13:45:00'
    assert TimeFormat().serialize(datetime.time(hour=13)) == '13:00:00'



# Generated at 2022-06-12 15:40:06.962187
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    result = time.validate('15:45:00')
    assert result == datetime.time(15, 45, 0, 0)


# Generated at 2022-06-12 15:40:11.871576
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Assignment
    obj = DateFormat()
    value = "2019-12-02"
    
    # Act
    result = obj.validate(value)
    
    # Assert
    assert result == datetime.date(2019, 12, 2)
    assert isinstance(result, datetime.date)



# Generated at 2022-06-12 15:40:23.062636
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    def test(value, expected):
        error = None
        result = None
        try:
            result = DateFormat().validate(value)
        except Exception as err:
            error = err

        assert error == expected, f"{value} does not match {expected}"

    # for each test case
    test('2019-04-09', None)
    test('20190409', ValidationError(text='Must be a valid date format.', code='format'))
    test('2019049999', ValidationError(text='Must be a real date.', code='invalid'))



# Generated at 2022-06-12 15:40:26.254997
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    with pytest.raises(ValueError):
        DateTimeFormat.validate("2019-12-32T12:00:32Z")

# Generated at 2022-06-12 15:40:34.106644
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate('2020-08-11T12:22:30.555555') == datetime.datetime(2020, 8, 11, 12, 22, 30, 555555)
    assert dtf.validate('2020-08-11T12:22:30.555555Z') == datetime.datetime(2020, 8, 11, 12, 22, 30, 555555, tzinfo=datetime.timezone.utc)
    assert dtf.validate('2020-08-11T12:22:30.555555+02:30') == datetime.datetime(2020, 8, 11, 12, 22, 30, 555555, tzinfo=datetime.timezone(datetime.timedelta(hours=2, minutes=30)))
    assert dtf.valid

# Generated at 2022-06-12 15:40:36.955087
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetimeformat = DateTimeFormat()
    assert datetimeformat.validate("2019-01-01T23:00:00Z") == datetime.datetime(2019, 1, 1, 23, 0, 0, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-12 15:40:40.562896
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_obj = DateFormat()
    date1 = date_obj.validate("2019-09-23")
    date2 = date_obj.validate("2019-02-31")

    assert date1.year == 2019
    assert date1.month == 9
    assert date1.day == 23
    assert date2 == ValidationError(text=date_obj.errors['invalid'], code='invalid')


# Generated at 2022-06-12 15:40:47.295856
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    validator = TimeFormat()
    assert validator.validate("12:00:00") == datetime.time(12, 00, 00)
    assert validator.validate("12:00:00.123") == datetime.time(12, 00, 00, 123000)
    assert validator.validate("12:00:00.000123") == datetime.time(12, 00, 00, 123)
    assert validator.validate("12:00") == datetime.time(12, 00)
    assert validator.validate("12") == datetime.time(12)



# Generated at 2022-06-12 15:40:51.304499
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()
    assert format.validate("2020-01-24T15:38:22Z") == datetime.datetime(
        2020, 1, 24, 15, 38, 22, tzinfo=datetime.timezone.utc
    )


# Generated at 2022-06-12 15:40:54.947613
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    given_parameter = uuid.uuid4()
    given_format = UUIDFormat()

    expected_result = given_parameter
    actual_result = given_format.validate(str(given_parameter))

    assert actual_result == expected_result

# Generated at 2022-06-12 15:41:00.671105
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u = UUIDFormat()
    value = "b4fa6bcc-6b68-11e9-8647-d663bd873d93"

    match = UUID_REGEX.match(value)
    if not match:
        raise u.validation_error("format")

    return uuid.UUID(value)


# Generated at 2022-06-12 15:41:02.508416
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    instance = DateTimeFormat()
    assert instance.validate("2020-03-03T15:14:11.123456")

# Generated at 2022-06-12 15:41:07.511510
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    d = DateFormat()
    assert d.validate("2020-01-01") == datetime.date(2020, 1, 1)


# Generated at 2022-06-12 15:41:12.675059
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    # case 1:
    value = '10:20:30'
    time = time_format.validate(value)
    assert time == datetime.time(10, 20, 30)
    # case 2:
    value = '10:20'
    time = time_format.validate(value)
    assert time == datetime.time(10, 20)
    # case 3:
    value = '10'
    time = time_format.validate(value)
    assert time == datetime.time(10)



# Generated at 2022-06-12 15:41:16.948377
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    UUIDFormat().validate(value="f47ac10b-58cc-4372-a567-0e02b2c3d479")



# Generated at 2022-06-12 15:41:22.460963
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    value = 'b7dfa0f6-8e24-11e6-bbf7-080027ebc2e5'
    result = uuid_format.validate(value)
    assert isinstance(result, uuid.UUID)



# Generated at 2022-06-12 15:41:25.626478
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid = UUIDFormat()
    assert str(uuid.validate("01234567-89ab-cdef-0123-456789abcdef")) == "01234567-89ab-cdef-0123-456789abcdef"



# Generated at 2022-06-12 15:41:36.669895
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_1 = "a7a36d1a-fc7d-46c6-9f86-f3bae0f01653"
    uuid_2 = "a7a36d1afc7d46c69f86f3bae0f01653"
    uuid_3 = "592e28e6-a9c9-11e9-be6c-2c4d54b13a8f"

    assert UUIDFormat().validate(uuid_1) == uuid.UUID('a7a36d1a-fc7d-46c6-9f86-f3bae0f01653')

# Generated at 2022-06-12 15:41:43.394833
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    try:
        df.validate("2019-01-01")
        assert True
    except Exception as e:
        assert False, "Expected: Valid string, got: Invalid string"

    try:
        df.validate(42)
        assert False, "Expected: Invalid string, got: Valid string"
    except Exception as e:
        assert True


# Generated at 2022-06-12 15:41:51.869877
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u = UUIDFormat()
    assert u.validate('c9bf9e57-1685-4c89-bafb-ff5af830be8a') == uuid.UUID('c9bf9e57-1685-4c89-bafb-ff5af830be8a')
    assert u.validate('c9bf9e57-1685-4c89-bafb-ff5af830be8a') == uuid.UUID('c9bf9e57-1685-4c89-bafb-ff5af830be8a')
    assert u.validate('c9bf9e57-1685-4c89-bafg-ff5af830be8a') == "Must be valid UUID format."

# Generated at 2022-06-12 15:41:56.016940
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_format = UUIDFormat()
    assert uuid_format.validate("939a9a87-dae3-48e3-8e1b-f18b5a5d5331") is not None


# Generated at 2022-06-12 15:41:59.547828
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    assert UUIDFormat().validate("123e4567-e89b-12d3-a456-426655440000") is not None
    assert UUIDFormat().validate("123e4567") is not None



# Generated at 2022-06-12 15:42:04.864547
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2015-01-01") == datetime.date(2015, 1, 1)


# Generated at 2022-06-12 15:42:09.085837
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_value = datetime.date(2020, 8, 1)
    try:
        assert test_DateFormat_validate.value.validate("2020-8-02") == date_value
    except:
        print("DateFormat validate method failed")


# Generated at 2022-06-12 15:42:13.340405
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # <BLANKLINE>
    # Arrange
    # <BLANKLINE>
    # Act
    # <BLANKLINE>
    # Assert
    # <BLANKLINE>
    pass

# Generated at 2022-06-12 15:42:19.330569
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf1 = TimeFormat()
    tf2 = TimeFormat()
    tf3 = TimeFormat()
    tf4 = TimeFormat()
    
    print(tf1.validate("00:00"))
    print(tf2.validate("14:30"))
    print(tf3.validate("20:00:00"))
    print(tf4.validate("01:00:01.000"))
    
    #tf1.validate("14:30..abc")
    #tf2.validate("14:30:")
    
test_TimeFormat_validate()

# Generated at 2022-06-12 15:42:27.667135
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    """
    Test validate method of class TimeFormat
    """
    t1 = TimeFormat()
    value1 = datetime.time(hour=9, minute=40)
    value2 = (2020, 7, 6, 9, 40, 3, 250000)
    value3 = "2020-07-06T09:40:03.250000"

    assert t1.validate("09:40:03.250000") == value1
    assert t1.validate(value2) == value1
    assert t1.validate(value3) == value1

# Generated at 2022-06-12 15:42:39.109767
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate('00:00') == datetime.time(0, 0)
    assert TimeFormat().validate('00:00:30') == datetime.time(0, 0, 30)
    assert TimeFormat().validate('00:00:30.500000') == datetime.time(0, 0, 30, 500000)
    assert TimeFormat().validate('00:00:30.501000') == datetime.time(0, 0, 30, 501000)
    assert TimeFormat().validate('00:00:30.501') == datetime.time(0, 0, 30, 501000)
    assert TimeFormat().validate('00:00:30.01') == datetime.time(0, 0, 30, 100000)


# Generated at 2022-06-12 15:42:40.516858
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    tf.validate("12:23")
    tf.validate("12:23:23")
    tf.validate("12:23:23.123")


# Generated at 2022-06-12 15:42:47.041106
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    """
    This function test validate function of DateTimeFormat class.

    """
    from typesystem.datetime import DateTimeFormat

    assert DateTimeFormat().validate('2019-03-25T12:00:00Z')==datetime.datetime(2019, 3, 25, 12, 0, 0, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().validate('2019-03-25T12:00:00+09:00')==datetime.datetime(2019, 3, 25, 12, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=9)))

# Generated at 2022-06-12 15:42:50.255592
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = "10:15:30.000000"
    format = TimeFormat()
    assert format.validate(time) == datetime.time(10, 15, 30)



# Generated at 2022-06-12 15:42:52.282895
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat()
    assert time.validate("12:23") == datetime.time(12, 23)
    pass


# Generated at 2022-06-12 15:43:03.873062
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    # Check datetime format when datetime has timezone
    d1 = dateTimeFormat.validate("2019-10-20T12:22:55+08:30")
    assert d1 == datetime.datetime(2019, 10, 20, 12, 22, 55, tzinfo=datetime.timezone(datetime.timedelta(hours=8, minutes=30)))
    # Check datetime format when datetime has no timezone
    d2 = dateTimeFormat.validate("2019-10-20T12:22:55")
    assert d2 == datetime.datetime(2019, 10, 20, 12, 22, 55)
    # Check datetime format when datetime has z timezone

# Generated at 2022-06-12 15:43:13.359894
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate('2010-10-10')

    with pytest.raises(ValidationError):
        date_format.validate('2020-03-32')

    with pytest.raises(ValidationError):
        date_format.validate('2020-13-32')

    with pytest.raises(ValidationError):
        date_format.validate('X020-13-32')

    with pytest.raises(ValidationError):
        date_format.validate('2020-X3-32')

    with pytest.raises(ValidationError):
        date_format.validate('2020-13-X2')



# Generated at 2022-06-12 15:43:17.024000
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    try:
        tf.validate('123:32:23')
    except :
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:43:19.222876
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateFormat = DateFormat()
    date = dateFormat.validate("1976-04-07")
    assert date == datetime.date(1976, 4, 7)
    

# Generated at 2022-06-12 15:43:22.008100
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormat = TimeFormat()
    result = timeFormat.validate("12:12")
    assert result == datetime.time(hour=12, minute=12)

# Generated at 2022-06-12 15:43:26.506505
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # if the value doesn't match regular expression of the python datetime formats
    # raise ValidationError
    dt = DateTimeFormat()
    with pytest.raises(ValidationError):
        assert dt.validate("1986-12-07T21:17:00+00:00")



# Generated at 2022-06-12 15:43:28.556389
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate(datetime.datetime.now().isoformat())


# Generated at 2022-06-12 15:43:32.086416
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormat = TimeFormat()
    assert timeFormat.validate("12:34:00") == datetime.time(12,34)
    assert timeFormat.validate("12:34:30.123456") == datetime.time(12,34,30,123456)


# Generated at 2022-06-12 15:43:35.261969
# Unit test for method validate of class DateFormat

# Generated at 2022-06-12 15:43:47.307264
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    class TestObject:
        format = TimeFormat()

    time_formats = {
        "00:00:00.000000": datetime.time(tzinfo=None),
        "12:00:00.000000": datetime.time(12, tzinfo=None),
        "12:34:00.000000": datetime.time(12, 34, tzinfo=None),
        "12:34:56.000000": datetime.time(12, 34, 56, tzinfo=None),
        "12:34:56.123456": datetime.time(12, 34, 56, 123456, tzinfo=None),
        "12:34:56.123456Z": datetime.time(12, 34, 56, 123456, tzinfo=None),
    }


# Generated at 2022-06-12 15:43:53.125761
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    try:
        tf.validate("12:12")
    except ValidationError:
        print("Success")

# Test for method serialize of class TimeFormat

# Generated at 2022-06-12 15:43:56.349013
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    expected_output = datetime.date(2000,12,31)
    result = DateFormat().validate("2000-12-31")
    assert result == expected_output


# Generated at 2022-06-12 15:44:05.179904
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    input_1 = '00:01:00'
    input_2 = '0:01:00'
    input_3 = '00:1:00'
    input_4 = '00:1:0'
    input_5 = '00:01:0'
    input_6 = '140:01:0'
    input_7 = '140:01'
    input_8 = '23:59'
    input_9 = '00:00:01'
    input_10 = '00:00:00'
    input_11 = '00:00:1'
    input_12 = '00:00:0'
    input_13 = '6:00'
    input_14 = '06:00'
    input_15 = '06:01'

# Generated at 2022-06-12 15:44:08.147306
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('01:02:03.123456') == datetime.time(1,2,3,123456)


# Generated at 2022-06-12 15:44:11.044004
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = datetime.time(12)
    time_format = TimeFormat(format=None)
    time_format.validate(time)


# Generated at 2022-06-12 15:44:16.667219
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    assert t.validate('12:00:00.000') == datetime.time(12, 00, 00)
    assert t.validate('12:00:00.000000') == datetime.time(12, 00, 00)

    with pytest.raises(ValidationError):
        t.validate('12::00.000')

# Generated at 2022-06-12 15:44:21.918835
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t1 = TimeFormat()
    print(t1.validate("12:34:56"))
    print(t1.validate("12:34:56.123456"))
    print(t1.validate("12:34:56.123"))
    print(t1.validate("12:34:56.123456"))
    print(t1.validate("12:34:56.123456789"))



# Generated at 2022-06-12 15:44:29.885732
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    start_time="2020-02-10 12:00:00"
    end_time="2020-02-10 12:00:00"
    ex_date_time_format_start=DateTimeFormat().validate(start_time)
    ex_date_time_format_end=DateTimeFormat().validate(end_time)
    assert ex_date_time_format_start.year ==2020
    assert ex_date_time_format_start.month==2
    assert ex_date_time_format_start.day==10
    assert ex_date_time_format_start.hour==12
    assert ex_date_time_format_start.minute==0
    assert ex_date_time_format_start.second==0
    assert ex_date_time_format_end.year ==2020
    assert ex_date_time

# Generated at 2022-06-12 15:44:32.158300
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    result = TimeFormat().validate("15:30:00")
    assert result == datetime.time(15, 30, 0)



# Generated at 2022-06-12 15:44:39.404355
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert(TimeFormat().validate("00:00:00") == datetime.datetime(1900, 1, 1, 0, 0, 0).time())
    assert (TimeFormat().validate("00:00") == datetime.datetime(1900, 1, 1, 0, 0).time())
    assert(TimeFormat().validate("23:59:59") == datetime.datetime(1900, 1, 1, 23, 59, 59).time())


# Generated at 2022-06-12 15:44:48.071278
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    t.validate('12:45')
    t.validate('12:45:22')
    t.validate('12:45:22.7')
    t.validate('12:45:22.78')
    t.validate('12:45:22.789')
    t.validate('12:45:22.7894')
    t.validate('12:45:22.78951')
    t.validate('12:45:22.789512')
    t.validate('12:45:22.7895123456')
    t.validate('12:45:22.1234567')
    t.validate('12:45:22.01234567')
    t.validate('12:45:22.001234567')

# Generated at 2022-06-12 15:44:50.694498
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    resultado = DateFormat()
    assert resultado.validate("2020-06-04") == datetime.date(2020, 6, 4)


# Generated at 2022-06-12 15:44:59.324409
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    valid_time = "01:02:03"
    invalid_time = "01:02"
    native_time = datetime.datetime.now()
    result1 = time_format.validate(valid_time)
    assert isinstance(result1, datetime.time)
    assert result1.hour == 1
    assert result1.minute == 2
    assert result1.second == 3
    # result2 = time_format.validate(invalid_time)
    # assert result2 == "Must be a valid time format."
    assert time_format.is_native_type(native_time)
    assert not isinstance(native_time, datetime.time)


# Generated at 2022-06-12 15:45:02.598977
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    date = df.validate("2008-08-08")
    assert date == datetime.date(2008, 8, 8)


# Generated at 2022-06-12 15:45:05.765917
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format=TimeFormat()
    time=time_format.validate("13:15")
    assert time==datetime.time(hour=13, minute=15)


# Generated at 2022-06-12 15:45:08.702251
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # time_str = "13:37"
    tf = TimeFormat()
    res = tf.validate("13:37")
    print(res)


# Generated at 2022-06-12 15:45:18.503275
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format = DateTimeFormat()
    # test_datetime_str = '2019-06-04T12:45:26.841447Z'
    test_datetime_str = '2019-06-04T10:45:26.841447'
    datetime_obj = format.validate(test_datetime_str)
    assert isinstance(datetime_obj, datetime.datetime)
    assert datetime_obj.year == 2019
    assert datetime_obj.month == 6
    assert datetime_obj.day == 4
    assert datetime_obj.hour == 10
    assert datetime_obj.minute == 45
    assert datetime_obj.second == 26
    assert datetime_obj.microsecond == 841447
    assert not datetime_obj.tzinfo


# Generated at 2022-06-12 15:45:23.048021
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()
    value = format.validate("2018-02-01")
    assert isinstance(value, datetime.date)
    assert value.year == 2018
    assert value.month == 2
    assert value.day == 1


# Generated at 2022-06-12 15:45:33.846262
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    obj=TimeFormat()
    time1_format="10.15"
    time1_error="Must be a valid time format."
    time2_format="15:12"
    time2_error="Must be a real time."
    time3_format="08:15:00"
    time3_error="Must be a real time."
    time4_format="11:42:20"
    time4_error="Must be a real time."
    time5_format="04:33:00"
    time5_error="Must be a real time."
    # Test 1 : valid format with error in data
    try:
        obj.validate(time1_format)
    except ValidationError as e:
        assert e.text==time1_error
        assert e.code=="format"
    # Test 2 : valid format

# Generated at 2022-06-12 15:45:38.565839
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert type(df.validate('2019-01-11')) is datetime.date
    date = df.validate('2019-01-11')
    assert date==datetime.date(2019,1,11)


# Generated at 2022-06-12 15:45:51.744652
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    from typesystem import Boolean, DateTime, Dict, Float, Integer, List, Object, String

    class Pet(Object):
        name = String(required=True)
        birth_date = DateTime(required=True)
        is_good_boy = Boolean(optional=True)

    class Person(Object):
        name = String(required=True)
        age = Integer(optional=True)
        spouse = Object(
            "Person",
            optional=True,
            required=False,
            fields={"name": String(required=True), "age": Integer(required=True)},
        )
        children = List(
            Object(
                "Person",
                required=True,
                fields={"name": String(required=True), "age": Integer(required=True)},
            )
        )


# Generated at 2022-06-12 15:45:52.483305
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    raise NotImplementedError()


# Generated at 2022-06-12 15:45:55.985514
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    x = datetime.date.today()
    d = DateFormat()
    assert d.validate(str(x)) == x
    with pytest.raises(ValidationError):
        d.validate("2017-12-40")
    with pytest.raises(ValidationError):
        d.validate("2001-00-01")
    with pytest.raises(ValidationError):
        d.validate("2017.01.01")
    with pytest.raises(ValidationError):
        d.validate("2017")


# Generated at 2022-06-12 15:46:04.331773
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # rule 1
    value = TimeFormat().validate("23:01:20")
    assert isinstance(value, datetime.time)
    assert value.hour == 23 and value.minute == 1 and value.second == 20

    # rule 2
    value = TimeFormat().validate("23:01:20.123456")
    assert isinstance(value, datetime.time)
    assert value.microsecond == 123456 and value.hour == 23 and value.minute == 1 and value.second == 20



# Generated at 2022-06-12 15:46:13.537149
# Unit test for method validate of class DateTimeFormat

# Generated at 2022-06-12 15:46:21.539871
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format=TimeFormat()
    assert time_format.validate('12:00:00') == datetime.time(12, 0)
    assert time_format.validate('12:00') == datetime.time(12, 0)
    assert time_format.validate('12:00:00.12') == datetime.time(12, 0, 0, 120000)
    assert time_format.validate('12:00:00.1234') == datetime.time(12, 0, 0, 123400)
    assert time_format.validate('12:00:00.123412') == datetime.time(12, 0, 0, 123412)

# Generated at 2022-06-12 15:46:33.378253
# Unit test for method validate of class DateTimeFormat

# Generated at 2022-06-12 15:46:36.994367
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time: datetime.time = datetime.time(11, 0, 0, 0)
    time_format = TimeFormat()
    assert time_format.validate(time.isoformat()) == time
test_TimeFormat_validate()

# Generated at 2022-06-12 15:46:39.852905
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("20:25") == datetime.time(20,25)


# Generated at 2022-06-12 15:46:49.854872
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert DateFormat().validate("2019-12-31") == datetime.date(2019, 12, 31)
    assert DateFormat().validate("2000-01-01") == datetime.date(2000, 1, 1)

    with pytest.raises(ValidationError):
        DateFormat().validate(123)

    with pytest.raises(ValidationError):
        DateFormat().validate("2019-13-01")

    with pytest.raises(ValidationError):
        DateFormat().validate("2019-12-32")

    with pytest.raises(ValidationError):
        DateFormat().validate("2019-01-32")



# Generated at 2022-06-12 15:46:57.836218
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    tf.validate("1:1:01.100100")
    return True


# Generated at 2022-06-12 15:47:09.955910
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time = time_format.validate('16:30:00')
    assert time.hour == 16
    assert time.minute == 30
    assert time.second == 0
    assert time.microsecond == 0
    time = time_format.validate('16:30:00.123456')
    assert time.hour == 16
    assert time.minute == 30
    assert time.second == 0
    assert time.microsecond == 123456
    time = time_format.validate('16:30:59.123456')
    assert time.hour == 16
    assert time.minute == 30
    assert time.second == 59
    assert time.microsecond == 123456
    try:
        time_format.validate('1630')
        assert False
    except ValidationError:
        assert True
   

# Generated at 2022-06-12 15:47:14.413286
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date = date_format.validate("2015-05-11")

    assert isinstance(date, datetime.date)
    assert date.year == 2015
    assert date.month == 5
    assert date.day == 11



# Generated at 2022-06-12 15:47:17.152126
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    data = '2017-11-03T11:48:45Z'
    b = DateTimeFormat()
    b.validate(data)
    return True


# Generated at 2022-06-12 15:47:26.591412
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = "10:00"
    assert TimeFormat().validate(time) == datetime.time(10,0)
    time = "10:00:00"
    assert TimeFormat().validate(time) == datetime.time(10,0)
    time = "10:00:00.01"
    assert TimeFormat().validate(time) == datetime.time(10,0,0,10000)
    time = "5:6:7.89"
    assert TimeFormat().validate(time) == datetime.time(5, 6, 7, 890000)
    time = "10:00:00.010101"
    assert TimeFormat().validate(time) == datetime.time(10, 0, 0, 101010)
    time = "10:00:00.01011"

# Generated at 2022-06-12 15:47:36.041051
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("12:12:12") == datetime.time(hour=12, minute=12, second=12)
    assert TimeFormat().validate("12:12:12.123") == datetime.time(hour=12, minute=12, second=12, microsecond=123000)
    assert TimeFormat().validate("12:12:12.12") == datetime.time(hour=12, minute=12, second=12, microsecond=120000)
    assert TimeFormat().validate("12:12:12.1") == datetime.time(hour=12, minute=12, second=12, microsecond=100000)
    assert TimeFormat().validate("12:12:12.0") == datetime.time(hour=12, minute=12, second=12)

# Generated at 2022-06-12 15:47:47.226967
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test1 = '2020-05-15T12:00:00Z'
    expected1 = datetime(2020, 5, 15, 12, 0, 0, 0, tzinfo=timezone.utc)
    result1 = DateTimeFormat().validate(test1)
    assert result1 == expected1

    test2 = '2020-05-15T12:00:00-05:00'
    expected2 = datetime(2020, 5, 15, 12, 0, 0, 0, tzinfo=timezone(timedelta(hours=-5)))
    result2 = DateTimeFormat().validate(test2)
    assert result2 == expected2


# Generated at 2022-06-12 15:47:51.297418
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = TimeFormat().validate("10:30:06.123456")
    assert time.hour == 10
    assert time.minute == 30
    assert time.second == 6
    assert time.microsecond == 123456
    assert time.tzinfo is None


# Generated at 2022-06-12 15:47:57.164775
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    test_time = "12:34:56.7890"

    tf_instance = TimeFormat()
    time = tf_instance.validate(test_time)

    assert time.hour == 12
    assert time.minute == 34
    assert time.second == 56
    assert time.microsecond == 789000


# Generated at 2022-06-12 15:48:01.353699
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    from typesystem.base import String

    string = String()
    field = string.bind("time", format="time")

    assert field.type("12:34:56.789") == datetime.time(12, 34, 56, 789000)

    with pytest.raises(ValidationError) as exc_info:
        field.type("12:34")

    assert exc_info.value.code == "format"
    assert str(exc_info.value) == "Must be a valid time format."

# Generated at 2022-06-12 15:48:09.702458
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    # Define valid_input
    valid_input='2000-01-01'
    # Define invalid_input
    invalid_input='2000-01-9999'

    # Call method validate of class DataFormat 
    assert df.validate(valid_input) != None
    assert df.validate(invalid_input) == None


# Generated at 2022-06-12 15:48:18.902570
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    valid_data = [
        "12:34",
        "12:34:56",
        "12:34:56.1234",
        "12:34:56.123456",
        "12:34:56.123450",
    ]
    for value in valid_data:
        timeformat = TimeFormat()
        try:
            timeformat.validate(value)
        except:
            assert False, f"Correct value {value} was not parsed"
    invalid_data = ["123", "12:", "12:345"]
    for value in invalid_data:
        timeformat = TimeFormat()
        try:
            timeformat.validate(value)
            assert False, f"Incorrect value {value} was parsed"
        except ValidationError:
            assert True



# Generated at 2022-06-12 15:48:29.118691
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('00:00:00') == datetime.time(0, 0)
    assert time_format.validate('12:34:56') == datetime.time(12, 34, 56)
    assert time_format.validate('12:34:56.123') == datetime.time(12, 34, 56, 123000)
    assert time_format.validate('12:34:56.123456') == datetime.time(12, 34, 56, 123456)
    assert time_format.validate('12:34:56.123456789') == datetime.time(12, 34, 56, 123456)

# Generated at 2022-06-12 15:48:34.148794
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test with a valid date format
    value_valid = "2020-01-01"
    assert DateFormat().validate(value_valid).__str__() == "2020-01-01"
    
    # Test with an invalid date format
    value_invalid = "2020-1-1"
    try:
        DateFormat().validate(value_invalid)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-12 15:48:36.345713
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    dateTimeFormat.validate("2020-10-23T18:19:27.744Z")


# Generated at 2022-06-12 15:48:43.593217
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat=DateFormat()
    # test valid case
    value = "2020-02-02"
    try:
        actual = dateformat.validate(value)
    except ValidationError as e:
        actual = str(e)
    expected = datetime.date(2020, 2, 2)
    assert actual == expected

    # test invalid case with invalid format
    value = "2020-2-2"
    try:
        actual = dateformat.validate(value)
    except ValidationError as e:
        actual = str(e)
    expected = dateformat.validation_error("format")
    assert actual == expected

    # test invalid case with invalid date
    value = "2020-02-30"
    try:
        actual = dateformat.validate(value)
    except ValidationError as e:
        actual

# Generated at 2022-06-12 15:48:46.096128
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    x = DateFormat()
    assert x.validate("2020-01-23") == datetime.date(2020, 1, 23)


# Generated at 2022-06-12 15:48:50.143914
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time = '12:00'
    result = TimeFormat().validate(time)
    assert result == datetime.time(hour=12, minute=0, tzinfo=None)


# Generated at 2022-06-12 15:49:01.235209
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    d1 = '2020-03-02' # valid date
    d2 = '2010-09-30' # valid date
    d3 = '04-02-2020' # invalid date format
    d4 = '2020-13-32' # invalid date

    df = DateFormat()

    assert df.validate(d1) == datetime.date(2020, 3, 2)
    assert df.validate(d2) == datetime.date(2010, 9, 30)
    assert df.validate(d3) == ValidationError(code='format', text='Must be a valid date format')
    assert df.validate(d4) == ValidationError(code='invalid', text='Must be a real date')


# Generated at 2022-06-12 15:49:05.426155
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    val = TimeFormat().validate("12:34:56.789012+01:30")
    assert val == datetime.time(hour=12,minute=34,second=56,microsecond=789012,tzinfo=datetime.timezone(datetime.timedelta(hours=1,minutes=30)))