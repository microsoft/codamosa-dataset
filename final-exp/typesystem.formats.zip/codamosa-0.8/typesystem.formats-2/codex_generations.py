

# Generated at 2022-06-12 15:39:23.650681
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    a_string="23:12:34.123123"
    time_format=TimeFormat()
    assert time_format.validate(a_string).__str__()=="23:12:34.123123"

# Generated at 2022-06-12 15:39:30.968195
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    d = create_datetime(2019, 1, 2, 3, 4, 5, 6, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(d) == '2019-01-02T03:04:05.000006Z'

    d = create_datetime(2019, 1, 2, 3, 4, 5, 6, tzinfo=datetime.timezone(datetime.timedelta(minutes=30)))
    assert DateTimeFormat().serialize(d) == '2019-01-02T03:04:05.000006+00:30'

    d = create_datetime(2019, 1, 2, 3, 4, 5, 6, tzinfo=datetime.timezone(datetime.timedelta(minutes=-30)))

# Generated at 2022-06-12 15:39:39.491296
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    format = DateFormat()
    assert format.validate("2020-05-22") == datetime.date(2020, 5, 22)
    # assert format.validate("2020-05-22",input) == datetime.date(2020, 5, 22)
    # assert format.validate("2020-5-22") == datetime.date(2020, 5, 22)
    # assert format.validate("2020-05-22") == datetime.date(2020, 5, 22)


# Generated at 2022-06-12 15:39:44.070184
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2020-03-03') == datetime.date(2020, 3, 3)
    try:
        date_format.validate('2011-03-03')
    except ValidationError:
        pass
    try:
        date_format.validate('2021-01-32')
    except ValidationError:
        pass

# Generated at 2022-06-12 15:39:53.375356
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uf = UUIDFormat()
    assert(uf.validate('12345678-1234-5678-1234-567812345678') == uuid.UUID('12345678-1234-5678-1234-567812345678'))
    assert(uf.validate('12345678-1234-5678-1234-567812345678') == uuid.UUID('12345678123456781234567812345678'))
    assert(uf.validate('12345678123456781234567812345678') == uuid.UUID('12345678123456781234567812345678'))

# Generated at 2022-06-12 15:40:03.823547
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    obj = None
    assert DateTimeFormat().serialize(obj) == None
    obj = datetime.datetime(year=2018, month=3, day=2, hour=1, minute=11, second=12)
    assert DateTimeFormat().serialize(obj) == '2018-03-02T01:11:12'
    obj = datetime.datetime(year=2018, month=3, day=2, hour=1, minute=11, second=12, tzinfo=datetime.timezone.utc)
    assert DateTimeFormat().serialize(obj) == '2018-03-02T01:11:12Z'

# Generated at 2022-06-12 15:40:07.172819
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()

    date = date_format.validate("2017-12-13")
    assert date == datetime.date(2017, 12, 13)

    with pytest.raises(ValidationError):
        date_format.validate("2017/12/13")

    with pytest.raises(ValidationError):
        date_format.validate("2017-13-13")


# Generated at 2022-06-12 15:40:14.709746
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    assert tf.validate('14:39:54') == datetime.time(hour=14, minute=39, second=54)
    assert tf.validate('14:39') == datetime.time(hour=14, minute=39)
    assert tf.validate('14:39:54.123') == datetime.time(hour=14, minute=39, second=54, microsecond=123000)
    assert tf.validate('14:39:54.123456') == datetime.time(hour=14, minute=39, second=54, microsecond=123456)


# Generated at 2022-06-12 15:40:21.592035
# Unit test for method serialize of class DateTimeFormat
def test_DateTimeFormat_serialize():
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 2, 3, 4, 5, tzinfo=datetime.timezone(datetime.timedelta(hours=1)))) == "2020-01-02T03:04:05+01:00"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 2, 3, 4, 5, tzinfo=datetime.timezone.utc)) == "2020-01-02T03:04:05Z"
    assert DateTimeFormat().serialize(datetime.datetime(2020, 1, 2, 3, 4, 5)) == "2020-01-02T03:04:05"

# Generated at 2022-06-12 15:40:31.883752
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Test for UTC
    utc_time = DateTimeFormat().validate("2015-12-24T15:39:19Z")
    assert utc_time.year == 2015
    assert utc_time.month == 12
    assert utc_time.day == 24
    assert utc_time.hour == 15
    assert utc_time.minute == 39
    assert utc_time.second == 19
    assert utc_time.microsecond == 0
    assert utc_time.tzinfo == datetime.timezone.utc

    # Test for negative timezone
    neg_time = DateTimeFormat().validate("2015-12-24T15:39:19+00:30")
    assert neg_time.year == 2015
    assert neg_time.month == 12
    assert neg_time.day == 24

# Generated at 2022-06-12 15:40:42.378763
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    uuid_string = "01234567-89ab-cdef-0123-456789abcdef"
    uuid_format = UUIDFormat()
    uuid_obj = uuid.UUID(uuid_string)
    assert uuid_format.validate(uuid_string) == uuid_obj
    # Test error
    try:
        uuid_format.validate("a" * 32)
    except ValidationError as e:
        assert e.code == "format"

# Generated at 2022-06-12 15:40:47.362666
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Test case 01
    res_01 = TimeFormat().validate("23:59:59.999999999")
    assert res_01 == datetime.time(23, 59, 59, 999999)
    
    # Test case 02
    res_02 = TimeFormat().validate("23:59:59.1234567")
    assert res_02 == datetime.time(23, 59, 59, 123456)



# Generated at 2022-06-12 15:40:53.352923
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    format = UUIDFormat()
    value = format.validate('fb7cc43e-e15c-4442-8736-f8ff82322ce6')
    assert value == 'fb7cc43e-e15c-4442-8736-f8ff82322ce6'


UUID = UUIDFormat()
DATETIME = DateTimeFormat()
DATE = DateFormat()
TIME = TimeFormat()

# Generated at 2022-06-12 15:40:54.695077
# Unit test for method serialize of class TimeFormat
def test_TimeFormat_serialize():
    tf = TimeFormat()
    t = tf.validate("13:30:00")
    assert tf.serialize(t) == "13:30:00"

# Generated at 2022-06-12 15:40:58.218274
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    validate_test = DateTimeFormat()
    common_test_string = "2014-05-01T14:30:59Z"
    assert validate_test.validate(common_test_string).isoformat() == common_test_string


# Generated at 2022-06-12 15:41:02.228869
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    with pytest.raises(ValidationError):
        UUIDFormat().validate("test")
    UUIDFormat().validate("12345678-1234-5678-1234-567812345678")

# Generated at 2022-06-12 15:41:07.779373
# Unit test for method validate of class UUIDFormat
def test_UUIDFormat_validate():
    u = UUIDFormat()
    assert str(u.validate("4d4bead8-eae1-4b3b-b3a9-903abccc6b2d")) == "4d4bead8-eae1-4b3b-b3a9-903abccc6b2d"
    try:
        u.validate("hello")
    except ValidationError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:41:17.145414
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("00:00") == datetime.time(0,0)
    assert TimeFormat().validate("00:00:00") == datetime.time(0,0)
    assert TimeFormat().validate("00:00:00.000000") == datetime.time(0,0)
    assert TimeFormat().validate("23:59:59.123456") == datetime.time(23,59,59,123456)
    assert TimeFormat().validate("23:59:59.123456") == datetime.time(23,59,59,123456)
    assert TimeFormat().validate("23:59:59.123456") == datetime.time(23,59,59,123456)

test_TimeFormat_validate()

# Generated at 2022-06-12 15:41:27.499412
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    assert time_format.validate("15:14") == datetime.time(15, 14)
    assert time_format.validate("15:14:13") == datetime.time(15, 14, 13)
    assert time_format.validate("15:14:13.123456") == datetime.time(15, 14, 13, 123456)
    assert time_format.validate("15:14:13.123") == datetime.time(15, 14, 13, 123000)
    assert time_format.validate("15:14:13.12") == datetime.time(15, 14, 13, 120000)
    assert time_format.validate("15:14:13.1") == datetime.time(15, 14, 13, 100000)

    assert time_format

# Generated at 2022-06-12 15:41:37.589921
# Unit test for method validate of class UUIDFormat

# Generated at 2022-06-12 15:41:45.273103
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    correct_time_format = '13:32'
    wrong_time_format = '13:32:34.1234567'
    time_format = TimeFormat()
    assert time_format.validate(correct_time_format) == datetime.time(13, 32)
    try:
        time_format.validate(wrong_time_format)
    except ValidationError:
        pass

# Generated at 2022-06-12 15:41:47.877690
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    value = "17:59:00.000"
    tf = TimeFormat()
    result = tf.validate(value)

    assert(result == datetime.time(17,59,0,0))

# Generated at 2022-06-12 15:41:54.924947
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert(DateTimeFormat().validate("2016-08-10T11:01:00.1234Z") == datetime.datetime(2016, 8, 10, 11, 1, 0, 123400, tzinfo=datetime.timezone.utc))
    assert(DateTimeFormat().validate("2016-08-10T11:01:00Z") == datetime.datetime(2016, 8, 10, 11, 1, 0, 0, tzinfo=datetime.timezone.utc))
    assert(DateTimeFormat().validate("2016-08-10T11:01Z") == datetime.datetime(2016, 8, 10, 11, 1, 0, 0, tzinfo=datetime.timezone.utc))

# Generated at 2022-06-12 15:42:01.860285
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_df = DateTimeFormat()
    result_date_time = test_df.validate("2019-02-27T21:23:39.213Z")
    assert result_date_time.year == 2019
    assert result_date_time.month == 2
    assert result_date_time.day == 27
    assert result_date_time.hour == 21
    assert result_date_time.minute == 23
    assert result_date_time.second == 39
    assert result_date_time.microsecond == 213000


# Generated at 2022-06-12 15:42:04.864026
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    a=TimeFormat()
    b='00:00:00'
    c=a.validate(b)
    assert c.second==0

# Generated at 2022-06-12 15:42:10.758585
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("00:00:00") == datetime.time(0, 0)
    assert TimeFormat().validate("00:00:00.123") == datetime.time(0,0,0,123000)
    assert TimeFormat().validate("23:59:59") == datetime.time(23, 59, 59)
    assert TimeFormat().validate("23:59") == datetime.time(23, 59)


# Generated at 2022-06-12 15:42:21.924377
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    (r0,r1,r2)=(1,1,1)
    try:
        with TimeFormat() as tf:
            assert tf.validate("13:40:54") == datetime.time(13,40,54)
            assert tf.validate("13:40") == datetime.time(13,40)
            assert tf.validate("13") == datetime.time(13,0)
    except ValidationError:
        r0=0
    try:
        with TimeFormat() as tf:
            tf.validate("13:61:54")
    except ValidationError:
        r1=0
    try:
        with TimeFormat() as tf:
            tf.validate("24:40:54")
    except ValidationError:
        r2=0

# Generated at 2022-06-12 15:42:33.321793
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-09-23") == datetime.date(2019, 9, 23)
    assert DateTimeFormat().validate("2019-09-23 07:44:36.098765") == datetime.datetime(2019, 9, 23, 7, 44, 36, 98765)
    assert DateTimeFormat().validate("2019-09-23 07:44:36+10:00") == datetime.datetime(2019, 9, 23, 7, 44, 36, tzinfo=datetime.timezone(datetime.timedelta(seconds=36000)))
    assert DateTimeFormat().validate("2019-09-23+10:00") == datetime.date(2019, 9, 23)
    assert DateTimeFormat().validate("2019-09-23T07:44:36+10:00")

# Generated at 2022-06-12 15:42:43.230438
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
	tf = TimeFormat()
	
	assert tf.validate("00:00:00") == datetime.time(0, 0)
	assert tf.validate("00:00") == datetime.time(0, 0)
	assert tf.validate("23:59") == datetime.time(23, 59)
	assert tf.validate("23:59:59") == datetime.time(23, 59, 59)
	assert tf.validate("23:59:59.123") == datetime.time(23, 59, 59, 123000)
	assert tf.validate("23:59:59.123456") == datetime.time(23, 59, 59, 123456)
	
	with pytest.raises(ValidationError):
		tf.validate("")
		

# Generated at 2022-06-12 15:42:55.281051
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormat = TimeFormat()
    datetimeFormat = DateTimeFormat()
    # check correct formats
    assert timeFormat.validate("03:17:12") == datetimeFormat.validate("2020-01-01T03:17:12")
    assert timeFormat.validate("03:17:12.213") == datetimeFormat.validate("2020-01-01T03:17:12.213")
    assert timeFormat.validate("03:17") == datetimeFormat.validate("2020-01-01T03:17")
    # check incorrect formats
    try:
        timeFormat.validate("03:17:12.213.213")
    except ValidationError as e:
        assert e.code == "format"

# Generated at 2022-06-12 15:43:00.264459
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2000-01-01') == datetime.date(2000,1,1)


# Generated at 2022-06-12 15:43:03.472274
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    value = "2000-01-01T00:00:00Z"
    dtf = DateTimeFormat()
    assert dtf.validate(value) == datetime.datetime(2000, 1, 1, 0, 0, 0, 0, datetime.timezone.utc)

# Generated at 2022-06-12 15:43:05.173266
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    assert df.validate("2003-01-01") == datetime.date(2003, 1, 1)

# Generated at 2022-06-12 15:43:07.005497
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtformat=DateTimeFormat()
    dt=dtformat.validate("123")
    print(dt)


test_DateTimeFormat_validate()

# Generated at 2022-06-12 15:43:12.771883
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    import datetime
    from typesystem.base import ValidationError
    dtf = DateTimeFormat()
    try:
        dtf.validate("2019-01-01T00:00:01+01:00")
    except ValidationError as v:
        print(v.text)
        print(v.code)

test_DateTimeFormat_validate()

# Generated at 2022-06-12 15:43:19.512347
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    from datetime import time

    time_format = TimeFormat()

    times = [
        ("12:59", time(12, 59)),
        ("12:59:59", time(12, 59, 59)),
        ("12:59:59.123456", time(12, 59, 59, 123456)),
    ]

    for string_time, native_time in times:
        assert native_time == time_format.validate(string_time)


# Generated at 2022-06-12 15:43:22.233556
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    assert time_format.validate('22:33:44') == datetime.time(22, 33, 44)


# Generated at 2022-06-12 15:43:28.090698
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Assume
    input = "2016-06-08T15:30:00Z"
    expected_output = datetime.datetime(2016, 6, 8, 15, 30, tzinfo=datetime.timezone.utc)

    # Action
    datetime_format = DateTimeFormat()
    output = datetime_format.validate(input)

    # Assert
    assert output == expected_output

# Generated at 2022-06-12 15:43:30.197038
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    assert (DateFormat().validate("2019-05-19") == datetime.date(2019, 5, 19))


# Generated at 2022-06-12 15:43:36.949459
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()

    assert time_format.validate("12:34:56") == datetime.time(12, 34, 56)
    assert time_format.validate("12:34:56.123456") == datetime.time(12, 34, 56, 123456)
    assert time_format.validate("12:34") == datetime.time(12, 34)
    assert time_format.validate("12") == datetime.time(12)

    with pytest.raises(ValidationError):
        time_format.validate("12:34:56.1234567")


# Generated at 2022-06-12 15:43:50.368289
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    error = []
    datetime_format = DateTimeFormat()
    try:
        result = datetime_format.validate("2020-10-10T12:12:12+00:00")
    except ValidationError as e:
        error.append(e.code)
    except Exception as e:
        error.append(e)
    assert len(error) == 0
    assert isinstance(result, datetime.datetime)

    try:
        result = datetime_format.validate("2020-10-10T12:12:12Z")
    except ValidationError as e:
        error.append(e.code)
    except Exception as e:
        error.append(e)
    assert len(error) == 0
    assert isinstance(result, datetime.datetime)


# Generated at 2022-06-12 15:44:00.449490
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # string with valid date format
    date = "2020-12-31T00:00:00"
    dateformat = DateTimeFormat()
    date_validated = dateformat.validate(date)
    assert date_validated.isoformat() == date
    assert type(date_validated) is datetime.datetime

    # string with invalid date format
    date = "2020-12-31"
    try:
        dateformat.validate(date)
    except ValidationError as e:
        assert e.code == "format"
    else:
        assert False, "no error raised"


# Generated at 2022-06-12 15:44:12.484704
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    # Test to validate format of a valid date
    df = DateFormat()
    assert df.validate("2020-01-01") == datetime.date(2020, 1, 1)

    # Test to validate format of an invalid date
    with pytest.raises(ValidationError) as e:
        df.validate("2020-01")

    assert e.value.code == "format"
    assert e.value.text == "Must be a valid date format."

    # Testing to validate whether the date is a real date
    with pytest.raises(ValidationError) as e:
        df.validate("2020-13-01")

    assert e.value.code == "invalid"
    assert e.value.text == "Must be a real date."


# Generated at 2022-06-12 15:44:17.763366
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    date_1 = date_format.validate("2002-12-01")
    date_2 = date_format.validate("2018-01-01")
    assert date_1 == datetime.date(2002, 12, 1)
    assert date_2 == datetime.date(2018, 1, 1)


# Generated at 2022-06-12 15:44:27.375927
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dateTimeFormat = DateTimeFormat()
    assert dateTimeFormat.validate("2000-01-01T00:00:00+00:00") == datetime.datetime(2000, 1, 1, 0, 0, tzinfo=datetime.timezone.utc)
    assert dateTimeFormat.validate("2000-01-01T00:00:00+01:00") == datetime.datetime(2000, 1, 1, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=1, minutes=0)))

# Generated at 2022-06-12 15:44:30.615455
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat = DateFormat()
    valid_date = dateformat.validate('2020-12-01')
    assert valid_date.isoformat() == '2020-12-01'


# Generated at 2022-06-12 15:44:39.296841
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    actual = DateTimeFormat().validate("2018-07-05T10:00:00.000001Z")
    expected = datetime.datetime(2018, 7, 5, 10, 0, 0, 1, datetime.timezone.utc)
    assert actual == expected

    actual = DateTimeFormat().validate("2018-07-05T23:00:00+05:30")
    expected = datetime.datetime(2018, 7, 5, 23, 0, 0, 0, datetime.timedelta(hours=5, minutes=30))
    assert actual == expected

    actual = DateTimeFormat().validate("2018-07-05T23:00:00.001+05:30")

# Generated at 2022-06-12 15:44:41.061633
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    dateformat = DateFormat()
    dateformat.validate("1998-01-10")


# Generated at 2022-06-12 15:44:42.630099
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    time_format.validate('00:00:00.000000')

# Generated at 2022-06-12 15:44:52.299797
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dt = DateTimeFormat()
    assert dt.validate("2020-11-01") == datetime.datetime(2020, 11, 1)
    assert dt.validate("2020-11-01T12:12:12.123456") == datetime.datetime(2020, 11, 1, 12, 12, 12, 123456)
    assert dt.validate("2020-11-01T12:12:12Z") == datetime.datetime(2020, 11, 1, 12, 12, 12, tzinfo=datetime.timezone.utc)
    assert dt.validate("2020-11-01T12:12:12+00:00") == datetime.datetime(2020, 11, 1, 12, 12, 12, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-12 15:44:58.286220
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    fmt = DateTimeFormat()
    result = fmt.validate("2019-03-01T17:11:43.123456Z")
    assert result == datetime.datetime(2019,3,1,17,11,43,123456,datetime.timezone.utc)

# Generated at 2022-06-12 15:45:09.187347
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date1 = '1300-03-03'
    assert DateFormat().validate(date1) == datetime.date(1300,3,3)
    date2 = '0300-03-03'
    assert DateFormat().validate(date2) == datetime.date(300,3,3)
    date3 = '1300-03-333'
    assert DateFormat().validate(date3) == datetime.date(1300,3,333)
    date4 = '1300-13-03'
    assert DateFormat().validate(date4) == datetime.date(1300,13,3)
    date5 = '1300-03-03T15:08:35.0319128'
    assert DateFormat().validate(date5) == datetime.date(1300,3,3)


# Generated at 2022-06-12 15:45:11.213350
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    DateTimeFormat.validate("2019-09-12T07:18:43.33")

# Generated at 2022-06-12 15:45:12.730038
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate('1997-2-3T12:30:30') == datetime.datetime(1997, 2, 3, 12, 30, 30)

# Generated at 2022-06-12 15:45:18.047510
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format=DateTimeFormat()
    try:
        format.validate("20:10")
        assert False
    except ValidationError:
        assert True

    try:
        format.validate("2019-12-02T08:00")
        assert True
    except ValidationError:
        assert False

    try:
        format.validate("2019-06-02T08:00:13.23+07:00")
        assert True
    except ValidationError:
        assert False

    try:
        format.validate("2019-06-02T08:00:13.23+07")
        assert True
    except ValidationError:
        assert False


# Generated at 2022-06-12 15:45:22.282306
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate(): 
    assert DateTimeFormat().validate('2005-12-30T15:39:21.000Z') == datetime.datetime(2005,12,30,15,39,21,0)


# Generated at 2022-06-12 15:45:33.168790
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    def datetime_assert(d: datetime.datetime, t: datetime.datetime):
        m, s = divmod((d - t).total_seconds(), 60)
        h, m = divmod(m, 60)
        assert (h, m, s) == (0, 0, 0)

    datetime_assert(DateTimeFormat().validate("2020-02-02T10:11:12"), datetime.datetime(2020, 2, 2, 10, 11, 12, 0))
    datetime_assert(DateTimeFormat().validate("2020-02-02T10:11:12+08:00"), datetime.datetime(2020, 2, 2, 10, 11, 12, 0, tzinfo = datetime.timezone(datetime.timedelta(hours=8))))

# Generated at 2022-06-12 15:45:44.588537
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    date_time_format = DateTimeFormat()
    date_time_obj = date_time_format.validate("2020-08-12T15:35")
    assert isinstance(date_time_obj, datetime.datetime)
    assert date_time_obj == datetime.datetime(2020, 8, 12, 15, 35)
    
    date_time_obj = date_time_format.validate("2020-08-12T15:35:00")
    assert isinstance(date_time_obj, datetime.datetime)
    assert date_time_obj == datetime.datetime(2020, 8, 12, 15, 35)
    
    date_time_obj = date_time_format.validate("2020-08-12T15:35:00.000")

# Generated at 2022-06-12 15:45:48.230811
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetime_format = DateTimeFormat()
    actual=datetime_format.validate("2018-11-07T17:36:55Z")
    expected=datetime.datetime(2018, 11, 7, 17, 36, 55, 0)
    assert actual==expected


# Generated at 2022-06-12 15:45:56.352774
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    fmt = DateTimeFormat()
    assert fmt.validate("2020-11-10") == datetime.date(2020, 11, 10)
    assert fmt.validate("10:20:30.123456") == datetime.time(10, 20, 30, 123456)
    assert fmt.validate("2020-11-10T10:20:30.123456") == datetime.datetime(2020, 11, 10, 10, 20, 30, tzinfo=datetime.timezone.utc)
    assert fmt.validate("2020-11-10T10:20:30.123456Z") == datetime.datetime(2020, 11, 10, 10, 20, 30, tzinfo=datetime.timezone.utc)

# Generated at 2022-06-12 15:46:05.400374
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    assert DateTimeFormat().validate("2019-06-27T13:27:30+05:30") == datetime.datetime(
        2019, 6, 27, 13, 27, 30, tzinfo=datetime.timezone(datetime.timedelta(hours=5, minutes=30))
    )

# Generated at 2022-06-12 15:46:08.594170
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date = "2020-12-31"
    date_format = DateFormat()
    assert date_format.validate(date) == datetime.date(year=2020, month=12, day=31)


# Generated at 2022-06-12 15:46:20.365656
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    print("\nTesting function DateFormat.validate")
    date = DateFormat()

    # testing correct date
    try:
        date.validate("1990-01-01")
        print("Correct for 1990-01-01")
    except ValidationError as e:
        print("Error: " + str(e))

    # testing incorrect date format
    try:
        date.validate("1990/01/01")
        print("Error: 1990/01/01 is incorrect format")
    except ValidationError as e:
        print("Correct for 1990/01/01: " + str(e))

    # testing incorrect data

# Generated at 2022-06-12 15:46:25.149209
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
        dateTimeFormat = DateTimeFormat()
        dateTimeFormat.is_native_type('test') == False
        dateTimeFormat.validate('2019-12-17T10:58:35.000000') == '2019-12-17T10:58:35'

# Generated at 2022-06-12 15:46:28.398830
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_text = "2019-01-01"
    date_object = datetime.datetime(2019, 1, 1)
    actual = DateFormat().validate(date_text)
    expected = date_object.date()
    assert actual == expected

# Generated at 2022-06-12 15:46:31.278249
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeformat = TimeFormat()
    with pytest.raises(NotImplementedError):
        timeformat.validate("10:10:10")


# Generated at 2022-06-12 15:46:39.132929
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    dtf = DateTimeFormat()
    assert dtf.validate("2010-05-10T23:00:00Z") == datetime.datetime(2010, 5, 10, 23, 0, 0, tzinfo=datetime.timezone.utc)
    assert dtf.validate("2010-05-10T23:00:00+02:00") == datetime.datetime(2010, 5, 10, 23, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))
    assert dtf.validate("2010-05-10T23:00:00+0200") == datetime.datetime(2010, 5, 10, 23, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(hours=2)))

# Generated at 2022-06-12 15:46:39.791685
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():

    pass


# Generated at 2022-06-12 15:46:44.069227
# Unit test for method validate of class DateFormat
def test_DateFormat_validate(): 
    d = DateFormat()
    test_date = "2019-09-10"
    print(d.validate(test_date))
    #assert d.validate(test_date) == datetime.date(2019, 9, 10)


# Generated at 2022-06-12 15:46:49.722457
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    myVal = "2020-02-23T21:19:00Z"
    d = DateTimeFormat()
    r = d.validate(myVal)
    assert r == datetime.datetime(2020, 2, 23, 21, 19, 0, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-12 15:46:56.346192
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    timeFormat=TimeFormat()
    timeFormat.validate("11:20:00.000000")

# Generated at 2022-06-12 15:47:01.046927
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    import datetime
    tzinfo = datetime.timezone(datetime.timedelta(hours=-6))
    formatter = DateTimeFormat()
    value = "2018-04-01T11:57:32-06:00"
    result = formatter.validate(value)
    assert isinstance(result, datetime.datetime)
    assert result.year == 2018
    assert result.month == 4
    assert result.day == 1
    assert result.hour == 11
    assert result.minute == 57
    assert result.second == 32
    assert result.tzinfo == tzinfo

# Generated at 2022-06-12 15:47:13.381937
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    # valid data
    validate_success_dataset = [
        "2018-12-11",
        "0001-01-01",
        "9999-12-31"
    ]
    for testDate in validate_success_dataset:
        assert df.validate(testDate) == datetime.date(year = int(testDate[0:4]), month = int(testDate[5:7]), day = int(testDate[8:10]))

    # invalid data

# Generated at 2022-06-12 15:47:23.852572
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    format_ = DateTimeFormat()

    value = format_.validate("2010-01-01T11:12:13.123000")
    assert value.year == 2010
    assert value.month == 1
    assert value.day == 1
    assert value.hour == 11
    assert value.minute == 12
    assert value.second == 13
    assert value.microsecond == 123000

    value = format_.validate("2010-01-01T11:12:13.123456")
    assert value.year == 2010
    assert value.month == 1
    assert value.day == 1
    assert value.hour == 11
    assert value.minute == 12
    assert value.second == 13
    assert value.microsecond == 123456

    value = format_.validate("2010-01-01T11:12:13.123")
    assert value

# Generated at 2022-06-12 15:47:28.945950
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    t = TimeFormat()
    assert t.validate("11:23") == "11:23:00"
    assert t.validate("11:23:12") == "11:23:12"
    assert t.validate("11:23:12.345678") == "11:23:12.345678"

# Generated at 2022-06-12 15:47:37.000310
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
  x = DateTimeFormat()
  assert x.validate('2020-01-01').isoformat() == '2020-01-01T00:00:00'
  assert x.validate('2020-01-01T01:01:01').isoformat() == '2020-01-01T01:01:01'
  assert x.validate('2020-01-01T01:01:01.2').isoformat() == '2020-01-01T01:01:01.200000'
  assert x.validate('2020-01-01T01:01:01.111222').isoformat() == '2020-01-01T01:01:01.111222'

# Generated at 2022-06-12 15:47:47.620736
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    df = DateFormat()
    # Test for valid input
    result = df.validate("2020-08-26")
    assert result == datetime.date(2020, 8, 26)
    # Test for invalid input
    with pytest.raises(ValidationError) as e:
        df.validate("2020-08-30")
    assert e.value.code == "invalid"
    # Test for invalid format
    with pytest.raises(ValidationError) as e:
        df.validate("2020-08/26")
    assert e.value.code == "format"


# Generated at 2022-06-12 15:47:50.435720
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    test_datetime = datetime.datetime(2019, 1, 1)
    assert DateTimeFormat().validate(test_datetime.isoformat()) == test_datetime


# Generated at 2022-06-12 15:48:01.184979
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    datetimeformat = DateTimeFormat()
    # test_invalid_datetime_format
    try:
        datetimeformat.validate("2019-10-3")
        raise Exception
    except ValidationError as e:
        assert e.code == "format"
    # test_invalid_datetime_format2
    try:
        datetimeformat.validate("2019-10-0312:23:34:56")
        raise Exception
    except ValidationError as e:
        assert e.code == "format"
    # test_invalid_datetime_value
    try:
        datetimeformat.validate("2011-13-01")
        raise Exception
    except ValidationError as e:
        assert e.code == "invalid"
    # test_invalid_datetime_value2

# Generated at 2022-06-12 15:48:02.178172
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    a = DateTimeFormat()



# Generated at 2022-06-12 15:48:07.571939
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    tf = TimeFormat()
    tf.validate("12:30:22")



# Generated at 2022-06-12 15:48:10.157237
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format1 = DateFormat()
    date1 = date_format1.validate('2048-12-14')
    assert date1 == datetime.date(2048, 12, 14)
    date_format2 = DateFormat()
    date2 = date_format2.validate('2019-05-24')
    assert date2 == datetime.date(2019, 5, 24)


# Generated at 2022-06-12 15:48:18.984787
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    # Test case 1
    value1 = '12:30:59'
    expected1 = datetime.time(12, 30, 59)
    actual1 = TimeFormat().validate(value1)
    assert actual1 == expected1

    # Test case 2
    value2 = '12:30:59.999999'
    expected2 = datetime.time(12, 30, 59, 999999)
    actual2 = TimeFormat().validate(value2)
    assert actual2 == expected2

    # Test case 3
    value3 = '12:30:59.9'
    expected3 = datetime.time(12, 30, 59, 900000)
    actual3 = TimeFormat().validate(value3)
    assert actual3 == expected3


# Generated at 2022-06-12 15:48:23.393510
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
  time_object = datetime.datetime(1,1,1,1,1,1,0)
  time_validation = TimeFormat().validate("1:1:1")
  assert time_validation == time_object

# Generated at 2022-06-12 15:48:26.429749
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    time_format = TimeFormat()
    try:
        time_format.validate("2020-03-03T00:00:00Z")
    except ValidationError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-12 15:48:31.855124
# Unit test for method validate of class DateTimeFormat
def test_DateTimeFormat_validate():
    # Check the validation of a valid datetime
    datetime_format = DateTimeFormat()
    assert datetime_format.validate("2017-03-29T13:13:25.454545") == datetime.datetime(2017, 3, 29, 13, 13, 25, 454545)
    assert datetime_format.validate("2017-03-29T13:13:25") == datetime.datetime(2017, 3, 29, 13, 13, 25)
    assert datetime_format.validate("2017-03-29T13:13") == datetime.datetime(2017, 3, 29, 13, 13)
    assert datetime_format.validate("2017-03-29T13") == datetime.datetime(2017, 3, 29, 13)
    # Check the validation of a invalid datetime

# Generated at 2022-06-12 15:48:36.675118
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    f = DateFormat()
    assert f.validate('2020-4-27') == datetime.date(2020, 4, 27)

# # Unit test for method validate of class DateFormat
# def test_DateFormat_validate_2():
#     f = DateFormat()
#     assert f.validate('2020-4-27') == datetime.date(2020, 4, 27)


# Generated at 2022-06-12 15:48:40.460048
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    value = "2019-11-30"
    dt = DateFormat().validate(value)
    assert dt.year == 2019
    assert dt.month == 11
    assert dt.day == 30



# Generated at 2022-06-12 15:48:49.855192
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    TimeFormat = TimeFormat()
    assert TimeFormat.validate('03:11:00')==datetime.time(3, 11)
    assert TimeFormat.validate('03:11:00.255000')==datetime.time(3, 11, 0, 255000)
    assert TimeFormat.validate('03:11')==datetime.time(3, 11)
    assert TimeFormat.validate('5:36:52')==datetime.time(5, 36, 52)
    assert TimeFormat.validate('00:30:00')==datetime.time(0, 30)

# Generated at 2022-06-12 15:48:52.364778
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    d = DateFormat()
    assert d.validate('2020-01-02')==datetime.date(2020, 1, 2)


# Generated at 2022-06-12 15:49:04.277744
# Unit test for method validate of class TimeFormat
def test_TimeFormat_validate():
    assert TimeFormat().validate("00:01:02.123456") == datetime.time(0, 1, 2, 123456)
    assert TimeFormat().validate("00:01:02.1234567") == datetime.time(0, 1, 2, 123456)
    assert TimeFormat().validate("00:01:02.123123") == datetime.time(0, 1, 2, 123120)



# Generated at 2022-06-12 15:49:07.894036
# Unit test for method validate of class DateFormat
def test_DateFormat_validate():
    date_format = DateFormat()
    assert date_format.validate('2018-12-10') == datetime.date(2018, 12, 10)
