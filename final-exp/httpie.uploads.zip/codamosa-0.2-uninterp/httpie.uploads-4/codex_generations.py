

# Generated at 2022-06-17 21:17:32.847016
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)

# Generated at 2022-06-17 21:17:38.945741
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'abc'

    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'abc'

    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request_body

# Generated at 2022-06-17 21:17:40.346496
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert prepare_request_body('test', lambda x: x) == 'test'

# Generated at 2022-06-17 21:17:45.881622
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    encoder = MultipartEncoder(fields={'field0': 'value', 'field1': 'value'})
    chunked_multipart_upload_stream = ChunkedMultipartUploadStream(encoder)
    assert chunked_multipart_upload_stream.__iter__() is not None


# Generated at 2022-06-17 21:17:54.631438
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:18:00.552661
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'
    assert request.body == b'x\x9cK\xca\x00\x02\x00\x04'

# Generated at 2022-06-17 21:18:05.531766
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from io import BytesIO
    from httpie.cli.dicts import RequestDataDict

    body = RequestDataDict({"key": "value"})
    body = urlencode(body, doseq=True)
    body = BytesIO(body.encode())

    def callback(chunk):
        print(chunk)

    stream = ChunkedUploadStream(body, callback)
    for chunk in stream:
        print(chunk)

# Generated at 2022-06-17 21:18:15.850866
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {'a': 'b'}
    boundary = 'boundary'
    content_type = 'multipart/form-data'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert data.boundary_value == boundary
    assert content_type == 'multipart/form-data; boundary=boundary'
    data = {'a': 'b'}
    boundary = 'boundary'
    content_type = 'multipart/form-data; boundary=boundary'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert data.boundary_value == boundary
    assert content_type == 'multipart/form-data; boundary=boundary'


# Generated at 2022-06-17 21:18:21.145813
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, False)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'
    assert request.body == b'x\x9cK\xca\x00\x02\x81\x01'

# Generated at 2022-06-17 21:18:27.435486
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc\xcf\x07\x00\x1d\x04\x88'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:18:40.907966
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    data = MultipartRequestDataDict()
    data['file'] = 'test'
    encoder = MultipartEncoder(fields=data.items())
    stream = ChunkedMultipartUploadStream(encoder)
    assert len(list(stream.__iter__())) == 2

# Generated at 2022-06-17 21:18:47.458635
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:18:53.365821
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=["abc", "def", "ghi"],
        callback=lambda chunk: print(chunk)
    )
    assert stream.__iter__() == ["abc", "def", "ghi"]



# Generated at 2022-06-17 21:19:03.527103
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from unittest.mock import Mock
    from httpie.cli.dicts import RequestDataDict
    from httpie.compat import is_py2
    from httpie.compression import ChunkedUploadStream
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_PREFIX
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SUFFIX
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SUFFIX_LEN
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_SUFF

# Generated at 2022-06-17 21:19:13.202197
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    import json
    import requests
    from requests_toolbelt import MultipartEncoder

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False

    # test for string
    assert prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    ) == body

    # test for bytes
    body = b'{"a": "b"}'
    assert prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    ) == body

    # test for io.StringIO
    body = io

# Generated at 2022-06-17 21:19:23.781031
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder.MultipartEncoder
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver.__init__
    import requests_toolbelt.multipart.encoder.MultipartEncoder

# Generated at 2022-06-17 21:19:28.473616
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # Arrange
    stream = ['a', 'b', 'c']
    callback = lambda x: x
    chunked_upload_stream = ChunkedUploadStream(stream, callback)
    expected = ['a', 'b', 'c']

    # Act
    actual = list(chunked_upload_stream)

    # Assert
    assert actual == expected


# Generated at 2022-06-17 21:19:34.902658
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'abc'
    request.headers['Content-Length'] = '3'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:19:43.360667
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'
    assert type(result) == str

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'
    assert type(result) == ChunkedUploadStream

    body = 'test'

# Generated at 2022-06-17 21:19:45.653179
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'


# Generated at 2022-06-17 21:20:08.171488
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.utils import body_read_callback
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import os
    import sys
    import tempfile

    # Test for function prepare_request_body
    # Test for function prepare_request_body
    # Test for function prepare_request_body
    # Test for function prepare_request_body
    # Test for function prepare_request_body
    # Test for function prepare_request_body
    # Test for function prepare_request_body
    # Test for function prepare_request_body
    # Test for function prepare_request_body
    # Test for function prepare_request_body
    # Test for function prepare_request_body
    #

# Generated at 2022-06-17 21:20:18.149671
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "abcdefghijklmnopqrstuvwxyz"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = RequestDataDict({"a": "b"})

# Generated at 2022-06-17 21:20:26.649300
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    import json
    import sys
    from httpie.cli.dicts import MultipartRequestDataDict, RequestDataDict
    from httpie.cli.utils import prepare_request_body
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LF
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_CRLF
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_CR
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LFCR

# Generated at 2022-06-17 21:20:32.121793
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, False)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1a\x04\x00'

# Generated at 2022-06-17 21:20:38.233112
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict(
        {
            'key1': 'value1',
            'key2': 'value2',
            'key3': 'value3',
        }
    )
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=--------------------------944252778306067888976936'
    assert data.content_type == 'multipart/form-data; boundary=--------------------------944252778306067888976936'
    assert data.fields == {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
    }

# Generated at 2022-06-17 21:20:47.845724
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:20:57.783568
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02\x82\x01\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:21:04.573605
# Unit test for function prepare_request_body
def test_prepare_request_body():
    def body_read_callback(chunk):
        return chunk

    body = 'test'
    assert prepare_request_body(body, body_read_callback) == body

    body = b'test'
    assert prepare_request_body(body, body_read_callback) == body

    body = io.BytesIO(b'test')
    assert prepare_request_body(body, body_read_callback) == body

    body = MultipartEncoder(fields={'test': 'test'})
    assert isinstance(prepare_request_body(body, body_read_callback), MultipartEncoder)

    body = RequestDataDict({'test': 'test'})
    assert prepare_request_body(body, body_read_callback) == 'test=test'

    body = 'test'

# Generated at 2022-06-17 21:21:10.255567
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:21:19.275119
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    body = '{"a": "b"}'
    body_read_callback = lambda x: x

# Generated at 2022-06-17 21:21:35.761516
# Unit test for function compress_request
def test_compress_request():
    import requests
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.constants import DEFAULT_DATA_CONTENT_TYPES
    from httpie.cli.constants import DEFAULT_FORM_CONTENT_TYPES
    from httpie.cli.constants import DEFAULT_JSON_CONTENT_TYPES
    from httpie.cli.constants import DEFAULT_MULTIPART_CONTENT_TYPES
    from httpie.cli.constants import DEFAULT_UPLOAD_CONTENT_TYPES
    from httpie.cli.constants import DEFAULT_XFORM_CONTENT_TYPES
    from httpie.cli.constants import DEFAULT_XJSON_CONTENT_TYPES
    from httpie.cli.constants import DEFAULT_XWWW_FORM_

# Generated at 2022-06-17 21:21:45.435209
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    assert isinstance(result, str)

    body = b'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    assert isinstance(result, bytes)

    body = io.BytesIO(b'hello world')
    body_read_callback

# Generated at 2022-06-17 21:21:53.363418
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict()
    data['file'] = 'test.txt'
    data['name'] = 'test'
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=----------------------------d7b8e9f1a9a5'
    assert data.content_type == 'multipart/form-data; boundary=----------------------------d7b8e9f1a9a5'
    assert data.fields == [('file', 'test.txt'), ('name', 'test')]
    assert data.boundary_value == '----------------------------d7b8e9f1a9a5'

# Generated at 2022-06-17 21:22:01.118223
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:09.312669
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcf\x07\x00\x06,\x02\x15\x00\x1b\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:22:20.000661
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "abc"
    request.headers = {}
    compress_request(request, True)
    assert request.body == zlib.compress(b"abc")
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))
    request.body = "abc"
    request.headers = {}
    compress_request(request, False)
    assert request.body == zlib.compress(b"abc")
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))
    request.body = "abc"
    request.headers = {}
    compress_request(request, False)
    assert request

# Generated at 2022-06-17 21:22:24.607165
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == zlib.compress(b'hello world')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '15'

# Generated at 2022-06-17 21:22:30.414808
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:38.167199
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {'a': 'b'}
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=---------------------------7dd22b03727c8'
    assert data.fields == {'a': 'b'}
    assert data.boundary == '---------------------------7dd22b03727c8'

    data = {'a': 'b'}
    data, content_type = get_multipart_data_and_content_type(data, boundary='test')
    assert content_type == 'multipart/form-data; boundary=test'
    assert data.fields == {'a': 'b'}
    assert data.boundary == 'test'

    data = {'a': 'b'}

# Generated at 2022-06-17 21:22:49.463590
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:23:04.534909
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xccM\x07\x00\x05\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:23:12.301531
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)

# Generated at 2022-06-17 21:23:22.382353
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:23:25.297733
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02M\x01\x14\x00\x9b\x03'

# Generated at 2022-06-17 21:23:29.326716
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:23:35.345268
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "abc"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "abc"
    body = "abc"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "abc"
    body = "abc"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:23:41.684190
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:23:49.351366
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from io import BytesIO
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import RequestDataDict
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = b'test'
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = BytesIO(b'test')
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = Multipart

# Generated at 2022-06-17 21:24:01.313476
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:24:05.139243
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, False)
    assert request.body == zlib.compress(b'hello world')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:24:23.844444
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    result = prepare_request_body(body, body_read_callback, offline, chunked)
    assert result == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    offline = True
    chunked = False
    result = prepare_request_body(body, body_read_callback, offline, chunked)
    assert result == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    offline = False
    chunked = True
    result = prepare_request_body(body, body_read_callback, offline, chunked)
    assert result == 'hello world'

    body = 'hello world'
    body

# Generated at 2022-06-17 21:24:30.235630
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:24:33.888671
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:24:45.077299
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:24:49.469725
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:25:02.317354
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
   

# Generated at 2022-06-17 21:25:09.635024
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:25:19.197212
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    body = '{"a": "b"}'
    body_read_callback = lambda x: x

# Generated at 2022-06-17 21:25:24.897368
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:25:29.097868
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\x04\x00\x1d\x8a\x04\x8a'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:25:44.311181
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1b\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:25:52.960405
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'1234567890'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\xcb\xcf\x07\x00\x02M\xccMU\x04\x00\x1d\x8a\x04\x8a'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'
    compress_request(request, False)
    assert request.body == b'x\x9cKLJ\xcb\xcf\x07\x00\x02M\xccMU\x04\x00\x1d\x8a\x04\x8a'

# Generated at 2022-06-17 21:26:01.257592
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World!'
    request.headers = {'Content-Length': '12'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '25'

# Generated at 2022-06-17 21:26:11.086295
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)

# Generated at 2022-06-17 21:26:18.207375
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\r\x00\xbd\x1a\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:26:22.276383
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01\x02\x03\x04'

# Generated at 2022-06-17 21:26:29.879844
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:26:41.560147
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline

# Generated at 2022-06-17 21:26:50.021399
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:27:00.288820
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)