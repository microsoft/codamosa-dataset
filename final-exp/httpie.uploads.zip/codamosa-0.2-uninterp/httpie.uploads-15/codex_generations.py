

# Generated at 2022-06-17 21:17:20.128673
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8a\x03\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:17:26.930857
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1b\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:17:33.590071
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\x04\x00\x1d\x8a\x04\x8a'

# Generated at 2022-06-17 21:17:37.338113
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x01'

# Generated at 2022-06-17 21:17:48.372743
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
   

# Generated at 2022-06-17 21:17:58.057181
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\x04\x00\x1d\x0b\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:18:06.838500
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from io import BytesIO
    from httpie.cli.dicts import RequestDataDict
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE

    body = RequestDataDict({'a': 'b'})
    body = prepare_request_body(body, lambda x: x)
    body = BytesIO(body)
    body = ChunkedUploadStream(body, lambda x: x)
    body = b''.join(body)
    if is_windows:
        assert body == b'a=b'
    else:
        assert body == b'a=b' + BINARY_SUPPRESSED_NOTICE

# Generated at 2022-06-17 21:18:16.778964
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from io import BytesIO
    from unittest.mock import Mock
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartEncoder
    from httpie.cli.dicts import ChunkedUploadStream
    from httpie.cli.dicts import ChunkedMultipartUploadStream

    # Test for method __iter__ of class ChunkedUploadStream

# Generated at 2022-06-17 21:18:22.505950
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\xcb\xcf\x07\x00\x02\x82\x01\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:18:25.517624
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda chunk: print(chunk)
    )
    for chunk in stream:
        print(chunk)

# Generated at 2022-06-17 21:18:43.768964
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xccM\x01\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:18:47.767553
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=['a', 'b', 'c'],
        callback=lambda chunk: print(chunk),
    )
    assert list(stream) == ['a', 'b', 'c']


# Generated at 2022-06-17 21:19:01.272248
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict(
        {
            'foo': 'bar',
            'baz': 'qux',
        }
    )
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=--------------------------8e0c9b8e8b8c8c4a'
    assert data.boundary_value == '--------------------------8e0c9b8e8b8c8c4a'
    assert data.fields == [
        ('foo', 'bar'),
        ('baz', 'qux')
    ]
    assert data.content_type == 'multipart/form-data; boundary=--------------------------8e0c9b8e8b8c8c4a'

# Generated at 2022-06-17 21:19:11.225854
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    import io
    import requests_toolbelt
    import requests
    import zlib
    import json
    import os
    import tempfile
    import sys
    import shutil
    import random
    import string
    import time
    import re
    import subprocess
    import urllib.parse
    import http.client
    import http.server
    import socketserver
    import threading
    import socket
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.parse
    import urllib

# Generated at 2022-06-17 21:19:16.666476
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:19:20.905293
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {'a': 'b'}
    boundary = 'boundary'
    content_type = 'content_type'
    encoder, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert encoder.boundary_value == boundary
    assert content_type == 'content_type; boundary=boundary'
    encoder, content_type = get_multipart_data_and_content_type(data, boundary)
    assert encoder.boundary_value == boundary
    assert content_type == 'multipart/form-data; boundary=boundary'
    encoder, content_type = get_multipart_data_and_content_type(data)
    assert encoder.boundary_value != boundary

# Generated at 2022-06-17 21:19:26.931716
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\xf5'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:19:37.597869
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict({'a': 'b'})
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=----------------------------8a9b9f7e7d6f'
    assert data.content_type == 'multipart/form-data; boundary=----------------------------8a9b9f7e7d6f'
    assert data.to_string() == '------------------------------8a9b9f7e7d6f\r\nContent-Disposition: form-data; name="a"\r\n\r\nb\r\n------------------------------8a9b9f7e7d6f--\r\n'

# Generated at 2022-06-17 21:19:43.017942
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\x01\x00\x1a\x04\x88\x1a\x05'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '24'

# Generated at 2022-06-17 21:19:47.476409
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare

# Generated at 2022-06-17 21:19:56.678240
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\xf5'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:20:03.847820
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:20:11.995837
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xccH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'

# Generated at 2022-06-17 21:20:16.431503
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:20:21.566508
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:20:32.089465
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'
    chunked = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'
    body = {'key': 'value'}
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)

# Generated at 2022-06-17 21:20:37.033810
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\r\x00\xbd\x1a\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '24'

# Generated at 2022-06-17 21:20:41.792680
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, False)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:20:47.749385
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:21:01.225697
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    import json
    import requests
    from requests_toolbelt import MultipartEncoder

    # Test for function prepare_request_body
    def test_prepare_request_body_func(
        body: Union[str, bytes, IO, MultipartEncoder, RequestDataDict],
        body_read_callback: Callable[[bytes], bytes],
        content_length_header_value: int = None,
        chunked=False,
        offline=False,
    ) -> Union[str, bytes, IO, MultipartEncoder, ChunkedUploadStream]:
        return prepare_request_body(
            body,
            body_read_callback,
            content_length_header_value,
            chunked,
            offline,
        )

    # Test for function get_multipart_data_and_content_

# Generated at 2022-06-17 21:21:17.081903
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '26'

# Generated at 2022-06-17 21:21:25.391327
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "hello world"
    assert type(result) == str

    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "hello world"
    assert type(result) == ChunkedUploadStream

    body = "hello world"
    body_read_

# Generated at 2022-06-17 21:21:35.761565
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == 'abc'

    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == 'abc'

    body = 'abc'
    body_read_callback

# Generated at 2022-06-17 21:21:45.435411
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)

# Generated at 2022-06-17 21:21:54.184725
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    offline = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body.encode()
    body = RequestDataDict({'test': 'test'})

# Generated at 2022-06-17 21:22:00.674366
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:08.823011
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:22:13.941798
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:21.094737
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8a\x03\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '19'

# Generated at 2022-06-17 21:22:31.051599
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None

# Generated at 2022-06-17 21:22:51.412953
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello'
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello'
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:22:59.709786
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:23:09.083607
# Unit test for function compress_request
def test_compress_request():
    import requests
    import httpie.cli.argtypes
    import httpie.cli.dicts
    import httpie.cli.formatter
    import httpie.cli.utils
    import httpie.compression
    import httpie.downloads
    import httpie.input
    import httpie.output
    import httpie.plugins
    import httpie.status
    import httpie.streams
    import httpie.utils
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main

# Generated at 2022-06-17 21:23:16.191037
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'abc'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:23:21.371134
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:23:27.424171
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:23:32.921803
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'

# Generated at 2022-06-17 21:23:38.934116
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:23:43.550487
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:23:50.344260
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello world'
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.callback == body_read_callback
    assert result.stream.__next__() == 'hello world'.encode()
    body = 'hello world'
    body_read_

# Generated at 2022-06-17 21:24:05.486926
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:24:11.700598
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '30'

# Generated at 2022-06-17 21:24:17.233939
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == 'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == 'hello'

    body = 'hello'
    body_read_callback

# Generated at 2022-06-17 21:24:23.363432
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {'Content-Length': str(len(request.body))}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '35'

# Generated at 2022-06-17 21:24:33.969449
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline

# Generated at 2022-06-17 21:24:40.864401
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:24:49.091489
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:25:02.187839
# Unit test for function compress_request
def test_compress_request():
    from httpie.core import main
    from httpie.compat import is_windows
    from httpie.output.streams import get_binary_stream

    if is_windows:
        return

    args = ['--compress', '--form', 'POST', 'http://httpbin.org/post', 'a=b']
    with main(args=args, stdin=get_binary_stream('hello world')) as r:
        assert r.exit_status == 0
        assert 'Content-Encoding: deflate' in r.stderr
        assert 'Content-Length: 20' in r.stderr
        assert 'hello world' in r.stderr

    args = ['--compress', '--form', 'POST', 'http://httpbin.org/post', 'a=b']

# Generated at 2022-06-17 21:25:10.573540
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\r\x00\xbd\x1a\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '27'

# Generated at 2022-06-17 21:25:16.561680
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:25:32.972552
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:25:41.993512
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a":"b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False

    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a":"b"}'

    body = '{"a":"b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False

    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a":"b"}'

    body = '{"a":"b"}'
    body_read_callback = lambda x: x


# Generated at 2022-06-17 21:25:50.572048
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import parse_items
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import plugin_manager
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_stream
    from httpie.utils import get_response_stream


# Generated at 2022-06-17 21:25:59.419308
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'body'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '7'
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02'

# Generated at 2022-06-17 21:26:05.167891
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'
    assert request.body == b'x\x9c+I-.Q(I\xcf\xcc,\x00\x00\x00'

# Generated at 2022-06-17 21:26:16.506005
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import parse_items
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type

# Generated at 2022-06-17 21:26:22.494200
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9c+J-.Q(I-.\xca-\xccK\x04\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:26:27.124396
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:26:30.736850
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:26:38.654888
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:26:59.733866
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result != body
    assert result.callback == body_read_callback
    assert result.stream == (chunk.encode() for chunk in [body])
    offline = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

# Generated at 2022-06-17 21:27:06.534416
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1a\x04\x00'