

# Generated at 2022-06-17 21:17:28.023393
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    import requests
    import json
    import os
    import sys
    import time
    import random
    import string
    import tempfile
    import subprocess
    import io
    import base64
    import hashlib
    import unittest
    import logging
    import httpie
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.plugins.builtin.auth
    import httpie.plugins.builtin.core
    import httpie.plugins.builtin.downloads
    import httpie.plugins.builtin.form
    import httpie.plugins.builtin.generic
    import httpie.plugins.builtin.graph

# Generated at 2022-06-17 21:17:33.365715
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\xcb\xcf\x07\x00\x02M\x01\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:17:45.338465
# Unit test for function prepare_request_body

# Generated at 2022-06-17 21:17:57.111860
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder.MultipartEncoder
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.Multipart

# Generated at 2022-06-17 21:18:06.969415
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests

# Generated at 2022-06-17 21:18:16.894250
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'
    offline = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'
    body = b'test'

# Generated at 2022-06-17 21:18:26.740661
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict

# Generated at 2022-06-17 21:18:31.348019
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    encoder = MultipartEncoder(
        fields={'field0': 'value', 'field1': 'value', 'field2': 'value'}
    )
    chunked_multipart_upload_stream = ChunkedMultipartUploadStream(encoder)
    for chunk in chunked_multipart_upload_stream:
        print(chunk)


# Generated at 2022-06-17 21:18:42.102596
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == ChunkedUploadStream(stream=(chunk.encode() for chunk in [body]), callback=body_read_callback)
    body = 'hello world'
    body_read_callback

# Generated at 2022-06-17 21:18:51.532536
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:19:01.486993
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b'

# Generated at 2022-06-17 21:19:07.904299
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:19:15.268185
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.compat import is_py2
    from httpie.compat import is_windows
    import os
    import sys
    import tempfile
    import unittest

    class TestChunkedMultipartUploadStream(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.tempfile = os.path.join(self.tempdir, 'test.txt')
            with open(self.tempfile, 'w') as f:
                f.write('test')

        def tearDown(self):
            os.remove(self.tempfile)
            os.rmdir(self.tempdir)


# Generated at 2022-06-17 21:19:23.203380
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.argtypes import KeyValueArgType

    data = MultipartRequestDataDict()
    data['file'] = ('test.txt', open('test.txt', 'rb'), 'text/plain')
    data['name'] = 'test'
    encoder = MultipartEncoder(fields=data.items())
    stream = ChunkedMultipartUploadStream(encoder=encoder)
    for chunk in stream:
        print(chunk)


# Generated at 2022-06-17 21:19:31.631835
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder.MultipartEncoder
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.Multipart

# Generated at 2022-06-17 21:19:39.436287
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '29'

# Generated at 2022-06-17 21:19:47.265894
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.compat import is_windows
    from httpie.cli.constants import DEFAULT_CONTENT_TYPE
    from httpie.cli.constants import DEFAULT_CONTENT_TYPE_FORM_URLENCODED
    from httpie.cli.constants import DEFAULT_CONTENT_TYPE_MULTIPART
    from httpie.cli.constants import DEFAULT_CONTENT_TYPE_JSON
    from httpie.cli.constants import DEFAULT_CONTENT_TYPE_JSON_STREAM
    from httpie.cli.constants import DEFAULT_CONTENT_TYPE_JSON_STREAM_COMPACT
    from httpie.cli.constants import DEFAULT_CONTENT_TYPE_JSON_

# Generated at 2022-06-17 21:20:00.966161
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'abc'

    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'abc'

    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:20:10.321224
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    import json
    import requests
    from httpie.cli.dicts import MultipartRequestDataDict, RequestDataDict

    # Test for body is str
    body = 'test'
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    content_length_header_value = None
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    # Test for body is bytes
    body = b'test'
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    content_length_header_value = None

# Generated at 2022-06-17 21:20:17.419345
# Unit test for function compress_request
def test_compress_request():
    import json
    import requests
    from requests.models import RequestEncodingMixin
    from requests.models import Request
    from requests.models import PreparedRequest
    from requests.models import CaseInsensitiveDict
    from requests.structures import CaseInsensitiveDict

    # Test for function compress_request
    # Test for case 1: request.body is str
    request = Request(method='GET', url='https://httpbin.org/get')
    request.body = '{"key": "value"}'
    request.headers = CaseInsensitiveDict()
    request.headers['Content-Type'] = 'application/json'
    request.headers['Content-Length'] = str(len(request.body))
    request.prepare()
    compress_request(request, True)

# Generated at 2022-06-17 21:20:32.121941
# Unit test for method __iter__ of class ChunkedMultipartUploadStream

# Generated at 2022-06-17 21:20:38.226318
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder.MultipartEncoder
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.Mult

# Generated at 2022-06-17 21:20:44.854810
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False

    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False

    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True


# Generated at 2022-06-17 21:20:52.920103
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.compat import str
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import CONTENT_TYPE_JSON
    from httpie.cli.constants import CONTENT_TYPE_FORM
    from httpie.cli.constants import CONTENT_TYPE_MULTIPART
    from httpie.cli.constants import CONTENT_TYPE_URLENCODED
    from httpie.cli.constants import CONTENT_TYPE_STREAM
    from httpie.cli.constants import CONTENT_TYPE_FILE
    from httpie.cli.constants import CONTENT_TYPE_TEXT
    from httpie.cli.constants import CONTENT_TYPE_HTML


# Generated at 2022-06-17 21:21:02.871332
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    import json
    import requests
    from requests_toolbelt import MultipartEncoder

    body = '{"a": 1}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False

    # Test for str
    assert isinstance(prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline), str)

    # Test for bytes
    body = b'{"a": 1}'
    assert isinstance(prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline), bytes)

    # Test for IO
    body = io.BytesIO(b'{"a": 1}')

# Generated at 2022-06-17 21:21:12.816527
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:21:17.034074
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body


# Generated at 2022-06-17 21:21:22.411136
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:21:29.204906
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    import io
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.utils import ChunkedUploadStream
    from httpie.cli.utils import prepare_request_body
    from httpie.cli.utils import get_multipart_data_and_content_type
    from httpie.cli.utils import compress_request

    # Test for method __iter__ of class ChunkedUploadStream
    def test_ChunkedUploadStream___iter__():
        stream = io.StringIO('abc')
        chunked_stream = ChunkedUploadStream(stream, lambda x: x)
        assert list(chunked_stream) == ['abc']

    # Test for method __iter__ of class ChunkedMultipartUploadStream

# Generated at 2022-06-17 21:21:34.170922
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    data = MultipartRequestDataDict()
    data['file'] = 'test'
    encoder = MultipartEncoder(fields=data.items())
    stream = ChunkedMultipartUploadStream(encoder)
    for chunk in stream:
        print(chunk)



# Generated at 2022-06-17 21:21:55.446398
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder.MultipartEncoder
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoder

# Generated at 2022-06-17 21:22:00.836882
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:22:11.697017
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    import requests
    import json
    import os
    import tempfile
    import shutil
    import io
    import sys
    import unittest

    class TestChunkedMultipartUploadStream(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.tmp_file = os.path.join(self.tmp_dir, 'tmp.txt')
            self.tmp_file_content = 'abcdefghijklmnopqrstuvwxyz'
            with open(self.tmp_file, 'w') as f:
                f.write(self.tmp_file_content)

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)


# Generated at 2022-06-17 21:22:22.319085
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict(
        {
            'a': 'b',
            'c': 'd',
        }
    )
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=---------------------------7d44e178b0434'
    assert data.to_string() == '''\
-----------------------------7d44e178b0434
Content-Disposition: form-data; name="a"

b
-----------------------------7d44e178b0434
Content-Disposition: form-data; name="c"

d
-----------------------------7d44e178b0434--
'''

# Generated at 2022-06-17 21:22:27.685740
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '15'
    assert request.body == b'x\x9c+\xcf\xcfMU(\xceL\xccK\x07\x00\x1a\x04\x00'

# Generated at 2022-06-17 21:22:36.944885
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'

# Generated at 2022-06-17 21:22:39.857388
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:22:42.466836
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:22:51.009637
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\x04\x00\x1d\x0b\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '29'

# Generated at 2022-06-17 21:22:55.939679
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: print(x)
    )
    assert next(stream) == b'a'
    assert next(stream) == b'b'
    assert next(stream) == b'c'


# Generated at 2022-06-17 21:23:08.328506
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    data = MultipartRequestDataDict()
    data['file'] = ('file.txt', 'content')
    encoder = MultipartEncoder(fields=data.items())
    stream = ChunkedMultipartUploadStream(encoder)
    assert stream.__iter__() == encoder.to_string()

# Generated at 2022-06-17 21:23:15.446315
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:23:24.609953
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests

# Generated at 2022-06-17 21:23:27.073053
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(stream=['a', 'b', 'c'], callback=lambda x: x)
    assert iter(stream) == ['a', 'b', 'c']


# Generated at 2022-06-17 21:23:32.316425
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '25'

# Generated at 2022-06-17 21:23:36.878882
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from unittest.mock import Mock
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.utils import prepare_request_body
    from httpie.cli.utils import ChunkedUploadStream
    from httpie.cli.utils import ChunkedMultipartUploadStream
    from httpie.cli.utils import get_multipart_data_and_content_type
    from httpie.cli.utils import compress_request
    from httpie.cli.utils import test_ChunkedUploadStream___iter__
    from httpie.cli.utils import test_ChunkedMultipartUploadStream___iter__
    from httpie.cli.utils import test_get_multipart_data_and_content_type
    from httpie.cli.utils import test_compress_request

# Generated at 2022-06-17 21:23:39.795720
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda chunk: print(chunk)
    )
    for chunk in stream:
        print(chunk)


# Generated at 2022-06-17 21:23:42.768032
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'abc'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'

# Generated at 2022-06-17 21:23:48.179018
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:24:00.920859
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict([('a', 'b')])
    data, content_type = get_multipart_data_and_content_type(data)

# Generated at 2022-06-17 21:24:24.344996
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from httpie.cli.dicts import MultipartRequestDataDict
    from requests_toolbelt import MultipartEncoder
    data = MultipartRequestDataDict(
        {
            'file': (
                'test.txt',
                'hello world',
                'text/plain',
            ),
        },
    )
    encoder = MultipartEncoder(
        fields=data.items(),
    )
    stream = ChunkedMultipartUploadStream(
        encoder=encoder,
    )

# Generated at 2022-06-17 21:24:34.918556
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert isinstance(prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline), ChunkedUploadStream)
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body.encode()
    body = b'test'
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

# Generated at 2022-06-17 21:24:41.568139
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:24:46.217500
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {'Content-Length': str(len(request.body))}
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:24:50.404363
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:25:01.945446
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from io import BytesIO
    from typing import Callable
    from unittest import TestCase

    class TestChunkedUploadStream(TestCase):
        def test_ChunkedUploadStream___iter__(self):
            stream = BytesIO(b'abcdefghijklmnopqrstuvwxyz')
            callback = lambda chunk: None
            chunked_upload_stream = ChunkedUploadStream(stream, callback)
            for chunk in chunked_upload_stream:
                self.assertEqual(chunk, b'abcdefghijklmnopqrstuvwxyz')

    TestChunkedUploadStream().test_ChunkedUploadStream___iter__()


# Generated at 2022-06-17 21:25:12.777952
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests

# Generated at 2022-06-17 21:25:23.405842
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"name": "value"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    assert type(result) == str

    body = '{"name": "value"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    assert type(result) == str

    body = '{"name": "value"}'
    body_

# Generated at 2022-06-17 21:25:27.752741
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:25:34.372632
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request_body

# Generated at 2022-06-17 21:26:20.037257
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import io
    import requests
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder

# Generated at 2022-06-17 21:26:25.202779
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict([('a', 'b'), ('c', 'd')])
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=---------------------------7d44e178b0434'
    assert data.boundary_value == '---------------------------7d44e178b0434'
    assert data.fields == [('a', 'b'), ('c', 'd')]

# Generated at 2022-06-17 21:26:32.093556
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    import io
    import requests
    import os
    import tempfile
    import shutil
    import random
    import string
    import zlib
    import base64
    import json
    import unittest

    class ChunkedMultipartUploadStreamTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file_path = os.path.join(self.temp_dir, 'temp_file')
            self.temp_file = open(self.temp_file_path, 'wb')
            self.temp_file_name = 'temp_file'

# Generated at 2022-06-17 21:26:39.315206
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == zlib.compress(b'hello world')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:26:40.899093
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(stream=["a", "b", "c"], callback=lambda x: x)
    assert list(stream) == ["a", "b", "c"]


# Generated at 2022-06-17 21:26:48.552423
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = b'hello world'
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

# Generated at 2022-06-17 21:26:59.952518
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    import io
    import requests
    import requests_toolbelt
    from httpie.cli.dicts import MultipartRequestDataDict, RequestDataDict
    from httpie.cli.constants import DEFAULT_CHUNK_SIZE
    from httpie.cli.constants import DEFAULT_CONTENT_TYPE
    from httpie.cli.constants import DEFAULT_FORM_CONTENT_TYPE
    from httpie.cli.constants import DEFAULT_MULTIPART_CONTENT_TYPE
    from httpie.cli.constants import DEFAULT_JSON_CONTENT_TYPE
    from httpie.cli.constants import DEFAULT_UPLOAD_CONTENT_TYPE
    from httpie.cli.constants import DEFAULT_UPLOAD_FILENAME
    from httpie.cli.constants import DEFAULT_UPLOAD_FIL

# Generated at 2022-06-17 21:27:02.957259
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda chunk: print(chunk)
    )
    assert list(stream) == [b'a', b'b', b'c']

# Generated at 2022-06-17 21:27:12.206023
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request