

# Generated at 2022-06-17 21:17:36.349910
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests

# Generated at 2022-06-17 21:17:45.175280
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1a\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '21'

# Generated at 2022-06-17 21:17:54.796262
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '25'

# Generated at 2022-06-17 21:18:01.629071
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    data = MultipartRequestDataDict()
    data['file'] = 'test'
    encoder = MultipartEncoder(fields=data.items())
    stream = ChunkedMultipartUploadStream(encoder=encoder)
    assert stream.__iter__() is not None


# Generated at 2022-06-17 21:18:09.362647
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = {'key': 'value'}
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'key=value'

    body = {'key': 'value'}
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'key=value'

    body = 'value'
    body_read_callback = lambda x: x
    content_length_header

# Generated at 2022-06-17 21:18:18.253371
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    import io
    import pytest
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartEncoder
    from httpie.cli.dicts import ChunkedUploadStream
    from httpie.cli.dicts import ChunkedMultipartUploadStream
    from httpie.cli.dicts import prepare_request_body
    from httpie.cli.dicts import get_multipart_data_and_content_type
    from httpie.cli.dicts import compress_request
    from httpie.cli.dicts import test_ChunkedUploadStream___iter__
    from httpie.cli.dicts import test_ChunkedMultipartUploadStream___iter__

# Generated at 2022-06-17 21:18:23.926024
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {'Content-Length': str(len(request.body))}
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:18:32.194692
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.compat import is_windows
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.compression import ChunkedMultipartUploadStream
    from httpie.compression import prepare_request_body
    from httpie.compression import get_multipart_data_and_content_type
    from httpie.compression import compress_request
    from httpie.compression import ChunkedUploadStream
    from httpie.compression import ChunkedMultipartUploadStream
    from httpie.compression import prepare_request_body
    from httpie.compression import get_multipart_data_and_content_type
    from httpie.compression import compress_request
    from httpie.compression import ChunkedUpload

# Generated at 2022-06-17 21:18:42.887944
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    import requests
    import os
    import tempfile
    import random
    import string
    import io
    import zlib
    import json
    import base64
    import hashlib
    import time
    import sys
    import unittest
    import re
    import subprocess
    import shutil
    import multiprocessing
    import threading
    import queue
    import socket
    import ssl
    import urllib3
    import urllib3.connection
    import urllib3.util.connection
    import urllib3.util.retry
    import urllib3.util.response
    import urllib3.util.timeout
    import urllib3.util.url
    import urllib3.util.request
    import urllib3

# Generated at 2022-06-17 21:18:50.107227
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello world"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\r\x00\xbd\xfa\x8f\x80'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:19:10.131986
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '15'

# Generated at 2022-06-17 21:19:16.652131
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:19:23.251884
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:19:31.656743
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcf\x07\x00\x06,\x02\x15'

# Generated at 2022-06-17 21:19:38.049568
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, False)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:19:43.329162
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1b\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '19'

# Generated at 2022-06-17 21:19:46.155877
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, True)
    assert request.body == zlib.compress(b"Hello World")
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(zlib.compress(b"Hello World")))

# Generated at 2022-06-17 21:19:54.110674
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, False)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00'

# Generated at 2022-06-17 21:19:57.836922
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'abc'
    request.headers = {'Content-Length': '3'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:20:02.232731
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: x
    )
    assert list(stream) == [b'a', b'b', b'c']


# Generated at 2022-06-17 21:20:18.940304
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:20:29.794750
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None

# Generated at 2022-06-17 21:20:37.638211
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:20:44.576904
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:20:48.664288
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    body = '1234567890'
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in [body]),
        callback=None,
    )
    assert body == ''.join(stream)



# Generated at 2022-06-17 21:20:56.490830
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"name":"test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body



# Generated at 2022-06-17 21:21:00.372318
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:21:02.779455
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: print(x)
    )
    for chunk in stream:
        print(chunk)

# Generated at 2022-06-17 21:21:08.258505
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:21:17.249614
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello'
    chunked = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello'
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello'
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_

# Generated at 2022-06-17 21:21:36.257291
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:21:40.929635
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:21:44.609149
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:21:50.290207
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-17 21:21:56.595228
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: x,
    )
    assert list(stream) == [b'a', b'b', b'c']


# Generated at 2022-06-17 21:22:04.534036
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'abc'

    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'abc'

    body = 'abc'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:22:13.512938
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\x04\x00\x1d\x0f\x8a\x03\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'
    request.body = "hello world"
    compress_request(request, False)

# Generated at 2022-06-17 21:22:23.556698
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    import io
    import requests
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.argtypes import KeyValueArgType

    # Test for method __iter__ of class ChunkedUploadStream
    #
    # This is a unit test.
    # It tests the method __iter__ of class ChunkedUploadStream
    #
    # Arguments:
    #   stream: Iterable
    #   callback: Callable
    #
    # Return:
    #   Iterable[Union[str, bytes]]
    #
    # The method under test is __iter__.
    #
    # The method under test is a generator.
    # It yields values.
    # The values it yields are of type Union[str, bytes].
    #
    # This test asserts that the method under test yields the expected values.

# Generated at 2022-06-17 21:22:27.479128
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: None,
    )
    assert list(stream) == [b'a', b'b', b'c']


# Generated at 2022-06-17 21:22:32.978649
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:49.078085
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=['a', 'b', 'c'],
        callback=lambda x: x,
    )
    assert list(stream) == ['a', 'b', 'c']

# Generated at 2022-06-17 21:22:52.741056
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    def callback(chunk):
        print(chunk)
    stream = ChunkedUploadStream(stream=['a', 'b', 'c'], callback=callback)
    for chunk in stream:
        print(chunk)


# Generated at 2022-06-17 21:22:58.464837
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

# Generated at 2022-06-17 21:23:08.288934
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a":1}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a":1}'

    body = '{"a":1}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a":1}'

    body = '{"a":1}'
    body_read_callback = lambda x: x


# Generated at 2022-06-17 21:23:13.158304
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    compress_request(request, False)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:23:18.748038
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:23:21.846212
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=['a', 'b', 'c'],
        callback=lambda x: print(x)
    )
    assert list(stream) == ['a', 'b', 'c']


# Generated at 2022-06-17 21:23:31.159525
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.utils import body_read_callback
    from httpie.cli.utils import prepare_request_body
    from httpie.cli.utils import ChunkedUploadStream
    from httpie.cli.utils import ChunkedMultipartUploadStream
    from httpie.cli.utils import get_multipart_data_and_content_type
    from httpie.cli.utils import compress_request
    from httpie.cli.utils import get_multipart_data_and_content_type
    from httpie.cli.utils import compress_request
    from httpie.cli.utils import get_multipart_data_and_content_type
    from httpie.cli.utils import compress_request
    from httpie.cli.utils import get_multip

# Generated at 2022-06-17 21:23:34.077181
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(stream=['a', 'b', 'c'], callback=lambda x: x)
    assert list(stream) == ['a', 'b', 'c']


# Generated at 2022-06-17 21:23:36.822434
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(stream=iter(['a', 'b', 'c']), callback=lambda x: x)
    assert list(stream) == ['a', 'b', 'c']



# Generated at 2022-06-17 21:23:59.550776
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:24:04.590494
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == zlib.compress(b"test")
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:24:09.089403
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:24:15.573528
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)

# Generated at 2022-06-17 21:24:21.712297
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'

# Generated at 2022-06-17 21:24:31.305075
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, False)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-17 21:24:42.781793
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8a\x03\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, False)

# Generated at 2022-06-17 21:24:47.225560
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress('hello world'.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:24:53.656873
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline

# Generated at 2022-06-17 21:25:03.271412
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request_body

# Generated at 2022-06-17 21:25:25.044860
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import parse_items
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN
    from httpie.utils import get_response_type
    from httpie.utils import get_response_type_raw
    from httpie.utils import is_json
    from httpie.utils import is_text
    from httpie.utils import is_xml
    from httpie.utils import super_len
    from httpie.utils import super_len_iter
    from httpie.utils import super_len_iter_raw


# Generated at 2022-06-17 21:25:32.356530
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"name":"test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = '{"name":"test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'{"name":"test"}'

    body = '{"name":"test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None

# Generated at 2022-06-17 21:25:37.676118
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.callback == body_read_callback
    assert result.stream == ('test',)

    body = 'test'
    body_read_callback = lambda x: x
    content_length_

# Generated at 2022-06-17 21:25:41.616739
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:25:50.306998
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    compress_request(request, True)

# Generated at 2022-06-17 21:25:57.888219
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    compress_request(request, True)
    assert request.body == zlib.compress("Hello World".encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:26:06.967931
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello"
    compress_request(request, True)

# Generated at 2022-06-17 21:26:10.082140
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\xf5'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:26:15.991856
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:26:18.641291
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {'a': 'b'}
    boundary = 'boundary'
    content_type = 'content_type'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert data.content_type == 'multipart/form-data; boundary=boundary'
    assert content_type == 'multipart/form-data; boundary=boundary'

# Generated at 2022-06-17 21:26:42.625974
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)

# Generated at 2022-06-17 21:26:52.002748
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == body
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == body
    body = 'test'

# Generated at 2022-06-17 21:27:00.158099
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'
    request.body = 'test'
    compress

# Generated at 2022-06-17 21:27:06.327938
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02M\x01\x14\x00\x9b\x04\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'