

# Generated at 2022-06-17 21:17:35.213450
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert isinstance(result, ChunkedUploadStream)
    assert result.callback == body_read_callback
    assert list(result.stream) == [body.encode()]
    offline = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)

# Generated at 2022-06-17 21:17:41.989907
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'abc'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\x00\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:17:48.669537
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\x02\x00\x01\x05\x00\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:17:59.731317
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from io import BytesIO
    body = BytesIO(b'hello world')
    body_read_callback = lambda chunk: print(chunk)
    body = prepare_request_body(body, body_read_callback)
    assert body.read() == b'hello world'
    assert body.read() == b''
    body.seek(0)
    assert body.read() == b'hello world'
    body = prepare_request_body(body, body_read_callback, chunked=True)
    assert body.read() == b'hello world'
    assert body.read() == b''
    body.seek(0)
    assert body.read() == b'hello world'
    body = prepare_request_body(body, body_read_callback, offline=True)
    assert body == b'hello world'
   

# Generated at 2022-06-17 21:18:04.474720
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'



# Generated at 2022-06-17 21:18:15.149351
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"name": "httpie"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"name": "httpie"}'

    body = '{"name": "httpie"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"name": "httpie"}'

    body = '{"name": "httpie"}'
    body

# Generated at 2022-06-17 21:18:24.932891
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    import json
    import requests
    from requests_toolbelt import MultipartEncoder

    def test_callback(chunk):
        print(chunk)

    body = '{"a": "b"}'
    body_read_callback = test_callback
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == body

    body = io.StringIO('{"a": "b"}')
    body_read_callback = test_callback
    content_length_header_value = None
    chunked = False
    offline = False

# Generated at 2022-06-17 21:18:34.620716
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartEncoder
    from httpie.cli.dicts import ChunkedUploadStream
    from httpie.cli.dicts import ChunkedMultipartUploadStream
    from httpie.cli.dicts import prepare_request_body
    from httpie.cli.dicts import get_multipart_data_and_content_type
    from httpie.cli.dicts import compress_request
    from httpie.cli.dicts import test_ChunkedUploadStream___iter__
    from httpie.cli.dicts import test_ChunkedMultipartUploadStream___iter__
    from httpie.cli.dicts import test_prepare_request

# Generated at 2022-06-17 21:18:41.299364
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:18:51.108597
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"test": "test"}'

    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"test": "test"}'

    body = '{"test": "test"}'

# Generated at 2022-06-17 21:19:00.832387
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())

# Generated at 2022-06-17 21:19:02.997987
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=['a', 'b', 'c'],
        callback=lambda x: x,
    )
    assert list(stream) == ['a', 'b', 'c']

# Generated at 2022-06-17 21:19:08.116292
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: print(x)
    )
    assert list(stream) == [b'a', b'b', b'c']

# Generated at 2022-06-17 21:19:17.237360
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:19:27.441161
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for case of offline
    body = "test"
    body_read_callback = lambda x: x
    offline = True
    chunked = False
    content_length_header_value = None
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    # Test for case of chunked
    body = "test"
    body_read_callback = lambda x: x
    offline = False
    chunked = True
    content_length_header_value = None
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    # Test for case of file-like object
    body = "test"
    body_read_callback = lambda x: x
    offline = False
   

# Generated at 2022-06-17 21:19:38.189510
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from httpie.cli.dicts import RequestDataDict
    from requests_toolbelt import MultipartEncoder
    import io
    import os
    import sys

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)

# Generated at 2022-06-17 21:19:42.323187
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == zlib.compress('hello world'.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:19:48.074505
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict({'a': 'b'})
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=---------------------------7dd22b037d4e8'
    assert data.to_string() == '--' + data.boundary_value + '\r\nContent-Disposition: form-data; name="a"\r\n\r\n' + 'b' + '\r\n--' + data.boundary_value + '--\r\n'

# Generated at 2022-06-17 21:20:00.263123
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    data = MultipartRequestDataDict()
    data['a'] = 'b'
    encoder = MultipartEncoder(
        fields=data.items(),
        boundary='boundary',
    )
    stream = ChunkedMultipartUploadStream(encoder)
    assert stream.chunk_size == 102400
    assert stream.encoder == encoder
    assert list(stream) == [b'--boundary\r\nContent-Disposition: form-data; name="a"\r\n\r\nb\r\n--boundary--\r\n']

# Generated at 2022-06-17 21:20:06.576594
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:20:18.643801
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    import json
    import os
    import tempfile
    import unittest

    from httpie.cli.dicts import MultipartRequestDataDict, RequestDataDict

    class TestPrepareRequestBody(unittest.TestCase):
        def test_prepare_request_body_str(self):
            body = 'body'
            self.assertEqual(
                prepare_request_body(body, lambda x: x),
                body
            )

        def test_prepare_request_body_bytes(self):
            body = b'body'
            self.assertEqual(
                prepare_request_body(body, lambda x: x),
                body
            )

        def test_prepare_request_body_io(self):
            body = io.BytesIO(b'body')

# Generated at 2022-06-17 21:20:23.626633
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-17 21:20:28.102282
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

# Generated at 2022-06-17 21:20:37.388259
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict(
        {'name': 'value', 'name2': 'value2'}
    )
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=---------------------------735323031399963166993862150'
    assert data.boundary_value == '---------------------------735323031399963166993862150'
    assert data.fields == [('name', 'value'), ('name2', 'value2')]

# Generated at 2022-06-17 21:20:41.792673
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:20:47.369698
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress("hello world".encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:21:01.003254
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '47'


# Generated at 2022-06-17 21:21:03.959850
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "hello world"


# Generated at 2022-06-17 21:21:13.518556
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, False)
    assert request.body == 'hello world'
    assert 'Content-Encoding' not in request.headers
    assert 'Content-Length' not in request.headers

# Generated at 2022-06-17 21:21:23.947330
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:21:34.035824
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00'

# Generated at 2022-06-17 21:21:38.979815
# Unit test for function compress_request
def test_compress_request():
    import requests
    import zlib
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))
    assert request.body == zlib.compress(request.body.encode())

# Generated at 2022-06-17 21:21:43.733599
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello world"
    request.headers = {}
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:21:49.298222
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:21:58.996695
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:22:09.866369
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for function prepare_request_body
    # Test for case 1: body is a string
    body = 'Hello World'
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    content_length_header_value = None
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == body

    # Test for case 2: body is a bytes
    body = b'Hello World'
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    content_length_header_value = None

# Generated at 2022-06-17 21:22:20.891295
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert isinstance(prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline), ChunkedUploadStream)
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body.encode()
    body = {'test': 'test'}

# Generated at 2022-06-17 21:22:26.164430
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:22:35.805612
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for function prepare_request_body
    # Test for case 1: body is a string
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline
    )
    assert result == body

    # Test for case 2: body is a bytes
    body = b'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False

# Generated at 2022-06-17 21:22:39.404686
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:22:59.635179
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict(
        {
            'file': (
                'test.txt',
                'content',
                'text/plain',
            ),
            'field': 'value',
        }
    )
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=--------------------------8c8b8d3b3b3c6f8d'

# Generated at 2022-06-17 21:23:06.111011
# Unit test for function compress_request
def test_compress_request():
    import requests
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1a\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:23:09.647680
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == zlib.compress(b'test')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-17 21:23:21.119610
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'
   

# Generated at 2022-06-17 21:23:30.900321
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, True)

# Generated at 2022-06-17 21:23:34.260508
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-17 21:23:43.631635
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)

# Generated at 2022-06-17 21:23:50.409979
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline).callback('test') == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_

# Generated at 2022-06-17 21:24:00.640480
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '32'

# Generated at 2022-06-17 21:24:07.516922
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '25'

# Generated at 2022-06-17 21:24:20.665810
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:24:29.403801
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\x02\x00\x01\x05\x00\x00\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '15'

# Generated at 2022-06-17 21:24:38.792036
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'
    request.body = 'test'
    compress_request(request, False)
    assert request.body == 'test'
    assert 'Content-Encoding' not in request.headers
    assert 'Content-Length' not in request.headers

# Generated at 2022-06-17 21:24:44.935782
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xccM\x01\x00\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:24:51.103624
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == body
    assert type(result) == str

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )

# Generated at 2022-06-17 21:25:01.220731
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xccMU(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '33'

# Generated at 2022-06-17 21:25:09.719658
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:25:19.317807
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:25:24.708021
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02\x82\x01\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:25:29.464160
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:25:43.053542
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request_body

# Generated at 2022-06-17 21:25:49.982642
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:25:59.682341
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:26:07.054570
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'
    request.body = "test"
    compress_request(request, False)
    assert request.body == "test"
    assert 'Content-Encoding' not in request.headers
    assert 'Content-Length' not in request.headers

# Generated at 2022-06-17 21:26:17.986039
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\x01\x00\x1a\x04\x88\x1a\x05'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '27'

    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, False)

# Generated at 2022-06-17 21:26:23.630249
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:26:28.406577
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:26:36.115443
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:26:42.400273
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:26:46.880632
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:27:02.186957
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:27:08.026038
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'