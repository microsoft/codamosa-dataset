

# Generated at 2022-06-17 21:17:26.810726
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:17:35.375563
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import io
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder

# Generated at 2022-06-17 21:17:47.382360
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.callback('hello') == 'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None

# Generated at 2022-06-17 21:17:57.721420
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart

# Generated at 2022-06-17 21:18:07.385559
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.compat import urlopen
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.constants import CONTENT_TYPE_JSON
    from httpie.cli.constants import CONTENT_TYPE_FORM
    from httpie.cli.constants import CONTENT_TYPE_MULTIPART
    from httpie.cli.constants import CONTENT_TYPE_URLENCODED
    from httpie.cli.constants import CONTENT_TYPE_TEXT
    from httpie.cli.constants import CONTENT_TYPE_OCTET_STREAM
    from httpie.cli.constants import CONTENT_TYPE_ANY
    from httpie.cli.constants import CONTENT

# Generated at 2022-06-17 21:18:17.198302
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = b"hello world"
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

# Generated at 2022-06-17 21:18:27.171157
# Unit test for function compress_request
def test_compress_request():
    import requests
    import zlib
    import io
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == zlib.compress(b"hello world")
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

    request = requests.PreparedRequest()
    request.body = io.BytesIO(b"hello world")
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == zlib.compress(b"hello world")
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request

# Generated at 2022-06-17 21:18:34.410134
# Unit test for function prepare_request_body
def test_prepare_request_body():
    def body_read_callback(chunk):
        print(chunk)

    body = 'hello world'
    body = prepare_request_body(body, body_read_callback)
    assert body == 'hello world'

    body = b'hello world'
    body = prepare_request_body(body, body_read_callback)
    assert body == b'hello world'

    body = io.BytesIO(b'hello world')
    body = prepare_request_body(body, body_read_callback)
    assert body.read() == b'hello world'

    body = io.StringIO('hello world')
    body = prepare_request_body(body, body_read_callback)
    assert body.read() == 'hello world'

    body = RequestDataDict({'hello': 'world'})
    body = prepare_

# Generated at 2022-06-17 21:18:44.579184
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder.MultipartEncoder
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.Multipart

# Generated at 2022-06-17 21:18:53.038501
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    from requests_toolbelt.multipart import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPGSSAPIAuth
    from httpie.plugins.builtin import HTTPGSSAPIKeytabAuth
    from httpie.plugins.builtin import HTTPNegotiateAuth
    from httpie.plugins.builtin import HTTPAuthPlugin

# Generated at 2022-06-17 21:19:02.858307
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {'a': 'b'}
    boundary = 'boundary'
    content_type = 'content_type'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert content_type == 'content_type; boundary=boundary'
    assert data.boundary_value == 'boundary'
    assert data.fields == [('a', 'b')]

# Generated at 2022-06-17 21:19:12.990871
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.callback(result.stream.__next__()) == "test"

    body = "test"
    body_read_callback = lambda x: x

# Generated at 2022-06-17 21:19:18.449015
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare

# Generated at 2022-06-17 21:19:26.894130
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:19:31.447030
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda chunk: print(chunk)
    )
    assert stream.__iter__() == ['a', 'b', 'c']

# Generated at 2022-06-17 21:19:37.860723
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:19:42.650449
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02\x82\x01\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:19:45.479279
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:19:50.149292
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: print(x)
    )
    for chunk in stream:
        print(chunk)


# Generated at 2022-06-17 21:20:01.703107
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    import requests
    import requests.utils
    import requests.adapters
    import requests.packages.urllib3.util.url
    import requests.packages.urllib3.util.retry
    import requests.packages.urllib3.response
    import requests.packages.urllib3.poolmanager
    import requests.packages.urllib3.connectionpool
    import requests.packages.urllib3.filepost
    import requests.packages.urllib3.contrib.pyopenssl
    import requests.packages.urllib3.contrib.socks
    import requests.packages.urllib3.exceptions
   

# Generated at 2022-06-17 21:20:14.047716
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    encoder = MultipartEncoder(
        fields={'field0': 'value', 'field1': 'value', 'field2': 'value'}
    )
    chunked_encoder = ChunkedMultipartUploadStream(encoder)
    for chunk in chunked_encoder:
        print(chunk)


# Generated at 2022-06-17 21:20:18.512640
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from unittest.mock import MagicMock
    from unittest.mock import call
    from unittest.mock import patch

    mock_callback = MagicMock()
    mock_stream = [b'a', b'b', b'c']

    chunked_upload_stream = ChunkedUploadStream(mock_stream, mock_callback)
    for chunk in chunked_upload_stream:
        pass

    mock_callback.assert_has_calls([call(b'a'), call(b'b'), call(b'c')])


# Generated at 2022-06-17 21:20:25.181215
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:20:33.297210
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = True

# Generated at 2022-06-17 21:20:39.755157
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '25'

# Generated at 2022-06-17 21:20:50.130833
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder.MultipartEncoder
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.Mult

# Generated at 2022-06-17 21:21:01.593820
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from httpie.cli.dicts import MultipartRequestDataDict
    from requests_toolbelt import MultipartEncoder
    data = MultipartRequestDataDict(
        {
            'foo': 'bar',
            'baz': 'qux',
            'file': (
                'httpie.py',
                open('httpie.py', 'rb'),
                'application/x-python',
            )
        }
    )
    encoder = MultipartEncoder(
        fields=data.items(),
        boundary=None,
    )
    stream = ChunkedMultipartUploadStream(encoder=encoder)
    for chunk in stream:
        print(chunk)

# Generated at 2022-06-17 21:21:08.983279
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.compression import ChunkedMultipartUploadStream
    data = MultipartRequestDataDict()
    data['file'] = ('file.txt', 'content')
    encoder = MultipartEncoder(fields=data.items())
    stream = ChunkedMultipartUploadStream(encoder=encoder)
    assert stream.__iter__() is not None

# Generated at 2022-06-17 21:21:15.542376
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1a\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '19'

# Generated at 2022-06-17 21:21:21.328978
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    data = MultipartRequestDataDict()
    data['file'] = ('test.txt', 'test')
    encoder = MultipartEncoder(fields=data.items())
    stream = ChunkedMultipartUploadStream(encoder=encoder)
    assert stream.__iter__() == encoder.__iter__()

# Generated at 2022-06-17 21:21:38.438129
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:21:43.530329
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:21:47.673857
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == body


# Generated at 2022-06-17 21:21:57.766705
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02\x82\x01\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:00.336057
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:07.036753
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:22:14.515327
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict([('a', 'b')])
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=%s' % data.boundary_value
    data, content_type = get_multipart_data_and_content_type(data, content_type='multipart/form-data')
    assert content_type == 'multipart/form-data; boundary=%s' % data.boundary_value
    data, content_type = get_multipart_data_and_content_type(data, content_type='multipart/form-data; boundary=123')
    assert content_type == 'multipart/form-data; boundary=123'
    data, content

# Generated at 2022-06-17 21:22:20.758013
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:22:26.032947
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'abc'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:22:31.640214
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == zlib.compress(b'hello world')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'



# Generated at 2022-06-17 21:22:52.607857
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.stream.__next__() == body.encode()
    body = io.BytesIO(body.encode())
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.stream.__next__() == body.read()
   

# Generated at 2022-06-17 21:23:02.621210
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline).stream.__next__() == b'test'

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
   

# Generated at 2022-06-17 21:23:08.325813
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:23:15.399752
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\xf5'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:23:20.273351
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {'a': 'b'}
    boundary = 'boundary'
    content_type = 'content_type'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert data.boundary_value == boundary
    assert content_type == 'content_type; boundary=boundary'

# Generated at 2022-06-17 21:23:23.508484
# Unit test for function compress_request
def test_compress_request():
    request = requests.Request('GET', 'http://httpbin.org/get')
    request = request.prepare()
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '0'

# Generated at 2022-06-17 21:23:31.045177
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'
    body = RequestDataDict({'hello': 'world'})

# Generated at 2022-06-17 21:23:35.241770
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body


# Generated at 2022-06-17 21:23:44.755842
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from io import BytesIO
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import parse_items
    from httpie.compat import is_windows
    from httpie.context import Environment
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.plugins.builtin import HTTPTokenAuth
    from httpie.plugins.builtin import HTTPAuthPlugin
    from httpie.plugins.builtin import HTTPPassAuth
    from httpie.plugins.builtin import HTTPDigestAuth
    from httpie.plugins.builtin import HTTPProxyAuth

# Generated at 2022-06-17 21:23:48.580243
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-17 21:23:58.781846
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:24:04.858462
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-17 21:24:12.738922
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from io import BytesIO
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict

# Generated at 2022-06-17 21:24:19.847074
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'



# Generated at 2022-06-17 21:24:28.255321
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xccM\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-17 21:24:33.609767
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:24:40.494189
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:24:45.005850
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": 1}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body


# Generated at 2022-06-17 21:24:51.154808
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict(
        {
            'a': 'b',
            'c': 'd',
        }
    )
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=--------------------------788766035852398982418074'
    assert data.content_type == 'multipart/form-data; boundary=--------------------------788766035852398982418074'

# Generated at 2022-06-17 21:25:00.981813
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\r\x00\xbd\xf8\x89\xa7\x05\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:25:17.722285
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:25:25.688391
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'hello'
    request.headers['Content-Length'] = '5'
    compress_request(request, True)
    assert request.body == zlib.compress(b'hello')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'
    request = requests.PreparedRequest()
    request.body = b'hello'
    request.headers['Content-Length'] = '5'
    compress_request(request, False)
    assert request.body == b'hello'
    assert 'Content-Encoding' not in request.headers
    assert request.headers['Content-Length'] == '5'

# Generated at 2022-06-17 21:25:28.729451
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: x,
    )
    assert list(stream) == [b'a', b'b', b'c']



# Generated at 2022-06-17 21:25:35.071881
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:25:38.718342
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: x,
    )
    assert list(stream) == [b'a', b'b', b'c']


# Generated at 2022-06-17 21:25:42.321259
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:25:48.596892
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:25:59.533545
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9cKLJ\xcb\xcf\x07\x00\x02M\xccMU(I-.Q\x04\x00\x1c\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '29'

# Generated at 2022-06-17 21:26:04.517265
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda chunk: print(chunk.decode())
    )
    assert list(stream) == [b'a', b'b', b'c']


# Generated at 2022-06-17 21:26:08.519692
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1e\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:26:35.381116
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict

# Generated at 2022-06-17 21:26:40.717434
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:26:46.019087
# Unit test for function prepare_request_body
def test_prepare_request_body():
    data = {'a': 'b'}
    body = prepare_request_body(data, None)
    assert body == 'a=b'

    data = {'a': 'b'}
    body = prepare_request_body(data, None, chunked=True)
    assert isinstance(body, ChunkedUploadStream)
    assert body.stream == ('a=b'.encode(),)

    data = {'a': 'b'}
    body = prepare_request_body(data, None, offline=True)
    assert body == 'a=b'

    data = {'a': 'b'}
    body = prepare_request_body(data, None, offline=True, chunked=True)
    assert body == 'a=b'

    data = {'a': 'b'}
    body = prepare_

# Generated at 2022-06-17 21:26:54.314498
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '25'

# Generated at 2022-06-17 21:26:59.583812
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello'
    request.headers = {'Content-Length': '5'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '30'