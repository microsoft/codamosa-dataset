

# Generated at 2022-06-17 21:17:29.148340
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:17:32.965694
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from io import BytesIO
    from unittest.mock import MagicMock

    callback = MagicMock()
    stream = BytesIO(b'abc')
    chunked_stream = ChunkedUploadStream(stream, callback)
    for chunk in chunked_stream:
        assert chunk == b'abc'
    callback.assert_called_once_with(b'abc')



# Generated at 2022-06-17 21:17:45.072219
# Unit test for function compress_request
def test_compress_request():
    import requests
    import zlib
    import json
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.cli.utils
    import httpie.cli.auth
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.builtin
    import httpie.plugins.built

# Generated at 2022-06-17 21:17:49.933077
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8a\x03\x00'

# Generated at 2022-06-17 21:17:56.285472
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:18:06.334969
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from io import BytesIO
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import parse_items
    from httpie.cli.utils import get_response_stream
    from httpie.compat import is_windows
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE_LEN
    from httpie.output.streams import write_binary_response
    from httpie.output.streams import write_response
    from httpie.output.streams import write_stream
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth

# Generated at 2022-06-17 21:18:16.494529
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:18:26.055958
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    import io
    import unittest
    from unittest.mock import MagicMock

    class TestChunkedUploadStream(unittest.TestCase):
        def test_ChunkedUploadStream___iter__(self):
            stream = io.BytesIO(b'abcdefghijklmnopqrstuvwxyz')
            callback = MagicMock()
            chunked_upload_stream = ChunkedUploadStream(stream, callback)
            for chunk in chunked_upload_stream:
                self.assertEqual(chunk, b'abcdefghijklmnopqrstuvwxyz')
            callback.assert_called_once_with(b'abcdefghijklmnopqrstuvwxyz')

    unittest.main()

# Generated at 2022-06-17 21:18:36.003253
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.callback == body_read_callback
    assert result.stream == (chunk.encode() for chunk in [body])
    offline = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body.encode()
   

# Generated at 2022-06-17 21:18:41.910746
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:18:53.741147
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: x,
    )
    assert [chunk.decode() for chunk in stream] == ['a', 'b', 'c']



# Generated at 2022-06-17 21:18:55.790690
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    data = '1234567890'
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in [data]),
        callback=lambda x: x
    )
    assert list(stream) == [data.encode()]


# Generated at 2022-06-17 21:18:59.701484
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=['a', 'b', 'c'],
        callback=lambda x: print(x)
    )
    assert list(stream) == ['a', 'b', 'c']

# Generated at 2022-06-17 21:19:05.732465
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:19:08.677997
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:19:15.785318
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    import io
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartEncoder
    from httpie.cli.dicts import ChunkedUploadStream
    from httpie.cli.dicts import ChunkedMultipartUploadStream
    from httpie.cli.dicts import prepare_request_body
    from httpie.cli.dicts import get_multipart_data_and_content_type
    from httpie.cli.dicts import compress_request
    from httpie.cli.dicts import test_ChunkedUploadStream___iter__
    from httpie.cli.dicts import test_ChunkedMultipartUploadStream___iter__
    from httpie.cli.dicts import test_

# Generated at 2022-06-17 21:19:26.150349
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"name":"test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert isinstance(prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline), ChunkedUploadStream)
    body = io.StringIO(body)
    assert isinstance(prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline), ChunkedUploadStream)
    offline = True

# Generated at 2022-06-17 21:19:37.695013
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH,\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'
    request.body = 'Hello World'
    request.headers = {}
    compress_request(request, False)
    assert request.body == 'Hello World'
    assert 'Content-Encoding' not in request.headers

# Generated at 2022-06-17 21:19:42.089329
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'
    assert request.body == b'x\x9cK\xca\x00\x02\x05\x00\x00\x00'

# Generated at 2022-06-17 21:19:45.066707
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: x,
    )
    assert list(stream) == [b'a', b'b', b'c']

# Generated at 2022-06-17 21:19:55.260365
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'
    assert request.body == b'x\x9cK\xca\x00\x02\x00\x00\x00'

# Generated at 2022-06-17 21:20:03.133832
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcf\x07\x00\x06,\x02\x15'

# Generated at 2022-06-17 21:20:12.423207
# Unit test for function compress_request
def test_compress_request():
    import pytest
    import requests
    from httpie.compression import compress_request

    def test_compress_request_helper(request_body, always, expected_body, expected_headers):
        request = requests.Request(
            method='POST',
            url='http://httpbin.org/post',
            data=request_body,
        )
        prepared_request = request.prepare()
        compress_request(prepared_request, always)
        assert prepared_request.body == expected_body
        assert prepared_request.headers == expected_headers


# Generated at 2022-06-17 21:20:17.894713
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {'Content-Length': str(len(request.body))}
    compress_request(request, False)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))
    assert request.body != "Hello World"
    assert request.body == zlib.compress(b"Hello World")
    request.body = "Hello World"
    request.headers = {'Content-Length': str(len(request.body))}
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:20:22.529128
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:20:29.642932
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, False)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:20:36.536572
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:20:43.968646
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline

# Generated at 2022-06-17 21:20:52.371802
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:21:00.000816
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:21:14.602262
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
   

# Generated at 2022-06-17 21:21:23.785655
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:21:34.732933
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare

# Generated at 2022-06-17 21:21:41.999249
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from io import BytesIO
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.constants import DEFAULT_CHUNK_SIZE
    from httpie.cli.constants import CONTENT_TYPE_JSON
    from httpie.cli.constants import CONTENT_TYPE_FORM
    from httpie.cli.constants import CONTENT_TYPE_MULTIPART
    from httpie.cli.constants import CONTENT_TYPE_URLENCODED
    from httpie.cli.constants import CONTENT_TYPE_TEXT
    from httpie.cli.constants import CONTENT_TYPE_OCTET_STREAM
    from httpie.cli.constants import CONTENT_TYPE_XML
    from httpie.cli.constants import CONTENT_TYPE_YAML

# Generated at 2022-06-17 21:21:49.367447
# Unit test for function compress_request
def test_compress_request():
    import requests
    import zlib
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import Multipart

# Generated at 2022-06-17 21:21:58.499224
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:22:01.450833
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:22:12.190992
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)

# Generated at 2022-06-17 21:22:19.918697
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:22:28.308510
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xed\x9d\x0b\x8a\x00\x00\x00'

# Generated at 2022-06-17 21:22:49.473876
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '30'
    request.body = "hello"
    request.headers = {}
    compress_request(request, True)

# Generated at 2022-06-17 21:22:56.909161
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1b\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:23:07.157015
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request_body

# Generated at 2022-06-17 21:23:18.839132
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)

# Generated at 2022-06-17 21:23:22.998600
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:23:25.855469
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

# Generated at 2022-06-17 21:23:34.267785
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:23:39.790541
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\x04\x00\x02\x82\x01\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'


# Generated at 2022-06-17 21:23:44.616092
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:23:50.093501
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:24:18.236638
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:24:21.909482
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == zlib.compress(b'hello world')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:24:32.951703
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare

# Generated at 2022-06-17 21:24:39.258149
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:24:48.209382
# Unit test for function compress_request
def test_compress_request():
    import requests
    import httpie.cli.argtypes
    import httpie.cli.dicts
    import httpie.cli.output
    import httpie.cli.sessions
    import httpie.cli.streams
    import httpie.cli.utils
    import httpie.compat
    import httpie.core
    import httpie.downloads
    import httpie.input
    import httpie.output
    import httpie.plugins
    import httpie.status
    import httpie.streams
    import httpie.utils
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__
    import httpie.__main__

# Generated at 2022-06-17 21:25:00.208574
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '30'

# Generated at 2022-06-17 21:25:06.173761
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:25:11.916977
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:25:18.563623
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:25:27.199683
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict({'a': 'b'})
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=--------------------------934231659237912509570497'
    assert data.boundary == '--------------------------934231659237912509570497'
    assert data.fields == [('a', 'b')]

    data = MultipartRequestDataDict({'a': 'b'})
    data, content_type = get_multipart_data_and_content_type(data, boundary='123')
    assert content_type == 'multipart/form-data; boundary=123'
    assert data.boundary == '123'

# Generated at 2022-06-17 21:26:00.735430
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    assert prepare_request_body(body, None) == body
    assert prepare_request_body(body, None, chunked=True) != body
    assert prepare_request_body(body, None, chunked=True) != body
    assert prepare_request_body(body, None, chunked=True) != body
    assert prepare_request_body(body, None, chunked=True) != body
    assert prepare_request_body(body, None, chunked=True) != body
    assert prepare_request_body(body, None, chunked=True) != body
    assert prepare_request_body(body, None, chunked=True) != body
    assert prepare_request_body(body, None, chunked=True) != body

# Generated at 2022-06-17 21:26:05.932139
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:26:09.537838
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:26:16.350977
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c+\xce\xcfMU(\xca\xccK\x07\x00\x1e\x85\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '19'

# Generated at 2022-06-17 21:26:23.632894
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '25'

# Generated at 2022-06-17 21:26:28.004876
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '26'

# Generated at 2022-06-17 21:26:36.236038
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:26:42.213968
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'
    assert request.body == b'x\x9cK\xca\x00\x02\x00\x00\x00'

# Generated at 2022-06-17 21:26:46.533728
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:26:56.452491
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True