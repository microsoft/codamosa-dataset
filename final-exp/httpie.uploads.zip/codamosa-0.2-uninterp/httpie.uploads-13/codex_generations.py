

# Generated at 2022-06-17 21:17:26.057524
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    def callback(chunk):
        print(chunk)
    stream = ChunkedUploadStream(stream=["a", "b", "c"], callback=callback)
    for chunk in stream:
        print(chunk)


# Generated at 2022-06-17 21:17:35.241686
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict({'a': 'b'})
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=--------------------------8a5e5d5c5dacf9a2'
    assert data.boundary_value == '--------------------------8a5e5d5c5dacf9a2'
    assert data.fields == [('a', 'b')]
    assert data.content_type == 'multipart/form-data; boundary=--------------------------8a5e5d5c5dacf9a2'

# Generated at 2022-06-17 21:17:41.991102
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:17:47.864627
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xccM\x02\x00\x04\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:17:58.160884
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"name":"test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"name":"test"}'

    body = '{"name":"test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"name":"test"}'

    body = '{"name":"test"}'
    body_read_callback = lambda x: x


# Generated at 2022-06-17 21:18:04.702536
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xccM\x01\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:18:15.233675
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    from io import BytesIO
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.exceptions import ParseError
    from httpie.cli.parser import parse_items
    from httpie.cli.argtypes import KeyValueArgType

# Generated at 2022-06-17 21:18:25.016510
# Unit test for function compress_request
def test_compress_request():
    import requests
    import json
    import zlib
    import httpie.cli.dicts
    import httpie.cli.argtypes
    import httpie.cli.exceptions
    import httpie.plugins
    import httpie.plugins.builtin
    import httpie.plugins.builtin.core
    import httpie.plugins.builtin.downloads
    import httpie.plugins.builtin.form
    import httpie.plugins.builtin.generic
    import httpie.plugins.builtin.help
    import httpie.plugins.builtin.http
    import httpie.plugins.builtin.prompt
    import httpie.plugins.builtin.sessions
    import httpie.plugins.builtin.stream
    import httpie.plugins.builtin.style
    import httpie.plugins.builtin.upload
    import httpie

# Generated at 2022-06-17 21:18:34.622984
# Unit test for function compress_request
def test_compress_request():
    import requests
    import json
    import zlib
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import JSONDataDict
    from httpie.cli.dicts import FormDataDict
    from httpie.cli.dicts import PlainDataDict
    from httpie.cli.dicts import FileDataDict
    from httpie.cli.dicts import FileBytesDataDict
    from httpie.cli.dicts import FileStreamDataDict
    from httpie.cli.dicts import FileMultiDict
    from httpie.cli.dicts import FileMultiStreamDict
    from httpie.cli.dicts import FileMultiBytesDict
    from httpie.cli.dicts import FileMultiPathD

# Generated at 2022-06-17 21:18:44.743364
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)

# Generated at 2022-06-17 21:18:54.017975
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02M\x01\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-17 21:19:01.813753
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:19:06.186694
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = [b'a', b'b', b'c']
    chunked_upload_stream = ChunkedUploadStream(stream, lambda x: x)
    assert list(chunked_upload_stream) == stream


# Generated at 2022-06-17 21:19:11.147970
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(b'hello world')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:19:15.843476
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'hello world'
    compress_request(request, True)
    assert request.body == zlib.compress(b'hello world')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '20'

# Generated at 2022-06-17 21:19:26.234538
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    result

# Generated at 2022-06-17 21:19:33.194518
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(b'hello world')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:19:39.393863
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x01'

# Generated at 2022-06-17 21:19:45.631758
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)

# Generated at 2022-06-17 21:19:56.134417
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert isinstance(prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline), ChunkedUploadStream)
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body.encode()
    body = io.BytesIO(body.encode())

# Generated at 2022-06-17 21:20:10.568408
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None

# Generated at 2022-06-17 21:20:17.595820
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:20:26.039929
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict(
        {
            'name': 'value',
            'name2': 'value2',
            'name3': 'value3',
        }
    )
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=---------------------------8d8f0d6c9e9e9f6d'
    assert data.boundary_value == '---------------------------8d8f0d6c9e9e9f6d'
    assert data.fields == [
        ('name', 'value'),
        ('name2', 'value2'),
        ('name3', 'value3'),
    ]

# Generated at 2022-06-17 21:20:30.495126
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:20:40.607584
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict(
        [('key1', 'value1'), ('key2', 'value2')],
    )
    data, content_type = get_multipart_data_and_content_type(data)
    assert data.boundary_value == content_type.split(';')[1].split('=')[1]

# Generated at 2022-06-17 21:20:46.165187
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    assert result == body


# Generated at 2022-06-17 21:20:53.956291
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert isinstance(result, ChunkedUploadStream)
    assert result.callback == body_read_callback
    assert result.stream == (chunk.encode() for chunk in [body])
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False


# Generated at 2022-06-17 21:20:56.380236
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, True)
    assert request.body == zlib.compress(b"hello world")
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:21:00.557254
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:21:06.428250
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'{"a": "b"}'

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None


# Generated at 2022-06-17 21:21:22.475960
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:21:31.021883
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '26'

# Generated at 2022-06-17 21:21:36.661346
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcf\x07\x00\x04\x04\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:21:39.738096
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:21:45.227610
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:21:54.029358
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)

# Generated at 2022-06-17 21:22:04.064929
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)

# Generated at 2022-06-17 21:22:13.181925
# Unit test for function compress_request
def test_compress_request():
    import requests
    import zlib
    import json
    import io
    import os
    import sys
    import pytest
    from httpie.cli.dicts import MultipartRequestDataDict, RequestDataDict
    from httpie.cli.argtypes import KeyValueArgType
    from httpie.compression import compress_request
    from httpie.plugins import plugin_manager
    from httpie.plugins.builtin import HTTPBasicAuth
    from httpie.context import Environment
    from httpie.output.streams import get_binary_stream

    env = Environment(
        stdin=get_binary_stream('binary', isatty=False),
        stdout=get_binary_stream('binary', isatty=False),
        stderr=get_binary_stream('binary', isatty=False),
    )

    plugin

# Generated at 2022-06-17 21:22:23.511867
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "abc"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "abc"

    body = "abc"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "abc"

    body = "abc"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:22:31.051370
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:22:51.490135
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
   

# Generated at 2022-06-17 21:22:56.908610
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:23:02.065092
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:23:07.613200
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9c+I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:23:19.520071
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:23:24.118813
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:23:34.001184
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for function prepare_request_body
    # Test for chunked upload
    body = "1234567890"
    body_read_callback = lambda x: x
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, chunked, offline)
    assert isinstance(result, ChunkedUploadStream)
    # Test for offline
    body = "1234567890"
    body_read_callback = lambda x: x
    chunked = False
    offline = True
    result = prepare_request_body(body, body_read_callback, chunked, offline)
    assert result == body
    # Test for file-like object
    body = io.BytesIO("1234567890".encode())
    body_read_callback = lambda x: x

# Generated at 2022-06-17 21:23:36.902491
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:23:43.257877
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00\x03\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'

# Generated at 2022-06-17 21:23:50.186973
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict({'a': 'b'})
    boundary = 'boundary'
    content_type = 'content_type'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert data.boundary_value == boundary
    assert content_type == 'content_type; boundary=boundary'
    data = MultipartRequestDataDict({'a': 'b'})
    boundary = 'boundary'
    content_type = 'content_type; boundary=boundary'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert data.boundary_value == boundary
    assert content_type == 'content_type; boundary=boundary'
    data

# Generated at 2022-06-17 21:24:15.523870
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"key": "value"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"key": "value"}'

    body = '{"key": "value"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.callback == body_read_callback
    assert result.stream == ('{"key": "value"}'.encode(),)

   

# Generated at 2022-06-17 21:24:21.682944
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:24:28.822190
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:24:37.528847
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'
    assert request.body == b'x\x9c+\xcf\xcfM\xcd\xc9\xc9\x07\x00\x06,\x02\x15\x00\x00\x00'

# Generated at 2022-06-17 21:24:44.751424
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\x01\x00\x1a\x03\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:24:50.995120
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert prepare_request_body(b'', None) == b''
    assert prepare_request_body(b'', None, chunked=True) == b''
    assert prepare_request_body(b'', None, offline=True) == b''
    assert prepare_request_body(b'', None, chunked=True, offline=True) == b''

    assert prepare_request_body(b'', None, content_length_header_value=0) == b''
    assert prepare_request_body(b'', None, content_length_header_value=0, chunked=True) == b''
    assert prepare_request_body(b'', None, content_length_header_value=0, offline=True) == b''

# Generated at 2022-06-17 21:24:59.747869
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:25:10.892350
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for function prepare_request_body
    # Test for case 1: body is a string
    body = "test"
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    content_length_header_value = None
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    # Test for case 2: body is a bytes
    body = b"test"
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    content_length_header_value = None
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == b"test"

    #

# Generated at 2022-06-17 21:25:17.070316
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:25:25.795569
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'hello world'

    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request

# Generated at 2022-06-17 21:26:07.363386
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:26:14.442065
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:26:17.678467
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:26:22.730725
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:26:27.596793
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1b\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '18'

# Generated at 2022-06-17 21:26:32.591564
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:26:40.355388
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:26:43.758291
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8a\x03\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:26:47.649688
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict(
        {
            'a': 'b',
            'c': 'd',
        }
    )
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=--------------------------908737157969098124557983'
    assert data.to_string() == '''\
--------------------------908737157969098124557983
Content-Disposition: form-data; name="a"

b
--------------------------908737157969098124557983
Content-Disposition: form-data; name="c"

d
--------------------------908737157969098124557983--
'''

# Generated at 2022-06-17 21:26:59.623029
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert prepare_request_body('', None, None, False, False) == '', 'prepare_request_body() failed'
    assert prepare_request_body('', None, None, False, True) == '', 'prepare_request_body() failed'
    assert prepare_request_body('', None, None, True, False) == '', 'prepare_request_body() failed'
    assert prepare_request_body('', None, None, True, True) == '', 'prepare_request_body() failed'
    assert prepare_request_body(b'', None, None, False, False) == b'', 'prepare_request_body() failed'
    assert prepare_request_body(b'', None, None, False, True) == b'', 'prepare_request_body() failed'
    assert prepare_request_body