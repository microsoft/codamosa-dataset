

# Generated at 2022-06-17 21:17:24.948564
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda chunk: print(chunk)
    )
    assert next(stream) == b'a'
    assert next(stream) == b'b'
    assert next(stream) == b'c'


# Generated at 2022-06-17 21:17:32.995038
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {'a': 'b'}
    data, content_type = get_multipart_data_and_content_type(data)
    assert content_type == 'multipart/form-data; boundary=---------------------------7d44e178b0434'
    assert data.boundary_value == '---------------------------7d44e178b0434'
    assert data.fields == [('a', 'b')]

    data = {'a': 'b'}
    data, content_type = get_multipart_data_and_content_type(data, boundary='test')
    assert content_type == 'multipart/form-data; boundary=test'
    assert data.boundary_value == 'test'
    assert data.fields == [('a', 'b')]


# Generated at 2022-06-17 21:17:39.881574
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:17:46.217039
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:17:55.587265
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:18:01.917140
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:18:07.597009
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:18:17.344646
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00\x03\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00\x03'

# Generated at 2022-06-17 21:18:27.286013
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    offline = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    body = io.StringIO(body)

# Generated at 2022-06-17 21:18:34.458622
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    import json
    import os
    import tempfile

    from httpie.cli.dicts import MultipartRequestDataDict, RequestDataDict

    def test_prepare_request_body_with_string():
        body = 'test'
        body_read_callback = lambda x: x
        content_length_header_value = None
        chunked = False
        offline = False
        result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
        assert result == body

    def test_prepare_request_body_with_bytes():
        body = b'test'
        body_read_callback = lambda x: x
        content_length_header_value = None
        chunked = False
        offline = False
        result = prepare_request_

# Generated at 2022-06-17 21:18:43.119192
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=['a', 'b', 'c'],
        callback=lambda x: print(x)
    )
    assert list(stream) == ['a', 'b', 'c']

# Generated at 2022-06-17 21:18:48.852603
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\xf5'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-17 21:18:58.594720
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\x02\x00\x02\xe7\x04\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:19:02.696323
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:19:09.056609
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:19:14.012283
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello World'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:19:25.038878
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)

# Generated at 2022-06-17 21:19:32.407233
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00\x03\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'

# Generated at 2022-06-17 21:19:41.865149
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"name": "value"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False

    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    body = '{"name": "value"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False

    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"name": "value"}'

    body = '{"name": "value"}'
    body_read_callback = lambda x: x
    content

# Generated at 2022-06-17 21:19:47.470071
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'hello'
    compress_request(request, True)
    assert request.body == zlib.compress(b'hello')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'
    request.body = b'hello'
    compress_request(request, False)
    assert request.body == b'hello'
    assert 'Content-Encoding' not in request.headers
    assert 'Content-Length' not in request.headers

# Generated at 2022-06-17 21:19:56.717888
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:20:05.289041
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\x04\x00\x1d\x0b\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:20:09.879201
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:20:16.668896
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {'a': 'b'}
    boundary = 'boundary'
    content_type = 'content_type'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert data.boundary_value == boundary
    assert content_type == 'content_type; boundary=boundary'
    data = {'a': 'b'}
    boundary = 'boundary'
    content_type = 'content_type; boundary=boundary'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert data.boundary_value == boundary
    assert content_type == 'content_type; boundary=boundary'

# Generated at 2022-06-17 21:20:21.791842
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:20:28.884125
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:20:39.950386
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict

# Generated at 2022-06-17 21:20:50.129642
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:21:00.832670
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:21:06.607087
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for string
    body = "test"
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    content_length_header_value = None
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    # Test for bytes
    body = b"test"
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    content_length_header_value = None
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == b"test"

    # Test for file-like object
    body = io.BytesIO(b"test")
    body_

# Generated at 2022-06-17 21:21:23.913933
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for function prepare_request_body
    # Test for body is a string
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    # Test for body is a bytes
    body = b"test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    # Test for body is a file-like object
   

# Generated at 2022-06-17 21:21:34.732746
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:21:41.999379
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    body = '{"test": "test"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    body = '{"test": "test"}'
    body_read_callback = lambda x: x

# Generated at 2022-06-17 21:21:46.552231
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:21:54.767064
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.callback == body_read_callback
    assert result.stream == (chunk.encode() for chunk in [body])
    body = io.BytesIO(b'test')
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result.callback == body_

# Generated at 2022-06-17 21:22:04.949799
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from io import BytesIO
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict

    def body_read_callback(chunk):
        print('chunk:', chunk)

    # test for str
    body = 'test'
    body = prepare_request_body(body, body_read_callback)
    assert body == 'test'

    # test for bytes
    body = b'test'
    body = prepare_request_body(body, body_read_callback)
    assert body == b'test'

    # test for file-like object
    body = BytesIO(b'test')
    body = prepare_request_body(body, body_read_callback)

# Generated at 2022-06-17 21:22:13.755905
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:22:20.971626
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\r\x00\xbd\xf8\x89\xa2'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '29'

# Generated at 2022-06-17 21:22:25.643277
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:32.079160
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02M\x01\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-17 21:22:42.449979
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': str(len(request.body))}
    compress_request(request, True)
    assert request.body == zlib.compress(request.body.encode())
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == str(len(request.body))

# Generated at 2022-06-17 21:22:49.041854
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:57.237109
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:23:01.497590
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False

    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body


# Generated at 2022-06-17 21:23:10.219455
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a": "b"}'

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a": "b"}'

    body = '{"a": "b"}'

# Generated at 2022-06-17 21:23:14.375832
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:23:23.734733
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked=False
    offline=False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "test"
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked=True
    offline=False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "test"
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked=False
    offline=True

# Generated at 2022-06-17 21:23:29.601104
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:23:37.843396
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:23:43.428442
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {'Content-Length': str(len(request.body))}
    compress_request(request, False)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:23:58.644324
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\r\x00\xbd\x1a\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:24:05.610583
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '21'

# Generated at 2022-06-17 21:24:12.253872
# Unit test for function compress_request
def test_compress_request():
    import requests
    request = requests.Request('POST', 'http://httpbin.org/post', data='hello world')
    prepared_request = request.prepare()
    compress_request(prepared_request, True)
    assert prepared_request.headers['Content-Encoding'] == 'deflate'
    assert prepared_request.headers['Content-Length'] == '22'
    assert prepared_request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'

# Generated at 2022-06-17 21:24:20.107957
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:24:30.594444
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '26'

# Generated at 2022-06-17 21:24:41.410109
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": 1}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a": 1}'

    body = '{"a": 1}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a": 1}'

    body = '{"a": 1}'
    body_read_callback = lambda x: x


# Generated at 2022-06-17 21:24:49.434070
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:25:02.294061
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:25:11.414498
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:25:21.913420
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:25:39.887998
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:25:46.073324
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    import requests_toolbelt.multipart

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello world'

    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline).stream == ['hello world'.encode()]

    body = io.BytesIO(b'hello world')
    body_read_callback = lambda x: x

# Generated at 2022-06-17 21:25:53.664095
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": 1}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a": 1}'

    body = '{"a": 1}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == '{"a": 1}'

    body = '{"a": 1}'
    body_read_callback = lambda x: x


# Generated at 2022-06-17 21:25:57.464042
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {'Content-Length': str(len(request.body))}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02M\x01\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:26:03.279441
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:26:09.516729
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request_body

# Generated at 2022-06-17 21:26:20.276845
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:26:24.491201
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:26:28.641788
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:26:34.711088
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request_body

# Generated at 2022-06-17 21:26:54.680558
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from io import StringIO
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict

# Generated at 2022-06-17 21:27:00.809547
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"name": "foo"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = '{"name": "foo"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = '{"name": "foo"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline

# Generated at 2022-06-17 21:27:07.373045
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8a\x03\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'