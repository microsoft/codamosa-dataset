

# Generated at 2022-06-17 21:17:18.317429
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:17:28.586566
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:17:36.097543
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for function prepare_request_body
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = {'test': 'test'}

# Generated at 2022-06-17 21:17:47.982397
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:17:58.259568
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'abc'
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01\x8b\x01\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '15'
    request = requests.PreparedRequest()
    request.body = 'abc'
    compress_request(request, False)
    assert request.body == 'abc'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '15'
    request = requests.PreparedRequest()

# Generated at 2022-06-17 21:18:07.655732
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    import io
    import os
    import tempfile
    import random
    import string
    import zlib

    def random_string(string_length=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(string_length))

    def random_bytes(string_length=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(string_length)).encode()

    def random_file(string_length=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return

# Generated at 2022-06-17 21:18:13.395569
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:18:21.898404
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    import io
    import unittest
    from unittest.mock import MagicMock

    class TestChunkedUploadStream(unittest.TestCase):
        def test_ChunkedUploadStream___iter__(self):
            stream = io.BytesIO(b'abc')
            callback = MagicMock()
            chunked_upload_stream = ChunkedUploadStream(stream, callback)
            for chunk in chunked_upload_stream:
                self.assertEqual(chunk, b'abc')
            callback.assert_called_once_with(b'abc')

    unittest.main()


# Generated at 2022-06-17 21:18:26.616290
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:18:29.860689
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['a', 'b', 'c']),
        callback=lambda x: print(x)
    )
    for chunk in stream:
        print(chunk)



# Generated at 2022-06-17 21:18:43.629958
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'

# Generated at 2022-06-17 21:18:52.639573
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:18:59.972588
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:19:10.296638
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for function prepare_request_body
    # Test for case 1: body is a string
    body = 'test'
    body_read_callback = lambda x: x
    offline = False
    chunked = False
    content_length_header_value = None
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    # Test for case 2: body is a bytes
    body = b'test'
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body

    # Test for case 3: body is a file-like object
    body = io.BytesIO(b'test')

# Generated at 2022-06-17 21:19:14.872504
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\x00\x00\x00\x01\x05\x00\x03\x08'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:19:25.819305
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == "test"

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    assert prepare_request_body

# Generated at 2022-06-17 21:19:37.649573
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    data = MultipartRequestDataDict()
    data['file'] = ('test.txt', 'test')
    data['file2'] = ('test2.txt', 'test2')
    encoder = MultipartEncoder(fields=data.items())
    stream = ChunkedMultipartUploadStream(encoder)
    assert stream.chunk_size == 102400
    assert stream.encoder == encoder

# Generated at 2022-06-17 21:19:42.558011
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers['Content-Length'] = '4'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xccM\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:19:47.509756
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8a\x03\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:20:00.995832
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt.multipart.encoder
    from requests_toolbelt.multipart.encoder import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestData

# Generated at 2022-06-17 21:20:13.036441
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = b'test'
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

# Generated at 2022-06-17 21:20:21.565493
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from io import BytesIO
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
   

# Generated at 2022-06-17 21:20:32.089314
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict

# Generated at 2022-06-17 21:20:41.171919
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import random
    import string
    import requests_toolbelt.multipart.encoder

    def randomString(stringLength=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(stringLength))

    data = {'field0': 'value', 'field1': 'value', 'field2': 'value'}
    encoder = requests_toolbelt.multipart.encoder.MultipartEncoder(fields=data)
    chunked_multipart_upload_stream = ChunkedMultipartUploadStream(encoder)
    for i in chunked_multipart_upload_stream:
        assert i == encoder.read(100 * 1024)


# Generated at 2022-06-17 21:20:46.801386
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xccOR\x08\x00\x9d\x90\x0b\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:20:54.307817
# Unit test for function prepare_request_body
def test_prepare_request_body():
    from io import BytesIO
    from requests_toolbelt import MultipartEncoder

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline
    )
    assert result == body

    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline
    )

# Generated at 2022-06-17 21:20:58.171189
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'


# Generated at 2022-06-17 21:21:08.501716
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    ) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    ) == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length

# Generated at 2022-06-17 21:21:16.000572
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '32'

# Generated at 2022-06-17 21:21:22.438111
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1a\x04\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '22'

# Generated at 2022-06-17 21:21:35.951362
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder.MultipartEncoder
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.Mult

# Generated at 2022-06-17 21:21:40.401370
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:21:49.325686
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import RequestDataDict

# Generated at 2022-06-17 21:21:57.846669
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    compress_request(request, True)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '9'

# Generated at 2022-06-17 21:22:01.823840
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "test"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == "test"


# Generated at 2022-06-17 21:22:05.940710
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'

# Generated at 2022-06-17 21:22:14.219297
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.compat import is_windows
    import os
    import tempfile
    import shutil
    import sys
    import io
    import random
    import string
    import zlib
    import base64
    import json
    import requests
    import requests_toolbelt
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.multipart.decoder.body
    import requests_toolbelt.multipart.decoder.body.part
    import requests_toolbelt.multipart.decoder.body.part.headers
    import requests_toolbelt.mult

# Generated at 2022-06-17 21:22:24.406149
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.cli.dicts import RequestDataDict
    from httpie.cli.dicts import MultipartRequest

# Generated at 2022-06-17 21:22:30.250983
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:22:36.236335
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02M\x01\x04\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '14'

# Generated at 2022-06-17 21:22:51.453213
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'hello'

    body = 'hello'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:22:57.551982
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {'Content-Length': '4'}
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '18'

# Generated at 2022-06-17 21:23:02.532109
# Unit test for function compress_request
def test_compress_request():
    import requests
    import zlib
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == zlib.compress(b'hello world')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '16'

# Generated at 2022-06-17 21:23:10.985203
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == 'test'
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:23:21.524906
# Unit test for function prepare_request_body

# Generated at 2022-06-17 21:23:31.123169
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:23:40.649232
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:23:48.752284
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert isinstance(prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline), ChunkedUploadStream)
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body.encode()
    body = b'test'
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

# Generated at 2022-06-17 21:23:56.301843
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'abc'
    request.headers['Content-Length'] = '3'
    compress_request(request, True)
    assert request.body == zlib.compress(b'abc')
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'

# Generated at 2022-06-17 21:24:01.186605
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:24:12.982257
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from io import BytesIO
    from requests_toolbelt import MultipartEncoder


# Generated at 2022-06-17 21:24:15.965321
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:24:21.864668
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    request.headers = {'Content-Length': '11'}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x02M\x01\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-17 21:24:27.757387
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {'a': 'b'}
    boundary = 'boundary'
    content_type = 'content_type'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    assert data.boundary_value == boundary
    assert content_type == 'content_type; boundary=boundary'

# Generated at 2022-06-17 21:24:38.907757
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xcc\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length']

# Generated at 2022-06-17 21:24:47.967276
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'{"a": "b"}'

    body = '{"a": "b"}'
    body_read_callback = lambda x: x
    content_length_header_value = None


# Generated at 2022-06-17 21:25:01.691804
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    from httpie.compat import urlopen
    from httpie.output.streams import BINARY_SUPPRESSED_NOTICE
    import os
    import tempfile
    import time
    import random
    import string
    import shutil
    import requests
    import requests_toolbelt
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.decoder
    import requests_toolbelt.utils
    import requests_toolbelt.streaming_iterator
    import requests_toolbelt.downloadutils
    import requests_toolbelt.downloadutils.streams
    import requests_toolbelt.downloadutils.streams.chunked

# Generated at 2022-06-17 21:25:12.762607
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == b'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = True

# Generated at 2022-06-17 21:25:23.405989
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "hello world"
    request.headers = {}
    compress_request(request, False)

# Generated at 2022-06-17 21:25:31.729635
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt.multipart
    import requests_toolbelt.multipart.encoder
    import requests_toolbelt.multipart.encoder.MultipartEncoder
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.MultipartEncoderObserver.MultipartEncoderObserver.MultipartEncoderObserver
    import requests_toolbelt.multipart.encoder.MultipartEncoderMonitor.Mult

# Generated at 2022-06-17 21:25:43.500231
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:25:52.431707
# Unit test for function compress_request
def test_compress_request():
    # Test case 1:
    #   request.body is a string
    #   is_economical is True
    #   always is False
    #   expected: request.body is deflated
    #             request.headers['Content-Encoding'] is 'deflate'
    #             request.headers['Content-Length'] is the length of deflated data
    request = requests.PreparedRequest()
    request.body = 'abc'
    request.headers = {'Content-Length': '3'}
    compress_request(request, False)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '11'

   

# Generated at 2022-06-17 21:26:02.154832
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'test'

    body = 'test'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False

# Generated at 2022-06-17 21:26:09.008127
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    chunked = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    offline = True
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    body = "hello world"
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False

# Generated at 2022-06-17 21:26:15.833229
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.body == b'x\x9cK\xca\xccO\x00\x06,\x02\x15\x00\x9b\x04\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '17'

# Generated at 2022-06-17 21:26:19.158667
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello World"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '23'

# Generated at 2022-06-17 21:26:24.815238
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'hello world'
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\x1d\x8b\x04\x00\x00\x00\x00'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '25'

# Generated at 2022-06-17 21:26:29.210476
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'

# Generated at 2022-06-17 21:26:32.434239
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '8'
    assert request.body == b'x\x9cK\xcb\xcf\x07\x00\x06,\x02\x15'

# Generated at 2022-06-17 21:26:44.029282
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'hello world'
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    chunked = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == 'hello world'
    offline = True
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    assert result == body
    body = {'hello': 'world'}

# Generated at 2022-06-17 21:26:59.975705
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt import MultipartEncoder
    from httpie.cli.dicts import MultipartRequestDataDict
    data = MultipartRequestDataDict()
    data['a'] = 'b'
    data['c'] = 'd'
    encoder = MultipartEncoder(fields=data.items())
    stream = ChunkedMultipartUploadStream(encoder)
    assert next(stream) == encoder.read(100 * 1024)
    assert next(stream) == encoder.read(100 * 1024)
    assert next(stream) == encoder.read(100 * 1024)
    assert next(stream) == encoder.read(100 * 1024)
    assert next(stream) == encoder.read(100 * 1024)
    assert next(stream) == encoder.read(100 * 1024)
   