

# Generated at 2022-06-25 19:21:12.636442
# Unit test for function compress_request
def test_compress_request():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    prepared_request_0 = requests.PreparedRequest()
    compress_request(prepared_request_0, True)
    compress_request(prepared_request_0, False)



# Generated at 2022-06-25 19:21:15.194492
# Unit test for function compress_request
def test_compress_request():

    # import requests

    request = {
        'request': {
        },
        'body': '\x00',
    }
    always = False
    compress_request(request, always)


# Generated at 2022-06-25 19:21:26.698449
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = ""
    compress_request(request, True)
    assert request.body == ""

    request.body = "Some text"
    compress_request(request, True)
    assert request.body == b'x\x9c\xcbO\xcd\xcc\xcf\x07\x00\xad\x02\x06\x00\x0f\x03\x00\x00'

    request.body = open("/dev/random")
    compress_request(request, True)

# Generated at 2022-06-25 19:21:31.562375
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = [b'']
    iterable_0 = stream_0
    def callable_0(chunk_0):
        pass
    chunked_upload_stream_0 = ChunkedUploadStream(iterable_0, callable_0)
    assert False


# Generated at 2022-06-25 19:21:34.326697
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(stream, callback)
    iter_0 = chunked_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:21:43.745452
# Unit test for function prepare_request_body
def test_prepare_request_body():
    def body_read_callback(arg0):
        return arg0
    def assert_raises():
        raise AssertionError
    body = ''
    body_read_callback = body_read_callback
    content_length_header_value = 0
    chunked = False
    offline = False
    assert_raises(NotImplementedError, type(prepare_request_body(
        body="",
        body_read_callback=body_read_callback,
        content_length_header_value=content_length_header_value,
        chunked=chunked,
        offline=offline,
    )))

    body = ('abcdefghijklmnopqrstuvwxyz')
    body_read_callback = body_read_callback
    content_length_header_value = 0
    chunked = False

# Generated at 2022-06-25 19:21:48.300912
# Unit test for function compress_request
def test_compress_request():
    preconditions[0] = inspect.isclass(module_0.MultipartRequestDataDict)



# Generated at 2022-06-25 19:21:56.284577
# Unit test for function compress_request
def test_compress_request():
    import httpie.cli.dicts as module_0
    import zlib
    file_0 = module_0.MultipartRequestDataDict()
    file_0[b'bar'] = (b'foo', )
    file_0[b'bar'] = (b'foo', b'application/octet-stream')
    file_0[b'bar'] = (b'foo', b'application/octet-stream', b'foo.txt')
    file_0[b'bar'] = (b'foo', u'application/octet-stream', u'foo.txt', {b'foo': b'bar'})
    file_0[b'foo'] = [b'foo', ]
    file_0[b'foo'] = [b'foo', b'bar']

# Generated at 2022-06-25 19:21:58.151797
# Unit test for function compress_request
def test_compress_request():
    # Setup
    request = requests.PreparedRequest()
    always = True
    
    # Test
    compre

# Generated at 2022-06-25 19:22:05.933469
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # stream_0 is a iterable of type str
    stream_0 = iter([])
    # chunked_upload_stream_0 is of type ChunkedUploadStream
    chunked_upload_stream_0 = ChunkedUploadStream(stream=stream_0, callback=None)
    # str_0 is of type str
    str_0 = str()
    # str_1 is of type str
    str_1 = str()
    # tuple_0 is of type tuple
    tuple_0 = (str_0, str_1)
    # tuple_1 is of type tuple
    tuple_1 = (str_0, str_1)
    # list_0 is of type list
    list_0 = [str_0, str_1]
    # bytes_0 is of type bytes
    bytes_0 = bytes()
    #

# Generated at 2022-06-25 19:22:21.408587
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert_equal(type(prepare_request_body('body', 'body_read_callback', content_length_header_value='content_length_header_value', chunked='chunked', offline='offline')), str)
    assert_equal(type(prepare_request_body(b'body', 'body_read_callback', content_length_header_value='content_length_header_value', chunked='chunked', offline='offline')), bytes)
    assert_equal(type(prepare_request_body(io.BytesIO(b''), 'body_read_callback', content_length_header_value='content_length_header_value', chunked='chunked', offline='offline')), io.BytesIO)

# Generated at 2022-06-25 19:22:28.291914
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    """
    Test for method __iter__ of class ChunkedMultipartUploadStream
    """
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(None)
    chunked_multipart_upload_stream_0.__iter__()
    body_read_callback_0 = lambda arg: arg
    request_data_dict_0 = module_0.RequestDataDict()
    content_length_header_value_0 = 0
    # The next line fails due to a missing type annotation
    stream_0 = prepare_request_body(request_data_dict_0, body_read_callback_0, content_length_header_value_0)
    content_type_0 = 'type/0'

# Generated at 2022-06-25 19:22:34.401773
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(stream=(chunk.encode() for chunk in [body]), callback=body_read_callback)
    assert next(chunked_upload_stream_0) == body.encode()
    assert next(chunked_upload_stream_0) == body.encode()
    assert next(chunked_upload_stream_0) == body.encode()


# Generated at 2022-06-25 19:22:43.379310
# Unit test for function prepare_request_body
def test_prepare_request_body():
    
    
    
    
        
    request_data_dict_0 = module_0.RequestDataDict()
    str_0 = prepare_request_body(request_data_dict_0)
    request_data_dict_1 = module_0.RequestDataDict()
    request_data_dict_2 = module_0.RequestDataDict()
    str_1 = prepare_request_body(request_data_dict_1, request_data_dict_2)
    request_data_dict_3 = module_0.RequestDataDict()
    request_data_dict_4 = module_0.RequestDataDict()
    str_2 = prepare_request_body(request_data_dict_3, request_data_dict_4, request_data_dict_4)
    str_3 = prepare_request_body

# Generated at 2022-06-25 19:22:47.197205
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    encoder = MultipartEncoder({})
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(encoder)
    for chunk in chunked_multipart_upload_stream_0:
        pass


# Generated at 2022-06-25 19:22:49.389308
# Unit test for function compress_request
def test_compress_request():
    result = compress_request()
    assert result is None



# Generated at 2022-06-25 19:22:59.472671
# Unit test for function prepare_request_body
def test_prepare_request_body():
    arg0 = None
    arg1 = lambda arg: arg
    arg2 = None
    arg3 = True
    arg4 = False
    assert prepare_request_body(arg0, arg1, arg2, arg3, arg4) is None
    arg0 = b'Body'
    arg1 = lambda arg: arg
    arg2 = None
    arg3 = True
    arg4 = False
    assert prepare_request_body(arg0, arg1, arg2, arg3, arg4) is None
    arg0 = b'Body'
    assert type(prepare_request_body(arg0, arg1, arg2, arg3, arg4)) == ChunkedUploadStream
    arg0 = b'Body'
    arg1 = lambda arg: arg
    arg2 = 1
    arg3 = True
    arg4 = False


# Generated at 2022-06-25 19:23:01.602951
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    prepare_request_body(request_data_dict_0, lambda x: x)


# Generated at 2022-06-25 19:23:05.656410
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(MultipartEncoder())
    for _ in range(0, 10):
        _ = iter(chunked_multipart_upload_stream_0)

import io


# Generated at 2022-06-25 19:23:08.921237
# Unit test for function compress_request
def test_compress_request():
    from requests import PreparedRequest
    from requests import Request
    request = Request('GET', 'http://httpbin.org/get')
    request = PreparedRequest()
    compress_request(request, True)
    compress_request(request, False)

# Generated at 2022-06-25 19:23:19.827628
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = {
        'name': 'path',
        'filename': 'file'
    }
    boundary = '----WebKitFormBoundary'
    content_type = 'App'
    result = get_multipart_data_and_content_type(data, boundary, content_type)


# Generated at 2022-06-25 19:23:22.438216
# Unit test for function compress_request
def test_compress_request():
    data = np.random.rand(100)
    expected = np.sin(data)
    assert np.allclose(sin(data), expected)


# Generated at 2022-06-25 19:23:24.664935
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream = create_ChunkedMultipartUploadStream()
    result = chunked_multipart_upload_stream.__iter__()


# Generated at 2022-06-25 19:23:26.066888
# Unit test for function prepare_request_body
def test_prepare_request_body():
    var_0 = prepare_request_body()


# Generated at 2022-06-25 19:23:29.500241
# Unit test for function compress_request
def test_compress_request():
    # Setup
    request = requests.PreparedRequest()

    # Testing
    # This should raise an exception because there is not enough parameters
    with pytest.raises(TypeError):
        compress_request()

    assert compress_request(request, always=False) is None
    assert compress_request(request, always=True) is None


# Generated at 2022-06-25 19:23:33.559180
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Check if there is a raise when the input is invalid
    with pytest.raises(AssertionError):
        prepare_request_body(None)
    # Check if there is a return when the input is valid
    temp_r = prepare_request_body("test","test")
    assert temp_r is not None

# Generated at 2022-06-25 19:23:37.181189
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    var_1 = ChunkedUploadStream()
    var_1.callback()


# Generated at 2022-06-25 19:23:39.078170
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    def test_case_0():
        var_0 = ChunkedMultipartUploadStream()
        pass



# Generated at 2022-06-25 19:23:39.639569
# Unit test for function compress_request
def test_compress_request():
    assert True


# Generated at 2022-06-25 19:23:40.510284
# Unit test for function compress_request
def test_compress_request():
    assert func_0() == 0


# Generated at 2022-06-25 19:23:57.466512
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import json
    import zlib

    body = prepare_request_body('', lambda data: data)
    body_file = open('/tmp/httpie/body_file.txt')
    body_read_callback = lambda data: data
    content_length_header_value = 0
    chunked = True
    offline = False
    body_1 = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)

    rd_0 = RequestDataDict({})
    rd_1 = RequestDataDict({})
    rd_2 = RequestDataDict({})
    rd_3 = RequestDataDict({})
    rd_4 = RequestDataDict({})
    rd_5 = RequestDataDict({})
    rd_6 = RequestDataD

# Generated at 2022-06-25 19:24:06.920823
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    str_0 = 'a'
    multipart_encoder_0 = MultipartEncoder(str_0, str_0)
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.chunk_size = 100

# Generated at 2022-06-25 19:24:11.888757
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    request_0.headers = {}
    request_0.body = 'div>\n\n            <button'
    compress_request(request_0, True)

if __name__ == '__main__':
    test_compress_request()

# Generated at 2022-06-25 19:24:18.189379
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder(b'', '')
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.chunk_size = 4
#   for i in chunked_multipart_upload_stream_0:
#       chunk_0 = i
    assert chunk_0 == b''


# Generated at 2022-06-25 19:24:24.283126
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    str_0 = 'aJN'
    multipart_encoder_0 = MultipartEncoder(str_0, str_0)
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.chunk_size = -3525
    try:
        chunked_multipart_upload_stream_0.__iter__()
    except IOError:
        pass


# Generated at 2022-06-25 19:24:31.187414
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    str_0 = 'nvLsig|+\nr,ndO/B:\nB`'
    chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)
    str_1 = str(chunked_upload_stream_0)
    assert str_1 == chunked_upload_stream_0

# Generated at 2022-06-25 19:24:40.962407
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    dict_0 = {}
    dict_1 = dict_0
    dict_2 = dict_1
    dict_0 = {
        '7': 'tPvZV4', 
        '7': 'tPvZV4', 
        '7': 'tPvZV4', 
        '7': 'tPvZV4', 
        '7': 'tPvZV4', 
        '7': 'tPvZV4', 
    }

# Generated at 2022-06-25 19:24:41.797040
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert 0 == 0


# Generated at 2022-06-25 19:24:42.371695
# Unit test for function compress_request
def test_compress_request():
    assert True

# Generated at 2022-06-25 19:24:52.717396
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    str_0 = 'nvLsig|+\nr,ndO/B:\nB`'
    chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)
    str_b_0 = b'nvLsig|+\nr,ndO/B:\nB`'

# Generated at 2022-06-25 19:25:12.426752
# Unit test for function prepare_request_body
def test_prepare_request_body():
    str_0 = 'J'
    chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)
    bytes_1 = b'GET'
    str_0 = '\u0013#^'
    multipart_request_data_dict_0 = MultipartRequestDataDict(str_0, str_0)
    str_1 = 'application/json'
    multipart_encoder_0, str_2 = get_multipart_data_and_content_type(multipart_request_data_dict_0, str_1, str_1)
    request_0 = requests.Request(bytes_1, str_1, multipart_encoder_0).prepare()
    str_2 = 'text/plain'

# Generated at 2022-06-25 19:25:20.289148
# Unit test for function compress_request
def test_compress_request():
    d0 = 'l'
    d1 = 'o'
    d2 = 'w'
    d3 = 'e'
    d4 = 'r'
    d5 = 'c'
    d6 = 'a'
    d7 = 's'
    d8 = 'e'
    d9 = 's'
    d10 = ' '
    d11 = 'r'
    d12 = 'u'
    d13 = 'n'
    d14 = ' '
    d15 = 's'
    d16 = 'o'
    d17 = 'f'
    d18 = 't'
    d19 = 'w'
    d20 = 'a'
    d21 = 'r'
    d22 = 'e'
    d23 = '\r'
    d24 = '\n'

# Generated at 2022-06-25 19:25:30.764511
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    str_0 = 'nvLsig|+\nr,ndO/B:\nB`'
    chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)
    chunked_upload_stream_0.stream
    str_1 = 'nvLsig|+\nr,ndO/B:\nB`'
    str_2 = 'nvLsig|+\nr,ndO/B:\nB`'
    chunked_upload_stream_1 = ChunkedUploadStream(str_1, str_2)
    chunked_upload_stream_1.stream
    str_3 = 'nvLsig|+\nr,ndO/B:\nB`'
    str_4 = 'nvLsig|+\nr,ndO/B:\nB`'


# Generated at 2022-06-25 19:25:36.128094
# Unit test for function compress_request
def test_compress_request():
    requests_0 = requests.PreparedRequest()
    compress_request(requests_0, True)
    assert requests_0.body == 'nvLsig|+\nr,ndO/B:\nB`'


# Generated at 2022-06-25 19:25:39.285191
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    str_0 = 'nvLsig|+\nr,ndO/B:\nB`'
    chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)
    # TODO
    # assert 


# Generated at 2022-06-25 19:25:45.627424
# Unit test for function compress_request
def test_compress_request():
    class RequestDataDict_0:
        def __init__(self, arg0, arg1=None):
            self.dict = dict([(arg0, arg1)])

        def items(self):
            return self.dict.items()

    class requests_0:
        class PreparedRequest_0:
            def __init__(self, arg0=None):
                self.headers = dict([('Content-Type', arg0)])


# Generated at 2022-06-25 19:25:54.898182
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = requests.PreparedRequest()
    prepared_request_0.body = 'nvLsig|+\nr,ndO/B:\nB`'
    prepared_request_0.headers = {}
    compress_request(prepared_request_0, True)
    

# Generated at 2022-06-25 19:26:05.534480
# Unit test for function compress_request
def test_compress_request():
    from requests.structures import CaseInsensitiveDict
    from requests.models import RequestEncodingMixin
    from requests.models import Request

    def patch_request_encoding_mixin(request):
        headers = CaseInsensitiveDict()
        headers['Content-Length'] = '1337'
        headers['Content-Encoding'] = 'deflate'
        request.headers = headers

    request_0 = Request()
    request_0.data = 'Content-Length'
    request_0.headers = CaseInsensitiveDict()
    request_0.url = 'CxVu>qm8r|V\n'
    request_0.method = 'GET'
    compress_request(request_0, True)
  


# Generated at 2022-06-25 19:26:10.374016
# Unit test for function compress_request
def test_compress_request():
    data = '\n\n\f\r\x0c'
    always = True
    request = (data, always)
    assert_equal(callable(compress_request), True)
    assert_equal(compress_request(request), None)


# Generated at 2022-06-25 19:26:19.297879
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder('bytes')
    str_0 = "__fvjVy|Y\ntfkF*{K\n}@E"
    str_1 = 'j!z*\x7f'
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    for _ in range(45):
        if (chunked_multipart_upload_stream_0.chunk_size == str_0):
            str_0 = str_1
    for _ in range(16):
        try:
            next(iter(chunked_multipart_upload_stream_0))
        except StopIteration:
            pass



# Generated at 2022-06-25 19:26:43.844289
# Unit test for function compress_request
def test_compress_request():
    class requests_PreparedRequest_0:
        body = [((str_0, 'utf-8'))]
        headers = {'Content-Encoding': 'deflate', 'Content-Length': (str_1)}
        body = [((str_0, 'utf-8'))]
        headers = {'Content-Encoding': 'deflate', 'Content-Length': (str_1)}
        def __init__(self):
            self.body = [((str_0, 'utf-8'))]
            self.headers = {'Content-Encoding': 'deflate', 'Content-Length': (str_1)}
        def __init__(self):
            self.body = [((str_0, 'utf-8'))]

# Generated at 2022-06-25 19:26:50.003361
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    encoder = 'this_is_a_invalid_MultipartEncoder_instance'
    chunked_upload_stream = ChunkedMultipartUploadStream(encoder)
    result = chunked_upload_stream.__iter__()


# Generated at 2022-06-25 19:26:54.593541
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = False
    compress_request(request, always)


# Generated at 2022-06-25 19:26:59.858411
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder(None, None)
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    multipart_encoder_0.read = multipart_encoder_0.read
    assert chunked_multipart_upload_stream_0.__iter__() is not None


# Generated at 2022-06-25 19:27:01.558691
# Unit test for function compress_request
def test_compress_request():
    input_0 = '~#'
    assert compress_request(input_0, True) == '`$'


# Generated at 2022-06-25 19:27:06.971097
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    for _ in chunked_multipart_upload_stream_0:
        pass


# Generated at 2022-06-25 19:27:12.291826
# Unit test for function compress_request
def test_compress_request():
    data = 'some data'
    req = requests.Request('POST', 'https://httpbin.org', data=data)
    prepared_request = req.prepare()
    compress_request(prepared_request, True)
    # ["Content-Encoding", "deflate"], ["Content-Length", "22"]
    assert prepared_request.headers == {
        'Content-Encoding': 'deflate',
        'Content-Length': '22',
    }
    assert prepared_request.body == zlib.compress(data.encode())


# Generated at 2022-06-25 19:27:17.627108
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder((('A', 'A'), ('A', 'A'), ('A', 'A'), ('A', 'A'), ('A', 'A'), ('A', 'A'), ('A', 'A')))
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    # Iterate generator just to see if any exceptions are thrown
    for chunk in chunked_multipart_upload_stream_0:
        pass



# Generated at 2022-06-25 19:27:23.115013
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = test_case_0()
    body_read_callback = test_case_0()
    content_length_header_value = test_case_0()
    chunked = test_case_0()
    offline = test_case_0()
    result = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)


# Generated at 2022-06-25 19:27:29.930069
# Unit test for function compress_request
def test_compress_request():
    with open(os.devnull, 'wb') as stream_0:
        multipart_encoder_0 = MultipartEncoder(stream_0)
    multipart_encoder_0 = MultipartEncoder(multipart_encoder_0)
    def test_func_0(arg_0):
        multipart_encoder_0 = ChunkedMultipartUploadStream(arg_0)
    m = test_func_0(multipart_encoder_0)
    assert not hasattr(m, 'read')

# Generated at 2022-06-25 19:27:59.632062
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    # Assert type is matter.
    data = {'str': 'str', 'str2': 'str2'}
    encoder, _ = get_multipart_data_and_content_type(data)
    assert isinstance(encoder.fields, dict), \
        'Type of fields should be dict'
    assert len(encoder.fields.keys()) == 2, \
        'Length of data should be 2'
    assert isinstance(encoder.boundary_value, str)


# Generated at 2022-06-25 19:28:09.129121
# Unit test for function prepare_request_body
def test_prepare_request_body():

    def test_case_0():
        str_0 = 'nvLsig|+\nr,ndO/B:\nB`'
        chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)

    def test_case_1():
        str_0 = 'Y<K(3u~+m1#9\nR'
        chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)
        chunked_upload_stream_1 = ChunkedUploadStream(chunked_upload_stream_0, str_0)

    def test_case_2():
        str_0 = 'nvLsig|+\nr,ndO/B:\nB`'

# Generated at 2022-06-25 19:28:17.611399
# Unit test for function compress_request
def test_compress_request():
    requests_0 = requests
    requests_0.request = 'request'
    str_0 = 'application/json'
    requests_0.headers = {
        'Content-Type': str_0,
    }
    str_1 = '{"key": "value"}'
    requests_0.body = str_1.encode()
    requests_0.status_code = 200
    requests_0.reason = 'OK'
    bool_0 = False
    assert_equal(compress_request(requests_0, bool_0), None)


# Generated at 2022-06-25 19:28:18.158254
# Unit test for function compress_request
def test_compress_request():
    pass

# Generated at 2022-06-25 19:28:26.881727
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    str_0 = 'nvLsig|+\nr,ndO/B:\nB`'
    chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)
    str_1 = ''
    str_2 = "B`"
    str_3 = 'nvLsig|+\nr,ndO/B:\n'
    str_4 = "B`"
    str_5 = 'nvLsig|+\nr,ndO/B:\n'
    str_6 = ''
    str_7 = "B`"
    str_8 = 'nvLsig|+\nr,ndO/B:\n'
    str_9 = "B`"
    str_10 = 'nvLsig|+\nr,ndO/B:\n'
    str_

# Generated at 2022-06-25 19:28:28.468871
# Unit test for function compress_request
def test_compress_request():
    prepared_request = requests.PreparedRequest()
    compress_request(prepared_request, True)


# Generated at 2022-06-25 19:28:35.088796
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    str_0 = 'nvLsig|+\nr,ndO/B:\nB`'
    chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)
    chunked_upload_stream_0.chunk_size = 0
    chunked_upload_stream_0.stream = str_0
    expected_0 = chunked_upload_stream_0
    actual_0 = chunked_upload_stream_0.__iter__()
    assert actual_0 == expected_0


# Generated at 2022-06-25 19:28:44.545920
# Unit test for function compress_request
def test_compress_request():
    data = 'test_data_0'
    requests_0 = requests.PreparedRequest()
    requests_0.method = 'PUT'
    requests_0.url = 'http://example.com/'
    requests_0.headers['Accept'] = '*/*'
    requests_0.headers['Content-Type'] = 'application/json'
    requests_0.body = data
    always = False
    assert 'application/json' in requests_0.headers
    assert 'Accept' in requests_0.headers
    compress_request(requests_0, always)
    assert 'application/json' in requests_0.headers
    assert 'Accept' in requests_0.headers
    str_0 = 'nvLsig|+\nr,ndO/B:\nB`'

# Generated at 2022-06-25 19:28:46.959797
# Unit test for function compress_request
def test_compress_request():
    request = None
    always = False
    compress_request(request, always)


# Generated at 2022-06-25 19:28:54.994524
# Unit test for function prepare_request_body
def test_prepare_request_body():
    str_0 = 'aX^oJ-~Y#\n'
    dict_0 = {str_0:str_0}
    str_1 = 'I@}p`\n'
    str_2 = 'm\n'
    str_3 = 'T\n'
    str_4 = '\n'
    dict_1 = {str_0:str_0, str_1:str_1, str_4:str_3, str_2:str_1}
    chunked_upload_stream_0 = prepare_request_body(dict_1, dict_0, False, str_0)
    assert len(chunked_upload_stream_0) == 4


# Generated at 2022-06-25 19:29:31.338215
# Unit test for function compress_request
def test_compress_request():
    class TestRequest:
        def __init__(self, method, headers, body):
            self.method = method
            self.headers = headers
            self.body = body

    test_request = TestRequest('GET', {}, 'Hello World')
    compress_request(test_request, True)
    assert test_request.body == zlib.compress(b'Hello World')
    assert test_request.headers['Content-Encoding'] == 'deflate'
    assert test_request.headers['Content-Length'] == '26'

    test_request = TestRequest('GET', {}, 'Hello World')
    compress_request(test_request, False)
    assert test_request.body == zlib.compress(b'Hello World')
    assert test_request.headers['Content-Encoding'] == 'deflate'
    assert test_

# Generated at 2022-06-25 19:29:32.788561
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)


# Generated at 2022-06-25 19:29:42.601742
# Unit test for function compress_request
def test_compress_request():
    from requests import PreparedRequest
    from httpie import main
    prepared_request_0 = PreparedRequest()
    prepared_request_0.body = 'b5yfbg2vhz1t'
    def always_0():
        return False
    compress_request(prepared_request_0, always_0())
    prepared_request_1 = PreparedRequest()
    prepared_request_1.body = 'b5yfbg2vhz1t'
    def always_1():
        return False
    compress_request(prepared_request_1, always_1())
    prepared_request_2 = PreparedRequest()
    prepared_request_2.body = 'nvLsig|+\nr,ndO/B:\nB`'
    def always_2():
        return False

# Generated at 2022-06-25 19:29:46.711394
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    request_0.body = 'content'
    compress_request(request_0, False)
    assert request_0.body == b'x\x9cc`\x08\xcd\xc9\xc9W(\xcf/\xcaIQ\xcc \x82\x01\x00\x1a\x80'



# Generated at 2022-06-25 19:29:48.597449
# Unit test for function compress_request
def test_compress_request():
    str_0 = 'PDq3[:1'
    class_0 = requests.PreparedRequest()
    compress_request(True, str_0)


# Generated at 2022-06-25 19:29:59.330074
# Unit test for function prepare_request_body
def test_prepare_request_body():
    file_input = 'file'
    body_read_callback = 'callback'
    content_length_header_value = 100
    chunked = True
    offline = 'offline'
    str_0 = 'nvLsig|+\nr,ndO/B:\nB`'
    chunked_upload_stream_0 = ChunkedUploadStream(str_0, str_0)
    bytes_0 = b'\xad\xac\xb3\xab'
    file_0 = open('test_file', 'w')
    file_0.write(bytes_0)
    file_0.close()
    request_data_dict_0 = RequestDataDict()

# Generated at 2022-06-25 19:30:08.951898
# Unit test for function compress_request
def test_compress_request():
    # Lets define our request
    request = requests.PreparedRequest()
    request.method = 'PUT'
    # This is stream implementation
    request.url = 'https://httpbin.org/put'
    request.headers['Content-Type'] = 'multipart/form-data'
    request.body = b'--\nContent-Disposition: form-data; name="file"; filename="test.txt"\nContent-Type: text/plain'
    request.headers['Content-Length'] = '10'
    # Lets define our request
    request1 = requests.PreparedRequest()
    request1.method = 'PUT'
    # This is stream implementation
    request1.url = 'https://httpbin.org/put'
    request1.headers['Content-Type'] = 'multipart/form-data'
    request1

# Generated at 2022-06-25 19:30:14.996508
# Unit test for function prepare_request_body
def test_prepare_request_body():
    arg0 = 'KRa!NM}w'
    arg1 = '\nf9s\n(s\ttp\nkv\rp\r:r\r&K`\ng`a\rTbkO\nHBk7\n^E'
    arg2 = '\ng`a\rTbkO\nHBk7\n^E'
    arg3 = '\ng`a\rTbkO\nHBk7\n^E'
    arg4 = '\ng`a\rTbkO\nHBk7\n^E'
    func_ret_val0 = prepare_request_body(arg0, arg1, arg2, arg3, arg4)
    first_call_to_prepare_request_body = func_ret_val0

# Unit test

# Generated at 2022-06-25 19:30:24.853164
# Unit test for function compress_request
def test_compress_request():
    # Import from main file.
    from httpie import cli

    # Unit testing for function: compress_request
    request_0 = requests.PreparedRequest()
    compress_request(request_0, 0)
    request_1 = requests.PreparedRequest()
    compress_request(request_1, 1)
    request_2 = requests.PreparedRequest()
    compress_request(request_2, 2)
    request_3 = requests.PreparedRequest()
    compress_request(request_3, 3)
    request_4 = requests.PreparedRequest()
    compress_request(request_4, 4)
    request_5 = requests.PreparedRequest()
    compress_request(request_5, 5)
    request_6 = requests.PreparedRequest()
    compress_request(request_6, 6)
    request_7

# Generated at 2022-06-25 19:30:35.684513
# Unit test for function compress_request
def test_compress_request():
    url_0 = 'https://github.com'
    str_0 = '"{}"'
    str_1 = 'application/json'
    str_2 = '{\'date\': \'2014-12-22\'}'
    request_data_dict_0 = RequestDataDict(str_2)
    multipart_encoder_0 = MultipartEncoder(request_data_dict_0, request_data_dict_0)
    prepared_request_0 = requests.PreparedRequest()
    deflater = zlib.compressobj()
    if isinstance(prepared_request_0.body, str):
        body_bytes = prepared_request_0.body.encode()
    elif hasattr(prepared_request_0.body, 'read'):
        body_bytes = prepared_request_0.body