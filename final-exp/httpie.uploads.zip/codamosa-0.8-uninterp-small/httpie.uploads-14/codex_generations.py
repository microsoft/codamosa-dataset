

# Generated at 2022-06-25 19:21:07.375306
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    generator = chunked_multipart_upload_stream_0.__iter__()
    assert isinstance(generator, types.GeneratorType)
    for elem in generator: pass


# Generated at 2022-06-25 19:21:09.173547
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    always_0 = True
    compress_request(request_0, always_0)


# Generated at 2022-06-25 19:21:14.558753
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    iterable_0 = None
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(iterable_0, prepared_request_0)
    assert isinstance(chunked_upload_stream_0.__iter__(), Iterable)

import requests.models as module_0

import requests_toolbelt as module_1


# Generated at 2022-06-25 19:21:25.937365
# Unit test for function prepare_request_body
def test_prepare_request_body():
    iterable_0 = None
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(iterable_0, prepared_request_0)
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedMultipartUploadStream(prepared_request_0)
    iterable_0 = None
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(iterable_0, prepared_request_0)
    multipart_encoder_0 = MultipartEncoder()
    string_0 = 'test'
    int32_0 = 100
    multipart_request_data_dict_0 = MultipartRequestDataDict

# Generated at 2022-06-25 19:21:28.638980
# Unit test for function compress_request
def test_compress_request():
    # Variables for test_compress_request
    request = 'str'
    always = True

    # Call the function
    compress_request(request, always)


# Generated at 2022-06-25 19:21:33.435972
# Unit test for function compress_request
def test_compress_request():
    iterable_0 = None
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(iterable_0, prepared_request_0)
    assert chunked_upload_stream_0 is not None

import requests.models as module_1


# Generated at 2022-06-25 19:21:39.659538
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.chunk_size = 100 * 1024
    chunked_multipart_upload_stream_0.encoder = multipart_encoder_0


# Generated at 2022-06-25 19:21:43.878664
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder({}, boundary=None)
    multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    multipart_upload_stream_0.chunk_size = 100
    multipart_upload_stream_0.encoder = multipart_encoder_0
    multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:21:48.272841
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Get the function under test
    import httpie.utils as httpie_utils
    prepare_request_body_fut = httpie_utils.prepare_request_body
    
    # Create mock object
    chunked = False
    offline = False
    iterable_0 = None
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(iterable_0, prepared_request_0)
    
    # Invoke function under test
    actual_result = prepare_request_body_fut(iterable_0, prepared_request_0, chunked, offline)
    
    # Check result
    assert actual_result == chunked_upload_stream_0


# Generated at 2022-06-25 19:21:57.552179
# Unit test for function compress_request
def test_compress_request():
    always = True
    request = requests.PreparedRequest()
    request.headers = {}
    compress_request(request, always)
    # basic test
    assert hasattr(request, "headers")
    assert isinstance(request.headers, dict)
    assert 'Content-Encoding' in request.headers
    assert request.headers['Content-Encoding'] == 'deflate'
    assert 'Content-Length' in request.headers
    assert request.headers['Content-Length'] == '0'
    assert hasattr(request, "body")
    assert request.body == b''

    request = requests.PreparedRequest()
    request.headers = {}
    request.body = 'foo'
    compress_request(request, always)
    assert hasattr(request, "headers")
    assert isinstance(request.headers, dict)

# Generated at 2022-06-25 19:22:08.225126
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert prepare_request_body(
        body=('data',),
        body_read_callback=(lambda bytes_0: (bytes_0,)),
        content_length_header_value=(0),
        chunked=(False),
        offline=(False)
    ) == ('data',)


# Generated at 2022-06-25 19:22:15.130609
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    for chunk in chunked_upload_stream_0:
        assert type(chunk) in (str, bytes) is True

import requests.models as module_1
import requests.utils as module_2


# Generated at 2022-06-25 19:22:22.520929
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # Set up mock object
    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_0 = chunked_upload_stream_0
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    # Perform the method call
    # Perform the assertions


# Generated at 2022-06-25 19:22:28.680803
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():

    # Test cases

    def it_should_return_chunks_of_data_from_the_multipart_encoder():
        # Mock encoder
        encoder = Mock()
        encoder.read.return_value = b'a'

        # Test the method
        instance = ChunkedMultipartUploadStream(encoder=encoder)
        chunks = list(instance)

        # Assertions
        encoder.read.assert_called_with(10240)
        assert chunks == [b'a']

    def it_should_return_empty_list_when_encoder_has_no_data_left():
        # Mock encoder
        encoder = Mock()
        encoder.read.return_value = b''

        # Test the method

# Generated at 2022-06-25 19:22:31.473005
# Unit test for function compress_request
def test_compress_request():
    var_0 = requests.PreparedRequest()
    var_1 = True
    compress_request(var_0, var_1)


# Generated at 2022-06-25 19:22:37.376502
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(chunked_upload_stream_0)

    # Call method __iter__
    assert_equals(chunked_multipart_upload_stream_0.__iter__(), chunked_upload_stream_0)


# Generated at 2022-06-25 19:22:38.773220
# Unit test for function compress_request
def test_compress_request():
    assert callable(compress_request)


# Generated at 2022-06-25 19:22:42.223122
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    chunked_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:22:46.167174
# Unit test for function compress_request
def test_compress_request():
    prepared_request_1 = module_0.PreparedRequest()
    prepared_request_1.body = "deflate"
    compress_request(prepared_request_1, prepared_request_1)

if __name__ == '__main__':
    test_compress_request()

# Generated at 2022-06-25 19:22:57.256688
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data_0 = MultipartRequestDataDict()
    # Function get_multipart_data_and_content_type contains following lines of code.
    #
    #     encoder = MultipartEncoder(
    #         fields=data.items(),
    #         boundary=boundary,
    #     )
    #     if content_type:
    #         content_type = content_type.strip()
    #         if 'boundary=' not in content_type:
    #             content_type = f'{content_type}; boundary={encoder.boundary_value}'
    #     else:
    #         content_type = encoder.content_type
    #
    #     data = encoder
    #     return data, content_type
    #

    # LCOV_EXCL_START
    #

# Generated at 2022-06-25 19:23:07.914063
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.encoder.read(100)


# Generated at 2022-06-25 19:23:18.408069
# Unit test for function compress_request
def test_compress_request():
    # Tested for
    # requests.models.PreparedRequest
    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_0.body = prepared_request_0
    prepared_request_0.headers['Content-Encoding'] = 'deflate'
    prepared_request_0.headers['Content-Length'] = 'deflate'
    # requests.models.PreparedRequest
    prepared_request_1 = module_0.PreparedRequest()
    # bool
    always_0 = True
    compress_request(prepared_request_1, always_0)
    prepared_request_0.body = prepared_request_1
    prepared_request_0.body = prepared_request_1
    prepared_request_0.body = prepared_request_1
    prepared_request_0.headers['Content-Encoding']

# Generated at 2022-06-25 19:23:23.121800
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    for arg_0 in chunked_upload_stream_0:
        assert arg_0 == prepared_request_0, "Argument 0 of __iter__ has wrong value"


# Generated at 2022-06-25 19:23:26.186603
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedMultipartUploadStream(module_0.MultipartEncoder())
    # Iteration on this object is already tested (in test_case_0). So nothing to test here.


# Generated at 2022-06-25 19:23:29.887631
# Unit test for function compress_request
def test_compress_request():
    ctx = Globals()
    ctx.encoding = 'deflate'
    ctx.always_compress = True
    ctx.decompress_response = True
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    pass

# Generated at 2022-06-25 19:23:32.841986
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_0.headers = {}
    compress_request(prepared_request_0, prepared_request_0)


# Generated at 2022-06-25 19:23:38.869929
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    multipart_encoder_0.read()
    chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:23:42.121855
# Unit test for function prepare_request_body
def test_prepare_request_body():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    assert chunked_upload_stream_0 == prepare_request_body(prepared_request_0, prepared_request_0)


# Generated at 2022-06-25 19:23:45.825901
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    for _ in chunked_upload_stream_0:
        pass

import requests.models as module_1


# Generated at 2022-06-25 19:23:49.770056
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    compress_request(prepared_request_0, True)


# Generated at 2022-06-25 19:24:04.321678
# Unit test for function compress_request
def test_compress_request():
    # Setup
    request = requests.Request()
    always = True
    compress_request(request, always)


# Generated at 2022-06-25 19:24:10.452706
# Unit test for function compress_request
def test_compress_request():
    import requests.models as module_0
    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_0.body = bytes(248)
    prepared_request_0.headers = {}
    compress_request(prepared_request_0, False)
    # TODO: add more test cases for compression


# Generated at 2022-06-25 19:24:21.679178
# Unit test for function compress_request
def test_compress_request():
    def func(request, always):
        deflater = zlib.compressobj()
        if isinstance(request.body, str):
            body_bytes = request.body.encode()
        elif hasattr(request.body, 'read'):
            body_bytes = request.body.read()
        else:
            body_bytes = request.body
        deflated_data = deflater.compress(body_bytes)
        deflated_data += deflater.flush()
        is_economical = len(deflated_data) < len(body_bytes)
        if is_economical or always:
            request.body = deflated_data
            request.headers['Content-Encoding'] = 'deflate'
            request.headers['Content-Length'] = str(len(deflated_data))
    # STRING
    request

# Generated at 2022-06-25 19:24:32.788907
# Unit test for function compress_request
def test_compress_request():

    test_cases = [
        {
            'test_request_0': module_0.PreparedRequest(),
            'test_always_0': True,
        },
        {
            'test_request_0': module_0.PreparedRequest(),
            'test_always_0': False,
        },
        {
            'test_request_0': module_0.PreparedRequest(),
            'test_always_0': True,
        },
        {
            'test_request_0': module_0.PreparedRequest(),
            'test_always_0': False,
        },
    ]

    for test_case in test_cases:
        compress_request(**test_case)


# Generated at 2022-06-25 19:24:42.364163
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    # Test cases for function 'compress_request'
    #
    #
    #
    # Defaults for function arguments.
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #

# Generated at 2022-06-25 19:24:46.754888
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = None
    chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:24:50.536054
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_0.body = 'prepared_request_0.body'
    always_0 = 'always_0'
    encoding_0 = compress_request(prepared_request_0, always_0)
    assert (encoding_0 is None)


# Generated at 2022-06-25 19:24:57.765014
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    prepared_request_0.body = chunked_upload_stream_0
    prepared_request_0.headers = {}
    compress_request(prepared_request_0, False)


# Generated at 2022-06-25 19:24:59.623132
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert True


# Generated at 2022-06-25 19:25:01.243069
# Unit test for function compress_request
def test_compress_request():
    request_0 = module_0.PreparedRequest()
    compress_request(request_0, request_0)

import requests.models as module_1


# Generated at 2022-06-25 19:25:15.222470
# Unit test for function prepare_request_body
def test_prepare_request_body():
    prepared_request_0 = module_0.PreparedRequest()
    assert prepare_request_body(prepared_request_0, prepared_request_0) == prepared_request_0


# Generated at 2022-06-25 19:25:27.021209
# Unit test for function compress_request
def test_compress_request():
    # Test the case where the request body is a bytes object and the body length is >= the compressed body length
    request_body_bytes_object = b"Httpie is a command-line HTTP client. It will make you smile. HTTPie consists of a single http command designed for painless debugging and interaction with HTTP servers, RESTful APIs, and web services. https://httpie.org/"
    request_headers = {"Content-Type": "application/octet-stream"}
    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_0.body = request_body_bytes_object
    prepared_request_0.headers = request_headers
    compress_request(prepared_request_0, True)
    assert prepared_request_0.headers["Content-Encoding"] == "deflate"

    # Test the case where the request body is a bytes

# Generated at 2022-06-25 19:25:30.836216
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(prepared_request_0)
    for item in chunked_multipart_upload_stream_0:
        pass


# Generated at 2022-06-25 19:25:38.534646
# Unit test for function compress_request
def test_compress_request():

    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_1 = module_0.PreparedRequest()
    prepared_request_0.body = prepared_request_1
    prepared_request_0.headers = {'Content-Encoding': 'gzip'}
    prepared_request_0.headers = {'Content-Length': '12345'}
    # 
    assert prepared_request_0.body == prepared_request_1

# Generated at 2022-06-25 19:25:41.262789
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    compress_request(prepared_request_0, True)


# Generated at 2022-06-25 19:25:42.863768
# Unit test for function compress_request
def test_compress_request():
    request_0 = module_0.PreparedRequest()
    compress_request(request_0, True)
    compress_request(request_0, False)


# Generated at 2022-06-25 19:25:43.683262
# Unit test for function compress_request
def test_compress_request():
    assert func_return == 1
    # TODO: Create actual tests for each of the functions.

# Generated at 2022-06-25 19:25:53.874932
# Unit test for function prepare_request_body
def test_prepare_request_body():
    param0 = 'value0'
    param1 = 'value1'
    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_1 = ChunkedMultipartUploadStream(prepared_request_0)
    prepared_request_2 = ChunkedUploadStream(prepared_request_0, prepared_request_1.chunk_size)
    prepared_request_3 = MultipartEncoder(prepared_request_0, prepared_request_1)
    prepared_request_4 = get_multipart_data_and_content_type(prepared_request_0, prepared_request_0, prepared_request_1)
    prepared_request_5 = MultipartEncoder(prepared_request_0, prepared_request_1)

# Generated at 2022-06-25 19:25:59.059989
# Unit test for function prepare_request_body
def test_prepare_request_body():
    test_body = {
        'field_1': 'value_1',
        'field_2': 'value_2',
        'field_3': 'value_3',
    }
    request_body = prepare_request_body(test_body, lambda *args: None)

    assert request_body == urlencode(test_body, doseq=True)


# Generated at 2022-06-25 19:26:04.302989
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    chunked_upload_stream_0.iter = (lambda: 2)
    chunked_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:26:30.946274
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    compress_request(prepared_request_0, True)

if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-25 19:26:42.449159
# Unit test for function compress_request
def test_compress_request():
    always = True
    body_bytes = b"Test data"
    deflated_data = b"Test data"
    len_deflated_data = len(deflated_data)
    len_body_bytes = len(body_bytes)

    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_0.body = body_bytes
    prepared_request_0.headers = {"Content-Length": str(len_body_bytes)}

    compress_request(prepared_request_0, always)
    assert prepared_request_0.body == deflated_data
    assert prepared_request_0.headers["Content-Encoding"] == "deflate"
    assert prepared_request_0.headers["Content-Length"] == str(len_deflated_data)

    prepared_request_1 = module_0.Prepared

# Generated at 2022-06-25 19:26:46.407111
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    request = prepared_request_0
    always = prepared_request_0
    compress_request(request, always)


# Generated at 2022-06-25 19:26:49.429426
# Unit test for function compress_request
def test_compress_request():
    assert 1 == 1

import requests.models as module_0


# Generated at 2022-06-25 19:26:56.749473
# Unit test for function prepare_request_body
def test_prepare_request_body():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    assert chunked_upload_stream_0 == prepare_request_body(prepared_request_0, prepared_request_0)
    assert chunked_upload_stream_0 == prepare_request_body(prepared_request_0, prepared_request_0, prepared_request_0)
    assert chunked_upload_stream_0 == prepare_request_body(prepared_request_0, prepared_request_0, prepared_request_0, prepared_request_0)

# Generated at 2022-06-25 19:26:59.287145
# Unit test for function compress_request
def test_compress_request():
    assert False, "Test for method compress_request not implemented"
    # prepared_request_0 = module_0.PreparedRequest()
    # compress_request(prepared_request_0, False)

# Generated at 2022-06-25 19:27:06.120658
# Unit test for function prepare_request_body
def test_prepare_request_body():
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)
    multipart_encoder_0 = MultipartEncoder(prepared_request_0, prepared_request_0)
    request_data_dict_0 = RequestDataDict(prepared_request_0, prepared_request_0)
    prepare_request_body(prepared_request_0, prepared_request_0, prepared_request_0, prepared_request_0)
    prepare_request_body(prepared_request_0, prepared_request_0, prepared_request_0, prepared_request_0, prepared_request_0)

# Generated at 2022-06-25 19:27:14.337076
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict_0 = MultipartRequestDataDict()

    data, content_type = get_multipart_data_and_content_type(multipart_request_data_dict_0, None, None)
    assert type(data) == "MultipartEncoder"

    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(data)



# Generated at 2022-06-25 19:27:18.479586
# Unit test for function compress_request
def test_compress_request():
    request = module_0.PreparedRequest()
    assert (compress_request(request, False) == None)


# Generated at 2022-06-25 19:27:23.417051
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    prepared_request_0 = module_0.PreparedRequest()
    chunked_upload_stream_0 = ChunkedUploadStream(prepared_request_0, prepared_request_0)

# Generated at 2022-06-25 19:28:36.805347
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    result = ChunkedUploadStream(prepared_request_0, prepared_request_0).__iter__()


# Generated at 2022-06-25 19:28:39.389132
# Unit test for function compress_request
def test_compress_request():
    request_data = module_0.PreparedRequest()
    compress_request(request_data, always = True)

import urllib3 as module_1


# Generated at 2022-06-25 19:28:43.162004
# Unit test for function compress_request
def test_compress_request():

    # Start of prepare
    requests.models.PreparedRequest()
    request = None  # type: requests.PreparedRequest
    always = None  # type: bool
    # End of prepare

    def test():
        compress_request(request, always)

    # Start of cleanup
    # End of cleanup

# Generated at 2022-06-25 19:28:46.535734
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert isinstance(prepare_request_body(chunked_upload_stream_0, prepared_request_0, content_channel_0=False, offline=False), ChunkedUploadStream)


# Generated at 2022-06-25 19:28:47.740543
# Unit test for function compress_request
def test_compress_request():
    assert True


import requests.models as module_1


# Generated at 2022-06-25 19:28:54.497600
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    def test_compress_request_0():
        prepared_request_0.headers = {}
    prepared_request_0.headers['Content-Encoding'] = 2
    prepared_request_0.headers['Content-Length'] = 2
    prepared_request_0.headers = {}
    prepared_request_0.headers['Content-Encoding'] = 2
    prepared_request_0.headers['Content-Length'] = 2
    compress_request(prepared_request_0,True)


# Generated at 2022-06-25 19:28:55.808517
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    compress_request(request, True)

# Generated at 2022-06-25 19:28:58.170151
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict_0 = MultipartRequestDataDict()
    get_multipart_data_and_content_type(multipart_request_data_dict_0, multipart_request_data_dict_0)


# Generated at 2022-06-25 19:29:07.512818
# Unit test for function prepare_request_body
def test_prepare_request_body():
    multipart_form_data_0 = MultipartRequestDataDict(prepared_request_0)
    prepared_request_0 = module_0.PreparedRequest()
    prepared_request_1 = module_0.PreparedRequest()
    multipart_encoder_0 = MultipartEncoder(fields=prepared_request_1, boundary=prepared_request_1)
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(encoder=multipart_encoder_0)
    chunked_upload_stream_0 = ChunkedUploadStream(multipart_encoder_0, prepared_request_1)
    assert_equal(chunked_upload_stream_0, prepare_request_body(prepared_request_0, prepared_request_1))
    assert_equal

# Generated at 2022-06-25 19:29:09.071714
# Unit test for function compress_request
def test_compress_request():
    test_case_0()

import requests.models as module_1
