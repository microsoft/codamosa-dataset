

# Generated at 2022-06-25 19:20:57.218587
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(stream=iter((1,)), callback=iter)
    chunked_upload_stream_0.stream
    chunked_upload_stream_0.callback

    # Expected value is not supported for this test
    return


# Generated at 2022-06-25 19:20:59.449624
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    pass
    # Expected result:

    # Actual result:
    # pass


# Generated at 2022-06-25 19:21:03.318761
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder(((None, None),))
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    for chunk_0 in chunked_multipart_upload_stream_0:
        pass


# Generated at 2022-06-25 19:21:08.962472
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest('GET', timeout=2.0)
    request_0.body = ''
    request_0.headers['Content-Length'] = '0'
    request_0.headers['Content-Encoding'] = 'identity'
    compress_request(request_0, True)

# Generated at 2022-06-25 19:21:12.319790
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(None, None)
    with pytest.raises(TypeError):
        for _ in chunked_upload_stream_0: pass


# Generated at 2022-06-25 19:21:17.094717
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.headers = {}
    request.body = 'test'
    compress_request(request, False)
    assert request.body == b'x\x9cKLJ\x04\x00\x00\x00\x00\x01'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '10'



# Generated at 2022-06-25 19:21:26.437954
# Unit test for function compress_request
def test_compress_request():
    data = b"Some body data"
    content_length = super_len(data)
    headers = {'Content-Length': str(content_length)}
    request = requests.Request("POST", "http://example.com", headers=headers, data=data)
    request = request.prepare()
    compress_request(request, always=True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert super_len(request.body) != content_length


import httpie.cli.dicts as module_0
import httpie.cli as module_1


# Generated at 2022-06-25 19:21:32.432765
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # Define a valid instance of ChunkedUploadStream
    ChunkedUploadStream_instance_0 = ChunkedUploadStream(list(), print)
    ChunkedUploadStream_instance_0.stream = list(bytes())
    # Assert the iterator returned by __iter__ is callable
    assert_true(hasattr(ChunkedUploadStream_instance_0.__iter__(), '__call__'))



# Generated at 2022-06-25 19:21:42.683541
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder(
        fields=[('username', 'john'), ('password', '1234')],
        boundary='----------------------------70b5d369b6e2'
    )
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    collection_0 = chunked_multipart_upload_stream_0
    collection_1 = chunked_multipart_upload_stream_0
    collection_2 = chunked_multipart_upload_stream_0
    int_0 = collection_0.chunk_size
    int_1 = collection_1.chunk_size
    int_2 = collection_2.chunk_size
    int_3 = 10000
    int_4 = 10000
    int_

# Generated at 2022-06-25 19:21:44.882257
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    pass


# Generated at 2022-06-25 19:21:59.347610
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import io
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(None)
    # Assume the chunk size is 100kb.
    assert not chunked_multipart_upload_stream_0.chunk_size == 0
    assert not chunked_multipart_upload_stream_0.stream
    chunked_multipart_upload_stream_1 = ChunkedMultipartUploadStream(None)
    # Assume the chunk size is 100kb.
    assert not chunked_multipart_upload_stream_1.chunk_size == 0
    assert not chunked_multipart_upload_stream_1.stream
    chunked_multipart_upload_stream_2 = ChunkedMultipartUploadStream(None)
    # Assume the chunk size is 100kb.

# Generated at 2022-06-25 19:22:03.748964
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = [chunk.encode() for chunk in [body]]
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, body_read_callback)
    # __iter__ should return an iterable
    try:
        for chunk in chunked_upload_stream_0:
            pass
    except TypeError as e:
        print('TypeError raised: {}'.format(e))


# Generated at 2022-06-25 19:22:04.712383
# Unit test for function prepare_request_body
def test_prepare_request_body():
    pass



# Generated at 2022-06-25 19:22:15.770721
# Unit test for function compress_request
def test_compress_request():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    tuple_1 = (tuple_0[0], 'multipart/form-data; boundary=%s' % tuple_0[1].boundary_value)
    request_data_dict_0 = module_0.RequestDataDict()
    request_body_0 = prepare_request_body(request_data_dict_0)
    dict_0 = {'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': '0'}

# Generated at 2022-06-25 19:22:26.545533
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()

# Generated at 2022-06-25 19:22:30.285778
# Unit test for function compress_request
def test_compress_request():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)


# Generated at 2022-06-25 19:22:31.936711
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert body == return_value
    

# Generated at 2022-06-25 19:22:34.910719
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = object()
    func_0 = object()
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, func_0)
    for chunk in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:22:38.859196
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    encoder_0 = MultipartEncoder(fields={})
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(encoder_0)
    tuple_0 = chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:22:41.086319
# Unit test for function compress_request
def test_compress_request():

    import requests
    always = True
    request = requests.PreparedRequest()
    compress_request(request, always)


# Generated at 2022-06-25 19:22:49.593894
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    compress_request(request, True)


# Generated at 2022-06-25 19:22:50.598017
# Unit test for function prepare_request_body
def test_prepare_request_body():
    pass



# Generated at 2022-06-25 19:23:00.483160
# Unit test for function compress_request
def test_compress_request():
    import requests
    import httpie.cli.dicts as module_0

    request_0 = requests.PreparedRequest()
    request_0.body = 'request_0.body'
    request_0.headers = module_0.KeyValue()
    request_0.headers['Content-Type'] = 'application/x-www-form-urlencoded'
    
    compress_request(request_0, False)

    assert 'Content-Type' in request_0.headers

# Generated at 2022-06-25 19:23:04.218163
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ()
    callback = lambda stream: None
    chunked_upload_stream_0 = ChunkedUploadStream(stream, callback)
    iter_0 = chunked_upload_stream_0.__iter__()
    tuple_0 = next(iter_0)


# Generated at 2022-06-25 19:23:09.421643
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # do not use assertRaises in the test
    stream_0 = ['']
    callback_0 = test_ChunkedUploadStream___iter___callback_0
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, callback_0)
    iterator_0 = chunked_upload_stream_0.__iter__()

# Generated at 2022-06-25 19:23:12.458861
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    tuple_0 = prepare_request_body(request_data_dict_0, lambda chunk: None)


# Generated at 2022-06-25 19:23:16.345250
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder(fields=())
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    assert chunked_multipart_upload_stream_0.__iter__() is not None


# Generated at 2022-06-25 19:23:19.314971
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = False
    # Assert
    compress_request(request, always)


# Generated at 2022-06-25 19:23:28.199593
# Unit test for function compress_request
def test_compress_request():

        import json
        import httpie.cli.dicts as module_0
        import requests

        json.dumps({'info': 'httpie', 'verison': '1.0.2'}, indent=2)

        http_request_0 = module_0.MultipartRequestDataDict()
        http_request_0['info'] = 'httpie'
        http_request_0['verison'] = '1.0.2'

        headers_0 = {}
        headers_0['Content-Type'] = 'application/json'
        headers_0['Content-Length'] = '15'

        http_request_0 = module_0.MultipartRequestDataDict()
        http_request_0['info'] = [1234]

        headers_1 = {}

# Generated at 2022-06-25 19:23:31.878799
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(MultipartEncoder())
    str_0 = str(chunked_multipart_upload_stream_0)
    assert str_0 == '[<ChunkedMultipartUploadStream>]'


# Generated at 2022-06-25 19:23:46.579775
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    multipart_encoder_0, str_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    for x in [1, 2, 3]:
        iterator_0 = chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:23:57.594716
# Unit test for function compress_request
def test_compress_request():
    import requests

    # Test with no body, but no Content-Length header
    request_0 = requests.PreparedRequest()
    request_0.headers = {
        'Content-Length': None
    }

    assert request_0.body is None
    assert request_0.headers['Content-Length'] is None
    compress_request(request_0, always=False)
    assert request_0.body is None
    assert request_0.headers['Content-Length'] is None

    # Test with empty string body
    request_0 = requests.PreparedRequest()
    request_0.body = ''
    request_0.headers = {
        'Content-Length': str(len(request_0.body))
    }
    assert request_0.body == ''
    assert request_0.headers['Content-Length'] == '0'


# Generated at 2022-06-25 19:24:01.786008
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    # initialization
    chunked_multipart_upload_stream = ChunkedMultipartUploadStream()

    # test
    test_string = chunked_multipart_upload_stream.__iter__()


# Generated at 2022-06-25 19:24:08.419899
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = b'abc'
    body_read_callback = lambda chunk: print(chunk)
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    body_1 = prepare_request_body(body, body_read_callback, True, False)
    print(body_1)
    pass

# Generated at 2022-06-25 19:24:18.995976
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = '\xFF\xD8'
    body_read_callback = lambda bytes: bytes
    cll = 6
    chunked = True
    offline = False
    res = prepare_request_body(body, body_read_callback, cll, chunked, offline)
    assert(res == b'\xFF\xD8')
    body = '\xFF\xD8'
    body_read_callback = lambda bytes: bytes
    cll = 6
    chunked = True
    offline = True
    res = prepare_request_body(body, body_read_callback, cll, chunked, offline)
    assert(res == b'\xFF\xD8')
    body = '\xFF\xD8'
    body_read_callback = lambda bytes: bytes
    cll = 6


# Generated at 2022-06-25 19:24:23.287031
# Unit test for function compress_request
def test_compress_request():
    requests_prepared_request_0 = requests.PreparedRequest()
    compress_request(requests_prepared_request_0, False)


# Generated at 2022-06-25 19:24:24.192201
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    pass


# Generated at 2022-06-25 19:24:33.102693
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # TODO: Should we keep a `request_data` argument here?
    #   If not, all callsites should be refactored.
    #   If we do, then this is a backward-incompatible change.
    #   Wait until v3.0.0 to decide.
    chunkeduploadstream_0 = ChunkedUploadStream( ( 'foo', 'bar', 'baz' ), None )
    for loop_var_0 in chunkeduploadstream_0:
        pass


# Generated at 2022-06-25 19:24:36.003613
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    ChunkedMultipartUploadStream_instance_0 = ChunkedMultipartUploadStream( )
    Iterable_0 = ChunkedMultipartUploadStream_instance_0.__iter__()


# Generated at 2022-06-25 19:24:45.065587
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    multipart_encoder_0 = MultipartEncoder(fields=multipart_request_data_dict_0.items(), boundary=None)
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.encoder.read = lambda : b''
    chunked_multipart_upload_stream_0.chunk_size = 100 * 1024
    list_0 = list(chunked_multipart_upload_stream_0)
    list_1 = list(chunked_multipart_upload_stream_0)

# Generated at 2022-06-25 19:25:00.946284
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Blanket unit test
    request_data_dict_0 = module_0.RequestDataDict()
    bytes_0 = b'l\xda.'
    file_like_object_0 = io.BytesIO(bytes_0)
    str_0 = ''
    multipart_encoder_0 = MultipartEncoder()
    multipart_encoder_0 = MultipartEncoder(fields={})
    dict_0 = {}

    def function_0(bytes_1):
        return bytes_1

    prepare_request_body(request_data_dict_0, function_0)
    prepare_request_body(file_like_object_0, function_0)
    prepare_request_body(file_like_object_0, function_0, content_length_header_value=0)
    prepare_request_

# Generated at 2022-06-25 19:25:05.303837
# Unit test for function compress_request
def test_compress_request():
    increment_0 = 1
    request_obj_0 = requests.PreparedRequest()
    file_obj_0 = open('/dev/null','r')
    request_obj_0.body = file_obj_0
    always_0 = True
    compress_request(request_obj_0, always_0)


# Generated at 2022-06-25 19:25:12.265010
# Unit test for function compress_request
def test_compress_request():
    string_0 = '<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>Document</title>\n</head>\n<body>\n    <h1>Hello world</h1>\n</body>\n</html>\n'
    requests_prepared_request_0 = requests.Request('GET', 'http://vnexpress.net', data=string_0).prepare()
    compress_request(requests_prepared_request_0, True)

# Generated at 2022-06-25 19:25:16.511018
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = (1, 2)
    callback_0 = key
    deflater = zlib.compressobj()
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, callback_0)
    for chunk in chunked_upload_stream_0:
        deflater.compress(chunk)


# Generated at 2022-06-25 19:25:27.091676
# Unit test for function compress_request
def test_compress_request():
    def _test_compress_request_0():
        # Test case 0
        def _test_case_0_0():
            # Test nested case 0
            def _test_case_0_0_0():
                # Test nested case 0
                pass
            # Test nested case 1
            def _test_case_0_0_1():
                # Test nested case 0
                pass
        # Test nested case 1
        def _test_case_0_1():
            # Test nested case 0
            def _test_case_0_1_0():
                # Test nested case 0
                pass
            # Test nested case 1
            def _test_case_0_1_1():
                # Test nested case 0
                pass
        # Test nested case 2

# Generated at 2022-06-25 19:25:34.035436
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict_1 = module_0.MultipartRequestDataDict()
    tuple_1 = get_multipart_data_and_content_type(multipart_request_data_dict_1)
    tuple_2 = get_multipart_data_and_content_type(multipart_request_data_dict_1, boundary="0x00", content_type="")

    assert isinstance(tuple_1, tuple)

import httpie.cli.args as module_1



# Generated at 2022-06-25 19:25:41.879191
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    assert tuple_0[0] is not None
    assert tuple_0[1] is not None

if __name__ == '__main__':
    from tests.test_multipart import test_case_0
    from tests.test_multipart import test_get_multipart_data_and_content_type
    test_case_0()
    test_get_multipart_data_and_content_type()

# Generated at 2022-06-25 19:25:42.660284
# Unit test for function compress_request
def test_compress_request():
    pass

# Generated at 2022-06-25 19:25:48.153421
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = ""
    always = False
    assert compress_request(request, always) == None
    assert request.body == ""
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '0'
    return


# Generated at 2022-06-25 19:25:50.460261
# Unit test for function compress_request
def test_compress_request():

    # Setup
    request = ...

    # Exercise
    compress_request(request)

    # Verify
    assert True


# Generated at 2022-06-25 19:26:02.647367
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Setup
    body_0 = 'a'
    body_read_callback_0 = lambda _: None
    chunked_0 = False
    offline_0 = False
    expected_result_0 = 'a'

    # Invocation and assertions
    body_1 = prepare_request_body(body_0, body_read_callback_0, chunked_0, offline_0)
    assert body_1 == expected_result_0


# Generated at 2022-06-25 19:26:12.686314
# Unit test for function prepare_request_body
def test_prepare_request_body():

    # Test body is string type
    str_body = "This is a string"
    body = prepare_request_body(str_body, lambda x: 0)
    assert body == str_body

    # Test body is bytes type
    bytes_body = b"\x00\x01\x02\x03"
    body = prepare_request_body(bytes_body, lambda x: 0)
    assert body == bytes_body

    # Test body is RequestDataDict type
    request_data_dict_body = RequestDataDict()
    body = prepare_request_body(request_data_dict_body, lambda x: 0)
    assert body == urlencode(request_data_dict_body, doseq=True)

    # Test body is MultipartEncoder type

# Generated at 2022-06-25 19:26:18.729609
# Unit test for function compress_request
def test_compress_request():
    import requests, unittest
    class TestCompressRequest(unittest.TestCase):
        def test_compress_request_0(self):
            request = requests.PreparedRequest()
            always = False
            compress_request(request, always)
        def test_compress_request_1(self):
            request = requests.PreparedRequest()
            always = True
            compress_request(request, always)
    unittest.main()


# Generated at 2022-06-25 19:26:25.880388
# Unit test for function compress_request
def test_compress_request():
    import httpie.server  # noqa
    import threading
    import requests
    import requests.structures
    import requests.exceptions
    from httpie.cli.exit import exit_json
    from httpie.server import start_server
    from requests.structures import CaseInsensitiveDict
    from requests.exceptions import ConnectionError
    from httpie.cli.argtypes import KeyValue
    from httpie.cli import cli
    from httpie import ExitStatus

    request_0 = requests.PreparedRequest()
    str_0 = ''
    request_0.body = str_0
    request_0.headers = CaseInsensitiveDict()
    compress_request(request_0, True)

    # Unit test for function module_0.MultipartRequestDataDict

# Generated at 2022-06-25 19:26:36.600179
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict)
    multipart_request_data_dict = module_0.MultipartRequestDataDict()
    content_type = "multipart/form-data"
    tuple_1 = get_multipart_data_and_content_type(multipart_request_data_dict, "boundary", content_type)
    multipart_request_data_dict = module_0.MultipartRequestDataDict()
    content_type = "application/x-www-form-urlencoded"

# Generated at 2022-06-25 19:26:45.953371
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_0 = 'A body'
    passed_arg_0 =  'A body'
    expected_return_value_0 = ChunkedUploadStream
    computed_return_value_0 = prepare_request_body(body_0, passed_arg_0)
    assert type(computed_return_value_0) == expected_return_value_0
    
    body_1 = 'A body'
    passed_arg_1 =  'A body'
    expected_return_value_1 = ChunkedUploadStream
    computed_return_value_1 = prepare_request_body(body_1, passed_arg_1)
    assert type(computed_return_value_1) == expected_return_value_1
    
    body_2 = 'A body'
    passed_arg_2 =  'A body'


# Generated at 2022-06-25 19:26:54.861096
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    bytes_0 = prepare_request_body(request_data_dict_0)
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    data_0, content_type_0 = tuple_0
    bytes_1 = prepare_request_body(data_0)
    request_data_dict_1 = module_0.RequestDataDict()
    def body_read_callback_0(chunk_0):
        pass
    tuple_1 = (request_data_dict_1, body_read_callback_0)

# Generated at 2022-06-25 19:26:59.134761
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(
        [
            "abc",
            "def",
            "ghi",
            "jkl",
        ]
    )
    tuple_0 = chunked_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:27:02.567898
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    #assertion
    exception_0 = None
    try:
        prepare_request_body(request_data_dict_0, lambda x : x, None)
    except Exception as exception:
        exception_0 = exception
    assert exception_0 is None

# Generated at 2022-06-25 19:27:12.321764
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Initial state
    body_read_callback = None

    body = ''

    chunked = False
    offline = False

    # Body is byte string -> it is "file-like".
    body = b'some stuff'

    result, = prepare_request_body(
        body,
        body_read_callback,
        chunked=chunked,
        offline=offline,
    )

    # Check that result is not a callable (ie, not a generator).
    result(None)

    # Body is byte string -> it is "file-like".
    body = b'some stuff'

    # Offline
    offline = True

    result, = prepare_request_body(
        body,
        body_read_callback,
        chunked=chunked,
        offline=offline,
    )

    # Check that

# Generated at 2022-06-25 19:27:19.099721
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert True
    # Tested on x64 Windows 10, no exceptions raised


# Generated at 2022-06-25 19:27:25.446479
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = b'body'
    chunked = False
    content_length_header_value = None
    offline = False
    def body_read_callback(chunk):
        pass
    result = prepare_request_body(
        body=body,
        body_read_callback=body_read_callback,
        chunked=chunked,
        content_length_header_value=content_length_header_value,
        offline=offline,
    )


# Generated at 2022-06-25 19:27:34.727073
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_0 = str()
    body_read_callback_0 = lambda arg_0: arg_0
    tuple_0 = prepare_request_body(body_0, body_read_callback_0)
    body_1 = bytes()
    tuple_1 = prepare_request_body(body_1, body_read_callback_0)
    body_2 = io.StringIO()
    tuple_2 = prepare_request_body(body_2, body_read_callback_0)
    body_3 = io.BytesIO()
    tuple_3 = prepare_request_body(body_3, body_read_callback_0)
    multipart_encoder_0 = requests_toolbelt.MultipartEncoder()

# Generated at 2022-06-25 19:27:41.499492
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Content-Type: application/json
    prepare_request_body(body="""{"foo": "bar"}""", body_read_callback=start)

    # Content-Type: application/json
    prepare_request_body(body="""{"foo": "bar"}""", body_read_callback=start, chunked=True)

    # Content-Type: application/json
    prepare_request_body(body="""{"foo": "bar"}""", body_read_callback=start, chunked=True, offline=True)


# Generated at 2022-06-25 19:27:50.779486
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import argparse as module_0
    import requests as module_1
    import typing as module_2
    import typing as module_3
    import typing as module_4
    import typing as module_5

    argument_parser_0 = module_0.ArgumentParser()
    
    substring_0 = argument_parser_0.add_mutually_exclusive_group()
    substring_0.add_argument('--verbose', action='store_true')
    
    substring_1 = argument_parser_0.add_argument('--compress', default=False, action='store_true')
    substring_1.add_argument('--compress-alg', default='deflate', action='store')
    
    str_0 = 'The URL that the request is sent to.'

# Generated at 2022-06-25 19:27:59.823903
# Unit test for function prepare_request_body
def test_prepare_request_body():
    dict_0 = {'data': 'value'}
    request_data_dict_0 = module_0.RequestDataDict()
    request_data_dict_0.update(dict_0)
    request_data_dict_1 = module_0.RequestDataDict()
    request_data_dict_1.update(dict_0)
    tuple_0 = get_multipart_data_and_content_type(request_data_dict_1)
    request_data_dict_2 = module_0.RequestDataDict()
    request_data_dict_2.update(dict_0)
    request_data_dict_2._as_value = lambda  : ''

# Generated at 2022-06-25 19:28:04.129662
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(
        callback=test_ChunkedUploadStream___iter__,
        stream=(chunk.encode() for chunk in [""]),
    )
    for _ in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:28:07.208087
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = ['stream']
    callback_0 = print
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, callback_0)
    tuple_0 = zip(chunked_upload_stream_0)


# Generated at 2022-06-25 19:28:18.200240
# Unit test for function compress_request
def test_compress_request():
    url_0 = 'http://httpbin.org/post'
    content_type_0 = 'text/plain'
    body_0 = '\n  Hello, world!\n'
    request_0 = requests.PreparedRequest()
    request_0.prepare(
        method='POST',
        url=url_0,
        headers={'Content-Type': content_type_0},
        data=body_0
    )
    compress_request(
        request_0,
        always=True
    )
    assert request_0.body == b'x\x9c\xcbH,W(\xcf/\xcaI\x01\x00O\x9a\x04Z\xab\x00\x00'

# Generated at 2022-06-25 19:28:26.916642
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_0 = "test"
    body_read_callback_0 = print
    body_1 = "test"
    body_read_callback_1 = print
    body_2 = "test"
    body_read_callback_2 = print
    body_3 = "test"
    body_read_callback_3 = print
    body_4 = "test"
    body_read_callback_4 = print
    body_5 = "test"
    body_read_callback_5 = print
    body_6 = "test"
    body_read_callback_6 = print
    body_7 = "test"
    body_read_callback_7 = print

    tuple_0 = prepare_request_body(body_0, body_read_callback_0)

# Generated at 2022-06-25 19:28:47.462935
# Unit test for function prepare_request_body
def test_prepare_request_body():
    data = RequestDataDict({"a": "b"})
    prepared_data = prepare_request_body(data, lambda x: x)
    if isinstance(prepared_data, str):
        assert prepared_data == "a=b"

    data = RequestDataDict({"a": ["b", "c"]})
    prepared_data = prepare_request_body(data, lambda x: x)
    if isinstance(prepared_data, str):
        assert prepared_data == "a=b&a=c"

    # A simple body
    prepared_data = prepare_request_body("body", lambda x: x)
    assert prepared_data == "body"

    # A simple body with chunked encoding
    # TODO: This does not work with the current implementation of
    #   ChunkedUploadStream. Either improve the

# Generated at 2022-06-25 19:28:48.997969
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = True
    compress_request(request, always)
    assert request.body == None
    assert request.headers == {'Content-Encoding': 'deflate', 'Content-Length': '0'}


# Generated at 2022-06-25 19:28:57.939952
# Unit test for function compress_request
def test_compress_request():
    import zlib
    from requests.structures import CaseInsensitiveDict
    from requests.models import Request

    request = Request(method='POST', url='http://www.example.com/',
                      data='body')
    compress_request(request, always=True)
    assert (request.headers['Content-Encoding'] == 'deflate')
    assert (request.body == zlib.compressobj().compress(b'body') +
            zlib.compressobj().flush())

    request = Request(method='POST', url='http://www.example.com/',
                      data='body')
    compress_request(request, always=False)
    assert (request.headers['Content-Encoding'] == 'deflate')

# Generated at 2022-06-25 19:29:07.305656
# Unit test for function compress_request
def test_compress_request():
    multipart_request_data_dict_2 = module_0.MultipartRequestDataDict()
    tuple_2 = get_multipart_data_and_content_type(multipart_request_data_dict_2)
    case_0 = tuple_2
    case_1 = case_0
    case_2 = case_1
    case_3 = case_2
    case_4 = case_3
    case_5 = case_4
    case_6 = case_5
    request_5 = requests.PreparedRequest()
    request_5.body = case_6
    request_5.headers = {'Content-Encoding': 'deflate', 'Content-Length': 'str(len(deflated_data))'}
    compress_request(request_5, False)

test_compress_request()

# Generated at 2022-06-25 19:29:11.507576
# Unit test for function prepare_request_body
def test_prepare_request_body():
    data_0 = 'multipart/form-data; boundary=TestBoundary'
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    assert str(prepare_request_body(multipart_request_data_dict_0, lambda x: x, content_type=data_0)) == 'multipart/form-data; boundary=----------------------------23b395a13b93'
    assert True is True


# Generated at 2022-06-25 19:29:13.757538
# Unit test for function compress_request
def test_compress_request():
    # Assign
    request = requests.PreparedRequest(requests.Request('GET', ''))
    always = False
    request.body = 'test' * 1000000
    # Act
    compress_request(request, always)
    # Assert
    assert request.headers['Content-Encoding'] == 'deflate' or None
    assert request.headers['Content-Length'] == '780906'

test_case_0()
test_compress_request()

# Generated at 2022-06-25 19:29:18.437180
# Unit test for function compress_request
def test_compress_request():
    # TODO: Refactor
    request = mock.MagicMock()
    def test_case_0():
        # TODO: Refactor
        request.body = "body"
        request.headers = {}
        compress_request(request, True)
        assert request.body == b'd\xc2\x11\x00\xdd\xaf?\xbd\x01\x00\x00'
        assert request.headers['Content-Encoding'] == 'deflate'
        assert request.headers['Content-Length'] == '11'

# Generated at 2022-06-25 19:29:26.062499
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    import collections.abc as module_0
    import typing as module_1
    import io as module_2

    chunked_upload_stream_0 = ChunkedUploadStream(object(), object())
    iterator_0 = iter(chunked_upload_stream_0)
    assert isinstance(iterator_0, module_0.Iterator)

    chunked_upload_stream_1 = ChunkedUploadStream(object(), object())
    
    with pytest.raises(StopIteration):
        next(iter(chunked_upload_stream_1))


# Generated at 2022-06-25 19:29:34.277901
# Unit test for function compress_request
def test_compress_request():
    from requests import PreparedRequest
    from httpie.cli.dicts import MultipartRequestDataDict, RequestDataDict
    from requests_toolbelt.multipart.encoder import MultipartEncoder
    import zlib
    from typing import Callable, IO, Iterable, Tuple, Union
    from urllib.parse import urlencode

    import requests
    from requests.utils import super_len
    from requests_toolbelt import MultipartEncoder

    from httpie.cli.dicts import MultipartRequestDataDict, RequestDataDict

    class ChunkedUploadStream:
        def __init__(self, stream: Iterable, callback: Callable):
            self.callback = callback
            self.stream = stream


# Generated at 2022-06-25 19:29:44.439264
# Unit test for function compress_request
def test_compress_request():
    class MockResponse:
        def __init__(self, content):
            self.content = content

    class MockSession:
        def post(self, url):
            return MockResponse(b'testing')

        def __enter__(self):
            return MockSession()

        def __exit__(self, exc_type, exc_value, traceback):
            pass

    # check response content
    request = requests.PreparedRequest()
    request.body = 'testing'
    with MockSession() as session:
        response = session.post('http://httpbin.org/post', data=request.body)
        assert response.content == b'testing'
    # check deflate is applied
    compress_request(request, True)

# Generated at 2022-06-25 19:30:31.426658
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, False)


from contextlib import contextmanager
import io
from typing import ContextManager

from requests.models import Response

from httpie.core import main
from httpie.context import Environment
from httpie.compat import str
from httpie.cli.argtypes import KeyValueArgType
from httpie.input import SEP_CREDENTIALS, SEP_GROUP, SEP_HEADER, SEP_QUERY, DataDict
from httpie.output import BINARY_SUPPRESSED_NOTICE



# Generated at 2022-06-25 19:30:39.189350
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert prepare_request_body(dict()) == b'{}'
    assert prepare_request_body(dict(a=1)) == b'a=1'
    assert prepare_request_body(dict(a='1')) == b'a=1'
    assert prepare_request_body(dict(a=1, b=2, c=3)) == b'a=1&b=2&c=3'
    assert prepare_request_body(dict(a=1, b='foo bar')) == b'a=1&b=foo+bar'
    assert prepare_request_body(dict(a=1, b='\t')) == b'a=1&b=%09'
    assert prepare_request_body(dict(a=1, b='\\')) == b'a=1&b=%5C'