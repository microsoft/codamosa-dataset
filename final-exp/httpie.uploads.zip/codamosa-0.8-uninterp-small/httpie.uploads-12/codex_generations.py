

# Generated at 2022-06-25 19:21:05.316091
# Unit test for function compress_request
def test_compress_request():
    class Request:
        def __init__(self):
            self.headers = {'Content-Length': 12}
            self.body = 'Hello World!'

    class PreparedRequest:
        def __init__(self):
            self.headers = {'Content-Length': 12}
            self.body = 'Hello World!'

    request = Request()
    pequest = PreparedRequest()

    compress_request(request, False)
    assert request.headers['Content-Length'] == '12'
    assert len(request.body) == 12

    compress_request(pequest, False)
    assert pequest.headers['Content-Length'] == '10'
    assert len(pequest.body) == 10

# Generated at 2022-06-25 19:21:12.242539
# Unit test for function prepare_request_body
def test_prepare_request_body():
    def body_read_callback(chunk: bytes) -> bytes:
        # TODO: Write unit test for prepare_request_body
        pass

    body = b''
    content_length_header_value = 0
    chunked = False
    offline = False

    var_0 = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)


# Generated at 2022-06-25 19:21:13.880579
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # TEST CASE 0
    test_case_0()

test_ChunkedUploadStream___iter__()

# Generated at 2022-06-25 19:21:21.658455
# Unit test for function compress_request
def test_compress_request():
    with open('httpie-pytest-result.json', 'r') as f:
        input_json = f.read()

    p = requests.PreparedRequest()
    p.body = input_json
    p.headers = {}
    p.headers['Content-Type'] = 'application/json'
    compress_request(p,True)

    # The result should be equal to the sample result
    with open('httpie-pytest-expected.json', 'rb') as f:
        expected_result = f.read()
    assert expected_result == p.body

# Generated at 2022-06-25 19:21:26.150481
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    var_0 = ChunkedUploadStream()
    var_1 = ChunkedUploadStream()
    var_0.stream = var_1.stream
    var_0.callback = var_1.callback
    var_0.__iter__()


# Generated at 2022-06-25 19:21:33.800487
# Unit test for function compress_request
def test_compress_request():
    data = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    bytes_input = BytesIO(data)
    request = requests.PreparedRequest()
    request.body = bytes_input
    compress_request(request, 1)
    compressed_data = request.body
    decompressed_data = zlib.decompressobj().decompress(compressed_data)
    assert decompressed_data == data

# Generated at 2022-06-25 19:21:36.450329
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = ChunkedUploadStream(b'', b'')
    stream.__iter__()



# Generated at 2022-06-25 19:21:43.660472
# Unit test for function compress_request
def test_compress_request():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    var_0 = prepare_request_body(bytes_0, bytes_0)
    var_1 = requests.PreparedRequest()
    var_1.body = var_0
    compress_request(var_1, True)
    var_1.headers['Content-Encoding'] = 'deflate'
    var_1.headers['Content-Length'] = str(len(var_1.body))


test_case_0()
test_compress_request()

# Generated at 2022-06-25 19:21:53.053050
# Unit test for function compress_request
def test_compress_request():
    var_0 = {'Content-Encoding': 'deflate'}
    var_1 = 'deflate'
    var_2 = requests.PreparedRequest()
    var_2.headers = var_0
    var_2.body = 'deflate'
    var_2.headers['Content-Length'] = len('deflate')
    compress_request(var_2, False)
    assert var_2.headers == var_0
    assert var_2.body == var_1
    assert var_2.headers['Content-Length'] == len('deflate')


# Generated at 2022-06-25 19:21:56.051082
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    var_0 = prepare_request_body(bytes_0, bytes_0)


# Generated at 2022-06-25 19:22:16.310190
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Tests with param body_read_callback
    # Tests with param content_length_header_value
    # Tests with param chunked
    # Tests with param offline
    prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)

    # Tests with param body_read_callback
    # Tests with param content_length_header_value
    # Tests with param chunked
    prepare_request_body(body, body_read_callback, content_length_header_value, chunked)

    # Tests with param body_read_callback
    # Tests with param content_length_header_value
    # Tests with param offline
    prepare_request_body(body, body_read_callback, content_length_header_value, offline=offline)



# Generated at 2022-06-25 19:22:17.781942
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    assert callable(getattr(ChunkedUploadStream, '__iter__', None))


# Generated at 2022-06-25 19:22:24.188795
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "abcd"
    request.headers = {}
    compress_request(request, True)
    assert request.body == b'x\x9c\\\xcbH\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00\xaa\x04\x82\x04'
    assert request.headers == {'Content-Encoding': 'deflate', 'Content-Length': '28'}


# Generated at 2022-06-25 19:22:27.148392
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = True
    compress_request_0 = compress_request(request, always)


# Generated at 2022-06-25 19:22:28.623945
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert isinstance(prepare_request_body(), object)


# Generated at 2022-06-25 19:22:38.647401
# Unit test for function compress_request
def test_compress_request():
    from httpie.cli.requestbuilder import construct_request_from_args
    from httpie.plugins.builtin import HTMLFormParser
    from httpie.compat import is_py26
    from httpie.core import main
    from httpie.output.streams import DefaultStream
    from httpie.plugins import builtin
    from httpie import ExitStatus
    from mock import Mock
    from pprint import pprint




# Generated at 2022-06-25 19:22:45.826438
# Unit test for function prepare_request_body
def test_prepare_request_body():

    test_multipart_encoder = MultipartEncoder()
    test_data = b'content=Hello+World'
    test_request_data_dict = RequestDataDict(test_data)
    dummy_func = lambda s: s

    rt1 = prepare_request_body(
        body=test_data, body_read_callback=dummy_func,
    )
    assert rt1 == test_data

    rt2 = prepare_request_body(
        body=test_request_data_dict, body_read_callback=dummy_func,
    )
    assert rt2 == test_data

    rt3 = prepare_request_body(
        body=test_multipart_encoder, body_read_callback=dummy_func,
    )
    assert rt3 == test_

# Generated at 2022-06-25 19:22:47.074719
# Unit test for function compress_request
def test_compress_request():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:22:51.368247
# Unit test for function compress_request
def test_compress_request():
    headers = {'Test': 'Test'}
    req = requests.PreparedRequest()
    req.headers.update(headers)
    data = 'Hello World'
    req.body = data
    compress_request(req, False)
    pass

# Generated at 2022-06-25 19:23:01.036689
# Unit test for function compress_request
def test_compress_request():
    import requests
    from requests.structures import CaseInsensitiveDict
    from requests.compat import BytesIO
    # Case 1:
    # body_bytes = b'helllo world'
    # deflater = zlib.compressobj()
    # deflated_data = deflater.compress(body_bytes)
    # deflated_data += deflater.flush()
    # is_economical = len(deflated_data) < len(body_bytes)
    prepared_request_0 = requests.PreparedRequest()
    prepared_request_0.url = 'https://www.google.com'
    prepared_request_0.method = 'GET'
    prepared_request_0.headers = CaseInsensitiveDict({
        'Content-Type': 'application/json'
    })

# Generated at 2022-06-25 19:23:10.931276
# Unit test for function compress_request
def test_compress_request():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    var_0 = prepare_request_body(bytes_0, bytes_0)

# Generated at 2022-06-25 19:23:15.752209
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test 0
    # bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    # body_read_callback = bytes_0
    # var_0 = prepare_request_body(bytes_0, body_read_callback)
    # assert var_0 ==
    pass

# Generated at 2022-06-25 19:23:23.462404
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    callback = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    obj = ChunkedUploadStream(stream, callback)
    __result = obj.__iter__()
    assert type(__result) == Iterable


# Generated at 2022-06-25 19:23:30.609904
# Unit test for function prepare_request_body

# Generated at 2022-06-25 19:23:39.596683
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    bytes_1 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    ChunkedUploadStream(bytes_0, bytes_1).__iter__()

# Unit Test for method __iter__ of class ChunkedMultipartUploadStream

# Generated at 2022-06-25 19:23:45.150141
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b'\xeb\x0f\x95B$\xe8\x17\xd6\xcb\t\x80\xdd\x7f\xd4\xb4\x04_\xab\x0c\xee\x1b\x8e\x9f\x99\xbc\x08'
    class_1 = ChunkedUploadStream(bytes_0, bytes_0)
    int_0 = class_1.__iter__()



# Generated at 2022-06-25 19:23:50.605224
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    print('Executing function test_get_multipart_data_and_content_type')
    # TODO: Do something with these values (return data?)
    test_get_multipart_data_and_content_type_data, test_get_multipart_data_and_content_type_content_type = get_multipart_data_and_content_type({})


# Generated at 2022-06-25 19:24:00.577369
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    prepare_request_body(body_read_callback=bytes)
    data = '2'
    data1 = data.encode()
    data2 = encode(data1)
    deflater = zlib.compressobj()
    body_bytes = request.body
    request.body = deflater.compress(body_bytes)
    request.headers['Content-Encoding'] = 'deflate'
    request.headers['Content-Length'] = str(len(deflated_data))
    set_content_length_header(request)
    content_length = request.headers['content-length']
    len(request.body)


# Generated at 2022-06-25 19:24:08.101453
# Unit test for function compress_request
def test_compress_request():
    import requests
    import urllib3
    urllib3.disable_warnings()
    request = requests.PreparedRequest()
    request.body = "Testing compress_request"

# Generated at 2022-06-25 19:24:18.689592
# Unit test for function compress_request
def test_compress_request():
    import requests
    import requests.auth
    import httpie.cli.auth
    from httpie.cli.parser import ItemSpec
    request_1 = requests.Request(url='https://httpbin.org/post', method='POST', data={})
    auth_1 = None
    sender = httpie.cli.auth.AuthCredentials(auth_1, ItemSpec(key=None, sep=None, val=None, orig=None))
    prepared_1 = request_1.prepare()
    sender.apply(prepared_1)
    compress_request(prepared_1, True)
    assert len(prepared_1.body) == 42
    assert prepared_1.headers['Content-Encoding'] == 'deflate'
    assert prepared_1.headers['Content-Length'] == '42'



# Generated at 2022-06-25 19:24:32.094086
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    var_16 = ChunkedUploadStream(bytes_0, bytes_0)
    var_17 = iter(var_16)
    var_18 = next(var_17)


# Generated at 2022-06-25 19:24:34.865787
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    var_0 = prepare_request_body(bytes(), bytes(1))
    var_1 = test_case_0()
    for var_2 in var_1:
        var_2


# Generated at 2022-06-25 19:24:36.763703
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    body = "data"
    request.body = body
    compress_request(request, True)

# Generated at 2022-06-25 19:24:40.819529
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict({'key1': 'value1'})
    boundary = 'boundary'
    content_type = 'content_type'
    data, content_type = get_multipart_data_and_content_type(data, boundary, content_type)


# Generated at 2022-06-25 19:24:47.199925
# Unit test for function compress_request
def test_compress_request():
    def dummy_callback(data):
        return data

    body = b"hello world"

    always = False

    request = requests.Request("POST", "https://google.com", data=body)

    prepared = request.prepare()

    compress_request(prepared, always)


test_case_0()
test_compress_request()

# Generated at 2022-06-25 19:24:48.799235
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.headers = {}

    compress_request(request, True)

# Generated at 2022-06-25 19:24:52.308574
# Unit test for function prepare_request_body
def test_prepare_request_body():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    var_0 = prepare_request_body(bytes_0, bytes_0)
    assert var_0 == bytes_0



# Generated at 2022-06-25 19:24:53.013828
# Unit test for function prepare_request_body
def test_prepare_request_body():
    test_case_0()


# Generated at 2022-06-25 19:24:55.875547
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "test"
    request.headers['Content-Length'] = str(len(request.body))
    assert request.body == "test"
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'

# Generated at 2022-06-25 19:24:59.126165
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    ChunkedUploadStream(bytes_0, bytes_0)


# Generated at 2022-06-25 19:25:09.663094
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    compress_request(request, always=False)
    return True


if __name__ == '__main__':
    # assert test_compress_request()==True
    test_case_0()

# Generated at 2022-06-25 19:25:12.815979
# Unit test for function prepare_request_body
def test_prepare_request_body():
    data = ['a', 'b', 'c']
    callback = lambda x : data.append(x)
    prepare_request_body(data, callback)
    print(data)
    assert data[-1] == 'c'

# Generated at 2022-06-25 19:25:20.128633
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b'\x0e\xe9\x16\x04\x90\x8f\x1d\xf6Z\xa6\x8b\x91\xdc\x10\xbb\x8c\x11\xce\xed\x01\xb8\xb9\xafM\x80\x1f\x8d\x96\xe5\xe1\xabb\xbc\x8a\x11\xc3'
    var_0 = ChunkedUploadStream((chunk.encode() for chunk in [bytes_0]), bytes_0)
    result = list(var_0)
    assert len(result) == 1
    assert result == [bytes_0]


# Generated at 2022-06-25 19:25:25.027868
# Unit test for function compress_request
def test_compress_request():
    class PreparedRequest:
        def __init__(self, body, headers):
            self.body = body
            self.headers = headers

    request = PreparedRequest(b"foobarbaz", {})
    compress_request(request, True)
    assert(b"foobarbaz" == request.body)
    assert("deflate" == request.headers["Content-Encoding"])

# Generated at 2022-06-25 19:25:33.118143
# Unit test for function compress_request
def test_compress_request():
    url = u'https://httpbin.org/anything'
    request_body = 'hi'
    request = requests.Request('post', url, data=request_body).prepare()
    request_body = 'hello'
    request = requests.Request('post', url, data=request_body).prepare()
    request_body = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    request = requests.Request('post', url, data=request_body).prepare()
    return request, request_body


# Generated at 2022-06-25 19:25:38.240166
# Unit test for function compress_request
def test_compress_request():
    class Request:
        body = b'The quick brown fox jumps over the lazy dog'
        headers = {
            'Content-Encoding': 'deflate',
            'Content-Length': str(len(body))
        }
    request = Request()
    data = b'The quick brown fox jumps over the lazy dog'
    compress_request(request, True)
    assert request.body == data

# Generated at 2022-06-25 19:25:43.094837
# Unit test for function compress_request
def test_compress_request():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    request_0 = requests.PreparedRequest()
    request_0.method = 'POST'
    request_0.body = bytes_0
    request_0.headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': '15'}
    compress_request(request_0, True)

test_case_0()
test_compress_request()

# Generated at 2022-06-25 19:25:50.166308
# Unit test for function prepare_request_body
def test_prepare_request_body():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    assert prepare_request_body(bytes_0, bytes_0) == b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'


# Generated at 2022-06-25 19:25:54.250973
# Unit test for function compress_request
def test_compress_request():
    class Request:
        headers = {}
        body = 'hello'

    r = Request()
    compress_request(r, True)

    assert r.headers['Content-Encoding'] == 'deflate'

    r.headers['Content-Encoding'] = 'fdsa'
    compress_request(r, False)
    assert 'Content-Encoding' not in r.headers

# Generated at 2022-06-25 19:25:59.168094
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    var_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    var_1 = ChunkedUploadStream(var_0, var_0)
    assert var_1 is not None



# Generated at 2022-06-25 19:26:15.648828
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    data = MultipartRequestDataDict({'a': 'foo', 'b': 'bar'})
    boundary = '123'
    content_type = 'Content-Type: multipart/form-data; boundary=123'
    result = get_multipart_data_and_content_type(data, boundary, content_type)

# Generated at 2022-06-25 19:26:23.627382
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    assert get_multipart_data_and_content_type({"hello": "world"}) == (MultipartEncoder({'hello': 'world'}), 'multipart/form-data; boundary=9d5b0e5b532c4bf79ba6bb86737c9715')
    try:
        get_multipart_data_and_content_type({"hello": 10})
    except requests.exceptions.RequestException as err:
        assert "Not a valid string." in str(err)

# Generated at 2022-06-25 19:26:31.982544
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import string

    from pytest import raises

    from httpie.context import Environment
    from httpie.core import main
    from httpie.models import Request
    from tests.utils import http

    for body in (b'', '', '{}'):
        bytes_ = body if isinstance(body, bytes) else body.encode()
        assert prepare_request_body(bytes_, bytes_) == bytes_
        assert prepare_request_body(bytes_, bytes_, content_length_header_value=len(bytes_)) == bytes_
        assert prepare_request_body(bytes_, bytes_, chunked=True) == bytes_
        assert prepare_request_body(bytes_, bytes_, chunked=True, offline=True) == bytes_

        # Test that chunked=False cannot be satisfied.

# Generated at 2022-06-25 19:26:39.866073
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b"Toto je velice velky kus textu, kterej by mohl byt nekompresovatelnej, ale podle myho je kompresovatelnej."
    request.headers['Content-Type'] = 'text/plain'
    always = True
    compress_request(request, always)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert len(request.body) == 77

# Generated at 2022-06-25 19:26:41.800488
# Unit test for function compress_request
def test_compress_request():
    import requests
    request = requests.PreparedRequest()
    request.body = b'\x00'
    compress_request(request, True)

# Generated at 2022-06-25 19:26:46.878805
# Unit test for function prepare_request_body
def test_prepare_request_body():

    import time
    import datetime
    start_time = time.time()
    print ("Start time: " + str(datetime.datetime.now()))

    test_case_0()

    end_time = time.time()
    print ("End time: " + str(datetime.datetime.now()))
    print ("Overall time: " + str(end_time - start_time))
    return

#test_prepare_request_body()
test_prepare_request_body()

# Generated at 2022-06-25 19:26:51.345012
# Unit test for function prepare_request_body
def test_prepare_request_body():
    try:
        assert type(test_case_0()) == bytes
    except Exception as e:
        print(str(e))

# Execute the program.
test_prepare_request_body()

# Generated at 2022-06-25 19:27:02.124087
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b"\x00\x00\x00\x00"
    var_52 = zlib.decompressobj(wbits=17)
    var_52.unconsumed_tail = bytes_0
    bytes_1 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    request_data_dict_0 = RequestDataDict(
        {"\x91\x93\xdfh\\\x8e\x11a\x93\x11\x97\xfd\xd3\xfd\xbe": "\x00\x00\x00\x00"},
    )

    content_length = 5678

# Generated at 2022-06-25 19:27:12.028708
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    bytes_1 = b'\x1a\xaa\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    bytes_2 = b'\x1a\xaa\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    var_0 = prepare_request_body(bytes_0, bytes_0)

# Generated at 2022-06-25 19:27:19.213241
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = (v for v in [ChunkedUploadStream])
    bytes_0 = urlencode({'kwargs': 'kwargs', 'a': 'a', 'b': 'b', 'args': 'args', 'data': 'data'}).encode()
    def deflater_0(var_0):
        return zlib.compressobj()
    multipart_encoder = MultipartEncoder(fields={'kwargs': 'kwargs', 'a': 'a', 'b': 'b', 'args': 'args', 'data': 'data'})
    def super_len_0(var_0):
        return super_len(var_0)
    def body_read_callback():
        return ''

# Generated at 2022-06-25 19:27:36.594780
# Unit test for function prepare_request_body
def test_prepare_request_body():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()



# Generated at 2022-06-25 19:27:41.410176
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    MultipartRequestDataDict_0 = MultipartRequestDataDict()

    MultipartRequestDataDict_0['baz'] = 'bar'
    MultipartRequestDataDict_0['foo'] = 'bar'

    var_0, var_1 = get_multipart_data_and_content_type(MultipartRequestDataDict_0, None, None)

# Generated at 2022-06-25 19:27:50.706484
# Unit test for function compress_request
def test_compress_request():
    get_multipart_data_and_content_type()
    def test_case_0():
        request = requests.PreparedRequest()
        request.url = 'http://test.com'
        request.body = b'hello world!'
        request.headers['Content-Length'] = '12'
        compress_request(request, True)
        assert request.headers['Content-Length'] == '12'
        assert request.headers['Content-Encoding'] == 'deflate'

    def test_case_1():
        request = requests.PreparedRequest()
        request.url = 'http://test.com'
        request.body = b'hello world!'
        request.headers['Content-Length'] = '12'
        compress_request(request, False)
        assert request.headers['Content-Length'] == '12'

# Generated at 2022-06-25 19:27:56.166658
# Unit test for function compress_request
def test_compress_request():
    import requests
    import zlib
    request = requests.PreparedRequest()
    request.headers['Content-Length'] = str(len(b'foo'))
    request.body = b'foo'
    compress_request(request, True)
    print(request.headers['Content-Encoding'])
    print(zlib.decompress(request.body))


if __name__ == '__main__':
    test_case_0()
    # test_compress_request()

# Generated at 2022-06-25 19:28:03.743358
# Unit test for function compress_request
def test_compress_request():
    request = prepare_request_body(b"test", b"test")
    always = False
    compress_request(request, always)
    assert request.body == b"\x78\x9c\xed\xcd\x6b\x4c\xc4\x40\x10\xc6\xef\xf9\xba\x07\xa1\x13\xe2\xa7\xb3\x0e\x82\x00\x00\x01\x0b\x63\x60\x60\x60\x00\x00\x00\x01\xff"

# Generated at 2022-06-25 19:28:11.631044
# Unit test for function compress_request
def test_compress_request():
    import base64
    import zlib
    import requests
    deflater = zlib.compressobj()
    deflated_data = deflater.compress(b'enc')
    deflated_data += deflater.flush()
    request = requests.PreparedRequest()
    request.body = b'enc'
    compress_request(request, True)
    assert request.body == deflated_data
    request = requests.PreparedRequest()
    request.body = b'encode'
    compress_request(request, False)
    assert request.body == b'encode'


# Generated at 2022-06-25 19:28:16.494426
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = b'{\n\t"foo": "bar"\n}'
    request.headers['Content-Length'] = str(len(request.body))
    compress_request(request, True)


# Example test for function get_multipart_data_and_content_type

# Generated at 2022-06-25 19:28:22.172711
# Unit test for function compress_request
def test_compress_request():
    input_request = requests.PreparedRequest()
    input_request.body = b'foo'
    input_request.headers['Content-Length'] = str(len(input_request.body))
    compress_request(input_request,False)

    # Run once
    for _ in range(10):
        test_case_0()
    # Run once
    for _ in range(10):
        test_compress_request()

# Generated at 2022-06-25 19:28:26.881908
# Unit test for function prepare_request_body
def test_prepare_request_body():
    print("Testing prepare_request_body()")

    # Arrange
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'

    # Act
    var_0 = prepare_request_body(bytes_0, bytes_0)

    # Assert
    assert var_0 == bytes_0


# Generated at 2022-06-25 19:28:34.171813
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b'\x97\x9f\x03\x8a\xc6\xd3\xb2\xea\x97\x9f\x03\x8a\xc6\xd3\xb2'
    bytes_1 = b'\xbe\x9a\x9a\x9a\x9a\x9a\x9a\xbe\x9a\x9a\x9a\x9a\x9a\x9a\xbe'
    ChunkedUploadStream(bytes_0, bytes_1)



# Generated at 2022-06-25 19:28:53.551990
# Unit test for function compress_request
def test_compress_request():
    headers = {'Content-Type': 'application/json'}
    response = requests.put(
        'https://httpbin.org/put',
        data={'a': 1, 'b': 2, 'c': 3},
        headers=headers
    )

    request = response.request
    compress_request(request, False)
    compressed_request_body = request.body

    deflater = zlib.compressobj()
    compressed_data = deflater.compress(response.request.body)
    compressed_data += deflater.flush()
    is_economical = len(compressed_data) < len(response.request.body)
    assert is_economical



# Generated at 2022-06-25 19:28:57.875311
# Unit test for function compress_request
def test_compress_request():
    test_case_0()

# Generated at 2022-06-25 19:29:07.252847
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    dict_0 = {3: 4, 2: 8, 5: 1, 4: 9}
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()

    # Keyword args

# Generated at 2022-06-25 19:29:09.316266
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert callable(prepare_request_body)
    test_case_0()
    assert True



# Generated at 2022-06-25 19:29:18.216881
# Unit test for function compress_request
def test_compress_request():
    from requests import PreparedRequest
    from urllib.request import Request, urlopen
    from requests_toolbelt.multipart.decoder import MultipartDecoder
    from headers_parser import headers_parser_cmd
    from httpie import cli

    test_file = open("./tests/resources/request.txt", "r")
    request_line = test_file.readline()
    headers = test_file.readline()
    body = test_file.read()

    method, url, version = request_line.split(' ')
    headers = headers_parser_cmd(headers)
    body = body.encode('utf-8')
    prepared_request = PreparedRequest()

# Generated at 2022-06-25 19:29:25.652630
# Unit test for function compress_request
def test_compress_request():
    # create a request
    url = "http://httpbin.org/get"
    request = requests.Request("GET", url).prepare()

    # generate random bytes
    bytes_content = os.urandom(1024)
    request.body = bytes_content
    request.headers['Content-Encoding'] = 'deflate'
    request.headers['Content-Length'] = str(len(bytes_content))
    compress_request(request, False)

    # compress
    deflater = zlib.compressobj()
    deflated_data = deflater.compress(bytes_content)
    deflated_data += deflater.flush()
    assert request.body == deflated_data

if __name__ == "__main__":
    test_case_0()
    print('Success')

# Generated at 2022-06-25 19:29:33.921520
# Unit test for function compress_request
def test_compress_request():
    var_4 = requests.PreparedRequest()
    var_4.body = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    var_4.headers = {}
    var_4.headers['Content-Encoding'] = None
    var_4.headers['Content-Length'] = '20'
    var_5 = True
    var_6 = compress_request(var_4,var_5)
    if var_6 == 0xea and var_5 == True:
        var_5 = True
        var_6 = compress_request(var_4,var_5)
        if var_6 == 0xea and var_5 == True:
            var_5 = True
            var_

# Generated at 2022-06-25 19:29:44.033130
# Unit test for function compress_request

# Generated at 2022-06-25 19:29:47.080364
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'test'
    deflater = zlib.compressobj()
    body = request.body.encode()
    deflated_data = deflater.compress(body)
    deflated_data += deflater.flush()
    is_economical = len(deflated_data) < len(body)
    if is_economical:
        request.body = deflated_data
        request.headers['Content-Encoding'] = 'deflate'
        request.headers['Content-Length'] = len(deflated_data)

# Generated at 2022-06-25 19:29:54.398489
# Unit test for function compress_request
def test_compress_request():
    class PreparedRequest:
        def __init__(self, input_body):
            self.body = input_body
            self.headers = {}

    request_object = PreparedRequest(b"abcdefghijklmnop")
    compress_request(request_object, 1)
    if 'Content-Encoding' in request_object.headers:
        if 'Content-Length' in request_object.headers:
            if request_object.headers['Content-Length'] == '17':
                if request_object.body[-2:] == b'\x6e\x6f':
                    return True
    return False


# Generated at 2022-06-25 19:30:21.454132
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    obj = ChunkedUploadStream(None, None)


# Generated at 2022-06-25 19:30:26.145896
# Unit test for function prepare_request_body
def test_prepare_request_body():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = prepare_request_body(bytes_0, bytes_0)
    assert check_bytes_value_0(var_0)


# Generated at 2022-06-25 19:30:27.019102
# Unit test for function compress_request
def test_compress_request():
    assert True == True

# Generated at 2022-06-25 19:30:31.807552
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = prepare_request_body(bytes('test', encoding='utf-8'), bytes(b''))
    sol = iter(ChunkedUploadStream(stream, bytes(b'')))
    assert str(type(sol)) == "<class 'generator'>"


# Generated at 2022-06-25 19:30:36.224800
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test case example 0
    bytes_0 = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    var_0 = prepare_request_body(bytes_0, bytes_0)
    assert var_0 == bytes_0


# Generated at 2022-06-25 19:30:44.724991
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest
    request.body = b'\xea\xa3\xd7uN\x84\x14\xf65\x915\xeeTyu\xff\xa1\x03\xfe\xe0'
    request.headers = HeaderMap(request)

    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'