

# Generated at 2022-06-25 19:21:02.349596
# Unit test for function compress_request
def test_compress_request():
    class Mock(object):
        pass

    request = Mock()
    request.body = "1234567890"
    compress_request(request, "blah")
    assert request.body == b'x\x9c+\xceL\xcf\xcd\xcf\xcc\xcd\xe2\x02\x04'
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '18'

# Generated at 2022-06-25 19:21:03.471004
# Unit test for function compress_request
def test_compress_request():
    request = MultipartRequestDataDict()
    compress_request(request)

# Generated at 2022-06-25 19:21:06.368742
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_1 = module_0.ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_1.__iter__()


# Generated at 2022-06-25 19:21:09.455436
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(encoder_0)
    chunked_multipart_upload_stream_1 = ChunkedMultipartUploadStream(encoder_0)
    def test_lambda():
        iter(chunked_multipart_upload_stream_0)
    test_lambda()


# Generated at 2022-06-25 19:21:12.713353
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream((chunk.encode() for chunk in []), None)
    assert [] == list(chunked_upload_stream_0)


# Generated at 2022-06-25 19:21:14.951573
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    prepare_request_body(request_data_dict_0, lambda chunk: None)


# Generated at 2022-06-25 19:21:24.787508
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
	# Input:
	multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
	boundary_0 = None
	content_type_0 = None
	# Output:
	multipart_encoder_0 = MultipartEncoder(fields=multipart_request_data_dict_0.items(), boundary=boundary_0)
	content_type_1 = multipart_encoder_0.content_type

	assert  multipart_encoder_0 == multipart_request_data_dict_0
	assert  content_type_1 == multipart_encoder_0.content_type


# Generated at 2022-06-25 19:21:31.562018
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder(
        fields=[(
            'Content-Disposition',
            'form-data; name="Content-Disposition"'
        )],
        boundary='boundary'
    )
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(
        encoder=multipart_encoder_0
    )
    chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:21:39.821985
# Unit test for method __iter__ of class ChunkedMultipartUploadStream

# Generated at 2022-06-25 19:21:44.827223
# Unit test for function compress_request
def test_compress_request():
    class DummyRequest:
        def __init__(self):
            self.body = "Test String"
            self.headers = {"Content-Length" : str(len(self.body))}
    dummy_request = DummyRequest()
    compress_request(dummy_request, True)
    assert dummy_request.body == zlib.compress(dummy_request.body.encode())
    assert dummy_request.headers['Content-Encoding'] == 'deflate'
    assert dummy_request.headers['Content-Length'] == str(len(dummy_request.body))

# Generated at 2022-06-25 19:21:59.733275
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "compressed data"
    request.headers = {"Content-Encoding" : "deflate", "Content-Length" : "20"}
    compress_request(request, True)


# Generated at 2022-06-25 19:22:03.547693
# Unit test for function compress_request
def test_compress_request():
    requests.PreparedRequest()
    def test_0():
        compress_request(requests.PreparedRequest(), True)

    test_0()


# Generated at 2022-06-25 19:22:07.264041
# Unit test for function compress_request
def test_compress_request():
    import requests
    request = requests.PreparedRequest()
    request.body = b'abc'
    request.headers = {}
    always = True
    compress_request(request,always)
    print(request.body)
    print(request.headers)
    print('finish')


# Generated at 2022-06-25 19:22:13.226549
# Unit test for function compress_request

# Generated at 2022-06-25 19:22:21.895613
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    test_data_0 = {"form-field-0": "value", "form-field-1": "value"}
    test_data_1 = "value"
    test_data_2 = "value"
    test_data_3 = "value"
    test_data_4 = "value"
    test_data_5 = "value"
    test_data_6 = "value"
    test_data_7 = "value"
    test_data_8 = "value"
    test_data_9 = "value"
    test_data_10 = "value"
    test_data_11 = "value"
    test_data_12 = "value"
    test_data_13 = "value"
    test_data_14 = "value"
    test_data_15 = "value"
    test_data_16

# Generated at 2022-06-25 19:22:22.769954
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    test_case_0()

# Generated at 2022-06-25 19:22:34.778607
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    # Boundary is randomly generated by function
    data_0 = MultipartRequestDataDict({"abc": "123"})
    content_type_0 = "line"
    test_0 = get_multipart_data_and_content_type(data_0, content_type_0)
    assert test_0[0] == content_type_0
    # Boundary is randomly generated by function
    data_0 = MultipartRequestDataDict({"abc": "123"})
    boundary_2 = "--ascii"
    content_type_0 = "Content-Type"
    test_0 = get_multipart_data_and_content_type(data_0, boundary_2, content_type_0)
    assert test_0[0] == content_type_0
    # Boundary is randomly generated

# Generated at 2022-06-25 19:22:36.187290
# Unit test for function compress_request
def test_compress_request():
    assert (compress_request(request, always = False)) == None


# Generated at 2022-06-25 19:22:38.085401
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    ChunkedMultipartUploadStream.__iter__(ChunkedMultipartUploadStream(MultipartEncoder))


# Generated at 2022-06-25 19:22:45.618987
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    from requests_toolbelt.multipart.encoder import MultipartEncoder
    from requests_toolbelt.utils.content_streams import (
        iter_field_objects,
    )
    from requests_toolbelt.utils.content_streams import (
        iter_fields,
    )

    def mock_read__0():
        return "No files or bytes are expected to be read from the encoder"
    def mock_read__1():
        return "No files or bytes are expected to be read from the encoder"
    def mock_read__2():
        return "No files or bytes are expected to be read from the encoder"

    mock_read__0.__defaults__ = (None, None)
    mock_read__0.__kwdefaults__ = {}

# Generated at 2022-06-25 19:22:51.682555
# Unit test for function compress_request
def test_compress_request():
    assert(bool_0)


# Generated at 2022-06-25 19:22:54.287625
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    try:
        chunkedUploadStream = ChunkedUploadStream(list(),list())
        chunkedUploadStream.__iter__()
    except:
        pass


# Generated at 2022-06-25 19:22:55.799971
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    run_ChunkedMultipartUploadStream___iter__()


# Generated at 2022-06-25 19:23:03.934359
# Unit test for function compress_request
def test_compress_request():
    data = (b'abc'*300)
    if(len(data)%2 == 1):
        data += 'A'
    request_info = requests.Request('POST',
                                    'http://httpbin.org/post',
                                    data=data)
    prepared_request = request_info.prepare()


    request_info_1 = requests.Request('POST',
                                    'http://httpbin.org/post',
                                    data=data)
    prepared_request_1 = request_info_1.prepare()

    compress_request(prepared_request_1,True)
    # assert prepared_request._cookies.keys == cookies_2, \
    #     "Expected {}, Got {}".format(cookies_2, prepared_request._cookies.keys)
    # assert prepared_request._cookies

# Generated at 2022-06-25 19:23:14.102034
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    data = MultipartRequestDataDict.from_key_value('foo', 'bar')
    boundary = None
    content_type = None
    encoder, content_type = get_multipart_data_and_content_type(data, boundary, content_type)
    boundary = encoder.boundary
    chunked_multipart_upload_stream = ChunkedMultipartUploadStream(encoder)
    chunked_multipart_upload_stream.chunk_size = 100 * 1024
    trial = 0
    while trial < 2:
        trial = trial + 1
        while True:
            chunk = encoder.read(chunked_multipart_upload_stream.chunk_size)
            if not chunk:
                break
            assert chunked_multipart_upload_stream.__iter__() != chunk

# Generated at 2022-06-25 19:23:20.049415
# Unit test for function prepare_request_body
def test_prepare_request_body():
    test_body_read_callback = test_case_0
    test_chunked = True
    test_offline = False
    test_body = "Test body"

    result_body = prepare_request_body(test_body, test_body_read_callback, test_chunked, test_offline)

    if isinstance(result_body, ChunkedUploadStream):
        return True

    return False


# Generated at 2022-06-25 19:23:28.792850
# Unit test for function compress_request
def test_compress_request():
    import requests
    import zlib
    def test(request, always):
        deflater = zlib.compressobj()
        if isinstance(request.body, str):
            body_bytes = request.body.encode()
        elif hasattr(request.body, 'read'):
            body_bytes = request.body.read()
        else:
            body_bytes = request.body
        deflated_data = deflater.compress(body_bytes)
        deflated_data += deflater.flush()
        is_economical = len(deflated_data) < len(body_bytes)
        if is_economical or always:
            request.body = deflated_data
            request.headers['Content-Encoding'] = 'deflate'

# Generated at 2022-06-25 19:23:32.977886
# Unit test for function compress_request
def test_compress_request():
    try:
        # Prepare the inputs for unit test
        request = requests.PreparedRequest()
        always = True

        # Invoke the function under test
        compress_request(request, always)

        # Assertions
        assert True

    except Exception as e:
        print(f"compress_request() failed due to {e}")

# Generated at 2022-06-25 19:23:39.677085
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():

    # Setup
    stream_0 = ['d', 'Z', 'c', 'C']

    def callback_0(arg_0):
        pass

    obj_0 = ChunkedUploadStream(stream_0, callback_0)

    # Invocation
    iter_0 = obj_0.__iter__()

    # Verification
    assert isinstance(iter_0, Iterable)


# Generated at 2022-06-25 19:23:46.221794
# Unit test for function prepare_request_body
def test_prepare_request_body():

    body = b'{"Foo":"bar"}'

    body_read_callback = body.decode()

    """Original code:
        body = prepare_request_body(
            body=body,
            body_read_callback=body_read_callback,
            content_length_header_value=None,
            chunked=False,
            offline=False,
        )
    """

    # assertion for branch: test_case_0
    if body_read_callback:
        test_case_0()

    body = body.encode()
    return body

test_prepare_request_body()

# Generated at 2022-06-25 19:24:02.997072
# Unit test for function compress_request
def test_compress_request():
    # Arguments:
    #   request: requests.PreparedRequest = <unspecified>
    #   always: bool = <unspecified>
    # Returns:
    #   Nothing
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    multipart_encoder_1 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    requests_prepared_request_0 = requests.PreparedRequest()
    requests_prepared_request_0.body = multipart_encoder_1
    compress_request(requests_prepared_request_0, True)


# Generated at 2022-06-25 19:24:04.761763
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    compress_request(request, True)
    compress_request(request, False)


# Generated at 2022-06-25 19:24:14.949647
# Unit test for function compress_request
def test_compress_request():
    request =  requests.PreparedRequest()
    always = True
    compress_request(request, always)
    assert request.body == b"x\x9c+W\xccM\xcf/0\x10\x00\xad\x00\x01\x9c\xc8\xccM\x00\x06\x00\x04\x00\x02>\x00\x01\x00\xc8\x00\x00\x00\x01\x00\x00\x00\x01\xc9\x00\x00\x00\x00"

if __name__ == "__main__":
    test_compress_request()

# Generated at 2022-06-25 19:24:22.947180
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = urlencode({'foo':'bar','baz':'flim'},doseq=True)

    body_read_callback = lambda x: x

    content_length_header_value = None
    chunked = False
    offline = False

    result = prepare_request_body(
        body=body,
        body_read_callback=body_read_callback,
        content_length_header_value=content_length_header_value,
        chunked=chunked,
        offline=offline,
    )

    assert result == "foo=bar&baz=flim"


# Generated at 2022-06-25 19:24:35.006784
# Unit test for function compress_request
def test_compress_request():
    multipart_request_data_dict_1 = module_0.MultipartRequestDataDict()
    tuple_1 = get_multipart_data_and_content_type(multipart_request_data_dict_1)
    multipart_request_data_dict_1_0 = multipart_request_data_dict_1
    tuple_1_0 = tuple_1
    from httpie.cli.dicts import MultipartRequestDataDict
    multipart_request_data_dict_1_1 = MultipartRequestDataDict
    tuple_1_1 = tuple_1_0
    multipart_encoder_0 = tuple_1_0[0]
    assert multipart_encoder_0.content_type == multipart_encoder_0.content_type
    assert multipart_encoder_0

# Generated at 2022-06-25 19:24:38.157040
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ["1"]),
        callback=print,
    )
    for chunk in stream_0:
        pass


# Generated at 2022-06-25 19:24:41.510674
# Unit test for function prepare_request_body
def test_prepare_request_body():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)


# Generated at 2022-06-25 19:24:52.308883
# Unit test for function prepare_request_body
def test_prepare_request_body():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    request_data_dict_0 = module_0.RequestDataDict()
    bytes_0 = prepare_request_body(bytes_0)
    object_0 = MultipartRequestDataDict()
    object_0 = MultipartRequestDataDict()
    object_0 = MultipartRequestDataDict()
    object_0 = MultipartRequestDataDict()
    object_0 = MultipartRequestDataDict()
    object_0 = MultipartRequestDataDict()
    object_0 = MultipartRequestDataDict()
    object_0 = MultipartRequest

# Generated at 2022-06-25 19:24:57.047496
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream((), lambda: None)
    iter(chunked_upload_stream_0)


# Generated at 2022-06-25 19:25:02.234448
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    class_instance_0 = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in []),
        callback=lambda: None,
    )
    for class_instance_0 in class_instance_0:
        pass


# Generated at 2022-06-25 19:25:13.532020
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict(headers={})
    str_0 = prepare_request_body(request_data_dict_0,
                                 body_read_callback=lambda x: x,
                                 chunked=False,
                                 offline=False)


# Generated at 2022-06-25 19:25:15.059216
# Unit test for function compress_request
def test_compress_request():
    # TODO: Implement unit test for compress_request(request, always)
    pass

# Generated at 2022-06-25 19:25:19.157582
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    compress_request(request, False)


# Generated at 2022-06-25 19:25:20.655107
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    method_0 = ChunkedMultipartUploadStream.__iter__


# Generated at 2022-06-25 19:25:26.599274
# Unit test for function compress_request
def test_compress_request():

    from requests.structures import CaseInsensitiveDict
    from requests.compat import str as cstr

    request_0 = requests.PreparedRequest()
    request_0.body = ""
    request_0.headers = CaseInsensitiveDict({})
    compress_request(request_0, True)

    # assert request_0.body == ""
    assert request_0.headers == {
        'Content-Encoding': 'deflate',
        'Content-Length': '0'
    }

# Generated at 2022-06-25 19:25:27.889608
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # TODO: Add a test case for missing data
    # TODO: Add a test case for missing data
    # TODO: Add a test case for missing data
    pass


# Generated at 2022-06-25 19:25:34.984695
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    import requests_toolbelt
    multipart_encoder_0 = requests_toolbelt.MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    class ITC:
        def __init__(self, *args):
            self.iterable = args
        def __iter__(self):
            return iter(self.iterable)
    iter_0 = ITC("")
    assert iter(chunked_multipart_upload_stream_0) == iter_0


# Generated at 2022-06-25 19:25:38.068562
# Unit test for function compress_request
def test_compress_request():
    kwargs = {
            'always': bool,
            'request': requests.PreparedRequest,
            }
    compress_request(**kwargs)

import httpie.cli.dicts as module_0


# Generated at 2022-06-25 19:25:40.553741
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    ChunkedMultipartUploadStream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    #
    assert True

import httpie.cli.dicts as module_1


# Generated at 2022-06-25 19:25:42.501604
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = requests.PreparedRequest()
    compress_request(prepared_request_0, True)


# Generated at 2022-06-25 19:26:02.451091
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'foo'
    body_read_callback = lambda: None
    prepare_request_body(body, body_read_callback)
    body = 'foo'
    body_read_callback = lambda: None
    prepare_request_body(body, body_read_callback, chunked=True)
    body = StringIO()
    body_read_callback = lambda: None
    prepare_request_body(body, body_read_callback, chunked=True)
    body = 'foo'
    body_read_callback = lambda: None
    prepare_request_body(body, body_read_callback, offline=True)
    body = StringIO()
    body_read_callback = lambda: None
    prepare_request_body(body, body_read_callback, offline=True)
    body = StringIO()
    body_read

# Generated at 2022-06-25 19:26:03.107112
# Unit test for function compress_request
def test_compress_request():
    pass

# Generated at 2022-06-25 19:26:07.925869
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = (1, 2, 3)
    callback_0 = print
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, callback_0)
    for x_0 in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:26:10.948308
# Unit test for function prepare_request_body
def test_prepare_request_body():
    prepare_request_body()


# Generated at 2022-06-25 19:26:18.561456
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "a"

    compress_request(request, True)

    assert request.headers['Content-Encoding'] == 'deflate'

    request = requests.PreparedRequest()
    request.body = "aaaaaaaaaaaaaaaaaaaaaa"

    compress_request(request, True)

    assert request.headers['Content-Encoding'] == 'deflate'

    request = requests.PreparedRequest()
    request.body = "aaaaaaaaaaaaaaaaaaaaaa"

    compress_request(request, False)

    assert request.headers.get('Content-Encoding') == None



# Generated at 2022-06-25 19:26:25.784862
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_1 = module_0.RequestDataDict()
    body_1 = prepare_request_body(request_data_dict_1)

# Generated at 2022-06-25 19:26:30.214024
# Unit test for function compress_request
def test_compress_request():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    prepared_request = prepare_request_body(tuple_0[0])
    compress_request(prepared_request, True)

# Generated at 2022-06-25 19:26:36.048890
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "Hello There"
    request.headers = {'Content-Length': "11"}
    always = False
    compress_request(request, always)
    request.headers['Content-Encoding'] == 'deflate'
    request.headers['Content-Length'] == '18'

# Generated at 2022-06-25 19:26:39.366833
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    # Initialization
    ChunkedMultipartUploadStream_0 = ChunkedMultipartUploadStream()
    assert None is not ChunkedMultipartUploadStream_0


# Generated at 2022-06-25 19:26:41.673196
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(stream=())
    for chunk in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:27:02.775938
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, False)


# Generated at 2022-06-25 19:27:07.805150
# Unit test for function compress_request
def test_compress_request():
    request = requests.Request()
    request.prepare()
    compress_request(request, True)
    compress_request(request, False)
    request.body = 'Body'
    compress_request(request, True)
    compress_request(request, False)


# Generated at 2022-06-25 19:27:11.071441
# Unit test for function compress_request
def test_compress_request():
    request_0: requests.PreparedRequest
    module_0.compress_request(request=request_0)


# Generated at 2022-06-25 19:27:12.464711
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    pass


# Generated at 2022-06-25 19:27:16.430659
# Unit test for function compress_request
def test_compress_request():

    # Arrange
    request = requests.PreparedRequest()
    request.body = b"Hello, my name is Lukas"

    # Act
    compress_request(request, True)

    # Assert
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '31'




# Generated at 2022-06-25 19:27:23.115307
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder(fields={})
    multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    multipart_encoder_0.read = lambda : ""
    list_0 = []
    for _ in multipart_upload_stream_0:
        list_0.append(True)
    assert len(list_0) > 0


# Generated at 2022-06-25 19:27:28.659834
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.headers = {}
    request.body = 'something'
    compress_request(request, True)
    assert request.body == b'x\x9c+H,I-.Q\x04\x00\x00\x00\x00\x11\x00\x08something\x04\x00\x00\x00\x00'


# Generated at 2022-06-25 19:27:30.211659
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)


# Generated at 2022-06-25 19:27:40.230291
# Unit test for function compress_request
def test_compress_request():
    from httpie.cli.dicts import MultipartRequestDataDict, RequestDataDict
    from httpie import cli

    class Object:
        def __len__(self):
            return 0

    body = 'test'
    data = {'test': 'test'}
    multipart_request_data_dict = MultipartRequestDataDict()
    request_data_dict = RequestDataDict()
    method = 'GET'

    assert cli.compress_request(None, True, data) is True
    assert cli.compress_request(None, True, body) is True
    assert cli.compress_request(None, True, multipart_request_data_dict) is True
    assert cli.compress_request(None, True, request_data_dict) is True

    # Test Error body

# Generated at 2022-06-25 19:27:44.549458
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream([], lambda x : x)
    list_0 = []
    for obj_0 in chunked_upload_stream_0:
        list_0.append(obj_0)


# Generated at 2022-06-25 19:28:10.708459
# Unit test for function compress_request
def test_compress_request():
    import io
    import requests
    import io
    import requests
    request_0 = requests.PreparedRequest()
    request_0.body = io.BytesIO(b'PGh0bWw+DQogIDxib2R5Pg0KICAgIDxwPmhlbGxvPC9wPg0KICA8L2JvZHk+DQo8L2h0bWw+DQo=')

    compress_request(request_0, True)


# Generated at 2022-06-25 19:28:15.049589
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder(fields='')
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:28:24.000268
# Unit test for function compress_request
def test_compress_request():
    # Request with no body
    request = requests.PreparedRequest()
    compress_request(request, True)
    # Request with byte body
    request = requests.PreparedRequest()
    request.body = b'test'
    compress_request(request, True)
    # Request with string body
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, True)
    # Request with file body
    request = requests.PreparedRequest()
    request.body = io.BytesIO(b'test')
    compress_request(request, True)
    # Request with non compressed body
    request = requests.PreparedRequest()
    request.body = 'test'
    compress_request(request, False)

# Generated at 2022-06-25 19:28:25.163833
# Unit test for function compress_request
def test_compress_request():
    assert("The function 'compress_request' is not working properly")


# Generated at 2022-06-25 19:28:27.834807
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    always_0 = False
    compress_request(request_0, always_0)
    request_1 = requests.PreparedRequest()
    always_0 = True
    compress_request(request_1, always_0)


# Generated at 2022-06-25 19:28:29.947616
# Unit test for function compress_request
def test_compress_request():
    request_1 = module_0.RequestDataDict()
    request_1.body = b'body'
    compress_request(request_1, True)

# Generated at 2022-06-25 19:28:30.942574
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    assert True



# Generated at 2022-06-25 19:28:33.379791
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)
    requests_prepared_request_0 = requests.PreparedRequest()


# Generated at 2022-06-25 19:28:35.564632
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = requests.PreparedRequest()
    bool_0 = False
    compress_request(prepared_request_0, bool_0)


# Generated at 2022-06-25 19:28:39.467687
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    # Setup
    encoder = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(encoder)

    # Test
    for i in chunked_multipart_upload_stream_0:
        pass


# Generated at 2022-06-25 19:29:14.372334
# Unit test for function prepare_request_body
def test_prepare_request_body():
    stream = None
    body = RequestDataDict()
    body_read_callback = None
    chunked = True
    offline = False
    result = prepare_request_body(body, body_read_callback, 100, chunked, offline)
    assert result is not None


# Generated at 2022-06-25 19:29:18.551500
# Unit test for function compress_request
def test_compress_request():
    multipart_encoder_0 = get_multipart_data_and_content_type(None)[0]
    request_0 = requests.PreparedRequest()
    request_0.body = multipart_encoder_0
    request_0.headers['Content-Encoding'] = 'deflate'
    request_0.headers['Content-Length'] = '5'
    request_0.headers['Content-Type'] = 'multipart/form-data'
    compress_request(request_0, False)



# Generated at 2022-06-25 19:29:22.372290
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = ()
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0)
    assert isinstance(iter(chunked_upload_stream_0), types.GeneratorType)


# Generated at 2022-06-25 19:29:31.410897
# Unit test for function compress_request
def test_compress_request():
    import io
    import httpie.cli.dicts as module_0
    import json
    def get_prepared_request_0():
        multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
        request_data_dict_0 = module_0.RequestDataDict()
        request_data_dict_0.append('a', 1)
        request_data_dict_0.append('b', 2)
        request_data_dict_0.append('c', 3)
        data = request_data_dict_0
        request_kwargs_0 = {'data': data}
        request_0 = requests.Request('POST', 'http://127.0.0.1:5000/post', **request_kwargs_0)
        prepared_request_0 = request_0.prep

# Generated at 2022-06-25 19:29:40.813773
# Unit test for function compress_request
def test_compress_request():
    from requests import PreparedRequest
    from io import BytesIO
    request = PreparedRequest()
    request.body = "a string"
    compress_request(request, True)
    assert request.body == b'x\x9c+I-.Q\x04\x00\x00\x00\x00\x00\x01\x04\x00\x99\xd1H,\xcd\xc9\xc9W(\xcf/\xcaI\x01\x00%\x04\x00\x00\x00'

    request.body = BytesIO(b"a string")
    compress_request(request, True)

# Generated at 2022-06-25 19:29:49.076911
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = "some string of text"
    callback = print
    assert type(prepare_request_body(body, callback)) == ChunkedUploadStream


# Generated at 2022-06-25 19:29:54.396164
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # Define arguments
    stream = [b'foo', b'bar']
    callback = lambda chunk: True

    # Obtain the object to test
    obj = ChunkedUploadStream(stream, callback)
    assert obj.callback == callback

    # Call method(s) to test
    iter_return_0 = next(iter(obj))

    # Perform assertions
    assert iter_return_0 == b'foo'


# Generated at 2022-06-25 19:30:03.939887
# Unit test for function compress_request
def test_compress_request():
    multipart_request_data_dict_0 = MultipartRequestDataDict()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_request_data_dict_0)
    offline_0 = True
    request_data_dict_0 = RequestDataDict()
    chunked_upload_stream_0 = ChunkedUploadStream(request_data_dict_0, chunked_multipart_upload_stream_0)
    request_body_0 = prepare_request_body(chunked_upload_stream_0, chunked_multipart_upload_stream_0, offline=offline_0)
    prepared_request_0 = requests.PreparedRequest()
    prepared_request_1 = requests.PreparedRequest()
    prepared_request_2 = requests.Pre

# Generated at 2022-06-25 19:30:05.796156
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = False
    assert(compress_request(request, always)) == None


# Generated at 2022-06-25 19:30:07.503671
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'Testing 1 2 3'
    body_read_callback = lambda chunk: chunk
    assert(prepare_request_body(body, body_read_callback) == body)


# Generated at 2022-06-25 19:30:27.116991
# Unit test for function compress_request
def test_compress_request():
    pass

# Generated at 2022-06-25 19:30:28.983409
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    assert None is compress_request(request, False)


# Generated at 2022-06-25 19:30:31.649417
# Unit test for function compress_request
def test_compress_request():

    request_0 = requests.PreparedRequest()
    compress_request(request_0, False)


# Generated at 2022-06-25 19:30:32.575605
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert 0 == 0


# Generated at 2022-06-25 19:30:36.262264
# Unit test for function compress_request
def test_compress_request():
    req = requests.PreparedRequest()
    compress_request(req, False)
    req.body = "Hello World!"
    compress_request(req, False)
    req.body = "Hello World!"
    req.headers["Content-Length"] = "12"
    compress_request(req, True)


# Generated at 2022-06-25 19:30:47.181790
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    bool_0 = bool()
    compress_request(request_0, bool_0)
    multipart_request_data_dict_1 = module_0.MultipartRequestDataDict()
    tuple_1 = get_multipart_data_and_content_type(
        multipart_request_data_dict_1,
        boundary=str(),
        content_type=str(),
    )
    request_data_dict_0 = module_0.RequestDataDict()
    str_0 = str()
    str_1 = str()