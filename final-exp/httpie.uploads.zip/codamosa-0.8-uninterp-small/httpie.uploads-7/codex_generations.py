

# Generated at 2022-06-25 19:20:57.444520
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    pass


# Generated at 2022-06-25 19:21:01.042719
# Unit test for function prepare_request_body
def test_prepare_request_body():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)


# Generated at 2022-06-25 19:21:03.807061
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = ChunkedUploadStream(
        MultipartEncoder(),
        MultipartEncoder()
    )
    assert None is not chunked_multipart_upload_stream_0


# Generated at 2022-06-25 19:21:09.699568
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # "https://github.com/jkbrzt/httpie/issues/535"
    # "Special case STDIN upload with --form --chunked"
    body = b'\x00\x00\x00\x00'
    body_read_callback = lambda chunk: True
    content_length_header_value = 0
    chunked = false
    offline = true
    assert prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline) == body
    # "https://github.com/jkbrzt/httpie/issues/535"
    # "Special case STDIN upload with --form --chunked"
    body = b'\x00\x00\x00\x00'
    body_read_callback = lambda chunk: True
    content_

# Generated at 2022-06-25 19:21:11.199570
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    pass


# Generated at 2022-06-25 19:21:19.470040
# Unit test for function prepare_request_body
def test_prepare_request_body():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)


# Generated at 2022-06-25 19:21:28.497498
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    # Test the function with a MultipartRequestDataDict and no additional args
    assert isinstance(get_multipart_data_and_content_type(test_case_0()[0]), tuple)
    # Tests the function with a MultipartRequestDataDict, boundary and content_type
    # Ensure that the return from get_multipart_data_and_content_type is a tuple
    # Ensure that the return from get_multipart_data_and_content_type[0] is a MultipartEncoder
    # Ensure that the return from get_multipart_data_and_content_type[1] is a string


# Generated at 2022-06-25 19:21:30.855703
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    compress_request(request, always=True)


# Generated at 2022-06-25 19:21:38.832322
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    method_name = "__iter__"
    stream_0 = list()
    callback_0 = tuple()
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, callback_0)
    assert hasattr(chunked_upload_stream_0, method_name)
    method = getattr(chunked_upload_stream_0, method_name)
    assert callable(method)
    result = method()
    assert result is not None
    assert hasattr(result, "__iter__")


# Generated at 2022-06-25 19:21:39.738977
# Unit test for function compress_request
def test_compress_request():
    pass



# Generated at 2022-06-25 19:22:02.123267
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    iterable_0 = iter(chunked_multipart_upload_stream_0)
    #assert iterable_0.__len__() == 0


# Generated at 2022-06-25 19:22:11.339523
# Unit test for function compress_request
def test_compress_request():
    # Initialize a request and add some body data to it
    request = requests.PreparedRequest()
    request.body = """                                                         
    def test_case_0():
        multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
        tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    """
    # Set always to true
    always_true = True
    # Compress request
    compress_request(request, always_true)
    # Check if the body is compressed
    assert request.body.__class__.__name__ == 'bytes'

# Generated at 2022-06-25 19:22:13.176972
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    assert compress_request(request, True) == None


# Generated at 2022-06-25 19:22:20.329193
# Unit test for function compress_request
def test_compress_request():
    class MockRequest(object):
        def __init__(self, body, headers):
            self.body = body
            self.headers = headers
    request = MockRequest(b'testdata', {'Content-Length': '8'})
    _ = compress_request(request, False)
    assert request.body == b'x\x9c\xcbH\xcd\xc9\xc9\x07\x00\x06,\x02\x15'
    assert request.headers['Content-Length'] == '11'
    assert request.headers['Content-Encoding'] == 'deflate'

# Generated at 2022-06-25 19:22:23.273155
# Unit test for function compress_request
def test_compress_request():
    always = True
    prepared_request_0 = requests.PreparedRequest()
    prepared_request_0.body = 'hello world!'
    compress_request(prepared_request_0, always)
# test_compress_request()

# Generated at 2022-06-25 19:22:28.956454
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():

    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)

    assert None


import httpie.cli.dicts as module_1


# Generated at 2022-06-25 19:22:34.147087
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Input:
    #   body: Union[str, bytes, IO, MultipartEncoder, RequestDataDict],
    #   body_read_callback: Callable[[bytes], bytes],
    #   content_length_header_value: int = None,
    #   chunked=False,
    #   offline=False,
    pass


# Generated at 2022-06-25 19:22:37.249311
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = 'Hello'
    compress_request(request, False)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 19:22:38.985645
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 19:22:39.471784
# Unit test for function compress_request
def test_compress_request():
    pass


# Generated at 2022-06-25 19:22:53.205220
# Unit test for function compress_request
def test_compress_request():
    import requests
    request = requests.Request(method = 'post', url = 'https://httpbin.org/post', data = 'test')
    prep_request = request.prepare()
    test_result = compress_request(prep_request, True)
    assert prep_request.headers['Content-Encoding'] == 'deflate'

test_case_0()
test_compress_request()

# Generated at 2022-06-25 19:22:54.578094
# Unit test for function compress_request
def test_compress_request():
    assert callable(module_0.compress_request)


# Generated at 2022-06-25 19:23:03.339705
# Unit test for function compress_request
def test_compress_request():
    # Prepare
    import requests
    import httpie.compression
    import io
    import zlib
    import pytest
    
    
    
    
    
    
    request_0 = requests.PreparedRequest()
    request_0.headers = {}
    request_0.body = io.BytesIO(b"")
    
    
    
    
    
    
    compress_request(request_0, False)
    assert not request_0.body
    
    
    
    
    
    
    request_1 = requests.PreparedRequest()
    request_1.headers = {}
    request_1.body = b"body"
    
    
    
    
    
    
    compress_request(request_1, False)
    assert request_1.body == zlib.compress(b"body")

# Generated at 2022-06-25 19:23:06.957501
# Unit test for function compress_request
def test_compress_request():
    from requests import PreparedRequest

    # Unit test for function compress_request
    import httpie.cli.dicts as module_0
    request_0 = PreparedRequest()
    request_0.body = ''
    compress_request(request_0, True)

# Generated at 2022-06-25 19:23:07.573420
# Unit test for function compress_request
def test_compress_request():
    pass

# Generated at 2022-06-25 19:23:09.502557
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    assert compress_request(request, True)
    assert compress_request(request, False)


# Generated at 2022-06-25 19:23:19.997711
# Unit test for function compress_request
def test_compress_request():
    from httpie.cli.interpret import Request

    request = Request(
        args=['POST', 'httpbin.org/post'],
        env={},
        stdin=io.BytesIO(b'test'),
    )
    compress_request(request.prepare(), always=False)
    assert request.prepare().headers['Content-Encoding'] == 'deflate'


if __name__ == "__main__":
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    from httpie.cli.interpret import Request


# Generated at 2022-06-25 19:23:21.586260
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always=False
    compress_request(request, always)


# Generated at 2022-06-25 19:23:26.678800
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # Setup
    chunked_upload_stream_0 = ChunkedUploadStream([], lambda: None)

    # Testing
    iterable_0 = iter(chunked_upload_stream_0)
    chunk_0 = next(iterable_0)
    assert chunk_0 == b''
    chunk_1 = next(iterable_0)
    assert chunk_1 == b''

# Generated at 2022-06-25 19:23:30.468202
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request = requests.Request(
        method='POST',
        url='https://httpbin.org/post',
        headers={
            'Content-Type': 'application/json',
            'Content-Encoding': 'deflate',
        },
        data=b'{"hi": "world"}',
    )
    prepared_request = request.prepare()



# Generated at 2022-06-25 19:23:38.954101
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)


# Generated at 2022-06-25 19:23:41.004674
# Unit test for function compress_request
def test_compress_request():
    request: requests.PreparedRequest
    always = True
    compress_request(request, always)
    always = False
    compress_request(request, always)


# Generated at 2022-06-25 19:23:41.528784
# Unit test for function prepare_request_body
def test_prepare_request_body():
    pass

# Generated at 2022-06-25 19:23:51.050877
# Unit test for function compress_request
def test_compress_request():
    import types
    import unittest

    import httpie.cli.dicts as module_0
    import requests as module_1

    class MockPreparedRequest(module_1.PreparedRequest):

        def __init__(self, headers, body):
            self.body = body
            self.headers = headers
    class MockStr:

        def __init__(self, str):
            self.str = str
        def encode(self):
            return self.str
        @property
        def read(self):
            return self.str
    class MockDict:

        def __init__(self, dictionary):
            self.dictionary = dictionary
        def read(self):
            return self.dictionary
        def __len__(self):
            return len(self.dictionary)
    class MockWithoutRead:
        pass
   

# Generated at 2022-06-25 19:23:54.981980
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = 'string'
    callback = 'string'
    chunked_upload_stream_0 = ChunkedUploadStream(stream, callback)
    for _ in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:23:57.673160
# Unit test for function compress_request
def test_compress_request():
    requests_0 = requests()
    requests_1 = requests.PreparedRequest()
    function_0 = compress_request(requests_1, False, )



# Generated at 2022-06-25 19:23:58.231147
# Unit test for function compress_request
def test_compress_request():

    # Pass
    pass

# Generated at 2022-06-25 19:24:03.680398
# Unit test for function compress_request
def test_compress_request():
    requests_prepared_request_0 = requests.PreparedRequest()
    requests_prepared_request_0.body = ""
    requests_prepared_request_0.headers = {}
    compress_request(requests_prepared_request_0, True)
    compress_request(requests_prepared_request_0, False)


# Generated at 2022-06-25 19:24:04.210698
# Unit test for function compress_request
def test_compress_request():
    assert True


# Generated at 2022-06-25 19:24:06.223035
# Unit test for function compress_request
def test_compress_request():
    assert compress_request


# Generated at 2022-06-25 19:24:17.942716
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = ''
    body_read_callback = lambda x: x
    content_length_header_value = None
    chunked = False
    offline = False
    actual = prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    expected = ''
    assert actual == expected


# Generated at 2022-06-25 19:24:25.554431
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # Instantiate the type under test
    # Tests return type Switching between bytes and str is not yet
    # implemented for generator expressions in Python 2. See PEP 486 for
    # rationale.
    chunked_upload_stream_0 = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['']),
        callback=print,
    )
    # Iterate the type under test
    for chunk in chunked_upload_stream_0:
        pass
    # Tests return type Switching between bytes and str is not yet
    # implemented for generator expressions in Python 2. See PEP 486 for
    # rationale.
    chunked_upload_stream_1 = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['', '']),
        callback=print,
    )
    # Iterate the

# Generated at 2022-06-25 19:24:36.757586
# Unit test for function prepare_request_body
def test_prepare_request_body():

    # Invoke function with invalid types for test coverage
    try:
        prepare_request_body([], None)
    except Exception:
        pass
    try:
        prepare_request_body({}, None)
    except Exception:
        pass
    try:
        prepare_request_body(1, None)
    except Exception:
        pass
    try:
        prepare_request_body(1.0, None)
    except Exception:
        pass
    try:
        prepare_request_body((), None)
    except Exception:
        pass
    try:
        prepare_request_body(True, None)
    except Exception:
        pass
    try:
        prepare_request_body(None, None)
    except Exception:
        pass

# Generated at 2022-06-25 19:24:44.335456
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # Set mock object attributes during construction (autospec=True)
    chunked_upload_stream_0 = ChunkedUploadStream(list(), lambda x0: None)
    # Assert 0th element of result.
    # Assert 1st element of result.
    # Assert 2nd element of result.
    # Assert 3rd element of result.
    # Assert 4th element of result.
    # Assert 5th element of result.
    # Assert 6th element of result.
    # Assert 7th element of result.
    # Assert 8th element of result.
    # Assert 9th element of result.


# Generated at 2022-06-25 19:24:46.248552
# Unit test for function compress_request
def test_compress_request():
    # Calling function with arguments (PreparedRequest, bool)
    compress_request()


# Generated at 2022-06-25 19:24:52.480617
# Unit test for function compress_request
def test_compress_request():
    def mock_request(request):
        return request
    
    always = False
    request = mock_request()
    compress_request(request, always)
    compress_request(request[0], request[1])
    compress_request(request=request, always=always)
    compress_request(always, request=request)
    compress_request(always=always, request=request)
    compress_request(request=request, always=always)
    compress_request(always=always, request=request)
    compress_request(request, always=always)
    compress_request(always, request)


# Generated at 2022-06-25 19:24:55.479399
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    pass


# Generated at 2022-06-25 19:24:57.542768
# Unit test for function compress_request
def test_compress_request():
    main_argv = None
    request = main_argv
    always = main_argv
    compress_request(request, always)


# Generated at 2022-06-25 19:24:59.577566
# Unit test for function prepare_request_body
def test_prepare_request_body():
    pass


# Generated at 2022-06-25 19:25:08.853033
# Unit test for function compress_request
def test_compress_request():
    import io
    import requests
    import zlib

    # Case 0
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)

    request_0 = requests.PreparedRequest()
    request_0.body = tuple_0[0]
    request_0.headers = {}
    request_0.headers['Content-Length'] = str(
        len(
            tuple_0[0].to_string()
        )
    )
    deflater_0 = zlib.compressobj()

    compress_request(request_0, False)

    # Case 1

# Generated at 2022-06-25 19:25:24.060822
# Unit test for function compress_request

# Generated at 2022-06-25 19:25:33.214484
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    def set_headers_0(self, headers_0):
        for key in headers_0.keys():
            self.headers[key] = headers_0[key]
    if hasattr(request_0, 'headers'):
        set_headers_0(request_0, {})
    else:
        request_0.headers = {}
    def set_body_0(self, body_0):
        self.body = body_0
    if hasattr(request_0, 'body'):
        set_body_0(request_0, 'foo')
    else:
        request_0.body = 'foo'
    compress_request(request_0, False)


# Generated at 2022-06-25 19:25:42.694044
# Unit test for function prepare_request_body
def test_prepare_request_body():
    var_0 = prepare_request_body(
        body={"abcd": "efgh"},
        body_read_callback="",
    )
    assert var_0 == "abcd=efgh"
    var_1 = prepare_request_body(
        body={"abcd": "efgh"},
        body_read_callback="",
        content_length_header_value=1,
    )
    assert var_1 == "abcd=efgh"
    var_2 = prepare_request_body(
        body={"abcd": "efgh"},
        body_read_callback="",
        chunked=True,
    )
    assert var_2 == "abcd=efgh"

# Generated at 2022-06-25 19:25:46.987126
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(stream=(chunk.encode() for chunk in [body]), callback=body_read_callback)
    for element in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:25:55.587860
# Unit test for function compress_request
def test_compress_request():
    # Create a mock of the request.
    request = MockRequest()

    # Give the request some data to compress.
    request.body = b'blahblahblah'

    # Call the function under test.
    compress_request(request, True)

    # Ensure the request body is compressed.
    assert request.body is not b'blahblahblah'

    # Ensure Content-Type was added (not present before compression).
    assert 'Content-Type' in request.headers

    # Ensure Content-Encoding was added.
    assert 'Content-Encoding' in request.headers

    # Ensure Content-Length was added.
    assert 'Content-Length' in request.headers


# MockRequest
# A simple mock class for a requests.PreparedRequest
# The minimum necessary fields are implemented to match the real class.
# This was used to

# Generated at 2022-06-25 19:26:02.357937
# Unit test for function compress_request
def test_compress_request():
    import requests
    class A:
        def read(self):
            return "abc"

    prepared_request_0 = requests.PreparedRequest()
    prepared_request_0.body = A()
    compress_request(prepared_request_0, True)
    assert prepared_request_0.body == 'x\x9cK\xca\x00\x00\x00\x06\x00\x01'


# Generated at 2022-06-25 19:26:12.534729
# Unit test for function prepare_request_body
def test_prepare_request_body():
    def get_request_body(body):
        return prepare_request_body(body, lambda *args: None)

    info = (
        'If a string is passed as a body, it should be returned unchanged.'
    )
    assert get_request_body('hello') == 'hello', info

    info = (
        'A bytes object passed as a body should be returned unchanged.'
    )
    assert get_request_body(b'hello') == b'hello', info

    info = (
        'If a file-like object is passed as a body, it should be returned'
        ' unchanged.'
    )
    class FileLike(object): pass
    obj = FileLike()
    assert get_request_body(obj) == obj, info


# Generated at 2022-06-25 19:26:21.598182
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict_0 = 1
    content_type_0 = 'text/plain'
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0,content_type=content_type_0)
# TESTS

if __name__ == '__main__':
    import traceback
    import sys
    import unittest


    class Tests(unittest.TestCase):
        def test_case_0(self):
            try:
                test_case_0()
            except:
                traceback.print_exc()
                self.fail('Exception raised')


# Generated at 2022-06-25 19:26:22.505889
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)




# Generated at 2022-06-25 19:26:23.483028
# Unit test for function prepare_request_body
def test_prepare_request_body():
    def foobar(body):
        pass
    prepare_request_body(foobar, foobar)

# Generated at 2022-06-25 19:26:54.960021
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = requests.PreparedRequest()
    compress_request(prepared_request_0)


# Generated at 2022-06-25 19:26:57.224648
# Unit test for function compress_request
def test_compress_request():
    always = True
    request = requests.PreparedRequest()
    compress_request(request, always)


# Generated at 2022-06-25 19:27:02.599450
# Unit test for function compress_request
def test_compress_request():
    # Request with a body.
    request_0 = requests.PreparedRequest()
    request_0.body = "ab"
    compress_request(request_0, False)
    assert request_0.body == b'\x78\x9c\xcbHM(I\x02\x00\x11\xf9;\x04\x00\x00\x00'
    assert request_0.headers['Content-Encoding'] == 'deflate'
    assert request_0.headers['Content-Length'] == '15'


# Generated at 2022-06-25 19:27:03.466100
# Unit test for function compress_request
def test_compress_request():
    pass



# Generated at 2022-06-25 19:27:10.365323
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunks_0 = [b'2', b'3', b'4']
    callback_0 = lambda chunk: None
    chunked_upload_stream_0 = ChunkedUploadStream(chunks_0, callback_0)
    
    assert chunked_upload_stream_0.callback
    assert chunked_upload_stream_0.stream == chunks_0
    for i in chunked_upload_stream_0:
    	assert (i in chunks_0)

# Generated at 2022-06-25 19:27:13.313077
# Unit test for function prepare_request_body
def test_prepare_request_body():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    str_0 = prepare_request_body(multipart_request_data_dict_0)


# Generated at 2022-06-25 19:27:14.652172
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # Test without exception
    # Test without exception
    # Test without exception
    pass

# Generated at 2022-06-25 19:27:18.149889
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = False
    compress_request(request, always)


# Generated at 2022-06-25 19:27:20.588219
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = True
    compress_request(request, always)


# Generated at 2022-06-25 19:27:24.372793
# Unit test for function compress_request
def test_compress_request():

    requests_0 = requests.PreparedRequest()
    requests_0.body = 10
    requests_0.headers = {'Content-Length': 1, 'Content-Encoding': 'gzip'}
    bool_0 = True
    #Assertion
    assert compress_request(requests_0, bool_0) == None


# Generated at 2022-06-25 19:27:56.996691
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = True
    compress_request(request, always)
    always = False
    compress_request(request, always)

    compress_request(request, always)
    assert request.body == b'data'

    compress_request(request, always)
    assert request.body == b'data'

    compress_request(request, always)
    assert request.body == b'data'


# Generated at 2022-06-25 19:28:02.005708
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = str()
    def callback_0(arg_0):
        return None
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, callback_0)
    # assert_raises(TypeError,
    #               lambda: ChunkedUploadStream.__iter__(chunked_upload_stream_0)
    #               )



# Generated at 2022-06-25 19:28:07.134926
# Unit test for function compress_request
def test_compress_request():
    import requests

    # TODO: Add more tests!
    request = requests.PreparedRequest()
    request.headers = {'Content-Length': '1000'}
    request.body = b'a' * 1000
    compress_request(request, always=True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == "106"
    assert len(request.body) < 1000



# Generated at 2022-06-25 19:28:10.974080
# Unit test for function compress_request
def test_compress_request():
    # Setup
    request = requests.PreparedRequest()
    always = True
    # Pre-condition
    assert always is True
    # Run method to be tested
    compress_request(request, always)


# Generated at 2022-06-25 19:28:13.458849
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(iter(()), lambda : print())
    for chunk in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:28:14.745087
# Unit test for function compress_request
def test_compress_request():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 19:28:16.684899
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = True
    compress_request(request, always)


# Generated at 2022-06-25 19:28:17.997987
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert add(3,2) == 5


# Generated at 2022-06-25 19:28:18.976900
# Unit test for function compress_request
def test_compress_request():
    assert(test_case_0())

# Generated at 2022-06-25 19:28:22.435611
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    body_read_callback_0 = lambda bytes: bytes
    prepare_request_body(request_data_dict_0, body_read_callback_0)

# Generated at 2022-06-25 19:28:51.098988
# Unit test for function compress_request
def test_compress_request():
    httpie.cli.dicts.compress_request(None, None)


# Generated at 2022-06-25 19:28:59.584300
# Unit test for function compress_request
def test_compress_request():
    from urllib3.response import HTTPResponse
    request = HTTPResponse('\x1f\x8b\x08\x08\x98\x98\x98\x98\x00\x03silly.txt\x00\x03\xed\xbd\xa7\xf3\x0a\xa1\x14\x00\x00\x00')

# Generated at 2022-06-25 19:29:02.298527
# Unit test for function compress_request
def test_compress_request():
    request = ""
    always = ""
    assert(compress_request(request, always) == None)



# Generated at 2022-06-25 19:29:08.701487
# Unit test for function compress_request
def test_compress_request():
    from requests.structures import CaseInsensitiveDict
    from requests.models import RequestEncodingMixin
    request = RequestEncodingMixin()
    request.body = 'request_body'
    request.headers = CaseInsensitiveDict({'accept-encoding': 'deflate, gzip'})
    compress_request(request, False)
    assert request.body == b'x\x9cK\xca\xcf\xc8\x01\x00\xaa\x03\x98\x00F\x00\x05'
    assert request.headers['content-encoding'] == 'deflate'
    assert request.headers['content-length'] == '13'

# Generated at 2022-06-25 19:29:16.668517
# Unit test for function compress_request
def test_compress_request():
    class StubPreparedRequest(requests.PreparedRequest):
        def __init__(self, body, headers = {}):
            self.body = body
            self.headers = headers
    test_input = requests.PreparedRequest()
    compress_request(test_input, True)
    compress_request(test_input, False)
    compress_request(StubPreparedRequest(""), True)
    compress_request(StubPreparedRequest(""), False)
    compress_request(StubPreparedRequest("a"*100), True)
    compress_request(StubPreparedRequest("a"*100), False)

# Generated at 2022-06-25 19:29:23.085752
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    object_0 = ChunkedUploadStream(iter(list()), iter)
    __iter___return_value_0 = object_0.__iter__()
    assert not isinstance(__iter___return_value_0, type(Object))
    assert not isinstance(__iter___return_value_0, type(FunctionType))


# Generated at 2022-06-25 19:29:25.491539
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    compress_request(request, False)

import httpie.cli.dicts as module_0


# Generated at 2022-06-25 19:29:28.987173
# Unit test for function compress_request
def test_compress_request():
    requests.PreparedRequest()
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)

# Generated at 2022-06-25 19:29:33.960297
# Unit test for function compress_request
def test_compress_request():
    # TODO: Remove.
    # With Python 3.7 we could use
    #
    #     from unittest.mock import Mock
    #
    # Also consider using a fake class instead of a mock.
    from unittest.mock import Mock

    request = Mock()
    compress_request(request, True)
    assert request.body is not None
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] is not None


# Generated at 2022-06-25 19:29:37.377999
# Unit test for function compress_request
def test_compress_request():
    import httpie.cli.dicts as module_0
    request_0 = module_0.MultipartRequestDataDict()
    compress_request(request_0, True)


# Generated at 2022-06-25 19:30:10.896658
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    assert prepare_request_body(request_data_dict_0, None, None, False, False)
    assert prepare_request_body('', None, None, False, False)


# Generated at 2022-06-25 19:30:11.588204
# Unit test for function compress_request
def test_compress_request():
    assert True


# Generated at 2022-06-25 19:30:16.549407
# Unit test for function compress_request
def test_compress_request():
    is_economical = 0
    always = 0
    request = requests.PreparedRequest
    request.body = b'This is a really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really long string'
    compress_request(request, always)
    assert request.body == b'\x78\x9c\xcbH\xcd\xc9\xc9\x07\x00\x06,\x02\xf5\x89\x04\x00' and request.headers['Content-Encoding'] == 'deflate' and request.headers['Content-Length'] == '21'
# END

# Generated at 2022-06-25 19:30:22.361427
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    '''
    Unit test for method __iter__ of class ChunkedUploadStream
    '''
    chunks = module_0.MultipartRequestDataDict()
    callback = module_0.MultipartRequestDataDict()
    chunked_upload_stream_0 = ChunkedUploadStream(chunks, callback)
    for chunk in chunked_upload_stream_0:
        pass

import requests_toolbelt as module_1


# Generated at 2022-06-25 19:30:24.570982
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest
    always_0 = False
    compress_request(request_0, always_0)

# Generated at 2022-06-25 19:30:26.308075
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)


# Generated at 2022-06-25 19:30:36.509254
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder(fields={}, boundary='2iM6UY8YF1jG10fz6UdR6BV8s1sO')
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(encoder=multipart_encoder_0)
    chunked_multipart_upload_stream_0.chunk_size = 5
    iterator_0 = iter(chunked_multipart_upload_stream_0)
    stream_0 = multipart_encoder_0.read(size=9)
    assert stream_0 == b'--2iM6UY8YF1jG10fz6UdR6BV8s1sO--'

# Generated at 2022-06-25 19:30:47.181564
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # Precondition
    # Method arguments
    stream_0 = [b'\x8a\x94\x91\x9c&\xb9\x97+\x81\xc0\xce\x19', b'\x96\xfb\x9f\x9e\xbc\xc5\x19N\xb7\x16\xe2\xee\xf3']
    callback_0 = test_case_0
    # Create instance
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, callback_0)

    # Type check
    assert isinstance(chunked_upload_stream_0.stream, Iterable)
    assert isinstance(chunked_upload_stream_0.callback, Callable)

    # Test real work

    # Check