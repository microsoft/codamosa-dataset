

# Generated at 2022-06-25 19:20:59.011541
# Unit test for function compress_request
def test_compress_request():
    from httpie.compression import test_case_0
    try:
        test_case_0()
    except:
        assert False


import requests.models as module_0


# Generated at 2022-06-25 19:21:02.086521
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    bool_0 = False
    var_0 = compress_request(prepared_request_0, bool_0)

import requests.models as module_0


# Generated at 2022-06-25 19:21:06.284428
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    mp_encoder0 = MultipartEncoder(
        fields=[('field0', 'value0')],
        boundary='abcd'
    )
    chunked_multipart_upload_stream0 = ChunkedMultipartUploadStream(
        encoder=mp_encoder0
    )
    var_0 = len(chunked_multipart_upload_stream0.__iter__())
    assert var_0 == 0



# Generated at 2022-06-25 19:21:11.048742
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    bool_0 = False
    var_0 = compress_request(prepared_request_0, bool_0)
    var_1 = compress_request(prepared_request_0, bool_0)
    str_0 = str()
    prepared_request_0.body = str_0
    var_2 = compress_request(prepared_request_0, bool_0)
    str_1 = str()
    prepared_request_0.headers = {'Content-Encoding': str_1}
    var_3 = compress_request(prepared_request_0, bool_0)
    str_2 = str()
    prepared_request_0.headers = {'Content-Length': str_2}

# Generated at 2022-06-25 19:21:17.912342
# Unit test for function prepare_request_body
def test_prepare_request_body():
    try:
        arg_0 = None
        arg_1 = None
        arg_2 = None
        arg_3 = None
        arg_4 = None
        var_0 = prepare_request_body(arg_0, arg_1, arg_2, arg_3, arg_4)
        module_0.PreparedRequest()
        module_0.PreparedRequest()
        module_0.PreparedRequest()
        module_0.PreparedRequest()
    except Exception:
        pass


# Generated at 2022-06-25 19:21:20.955913
# Unit test for function prepare_request_body
def test_prepare_request_body():
    string_0 = 'request'
    var_0 = prepare_request_body(string_0, lambda c: c)


# Generated at 2022-06-25 19:21:32.038782
# Unit test for function compress_request
def test_compress_request():
    body = 'foo=1'
    headers = {'Content-Length': '4', 'Content-Type': 'application/x-www-form-urlencoded'}
    req = requests.PreparedRequest()
    req.prepare(method='POST', url='http://httpbin.org/post', headers=headers, data=body)
    compress_request(req, bool_0=False)
    body = 'foo=1'
    headers = {'Content-Length': '4', 'Content-Type': 'application/x-www-form-urlencoded'}
    req = requests.PreparedRequest()
    req.prepare(method='POST', url='http://httpbin.org/post', headers=headers, data=body)
    compress_request(req, bool_0=True)

# Generated at 2022-06-25 19:21:35.944293
# Unit test for function prepare_request_body
def test_prepare_request_body():
    str_0 = prepare_request_body(body=None, body_read_callback=False,
                                 content_length_header_value=False, chunked=False,
                                 offline=False)


# Generated at 2022-06-25 19:21:39.444682
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = module_0.PreparedRequest()
    bool_0 = False
    var_0 = compress_request(prepared_request_0, bool_0)


import requests.models as module_0


# Generated at 2022-06-25 19:21:45.998518
# Unit test for function prepare_request_body
def test_prepare_request_body():
    param_0 = {'foo': 'bar', 'baz': 'qux'}
    param_1 = None
    (var_0, var_1) = get_multipart_data_and_content_type(param_0, param_1)
    param_2 = {'foo': 'bar', 'baz': 'qux'}
    param_3 = None
    param_4 = None
    var_2 = prepare_request_body(param_3, param_2, param_4)
    var_3 = False
    var_4 = False
    var_5 = prepare_request_body(var_0, param_2, param_4, var_3, var_4)
    return (var_0, var_1, var_2, var_3, var_4, var_5)

# Generated at 2022-06-25 19:21:55.330249
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    for chunk_0 in chunked_multipart_upload_stream_0:
        pass


# Generated at 2022-06-25 19:22:01.504375
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder({})
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.chunk_size = 200 * 1024
    def test_lambda_0(chunk_0 : bytes) -> bytes:
        return chunk_0
    setattr(chunked_multipart_upload_stream_0, "callback", test_lambda_0)
    iteration_0 = iter(chunked_multipart_upload_stream_0)
    assert len(list(iteration_0)) > 0


# Generated at 2022-06-25 19:22:12.477422
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    io_0 = io.BytesIO()
    multipart_encoder_0 = MultipartEncoder(fields=io_0)
    tuple_0 = get_multipart_data_and_content_type(
        multipart_encoder_0,
        boundary=multipart_encoder_0.boundary_value,
        content_type=multipart_encoder_0.content_type
    )
    iterable_0 = ((multipart_encoder_0.read(100*1024)))
    iterable_1 = (stream for stream in iterable_0)
    chunked_upload_stream_0 = ChunkedUploadStream(iterable_1, test_ChunkedUploadStream___iter___0)

# Generated at 2022-06-25 19:22:21.498301
# Unit test for function compress_request
def test_compress_request():
    import json
    import requests

    url = 'http://httpbin.org/post'
    body = {'key1': 'value1'}
    # Requests to httpbin.org support gzip compression
    # so compression doesn't make sense here.
    request = requests.Request('POST', url=url, data=json.dumps(body))
    prepared_request = request.prepare()
    compress_request(prepared_request, always=False)

    assert prepared_request.body == '{"key1": "value1"}'
    assert 'Content-Encoding' not in prepared_request.headers

    prepared_request = request.prepare()
    compress_request(prepared_request, always=True)

    assert prepared_request.body == '{"key1": "value1"}'

# Generated at 2022-06-25 19:22:28.293984
# Unit test for function compress_request
def test_compress_request():
    class MockRequest:
        def __init__(self, body='body'):
            self._headers = {}
            self.body = body

        @property
        def headers(self):
            return self._headers

        @headers.setter
        def headers(self, value):
            self._headers = value

    request = MockRequest()
    compress_request(request, True)
    assert request._headers['Content-Encoding'] == 'deflate'
    assert len(request.body) == 11

    request = MockRequest()
    compress_request(request, False)
    assert 'Content-Encoding' not in request._headers
    assert len(request.body) == 11

    request = MockRequest()
    request._headers = {'Content-Type': 'application/json'}
    compress_request(request, False)

# Generated at 2022-06-25 19:22:30.534658
# Unit test for function prepare_request_body
def test_prepare_request_body():
    data = 'hello world'
    modified_data = prepare_request_body(data)
    assert data == modified_data
    pass


# Generated at 2022-06-25 19:22:40.719051
# Unit test for function compress_request
def test_compress_request():
    always = False
    request = requests.PreparedRequest()
    compress_request(request, always)
    request = requests.PreparedRequest()
    request.body = ""
    compress_request(request, always)
    request = requests.PreparedRequest()
    request.body = "b2xk"
    compress_request(request, always)
    request = requests.PreparedRequest()
    request.body = "b2xk"
    request.headers = {"Content-Encoding": "deflate"}
    compress_request(request, always)
    request = requests.PreparedRequest()
    request.body = "b2xk"
    request.headers = {"Content-Length": "4"}
    compress_request(request, always)
    request = requests.PreparedRequest()
    request.body = "b2xk"

# Generated at 2022-06-25 19:22:43.942502
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict_1 = module_0.MultipartRequestDataDict()
    tuple_1 = get_multipart_data_and_content_type(multipart_request_data_dict_1)


# Generated at 2022-06-25 19:22:50.025036
# Unit test for function prepare_request_body

# Generated at 2022-06-25 19:22:53.154233
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream()
    iter_0 = chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:23:04.093445
# Unit test for function compress_request
def test_compress_request():
    print ('Testing function compress_request...', end='')
    str_0 = 'callback'
    always = False
    request = requests.PreparedRequest()
    compress_request(request=request, always=always)
    assert(request.body == None)
    assert(request.headers == {'Content-Encoding': 'deflate', 'Content-Length': '0'})
    print ('seems ok')


# Generated at 2022-06-25 19:23:08.606705
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    str_0 = 'callback'
    print("Testing method __iter__ of class ChunkedUploadStream")
    test_obj_0 = ChunkedUploadStream(stream=(chunk.encode() for chunk in [body]), callback=test_case_0)
    assert test_obj_0.__iter__() == expected_result_0


# Generated at 2022-06-25 19:23:19.107584
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    mock_encoder = mock.Mock()
    mock_encoder.read.return_value = None
    mock_encoder.chunk_size = 100
    mock_encoder.read.side_effect = [b"1", b"2", b"3", b"4", b"5", None, ]
    mock_encoder.read_all.side_effect = [b"1", b"2", b"3", b"4", b"5", None, ]
    mock_encoder.read.return_value = None
    obj = ChunkedMultipartUploadStream(mock_encoder)
    try:
        import __builtin__
    except ImportError:
        import builtins

# Generated at 2022-06-25 19:23:20.356474
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    print(get_multipart_data_and_content_type)


# Generated at 2022-06-25 19:23:26.481538
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = None
    body_read_callback = None
    content_length_header_value = None
    chunked = None
    offline = None
    result = prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )
    str_0 = type(result).__name__
    if str_0 == 'generator':
        str_0 = 'generator_closure'


# Generated at 2022-06-25 19:23:30.931638
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = "This is HTTPie."
    request.headers = {'Content-Length': str(len(request.body))}
    compress_request(request, True)
    assert(request.headers['Content-Encoding'] == 'deflate')
    assert(request.headers['Content-Length'] == str(len(request.body)))


# Generated at 2022-06-25 19:23:41.449371
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    str_0 = 'a'
    str_1 = 'a'
    always = True
    compress_request(request, always)
    # assert that everything is the same
    for attr in ['body', 'headers']:
        assert getattr(request, attr) == getattr(request, attr)
    request.body = str_0
    assert request.body == str_1
    assert request.body == str_1
    assert request.body == str_1
    assert request.headers['Content-Encoding'] == request.headers['Content-Encoding']
    request.headers['Content-Encoding'] = 'a'
    # assert that everything is the same

# Generated at 2022-06-25 19:23:43.190320
# Unit test for function compress_request
def test_compress_request():
    test_compress_request_0()
    test_compress_request_1()
    test_compress_request_2()



# Generated at 2022-06-25 19:23:44.034661
# Unit test for function compress_request
def test_compress_request():
    pass
    

# Generated at 2022-06-25 19:23:46.455752
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    # Test get_multipart_data_and_content_type with a range of arguments
    test_get_multipart_data_and_content_type_inner()



# Generated at 2022-06-25 19:23:55.261510
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    request.body = '''foo
bar
baz
asdf'''
    compress_request(request, True)
    return

# Generated at 2022-06-25 19:24:05.609074
# Unit test for function compress_request
def test_compress_request():
    import httpie.cli.dicts as module_0
    import requests
    request_0 = requests.PreparedRequest()
    compress_request(request_0, 0)
    compress_request(request_0, 0)
    request_0 = requests.PreparedRequest()
    compress_request(request_0, 1)
    request_0 = requests.PreparedRequest()
    compress_request(request_0, 1)
    compress_request(request_0, 0)
    request_0 = requests.PreparedRequest()
    compress_request(request_0, 1)
    compress_request(request_0, 0)
    compress_request(request_0, 1)
    request_0 = requests.PreparedRequest()
    compress_request(request_0, 1)
    compress_request(request_0, 0)
   

# Generated at 2022-06-25 19:24:08.625756
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    prepare_request_body(request_data_dict_0, lambda *args: None)


# Generated at 2022-06-25 19:24:09.588905
# Unit test for function compress_request
def test_compress_request():
    pass


# Generated at 2022-06-25 19:24:18.995216
# Unit test for function prepare_request_body
def test_prepare_request_body():
    dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(dict_0)
    dict_1 = module_0.MultipartRequestDataDict()
    tuple_1 = get_multipart_data_and_content_type(dict_1)
    dict_2 = module_0.MultipartRequestDataDict()
    tuple_2 = get_multipart_data_and_content_type(dict_2)
    dict_3 = module_0.MultipartRequestDataDict()
    tuple_3 = get_multipart_data_and_content_type(dict_3)


# Generated at 2022-06-25 19:24:22.161517
# Unit test for function compress_request
def test_compress_request():
    # TODO: Write unit tests for compress_request
    ...


# Generated at 2022-06-25 19:24:25.105408
# Unit test for function compress_request
def test_compress_request():
    from requests import PreparedRequest
    request_0 = PreparedRequest()
    request_0.body = 'a'
    always_0 = True
    compress_request(request_0, always_0)


# Generated at 2022-06-25 19:24:33.417060
# Unit test for function compress_request
def test_compress_request():
    prep_req = requests.PreparedRequest()
    prep_req.body = "test"
    compress_request(prep_req, True)
    assert prep_req.headers['Content-Encoding'] == "deflate"
    assert prep_req.headers['Content-Length'] == "8"
    assert prep_req.body == b"x\x9cK\xca\xcc\x04\x00\x02\x82\xf2\x01\x04\x00"

# Generated at 2022-06-25 19:24:35.378567
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    compress_request(request, always = True)

import httpie.cli.dicts as module_0


# Generated at 2022-06-25 19:24:37.189504
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = False
    compress_request(request, always)


# Generated at 2022-06-25 19:24:44.815222
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = True
    compress_request(request, always)
    assert True


# Generated at 2022-06-25 19:24:47.157920
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    class_0 = ChunkedUploadStream(stream=.0, callback=.0)
    iter_0 = class_0.__iter__()


# Generated at 2022-06-25 19:24:49.995623
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)

# Generated at 2022-06-25 19:24:51.382497
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    compress_request(request, False)


# Generated at 2022-06-25 19:24:58.198519
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(ChunkedMultipartUploadStream.chunk_size)
    tuple_0 = chunked_multipart_upload_stream_0.__iter__()
    assert tuple_0


# Generated at 2022-06-25 19:25:02.644568
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(encoder_0)
    for __ in chunked_multipart_upload_stream_0:
        pass


# Generated at 2022-06-25 19:25:05.560204
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict_1 = {
    }
    tuple_4 = get_multipart_data_and_content_type(multipart_request_data_dict_1)


# Generated at 2022-06-25 19:25:06.134756
# Unit test for function compress_request
def test_compress_request():
    compress_request()

# Generated at 2022-06-25 19:25:09.266280
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = '<stream>'
    stream_0 = (chunk.encode() for chunk in [stream])
    chunked_upload_stream_0 = ChunkedUploadStream(stream=stream_0, callback=None)
    for arg_0 in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:25:18.708462
# Unit test for function compress_request
def test_compress_request():

    import requests

    import zlib

    # typechecked
    assert_raises_type_error(
        compress_request,
        ('request', requests.PreparedRequest()),
        ('always', True),
        ('no-compress', False),
    )

    # typechecked
    assert_raises_type_error(
        compress_request,
        ('request', requests.PreparedRequest()),
        ('always', 1),
        ('no-compress', False),
    )

    # typechecked
    assert_raises_type_error(
        compress_request,
        ('request', requests.PreparedRequest()),
        ('always', False),
        ('no-compress', 'foo'),
    )

    # typechecked

# Generated at 2022-06-25 19:25:33.263669
# Unit test for function compress_request
def test_compress_request():
    pass

# Generated at 2022-06-25 19:25:42.691164
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import sys as module_0
    import io as module_1
    import itertools as module_2
    import typing as module_3
    request_data_dict_0 = module_0.request_data_dict()
    chunked_upload_stream_0 = prepare_request_body(request_data_dict_0, lambda x: x)
    bool_0 = isinstance(chunked_upload_stream_0, module_3.Iterable)
    str_0 = 'abcdefg'
    chunked_upload_stream_1 = prepare_request_body(str_0, lambda x: x)
    bool_1 = isinstance(chunked_upload_stream_1, module_3.Iterable)
    str_1 = module_1.StringIO()
    int_0 = 2
    module_0.mult

# Generated at 2022-06-25 19:25:53.197425
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    assert isinstance(prepare_request_body(request_data_dict_0), ChunkedUploadStream)
    assert isinstance(prepare_request_body(request_data_dict_0, 0), ChunkedUploadStream)
    assert isinstance(prepare_request_body(request_data_dict_0, 0, 0), ChunkedUploadStream)
    assert isinstance(prepare_request_body(request_data_dict_0, 0, 0, 0), ChunkedUploadStream)
    assert isinstance(prepare_request_body(request_data_dict_0, 0, 0, 0, 0), ChunkedUploadStream)

# Generated at 2022-06-25 19:25:55.834843
# Unit test for function compress_request
def test_compress_request():
    request = requests.Request('GET', url='http://www.example.com/')
    always = True
    compress_request(request, always)
    always = False
    compress_request(request, always)

# Generated at 2022-06-25 19:26:02.547780
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = ()
    callback_0 = ()

    # Create an instance of ChunkedUploadStream (Class/Object)
    chunkeduploadstream_0 = ChunkedUploadStream(stream_0, callback_0)

    # Call the method __iter__
    try:
        iterator_0 = chunkeduploadstream_0.__iter__()
    except:
        assert False, 'The method __iter__ failed!'


# Generated at 2022-06-25 19:26:08.730572
# Unit test for function prepare_request_body
def test_prepare_request_body():
    def body_read_callback(chunk):
        return chunk

    body_0 = ""
    request_data_dict_0 = module_0.RequestDataDict()
    body_0 = prepare_request_body(body_0, body_read_callback, request_data_dict_0, True, True)

    assert body_0 is not None
    assert type(body_0) is str


# Generated at 2022-06-25 19:26:19.057967
# Unit test for function compress_request
def test_compress_request():
    class Mock0:
        def __init__(self, request):
            self.request = request

        def compress(self, body_bytes):
            return body_bytes

        def flush(self):
            return '%'

    class Mock1:
        def __init__(self, request):
            self.request = request

        def read(self):
            return 'X'

    mock1 = Mock0(request=Mock1())
    mock2 = Mock0(request=Mock1())
    mock3 = Mock0(request=Mock1())

    assert compress_request(mock1, always=False) == None
    assert compress_request(mock2, always=False) == None
    assert compress_request(mock3, always=False) == None


# Generated at 2022-06-25 19:26:25.253434
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import multipart
    body_0 = 'a'
    multipart_encoder_0 = multipart.MultipartEncoder()
    request_data_dict_0 = module_0.RequestDataDict()
    assert prepare_request_body(body_0, multipart_encoder_0, request_data_dict_0) == 'a'
    assert prepare_request_body(multipart_encoder_0, body_0, request_data_dict_0) == multipart_encoder_0
    assert prepare_request_body(request_data_dict_0, multipart_encoder_0, body_0) == 'a=1'


# Generated at 2022-06-25 19:26:35.964430
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test for preparing body for offline mode
    body = 'Hello World'
    offline = True
    request_body = prepare_request_body(body, None, offline=offline)
    assert request_body == body

    # Test for stdin as body when in offline mode
    body = io.StringIO(u'Hello World')
    offline = True
    request_body = prepare_request_body(body, None, offline=offline)
    assert request_body == 'Hello World'

    # Test for preparing body for chunked mode
    body = 'Hello World'
    chunked = True
    request_body = prepare_request_body(body, None, chunked=chunked)
    assert request_body
    assert request_body.callback == None

    # Test for preparing body for non-offline and non-chunked mode


# Generated at 2022-06-25 19:26:38.436794
# Unit test for function compress_request
def test_compress_request():
    import requests
    
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)


# Generated at 2022-06-25 19:26:54.047754
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    pass


# Generated at 2022-06-25 19:26:56.690471
# Unit test for function compress_request
def test_compress_request():
    # Test for function 'compress_request'
    # test for function: def compress_request(request: requests.PreparedRequest,
    # always: bool,) -> None:
    # TODO: implement tests for function compress_request
    pass

# Generated at 2022-06-25 19:26:58.883600
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = None
    callback_0 = None
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, callback_0)


# Generated at 2022-06-25 19:27:01.596687
# Unit test for function prepare_request_body
def test_prepare_request_body():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)

# Generated at 2022-06-25 19:27:11.134240
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    # Python 3.6 and newer:
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    multipart_encoder_0 = tuple_0[0]
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.__iter__()
    chunked_multipart_upload_stream_0.__iter__()
    chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:27:18.967345
# Unit test for function compress_request
def test_compress_request():
    import mock
    import requests
    import zlib

    request_0: requests.PreparedRequest = mock.Mock()
    if (isinstance(request_0.body, str)):
        body_bytes_0 = (request_0.body.encode())
    elif (hasattr(request_0.body, 'read')):
        body_bytes_0 = (request_0.body.read())
    else:
        body_bytes_0 = request_0.body
    deflater_0 = (zlib.compressobj())
    deflated_data_0 = (deflater_0.compress(body_bytes_0))
    deflated_data_0 = ((deflated_data_0 + (deflater_0.flush())))

# Generated at 2022-06-25 19:27:29.266348
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test 1
    request_data_dict_0 = module_0.RequestDataDict()
    prepare_request_body(request_data_dict_0, lambda chunk: None)
    # Test 2
    request_data_dict_1 = module_0.RequestDataDict()
    object_0 = module_0.RequestDataDict()
    prepare_request_body(request_data_dict_1, object_0.__setitem__)
    # Test 3
    request_data_dict_2 = module_0.RequestDataDict()
    object_1 = module_0.RequestDataDict()
    prepare_request_body(request_data_dict_2, object_1.__setitem__, offline=True)
    # Test 4
    request_data_dict_3 = module_0.RequestDataDict

# Generated at 2022-06-25 19:27:35.674030
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder({'Content-Disposition': 'form-data; name="foo"', 'Content-Type': 'text/plain'})
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    iterator_0 = chunked_multipart_upload_stream_0.__iter__()
    assert isinstance(iterator_0, Iterable)
    assert len(iter(iterator_0)) == 1


# Generated at 2022-06-25 19:27:38.578795
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0)
    tuple_0 = (request_0, request_0)


# Generated at 2022-06-25 19:27:44.866537
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_read_callback_0 = lambda x: x
    request_data_dict_0 = module_0.RequestDataDict()
    html_0 = prepare_request_body(request_data_dict_0,body_read_callback_0, offline=False,)


# Generated at 2022-06-25 19:28:06.249487
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = b'some body'
    chunk = b'some chun'
    encoder = MultipartEncoder(fields={'key': 'value'})
    encoder_chunk = encoder.read(len(chunk))

    def body_read_callback(callback_chunk):
        assert callback_chunk == chunk

    body_0 = prepare_request_body(body, body_read_callback, chunked=True)
    body_1 = prepare_request_body(body, body_read_callback)
    body_2 = prepare_request_body(body, body_read_callback, chunked=True, offline=True)
    body_3 = prepare_request_body(body, body_read_callback, offline=True)

    assert body_0.stream is body.split(b'')
    assert body_1

# Generated at 2022-06-25 19:28:17.297006
# Unit test for function compress_request
def test_compress_request():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    multipart_encoder_0 = tuple_0[0]
    str_0 = tuple_0[1]
    requests_0 = requests
    requests_1 = requests
    requests_2 = requests
    requests_3 = requests
    class_0 = requests_0.PreparedRequest
    class_1 = requests_1.PreparedRequest
    class_2 = requests_2.PreparedRequest
    class_3 = requests_3.PreparedRequest
    class_4 = class_3(method='get', url='/path')
    prepared_request_0 = class_4
    bool_0

# Generated at 2022-06-25 19:28:26.169341
# Unit test for function compress_request

# Generated at 2022-06-25 19:28:30.756230
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = module_0.RequestDataDict()
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)
    


# Generated at 2022-06-25 19:28:32.412493
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream()


# Generated at 2022-06-25 19:28:41.791951
# Unit test for function prepare_request_body
def test_prepare_request_body():
    import io
    # Missing arguments.
    with raises(TypeError):
        prepare_request_body()
    # Positional arguments.
    tuple_0 = prepare_request_body('string_0')
    # Keyword arguments.
    def function_0(body: bytes) -> bytes:
        return body
    tuple_0 = prepare_request_body(
        body='string_0',
        body_read_callback=function_0,
        chunked=False,
        content_length_header_value=17,
        offline=True,
    )
    # Positional and keyword arguments mixed.
    # Default values.
    # Default values.
    # Default values.
    # Default values.
    # Default values.
    # Keyword argument 'offline' is False.
    # File-like objects.
    file_obj

# Generated at 2022-06-25 19:28:44.980934
# Unit test for function compress_request
def test_compress_request():
    test_compress_request_0()
    test_compress_request_1()
    test_compress_request_2()
    test_compress_request_3()
    test_compress_request_4()


# Generated at 2022-06-25 19:28:54.730041
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = b"Hello"
    callback = lambda data: None
    assert prepare_request_body(body, callback, None, False, False) == b"Hello"
    assert prepare_request_body(body, callback, None, True, False) == b"Hello"
    assert prepare_request_body(body, callback, None, False, True) == b"Hello"

    body = b"Hello"
    callback = lambda data: data
    assert prepare_request_body(body, callback, None, False, False) == b"Hello"
    assert prepare_request_body(body, callback, None, True, False) == b"Hello"
    assert prepare_request_body(body, callback, None, False, True) == b"Hello"

    # from httpie.cli.dicts import MultipartRequestDataDict
    multipart_

# Generated at 2022-06-25 19:29:01.290952
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert prepare_request_body(
        body='a',
        body_read_callback=None,
        content_length_header_value=None,
        chunked=False,
        offline=False) == 'a'


# Generated at 2022-06-25 19:29:10.760600
# Unit test for function compress_request
def test_compress_request():
    data = b'The quick brown fox jumps over the lazy dog'
    content_type = 'text/plain'
    request = requests.Request('POST', 'http://httpbin.org/post', data=data, headers={
        'Content-Type': content_type
    })

    # When not always and the compressed body would be bigger, do nothing
    always = False
    compress_request(request.prepare(), always)
    assert request.body == data
    assert 'Content-Encoding' not in request.headers
    assert request.headers['Content-Length'] == str(len(data))

    # When always and the compressed body would be bigger, do the compression
    always = True
    compress_request(request.prepare(), always)
    assert request.body != data
    assert request.headers['Content-Encoding'] == 'deflate'


# Generated at 2022-06-25 19:29:59.616559
# Unit test for function compress_request
def test_compress_request():

    # Arrange
    input_body = 'This is a test.'

    class PreparedRequest:
        def __init__(self):
            self.body = input_body
            self.headers = {'Content-Length': str(len(input_body))}

    request = PreparedRequest()

    # Act
    compress_request(request, True)

    # Assert
    deflated_data = request.body
    assert deflated_data is not input_body
    assert deflated_data is not None
    assert isinstance(deflated_data, bytes)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '13'



# Generated at 2022-06-25 19:30:01.452747
# Unit test for function compress_request
def test_compress_request():
    assert True

# Generated at 2022-06-25 19:30:05.797049
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Setup some arguments from original function
    # Arguments will be modified during test runs
    body = ''
    body_read_callback = ''
    content_length_header_value = ''
    chunked = ''
    offline = ''
    
    prepare_request_body(
        body,
        body_read_callback,
        content_length_header_value,
        chunked,
        offline,
    )

# Generated at 2022-06-25 19:30:12.836829
# Unit test for function prepare_request_body
def test_prepare_request_body():

    def body_read_callback():
        pass

    def func_mp_request_data_dict():
        return module_0.MultipartRequestDataDict()

    def func_request_data_dict():
        return module_0.RequestDataDict()

    chunked = True
    offline = False

    # Test 1:
    # args is a bytes
    body_1 = b'This is a test'
    content_length_header_value = 12
    output_1 = prepare_request_body(body_1, body_read_callback, content_length_header_value, chunked, offline)
    assert(output_1 == body_1)

    # Test 2:
    # args is a str
    body_2 = 'This is a test'

# Generated at 2022-06-25 19:30:15.150025
# Unit test for function compress_request
def test_compress_request():

    args = {'always': True, 'request': 'request:PreparedRequest'}
    compress_request(**args)


# Generated at 2022-06-25 19:30:21.767366
# Unit test for function prepare_request_body
def test_prepare_request_body():
    test_parameter_0 = {
        'A': ['a'],
        'B': ['1', '2'],
    }
    test_parameter_1 = True
    test_parameter_2 = True
    test_parameter_3 = True

    test_returned = prepare_request_body(
        test_parameter_0,
        test_parameter_1,
        test_parameter_2,
        test_parameter_3,
    )


# Generated at 2022-06-25 19:30:24.247410
# Unit test for function compress_request
def test_compress_request():
    requests_prepared_request_0 = requests.PreparedRequest()
    compress_request(requests_prepared_request_0, True)


# Generated at 2022-06-25 19:30:26.957651
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    request_0.body = "This is the request body to compress"
    compress_request(request_0, True)


# Generated at 2022-06-25 19:30:32.127318
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(
        stream=(chunk.encode() for chunk in ['value']),
        callback=get_multipart_data_and_content_type,
    )
    for chunk in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:30:35.879504
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream = [
        'a',
        'b',
        'c',
    ]
    def callback(chunk): pass
    chunked_upload_stream_0 = ChunkedUploadStream(stream, callback)
    for _ in chunked_upload_stream_0:
        pass
