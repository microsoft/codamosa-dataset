

# Generated at 2022-06-25 19:21:01.330131
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    # Basic testing
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    iter_0 = iter(chunked_multipart_upload_stream_0)
    assert iter_0.__length_hint__() == 0
    assert iter_0.__next__().__class__ == bytes
    assert iter_0.__next__().__class__ == bytes


# Generated at 2022-06-25 19:21:08.160620
# Unit test for function compress_request
def test_compress_request():
    # MultipartRequestDataDict
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    # MultipartEncoder
    multipart_encoder_0 = MultipartEncoder(fields=multipart_request_data_dict_0.items())
    # str
    str_0 = 'form-data'
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0, content_type=str_0)
    # requests.PreparedRequest
    prepared_request_0 = requests.Request('GET', 'http://example.com').prepare()
    prepared_request_0.body = multipart_encoder_0
    compress_request(prepared_request_0, True)


# Generated at 2022-06-25 19:21:13.600437
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    request_0.body = 'string'
    always_0 = False
    assert compress_request(request_0, always_0) is None
    request_1 = requests.PreparedRequest()
    request_1.body = 'string'
    always_1 = True
    compress_request(request_1, always_1)


# Generated at 2022-06-25 19:21:16.943796
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = MultipartEncoder()
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    for chunk in chunked_multipart_upload_stream_0:
        pass


# Generated at 2022-06-25 19:21:21.559107
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    multipart_request_data_dict_0 = module_0.MultipartRequestDataDict()
    tuple_0 = get_multipart_data_and_content_type(multipart_request_data_dict_0)

# Generated at 2022-06-25 19:21:33.076393
# Unit test for function compress_request
def test_compress_request():
    # TODO: fix
    def mock_prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline):
        assert 1==1
        return body

    module_0.prepare_request_body = mock_prepare_request_body

    from io import TextIOBase

    class MockRequest(object):
        body = "abc"
        headers = {"Content-Length": "3"}
        # TODO: mock isinstance(request.body, str)
        def __init__(self, body):
            self.body = body

    request = MockRequest("abc")
    always = False

    compress_request(request, always)

    assert request.headers["Content-Encoding"] == "deflate"
    assert request.headers["Content-Length"] == "3"

# Generated at 2022-06-25 19:21:36.456666
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream()
    for chunk_0 in chunked_upload_stream_0:
        pass


# Generated at 2022-06-25 19:21:40.241834
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Arrange
    body = "test"
    body_read_callback = lambda x: x 

    # Act
    resp = prepare_request_body(body, body_read_callback)

    # Assert
    assert resp == "test"


# Generated at 2022-06-25 19:21:41.328164
# Unit test for function get_multipart_data_and_content_type
def test_get_multipart_data_and_content_type():
    assert(len(get_multipart_data_and_content_type(module_0.MultipartRequestDataDict())) == 2)

# Generated at 2022-06-25 19:21:48.486950
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    arg_0 = test_ChunkedUploadStream___iter___0()
    chunked_upload_stream_0 = ChunkedUploadStream(arg_0[0],arg_0[1])
    iter_0 = chunked_upload_stream_0.__iter__()
    test_case_1(iter_0)


# Generated at 2022-06-25 19:22:05.933550
# Unit test for function compress_request
def test_compress_request():
    data = 'hello'
    deflater = zlib.compressobj()
    deflated_data = deflater.compress(data.encode())
    deflated_data += deflater.flush()
    is_economical = len(deflated_data) < len(data)

# Generated at 2022-06-25 19:22:07.862122
# Unit test for function compress_request
def test_compress_request():
    assert True # TODO: implement your test here



# Generated at 2022-06-25 19:22:09.949467
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    gen = ChunkedMultipartUploadStream().__iter__()
    next(gen)


# Generated at 2022-06-25 19:22:13.278562
# Unit test for method __iter__ of class ChunkedUploadStream

# Generated at 2022-06-25 19:22:21.921529
# Unit test for function compress_request
def test_compress_request():
    import json
    import zlib

    request = requests.PreparedRequest(
        'GET', 'http://httpbin.org',
    )
    request.body = json.dumps({
        'foo': 'bar'
    }).encode()
    request.headers['Content-Type'] = 'application/json'
    request.headers['Content-Encoding'] = 'deflate'
    assert request.body == b'{"foo": "bar"}'
    compress_request(request, always=True)
    assert request.body == zlib.compress(b'{"foo": "bar"}')
    assert request.headers == {
        'Content-Encoding': 'deflate',
        'Content-Type': 'application/json',
        'Content-Length': '18'
    }



# Generated at 2022-06-25 19:22:23.118955
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream()


# Generated at 2022-06-25 19:22:24.433271
# Unit test for function compress_request
def test_compress_request():
    assert True



# Generated at 2022-06-25 19:22:26.025098
# Unit test for function compress_request
def test_compress_request():
    req = requests.PreparedRequest()
    compress_request(req, False)

# Generated at 2022-06-25 19:22:32.789345
# Unit test for function prepare_request_body
def test_prepare_request_body():
    in_body = 'data'
    chunked = True
    offline = False
    expected_out = 'data'
    actual_out = prepare_request_body(
        body=in_body,
        body_read_callback=None,
        content_length_header_value=None,
        chunked=chunked,
        offline=offline,
    )
    assert actual_out == expected_out



# Generated at 2022-06-25 19:22:34.061874
# Unit test for function prepare_request_body
def test_prepare_request_body():
    assert prepare_request_body() == None, "Test Failed"


# Generated at 2022-06-25 19:22:46.009181
# Unit test for method __iter__ of class ChunkedUploadStream

# Generated at 2022-06-25 19:22:47.246886
# Unit test for function compress_request
def test_compress_request():
    request = None
    always = False
    compress_request(request, always)

# Generated at 2022-06-25 19:22:58.321223
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_read_callback_0 = None
    body_0 = ""
    content_length_header_value_0 = None
    offline_0 = False
    chunked_0 = False
    test_prepare_request_body_0(body_read_callback_0, body_0, content_length_header_value_0, offline_0, chunked_0)
    body_read_callback_0 = None
    body_0 = ""
    content_length_header_value_0 = None
    offline_0 = True
    chunked_0 = True
    test_prepare_request_body_0(body_read_callback_0, body_0, content_length_header_value_0, offline_0, chunked_0)
    body_read_callback_0 = None
    body_0 = ""
   

# Generated at 2022-06-25 19:23:04.838916
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Test the outermost if block.
    body = None
    body_read_callback = None
    content_length_header_value = None
    chunked = False
    offline = False
    actual = prepare_request_body(body, body_read_callback, content_length_header_value)
    expected = None
    assert actual == expected

    # Test the innermost if block.
    body = ''
    body_read_callback = None
    content_length_header_value = None
    chunked = False
    offline = False
    actual = prepare_request_body(body, body_read_callback, content_length_header_value)
    expected = ''
    assert actual == expected

# Test case for prepare_request_body

# Generated at 2022-06-25 19:23:10.006881
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    assert MultipartEncoder is type(chunked_multipart_upload_stream_0.encoder)
    assert 100 * 1024 is chunked_multipart_upload_stream_0.chunk_size



# Generated at 2022-06-25 19:23:11.728098
# Unit test for function compress_request
def test_compress_request():
    request_0 = None
    compress_request(request_0, True)

# Generated at 2022-06-25 19:23:13.770614
# Unit test for function compress_request
def test_compress_request():
    request_0 = None
    always_0 = False
    compress_request(request_0, always_0)


# Generated at 2022-06-25 19:23:16.262501
# Unit test for function prepare_request_body
def test_prepare_request_body():
    request_data_dict_0 = None
    callback_0 = None
    chunked_upload_stream_0 = ChunkedUploadStream(request_data_dict_0, callback_0)


# Generated at 2022-06-25 19:23:26.519297
# Unit test for function prepare_request_body
def test_prepare_request_body():

    import io
    import typing
    import requests

    chunked_upload_stream_0 = None
    chunked_upload_stream_1 = None
    chunked_upload_stream_2 = None
    chunked_upload_stream_3 = None
    chunked_multipart_upload_stream_1 = None
    def body_read_callback_0(body_bytes_0: bytes):
        pass
    request_data_dict_0 = None
    request_data_dict_1 = None

    multipart_request_data_dict_0 = None
    boundary_0 = None
    multipart_encoder_1 = None

    prepared_request_body_0 = prepare_request_body(chunked_upload_stream_0, body_read_callback_0)
    prepared_request_body_2 = prepare_request_

# Generated at 2022-06-25 19:23:27.993009
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)
    

# Generated at 2022-06-25 19:23:43.309550
# Unit test for function prepare_request_body
def test_prepare_request_body():
    test_body_0 = None
    test_callback_0 = None
    test_content_length_header_value_0 = None
    test_chunked_0 = None
    test_offline_0 = None
    test_return_0 = prepare_request_body(
        test_body_0,
        test_callback_0,
        test_content_length_header_value_0,
        test_chunked_0,
        test_offline_0,
    )
    # Test for satisfy
    test_file_like_0 = None
    test_file_like_1 = hasattr(test_file_like_0, 'read')

# Generated at 2022-06-25 19:23:45.068940
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = True
    compress_request(request, always)



# Generated at 2022-06-25 19:23:46.579793
# Unit test for function compress_request
def test_compress_request():
    request_0 = None
    always_0 = False
    compress_request(request_0, always_0)


# Generated at 2022-06-25 19:23:55.117704
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    try:
        assert_equal(list(chunked_multipart_upload_stream_0.__iter__()), [])
    except TypeError as e:
        assert_equal(str(e), 'object of type NoneType has no len()')
    expected_0 = ()
    actual_0 = chunked_multipart_upload_stream_0.__iter__()
    assert_equal(expected_0, actual_0)

# Generated at 2022-06-25 19:23:57.469456
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = False
    result = compress_request(request, always)
    assert result is None


# Generated at 2022-06-25 19:24:04.246458
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = {}
    body_read_callback = lambda chunk: None
    content_length_header_value = None
    chunked = False
    offline = False
    # Test with a dictionary
    prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)
    # Test with an integer
    prepare_request_body(0, body_read_callback, content_length_header_value, chunked, offline)


# Generated at 2022-06-25 19:24:08.551315
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    always_0 = False

    # Call compress_request with arguments request_0, always_0
    compress_request(request_0, always_0)



# Generated at 2022-06-25 19:24:19.106033
# Unit test for function compress_request
def test_compress_request():
    multipart_encoder_0 = MultipartEncoder(fields=[])
    request_0 = requests.PreparedRequest()
    request_0.body = multipart_encoder_0
    request_0.headers = {
        'Content-Encoding': 'deflate',
        'Content-Length': '11'
    }
    always_0 = False
    # State before function call.
    print(request_0.headers['Content-Encoding'], request_0.headers['Content-Length'])
    compress_request(request_0, always_0)
    # State after function call.
    print(request_0.headers['Content-Encoding'], request_0.headers['Content-Length'])
    assert(request_0.headers['Content-Encoding'] == 'deflate')

# Generated at 2022-06-25 19:24:23.634556
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    yield


# Generated at 2022-06-25 19:24:31.615924
# Unit test for function prepare_request_body
def test_prepare_request_body():
    multipart_encoder_0 = None
    body_read_callback_0 = None
    content_length_header_value_0 = 0
    chunked_0 = None
    offline_0 = None

    body_0 = None

    assert prepare_request_body(
        body_0, body_read_callback_0, content_length_header_value_0, chunked_0, offline_0
    )


# Generated at 2022-06-25 19:24:38.957849
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = ChunkedUploadStream(None, None)
    chunked_upload_stream_0___iter___0 = None
    for val in chunked_upload_stream_0___iter___0:
        pass


# Generated at 2022-06-25 19:24:40.771966
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = False
    compress_request(request, always)


# Generated at 2022-06-25 19:24:46.174686
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    chunked_multipart_upload_stream_0.chunk_size = 100 * 1024
    chunked_multipart_upload_stream_0.encoder = multipart_encoder_0
    # __iter__ method return value
    assert(next(chunked_multipart_upload_stream_0.__iter__()) == None)


# Generated at 2022-06-25 19:24:48.272731
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    chunked_upload_stream_0 = None
    chunked_upload_stream_1 = ChunkedUploadStream(
        stream=chunked_upload_stream_0,
        callback=test_ChunkedUploadStream___iter__)


# Generated at 2022-06-25 19:24:51.234836
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    content_length = len(request.body)
    compress_request(request, True)
    assert request.headers['Content-Encoding'] == 'deflate'
    assert int(request.headers['Content-Length']) < content_length

# Generated at 2022-06-25 19:24:57.923050
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    for _ in chunked_multipart_upload_stream_0:
        pass


# Generated at 2022-06-25 19:25:03.629036
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_read_callback_0 = None
    body_0 = None
    content_length_header_value_0 = None
    chunked_0 = None
    offline_0 = None
    prepare_request_body(body_0, body_read_callback_0, content_length_header_value_0, chunked_0, offline_0)


# Generated at 2022-06-25 19:25:05.765202
# Unit test for function compress_request
def test_compress_request():
    request_0 = None
    always_0 = None
    assert(compress_request(request_0, always_0) is None)


# Generated at 2022-06-25 19:25:17.035355
# Unit test for function compress_request
def test_compress_request():
    import inspect
    import json
    import zlib
    import itertools
    import random

    import requests
    import pytest

    from httpie import ExitStatus
    from httpie.core import main

    from . import httpbin

    """Test for function 'compress_request' in module 'httpie.compression'
    """

    content_type = 'multipart/form-data; boundary=------------------------5b5a5b5fb5b5a5b5'
    data = {'foo': 'bar'}
    uri = httpbin.url + '/post'
    method = 'POST'
    request_headers = {'Content-Type': content_type, 'User-Agent': 'httpie'}
    r = requests.Request(method, uri, data=data, headers=request_headers)
    prepared = r

# Generated at 2022-06-25 19:25:18.903750
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()
    always = True
    compress_request(request, always)
    return True

# Generated at 2022-06-25 19:25:32.944500
# Unit test for function compress_request
def test_compress_request():

    request = requests.PreparedRequest()
    body = open(os.path.abspath('./test/test_file'), 'rb')
    request.body = body
    request.headers['Transfer-Encoding'] = 'chunked'

    compress_request(request, True)

    print(request.body)
    print(request.headers)

    assert request.body

# Generated at 2022-06-25 19:25:34.271976
# Unit test for function compress_request
def test_compress_request():
    request = None
    always = False
    compress_request(request, always)

# Generated at 2022-06-25 19:25:35.063027
# Unit test for function prepare_request_body
def test_prepare_request_body():
    pass


# Generated at 2022-06-25 19:25:40.437708
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    def callback_0(chunk):
        return chunk
    chunked_upload_stream_0 = ChunkedUploadStream(None, callback_0)
    chunked_upload_stream_0.callback = None
    chunked_upload_stream_0.stream = None
    # Unit test for ChunkedUploadStream.__iter__()
    assert isinstance(iter(chunked_upload_stream_0), types.GeneratorType)



# Generated at 2022-06-25 19:25:44.021962
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    callback_0 = None
    chunked_upload_stream_0 = ChunkedUploadStream(stream=Iterable, callback=callback_0)
    chunked_upload_stream_0.stream
    chunked_upload_stream_0.callback


# Generated at 2022-06-25 19:25:47.085506
# Unit test for function compress_request
def test_compress_request():
    # check that the hostname is correct
    request = requests.PreparedRequest()
    always = True
    assert compress_request(request, always) == None

# Generated at 2022-06-25 19:25:51.518765
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    str_0_0 = chunked_multipart_upload_stream_0.__iter__()
    assert type(str_0_0) == generator


# Generated at 2022-06-25 19:25:52.697119
# Unit test for function compress_request
def test_compress_request():
    request = None
    always = False
    compress_request(request, always)

# Generated at 2022-06-25 19:26:03.194129
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_0 = 'body'
    body_1 = None
    body_2 = 'body'
    body_3 = None
    body_4 = 'body'
    body_5 = None
    body_6 = 'body'
    body_7 = None
    body_8 = 'body'
    body_9 = None
    body_10 = 'body'
    body_11 = None
    body_12 = 'body'
    body_13 = None
    body_14 = 'body'
    body_15 = None
    body_16 = 'body'
    body_17 = None
    body_18 = 'body'
    body_19 = None
    body_20 = 'body'
    body_21 = None
    body_22 = 'body'
    body_23 = None

# Generated at 2022-06-25 19:26:04.613123
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    # This is a stub
    raise RuntimeError()


# Generated at 2022-06-25 19:26:15.134774
# Unit test for function compress_request
def test_compress_request():
    request = None
    always = 1
    assert compress_request(request, always) == None


# Generated at 2022-06-25 19:26:16.025375
# Unit test for function compress_request
def test_compress_request():
    assert True



# Generated at 2022-06-25 19:26:23.941538
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    def deflater_0():
        return zlib.compressobj()
    def deflater_0():
        return zlib.compressobj()
    def deflater_0():
        return zlib.compressobj()
    def deflater_0():
        return zlib.compressobj()
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    def deflater_0():
        return zlib.compressobj()
    def deflater_0():
        return zlib.compressobj()
    def deflater_0():
        return zlib.compressobj()
    def deflater_0():
        return zlib.compressobj()

# Generated at 2022-06-25 19:26:32.538993
# Unit test for function compress_request
def test_compress_request():
    multipart_encoder_0 = None
    request_0 = requests.PreparedRequest()
    request_0.body = multipart_encoder_0
    request_0.headers = {'Content-Encoding': 'deflate', 'Content-Length': 'str(len(deflated_data))'}
    deflated_data_0 = None
    def test_lambda_0(body_bytes_0, *args_0, **kwargs_0):
        superset_call_result_0 = superset(body_bytes_0, *args_0, **kwargs_0)
        return superset_call_result_0

# Generated at 2022-06-25 19:26:43.726328
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = b''
    body = ChunkedUploadStream(iter([body]), None)
    body = ChunkedMultipartUploadStream()
    body = RequestDataDict({})
    body = urlencode(body, doseq=True)
    body = ChunkedUploadStream(iter([body]), None)
    body = ChunkedMultipartUploadStream()
    body = b''
    body = ChunkedUploadStream(iter([body]), None)
    body = None
    body = b''
    body = ChunkedUploadStream(iter([body]), None)
    body = ChunkedMultipartUploadStream()
    body = b''
    body = ChunkedUploadStream(iter([body]), None)
    body = ChunkedMultipartUploadStream()
    body = b''
    body = ChunkedUpload

# Generated at 2022-06-25 19:26:51.163066
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = None
    always_0 = False

    compress_request(prepared_request_0, always_0)

# Tested: def get_multipart_data_and_content_type(data: MultipartRequestDataDict, boundary: str = None,
# content_type: str = None) -> Tuple[MultipartEncoder, str]:


test_case_0()

# Generated at 2022-06-25 19:26:57.440040
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    iter_0 = chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:27:01.792443
# Unit test for function compress_request
def test_compress_request():
    prepared_request_0 = requests.PreparedRequest()
    prepared_request_0.body = b''
    compress_request(prepared_request_0, None)
    assert prepared_request_0.body == b''
    assert prepared_request_0.headers['Content-Encoding'] == 'deflate'
    assert prepared_request_0.headers['Content-Length'] == '0'


# Generated at 2022-06-25 19:27:11.819070
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.Request(method='GET', url='HTTP://httpbin.org')
    request_0.update(headers={'User-Agent': 'HTTPie/0.9.9'})
    multipart_encoder_1 = MultipartEncoder(fields=[], boundary='JYWyX9C4WF4K4AaCJpiU6ZpPK6e41UfS')
    multipart_encoder_1.update(content_type='multipart/form-data; boundary=JYWyX9C4WF4K4AaCJpiU6ZpPK6e41UfS')
    chunked_multipart_upload_stream_1 = ChunkedMultipartUploadStream(multipart_encoder_1)

# Generated at 2022-06-25 19:27:13.543532
# Unit test for function compress_request
def test_compress_request():
    # Test for common case.
    prepared_request_0 = None
    boolean_0 = None
    compress_request(prepared_request_0, boolean_0)



# Generated at 2022-06-25 19:27:23.494846
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)

# Generated at 2022-06-25 19:27:26.416723
# Unit test for function compress_request
def test_compress_request():
    request_0 = None
    always_0 = False
    compress_request(request_0, always_0)


# Generated at 2022-06-25 19:27:28.247392
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    always_0 = True
    compress_request(request_0, always_0)


# Generated at 2022-06-25 19:27:31.445443
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    # assert chunked_multipart_upload_stream_0.__iter__()


# Generated at 2022-06-25 19:27:36.985382
# Unit test for function compress_request
def test_compress_request():
    multipart_encoder_0 = None
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(multipart_encoder_0)
    requests_prepared_request_0 = requests.PreparedRequest(chunked_multipart_upload_stream_0, None)
    always_0 = True
    compress_request(requests_prepared_request_0, always_0)

# Generated at 2022-06-25 19:27:39.344605
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    i_0 = next(ChunkedUploadStream.stream)
    assert True



# Generated at 2022-06-25 19:27:50.029964
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_0 = 'hello'
    body_read_callback_0 = lambda arg0: arg0
    chunked_upload_stream_0 = ChunkedUploadStream(iter([]), body_read_callback_0)
    body_1 = 'hello'
    body_read_callback_1 = lambda arg0: arg0
    chunked_upload_stream_1 = ChunkedUploadStream(iter([]), body_read_callback_1)
    body_2 = 'hello'
    body_read_callback_2 = lambda arg0: arg0
    chunked_upload_stream_2 = ChunkedUploadStream(iter([]), body_read_callback_2)
    body_3 = 'hello'
    body_read_callback_3 = lambda arg0: arg0
    chunked_upload_stream_3 = Chunk

# Generated at 2022-06-25 19:27:59.101069
# Unit test for function compress_request
def test_compress_request():
    request = requests.PreparedRequest()

    compress_request(request, False)

    # Check if the function did not process when the request body was none
    assert request.body == None
    assert 'Content-Encoding' not in request.headers
    assert 'Content-Length' not in request.headers

    request.body = "Hello World"
    compress_request(request, False)

    # Check if the function did not process when the request body is not economical
    assert request.body == "Hello World"
    assert 'Content-Encoding' not in request.headers
    assert 'Content-Length' not in request.headers

    compress_request(request, True)

    # Check if the function did process when the request body is economical or if always is true
    assert request.body != "Hello World"
    assert 'Content-Encoding' in request.headers

# Generated at 2022-06-25 19:28:04.827025
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_read_callback_0 = lambda chunk: None 
    body_0 = ''
    content_length_header_value_0 = None
    chunked_0 = True
    offline_0 = True
    val_0 = prepare_request_body(body_0,body_read_callback_0,content_length_header_value_0,chunked_0,offline_0)
    assert type(val_0) == str


# Generated at 2022-06-25 19:28:15.244997
# Unit test for function prepare_request_body
def test_prepare_request_body():
    multipart_encoder_0 = None
    request_data_dict_0 = None
    chunked_upload_stream_0 = ChunkedUploadStream(request_data_dict_0, body_read_callback = None)
    str_0 = prepare_request_body(request_data_dict_0, body_read_callback = None, chunked = False, offline = False)
    str_1 = prepare_request_body(request_data_dict_0, body_read_callback = None, content_length_header_value = None, offline = False)
    str_2 = prepare_request_body(request_data_dict_0, body_read_callback = None, content_length_header_value = None, chunked = False)

# Generated at 2022-06-25 19:28:25.753154
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = None
    assert chunked_multipart_upload_stream_0.__iter__() is None


# Generated at 2022-06-25 19:28:28.063366
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_read_callback_0 = None
    prepare_request_body(
        body=b'',
        body_read_callback=body_read_callback_0
    )


# Generated at 2022-06-25 19:28:30.942721
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = 'af7ae505a9eed503f8b8e6982036873e'
    data = chunked_multipart_upload_stream_0
    assert body == data


# Generated at 2022-06-25 19:28:35.382343
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    def __init__():
        multipart_encoder_0 = None
        return ChunkedMultipartUploadStream(multipart_encoder_0)

    chunked_multipart_upload_stream_0 = __init__()

    assert isinstance(chunked_multipart_upload_stream_0.__iter__(), types.GeneratorType)


# Generated at 2022-06-25 19:28:45.033463
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    chunked_multipart_upload_stream_0 = ChunkedMultipartUploadStream(None)
    multipart_encoder_0 = MultipartEncoder(None, None)
    assert MultipartEncoder is not None

    chunked_multipart_upload_stream_0.encoder = multipart_encoder_0
    multipart_encoder_0.read = mock.Mock(side_effect=lambda buffer: "", return_value="")
    multipart_encoder_0.read=mock.Mock(return_value=None)
    chunked_multipart_upload_stream_0.chunk_size=100 * 1024
    multipart_encoder_0.read = mock.Mock(side_effect=lambda buffer: "", return_value="")
    chunked_multipart_

# Generated at 2022-06-25 19:28:49.403472
# Unit test for function compress_request
def test_compress_request():
    always = True
    request_0 = requests.PreparedRequest()
    request_0.headers = {}
    request_0.body = ''
    request_0.headers['Content-Encoding'] = 'deflate'
    request_0.headers['Content-Length'] = '2'
    compress_request(request_0, always)


# Generated at 2022-06-25 19:28:54.994635
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_read_callback: Callable[[bytes], bytes]
    body_read_callback = test_case_0
    body: Union[str, bytes, IO, MultipartEncoder, RequestDataDict]
    chunked = False
    content_length_header_value = None
    offline = False
    prepare_request_body(body, body_read_callback, content_length_header_value, chunked, offline)


# Generated at 2022-06-25 19:29:00.086338
# Unit test for function compress_request
def test_compress_request():
    request_0 = requests.PreparedRequest()
    compress_request(request_0, True)

    request_1 = requests.PreparedRequest()
    compress_request(request_1, False)



# Generated at 2022-06-25 19:29:08.893280
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    is_file_like = hasattr(body, 'read')
    if not is_file_like:
        if chunked:
            body = ChunkedUploadStream(
                # Pass the entire body as one chunk.
                stream=(chunk.encode() for chunk in [body]),
                callback=body_read_callback,
            )

# Generated at 2022-06-25 19:29:14.622425
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = None
    body_read_callback = None
    content_length_header_value = None
    chunked = None
    offline = None
    output = prepare_request_body(
        body, body_read_callback, content_length_header_value, chunked, offline)
    print(output)


# Generated at 2022-06-25 19:29:39.187384
# Unit test for function compress_request
def test_compress_request():
    # Call function with correct arguments.
    request = requests.PreparedRequest()
    request.headers['Content-Encoding'] = 'deflate'
    request.headers['Content-Length'] = '0'
    compress_request(request, True)
    # Check that headers were not changed.
    assert request.headers['Content-Encoding'] == 'deflate'
    assert request.headers['Content-Length'] == '0'

# Generated at 2022-06-25 19:29:41.034051
# Unit test for function compress_request
def test_compress_request():
    request_0 = None
    always_0 = False
    compress_request(request_0, always_0)

# Generated at 2022-06-25 19:29:49.264735
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # Simple test of passing through a body without any processing
    body = b'an example request body'
    length = len(body)
    callback = lambda x: length
    output = prepare_request_body(body, callback)
    assert(output == body)

    def test_data(body, length, callback=None):
        output = prepare_request_body(body, callback)
        if isinstance(body, str):
            # We expect the body to be encoded now
            assert(isinstance(output, bytes))
        elif hasattr(body, 'read'):
            # We expect the body to be wrapped in a ChunkedUploadStream
            assert(isinstance(output, ChunkedUploadStream))
            # Verify the correct size is passed to the callback
            output.callback(body)
            assert(length == len(body))
       

# Generated at 2022-06-25 19:29:54.594801
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    print("TEST: ChunkedUploadStream.__iter__\n")

    callback = lambda x: print("CALLBACK")
    stream = (1, 2, 3)
    chunked_upload_stream_0 = ChunkedUploadStream(stream, callback)

    print("-- __iter__ should call callback 3 times --")
    for i in chunked_upload_stream_0:
        print("NEXT ITERATION")


# Generated at 2022-06-25 19:29:58.276491
# Unit test for method __iter__ of class ChunkedMultipartUploadStream
def test_ChunkedMultipartUploadStream___iter__():
    multipart_encoder_0 = None

# Generated at 2022-06-25 19:30:01.646109
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body = None
    callback = None
    content_length_header_value = None
    chunked = False
    offline = False
    assert prepare_request_body(body, callback, content_length_header_value, chunked, offline) is None


# Generated at 2022-06-25 19:30:04.715820
# Unit test for function compress_request
def test_compress_request():
    if (test_compress_request.__doc__):
        print(test_compress_request.__doc__)
    request_0 = requests.PreparedRequest()
    result_0 = compress_request(request_0, True)
    assert result_0 is None


# Generated at 2022-06-25 19:30:12.056259
# Unit test for function prepare_request_body
def test_prepare_request_body():
    body_read_callback_0 = None
    body_0 = b'\x8a\x01\xcd\xb0"\x8b\xad\xfc\xbb\x84M\xe8\x05\xdd\x89\xfd'
    content_length_header_value_0 = None
    chunked_0 = False
    offline_0 = False
    result = prepare_request_body(
        body_read_callback=body_read_callback_0,
        body_0=body_0,
        content_length_header_value=content_length_header_value_0,
        chunked=chunked_0,
        offline=offline_0,
    )

# Generated at 2022-06-25 19:30:22.425238
# Unit test for method __iter__ of class ChunkedUploadStream
def test_ChunkedUploadStream___iter__():
    stream_0 = array.array('B')
    for _ in range(0, 0, 1):
        stream_0.append(random.randint(0, 255))
    chunked_upload_stream_0 = ChunkedUploadStream(stream_0, random.randint(0, 65535))
    stream_1 = array.array('B')
    for _ in range(0, 0, 1):
        stream_1.append(random.randint(0, 255))
    chunked_upload_stream_1 = ChunkedUploadStream(stream_1, random.randint(0, 65535))
    chunked_upload_stream_0.stream = chunked_upload_stream_1.stream
    chunked_upload_stream_0.callback = chunked_upload_stream_1.callback
    chunked_upload_stream

# Generated at 2022-06-25 19:30:33.493609
# Unit test for function prepare_request_body
def test_prepare_request_body():
    # simple test
    assert prepare_request_body(
        body='foo',
        body_read_callback=print,
        content_length_header_value=None,
        chunked=False,
        offline=False,
    ) == 'foo'

    assert prepare_request_body(
        body='foo',
        body_read_callback=print,
        content_length_header_value=None,
        chunked=True,
        offline=False,
    ) == 'foo'

    # test for chunked
    chunked_stream = prepare_request_body(
        body='foo',
        body_read_callback=print,
        content_length_header_value=None,
        chunked=True,
        offline=False,
    )