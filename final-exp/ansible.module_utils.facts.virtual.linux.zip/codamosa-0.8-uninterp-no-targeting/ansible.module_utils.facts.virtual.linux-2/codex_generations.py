

# Generated at 2022-06-20 20:34:02.650372
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None

# Generated at 2022-06-20 20:34:04.337052
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the constructor
    """
    module = AnsibleModule(argument_spec={})
    platform_obj = LinuxVirtual(module)
    assert platform_obj.module is not None

# Generated at 2022-06-20 20:34:08.699062
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector._platform == 'Linux'
    assert len(collector._fact_class._ignore_files) == 8
    assert collector._fact_class._ignore_files['/proc/bc'] == 'bc'
    assert collector._fact_class._ignore_files['/.dockerenv'] == 'docker'
    assert collector._fact_class._ignore_files['/.dockerinit'] == 'docker'
    assert collector._fact_class._ignore_files['/.lxc/'] == 'lxc'
    assert collector._fact_class._ignore_files['/.docker/'] == 'podman'
    assert collector._fact_class._ignore_files['/.virt-service-env.json'] == 'systemd-nspawn'

# Generated at 2022-06-20 20:34:14.681614
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    context = dict()

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        )
    )
    virtual_info = LinuxVirtual(module).populate()
    for key in ('virtualization_role', 'virtualization_type',
                'virtualization_tech_guest', 'virtualization_tech_host'):
        assert key in virtual_info

# Generated at 2022-06-20 20:34:19.049962
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    test_LinuxVirtual = LinuxVirtual(None)
    assert 'virtualization_tech_guest' in test_LinuxVirtual.get_virtual_facts()
    assert 'virtualization_tech_host' in test_LinuxVirtual.get_virtual_facts()
    assert 'virtualization_role' in test_LinuxVirtual.get_virtual_facts()
    assert 'virtualization_type' in test_LinuxVirtual.get_virtual_facts()

# Generated at 2022-06-20 20:34:21.574945
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class.__name__ == 'LinuxVirtual'
    assert lvc._fact_class._platform == 'Linux'
    assert lvc._fact_class.collect() == dict(virtualization_type='NA', virtualization_role='NA', virtualization_tech_guest=set(), virtualization_tech_host=set())

# Generated at 2022-06-20 20:34:29.976875
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts of class LinuxVirtual
    #
    # [] is a valid argument
    
    
    _svc_cmd_stop = MagicMock(return_value=(0, '', ''))
    _svc_cmd_start = MagicMock(return_value=(0, '', ''))
    _svc_cmd_restart = MagicMock(return_value=(0, '', ''))
    _svc_is_enabled = MagicMock(return_value=True)
    _svc_exists = MagicMock(return_value=True)
    _svc_is_running = MagicMock(return_value=True)
    _svc_get_runlevel = MagicMock(return_value='5')

# Generated at 2022-06-20 20:34:36.489919
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes

    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs.get('params', {})
            self.exit_json = kwargs.get('exit_json', None)
            self.run_command = lambda *args, **kwargs: (0, '', '')

        def fail_json(self, *args, **kwargs):
            raise Exception("Exception")

    def exit_json_side_effect(*args, **kwargs):
        raise Exception("exit_json called")

    module_args = {}

# Generated at 2022-06-20 20:34:47.525120
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    #
    # Create a mock module for this unit test
    #
    mock_module = AnsibleModule(
        argument_spec=dict()
    )

    mock_module.get_bin_path = MagicMock(return_value=None)

    #
    # Create the instance of the class being tested
    #
    lv = LinuxVirtual(mock_module)

    #
    #  Test the constructor and get_virtual_facts()
    #
    assert isinstance(lv, LinuxVirtual)
    lv.get_virtual_facts()
    assert lv.virtual_facts
    assert 'virtualization_role' in lv.virtual_facts
    assert 'virtualization_type' in lv.virtual_facts


# Generated at 2022-06-20 20:34:54.038009
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = lambda x: x
    with patch('ansible_collections.ansible.community.plugins.module_utils.facts.virtual.LinuxVirtual._get_subclasses', lambda x: []):
        ModuleFactsVirtualization = LinuxVirtual(module)
    module_facts_virtualization = ModuleFactsVirtualization.populate()
    assert module_facts_virtualization is not None
# end of unit test for constructor of class LinuxVirtual
