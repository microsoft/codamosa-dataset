

# Generated at 2022-06-20 20:33:38.712238
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_collector = LinuxVirtualCollector()
    assert virtual_collector._platform == 'Linux'
    assert isinstance(virtual_collector._fact_class, type(LinuxVirtual))


# Generated at 2022-06-20 20:33:43.972160
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test module for LinuxVirtual class
    """
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    ansible_virtual = linux_virtual.populate()
    assert ansible_virtual.get('virtualization_type') is not None


# Generated at 2022-06-20 20:33:55.292660
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Unit test for LinuxVirtual.get_virtual_facts
    """
    # Setup
    linux_virtual_instance = LinuxVirtual()
    # Command.run_command() is replaced by mocked method run_command in order to
    # be able to control its return values
    linux_virtual_instance.module.run_command = MagicMock(return_value=(0, '', ''))
    # Command.get_bin_path() is replaced by mocked method get_bin_path in order to
    # be able to control its return values
    linux_virtual_instance.module.get_bin_path = MagicMock(return_value='')
    # Function get_file_content() is replaced by mocked method get_file_content in order to
    # be able to control its return values
    # Function get_file_lines() is replaced by mocked method

# Generated at 2022-06-20 20:33:56.847287
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    lv.get_virtual_facts()


# Generated at 2022-06-20 20:33:59.575908
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    class TestModule:
        def get_bin_path(self, path):
            return path

    module = TestModule()

    virt = LinuxVirtual(module)
    assert virt is not None
    assert virt.module is not None


# Generated at 2022-06-20 20:34:01.421531
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    get_virtual_facts function unit test stub
    """
    obj = LinuxVirtual()
    print("VirtTech", obj.get_virtual_facts())


# Generated at 2022-06-20 20:34:02.629641
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    test_collector = LinuxVirtualCollector()
    assert test_collector is not None


# Generated at 2022-06-20 20:34:09.721589
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    unit test to get_virtual_facts
    """

# Generated at 2022-06-20 20:34:18.412040
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import json
    import os

    content_proc_1_cgroup = '''
    8:devices:/user.slice/user-1020.slice/session-1.scope
    7:hugetlb:/
    6:perf_event:/
    5:blkio:/user.slice/user-1020.slice/session-1.scope
    4:freezer:/
    3:memory:/user.slice/user-1020.slice/session-1.scope
    2:cpu,cpuacct:/user.slice/user-1020.slice/session-1.scope
    1:name=systemd:/user.slice/user-1020.slice/session-1.scope
    0::/user.slice/user-1020.slice/session-1.scope
    '''

    content_proc_self_cgroup

# Generated at 2022-06-20 20:34:27.273070
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    from ansible.module_utils.facts.virtual.common import Common

    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = 'test'
    mock_module.run_command.return_value = (0, 'fake', None)
    mock_module.get_file_lines.return_value = ['fake']
    mock_module.get_file_content.return_value = 'fake'
    fakes = LinuxVirtual(mock_module)
    result = fakes.get_virtual_facts()
    assert 'virtualization_tech_host' in result