

# Generated at 2022-06-20 20:33:24.801589
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})

    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()

    expected_keys = ['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']

    for key in expected_keys:
        assert key in virtual_facts, '%s not in virtual_facts' % key


# Generated at 2022-06-20 20:33:28.930969
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """ Test get_virtual_facts() function for class LinuxVirtual """
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    result = linux_virtual.get_virtual_facts()
    assert result
test_LinuxVirtual_get_virtual_facts()


# Generated at 2022-06-20 20:33:34.652623
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual = LinuxVirtual({})
    virtual_facts = virtual.get_virtual_facts()

    # Ensure that the methods return the correct data types
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)



# Generated at 2022-06-20 20:33:43.166839
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    result = dict(
        changed=False,
        virtual_facts=dict()
    )

    lv = LinuxVirtual(module)
    result['virtual_facts'] = lv.get_virtual_facts()

    module.exit_json(**result)
# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 20:33:49.499096
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)

    # Invoke get_virtual_facts method and store
    # results in the virtual_facts variable
    virtual_facts = lv.get_virtual_facts()

    keys = virtual_facts.keys()
    keys.sort()

    for k in keys:
        if not isinstance(virtual_facts[k], set):
            print('%s: %s' % (k, virtual_facts[k]))

    # TODO: Add more test cases

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-20 20:33:53.782176
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import sys, os
    test_class = LinuxVirtual(None)
    virtual_facts = test_class.get_virtual_facts()
    print('virtual_facts = ' + str(virtual_facts))
    sys.exit(0)

# Unit test code
if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:33:57.196408
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = VirtualCollectorModule()
    lvc = LinuxVirtualCollector(module)
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual


# Generated at 2022-06-20 20:34:00.679589
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    mod_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(mod_path)
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual


# Generated at 2022-06-20 20:34:02.520116
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Initialize a LinuxVirtual object and test constructor logic
    """
    # create a class object
    module = AnsibleModuleMock()
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None


# Generated at 2022-06-20 20:34:05.356855
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # unit tests for get_virtual_facts method
    linux_virtual = LinuxVirtual()
    assert linux_virtual.get_virtual_facts() == {'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([]), 'virtualization_type': 'NA', 'virtualization_role': 'NA'}