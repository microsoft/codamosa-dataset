

# Generated at 2022-06-20 20:33:35.785644
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector._fact_class, type(LinuxVirtual))

# Generated at 2022-06-20 20:33:46.684425
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # We need to mock module.run_command as we can't assume dmidecode is
    # installed and/or we have the right permissions to read it.

    module_mock = AnsibleModule(argument_spec={})
    module_mock.run_command = MagicMock(return_value=(1, "", ""))

    virtual = LinuxVirtual(module_mock)

    # Note: This will return always 'NA' for virtualization_type and
    # virtualization_role, as no file exists on the mocked filesystem.
    # We should test for 'NA' in the return value of get_virtual_facts.
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:33:54.804498
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    m = MagicMock()
    m.get_bin_path.return_value = 'dmi_bin'
    dummy_module = type('', (), {'run_command': lambda x: (0, None, None), 'get_bin_path': m.get_bin_path})
    c = LinuxVirtualCollector(dummy_module)
    assert isinstance(c, VirtualCollector)
    assert c._fact_class == LinuxVirtual
    assert c._platform == 'Linux'

# Collect function for class LinuxVirtualCollector

# Generated at 2022-06-20 20:33:59.788757
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test for constructor of class LinuxVirtual
    """
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )
    linux_virtual = LinuxVirtual(module)
    print('linux_virtual class: ')
    pprint(vars(linux_virtual))
    print('')
    print('linux_virtual facts: ')
    pprint(linux_virtual.get_virtual_facts())


# Generated at 2022-06-20 20:34:01.319114
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.collector import Collector

    vc = LinuxVirtualCollector()
    assert isinstance(vc, Collector)
    assert isinstance(vc.get_virtual_facts(), dict)

# Generated at 2022-06-20 20:34:02.800945
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    linux_virtual = LinuxVirtual(module)

    assert hasattr(linux_virtual, 'virtual_facts')


# Generated at 2022-06-20 20:34:05.463290
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    ''' linux_virtual.py:LinuxVirtual.__init__() '''
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    print("lv is %s" % repr(lv))


# Generated at 2022-06-20 20:34:06.837900
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    lib_virt = LinuxVirtual(module)
    assert lib_virt is not None


# Generated at 2022-06-20 20:34:08.324482
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert isinstance(lvc.fact_class(), LinuxVirtual)


# Generated at 2022-06-20 20:34:09.175721
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test class constructor"""
    assert LinuxVirtualCollector._platform == 'Linux'
