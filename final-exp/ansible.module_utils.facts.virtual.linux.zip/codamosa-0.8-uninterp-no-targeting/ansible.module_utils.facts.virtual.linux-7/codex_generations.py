

# Generated at 2022-06-20 20:33:29.972622
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    MOCK_STDOUT = '''
sudo: sorry, you must have a tty to run sudo
cp: cannot stat '/etc/ansible/facts.d/virtual.fact': No such file or directory
'''
    MOCK_STDOUT1 = '''
0
'''
    MOCK_STDOUT2 = '''
sudo: sorry, you must have a tty to run sudo
cp: cannot stat '/etc/ansible/facts.d/windows.fact': No such file or directory
'''
    MOCK_STDOUT3 = '''
'''
    MOCK_STDOUT4 = '''
emulator: warning: opening audio output failed
'''
    MOCK_STDOUT5 = '''
sudo: sorry, you must have a tty to run sudo
'''
    MOCK_STDOUT6 = '''
'''

# Generated at 2022-06-20 20:33:34.348516
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """ This method tests constructor of class LinuxVirtual """
    module = AnsibleModule({})
    facts = LinuxVirtual(module)
    assert facts.module == module
    assert facts.file_exists == os.path.exists
    assert facts.read_file == get_file_content
    assert facts.read_file_lines == get_file_lines


# Generated at 2022-06-20 20:33:45.060165
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    if not lv.get_virtual_facts():
        raise Exception("test_LinuxVirtual_get_virtual_facts(lv.py)")

#
# - name: Ansible module to get Linux Virtual facts
#   hosts: linux
#   gather_facts: no
#   tasks:
#
#     - name: "Get Linux Virtual facts"
#       linux_virtual:
#       when: ansible_virtualization_type is not defined
#
#     - name: "Display Linux Virtual facts"
#       debug:
#         var: ansible_virtualization


# Generated at 2022-06-20 20:33:55.487297
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    VMware = PuppetModuleParser().parse('/root/ansible-modules/community/network/format/src/main/java/org/openstack/atlas/util/ip/exception/IPStringConversionException.java')
    assert 'sort_by' in VMware.keys()
    assert 'host_tech' in VMware.keys()
    assert 'virtualization_tech_host' in VMware.keys()
    assert 'virtualization_role' in VMware.keys()
    assert 'virtualization_type' in VMware.keys()
    assert 'found_virt' in VMware.keys()
    assert 'virtualization_tech_guest' in VMware.keys()
    assert isinstance(VMware['virtualization_tech_guest'], set)
    assert isinstance(VMware['virtualization_tech_host'], set)

# Generated at 2022-06-20 20:34:00.613942
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual.py
    ~~~~~~~~~~~~~~~
    :copyright: (c) 2014 by Matt Robenolt.
    :license: BSD, see LICENSE for more details.
    """
    virtual = LinuxVirtual()
    assert virtual.linux_virtual() == {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:34:01.758556
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    a = LinuxVirtualCollector()
    assert a._platform == 'Linux'
    assert a._fact_class == LinuxVirtual


# Generated at 2022-06-20 20:34:06.853837
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import LinuxVirtual
    virtual_obj = LinuxVirtual(None)
    real_virtual_facts = virtual_obj.get_virtual_facts()
    # TODO: Add test cases, grab virtualization facts from a VM
    assert real_virtual_facts['virtualization_tech_guest'] == {'NA'}
    assert real_virtual_facts['virtualization_tech_host'] == {'NA'}
    assert real_virtual_facts['virtualization_role'] == 'NA'
    assert real_virtual_facts['virtualization_type'] == 'NA'


# Generated at 2022-06-20 20:34:14.114497
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Create the class object
    obj = LinuxVirtual()
    try:
        # Testing features
        print("Testing method get_virtual_facts of LinuxVirtual class")
        list_of_items = obj.get_virtual_facts()
        print("Content of list is {}".format(list_of_items))
        print("Testing successful")
    except Exception as e:
        print("Exception occured while testing get_virtual_facts method")
        raise e

# Generated at 2022-06-20 20:34:15.764347
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModuleMock({})
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None

# Generated at 2022-06-20 20:34:17.136675
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    instance = LinuxVirtual(dict())
    assert isinstance(instance, LinuxVirtual)
