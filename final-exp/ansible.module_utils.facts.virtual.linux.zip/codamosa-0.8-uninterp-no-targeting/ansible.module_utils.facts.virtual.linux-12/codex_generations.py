

# Generated at 2022-06-20 20:33:29.492226
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Create an isntance of class LinuxVirtual to test method get_virtual_facts
    module = AnsibleModuleMock()
    linuxv = LinuxVirtual(module)
    # Create a test fixture
    virtual_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set([])
    }
    # Define the return_value of mocked method get_bin_path
    module.get_bin_path.return_value = '/bin/dmidecode'
    module.run_command.return_value = (0, 'test_out', 'test_err')
    # Test method get_virtual_facts
    assert linuxv.get_virtual_facts() == virtual_

# Generated at 2022-06-20 20:33:31.535457
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock(argument_spec={})
    fact_collector = LinuxVirtualCollector(module=module)
    fact = fact_collector.collect()
    assert fact.virtualization_type != ''
    if fact.virtualization_role:
        assert fact.virtualization_role in ('guest', 'host')


# Generated at 2022-06-20 20:33:33.961378
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    l_virtual = LinuxVirtual(module)

    assert l_virtual.module is module

# Unit test function LinuxVirtual.get_virtual_facts()

# Generated at 2022-06-20 20:33:42.576811
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module_args = {}
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    result = dict(
        changed=False,
        original_message='',
        message=''
    )

    linux_virtual = LinuxVirtual(module)
    result['virtualization'] = linux_virtual.get_virtualization_facts()
    result['msg'] = "Success - virtualization facts"

    module.exit_json(**result)



# Generated at 2022-06-20 20:33:50.012585
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    lvm_version = get_file_content('/proc/lvm/global', default='2.02.90')

# Generated at 2022-06-20 20:33:58.726512
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class Mock(object):

        def __init__(self):
            self.data = {}

        def get_bin_path(self, arg):
            return self.data['get_bin_path']

        def run_command(self, arg):
            return self.data['run_command']

    module = Mock()

# Generated at 2022-06-20 20:34:00.769429
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module=module)

    lv_virtual_facts = lv.get_virtual_facts()
    assert isinstance(lv_virtual_facts, dict)
    assert lv_virtual_facts.get('virtualization_type') is not None


# Generated at 2022-06-20 20:34:07.046923
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # This instantiation of LinuxVirtual is used only for its method get_virtual_facts
    # Doesn't use the AnsibleModule argument
    l = LinuxVirtual(None)

    # Test case #1: Test detection of kvm host
    # Test data is the output of /usr/bin/dmesg command.
    # In this test output, we have the following line:
    # [    0.000000] Hypervisor detected: KVM

# Generated at 2022-06-20 20:34:10.475575
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual(None)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts == {
        "virtualization_type": "NA",
        "virtualization_role": "NA",
        "virtualization_tech_host": set(),
        "virtualization_tech_guest": set(),
    }


# Generated at 2022-06-20 20:34:11.963104
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    v = LinuxVirtual()
    assert v.virtual == 'LinuxVirtual'
