

# Generated at 2022-06-20 20:33:08.739052
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test for LinuxVirtualCollector()
    """
    p = LinuxVirtualCollector()
    assert p.fact_class == LinuxVirtual, "Invalid fact class is assigned"
    assert p.platform == 'Linux', "Invalid platform is assigned"


# Generated at 2022-06-20 20:33:10.428824
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = {'kernel': 'Linux', 'machine': 'x86_64', 'system': 'Linux'}
    v = LinuxVirtualCollector(module=None, facts=x)
    assert v.is_valid()
    assert v._platform == 'Linux'


# Generated at 2022-06-20 20:33:19.658072
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    if not HAS_PSUTIL:
        module.fail_json(msg='psutil is required for this module')
    if not HAS_PRETTYTABLE:
        module.fail_json(msg='prettytable is required for this module')
    linux_virtual = LinuxVirtual(module)
    virtual_facts_results = linux_virtual.get_virtual_facts()
    result = dict(
        changed=False,
        ansible_facts=dict(virtual=virtual_facts_results)
    )

    if module.check_mode:
        module.exit_json(**result)

    module.exit_json(**result)



# Generated at 2022-06-20 20:33:21.095044
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  m=LinuxVirtual()
  assert type(m.get_virtual_facts()) is dict

# Generated at 2022-06-20 20:33:28.848828
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, command_path, *args, **kwargs):
            if args[0][0] == 'test':
                return 0, 'test', ''
            elif args[0][-1] == 'test':
                return 0, '', 'test'
            else:
                return 0, '', ''

        def get_bin_path(self, *args, **kwargs):
            return 'test'

    module = MockModule({})
    test_obj = LinuxVirtual(module)
    module.run_command = MagicMock(return_value=[0, '', ''])
    module.get_bin_path = MagicMock(return_value='test')

# Generated at 2022-06-20 20:33:30.092954
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    instance = LinuxVirtualCollector()
    assert instance.__class__.__name__ == 'LinuxVirtualCollector'
    assert instance.platform == 'Linux'


# Generated at 2022-06-20 20:33:31.600893
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual = LinuxVirtual(None)
    assert virtual.virtual['virtualization_type'] == 'NA'

# Generated at 2022-06-20 20:33:32.768676
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert LinuxVirtual().get_virtual_facts(LinuxVirtual(), 'module')


# Generated at 2022-06-20 20:33:34.414195
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    linux_virtual_collector = LinuxVirtualCollector(module)

    assert linux_virtual_collector.platform == 'Linux'
    assert linux_virtual_collector.fact_class == LinuxVirtualCollector._fact_class


# Generated at 2022-06-20 20:33:36.746808
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    fact_collector = LinuxVirtualCollector(module)
    fact_collector.collect()
    linux_virtual_fact = fact_collector.get_facts()
    keys = linux_virtual_fact.keys()
    assert_good_keys(keys)
    assert_good_values(linux_virtual_fact)