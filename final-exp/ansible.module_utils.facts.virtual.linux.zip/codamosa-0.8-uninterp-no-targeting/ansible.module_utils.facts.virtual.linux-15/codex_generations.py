

# Generated at 2022-06-20 20:34:16.131414
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Tests that LinuxVirtualCollector can be initialized"""
    collect = LinuxVirtualCollector(None)
    assert collect.platform == 'Linux'
    assert collect.fact_class == LinuxVirtual
    assert collect.guest_tech == set()
    assert collect.host_tech == set()


# Generated at 2022-06-20 20:34:17.997488
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    my_facts = lv.get_virtual_facts()
    if my_facts:
        for k,v in my_facts.items():
            print("%s : %s" % (k,v))


# Generated at 2022-06-20 20:34:21.949352
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():

    # This test assumes that the module is installed and run on Linux,
    # which is the only platform for which class LinuxVirtual is constructed.
    # There are no tests for cases when module runs on other platform.
    assert isinstance(LinuxVirtual(), LinuxVirtual)



# Generated at 2022-06-20 20:34:22.606232
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()


# Generated at 2022-06-20 20:34:24.634872
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # test empty and with_module
    LinuxVirtualCollector()
    LinuxVirtualCollector(with_module=True)


# Generated at 2022-06-20 20:34:31.322599
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    testargs = {"/usr/bin/python2.7": "python", "/usr/local/bin/ansible-connection": "ansible-connection"}
    with mock.patch.dict(sys.modules[__name__].__dict__, testargs):
        from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
        from ansible.module_utils.facts.virtual.base import BaseVirtual
        conn = LinuxVirtual()
        my_dict = {}
        my_dict = conn.get_virtual_facts()
        assert my_dict['virtualization_role'] in (None, 'guest', 'host', 'container', 'NA')

# Generated at 2022-06-20 20:34:35.816906
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Test to make sure the class is working'''

    # setup module
    module = AnsibleModule(argument_spec={})
    module_params = {}
    module.params = module_params

    # instantiate the class
    obj = LinuxVirtual(module)

    # test return vars
    ret = {'virtualization_type': 'virtualbox', 'virtualization_role': 'guest'}
    assert ret == obj.get_virtual_facts()


# Generated at 2022-06-20 20:34:46.803494
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    fake_module = FakeAnsibleModule()
    dist = LinuxDistribution(fake_module, platform.dist())
    dist.details = LinuxDistributionDetails(fake_module)

    test_module = LinuxVirtual(fake_module, dict(), dist)

    assert(isinstance(test_module, BaseVirtual))

    # test get_facts()
    result = test_module.get_facts()
    assert('virtual' in result)
    assert('virtualization_type' in result['virtual'])
    assert('virtualization_role' in result['virtual'])
    assert('virtualization_system' in result['virtual'])
    assert('virtualization_tech_guest' in result['virtual'])
    assert('virtualization_tech_host' in result['virtual'])

    # test get_facts()
    result = test_module.get

# Generated at 2022-06-20 20:34:50.897481
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    main_obj = object()
    module_obj = object()
    main_obj.params = None
    module_obj.params = None
    module_obj.main = main_obj
    virtual_obj = LinuxVirtualCollector(module_obj)
    assert virtual_obj is not None


# Generated at 2022-06-20 20:34:53.144660
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual_obj = LinuxVirtual()
    assert linux_virtual_obj.__class__.__name__ == 'LinuxVirtual'
