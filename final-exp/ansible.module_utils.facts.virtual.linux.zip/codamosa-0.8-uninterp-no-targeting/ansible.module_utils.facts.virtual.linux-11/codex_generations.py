

# Generated at 2022-06-20 20:32:55.496152
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Test for the default constructor
    x = LinuxVirtual()
    assert x.__class__.__name__ == 'LinuxVirtual'
    # Test for the constructor with the argument {platform: 'Linux'}
    y = LinuxVirtual({'platform': 'Linux'})
    assert y.platform == 'Linux'



# Generated at 2022-06-20 20:32:59.251774
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual.__class__.__name__ == "LinuxVirtual"

# Generated at 2022-06-20 20:33:03.670400
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module_mock = Mock(name='module')
    module_mock.params = {'gather_subset': ['!all'],
                          'filter': 'virtual',
                          'gather_timeout': 10}
    collecter_mock = Mock(name='collector')
    collecter_mock.module = module_mock
    collecter_mock.name = 'virtual'
    collecter_mock.options = ''
    collecter_mock.subset = ['all']
    facts_mock = Mock(name='facts')
    virtual_collector = LinuxVirtualCollector(collecter_mock)
    assert virtual_collector.platform == 'Linux'
    assert virtual_collector.name == 'virtual'
    assert virtual_collector.options == ''
    assert virtual_collector.subset

# Generated at 2022-06-20 20:33:04.703916
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.__class__.__name__ == 'LinuxVirtualCollector'


# Generated at 2022-06-20 20:33:15.174035
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock, Mock

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}

        # AnsibleModule Mock and helper function
        def exit_json(self, **kwargs):
            return True

        def fail_json(self, **kwargs):
            return False

    class AnsibleModuleUtils(object):
        @staticmethod
        def run_command(command):
            return [0, "", ""]

        @staticmethod
        def get_file_content(file):
            return ""

        @staticmethod
        def get_file_lines(file):
            return

# Generated at 2022-06-20 20:33:16.981039
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    linux_virtual_obj = LinuxVirtual(module)

    assert linux_virtual_obj is not None

# Generated at 2022-06-20 20:33:19.838905
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    ''' linux_virtual constructor.

    isinstance() should return True for an object of LinuxVirtual class.
    '''
    linux_virtual_obj = LinuxVirtual()
    assert isinstance(linux_virtual_obj, LinuxVirtual) == True


# Generated at 2022-06-20 20:33:21.645981
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector is not None

    # It should not be possible to instantiate VirtualCollector
    # Since it is an abstract class
    with pytest.raises(TypeError):
        abstract_virtual_collector = VirtualCollector()

# Generated at 2022-06-20 20:33:22.333528
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    VirtualCollector(module)



# Generated at 2022-06-20 20:33:24.011096
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert lv

