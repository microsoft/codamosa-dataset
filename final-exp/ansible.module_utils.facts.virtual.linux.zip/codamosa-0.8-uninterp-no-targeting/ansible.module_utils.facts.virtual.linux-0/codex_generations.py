

# Generated at 2022-06-20 20:33:48.323988
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Create an instance of class LinuxVirtual
    virtual_object = LinuxVirtual()
    # Extend module mock class attributes with required ones for this method
    virtual_object.module.get_bin_path = MagicMock(return_value=None)

    # Check the returned value of method get_virtual_facts
    assert virtual_object.get_virtual_facts() == {}

# Generated at 2022-06-20 20:33:50.111694
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    assert(len(lv.get_virtual_facts()) > 0)


# Generated at 2022-06-20 20:33:53.205072
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    LinuxVirtualTest = LinuxVirtual(module=None)
    virtual_facts = LinuxVirtualTest.get_virtual_facts()
    print(virtual_facts)

# Generated at 2022-06-20 20:33:59.193738
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    lv_data = lv.collect()
    assert type(lv_data) == dict, "LinuxVirtual returned incorrect type"
    for key in lv_data.keys():
        # All keys should be strings
        assert type(key) == str, "LinuxVirtual returned non-string key"
        # All values should be either strings or sets
        if type(lv_data[key]) is not str:
            assert type(lv_data[key]) is set, "LinuxVirtual returned non-string value for %s" % key


# Generated at 2022-06-20 20:34:01.060615
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test for LinuxVirtualCollector.__init__()"""
    try:
        LinuxVirtualCollector(dict())
    except Exception as exc:
        assert False, 'Failed to create class: %s' % exc


"""Unit test for LinuxVirtualCollector.collect()"""

# Generated at 2022-06-20 20:34:04.149810
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """test_LinuxVirtual_get_virtual_facts.py: Test get_virtual_facts() method of LinuxVirtual"""
    module = AnsibleModuleMock()
    lsv = LinuxVirtual(module)
    result = lsv.get_virtual_facts()
    assert isinstance(result, dict)

# Generated at 2022-06-20 20:34:06.931441
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Create an instance of LinuxVirtualCollector
    avc = LinuxVirtualCollector()
    # Assert the value of _fact_class
    assert avc._fact_class == LinuxVirtual
    # Assert the value of _platform
    assert avc._platform == "Linux"

# Unit test function for get_virtual_facts()

# Generated at 2022-06-20 20:34:08.231118
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector(None)
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-20 20:34:09.598667
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():  # pylint: disable=W0621
    linux_virtual_collector = LinuxVirtualCollector(None)
    assert linux_virtual_collector._platform == 'Linux'

# Generated at 2022-06-20 20:34:15.121747
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
    )

    linux_virtual = LinuxVirtual(module)

    # This is a basic test to ensure the method exists
    # This method is relatively difficult to unit test
    virtual_facts = linux_virtual.get_virtual_facts()

    module.exit_json(changed=False, ansible_facts=dict(virtual=virtual_facts))
