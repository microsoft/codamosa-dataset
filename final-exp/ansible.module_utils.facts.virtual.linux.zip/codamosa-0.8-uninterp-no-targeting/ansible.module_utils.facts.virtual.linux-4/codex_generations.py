

# Generated at 2022-06-20 20:34:02.542684
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Test LinuxVirtual.get_virtual_facts"""

    hypervisor_id = "hypervisor_id"
    hypervisor_uuid = "hypervisor_uuid"
    hypervisor_name = "hypervisor_name"
    hypervisor_version = "hypervisor_version"
    hypervisor_hostname = "hypervisor_hostname"
    hypervisor_type = "hypervisor_type"
    hypervisor_vcpus = "hypervisor_vcpus"
    hypervisor_memory_mib = "hypervisor_memory_mib"
    hypervisor_max_vcpus = "hypervisor_max_vcpus"
    hypervisor_max_memory_mib = "hypervisor_max_memory_mib"


# Generated at 2022-06-20 20:34:08.422877
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Constructor test for class LinuxVirtual
    '''

    # Define test inputs and expected results

# Generated at 2022-06-20 20:34:10.148212
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert linux_virtual.is_linux_virtual() == True



# Generated at 2022-06-20 20:34:12.345837
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    virtual = LinuxVirtual(module)
    assert virtual.module


# Generated at 2022-06-20 20:34:17.039244
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Testing the virtual facts via method get_virtual_facts of class LinuxVirtual
    """
    l = LinuxVirtual()
    assert l.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'docker', 'virtualization_tech_guest': {'container', 'docker'}, 'virtualization_tech_host': {'docker'}}

# Generated at 2022-06-20 20:34:20.420414
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    print("Testing method get_virtual_facts of class LinuxVirtual")
    _LinuxVirtual_get_virtual_facts()



# Generated at 2022-06-20 20:34:23.202669
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils.facts.virtual import LinuxVirtual
    v = LinuxVirtual()
    assert v is not None


# Generated at 2022-06-20 20:34:25.061554
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    obj = LinuxVirtual()
    assert obj.get_virtual_facts() is None

# Generated at 2022-06-20 20:34:29.420877
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    '''Unit test for constructor of class LinuxVirtualCollector'''
    module = MagicMock()
    collector = LinuxVirtualCollector(module=module)
    assert isinstance(collector, LinuxVirtual)
    assert collector.platform == 'Linux'

# Generated at 2022-06-20 20:34:34.079003
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxVirtualCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual
    assert collector.fact_class.platform == 'Linux'
