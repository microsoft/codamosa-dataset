

# Generated at 2022-06-20 20:33:57.836255
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    mod = MockAnsibleModule()
    facts = LinuxVirtual(mod).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_system' in facts

# Generated at 2022-06-20 20:34:04.663966
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Create an instance of LinuxVirtual class
    lv = LinuxVirtual()

    # Run a command and store result in a LinuxVirtual.CmdResult object
    pretend_command_result = lv.CmdResult(stdout='test', stderr='test2', rc=1)

    # Test the override of run_command method
    assert pretend_command_result == lv.run_command('test')  # pylint: disable=E1101

    # Test the CmdResult class
    assert pretend_command_result.stdout == 'test'
    assert pretend_command_result.stderr == 'test2'

    # Test the get_file_content method
    assert lv.get_file_content('/tmp/test') == ''

    # Test the get_file_lines method

# Generated at 2022-06-20 20:34:07.309736
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    vf = LinuxVirtual()
    keys = vf.get_virtual_facts().keys()
    assert len(keys) == 4
    assert 'virtualization_role' in keys
    assert 'virtualization_type' in keys
    assert 'virtualization_tech_host' in keys
    assert 'virtualization_tech_guest' in keys


# Generated at 2022-06-20 20:34:08.075634
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector
    assert collector is not None


# Generated at 2022-06-20 20:34:17.389960
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    linux_virtual_obj = LinuxVirtual()

    file_data = [
        "4",
        "4",
    ]
    with patch.object(builtins, 'open') as mock_open:
        mock_open.side_effect = (
            mock_open.return_value.__enter__.return_value,
            mock_open.return_value.__enter__.return_value,
        )
        mock_open.return_value.__enter__.return_value.read.side_effect = file_data
        virtual_facts = linux_virtual_obj.get_virtual_facts()
        assert virtual_facts['virtualization_type'] == 'openvz'
        assert virtual_facts['virtualization_role'] == 'host'
        assert virtual_facts['virtualization_tech_host'] == {'openvz'}

# Generated at 2022-06-20 20:34:27.937487
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class LinuxVirtual"""
    # First mock the module

# Generated at 2022-06-20 20:34:30.521957
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test for `LinuxVirtualCollector` constructor
    """
    LinuxVirtualCollector()

# Generated at 2022-06-20 20:34:31.958733
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule({})
    vm = LinuxVirtual(module)
    result = vm.get_virtual_facts()
    assert result is not None

# Generated at 2022-06-20 20:34:36.879115
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    facts_real = lv.get_virtual_facts()
    assert isinstance(facts_real['virtualization_tech_host'], FrozenSet)
    assert isinstance(facts_real['virtualization_tech_guest'], FrozenSet)
    assert isinstance(facts_real['virtualization_tech_host'], FrozenSet)
    assert isinstance(facts_real['virtualization_tech_guest'], FrozenSet)

# Generated at 2022-06-20 20:34:48.816116
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    
    params = dict(
        os_facts={
            'distribution': 'Debian',
            'name': 'Debian GNU/Linux'
        },
        path_info={
            'awk': '/usr/bin/awk',
            'chroot': '/usr/sbin/chroot',
            'dmidecode': '/usr/sbin/dmidecode',
            'grep': '/bin/grep',
            'lscpu': '/usr/bin/lscpu'
        }
    )

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lv = LinuxVirtual(module)

    # get_file_lines_tmp
    custom_file_lines = """
    test line 1
    test line 2
    """
    tmp_file = Named