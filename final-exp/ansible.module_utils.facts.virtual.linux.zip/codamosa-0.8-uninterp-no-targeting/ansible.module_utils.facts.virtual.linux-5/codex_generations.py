

# Generated at 2022-06-20 20:33:05.670144
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Unit test for constructor of class LinuxVirtual"""

    # Need to mock the linux_distribution function in order to get consistent
    # values on different operating systems.
    def linux_distribution_mock():
        """
        Mock function to return the current operating system.
        """
        return ('Red Hat Enterprise Linux Server', '6.4', 'Santiago')
    real_linux_distro = platform._distro_func
    platform._distro_func = linux_distribution_mock

    # Test the constructor
    try:
        LinuxVirtual()
    # pylint: disable=W0702
    except Exception as exception:
        raise AssertionError("Cannot instantiate LinuxVirtual class: %s" % exception)
    finally:
        platform._distro_func = real_linux_distro


# Generated at 2022-06-20 20:33:08.634937
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})

    lv = LinuxVirtual(module)
    lv.get_virtual_facts()

    module.exit_json(changed=False)


# Generated at 2022-06-20 20:33:14.283108
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)


# Generated at 2022-06-20 20:33:15.788871
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    collector = LinuxVirtualCollector(module)
    assert collector.get_facts() == {'virtualization_type': 'NA', 'virtualization_role': 'NA'}

# Generated at 2022-06-20 20:33:18.713448
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec=dict())
    result = dict()
    if module.check_mode:
        module.exit_json(changed=False)
    linux_virtual = LinuxVirtualCollector(module).collect()
    if linux_virtual is not None:
        result['virtual'] = linux_virtual
        module.exit_json(ansible_facts=result)
    else:
        module.fail_json(msg="Could not gather virtual facts")


if __name__ == '__main__':
    test_LinuxVirtualCollector()

# Generated at 2022-06-20 20:33:26.877387
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    m_module = AnsibleModule(argument_spec={})
    m_module.run_command = MagicMock(return_value=(0, '', ''))
    m_module.get_bin_path = Mock(return_value='')
    m_module.get_tmp_path = Mock(return_value='')

    m_LinuxVirtual = LinuxVirtual(m_module)

    m_LinuxVirtual.get_file_content = Mock(return_value='')

    m_LinuxVirtual.is_linux_system = Mock(return_value=True)
    m_LinuxVirtual.is_linux_system.return_value = True
    m_LinuxVirtual.get_file_lines = Mock(return_value="")


# Generated at 2022-06-20 20:33:36.419542
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # create an object of the LinuxVirtual class to test
    module_args = dict()
    # a module_arg is needed, otherwise the exception SystemExit occurs
    module_args['socket_timeout'] = 1
    module_args['runas_user'] = 'root'
    module_args['runas_user'] = 'root'
    # create a fake AnsibleModule object
    mock_module = AnsibleModule(argument_spec=module_args)
    mock_module.get_bin_path = MagicMock(return_value='/bin/echo')
    mock_module.run_command = MagicMock(return_value=(0, '', ''))
    mock_module.__getitem__ = MagicMock(return_value=0)
    mock_module.params['runas_user'] = 'root'

# Generated at 2022-06-20 20:33:43.970854
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    linux_virtual.collect_facts()
    results = linux_virtual.get_virtual_facts()

    assert type(results) is dict
    assert set(results) == set(['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host'])

# Unit test suite for class LinuxDistribution

# Generated at 2022-06-20 20:33:47.998515
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector.platform == 'Linux'
    assert LinuxVirtualCollector.fact_class == LinuxVirtual


# Generated at 2022-06-20 20:33:54.804293
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    result = LinuxVirtual({}).get_virtual_facts()
    assert result['virtualization_role'] == 'host'
    assert result['virtualization_type'] == 'lxc'
    assert len(result['virtualization_tech_host'].intersection(result['virtualization_tech_guest'])) == 0
    assert len(result['virtualization_tech_host'].union(result['virtualization_tech_guest'])) == 2

