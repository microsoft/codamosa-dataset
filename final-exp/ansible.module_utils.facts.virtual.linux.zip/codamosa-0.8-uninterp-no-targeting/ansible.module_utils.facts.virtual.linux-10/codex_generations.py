

# Generated at 2022-06-20 20:33:04.878441
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_tech_host'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm', 'container'])

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lv = LinuxVirtual(module)
    lv.os_release['product_name'] = 'RHEL'

# Generated at 2022-06-20 20:33:05.732971
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    arg = LinuxVirtualCollector()
    assert arg._platform == 'Linux'


# Generated at 2022-06-20 20:33:07.902526
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Test the constructor of class LinuxVirtual"""
    module = AnsibleModuleMock()
    virtual = LinuxVirtual(module)
    assert virtual

# Generated at 2022-06-20 20:33:08.981138
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert type(c._fact_class) == LinuxVirtual
    assert c._platform == 'Linux'


# Generated at 2022-06-20 20:33:13.429791
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    my_module = FakeModule()
    result = LinuxVirtual(module=my_module)
    assert 'LinuxVirtual' == result.__class__.__name__
    assert isinstance(result.platform_subclass, LinuxVirtual)


# Generated at 2022-06-20 20:33:15.498549
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule({})
    lxv = LinuxVirtualCollector(module)
    assert isinstance(lxv, VirtualCollector)
    assert lxv.module == module
    assert lxv.facts == {}

# Generated at 2022-06-20 20:33:25.093765
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import unittest
    import os
    import shutil
    import tempfile
    import platform

    class MockModule(object):
        _result = {'rc': 0, 'stdout': '', 'stderr': ''}
        _cache = {}

        def get_bin_path(self, path, opt_dirs=[], required=False):
            if path in MockModule._cache:
                return MockModule._cache[path]

            for dir in ['/bin', '/sbin', '/usr/bin', '/usr/sbin']:
                p = os.path.join(dir, path)
                if os.path.exists(p):
                    MockModule._cache[path] = p
                    return p

            return None

        def run_command(self, args):
            return MockModule._result


# Generated at 2022-06-20 20:33:26.617817
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test constructor of class LinuxVirtualCollector
    """
    module = AnsibleModuleMock()
    fact_collector = LinuxVirtualCollector(module)
    assert isinstance(fact_collector._fact_class, LinuxVirtual)

# Generated at 2022-06-20 20:33:31.264268
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test to see if the LinuxVirtual constructor works
    """
    (is_change, virtual_facts) = LinuxVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ('kvm', 'virtualbox', 'NA')
    assert virtual_facts['virtualization_role'] in ('guest', 'host', 'NA')
    # FIXME: we should check for virtualization_role


# Generated at 2022-06-20 20:33:34.445973
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """linux_virtual - constructor test
    """
    module = AnsibleModule(argument_spec=dict())
    is_linuxvirtual_instance = isinstance(LinuxVirtual(module), LinuxVirtual)
    assert is_linuxvirtual_instance is True
