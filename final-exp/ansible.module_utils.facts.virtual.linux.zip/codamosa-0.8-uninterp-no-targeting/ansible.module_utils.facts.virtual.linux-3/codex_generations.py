

# Generated at 2022-06-20 20:33:29.544129
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    facts = lv.get_virtual_facts()

    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] in ('host', 'guest', 'NA')
    assert 'virtualization_type' in facts

# Generated at 2022-06-20 20:33:40.438015
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    def vt_fact_refine(vt_fact):
        if vt_fact:
            if 'virtualization_role' in vt_fact:
                if vt_fact['virtualization_role'] is None:
                    vt_fact['virtualization_role'] = 'NA'
            if 'virtualization_type' in vt_fact:
                if vt_fact['virtualization_type'] is None:
                    vt_fact['virtualization_type'] = 'NA'
        return vt_fact

    virtual_facts = LinuxVirtual().populate()
    virtual_facts = vt_fact_refine(virtual_facts)

    assert not virtual_facts.get('virtualization_role')
    assert not virtual_facts.get('virtualization_type')

# Generated at 2022-06-20 20:33:42.921483
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lvirtual = LinuxVirtual()
    assert hasattr(lvirtual, 'virtual_subsystems')


# Generated at 2022-06-20 20:33:48.874007
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module_args = {}
    module = basic.AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
        add_file_common_args=True,
    )

    if not HAS_LIBVIRT:
        module.fail_json(msg='python libvirt library not found')

    libvirt_obj = LinuxVirtual(module)

    module.exit_json(changed=False, virtual=libvirt_obj.gather_virtual_facts())



# Generated at 2022-06-20 20:33:50.519300
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert c.platform == 'Linux'
    assert c.fact_class == LinuxVirtual

# Generated at 2022-06-20 20:33:59.194685
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import LinuxVirtual
    from ansible.module_utils.facts.virtual import get_file_content
    from ansible.module_utils.facts.virtual import get_file_lines
    from ansible.module_utils.facts.virtual import Virtual, VirtualFactCollector
    from ansible.module_utils.facts.virtual import is_docker_container

    module = MagicMock(name='module')

    collector = VirtualFactCollector(module, Virtual)
    facts_class = LinuxVirtual()

    vfacts = {}


# Generated at 2022-06-20 20:34:00.542077
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert c is not None
    assert c._fact_class.__name__ == "LinuxVirtual"
    assert c._platform == "Linux"

# Generated at 2022-06-20 20:34:01.549837
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x._platform == 'Linux'

# Generated at 2022-06-20 20:34:07.583108
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    class MockModule(object):
        def run_command(self, cmd):
            if cmd == 'systemd-detect-virt':
                return (0, 'none', '')
            else:
                return (0, 'Some contents', '')

        def get_bin_path(self, cmd):
            if cmd == 'lscpu':
                return '/usr/bin/lscpu'
            else:
                return None

    class MockOs(object):
        def path(self):
            return os

        def access(self, path, mode):
            return True

        def isdir(self, path):
            if path == '/rhev/':
                return False
            else:
                return True
        def exists(self, path):
            if path == '/.dockerenv':
                return True

# Generated at 2022-06-20 20:34:17.359830
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    from ansible.module_utils.facts.virtual.collector import VirtualCollector
    class DummyModule:
        def get_bin_path(self, x, opts=None):
            return "dummy_bin_path"
        def run_command(self, x):
            return 0, "", ""
    class DummyCollector(VirtualCollector):
        def __init__(self, module):
            self.linux_virtual = LinuxVirtual(module)
    dummy_module = DummyModule()
    dummy_collector = DummyCollector(dummy_module)
    print(dummy_collector.get_virtual_facts())
    assert "virtualization_type" in dummy_collector.get_virtual_facts()

#-------------------------------------------------------------------------------