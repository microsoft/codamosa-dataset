

# Generated at 2022-06-17 03:13:39.565403
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:13:43.111441
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    lvc = LinuxVirtualCollector(module)
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual


# Generated at 2022-06-17 03:13:46.940916
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxVirtualCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual


# Generated at 2022-06-17 03:13:52.816289
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Initialize the class
    linux_virtual = LinuxVirtual()
    # Initialize the return values
    virtual_facts = {}
    # Initialize the parameters
    # Call the method
    virtual_facts = linux_virtual.get_virtual_facts()
    # Assert the return value
    assert virtual_facts == {'virtualization_type': 'NA', 'virtualization_role': 'NA', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-17 03:13:56.094737
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test the constructor of class LinuxVirtualCollector
    """
    module = AnsibleModuleMock()
    lvc = LinuxVirtualCollector(module)
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-17 03:14:01.997316
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:14:12.592001
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a LinuxVirtual object
    lv = LinuxVirtual(module)

    # Create a virtual_facts dict
    virtual_facts = dict()

    # Call method get_virtual_facts
    virtual_facts = lv.get_virtual_facts()

    # Check if virtual_facts is a dict
    assert isinstance(virtual_facts, dict)

    # Check if virtual_facts has the right keys
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-17 03:14:19.498062
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-17 03:14:27.474831
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:14:28.813101
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual
