

# Generated at 2022-06-17 03:13:26.899538
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:13:29.655566
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxVirtualCollector(module=module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual


# Generated at 2022-06-17 03:13:41.660036
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create a dummy file system
    tmpdir = tempfile.mkdtemp()
    os.mkdir(tmpdir + '/sys')
    os.mkdir(tmpdir + '/sys/devices')
    os.mkdir(tmpdir + '/sys/devices/virtual')
    os.mkdir(tmpdir + '/sys/devices/virtual/dmi')
    os.mkdir(tmpdir + '/sys/devices/virtual/dmi/id')
    os.mkdir(tmpdir + '/proc')
    os.mkdir(tmpdir + '/proc/1')
    os.mkdir(tmpdir + '/proc/1/cgroup')
    os.mkdir(tmpdir + '/proc/vz')
    os

# Generated at 2022-06-17 03:13:48.996526
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:13:51.647057
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)
    result = lv.get_virtual_facts()
    assert result['virtualization_type'] == 'NA'
    assert result['virtualization_role'] == 'NA'
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:13:56.049863
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    lvc = LinuxVirtualCollector(module)
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-17 03:13:58.734799
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual


# Generated at 2022-06-17 03:14:05.757171
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:14:12.338283
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:14:15.824237
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxVirtualCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual
