

# Generated at 2022-06-17 03:13:38.777810
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test the constructor of class LinuxVirtualCollector
    """
    module = AnsibleModuleMock()
    virtual_collector = LinuxVirtualCollector(module)
    assert virtual_collector._fact_class == LinuxVirtual
    assert virtual_collector._platform == 'Linux'


# Generated at 2022-06-17 03:13:42.249053
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxVirtualCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual


# Generated at 2022-06-17 03:13:52.587941
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test with a mocked module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=None)
    module.get_file_content = MagicMock(return_value=None)
    module.get_file_lines = MagicMock(return_value=[])
    module.get_mount_size = MagicMock(return_value=None)
    module.get_mount_size_bytes = MagicMock(return_value=None)
    module.get_mount_options = MagicMock(return_value=None)
    module.get_mount_points = MagicMock(return_value=[])

# Generated at 2022-06-17 03:14:03.884985
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    lv = LinuxVirtual(module)
    # Test for a system that is not virtualized
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test for a system that is virtualized
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='/bin/dmidecode')

# Generated at 2022-06-17 03:14:10.681948
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:14:21.830900
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test with a mocked module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    # Test with a mocked module
    lv = LinuxVirtual(module)
    # Test with a mocked module
    lv.module = module
    # Test with a mocked module
    lv.module.run_command = MagicMock(return_value=(0, '', ''))
    # Test with a mocked module
    lv.module.get_bin_path = MagicMock(return_value=None)
    # Test with a mocked module
    lv.get_file_lines = MagicMock(return_value=[])
    # Test with a mocked module
    lv.get_file_content = MagicMock(return_value='')
    # Test with a mocked module


# Generated at 2022-06-17 03:14:25.054609
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxVirtualCollector(module=module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual


# Generated at 2022-06-17 03:14:28.906203
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)
    facts = lv.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert isinstance(facts['virtualization_tech_host'], set)


# Generated at 2022-06-17 03:14:30.306697
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-17 03:14:32.982045
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxVirtualCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual
