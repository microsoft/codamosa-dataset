

# Generated at 2022-06-17 03:13:46.526183
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:13:53.119406
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set(['kvm'])


# Generated at 2022-06-17 03:14:04.192443
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Unit test for constructor of class LinuxVirtualCollector
    """
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.get_file_content = get_file_content_mock
    module.get_file_lines = get_file_lines_mock
    module.exit_json = exit_json_mock
    module.fail_json = fail_json_mock
    module.params = {}
    module.params['gather_subset'] = ['!all']
    module.params['filter'] = '*'
    module.params['gather_timeout'] = 10
    module.params['gather_network_resources'] = False

# Generated at 2022-06-17 03:14:09.194275
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test the constructor of class LinuxVirtualCollector
    """
    module = AnsibleModule(argument_spec={})
    assert LinuxVirtualCollector(module)._platform == 'Linux'


# Generated at 2022-06-17 03:14:16.210223
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:14:19.858868
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    virtual_collector = LinuxVirtualCollector(module)
    assert virtual_collector.platform == 'Linux'
    assert virtual_collector.fact_class == LinuxVirtual


# Generated at 2022-06-17 03:14:23.399228
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    virtual = LinuxVirtualCollector(module)
    assert virtual.platform == 'Linux'
    assert virtual.fact_class == LinuxVirtual


# Generated at 2022-06-17 03:14:27.224406
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxVirtualCollector(module=module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual


# Generated at 2022-06-17 03:14:32.350531
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:14:40.132340
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    lv = LinuxVirtual(module)
    facts = lv.get_virtual_facts()
    assert facts['virtualization_type'] == 'NA'
    assert facts['virtualization_role'] == 'NA'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()
