

# Generated at 2022-06-11 05:51:54.393767
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # done in test_linux_virtual_facts module in test_virtual.py
    pass


# ===========================================
# Subclass LinuxService for systemd platforms
# ===========================================

# Generated at 2022-06-11 05:52:02.863118
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class module:
        def get_bin_path(self, path, opt_dirs=[]):
            return path
        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None):
            out = ''
            if args[0] == 'virsh':
                if os.path.exists('tests/virsh.txt'):
                    with open('tests/virsh.txt', 'r') as fh:
                        out = fh.read()
            elif args[0] == 'systemd-detect-virt':
                if os.path.exists('tests/systemd-detect-virt.txt'):
                    with open('tests/systemd-detect-virt.txt', 'r') as fh:
                        out = fh.read()
           

# Generated at 2022-06-11 05:52:04.778041
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual = LinuxVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-11 05:52:11.317716
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual

    # create an instance
    Facter = LinuxVirtual()
    # call get_virtual_facts with valid input
    result = Facter.get_virtual_facts()
    # assert the output
    print (result)

if __name__ == "__main__":
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-11 05:52:13.298900
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-11 05:52:17.430100
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class ansible_module_mock:
        def __init__(self):
            self.params = {}
            self.bin_path = lambda x: x
            self.run_command = lambda x: (0, '', '')
            self.fail_json = lambda x: False

    test_object = LinuxVirtual()

    for key, value in test_data['virtual'].items():
        assert value == test_object.get_virtual_facts()[key]


# Generated at 2022-06-11 05:52:21.663048
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule({})
    lv = LinuxVirtual(module)
    assert lv.get_virtual_facts() == {'virtualization_tech_host': set(), \
                                      'virtualization_tech_guest': set(['container']), \
                                      'virtualization_type': 'docker', \
                                      'virtualization_role': 'guest'}


# Generated at 2022-06-11 05:52:24.499559
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.collector import Collector
    assert issubclass(LinuxVirtualCollector, Collector)
    lvc = LinuxVirtualCollector()
    assert isinstance(lvc, VirtualCollector)


# Generated at 2022-06-11 05:52:30.917915
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value='/bin/dmidecode')

    # Test
    module.run_command = MagicMock(return_value=(0, MOCK_DMIDECODE_OUTPUT, ""))
    module.get_bin_path = MagicMock(return_value='/bin/dmidecode')
    result = LinuxVirtual(module).get_virtual_facts()

    assert result['virtualization_tech_guest'] == set(['kvm'])
    assert result['virtualization_tech_host'] == set(['kvm'])

# Generated at 2022-06-11 05:52:32.596579
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    o = LinuxVirtualCollector()
    assert o is not None
