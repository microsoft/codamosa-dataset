

# Generated at 2022-06-11 05:52:24.101947
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    if not HAS_LIBVIRT:
        module.fail_json(msg='libvirt is not importable.')
    if not HAS_LIBS:
        module.fail_json(msg='The `lxml` python3 module is not importable.')
    virtual_facts = LinuxVirtual(module).get_virtual_facts()
    assert isinstance(virtual_facts, dict)


# Generated at 2022-06-11 05:52:26.799583
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test = LinuxVirtual()
    assert test.get_virtual_facts() == dict(virtualization_type='NA', virtualization_role='NA',
                                            virtualization_tech_guest=set(), virtualization_tech_host=set())


# Generated at 2022-06-11 05:52:31.166228
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = {}
    fact_collector = LinuxVirtualCollector(facts)
    assert fact_collector
    assert isinstance(fact_collector._fact_class, LinuxVirtual)
    assert fact_collector._platform == 'Linux'


# Generated at 2022-06-11 05:52:34.126523
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    test_obj = LinuxVirtualCollector()
    assert test_obj is not None
    assert test_obj._fact_class == LinuxVirtual
    assert test_obj._platform == 'Linux'


# Generated at 2022-06-11 05:52:35.054989
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()

# Generated at 2022-06-11 05:52:39.891801
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Unit test for method ``get_virtual_facts`` of class ``LinuxVirtual``"""
    # create a instance of LinuxVirtual calss
    virtual = LinuxVirtual()

    # invoke ``get_virtual_facts`` method of the LinuxVirtual class
    virtual.get_virtual_facts()

    # verify that the returned value is of type dict
    assert (type(virtual.get_virtual_facts()) == dict)


# Generated at 2022-06-11 05:52:42.234756
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test for constructor
    """
    args = {'collect_default_facts': False, 'filter': ['virtualization_*']}
    assert LinuxVirtualCollector(args)

# Generated at 2022-06-11 05:52:45.660096
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    lv = LinuxVirtual(module)
    res = lv.get_virtual_facts()
    assert res['virtualization_type'] == 'kvm'

# Generated at 2022-06-11 05:52:48.492491
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector._fact_class == LinuxVirtual
    assert collector._platform == 'Linux'
    assert collector._facts_to_collect == None


# Generated at 2022-06-11 05:52:52.246059
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)

    # TODO: Write unit test for method get_virtual_facts of class LinuxVirtual


