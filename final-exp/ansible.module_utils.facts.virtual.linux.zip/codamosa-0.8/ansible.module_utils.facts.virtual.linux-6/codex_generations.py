

# Generated at 2022-06-11 05:52:58.939555
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    fixture = LinuxVirtual({
        'platform': 'Linux',
        'system': 'Linux',
        'virtual': 'LinuxVirtual',
        'os_family': 'RedHat',
        'distribution': 'Fedora',
        'distribution_release': '28',
        'distribution_major_version': '28',
        'distribution_version': '28',
    })
    assert fixture.get_virtual_facts() == {
        'virtualization_type': 'NA',
        'virtualization_role': 'NA',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-11 05:53:01.017972
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_collector = LinuxVirtualCollector()
    assert virtual_collector._fact_class == LinuxVirtual
    assert virtual_collector._platform == 'Linux'

# Generated at 2022-06-11 05:53:04.734270
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Unit test for constructor of class LinuxVirtualCollector
    """
    module = AnsibleModuleMock()
    obj = LinuxVirtualCollector(module)

    assert obj._fact_class == LinuxVirtual
    assert obj._platform == 'Linux'


# Generated at 2022-06-11 05:53:14.410310
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Create module & mock fact
    module = AnsibleModuleMock()
    module.params = {'gather_subset': ['all']}
    mock_fact = LinuxVirtualCollector(module)
    assert('/proc/cpuinfo' in mock_fact._file_list)

    # End of test_LinuxVirtualCollector

if __name__ == '__main__':
    my_test = LinuxVirtualCollector()
    my_test.collect()
    print("my_test.data[0] %s" % my_test.data[0])
    print("my_test.data[1] %s" % my_test.data[1])
    print("my_test.data[2] %s" % my_test.data[2])

# Generated at 2022-06-11 05:53:24.240015
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    If a system has lxc containers, return the facts
    """

# Generated at 2022-06-11 05:53:26.632838
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    v_facts = lv.get_virtual_facts()

# Generated at 2022-06-11 05:53:30.172996
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    event_data = {}
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(default=None, type='list')
    ))

    result = LinuxVirtual.get_virtual_facts(module, event_data)

    assert result is not None

# Generated at 2022-06-11 05:53:35.896413
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mock = MagicMock()
    m = LinuxVirtual(mock)
    m.get_file_content = MagicMock(return_value='')
    m.get_file_lines = MagicMock(return_value=[])
    m.get_bin_path = MagicMock(return_value=None)
    m.module.run_command = MagicMock(return_value=(0, '', ''))
    m.get_virtual_facts()


# Generated at 2022-06-11 05:53:37.447089
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    virtual = LinuxVirtualCollector(module)
    assert virtual._platform == 'Linux'

# Generated at 2022-06-11 05:53:45.524950
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    results = dict()
    host_facts = dict(
        ansible_all_ipv4_addresses=['1.2.3.4'],
        ansible_architecture='x86_64',
        ansible_default_ipv4=dict(
            address='1.2.3.4',
            aliases=['eth0'],
            interface='eth0'
        ),
        ansible_distribution='CentOS',
        ansible_distribution_major_version='7',
        ansible_distribution_version='7.8.2003',
        ansible_machine='x86_64',
        ansible_os_family='RedHat',
        ansible_pkg_mgr='yum',
        ansible_system='Linux'
    )
