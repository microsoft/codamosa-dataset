

# Generated at 2022-06-11 05:52:44.920885
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
    )

    lv = LinuxVirtual(module)
    assert lv.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'virtualbox',
        'virtualization_tech_guest': {
            'virtualbox'
        },
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-11 05:52:55.178789
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = get_module_mock()
    module.get_bin_path.return_value = '/bin/lscpu'

    l = LinuxVirtual(module)

    # Test VirtualBox guest

# Generated at 2022-06-11 05:53:04.970344
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    m_get_file_content = MagicMock(return_value='somecontent')
    m_get_file_lines = MagicMock(return_value=['VxID: 0'])
    m_get_bin_path = MagicMock(return_value='path')

    test_obj = LinuxVirtual(dict(), dict())
    test_obj.module = MagicMock()
    test_obj.module.get_bin_path = m_get_bin_path
    test_obj.get_file_content = m_get_file_content
    test_obj.get_file_lines = m_get_file_lines
    result = test_obj.get_virtual_facts()
    assert result['virtualization_role'] == 'host'
    assert result['virtualization_type'] == 'linux_vserver'

# Unit

# Generated at 2022-06-11 05:53:09.217504
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec=dict())
    collector = LinuxVirtualCollector(module)
    assert isinstance(collector, object)
    assert isinstance(collector, LinuxVirtualCollector)
    assert isinstance(collector.collect(), dict)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 05:53:11.087918
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'


# Generated at 2022-06-11 05:53:17.215888
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_host': None, 'virtualization_tech_guest': None}
    LinuxVirtual.get_virtual_facts(virtual_facts)
    assert virtual_facts['virtualization_type'] is not None
    assert virtual_facts['virtualization_role'] is not None
    assert virtual_facts['virtualization_tech_host'] is not None
    assert virtual_facts['virtualization_tech_guest'] is not None

# Generated at 2022-06-11 05:53:27.217691
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module.run_command = MagicMock()
    lv.get_virtual_facts()
    lv.module.run_command.assert_called_once_with(['lscpu', '-e'], check_rc=True)
    lv.module.run_command.reset_mock()

    lv.module.run_command.return_value = (0, '', None)
    lv.get_virtual_facts()
    lv.module.run_command.assert_called_once_with(['lscpu', '-e'], check_rc=True)
    lv.module.run_command.reset_mock()

    lv.module.run_command.return_value = (1, '', None)
    lv.get_virtual_

# Generated at 2022-06-11 05:53:28.891002
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector._fact_class == LinuxVirtual
    assert LinuxVirtualCollector._platform == 'Linux'

# Generated at 2022-06-11 05:53:33.063616
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux = LinuxVirtualCollector().collect()
    assert linux['virtualization_type'] == "physical"
    assert linux['virtualization_role'] == "host"
    assert 'virtualization_tech_guest' not in linux
    assert 'virtualization_tech_host' not in linux


# Generated at 2022-06-11 05:53:37.591047
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    linux_virtual = LinuxVirtual()

    # Mock get_file_lines with dummy data for method testing
    def get_file_lines(file):
        if file == '/proc/cpuinfo':
            return '''
processor	: 0
vendor_id	: GenuineIntel
cpu family	: 6
model		: 61
model name	: Intel(R) Core(TM) i5-4670K CPU @ 3.40GHz
'''.splitlines()
        elif file == '/sys/devices/virtual/dmi/id/product_name':
            return ['VMware Virtual Platform']
        else:
            return []
