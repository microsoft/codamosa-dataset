

# Generated at 2022-06-11 05:52:55.003679
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    print("Test get_virtual_facts")
    module = AnsibleModule(
        argument_spec=dict()
    )
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    print(virtual_facts)
if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()


# Generated at 2022-06-11 05:53:01.734283
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    '''
    Constructor of class LinuxVirtualCollector
    '''
    dummy_module = DummyAnsibleModule()
    dummy_module.params = {
        'gather_subset': ['!all', '!min'],
        'filter': '*virtual*'
    }
    col = LinuxVirtualCollector(dummy_module)
    assert col.platform == "Linux"
    assert col.gather_subset == {'!all', '!min'}
    assert col.filter == "*virtual*"


# Generated at 2022-06-11 05:53:11.776021
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Mock the linux.py's get_virtual_facts module.
    """
    import re
    mocked_facts = fact_filter.get_facts_dictionary()
    mocked_module = mock.Mock()

    mocked_module.run_command = lambda _: (0, "", "")
    mocked_module.get_bin_path = lambda _: "/usr/bin/dmidecode"

    mocked_facts['ansible_virtualization_type'] = None
    mocked_facts['ansible_virtualization_role'] = None
    mocked_facts['ansible_virtualization_tech_guest'] = set()
    mocked_facts['ansible_virtualization_tech_host'] = set()
    mocked_facts['ansible_virtualization_fact'] = None


# Generated at 2022-06-11 05:53:15.439609
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    this_virtual_fact = LinuxVirtual()
    result = this_virtual_fact.get_virtual_facts()

    assert result['virtualization_type'] == 'virtualbox'
    assert result['virtualization_role'] == 'guest'
    assert 'virtualbox' in result['virtualization_tech_guest']


# Generated at 2022-06-11 05:53:19.473467
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector.__name__ == 'LinuxVirtualCollector'
    assert LinuxVirtualCollector.platform == 'Linux'
    assert LinuxVirtualCollector._fact_class.__name__ == 'LinuxVirtual'
    assert isinstance(LinuxVirtualCollector._fact_class, type)


# Generated at 2022-06-11 05:53:29.145973
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    av = LinuxVirtual()

    av.module = mock.Mock()
    av.module.run_command.return_value = (1, '', '')

    dmi_bin = av.module.get_bin_path.return_value
    dmi_bin = '/usr/sbin/dmidecode'
    av.module.get_bin_path.return_value = dmi_bin

    av.module.run_command.return_value = (0, 'vmware', '')

    av.module.run_command.return_value = (0, '', '')

    expected = {'virtualization_type': 'VMware',
                'virtualization_role': 'guest',
                'virtualization_tech_guest': {'VMware'},
                'virtualization_tech_host': set()}

    ret

# Generated at 2022-06-11 05:53:34.045811
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    expected_result = {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_host': set(['kvm']),
        'virtualization_tech_guest': set(['kvm'])}
    __validate_virtual_facts(LinuxVirtualCollector(), expected_result)


# Generated at 2022-06-11 05:53:36.962723
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux = LinuxVirtual(module=None)
    linux.get_file_content = MagicMock(return_value='')
    linux.get_file_lines = MagicMock(return_value=[''])
    assert linux.get_virtual_facts() == {
        'virtualization_type': 'NA',
        'virtualization_role': 'NA',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-11 05:53:45.089271
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    class mock_module:
        params = {'only_virtual': False}
        def run_command(self, *args, **kwargs):
            print(args)
            if 'systemd-detect-virt' in args[0]:
                return 0, 'kvm', None
            elif 'cat' in args[0] and 'cgroup' in args[0]:
                return 0, '3:cpu,cpuacct:/docker/a11f6e1d6aacfdf0b2a927c54a9f933c6f39a8e86a6e5e6dac4930a2ef8f22b6', None

# Generated at 2022-06-11 05:53:47.441132
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})

    module.params = {}

    lv = LinuxVirtual()
    lv.module = module
    result = lv.get_virtual_facts()
    # assert result['virtualization_type'] == 'kvm'
    # assert result['virtualization_role'] == 'guest'
    assert result

if __name__ == "__main__":
    main()