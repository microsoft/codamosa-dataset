

# Generated at 2022-06-11 05:52:26.377343
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    vc = LinuxVirtualCollector(module)
    assert isinstance(vc, VirtualCollector)


# Generated at 2022-06-11 05:52:34.083162
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test for constructor of class LinuxVirtualCollector"""
    fake_module = AnsibleModuleMock(
        dict(run_command=MagicMock(return_value={'rc': 0, 'stdout': 'test_str', 'stderr': ''}))
    )
    virtual_collector = LinuxVirtualCollector(fake_module)
    assert isinstance(virtual_collector._fact_class, LinuxVirtual)
    assert virtual_collector._module is fake_module


# Generated at 2022-06-11 05:52:36.060512
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # TODO: Refactor this test to not use "eval"
    assert eval(repr(LinuxVirtualCollector())) == LinuxVirtualCollector()

# Generated at 2022-06-11 05:52:38.763340
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert LinuxVirtual().get_virtual_facts() == {'virtualization_role': 'NA', 'virtualization_type': 'NA'}

# Module Ansible boilerplate for the unit test.

# Generated at 2022-06-11 05:52:43.619400
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test instantiation of LinuxVirtualCollector class."""
    my_obj = LinuxVirtualCollector()
    assert my_obj is not None, "Failed to instantiate LinuxVirtualCollector object."
    assert isinstance(my_obj, VirtualCollector), "LinuxVirtualCollector doesn't inherit from VirtualCollector."
    assert isinstance(my_obj, LinuxVirtualCollector), "LinuxVirtualCollector doesn't inherit from itself."

# Generated at 2022-06-11 05:52:53.473691
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # The function populate_virtual_facts_from_dmi_data() is not mocked
    # because of the following error:
    #     def mock_decode(s):
    #     TypeError: mock_decode() missing 1 required positional argument: 'coding'
    # When this is fixed, set the 'skip' value to False.
    skip = True

    # Mock the dmidecode's output, check the virtualization type
    virtual_data = {
        'vendor': 'innotek GmbH',
        'product': 'VirtualBox'
    }

# Generated at 2022-06-11 05:52:55.625489
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector.platform == 'Linux', 'LinuxVirtualCollector.platform should be equal to Linux'


# Generated at 2022-06-11 05:53:00.819717
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # This will fail if we cannot get a _fact_class, e.g. due to import errors.
    LinuxVirtualCollector()
    # It will also fail if we cannot get a _platform
    assert LinuxVirtualCollector()._platform == 'Linux'
    # It will fail if we fail to mixin the correct class
    assert issubclass(LinuxVirtualCollector()._fact_class, LinuxVirtual)



# Generated at 2022-06-11 05:53:07.318764
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )

    # Pass in a mock for the set_module_facts() method
    linux_virtual = LinuxVirtual(module=module)
    result = linux_virtual.get_virtual_facts()

    assert 'virtualization_role' in result
    assert 'virtualization_type' in result
    assert 'virtualization_tech_host' in result
    assert 'virtualization_tech_guest' in result


# Generated at 2022-06-11 05:53:13.931898
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    testobj = LinuxVirtual()
    testobj.module = get_module_mock()
    testobj.module.run_command = get_command_mock()
    testobj.module.get_bin_path = get_bin_path_mock()
    testobj.get_file_content = get_file_content_mock()
    testobj.get_file_lines = get_file_lines_mock()
    # TODO: Test asserts
    testobj.get_virtual_facts()
# Unit test class for testing methods of class LinuxNetwork