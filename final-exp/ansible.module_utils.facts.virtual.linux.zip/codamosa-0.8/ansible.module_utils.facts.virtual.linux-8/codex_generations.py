

# Generated at 2022-06-11 05:52:40.569597
# Unit test for method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-11 05:52:43.872771
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    '''
    Test for constructor of class LinuxVirtualCollector
    '''
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector._platform == 'Linux'
    assert linux_virtual_collector._fact_class == LinuxVirtual


# Generated at 2022-06-11 05:52:52.958092
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Testing case #1:
    # Test to return 'None' for the hostname
    linux_virtual = LinuxVirtual(None)
    linux_virtual.module.get_bin_path = MagicMock(return_value=True)
    hostname = linux_virtual.get_virtual_facts()
    assert hostname['virtualization_type'] == 'virtualbox'

    # Testing case #2:
    # Test to return 'None' for the hostname
    linux_virtual = LinuxVirtual(None)
    linux_virtual.module.get_bin_path = MagicMock(return_value=False)
    hostname = linux_virtual.get_virtual_facts()
    assert hostname['virtualization_type'] == 'NA'


# Generated at 2022-06-11 05:53:03.026062
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.linux import LinuxVirtual

    mock_module = MagicMock()
    mock_module.run_command.side_effect = lambda x: (254, '', 'error')
    mock_module.check_mode = False
    mock_module.get_bin_path.side_effect = lambda x: "/usr/bin/%s" % x

    module = LinuxVirtual(mock_module)

    # /sys/devices/virtual exists
    with patch('os.path.exists', return_value=True):
        # fake lscpu (lscpu exists)
        with patch('os.path.isfile', return_value=True):
            # Fake host_tech and guest_tech
            host_tech = set()
            guest_tech = set()
            # Fake the existence of /proc

# Generated at 2022-06-11 05:53:12.973293
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    data = dict()
    data['virtual'] = dict()
    data['virtual']['virtual_facts'] = dict()
    data['virtual']['virtual_facts']['virtualization_type'] = 'None'
    data['virtual']['virtual_facts']['virtualization_role'] = 'None'
    data['virtual']['virtual_facts']['virtualization_tech_guest'] = 'None'
    data['virtual']['virtual_facts']['virtualization_tech_host'] = 'None'
    module = CommandResult(dict(
        changed=False,
        rc=0,
        stdout='',
        stderr='',
        cmd=''
    ))
    module.get_bin_path = MagicMock(return_value=True)
    module.run_command = MagicMock

# Generated at 2022-06-11 05:53:14.567910
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector()
    assert virtual.distribution_name == 'Linux'


# Generated at 2022-06-11 05:53:24.436505
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Creating a mock module object
    # AnsibleModule Mock object
    mock_module_obj = type('AnsibleModule', (object,), dict(
        check_mode=False,
        debug=False,
        log=logging.getLogger(),
        get_bin_path=MagicMock(return_value='dmidecode'),
        run_command=MagicMock(
            return_value=(0, "dmi_system_product_name: VMware\n# dmi_system_vendor: innotek GmbH", "")
        ),
    ))
    # This will return a LinuxDistribution object
    lv = LinuxVirtual(mock_module_obj)

# Generated at 2022-06-11 05:53:28.977628
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # GIVEN a VirtualCollector object
    linuxVirtualCollectorObject = LinuxVirtualCollector()
    # THEN assert that it is a VirtualCollector object
    assert isinstance(linuxVirtualCollectorObject, VirtualCollector)
    # AND assert the correct fact class and platform are set
    assert linuxVirtualCollectorObject._fact_class == LinuxVirtual
    assert linuxVirtualCollectorObject._platform == 'Linux'

# Generated at 2022-06-11 05:53:31.049584
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vm = LinuxVirtualCollector(None)
    assert vm.platform == 'Linux'
    assert vm.fact_class == LinuxVirtual

# Generated at 2022-06-11 05:53:33.020403
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.platform == 'Linux'
