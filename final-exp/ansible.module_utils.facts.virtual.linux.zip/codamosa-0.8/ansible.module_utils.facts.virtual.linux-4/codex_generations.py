

# Generated at 2022-06-11 05:52:00.802912
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test LinuxVirtualCollector constructor
    """
    tmp_dir = tempfile.mkdtemp()
    os.mkdir(tmp_dir + "/proc")
    os.mkdir(tmp_dir + "/sys")
    os.mkdir(tmp_dir + "/dev")
    os.mkdir(tmp_dir + "/dev/kvm")
    os.mkdir(tmp_dir + "/proc/vmware")
    os.mkdir(tmp_dir + "/proc/vz")
    os.mkdir(tmp_dir + "/run/systemd/container")
    os.mkdir(tmp_dir + "/rhev/")
    os.mkdir(tmp_dir + "/.docker")
    open(tmp_dir + "/.docker/config.json", 'w').close()


# Generated at 2022-06-11 05:52:11.405346
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class ModuleMock: 
        def __init__(self, *args, **kwargs):
            self.bin_path_cache = {}

        def get_bin_path(self, prog, required):
            return self.bin_path_cache.get(prog, None)

    class RunCommandMock:
        def __init__(self, *args, **kwargs):
            self.bin_path_cache = {}
            self.rc = 0
            self.out = ''
            self.err = ''

        def __call__(self, args, *kargs, **kwargs):
            return self.rc, self.out, self.err

    t = LinuxVirtual()
    t.module = ModuleMock()
    t.module.run_command = RunCommandMock()

    # test case 1: is_container


# Generated at 2022-06-11 05:52:14.561573
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule({})
    virtual_collector = LinuxVirtualCollector(module)
    assert virtual_collector.platform == 'Linux'
    assert virtual_collector.fact_class == LinuxVirtual

# Generated at 2022-06-11 05:52:19.856983
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Return a set of virtualization facts based on the contents of /proc, /sys, and dmidecode (when available).

    """

    logger = logging.getLogger('ansible.module_utils.basic.ansible_support_testsuite.unit_test')
    logger.info("\nTESTSUITE - START test_LinuxVirtual_get_virtual_facts\n")

    virtual_obj = LinuxVirtual()

    virtual_facts = virtual_obj.get_virtual_facts()
    print(virtual_facts)

    logger.info("\nTESTSUITE - END test_LinuxVirtual_get_virtual_facts\n")

if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-11 05:52:27.563569
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    generator = LinuxVirtual()
    with patch.dict(os.environ, {'NOVA_CONF_DIR': '/etc/nova'}):
        assert generator.get_file_content('/etc/nova/nova-compute.conf') == 'VirtualHost'
        assert generator.get_file_content('/etc/nova/nova-compute2.conf', default='NoVirtualHost') == 'NoVirtualHost'
    if os.path.exists('/sys/devices/virtual/dmi/id/product_name'):
        with open('/sys/devices/virtual/dmi/id/product_name', 'w') as f:
            f.write('KVM')
        assert generator.get_file_content('/sys/devices/virtual/dmi/id/product_name') == 'KVM'

# Generated at 2022-06-11 05:52:37.248270
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock()
    virtual = LinuxVirtual(module=module)
    virtual.virtualization_type = None
    virtual.is_container = MagicMock()
    virtual.is_container.return_value = False
    virtual.get_virtual_facts()
    module.run_command.assert_any_call(['systemd-detect-virt'])
    virtual.is_container.assert_any_call()
    assert len(virtual.virtualization_tech_host) == 0
    assert len(virtual.virtualization_tech_guest) == 0
    virtual.virtualization_type = 'openstack'
    virtual.is_container = MagicMock()

# Generated at 2022-06-11 05:52:39.260575
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector(None)
    assert virtual.platform == 'Linux'
    assert virtual.fact_class == LinuxVirtual



# Generated at 2022-06-11 05:52:48.750966
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual = LinuxVirtual()
    virtual.module = AnsibleModule(argument_spec={})
    virtual.module.get_bin_path = MagicMock(return_value="/usr/bin/lscpu")
    virtual_facts = {
        "virtualization_role": "guest",
        "virtualization_type": "kvm",
        "virtualization_tech_guest": {
            "container",
            "docker",
            "kvm"
        },
        "virtualization_tech_host": {
            "kvm"
        }
    }
    virtual._get_file_content = MagicMock(return_value="QEMU")
    virtual._get_file_lines = MagicMock(return_value=["model name : QEMU Virtual CPU"])
    virtual.get_virtual_facts()
    assert virtual

# Generated at 2022-06-11 05:52:58.981178
# Unit test for constructor of class LinuxVirtualCollector

# Generated at 2022-06-11 05:53:08.761542
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    args = {
        'ansible_facts': {},
    }
    current_module = AnsibleModule(argument_spec=args)
    linux_virtual_obj = LinuxVirtual(current_module)
    #set content of /proc/cpuinfo
    file_cpuinfo = 'model name      : QEMU Virtual CPU version (cpu64-rhel6)'
    with open('/tmp/cpuinfo', 'w') as f:
        f.write(file_cpuinfo)
    os.symlink('/tmp/cpuinfo', '/proc/cpuinfo')
    #set content of /proc/self/status
    file_status = 'VxID: 1'
    with open('/tmp/status', 'w') as f:
        f.write(file_status)