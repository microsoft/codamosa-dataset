

# Generated at 2022-06-11 05:51:54.833941
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from unittest import mock

    # Initialize mocks
    module_mock = mock.Mock()
    module_mock.get_bin_path.return_value = '/fake/path'
    module_mock.run_command.return_value = (0, b'data', b'')
    module_mock.get_file_content.return_value = 'data'
    try:
        from __main__ import display
        display.vvv = mock.Mock()
    except Exception:
        pass

    # Create the object
    linux_virtual = LinuxVirtual(module_mock)

    # Run the method
    result = linux_virtual.get_virtual_facts()

    # Assert result

# Generated at 2022-06-11 05:52:03.354429
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Test function for get_virtual_facts of class LinuxVirtual.
    """
    loader = unittest.TestLoader()
    tests = loader.loadTestsFromTestCase(LinuxVirtualTestCase)
    suite = unittest.TestSuite([tests])
    unittest.TextTestRunner(verbosity=2).run(suite)

# Load module for test
module_args = dict()
module = AnsibleModule(argument_spec=module_args)

result = dict(
    changed=False,
    ansible_facts=dict(
        ansible_virtualization_role='guest',
        ansible_virtualization_type='virtualbox',
        ansible_virtualization_tech_guest={'virtualbox'},
        ansible_virtualization_tech_host={},
    )
)


# Generated at 2022-06-11 05:52:07.333100
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    result = LinuxVirtualCollector(module).collect()
    assert 'virtualization_tech_guest' and 'virtualization_tech_host' and \
           'virtualization_type' in result['ansible_facts']

# Generated at 2022-06-11 05:52:12.152255
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    lv = LinuxVirtualCollector(module)
    assert_equals(lv.platform, 'Linux')

# Helper method: Create an instance of AnsibleModule and test class LinuxVirtualCollector

# Generated at 2022-06-11 05:52:16.811283
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = DummyAnsibleModule(load_fixtures=False)
    lv._get_dmi_data = DummyDmiData()
    lv.module.exit_json(changed=False, ansible_facts=lv.get_virtual_facts())


# Generated at 2022-06-11 05:52:18.142166
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.facts is None


# Generated at 2022-06-11 05:52:21.072696
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Check the constructor of class LinuxVirtualCollector."""
    facts = dict()
    result = dict()
    collector = LinuxVirtualCollector(facts, dict(), dict(), result)
    assert collector is not None
    assert result == dict()


# Generated at 2022-06-11 05:52:24.029111
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    instance = LinuxVirtualCollector()
    assert isinstance(instance, LinuxVirtualCollector)
    assert isinstance(instance, Collector)
    assert instance._platform == 'Linux'
    assert isinstance(instance._fact_class, LinuxVirtual)

# Unit tests for class LinuxVirtual

# Generated at 2022-06-11 05:52:25.546796
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector(None)
    assert linux_virtual_collector.platform == 'Linux'

# Generated at 2022-06-11 05:52:31.225600
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    result = {}

    # populate the up to date virtual facts
    virtual = LinuxVirtual(module)
    virtual_facts = virtual.get_virtual_facts()

    result['ansible_virtualization_type'] = virtual_facts['virtualization_type']
    result['ansible_virtualization_role'] = virtual_facts['virtualization_role']
    result['ansible_virtualization_tech_guest'] = virtual_facts['virtualization_tech_guest']
    result['ansible_virtualization_tech_host'] = virtual_facts['virtualization_tech_host']

    module.exit_json(ansible_facts=result)