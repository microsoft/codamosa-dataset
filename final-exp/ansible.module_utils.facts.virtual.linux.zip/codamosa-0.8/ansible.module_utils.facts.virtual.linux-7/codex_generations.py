

# Generated at 2022-06-11 05:52:18.178108
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import doctest
    import sys
    sys.path.append('/home/qa')
    from lib.ansible_module_common import get_file_content, get_file_lines, get_mount_size, get_mount_device

    module_args = dict()
    m = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    lv = LinuxVirtual(m)

    facts = lv.get_virtual_facts()
    assert facts


# Generated at 2022-06-11 05:52:25.658580
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Setup
    module = AnsibleModule(argument_spec={})
    mocked_LinuxSysctl = mock.Mock()
    mocked_LinuxSysctl.get_file_content.return_value = ''
    mocked_LinuxSysctl.get_file_lines.return_value = []
    module.get_bin_path.return_value = 'fake_path'
    inst = LinuxVirtual(module, mocked_LinuxSysctl)
    # Execute
    result = inst.get_virtual_facts()
    # verify
    assert result == dict(virtualization_type='NA',
                          virtualization_role='NA',
                          virtualization_tech_guest=set(),
                          virtualization_tech_host=set())


# Generated at 2022-06-11 05:52:29.937732
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    import ansible_collections.ansible.misc.plugins.module_utils.facts.virtual

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    ansible_collections.ansible.misc.plugins.module_utils.facts.virtual.LinuxVirtual(module).populate()
    result = module.exit_json()
    assert result == {
        'ansible_facts': {
            'virtualization_role': 'guest',
            'virtualization_type': 'docker',
            'virtualization_tech_guest': 'container',
            'virtualization_tech_host': 'container'
        }
    }


# Generated at 2022-06-11 05:52:36.875966
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    os.environ['PATH'] = '/sbin:/usr/sbin:/usr/bin:/bin'
    os.environ['LANG'] = 'en_US.UTF-8'
    os.environ['LC_ALL'] = 'en_US.UTF-8'
    module = AnsibleModule(
        argument_spec=dict(
        ),
    )
    virtual = LinuxVirtual()
    module.exit_json(changed=False, ansible_facts=dict(virtual_facts=virtual.get_virtual_facts()))
if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-11 05:52:45.959503
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )

    if not HAVE_DMIDECODE:
        module.fail_json(msg='The `dmidecode` binary is not in the path.  Is it installed?')

    if not HAVE_LSHAL:
        module.fail_json(msg='The `lshal` binary is not in the path.  Is it installed?')

    if not HAVE_LSCPU:
        module.fail_json(msg='The `lscpu` binary is not in the path.  Is it installed?')

    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    module.exit_json(changed=False, ansible_facts=dict(virtual=virtual_facts))

# import

# Generated at 2022-06-11 05:52:56.426766
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    argument_spec = dict(
        module=dict(type='str', choices=['kvm', 'zvm', 'lpar', 'ibm_systemz', 'xen', 'aix', 's390x', 'vmware', 'openvz', 'hpvm', 'uml', 'oracle', 'parallels', 'virtualbox', 'openstack', 'gce', 'hyperv', 'bhyve', 'NA'])
    )

    module = AnsibleModule(
        argument_spec=argument_spec
    )

    if module.params['module'] == 'lpar':
        # create and chdir to a tempdir
        tempdir_path = tempfile.mkdtemp()
        os.chdir(tempdir_path)

        # create dirs and files
       

# Generated at 2022-06-11 05:52:57.346680
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts = LinuxVirtual().get_virtual_facts()
    assert virtual_facts


# Generated at 2022-06-11 05:52:58.670409
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Unit test for constructor of class LinuxVirtualCollector
    """
    collect_virt = LinuxVirtualCollector()
    assert collect_virt is not None


# Generated at 2022-06-11 05:53:01.473731
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = MagicMock()
    platform_object = LinuxVirtualCollector(module)
    # Checks for constructor of class LinuxVirtualCollector
    assert isinstance(platform_object._collector, LinuxVirtual)


# Generated at 2022-06-11 05:53:05.622686
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Definition of unit test for method get_virtual_facts of class LinuxVirtual.
    """
    test_obj = LinuxVirtual({'ANSIBLE_MODULE_ARGS': {}})
    assert test_obj.get_virtual_facts() == {}

# Class to process facts on POSIX based system