

# Generated at 2022-06-11 05:53:04.001116
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual


# Generated at 2022-06-11 05:53:10.951940
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test for constructor of class LinuxVirtualCollector"""
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    fact_collector = LinuxVirtualCollector(module)

    # Asserting the instance is of the correct type
    assert isinstance(fact_collector, VirtualCollector)

    # Asserting the instance is of the correct type
    assert isinstance(fact_collector.facts, LinuxVirtual)

    # Asserting the platform is correct
    assert fact_collector._platform == 'Linux'

# Generated at 2022-06-11 05:53:16.419787
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test method LinuxVirtual().get_virtual_facts()
    """
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    if linux_virtual.get_virtual_facts() == {'virtualization_type': 'NA', 'virtualization_role': 'NA', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}:
        print("ALWAYS TRUE")


# Generated at 2022-06-11 05:53:19.429297
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual('module')
    params = {'module': None}
    result = linux_virtual.get_virtual_facts(**params)
    assert isinstance(result, dict)


# Generated at 2022-06-11 05:53:24.523198
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class LinuxVirtual
    '''
    module = AnsibleModuleMock()
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'

# Generated at 2022-06-11 05:53:34.044237
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual = LinuxVirtual(module)

    facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'docker',
        'virtualization_tech_guest': set(['docker']),
        'virtualization_tech_host': set(),
    }
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == facts

    facts = {
        'virtualization_role': 'host',
        'virtualization_type': 'lxc',
        'virtualization_tech_guest': set(['container']),
        'virtualization_tech_host': set(['lxc']),
    }

# Generated at 2022-06-11 05:53:42.447928
# Unit test for method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-11 05:53:42.878465
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    return LinuxVirtualCollector

# Generated at 2022-06-11 05:53:49.224846
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    dummy_lg = LinuxVirtual(module)


# Generated at 2022-06-11 05:53:53.232942
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    linux_virtual = LinuxVirtual(module)

    # The assertion below is fake since it is difficult to test this method.
    # In order to test this method, we would need to create files and directories in
    # /sys, /proc, etc. and set the /proc/sys files.

    # We will check if the result is a dictionary.
    virtual_facts = linux_virtual.get_virtual_facts(["virtual"])
    assert isinstance(virtual_facts, dict)
