

# Generated at 2022-06-11 05:52:31.897165
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_fact = LinuxVirtualCollector.collect()
    for key in ['virtualization_type', 'virtualization_role']:
        assert key in virtual_fact


# Generated at 2022-06-11 05:52:33.111907
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    v = LinuxVirtualCollector()
    assert v.facts is None


# Generated at 2022-06-11 05:52:42.025399
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class AnsibleModuleFake:
        def __init__(self):
            self.check_mode = False
            self._tmp_dir = None
            self.cleanup_tmp_dir = False
            self.env = dict()
            self.args = dict()

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg == 'lscpu':
                return '/usr/bin/lscpu'
            elif arg == 'dmidecode':
                return '/usr/bin/dmidecode'
            return None

        def run_command(self, cmd):
            out, err, rc = '', '', 0

            if cmd == '/usr/bin/lscpu':
                out = 'Hypervisor: KVM'

# Generated at 2022-06-11 05:52:42.713190
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:52:48.019407
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    virtual_facts = LinuxVirtualCollector(module).collect()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 05:52:56.274742
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule
    fake = FakedLinuxVirtual()
    module.get_bin_path = fake.ansible_get_bin_path
    module.run_command = fake.ansible_run_command

    fake.module = module

    assert fake.get_virtual_facts()['virtualization_type'] == 'QEMU'
    assert fake.get_virtual_facts()['virtualization_role'] == 'guest'
    assert 'kvm' in fake.get_virtual_facts()['virtualization_tech_guest']
    assert 'docker' in fake.get_virtual_facts()['virtualization_tech_guest']

# Generated at 2022-06-11 05:53:02.123953
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """ Constructor of LinuxVirtualCollector should return an
        instance of LinuxVirtualCollector with correct attributes
    """
    from ansible.module_utils.facts import Facts
    m = AnsibleModuleMock()
    f = Facts(m)
    fc = LinuxVirtualCollector(m, f)
    assert isinstance(fc, LinuxVirtualCollector)
    assert fc._fact_class == LinuxVirtual
    assert fc._platform == 'Linux'

# Generated at 2022-06-11 05:53:08.336156
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    if not HAS_PYTHON_DMIDECODE:
        module.fail_json(msg='This test needs the python-dmidecode library')

    lvirtual = LinuxVirtual(module)

    virtual_facts = lvirtual.get_virtual_facts()
    module.exit_json(ansible_facts=dict(
          virtual=virtual_facts))


# Generated at 2022-06-11 05:53:14.171152
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    module = AnsibleModule(argument_spec={})

    # Return values, change them as you see fit.
    # Don't use hardcoded return values.
    retvals = dict(
        changed=True,
        msg='',
        facts={},
        warnings=[],
        unreachable=[],
        failed=False,
    )
    # retvals = vm.get_virtual_facts()
    assert retvals == vm.get_virtual_facts()

# Generated at 2022-06-11 05:53:22.919702
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of class LinuxVirtual
    """
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=['all'], type='list')
        )
    )

    lv = LinuxVirtual(module)
    fs = lv.get_virtual_facts(module.params['gather_subset'])

    assert type(fs['virtualization_type'] or None) is str
    assert type(fs['virtualization_role'] or None) is str
    assert type(fs['virtualization_tech_guest']) is set
    assert type(fs['virtualization_tech_host']) is set
