

# Generated at 2022-06-11 05:52:38.927185
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    unit test method get_virtual_facts of class LinuxVirtual
    '''
    import os
    import tempfile
    unit = LinuxVirtual1()
    # Override to prevent test failures if temp file cannot be created

# Generated at 2022-06-11 05:52:40.741228
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    facts = dict()
    LinuxVirtual(facts, dict()).get_virtual_facts()
    return facts



# Generated at 2022-06-11 05:52:41.345449
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()

# Generated at 2022-06-11 05:52:46.499672
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    lv = LinuxVirtual(module)
    assert "virtualization_type" in lv.get_virtual_facts()
    assert "virtualization_role" in lv.get_virtual_facts()

    # AnsibleModule.exit_json is a fake, so we cannot check whether the right
    # values are returned

# Collect the virtual facts

# Generated at 2022-06-11 05:52:47.978454
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()


# Generated at 2022-06-11 05:52:51.297082
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():

    from ansible.module_utils.facts.virtual.linux import LinuxVirtualCollector
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    collect = LinuxVirtualCollector()
    assert collect.collect() == LinuxVirtual().collect()

# Generated at 2022-06-11 05:52:54.132659
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual = LinuxVirtual(module=None)
    assert virtual.get_virtual_facts()['virtualization_type'] != ''
    assert virtual.get_virtual_facts()['virtualization_role'] != ''



# Generated at 2022-06-11 05:53:04.301038
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Mock module for testing
    class ModuleMock():
        def __init__(self):
            pass

        def get_bin_path(self, path):
            if path == 'lscpu':
                return '/bin/lscpu'
            return None

        def run_command(self, command):
            if command == ['lscpu']:
                return 0, 'Hypervisor: KVM', ''
            return 0, '', ''

    module = ModuleMock()
    module.run_command = MagicMock(name="run_command")
    module.run_command.return_value = 0, 'Hypervisor: KVM', ''
    module.get_bin_path = MagicMock(name="get_bin_path")
    module.get_bin_path.return_value = '/bin/lscpu'
    l

# Generated at 2022-06-11 05:53:07.364254
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector(None)
    assert isinstance(lvc._fact_class, LinuxVirtual)
    assert lvc._fact_class.module is None
    assert lvc._platform == 'Linux'

# Generated at 2022-06-11 05:53:11.133444
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    with pytest.raises(UnboundLocalError):
        test_module = AnsibleModule(argument_spec={}, supports_check_mode=False)
        test_LinuxVirtual = LinuxVirtual(test_module)
        test_LinuxVirtual.get_virtual_facts()
