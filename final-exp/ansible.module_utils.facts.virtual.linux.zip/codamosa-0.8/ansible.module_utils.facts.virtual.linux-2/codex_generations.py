

# Generated at 2022-06-11 05:52:43.492304
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x._fact_class is not None
    assert x._fact_class.__name__ == 'LinuxVirtual'
    assert x._platform == 'Linux'


# Generated at 2022-06-11 05:52:44.879951
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj._fact_class == LinuxVirtual

# Generated at 2022-06-11 05:52:47.714512
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    results = dict()
    collector = LinuxVirtualCollector(dict(), results)
    assert collector._fact_class == LinuxVirtual
    assert collector._platform == 'Linux'

# Generated at 2022-06-11 05:52:50.327229
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.__class__.__name__ == 'LinuxVirtualCollector'
    assert lvc._platform == 'Linux'


# Generated at 2022-06-11 05:52:53.869081
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector(BaseModuleMock)
    lvc._platform = 'Linux'
    assert lvc._platform == 'Linux'
    assert isinstance(lvc, LinuxVirtual)
    assert isinstance(lvc, VirtualCollector)



# Generated at 2022-06-11 05:52:58.073849
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    ret = LinuxVirtual.get_virtual_facts(module)
    assert ret == {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_guest': {'kvm'}, 'virtualization_tech_host': {}}

# Generated at 2022-06-11 05:53:05.057501
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['!all']
    linux_virtual = LinuxVirtual(module)
    expected_virtual_facts = {
        'virtualization_tech_host': set(['docker']),
        'virtualization_tech_guest': set(['container']),
        'virtualization_type': 'docker',
        'virtualization_role': 'guest',
    }
    actual_virtual_facts = linux_virtual.get_virtual_facts()

    assert actual_virtual_facts == expected_virtual_facts

# Generated at 2022-06-11 05:53:13.767992
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # prepare the test environment
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    set_module_args(dict(
        _ansible_remote_tmp="/tmp/ansible_lvirtual"
    ))
    # declare a test object
    lvirtual_test_obj = LinuxVirtual(module)
    # call the method under test
    return_value = lvirtual_test_obj.get_virtual_facts()
    # print the results
    module.exit_json(ansible_facts=dict(virtual=return_value))

# import module snippets
from ansible.module_utils.basic import *
# declare an ansible module object
main()

# Generated at 2022-06-11 05:53:15.743716
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x._platform == 'Linux'
    assert x._fact_class == LinuxVirtual


# Generated at 2022-06-11 05:53:18.250312
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = AnsibleModule(
        argument_spec = dict()
    )
    lv.get_virtual_facts()