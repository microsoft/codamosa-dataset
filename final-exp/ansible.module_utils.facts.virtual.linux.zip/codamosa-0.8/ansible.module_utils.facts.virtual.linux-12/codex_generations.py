

# Generated at 2022-06-11 05:52:39.426355
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    linuxvirtual = LinuxVirtual(module)
    assert 'NA' in linuxvirtual.get_virtual_facts()
    assert 'NA' in linuxvirtual.get_virtual_facts()["virtualization_role"]
    assert 'NA' in linuxvirtual.get_virtual_facts()["virtualization_type"]


# Generated at 2022-06-11 05:52:41.460464
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    lvc = LinuxVirtualCollector(module)
    assert lvc is not None


# Generated at 2022-06-11 05:52:51.165736
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = fake_module(**{})
    lvc = LinuxVirtualCollector(module)
    assert lvc.module.params == {'gather_subset': ['all'], 'filter': '*'}
    assert lvc._facts == {}

    module = fake_module(**{'filter': ['virtual', 'kernel']})
    lvc = LinuxVirtualCollector(module)
    assert lvc.module.params == {'gather_subset': ['all'], 'filter': ['virtual', 'kernel']}
    assert lvc._facts == {}

    module = fake_module(**{'gather_subset': ['!all', 'virtual']})
    lvc = LinuxVirtualCollector(module)

# Generated at 2022-06-11 05:52:53.258886
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert c is not None and isinstance(c, LinuxVirtualCollector)


# Generated at 2022-06-11 05:52:55.478749
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Method get virtual facts of class LinuxVirtual.

    :return:
    """
    pass



# Generated at 2022-06-11 05:52:57.388543
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_collector = LinuxVirtualCollector()
    assert isinstance(virtual_collector, LinuxVirtualCollector)

# Generated at 2022-06-11 05:52:58.738697
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj.__class__.__name__ == 'LinuxVirtualCollector'
    assert obj.platform == 'Linux'



# Generated at 2022-06-11 05:53:03.076201
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    obj = LinuxVirtual()
    assert(obj.get_virtual_facts() == {'virtualization_type': 'NA', 'virtualization_role': 'NA', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()})


#===============================================================================
#
# LinuxDistribution
#
#===============================================================================

# Generated at 2022-06-11 05:53:06.058449
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = DummyAnsibleModule()
    facts = lv.get_virtual_facts()
    assert(facts['virtualization_type'] == 'virtualbox')

# Generated at 2022-06-11 05:53:10.766603
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    There is no testing for this method, as it relies on a lot of
    /proc and /sys (and /dev) entries which are very Linux specific.
    It is assumed that if the plugin works on a given Linux system, it
    will continue to work.
    '''
    return True

# end of class LinuxVirtual
