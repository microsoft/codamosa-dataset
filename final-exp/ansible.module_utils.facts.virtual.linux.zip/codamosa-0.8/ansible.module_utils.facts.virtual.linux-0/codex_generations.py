

# Generated at 2022-06-11 05:52:13.466029
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    m = AnsibleModule(
        argument_spec = dict(
            filter = dict(default=None, required=False, type='str')
        )
    )
    lv = LinuxVirtual(m)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts == dict(
        virtualization_type = 'kvm',
        virtualization_role = 'guest',
        virtualization_tech_guest = set(['kvm']),
        virtualization_tech_host = set([]),
    )


# Generated at 2022-06-11 05:52:22.560844
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Unit test for method LinuxVirtual._get_virtual_facts
    """
    class MockLinuxVirtualModule:
        """ Mock AnsibleModule class for unit test """
        def __init__(self):
            return None

        @staticmethod
        def get_bin_path(cmd):
            """
            Method to return path of an executable
            """
            if cmd == 'dmidecode':
                return '/usr/sbin/dmidecode'
            elif cmd == 'lscpu':
                if os.path.exists('tests/unit/modules/utils/lscpu'):
                    return 'tests/unit/modules/utils/lscpu'
                else:
                    return '../../modules/utils/lscpu'
            else:
                return None


# Generated at 2022-06-11 05:52:25.877214
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    fc = lvc._fact_class
    assert lvc._platform == 'Linux'
    assert fc.__name__ == 'LinuxVirtual'
    assert fc.__module__ == 'ansible.module_utils.facts.virtual.linux'

# Generated at 2022-06-11 05:52:28.964258
# Unit test for method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-11 05:52:29.991486
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()


# Generated at 2022-06-11 05:52:31.208345
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.get_virtual_facts()


# Generated at 2022-06-11 05:52:35.889513
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lxv = LinuxVirtual(module)
    virtual_facts = lxv.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    module.exit_json(changed=False, ansible_facts=dict(virtual=virtual_facts))



# Generated at 2022-06-11 05:52:38.557447
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtualCollector
    virtual_collector = LinuxVirtualCollector(None)
    assert virtual_collector._platform == 'Linux'


# Generated at 2022-06-11 05:52:48.108396
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = MagicMock()
    check_file_exists_mock = MagicMock(name='check_file_exists')
    module.check_file_exists = check_file_exists_mock
    get_file_content_mock = MagicMock(name='get_file_content')
    module.get_file_content = get_file_content_mock
    get_file_lines_mock = MagicMock(name='get_file_lines')
    module.get_file_lines = get_file_lines_mock
    get_bin_path_mock = MagicMock(name='get_bin_path')
    module.get_bin_path = get_bin_path_mock
    run_command_mock = MagicMock(name='run_command')
    module.run

# Generated at 2022-06-11 05:52:50.418668
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual = LinuxVirtual()
    assert virtual
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts
