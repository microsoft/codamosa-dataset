

# Generated at 2022-06-23 02:13:49.637095
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    data = linux_virtual.populate()
    assert 'virtualization_type' in data


# Generated at 2022-06-23 02:13:50.323866
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    assert LinuxVirtual()

# Generated at 2022-06-23 02:13:55.423151
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facter_runner = FacterRunner()
    virtual_collector = LinuxVirtualCollector(facter_runner)
    assert virtual_collector._module == facter_runner
    assert virtual_collector._platform == 'Linux'
    assert virtual_collector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:13:59.832402
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    lv = LinuxVirtual(module)

    assert lv.module == module

# Generated at 2022-06-23 02:14:07.257288
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    Test.create_dir(['facts.d'])
    Test.create_file(['facts.d/virtual.fact'], '')
    virtual = LinuxVirtualCollector(dict(collect_subset=['!all', 'virtual'], module=MockModule()), None)
    assert not virtual.is_valid()
    assert virtual.get_facts() == dict()
    assert virtual.get_facts_type() == 'virtual'


# Generated at 2022-06-23 02:14:13.407981
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    platforms = ['Linux']
    # Testing platform = Linux, an object should be created
    virtual_collector = LinuxVirtualCollector(platforms, None)
    assert virtual_collector is not None
    # Testing platform = Windows, the object should be set to None
    platforms = ['Windows']
    virtual_collector = LinuxVirtualCollector(platforms, None)
    assert virtual_collector is None



# Generated at 2022-06-23 02:14:22.111094
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(test_module)
    facts = lv.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert len(facts['virtualization_tech_guest']) == 1
    assert len(facts['virtualization_tech_host']) == 0



# Generated at 2022-06-23 02:14:29.979696
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """ Test :meth: `ansible.module_utils.facts.system.linux.get_virtual_facts`
    """
    # construct a mock module
    module = AnsibleModule(
        argument_spec={},
    )
    # instantiate a WindowsSystem facts class with the mock module as
    # argument
    win_sys_virtual = LinuxVirtual(module)
    # call the get_virtual_facts method with valid argument
    win_sys_virtual_virtual_facts = win_sys_virtual.get_virtual_facts()
    # Test virtual_facts return
    assert win_sys_virtual_virtual_facts['virtualization_type'] == 'NA'
    assert win_sys_virtual_virtual_facts['virtualization_role'] == 'NA'
    assert win_sys_virtual_virtua

# Generated at 2022-06-23 02:14:31.939085
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.fact_class == LinuxVirtual
    assert collector.platform == 'Linux'

# Generated at 2022-06-23 02:14:33.781869
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert(linux_virtual is not None)


# Generated at 2022-06-23 02:14:38.685342
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Test get_virtual_facts with no details
    # This will prevent any failure in case of missing information
    inst = LinuxVirtual()
    facts = inst.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert facts['virtualization_type'] == 'NA'
    assert facts['virtualization_role'] == 'NA'


# Generated at 2022-06-23 02:14:39.546500
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # TODO: write
    pass


# Generated at 2022-06-23 02:14:49.283936
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    vm = LinuxVirtual()
    vm.module.get_bin_path = MagicMock(return_value=1)

# Generated at 2022-06-23 02:14:53.607502
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    setattr(module, '_ansible_no_log', False)
    vm = LinuxVirtual(module)
    facts = vm.get_virtual_facts()
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts


# Generated at 2022-06-23 02:14:57.914286
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''test constructor of class LinuxVirtual'''
    # pylint: disable=W0212
    module = MockModule()
    linux_virtual = LinuxVirtual(module)
    for attr in ('module', 'is_virtual'):
        if not hasattr(linux_virtual, attr):
            raise AssertionError('%s not found' % attr)


# Generated at 2022-06-23 02:15:00.838427
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Unit test for get_virtual_facts method
    '''
    virtual = LinuxVirtual()
    result = virtual.get_virtual_facts()
    assert isinstance(result, dict)
    assert result


# Generated at 2022-06-23 02:15:06.036680
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # input arguments for the module

    # initialization method is called with an empty dict
    linux_virtual_obj = LinuxVirtual(dict())
    # get system virtualization facts
    facts = linux_virtual_obj.get_virtual_facts()
    print(facts)

if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:15:17.169197
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """ Perform unit test for constructor of class LinuxVirtual """
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    import ansible.module_utils.facts.virtual.linux_virtual as virtual_helper

    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Set up class
    selected_virtual_platform = virtual_helper.get_platform_virtual(test_module)
    selected_virtual_platform = selected_virtual_platform or {}
    selected_virtual_platform['platform'] = 'Linux'
    virtual_platform_class = selected_virtual_platform.get('class') or LinuxVirtual
    virtual_platform = virtual_platform_class(test_module)

    # Check that class variables are set correctly

# Generated at 2022-06-23 02:15:21.358498
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert isinstance(lvc.facts, LinuxVirtual)
    assert lvc.platform in VirtualCollector.registry

# Generated at 2022-06-23 02:15:27.973842
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    linux_virtual = LinuxVirtual(module=module)
    result = linux_virtual.get_virtual_facts(module)
    assert isinstance(result, dict)
    assert 'virtualization_role' in result
    assert 'virtualization_type' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result

# Generated at 2022-06-23 02:15:36.450130
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lv = LinuxVirtual(module)

    # No dmidecode available for testing
    module.get_bin_path = MagicMock(return_value=None)

    virtual_facts = lv.get_virtual_facts()
    assert "virtualization_type" in virtual_facts
    assert "virtualization_role" in virtual_facts
    assert "virtualization_tech_host" in virtual_facts
    assert "virtualization_tech_guest" in virtual_facts
    assert "virtualization_tech_host" in virtual_facts
    assert "virtualization_tech_guest" in virtual_facts

# Unit test class for module

# Generated at 2022-06-23 02:15:42.418970
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Constructor for class LinuxVirtual
    '''
    module_mock = AnsibleModuleMock()
    linuxvirtual_obj = LinuxVirtual(module_mock)
    assert linuxvirtual_obj.module == module_mock


# Generated at 2022-06-23 02:15:50.478630
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Test get_virtual_facts function from module ModuleUtils/facts/system/linux_virtual
    '''
    # Create object for testing
    linux_virtual_obj = LinuxVirtual()

    # Mock module.run_command method
    module_run_command_mock = MagicMock(return_value=(0,"controllername\n",""))
    linux_virtual_obj.module.run_command = module_run_command_mock

    # Mock get_file_lines method

# Generated at 2022-06-23 02:15:56.762669
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    class TestModule():
        def __init__(self,params={}):
            self.params = params

        def get_bin_path(self, cmd, opts=None, chk_sudo=False):
            return None

        def run_command(cmd):
            return (0, '', '')

    class TestAnsibleModule():
        def __init__(self, params={}):
            self.params = params
            self.fail_json = lambda *args, **kwargs: exit(1)
            self.exit_json = lambda *args, **kwargs: exit(1)

    my_obj = LinuxVirtual(TestAnsibleModule(params={}))

    if (my_obj.get_virtual_facts() is not None):
        pass


# Generated at 2022-06-23 02:16:07.241904
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    if not HAS_UNAME:
        module.fail_json(msg="uname or uname -m required for this module")
    if not HAS_SYS_INFO:
        module.fail_json(msg="sysinfo required for this module")
    if not HAS_SYS_HYPERVISOR:
        module.fail_json(msg="sys_hypervisor required for this module")
    if not HAS_DMI:
        module.fail_json(msg="dmi required for this module")
    if not HAS_CPUINFO:
        module.fail_json(msg="cpuinfo required for this module")
    if not HAS_PROC_STAT:
        module.fail_json(msg="proc_stat required for this module")

    obj = LinuxVirtual

# Generated at 2022-06-23 02:16:16.068395
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    data = {
            'virtualization_type': 'some_type',
            'virtualization_role': 'some_role',
            }
    values = {
            'virtualization': data,
            'virtual_facts': data,
            }
    module = FakeModule(values)
    linux_virtual = LinuxVirtual(module)
    result = linux_virtual.get_virtual_facts()
    assert result == data

# Generated at 2022-06-23 02:16:19.731969
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    facts = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    module = LinuxVirtual(facts, False)
    print(module.get_virtual_facts())
# Unit test of class LinuxVirtual


# Generated at 2022-06-23 02:16:21.752962
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x._platform == 'Linux'



# Generated at 2022-06-23 02:16:24.186153
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    is_linux_virtual = LinuxVirtual(module)
    assert is_linux_virtual


# Generated at 2022-06-23 02:16:27.326301
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Constructor test of class LinuxVirtualCollector
    """
    virtual = LinuxVirtualCollector()
    # Virtualization is None since it will be initialized later
    assert virtual._platform == 'Linux'


# Generated at 2022-06-23 02:16:30.634353
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    pl = LinuxVirtualCollector()
    assert pl._fact_class.__name__ == 'LinuxVirtual'
    assert pl._platform == 'Linux'

# Generated at 2022-06-23 02:16:41.099049
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
    )
    d = { 'virtualization_lib': 'linux', }
    l = LinuxVirtual(m)
    v = l.get_virtual_facts(d)
    assert bool(v)
    assert 'virtualization_lib' in v
    assert v['virtualization_lib'] == 'linux'
    assert 'virtualization_type' in v
    assert 'virtualization_role' in v
    assert 'virtualization_tech_guest' in v
    assert 'virtualization_tech_host' in v
    assert v['virtualization_tech_guest'] == set()
    assert v['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:16:45.160873
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    linux_virtual_collector = LinuxVirtualCollector(module)
    assert linux_virtual_collector._fact_class == LinuxVirtual
    assert linux_virtual_collector._platform == 'Linux'


# Generated at 2022-06-23 02:16:47.666770
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector.get_platform() == 'Linux'

# Generated at 2022-06-23 02:16:51.099367
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()

    assert isinstance(lv.selected_host_facts, dict)
    assert isinstance(lv.selected_guest_facts, dict)

    assert isinstance(lv.host_facts, dict)
    assert isinstance(lv.guest_facts, dict)


# Generated at 2022-06-23 02:16:54.157529
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_module = AnsibleModule(argument_spec={})
    obj = LinuxVirtual(test_module)
    result = obj.get_virtual_facts()
    assert isinstance(result, dict)

# Generated at 2022-06-23 02:17:06.425138
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lv = LinuxVirtual(module)

    # Set up the mocks
    failed_read = False
    failed_write = False

    def mock_run_command(self, cmd, check_rc=False):
        out = 'output'
        err = 'error'
        rc = 0
        if cmd == ['/bin/cat', '/proc/cpuinfo']:
            if failed_read:  # Every other time
                rc = 1
                err = 'Failed to read /proc/cpuinfo'
        return rc, out, err

    def mock_get_file_lines(self, filename):
        if filename == '/proc/cpuinfo':
            if failed_read:
                return []
            else:
                return

# Generated at 2022-06-23 02:17:11.675070
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test :meth:`insights.parsers.get_virtual_facts.LinuxVirtual._get_virtual_facts`
    """
    module = AnsibleModule(argument_spec={})
    obj = LinuxVirtual(module)
    out = obj._get_virtual_facts()
    assert out['virtualization_type'] == 'NA'

# Generated at 2022-06-23 02:17:21.156673
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/bin/lscpu'
    linux_virtual = LinuxVirtual(module)

# Generated at 2022-06-23 02:17:23.885374
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert linux_virtual.linux_distribution is not None
    assert linux_virtual.module



# Generated at 2022-06-23 02:17:32.779182
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec=dict())
    facts = LinuxVirtualCollector(module=module).collect()
    assert isinstance(facts['ansible_virtual'], dict)
    assert isinstance(facts['ansible_virtual']['virtualization_type'], str)
    assert isinstance(facts['ansible_virtual']['virtualization_role'], str)
    assert isinstance(facts['ansible_virtual']['virtualization_tech_host'], set)
    assert isinstance(facts['ansible_virtual']['virtualization_tech_guest'], set)

# Generated at 2022-06-23 02:17:34.120876
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert lv is not None

# Generated at 2022-06-23 02:17:44.078010
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    from ansible.module_utils.facts.virtual.linux_virtual import get_file_content
    from ansible.module_utils.facts.virtual.linux_virtual import get_file_lines
    from ansible.module_utils.facts.virtual.linux_virtual import uniq
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import get_distribution
    from ansible.module_utils.facts.system.distribution import get_linux_distribution
    from ansible.module_utils.facts.system.distribution import get_redhatish_release_file
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 02:17:47.368160
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert isinstance(lvc, VirtualCollector)
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'


# Generated at 2022-06-23 02:17:53.777194
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    import sys
    from ansible.module_utils.facts.collector.base import TestAnsibleModule
    from ansible.module_utils.facts import ansible_collector

    module = TestAnsibleModule(disable_debugger=True)
    sys.modules['ansible_collections.ansible.community.plugins.module_utils.facts.collector.linux'] = ansible_collector
    virtual_collec_obj = LinuxVirtualCollector(module)
    assert virtual_collec_obj.__class__.__name__ == 'LinuxVirtualCollector'



# Generated at 2022-06-23 02:18:04.511233
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import os
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.plugins.module_utils._text import to_bytes

    class TestLinuxVirtual(unittest.TestCase):
        def setUp(self):
            self.mock_module = patch.object(basic.AnsibleModule, 'exit_json')
            self.mock_module.start()
            self.addCleanup(self.mock_module.stop)
            self.mock_run_command = patch.object(basic.AnsibleModule, 'run_command')
            self.mock_run_command.start()

# Generated at 2022-06-23 02:18:09.244520
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert linux_virtual.platform == 'Linux', 'Wrong platform'
    assert linux_virtual.distribution is None, 'Wrong distribution'



# Generated at 2022-06-23 02:18:18.160064
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    def get_test_content(test_file):
        return test_file.content if test_file else None
    test_obj = LinuxVirtual(dict(
        get_file_content=get_test_content,
        get_file_lines=lambda test_file: test_file.content.splitlines() if test_file else [],
        stat=lambda test_file: os.stat(test_file.name) if test_file else None,
        path_exists=lambda test_file: True if test_file else False,
        lsb_release=dict(distributor_id='Debian', major_release='8', description='Debian GNU/Linux'),
        get_bin_path=lambda binary: '/bin/' + binary,
    ))
    # The 'sys_vendor' value in the test cases is not used in the

# Generated at 2022-06-23 02:18:19.914485
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = VirtualCollector(None, 'Linux')
    assert isinstance(vc, LinuxVirtualCollector)

# Generated at 2022-06-23 02:18:25.577568
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Test creating the class
    virtual_facts = LinuxVirtualCollector()

    # Test constructor by ensuring internal class is created
    assert isinstance(virtual_facts, VirtualCollector)
    assert isinstance(virtual_facts, LinuxVirtualCollector)
    assert isinstance(virtual_facts._fact_class, LinuxVirtual)
    assert virtual_facts._platform == 'Linux'


# Generated at 2022-06-23 02:18:27.541315
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    coll = LinuxVirtualCollector()
    assert coll._fact_class == LinuxVirtual
    assert coll._platform == 'Linux'

# Generated at 2022-06-23 02:18:31.277207
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleStub()
    c = LinuxVirtualCollector(module=module)
    assert c._platform == 'Linux'
    assert isinstance(c._fact_class(module), LinuxVirtual)

############################################################################
#   Darwin VirtualCollector
############################################################################

# Generated at 2022-06-23 02:18:44.238740
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.exit_json = exit_json
    module.fail_json = fail_json
    lv = LinuxVirtual(module)

    # Valid
    with open(os.path.join(filedir, 'files/proc_1_cgroup')) as f:
        mock_get_file_content.return_value = f.read()
    with open(os.path.join(filedir, 'files/proc_self_status')) as f:
        mock_get_file_lines.return_value = f.readlines()
    with open(os.path.join(filedir, 'files/proc_cpuinfo')) as f:
        mock_get_file_lines.return_value = f.readlines()

# Generated at 2022-06-23 02:18:51.666200
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # This code will let you run unit test for method 'get_virtual_facts' from class 'LinuxVirtual' without installing the module
    # Load Ansible module
    from ansible.module_utils.basic import AnsibleModule
    # Create a simple dummy module
    module = AnsibleModule({}, {}, supports_check_mode=False)

    # Load virtual.py
    exec(open('/home/bts/ansible-modules-extras/system/virtual.py').read())

    # Create an instance of the class 'LinuxVirtual'
    lv = LinuxVirtual(module)

    # Call method 'get_virtual_facts'
    print("Result of 'get_virtual_facts' is: " + str(lv.get_virtual_facts()))


# Generated at 2022-06-23 02:18:54.363340
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    m = AnsibleModule(argument_spec=dict())
    f = LinuxVirtual(m)

    # Add assertions here


# Generated at 2022-06-23 02:19:01.989350
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Return a LinuxVirtual object'''
    module = AnsibleModule(argument_spec=dict())
    if not HAS_LIBVIRT:
        module.fail_json(msg='libvirt module required for this module')
    obj = LinuxVirtual(module)
    module.exit_json(ansible_facts={'virtualization': obj.get_virtual_facts()})

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:19:11.752916
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import LinuxVirtual
    from ansible.module_utils.facts import FactCache
    from mock import MagicMock, patch
    virt_obj = MagicMock()
    virt_obj.module = MagicMock()
    virt_obj.module.run_command.return_value = (0, 'test_data', '')
    virt_obj.cachefile = 'test_data'
    with patch.object(FactCache, '_is_cachefile_valid', return_value=True):
        with patch.object(FactCache, '_load_facts_from_cache', return_value=None):
            with patch.object(FactCache, '_write_cache_file', return_value=None):
                virt_obj.get_virtual_facts()

# Generated at 2022-06-23 02:19:23.231935
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Create a mock module
    mock_module = type('AnsibleModule', (), {})()

    # Instantiate the class we'll be testing
    mock_LinuxVirtual = type('LinuxVirtual', (LinuxVirtual,), {'is_linux': lambda *x: True, 'has_virt_what': lambda *x: False, 'get_bin_path': lambda *x: None})
    mock_LinuxVirtual = mock_LinuxVirtual()

    # Make sure we return something for each possible branch (from get_virtual_facts)
    mock_LinuxVirtual.get_file_content = lambda *x: None

# Generated at 2022-06-23 02:19:29.524830
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    test_module = AnsibleModule(argument_spec=dict())
    test_linux_virtual = LinuxVirtual(test_module)
    assert os.path.exists('/proc')
    assert test_linux_virtual.data is not None
    assert test_linux_virtual.data.get('virtualization_type') is not None
    assert test_linux_virtual.data.get('virtualization_role') is not None


# Generated at 2022-06-23 02:19:31.424951
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virt = LinuxVirtualCollector(None)
    assert isinstance(virt._collector, LinuxVirtual)
    assert virt._platform == 'Linux'


# Generated at 2022-06-23 02:19:32.537489
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-23 02:19:42.008394
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """ Simple test for method LinuxVirtual.get_virtual_facts(module) """
    from ansible.module_utils.facts import ModuleBase
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.facts import ansible_virtual as virtual
    from ansible_collections.ansible.community.tests.unit.units.compat import unittest
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    module = MockAnsibleModule()
    set_module_args(dict(gather_subset='virtual'))

    result = virtual.get_virtual_facts(module)

    class TestLinuxVirtual(unittest.TestCase):
        """ A group of related Unit Tests. """

# Generated at 2022-06-23 02:19:44.466116
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()

    assert lvc._fact_class.__name__ == LinuxVirtual.__name__
    assert lvc._platform == 'Linux'

# Generated at 2022-06-23 02:19:51.609443
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual test class for testing methods
    """
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=False
    )

    lxvirt_obj = LinuxVirtual(module)
    lxvirt_obj.get_all_facts()


# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.urls import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:19:59.196070
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # create an instance of the class LinuxVirtualCollector
    collect = LinuxVirtualCollector()
    # check to see if the instance was created properly
    assert isinstance(collect, LinuxVirtualCollector)
    # check to see if it is subclassed correctly
    assert issubclass(LinuxVirtualCollector, VirtualCollector)
    # check to see if the variable names match the class variables
    assert collect._fact_class == LinuxVirtual
    assert collect._platform == 'Linux'

# Generated at 2022-06-23 02:20:01.597829
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert isinstance(lvc, LinuxVirtualCollector)
    assert isinstance(lvc.facts, LinuxVirtual)


# Generated at 2022-06-23 02:20:10.388719
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Test for standard 'host' output
    virtual_facts = LinuxVirtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'

    # Test for standard 'guest' output
    virtual_facts = LinuxVirtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'

    # Test for 'host' output when lve is installed
    virtual_facts = LinuxVirtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:20:14.153640
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)
    module.exit_json(changed=False, ansible_facts=dict(virtual_facts=lv.run()))


# Generated at 2022-06-23 02:20:25.574793
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class ModuleMock(object):
        def get_bin_path(self, arg):
            return arg
        def run_command(self, arg):
            return(0, '', '')
    test = LinuxVirtual(ModuleMock())
    test.module.run_command = MagicMock(return_value=(0, 'systemd', ''))
    test.get_file_lines = MagicMock(return_value=['a','b','c'])
    test.get_file_content = MagicMock(return_value='systemd')
    test.get_supported_filesystems = MagicMock(return_value=['a','b','c'])
    test.get_uname_info = MagicMock(return_value=['a','b','c'])
    test.module.get_bin_path = MagicM

# Generated at 2022-06-23 02:20:27.292396
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    assert isinstance(LinuxVirtual(), LinuxVirtual)


# Generated at 2022-06-23 02:20:34.270107
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test module for virtual facts
    """

    # Create a mock object of 'LinuxVirtual' class, without actually
    # creating the class.
    module = LinuxVirtual(dict())
    # Get the mock object's 'get_virtual_facts' method's return value
    virtual_facts = module.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_type'] == 'NA'


# Generated at 2022-06-23 02:20:40.444742
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual({})
    assert lv.get_virtual_facts() == {
        'virtualization_type': 'NA',
        'virtualization_role': 'NA',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }



# Generated at 2022-06-23 02:20:46.265586
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual_facts = {}
    linux_virtual_ins = LinuxVirtual(virtual_facts)
    assert isinstance(linux_virtual_ins, LinuxVirtual)
    assert virtual_facts == {}


# Generated at 2022-06-23 02:20:48.920653
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert(linux_virtual is not None)


# Generated at 2022-06-23 02:20:55.641570
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Setup
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, '', ''))
    linuxvirt = LinuxVirtual(module)

    # Run
    result = linuxvirt.get_virtual_facts()

    # Verify
    assert result == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_role': 'NA',
        'virtualization_type': 'NA',
    }

# Generated at 2022-06-23 02:20:59.101770
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    with patch.multiple(lv,
                        get_file_content=DEFAULT,
                        get_file_lines=DEFAULT):
        lv.get_virtual_facts()



# Generated at 2022-06-23 02:21:01.606646
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector(None)
    assert collector._fact_class.__name__ == 'LinuxVirtual'
    assert collector._platform == 'Linux'

# Generated at 2022-06-23 02:21:04.584766
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    mod = AnsibleModule({})
    virt = LinuxVirtual(mod)
    assert isinstance(virt, LinuxVirtual)

    virt = LinuxVirtual(mod)
    assert isinstance(virt.get_virtual_facts(), dict)


# Generated at 2022-06-23 02:21:07.288112
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual

# Generated at 2022-06-23 02:21:11.412863
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._fact_class.__name__ == 'LinuxVirtual'
    assert lvc._platform == 'Linux'


# Generated at 2022-06-23 02:21:13.205977
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual = LinuxVirtual()
    assert virtual.__class__.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:21:21.842153
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    cpu_num = psutil.cpu_count()
    mem = psutil.virtual_memory()
    vm_test = LinuxVirtual(module=None, collector=None)
    assert vm_test.memtotal == mem.total
    assert vm_test.memfree == mem.free
    assert vm_test.memcached == mem.cached
    assert vm_test.membuffers == mem.buffers
    assert vm_test.swaptotal == psutil.swap_memory().total
    assert vm_test.swapfree == psutil.swap_memory().free
    assert vm_test.swapcached == psutil.swap_memory().cached
    assert vm_test.virt_type == 'NA'
    assert vm_test.virt_role == 'NA'
    assert vm_test.virt_tech_guest

# Generated at 2022-06-23 02:21:25.525776
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    all_facts = linux_virtual.populate()
    assert all_facts is not None


# Generated at 2022-06-23 02:21:26.993537
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    LinuxVirtual()


# Generated at 2022-06-23 02:21:36.245790
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import pytest
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual

    path_exists_mock = mock.mock_open(read_data='')
    path_exists_mock.return_value.__iter__ = lambda self: self
    path_exists_mock.return_value.__next__ = lambda self: next(iter(self.readline, ''))
    path_exists_mock.return_value.read = lambda x: ''
    path_exists_mock.return_value.readline = lambda x: ''
    path_exists_mock.return_value.readlines = lambda x: []


# Generated at 2022-06-23 02:21:47.511237
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    sys_vendor = get_file_content('/sys/devices/virtual/dmi/id/sys_vendor')
    product_family = get_file_content('/sys/devices/virtual/dmi/id/product_family')
    if sys_vendor == 'Red Hat':
        if product_family == 'RHV':
            virtual = LinuxVirtual(module)
            if virtual.virtual == {
                'virtualization_type': 'RHV',
                'virtualization_role': 'guest',
                'virtualization_tech_guest': set(['RHV', 'container']),
                'virtualization_tech_host': set([])
            }:
                print("SUCCESS: constructor test succeeded as expected")

# Generated at 2022-06-23 02:21:49.094512
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test method LinuxVirtual._get_virtual_facts
    """
    assert True

# Generated at 2022-06-23 02:21:56.641798
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModuleMock()
    os_obj = LinuxVirtual(module)
    assert isinstance(os_obj, LinuxVirtual)
    if os.path.exists('/sys/devices/virtual/dmi/id/product_name'):
        assert type(os_obj.get_virtual_facts()) is dict
    else:
        assert type(os_obj.get_virtual_facts()) is NoneType

# Collect all facts from this file
# This function is the "entry point" defined in ansible mapping file
# The result of this function will be stored in ansible "facts".

# Generated at 2022-06-23 02:22:05.681704
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = AnsibleModule({})
    lv.module.run_command = Mock(return_value=(1, '', ''))
    lv.module.get_bin_path = Mock(return_value='/bin/true')
    lv.get_file_content = Mock(return_value="")
    lv.get_file_lines = Mock(return_value="")
    lv.get_file_lines = Mock(return_value="")
    lv.get_file_lines = Mock(return_value="")
    lv.get_file_lines = Mock(return_value="")
    lv.get_file_lines = Mock(return_value="")
    lv.get_file_lines = Mock(return_value="")
    lv.get_

# Generated at 2022-06-23 02:22:07.969938
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virt = LinuxVirtual()
    assert isinstance(virt, LinuxVirtual)
    assert not virt.is_virtual


# Generated at 2022-06-23 02:22:10.763391
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    assert LinuxVirtual().virtual()['virtualization_type'] == 'NA'
    assert LinuxVirtual().virtual()['virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:22:21.306280
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Test instance creation
    try:
        instance = LinuxVirtualCollector()
    except Exception as e:
        assert False, "Could not create VirtualCollector instance: " + str(e)

    # Test if the class attribute '_fact_class' is properly set to the class of which this class is a subclass
    assert LinuxVirtualCollector._fact_class == LinuxVirtual, "Class attribute '_fact_class' not properly set"

    # Test if parent class is properly inherited
    assert isinstance(instance, VirtualCollector), "Parent class (VirtualCollector) not properly inherited"

    # Test if the class attribute '_platform' is properly set (for the parent class)
    assert instance._platform == 'Linux', "Class attribute '_platform' of parent class not properly set"

    # Finally, assert that no exception was raised
    assert True

# Generated at 2022-06-23 02:22:24.173507
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    LinuxVirtual_test_obj = LinuxVirtual()
    results = LinuxVirtual_test_obj.get_virtual_facts()
    return results


# Generated at 2022-06-23 02:22:31.737583
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    virtual_facts = lv.get_virtual_facts()
    assert isinstance(virtual_facts, dict), 'virtual_facts needs to be a dict'
    assert len(virtual_facts) > 1, 'Need more than just constructors return value'
    assert 'virtualization_role' in virtual_facts, 'virtualization_role key missing'
    assert 'virtualization_type' in virtual_facts, 'virtualization_type key missing'


# Generated at 2022-06-23 02:22:37.505176
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    with pytest.raises(Exception) as exc_info:
        LinuxVirtualCollector()
    assert "missing required argument" in str(exc_info.value)

    with pytest.raises(Exception) as exc_info:
        LinuxVirtualCollector(module=None)
    assert "missing required argument" in str(exc_info.value)

    x = LinuxVirtualCollector(module=AnsibleModule(argument_spec=dict(), supports_check_mode=False))
    assert x is not None

# Generated at 2022-06-23 02:22:42.094265
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Constructor test of class LinuxVirtualCollector
    """
    virtual_collector_linux = LinuxVirtualCollector()
    assert virtual_collector_linux._platform == 'Linux', "Platform is not Linux"

# Generated at 2022-06-23 02:22:53.155244
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Initialize test data
    linux_virtual = LinuxVirtual(True, True, True, True, True, True)
    facts = {}

    # Mock get_file_content
    def mock_get_file_content(filename):
        if filename in ['/sys/class/dmi/id/product_name', '/sys/class/dmi/id/sys_vendor', '/sys/class/dmi/id/product_family', '/sys/devices/virtual/dmi/id/product_name', '/sys/devices/virtual/dmi/id/sys_vendor']:
            return 'abc'
        return '/proc/1/cgroup'


# Generated at 2022-06-23 02:22:56.675346
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj is not None


# Generated at 2022-06-23 02:23:02.770392
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    unit test for get_virtual_facts
    '''
    # Testing without parameters
    module = AnsibleModule(argument_spec={})
    lv_obj = LinuxVirtual(module)
    virtual_facts = lv_obj.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'virtualbox'


# Generated at 2022-06-23 02:23:04.825037
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # This is required to be implemented as a unittest

    # tests will be added to the module
    pass

# Generated at 2022-06-23 02:23:07.817820
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    collector = LinuxVirtualCollector(module)
    result = collector.collect()
    assert result is not None



# Generated at 2022-06-23 02:23:17.512965
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual

    mymodule = basic.AnsibleModule(argument_spec=dict())
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'NA'
    virtual_facts['virtualization_role'] = 'NA'
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    assert LinuxVirtual(mymodule, virtual_facts).collect() == virtual_facts

# Generated at 2022-06-23 02:23:25.364859
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    v = LinuxVirtual()
    iv = v.get_virtual_facts()
    assert 'virtualization_type' in iv, "Virtualization type not found"
    assert iv['virtualization_type'] != 'NA', "'NA' virtualization type found"
    assert 'virtualization_role' in iv, "Virtualization role not found"
    assert iv['virtualization_role'] != 'NA', "'NA' virtualization role found"

# unit test for get_file_content()

# Generated at 2022-06-23 02:23:29.055308
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the construction of the LinuxVirtual class
    """

    virt_facts = LinuxVirtual()
    assert virt_facts is not None


# Generated at 2022-06-23 02:23:31.010629
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    l = LinuxVirtual()
    assert l.any_virtual
    assert l.hypervisor
    assert l.virtual_role

# Generated at 2022-06-23 02:23:34.812252
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector()
    assert virtual.__class__ == VirtualCollector
    assert virtual._platform == 'Linux'
    assert virtual._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:23:37.736724
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():

    virtual_collector = LinuxVirtualCollector(None)

    assert virtual_collector.platform == 'Linux'
    assert virtual_collector.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:23:42.277992
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert c
    assert is_subclass(c.virtual_facts._fact_class, LinuxVirtual)
    assert c.virtual_facts._platform == 'Linux'
    assert c.virtual_facts._fact_class.__name__ == 'LinuxVirtual'



# Generated at 2022-06-23 02:23:52.365269
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    lv = LinuxVirtual()

    module = MagicMock()
    lv.module = module

    module.get_bin_path = MagicMock(return_value = False)
    lv.get_file_lines = MagicMock(return_value = ['systemd-nspawn', 'docker'])
    lv.get_file_content = MagicMock(return_value = 'docker')
    out = lv.get_virtual_facts()
    assert out == {'virtualization_type': 'docker', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['docker', 'systemd-nspawn', 'container']), 'virtualization_tech_host': set(['docker'])}

    module.get_bin_path = MagicMock(return_value = False)
    lv.get