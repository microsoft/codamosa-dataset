

# Generated at 2022-06-23 02:13:47.440172
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virt_obj = LinuxVirtual()
    result = virt_obj.get_virtual_facts()
    print(result)
    result = virt_obj.get_virtual_facts()
    print(result)


# Generated at 2022-06-23 02:13:51.945417
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    import platform
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import cache
    import pytest

    # Instantiate object
    LinuxVirtualCollectorObj = LinuxVirtualCollector()

    # Unit test for _fact_class attribute
    assert LinuxVirtualCollectorObj._fact_class == LinuxVirtual

    # Unit test for _platform attribute
    assert LinuxVirtualCollectorObj._platform == 'Linux'

    # Value for self.platform
    linux_platform = 'Linux'

    # Value for fact_class
    fact_class = LinuxVirtual

    # Value for fact_subclass
    fact_subclass = 'Virtual'

    # Value for subclass
    LinuxVirtualCollector_subclass = 'virtual'

    # Value for name
    LinuxVirtualCollector_name = 'virtual'

    # Value for

# Generated at 2022-06-23 02:13:57.816032
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    args = {}
    args['ansible_facts'] = ''
    args['module'] = 'test'
    # Create an instance of LinuxVirtual class
    LinuxVirtualObj = LinuxVirtual()
    # Get virtual facts into a variable
    Virtual_facts = LinuxVirtualObj.get_virtual_facts(args)
    assert Virtual_facts


# Generated at 2022-06-23 02:14:00.155739
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linvirt = LinuxVirtual()
    assert linvirt.get_virtual_facts() == {
    'virtualization_tech_host': set(['kvm']),
    'virtualization_type': 'kvm',
    'virtualization_role': 'guest',
    'virtualization_tech_guest': set(['kvm'])
    }



# Generated at 2022-06-23 02:14:02.136434
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test whether LinuxVirtualCollector is properly initialized
    """
    lv = LinuxVirtualCollector()
    assert lv.platform == 'Linux'
    assert lv.fact_class == LinuxVirtual
    assert lv._fact_class == LinuxVirtual
    assert lv._platform == 'Linux'

# Generated at 2022-06-23 02:14:08.827986
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    facts = lv.collect()
    module.exit_json(ansible_facts=facts)

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:14:10.667754
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    assert isinstance(LinuxVirtual(module), LinuxVirtual)


# Generated at 2022-06-23 02:14:22.686467
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_plugin = LinuxVirtual()

    # get_file_content should return the content of the file
    (rc,out,err) = virtual_plugin.module.run_command("echo hello",check_rc=False)
    assert virtual_plugin.get_file_content("/tmp/test") == 'hello'

    # get_file_lines should return the content of the file
    assert virtual_plugin.get_file_lines("/tmp/test") == ['hello']

    # Invalid scenario: when lsattr command is not available in PATH
    assert virtual_plugin.get_virtual_facts()['virtualization_type'] == 'NA'

    # Invalid scenario: when dmidecode command is not available in PATH
    assert virtual_plugin.get_virtual_facts()['virtualization_type'] == 'NA'

    # Invalid scenario: when lscpu

# Generated at 2022-06-23 02:14:34.374915
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    module.params['ansible_facts'] = {}
    module.params['ansible_facts']['ansible_virtualization_role'] = 'guest'
    module.params['ansible_facts']['ansible_virtualization_type'] = 'virtualbox'
    module.params['ansible_facts']['ansible_virtualization_tech_guest'] = set(['virtualbox'])
    module.params['ansible_facts']['ansible_virtualization_tech_host'] = set(['virtualbox'])
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert ('ansible_virtualization_role' in virtual_facts)

# Generated at 2022-06-23 02:14:36.540978
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vm = LinuxVirtualCollector()
    assert vm._platform == 'Linux'
    assert vm._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:14:44.095665
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class LinuxVirtualMock:
        def get_bin_path(self, foo):
            return None
        def run_command(self, command):
            out = 'model name  : x86_64'
            return 0, out, ''
    class ModuleMock:
        def get_bin_path(self, foo):
            return '/usr/bin/dmidecode'
    module = ModuleMock()
    linux_virtual = LinuxVirtual(module)
    linux_virtual.get_virtual_facts()
    assert linux_virtual.virtual_facts['virtualization_type'] == 'NA'
    assert linux_virtual.virtual_facts['virtualization_role'] == 'NA'
    assert linux_virtual.virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:14:50.150314
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the LinuxVirtual constructor.

    This function is not a real unit test.  It assists in manual testing of
    the LinuxVirtual constructor.  If the constructor raises an exception,
    the unit test will fail and present a traceback.
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
    )

    lv = LinuxVirtual(module)
    facts = lv.populate()
    for fact in facts:
        print("{0}: {1}".format(fact, facts[fact]))


# Generated at 2022-06-23 02:14:54.994028
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # test virt-what
    lv = LinuxVirtual()

    lv.module.run_command = Mock(side_effect=[(0, 'example', '')])
    lv.get_virtual_facts()
    lv.module.run_command.assert_called_with('virt-what')

    lv.module.run_command = Mock(side_effect=[(1, '', 'error')])
    lv.get_virtual_facts()
    lv.module.run_command.assert_called_with('virt-what')
    # test normal output
    lv.module.run_command = Mock(side_effect=[(0, 'lxc\nkvm\n', '')])
    facts = lv.get_virtual_facts()
    # In case multiple output from virt-what, first is considered to be

# Generated at 2022-06-23 02:15:03.576658
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = MagicMock()
    fd, tmp_file = tempfile.mkstemp(dir='/tmp')
    expected_facts = {
                  'virtualization_type':'kvm',
                  'virtualization_role':'host',
                  'virtualization_tech_host': set(['kvm']),
                  'virtualization_tech_guest': set(),
                 }
    with open(tmp_file, "w") as fh:
        fh.write("/1:name=systemd:/user.slice/user-1000.slice/user@1000.service/docker\n")

# Generated at 2022-06-23 02:15:06.796865
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test constructor of LinuxVirtualCollector class"""
    my_obj = LinuxVirtualCollector()
    assert my_obj.platform == 'Linux'
    assert my_obj.fact_class == LinuxVirtual

# Generated at 2022-06-23 02:15:09.132867
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vcol = LinuxVirtualCollector()
    assert vcol._fact_class == LinuxVirtual
    assert vcol._platform == 'Linux'


# Generated at 2022-06-23 02:15:13.106040
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the constructor of class LinuxVirtual
    """
    module = AnsibleModule(argument_spec={})
    is_linux_virtual_obj = LinuxVirtual(module)
    assert is_linux_virtual_obj


# Generated at 2022-06-23 02:15:14.572036
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert 'Linux' == LinuxVirtualCollector._platform



# Generated at 2022-06-23 02:15:17.559377
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vobj = LinuxVirtualCollector()
    assert vobj._platform == 'Linux'
    assert vobj._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:15:18.230409
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()

# Generated at 2022-06-23 02:15:20.667206
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()


# Generated at 2022-06-23 02:15:30.589266
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule({})
    m_get_bin_path = MagicMock(return_value='/usr/bin/dmidecode')
    m_run_command = MagicMock(return_value=(0, '', ''))
    m_get_file_content = MagicMock(return_value='')
    m_get_file_lines = MagicMock(return_value='')
    m_os_path_exists = MagicMock(return_value=False)
    m_os_access = MagicMock(return_value=True)
    virtual_facts = LinuxVirtual(module)

# Generated at 2022-06-23 02:15:33.685099
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Construct class
    module = AnsibleModule(argument_spec={})
    os_obj = LinuxVirtual(module)

    # Test member variables set
    module.exit_json(changed=False, ansible_facts=os_obj.get_facts())


# Generated at 2022-06-23 02:15:39.670198
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import LinuxVirtual # pylint: disable=import-error
    module = AnsibleModule(  # pylint: disable=invalid-name
        argument_spec={},
        supports_check_mode=True,
    )
    linux_virtual = LinuxVirtual(module)  # pylint: disable=invalid-name
    assert not linux_virtual.get_virtual_facts()



# Generated at 2022-06-23 02:15:48.731741
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Arrange
    test_bin_path = '/usr/bin/printf'
    test_run_command_out = ('', '', 0)
    test_get_file_content_out = ''
    test_get_file_lines_out = []

    # Act

# Generated at 2022-06-23 02:15:50.233533
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    d = LinuxVirtual({})
    assert d is not None


# Generated at 2022-06-23 02:16:00.561138
# Unit test for method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-23 02:16:06.093668
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():

    # constructor without parameters
    module = AnsibleModule(argument_spec=dict())
    linux_virtual_obj = LinuxVirtual(module)

    # constructor with parameters
    module = AnsibleModule(argument_spec=dict())
    linux_virtual_obj = LinuxVirtual(module, facts_module=Facts(module))


# Generated at 2022-06-23 02:16:08.456233
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lv = LinuxVirtualCollector()
    assert isinstance(lv, LinuxVirtual)



# Generated at 2022-06-23 02:16:18.365665
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    virt_path = ['/bin/virt-what']
    virt_path.append('')
    path_list = ['/proc', '/dev/kvm', '/dev/vz', '/selinux', '/usr/bin/systemd-detect-virt']

    vm = LinuxVirtual(module, virt_path, path_list)

    virt_facts = vm.get_virtual_facts()

    virt_facts_dict = dict(virt_facts)

    assert virt_facts_dict['virtualization_type'] == 'virt-what'
    assert virt_facts_dict['virtualization_role'] == 'guest'
    assert 'virt-what' in virt_facts_dict['virtualization_tech_guest']


# Generated at 2022-06-23 02:16:20.815555
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    try:
        LinuxVirtualCollector()
    except Exception:
        assert False,  "Instantiation of LinuxVirtualCollector failed"


# Generated at 2022-06-23 02:16:23.173452
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """This function is to test the constructor of LinuxVirtualCollector/LinuxVirtual
    """
    assert LinuxVirtualCollector(dict()) is not None


# Generated at 2022-06-23 02:16:27.545813
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    m_module = MagicMock()
    m_fact_class = MagicMock()
    lvc = LinuxVirtualCollector(m_module, m_fact_class)

    assert lvc.module == m_module
    assert lvc.fact_class == m_fact_class



# Generated at 2022-06-23 02:16:30.941399
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    s = LinuxVirtualCollector()
    assert isinstance(s, LinuxVirtual)
    assert s._platform == 'Linux'



# Generated at 2022-06-23 02:16:41.351004
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    # Create temp dir
    tmp_dir = tempfile.mkdtemp()
    module_name = 'ansible.modules.system.linux_virtual'
    module = import_module(module_name)

    # Create a temp file to simulate a /proc/1/cgroup file
    file_path = os.path.join(tmp_dir, 'cgroup')

# Generated at 2022-06-23 02:16:45.129082
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-23 02:16:48.450312
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """This is to test the LinuxVirtual constructor"""
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module=module)
    assert linux_virtual.module is module


# Generated at 2022-06-23 02:16:53.609090
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    lvc = LinuxVirtualCollector(module=module)
    assert isinstance(lvc, VirtualCollector)
    assert isinstance(lvc, LinuxVirtualCollector)
    lvc = LinuxVirtualCollector(module=module, fact_class=LinuxVirtual)
    assert isinstance(lvc.fact, LinuxVirtual)


# Generated at 2022-06-23 02:16:56.887718
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    _mod = AnsibleModuleMockVirtFacts()
    _mod.params = {}
    _obj = LinuxVirtualCollector(_mod)
    assert _obj


# Generated at 2022-06-23 02:17:08.411286
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Test for LinuxVirtual class constructor
    '''
    import sys
    import os
    from distutils.version import LooseVersion

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = sys.exit
            self.fail_json = sys.exit
        def get_bin_path(self, name):
            if 'lscpu' in name:
                # For a test run on Travis, it does not make sense to
                # worry about lscpu.
                return name
            else:
                return None
        def run_command(self, cmd):
            if cmd == ['lscpu']:
                return (0, "", "")
            else:
                print("run_command: %s" % cmd)

# Generated at 2022-06-23 02:17:11.141011
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual(None)
    assert linux_virtual.__class__.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:17:13.810143
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    lv.get_virtual_facts()
# Unit test:
if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:17:17.936955
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json(changed=False, ansible_facts=dict(
        virtual_facts=LinuxVirtual(module).populate()
    ))

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:17:29.897336
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test with physical server
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    virtual_facts = LinuxVirtual(test_module).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'NA'
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'] == 'NA'
    assert 'virtualization_tech_guest' in virtual_facts
    assert virtual_facts['virtualization_tech_guest'] == set(['NA'])
    assert 'virtualization_tech_host' in virtual_facts
    assert virtual_facts['virtualization_tech_host'] == set(['NA'])

    # Test with guest on KVM
    test_

# Generated at 2022-06-23 02:17:36.751357
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual('/', module)
    assert lv.distribution == 'NA'
    assert lv.distribution_version == 'NA'
    assert lv.distribution_major_version == 'NA'
    assert lv.distribution_release == 'NA'
    assert lv.virtualization_type == 'NA'
    assert lv.virtualization_role == 'NA'


# Generated at 2022-06-23 02:17:40.294693
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    lvc = LinuxVirtualCollector()
    assert isinstance(lvc, VirtualCollector)
    assert lvc.fact_class._platform == 'Linux'


# Generated at 2022-06-23 02:17:49.687482
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    mc = LinuxVirtualCollector(module)
    facts = mc.collect()
    assert 'virtualization_role' in facts
    assert isinstance(facts['virtualization_role'], str)
    assert 'virtualization_type' in facts
    assert isinstance(facts['virtualization_type'], str)
    assert 'virtualization_tech_guest' in facts
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert 'virtualization_tech_host' in facts
    assert isinstance(facts['virtualization_tech_host'], set)


# Generated at 2022-06-23 02:17:58.344123
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  # check for virtualization_type virtualbox
    assert LinuxVirtual().get_virtual_facts()['virtualization_type'] == 'virtualbox'
    assert LinuxVirtual().get_virtual_facts()['virtualization_role'] == 'guest'
    assert LinuxVirtual().get_virtual_facts()['virtualization_tech_guest'] == set(['virtualbox'])
    assert LinuxVirtual().get_virtual_facts()['virtualization_tech_host'] == set([])

from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-23 02:18:00.259322
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc is not None

# Generated at 2022-06-23 02:18:09.233131
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class TestModule:
        def get_bin_path(self, module):
            return None
        def run_command(self, module):
            return 2, '', 'ERROR'

    module = TestModule()
    module.get_bin_path = MagicMock(return_value="/bin/dmidecode")

# Generated at 2022-06-23 02:18:18.134837
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    
    # Dummy class for mocking
    class DummyModule(object):
        def __init__(self):
            self.params = dict()
            self.fail_json = None
        def get_bin_path(self, arg_1, opt_arg_2=None):
            return "/bin/foo"
        def run_command(self, args, check_rc=False):
            return (0, '', '')

    # GIVEN: My mocked get_file_content()

# Generated at 2022-06-23 02:18:20.884768
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(
        argument_spec=dict()
    )

    linux_virtual_obj = LinuxVirtual(module=module)
    linux_virtual_facts = dict()
    linux_virtual_facts = linux_virtual_obj.populate()

    module.exit_json(
        ansible_facts=dict(
            linux_virtual=linux_virtual_facts
        )
    )



# Generated at 2022-06-23 02:18:23.115182
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = FakeAnsibleModule()
    f = LinuxVirtual(module)
    assert f.module == module, 'module not set correctly'

# Generated at 2022-06-23 02:18:33.492753
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    # Inject mocks to module
    module.get_bin_path = MagicMock(return_value='/bin/true')
    module.run_command = MagicMock(return_value=(0, 'output', ''))
    module.get_file_content = MagicMock(return_value='100')
    module.get_file_lines = MagicMock(return_value=['line1', 'line2'])
    virtual = LinuxVirtual(module)
    assert virtual.get_file_content('/proc/cpuinfo') == 'output'
    assert virtual.get_file_lines('/proc/cpuinfo') == ['line1', 'line2']

# Generated at 2022-06-23 02:18:36.422549
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    res = LinuxVirtual.get_virtual_facts(module)
    assert res is not None, 'unit test failed'


# Generated at 2022-06-23 02:18:38.178968
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:50.569538
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = Mock()
    lv.module.get_bin_path.return_value = '/bin/dmidecode'
    lv.module.run_command.return_value = (0, 'test_run_command', '')
    result = lv.get_virtual_facts()
    assert result == {'virtualization_type': 'test_run_command',
                      'virtualization_role': 'NA',
                      'virtualization_tech_guest': set(),
                      'virtualization_tech_host': set()}
    lv.module.run_command.return_value = (1, 'test_run_command', '')
    result = lv.get_virtual_facts()

# Generated at 2022-06-23 02:18:53.833226
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    virt_obj = LinuxVirtual(module)
    assert type(virt_obj) is LinuxVirtual

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:19:04.912732
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """ Test get_virtual_facts method of LinuxVirtual class
    """

    # Setup
    linux_virtual = LinuxVirtual()
    module = get_test_module()
    linux_virtual.module = module
    module.run_command = MagicMock(return_value=(0, '', ''))
    if not hasattr(module, 'lscpu'):
        module.lscpu = []
    if not hasattr(module, 'virt_what'):
        module.virt_what = []
    if not hasattr(module, 'systemd_container'):
        module.systemd_container = ''
    module.get_bin_path = MagicMock(return_value=None)

# Generated at 2022-06-23 02:19:07.033589
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collect = LinuxVirtualCollector()
    assert(collect._platform == 'Linux')
    assert(collect._fact_class == LinuxVirtual)

# Generated at 2022-06-23 02:19:13.279363
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """linux_virtual.py: Constructing and testing 'LinuxVirtual' class"""

    # Create the class with dummy Arguments
    my_virtual_obj = LinuxVirtual(dict(ANSIBLE_MODULE_ARGS=dict()), dict())

    # Testing virtual_facts function
    if my_virtual_obj.virtual_facts() != 'NA':
        print('linux_virtual.py: virtual_facts() - Success')
    else:
        print('linux_virtual.py: virtual_facts() - Failure')


# Main function to execute unit test
if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:19:15.658359
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)

    print(lv.get_virtual_facts())

# Generated at 2022-06-23 02:19:22.909780
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual(None)

    # Test virtualization facts dictionary
    module = Mock()
    lv.module = module
    lv.module.run_command.return_value = (0, 'String', '')
    lv.module.get_bin_path.return_value = 'path'

    assert lv.get_virtual_facts() == {'virtualization_role': 'host',
                                      'virtualization_type': 'lxc',
                                      'virtualization_tech_host': set(['docker',
                                                                      'lxc',
                                                                      'systemd-nspawn']),
                                      'virtualization_tech_guest': set(['docker',
                                                                       'lxc',
                                                                       'systemd-nspawn'])}

# Generated at 2022-06-23 02:19:28.438319
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # source: https://circleci.com/docs/2.0/local-jobs/
    os.environ['CIRCLE_JOB'] = 'build'
    facts = LinuxVirtual(None).get_virtual_facts()
    assert facts['virtualization_type'] == 'circleci'
    assert facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:19:32.085015
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    platform_virtual = LinuxVirtual(module)
    assert isinstance(platform_virtual, BaseVirtual) == True
    assert isinstance(platform_virtual, BaseLinuxVirtual) == True


# Generated at 2022-06-23 02:19:35.502827
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    ''' test _init_ method of class LinuxVirtual '''
    module = AnsibleModule(argument_spec={})
    obj = LinuxVirtual(module)
    assert hasattr(obj, 'module')
    assert obj.module == module



# Generated at 2022-06-23 02:19:37.954211
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    assert lv.module == module

# Generated at 2022-06-23 02:19:43.000418
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    result = LinuxVirtualCollector(module).collect()
    assert isinstance(result, dict)
    assert 'virtualization_role' in result
    assert 'virtualization_type' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result


# Generated at 2022-06-23 02:19:54.624362
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    m = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    l_virtual = LinuxVirtual(m, {})

    #
    # Test virtual_facts
    #
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'VMware'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = set(['VMware'])
    virtual_facts['virtualization_tech_host'] = set()

    # Test virtual_facts - chroot
    os.environ['FAKE_CHROOT_DIR'] = '/'
    assert l_virtual.get_virtual_facts() == dict()

    # Test virtual_facts - return value

# Generated at 2022-06-23 02:19:57.208853
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert hasattr(LinuxVirtualCollector(), '_fact_class')
    assert 'Linux' == LinuxVirtualCollector._platform


# Generated at 2022-06-23 02:19:58.927011
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    instance = VirtualCollector.factory()
    assert isinstance(instance, LinuxVirtualCollector)



# Generated at 2022-06-23 02:20:07.863581
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual = LinuxVirtual()

    # Test virtualization_type
    assert virtual.get_virtual_facts()['virtualization_type'] == 'kvm'
    assert virtual.get_virtual_facts()['virtualization_role'] == 'guest'

    # Test virtualization technology detection
    assert 'uml' in virtual.get_virtual_facts()['virtualization_tech_guest']
    assert 'kvm' in virtual.get_virtual_facts()['virtualization_tech_guest']
    assert 'virtualbox' in virtual.get_virtual_facts()['virtualization_tech_guest']
    assert 'openvz' in virtual.get_virtual_facts()['virtualization_tech_guest']
    assert 'container' in virtual.get_virtual_facts()['virtualization_tech_guest']

# Generated at 2022-06-23 02:20:19.091209
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # create temporary file
    fd, fpath = tempfile.mkstemp()

# Generated at 2022-06-23 02:20:20.571868
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x.platform == 'Linux'

# Generated at 2022-06-23 02:20:24.116515
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    facts = LinuxVirtual().populate()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts


# Generated at 2022-06-23 02:20:25.264945
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert False

# Generated at 2022-06-23 02:20:27.811901
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert(LinuxVirtual().get_virtual_facts() is not None)

# ===========================================
# OS sub class for generic Linux
# ===========================================

# Generated at 2022-06-23 02:20:30.598991
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    result = linux_virtual.get_virtual_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-23 02:20:39.853099
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    os = OS(module)
    virtual = LinuxVirtual(module, os)
    print("Virtualization type for this system: %s" % virtual.virtualization_type)
    print("Virtualization role for this system: %s" % virtual.virtualization_role)
    print("Virtualization technology (host): %s" % virtual.virtualization_tech_host)
    print("Virtualization technology (guest): %s" % virtual.virtualization_tech_guest)

if __name__ == '__main__':
    test_LinuxVirtualCollector()

# Generated at 2022-06-23 02:20:44.180345
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import LinuxVirtual
    obj = LinuxVirtual()
    assert obj.get_virtual_facts() is not None


# Generated at 2022-06-23 02:20:44.986356
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux = LinuxVirtual()  # noqa


# Generated at 2022-06-23 02:20:52.130884
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts
    """
    # Get current instance
    my_linux_virtual = LinuxVirtual()
    # Test and assert
    assert my_linux_virtual.get_virtual_facts() == {u'virtualization_tech_host': set(), u'virtualization_role': None, u'virtualization_tech_guest': set(), u'virtualization_type': u'physical'}
    # Write unit test here

# Class to implement Linux hostname facts

# Generated at 2022-06-23 02:20:53.756594
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)
    assert lv is not None

# Generated at 2022-06-23 02:20:55.542871
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    v = LinuxVirtual()
    assert isinstance(v, LinuxVirtual)


# Generated at 2022-06-23 02:21:02.987977
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})

    return_value = dict()
    # Return value example for LinuxKVMGuest virtualization
    return_value['virtualization_role'] = 'guest'
    return_value['virtualization_type'] = 'kvm'

    set_module_args(dict(
        gather_subset=['!all', '!min'],
        filter=dict(type='dict', required=False),
        any_errors_fatal=dict(type='bool', required=False, default=False),
    ))

    linux_virtual_ins = LinuxVirtual(module)
    # When gather_subset is set to a subset of virtual,
    # LinuxVirtual._gather_subset_virtual will be called
    # LinuxVirtual._gather_subset_virtual() returns None
    linux_virtual_ins

# Generated at 2022-06-23 02:21:15.143829
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Set up mock module and AnsibleModule
    mock_module = MagicMock()

    with patch.multiple(mock_module, run_command=DEFAULT, get_bin_path=DEFAULT):
        mock_module.run_command.return_value = (0, '0', '')
        mock_module.get_bin_path.return_value = None

        # Set up mock Facts class and instantiate object
        mock_Facts = MagicMock(spec=Facts)
        mock_Facts_instance = mock_Facts()

        # Set up mock LinuxVirtual class and instantiate object
        mock_LinuxVirtual = MagicMock(spec=LinuxVirtual)
        mock_LinuxVirtual_instance = mock_LinuxVirtual(mock_module)

        # Set up mock LinuxDistribution class and instantiate object

# Generated at 2022-06-23 02:21:17.905854
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert isinstance(lvc.facts, LinuxVirtual)
    assert lvc.facts.platform == 'Linux'


# Generated at 2022-06-23 02:21:22.696618
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test for constructor of class LinuxVirtual
    """
    # Create a dummy module
    module = AnsibleModule(argument_spec = dict())
    module.params = dict()

    # Create an object of class LinuxVirtual
    lv = LinuxVirtual(module)

    # Return the results for the tests
    return lv


# Generated at 2022-06-23 02:21:27.295690
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lvm = LinuxVirtual(module)
    print(lvm.get_virtual_facts())


### end of AnsibleModule

# Generated at 2022-06-23 02:21:30.399584
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert isinstance(linux_virtual_collector, LinuxVirtualCollector)
    assert isinstance(linux_virtual_collector.facts, LinuxVirtual)


# Generated at 2022-06-23 02:21:31.740644
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    info = LinuxVirtual()
    assert type(info) == LinuxVirtual

# Generated at 2022-06-23 02:21:36.376179
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict(test=dict(type='bool', default=False)))
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    module.exit_json(changed=False, virtual_facts=virtual_facts)



# Generated at 2022-06-23 02:21:45.969094
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # ansible module arguments
    argument_spec = dict()
    module = AnsibleModule(argument_spec=argument_spec)
    # create an instance of LinuxVirtual and execute gather_facts()
    lv = LinuxVirtual(module)
    virtual_facts = lv.gather_facts()
    # test if some keys are in resulting dict:
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-23 02:21:52.863495
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test for LinuxVirtualCollector class.
    """
    _test_module = type('Module', (object,), {})()
    _test_module.get_bin_path = MagicMock()
    _test_module.run_command = MagicMock()

    _test_LinuxVirtualCollector = LinuxVirtualCollector(_test_module, 'Linux')
    assert _test_LinuxVirtualCollector._platform is 'Linux'


if __name__ == "__main__":
    test_LinuxVirtualCollector()

# Generated at 2022-06-23 02:21:58.133050
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    V = LinuxVirtualCollector()
    assert V._platform == 'Linux'
    assert V._fact_class.__name__ == 'LinuxVirtual'
    assert V._fact_class._platform == 'Linux'
    assert V._fact_class._module == platform.system().lower()
    assert V._fact_class._module._platform == 'Linux'
    assert V._fact_class._module._name == 'linux_virtual'

# Generated at 2022-06-23 02:22:03.785208
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class MockModule(object):
        pass

    module = MockModule()
    lv = LinuxVirtual(module)
    # virtual_facts should be a dictionary
    virtual_facts = lv.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts


# Generated at 2022-06-23 02:22:10.833603
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts = LinuxVirtual().get_virtual_facts()
    # This is just a regression test, it might not catch every scenario
    assert(virtual_facts.get('virtualization_type', False) is not False)
    assert(virtual_facts.get('virtualization_role', False) is not False)
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert virtual_facts.get('virtualization_type') == 'kvm'
    assert virtual_facts.get('virtualization_role') == 'host'


# Generated at 2022-06-23 02:22:13.373363
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    v_collector = LinuxVirtualCollector()
    assert v_collector.platform == 'Linux'
    assert v_collector._fact_class == LinuxVirtual

# Generated at 2022-06-23 02:22:15.766684
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    m = AnsibleModuleMock()
    linux_virtual = LinuxVirtual(m)
    assert linux_virtual.module == m


# Generated at 2022-06-23 02:22:18.933250
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.collector import Collector
    c = LinuxVirtualCollector(Collector)
    assert c.get_virtual_facts()["virtualization_type"] == "NA"

# Generated at 2022-06-23 02:22:21.260048
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virt_obj = LinuxVirtual()
    assert virt_obj.platform == 'Linux'
    assert virt_obj.distribution == 'NA'


# Generated at 2022-06-23 02:22:25.370958
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    my_obj = LinuxVirtualCollector()
    assert my_obj
    assert isinstance(my_obj._fact_class, LinuxVirtual)
    assert my_obj._platform == 'Linux'


# Generated at 2022-06-23 02:22:28.890906
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Unit test for constructor of class LinuxVirtual.

    :returns: ``dict``
    '''
    return LinuxVirtual().collect()


# Generated at 2022-06-23 02:22:34.471599
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module.run_command = lambda args: (0, '', '')
    lv.module.get_bin_path = lambda args: 'dmidecode'
    lv.dmidecode_parser = DmiDecodeParser()
    lv.dmidecode_parser.get_value = lambda: ''
    assert lv.get_virtual_facts()['virtualization_type'] == 'NA'

# Generated at 2022-06-23 02:22:41.466372
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    virtual = LinuxVirtual(module=module, collect_subset=['all'])
    virtual.collect_platform_subset_facts()
    expected_keys = ['virtualization_type', 'virtualization_role']
    keys = virtual.get_facts().keys()
    if not expected_keys.sort() == keys.sort():
        module.fail_json(msg="Gathered facts are missing some keys: %s" % (' '.join(keys.sort())))


# Generated at 2022-06-23 02:22:50.278637
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Unit test of LinuxVirtual
    '''
    import ansible.utils.platform

    class OSDistribution(object):
        '''
        Constructor of OSDistribution class
        '''
        def __init__(self, name, version_number, id, like, major_version):
            self.name = name
            self.version_number = version_number
            self.id = id
            self.like = like
            self.major_version = major_version

    class ModuleUtils(object):
        '''
        Constructor of ModuleUtils class
        '''
        class basic(object):
            '''
            Constructor of basic class
            '''
            class Distribution(object):
                '''
                Constructor of Distribution class
                '''

# Generated at 2022-06-23 02:22:57.468362
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import Facts

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    facts = Facts(module=module)
    linux_virtual = LinuxVirtual(module=module)
    facts.populate()

    assert facts is not None


# Generated at 2022-06-23 02:23:02.853061
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Setup
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    # Exercise
    virtual_facts = lv.get_virtual_facts()
    # Verify
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    # Cleanup - none necessary


# =============================

# Generated at 2022-06-23 02:23:05.761988
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    virtual = LinuxVirtualCollector(module=module).collect()
    assert 'virtualization_tech_guest' in virtual



# Generated at 2022-06-23 02:23:07.405166
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    col = LinuxVirtualCollector()

# unit test for the LinuxVirtual class

# Generated at 2022-06-23 02:23:19.250057
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """unit test for constructor of class LinuxVirtual"""

    module = DummyModule()
    lv = LinuxVirtual(module)
    if lv is not None:
        print("SUCCESS: instantiation of class LinuxVirtual")
    else:
        print("ERROR: instantiation of class LinuxVirtual")

    facts = {}
    result = lv.get_virtual_facts(facts)
    if 'virtualization_tech_guest' in result:
        print("SUCCESS: virtualization_tech_guest in result")
    else:
        print("ERROR: virtualization_tech_guest not in result")
    if 'virtualization_tech_host' in result:
        print("SUCCESS: virtualization_tech_host in result")
    else:
        print("ERROR: virtualization_tech_host not in result")


# Generated at 2022-06-23 02:23:22.007223
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == "Linux"
    assert lvc._fact_class == LinuxVirtual

# Generated at 2022-06-23 02:23:31.910076
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    print('Testing method get_virtual_facts of class LinuxVirtual')

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(required=False, default={}, type='dict')
        ),
    )
    if not HAS_PYTHON26:
        module.fail_json(msg='python >= 2.6 required for this module')

    global _shared_state
    global _cache
    _shared_state['module'] = module
    _shared_state['_cache'] = dict()

    linux_virtual = LinuxVirtual(module=module)

    # Stubs for get_file_content and get_file_lines

# Generated at 2022-06-23 02:23:40.641713
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test constructor of class LinuxVirtual
    """
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual

    module_arg_spec = {}
    facts_obj = ModuleFacts(False, False, module_arg_spec, True)
    facts_obj.ansible_facts['ansible_system'] = 'Linux'

    # Test for all required params
    virtual_obj = LinuxVirtual(facts_obj)
    assert virtual_obj is not None


# Generated at 2022-06-23 02:23:51.318356
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual unit test to create class object
    """
    module = AnsibleModule(
        argument_spec=dict())

    # Create object for class LinuxVirtual
    if not os.path.exists('/proc/cpuinfo'):
        try:
            os.makedirs('/proc/cpuinfo')
        except OSError:
            pass
    if not os.path.exists('/proc/modules'):
        try:
            os.makedirs('/proc/modules')
        except OSError:
            pass
    linux_virtual = LinuxVirtual(module)

    # Create a test case dictionary