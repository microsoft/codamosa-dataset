

# Generated at 2022-06-23 02:13:55.741968
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Make sure that the LinuxVirtualCollector is a subclass of the base class Collector
    assert issubclass(LinuxVirtualCollector, Collector)

    # Test the initializer of the LinuxVirtualCollector class,
    # which should set the instance object's _fact_class field to LinuxVirtual,
    # and the _platform field to "Linux".
    # This call should be made with the object of class Collector.
    fact_collector = LinuxVirtualCollector("test_module")

    assert fact_collector._fact_class == LinuxVirtual
    assert fact_collector._platform == "Linux"

# Generated at 2022-06-23 02:14:00.078634
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test constructor of class LinuxVirtualCollector"""
    module = AnsibleModuleMock()
    lvc = LinuxVirtualCollector(module)
    assert isinstance(lvc, VirtualCollector)
    assert lvc._fact_class is LinuxVirtual
    assert lvc._platform == 'Linux'

# Generated at 2022-06-23 02:14:02.666852
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    facts = LinuxVirtual(module)
    assert facts


# Generated at 2022-06-23 02:14:14.724207
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    global virtual_facts
    virtual_facts = { 'virtualization_role': None, 'virtualization_type': None, 'virtualization_tech_guest': None, 'virtualization_tech_host': None }
    global get_file_content_result

# Generated at 2022-06-23 02:14:24.175515
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    fact_subclass_obj = LinuxVirtualCollector(module)
    fact_subclass_obj.collect()

    assert fact_subclass_obj.platform == 'Linux'
    assert len(fact_subclass_obj.data.keys()) is 1
    assert fact_subclass_obj.data["virtual"] == {
        'name': 'NA',
        'role': 'NA',
        'type': 'NA',
        'uuid': 'NA',
        'system_uuid': 'NA',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
    }


# Generated at 2022-06-23 02:14:25.361448
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    return



# Generated at 2022-06-23 02:14:29.427256
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """ Unit test for constructor of class LinuxVirtualCollector """
    obj = LinuxVirtualCollector()
    assert obj._platform == 'Linux'
    assert obj._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:14:36.820990
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})

    lv = LinuxVirtual(module)
    facts = lv.get_virtual_facts()
    keys = [
        'virtualization_role',
        'virtualization_type',
        'virtualization_tech_guest',
        'virtualization_tech_host'
    ]
    for key in keys:
        assert key in facts.keys()
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert isinstance(facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:14:38.099298
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector(None)
    assert lvc._fact_class.__name__ == "LinuxVirtual"
    assert lvc._platform == "Linux"


# Generated at 2022-06-23 02:14:48.527104
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import __utils__
    # Basic usage
    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    module.params = {}
    module._ansible_facts = {}
    module._ansible_facts['ansible_facts'] = {}
    module._ansible_facts['ansible_facts']['ansible_virtualization_type'] = ''
    module._ansible_facts['ansible_facts']['ansible_virtualization_role'] = ''
    module._ansible_facts['ansible_facts']['ansible_virtualization_tech_guest'] = ''

# Generated at 2022-06-23 02:14:51.424010
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual = LinuxVirtual(module=None)
    virtual_facts = virtual._get_virtual_facts()
    assert virtual_facts['virtualization_type'] == "host"
    assert virtual_facts['virtualization_role'] == "host"

# Generated at 2022-06-23 02:15:00.719675
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.system.virtual import VirtualCollector
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual

    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector._platform == 'Linux'
    assert linux_virtual_collector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:15:04.308181
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Constructor of class LinuxVirtualCollector should create an instance of class LinuxVirtual
    """
    module = AnsibleModule(argument_spec={})
    linux_virtual_fact = LinuxVirtualCollector(module).collect()[0]
    assert isinstance(linux_virtual_fact, LinuxVirtual) is True


# Generated at 2022-06-23 02:15:05.998985
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    my_virtual = LinuxVirtual(dict())
    my_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:15:17.169988
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts_reference = {'virtualization_type': 'lxc',
                               'virtualization_role': 'guest',
                               'virtualization_tech_guest': {'container', 'lxc'},
                               'virtualization_tech_host': set()}
    linux_virtual = LinuxVirtual(module=None)
    virtual_facts = linux_virtual.get_virtual_facts()

    # Remove keys from result to match expected output
    if 'virtualization_type' not in virtual_facts_reference:
        virtual_facts.pop('virtualization_type')
    if 'virtualization_role' not in virtual_facts_reference:
        virtual_facts.pop('virtualization_role')

# Generated at 2022-06-23 02:15:23.133826
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    module.exit_json = MagicMock(return_value=dict(data='Hello from mock'))

    sys_module = MagicMock()
    sys_module.platform = 'linux'

    virtual_info = LinuxVirtual(module)

    assert virtual_info.module == module
    assert virtual_info.system == sys_module


# Generated at 2022-06-23 02:15:34.646465
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()

# Generated at 2022-06-23 02:15:38.640832
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module.params = {'fact_path': '/etc/ansible/facts.d'}
    facts = lv.get_virtual_facts()
    assert facts['virtualization_type'] == 'NA'


# Generated at 2022-06-23 02:15:43.684382
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)
    (guest_tech, host_tech) = lv.get_virtual_facts()
    module.exit_json(changed=False, guest_tech=guest_tech, host_tech=host_tech)

# Unit test entry point

# Generated at 2022-06-23 02:15:46.902014
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = LinuxVirtualCollector()
    assert vc is not None
    assert vc._platform == 'Linux'
    assert vc._fact_class == LinuxVirtual



# Generated at 2022-06-23 02:15:52.287160
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    for key, value in LinuxVirtualCollector(module).get_facts().items():
        module.exit_json(changed=False, ansible_facts={key: value})



# Generated at 2022-06-23 02:15:58.629165
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual()
    lv.module = module
    #TODO: Add some test cases for method get_virtual_facts of class LinuxVirtual
    #TODO: Write unit test for method get_virtual_facts of class LinuxVirtual
    # No test cases written for method get_virtual_facts of class LinuxVirtual

# Unit test to check method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-23 02:16:04.111162
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    assert linux_virtual.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'openvz'}

# Get the basic CPU facts using the __get_cpuinfo method
get_cpuinfo = LinuxVirtual.__get_cpuinfo

# class SolarisVirtual(BaseVirtual)

# Generated at 2022-06-23 02:16:05.613586
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert str(c) == "Virtual Linux: {}"

# Generated at 2022-06-23 02:16:08.509730
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    virtual_collector = LinuxVirtualCollector(module)
    assert virtual_collector


# Generated at 2022-06-23 02:16:14.189842
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    linux_virtual = LinuxVirtual(module)
    result = linux_virtual.get_virtual_facts()
    fields = ['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']
    for field in fields:
        assert field in result


# Generated at 2022-06-23 02:16:25.396356
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # LinuxVirtual.get_virtual_facts: should return virtualization facts,
    # and should not affect facts already set by other modules
    lv = LinuxVirtual("test")
    facts = {
        "virtualization_role": "host",
        "virtualization_type": "docker",
    }
    lv.module.facts = dict(facts)
    virtual_facts = {
        "virtualization_role": "guest",
        "virtualization_type": "kvm",
    }
    lv.get_virtual_facts()
    # Assert that the virtualization facts were set, and that the
    # existing facts were not affected.
    assert lv.module.facts["virtualization_role"] == "host"
    assert lv.module.facts["virtualization_type"] == "docker"

# Generated at 2022-06-23 02:16:28.998231
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Testing with a non-virtualized host
    module = AnsibleModule(argument_spec = dict())
    lv = LinuxVirtual(module=module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == "NA"



# Generated at 2022-06-23 02:16:39.875530
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat import unittest

    class Test_LinuxVirtual_get_virtual_facts(unittest.TestCase):

        def setUp(self):
            self.test_class = LinuxVirtual(FakeAnsibleModule)

        def test_get_virtual_facts_get_file_lines_raises_IOError(self):
            '''Test that method get_file_lines raises IOError.'''
            fake_file = '/proc/cpuinfo'

# Generated at 2022-06-23 02:16:47.666989
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual class constructor test mocking a 'Linux' system
    """

    module = AnsibleModule(argument_spec={})
    is_linux = True
    if is_linux:
        virtual = LinuxVirtual(module)
        # FIXME: find a way to test other methods as well
        assert virtual.linux_virtual()['virtualization_type'] == 'NA'
        assert virtual.linux_virtual()['virtualization_role'] == 'NA'
    else:
        skip("Not a Linux system")

# Generated at 2022-06-23 02:16:57.992895
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    virtual_facts = linux_virtual.collect_facts()

    # Example of these values we would find on a KVM host
    if virtual_facts['virtualization_type'] == 'kvm':
        assert virtual_facts['virtualization_role'] == 'host'
        assert virtual_facts['virtualization_tech_guest'] == set()
        assert virtual_facts['virtualization_tech_host'] == {'kvm'}
    # Example of these values we would find on a KVM guest
    if virtual_facts['virtualization_type'] == 'kvm':
        assert virtual_facts['virtualization_role'] == 'guest'
        assert virtual_facts['virtualization_tech_guest'] == {'kvm'}
        assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:17:01.710658
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    obj = LinuxVirtualCollector(module)
    assert obj._fact_class.__name__ == 'LinuxVirtual'
    assert obj._platform == 'Linux'


# Generated at 2022-06-23 02:17:04.433308
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    vm_collector = LinuxVirtualCollector(module)
    assert vm_collector.get_fact_class() == LinuxVirtual

# Generated at 2022-06-23 02:17:15.131465
# Unit test for constructor of class LinuxVirtualCollector

# Generated at 2022-06-23 02:17:22.884749
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test LinuxVirtualCollector constructor
    """

    module = collection_load_params(None, None)
    fixture = LinuxVirtualCollector(module=module)
    # Asserts for the LinuxVirtualCollector instance
    assert fixture.module == module
    assert fixture.platform == 'Linux'
    assert fixture._fact_class == LinuxVirtual
    assert isinstance(fixture, VirtualCollector)


# Generated at 2022-06-23 02:17:37.492022
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual_obj = LinuxVirtual()
    supported_facts = [
        'virtualization_role',
        'virtualization_type',
    ]
    unsupported_facts = [
        'virtualization_guest_fullname',
        'virtualization_guest_id',
        'virtualization_host_fullname',
        'virtualization_host_id',
        'virtualization_product_name',
        'virtualization_product_version',
    ]

    # check if unsupported facts are present in instance variables

# Generated at 2022-06-23 02:17:44.398818
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.collector.virtual import LinuxVirtualCollector
    from ansible.module_utils.facts.collector.virtual import LinuxVirtual
    from ansible.module_utils.facts import ModuleVirtual

    my_virt_fact = LinuxVirtualCollector(ModuleVirtual())
    my_linux_virt = LinuxVirtual()
    assert isinstance(my_virt_fact, LinuxVirtualCollector)
    assert my_virt_fact._platform == 'Linux'
    assert isinstance(my_virt_fact._fact_class, LinuxVirtual)
    assert my_virt_fact._fact_class == my_linux_virt


# Generated at 2022-06-23 02:17:48.776838
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector
    assert linux_virtual_collector.platform == 'Linux'
    assert linux_virtual_collector.fact_class == LinuxVirtual
    assert linux_virtual_collector.collect() == {}


# Generated at 2022-06-23 02:17:51.991958
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert c.is_active()
    assert issubclass(c._fact_class, LinuxVirtual)
    assert c._platform == 'Linux'


# Generated at 2022-06-23 02:17:56.812588
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(
        argument_spec=dict()
    )
    lv = LinuxVirtual(module)
    module.exit_json(**lv.get_virtual_facts())


if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:17:59.584006
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    linux_virtual = LinuxVirtual(module)

    # FIXME: Put test cases


# Generated at 2022-06-23 02:18:04.748617
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    LinuxVirtual test
    """

    module_mock = MagicMock()
    module_args = {
        'gather_subset': 'all',
    }

    module_mock.params = module_args

    # name class LinuxVirtual
    linux_virt = LinuxVirtual(module_mock)

    assert linux_virt.name == 'LinuxVirtual'

# Generated at 2022-06-23 02:18:14.661382
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Ensure that test_LinuxVirtualCollector is called with an AnsibleModule mock
    if not isinstance(sys.modules['__main__'].module, AnsibleModule):
        raise Exception("test_LinuxVirtualCollector must be called with an AnsibleModule mock.")
    module = sys.modules['__main__'].module

    linux_virtual_collector = LinuxVirtualCollector(module)
    assert isinstance(linux_virtual_collector, LinuxVirtualCollector)
    assert linux_virtual_collector._platform == "Linux"
    assert linux_virtual_collector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:16.358276
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual({}, {}, {})
    assert linux_virtual is not None



# Generated at 2022-06-23 02:18:29.056396
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    host_tech = set()
    guest_tech = set()
    virtual_facts = {'virtualization_role': 'NA', 'virtualization_type': 'NA', 'virtualization_tech_guest': guest_tech, 'virtualization_tech_host': host_tech}
    virt = get_virtual_facts(virtual_facts)

    virtual_facts = {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_guest': guest_tech, 'virtualization_tech_host': host_tech}
    virt = get_virtual_facts(virtual_facts)

    virtual_facts = {'virtualization_role': 'host', 'virtualization_type': 'kvm', 'virtualization_tech_guest': guest_tech, 'virtualization_tech_host': host_tech}
    virt

# Generated at 2022-06-23 02:18:35.030324
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert linux_virtual


# Generated at 2022-06-23 02:18:38.660397
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = DummyModule()
    dist = DummyDistribution()
    lv = LinuxVirtual(module, dist)

    assert lv != None


# Generated at 2022-06-23 02:18:40.500898
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    assert LinuxVirtual({}).facts == {}


# Generated at 2022-06-23 02:18:48.779945
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Unit test for constructor of class LinuxVirtual'''
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    linux_virtual = LinuxVirtual(module)
    result_test = dict(
        virtualization_type='kvm',
        virtualization_role='guest',
        virtualization_tech_host=set([]),
        virtualization_tech_guest=set(['kvm', 'container']),
    )
    assert linux_virtual.get_virtual_facts() == result_test


# Generated at 2022-06-23 02:18:59.248739
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Test with virtualization_role: guest and virtualization_type: hyperv
    set_module_args({'gather_subset': ['all'], 'filter': '*'})

# Generated at 2022-06-23 02:19:00.787254
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector(), LinuxVirtualCollector)


# Generated at 2022-06-23 02:19:09.891145
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.base import FakeModule
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.compat.tests.mock import patch, Mock
    from contextlib import nested
    import json
    import os

    module = FakeModule()
    LINUX_VIRTUAL_MODULE_UTILS_PATH = 'ansible.module_utils.facts.virtual.linux'

    xmllint_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'unit',
        'files',
        'xmllint'
    )
    xmllint_path = to_text(xmllint_path)


# Generated at 2022-06-23 02:19:14.250234
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert linux_virtual.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'openvz', 'virtualization_tech_guest': {'openvz', 'container'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-23 02:19:18.519053
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    # create an instance of LinuxVirtualCollector class
    x = LinuxVirtualCollector(module)
    assert x
    assert x.platform == 'Linux'
    assert x.fact_class == LinuxVirtual

# Generated at 2022-06-23 02:19:21.204875
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    v = LinuxVirtual(module)
    assert v.module == module


# Generated at 2022-06-23 02:19:25.636770
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual = LinuxVirtual()
    assert virtual
    assert isinstance(virtual, LinuxVirtual)

    # test methods not called by constructor
    dmi_bin = virtual.module.get_bin_path('dmidecode')
    if dmi_bin:
        virtual.get_dmi_data(dmi_bin)

# Generated at 2022-06-23 02:19:27.222171
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    assert True == LinuxVirtual(None).is_linux()


# Generated at 2022-06-23 02:19:28.379893
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    LinuxVirtual()


# Generated at 2022-06-23 02:19:35.544835
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    virtual_facts = linux_virtual.get_virtual_facts()
    assert type(virtual_facts) == type({})
    assert type(virtual_facts['virtualization_type']) == type('')
    assert type(virtual_facts['virtualization_role']) == type('')
    assert type(virtual_facts['virtualization_tech_guest']) in [type(set()), type(None)]
    assert type(virtual_facts['virtualization_tech_host']) in [type(set()), type(None)]

# Generated at 2022-06-23 02:19:45.745051
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    mock_module = Mock()
    lv.module = mock_module
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path = Mock(return_value='/bin/dmidecode')
    get_file_lines_output = [
        '0::root:/root:/bin/bash',
        '1:1::/:/usr/sbin/nologin'
    ]

    get_file_content_output = 'PRETEND THIS IS A FILE'
    with patch.object(lv,'get_file_lines', return_value=get_file_lines_output), \
         patch.object(lv, 'get_file_content', return_value=get_file_content_output):
        output = lv.get_

# Generated at 2022-06-23 02:19:48.106163
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual({'module': None})
    assert 'virtualization_type' in lv.get_virtual_facts()


# Generated at 2022-06-23 02:19:50.057915
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x.platform == 'Linux'


# Generated at 2022-06-23 02:19:53.860595
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert isinstance(c, LinuxVirtualCollector)
    assert isinstance(c.facts, LinuxVirtual)
    assert c.facts.platform == 'Linux'


# Generated at 2022-06-23 02:20:05.100497
# Unit test for method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-23 02:20:10.139404
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_class = LinuxVirtual()

    # create instance of class with args
    def return_true(self,*args,**kwargs):
        return True

    test_class.module.get_bin_path = return_true
    test_class.module.run_command = return_true
    test_data = test_class.get_virtual_facts()
    assert isinstance(test_data,dict)


# Generated at 2022-06-23 02:20:14.239719
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Tests whether initialisation of class LinuxVirtualCollector
    # raises a TypeError Exception for all the arguments
    # that are not of type string.

    # Pass a wrong argument type.
    with pytest.raises(TypeError):
        LinuxVirtualCollector(1)
        LinuxVirtualCollector(None)

# Generated at 2022-06-23 02:20:18.787150
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.collector import Collector
    c = LinuxVirtualCollector(Collector)
    assert c.platform == c._platform
    assert c.fact_class == c._fact_class


# Generated at 2022-06-23 02:20:26.953392
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Method to test get_virtual_facts method of class 'LinuxVirtual', using pytest
    '''
    facts_obj = LinuxVirtual()
    facts = facts_obj.get_virtual_facts()
    assert facts['virtualization_type'] in ['NA','openvz','kvm','docker','openstack','xen','parallels','QEMU','RHEV','lxc','uml','powervm_lx86','virtualbox','prl','ibm_systemz','RHV','kubevirt','virtualpc','systemd-nspawn','linux_vserver','bhyve']


# Generated at 2022-06-23 02:20:29.454933
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'


# Generated at 2022-06-23 02:20:32.668416
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Constructor for the LinuxVirtual class.

    :returns: LinuxVirtual class
    :rtype: ``object``
    '''
    return LinuxVirtual()


# Generated at 2022-06-23 02:20:37.486942
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create an instance
    virtual_collector = LinuxVirtualCollector(module=module)

    assert virtual_collector.platform == 'Linux'


# Generated at 2022-06-23 02:20:48.880938
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False)
    shared_obj = LinuxVirtual(module)
    facts = shared_obj.get_virtual_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] != 'NA'
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] != 'NA'
#-------------------------------

# Generated at 2022-06-23 02:20:55.921363
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0,"cgroup","")
    virt_inst = LinuxVirtual(mock_module)
    res = virt_inst.get_virtual_facts()
    assert(res.get('virtualization_type') == "NA")
    assert(res.get('virtualization_role') == "NA")
    assert(res.get('virtualization_tech_guest') == set())
    assert(res.get('virtualization_tech_host') == set())


# Generated at 2022-06-23 02:21:06.645424
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Setup
    i = LinuxVirtual()

    # Test with all paths being existant
    os.path.exists = MagicMock(return_value=True)
    # Test for hyperv and xen type
    get_file_content = MagicMock(side_effect=["Microsoft Hv", 'xen'])
    # Test for PV and HVM type
    get_file_lines = MagicMock(return_value=["mode: HVM", "mode: PV"])
    i.get_file_lines = get_file_lines
    i.get_file_content = get_file_content

# Generated at 2022-06-23 02:21:10.161825
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test constructor of class
    LinuxVirtualCollector.
    """
    linux_virtual_collector = LinuxVirtualCollector()

    assert linux_virtual_collector.platform == 'Linux'

# Generated at 2022-06-23 02:21:15.728321
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    my_class = LinuxVirtual()

    virtual_facts = my_class.get_virtual_facts()
    assert len(virtual_facts) > 1
    assert "virtualization_type" in virtual_facts
    assert virtual_facts["virtualization_type"] in ('physical', 'virtual', 'container', 'NA')

# class LinuxHardware for gathering hardware information
# about the underlying system

# Generated at 2022-06-23 02:21:17.471694
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtualCollector()
    assert isinstance(facts._collector, LinuxVirtual)



# Generated at 2022-06-23 02:21:29.607078
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    # Test constructor of class LinuxVirtual
    assert linux_virtual.is_linux()
    assert not linux_virtual.is_freebsd()
    assert not linux_virtual.is_openbsd()
    assert not linux_virtual.is_netbsd()
    assert not linux_virtual.is_darwin()
    assert not linux_virtual.is_sunos()
    assert not linux_virtual.is_aix()
    assert not linux_virtual.is_windows()
    assert not linux_virtual.is_hpux()
    assert not linux_virtual.is_cisco_ios()
    assert not linux_virtual.is_junosos()
    assert not linux_virtual.is_solaris()
    assert not linux_virtual.is_cumulus()
    assert linux_virtual.is_

# Generated at 2022-06-23 02:21:38.355803
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Given
    # When
    module_mock = MockAnsibleModule(module_args='', module_name='LinuxVirtual',
            module_path='library/linux_virtual.py',
            supports_check_mode=True)
    plugin = LinuxVirtual(module_mock)
    plugin.prompt = Mock(return_value=True)
    virtual_facts = plugin.get_virtual_facts()

    # Then
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-23 02:21:43.265505
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule()
    virtual_collector = LinuxVirtualCollector(module)
    assert virtual_collector._fact_class == LinuxVirtual
    assert virtual_collector._platform == "Linux"
    assert virtual_collector._facts is None


# Generated at 2022-06-23 02:21:49.346964
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    os_platform = 'Linux'
    virt = LinuxVirtual(module=None, os_platform=os_platform)
    # It should return an object
    assert virt is not None
    assert isinstance(virt, LinuxVirtual)
    # It should return an object with the correct properties
    assert virt.module == None
    assert virt.os_platform == os_platform



# Generated at 2022-06-23 02:21:54.053627
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector.virtual_type == 'virtual'
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector.platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual
    assert LinuxVirtualCollector.fact_class == LinuxVirtual



# Generated at 2022-06-23 02:22:04.734268
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virt = LinuxVirtual()
    # Test file_exists method
    assert virt.file_exists("/proc/cpuinfo")
    assert virt.file_exists("/proc/filesystems")
    assert virt.file_exists("/proc/1/cgroup")
    assert virt.file_exists("/proc/self/cgroup")
    assert virt.file_exists("/proc/vz")
    assert virt.file_exists("/proc/lve")
    assert virt.file_exists("/proc/xen")
    assert virt.file_exists("/sys/devices/virtual/dmi/id/product_name")
    assert virt.file_exists("/sys/devices/virtual/dmi/id/sys_vendor")

# Generated at 2022-06-23 02:22:07.878659
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  module = AnsibleModule(
    argument_spec = dict()
  )
  lv = LinuxVirtual(module)
  module.exit_json(**lv.get_virtual_facts())


# Generated at 2022-06-23 02:22:11.997875
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Test module LinuxVirtual class.
    '''
    _cache = {}
    lv = LinuxVirtual(_cache)

    assert isinstance(lv, LinuxVirtual)

    assert isinstance(lv.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:22:22.476453
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Unit test for constructor of class LinuxVirtualCollector
    """
    module = MagicMock(name='ansible.module_utils.facts.virtual._AnsibleModule')
    module.run_command = MagicMock(name='run_command')
    module.get_file_content = MagicMock(name='get_file_content')
    module.get_bin_path = MagicMock(name='get_bin_path')
    module.get_file_lines = MagicMock(name='get_file_lines')
    module.fail_json = MagicMock(name='fail_json')

    lvc = LinuxVirtualCollector(module, 'Linux')
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'
    assert lvc._module == module


# Generated at 2022-06-23 02:22:31.523606
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.collector import Collector
    c = Collector()
    fac = c.collect(['virtual'], ['ansible_facts', 'ansible_local'], [])['ansible_facts']
    # run the class constructor
    o = LinuxVirtualCollector(fac)
    # test the instance
    assert isinstance(o, LinuxVirtualCollector)
    # test the return type of get_facts() method
    assert isinstance(o.get_facts(), dict)


# Generated at 2022-06-23 02:22:37.389980
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual import LinuxVirtual

    module = AnsibleModule(
        argument_spec = dict()
    )
    lv = LinuxVirtual(module)
    facts = lv.get_virtual_facts()
    module.exit_json(ansible_facts = { 'virtualization_facts': facts })

if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:22:46.752160
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    # For test purposes, the host is configured to be a virtualbox guest
    virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'virtualbox',
        'virtualization_tech_guest': ['virtualbox'],
        'virtualization_tech_host': ['virtualbox'],
    }
    lv = LinuxVirtual(module)
    assert lv.get_virtual_facts() == virtual_facts


# Generated at 2022-06-23 02:22:48.803792
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Test constructor"""
    lv = LinuxVirtual()
    assert type(lv) is LinuxVirtual


# Generated at 2022-06-23 02:22:56.640413
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    class FakeDistro:
        def __init__(self, name):
            self.name = name
            self.linux_distribution = lambda: [self.name, '', '']

    class FakeAnsibleModule:
        def __init__(self):
            self.params = dict()
            self.distribution = FakeDistro("RedHat")

    virt_facts = dict(
        ansible_virtualization_role='host',
        virtualization_type='kvm',
        virtualization_tech_host=set(['kvm']),
        virtualization_tech_guest=set([]))

    linux_virt = LinuxVirtual(FakeAnsibleModule())
    test_facts = linux_virt.get_virtual_facts()
    assert test_facts == virt_facts


# Generated at 2022-06-23 02:23:05.659961
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    sys_vendor = get_file_content('/sys/devices/virtual/dmi/id/sys_vendor')
    if sys_vendor == 'Red Hat':
        product_family = get_file_content('/sys/devices/virtual/dmi/id/product_family')
    if sys_vendor == 'Red Hat' and product_family == 'RHV':
        guest_tech = set(['RHV','container'])
        host_tech = set(['RHV'])
        virtual_facts = dict(virtualization_type='RHV', virtualization_role='host', virtualization_tech_guest=guest_tech, virtualization_tech_host=host_tech)
    return virtual_facts

# Class LinuxDistribution

# Generated at 2022-06-23 02:23:17.584100
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    shared_lib_path = '/usr/share/ansible_test'
    if not os.path.exists(shared_lib_path):
        os.makedirs(shared_lib_path)
    virtual = LinuxVirtual(module, shared_lib_path)
    # Test with an unprivileged user
    module.run_command = MagicMock(side_effect=lambda _: (1, 'stdout', 'stderr'))
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:23:29.319494
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    m_instance = mock.Mock(spec_set=AnsibleModule)
    mock_get_bin_path = mock.MagicMock(return_value='/bin/dmidecode')
    m_instance.get_bin_path = mock_get_bin_path
    m_instance.run_command = mock.MagicMock(return_value=(0, 'fake', ''))
    m_instance.get_file_content = mock.MagicMock(return_value='host')
    m_instance.get_file_lines = mock.MagicMock(return_value=[])
    m_linux_virtual = LinuxVirtual(m_instance)

# Generated at 2022-06-23 02:23:36.869846
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Set up dummy module
    module = AnsibleModule(dict())

    # Create Collector object
    try:
        lvc = LinuxVirtualCollector(module)
    except Exception as e:
        module.fail_json(msg=unittesting_fail_msg(e))

    # Test VirtualCollector class is properly inherited
    assert isinstance(lvc, VirtualCollector)

    # Test that _platform attribute is properly set
    assert lvc._platform == 'Linux'



# Generated at 2022-06-23 02:23:47.915858
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    testobj = LinuxVirtual()
    # we can't use the facts object here
    testobj.facts = dict()
    # test openvz host
    testobj._is_lxc = False
    testobj._systemd_container = ""
    testobj._get_file_content = lambda x: None
    testobj._get_file_lines = lambda x: []
    testobj._get_bin_path = lambda x: "/bin/binary"
    testobj._get_mount_points = lambda x: []
    files_for_ovz_host = {"/proc/vz": "", "/proc/lve": "", "/proc/bc": ""}
    def mock_isfile(filename):
        return files_for_ovz_host.get(filename) is not None