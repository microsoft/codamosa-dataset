

# Generated at 2022-06-23 02:13:48.069863
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec={},
    )

    lvc = LinuxVirtualCollector(module)
    assert(lvc.module == module)
    assert(lvc.platform == 'Linux')
    assert(lvc.fact_class == LinuxVirtual)


# Generated at 2022-06-23 02:13:53.802174
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    with patch('ansible_collections.ansible.community.plugins.module_utils.facts.virtual.collectors.linux.LinuxVirtual.collect', return_value=dict()) as linux_virtual_collect:
        c = LinuxVirtualCollector()
        linux_virtual_collect.assert_called_with()
        assert c.platform == 'Linux'


# Generated at 2022-06-23 02:13:57.723184
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test module constructor
    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)
    assert lv is not None

# Generated at 2022-06-23 02:14:09.893711
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts in LinuxVirtual class
    """

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    sys_vendor = os.path.realpath(os.path.join(os.path.dirname(__file__), '../../../../../../sys/devices/virtual/dmi/id'))
    sys_module = os.path.realpath(os.path.join(os.path.dirname(__file__), '../../../../../../sys/module'))
    facts = LinuxVirtual(module).get_virtual_facts(sys_vendor, sys_module)
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'kvm'
    assert 'kvm'

# Generated at 2022-06-23 02:14:21.906121
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    host_facts = dict()
    module = AnsibleModule(argument_spec=dict())
    m_args = dict(
        module=module,
        host_facts=host_facts
    )
    m_linux_virtual = MagicMock(spec=LinuxVirtual)
    m_linux_virtual.get_virtual_facts = MagicMock(return_value=dict())

    with patch.multiple(
        'ansible.module_utils.facts.virtual.linux_virtual.LinuxVirtual',
        __init__=mock_init(m_args),
        get_virtual_facts=m_linux_virtual.get_virtual_facts
    ) as mocks:
        linux_virtual = LinuxVirtual(module=module, host_facts=host_facts)
        linux_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:14:23.715620
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtualCollector = LinuxVirtualCollector()
    assert virtualCollector is not None



# Generated at 2022-06-23 02:14:25.655358
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # create instance of class
    virtual_obj = LinuxVirtual()

    del virtual_obj


# Generated at 2022-06-23 02:14:29.219636
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """linux_virtual test class"""
    module = AnsibleModule({})
    assert ModuleUtils(module).get_platform_subclass(LinuxVirtual)


# Generated at 2022-06-23 02:14:33.149016
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Test virtual facts collection'''
    virtual = LinuxVirtual()
    assert virtual.collect_virtual_facts() == {'virtualization_type': 'NA', 'virtualization_role': 'NA'}

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 02:14:41.823202
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    # Mock the module which is passed as an argument in the constructor
    test_module = MagicMock()
    test_module.get_bin_path.return_value = '/bin/dmidecode'
    test_module.run_command.return_value = (0, "", "")
    # Mock the facts which is the output of the constructor
    test_facts = MagicMock()
    test_facts.get_all.return_value = {'virtualization_type': 'NA', 'virtualization_role': 'NA'}
    collector.module = test_module
    collector.facts = test_facts
    collector.collect()
    # Check if function get_all of _fact_class is called
    test_facts.get_all.assert_called_once()
    # Check if function get_bin

# Generated at 2022-06-23 02:14:48.253859
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual

    class FakeModule(object):
        def __init__(self):
            self.exit_json = MagicMock()
            self.fail_json = MagicMock()
            self.params = {}
            self.fail_json.side_effect = Exception

        def get_bin_path(self, program, required=False):
            if program == 'lscpu':
                return '/bin/lscpu'
            return None


# Generated at 2022-06-23 02:14:53.297636
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)

    assert isinstance(linux_virtual, LinuxVirtual)
    assert isinstance(linux_virtual.module, AnsibleModule)
    assert isinstance(linux_virtual.facts_class, LinuxHardware)


# Generated at 2022-06-23 02:14:56.274182
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module_mock = AnsibleModuleMock({'ansible_facts': {'os_family': 'Linux'}})
    tmp_LinuxVirtual = LinuxVirtual(module_mock)
    tmp_LinuxVirtual.get_virtual_facts()


# Generated at 2022-06-23 02:14:56.983541
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()

# Generated at 2022-06-23 02:15:03.983932
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  class Args():
    def __init__(self, module):
      self.module = module
  class MockedModule():
    def __init__(self):
      pass
    def get_bin_path(self, path):
      return None
    def run_command(self, cmd):
      return (0, '', '')
  args = Args(MockedModule())
  obj = LinuxVirtual(args)
  obj.get_virtual_facts()

# Generated at 2022-06-23 02:15:14.527025
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Test LinuxVirtual.get_virtual_facts()
    '''
    # Test with a basic system
    module = MagicMock()
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = True
    module.run_command.return_value = (1, '', '')
    module.get_file_lines = MagicMock()
    module.get_file_lines.return_value = []

# Generated at 2022-06-23 02:15:20.420085
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_facts = LinuxVirtual(module)
    for key in virtual_facts.virtual_facts:
        assert virtual_facts.virtual_facts[key] is not []
        assert virtual_facts.virtual_facts[key] is not ''
        assert virtual_facts.virtual_facts[key] is not 'NA'
        assert virtual_facts.virtual_facts[key] is not None


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:15:26.960061
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    os_version = 'RedHat8.0'
    virtual_facts = {'virtualization_type': 'openvz', 'virtualization_role': 'guest',
                     'virtualization_tech_host': {'openvz', 'container'},
                     'virtualization_tech_guest': {'openvz', 'container'}}
    assert lv.get_virtual_facts() == virtual_facts


# Generated at 2022-06-23 02:15:33.325975
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list')})
    lv = LinuxVirtual(module)
    assert(lv.name == 'virtual')
    assert(lv.platform == 'Linux')
    assert(lv.distribution == None)
    assert(lv.virtual_facts == {})
    assert(lv.module == module)


# Generated at 2022-06-23 02:15:36.078878
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = MagicMock()
    lv = LinuxVirtualCollector(module)
    assert lv._fact_class == LinuxVirtual
    assert lv._platform == 'Linux'

# Generated at 2022-06-23 02:15:42.340111
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():

    module = AnsibleModule(argument_spec=dict())

    if not HAS_PYTHON_DMIDECODE:
        module.fail_json(msg='Missing required python module (dmidecode)')

    linux_virtual = LinuxVirtual(module)

    module.exit_json(ansible_facts=dict(virtual=linux_virtual.populate()))

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:15:51.824022
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # For test_module_utils.py
    module = AnsibleModule(argument_spec=dict())
    # Inject mocks
    exec_command = lambda *args, **kwargs: (0, '', '')
    module.run_command = exec_command
    read_file = lambda *args, **kwargs: ''
    module.get_bin_path = lambda *args, **kwargs: None
    module.get_file_content = read_file
    module.get_file_lines = read_file
    module.params = {}
    linux = LinuxVirtual(module=module)
    # Test the facts collection
    facts = linux.collect_facts()
    # Just some basic testing.
    # The real testing is done by test_virtual.py anyway.
    assert 'virtualization_type' in facts

# Generated at 2022-06-23 02:16:01.844427
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import LinuxVirtual as _LinuxVirtual
    from ansible.module_utils.facts.virtual import get_file_content
    from ansible.module_utils.facts.virtual import get_file_lines
    from ansible.module_utils.facts.virtual import get_file_size
    from ansible.module_utils.facts.virtual import get_file_hash
    from ansible.module_utils.facts.virtual import get_file_version
    import sys
    import re
    class FakeModule(object):

        def get_bin_path(self, arg):
            return arg


# Generated at 2022-06-23 02:16:13.744141
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()

# Generated at 2022-06-23 02:16:25.073161
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    args = dict(
        platform_subclass=dict(
           dist_version_info=dict(
               major=6
           )
        ),
        kernel_version=4.4,
    )

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)

    if 'platform_subclass' in args:
        module.params['platform_subclass'] = FakeLinuxDistribution(args['platform_subclass'])
    module.params['kernel'] = args['kernel_version']

    # instantiate the virtual class
    virtual_ins = LinuxVirtual(module)

    # get the method to test
    method_to_test = 'get_virtual_facts'

    # get the virtual facts
    virtual_facts = virtual_ins.get_virtual_facts()

    # Validate virtual_facts

# Generated at 2022-06-23 02:16:26.904528
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector(), VirtualCollector) is True, 'test_LinuxVirtualCollector() failed!'


# Generated at 2022-06-23 02:16:36.893896
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set(['NA'])
    assert virtual_facts['virtualization_tech_host'] == set(['NA'])


# Generated at 2022-06-23 02:16:47.261049
# Unit test for method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-23 02:16:52.577160
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class LinuxVirtual'''
    virtual_facts = LinuxVirtual.get_virtual_facts()
    result = {'virtualization_role': 'guest',
              'virtualization_type': 'kvm'}
    if virtual_facts != result:
        raise AssertionError('virtual_facts result is not matching!')

# Generated at 2022-06-23 02:17:01.817400
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    os.path.exists = MagicMock(return_value=True)

    iface = LinuxVirtual(module)
    assert iface.module is module
    assert iface.run_command == module.run_command
    assert iface.get_bin_path == module.get_bin_path
    assert iface.os_path.exists == os.path.exists


# Generated at 2022-06-23 02:17:12.923420
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Do not use mock.patch on in-module functions to allow finding missing tests
    import os
    import glob
    import re
    import shutil
    import tempfile
    import sys
    import glob
    import distutils.version
    import copy
    import itertools

    def get_file_content(filename):
        with open(filename, 'rb') as f:
            return f.read().decode().strip()

    def get_file_lines(filename):
        with open(filename, 'rb') as f:
            return f.read().decode().splitlines()

    # Helper to filter out elements that are not part of unittest.mock.Mock
    # on Python 3.5 and 3.6

# Generated at 2022-06-23 02:17:15.388673
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Unit test for constructor of class LinuxVirtual"""
    module = AnsibleModule(argument_spec={})
    iv = LinuxVirtual(module)

# Generated at 2022-06-23 02:17:28.495934
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    response = LinuxVirtual.get_virtual_facts()
    assert response is not None

# <- [_get_virtual_facts]
# [_get_virtualbox_facts]
    def _get_virtualbox_facts(self):
        """Returns facts about a Virtualbox (see http://www.virtualbox.org/) installation"""
        virtualbox_facts = {}

        if not self.module.get_bin_path('VBoxControl'):
            return virtualbox_facts

        # Check for running instances
        (rc, out, err) = self.module.run_command('VBoxControl list runningvms')
        if rc == 0:
            virtualbox_facts.update({"virtualbox_running_vms": out.splitlines()})
        # Check for all instances
        (rc, out, err) = self.module.run_command

# Generated at 2022-06-23 02:17:39.851200
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    global module
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(type='str', required=False, default='*'),
            overrides=dict(type='dict', required=False, default={}),
        ),
        supports_check_mode=True,
    )
    linux_virtual = LinuxVirtual(module)
    # if the above raises an exception, the argument will be set to FAIL_SENTINEL
    module.exit_json(changed=False, ansible_facts=dict(linux_virtual=linux_virtual.get_all()))


# Generated at 2022-06-23 02:17:51.181566
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    # check Facts class creation
    linux_virtual = LinuxVirtual(module)
    # check virtual facts initialization
    result = linux_virtual.populate()
    assert result['virtualization_role'] in ['host', 'guest', 'NA']
    assert result['virtualization_type'] in ['container', 'kvm', 'parallels',
                                             'virtualbox', 'VMware', 'openstack',
                                             'openvz', 'xen', 'RHEV', 'lxc', 'podman',
                                             'KubeVirt', 'linux_vserver', 'ibm_systemz',
                                             'uml', 'bhyve', 'NA']
    assert result['virtualization_tech_guest']
    assert result['virtualization_tech_host']


# Generated at 2022-06-23 02:17:55.076526
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Test for constructor of class LinuxVirtual"""
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    assert lv is not None
    assert lv.module is not None



# Generated at 2022-06-23 02:18:05.223677
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    virtual_facts = linux_virtual.get_virtual_facts()
    guest_tech = virtual_facts['virtualization_tech_guest']
    host_tech = virtual_facts['virtualization_tech_host']
    assert 'docker' in guest_tech
    assert 'openvz' in guest_tech
    assert 'container' in guest_tech
    assert 'lxc' in guest_tech
    assert 'kvm' in host_tech
    assert 'xen' in host_tech
    assert 'PR/SM' in guest_tech
    assert 'ibm_systemz' in guest_tech
    assert 'parallels' in guest_tech
    assert 'openstack' in guest_tech
    assert 'openstack' in host_tech

# Generated at 2022-06-23 02:18:07.230432
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_obj = LinuxVirtual()
    result = test_obj.get_virtual_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-23 02:18:10.272198
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linc = LinuxVirtualCollector()
    assert linc._platform == 'Linux'
    assert isinstance(linc._fact_class, LinuxVirtual)


# Generated at 2022-06-23 02:18:14.438745
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Some simple tests for the constructor of class LinuxVirtual.
    '''
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual



# Generated at 2022-06-23 02:18:19.558990
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Constructor of class LinuxVirtual"""
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    module.exit_json(changed=False, ansible_facts={'virtual': {'name': 'openstack'}})


# Generated at 2022-06-23 02:18:20.750762
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    l = LinuxVirtual()


# Generated at 2022-06-23 02:18:28.636603
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    This unit tests verifies functionality of constructor in LinuxVirtual class
    by attempting to intializing a class with an empty constructor.
    This is meant to be run from the root dir of this source package
    using the following command:

    python -m test.unit.virtual.LinuxVirtual

    '''
    virtual_instance = LinuxVirtual()
    assert virtual_instance.get_facts() == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_guest': None, 'virtualization_tech_host': None}


# Generated at 2022-06-23 02:18:36.240106
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test case for constructor of class LinuxVirtualCollector"""
    assert issubclass(LinuxVirtualCollector, VirtualCollector)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:18:38.510433
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    assert lv is not None

# Generated at 2022-06-23 02:18:46.584383
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Test the constructor of the class LinuxVirtual
    '''

    module = AnsibleModule(
        argument_spec=dict(
        ),
        supports_check_mode=True
    )

    virtual = LinuxVirtual(module)
    virtual_facts = virtual.collect_virtual_facts()

    module.exit_json(ansible_facts=dict(virtual=virtual_facts))

# Import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:18:48.676307
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = None
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual


# Generated at 2022-06-23 02:18:53.519942
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = exit_json
    module.fail_json = fail_json

    linux_virtual = LinuxVirtual(module=module)
    virtual_facts = linux_virtual.populate()
    module.exit_json(ansible_facts=dict(virtual=virtual_facts))



# Generated at 2022-06-23 02:18:55.984348
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector()
    assert virtual.platform == "Linux"
    assert isinstance(virtual.fact, LinuxVirtual)


# Generated at 2022-06-23 02:18:58.337849
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.platform == 'Linux'
    assert isinstance(collector.fact, LinuxVirtual)

# Generated at 2022-06-23 02:19:03.299104
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    virtualFact = LinuxVirtual(module)
    virtual_facts = virtualFact.populate()
    keys = ("virtualization_role", "virtualization_type")
    for key in keys:
        assert key in virtual_facts

# Generated at 2022-06-23 02:19:05.898250
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj._platform == 'Linux'
    assert isinstance(obj, LinuxVirtual)
    assert isinstance(obj, VirtualCollector)

# Generated at 2022-06-23 02:19:08.726150
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test LinuxVirtual class init
    """
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual.module == module


# Generated at 2022-06-23 02:19:19.630307
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class LinuxVirtual.'''

    # Mock module class
    mock_module = Mock()

    # Fake check_output
    def mock_check_output(*cmd):
        '''Fake check_output'''
        return nrpe_check_output(*cmd, python_shell=False)

    # Fake is_directory
    def mock_is_directory(path):
        '''Fake is_directory'''
        return (path == '/sys' or
                path == '/proc' or
                path == '/dev/cgroup' or
                path == '/proc/self/cgroup')

    # Fake is_file
    def mock_is_file(path):
        '''Fake is_file'''
        if path == '/proc/1/cgroup':
            return True

# Generated at 2022-06-23 02:19:21.799627
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert c
    assert c.platform == 'Linux'


# Generated at 2022-06-23 02:19:31.598130
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import sys
    import unittest
    import utils
    # MockAnsibleModule is a context manager, so we must use "with" keyword
    with utils.MockAnsibleModule('ansible.module_utils.basic') as am:
        mod = am.module

# Generated at 2022-06-23 02:19:35.100766
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual = LinuxVirtual()
    if virtual.__class__ is LinuxVirtual:
        print("PASS: Successfully instantiated LinuxVirtual class")
    else:
        print("FAIL: Instantiation of LinuxVirtual class failed")


# Generated at 2022-06-23 02:19:36.221576
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual(dict())
    assert lv is not None


# Generated at 2022-06-23 02:19:38.513282
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtualCollector()
    assert facts._platform == 'Linux'
    assert isinstance(facts._fact_class, LinuxVirtual)

# Generated at 2022-06-23 02:19:40.158030
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    lv = LinuxVirtual(module)
    assert lv


# Generated at 2022-06-23 02:19:42.396776
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    result = linux_virtual.get_virtual_facts()
    assert type(result) is dict

# Generated at 2022-06-23 02:19:44.497174
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj is not None


# Generated at 2022-06-23 02:19:48.525090
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    fact_collector = LinuxVirtualCollector(module=module)
    assert fact_collector._platform == 'Linux'
    assert isinstance(fact_collector._fact_class(module=module), LinuxVirtual)


# Generated at 2022-06-23 02:19:52.065940
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._fact_class is LinuxVirtual
    assert lvc._platform == 'Linux'


# Generated at 2022-06-23 02:20:03.820919
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Test the constructor for module type
    module = Virtualization(module_args='', check_mode=False)
    assert module.module_args == ''

    module.module_args = 'name=foo,state=bar'
    assert module.module_args == 'name=foo,state=bar'

    module.module_args = 'foo=bar'
    assert module.module_args == 'foo=bar'

    # Test the constructor for Virtual class
    virtual = LinuxVirtual(module)
    assert virtual.module_name == 'virtual'
    assert virtual.module_aliases == ['guest']

# Generated at 2022-06-23 02:20:06.136858
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Unit test for constructor of class LinuxVirtual."""
    module = AnsibleModule(argument_spec={})
    assert LinuxVirtual(module) is not None


# Generated at 2022-06-23 02:20:09.598443
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    vc = LinuxVirtualCollector(module)
    assert vc.collect() is None

    with pytest.raises(NotImplementedError):
        vc.get_facts()

# Generated at 2022-06-23 02:20:11.199470
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    windows_virtual = LinuxVirtual()
    assert windows_virtual is not None


# Generated at 2022-06-23 02:20:19.876138
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.virtual.linux import LinuxVirtualCollector
    from copy import deepcopy
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleArgsParser

    # Get data from linux_virtual.py
    linux_virtual = LinuxVirtualCollector.collect()

    # Test virtualization_type
    assert linux_virtual['virtualization_type'] == 'kvm'

    # Test virtualization_role
    assert linux_virtual['virtualization_role'] == 'guest'

    # Test virtualization_tech_guest
    assert 'kvm' in linux_virtual['virtualization_tech_guest']
    assert 'container' in linux_virtual['virtualization_tech_guest']

    # Test virtualization_tech_host
    assert 'kvm' in linux

# Generated at 2022-06-23 02:20:25.070726
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Unit test for constructor of class LinuxVirtualCollector
    """
    virtual_facts_collector = LinuxVirtualCollector()
    assert virtual_facts_collector._platform == 'Linux'
    assert virtual_facts_collector._fact_class == LinuxVirtual
    assert virtual_facts_collector.collect() == virtual_facts_collector.facts


# Generated at 2022-06-23 02:20:37.612948
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts import FactCollector
    fact_collector = FactCollector()
    rhel_7_vm = LinuxVirtualCollector(fact_collector)
    assert rhel_7_vm.is_vm is True
    assert rhel_7_vm.is_container is False
    assert rhel_7_vm.is_hypervisor is False
    assert rhel_7_vm.is_virtualbox is False
    assert rhel_7_vm.is_openstack is False
    assert rhel_7_vm.is_kvm is True
    assert rhel_7_vm.is_kubernetes is False
    assert rhel_7_vm.is_xen is False
    assert rhel_7_vm.is_hyperv is False

# Generated at 2022-06-23 02:20:42.647573
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual constructor test
    """
    lvirt_instance = LinuxVirtual(module)
    assert lvirt_instance is not None

# Generated at 2022-06-23 02:20:48.300660
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Dummy AnsibleModule
    from ansible.module_utils.facts.virtual.base import AnsibleModule

    module = AnsibleModule
    lv = LinuxVirtualCollector(module)
    assert(lv.system == 'Linux')

# Generated at 2022-06-23 02:20:57.509896
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_LinuxVirtual = LinuxVirtual()
    test_LinuxVirtual.module = AnsibleModule

# Generated at 2022-06-23 02:20:58.440495
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:21:03.398596
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    assert lv.get_file_lines
    assert lv.get_file_content
    assert lv.get_virtual_facts


# Generated at 2022-06-23 02:21:06.288686
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.get_platform() == 'Linux'
    assert lvc.get_fact_class() == LinuxVirtual

# Generated at 2022-06-23 02:21:17.598125
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  test_module = AnsibleModule(argument_spec=dict())
  test_ansible_module = AnsibleModule(argument_spec=dict())
  test_ansible_os_family = AnsibleModule(argument_spec=dict())
  test_ansible_os_distribution = AnsibleModule(argument_spec=dict())
  test_ansible_system = AnsibleModule(argument_spec=dict())
  test_ansible_machine = AnsibleModule(argument_spec=dict())
  test_ansible_architecture = AnsibleModule(argument_spec=dict())
  test_ansible_distribution = AnsibleModule(argument_spec=dict())
  test_ansible_virtualization_role = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 02:21:23.810229
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module_args = {}
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    obj = LinuxVirtual(module)
    obj.get_virtual_facts()

# Unit test executable code
if __name__ == '__main__':
    print(json.dumps(test_LinuxVirtual_get_virtual_facts()))

# Generated at 2022-06-23 02:21:30.842421
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    return_values = dict(
        rc=0,
        changed=False,
        ansible_facts={},
        ansible_module=module
    )

    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    return_values['ansible_facts'] = virtual_facts

    module.exit_json(**return_values)


# Generated at 2022-06-23 02:21:40.827706
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    context_manager_mock = MagicMock(spec=['__enter__', '__exit__'])
    context_manager_mock.__enter__.return_value = ['kvm\n']
    open_mock = MagicMock(return_value=context_manager_mock)
    builtins_mock = {"open": open_mock}
    with patch.dict('sys.modules', builtins_mock):
        module_args = {}
        set_module_args(module_args)
        linux = LinuxVirtual()
        expected_result = {
            'virtualization_role': 'host',
            'virtualization_type': 'kvm',
            'virtualization_tech_host': {'kvm'},
            'virtualization_tech_guest': set()
        }
        assert linux.get_virtual

# Generated at 2022-06-23 02:21:48.027987
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual = LinuxVirtual()

    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values
    # Test with correct values

    with pytest.raises(Exception):
        # No exception expected
        virtual.get_virtual_facts()
        # No exception expected
        virtual.get_virtual_facts()
        # No exception expected
        virtual.get_virtual_facts()
        # No exception expected
        virtual.get_virtual_facts

# Generated at 2022-06-23 02:21:50.534746
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils.facts.virtual.base import BaseVirtual

    virtual = LinuxVirtual()

    assert isinstance(virtual, BaseVirtual)

# Generated at 2022-06-23 02:21:54.053551
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    assert type(linux_virtual) == LinuxVirtual
    assert linux_virtual.module is module


# Generated at 2022-06-23 02:22:04.771333
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()

    temp_dir = tempfile.mkdtemp()
    os.environ['VIRTUAL_ENV'] = temp_dir
    assert linux_virtual.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'virtualenv', 'virtualization_tech_guest': set(['virtualenv']), 'virtualization_tech_host': set()}
    del os.environ['VIRTUAL_ENV']
    shutil.rmtree(temp_dir)

    temp_dir = tempfile.mkdtemp()
    os.environ['CONTAINER'] = temp_dir

# Generated at 2022-06-23 02:22:11.012180
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''test case for method get_virtual_facts of class LinuxVirtual'''
    module = AnsibleModule(argument_spec={})
    virt = LinuxVirtual(module)
    virt_facts = virt.get_virtual_facts()
    assert virt_facts["virtualization_type"] == "kvm"
    assert virt_facts["virtualization_role"] == "host"
    assert "kvm" in virt_facts["virtualization_tech_host"]
    assert "kvm" in virt_facts["virtualization_tech_guest"]


# Generated at 2022-06-23 02:22:14.536854
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual = LinuxVirtualCollector()
    assert linux_virtual is not None


# Generated at 2022-06-23 02:22:18.137142
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test LinuxVirtual constructor
    """
    linux_virtual = LinuxVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    assert isinstance(linux_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:22:19.624960
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lv = LinuxVirtualCollector()
    assert lv.platform == 'Linux'

# Generated at 2022-06-23 02:22:28.343135
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    lv = LinuxVirtual(dict(mod=dict(get_bin_path=return_value), run_command=return_value))
    lv.module.run_command.side_effect = [
        (0, 'openvz', ''),
        (0, 'hypervisor', ''),
        (0, 'systemd-nspawn', '')
    ]
    assert lv.get_virtual_facts() == dict(
        virtualization_type='openvz',
        virtualization_role='guest',
        virtualization_tech_guest=set(['container', 'openvz']),
        virtualization_tech_host=set([])
    )

# Generated at 2022-06-23 02:22:29.921923
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    test_obj = LinuxVirtual(dict())
    assert isinstance(test_obj, LinuxVirtual)


# Generated at 2022-06-23 02:22:35.569047
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert "kvm" in virtual_facts['virtualization_tech_host']
    assert "kvm" in virtual_facts['virtualization_tech_guest']
# Class to derive facts about Linux operating systems

# Generated at 2022-06-23 02:22:43.489580
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value='/bin/dmidecode')
    args = {}
    obj = LinuxVirtual(module, args)
    obj.get_file_lines = MagicMock(return_value='return_value')
    obj.get_file_content = MagicMock(return_value='return_value')
    obj.module.run_command = MagicMock(return_value=(0, 'return_value', 'return_value'))
    res = obj.get_virtual_facts()
    assert res is not None

# Generated at 2022-06-23 02:22:47.602426
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """ Unit test for constructor of class LinuxVirtualCollector """
    my_virt = LinuxVirtualCollector()
    assert my_virt.platform == 'Linux', "Incorrect value for platform"
    assert my_virt.fact_class == LinuxVirtual, "Incorrect value for fact_class"

# Generated at 2022-06-23 02:22:53.896705
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    if not HAS_PSUTIL:
        module.fail_json(msg="psutil module is required")
    if not HAS_DBUS:
        module.fail_json(msg="dbus module is required")

    linux_virtual_facts = LinuxVirtual(module).get_facts()
    module.exit_json(ansible_facts=linux_virtual_facts)



# Generated at 2022-06-23 02:22:59.056840
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    lv = LinuxVirtual(module)
    virtual = lv.get_virtual_facts()
    assert type(virtual) is dict
    assert 'virtualization_type' in virtual
    assert 'virtualization_role' in virtual
    assert 'virtualization_tech_host' in virtual
    assert 'virtualization_tech_guest' in virtual



# Generated at 2022-06-23 02:23:02.160042
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    facts_dict = dict()
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)
    facts_dict.update(lv.get_virtual_facts())
    assert facts_dict['virtualization_type'] is not None


# Generated at 2022-06-23 02:23:03.415028
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    l = LinuxVirtual()
    assert l is not None


# Generated at 2022-06-23 02:23:07.287360
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test for constructor of class LinuxVirtual
    """
    linux_virtual = LinuxVirtual()
    assert linux_virtual.distribution is not None
    assert linux_virtual.distribution_release is not None
    assert linux_virtual.facts is not None

# Generated at 2022-06-23 02:23:19.149388
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    virtual_facts = linux_virtual.get_virtual_facts()
    assert type(virtual_facts) == dict
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set([])
    assert virtual_facts['virtualization_tech_host'] == set([])

#class OpenBSDVirtual(Virtual):
#    platform = "OpenBSD"
#    distribution = None
#
#    def get_virtual_facts(self):
#        virtual_facts = {}
#
#        if os.path.exists('/proc/cpuinfo'):
#            for line in get_file_lines('/proc/cpuinfo'):
#                if re.match('^

# Generated at 2022-06-23 02:23:22.017610
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    assert lv is not None


# Generated at 2022-06-23 02:23:30.001343
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    task = LinuxVirtual(module)

    assert 'kvm' in task.get_virtual_facts()['virtualization_tech_guest']
    assert 'virtualbox' in task.get_virtual_facts()['virtualization_tech_guest']
    assert 'openstack' in task.get_virtual_facts()['virtualization_tech_guest']
    assert 'qemu' in task.get_virtual_facts()['virtualization_tech_guest']
    assert 'container' in task.get_virtual_facts()['virtualization_tech_guest']
    assert 'containerd' in task.get_virtual_facts()['virtualization_tech_guest']
    assert 'docker' in task.get_virtual_facts()['virtualization_tech_guest']

# Generated at 2022-06-23 02:23:42.184847
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    if os.path.exists('/usr/bin/python2'):
        py2 = os.path.realpath('/usr/bin/python2')
    else:
        py2 = None

    if os.path.exists('/usr/bin/python3'):
        py3 = os.path.realpath('/usr/bin/python3')
    else:
        py3 = None

    if py2 and py3:
        # Run unit tests with Python 2
        run_command = AnsibleModule(argument_spec={})
        lv = LinuxVirtual(run_command)
        lv.get_virtual_facts()

        # Run unit tests with Python 3
        py2_env = os.environ.copy()
        py2_env['PYTHONPATH'] = '/usr/bin/python3'


# Generated at 2022-06-23 02:23:48.251981
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})

    # Create an object
    linux_virtual = LinuxVirtual(module)

    # Get facts
    linux_virtual_get_virtual_facts = linux_virtual.get_virtual_facts()

    # Return facts
    module.exit_json(
        ansible_virtual=linux_virtual_get_virtual_facts
    )
if __name__ == '__main__':
    main()