

# Generated at 2022-06-23 02:13:48.989232
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    my_obj = LinuxVirtualCollector(module)
    assert my_obj._fact_class == LinuxVirtual
    assert my_obj._platform == 'Linux'


# Generated at 2022-06-23 02:14:00.777001
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mc_facts = dict(
        module_setup=dict(
            filter='ansible.builtin.virtual'
        )
    )
    mc_result = dict(
        ansible_facts=dict(
            virtual=dict(
                virtualization_type='NA',
                virtualization_role='NA'
            )
        )
    )
    module = MagicMock(
        params=dict(),
        check_mode=False,
        get_bin_path=MagicMock(return_value=None),
        run_command=MagicMock(return_value=(0, '', '')),
    )
    module.get_bin_path.side_effect = lambda x: '/usr/bin/%s' % x
    lv = LinuxVirtual(module)

# Generated at 2022-06-23 02:14:08.669047
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lxvc = LinuxVirtualCollector()

    fv = lxvc.collect()
    assert fv.pop('collector') == 'LinuxVirtual'

    if 'virtualization_type' in fv:
        # virtualization_type and virtualization_role must be set together
        assert 'virtualization_role' in fv
    else:
        # or not set at all
        assert 'virtualization_role' not in fv


# builtin Ansible module entry point

# Generated at 2022-06-23 02:14:20.428308
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock({},
        "mock_arg_spec_facts.json")
    mock_facts = {
        "distribution": "centos",
        "virtualization_role": "guest",
        "virtualization_tech_host": ["vmware"],
        "virtualization_tech_guest": ["docker", "kvm"],
    }
    mock_virtual = LinuxVirtual(module)
    mock_virtual._collect()
    mock_virtual_collector = LinuxVirtualCollector(module)
    mock_virtual_collector.collect(mock_facts)
    assert mock_facts["virtualization_role"] == "guest"
    assert mock_facts["virtualization_tech_host"] == ["vmware"]
    assert mock_facts["virtualization_tech_guest"] == ["docker", "kvm"]

# Generated at 2022-06-23 02:14:31.987508
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    def test_module(module_name='ansible.builtin.setup', suffix='', options_suffix='', kwargs=None):
        if kwargs is None:
            kwargs = {}
        module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
            check_invalid_arguments=False,
        )
        module.params['gather_subset'] = ['all']
        module.params['filter'] = '*'
        module.params['_ansible_check_mode'] = True
        module.params['_ansible_debug'] = False
        module.params['_ansible_diff'] = False

# Generated at 2022-06-23 02:14:33.830812
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector(), LinuxVirtualCollector)

# Generated at 2022-06-23 02:14:41.181965
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_ = LinuxVirtual()

    virtual_.get_file_lines = lambda file: open(file).readlines()
    virtual_.get_file_content = lambda file: open(file).read()
    virtual_.get_bin_path = lambda file: file
    virtual_.module = type('', (), {'run_command': lambda self, command: (0, '', '')})()

    # FIXME: use testinfra
    facts = virtual_.get_virtual_facts()
    assert not facts['virtualization_type'].startswith('kvm')
    assert facts['virtualization_type'] != 'NA'
    assert facts['virtualization_role'] != 'NA'

# Generated at 2022-06-23 02:14:47.728681
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    log_mocker = LogMocker()
    log_mocker.start()

# Generated at 2022-06-23 02:14:49.175900
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual('module')
    assert linux_virtual.module is not None


# Generated at 2022-06-23 02:14:51.618879
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert lv.is_virtual() is False
    assert lv.get_virtual_facts() == {'virtualization_type': 'NA', 'virtualization_role': 'NA'}

# Generated at 2022-06-23 02:14:54.870407
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Constructor for class LinuxVirtual
    :return:
    """
    linux_virtual = LinuxVirtual('')
    assert isinstance(linux_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:15:06.036724
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    ''' linux_virtual.py: LinuxVirtual.__init__() '''
    MockModule = imp.new_module('ansible_collections.ansible.builtin.plugins.module_utils.facts.virtual.linux_virtual')
    sys.modules['ansible_collections.ansible.builtin.plugins.module_utils.facts.virtual.linux_virtual'] = MockModule
    MockModule.ANSIBLE_MODULE_ARGS = {}
    MockModule.run_command = Mock(return_value=(0, 'foo', ''))
    mock_module = MagicMock(name='ansible_collections.ansible.builtin.plugins.module_utils.facts.virtual.linux_virtual')
    mock_module.params = {}
    mock_module.run_command = Mock(return_value=(0, '', ''))

    virt

# Generated at 2022-06-23 02:15:11.577938
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test for constructor of class LinuxVirtual
    :return: None
    """
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = True
    lv = LinuxVirtual(module_mock)
    assert module_mock.exit_json.call_count == 0
    assert isinstance(lv, LinuxVirtual)


# Generated at 2022-06-23 02:15:13.126789
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual = LinuxVirtual()
    assert isinstance(virtual.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:15:17.742021
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''linux_virtual.py: LinuxVirtual class__init__ test'''
    module = AnsibleModule({})
    obj = LinuxVirtual(module)

    assert obj.vm_type == 'None', 'vm_type is empty'
    assert obj.vm_role == 'None', 'vm_role is empty'


# Generated at 2022-06-23 02:15:22.827809
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    # Test if constructor sets the _fact_class property to the LinuxVirtual class
    assert linux_virtual_collector._fact_class.__name__ == 'LinuxVirtual'
    # Test if constructor sets the _platform property to 'Linux'
    assert linux_virtual_collector._platform == 'Linux'

# Generated at 2022-06-23 02:15:27.247028
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    sut = LinuxVirtual()
    result = sut.get_virtual_facts()
    assert result == {'virtualization_role': 'host', 'virtualization_type': 'docker', 'virtualization_tech_host': {'docker'}, 'virtualization_tech_guest': {}}
test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:15:30.223454
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """linux_virtual - constructor test
    """
    virtual_facts = LinuxVirtual({})
    assert virtual_facts.__class__.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:15:33.070775
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # stub
    virtual = LinuxVirtual()
    assert (virtual.get_virtual_facts() == None, "")

# Generated at 2022-06-23 02:15:38.287917
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    create a LinuxVirtual class object
    '''
    module = AnsibleModule(argument_spec={})
    lx_virtual = LinuxVirtual(module)
    module.exit_json(changed=False, ansible_facts=dict(linux_virtual=lx_virtual.detect()))

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:15:42.629419
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # create object instance of class LinuxVirtual
    linux_virtual_object = LinuxVirtual()
    # call get_virtual_facts
    linux_virtual_object.get_virtual_facts()

# Generated at 2022-06-23 02:15:50.607809
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Assume function under test is isolated by module.
    # This unit test runs in the same process as the unit test module.
    class MockLinuxVirtual:
        def __init__(self):
            self.module = MockLinuxSystemInfo()
            self.warn = self.module.warn
            self.warnings = self.module.warnings


# Generated at 2022-06-23 02:15:58.896684
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    obj = LinuxVirtual()
    assert isinstance(obj.distribution, LinuxDistributionInfo)
    assert isinstance(obj.distribution.codename, str)
    assert isinstance(obj.distribution.id, str)
    assert isinstance(obj.distribution.major_version, str)
    assert isinstance(obj.distribution.minor_version, str)
    assert isinstance(obj.distribution.description, str)
    assert isinstance(obj.distribution.release_file, str)
    assert isinstance(obj.release, str)
    assert isinstance(obj.system, LinuxSystemInfo)
    assert isinstance(obj.kernel, str)
    assert isinstance(obj.hostname, str)
    assert isinstance(obj.domain, str)
    assert isinstance(obj.fqdn, str)
   

# Generated at 2022-06-23 02:16:03.835619
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector is not None

    fact = collector.collect()
    assert fact is not None
    assert fact.has_key('virtualization_type')
    assert fact.has_key('virtualization_role')
    assert fact['virtualization_role'] != ""
    assert fact.has_key('virtualization_tech_guest')
    assert fact.has_key('virtualization_tech_host')

# Generated at 2022-06-23 02:16:08.774018
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    vf = lv.get_virtual_facts()
    assert isinstance(vf, dict), 'LinuxVirtual.get_virtual_facts returned %s instead of a dict' % type(vf)


# Generated at 2022-06-23 02:16:13.644588
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = MagicMock()
    module.get_bin_path.return_value = '/bin/dmidecode'
    module.run_command.return_value = (0, '', '')
    lvc = LinuxVirtualCollector(module=module)
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:16:18.848933
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  module = AnsibleModule(
    argument_spec = dict(
    ),
    supports_check_mode=True
  )

  # Get the LinuxVirtual class object
  lv = LinuxVirtual(module)

  # Get the virtual facts from the class method
  res_args = lv.get_virtual_facts()
  module.exit_json(changed=False, ansible_facts=res_args)


# Generated at 2022-06-23 02:16:21.293243
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    virt = LinuxVirtual(module)

    assert(virt is not None)


# Generated at 2022-06-23 02:16:23.702809
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module=module)
    assert lv

# Generated at 2022-06-23 02:16:25.837667
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    l = LinuxVirtual()
    assert l is not None


# Generated at 2022-06-23 02:16:28.046556
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    LinuxVirtual - constructor
    """
    module = AnsibleModule(
        argument_spec=dict(),
    )

    assert LinuxVirtual(module).module == module


# Generated at 2022-06-23 02:16:33.828120
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_file_content = get_file_content_mock
    module.get_bin_path = get_bin_path_mock
    collector = LinuxVirtualCollector(module=module)
    assert collector.module == module


# Generated at 2022-06-23 02:16:40.351170
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Unit test.
    """
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    result = LinuxVirtualCollector(module).collect()

    # Ensure virtualization_type is defined
    assert 'virtualization_type' in result, "virtualization_type is missing from result"
    # Ensure virtualization_role is defined
    assert 'virtualization_role' in result, "virtualization_role is missing from result"



# Generated at 2022-06-23 02:16:43.436404
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector(dict(), dict())
    assert LinuxVirtualCollector._platform == 'Linux'
    assert virtual.get_platform() == 'Linux'


# Generated at 2022-06-23 02:16:48.467404
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    with patch('ansible.module_utils.facts.virtual.LinuxVirtual._get_virtual_facts') as get_virtual_facts_mock:
        test_module = LinuxVirtual(module=module)
        test_module.get_virtual_facts()

        get_virtual_facts_mock.assert_called_once()


# Generated at 2022-06-23 02:16:51.798793
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    clc = LinuxVirtualCollector()
    assert clc._fact_class == LinuxVirtual
    assert clc._platform == 'Linux'

# Generated at 2022-06-23 02:16:54.802604
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    results = LinuxVirtual_get_virtual_facts(test_module)
    assert results['virtualization_type'] == 'virtualbox'

# Generated at 2022-06-23 02:16:58.336660
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Test constructor of class LinuxVirtual
    '''
    obj = LinuxVirtual()
    assert isinstance(obj, LinuxVirtual)


# Generated at 2022-06-23 02:17:01.676799
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    print(lv.virtual_facts())
    assert lv is not None



# Generated at 2022-06-23 02:17:12.584164
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts = dict()
    virtual_facts['virtualization_role'] = 'host'
    virtual_facts['virtualization_type'] = 'kvm'
    #virtual_facts['virtualization_tech_guest'] = 'container'
    #virtual_facts['virtualization_tech_host'] = 'kvm'
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    facts = linux_virtual.get_virtual_facts()
    #print(facts)
    assert facts['virtualization_role'] == virtual_facts['virtualization_role']
    assert facts['virtualization_type'] == virtual_facts['virtualization_type']
    #assert facts['virtualization_tech_guest'] == virtual_facts['virtualization_tech_guest']
    #assert facts['virtualization_tech

# Generated at 2022-06-23 02:17:15.680796
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts is not None


# Generated at 2022-06-23 02:17:19.593785
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_module = VirtualCollector
    obj = virtual_module()
    assert obj._platform == 'Linux'
    assert obj._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:17:31.009119
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test constructor of class LinuxVirtualCollector.

    Raises:
        AssertionError: Raises if any test fails.
    """
    logger = logging.getLogger()
    logger.setLevel(logging.ERROR)
    if sys.version_info[0] == 2:
        module = AnsibleModule(argument_spec=dict())
    else:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils._text import to_native
        module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    lvc = LinuxVirtualCollector(module)
    assert lvc._facts == None
    assert lvc._fact_class.__name__ == 'LinuxVirtual'
    assert lvc._platform == 'Linux'

# Generated at 2022-06-23 02:17:33.831931
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    collector = LinuxVirtualCollector(module)

    assert isinstance(collector._fact_class, LinuxVirtual)
    assert collector._platform == 'Linux'

# Generated at 2022-06-23 02:17:40.696557
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual_obj = LinuxVirtual(dict())

    assert linux_virtual_obj.module == None
    assert linux_virtual_obj.gather_subset == ['!all']
    assert linux_virtual_obj.gather_network_resources == ['!all']

# Generated at 2022-06-23 02:17:45.772362
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    keys = ['virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host']
    assert set(virtual_facts.keys()) == set(keys)



# Generated at 2022-06-23 02:17:49.598054
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Get the class to instantiate
    cls = LinuxVirtualCollector

    # Check the platform is Linux
    assert cls._platform == 'Linux'
    # Check the fact class is LinuxVirtual
    assert cls._fact_class.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:18:01.603936
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module.get_bin_path = lambda name: name
    lv.module.run_command = lambda args: (0, '', '')
    ret = lv.get_virtual_facts()
    assert ret['virtualization_type'] == 'NA'
    assert ret['virtualization_role'] == 'NA'
    assert ret['virtualization_tech_host'] == set()
    assert ret['virtualization_tech_guest'] == set()
    lv.module.get_bin_path = lambda name: None
    lv.module.run_command = lambda args: (0, '', '')
    ret = lv.get_virtual_facts()
    assert ret['virtualization_type'] == 'NA'
    assert ret['virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:18:06.979371
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    system = LinuxVirtual(module)
    output = system.get_virtual_facts()
    #print json.dumps(output, ensure_ascii=False)
    module.exit_json(changed=False, ansible_facts=output)

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.local import LocalAnsibleModule

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:18:17.128273
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    # TODO: fix mock
    #lv.module.run_command.return_value = (0, open('test/virtual_kvm_guest').read(), '')
    # lv.get_file_content = lambda x: open('test/virtual_kvm_guest').read()
    lv.get_file_content = lambda x: open('test/' + x).read()
    lv.get_file_lines = lambda x: open('test/' + x).read().splitlines()
    facts = lv.get_virtual_facts()
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    #assert facts['virtualization_tech_guest'] == set(('kvm', 'container'))
   

# Generated at 2022-06-23 02:18:26.897674
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test LinuxVirtual constructor.

    :return: Nothing
    """

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_PSUTIL:
        module.fail_json(msg=missing_required_lib('psutil'), exception=PSUTIL_IMP_ERR)

    linux_virtual = LinuxVirtual(module)
    linux_virtual.populate()

    # Test for exception for dmidecode command not found
    linux_virtual.module.run_command = Mock(side_effect=OSError)
    linux_virtual.populate()

    # Test for exception for lscpu command not found

# Generated at 2022-06-23 02:18:29.690341
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc is not None
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:43.700865
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """ Unit test for class LinuxVirtualCollector """
    global MODULE_CACHE
    MODULE_CACHE = {}

    class TestModule:
        def __init__(self, params):
            self.params = params
            self.exit_json = lambda c, m: c

        def get_bin_path(self, name):
            return None

    class TestAnsibleModule:
        def __init__(self, **kwargs):
            self.params = dict()
            for key in kwargs:
                self.params[key] = kwargs[key]

        def fail_json(self, *args, **kwargs):
            raise Exception('An unexpected error happened.')

        def run_command(self, args, check_rc=True):
            return 0, '', ''


# Generated at 2022-06-23 02:18:49.964677
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = AnsibleModuleMock()
    virtual_facts = lv.get_virtual_facts()
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert virtual_facts['virtualization_type'] in ('docker', 'container', 'lxc', 'podman', 'openvz', 'containerd', 'systemd-nspawn', 'NA')
    assert virtual_facts['virtualization_role'] in ('guest', 'host', 'NA')

# Generated at 2022-06-23 02:18:51.940278
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lc = LinuxVirtualCollector()
    assert lc._fact_class == LinuxVirtual
    assert lc._platform == 'Linux'


# Generated at 2022-06-23 02:18:54.578718
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    ll = LinuxVirtual()
    res = ll.get_virtual_facts()
    assert isinstance(res, dict)


# Generated at 2022-06-23 02:18:58.247917
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    linux_virtual = LinuxVirtual(module)

    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts is not None

# Generated at 2022-06-23 02:19:01.403612
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None


# Generated at 2022-06-23 02:19:03.576458
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual_obj = LinuxVirtual()
    linux_virtual_obj.get_virtual_facts()

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:19:13.899374
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Unit test for constructor of class LinuxVirtual"""
    try:
        from ansible.modules.system.linux import LinuxVirtual
    except ImportError:
        sys.exit(SKIP_MSG)

    linux_virtual_obj = LinuxVirtual()

    module = AnsibleModule({})

    assert type(linux_virtual_obj.module) is AnsibleModule

    if not linux_virtual_obj.module.check_mode:
        linux_virtual_obj.virtual_facts = {}
        linux_virtual_obj.virtual_facts = linux_virtual_obj.get_virtual_facts()

        assert type(linux_virtual_obj.virtual_facts) is dict
        assert 'virtualization_type' in linux_virtual_obj.virtual_facts
        assert 'virtualization_role' in linux_virtual_obj.virtual_facts

# Generated at 2022-06-23 02:19:16.262937
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj.platform == 'Linux'
    obj.platform = 'Linux'


# Generated at 2022-06-23 02:19:21.860490
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    This function is to test constructor of class LinuxVirtualCollector
    """
    linux_virtual = LinuxVirtualCollector()
    assert linux_virtual.platform == 'Linux'
    assert linux_virtual.fact_class == 'LinuxVirtual'
    assert linux_virtual._fact_class == LinuxVirtual
    assert linux_virtual._platform == 'Linux'


# Generated at 2022-06-23 02:19:25.688216
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test for constructor of class LinuxVirtualCollector."""
    result = create_collector(LinuxVirtualCollector, 'Linux')

    assert result.fact_class is LinuxVirtual
    assert result.platform is 'Linux'

# Generated at 2022-06-23 02:19:31.048602
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    try:
        module = AnsibleModule(argument_spec={}, supports_check_mode=True)
        if not HAS_LIBVIRT:
            module.fail_json(msg="libvirt python module is not installed")
        virtual = LinuxVirtual(module)
        virtual.populate()
    except Exception as e:
        print("exception: %s" % e)
        raise



# Generated at 2022-06-23 02:19:39.211833
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Return values and parameters
    params = []
    return_value = []

    # Invoke method
    method = LinuxVirtual.get_virtual_facts
    p = mock.patch.object(LinuxVirtual, method.__name__, autospec=True)
    mocked_method = p.start()
    mocked_method.return_value = return_value
    try:
        method(*params)
        mocked_method.assert_called_once_with(*params)
    except Exception:
        raise
    finally:
        p.stop()

if __name__ == '__main__':
    _unittest.main()

# Generated at 2022-06-23 02:19:41.320555
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    result = lv.get_virtual_facts()

# Generated at 2022-06-23 02:19:46.711174
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    ''' Make sure we can create instance properly '''
    from ansible.module_utils.basic import AnsibleModule
    try:
        module = AnsibleModule({}, supports_check_mode=True)
    except Exception:
        pass
    else:
        obj = LinuxVirtual(module)
        assert isinstance(obj, LinuxVirtual)



# Generated at 2022-06-23 02:19:57.871599
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test setUp
    m = MagicMock()
    m.get_bin_path = MagicMock(return_value='/bin/dmidecode')
    m.run_command = MagicMock(return_value=(0, '# Product Name: BHYVE', ''))
    m.get_file_lines = MagicMock(side_effect=lambda f: ['virt_type'])
    m.get_file_content = MagicMock(return_value='invalid')
    l = LinuxVirtual(m)
    # Test execution
    result = l.get_virtual_facts()
    # Test assertions
    m.get_file_content.assert_any_call('/sys/devices/virtual/dmi/id/product_name')

# Generated at 2022-06-23 02:20:03.361075
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    host_facts = dict()
    c = LinuxVirtualCollector(host_facts)
    if not isinstance(c, VirtualCollector):
        print("Failed to create LinuxVirtualCollector object")
        return False

    if not isinstance(c.facts, Virtual):
        print("Failed to create Virtual object")
        return False

    return True


# Generated at 2022-06-23 02:20:06.028384
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    set_module_args(dict(
        gather_subset=dict(type='list', elements='virtual'),
    ))
    linux_virtual_ins = LinuxVirtual(module)
    result = linux_virtual_ins.get_virtual_facts()
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:20:10.975968
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Unit test for constructor of class LinuxVirtualCollector
    """
    # Constructor of class LinuxVirtualCollector
    lvc = LinuxVirtualCollector()

    # Check that _fact_class is LinuxVirtual
    assert lvc._fact_class == LinuxVirtual
    # Check that _platform is Linux
    assert lvc._platform == 'Linux'


###
### Unit tests for class LinuxVirtual
###


# Generated at 2022-06-23 02:20:17.103526
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lv = LinuxVirtual(module)
    assert lv.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'docker',
        'virtualization_tech_host': {},
        'virtualization_tech_guest': {
            'docker',
            'container',
        }
    }
# Getter for class LinuxVirtual

# Generated at 2022-06-23 02:20:22.020168
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lxc = LinuxVirtualCollector(module)
    assert lxc.platform == 'Linux'
    assert lxc.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:20:25.650125
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    lv.collect()
    if not lv.virtual_facts['virtualization_type']:
        print("Unexpected virtualization_type: %s" % lv.virtual_facts['virtualization_type'])


# Generated at 2022-06-23 02:20:31.071127
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
    )
    collector = LinuxVirtualCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual
    assert collector.fact_name == 'virtual'



# Generated at 2022-06-23 02:20:35.769719
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    test_obj = LinuxVirtual()

    # check type of test_obj
    assert isinstance(test_obj, (LinuxVirtual))

    # check if test_obj is an instance of BaseVirtual or not
    assert isinstance(test_obj, (BaseVirtual))

    # check if test_obj is an instance of LinuxDistribution or not
    assert isinstance(test_obj, (LinuxDistribution))


# Generated at 2022-06-23 02:20:40.176499
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule()
    x = LinuxVirtual(module)
    y = x.get_virtual_facts()
    assert y['virtualization_type'] == 'NA'
    assert y['virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:20:53.606000
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    L = LinuxVirtual()
    L.module = MagicMock()
    L.module.run_command.return_value = (0, '', '')
    L.module.get_bin_path.return_value = '/bin/dmidecode'
    dmi_bin = L.module.get_bin_path('dmidecode')
    with patch("ansible.module_utils.facts.virtual.LinuxVirtual.get_file_content") as get_file_content_mock, patch("ansible.module_utils.facts.virtual.LinuxVirtual.get_file_lines") as get_file_lines_mock:
        get_file_content_mock.return_value = 'Some random text'
        get_file_lines_mock.return_value = ['Some random line']

# Generated at 2022-06-23 02:20:56.793584
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = None
    os = LinuxVirtual(module)
    os.get_virtual_facts()
    # TODO: Better test
    # In the meantime, no test is better than crashing
    assert True


# Generated at 2022-06-23 02:21:07.236770
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import os
    # create a mock module instance
    class _mock_module:
        def __init__(self):
            self.run_command = _mock_run_command
            self.get_bin_path = _mock_get_bin_path
            self.get_file_content = _mock_get_file_content

    def _mock_run_command(self, args):
        # handle dmidecode
        if 'dmidecode' in args:
            if 'InnoTek Systemberatung GmbH' in args:
                return (0, 'InnoTek Systemberatung GmbH', None)
            if 'BHYVE' in args:
                return (0, 'BHYVE', None)
            return (1, '', None)
        # handle lscpu
       

# Generated at 2022-06-23 02:21:18.342978
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    with mock.patch('os.path.exists', return_value=True):
        with mock.patch('ansible.module_utils.facts.virtual.LinuxVirtual._get_virtual_facts_from_dmidecode', return_value=True):
            with mock.patch('os.path.exists', return_value=True):
                lv = LinuxVirtual()
                lv.module=mock.MagicMock()
                lv.module.get_bin_path=mock.MagicMock()
                lv.module.get_bin_path.return_value='/bin/dmidecode'
                lv.module.run_command=mock.MagicMock()
                lv.module.run_command.return_value=(0, 'VirtualBox', '')
                virtual_facts = lv.get_virtual_facts

# Generated at 2022-06-23 02:21:29.764799
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    virtual_facts = linux_virtual.get_virtual_facts()
    # Check if key 'virtualization_layet' present in return value
    assert 'virtualization_layer' in virtual_facts
    # Check if key 'virtualization_type' present in return value
    assert 'virtualization_type' in virtual_facts
    # Check if key 'virtualization_role' present in return value
    assert 'virtualization_role' in virtual_facts
    # Check if key 'virtualization_tech_host' present in return value
    assert 'virtualization_tech_host' in virtual_facts
    # Check if key 'virtualization_tech_guest' present in return value
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:21:38.233163
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # FIXME: Replace with Mock module
    # Mock-import module(s)
    from ansible.module_utils import basic

    # Mock-import object(s)
    from ansible.module_utils.facts import processor
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts import distribution
    from ansible.module_utils.facts import network
    from ansible.module_utils.facts.collector import BaseFactCollector

    # FIXME: Remove this "solution"
    # Monkey-patching hasattr to make sure that the code is not depending on
    # the content
    def hasattr_mock(module, attr):
        return True

    basic.hasattr = hasattr_mock

    # Mock-import variable(s)

# Generated at 2022-06-23 02:21:40.792912
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert isinstance(linux_virtual, LinuxVirtual) is True

# Generated at 2022-06-23 02:21:46.098133
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    test_virt = LinuxVirtualCollector()
    assert hasattr(test_virt, '_facts')
    assert hasattr(test_virt, '_fact_class')
    assert hasattr(test_virt, '_platform')
    assert test_virt._fact_class is LinuxVirtual
    assert test_virt._platform == 'Linux'



# Generated at 2022-06-23 02:21:56.552857
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    from ansible.module_utils.facts.virtual.linux import get_file_content
    from ansible.module_utils.facts.virtual.linux import get_file_lines
    import os
    import glob
    mock_module = Mock()
    linux_virtual = LinuxVirtual(mock_module)
    with patch.object(glob, 'glob') as mock_glob:
        mock_glob.return_value = []
        with patch.object(os.path, 'isfile') as mock_isfile:
            mock_isfile.return_value = True
            with patch.object(os.access, 'isdir') as mock_isdir:
                mock_isdir.return_value = True

# Generated at 2022-06-23 02:21:57.888281
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = mock.Mock()
    instance = LinuxVirtual(module)
    assert isinstance(instance, LinuxVirtual)

# Generated at 2022-06-23 02:22:00.129065
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = MagicMock()
    collector = LinuxVirtualCollector(module)
    assert collector._fact_class == LinuxVirtual
    assert collector._platform == 'Linux'

# Generated at 2022-06-23 02:22:04.142335
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = MockModule()
    module.run_command = Mock(return_value="return")
    # Test without fail_on_missing=False
    x = LinuxVirtual(module, fail_on_missing=False)
    # Test with fail_on_missing=False
    y = LinuxVirtual(module, fail_on_missing=False)


# Generated at 2022-06-23 02:22:08.057648
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    x = LinuxVirtualCollector(module=module)

    # Verify instance was properly built
    assert x._fact_class is LinuxVirtual
    assert x._platform == 'Linux'
    assert x._module == module

# Unit tests for class LinuxVirtual

# Generated at 2022-06-23 02:22:10.445442
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_collector = LinuxVirtualCollector()
    assert virtual_collector._platform == 'Linux'


# Generated at 2022-06-23 02:22:15.508079
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual = LinuxVirtual()
    assert 'LinuxVirtual' in str(type(virtual))

    new_module = AnsibleModule(argument_spec={})
    virtual.module = new_module
    virtual.get_virtual_facts()


if __name__ == "__main__":
    from ansible.module_utils.basic import *
    test_LinuxVirtual()

# Generated at 2022-06-23 02:22:25.641416
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    l = LinuxVirtual()
    # Testing all possible values for virtualization_type
    l.virtualization_type = 'powervm_lx86'
    assert l.virtualization_type == 'powervm_lx86'
    l.virtualization_type = 'lxc'
    assert l.virtualization_type == 'lxc'
    l.virtualization_type = ' containerd'
    assert l.virtualization_type == 'containerd'
    l.virtualization_type = 'docker'
    assert l.virtualization_type == 'docker'
    l.virtualization_type = 'openvz'
    assert l.virtualization_type == 'openvz'
    l.virtualization_type = 'openstack'
    assert l.virtualization_type == 'openstack'
    l.virtualization_

# Generated at 2022-06-23 02:22:29.897594
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    x = LinuxVirtual(module)
    module = MagicMock()
    result = x.get_virtual_facts()
    assert result == {}


# Generated at 2022-06-23 02:22:39.001072
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # get_virtual_facts does not need to run in any specfic directory
    cwd = os.getcwdu()

    test = LinuxVirtual()

    class ModuleFailException(Exception):
        pass

    class Module(object):
        def __init__(self, **kwargs):
            pass

        def get_bin_path(self, executable=None):
            if executable == 'dmidecode':
                return '/usr/sbin/dmidecode'
            return None

        def run_command(self, executable):
            if executable == ['lscpu']:
                return 0, '', ''
            return 0, 'Vendor: Microsoft\n', ''

    class TestFacts(object):
        def __init__(self, **kwargs):
            self.ansible_facts = {}


# Generated at 2022-06-23 02:22:47.806783
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    vm = LinuxVirtual()
    vm.module = AnsibleModuleMock()
    vm.module.get_bin_path = MagicMock(return_value=None)
    vm.module.run_command = MagicMock(return_value=(0, None, None))

    # dmidecode
    result = {
        'virtualization_role': 'host',
        'virtualization_type': 'kvm',
        'virtualization_tech_host': {'kvm'},
        'virtualization_tech_guest': set(),
    }
    # lxc
    vm.module.run_command.side_effect = [
        (0, None, None),
        (0, 'lxc', None),
    ]
    assert vm.get_virtual_facts() == result

    # docker
    vm.module.run_

# Generated at 2022-06-23 02:22:52.420179
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    with tempfile.TemporaryDirectory() as test_dir:
        collector = LinuxVirtualCollector(module=DummyModule(basedir=test_dir))
        assert collector is not None

        # Verify the collector name
        assert collector.name == 'LinuxVirtualCollector'


# Unit tests for the helper functions

# Generated at 2022-06-23 02:22:57.641139
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lvirtual = LinuxVirtual(module)
    result = lvirtual.get_virtual_facts()
    assert result.get('virtualization_type') == 'NA'

# Generated at 2022-06-23 02:23:03.336762
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    module.params['paths'] = None
    mod = LinuxVirtual(module)
    res = mod.populate()
    assert res.get('virtualization_type') == 'NA'
    assert res.get('virtualization_role') == 'NA'
    assert res.get('virtualization_tech_host') == set()
    assert res.get('virtualization_tech_guest') == set()

# Generated at 2022-06-23 02:23:04.990226
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector is not None


# Generated at 2022-06-23 02:23:07.090146
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # We don't need any argument
    assert LinuxVirtualCollector(None)



# Generated at 2022-06-23 02:23:11.705102
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Unit test for LinuxVirtual class constructor'''
    module = FakeModule()
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual.module == module


# Generated at 2022-06-23 02:23:13.919394
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    real_LinuxVirtualCollector = LinuxVirtualCollector()
    assert real_LinuxVirtualCollector.platform == 'Linux'
    assert real_LinuxVirtualCollector.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:23:24.948481
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.plugins.module_utils.facts import ansible_collector
    from ansible_collections.ansible.community.plugins.module_utils.facts import BaseFactCollector
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.linux import LinuxVirtual
    import os.path

    def get_file_content(path):
        return "Some content"


# Generated at 2022-06-23 02:23:26.511504
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x != None


# Generated at 2022-06-23 02:23:31.046345
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector({})
    assert isinstance(linux_virtual_collector._fact_class(), LinuxVirtual)
    assert linux_virtual_collector._platform == 'Linux'

# Generated at 2022-06-23 02:23:39.299735
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Checks if the LinuxVirtualCollector object is initialized properly
    """
    lvcollection = LinuxVirtualCollector(None)
    assert lvcollection._platform == 'Linux'
    assert lvcollection._fact_class.__name__ == 'LinuxVirtual'
    assert lvcollection.collect() == dict(
        virtualization_type='NA',
        virtualization_role='NA',
        virtualization_tech_host=set(),
        virtualization_tech_guest=set(),
    )


# Generated at 2022-06-23 02:23:49.264111
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command_called = False
            self.run_command = self.mock_run_command

        def get_bin_path(self, arg):
            return '/bin/' + arg

        def mock_run_command(self, arg):
            self.run_command_called = True
            return 0, 'fake.vmware.com', ''

    class MockFile:
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

        def readline(self):
            return self.data

    class MockFileRead:
        def __init__(self):
            self.mock_open = self.mock_open_obj
