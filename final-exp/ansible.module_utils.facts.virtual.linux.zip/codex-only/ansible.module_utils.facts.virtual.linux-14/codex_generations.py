

# Generated at 2022-06-23 02:13:58.476407
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class MockModule:
        def get_bin_path(self, param1):
            return 'dmidecode'
        def run_command(self, param1):
            if param1[0] == 'dmidecode':
                return (0, 'VirtualBox', '')
    mock_module = MockModule()
    obj = LinuxVirtual(mock_module)
    result = obj.get_virtual_facts()
    assert 'virtualization_type' in result
    assert result['virtualization_type'] == 'virtualbox'
    assert 'virtualization_role' in result
    assert result['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in result
    assert 'virtualbox' in result['virtualization_tech_guest']
    assert 'virtualization_tech_host' in result

# Generated at 2022-06-23 02:14:07.356436
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lxc_virtual_collector = LinuxVirtualCollector()
    assert lxc_virtual_collector.collector == lxc_virtual_collector
    assert lxc_virtual_collector._platform == 'Linux'
    assert lxc_virtual_collector.logger == logging.getLogger('ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.virtual.collectors.linux')
    assert lxc_virtual_collector.fact_class == lxc_virtual_collector._fact_class


# Generated at 2022-06-23 02:14:19.206349
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    if not HAS_PSUTIL:
        module.fail_json(msg='psutil is required for this module')
    if not HAS_PYTHON_DMI:
        module.fail_json(msg='python-dmi is required for this module')
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value='')
    module.get_file_lines = MagicMock(return_value='')
    x = LinuxVirtual(module)

# Generated at 2022-06-23 02:14:23.016764
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    l_virt = LinuxVirtual()
    expected = {'virtualization_role': 'guest', 'virtualization_type': 'lxc'}
    assert l_virt.get_virtual_facts() == expected, 'Unexpected Virtual Facts'


# Generated at 2022-06-23 02:14:30.505287
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts = {}
    test_linux = LinuxVirtual()
    # Test for docker
    os.path.exists = mock.MagicMock(return_value=True)
    os.path.isdir = mock.MagicMock(return_value=True)
    os.path.isfile = mock.MagicMock(return_value=True)
    get_file_lines = mock.MagicMock(return_value=['0::/system.slice/docker.service'])
    os.access = mock.MagicMock(return_value=True)
    virtual_facts = test_linux.get_virtual_facts()
    # Test for kvm
    os.path.exists = mock.MagicMock(return_value=True)
    virtual_facts = test_linux.get_virtual_facts()
    # Test for k

# Generated at 2022-06-23 02:14:34.813537
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert issubclass(LinuxVirtualCollector, VirtualCollector)
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual

    linux_virtual = LinuxVirtualCollector()
    assert linux_virtual._fact_class == LinuxVirtual

# Generated at 2022-06-23 02:14:42.927689
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the constructor of the class LinuxVirtual.
    """

    # Case 1:
    # Test when function `get_bin_path` return '/usr/bin/dmidecode'
    # The file '/sys/devices/virtual/dmi/id/product_name' doesn't exist.
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    mock_module = MagicMock(return_value=module)

    mock_args = {
        "get_bin_path.return_value": "/usr/bin/dmidecode",
        "run_command.return_value": (0, "VirtualBox\n", "")
    }

    with patch.multiple(LinuxVirtual, **mock_args) as mocked_dict:
        facts = LinuxVirtual.get_virtual_facts()
    assert facts

# Generated at 2022-06-23 02:14:46.185512
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    lv = LinuxVirtual()

    assert lv.get_distribution_virtualization_type() == 'NA'
    assert lv.get_virtualization_type()['virtualization_type'] == 'NA'
    assert lv.get_virtualization_role()['virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:14:55.501634
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Initialization
    linux_virtual = LinuxVirtual()
    module = Mock(run_command=Mock(return_value=(0, "", "")))
    linux_virtual.module = module
    module.get_bin_path=Mock(return_value='/usr/bin/lscpu')

    # Get the facts
    result = linux_virtual.get_virtual_facts()

    # Get the expected result
    expected_result = {'virtualization_role': 'NA',
                       'virtualization_type': 'NA',
                       'virtualization_tech_host': {'NA'},
                       'virtualization_tech_guest': {'NA'}
    }

    assert(result == expected_result)


# Generated at 2022-06-23 02:14:57.796909
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:15:03.926969
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts = LinuxVirtual(None).get_virtual_facts()
    assert virtual_facts['virtualization_role'] != ''
    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_tech_host'] != ''
    assert virtual_facts['virtualization_tech_guest'] != ''
    #assert virtual_facts['is_virtual'] == ''


# Virtual subclass for Darwin

# Generated at 2022-06-23 02:15:12.494647
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test LinuxVirtual class
    """
    module = AnsibleModule(argument_spec=dict())
    module.params = {}
    linux_virtual_test = LinuxVirtual(module)
    virtual_facts_test = linux_virtual_test.get_all_facts()
    assert 'virtualization_type' in virtual_facts_test.keys()
    assert 'virtualization_role' in virtual_facts_test.keys()
    assert 'virtualization_tech_guest' in virtual_facts_test.keys()
    assert 'virtualization_tech_host' in virtual_facts_test.keys()


# Generated at 2022-06-23 02:15:14.130597
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = MagicMock()
    facts = LinuxVirtualCollector(module).collect()
    assert type(facts) is dict


# Generated at 2022-06-23 02:15:18.420200
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    global module
    global module_class
    module = ansible_module_get_virtual()
    module_class = LinuxVirtual(module)
    module_class.get_virtual_facts()
    assert module.exit_json.called

# Generated at 2022-06-23 02:15:29.993902
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import platform

    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Construct a mock to wrap around module instance to return required values
    class MockOS:
        uname = 'Linux'
        platform = ''

    class MockModule:
        params = dict()
        check_mode = False
        os = MockOS()
        get_bin_path = lambda x, y: '/bin/' + y

        def run_command(self, cmd):
            return 0, '', ''

    m.os = MockOS()
    m.platform = platform.system()
    m.params.update(dict())

    v = LinuxVirtual(m)

    # Create facts dict to pass to the get_virtual_facts() module
    facts = dict()

# Generated at 2022-06-23 02:15:33.272878
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Unit test for constructor of class LinuxVirtual
    '''

    linux_virtual = LinuxVirtual()
    assert linux_virtual.module == None



# Generated at 2022-06-23 02:15:37.625550
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  virtual = LinuxVirtual()
  assert virtual.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'lxc', 'virtualization_tech_guest': {'container', 'lxc'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-23 02:15:48.469213
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    facts = {}
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True)
    instance = LinuxVirtual(module)
    (is_change, summary, results) = instance.get_virtual_facts(facts)
    # Test if the method returns two values
    assert isinstance(is_change, bool)
    assert isinstance(summary, str)
    # Test if the method returns a dict as third item
    assert isinstance(results, dict)
    # Test if all keys are present in results
    assert set(['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']).issubset(results.keys())



# Generated at 2022-06-23 02:15:55.328681
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    if not HAS_LIBVIRT:
        module.fail_json(msg="python-libvirt module is not installed")
    # Getting a mocked object of class to be tested
    obj = LinuxVirtual()
    # We are mocking test values of private variables
    obj.module = module
    # We are mocking test values of private methods
    obj.get_file_content = MagicMock(return_value=(0, "dummy"))
    obj.get_file_lines = MagicMock(return_value=(0, "dummy"))
    # Testing the method get_virtual_facts of class LinuxVirtual with
    # mocked input values
    result = obj.get_virtual_facts()
    assert result['virtualization_tech_guest'] == set([])

# Generated at 2022-06-23 02:16:02.507498
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
        Unit test for method LinuxVirtual_get_virtual_facts of class LinuxVirtual
    '''
    lv = LinuxVirtual({})
    virtual_facts = lv.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
# Class LinuxDistribution

# Generated at 2022-06-23 02:16:13.894039
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtuals = LinuxVirtual()

    assert virtuals.lscpu is not None
    assert virtuals.systemd_container is not None

    if os.path.exists("/bin/journalctl"):
        assert virtuals.journalctl_bin is not None
    else:
        assert virtuals.journalctl_bin is None

    if os.path.exists("/usr/sbin/dmidecode"):
        assert virtuals.dmidecode_bin is not None
    else:
        assert virtuals.dmidecode_bin is None

    assert virtuals.virt_what_bin is not None
    assert virtuals.virt_who_bin is not None



if __name__ == '__main__':
    # Unit test for constructor of class LinuxVirtual
    import doctest
    doctest.testmod()

    # Unit

# Generated at 2022-06-23 02:16:16.318905
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Test constructor of LinuxVirtualCollector
    assert isinstance(LinuxVirtualCollector(), VirtualCollector)


# Generated at 2022-06-23 02:16:19.154489
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = LinuxVirtualCollector("Linux")
    assert vc._platform == 'Linux'
    assert vc._fact_class == LinuxVirtual



# Generated at 2022-06-23 02:16:21.187447
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None

# Generated at 2022-06-23 02:16:29.654946
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Setup test fixture
    fixture = LinuxVirtual()
    fixture.module = get_fixture_ansible_module()
    fixture.command = get_fixture_command_for_module(fixture.module)
    fixture.file = get_fixture_legacy_file_for_module(fixture.module)
    # Test method
    facts = fixture.get_virtual_facts()
    # Assertions
    assert facts['virtualization_type'] == 'NA'
    assert facts['virtualization_role'] == 'NA'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:16:40.306376
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # get an instance of LinuxVirtual
    linux_virtual_facts_obj = LinuxVirtual(module)

    # path to various files and dirs
    files = [
        '/proc/cpuinfo'
    ]
    dirs = [
        '/proc/self/cgroup',
        '/sys/devices/virtual/dmi/id'
    ]
    # create temporary files and dirs to simulate their existence
    # create temporary files
    for f in files:
        os.path.isfile(f) and os.remove(f)
        with open(f, 'a') as fh:
            pass

    # create temporary dirs
    for d in dirs:
        os.path.isdir(d) and shut

# Generated at 2022-06-23 02:16:43.436289
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Unit test for constructor of class LinuxVirtual
    '''
    module = AnsibleModule({})
    ll = LinuxVirtual(module)
    assert ll != None


# Generated at 2022-06-23 02:16:44.972879
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virt = LinuxVirtual()
    assert virt != None


# Generated at 2022-06-23 02:16:55.371301
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import get_virtual_facts
    from collections import namedtuple

    module = namedtuple('Module', ('get_bin_path',))
    module.get_bin_path = lambda x: '/bin/x'
    module.run_command = lambda x: ('', '', '')

    assert get_virtual_facts(module).get('virtualization_type') == 'NA'
    assert get_virtual_facts(module).get('virtualization_role') == 'NA'
    assert get_virtual_facts(module).get('virtualization_tech_guest') == set()
    assert get_virtual_facts(module).get('virtualization_tech_host') == set()

    assert get_virtual_facts(module, '').get('virtualization_type') == 'NA'


# Generated at 2022-06-23 02:16:58.938563
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    vm = LinuxVirtual(module)
    vm.get_virtual_facts()


# Generated at 2022-06-23 02:17:01.668847
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # TODO
    NotImplemented
# Class LinuxVirtual

# Class BaseVirtual

# Generated at 2022-06-23 02:17:12.682767
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Unit tests for method :meth:`LinuxVirtual.get_virtual_facts`.
    """
    curr = LinuxVirtual()

    if os.path.exists('/proc/self/status'):
        # mock instance of file_lines
        def file_lines_mock(file):
            line_mock = 'VxID:	0'
            return [line_mock]
        curr.file_lines = file_lines_mock
        # mock instance of lscpu
        def lscpu_mock():
            out_mock = 'Hypervisor:	IBM/S390'
            return [out_mock]
        curr.lscpu = lscpu_mock
    else:
        return
    virtual_facts = curr.get_virtual_facts()
    # assert virtual_facts

# Generated at 2022-06-23 02:17:17.752408
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-23 02:17:20.067287
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = LinuxVirtualCollector()
    assert isinstance(vc._fact_class(vc.module), LinuxVirtual)

# Generated at 2022-06-23 02:17:23.825375
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    failed_module = AnsibleFailJsonMock()
    lvc = LinuxVirtualCollector(module)
    lvc.collect()
    assert lvc.facts['virtualization_type'] == 'NA'


# Generated at 2022-06-23 02:17:26.315212
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x._fact_class == LinuxVirtual
    assert x._platform == 'Linux'


# Generated at 2022-06-23 02:17:31.885639
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = None
    module.get_bin_path.return_value = '/usr/bin/dmidecode'
    lv = LinuxVirtual(module)
    assert lv
    assert lv.module == module


# Generated at 2022-06-23 02:17:42.260303
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    module.get_bin_path = MagicMock(side_effect=lambda x: x)
    module.run_command = MagicMock(side_effect=lambda x: [0, "", ""])

# Generated at 2022-06-23 02:17:44.241715
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lc = LinuxVirtualCollector()
    assert lc is not None

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:17:53.690137
# Unit test for method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-23 02:18:04.465473
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    # LinuxVirtual().populate() will load all attributes,
    # so we don't need to test that
    linux_virtual = LinuxVirtual(module)
    facts = linux_virtual.get_facts()
    assert facts['virtualization_role'] in ('host', 'guest')

# Generated at 2022-06-23 02:18:06.468578
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    actual = LinuxVirtualCollector()
    assert actual._fact_class == LinuxVirtual
    assert actual._platform == 'Linux'


# Generated at 2022-06-23 02:18:10.963006
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = get_platform_module('Linux')
    if module:
        virtual_collector = LinuxVirtualCollector(module)
        assert virtual_collector.fact_class == LinuxVirtual
        assert virtual_collector.platform == 'Linux'



# Generated at 2022-06-23 02:18:13.992444
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test constructor"""
    assert 'Linux' == LinuxVirtualCollector._platform
    assert LinuxVirtual == LinuxVirtualCollector._fact_class


# Generated at 2022-06-23 02:18:20.787117
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Test for LinuxVirtual class constructor.
    '''
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'QEMU Virtual CPU', ''))
    lv = LinuxVirtual(module)
    assert lv.module.run_command == module.run_command
    lv._get_asic_type()
    lv._get_cpu_type()
    lv._get_memory_facts()
    lv._get_virtual_facts()


# Generated at 2022-06-23 02:18:31.618721
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    try:
        from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
        from ansible.module_utils.facts.virtual.get_file_content import get_file_content
        from ansible.module_utils.facts.virtual.get_file_lines import get_file_lines
    except ImportError:
        return False

    module = FakeAnsibleModule()
    linux_virtual = LinuxVirtual(module)

    # Mock method get_file_content
    linux_virtual.get_file_content = get_mock_linux_virtual_get_file_content

    # Mock method get_file_lines
    linux_virtual.get_file_lines = get_mock_linux_virtual_get_file_lines

    # Test a system that is not a virtual machine
    virtual_facts = linux_virtual.get

# Generated at 2022-06-23 02:18:44.268713
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Create basic set of arguments
    module = AnsibleModule(argument_spec={})
    # Initialise the LinuxVirtual object with the module args
    linux_virtual = LinuxVirtual(module)

    virtual_facts_dict = {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_guest': None,
        'virtualization_tech_host': None
    }
    # Call the get_virtual_facts method
    result = linux_virtual.get_virtual_facts()
    # Check if all the items in the result dict are equal to the items in the virtual_facts_dict
    failed = any(item[1]!=item[0] for item in zip(result.items(), virtual_facts_dict.items()))
    assert failed is False


# Generated at 2022-06-23 02:18:46.930597
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    lsvirt = LinuxVirtual(module)
    assert(isinstance(lsvirt, LinuxVirtual))


# Generated at 2022-06-23 02:18:58.552803
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    # Create a LinuxVirtual
    lv = LinuxVirtual(module)
    
    # Mock the module and its parameters
    lv.module = MagicMock()
    lv.module.get_bin_path = MagicMock(return_value=None)
    lv.module.run_command = MagicMock(return_value=[0, None, None])
    lv.module.boolean = MagicMock(return_value=True)
    
    # Mock the get_file_content() function
    lv.get_file_content = MagicMock(return_value=None)

    # Mock the get_file_lines() function

# Generated at 2022-06-23 02:19:08.241214
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, "test", "")
    mock_module.get_bin_path.return_value = None

    lxvirt = LinuxVirtual(mock_module)
    facts = lxvirt.get_virtual_facts()

    # Assert that the get_file_content method was called.
    mock_module.run_command.assert_called_with("test", check_rc=False)
    assert facts["virtualization_type"] == "NA"
    assert facts["virtualization_role"] == "NA"

    # Ensure that if a VirtualizationType is already found,
    # we don't overwrite it.
    mock_module.run_command.reset_mock()

# Generated at 2022-06-23 02:19:11.132379
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test method for class LinuxVirtual
    """
    module = MockAnsibleModule()
    linux_virtual = LinuxVirtual(module=module)
    assert len(linux_virtual.virtual_facts) > 0


# Generated at 2022-06-23 02:19:16.855947
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Set up test parameters
    module = AnsibleModule

    # Set up test fixture
    linux_virtual = LinuxVirtual(module)

    # Run tested method get_virtual_facts()
    virtual = linux_virtual.get_virtual_facts()

    # Test assertion (what is expected?)
    assert True == virtual, 'get_virtual_facts() returned TRUE'

# Generated at 2022-06-23 02:19:18.693974
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    v = LinuxVirtual(module)
    assert v


# Generated at 2022-06-23 02:19:28.639881
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.common.removed import removed_module
    modules = {
        'open': removed_module.open
    }
    module_mock = MagicMock()
    module_mock.params = {'gather_timeout': 5}
    module_mock.run_command.return_value = (0, 'foo', '')
    module_mock.get_bin_path.return_value = '/bin/false'

    import sys
    if sys.version_info[0] < 3:
        open_name = '__builtin__.open'
    else:
        open_name = 'builtins.open'


# Generated at 2022-06-23 02:19:32.293261
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule({})
    virtual_collector = LinuxVirtualCollector(module)
    virtual_collector._populate()
    assert virtual_collector._facts['virtualization_type'] == 'virtualbox'


# Generated at 2022-06-23 02:19:38.207397
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test the constructor of LinuxVirtualCollector
    """
    from ansible.module_utils import basic
    col = LinuxVirtualCollector(basic.AnsibleModule(argument_spec={}).exit_json)
    assert col.platform == 'Linux'
    assert col.fact_class.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:19:39.545027
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.get_virtual_facts()

# Generated at 2022-06-23 02:19:41.774516
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():

    linux_virtual = LinuxVirtual({})

# Generated at 2022-06-23 02:19:43.697075
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Test constructor of the class LinuxVirtual"""
    virtual = LinuxVirtual()



# Generated at 2022-06-23 02:19:55.271802
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():

    module = AnsibleModule(argument_spec=dict(
        fact=dict(type='dict', required=False),
        filter=dict(type='str', required=False, default=''),
    ))

    if not HAS_LIBVIRT and not HAS_PSUTIL and not HAS_PROCFS and not \
            HAS_PRETTYTABLE and not HAS_DMI:
        module.fail_json(
            msg="Error: platform does not support virtualization facts")

    virtual = LinuxVirtual(module=module,
                           filter=module.params['filter'],
                           fact_subset=module.params['fact'])
    virtual_facts = virtual.populate()
    ansible_facts = dict()
    ansible_facts.update(virtual_facts)

# Generated at 2022-06-23 02:20:04.449819
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.sanitizers import VirtualSanitizer
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual

    # Create a new instance without any argument
    instance = LinuxVirtualCollector()

    for attr_name in dir(instance):
        test_failed = False
        attr = getattr(instance, attr_name)

        # Test if attributes are of the correct type
        if attr_name in ['_fact_class', '_sanitizers']:
            if not (isinstance(attr, type)):
                test_failed = True
        if attr_name == '_platform':
            if not (isinstance(attr, str)):
                test_failed = True

# Generated at 2022-06-23 02:20:10.390299
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert lv.virtualization_type == 'NA', 'virtualization_type should be NA'
    assert lv.virtualization_role == 'NA', 'virtualization_role should be NA'
    assert lv.virtualization_tech_guest == set(), 'virtualization_tech_guest should be Null'
    assert lv.virtualization_tech_host == set(), 'virtualization_tech_host should be Null'


# Generated at 2022-06-23 02:20:14.893233
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lv = LinuxVirtual(module)
    result = lv.get_virtual_facts()
    module.exit_json(**result)


# Generated at 2022-06-23 02:20:16.260310
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector._platform == 'Linux'


# Generated at 2022-06-23 02:20:20.267105
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = get_platform_module('Linux')
    virtual_collector = LinuxVirtualCollector(module)
    assert(virtual_collector.fact_class.platform is 'Linux')

# Generated at 2022-06-23 02:20:23.317754
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    try:
        virt = LinuxVirtual()
    except Exception as e:
        if str(e) != "This module only runs on Linux systems":
            print(str(e))
            assert False
    return


# Generated at 2022-06-23 02:20:28.019759
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test LinuxVirtualCollector constructor"""
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual
    assert LinuxVirtualCollector._platform == 'Linux'
    assert isinstance(LinuxVirtualCollector.get_facts(), LinuxVirtual)


# Generated at 2022-06-23 02:20:38.060593
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts import ansible_facts
    result = {}
    result['ansible_facts'] = ansible_facts
    result['ansible_facts']['ansible_virtualization_role'] = 'guest'
    result['ansible_facts']['ansible_virtualization_type'] = 'kvm'
    result['ansible_facts']['ansible_virtualization_tech_guest'] = 'kvm'
    result['ansible_facts']['ansible_virtualization_tech_host'] = 'kvm'
    return result


# Generated at 2022-06-23 02:20:46.120957
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Initial instance that is used in other unit tests
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == lvc._fact_class
    assert lvc.fact_class.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:20:56.713181
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    '''Unit test for LinuxVirtualCollector'''
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.hardware.linux import LinuxHardwareCollector
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual

    class MockModule(object):
        '''Class for mocking module.run_command method'''
        def __init__(self):
            self.params = {'gather_subset': '!all'}
            self.mock_module = MagicMock()
            self.fail_json = MagicMock()

    class MockAnsibleModule(object):
        '''Class for mocking AnsibleModule class constructor'''
        def __init__(self):
            self.params = {'gather_subset': '!all'}
            self

# Generated at 2022-06-23 02:21:05.988336
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.exit_json = exit_json
    module.fail_json = fail_json
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    # Provide some examples of keys/values returned in virtual_facts
    keys_to_test = [
        'virtualization_role',
        'virtualization_type',
        'virtualization_tech_host',
        'virtualization_tech_guest'
    ]
    for key in keys_to_test:
        assert key in virtual_facts


# Generated at 2022-06-23 02:21:17.388114
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.params['gather_subset'] = ['!all']

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def get_bin_path(self, path, opts=None, required=False):
            return '/bin/' + path

    def set_module_args(args):
        args

# Generated at 2022-06-23 02:21:19.019743
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert hasattr(lv, 'module')


# Generated at 2022-06-23 02:21:30.106579
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class LinuxVirtual
    '''
    v = LinuxVirtual()

# Generated at 2022-06-23 02:21:40.228507
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual.py
    ~~~~~~~~~~~~~~~~
    This is a unit test for the constructor of the class LinuxVirtual in the
    file linux_virtual.py
    :return:\n
    """
    module = OpenShiftAnsibleModuleMock()
    module.run_command = mock.MagicMock(return_value=['', '', 0])
    module.params = {}
    module.get_bin_path = mock.MagicMock(return_value='/usr/bin/virsh')

    result = LinuxVirtual(module)
    # Assert for case where assertEqual() is used
    assertEqual(result._platform_id, 'linux')

    # Assert for case where assertTrue() is used
    assertTrue(result.virtual_facts['virtualization_role'] == 'host')

# Generated at 2022-06-23 02:21:43.521639
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test LinuxVirtual class constructor.
    """
    lvirt = LinuxVirtual(dict())
    assert lvirt is not None

# Generated at 2022-06-23 02:21:45.740098
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual(None)
    assert lv is not None

# Generated at 2022-06-23 02:21:47.718546
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector(None)
    assert isinstance(x._collector, LinuxVirtual)

# Generated at 2022-06-23 02:21:52.913073
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    This test checks that LinuxVirtualCollector can be loaded and returns an object that is instance of VirtualCollector
    """
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    linux_virtual = LinuxVirtualCollector(module=module)
    assert isinstance(linux_virtual, VirtualCollector)

# Unit tests for class LinuxVirtual

# Generated at 2022-06-23 02:21:56.779020
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None
    assert isinstance(linux_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:22:02.299523
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    vf = lv.get_virtual_facts()
    assert vf['virtualization_role'] in ('guest', 'host', 'NA')
    if vf['virtualization_role'] in ('guest', 'host'):
        assert vf['virtualization_type'] != 'NA'
    print(vf)


# Generated at 2022-06-23 02:22:04.098394
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = LinuxVirtualCollector('/tmp')
    assert vc is not None


# Generated at 2022-06-23 02:22:06.830316
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Constructor
    linux_obj = LinuxVirtual()

    # Method get_virtual_facts
    linux_obj.get_virtual_facts()


# Generated at 2022-06-23 02:22:13.894004
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    ret = {}
    if not os.path.exists('/etc/redhat-release'):
        ret['msg'] = "Unable to find /etc/redhat-release"
        ret['failed'] = True
    else:
        module = AnsibleModule(argument_spec = dict())
        vm = LinuxVirtual(module)
        ret['facts'] = vm.get_virtual_facts()
    return ret


# Generated at 2022-06-23 02:22:20.654418
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    src = LinuxVirtual()
    src.module = FakeModule()
    src.module.run_command = fake_run_command
    virtual_facts = src.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'qemu'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['qemu'])
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:22:24.300340
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)
    try:
        vf = lv.get_virtual_facts()
    except Exception:
        vf = dict()

    module.exit_json(ansible_facts=dict(virtual=vf))


# Generated at 2022-06-23 02:22:28.453802
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Unit test function for LinuxVirtualCollector class
    """
    lvc = LinuxVirtualCollector()
    if lvc is not None:
        print("LinuxVirtualCollector class is constructed successfully")



# Generated at 2022-06-23 02:22:33.244939
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test module for LinuxVirtual class
    :return:
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list', default=['all'])))

    virtual = LinuxVirtual(module)
    result = virtual.populate()
    for key in result:
        print(key + "=" + str(result[key]))

if __name__ == "__main__":
    test_LinuxVirtual()

# Generated at 2022-06-23 02:22:45.467922
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_object = LinuxVirtual()
    params = {"module":None, "path":None}
    test_object.module = FakeAnsibleModule(params)
    test_object.path = FakeAnsibleModule(params)
    test_object.module.run_command = MagicMock(return_value=(0, "VxID:\t0", ""))

    params = {
        "virtctl_path":None,
        "kubectl_path":None,
        "docker_path":None,
        "openstack_path":None,
        "mock_virt_what":True,
        "mock_virtual_facts":True
    }
    test_object.module = FakeAnsibleModule(params)
    test_object.virtctl_path = FakeAnsibleModule(params)

# Generated at 2022-06-23 02:22:56.273857
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    class AnsibleModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, msg, **kwargs):
            self.exit_args = msg
            self.exit_kwargs = kwargs
            raise Exception(msg)

    class AnsibleModuleMock(AnsibleModule):
        def __init__(self):
            super(AnsibleModuleMock, self).__init__()
            self.run_command = Mock()

    class AnsibleModuleMockException(AnsibleModule):
        def __init__(self):
            super

# Generated at 2022-06-23 02:22:59.046460
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    with patch.object(LinuxVirtualCollector, '_get_fact_class') as mock_get_fact_class:
        LinuxVirtualCollector()
        mock_get_fact_class.assert_called_once()

# Generated at 2022-06-23 02:23:01.220832
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual

# Test the get_virtual_facts() method of class LinuxVirtual

# Generated at 2022-06-23 02:23:13.267790
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():  # pylint: disable=too-many-locals,too-many-statements,invalid-name
    '''
    Unit test for LinuxVirtual class constructor
    '''

    module_args = {}
    testedobj = LinuxVirtual(module_args)

    # Assert that virtualization_type is initialized as a dictionary
    assert testedobj.virtualization_type == {}

    # Assert that virtualization_role is initialized as a dictionary
    assert testedobj.virtualization_role == {}

    # Assert that virtualization_tech_guest is initialized as a dictionary
    assert testedobj.virtualization_tech_guest == {}

    # Assert that virtualization_tech_host is initialized as a dictionary
    assert testedobj.virtualization_tech_host == {}

    # Assert that the method get_virtual_facts() contains the keys:
   

# Generated at 2022-06-23 02:23:14.933262
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Tested in 'Test' section of this module
    pass


# Generated at 2022-06-23 02:23:18.874807
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Test constructor of class LinuxVirtual()'''
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lv = LinuxVirtual(module)
    assert lv.module == module

# Generated at 2022-06-23 02:23:22.167026
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # cast param as a dict (to make pylint happy)
    linux_virtual = LinuxVirtualCollector({})
    assert linux_virtual is not None


# Generated at 2022-06-23 02:23:31.986066
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Arrange
    class MockModule:
        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, check_rc=True):
            return 0, '', ''

        def fail_json(self, **kwargs):
            return False

    class MockLinuxVirtual:
        def __init__(self, module):
            self.module = module

        def get_file_content(self, fname):
            return ''

        def get_file_lines(self, fname):
            return ['']

    module = MockModule()
    linux_virtual = MockLinuxVirtual(module)

    # Act
    result = linux_virtual.get_virtual_facts()

    # Assert
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result

# Generated at 2022-06-23 02:23:35.875490
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    vm = LinuxVirtual(module)
    assert type(vm) == LinuxVirtual
    assert vm.system == platform.system()



# Generated at 2022-06-23 02:23:43.804888
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode=True
    )

    if not HAS_PSUTIL:
        module.fail_json(msg='The `psutil` python module is not installed.  Without `psutil`, `virtual` cannot be determined.')

    virtual_obj = LinuxVirtual(module)
    virtual_facts = virtual_obj.get_virtual_facts()
    module.exit_json(changed=False, ansible_facts=dict(virtual=virtual_facts))
