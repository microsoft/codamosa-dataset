

# Generated at 2022-06-23 02:13:51.253032
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    with pytest.raises(AnsibleFailJson):
        assert LinuxVirtual('').get_virtual_facts() == {
            'virtualization_role': 'guest',
            'virtualization_type': 'docker',
            'virtualization_tech_guest': set(['container', 'docker']),
            'virtualization_tech_host': set([])
        }

# Generated at 2022-06-23 02:13:54.264945
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lv = LinuxVirtual(module)

    virt_facts = lv.get_virtual_facts()

# Generated at 2022-06-23 02:13:59.584560
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # AnsibleModule and AnsibleExitJson objects are used from module_utils/basic.py
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson
    from ansible.module_utils.basic import AnsibleFailJson
    import json


# Generated at 2022-06-23 02:14:03.471963
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class.__name__ == 'LinuxVirtual'
    assert lvc.platform == 'Linux'



# Generated at 2022-06-23 02:14:07.690946
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Method get_virtual_facts of class LinuxVirtual parameters:
    """
    module = AnsibleModule(argument_spec=dict())
    module.exit_json(changed=False, meta=module.params)



# Generated at 2022-06-23 02:14:11.174380
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Test LinuxVirtual() constructor"""
    module = FakeAnsibleModule()
    set_module_args({})
    linux_virtual = LinuxVirtual(module)
    assert isinstance(linux_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:14:21.270899
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    facts = LinuxVirtual()

    # Test if 'virtualization_type' is a string and not empty
    assert isinstance(facts['virtualization_type'], str)
    assert len(facts['virtualization_type']) > 0

    # Test if 'virtualization_type' is a string and not empty
    assert isinstance(facts['virtualization_role'], str)

    # Test if 'virtualization_type' is a string and not empty
    assert isinstance(facts['virtualization_tech_guest'], set)

    # Test if 'virtualization_type' is a string and not empty
    assert isinstance(facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:14:24.692718
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    linux_virtual_test_obj = LinuxVirtual()
    virtual_facts = linux_virtual_test_obj.get_virtual_facts()

    assert isinstance(virtual_facts, dict), "Failed to get virtual facts."


# Generated at 2022-06-23 02:14:25.891083
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:14:31.882150
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    pass
    # Test virtual facts using the get_virtual_facts() method
    # virtual facts is a string value
    #virtual_facts = get_virtual_facts()
    #virtual_facts = os_virtual.get_virtual_facts()

    # Assert that virtual facts is a data type of string
    #assert isinstance(virtual_facts, str)


# Generated at 2022-06-23 02:14:41.187576
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Set up required input parameters
    module_name = 'ansible.module_utils.facts.system.virtual'
    module_args = {}
    tmp_path = tempfile.mkdtemp()

# Generated at 2022-06-23 02:14:44.982912
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual

# Test that the fact LinuxVirtual is named correctly and the host virtualization tech
# set is empty

# Generated at 2022-06-23 02:14:49.826773
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    # Assuming virt facts are obtained from lscpu
    virt_facts = {
        'virtualization_type': 'openstack',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'openstack'},
        'virtualization_tech_host': set()
    }
    assert virt_facts == lv.get_virtual_facts()

# Generated at 2022-06-23 02:14:57.605659
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Create instance for testing
    linux_virtual = LinuxVirtual(module)

    # perform test
    virtual_facts = linux_virtual.get_virtual_facts()

    # assert
    module.exit_json(virtual_facts=virtual_facts)

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:15:03.340493
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linuxVirtual = LinuxVirtual()
    assert linuxVirtual.get_virtual_facts() == {'virtualization_type': 'NA', 'virtualization_role': 'NA', 'virtualization_tech_guest': set(['container']), 'virtualization_tech_host': set()}

# Instance of class LinuxVirtual
linuxVirtual = LinuxVirtual()

# Ansible facts class for Linux system

# Generated at 2022-06-23 02:15:10.561922
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    test_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data')
    test_data_dir_file = os.path.join(test_data_dir, 'LinuxVirtual')

    # Read in actual data on which testing will be performed
    get_file_content = partial(get_file_content_outisde_docker, test_data_dir_file)
    get_file_lines = partial(get_file_lines_outside_docker, test_data_dir_file)
    module.run_command = mock.Mock(side_effect=get_mock_run_command(test_data_dir_file))

# Generated at 2022-06-23 02:15:14.382881
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    test the constructor
    """
    linux_virtual_ins = LinuxVirtual()
    assert linux_virtual_ins.module is not None
    assert linux_virtual_ins.module.params is not None


# Generated at 2022-06-23 02:15:26.154343
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    obj = LinuxVirtual()
    obj.module = MagicMock()
    obj.module.get_bin_path.return_value = '/usr/bin/lscpu'
    obj.module.run_command.return_value = (0, 'something', '')
    obj.module.get_bin_path.return_value = '/usr/bin/dmidecode'
    obj.module.run_command.return_value = (0, 'BHYVE', '')
    obj.module.run_command.return_value = (0, 'Red Hat', '')
    obj.module.run_command.return_value = (0, 'oVirt', '')
    obj.module.run_command.return_value = (0, 'VMware', '')

# Generated at 2022-06-23 02:15:27.410712
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x is not None


# Generated at 2022-06-23 02:15:30.435530
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    fact_collector = LinuxVirtualCollector(module)
    assert isinstance(fact_collector._fact_class(module), LinuxVirtual)

# Generated at 2022-06-23 02:15:38.696588
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    vm = LinuxVirtual(module)

    virtual_facts = vm.get_virtual_facts()

    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert type(virtual_facts['virtualization_tech_guest']) is set
    assert type(virtual_facts['virtualization_tech_host']) is set

# Unit test class for Linux_Systemd

# Generated at 2022-06-23 02:15:49.029516
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test various virt_facts
    """
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)
    # Test docker facts
    docker_facts = lv.get_virtual_facts('docker')
    assert docker_facts['virtualization_role'] == 'guest'
    assert docker_facts['virtualization_type'] == 'docker'
    assert docker_facts['virtualization_tech_guest'] == set(['docker'])
    assert docker_facts['virtualization_tech_host'] == set()
    # Test oVirt facts
    oVirt_facts = lv.get_virtual_facts('oVirt')
    assert oVirt_facts['virtualization_role'] == 'guest'
    assert oVirt_facts['virtualization_type'] == 'oVirt'

# Generated at 2022-06-23 02:15:59.361245
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils._text import to_bytes
    import platform
    import sys

    module_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

    mock_module = ModuleFacts()
    mock_module.params = {}
    mock_module.get_bin_path = lambda x: "/bin/%s" % x
    mock_module.run_command = lambda *args, **kwargs: [0, "a" * 1024, ""]
    mock_module.params = {
        'gather_subset': ['all'],
        'gather_timeout': 10,
        'filter': '*'
    }

    # Use module_path for the source

# Generated at 2022-06-23 02:16:04.422889
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(
        argument_spec={}
    )


    mod = LinuxVirtual(module)
    # host_tech should be empty set
    virtual_facts = mod.get_virtual_facts()
    mod.exit_json(ansible_facts={'virtualization_facts': virtual_facts})


# Unit test case for module

# Generated at 2022-06-23 02:16:09.389335
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import ansible.module_utils.facts.virtual as virtual
    virt = virtual.LinuxVirtual()
    virt.module.run_command = lambda *args, **kwargs: (0, 'output', '')
    assert virt.get_virtual_facts() == virtual.get_virtual_facts_defaultdict()

# Generated at 2022-06-23 02:16:11.324071
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert linux_virtual is not None


# Generated at 2022-06-23 02:16:13.843873
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the constructor of class LinuxVirtual
    """
    lx = LinuxVirtual()
    lx = LinuxVirtual(use_dmidecode=True)


# Generated at 2022-06-23 02:16:16.008142
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:16:20.548258
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # TODO: Implement unit test.
    # Test scenario:
    #   module.run_command("")
    #   module.fail_json(msg="")
    #   module.exit_json(changed=True, meta={"key":"value"})
    #   module.exit_json(changed=False, meta={"key":"value"})
    pass


# Generated at 2022-06-23 02:16:22.959753
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    assert lv.module == module



# Generated at 2022-06-23 02:16:26.202295
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    # Instantiate a test object of class LinuxVirtual
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None


# Generated at 2022-06-23 02:16:31.830837
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():

    facts = dict(distribution='redhat')

    impl_virt = LinuxVirtual(dict(), facts)
    impl_virt.populate()
    assert impl_virt.virtual_facts['virtualization_type'] == 'NA'
    assert impl_virt.virtual_facts['virtualization_role'] == 'NA'
    assert impl_virt.virtual_facts['virtualization_tech_guest'] == set()
    assert impl_virt.virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:16:36.347414
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.get_virtual_facts()

# Generated at 2022-06-23 02:16:42.062462
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    os_facts = dict()
    os_facts['distribution'] = 'RedHatEnterpriseServer'
    os_facts['distribution_major_version'] = 7
    os_facts['distribution_version'] = '7.6'
    linux = LinuxVirtual(module, os_facts)
    result = linux.populate()
    assert 'virtualization_type' in result


# Generated at 2022-06-23 02:16:45.829148
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test constructor of class LinuxVirtualCollector
    """
    test_object = LinuxVirtualCollector(None)

    assert test_object._platform == 'Linux'
    assert test_object._fact_class.__name__ == 'LinuxVirtual'

# Generated at 2022-06-23 02:16:55.991473
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    virtual_facts = {}

    def get_file_content(filename):
        return None

    def get_file_lines(filename):
        return None

    def run_command(command):
        return None

    class LinuxVirtual(object):
        def __init__(self):
            self.module = None

    lv = LinuxVirtual()
    lv.get_file_content = get_file_content
    lv.get_file_lines = get_file_lines
    lv.module = module
    lv.module.run_command = run_command
    virtual_facts = lv.get_virtual_facts()
    ansible_facts = {'virtual': virtual_facts}

# Generated at 2022-06-23 02:17:08.007103
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins

    if not PY2:
        builtin_module = 'builtins'
    else:
        builtin_module = '__builtin__'

    # Constructor test without argument
    lv = LinuxVirtual()

    # Constructor test with argument
    class FakeModule:
        def __init__(self, bin_ansible_call_args=None):
            self.params = {}
            self.bin_ansible_call_args = bin_ansible_call_args

        def get_bin_path(self, arg, required=False, opt_dirs=None):
            return self.bin_ansible_call_args[arg]


# Generated at 2022-06-23 02:17:12.039948
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtualCollector().collect()
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:17:19.495993
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Dict to be passed as argument to the class module
    module_arg_spec = dict(
        ansible_facts=dict(type='dict', required=False),
        ansible_facts_d=dict(type='dict', required=False)
    )
    # Instantiante the class module
    module = LinuxVirtual(argument_spec=module_arg_spec, supports_check_mode=False)
    # Generating the facts
    result = module.get_virtual_facts()
    # Check the facts
    assert result == {
        'virtualization_role': 'guest',
        'virtualization_type': 'docker', 
        'virtualization_tech_guest': set(['container', 'docker'])
    }



# Generated at 2022-06-23 02:17:22.099383
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    os_platform = LinuxVirtual(module)
    os_platform.get_virtual_facts()


# Generated at 2022-06-23 02:17:33.996842
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Create an instance of LinuxVirtualCollector
    :return:
    """
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    module.get_bin_path = ansible.module_utils.facts.collector.get_bin_path
    module.run_command = ansible.module_utils.facts.collector.run_command
    linux_virtual = LinuxVirtualCollector(module)
    module.exit_json(ansible_facts={"virtual_facts": linux_virtual.get_facts()})


if __name__ == '__main__':
    test_LinuxVirtualCollector()

# Generated at 2022-06-23 02:17:39.851456
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module=module)
    assert linux_virtual.module == module


# Generated at 2022-06-23 02:17:44.331990
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = LinuxVirtualCollector()
    assert vc._platform == 'Linux'
    assert isinstance(vc._fact_class, LinuxVirtual)

# Unit tests for functions in class LinuxVirtual

# Generated at 2022-06-23 02:17:45.823461
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert lv


# Generated at 2022-06-23 02:17:54.483464
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Constructor of class LinuxVirtualCollector should return an object of class LinuxVirtualCollector
    """
    module = Mock()
    module.check_mode = False
    module.get_bin_path = Mock(return_value="/bin/dmidecode")
    module.run_command = Mock(return_value=(0, "", ""))
    module.params = {'gather_subset': ['all']}
    module.tmpdir = None
    module.run_command_environ_update = None
    module.get_tmp_dir = Mock(return_value="/")
    module.file_exists = Mock(return_value=True)
    module.collection_dir = "tests/unit/output/ansible_collections/ansible_fact_collection"

# Generated at 2022-06-23 02:18:05.101976
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    module = LinuxVirtual()

    # Case 1: no virtualization technologies found
    # Expected result:
    #   {
    #       "virtualization_type": "NA",
    #       "virtualization_role": "NA",
    #       "virtualization_tech_guest": set(),
    #       "virtualization_tech_host": set()
    #   }

    module.get_file_lines = lambda path: []
    module.get_file_content = lambda path: None
    module.run_commands = lambda commands, check_rc=True: []
    module.get_bin_path = lambda tool: None
    module.stat = lambda path: None
    module.lstat = lambda path: None
    module.is_executable = lambda path: True
    module.exists = lambda path: False

# Generated at 2022-06-23 02:18:08.104816
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lv = LinuxVirtual(module)
    module.exit_json(changed = False, lv=lv)


# Generated at 2022-06-23 02:18:13.660573
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    with mock.patch('os.path.exists', return_value=True):
        linux_virtual_collector = LinuxVirtualCollector()
        assert linux_virtual_collector.platform == 'Linux'
        assert linux_virtual_collector.fact_class == LinuxVirtual
        assert linux_virtual_collector.fact_name == 'virtual'

# Generated at 2022-06-23 02:18:18.171266
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    '''
    Test the constructor of the class LinuxVirtualCollector
    '''
    linux_virtual_collector_obj = LinuxVirtualCollector()
    assert isinstance(linux_virtual_collector_obj._fact_class, LinuxVirtual)
    assert linux_virtual_collector_obj._platform == 'Linux'


# Generated at 2022-06-23 02:18:19.733889
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    l_col = LinuxVirtualCollector()
    assert l_col.fact_class == l_col._fact_class
    assert l_col.platform == l_col._platform


# Generated at 2022-06-23 02:18:22.809456
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    mock_module = AnsibleModule(
        argument_spec={
        }
    )

    test_class = LinuxVirtual(mock_module)
    assert test_class



# Generated at 2022-06-23 02:18:27.779071
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    try:
        module = AnsibleModule(argument_spec={}, supports_check_mode=True)
        obj = LinuxVirtual(module)
        facts = obj.get_all_virtual_facts()
        obj.exit_json(ansible_facts={'ansible_virtualization_facts': facts})
    except Exception as e:
        print(str(e))


if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:18:32.688649
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    fc = LinuxVirtualCollector()
    fc.collect()
    # Test if our fact class 'LinuxVirtual' is in fact_classes set.
    assert fc.fact_classes == (LinuxVirtual,)
    assert fc._platform == 'Linux'
    # Assert that the instantiated object is class LinuxVirtual
    assert isinstance(fc.fact_class_instances[0], LinuxVirtual)

# Generated at 2022-06-23 02:18:42.736663
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    l = LinuxVirtual()
    assert l.get_virtual_facts() == {'virtualization_type': 'lxc',
                                     'virtualization_role': 'guest',
                                     'virtualization_tech_guest': {'container', 'lxc'},
                                     'virtualization_tech_host': set()}
    assert l.get_virtual_facts() == {'virtualization_role': 'guest',
                                     'virtualization_type': 'lxc',
                                     'virtualization_tech_guest': {'container', 'lxc'},
                                     'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:18:54.360778
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import sys, os
    import imp
    import json
    import StringIO

    try:
        tmp_file, pathname, description = imp.find_module('ansible_module_linux_virtual', [os.path.join(sys.path[0], 'lib')])
        ansible_module_linux_virtual = imp.load_module('ansible_module_linux_virtual', tmp_file, pathname, description)
    finally:
        if tmp_file:
            tmp_file.close()

    virtual_facts_data = """
    Linux ansible-c1 4.18.0-147.8.1.el8_1.x86_64 #1 SMP Mon Aug 26 21:39:28 UTC 2019 x86_64 x86_64 x86_64 GNU/Linux
    """
    virtual_facts_data = StringIO

# Generated at 2022-06-23 02:18:58.744619
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    expected_result = {
        'virtualization_type': 'NA',
        'virtualization_role': 'NA',
        'virtualization_tech_host': [],
        'virtualization_tech_guest': []
    }
    module = AnsibleModule(argument_spec={})
    virtual_facts = LinuxVirtualCollector(module).collect()
    assert virtual_facts == expected_result

# Generated at 2022-06-23 02:19:03.521913
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert hasattr(LinuxVirtualCollector, '_platform')
    assert hasattr(LinuxVirtualCollector, '_fact_class')
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual



# Generated at 2022-06-23 02:19:06.494884
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Instantiation
    collector = LinuxVirtualCollector()
    # Testing the constructor
    assert collector._platform == 'Linux'
    assert collector._fact_class.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:19:08.587705
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Constructor test with dummy values
    hypervisor = LinuxVirtual(None)
    assert hypervisor.module is None


# Generated at 2022-06-23 02:19:10.385303
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    p = LinuxVirtualCollector()
    assert p._fact_class == LinuxVirtual



# Generated at 2022-06-23 02:19:16.121328
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():

    class LinuxVirtualTest(LinuxVirtual):
        def __init__(self):
            self.module = AnsibleModule(
                argument_spec = dict(),
                supports_check_mode = True
            )
            super(LinuxVirtualTest, self).__init__()

        def get_bin_path(self, arg):
            return "fake"

    lvt = LinuxVirtualTest()
    lvt()

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:19:16.880163
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  pass

# Generated at 2022-06-23 02:19:27.427298
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Tests the (private) constructor of LinuxVirtual class.
    """
    # pylint: disable=protected-access
    # W0212, Access to a protected member _%s of a client class

    # Always returns a hash ref, and members of the hash ref should never be undef.
    # Also, the virtualization_role is always set (based on the value of
    # virtualization_type).
    linux = LinuxVirtual(dict(ANSIBLE_MODULE_ARGS={}))
    key = "virtualization_type"
    assert key in linux.virtualization_facts
    assert linux.virtualization_facts[key] != "NA"
    key = "virtualization_role"
    assert key in linux.virtualization_facts
    assert linux.virtualization_facts[key] != "NA"

# Generated at 2022-06-23 02:19:28.951669
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert linux_virtual is not None


# Generated at 2022-06-23 02:19:37.483381
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    sys_facts = {
        'virtualization_type': 'NA',
        'virtualization_role': 'NA',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    fields = ['virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host']
    LinuxVirtual_test = LinuxVirtual(module = None)
    LinuxVirtual_test.module = FakeAnsibleModule(**sys_facts)
    ret = LinuxVirtual_test.get_virtual_facts()
    for field in fields:
        assert field in ret


# Generated at 2022-06-23 02:19:47.596608
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts import facts
    import mock
    import copy

    # Set up mocked module
    module = mock.MagicMock(name='module')
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = False

    result = {}
    facts_obj = facts(module)

    # Invoke the constructor with different arguments
    LinuxVirtualCollector(module, facts_obj, result)
    LinuxVirtualCollector(module, facts_obj, result, 'test')

    # Negative test cases
    if sys.version_info[0] < 3:
        # Class name is already present in the 'result' dictionary
        result['virtualization_type'] = 'NA'

# Generated at 2022-06-23 02:19:55.753545
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    print("start test_LinuxVirtual_get_virtual_facts()")

    # Set the virtual_facts['virtualization_type'] to NA,
    # to ensure the correct value is returned.
    virtual_facts['virtualization_type'] = 'NA'
    linux_virtual = LinuxVirtual(None)
    virtual_facts = linux_virtual.get_virtual_facts()

    print("test_LinuxVirtual_get_virtual_facts() virtual_facts =")

# Generated at 2022-06-23 02:19:59.116304
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    obj = LinuxVirtual()
    mock_module = Mock(return_value=None)
    mock_module.run_command.return_value = (0, 'value', '')
    mock_module.get_bin_path.return_value = '/bin/false'
    obj.module = mock_module
    assert obj.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_host': set(['kvm']), 'virtualization_tech_guest': set(['kvm'])}
# class SELinux

# Generated at 2022-06-23 02:20:05.864482
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    os_obj = LinuxVirtual(module)
    obj = os_obj.get_virtual_facts()
    assert obj.has_key('virtualization_role')
    assert obj.has_key('virtualization_type')
    assert obj.has_key('virtualization_tech_host')
    assert obj.has_key('virtualization_tech_guest')

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:20:13.468868
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})

    # Initialize the LinuxVirtual object
    linux_virtual_facts_object = LinuxVirtual(module)

    # Test the get_all_virtual_facts() function
    linux_virtual_facts = linux_virtual_facts_object.get_all_virtual_facts()
    assert linux_virtual_facts['virtualization_type'] != None
    if linux_virtual_facts['virtualization_type'] != 'NA':
        assert linux_virtual_facts['virtualization_role'] != None



# Generated at 2022-06-23 02:20:17.365436
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virt = LinuxVirtualCollector(dict())
    assert(virt.fact_class._platform == 'Linux')
    assert(virt.fact_class.__class__ == LinuxVirtual)
    assert(virt.platform == 'Linux')


# ===========================================
# RedHatVirtual sub class to run fact collection
# ===========================================

# Generated at 2022-06-23 02:20:19.780561
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    mod = ansible_module_mock()
    col = LinuxVirtualCollector(mod)
    mod.exit_json.assert_called_with(ansible_facts={})


# Generated at 2022-06-23 02:20:30.906617
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    with tempfile.NamedTemporaryFile() as virtfile:
        os.write(virtfile.fileno(), b"virtual\n")
        os.write(virtfile.fileno(), b"product_name:VMware\n")
        os.write(virtfile.fileno(), b"vendor:VMware\n")
        os.write(virtfile.fileno(), b"family:VMware\n")
        os.write(virtfile.fileno(), b"bios_vendor:VMware\n")
        os.write(virtfile.fileno(), b"systemd_container:docker\n")
        os.write(virtfile.fileno(), b"system_product_name:KVM\n")
        os.write(virtfile.fileno(), b"system_vendor:KVM\n")
        os

# Generated at 2022-06-23 02:20:32.626026
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector is not None


# Generated at 2022-06-23 02:20:43.325182
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Unit test to test if method get_virtual_facts of LinuxVirtual class
    is working properly
    """

    # create an object for class LinuxVirtual
    lvirtual = LinuxVirtual()
    # create an object of class module_utils.basic.AnsibleModule
    ans_obj = AnsibleModule(argument_spec={})
    # update the object of AnsibleModule with required arguments
    ans_obj.params = {}
    # set the object of AnsibleModule in object of class LinuxVirtual
    lvirtual.set_module(ans_obj)

    # set a common return value for method run_command of class AnsibleModule
    ans_obj.run_command = MagicMock(return_value=(0, "", ""))

    # set a common return value for method get_file_content of class AnsibleModule
    ans_obj.get_

# Generated at 2022-06-23 02:20:49.264881
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lv = LinuxVirtualCollector()
    assert lv.__class__.__name__ == 'LinuxVirtualCollector'
    assert lv._fact_class.__name__ == 'LinuxVirtual'
    assert lv._platform == 'Linux'



# Generated at 2022-06-23 02:20:52.501816
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    assert linux_virtual.get_virtual_facts()


# ===========================================
# Subclass DefaultVirtual
#
#   This is for all platforms that are not
#   Linux and are not virtual
# ===========================================

# Generated at 2022-06-23 02:20:58.356509
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    virt = LinuxVirtual(module)
    facts = virt.get_virtual_facts()

    assert facts['virtualization_type'] == 'NA'
    assert facts['virtualization_role'] == 'NA'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:21:07.780129
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Test case1:
    # Input:
    #   os_version = None
    #   os_release = None
    #   kernel = None
    # Expected result:
    #   An error will be returned
    os_version = None
    os_release = None
    kernel = None
    expected_result = 'Error: OS version or OS release or kernel is not set'
    result = None
    try:
        virtual = LinuxVirtualCollector(os_version, os_release, kernel)
    except AssertionError as error:
        result = error.args[0]
    assert result == expected_result
    # Test case2:
    # Input:
    #   os_version = 'Linux'
    #   os_release = '7'
    #   kernel = '3.10.0-123.el7.

# Generated at 2022-06-23 02:21:10.211345
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """This function is to test constructor of LinuxVirtual class."""
    module = Mock()
    obj_linux_virtual = LinuxVirtual(module)
    assert obj_linux_virtual.module == module


# Generated at 2022-06-23 02:21:14.694291
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    test = LinuxVirtual()

    keys = ('virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host')

    for key in keys:
        assert key in test.data.keys(), "%s key missing from data" % key



# Generated at 2022-06-23 02:21:19.441743
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """linux_virtual"""
    module = AnsibleModule(argument_spec=dict())
    my_obj = LinuxVirtual(module)
    result = my_obj.get_facts()

    module.exit_json(ansible_facts=result)

# import module snippets
from ansible.module_utils.basic import *

main()

# Generated at 2022-06-23 02:21:25.370031
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    '''Return multiple facts sets when multiple interfaces are defined.'''
    module = AnsibleModule(argument_spec={})
    is_linux = True
    if is_linux:
        collector = LinuxVirtualCollector(module)
        facts = collector.collect()
        keys = ['virtualization_role', 'virtualization_type', 'virtualization_tech_guest']
        for key in keys:
            assert key in facts

# Generated at 2022-06-23 02:21:32.342051
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    sys_path_save = sys.path
    try:
        sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))
        from ansible.module_utils.facts import ModuleFacts
        module = ModuleFacts(verbosity=0)
        results = LinuxVirtualCollector(module).collect()
        assert type(results) is dict
    finally:
        # Restore sys.path to what it was before
        sys.path = sys_path_save

# Generated at 2022-06-23 02:21:37.537773
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    virtual_collector = LinuxVirtualCollector()
    assert virtual_collector._fact_class.__name__ == 'LinuxVirtual'
    assert virtual_collector._fact_class._module == module
    assert virtual_collector._platform == 'Linux'



# Generated at 2022-06-23 02:21:49.050317
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    test_LinuxVirtual_get_virtual_facts(my_module):

        - name: Gather virtual facts
          set_fact:
            virtual_facts: "{{ ansible_virtual.get_virtual_facts() }}"
    """
    ansible_virtual = {"system_vendor": "OpenStack Foundation", "product_name": "OpenStack Compute", "virtual": "full", "product_serial": "44454c4c-3700-1052-8031-b2c04f445931", "system_serial": "44454c4c-3700-1052-8032-b2c04f445931", "product_uuid": "00000000-0000-0000-0000-000000000000", "product_version": "2013.1.5", "virtualization_type": "kvm"}

# Generated at 2022-06-23 02:21:59.034221
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from unittest.mock import Mock
    from ansible.module_utils.facts.virtual import Virtual
    import os
    import sys
    import pkg_resources

    virtual_facts = {
        'virtualization_role': 'NA',
        'virtualization_type': 'NA',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    mocked_module = Mock()
    mocked_module.get_bin_path.return_value = pkg_resources.resource_filename('ansible.module_utils.facts.virtual', 'virt-what')

    mocked_module.run_command = mocked_run_command = Mock()
    mocked_run_command.return_value = (0, 'vmware', '')

    mocked_module.file_exists = mocked_file

# Generated at 2022-06-23 02:22:02.332105
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test that if LinuxVirtualCollector is instantiated
    will return the correct LinuxVirtual object
    """
    linux_virtual = LinuxVirtualCollector(None)
    assert isinstance(linux_virtual, LinuxVirtual)
    assert linux_virtual.platform == 'Linux'


# Generated at 2022-06-23 02:22:09.870625
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test get_virtual_facts method of LinuxVirtual class.
    """
    if not HAS_SYS_VIRTUAL:
        module = AnsibleModule(argument_spec={})
        module.skip_json = True
        module.fail_json(msg='sys-virtual python module not available')

    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    # Set expected_virtual_facts based on your system
    # expected_virtual_facts = {'virtualization_role': 'NA', 'virtualization_type': 'NA'}
    expected_virtual_facts = {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set()}
   

# Generated at 2022-06-23 02:22:13.904871
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()

    assert isinstance(lvc.facts, LinuxVirtual)
    assert lvc.facts.__class__.__name__ == 'LinuxVirtual'
    assert lvc._platform == 'Linux'



# Generated at 2022-06-23 02:22:17.086716
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test constructor of class LinuxVirtualCollector
    """
    virt_col = LinuxVirtualCollector()
    assert virt_col.platform == 'Linux'
    assert virt_col.fact_class == LinuxVirtual



# Generated at 2022-06-23 02:22:26.167106
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    name = 'test_LinuxVirtual_get_virtual_facts'
    hostname = 'localhost'
    # Stub
    try:
        fh = open('/proc/cpuinfo', 'r')
        content_cpuinfo = fh.readlines()
        fh.close()
    except Exception as e:
        print("%s: failed to read /proc/cpuinfo file: %s" % (name, str(e)))
        return
    return_mock = content_cpuinfo
    mocker = MagicMock()
    mocker.return_value = return_mock
    # Test
    module = AnsibleModule({'gather_facts': 'no'}, {'ansible_facts': {}})
    with patch.object(LinuxVirtual, 'get_file_lines', mocker):
        module.get_bin_path

# Generated at 2022-06-23 02:22:28.733898
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    instance = LinuxVirtualCollector()
    assert isinstance(instance._virtual, LinuxVirtual)


# Generated at 2022-06-23 02:22:32.285608
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Constructor tests.
    """
    module = AnsibleModuleMock()
    virt = LinuxVirtualCollector(module)
    assert virt.platform == 'Linux'
    assert virt.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:22:44.477736
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    linux_virt = LinuxVirtual(module)
    with patch.object(linux_virt, 'get_file_content') as mock_get_file_content:
        with patch.object(linux_virt, 'get_file_lines') as mock_get_file_lines:
            mock_get_file_content.return_value = "1" # container_id

# Generated at 2022-06-23 02:22:48.196103
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    data = LinuxVirtual().get_virtual_facts()
    assert 'virtualization_type' in data
    assert 'virtualization_role' in data
    assert 'virtualization_tech_host' in data
    assert 'virtualization_tech_guest' in data

# Generated at 2022-06-23 02:22:56.532003
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import unittest
    from unittest import mock
    from ansible_collections.community.general.plugins.inventory.virtual.linux_virtual import LinuxVirtual

    # Mock the sys.virt_vars method, so that it does not try to read from outside the test environment

# Generated at 2022-06-23 02:23:06.705920
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    import sys
    import unittest
    import doctest

    class MockModule(object):
        def __init__(self):
            self._path = os.getenv('PATH').split(':')
            self._tmpdir = tempfile.mkdtemp(prefix='test_virtual_facts')
            self._files = []
            self.run_command_calls = 0
            self._exit_status = 0
            self._run_command_stdout = ""

        def get_bin_path(self, name):
            for path in self._path:
                full_path = os.path.join(path, name)
                if os.path.exists(full_path):
                    return full_path
            return None


# Generated at 2022-06-23 02:23:11.288221
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)
    assert lv.virtual_facts['virtualization_role'] == 'guest'
    assert lv.virtual_facts['virtualization_type'] == 'virtualbox'


# Generated at 2022-06-23 02:23:15.276063
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModuleMock()
    my_linux_virtual_facts = LinuxVirtual(module)
    if my_linux_virtual_facts:
        assert my_linux_virtual_facts is not None

# Unit test functions

# Generated at 2022-06-23 02:23:17.908357
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Constructor shouldn't raise any exception
    c = LinuxVirtualCollector(None)
    assert c is not None


# Generated at 2022-06-23 02:23:20.420932
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    obj.collect()
    assert obj.fact_class._platform == 'Linux'

# Generated at 2022-06-23 02:23:24.848628
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    assert lv.virtual_facts['virtualization_type'] == 'NA'
    assert lv.virtual_facts['virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:23:31.485036
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    import platform
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=['!all', '!min'], type='list'),
        ),
        supports_check_mode=True,
    )

    lv = LinuxVirtual(module)


# Generated at 2022-06-23 02:23:34.501016
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    facts = LinuxVirtual(module=None).populate()
    assert 'virtualization_role' in facts


# Generated at 2022-06-23 02:23:35.810618
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()


# Generated at 2022-06-23 02:23:39.201467
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """ Unit test for constructor of class LinuxVirtual """
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)

    assert linux_virtual is not None


# Generated at 2022-06-23 02:23:40.521523
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()


# Generated at 2022-06-23 02:23:42.418957
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual_facts = LinuxVirtual(None).populate()
    # Check the output from each module
    assert isinstance(virtual_facts, dict)
