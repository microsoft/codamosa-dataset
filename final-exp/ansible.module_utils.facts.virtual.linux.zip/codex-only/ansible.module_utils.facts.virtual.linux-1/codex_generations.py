

# Generated at 2022-06-23 02:13:51.613543
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test for constructor of class LinuxVirtualCollector"""
    module_args = {}
    module = AnsibleModule(argument_spec=module_args,
                           supports_check_mode=True)
    collector = LinuxVirtualCollector(module)
    try:
        assert collector.platform == 'Linux'
        assert collector.fact_class == LinuxVirtual
    except AssertionError as e:
        raise AssertionError(e)


# Generated at 2022-06-23 02:14:00.079841
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    lc = LinuxVirtualCollector(module=module)
    linux_virtual_collector_obj = LinuxVirtual(module=module)
    assert isinstance(lc.virtual_facts, LinuxVirtual)
    assert linux_virtual_collector_obj.get_file_content.__name__ == LinuxVirtual.get_file_content.__name__
    assert linux_virtual_collector_obj.get_file_lines.__name__ == LinuxVirtual.get_file_lines.__name__



# Generated at 2022-06-23 02:14:04.379832
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    virtual_collector = LinuxVirtual()
    module.exit_json(changed=False, ansible_facts=dict(virtual_facts=virtual_collector.collect(module)))


# Generated at 2022-06-23 02:14:16.849140
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Sample return values of os.path.exists and os.access
    exists_ret = [False, False, False, False]
    access_ret = [True, True, True, True]

    # Sample return values of open.readlines
    readlines_ret = [['cgroup', 'cgroup', 'cgroup', 'cgroup'],
                     ['cgroup', 'cgroup', 'cgroup', 'cgroup'],
                     ['5:blkio:blkio', '0::cpuset', '1::cpu,cpuacct', '2:name=systemd:', '3:memory:'],
                     ['5:blkio:blkio', '0::cpuset', '1::cpu,cpuacct', '2:name=systemd:', '3:memory:']]

    # Sample return values of os.list

# Generated at 2022-06-23 02:14:21.565972
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Makes some assertions using instances of the class "LinuxVirtual".
    '''
    TEST_MOD = FakeModule()
    linux_virtual = LinuxVirtual(TEST_MOD)

    assert linux_virtual.module == TEST_MOD


# Unit tests for method 'read_virtual_facts'

# Generated at 2022-06-23 02:14:29.560439
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={
        'fact_path': {'type': 'str', 'required': False},
    })

    vm = LinuxVirtual(module)
    vm.get_virtual_facts()


# -*- -*- -*- End included fragment: class/linux_virtual.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: ansible/module_utils/facts/virtual/__init__.py -*- -*- -*-



# Generated at 2022-06-23 02:14:33.487802
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the constructor of the LinuxVirtual class
    """
    module = AnsibleModule(argument_spec={})
    is_linux_virtual_instance = LinuxVirtual(module)
    assert is_linux_virtual_instance is not None


# Generated at 2022-06-23 02:14:34.963429
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(VirtualCollector.factory(),
                      LinuxVirtualCollector)

# Generated at 2022-06-23 02:14:37.789684
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    import ansible.module_utils.facts.virtual as virtual
    hc = LinuxVirtualCollector(virtual, platform='Linux')
    assert isinstance(hc, LinuxVirtualCollector)


# Generated at 2022-06-23 02:14:40.966651
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    vm = LinuxVirtual()
    assert vm.get_virtual_facts()

# end class LinuxVirtual


# Generated at 2022-06-23 02:14:44.518170
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    v = LinuxVirtual()
    # TODO: Make tests for get_virtual_facts method
    v.module.exit_json(changed=False, ansible_facts=dict(foo='bar'))


# Generated at 2022-06-23 02:14:48.318751
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.virtual.linux import LinuxVirtualCollector
    # Test object creation
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector is not None
    # Assert class of virtual_collector's fact_class
    assert linux_virtual_collector.fact_class is LinuxVirtual
    # Assert platform of virtual_collector
    assert linux_virtual_collector.platform == 'Linux'


# Generated at 2022-06-23 02:14:50.846855
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    result = LinuxVirtualCollector(dict())
    assert isinstance(result, LinuxVirtualCollector)


# Generated at 2022-06-23 02:15:01.711669
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    vit = LinuxVirtual()
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    vit.set_module(module)

    rc, out, err = vit.module.run_command('uname -a')
    if rc != 0:
        raise Exception("Failed to run command 'uname -a'")

    if 'amd64' in out:
        rc, out, err = vit.module.run_command('grep -q "hypervisor" /proc/cpuinfo')
        if rc != 0:
            raise Exception("Failed to run command 'grep -q 'hypervisor' /proc/cpuinfo'")

        if out == '1\n':
            rc, out, err = vit.module.run_command('dmesg | grep -q "VMware"')

# Generated at 2022-06-23 02:15:04.189127
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virt = LinuxVirtual('')
    if virt is None:
        raise AssertionError("LinuxVirtual constructor failed.")


# Generated at 2022-06-23 02:15:08.225297
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    v = LinuxVirtual()
    virtual_facts = v.get_virtual_facts(module)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-23 02:15:10.541019
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virt_collector = LinuxVirtualCollector()
    assert isinstance(virt_collector, VirtualCollector) and isinstance(virt_collector, LinuxVirtualCollector)


# Generated at 2022-06-23 02:15:21.014741
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible_collections.os.linux.tests.unit.compat.mock import patch
    import os.path
    import sys
    import platform

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # If the system we are running is not an EL, we have to skip the test.
    if not platform.dist()[0] in ('redhat', 'fedora', 'centos', 'oraclelinux', 'rhel'):
        display.displayText("Skip because this is not an EL system.\n")
        return

    # We want to skip tests, if dmidecode is not present

# Generated at 2022-06-23 02:15:26.116858
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    results = dict(
        changed=False,
        virtual=dict(),
    )
    virtual = LinuxVirtual(module)
    results['virtual'] = virtual.collect()
    module.exit_json(**results)



# Generated at 2022-06-23 02:15:28.922212
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    test_object = LinuxVirtual(dict())
    assert isinstance(test_object, LinuxVirtual)
    assert isinstance(test_object.module, AnsibleModule)


# Generated at 2022-06-23 02:15:36.490571
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    linux_virtual = LinuxVirtual(module)

    # Test with predefined values
    assert linux_virtual.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'virtualbox',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'virtualbox'}
    }


# Generated at 2022-06-23 02:15:48.054673
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import sys, os, mock
    sys.path.append(os.path.join('..', '..', 'lib'))
    import common
    host_facts = dict()
    host_facts['ansible_processor_vcpus'] = 4
    host_facts['ansible_processor_vendor'] = 'Intel'
    host_facts['ansible_processor'] = 'AMD'
    host_facts['ansible_lsb'] = dict()
    host_facts['ansible_lsb']['codename'] = 'xenial'
    host_facts['ansible_kernel'] = '4.10.0-42-generic'
    host_facts['ansible_os_family'] = 'RedHat'
    host_facts['ansible_distribution'] = 'Ubuntu'

# Generated at 2022-06-23 02:15:50.986553
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test the constructor of LinuxVirtualCollector class
    Return:
        A LinuxVirtualCollector object
    """
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector


# Generated at 2022-06-23 02:15:53.839597
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector(None)
    assert linux_virtual_collector.platform == 'Linux'
    assert isinstance(linux_virtual_collector.get_virtual_facts(), LinuxVirtual)


# Generated at 2022-06-23 02:16:04.726661
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import sys
    import os
    import tempfile
    import shutil
    import unittest.mock as mock
    # Construct a mock instance of class Module
    class MockModule:
        def __init__(self):
            self.exit_json = mock.MagicMock()
            self.fail_json = mock.MagicMock()
            # Construct a mock instance of class AnsibleModule
            class MockAnsibleModule:
                def __init__(self):
                    self.params = {}
            self.params = mock.MagicMock()
            self.params.__getitem__ = mock.MagicMock(side_effect=self.params.__getitem__)
            self.params.get = mock.MagicMock(side_effect=self.params.get)
            self.params.__contains__ = mock.MagicM

# Generated at 2022-06-23 02:16:12.292374
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    mod_mock = MagicMock(name='module')
    mod_mock.get_bin_path.return_value = '/usr/bin/dmidecode'

    # Create a instance of the LinuxVirtualCollector class
    lv_collector = LinuxVirtualCollector(module=mod_mock)

    # Test whether the attributes are correctly set
    assert lv_collector._fact_class == LinuxVirtual
    assert lv_collector._platform == 'Linux'



# Generated at 2022-06-23 02:16:20.472097
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
        """
        Test class LinuxVirtual constructor.

        :returns: None
        """
        module = AnsibleModule(argument_spec={})
        is_py2 = sys.version[0] == '2'
        if is_py2:
            linux_virtual = LinuxVirtual(module)
        else:
            with pytest.raises(AnsibleExitJson) as exc:
                LinuxVirtual(module)
            assert 'msg' in exc.value.args[0]
        del module
        del linux_virtual


# Generated at 2022-06-23 02:16:23.354202
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Unit test for constructor of class LinuxVirtual'''
    my_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    linux_virtual = LinuxVirtual(my_module)

    assert linux_virtual is not None


# Generated at 2022-06-23 02:16:27.676327
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_obj = LinuxVirtual()
    all_facts = dict(
        ansible_facts=dict(
            virtual=dict()
        )
    )
    return_value = test_obj.get_virtual_facts()
    assert return_value == all_facts['ansible_facts']['virtual']


# Generated at 2022-06-23 02:16:32.261301
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    lv = LinuxVirtual(module)
    module.exit_json(changed=False, ansible_facts={"virtual": lv.get_virtual_facts()})


# Generated at 2022-06-23 02:16:42.322094
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Import the class
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.linux_virtual import LinuxVirtual

    # Create an instance of LinuxVirtual
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = '/bin/dmidecode'
    module_mock.run_command.return_value = (0, 'some-command-output', 'some-command-error')
    linux_virtual = LinuxVirtual(module_mock)

    # Call the get_virtual_facts() method
    result = linux_virtual.get_virtual_facts()
    assert result == {
        'virtualization_type': 'some-command-output',
        'virtualization_role': 'some-command-output'
    }

# Generated at 2022-06-23 02:16:47.342106
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    linux_virtual = LinuxVirtual(module)
    facts = linux_virtual.populate()
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts


# Generated at 2022-06-23 02:16:50.546906
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    keys = ['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']
    assert set(linux_virtual.virtual_facts) <= set(keys)


# Generated at 2022-06-23 02:16:55.322137
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test constructor of class LinuxVirtualCollector."""
    module = AnsibleModuleMock()
    module.params = {}
    linux_virtual_collector = LinuxVirtualCollector(module)

    assert linux_virtual_collector.fact_class == LinuxVirtual
    assert linux_virtual_collector.platform == 'Linux'



# Generated at 2022-06-23 02:17:00.468054
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Constructor of LinuxVirtualCollector class
    """
    lin_virtual_obj = LinuxVirtualCollector()
    assert lin_virtual_obj._platform == 'Linux'
    assert lin_virtual_obj._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:17:05.391383
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test for LinuxVirtualCollector class."""
    module = AnsibleModule(argument_spec={})
    platform_virtual = LinuxVirtualCollector(module)
    assert platform_virtual._fact_class == LinuxVirtual
    assert platform_virtual._platform == 'Linux'


# Generated at 2022-06-23 02:17:07.902308
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    isinstance(LinuxVirtualCollector(module), VirtualCollector)


# Generated at 2022-06-23 02:17:18.072137
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual.py
    ~~~~~~~~~~~~~~~~~~~~
    :license: GPLv3, see LICENSE for more details.
    """
    # Linux Virtual Facts class creation for testing purpose
    virtual_facts = LinuxVirtual()

    # For testing purpose, we will use some other variables in place of ansible_facts
    class Object(object):
        pass

    ansible_facts = Object()

    # Call get_virtual_facts() of LinuxVirtual class for testing purpose
    virtual_facts.get_virtual_facts(ansible_facts)

    # Assertion for linux_virtual.py
    assert ansible_facts.virtualization_role == 'host' or 'guest' or 'NA'

# Generated at 2022-06-23 02:17:20.402371
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()  # This should not trigger any exception
    assert c is not None


# Generated at 2022-06-23 02:17:26.162330
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Constructor of LinuxVirtual
    '''
    module = ansible_mock.MockModule()
    linux_virtual_object = LinuxVirtual(module)
    assert isinstance(linux_virtual_object._module, ansible_mock.MockModule)


# Unit tests for common methods of the class LinuxVirtual

# Generated at 2022-06-23 02:17:29.131211
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector(None)
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'


# Generated at 2022-06-23 02:17:38.925707
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    fake_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all'])
        )

    )
    lv = LinuxVirtual(fake_module)
    lv.get_virtual_facts()
    assert lv.virtual_facts['virtualization_type'] == 'VMware'
    assert lv.virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:17:46.344108
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Setup test for get_virtual_facts
    :return:
    '''

    # Mock data for get_file_lines

# Generated at 2022-06-23 02:17:52.939381
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtualCollector().collect()
    assert 'virtual' in facts
    assert 'virtualization_role' in facts['virtual']
    assert 'virtualization_type' in facts['virtual']
    assert 'virtualization_tech_guest' in facts['virtual']
    assert 'virtualization_tech_host' in facts['virtual']
    assert 'virtualization_tech_product' in facts['virtual']
    assert 'virtualization_tech_vendor' in facts['virtual']
    assert 'virtualization_tech_version' in facts['virtual']

# Generated at 2022-06-23 02:17:57.953725
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = Mock(return_value=None)
    module.get_bin_path = Mock(return_value=None)
    module.run_command = Mock(return_value=None)
    collector = LinuxVirtualCollector(module=module)
    assert hasattr(collector, '_platform') and collector._platform == 'Linux'



# Generated at 2022-06-23 02:18:01.160752
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:03.913072
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert c.platform == 'Linux'
    assert c.fact_class == LinuxVirtual
    assert c.fact_name == 'virtual'


# Generated at 2022-06-23 02:18:13.439789
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual.py
    ~~~~~~~~~~~~~~~~
        This test ensures that when creating an instance of
        LinuxVirtual class that we get a correctly initialized
        object back.
    """
    import platform
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    platform_facts = platform.uname()._asdict()
    virtual_facts = LinuxVirtual({'ansible_facts': {'platform': platform_facts},
                                  'module': BaseFactCollector(None, None)})

    assert virtual_facts.platform == 'Linux'

# Generated at 2022-06-23 02:18:16.940709
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    v = LinuxVirtual()
    output = v.get_virtual_facts()

    expected_output = {'virtualization_role': 'guest',
                       'virtualization_type': 'kvm'}

    assert output == expected_output

# vim: set et sts=4 sw=4 :

# Generated at 2022-06-23 02:18:21.214177
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual.py
    ~~~~~~~~~~~~~~~~
        Unit test for constructor of class LinuxVirtual
    """
    obj = LinuxVirtual()
    assert isinstance(obj.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:18:24.830167
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Test constructor of class LinuxVirtual
    '''
    # Initialize mock environment
    linux_virtual = LinuxVirtual(dict(module=MagicMock(),
                                      params=dict()))

    # Check values
    assert isinstance(linux_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:18:27.418795
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    obj = LinuxVirtual(module)
    result = obj.get_virtual_facts()
    assert type(result) is dict

# Generated at 2022-06-23 02:18:32.956272
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # In order for unit test to pass, the file /sys/devices/virtual/dmi/id/product_name must exist and return 'RHEL Atomic Host'
    from ansible.module_utils.facts.virtual import LinuxVirtual
    from ansible.module_utils.facts.facts import Facts

    facts = Facts({})
    LinuxVirtual_object = LinuxVirtual({}, facts)
    virtual_facts = LinuxVirtual_object.get_virtual_facts()
    assert virtual_facts == {'virtualization_role': 'host'}



# Generated at 2022-06-23 02:18:35.115940
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    linux_virtualcollector = LinuxVirtualCollector(module)
    assert isinstance(linux_virtualcollector, LinuxVirtualCollector)


# Generated at 2022-06-23 02:18:36.037432
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()

# Generated at 2022-06-23 02:18:40.842912
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    linux_virtual = LinuxVirtual(module)

    result = linux_virtual.get_virtual_facts()
    assert isinstance(result, dict)

    module.exit_json(changed=False, virtual=result)


# Generated at 2022-06-23 02:18:48.996680
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():  # noqa: E501
    linux_virtual = LinuxVirtual('module')
    if os.uname()[4] == 'x86_64':
        assert linux_virtual.get_virtual_facts() == {'virtualization_type': 'physical', 'virtualization_role': 'NA', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}
    else:
        assert linux_virtual.get_virtual_facts() == {'virtualization_type': 'physical', 'virtualization_role': 'NA'}


# Generated at 2022-06-23 02:18:51.214816
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """This method will do the unit test for constructor of class LinuxVirtualCollector."""
    LinuxVirtualCollector()


# Generated at 2022-06-23 02:18:54.360424
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # This will run the constructor test, if the class is being run as a program
    # Provide the facts as an 'ansible_facts' parameter
    LinuxVirtualCollector(dict())


# Generated at 2022-06-23 02:19:05.259633
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModuleMock()

    # Testing with /proc/1/cgroup file contents for docker

# Generated at 2022-06-23 02:19:07.033288
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Test creating object
    x = LinuxVirtualCollector()
    assert x is not None

# Generated at 2022-06-23 02:19:13.596421
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.virtual.linux_virtual as linux_virtual
    import os
    import stat

    virt_facts = {}

    # set the virtual facts that are to be returned by get_virtual_facts
    virt_facts['virtualization_role'] = 'host'
    virt_facts['virtualization_type'] = 'kvm'
    virt_facts['virtualization_tech_host'] = set(['kvm'])
    virt_facts['virtualization_tech_guest'] = set([])

    # set /proc/1/cgroup to a test value, not the real value

# Generated at 2022-06-23 02:19:21.816460
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    expected_facts = {
        "virtualization_role": "host",
        "virtualization_type": "kvm",
        "virtualization_tech_guest": ["vz", "container", "lxc", "docker", "KubeVirt", "RHEV"],
        "virtualization_tech_host": ["Xen", "kvm", "RHEV"]
    }

    mock_module = MagicMock(return_value=True)
    mock_module.run_command = MagicMock(return_value=True)

# Generated at 2022-06-23 02:19:31.639462
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    virtual = LinuxVirtual(module)
    virtual_facts = virtual.collect()

    # LinuxVirtual.collect() always returns a dict
    assert type(virtual_facts) == dict, 'collect() must return a dict'
    assert type(virtual_facts['virtualization_tech_guest']) == set or virtual_facts['virtualization_tech_guest'] == 'NA', 'virtualization_tech_guest must be a set or "NA"'
    assert type(virtual_facts['virtualization_tech_host']) == set or virtual_facts['virtualization_tech_host'] == 'NA', 'virtualization_tech_host must be a set or "NA"'


# Generated at 2022-06-23 02:19:39.232826
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():

    lv = LinuxVirtual()
    lv.module.exit_json = lambda x: x
    lv.module.run_command = lambda x: (0, '', '')

    # Test that empty `facts` dict is returned if `dmidecode` is
    # unavailable.
    lv.module.get_bin_path = lambda x: None
    facts = lv.populate()

    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'virtualization_tech_guest' not in facts
    assert 'virtualization_tech_host' not in facts

    # Test that `dmidecode` is used if available.
    lv.module.get_bin_path = lambda x: x
    facts = lv.populate()


# Generated at 2022-06-23 02:19:49.903487
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Mock the module and system
    mocked_module = mock.MagicMock()
    mocked_system = mock.MagicMock()
    mocked_system.distribution = "fake_distro"
    mocked_system.distribution_version = "fake_version"
    mocked_system.distribution_major_version = "fake_major_version"
    mocked_system.system = "fake_system"
    mocked_system.machine = "fake_machine"

    # Mock a virtual class instance
    mocked_virtual = LinuxVirtual(mocked_module, mocked_system)

    # Mock all methods and properties of the mocked_virtual instance
    mocked_virtual.get_file_content.return_value = "fake_content"
    mocked_virtual.get_file_lines = lambda x: ["fake_line1", "fake_line2"]

    #

# Generated at 2022-06-23 02:19:56.722153
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test for constructor of class LinuxVirtual
    """
    lv = LinuxVirtual()
    assert lv.virtual_facts['virtualization_role'] == 'NA'
    assert lv.virtual_facts['virtualization_type'] == 'NA'
    assert lv.virtual_facts['virtualization_tech_guest'] == set()
    assert lv.virtual_facts['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:20:05.810323
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """The following tests are performed:
    - test_LinuxVirtual_linux_only()
    - test_LinuxVirtual_linux_and_kvm_libvirt()
    - test_LinuxVirtual_linux_and_kvm_kernel()
    - test_LinuxVirtual_linux_and_kvm_kernel_and_libvirt()
    - test_LinuxVirtual_docker()
    - test_LinuxVirtual_libvirt_lxc()
    - test_LinuxVirtual_unknown()
    - test_LinuxVirtual_linux_and_docker()
    - test_LinuxVirtual_openvz()
    """
    libvirt = None
    try:
        import libvirt
    except ImportError:
        libvirt = None


# Generated at 2022-06-23 02:20:12.695165
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    from datetime import datetime
    from time import time

    start_time = datetime.now()
    virtual = linux_virtual.populate()
    end_time = datetime.now()

    for key in sorted(virtual):
        module.exit_json(
            msg="%s: %s (%s)" % (
                key, virtual[key],
                (end_time - start_time).microseconds
            )
        )

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:20:19.557878
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.platform == 'Linux'
    assert isinstance(collector._collector, LinuxVirtual)
    assert collector._collector.platform == 'Linux'
    assert collector._collector.module


if __name__ == '__main__':
    # Unit test the virtualization facts
    virtual_collector = LinuxVirtualCollector()
    virtual_collector.collect()
    facts = virtual_collector.get_facts()
    for key, value in sorted(facts.items()):
        fact_type = type(value)
        if fact_type == set:
            print("%s: %s" % (key, ', '.join(value)))
        else:
            print("%s: %s" % (key, value))

# Generated at 2022-06-23 02:20:25.162361
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    fact_collection_process = LinuxVirtual()
    fact_collection_process.get_virtual_facts()
    assert fact_collection_process.get_virtual_facts() == {u'virtualization_role': 'host', u'virtualization_type': 'VMware', u'virtualization_tech_guest': set(['docker', 'container']), u'virtualization_tech_host': set(['VMware'])}

# Generated at 2022-06-23 02:20:28.126023
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import LinuxVirtual
    linuxVirtual = LinuxVirtual()
    print(linuxVirtual.get_virtual_facts())


# Generated at 2022-06-23 02:20:37.677371
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # create an instance of LinuxVirtual class
    lv = LinuxVirtual()

    # create a ansible module with module_utils/basic.py
    lv.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # set system facts
    lv.facts = {}

    # assert if virtual_facts['virtualization_tech_guest'] is not empety
    lv.get_virtual_facts()
    assert lv.virtual_facts['virtualization_tech_guest'] != set()

    return True


# Generated at 2022-06-23 02:20:40.904533
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    lvf = LinuxVirtual(module)
    vrt = lvf.get_virtual_facts()
    assert vrt['virtualization_type'] != 'NA'

# Generated at 2022-06-23 02:20:43.068605
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    obj = LinuxVirtualCollector(module)
    assert obj.platform == 'Linux'
    assert obj._fact_class == LinuxVirtual

# Generated at 2022-06-23 02:20:47.176511
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = LinuxVirtualCollector()
    assert vc._fact_class == LinuxVirtual
    assert vc._platform == 'Linux'

# Generated at 2022-06-23 02:20:52.314269
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    module.exit_json(virtual_facts=virtual_facts)

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:20:53.985150
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    lv = LinuxVirtual(module)
    assert lv.module == module


# Generated at 2022-06-23 02:20:55.960945
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vm = LinuxVirtualCollector()
    assert vm is not None


# Generated at 2022-06-23 02:21:06.701813
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # lxc is a container, so we should return only lxc as virtualization_type
    # and not lxc,docker,uml,openvz,containerd
    test1 = [
        '/proc/vz',
        '/.dockerinit',
        '/proc/bc',
        '/run/systemd/container',
    ]
    expected1 = {
        'virtualization_type': 'lxc',
        'virtualization_role': 'guest',
        'virtualization_tech_host': {'lxc'},
        'virtualization_tech_guest': {'lxc', 'container'},
    }
    assert LinuxVirtual.get_virtual_facts(test1) == expected1

    # docker is a container, so we should return only docker as virtualization_type
    # and not lxc,docker,uml,

# Generated at 2022-06-23 02:21:08.935491
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert lv is not None


# Generated at 2022-06-23 02:21:10.448669
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    result = LinuxVirtualCollector()
    assert result is not None



# Generated at 2022-06-23 02:21:20.585167
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """get_virtual_facts"""
    class MockModule(object):
        """methods for unittest"""
        def get_bin_path(self, arg):
            """mock module"""
            return None
        def run_command(self, arg):
            """mock module"""
            return (0, "", "")
    class MockFile(object):
        """mock class for open"""
        def __init__(self, content_str):
            self.content = content_str
            self.content_list = content_str.splitlines(True)
            self.index = 0
        def read(self):
            """mock method for open"""
            return self.content
        def readline(self):
            """mock method for open"""
            data = self.content_list[self.index]
            self.index

# Generated at 2022-06-23 02:21:23.247058
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    result = LinuxVirtualCollector()
    assert result._fact_class == LinuxVirtual
    assert result._platform == 'Linux'


# Generated at 2022-06-23 02:21:25.880242
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert linux_virtual and linux_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:21:35.673253
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Create a test instance
    mod = AnsibleModule({}, ())
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    mod.get_bin_path = lambda x: os.path.join(base_dir, 'bin', x)
    module = LinuxVirtual(mod)

    # Create a test file
    (fd, fname) = tempfile.mkstemp()

# Generated at 2022-06-23 02:21:37.722338
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Constructor test for LinuxVirtual
    '''
    my_obj = LinuxVirtual()
    assert my_obj.__class__.__name__ == "LinuxVirtual"



# Generated at 2022-06-23 02:21:44.506392
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Create an instance of LinuxVirtual
    virtual_facts = LinuxVirtual().get_virtual_facts()
    # output contains virtualization_type or virtualization_role
    # or both.  Test for this condition
    assert ('virtualization_type' in virtual_facts.keys() or
        'virtualization_role' in virtual_facts.keys())


# Get distribution from a system
# Works with most Linux >= 2.6

# Generated at 2022-06-23 02:21:46.589429
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual(dict())
    assert linux_virtual


# Generated at 2022-06-23 02:21:53.068456
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    if not os.path.exists('/proc/cpuinfo'):
        pytest.skip("system has no /proc/cpuinfo")
    # Create the object that we are going to test
    obj = LinuxVirtual()
    # There is no assert here, because we just want to see that this runs without
    # throwing any exceptions and also returns something.
    result = obj.populate()
    # Print results
    # print "result = %s" % result


# Generated at 2022-06-23 02:21:54.987745
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    m = AnsibleModuleMock()
    module = LinuxVirtual(m)
    assert module is not None

# Generated at 2022-06-23 02:21:59.146027
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    def testfunc(container='container'):
        lv = LinuxVirtual(container)
        return lv.get_virtual_facts()
    assert testfunc() == testfunc('no_container')


# Generated at 2022-06-23 02:22:07.180112
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import platform
    from ansible.module_utils.facts.virtual.base import FactsBaseVirtual
    module = AnsibleModule(
        argument_spec = dict()
    )

    module.params['gather_subset'] = ['!all', 'virtual']

    linux_virtual = LinuxVirtual(module)

    sys_info = {
        'hostname': platform.node(),
        'distribution': platform.system(),
        'distribution_version': platform.release(),
        'distribution_major_version': platform.release(),
        'kernel': platform.system(),
        'kernel_version': platform.release(),
    }


# Generated at 2022-06-23 02:22:09.211491
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # FIXME: in progress
    assert False


# Generated at 2022-06-23 02:22:15.924229
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module_args = dict()
    # FIXME: AnsibleModuleStub is not implemented yet in Ansible
    # FIXME: AnsibleModuleStub needs to be fixed to work with actual ansible module_utils
    # module = AnsibleModuleStub(argument_spec=module_args)
    module = AnsibleModule(argument_spec=module_args)
    linux_virtual = LinuxVirtual(module)
    linux_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:22:19.446041
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x._fact_class.__name__ == 'LinuxVirtual'
    assert x._platform == 'Linux'
    assert x._fact_class._platform == 'Linux'

# Generated at 2022-06-23 02:22:21.800991
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:22:24.217320
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    result = LinuxVirtualCollector()
    assert result
    assert (result.platform == 'Linux')
    assert (result.fact_class == LinuxVirtual)


# Generated at 2022-06-23 02:22:27.120229
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj.fact_class == LinuxVirtual
    assert obj.platform == 'Linux'

# Generated at 2022-06-23 02:22:29.135681
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual

# Generated at 2022-06-23 02:22:32.755614
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)

    assert lv
    assert lv.module
    assert lv.main()
    assert lv.main().get('virtualization_type')


# Generated at 2022-06-23 02:22:45.002431
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    ''' get_virtual_facts'''
    # Example scenario: VirtualBox running on Mac OSX

# Generated at 2022-06-23 02:22:55.871136
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    lv = LinuxVirtual(None)

    module_mock = Mock()
    module_mock.get_bin_path.return_value = None
    lv.module = module_mock

    lv.module.run_command.return_value = (1, 'output', 'error')
    assert lv.get_virtual_facts()['virtualization_type'] == 'NA'

    lv.module.run_command.return_value = (0, '/rhev/', 'error')
    assert lv.get_virtual_facts()['virtualization_type'] == 'RHEV'


# Generated at 2022-06-23 02:23:05.426416
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virt = LinuxVirtual()

    try:
        virt.module = mock.MagicMock()
        virt.module.get_bin_path = mock.Mock(return_value='/bin/dmidecode')
        virt.module.run_command = mock.Mock(return_value=(0, 'VMware', ''))
    except:
        virt.module.get_bin_path = mock.Mock(return_value='/bin/dmidecode')
        virt.module.run_command = mock.Mock(return_value=(0, 'VMware', ''))

    # Test for a guest with VMware virtualization technology
    assert virt.get_virtual_facts()['virtualization_type'] == 'VMware'
    assert virt.get_virtual_facts()['virtualization_role'] == 'guest'
    assert 'VMware'

# Generated at 2022-06-23 02:23:17.388283
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = AnsibleModule(
        argument_spec = dict(),
    )
    # get_file_content mocks

# Generated at 2022-06-23 02:23:22.301793
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    collector = LinuxVirtualCollector(module=module)
    assert collector._platform == 'Linux'
    assert isinstance(collector._fact_class, type)
    assert collector._fact_class.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:23:32.061661
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_args = None
            self.run_command_rc = 0
            self.run_command_return_value = None
            self.run_command_side_effect = None

        def get_bin_path(self, arg):
            return None

        def run_command(self, cmd):
            self.run_command_args = cmd
            if self.run_command_return_value is not None:
                return self.run_command_return_value
            elif self.run_command_side_effect is not None:
                raise self.run_command_side_effect
            else:
                return self.run_command_rc, '', ''


# Generated at 2022-06-23 02:23:42.623996
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(default=None, type='list'),
        ),
        supports_check_mode=True,
    )

    # Inject mocks.
    module.get_bin_path = lambda x: '/bin/' + x
    module.run_command = lambda x: (0, '', '')

    linux_virtual = LinuxVirtual(module)
    result = linux_virtual.get_virtual_facts()
    assert result['virtualization_tech_guest'] == set(['container'])
    assert result['virtualization_tech_host'] == set(['docker', 'kvm'])

