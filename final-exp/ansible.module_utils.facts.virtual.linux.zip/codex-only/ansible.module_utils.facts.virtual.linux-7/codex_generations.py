

# Generated at 2022-06-23 02:13:52.743504
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Test for getting virtual facts for Linux virtual host and guest
    '''
    my_linuxvirtual = LinuxVirtual()
    my_linuxvirtual.module.params = {'gather_subset': '!all,!min'}
    my_linuxvirtual.module.get_bin_path = MagicMock(return_value='/bin/cat')
    my_linuxvirtual.module.run_command = MagicMock(return_value=(0, 'test', ''))

# Generated at 2022-06-23 02:14:01.894982
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.collector.linux.virtual import LinuxVirtualCollector
    from ansible.module_utils.facts.collector import \
        VirtualCollector, \
        BaseVirtualCollector
    # Verify that the constructor for class LinuxVirtualCollector
    # creates an object of class VirtualCollector.
    assert isinstance(LinuxVirtualCollector(), VirtualCollector)
    # Verify that the constructor for class VirtualCollector creates
    # an object of class BaseVirtualCollector.
    assert isinstance(VirtualCollector(), BaseVirtualCollector)
    assert LinuxVirtualCollector().platform == 'Linux'


# Generated at 2022-06-23 02:14:06.395008
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils.facts.virtual.linux.LinuxVirtual import LinuxVirtual
    from ansible.module_utils.facts.virtual.base import BaseVirtual
    import inspect
    import types

    # Create instance of LinuxVirtual class
    virtual = LinuxVirtual()

    # Set module_args to `_ansible_version`
    virtual.module_args = dict(ANSIBLE_VERSION="v1.1.1.0")

    # Test method get_virtual_facts()
    if not isinstance(virtual.get_virtual_facts(), dict):
        raise AssertionError("The method `get_virtual_facts()` of class `LinuxVirtual()` should return a dict.")

# Generated at 2022-06-23 02:14:18.204633
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mock_module = MockModule(exit_json=True)

    mvf = mock.MagicMock()
    mvf.get_file_content = Mock(return_value='')
    mvf.get_file_lines = Mock(return_value=[])

    # Invoke get_virtual_facts of class LinuxVirtual with mvf as the first argument
    # and check if the returned facts are correct
    LinuxVirtual.get_virtual_facts(mvf)
    guest_tech = ['container', 'openvz']
    host_tech = ['openvz']

    virtual_facts = {'virtualization_type': 'openvz',
            'virtualization_role': 'guest',
            'virtualization_tech_guest': guest_tech,
            'virtualization_tech_host': host_tech
            }

# Generated at 2022-06-23 02:14:22.510174
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """linux_virtual - constructor test
    """
    module = AnsibleModule(argument_spec={})
    vm_inst = LinuxVirtual(module)
    expected_legal_values = set(['docker', 'lxc', 'podman', 'openvz', 'systemd-nspawn', 'containerd', 'container', 'kvm', 'oVirt', 'RHV', 'RHEV', 'VMware', 'openstack', 'xen', 'virtualbox', 'linux_vserver', 'kvm', 'parallels', 'openstack', 'uml', 'powervm_lx86', 'PR/SM', 'prsm', 'ibm_systemz', 'bhyve', 'NA'])

# Generated at 2022-06-23 02:14:24.331095
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector(None)
    assert isinstance(x, LinuxVirtualCollector)


# Generated at 2022-06-23 02:14:26.552617
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Helper test function to test the constructor of class LinuxVirtual.
    '''
    return LinuxVirtual()

# Generated at 2022-06-23 02:14:37.591018
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    lv = LinuxVirtual(module)
    # Test parms:
    # virsh cmd output
    # domain type
    # domain id
    # hypervisor name
    # strategy
    # expected virtualization_type
    # expected virtualization_role
    # expected guest_tech
    # expected host_tech

# Generated at 2022-06-23 02:14:45.906484
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    Virtual = LinuxVirtual(module)
    # Test the changes in the facts dictionary
    facts = dict()
    Virtual.get_virtual_facts(facts)
    facts_keys = sorted(facts.keys())
    expected_keys = sorted([
            'virtualization_type', 'virtualization_role',
            'virtualization_tech_guest', 'virtualization_tech_host'])

    assert facts_keys == expected_keys
# end of test_LinuxVirtual()


# Generated at 2022-06-23 02:14:49.513097
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """constructor of class LinuxVirtualCollector
    """
    collector = LinuxVirtualCollector(None)
    assert 'LinuxVirtualCollector' == collector.__class__.__name__
    assert isinstance(collector, VirtualCollector)
    assert 'Linux' == collector._platform
    assert LinuxVirtual == collector._fact_class


# Generated at 2022-06-23 02:14:53.288365
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    lv = LinuxVirtual(module=module)
    module.debug('in test_LinuxVirtual_get_virtual_facts')
    virtual_facts = lv.get_virtual_facts()
    module.exit_json(changed=False, ansible_facts=virtual_facts)


# Generated at 2022-06-23 02:14:54.561018
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    lv.populate()



# Generated at 2022-06-23 02:14:56.510299
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    host = LinuxVirtualCollector()
    assert host.facts_class == LinuxVirtual
    assert host.platform == 'Linux'

# Generated at 2022-06-23 02:15:02.796255
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    TestAnsibleModule = MockAnsibleModule
    test_object = TestAnsibleModule()
    module = test_object.get_module_mock()
    module.get_bin_path.side_effect = lambda arg: arg

    linux_virtual_object = LinuxVirtual(module)
    result = linux_virtual_object.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result


# Generated at 2022-06-23 02:15:11.841213
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Constructor of class LinuxVirtual
    """
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    facts = linux_virtual.get_virtual_facts()
    assert set(facts.keys()) == set(['virtualization_tech_guest', 'virtualization_tech_host',
                                     'virtualization_role', 'virtualization_type'])
    for key in ['virtualization_tech_guest', 'virtualization_tech_host']:
        assert isinstance(facts[key], set)
    for key in ['virtualization_role', 'virtualization_type']:
        assert isinstance(facts[key], str)


# Generated at 2022-06-23 02:15:22.284523
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    class TestModule():

        def get_bin_path(self, path):
            return "/opt/bin/{}".format(path)

        def run_command(self, *args, **kwargs):
            if args[0] == "/opt/bin/lscpu":
                return 0, "Hypervisor:\nKVM", ''
            if args[0] == "/opt/bin/systemd-detect-virt":
                return 1, '', None
            if args[0] == "/opt/bin/dmidecode":
                return 0, "VMWare", ''

    module = TestModule()

   

# Generated at 2022-06-23 02:15:25.442327
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    '''Unit test constructor of class LinuxVirtualCollector'''
    collector = LinuxVirtualCollector()
    assert collector.platform == "Linux"
    assert collector.fact_class == LinuxVirtual



# Generated at 2022-06-23 02:15:36.956843
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # pylint: disable=line-too-long,invalid-name
    ins_obj = LinuxVirtual()
    ins_obj.module = Mock()
    ins_obj.module.get_bin_path = Mock(return_value=True)
    ins_obj.module.get_file_content = Mock(return_value=True)
    ins_obj.module.get_file_lines = Mock(return_value=True)
    ins_obj.module.run_command = Mock(return_value=True)
    ret = ins_obj.get_virtual_facts()
    assert ret['virtualization_type'] == 'OpenStack Nova'
    #assert ret['virtualization_role'] == 'guest'
    assert ret['virtualization_tech_guest'] == {'openstack'}

# Generated at 2022-06-23 02:15:40.024384
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    virtual_collector = LinuxVirtualCollector(module)
    assert virtual_collector is not None
    assert virtual_collector._platform == 'Linux'


# Generated at 2022-06-23 02:15:44.402938
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    '''
    This method will test the constructor of LinuxVirtualCollector.
    '''
    module = AnsibleModuleMock()
    instance = LinuxVirtualCollector(module, None)
    assert isinstance(instance._fact_class, LinuxVirtual)
    assert instance._fact_class._platform == 'Linux'


# Generated at 2022-06-23 02:15:54.446834
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mock_module = MagicMock()

# Generated at 2022-06-23 02:15:57.526662
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    list_of_attributes = dir(linux_virtual)

    assert 'get_virtual_facts' in list_of_attributes


# Generated at 2022-06-23 02:15:59.902494
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector()
    assert virtual.__class__ == VirtualCollector
    assert virtual.platform == 'Linux'


# Generated at 2022-06-23 02:16:06.672919
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mylinux = LinuxVirtual()
    mylinux.module.get_bin_path = MagicMock(return_value='/usr/bin/ls')
    mylinux.module.run_command = MagicMock(return_value=(0, '', ''))
    mylinux.module.params = {'filter': '*', 'gather_subset': 'min'}
    mylinux.get_file_content = MagicMock(return_value='')
    mylinux.module.check_mode = MagicMock(return_value=False)
    mylinux.module.exit_json = MagicMock(return_value=None)
    mylinux.get_virtual_facts()



# Generated at 2022-06-23 02:16:11.248710
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''linux_virtual.py:Constructor'''

    module = AnsibleModule(argument_spec={})
    is_linux_virtual_instance = LinuxVirtual(module)
    assert isinstance(is_linux_virtual_instance, LinuxVirtual)
    assert is_linux_virtual_instance.module == module


# Generated at 2022-06-23 02:16:13.793759
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    is_linux_virtual_instance = isinstance(LinuxVirtual(module), LinuxVirtual)
    assert is_linux_virtual_instance is True

# Generated at 2022-06-23 02:16:17.995970
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector().collect()
    keys = (
        'virtualization_role',
        'virtualization_type',
        'virtualization_tech_guest',
        'virtualization_tech_host'
    )
    for key in keys:
        assert key in virtual



# Generated at 2022-06-23 02:16:20.815537
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    constants.load_system_facts()
    module = AnsibleModule({})
    vm = LinuxVirtual(module)
    vm.get_virtual_facts()


# Generated at 2022-06-23 02:16:22.344174
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert isinstance(linux_virtual, Virtual)


# Generated at 2022-06-23 02:16:31.759473
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    This is a test to determine the values returned by method
    get_virtual_facts of class LinuxVirtual
    """
    get_file_content_orig = LinuxVirtual.get_file_content

    def mock_get_file_content(self, filename):
        """
        This is a mock function for get_file_content method of class
        LinuxVirtual
        """
        return ""

    def mock_get_file_lines(self, filename):
        """
        This is a mock function for get_file_lines method of class
        LinuxVirtual
        """
        return ""

    # Add test for KVM with systemd-detected container
    os_exists_orig = os.path.exists


# Generated at 2022-06-23 02:16:41.078529
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Test method get_virtual_facts of class LinuxVirtual
    '''
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "", "")
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)


# Generated at 2022-06-23 02:16:47.027923
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lv = LinuxVirtual()
    lv.collect()
    assert lv.data.get('virtualization_type') == "virtualbox"
    assert lv.data.get('virtualization_role') == "guest"
    assert lv.data.get('virtualization_tech_guest') == set(['virtualbox'])
    assert lv.data.get('virtualization_tech_host') == set([])

# Generated at 2022-06-23 02:16:49.849964
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector(MockModule())
    assert collector._platform == 'Linux'
    assert isinstance(collector._fact_class, LinuxVirtual)


# Generated at 2022-06-23 02:16:59.245231
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = AnsibleModule(argument_spec={})
    lv.module.get_bin_path = Mock(return_value='')
    lv.module.run_command = Mock()
    lv.module.run_command.return_value = (0, '', '')
    lv.get_file_content = Mock(return_value='')
    lv.get_file_lines = Mock(return_value='')
    assert lv.get_virtual_facts() == {'virtualization_tech_guest': set(),
                                      'virtualization_tech_host': set(),
                                      'virtualization_type': 'NA',
                                      'virtualization_role': 'NA'}
# linux_virtual.py

# Generated at 2022-06-23 02:17:08.260004
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    class TestModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['!all', '!min']}
            self.fail_json = Mock(return_value=None)
            self.exit_json = Mock(return_result=None)

        def get_bin_path(self, arg):
            return "/bin/%s" % arg
    global module_args
    module_args = {}
    linux_virts = LinuxVirtual(TestModule())
    virt_facts = linux_virts.populate()
    assert virt_facts.get('virtualization_role') == 'host'



# Generated at 2022-06-23 02:17:18.004472
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module = MagicMock()
    lv.module.get_bin_path.return_value = '/usr/bin/dmidecode'
    lv.module.run_command.return_value = (0, 'BHYVE', '')
    lv.get_file_content = MagicMock(return_value = 'test_content')
    lv.get_file_lines = MagicMock(return_value = 'test_lines')
    assert lv.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'bhyve', 'virtualization_tech_host': 'set()', 'virtualization_tech_guest': 'set()'}

# Generated at 2022-06-23 02:17:29.934917
# Unit test for constructor of class LinuxVirtual

# Generated at 2022-06-23 02:17:40.862114
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Init
    my_LinuxVirtual = LinuxVirtual()

    ######################
    ### Initial tests ####
    ######################
    assert isinstance(my_LinuxVirtual, LinuxVirtual)

    assert my_LinuxVirtual.module

    #############
    # Unit tests
    #############
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_virtual_facts()
    # test_get_

# Generated at 2022-06-23 02:17:51.991964
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    obj = LinuxVirtual()
    obj.module = MagicMock()
    LinuxVirtual.get_file_lines = MagicMock(return_value=['/containers/lxc/6c5ee6af5b5d23b6f8ca6a55b6b344d6e3854a9a9e085b6d58a6f584d056311c'])
    LinuxVirtual.get_file_content = MagicMock(return_value='/system.slice/docker-6c5ee6af5b5d23b6f8ca6a55b6b344d6e3854a9a9e085b6d58a6f584d056311c.scope')
    obj.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-23 02:17:54.185430
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()

    # Check LinuxVirtualCollector attribute values
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'
#----------------------------------------

#----------------------------------------

# Generated at 2022-06-23 02:17:57.953179
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert LinuxVirtual().get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-23 02:18:00.076092
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    try:
        linux = LinuxVirtualCollector()
    except Exception:
        pass

# Generated at 2022-06-23 02:18:02.458247
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    dut = LinuxVirtual(module)
    dut.get_virtual_facts()

# Generated at 2022-06-23 02:18:04.364698
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector()

    assert virtual.get_platform() == 'Linux'


# Generated at 2022-06-23 02:18:10.810499
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    data = dict()
    data['ansible_facts'] = dict()
    data['ansible_facts']['ansible_system'] = 'Linux'
    data['ansible_facts']['ansible_python_version'] = '2.7.5'
    lv = LinuxVirtual(data)
    assert lv != None


# Generated at 2022-06-23 02:18:15.350704
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test constructor of class LinuxVirtual
    :return:
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None


# Generated at 2022-06-23 02:18:20.753291
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts import collector

    lc = LinuxVirtualCollector()
    assert isinstance(lc._fact_class, LinuxVirtual)
    assert lc._platform == 'Linux'
    assert isinstance(lc, collector.BaseFactCollector)


# Generated at 2022-06-23 02:18:24.344443
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Constructor test linux virtual class
    :return:
    """
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    module.exit_json(changed=False, virtual_facts=lv.get_virtual_facts())



# Generated at 2022-06-23 02:18:33.116682
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Create instance for class LinuxVirtualCollector
    virtual = LinuxVirtualCollector()
    # Check whether virtual is instance of class VirtualCollector
    if isinstance(virtual, VirtualCollector):
        print('Successfully created an instance of class VirtualCollector')
        # Check whether _fact_class of virtual is LinuxVirtual
        if virtual._fact_class == LinuxVirtual:
            print('Successfully verified variable _fact_class of class VirtualCollector with value '
                  'LinuxVirtual')
        else:
            print('Failed to verify variable _fact_class of class VirtualCollector with value '
                  'LinuxVirtual')
    else:
        print('Failed to create an instance of class VirtualCollector')



# Generated at 2022-06-23 02:18:35.795603
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test constructor of class LinuxVirtualCollector
    """
    collect = LinuxVirtualCollector()
    assert collect.platform in ('Linux')
    assert collect.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:40.692881
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test the constructor of LinuxVirtualCollector class."""
    os_virtual = LinuxVirtualCollector(dict(), False, None)
    assert os_virtual._platform == 'Linux'
    assert os_virtual._fact_class == LinuxVirtual
    assert isinstance(os_virtual._fact_class(dict(), False, None), LinuxVirtual)



# Generated at 2022-06-23 02:18:52.532299
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    lv = LinuxVirtual(module)
    setattr(lv, 'module', module)
    setattr(lv, '_check_mode', False)
    setattr(lv, '_dist_version_cache', {})
    setattr(lv, '_dist_version_cache', {})
    setattr(lv, '_cmd_has_bin', {})
    setattr(lv, '_gather_subset', [])
    setattr(lv, '_gather_network_resources', [])
    setattr(lv, '_network_resources', {})
    setattr(lv, '_platform', None)
    setattr(lv, '_socket_path', '')

# Generated at 2022-06-23 02:19:03.681621
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module_args = dict()
    module_args['gather_subset'] = list()
    module_args['gather_subset'].append('all')
    module_args['filter'] = dict()
    module_args['filter']['virtualization_type'] = '*'
    module_args['filter']['virtualization_role'] = '*'
    module_args['filter']['virtualization_tech_guest'] = '*'
    module_args['filter']['virtualization_tech_host'] = '*'
    # create LinuxVirtual object instance
    lxvrt = LinuxVirtual(module_args)
    # test method get_virtual_facts of class LinuxVirtual
    lxvrt_test_facts = dict()

# Generated at 2022-06-23 02:19:07.033778
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Constructor test
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual.module != None
    assert linux_virtual.virtualization_facts == {}



# Generated at 2022-06-23 02:19:14.297763
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Testing constructor of class LinuxVirtual
    '''
    module = AnsibleModule(argument_spec={})
    is_linux = (platform.system() == 'Linux')
    if not is_linux:
        module.fail_json(msg='platform not supported')

    linux_virtual_facts = LinuxVirtual(module)
    basic_facts = linux_virtual_facts.populate()
    module.exit_json(changed=False, ansible_facts=basic_facts)

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:19:16.660640
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test for LinuxVirtual class initialisation.
    """
    linuxv = LinuxVirtual()
    assert isinstance(linuxv, LinuxVirtual)

# Generated at 2022-06-23 02:19:20.414116
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Test the constructor of class LinuxVirtual
    '''
    module = AnsibleModule(argument_spec={})
    my_obj = LinuxVirtual(module)
    assert type(my_obj.module) == AnsibleModule


# Generated at 2022-06-23 02:19:26.890432
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """This function implements the unit test for LinuxVirtualCollector
    """

    import ansible.module_utils.facts.virtual.linux_virtual as linux_virtual
    reload(linux_virtual)

    #create an object
    linux_virtual_collector_obj = LinuxVirtualCollector()

    #check object created successfully
    assert linux_virtual_collector_obj._fact_class is not None

    #cleanup
    del linux_virtual_collector_obj


# Generated at 2022-06-23 02:19:30.574863
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)

    assert isinstance(lv.virtual_subsystems, list)
    assert len(lv.virtual_subsystems) > 0


# Generated at 2022-06-23 02:19:41.690509
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lv = LinuxVirtualCollector(None)
    lv_facts = lv.collect()
    assert 'virtualization_type' in lv_facts['ansible_virtualization_type'], \
           "Error in constructor of class LinuxVirtualCollector, " \
           "could not get virtualization_type from LinuxVirtualCollector."
    assert 'virtualization_role' in lv_facts['ansible_virtualization_role'], \
           "Error in constructor of class LinuxVirtualCollector, " \
           "could not get virtualization_role from LinuxVirtualCollector."
    assert 'virtualization_tech_guest' in lv_facts, \
           "Error in constructor of class LinuxVirtualCollector, " \
           "could not get virtualization_tech_guest from LinuxVirtualCollector."
    assert 'virtualization_tech_host'

# Generated at 2022-06-23 02:19:43.560279
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Instantiate a LinuxVirtual object'''
    LinuxVirtual()


# Generated at 2022-06-23 02:19:46.355839
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert not (lvc.platform_exclude() and lvc.platform_include())



# Generated at 2022-06-23 02:19:49.955959
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    get_virtual_facts unit test stub
    """
    module = AnsibleModule(argument_spec = dict())
    lv = LinuxVirtual(module)
    print(lv.get_virtual_facts())

# Generated at 2022-06-23 02:19:52.291857
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert isinstance(c, LinuxVirtualCollector)
    assert c.facts is None



# Generated at 2022-06-23 02:19:55.006219
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Constructor of LinuxVirtual, called when constructing module
    """
    lv = LinuxVirtual(None)
    assert lv is not None

# Generated at 2022-06-23 02:20:06.034895
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )

    # Mock
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=None)
    module.read_file = MagicMock(return_value='')

    # Get instance of LinuxVirtual class
    obj = LinuxVirtual(module)

    # Test LinuxVirtual.get_virtual_facts()
    # Test with /sys/fs/cgroup/cpu/lxc/ID exists
    os.path.exists = MagicMock(return_value=True)
    get_file_content = MagicMock(side_effect=lambda x: x.replace('/sys/fs/cgroup/cpu/lxc', ''))
    get_file_

# Generated at 2022-06-23 02:20:08.653496
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual

# Generated at 2022-06-23 02:20:18.430567
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """ Unit test for constructor of class LinuxVirtual
    """
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={},
                           supports_check_mode=True)

    linux_virtual = LinuxVirtual(module)

    # Check values of linux_virtual.facts
    linux_virtual_expected_facts = {}
    linux_virtual_expected_facts['virtualization_type'] = 'NA'
    linux_virtual_expected_facts['virtualization_role'] = 'NA'
    linux_virtual_expected_facts['virtualization_tech_guest'] = set()
    linux_virtual_expected_facts['virtualization_tech_host'] = set()


# Generated at 2022-06-23 02:20:24.304574
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    del sys.modules["ansible"]
    sys.modules["ansible"] = MagicMock()
    sys.modules["ansible"].module_utils = AnsibleModuleMock()
    virtual_collector = LinuxVirtualCollector(module=module)
    assert virtual_collector._fact_class is LinuxVirtual
    assert virtual_collector._platform == platform.system()
    assert virtual_collector.name == 'virtual'

# Generated at 2022-06-23 02:20:26.242021
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():

    lv = LinuxVirtual()
    lv.collect()

# Generated at 2022-06-23 02:20:28.776581
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual(None)

    # inits LinuxVirtual
    assert linux_virtual is not None


# Generated at 2022-06-23 02:20:40.861478
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Constructor of LinuxVirtual:
      - Initializes the virtualization facts.
    '''
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual import Virtual
    import tempfile

    virtual_facts = {}

    if not os.path.exists('/proc/cpuinfo'):
        temp_fd, temp_path = tempfile.mkstemp()
        os.close(temp_fd)
        os.mkdir(temp_path)
        os.symlink('/bin/bash', os.path.join(temp_path, 'python'))
        os.environ['PATH'] = ':'.join([temp_path, os.environ['PATH']])

    testmodule = type('Foo', (object,), {})()
    testmodule

# Generated at 2022-06-23 02:20:53.931004
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linst = LinuxVirtual()
    linst.module.get_bin_path = MagicMock(return_value=None)
    linst.module.run_command = MagicMock(return_value=(0, '', ''))
    linst.get_file_lines = MagicMock(return_value=[])
    linst.get_file_content = MagicMock(return_value=None)
    virtual_facts_result = linst.get_virtual_facts()
    assert type(virtual_facts_result) is dict
    assert 'virtualization_type' in virtual_facts_result
    assert 'virtualization_role' in virtual_facts_result
    assert 'virtualization_tech_guest' in virtual_facts_result
    assert 'virtualization_tech_host' in virtual_facts_result

# Generated at 2022-06-23 02:21:02.059681
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    info_dict = {
        'virtualization_type': 'NA',
        'virtualization_role': 'NA',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    mock_module = MagicMock()
    mock_module.fail_json.side_effect = Exception('foo')

    assert LinuxVirtual(mock_module).get_virtual_facts() == info_dict

# Generated at 2022-06-23 02:21:07.956689
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    # Create an instance of the class
    obj = LinuxVirtual(module)
    # Check that virtualization_* keys contain values
    assert (obj.get_virtual_facts()['virtualization_type'] != 'NA')
    assert (obj.get_virtual_facts()['virtualization_role'] != 'NA')
    # Check that the guest and host techs are lists
    assert (isinstance(obj.get_virtual_facts()['virtualization_tech_guest'], set))
    assert (isinstance(obj.get_virtual_facts()['virtualization_tech_host'], set))


# Generated at 2022-06-23 02:21:12.197311
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_facts = LinuxVirtualCollector().collect()
    assert type(virtual_facts) == dict
    for value in virtual_facts.values():
        assert type(value) in (dict, set)



# Generated at 2022-06-23 02:21:15.598195
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    FakeAnsibleModule.initialize()
    FakeAnsibleModule.load_params({})
    fact_obj = LinuxVirtualCollector(FakeAnsibleModule)
    assert isinstance(fact_obj,LinuxVirtualCollector)


# Generated at 2022-06-23 02:21:17.680043
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module_args = dict()
    linux_virtual = LinuxVirtual(module_args)
    assert type(linux_virtual).__name__ == 'LinuxVirtual'

# Generated at 2022-06-23 02:21:21.414919
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    is_linuxvirt_obj1 = LinuxVirtual(module)
    assert is_linuxvirt_obj1.__class__.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:21:24.693266
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    myobj = LinuxVirtual()
    myobj.populate()
    assert myobj.data['virtualization_type'] != 'NA'
    assert myobj.data['virtualization_role'] != 'NA'


# Generated at 2022-06-23 02:21:27.321034
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test constructor of LinuxVirtualCollector"""
    module = AnsibleModuleMock()
    virtual = LinuxVirtualCollector(module)
    assert virtual is not None


# Generated at 2022-06-23 02:21:28.696735
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()

    assert c is not None


# Generated at 2022-06-23 02:21:30.474206
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector() is not None


# Generated at 2022-06-23 02:21:38.692475
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Unit test for constructor of class LinuxVirtualCollector
    """
    module = MagicMock()

# Generated at 2022-06-23 02:21:40.593479
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    myvl = LinuxVirtual()
    assert myvl is not None


# Generated at 2022-06-23 02:21:52.611245
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class LinuxVirtual
    """
    # Set up mock objects
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'foo', 'bar')
    module.get_bin_path.return_value = '/usr/bin/dmidecode'
    tmp_file = []
    tmp_file.append('/run/systemd/container')
    tmp_file.append('/sys/devices/virtual/dmi/id/product_name')
    tmp_file.append('/sys/devices/virtual/dmi/id/sys_vendor')
    tmp_file.append('/sys/devices/virtual/dmi/id/product_family')

# Generated at 2022-06-23 02:21:59.994155
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Constructor of class LinuxVirtualCollector
    """
    linuxvirtual_collector = LinuxVirtualCollector()
    assert linuxvirtual_collector
    assert isinstance(linuxvirtual_collector, VirtualCollector)
    assert linuxvirtual_collector._fact_class is LinuxVirtual
    assert linuxvirtual_collector._platform == 'Linux'
    assert linuxvirtual_collector._capability == 'virtual'
    assert linuxvirtual_collector.fingerprint == platform.system


# Generated at 2022-06-23 02:22:06.597498
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mock_module = AnsibleModule(
        argument_spec = dict(
            filter = dict(type='str', required=True)
        )
    )
    mock_module.params = {'filter': 'foo'}

    mock_LinuxVirtual = LinuxVirtual(mock_module)
    facts = mock_LinuxVirtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'foo'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'foo'}
    assert facts['virtualization_tech_host'] == {}

# Unit test class for module

# Generated at 2022-06-23 02:22:18.831630
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    res = lv.get_virtual_facts()
    assert res['virtualization_role'] in ('guest', 'host', 'NA')
    assert res['virtualization_type'] in ('hyperv', 'lxc', 'openstack', 'kvm', 'container', 'bhyve', 'containerd', 'docker', 'uml',
                                          'parallels', 'podman', 'openvz', 'virtualbox', 'RHEV', 'ibm_systemz', 'KubeVirt', 'powervm_lx86',
                                          'PR/SM', 'RHV', 'systemd-nspawn', 'linux_vserver', 'VMware', 'xen', 'VirtualPC', 'NA')

# Generated at 2022-06-23 02:22:20.655485
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_module = LinuxVirtual()
    assert linux_virtual_module.get_virtual_facts

# Generated at 2022-06-23 02:22:22.593487
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector(None)
    assert collector._fact_class.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:22:29.234004
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test for constructor class LinuxVirtual
    """
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    module.exit_json(changed=False, ansible_facts=lv.get_virtual_facts())

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:22:30.780441
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector is not None


# Generated at 2022-06-23 02:22:39.396875
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    obj = LinuxVirtual()

# Generated at 2022-06-23 02:22:47.864838
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    obj = LinuxVirtual()

    orig_exists = os.path.exists
    def mock_exists(*args, **kwargs):
        if args[0].startswith('/dev/kvm'):
            return True
        if args[0].startswith('/proc/vz'):
            return True
        if args[0].startswith('/proc/self/status'):
            return True
        return orig_exists(*args, **kwargs)
    os.path.exists = mock_exists

    orig_get_file_lines = get_file_lines
    def mock_get_file_lines(*args, **kwargs):
        if args[0] == '/proc/self/status':
            return ['VxID: 0']

# Generated at 2022-06-23 02:22:58.288918
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils.facts.virtual.linux_virtual import (
        LinuxVirtual,
        get_file_content,
        get_file_lines,
    )

    class FakeArgs:
        def __init__(self, module):
            self.module = module

    class FakeModule:
        def __init__(self):
            self.params = {}
            self.args = FakeArgs(self)

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            # cmd is a list, if string, exit
            if isinstance(cmd, list):
                if cmd[0] == 'uname':
                    return (0, 'Linux', '')
                if cmd[0] == 'systemctl':
                    return (0, '', '')

# Generated at 2022-06-23 02:23:00.616673
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():

    lvc = LinuxVirtualCollector()
    assert LinuxVirtualCollector._fact_class == LinuxVirtual
    assert LinuxVirtualCollector._platform == 'Linux'

# Generated at 2022-06-23 02:23:03.188632
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = CollectorsWrap()
    collector = LinuxVirtualCollector(module=module)
    assert collector.module == module
    assert collector.platform == 'Linux'


# Generated at 2022-06-23 02:23:16.160187
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    result = LinuxVirtualCollector()
    assert result._fact_class == LinuxVirtual
    assert result._platform == "Linux"

# Unit tests for linux_virtual()
# Test 1
linux_virtual_output_1 = {
    'virtualization_type': None,
    'virtualization_role': None,
    'virtualization_tech_guest': set(['container']),
    'virtualization_tech_host': set(['KVM', 'openvz'])
}

# Test 2
linux_virtual_output_2 = {
    'virtualization_type': 'virtualbox',
    'virtualization_role': 'guest',
    'virtualization_tech_guest': set(['container', 'virtualbox']),
    'virtualization_tech_host': set(['KVM'])
}

# Test 3


# Generated at 2022-06-23 02:23:28.080474
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = MagicMock()
    lv = LinuxVirtual(module)
    get_file_lines = lv.get_file_lines

    # test with real dmidecode output
    module.get_bin_path = lambda x: '/usr/sbin/dmidecode'

# Generated at 2022-06-23 02:23:31.203787
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    l_vc = LinuxVirtualCollector()
    assert l_vc.platform == 'Linux'
    assert l_vc._fact_class == LinuxVirtual



# Generated at 2022-06-23 02:23:37.685658
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    import platform
    import collections

    virtual_facts = collections.defaultdict(str)

    linux_virtual = LinuxVirtual()
    if platform.system() != 'Linux':
        return
    try:
        virtual_facts = linux_virtual.populate()
    except Exception:
        pass


if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:23:40.527534
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Test a class construction
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector is not None


# Generated at 2022-06-23 02:23:42.204413
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector(None, None)
    assert collector._fact_class == LinuxVirtual
    assert collector._platform == 'Linux'


# Generated at 2022-06-23 02:23:45.623231
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Creates a LinuxVirtualCollector object and returns it.
    :return: LinuxVirtualCollector object
    :rtype: LinuxVirtualCollector
    """
    return LinuxVirtualCollector()
