

# Generated at 2022-06-23 02:13:57.770493
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    # This should not throw an exception.
    lv.get_virtual_facts()
    # test get_file_content
    assert(lv.get_file_content("/etc/hostname", "") == "localhost")
    assert(lv.get_file_content("/tmp/doesnotexist", "") == "")
    assert(not lv.get_file_content("/etc/shadow", "", False))
    # test get_file_lines
    assert(lv.get_file_lines("/etc/hostname") == ["localhost"])
    assert(lv.get_file_lines("/tmp/doesnotexist") == [])
    assert(lv.get_file_lines("/etc/shadow") == [])

# Generated at 2022-06-23 02:14:03.873425
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    This is a unit test for LinuxVirtual constructor without parameters. It'll simply create an object, run the collect function and print the result.
    """
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    result = lv.collect()
    print(result)

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:14:08.150221
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtualCollector(None).collect()
    for fact in facts:
        assert fact in ['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']



# Generated at 2022-06-23 02:14:09.350624
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Test normal instantiation
    obj = LinuxVirtualCollector(None, None)
    assert obj._fact_class == LinuxVirtual
    assert obj._platform == 'Linux'



# Generated at 2022-06-23 02:14:21.325968
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)

    module.run_command = MagicMock(return_value=(0, 'some_out', 'some_error'))
    module.get_bin_path = MagicMock(return_value='some_bin_path')
    module.boolean = MagicMock(return_value='some_bool')
    set_module_args({})

# Generated at 2022-06-23 02:14:22.357806
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert c.platform == 'Linux'
    assert c.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:14:30.483638
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Bunch of mock data
    lv = LinuxVirtual()
    lv.module = mock_module_args({"_ansible_is_executable": Mock(return_value=True), "run_command": Mock()})
    lv.get_virt_facts = Mock()
    lv.get_file_content = Mock(side_effect=["The files content", "", "motherboard"])
    lv.get_file_lines = Mock(return_value=["machine.*CHRP IBM pSeries .emulated by qemu."])
    lv.module.get_bin_path = Mock(return_value="/bin/dmidecode")
    lv.module.run_command = Mock(return_value=(0, "some text", ""))

    # The method under testing with mock data
    assert lv.get_virtual

# Generated at 2022-06-23 02:14:40.097883
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = {}
        def fail_json(self, **args):
            self.exit_json = args
        def get_bin_path(self, *args, **kwargs):
            return "/bin/systemd-nspawn"

        def run_command(self, *args, **kwargs):
            return 0, "", ""

    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = {}
        def fail_json(self, **args):
            self.exit_json = args
            raise Exception("exit json invoked")

# Generated at 2022-06-23 02:14:46.954344
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    class MockModule(object):
        @staticmethod
        def run_command(arg):
            return 0, '', ''

        @staticmethod
        def get_bin_path(arg):
            return None

    mock_module = MockModule()
    vm = LinuxVirtual(module=mock_module)
    host_tech = {
        'docker', 'kvm', 'xen'
    }
    guest_tech = {
        'qemu',
    }

# Generated at 2022-06-23 02:14:56.305126
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class LinuxVirtual.
    """
    module = Mock()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value="/usr/bin/dmidecode")

    mock_module = Mock()
    mock_module.params = {}
    mock_module.run_command = module.run_command
    mock_module.get_bin_path = module.get_bin_path

    mock_module.get_bin_path.return_value = True

    # Bug/Feature? dmidecode returns non-zero rc, but no output
    mock_module.run_command.return_value = (1, '', '')

    ldv = LinuxVirtual(mock_module)


# Generated at 2022-06-23 02:15:03.536059
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """This is a unit test for LinuxVirtual"""
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)
    has_data = False
    facts = lv.gather_facts()
    assert isinstance(facts, dict), 'Facts is not a dictionary'
    for key in [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host'
    ]:
        assert key in facts, 'Facts does not contain key %s' % key
        has_data = True
    assert has_data, 'Did not get any data from facts'

# Generated at 2022-06-23 02:15:10.472343
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    module.exit_json = exit_json
    module.fail_json = fail_json
    obj = LinuxVirtual(module)
    result = obj.get_virtual_facts()
    keys = result.keys()
    for key in ['virtualization_type', 'virtualization_role', 'virtualization_system']:
        assert key in keys

    module = AnsibleModule({})
    module.exit_json = exit_json
    module.fail_json = fail_json
    obj = LinuxVirtual(module)
    result = obj.get_virtual_facts()
    keys = result.keys()
    for key in ['virtualization_type', 'virtualization_role', 'virtualization_system']:
        assert key in keys


# Generated at 2022-06-23 02:15:15.047126
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Create an object of LinuxVirtual and checks that the object was correctly filled"""
    module = AnsibleModule({}, {}, warn_list=[])
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual.os_identifier == 'Linux'



# Generated at 2022-06-23 02:15:19.365822
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    class Args:
        def __init__(self):
            self.facts_type = None
    args = Args()
    virtual_collector = LinuxVirtualCollector(args)
    assert virtual_collector._fact_class is not None
    assert virtual_collector._platform == 'Linux'

# Generated at 2022-06-23 02:15:26.669115
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    testobj = LinuxVirtual()
    testobj.module.run_command = MagicMock(return_value=(0, 'fake', ''))
    testobj.module.get_bin_path = MagicMock(return_value=None)
    testobj.get_virtual_facts()
    #assert(testobj.module.run_command.called)
    #assert(testobj.module.get_bin_path.called)


# Generated at 2022-06-23 02:15:37.931774
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.virtual.linux import LinuxVirtualCollector
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.virtual.base import VirtualCollector
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.virtual.linux import LinuxVirtual
    import unittest
    import ansible.module_utils.basic
    import ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.virtual.linux

    class TestFactsLinux(unittest.TestCase):
        """
        Test class for LinuxVirtualCollector
        """

# Generated at 2022-06-23 02:15:41.104684
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector(), VirtualCollector)


# Generated at 2022-06-23 02:15:43.923189
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual
    assert collector._fact_class == LinuxVirtual
    assert collector._platform == 'Linux'

# Generated at 2022-06-23 02:15:51.707239
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    path_exists_map = {
        '/sys/devices/virtual/dmi/id/sys_vendor': False,
        '/sys/devices/virtual/dmi/id/product_name': False,
        '/sys/devices/virtual/dmi/id/bios_vendor': False,
        '/sys/devices/virtual/dmi/id/product_family': False,
        '/proc/cpuinfo': False,
        '/proc/xen/capabilities': False,
        '/proc/vz': False,
        '/proc/lve': False,
        '/proc/self/status': False,
        '/proc/modules': False,
        '/.dockerenv': False,
        '/.dockerinit': False,
        '/run/systemd/container': False,
        }

    get_file_content_map

# Generated at 2022-06-23 02:15:58.734508
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Create a LinuxVirtualCollector object.
    virtual_collector = LinuxVirtualCollector()
    # Check type of object.
    assert isinstance(virtual_collector, VirtualCollector)
    # Check type of variable
    assert isinstance(virtual_collector._fact_class, type)
    # Check type of variable
    assert isinstance(virtual_collector._platform, str)
    # Check value of variable
    assert virtual_collector._platform == 'Linux', 'Test Failed'


# Generated at 2022-06-23 02:16:04.203740
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual(module=DummyModule())
    facts = lv.get_virtual_facts()
    assert facts == {
        'virtualization_type': 'na',
        'virtualization_role': 'na',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([])
    }

# Generated at 2022-06-23 02:16:09.957662
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    facts = LinuxVirtual.get_virtual_facts(None)
    assert facts['virtualization_type'] == 'NA'
    assert facts['virtualization_role'] == 'NA'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()


# =================================
# RedHatVirtual Support
# =================================

# Generated at 2022-06-23 02:16:11.735623
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    platform_virtual = LinuxVirtual()
    assert platform_virtual.get_virtual_facts


# Generated at 2022-06-23 02:16:13.807419
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector.__doc__ is not None


# Generated at 2022-06-23 02:16:25.129846
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Test for the get_virtual_facts method of the LinuxVirtual class."""
    class ModuleMock(object):
        """Class of the mock module."""
        params = {}
        def get_bin_path(self, name):
            """Fake get_bin_path method."""
            if name == 'dmidecode':
                return '/sbin/dmidecode'
            elif name == 'lscpu':
                return '/sbin/lscpu'
            return None
        def run_command(self, cmd):
            """Fake run_command method."""

# Generated at 2022-06-23 02:16:33.692334
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test module initialization
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    def get_file_content(filename):
        if(filename == "/proc/modules" and "virtio" in open(filename).read()):
            return True
        return False
    module.get_file_content = get_file_content
    module.get_bin_path = lambda x: '/bin/'+x
    module.run_command = lambda x: (0, "", "")
    module.check_mode=False

    # Test get_file_content

# Generated at 2022-06-23 02:16:41.265782
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    res = lv.populate()
    assert_equal(res['virtualization_type'], 'NA')
    assert_equal(res['virtualization_role'], 'NA')
    assert_equal(res['virtualization_tech_guest'], set(['NA']))
    assert_equal(res['virtualization_tech_host'], set(['NA']))

if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-23 02:16:42.947280
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert issubclass(LinuxVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:16:47.559185
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Constructor of class LinuxVirtual:
    """
    module = AnsibleModule(
        argument_spec = dict()
    )
    linux_virtual = LinuxVirtual(module)
    out = linux_virtual.get_virtual_facts()
    module.exit_json(ansible_facts=out)


# Generated at 2022-06-23 02:16:57.342750
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''This function is used to test the constructor of class LinuxVirtual'''

    mock = LinuxVirtualMock()
    assert mock.get_virtual_facts() == {'virtualization_role': u'host', 'virtualization_type': u'kvm',
                                        'virtualization_tech_guest': {'kvm', 'container'}, 'virtualization_tech_host': {'kvm', 'container'}}
    mock = LinuxVirtualMock()
    mock.kernel_modules_virt.add('vboxdrv')
    assert mock.get_virtual_facts() == {'virtualization_role': u'host', 'virtualization_type': u'virtualbox',
                                        'virtualization_tech_guest': {'virtualbox'}, 'virtualization_tech_host': {'virtualbox'}}
    mock = LinuxVirtualMock()

# Generated at 2022-06-23 02:17:08.650698
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test function get_virtual_facts of class LinuxVirtual
    """
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-locals
    # pylint: disable=protected-access
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['all'], type='list'),
            'filter': dict(default='*', type='list')
        },
        supports_check_mode=False)
    f_get_virtual_facts = LinuxVirtual._get_virtual_facts
    # mock module methods
    setattr(module, 'get_bin_path', lambda x: '/usr/bin/%s' % x)

    # Initialize AnsibleModule test

# Generated at 2022-06-23 02:17:17.209322
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    this_module = AnsibleModule(
        argument_spec = dict(
            filter=dict(default='*', choices=['*']),
        ),
        supports_check_mode=True
    )

    virtual_facts = dict()
    LinuxVirtual(this_module).get_virtual_facts(virtual_facts)

    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'] in ['guest', 'host', 'NA']
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-23 02:17:22.349830
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Testing the constructor of class LinuxVirtual
    """
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    virtual_facts = lv.populate()

    assert virtual_facts['virtualization_role'] in ['host', 'guest']


# Generated at 2022-06-23 02:17:31.009009
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hosts = [
        'localhost',
        '127.0.0.1'
    ]
    current_user = getpass.getuser()
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    if module.check_mode:
        module.exit_json(changed=False)
    for host in hosts:
        for key, value in virtual_facts.items():
            assert type(virtual_facts[key]) == type(value)


# Generated at 2022-06-23 02:17:33.418534
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert isinstance(lv, LinuxVirtual)


# Generated at 2022-06-23 02:17:39.251250
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert issubclass(LinuxVirtualCollector, VirtualCollector)
    assert LinuxVirtualCollector._fact_class == LinuxVirtual
    assert LinuxVirtualCollector._platform == 'Linux'

# Generated at 2022-06-23 02:17:42.991741
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector(Collector)
    assert x.platform == 'Linux'


# Generated at 2022-06-23 02:17:49.417771
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    lv = LinuxVirtual(module)
    p = lv.get_virtual_facts()
    for k, v in p.items():
        print(k, v)

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:17:57.845516
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Assert that VirtualCollector is superclass of LinuxVirtualCollector
    assert issubclass(LinuxVirtualCollector, VirtualCollector)
    # Assert that LinuxVirtualCollector is a class
    assert isinstance(LinuxVirtualCollector, type)
    # Assert that LinuxVirtualCollector has the right platform
    assert LinuxVirtualCollector._platform == 'Linux'
    # Assert that LinuxVirtualCollector has the right class for fact
    assert LinuxVirtualCollector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:01.114190
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    linux_virtual = LinuxVirtual(module)
    # FIXME: add unit test for linux_virtual
    pass


# Generated at 2022-06-23 02:18:03.574137
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtualCollector()
    assert facts.platform == 'Linux'
    assert facts._fact_class is LinuxVirtual



# Generated at 2022-06-23 02:18:09.997241
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    virtual = LinuxVirtual(module)
    assert virtual.get_virtual_facts()['virtualization_type'] == 'NA'
    assert virtual.get_virtual_facts()['virtualization_role'] == 'NA'

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:18:18.457222
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    sys_mock = MagicMock()
    sys_mock.platform = 'linux'
    sys_mock.version_info = MagicMock(return_value=(2, 6, 31))
    sys_mock.hexversion = 36718208
    sys_mock.byteorder = 'big'
    sys_mock.maxsize = 9223372036854775807
    sys_mock.maxunicode = 1114111
    sys_mock.builtin_module_names = ('posix', 'nt', 'ntpath', 'genericpath', 'stat', '_stat', 'abc', '_abc', '_xyz', 'nt', 'errno', '_winapi')

# Generated at 2022-06-23 02:18:27.859908
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''linux_virtual.py: LinuxVirtual.__init__
    '''


    # create object of class LinuxVirtual
    obj = LinuxVirtual()

    # check attributes
    assert(obj.module.params == {})
    assert(obj.module.get_bin_path.__code__.co_varnames == ('self', 'filename', 'default', 'opt_dirs'))
    assert(obj.module.run_command.__code__.co_varnames == ('self', 'args', 'check_rc', 'close_fds', 'binary_data', 'path_prefix', 'cwd', 'use_unsafe_shell', 'prompt'))
    assert(obj.module.check_mode.__code__.co_varnames == ('self',))

# Generated at 2022-06-23 02:18:30.456343
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector.fact_class == LinuxVirtual
    assert linux_virtual_collector._platform == "Linux"

# Generated at 2022-06-23 02:18:44.019068
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    #initialize the module object
    module = AnsibleModule(
        argument_spec = dict(),
    )
    #initialize the class object
    linux_virtual = LinuxVirtual()
    result = linux_virtual.get_virtual_facts(module)

# Generated at 2022-06-23 02:18:55.313717
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # From here we retrieve our test data
    source = inspect.getsource(LinuxVirtual)
    lines = source.split("\n")

    test_pairs = []
    test_dict = {}
    for line in lines[:lines.index("# Unit test for method get_virtual_facts of class LinuxVirtual")-1]:
        if line.startswith("    def test_"):
            test_name = line.split(" ")[1].strip("():")
        elif line.startswith("        virtual_facts"):
            test_pairs.append(line.strip("        virtual_facts = ").strip("{}").split("="))

# Generated at 2022-06-23 02:19:04.631457
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Return the virtualization facts"""
    module = Mock()
    module.run_command.return_value = (0, "", "")
    module.get_bin_path.return_value = "/bin/dmidecode"
    linux_virtual = LinuxVirtual(module=module)
    actual_result = linux_virtual.get_virtual_facts()
    expected_result = {
        'virtualization_type': 'NA',
        'virtualization_role': 'NA',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }
    assert actual_result == expected_result


# Generated at 2022-06-23 02:19:14.892055
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module=module)

    # test if virtual_facts is a dict
    assert isinstance(lv.get_virtual_facts(), dict)

    # test if virtual_facts is not empty and contains 'virtualization_type'
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts != {}
    assert 'virtualization_type' in virtual_facts

    # test 'virtualization_type' is a string
    assert isinstance(virtual_facts['virtualization_type'], str)

    # test 'virtualization_role' is either 'guest' or 'host'
    assert virtual_facts['virtualization_role'] in ('guest', 'host')


# Generated at 2022-06-23 02:19:17.246514
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linuxVirtualCollector = LinuxVirtualCollector()
    assert linuxVirtualCollector.__class__.__name__ == 'LinuxVirtualCollector'

# Generated at 2022-06-23 02:19:21.575521
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    m = LinuxVirtualCollector()
    assert m._platform == 'Linux'
    assert isinstance(m, VirtualCollector)
    assert isinstance(m._fact_class(), Virtual)
    assert isinstance(m._fact_class(), LinuxVirtual)


# Generated at 2022-06-23 02:19:32.537275
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    host = Virtual()
    virtual_facts = host.get_virtual_facts()
    assert True == type(virtual_facts) is dict
    assert True == type(virtual_facts['virtualization_tech_guest']) is set
    assert True == type(virtual_facts['virtualization_tech_host']) is set
    assert True == type(virtual_facts['virtualization_role']) is str
    assert True == type(virtual_facts['virtualization_type']) is str

# Generated at 2022-06-23 02:19:35.034633
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Run tests for class LinuxVirtual
    linuxvirtual = LinuxVirtual()
    virtual_facts = linuxvirtual.get_virtual_facts()
    assert len(virtual_facts) > 0, "virtual_facts is empty"

# Unit tests for function get_file_lines

# Generated at 2022-06-23 02:19:43.881330
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # This method will be called with no arguments so we need a way to pass
    # all the needed parameters. Further more, we want to be able to test
    # the code with different parameters set.
    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
        by the test case"""
        pass

    class ModuleMock(object):
        """Mock class to replicate AnsibleModule"""
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            """Mock method to store results"""

# Generated at 2022-06-23 02:19:47.071339
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the constructor of the LinuxVirtual class.
    """
    module = AnsibleModule(argument_spec={})
    is_virt = LinuxVirtual(module)
    assert is_virt.is_virtual()

# Generated at 2022-06-23 02:19:58.179264
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test using mocked module and arguments
    def mock_get_file_lines(filename):
        if filename == "/sys/hypervisor/uuid":
            return []
        elif filename == "/proc/cpuinfo":
            return ["vendor_id       : User Mode Linux"]
        elif filename == "/sys/devices/virtual/dmi/id/sys_vendor":
            return ["Amazon EC2"]
        elif filename == "/proc/modules":
            return ["kvm"]
        elif filename == "/sys/devices/virtual/dmi/id/bios_vendor":
            return ["Xen"]
        elif filename == "/sys/devices/virtual/dmi/id/product_name":
            return ["OpenStack Compute"]

# Generated at 2022-06-23 02:20:07.864432
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    print('Checking method get_virtual_facts of class LinuxVirtual')
    test = LinuxVirtual(module)
    print('Testing support for xemu docker based virtualization')
    test.virtual_facts = dict()
    os.environ["PATH"] += ':/usr/sbin'
    test.module.set_command(('which', '/usr/sbin/vzctl'), (0, '', ''))
    test.module.set_command(('which', '/usr/bin/systemd-detect-virt'), (0, '', ''))
    test.module.set_command(('which', '/usr/bin/lxc-info'), (0, '', ''))
    test.module.set_command(('which', '/usr/bin/podman'), (0, '', ''))

# Generated at 2022-06-23 02:20:14.433103
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Constructor test for LinuxVirtual class

    :return:
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Create an instance of the LinuxVirtual class
    lv = LinuxVirtual(module=module)
    # Check if the platform_subclass property of the instance is set to LinuxVirtual
    assert lv.platform_subclass == LinuxVirtual


# Generated at 2022-06-23 02:20:22.628642
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.module.get_bin_path = MagicMock(return_value="/bin/dmidecode")
    lv.module.run_command = MagicMock(return_value=(0, "BHYVE", ""))
    assert lv.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'bhyve', 'virtualization_tech_guest': {'bhyve'}, 'virtualization_tech_host': set()}
    del lv


# Generated at 2022-06-23 02:20:29.517480
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector.__doc__ is not None
    assert LinuxVirtualCollector.collect.__doc__ is not None
    assert LinuxVirtualCollector.get_virtual_facts.__doc__ is not None
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual
    x = LinuxVirtualCollector()
    assert isinstance(x, VirtualCollector)
    assert isinstance(x, LinuxVirtualCollector)


# Generated at 2022-06-23 02:20:36.125011
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    module = FakeModule()
    src = "tests/fixtures/data/{0}".format(module.params['src'])
    module.params['path'] = src

    # set up
    test_LinuxVirtual_get_virtual_facts_obj = LinuxVirtual(module)

    return_value = test_LinuxVirtual_get_virtual_facts_obj.get_virtual_facts()



# Generated at 2022-06-23 02:20:46.018808
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    host_tech = set([])
    guest_tech = set([])
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'NA'
    virtual_facts['virtualization_role'] = 'NA'
    virtual_facts['virtualization_tech_host'] = host_tech
    virtual_facts['virtualization_tech_guest'] = guest_tech

    mod_args = dict()
    mod_args['module_setup'] = dict()
    mod_args['module_setup']['module_utils'] = dict()
    mod_args['module_setup']['module_utils']['basic'] = dict()
    mod_args['module_setup']['module_utils']['basic']['run_command'] = mock.MagicMock()

# Generated at 2022-06-23 02:20:47.844785
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual_obj = LinuxVirtual()

# Generated at 2022-06-23 02:20:51.012244
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virt_class = LinuxVirtualCollector()
    assert virt_class._platform == 'Linux'
    assert isinstance(virt_class._fact_class(None), LinuxVirtual)



# Generated at 2022-06-23 02:20:55.516739
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    facts = linux_virtual.get_virtual_facts()
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:21:06.369725
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    import platform
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest, mock

    class AnsibleModule:
        def __init__(self, params={}):
            self.params = params

        def exit_json(self, result={}):
            return result

    class TestLinuxVirtual(unittest.TestCase):
        def test_host_facts(self):
            with mock.patch.object(platform,
                                   'dist',
                                   return_value=('redhat', '7.3', 'Maipo')):
                module = AnsibleModule()
                lxvirt = LinuxVirtual(module)
                result = lxvirt.get_facts()
                self.assertIn('virtualization_role', result)

# Generated at 2022-06-23 02:21:11.654061
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Test with empty module
    module = AnsibleModule(
        argument_spec = dict(),
    )

    # Test with constructor
    lv = LinuxVirtual(module)

    # Assertion: Test that module is initialized
    assert module == lv.module


# Generated at 2022-06-23 02:21:17.906549
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Constructor of class LinuxVirtualCollector
    """
    # Seed the module_utils/facts/virtual.py module_run_command variable.
    module_run_command('/usr/bin/which lscpu')
    virtual_collector = LinuxVirtualCollector()
    assert virtual_collector.platform == 'Linux'
    assert virtual_collector.fact_class.__name__ == 'LinuxVirtual'
    assert virtual_collector.fact_class._platform == 'Linux'


# Generated at 2022-06-23 02:21:19.570392
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vm = LinuxVirtualCollector()
    assert vm not in (None, {}, [])


# Generated at 2022-06-23 02:21:21.646688
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linuxvirtual = LinuxVirtual()
    assert len(linuxvirtual.virtual_facts) > 0


# Generated at 2022-06-23 02:21:26.762198
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module_mock = MagicMock(os=FakeLinuxModule)
    lvc = LinuxVirtualCollector(module_mock)
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual
    assert lvc._module == module_mock



# Generated at 2022-06-23 02:21:37.493566
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    from ansible.module_utils.facts.module_lldp import module_lldp
    from ansible.module_utils.facts.sysctl import sysctl
    from ansible.module_utils.facts.system_files import system_files
    from ansible.module_utils.facts.virtual.openbsd_virtual import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.netbsd_virtual import NetBSDVirtual
    from ansible.module_utils.facts.virtual.freebsd_virtual import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.sunos_virtual import SunOSVirtual
    from ansible.module_utils.facts.virtual.smartos_virtual import SmartOSVirtual

# Generated at 2022-06-23 02:21:45.979949
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    linux_virtual = LinuxVirtual(module)

    module.run_command = MagicMock(return_value=(0, 'Intel Xeon', ''))
    # run_command is called with 'lscpu'
    result = linux_virtual.get_virtual_facts()
    module.run_command.assert_called_once_with('lscpu')
    assert result == {'virtualization_role': 'NA', 'virtualization_type': 'NA'}

# Generated at 2022-06-23 02:21:57.875793
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    lv = LinuxVirtual(module)

    # First test with a guest virtual machine
    virtual_facts_dict = dict(
        virtualization_type = 'kvm',
        virtualization_role = 'guest',
        virtualization_tech_guest = set(['kvm']),
        virtualization_tech_host = set([])
    )
    virtual_facts = lv.get_virtual_facts()
    assert virtual_facts == virtual_facts_dict, 'virtual_facts has unexpected output. Actual output: {}'.format(virtual_facts)
    assert lv.found_virt == True

    # Second test with a host virtual machine

# Generated at 2022-06-23 02:22:00.880813
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual({})
    expected = 'LinuxVirtual'
    actual = linux_virtual.__class__.__name__
    assert expected == actual, "Expected %s, got %s" % (expected, actual)


# Generated at 2022-06-23 02:22:03.421369
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    linux_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:22:06.024553
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    test_class = LinuxVirtualCollector()
    assert test_class.platform == 'Linux'
    assert test_class.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:22:13.369182
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    print(vars(linux_virtual))
    # linux_virtual.module =
    # linux_virtual.module.run_command =
    linux_virtual.get_virtual_facts()

if '/usr/lib/python2.7/unittest/main.py' == __file__:
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:22:23.785904
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    ansible_module = AnsibleModule({
        'module_setup': {},
    })
    machine = FakeMachine()
    fake_module = FakeModule()
    fake_module.get_bin_path.return_value = '/bin/dmidecode'
    fake_module.run_command.return_value = (0, 'VMware', '')
    machine.module = fake_module
    machine.module.params = {
        'gather_subset': [],
        'filter': [],
    }
    virtual_facts = machine.get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == 'VMware'
    assert virtual_facts.get('virtualization_role') == 'guest'

# Generated at 2022-06-23 02:22:27.473077
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)

    expected_facts = {'virtualization_role': 'guest', 'virtualization_type': 'uml', 'virtualization_tech_guest': {'uml'}, 'virtualization_tech_host': {}}
    assert expected_facts == lv.collect_virtual_facts()

# Generated at 2022-06-23 02:22:33.882952
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    ''' unit tests for LinuxVirtual'''

    # test LinuxVirtual object creation
    hypervisor = LinuxVirtual()

    # test LinuxVirtual object get_virtual_facts
    virtual_facts = hypervisor.get_virtual_facts()

    for keys in ('virtualization_type', 'virtualization_role'):
        assert keys in virtual_facts

    for keys in ('virtualization_tech_guest', 'virtualization_tech_host'):
        assert keys in virtual_facts


# Generated at 2022-06-23 02:22:43.841975
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # set up mock objects
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='')

    lv = LinuxVirtual(module)

    # Case 1:
    # virtualization_type = docker
    # virtualization_role = guest
    # virtualization_tech_guest = set(['docker', 'container'])
    # virtualization_tech_host = set()
    # /proc/1/cgroup
    #   11:perf_event:/docker/e9eb722fc56a2dd9940fd8b1fb53f7ac207ce57d14c7202cf652c69cecdb7111

# Generated at 2022-06-23 02:22:45.020361
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    v_c = LinuxVirtualCollector()
    assert v_c is not None


# Generated at 2022-06-23 02:22:50.302254
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Return LinuxVirtual object and its instance variable
    """
    linux_virtual_obj = LinuxVirtual({})

    # Test method get_virtual_facts()
    # If it returns expected results, test_LinuxVirtual() returns True
    return isinstance(linux_virtual_obj, LinuxVirtual) and \
           hasattr(linux_virtual_obj, 'module') and \
           isinstance(linux_virtual_obj.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:22:51.886290
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual(None)
    assert linux_virtual.facts_module is None


# Generated at 2022-06-23 02:23:02.935251
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # pylint: disable=too-many-statements
    import platform
    import psutil
    from ansible.module_utils.six import PY2
    module = AnsibleModule(argument_spec={})
    # Get platform information
    distro = platform.dist()
    machine = platform.machine()
    # Instantiate class
    linux_virtual = LinuxVirtual(module)

    # Test _get_file_content
    assert get_file_content('/proc/mounts') == linux_virtual._get_file_content('/proc/mounts'), \
        '_get_file_content didn\'t return expected result for /proc/mounts'

    # Test _get_file_lines

# Generated at 2022-06-23 02:23:06.322087
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    with pytest.raises(AnsibleError) as excinfo:
        LinuxVirtualCollector({}, {})
    assert 'module or facts parameter is required' in str(excinfo.value)



# Generated at 2022-06-23 02:23:11.406291
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    cp = LinuxVirtual(dict())
    assert cp.get_virtual_facts() == {'virtualization_type': 'NA',
                                      'virtualization_role': 'NA',
                                      'virtualization_tech_guest': set(),
                                      'virtualization_tech_host': set()}

# class LinuxService

# Generated at 2022-06-23 02:23:22.763086
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    linux_virtual = LinuxVirtual(test_module)
    assert linux_virtual.get_virtual_facts() == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest'
    }


# Generated at 2022-06-23 02:23:27.765427
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Performs basic unit tests for constructor of class LinuxVirtualCollector
    """
    # Creating object for class LinuxVirtualCollector
    obj = LinuxVirtualCollector()

    # Checking type and value of variable platform of object obj
    assert isinstance(obj._platform, str)
    assert obj._platform == 'Linux'
    # Checking type of variable fact_class of instance obj
    assert isinstance(obj._fact_class, LinuxVirtual)

# Generated at 2022-06-23 02:23:36.613921
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    #
    # TEST 1 for get_virtual_facts()
    # Expected output:
    #   - Found:
    #       - virtualization_type: "virtualbox"
    #       - virtualization_role: "host"
    #       - virtualization_tech_guest: set()
    #       - virtualization_tech_host: {'virtualbox'}
    #
    my_host_fact_dir = os.path.dirname(os.path.realpath(__file__))
    my_host_facts = os.path.join(my_host_fact_dir, 'files', 'host_facts.LinuxVirtual.test_1.json')

    with open(my_host_facts, 'r') as json_file:
        host_facts = json.load(json_file)

    linux_virtual = LinuxVirtual

# Generated at 2022-06-23 02:23:39.136145
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    lsmbios = LinuxVirtual(module)
    assert lsmbios is not None


# Generated at 2022-06-23 02:23:48.919080
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # define return values for mock_get_bin_path
    def mock_get_bin_path(*args, **kwargs):
        if args[0] in ('chroot', 'lscpu', 'dmidecode'):
            # mock binary is in /usr/bin
            return '/usr/bin/' + args[0]
        return None

    # define return values for mock_get_file_content