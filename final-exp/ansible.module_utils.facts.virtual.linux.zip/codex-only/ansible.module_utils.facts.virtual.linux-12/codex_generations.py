

# Generated at 2022-06-23 02:13:58.138342
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Create a temporary directory to store the virtual unit test file
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file to be used by the unit test
    fd, path = tempfile.mkstemp(prefix='virtual_linux_collector_unit_', dir=tmpdir)
    with os.fdopen(fd, 'w') as f:
        f.write('')

    # Create a module object to use in the unit test
    module = AnsibleModule(argument_spec=dict())

    # Create a LinuxVirtualCollector object from the module object
    v = LinuxVirtualCollector(module)

    # Check that the LinuxVirtualCollector object was successfully created
    assert v

    # Test the generator function
    v._fact_class.for_file(path)

    # Remove the temporary file and directory

# Generated at 2022-06-23 02:14:10.298228
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # ansible_facts is the dictionary that stores all the ansible facts collected
    ansible_facts = {}
    # This module_utils object will be used as the AnsibleModule object
    # in the constructor of LinuxVirtual
    module_args = {"ansible_facts": ansible_facts}
    module_obj = type('', (object,), module_args)()
    # Creating the instance of LinuxVirtual
    virt_obj = LinuxVirtual(module_obj)

    # Create a random string to be used in the assertions
    random_string = random_string_generator(size=6)
    # Fill the ansible_facts with the virtualization facts
    module_obj.ansible_facts = virt_obj.get_virtual_facts()
    # Asserting the ansible_facts are filled

# Generated at 2022-06-23 02:14:11.357658
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # To be written
    return None

# Generated at 2022-06-23 02:14:12.727290
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert True == True

# Generated at 2022-06-23 02:14:14.276333
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual(dict(module=dict(run_command=lambda *args, **kwargs: (0, '', ''))))
    assert isinstance(linux_virtual, LinuxVirtual)
    assert linux_virtual.module


# Generated at 2022-06-23 02:14:25.414614
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import types
    module = types.ModuleType('ansible.module_utils.facts')
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    module.get_file_content = get_file_content
    module.get_file_lines = get_file_lines
    module.get_mount_size = get_mount_size
    module.get_mount_size = get_mount_size
    module.get_file_content = get_file_content
    module.get_file_lines = get_file_lines

    class LinuxVirtual:
        def __init__(self, module):
            self.module = module
        def get_virtual_facts(self):
            return self._get_virtual_facts()
    return LinuxVirtual(module).get_virtual_facts()



# Generated at 2022-06-23 02:14:29.457880
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    fc = LinuxVirtualCollector()
    fc.collect()
    assert fc.facts['virtualization_type'] == 'NA'
    assert fc.facts['virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:14:31.830293
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    ls = LinuxVirtual(module)
    print(ls.get_virtual_facts())



# Generated at 2022-06-23 02:14:33.684343
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector()._fact, LinuxVirtual)

# Generated at 2022-06-23 02:14:38.569923
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path, required=False):
            return '/bin/%s' % path

    module = MockModule()
    module.run_command = lambda x: (0, '', '')
    lv = LinuxVirtual(module)
    assert lv.module == module


# Generated at 2022-06-23 02:14:41.016372
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    facts = LinuxVirtualCollector(module).get_facts()['ansible_virtual']
    assert isinstance(facts, dict)


# Generated at 2022-06-23 02:14:42.335333
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.platform == 'Linux'


# Generated at 2022-06-23 02:14:47.560930
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Test for valid parameters
    test_obj = LinuxVirtual(dict())
    assert test_obj.facts == dict()
    assert LinuxVirtual.platform == 'Linux'
    assert LinuxVirtual.distribution == None

    # Test with empty parameter
    test_obj = LinuxVirtual(dict())
    assert test_obj.facts == dict()
    assert LinuxVirtual.platform == 'Linux'
    assert LinuxVirtual.distribution == None

    # Test with invalid parameter
    test_obj = LinuxVirtual('hi')
    assert test_obj.facts == dict()
    assert LinuxVirtual.platform == 'Linux'
    assert LinuxVirtual.distribution == None


# Generated at 2022-06-23 02:14:51.388793
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Tests for the constructor of class LinuxVirtual

    # Testing class creation and exception raise
    linux_virtual_test = LinuxVirtual()
    assert linux_virtual_test
    with pytest.raises(AnsibleExitJson):
        linux_virtual_test.get_all()

# Generated at 2022-06-23 02:14:53.801651
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual(create_module())
    system_information = linux_virtual.collect()
    print(system_information)


# Generated at 2022-06-23 02:14:57.439588
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    mod = ansible_module_mock()
    vc = LinuxVirtualCollector(module=mod)
    assert vc
    assert vc.module == mod
    assert vc._platform == 'Linux'
    assert vc._fact_class == 'LinuxVirtual'

# Unit tests for constructor of class LinuxVirtual

# Generated at 2022-06-23 02:15:05.353040
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    if not HAS_PSUTIL:
        module.fail_json(msg='psutil is required for this module')
    virt_facts = LinuxVirtual(module).populate()
    keys = virt_facts.keys()
    keys.sort()

# Generated at 2022-06-23 02:15:15.545701
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = Mock(params={})
    collector = LinuxVirtualCollector(module=module)
    result = collector.collect()
    # Test if the result is a dict or not. Result should be a dict
    assert isinstance(result, dict)
    for key, value in result.items():
        # Test if the value associated with each key is a list or not.
        # Value should be a list
        assert isinstance(value, list)
        # Test if the value is empty or not. Values are list of
        # Virtual facts for a particular device. Value should not be
        # null
        assert value != []
        for element in value:
            # Test if the type of the element inside the value list
            # is a dict or not. Element should be a dict
            assert isinstance(element, dict)
            # Test if the keys are present in the

# Generated at 2022-06-23 02:15:27.039932
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  mc_result_get_virtual_facts = {'virtualization_role': 'guest', 'virtualization_tech_guest': frozenset({'kvm'}), 'virtualization_tech_host': frozenset({'kvm'})}
  module_mock = MagicMock()
  info_mock = MagicMock()
  filehandle_mock = MagicMock()
  filehandle_mock.read().splitlines.return_value = ['bhyve']
  filehandle_mock.read().splitlines().__iter__.return_value = ['bhyve']
  iter_return_values = []
  iter_return_values.append(['bhyve'])
  iter_return_values.append(['python-virtinst'])
  filehandle_mock.read().splitlines().__iter__

# Generated at 2022-06-23 02:15:33.015696
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    virtual = LinuxVirtual(module)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] != 'NA'
    assert virtual_facts['virtualization_role'] != 'NA'


# Generated at 2022-06-23 02:15:38.641533
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lxvirtual = LinuxVirtual()
    lxvirtual.module = MagicMock()

    with patch.object(lxvirtual, 'get_file_content', return_value='Dell'):
        lxvirtual.get_virtual_facts()
        lxvirtual.get_file_content.assert_called_with('/sys/devices/virtual/dmi/id/sys_vendor')


# Generated at 2022-06-23 02:15:43.416792
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    test_object = LinuxVirtual(None)
    assert test_object.module != None
    assert test_object.platform == 'Linux'
    assert test_object.get_file_content(__file__) != None
    assert test_object.get_file_lines(__file__) != None

# Generated at 2022-06-23 02:15:51.443049
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    linux_virtual = LinuxVirtual(module)
    (rc, out, err) = module.run_command("true")
    assert rc == 0
    assert not out
    assert not err
    virtual_facts = linux_virtual.get_virtual_facts()

    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts



# Generated at 2022-06-23 02:15:57.562779
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    my_obj = LinuxVirtualCollector()
    assert my_obj._fact_class == LinuxVirtual
    assert my_obj._platform == 'Linux'


if __name__ == '__main__':
    # Unit test for constructor of class LinuxVirtual
    my_obj = LinuxVirtual()

# Generated at 2022-06-23 02:15:59.769870
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    testmod = LinuxVirtual({})
    assert hasattr(testmod, 'get_virtual_facts')


# Generated at 2022-06-23 02:16:03.647290
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    linux_virtual_collector.collect()
    assert linux_virtual_collector.fact_class == LinuxVirtual
    assert linux_virtual_collector.platform == 'Linux'

# Generated at 2022-06-23 02:16:06.024211
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    lv = LinuxVirtual(module)
    assert lv is not None


# Generated at 2022-06-23 02:16:12.279194
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    a = LinuxVirtual()
    res = a.get_virtual_facts()
    assert res['virtualization_type'] == 'kvm'
    assert res['virtualization_role'] == 'guest'
    assert len(res['virtualization_tech_guest']) == 2
    assert len(res['virtualization_tech_host']) == 0
    assert 'kvm' in res['virtualization_tech_guest']

# Generated at 2022-06-23 02:16:16.008082
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert LinuxVirtual.get_virtual_facts(None, None) == {'virtualization_role': 'guest', 'virtualization_type': 'container', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'container'}}


# Generated at 2022-06-23 02:16:18.423312
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'


# Generated at 2022-06-23 02:16:20.419559
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lx_virtual = LinuxVirtual()
    print('LinuxVirtual: instance created')


# Generated at 2022-06-23 02:16:28.361353
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual(None, None)
    assert linux_virtual.get_virtual_facts() == {
        'virtualization_tech_host': set(['linux']),
        'virtualization_tech_guest': set(),
        'virtualization_type': 'NA',
        'virtualization_role': 'NA'
    }

# Generated at 2022-06-23 02:16:39.659477
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lxv = LinuxVirtual()

    # Test for /proc/self/cgroup

# Generated at 2022-06-23 02:16:45.888591
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual(None)
    actual = linux_virtual.get_virtual_facts()
    expected = {'virtualization_role': 'guest',
                'virtualization_type': 'virtualbox',
                'virtualization_tech_guest': 'virtualbox',
                'virtualization_tech_host': 'virtualbox'}
    assert actual == expected


# Generated at 2022-06-23 02:16:51.241123
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import LinuxVirtual
    import_module = AnsibleModule({},{}, [], [], [])
    linux_virtual = LinuxVirtual(import_module)
    result = linux_virtual.get_virtual_facts()
    if not isinstance(result, dict):
        raise AssertionError('Return type must be a dictionary')

# Generated at 2022-06-23 02:16:52.827784
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    x = LinuxVirtual()
    assert type(x.facts) is dict

# Generated at 2022-06-23 02:16:54.441960
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj._platform == 'Linux'
    assert obj._fact_class == LinuxVirtual

# Generated at 2022-06-23 02:17:02.120389
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    if not HAS_LIBVIRT:
        module.fail_json(msg="python-libvirt package is missing")
    if not HAS_PSUTIL:
        module.fail_json(msg="psutil package is missing")
    virtual = LinuxVirtual(module)
    virtual.detect_virtualization()
    (rc, out, err) = module.run_command('ip a')


# Generated at 2022-06-23 02:17:07.193511
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    if not HAS_PSUTIL:
        module.fail_json(msg=missing_required_lib('psutil'),
                         exception=PSUTIL_IMP_ERR)

    lv = LinuxVirtual(module)
    lv.get_virtual_facts()



# Generated at 2022-06-23 02:17:12.781103
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={'name': {'type': 'str', 'required': False}}, supports_check_mode=True)
    module.params = {'name': 'value'}
    linux_virtual = LinuxVirtual(module)
    result = linux_virtual.get_virtual_facts()
    module.exit_json(**result)


# Generated at 2022-06-23 02:17:14.674681
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert LinuxVirtual().get_virtual_facts() == {'virtualization_role': 'guest'}

# Generated at 2022-06-23 02:17:16.915436
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj.platform == 'Linux'
    assert obj.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:17:20.063726
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert inspect.isclass(LinuxVirtualCollector)
    assert isinstance(LinuxVirtualCollector, VirtualCollector)


# Generated at 2022-06-23 02:17:32.406871
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # hostname and fqdn are used to generate the output file name
    hostname = 'test'
    fqdn = 'test.example.com'

    # Create a random directory, used to store the output file
    with tempfile.TemporaryDirectory() as tempdir:
        output_dir = tempdir
        obj = LinuxVirtualCollector(hostname, fqdn, output_dir)
        assert obj._output_dir == output_dir

        # Verify the construction of output file name.  We want the file name to be
        # "test_test.example.com_LinuxVirtual.json", which is the output of
        # obj.output_file_name()
        file_name = obj.output_file_name()

# Generated at 2022-06-23 02:17:36.500206
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual_facts = LinuxVirtual().populate()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:17:42.611150
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'
    assert lvc._virtual_facts is not None
    assert lvc._virtual_facts == {'virtualization_tech_host': set([]),
                                  'virtualization_tech_guest': set([]),
                                  'virtualization_type': 'NA',
                                  'virtualization_role': 'NA'}


# Generated at 2022-06-23 02:17:45.426038
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Returns a LinuxVirtual object.
    """
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    return linux_virtual


# Generated at 2022-06-23 02:17:47.115958
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    lv.collect()


# Generated at 2022-06-23 02:17:55.015846
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    unit test for LinuxVirtual class constructor
    '''
    # pylint: disable=protected-access
    virtual = LinuxVirtual()
    if virtual._dist_name == 'Unknown' or \
       virtual._dist_version == 'Unknown' or \
       virtual._dist_version_string == 'Unknown':
        raise Exception('Failed to detect distro name, version and version_string')
    if virtual._fallback_pkg_mgr is None:
        raise Exception('Failed to detect fallback pkg mgr')
    if not isinstance(virtual._hostname, str):
        raise Exception('Failed to determine hostname')
    if not isinstance(virtual._kernel_version, str):
        raise Exception('Failed to determine kernel version')

# Generated at 2022-06-23 02:17:56.213721
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    sys_virt = LinuxVirtual(dict())
    if sys_virt == None:
        return False
    return True


# Generated at 2022-06-23 02:17:59.655904
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:08.893067
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    result_keys = [
        "virtualization_type",
        "virtualization_role",
        "virtualization_system",
        "virtualization_uuid",
        "virtualization_hypervisor",
        "virtualization_tech_guest",
        "virtualization_tech_host",
        "virtualization_numvcpus",
        "virtualization_numvcpus_onln",
        "virtualization_memsize",
        "virtualization_memavailable",
        ]

    # Call method to be tested
    virtual_facts = lv.get_virtual_facts()
    module.exit_json(changed=False, ansible_facts=dict(
        ansible_virtualization=virtual_facts))


# Generated at 2022-06-23 02:18:17.949611
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Unit test for constructor of class LinuxVirtual
    '''
    # Default constructor
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)

    # Test member variables
    if hasattr(module, 'params'):
        assert lv.module.params is not None
    if hasattr(module, 'run_command'):
        assert lv.module.run_command is not None
    if hasattr(module, 'fail_json'):
        assert lv.module.fail_json is not None
    if hasattr(module, 'exit_json'):
        assert lv.module.exit_json is not None
    if hasattr(module, 'get_bin_path'):
        assert lv.module.get_bin_path is not None



# Generated at 2022-06-23 02:18:24.538702
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    import platform
    module = AnsibleModule(argument_spec={})
    os_version = platform.dist()[1]
    linux_virtual = LinuxVirtual(module, os_version)
    # Test return data for Linux version
    assert linux_virtual.os_version == os_version
    # Test retrun data for module
    assert linux_virtual.module == module
    # Test return data for dmi_bin
    assert linux_virtual.dmi_bin == module.get_bin_path('dmidecode')



# Generated at 2022-06-23 02:18:29.602632
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    fact_collector = LinuxVirtualCollector(module)
    facts = fact_collector.collect(module, list())
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts


# Generated at 2022-06-23 02:18:37.805865
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    is_linux_virtual_instance = LinuxVirtual(module)
    assert is_linux_virtual_instance.virtual_subtype == 'virtual'


# Generated at 2022-06-23 02:18:40.870091
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:43.749390
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module=module)
    assert isinstance(linux_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:18:45.477370
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_collector = LinuxVirtualCollector(None)
    print("Virtualization Collector: %s" % virtual_collector)


if __name__ == '__main__':
    test_LinuxVirtualCollector()

# Generated at 2022-06-23 02:18:46.694799
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()


# Generated at 2022-06-23 02:18:54.755592
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    "Unit test for constructor of class LinuxVirtual"
    result = LinuxVirtual(None)

    expected_keys = [
        'virtualization_facts',
        'virtualization_role',
        'virtualization_role_list',
        'virtualization_type',
        'virtualization_type_list',
        'virtualization_tech_guest',
        'virtualization_tech_host'
    ]

    for key in expected_keys:
        assert key in result.get_virtual_facts()



# Generated at 2022-06-23 02:18:57.028498
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)
    assert lv

# Generated at 2022-06-23 02:19:03.305478
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import sys
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    lv = LinuxVirtual()
    if len(sys.argv) == 1 or sys.argv[1] == "get_virtual_facts":
        virtual_facts = lv.get_virtual_facts()
        pprint(virtual_facts)


# Generated at 2022-06-23 02:19:13.605310
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """LinuxVirtual - constructor test"""

    # Constructor without arguments
    linux_virtual_ins = LinuxVirtual()

    # Constructor with arguments
    module_ins = object
    linux_virtual_ins_with_args = LinuxVirtual(module_ins)

    # When:
    #    module_ins.params['gather_subset'] is undefined
    # Then:
    #    linux_virtual_ins_with_args.subset is defined and is equal to
    #    default value of linux_virtual_ins.subset
    assert linux_virtual_ins_with_args.subset == linux_virtual_ins.subset

    # When:
    #    module_ins.params['gather_subset'] is defined
    # Then:
    #    linux_virtual_ins_with_args.subset is defined and is equal to


# Generated at 2022-06-23 02:19:18.286199
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    lv_facts = lv.collect()
    module.exit_json(ansible_facts=lv_facts)

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:19:22.908530
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test the constructor of class LinuxVirtualCollector,
    which is invoked by the Ansible module, setup.py.
    """
    test_module = AnsibleModule(argument_spec=dict())
    lxc_collector = LinuxVirtualCollector(test_module)
    assert isinstance(lxc_collector, LinuxVirtualCollector)



# Generated at 2022-06-23 02:19:24.587743
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    vm = LinuxVirtual()
    assert vm is not None


# Generated at 2022-06-23 02:19:35.192411
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Mock module for testing
    class TestModule(object):
        def get_bin_path(self, name):
            if name == 'systemctl':
                return '/bin/systemctl'
            if name == 'lscpu':
                return '/bin/lscpu'
            if name == 'dmidecode':
                return '/bin/dmidecode'
            return None
        def run_command(self, cmd):
            if cmd == ['systemctl', 'is-system-running']:
                return (0, 'running', '')
            if cmd == ['lscpu']:
                return (0, 'Hypervisor: foo', '')
            if cmd == ['/bin/dmidecode', '-s', 'system-product-name']:
                return (0, '# foo', '')

# Generated at 2022-06-23 02:19:41.993752
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test for method get_virtual_facts
    """
    # mock module for testing
    class MockModule():
        def __init__(self):
            self.params = {}
            self.run_command = lambda x, **kwargs: (0, '', '')
            self.get_bin_path = lambda x: "/bin/%s" % x
    module = MockModule()
    module.params = {'gather_subset': 'all'}

    # run test
    LinuxVirtual(module).get_virtual_facts()
    assert module.exit_json.called == 0

# Generated at 2022-06-23 02:19:53.723968
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, 'sys'))
    os.mkdir(os.path.join(temp_dir, 'proc'))
    os.mkdir(os.path.join(temp_dir, 'sys', 'devices'))
    os.mkdir(os.path.join(temp_dir, 'sys', 'devices', 'virtual'))
    os.mkdir(os.path.join(temp_dir, 'sys', 'devices', 'virtual', 'dmi'))
    os.mkdir(os.path.join(temp_dir, 'sys', 'devices', 'virtual', 'dmi', 'id'))

    # Write a file for testing

# Generated at 2022-06-23 02:19:55.884745
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    plat = LinuxVirtual(module)
    assert plat



# Generated at 2022-06-23 02:20:01.818568
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual = LinuxVirtual()
    assert virtual.primary_key_name() == "virtualization_type"
    assert virtual.primary_key().get("virtualization_type", "") == "NA"
    assert virtual.secondary_key_name() == "virtualization_role"
    assert virtual.secondary_key().get("virtualization_role", "") == "NA"
    assert virtual.key().get("virtualization_type", "") == "NA"
    assert virtual.key().get("virtualization_role", "") == "NA"

# Generated at 2022-06-23 02:20:04.274546
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Test if constructor works as expected
    '''

    linux_virtual = LinuxVirtual({})
    assert isinstance(linux_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:20:09.547899
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    cmd = LinuxVirtual()

    virtual_facts = {}
    virtual_facts['virtualization_role'] = 'host'
    virtual_facts['virtualization_type'] = 'KVM'
    virtual_facts['virtualization_tech_host'] = {'kvm'}
    virtual_facts['virtualization_tech_guest'] = set()

    ret = cmd._get_virtual_facts()

    assert ret == virtual_facts


# Generated at 2022-06-23 02:20:12.844178
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Constructor test:
    #     Create object with parameter 'module' set to None
    lv = LinuxVirtual(None)
    # Tests whether the object was constructed correctly
    assert (lv != None)


# Generated at 2022-06-23 02:20:14.279903
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()


# Generated at 2022-06-23 02:20:20.011903
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test for LinuxVirtual class
    """
    os_obj = LinuxVirtual()
    facts = os_obj.get_virtual_facts()
    assert facts['virtualization_type'] is not None
    if facts['virtualization_role'] is not None:
        assert facts['virtualization_role'] in ('host', 'guest')


# Generated at 2022-06-23 02:20:24.801177
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual.py
    ~~~~~~~~~~~~~~~~
        This is a testing function for LinuxVirtual constructor.
    """
    module = AnsibleModule(argument_spec=dict())
    lvirt = LinuxVirtual(module)
    module.exit_json(ansible_facts=dict(lvirt.get_virtual_facts()))


# Generated at 2022-06-23 02:20:37.370280
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    class MockModule(object):
        def __init__(self, bin_path=None):
            self.bin_path_value = bin_path
            self.exit_json_value = None

        def get_bin_path(self, executable):
            return self.bin_path_value

        def exit_json(self, **kwargs):
            self.exit_json_value = kwargs

        def run_command(self, cmd):
            if cmd[0] == 'lscpu':
                return 0, get_file_content('tests/unit/test_files/test_ovirt.txt'), None
            if cmd[0] == 'dmidecode':
                return 0, get_file_content('tests/unit/test_files/test_dmidecode.txt'), None

    # Test to make sure we get a module not

# Generated at 2022-06-23 02:20:52.588017
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    class MockModule():
        def __init__(self):
            self.name = 'test'
            self.params = {}
        def get_bin_path(self, executable):
            return "/bin/%s" % executable
        def run_command(self, cmd):
            if cmd[0] == "cat":
                return 0, "NA", ""
            if cmd[0] == "lscpu":
                return 0, "Hypervisor: KVM", ""
            if cmd[0] == "dmidecode":
                return 0, "BHYVE", ""
            if cmd[0] == "systemd-detect-virt":
                return 0, "VMware", ""
            return 0, "", ""
    module = MockModule()
    fact = LinuxVirtualCollector(module)
    assert fact.platform == 'Linux'



# Generated at 2022-06-23 02:20:54.969727
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector(None, None)
    assert collector._platform == 'Linux'
    assert collector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:21:03.715478
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Test get_virtual_facts module of class LinuxVirtual."""
    linux_virtual = LinuxVirtual()
    actual_output = linux_virtual.get_virtual_facts()
    assert actual_output.get('virtualization_role') == 'guest'
    assert actual_output.get('virtualization_type') == 'kvm'
    assert actual_output.get('virtualization_tech_guest') == set(['kvm', 'container'])
    assert actual_output.get('virtualization_tech_host') == set(['kvm'])

# Generated at 2022-06-23 02:21:08.107002
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Construct an object
    obj = LinuxVirtual()

    # The object should be an instance of LinuxVirtual
    assert isinstance(obj, LinuxVirtual)

    # The object should have class attributes of the right type
    assert obj.module is not None


# Generated at 2022-06-23 02:21:17.107570
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    # Setup the testcase
    lv_mock = LinuxVirtual(module)
    # Provide a side-effect to get_file_content function which returns
    # file contents when requested for a particular file.
    test_data = {}
    fh = open('/proc/cpuinfo')
    test_data['/proc/cpuinfo'] = fh.read()
    fh.close()
    fh = open('/sys/devices/system/clocksource/clocksource0/current_clocksource')
    test_data['/sys/devices/system/clocksource/clocksource0/current_clocksource'] = fh.read()
    fh.close()

# Generated at 2022-06-23 02:21:23.338850
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    import os
    virt_mock = LinuxVirtual(None)

    facts = virt_mock.get_virtual_facts()
    assert(facts)
    assert('virtualization_role' in facts)
    assert('virtualization_type' in facts)
    assert('virtualization_tech_guest' in facts)
    assert('virtualization_tech_host' in facts)

# Generated at 2022-06-23 02:21:25.462167
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert False, "Test Suite not implemented"


# Generated at 2022-06-23 02:21:27.294076
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    a = LinuxVirtualCollector()
    assert a._platform == 'Linux'
    asse

# Generated at 2022-06-23 02:21:29.359496
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert isinstance(linux_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:21:37.002520
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test LinuxVirtual.get_virtual_facts()
    module = AnsibleModule(argument_spec={'name': dict(required=True, type='str')})
    lv = LinuxVirtual(module)
    # method get_virtual_facts() returns a dict
    result = lv.get_virtual_facts()
    assert isinstance(result, dict)
    if sys.version_info[0] == 2:
        assert result['virtualization_type'] == 'physical'
    else:
        assert result['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:21:48.139817
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test get_virtual_facts() by overriding __init__ and get_file_content methods
    class Test_get_virtual_facts_LinuxVirtual(LinuxVirtual):
        def __init__(self):
            self.module = mock.Mock()
            self.module.run_command.side_effect = self.run_command
            self.module.get_bin_path.side_effect = self.get_bin_path
            self.distribution = Distribution()
            self.lsb_release = LsbInfo()
            self.lsb_release.id = None
            self.lsb_release.release = None
            self.lsb_release.distributor_id = None
            self.lsb_release.codename = None
            self.lsb_release.description = None

# Generated at 2022-06-23 02:21:52.570940
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxVirtualCollector(module=module)
    assert type(collector) is LinuxVirtualCollector
    assert collector._fact_class == LinuxVirtual
    assert collector._platform == 'Linux'


# Generated at 2022-06-23 02:22:01.927195
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    lg = LinuxVirtual(module)
    result = lg.get_all_facts()
    assert type(result) is dict, 'Result is not a dictionary.'
    assert result['virtualization_type'] in ['lpar', 'NA'], \
        'Virtualization type should be lpar or NA.'
    assert result['virtualization_role'] in ['host', 'guest', 'NA'], \
        'Virtualization role should be host, guest or NA.'
    assert type(result['virtualization_tech_guest']) is set, \
        'Virtualization technology guest set should be set.'
    assert type(result['virtualization_tech_host']) is set, \
        'Virtualization technology host set should be set.'


# Generated at 2022-06-23 02:22:04.538788
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    lvc = LinuxVirtualCollector(module)
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:22:09.090541
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mod = AnsibleModule({})
    l = LinuxVirtual(mod)
    facts = l.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts


# Generated at 2022-06-23 02:22:20.249931
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    host_tech = set()
    guest_tech = set()
    virtual_facts = dict()

    # Input parameters
    params = dict()
    params['module'] = dict()
    params['module']['get_bin_path'] = Mock(side_effect=['/usr/bin/lscpu', '/usr/sbin/dmidecode', None])
    params['module']['run_command'] = Mock(side_effect=[(0, 'RHEL', ''),(0, 's390', ''), (0, 'Hypervisor', ''), (0, 's390', '')])

    # Setup the return values.
    ret = dict()
    ret['name'] = 'vserver'
    ret['state'] = 'running'
    ret['type'] = 'lxc'

    # Setup the mocks.
    mock

# Generated at 2022-06-23 02:22:23.162368
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    vc = LinuxVirtualCollector(module)
    assert vc.platform == 'Linux'
    assert isinstance(vc.facts, LinuxVirtual)



# Generated at 2022-06-23 02:22:27.794986
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test for constructor of class LinuxVirtual
    """
    module = AnsibleModule(argument_spec={})

    # create a LinuxVirtual object
    linux_virtual = LinuxVirtual(module)

    # check if attributes are initialized correctly
    assert linux_virtual.module == module
    assert linux_virtual.distribution == 'NA'
    assert linux_virtual.distribution_version == 'NA'


# Generated at 2022-06-23 02:22:30.985407
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    fact_instance = LinuxVirtualCollector(module)
    fact_instance.populate()
    module.exit_json.assert_called_once()


# Generated at 2022-06-23 02:22:35.132000
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    result = LinuxVirtual().get_virtual_facts(test_module)
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result


# Generated at 2022-06-23 02:22:38.242173
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert isinstance(obj._fact_class, type(Virtual))
    assert obj._fact_class.__name__ == 'LinuxVirtual'
    assert obj._platform == 'Linux'


# Generated at 2022-06-23 02:22:42.463009
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtualCollector
    result = LinuxVirtualCollector()
    assert result.platform == 'Linux'

# Generated at 2022-06-23 02:22:51.731026
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    MOCK_MODULE_RETURN_VALUES = {
        'get_bin_path': '',
        'run_command': [
            {'rc': 0, 'stdout': (
                """
                vendor_id       : User Mode Linux
                model name      : UML
                """), 'stderr': ''}]
    }
    MOCK_MODULE = MagicMock()
    MOCK_MODULE.run_command = MagicMock(**MOCK_MODULE_RETURN_VALUES)
    MOCK_MODULE.get_bin_path = MagicMock(**MOCK_MODULE_RETURN_VALUES)
    # Mock the module import
    mocked_module = MagicMock()
    mocked_module.check_mode = False
    mocked_module.params = {}
    mocked_module.get_

# Generated at 2022-06-23 02:22:58.360712
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    linux_virtual = LinuxVirtual(module)
    # We do not know the state of the system we run on, so just test that
    # the method does *something*.
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-23 02:23:01.740417
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """pytest: disable=no-member"""
    # Test for the LinuxVirtual constructor
    # Input params:
    #   - module: sanitize_facts class instance
    # Returns:
    #   - LinuxVirtual class instance
    with pytest.raises(Exception) as excinfo:
        virtual = LinuxVirtual(None)
        assert excinfo.value == "Parameter 'module' is required"
    assert str(excinfo.value) == "Parameter 'module' is required"


# Generated at 2022-06-23 02:23:07.821992
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Test get_virtual_facts of LinuxVirtual class
    """
    # create a mock module
    module = AnsibleModule(
        argument_spec={}
    )
    # create a mock module
    params = {}
    # instantiate LinuxVirtual object
    module.params = params
    linuxvirtual = LinuxVirtual(module)

    # Parse virtualization related facts
    linuxvirtual.get_virtual_facts()


# Generated at 2022-06-23 02:23:19.612558
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    vf_1 = {'virtualization_type': 'openvz', 'virtualization_role': 'guest'}
    vf_2 = {'virtualization_type': 'xen', 'virtualization_role': 'host'}
    vf_3 = {'virtualization_type': 'virtualbox', 'virtualization_role': 'host'}
    vf_4 = {'virtualization_type': 'container', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'docker', 'lxc', 'openvz'}}
    vf_5 = {'virtualization_type': 'kvm', 'virtualization_role': 'host'}

    lv = LinuxVirtual()
    lv.os_release_info = {'name': 'CentOS'}


# Generated at 2022-06-23 02:23:30.285336
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    import platform, os
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual

    # Set platform to Linux
    platform.system = lambda: 'Linux'

    # Set os.uname() to return various tuple items
    os_uname_call_count = 0

    def mock_os_uname():
        nonlocal os_uname_call_count

        result = None

        if os_uname_call_count == 0:
            result = ('Linux', 'test.host.name', '3.10.0-123.el7.x86_64', '#1 SMP Mon Jun 30 12:09:22 UTC 2014', 'x86_64')

# Generated at 2022-06-23 02:23:34.812382
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    '''
    Test LinuxVirtualCollector constructor
    '''
    lvc = LinuxVirtualCollector()
    assert(lvc)
    assert(lvc._platform == 'Linux')
    assert(isinstance(lvc, LinuxVirtual))

# Generated at 2022-06-23 02:23:36.924194
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector(dict())
    assert isinstance(x, LinuxVirtualCollector)



# Generated at 2022-06-23 02:23:41.504526
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """ Unit test for constructor of class LinuxVirtual """
    import sys

    module = FakeModule()
    sys.modules[module.__name__] = module
    obj = LinuxVirtual()
    assert isinstance(obj, object) and isinstance(obj, LinuxVirtual)
    assert obj.module == module



# Generated at 2022-06-23 02:23:43.707599
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    instance = LinuxVirtual({})
    assert isinstance(instance.get_virtual_facts(), dict)