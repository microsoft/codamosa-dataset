

# Generated at 2022-06-23 02:13:58.041120
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    facts = LinuxVirtual(module).get_virtual_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts.keys()
    assert isinstance(facts['virtualization_type'], str)

# Generated at 2022-06-23 02:14:01.446627
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    virt_collector = LinuxVirtualCollector(module)
    assert virt_collector._fact_class == LinuxVirtual
    assert virt_collector._platform == 'Linux'

# Generated at 2022-06-23 02:14:12.684124
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    my_linux = LinuxVirtual()
    my_virtual_facts = my_linux.get_virtual_facts()
    assert my_virtual_facts['virtualization_type'] in ('virtualbox','docker','openvz','Xen','uml','virtualpc','unknown','kvm','vserver','hyperv','parallels','virtualpc','VMware','linuxvserver','openstack','innotekgmbh','oracle','NA','KubeVirt')
    assert my_virtual_facts['virtualization_role'] in ('guest','NA','host')

from ansible.module_utils.facts.virtual.base import Virtual, collect_subclasses

_all_subclasses = collect_subclasses(Virtual)


# Generated at 2022-06-23 02:14:18.204592
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """linux_virtual - constructor test"""

    module = AnsibleModule(argument_spec={})
    is_linux_virtual_instance = isinstance(LinuxVirtual(module), LinuxVirtual)
    module.exit_json(changed=False, ansible_facts=dict(is_linux_virtual_instance=is_linux_virtual_instance))


# Generated at 2022-06-23 02:14:20.642166
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual

# Generated at 2022-06-23 02:14:32.191259
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Arrange
    FACTS = dict()
    FACTS['ansible_virtualization_type'] = None
    FACTS['ansible_virtualization_role'] = None
    FACTS['ansible_virtualization_tech_guest'] = None
    FACTS['ansible_virtualization_tech_host'] = None
    module = Mock()
    module.get_bin_path = lambda x: None
    module.run_command = lambda x: (0, None, None)
    lv = LinuxVirtual(module=module)
    # Act

    lv.get_virtual_facts()

    # Assert
    assert FACTS['ansible_virtualization_type'] == 'NA'
    assert FACTS['ansible_virtualization_role'] == 'NA'

# Generated at 2022-06-23 02:14:36.683021
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    my_obj = LinuxVirtualCollector()
    my_linux_obj = LinuxVirtual()

    if my_obj._fact_class != my_linux_obj.__class__ or my_obj._platform != 'Linux':
        raise Exception("LinuxVirtualCollector() object creation has failed")


# Generated at 2022-06-23 02:14:37.795538
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj._platform == 'Linux'
    assert isinstance(obj._fact_class, object)



# Generated at 2022-06-23 02:14:41.149315
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtualCollector().collect()
    assert 'virtualization_role' in facts['virtualization']
    assert 'virtualization_type' in facts['virtualization']
    assert 'virtualization_tech_guest' in facts['virtualization']
    assert 'virtualization_tech_host' in facts['virtualization']

# Generated at 2022-06-23 02:14:50.065299
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from unittest import mock
    from ansible.module_utils.basic import AnsibleModule
    class MockArgs(object):
        pass
    module_args = MockArgs()
    module_args.become = False
    module_args.become_user = None
    module_args.check_mode = False
    module_args.diff = False
    module_args.gather_subset = '!all'
    module_args.gather_timeout = 10
    module_args.module = None
    module_args.no_log = True
    module_args.timeout = 10
    module_args.verbosity = 0


# Generated at 2022-06-23 02:14:55.386182
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_module = LinuxVirtual()
    # Testing for method get_virtual_facts with arguments:
    facts = virtual_module.get_virtual_facts()
    
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts


# Generated at 2022-06-23 02:14:59.416793
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    linux_virtual = LinuxVirtual(module)
    # test code here
    # assert linux_virtual.get_virtual_facts() == 'value'


# Generated at 2022-06-23 02:15:06.445160
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """get_virtual_facts function unit test"""
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module=module)
    virtual_facts = linux_virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-23 02:15:09.184702
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lx_virtual = LinuxVirtual(module)
    assert isinstance(lx_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:15:19.828044
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # This test case is to cover the usage of get_virtual_facts() of LinuxVirtual class
    # It will return the 'virtual_facts' as a dictionary.
    # If the system is virtual, virtual_facts will contain valid values and will be empty dictionary otherwise
    # In case of error, the virtual_facts dictionary will not be empty and will contain error message with key 'error'
    # And empty string otherwise

    import os
    import imp
    import json

    with open(os.path.join(os.path.dirname(__file__), 'ansible_module_facts.json'), 'r') as ansible_module_facts:
        ansible_facts = json.load(ansible_module_facts)


# Generated at 2022-06-23 02:15:26.581233
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create instance of class LinuxVirtual
    lv = LinuxVirtual(module)
    # Create the facts
    virtual_facts = lv.get_virtual_facts()
    # Create the results
    results = {}
    results['failed'] = False
    results['ansible_facts'] = {'virtual': virtual_facts}
    return results



# Generated at 2022-06-23 02:15:28.923835
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:15:31.873796
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual

# Generated at 2022-06-23 02:15:35.155224
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert isinstance(lvc, VirtualCollector)
    assert isinstance(lvc._fact_class, LinuxVirtual)
    assert lvc._platform == 'Linux'

# Generated at 2022-06-23 02:15:38.741654
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    o_linuxVirtual = LinuxVirtualCollector()
    assert type(o_linuxVirtual) == LinuxVirtualCollector
    assert o_linuxVirtual.platform == 'Linux'
    assert type(o_linuxVirtual._fact_class) == LinuxVirtual


# Generated at 2022-06-23 02:15:41.169731
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """ This function will unit test the constructor of the class LinuxVirtualCollector"""
    obj = LinuxVirtualCollector()
    assert obj._platform == "Linux"
    assert obj._fact_class == LinuxVirtual
    return



# Generated at 2022-06-23 02:15:49.557984
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    def test_case(virt_method, virt_type, virt_role, virt_tech_host, virt_tech_guest):
        lv = LinuxVirtual()
        lv.is_linux = True
        lv.use_lscpu = False
        lv.use_dmidecode = False
        lv.virt_what = virt_method
        lv.virt_cmd = ['echo', '|', 'tr', '--delete', ' ']

        if virt_method == 'lscpu':
            lv.use_lscpu = True
            lv.lscpu_path = '/usr/bin/lscpu'
            lv.lscpu_bin = '/usr/bin/lscpu'

        if virt_method == 'dmidecode':
            lv.use_dmidecode = True


# Generated at 2022-06-23 02:15:54.094642
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    # Avoid the fact cache
    module.params['gather_subset'] = ['!all']
    module.params['gather_timeout'] = 1
    linux_virtual = LinuxVirtual(module=module)
    facts = linux_virtual.populate()
    print(jsonify(facts))



# Generated at 2022-06-23 02:16:01.158431
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual

    module = MagicMock()
    linux_virtual = LinuxVirtual(module)
    linux_virtual.module.run_command.return_value = (0, '', '')

    assert linux_virtual.get_virtual_facts() == {'virtualization_role': None, 'virtualization_type': 'NA', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-23 02:16:12.899021
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # If we ever test this, re-enable the following.
    # Also, wrap in exception handlers.
    # os.chdir('/')
    # os.chroot('/tmp')
    os.environ['PATH'] = '/usr/local/sbin:/sbin:/bin:/usr/sbin:/usr/bin'

    loader = ansible.loader.AnsibleLoader(None, '', True)
    shared_loader = ansible.loader.AnsibleLoader(None, '', True)

# Generated at 2022-06-23 02:16:15.866485
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:16:26.659532
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class LinuxVirtual
    '''

    fact_data = LinuxVirtual()

    # failed to read /proc/1/cgroup
    def mocked__check_cgroup_root(self):  # pylint: disable=no-self-argument
        '''
        Mock method for testing
        '''
        return -1

    fact_data.__check_cgroup_root = mocked__check_cgroup_root
    result = fact_data.get_virtual_facts()
    assert result["virtualization_type"] == 'NA'
    assert result["virtualization_role"] == 'NA'

    # read /proc/1/cgroup but does not contain any valid info

# Generated at 2022-06-23 02:16:30.471420
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    my_obj = LinuxVirtualCollector()
    my_obj.collect()
    assert my_obj._fact_class == LinuxVirtual
    assert my_obj._platform == 'Linux'



# Generated at 2022-06-23 02:16:36.526061
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    ''' linux_virtual.py:LinuxVirtual.UnitTest '''
    module = AnsibleModule()
    lv = LinuxVirtual(module)
    module.exit_json(changed=False, ansible_facts=lv.get_virtual_facts())

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:16:46.985649
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test for constructor of class LinuxVirtual.
    """
    class UnitTestModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg):
            return '/usr/bin/' + arg
    params = {'gather_subset': ['all', '!network', '!custom']}
    module = UnitTestModule(params=params)
    linux_virtual = LinuxVirtual(module)
    expected_facts = {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    assert linux_virtual.facts == expected_facts
    assert linux_virtual.virtual_facts()


# Generated at 2022-06-23 02:16:50.205618
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    virtual_facts = LinuxVirtual(module)
    return virtual_facts.get_virtual_facts()

# =========================================
# Main control flow


# Generated at 2022-06-23 02:16:52.790556
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    assert lv



# Generated at 2022-06-23 02:17:00.411812
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # This method tests presence or absence of keys in virtual_facts dict.
    # If a key is present, it does not test its value.
    linux_virtual = LinuxVirtual()
    virtual_facts = linux_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:17:10.819119
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    data = {}
    (mock_module, mock_lin_virt) = mock_linux_virtual(data)
    expected = {'virtualization_role': 'guest',
                'virtualization_type': 'kvm',
                'virtualization_tech_host': set(),
                'virtualization_tech_guest': set(['kvm'])}

    with open('/proc/cpuinfo', 'w') as mock_cpuinfo:
        mock_cpuinfo.write('model name : QEMU Virtual CPU\n')
        mock_lin_virt.get_virtual_facts()
    assert expected == mock_module.params.get('virtual')
    os.unlink('/proc/cpuinfo')



# Generated at 2022-06-23 02:17:12.326832
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual = LinuxVirtual({})
    assert virtual is not None


# Generated at 2022-06-23 02:17:14.980364
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec=dict())
    my_obj = LinuxVirtualCollector(module)
    assert my_obj.platform == "Linux"



# Generated at 2022-06-23 02:17:17.126383
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lx = LinuxVirtual()
    lx.get_virtual_facts()

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:17:29.280010
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''Unit test for LinuxVirtual.get_virtual_facts'''
    import os
    import shutil
    import tempfile
    import stat
    import random

    def get_random_int():
        '''Get random int with 0..100 range'''
        return random.randint(0, 100)

    def get_random_path():
        '''Get a random path'''
        path_components = []
        for _ in range(get_random_int()):
            path_components.append(''.join(random.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(get_random_int())))
        return os.path.join(*path_components)

    def get_random_str():
        '''Get random string with alnum characters and max length of 1024'''


# Generated at 2022-06-23 02:17:32.406293
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    collector = LinuxVirtualCollector(module)
    assert isinstance(collector._fact, LinuxVirtual)

# Generated at 2022-06-23 02:17:35.751052
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    # call all internal functions
    for f in dir(lv):
        if f.startswith('_'):
            continue
        getattr(lv, f)()


# Generated at 2022-06-23 02:17:36.463016
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector()

# Generated at 2022-06-23 02:17:40.396940
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    testObject = LinuxVirtualCollector()
    assert testObject != None, "LinuxVirtualCollector object not created"
    assert testObject.fact_class == LinuxVirtual, "fact_class should be LinuxVirtual"
    assert testObject.platform == 'Linux', "platform should be Linux"



# Generated at 2022-06-23 02:17:42.187992
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    assert LinuxVirtual({}) is not None


# Generated at 2022-06-23 02:17:52.626543
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec = dict()
    )
    set_module_args(module)
    module.params = basic._load_params(module.params, module.args)

    # Mock the methods of the class that will be instantiated in the main method
    class MockLinuxVirtual_Run(object):
        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
            return (0, "", "")
        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return "/bin/" + arg
    class MockLinuxVirtual_File(object):
        def get_file_lines(file):
            return []
       

# Generated at 2022-06-23 02:17:55.240543
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector._fact_class == LinuxVirtual
    assert LinuxVirtualCollector._platform == 'Linux'


# Generated at 2022-06-23 02:17:57.855064
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linuxv = LinuxVirtual()
    result = {}
    result['virtualization_type'] = 'kvm'
    result['virtualization_role'] = 'guest'
    result['virtualization_tech_guest'] = set(['kvm'])
    result['virtualization_tech_host'] = set(['kvm'])
    assert linuxv.get_virtual_facts() == result


# Generated at 2022-06-23 02:18:01.395441
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Constructor for linux virtual should set distribution and distribution_version variables
    linux_virtual = LinuxVirtual(dict(module=AnsibleModule(
    )))
    assert linux_virtual.distribution_version is not None
    assert linux_virtual.distribution is not None

# Generated at 2022-06-23 02:18:03.839218
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    class_ = LinuxVirtualCollector()
    assert class_._fact_class == LinuxVirtual
    assert class_._platform == 'Linux'


# Generated at 2022-06-23 02:18:04.545303
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert True

# Generated at 2022-06-23 02:18:08.344430
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:16.533204
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    data = {
        'ansible_facts': {
            'virtualization_type': 'none',
            'virtualization_role': 'guest',
            'virtualization_tech_guest': {'none'},
            'virtualization_tech_host': {'none'}
        }
    }
    test_virtual_collector = LinuxVirtualCollector(dict(), dict(), data)
    assert test_virtual_collector._platform == 'Linux'
    assert isinstance(test_virtual_collector._fact_class, LinuxVirtual)
    assert test_virtual_collector.get_virtual_facts() == data


# Generated at 2022-06-23 02:18:23.507103
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import LinuxVirtual
    fact = LinuxVirtual()
    result = fact.get_virtual_facts()
    assert result == {}

# +=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=
# Virtualization Facts

# Generated at 2022-06-23 02:18:27.687375
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    linux_virtual_collector = LinuxVirtualCollector(module)
    assert linux_virtual_collector.platform == 'Linux'
    assert linux_virtual_collector.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:18:31.057180
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vcol = LinuxVirtualCollector()
    assert vcol.os_platform == 'Linux'
    assert isinstance(vcol.facts, LinuxVirtual)
    assert vcol.facts.os_platform == 'Linux'


# Generated at 2022-06-23 02:18:39.236697
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    vm = LinuxVirtual()
    if vm is None:
        raise AssertionError("Failed to create LinuxVirtual object")
    else:
        # In the absence of a better test, the test passes if we were able to
        # instantiate a LinuxVirtual object.
        pass



# Generated at 2022-06-23 02:18:42.876054
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lsvirt = LinuxVirtual(module)
    if not isinstance(lsvirt, LinuxVirtual):
        raise AssertionError("Cannot create LinuxVirtual")


# Generated at 2022-06-23 02:18:54.453122
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Generate and setup mock module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    module.params = {}
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value="/usr/bin/dmidecode")


    # Generate a mock for the class LinuxVirtual and load the class for testing
    LinuxVirtual_mock = MagicMock(spec=LinuxVirtual)
    LinuxVirtual_mock.module = module
    linux_virtual = LinuxVirtual()
    sys.modules['ansible.module_utils.facts.virtual.linux.LinuxVirtual'] = LinuxVirtual_mock
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    # Generate

# Generated at 2022-06-23 02:18:57.073298
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj.platform == 'Linux'
    assert obj.fact_class == LinuxVirtual


# Generated at 2022-06-23 02:19:04.085139
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)
    assert 'linux' == lv.platform
    assert set() == lv.guest_tech
    assert set() == lv.host_tech
    assert 'NA' == lv.virtualization_role
    assert 'NA' == lv.virtualization_type
    assert 'linux' == lv.platform


# Generated at 2022-06-23 02:19:08.815220
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    linux_virtual = LinuxVirtual(module)
    module.exit_json(changed=False, ansible_facts=linux_virtual.get_virtual_facts())

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:19:17.721136
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    module = MagicMock()
    module.get_bin_path = lambda x: x

    libvirt_out = b"""Id    Name                           State\r
----------------------------------------------------\r
 5     rhel7_guest                  running\r
 7     rhel8_guest                  shut off"""
    module.run_command.return_value = (0, libvirt_out, None)

    virt_obj = LinuxVirtual(module)
    result = virt_obj.get_virtual_facts()
    assert 'libvirt' in result['virtualization_type']
    assert 'guest' in result['virtualization_role']

# Generated at 2022-06-23 02:19:23.150642
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test for constructor of class LinuxVirtualCollector"""
    from ansible.module_utils.facts.collector.virtual import VirtualCollector
    from ansible.module_utils.facts.collector.virt.linux_virtual import LinuxVirtualCollector
    my_obj = LinuxVirtualCollector()
    assert isinstance(my_obj, VirtualCollector)
    assert my_obj.platform == 'Linux'
    my_virtual_fact_class = my_obj.fact_class
    assert my_virtual_fact_class == LinuxVirtual
    assert issubclass(my_virtual_fact_class, Virtual)


# Generated at 2022-06-23 02:19:25.180992
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule({})
    virtual = LinuxVirtualCollector(module)
    virtual.get_facts()


# Generated at 2022-06-23 02:19:28.897492
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lxvirt = LinuxVirtual(module)
    result = lxvirt.get_virtual_facts()
    assert result is not None
    assert 'virtualization_type' in result


# Generated at 2022-06-23 02:19:30.054158
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector().collect(), dict)

# Generated at 2022-06-23 02:19:37.702883
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    # Test for class LinuxVirtual
    linux_virtual = LinuxVirtual(module)
    os_facts_dict = {}
    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'virtualbox'
    virtual_facts['virtualization_role'] = 'guest'
    os_facts_dict['virtualization'] = virtual_facts
    # Test LinuxVirtual._get_virtual_facts
    linux_virtual._get_virtual_facts(os_facts_dict)
    module.exit_json(changed=False)



# Generated at 2022-06-23 02:19:39.996676
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    x = LinuxVirtualCollector()
    assert x.platform_has_flag(x._platform, x._fact_class.flags)


# Generated at 2022-06-23 02:19:43.903997
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    uut = LinuxVirtual()
    uut.module.run_command = run_command
    result = uut.get_virtual_facts()
    assert result['virtualization_tech_guest'] == set(['container', 'docker'])
    assert result['virtualization_tech_host'] == set(['docker'])
# END OF UNIT TEST


# Generated at 2022-06-23 02:19:49.035507
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Constructor test
    module = Mock()
    obj = LinuxVirtualCollector(module)
    # Check if object is subclass of class VirtualCollector
    assert isinstance(obj, VirtualCollector)
    # Check if class LinuxVirtual is assigned to _fact_class
    assert obj._fact_class == LinuxVirtual
    # Check if platform is assigned to _platform
    assert obj._platform == 'Linux'



# Generated at 2022-06-23 02:20:00.090137
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lsv = AnsibleModuleAruba()
    lsv.get_bin_path = Mock(return_value="/usr/bin/lscpu")
    lsv.run_command = Mock(return_value=(0, 'data', ''))
    # Call test method
    virtual_facts = lsv.get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == 'KVM'
    assert virtual_facts.get('virtualization_role') == 'guest'
    assert virtual_facts.get('virtualization_tech_guest') == set(['kvm'])
    assert lsv.run_command.called


# Generated at 2022-06-23 02:20:09.151267
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
        Unit test for method get_virtual_facts of class LinuxVirtual
    '''
    # Initialize / setup variables
    module = Mock()
    module.run_command = Mock(return_value = 0)
    module.get_bin_path = Mock(return_value = True)
    if os.path.exists('/proc/self/status'):
        module.run_command = Mock(return_value = (0, 'VxID: 0', ''))

    virtual_facts = {'virtualization_type': 'NA', 'virtualization_role': 'NA', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    lv = LinuxVirtual(module)

    # Run method: get_virtual_facts
    virtual_facts = lv.get_virtual_facts()

   

# Generated at 2022-06-23 02:20:14.994329
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    my_obj = LinuxVirtual()
    my_out = my_obj.get_virtual_facts()
    assert my_out['virtualization_tech_guest'] == {'container', 'kvm'}
    assert my_out['virtualization_tech_host'] == {'kvm'}
    assert my_out['virtualization_type'] == 'kvm'
    assert my_out['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:20:22.812480
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    obj = LinuxVirtual()
    res = obj.get_virtual_facts()
    assert res

    # Old kernels
    obj.module.run_command = MagicMock(return_value=(0, '', ''))
    res = obj.get_virtual_facts()
    assert res

    # dmidecode not available
    obj.module.run_command = MagicMock(return_value=(1, '', ''))
    res = obj.get_virtual_facts()
    assert res

# Generated at 2022-06-23 02:20:29.721546
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Initialize class and returns the created object
    '''
    module = AnsibleModule({'shell': '/bin/bash'}, 'ansible_virtual_mock')
    module.exit_json = exit_json
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None
    assert linux_virtual.module is not None
    assert linux_virtual.shell == '/bin/bash'
    assert linux_virtual.python_shell is None


# Generated at 2022-06-23 02:20:40.031045
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Unit test for constructor of class LinuxVirtual"""

    class MockModule(object):
        """Class for mocking class ansible.modules.system.LinuxVirtual"""

        def __init__(self):
            """Constructor of class MockModule"""

            self.run_command = Mock()
            self.get_bin_path = Mock()

    module = MockModule()

    linux_virtual = LinuxVirtual(module)

    # Make sure all the properties are correctly initialized
    assert linux_virtual.module == module
    assert linux_virtual.gather_subset == ['!all', '!min']
    assert linux_virtual.gather_network_resources == None



# Generated at 2022-06-23 02:20:49.406626
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(module)
    result = lv.get_virtual_facts()
    assert result
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result


# Generated at 2022-06-23 02:20:50.409643
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    assert LinuxVirtual(dict())


# Generated at 2022-06-23 02:20:56.983098
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    # Create instance of class LinuxVirtual
    lv = LinuxVirtual(module)
    # Pass custom parameters to function under test
    result = lv.get_virtual_facts()
    assert type(result['virtualization_type']) is str
    assert type(result['virtualization_role']) is str
    assert type(result['virtualization_tech_host']) is set
    assert type(result['virtualization_tech_guest']) is set

# Generated at 2022-06-23 02:20:59.822819
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_facts = LinuxVirtualCollector()
    assert 'virtual' in virtual_facts.data


# Generated at 2022-06-23 02:21:02.731365
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Constructor
    """
    # Initializing instance of class LinuxVirtual
    linux_virtual = LinuxVirtual()

    # Check values of class variables
    assert linux_virtual.virtual_facts == {}


# Generated at 2022-06-23 02:21:03.682788
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Constructor test
    assert LinuxVirtualCollector()

# Generated at 2022-06-23 02:21:06.587445
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert isinstance(obj, LinuxVirtual)
    assert isinstance(obj, VirtualCollector)


# Generated at 2022-06-23 02:21:10.501896
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    ''' Test creation of LinuxVirtual object '''
    module = AnsibleModule(argument_spec={})
    virt_obj = LinuxVirtual(module)
    assert virt_obj.module == module


# Generated at 2022-06-23 02:21:13.116745
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    vm = LinuxVirtual(module=module)
    module.exit_json(changed=False, ansible_facts=vm.get_virtual_facts())



# Generated at 2022-06-23 02:21:21.814410
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # create an instance of the class and mock modules
    virtual = LinuxVirtual(AnsibleModule)
    mock_glob = MagicMock()
    mock_glob.glob.return_value = ['']
    mock_os = MagicMock()
    mock_os.geteuid.return_value = 0
    mock_os.path.exists.return_value = True
    mock_os.path.isdir.return_value = True
    mock_os.access.return_value = True
    mock_os.path.isfile.return_value = True
    mock_open = MagicMock()
    mock_open.return_value = MockFile('/sys/devices/virtual/dmi/id/product_name', '')

# Generated at 2022-06-23 02:21:32.854085
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual is not None

    assert linux_virtual.module.run_command.call_count == 0
    assert len(linux_virtual.module.run_command.call_args_list) == 0

    assert linux_virtual.module.get_bin_path.call_count == 0
    assert len(linux_virtual.module.get_bin_path.call_args_list) == 0

    assert linux_virtual.module.get_file_content.call_count == 0
    assert len(linux_virtual.module.get_file_content.call_args_list) == 0

    assert linux_virtual.module.get_file_lines.call_count == 0

# Generated at 2022-06-23 02:21:36.966078
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    test_module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(test_module)
    print(lv.get_virtual_facts())


# Generated at 2022-06-23 02:21:48.070171
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from os.path import exists
    from os.path import isdir
    from os import getuid
    from os import access
    from unittest.mock import MagicMock
    with MagicMock():
        lv = LinuxVirtual({})
        assert lv.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': 'NA', 'virtualization_role': 'NA'}
    with MagicMock():
        lv = LinuxVirtual({'getuid.return_value': 1,'exists.return_value': False,'isdir.return_value': False, 'access.return_value': False})

# Generated at 2022-06-23 02:21:52.895372
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    virtual_collector = VirtualCollector()
    assert isinstance(linux_virtual_collector, LinuxVirtualCollector)
    assert isinstance(linux_virtual_collector, virtual_collector.__class__)


# Generated at 2022-06-23 02:21:54.240958
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    assert False, "Test not implemented."

# Mock module for get_file_content

# Generated at 2022-06-23 02:22:04.921307
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class LinuxVirtual
    """
    # assume lsb_release installed in /usr/bin
    lsb_release_path = '/usr/bin/lsb_release'
    distro_name = 'debian'
    distro_version = '8'
    distro_id = 'debian'
    if os.path.exists(lsb_release_path):
        (rc, out, err) = getstatusoutput(lsb_release_path)
        if rc == 0:
            for line in out.splitlines():
                data = line.split(":", 1)
                key = data[0].strip()
                val = data[1].strip()
                if key == 'Distributor ID':
                    distro_id = val

# Generated at 2022-06-23 02:22:07.326453
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'



# Generated at 2022-06-23 02:22:13.958711
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():  # pylint: disable=W0621
    '''
    Constructor of class LinuxVirtual
    '''
    mock_module = Mock()
    mock_module.run_command = Mock(return_value=(0, '', ''))
    mock_module.get_bin_path = Mock(return_value='dmidecode')

    linux_virtual_inst = LinuxVirtual(mock_module)

    assert linux_virtual_inst.module == mock_module
    assert linux_virtual_inst.file_exists('/proc/cpuinfo')
    assert not linux_virtual_inst.file_exists('/proc/nonexistent')


# Generated at 2022-06-23 02:22:15.924174
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # check the default of LinuxVirtualCollector
    virtual = LinuxVirtualCollector()
    assert virtual.platform == 'Linux'

# Generated at 2022-06-23 02:22:23.979172
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts import get_virtual_facts
    from ansible.module_utils.facts import get_file_lines
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    setattr(LinuxVirtual, 'module', FakeModule())
    m = LinuxVirtual()
    # At first, the test is only to return true if there is no exception raise
    # After that, I will try to match the result with expected results
    # This is to make sure that this function will not break when it is called
    # in other place
    try:
        m.get_virtual_facts()
    except Exception:
        exception = True
    assert exception is False

# Generated at 2022-06-23 02:22:26.842086
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    my_obj = LinuxVirtualCollector()
    my_fact_class = LinuxVirtual
    my_platform = 'Linux'
    assert my_obj._fact_class == my_fact_class
    assert my_obj._platform == my_platform

# Generated at 2022-06-23 02:22:35.405894
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Tests class LinuxVirtual.
    """
    module = AnsibleModule(argument_spec={})
    res_args = {}
    module.params = res_args
    linux_virtual = LinuxVirtual(module)
    facts = {}

    res_args['gather_subset'] = ['!all', 'virtual']
    linux_virtual.populate()
    facts.update(linux_virtual.get_facts())

    # Assert that virtual facts are correctly returned
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts


# Generated at 2022-06-23 02:22:44.871277
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

    # FIXME: Rename 'libvirt' to 'libvirt_guest'
    # FIXME: Rename 'libvirt_guest_type' to 'libvirt_domain_type'
    # FIXME: Rename 'libvirt_guest_name' to 'libvirt_domain_name'
    # FIXME: Rename 'libvirt_guest_uuid' to 'libvirt_domain_uuid'


# Generated at 2022-06-23 02:22:47.722672
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    assert LinuxVirtual(module).run()["virtualization_type"] in ["container", "native", "guest", "host", "kvm", "lxc"]

# Generated at 2022-06-23 02:22:58.203877
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # unit test for method get_virtual_facts of class LinuxVirtual
    # called from get_all_facts as get_virtual_facts
    #
    # Patch module.get_bin_path and module.get_file_content
    module = None
    LinuxVirtual.module = module
    #
    # Patch RunCommand.run_command

    rc = RunCommand()
    LinuxVirtual.run_command = rc.run_command

    #
    # Patch get_file_content

    gfc = GetFileContent()
    LinuxVirtual.get_file_content = gfc.get_file_content

    #
    # Patch get_file_lines

    gfl = GetFileLines()
    LinuxVirtual.get_file_lines = gfl.get_file_lines

    #
    # Patch get_file_content

    gfc = Get

# Generated at 2022-06-23 02:23:00.964507
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector()
    assert obj.platform == "Linux"
    assert issubclass(obj.fact_class, LinuxVirtual) == True


# Generated at 2022-06-23 02:23:09.448665
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test = LinuxVirtual({})
    test.module = MagicMock(**{
        "fail_json.return_value": False,
        "get_bin_path.return_value": False,
        "run_command.return_value": (0, 'test', 'test'),
        "filter_string_to_list.return_value": False,
    })
    assert test.get_virtual_facts().keys() == {'virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host'}

# Generated at 2022-06-23 02:23:19.399429
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)

    # Replace functions with ones that don't need sudo or chroot
    lv.get_file_content = lambda path: '_'
    lv.get_file_lines = lambda path: ['foo', 'bar', 'baz']

    virtual_facts = lv.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set([])
    assert virtual_facts['virtualization_tech_host'] == set([])


# Generated at 2022-06-23 02:23:25.110215
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """ linux_virtual - constructor unit test """

    # Initialize and object
    # We are not passing args
    my_virt = LinuxVirtual()

    # Check object
    assert isinstance(my_virt, LinuxVirtual)

    # We can check the object attributes later
    assert isinstance(my_virt.module, AnsibleModule)

# Unit test: get_virtual_facts

# Generated at 2022-06-23 02:23:30.040236
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_obj = LinuxVirtual()
    result = test_obj.get_virtual_facts()
    assert result == {
        'virtualization_role': 'NA',
        'virtualization_type': 'NA',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-23 02:23:32.509302
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'


# Generated at 2022-06-23 02:23:37.200472
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert(lvc is not None)
    assert(lvc.fact_class is LinuxVirtual)
    assert(lvc.platform is 'Linux')

    # _collect_virtual_facts() is not unit tested.

# Generated at 2022-06-23 02:23:43.341245
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """This method will just instantiate the class"""
    LinuxVirtualCollector()


if __name__ == '__main__':
    # For test only
    module = AnsibleModule(argument_spec=dict())
    collector = LinuxVirtual(module=module)
    facts = collector.collect()
    result = dict(changed=False, ansible_facts=facts)
    module.exit_json(**result)