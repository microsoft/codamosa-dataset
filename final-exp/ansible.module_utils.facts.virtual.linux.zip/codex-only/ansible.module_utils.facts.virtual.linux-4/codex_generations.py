

# Generated at 2022-06-23 02:13:56.517577
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    lv = LinuxVirtual(module)

    # test case:
    # when the virtualization facts are not available
    # the output should be just one key (virtualization_type)
    # and the value should be equal to NA
    class mock_os:
        @staticmethod
        def path_exists(path):
            return False

    try:
        lv.os = mock_os
        facts = lv.get_virtual_facts()
        assert 'virtualization_type' in facts.keys()
        assert facts['virtualization_type'] == 'NA'
    except Exception:
        pytest.fail("unexpected fail")



# Generated at 2022-06-23 02:14:01.393280
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector()
    assert virtual._platform == 'Linux'
    # Tests if the __init__ method of LinuxVirtualCollector class is called
    assert virtual._fact_class is LinuxVirtual

# Test for method get_virtual_facts() of class LinuxVirtualCollector
# Test when no virtual facts are found

# Generated at 2022-06-23 02:14:13.736080
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    from ansible.module_utils.facts.virtual.linux_virtual import get_file_lines
    from ansible.module_utils.facts.virtual.linux_virtual import get_file_content

    def mock_get_file_lines(path):
        if path == '/proc/1/cgroup':
            return '9:cpuset:/docker/f40be8d90271c4638c36eda0b0b675454208ee305e5a5c5ab5f5dd5c5a5d5c5e5a5c5a5a5c5d5c5a5a5c5a5a5d5c5a5c5f5d5e5c'

# Generated at 2022-06-23 02:14:18.107474
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    ls = LinuxVirtual(module)
    print("ls.virtual_facts:", ls.virtual_facts)
    assert isinstance(ls.virtual_facts, dict)


# Generated at 2022-06-23 02:14:21.173544
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert (LinuxVirtualCollector._fact_class == LinuxVirtual)
    assert (LinuxVirtualCollector._platform == 'Linux')
    assert (LinuxVirtualCollector.collect(None) == {})

# Generated at 2022-06-23 02:14:24.589810
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    windows_virtual_collector = LinuxVirtualCollector(module)
    assert 'Linux' == windows_virtual_collector._platform

# Generated at 2022-06-23 02:14:28.272134
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = mock.MagicMock()
    collector = LinuxVirtualCollector(module)
    assert collector._fact_class == LinuxVirtual
    assert collector._platform == 'Linux'


# Generated at 2022-06-23 02:14:33.488400
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    vm = LinuxVirtual(module)

    for key in ('virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host'):
        assert key in vm.facts, "Failed to collect %s fact" % key


# Generated at 2022-06-23 02:14:44.394424
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    c = dict()
    o = LinuxVirtual(c)

    c['virtualization.technology_guest'] = set()
    c['virtualization.technology_host'] = set()
    c['virtualization.type'] = None
    c['virtualization.role'] = None

    try:
        abstract.get_file_content("/sys/devices/virtual/dmi/id/product_name")
        abstract.get_file_content("/sys/devices/virtual/dmi/id/sys_vendor")
        abstract.get_file_content("/sys/devices/virtual/dmi/id/product_family")
        abstract.get_file_content("/sys/devices/virtual/dmi/id/bios_vendor")
    except IOError:
        pass

    assert o.get_virtual_facts()


#

# Generated at 2022-06-23 02:14:47.966777
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert lvc._fact_class.__name__ == 'LinuxVirtual'
    assert lvc._fact_class._platform == 'Linux'
    assert lvc._fact_class._fact_class_name == 'LinuxVirtual'

# Generated at 2022-06-23 02:14:53.670986
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    lv.module = module
    lv.get_virtual_facts()
    assert lv.virtual_facts['virtualization_type'] == 'lxc'
    assert lv.virtual_facts['virtualization_role'] == 'guest'
    assert 'systemd_container' in lv.virtual_facts['virtualization_tech_guest']
test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:14:56.408258
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    mod_collector = LinuxVirtualCollector(module)
    assert mod_collector._fact_class is LinuxVirtual


# Generated at 2022-06-23 02:14:58.420079
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Unit test for constructor of class LinuxVirtual"""
    linux_virtual = LinuxVirtual()
    assert linux_virtual is not None

# Generated at 2022-06-23 02:15:06.774453
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleFailJson
    from ansible_collections.ansible.community.plugins.module_utils import basic

    m = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    # Override methods to force specific logic in the module to happen

# Generated at 2022-06-23 02:15:09.474809
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virt = LinuxVirtualCollector.fetch_virtual_facts()
    assert 'virtualization_type' in virt
    assert 'virtualization_role' in virt

# Generated at 2022-06-23 02:15:20.125578
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os

    mocked_module = basic.AnsibleModule(
        argument_spec=dict()
    )
    # required for gathering facts
    os_real_path = os.path.realpath
    os_path_isfile = os.path.isfile
    os_path_ismount = os.path.ismount
    os_path_isdir = os.path.isdir
    os_path_exists = os.path.exists
    os_path_basename = os.path.basename
    os_path_isdir = os.path.isdir
    os_path_split = os.path.split

    os.path.realpath = lambda x: x

# Generated at 2022-06-23 02:15:23.666427
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule({})
    virt = LinuxVirtualCollector(module)
    assert virt._platform == 'Linux'
    assert virt._fact_class == LinuxVirtual
    assert virt._facts_class == LinuxVirtual

# Unit test class LinuxVirtual

# Generated at 2022-06-23 02:15:31.292601
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:15:36.027442
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    my_LinuxVirtualCollector = LinuxVirtualCollector()
    assert my_LinuxVirtualCollector.platform == 'Linux'
    my_LinuxVirtualCollector.collect()
    assert 'virtualization_type' in my_LinuxVirtualCollector.facts
    assert 'virtualization_role' in my_LinuxVirtualCollector.facts
    assert 'virtualization_tech_guest' in my_LinuxVirtualCollector.facts
    assert 'virtualization_tech_host' in my_LinuxVirtualCollector.facts

# Generated at 2022-06-23 02:15:39.578107
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # source: https://github.com/ansible/ansible/blob/v2.10.1/test/lib/ansible_test/_data/unit/modules/system/linux/virtual_test.py
    pass

# Generated at 2022-06-23 02:15:43.248258
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(
        argument_spec = dict()
    )
    lv = LinuxVirtual(module)
    res_args = {
    }
    res = lv.populate()
    module.exit_json(**res)



# Generated at 2022-06-23 02:15:53.918978
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    bytes_str = b'\xcc\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

    mocked_module = MagicMock()

    mock_methods = [
        'get_bin_path', 'run_command']

    mocked_module.configure_mock(**dict([(method_name, MagicMock()) for method_name in mock_methods]))

    mocked_module.get_bin_path.return_value = '/bin/dmidecode'

    mocked_LinuxVirtual = LinuxVirtual(mocked_module)

    # unit test 1 - cpuinfo contains vendor_id as 'IBM/S390'

# Generated at 2022-06-23 02:16:04.726982
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Initialise empty LinuxVirtual object
    lv = LinuxVirtual()

    # mock the module
    mock_module = MagicMock()
    lv.module = mock_module

    # mock the module.get_bin_path method
    mock_get_bin_path = MagicMock()
    mock_module.get_bin_path = mock_get_bin_path

    # mock the LinuxSysctl objects
    mock_LinuxSysctl = MagicMock()
    lv.sysctl = mock_LinuxSysctl

    # mock the module.get_file_content method
    mock_get_file_content = MagicMock()
    mock_module.get_file_content = mock_get_file_content

    # mock the module.get_file_lines method
    mock_get_file_lines = MagicMock()
    mock_

# Generated at 2022-06-23 02:16:11.238674
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Test with default module object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    linux_virtual = LinuxVirtual(module)

    # Test with custom module object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        bypass_checks=False,
    )
    linux_virtual = LinuxVirtual(module)


# Generated at 2022-06-23 02:16:14.798888
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = ansible_module_create()
    v = LinuxVirtual(module)
    module.exit_json(**v.get_virtual_facts())


# Generated at 2022-06-23 02:16:25.865275
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    from ansible.module_utils.facts.virtual.linux_virtual import get_file_content
    import os
    import sys
    import unittest.mock as mock
    import pytest
    import glob
    import re

    class MockModule():
        def __init__(self):
            self.params = None
        def exit_json(self, result):
            return result
        def fail_json(self, msg, **kwargs):
            return msg

    def get_file_content(f):
        if re.match('/sys/devices/virtual/dmi/id/product_name', f):
            return 'OpenStack Nova'

# Generated at 2022-06-23 02:16:35.365816
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({}, supports_check_mode=True)
    lv = LinuxVirtual(module)
    facts = lv.populate()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_host_name' in facts
    assert type(facts['virtualization_tech_host']) is set
    assert type(facts['virtualization_tech_guest']) is set

# Generated at 2022-06-23 02:16:39.051729
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    LinuxVirtual class constructor test
    """
    module = AnsibleModule(argument_spec=dict())
    is_linux_virtual_obj = LinuxVirtual(module)
    assert is_linux_virtual_obj


# Generated at 2022-06-23 02:16:43.113912
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lxv = LinuxVirtualCollector()
    assert lxv.platform == 'Linux'
    assert lxv._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:16:50.620827
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    lv.module = Mock()
    lv.module.get_bin_path = Mock()
    lv.module.run_command = Mock()
    lv.get_virtual_facts()
    assert 'virtualization_type' in lv.virtual_facts
    assert 'virtualization_role' in lv.virtual_facts
    assert 'virtualization_tech_guest' in lv.virtual_facts
    assert 'virtualization_tech_host' in lv.virtual_facts


# Generated at 2022-06-23 02:17:00.017198
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.linux.virtual import LinuxVirtual
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    module = FakeModule()
    virtual = LinuxVirtual(module)
    hardware = LinuxHardware(module)
    # Test case 1 - guest

# Generated at 2022-06-23 02:17:04.442925
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    testmodule = AnsibleModule({}, suppress_facts=True)
    testmodule.params = {}
    linux_virtuals = LinuxVirtual(testmodule)
    # Check that initializing the class works.
    assert linux_virtuals


# Generated at 2022-06-23 02:17:15.268879
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # GIVEN: a test Instance of AnsibleModule
    test_ansible_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_ansible_module_virtual = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # stub out actual methods used
    test_ansible_module_virtual.get_bin_path = MagicMock(return_value="some/path/bin")
    test_ansible_module_virtual.run_command = MagicMock(return_value="some/path/bin")
    test_ansible_module_virtual.get_file_content = MagicMock(return_value="some/path/bin")
    test_ansible_module_virtual.get_file_lines = MagicMock(return_value="some/path/bin")


# Generated at 2022-06-23 02:17:28.497897
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # When 'dmidecode' is called, trap stdout and stderr
    #  so that we can make assertions about what was written.
    def dmidecode_side_effect(args, ignore_rc=False, **_):
        # Create a dict mapping a string to the output written to stdout
        #  when dmidecode is called with that string.
        dmidecode_output = {
            '-s system-product-name': "VMware Virtual Platform",
            '-s system-uuid': "VMware Virtual Platform"
        }
        # Strip off the "dmidecode" command.
        args = args.split()[1:]
        # Get the args passed to dmidecode.


# Generated at 2022-06-23 02:17:38.658015
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual.py
    ~~~~~~~~~~~~~~~~
        Unit test for constructor of class LinuxVirtual
    """
    #Initialize AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    linux_virtual_obj = LinuxVirtual(module)
    #Check initialized object should not be empty
    assert linux_virtual_obj is not None
    assert linux_virtual_obj.module is not None
    assert linux_virtual_obj.virtual_facts is not None


# Generated at 2022-06-23 02:17:45.772862
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    LVM = LinuxVirtual()
    LVM.module = AnsibleModule(argument_spec={})
    assert LVM.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'virtualbox', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'virtualbox'}}



# Generated at 2022-06-23 02:17:52.383679
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the LinuxVirtual constructor.
    """
    lv = LinuxVirtual()

    virtual_facts = lv.is_virtual()

    # Test properties
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-23 02:17:55.935576
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    lvc = LinuxVirtualCollector(module)
    assert lvc.platform == 'Linux'
    assert lvc.fact_class == LinuxVirtual



# Generated at 2022-06-23 02:17:57.527491
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test class LinuxVirtualCollector constructor"""
    assert LinuxVirtualCollector()

# Generated at 2022-06-23 02:18:01.555344
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Unit test for method LinuxVirtualCollector"""
    lvc = LinuxVirtualCollector()
    assert lvc._platform == 'Linux'
    assert isinstance(lvc._fact_class(), LinuxVirtual)


# Generated at 2022-06-23 02:18:03.864498
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual = LinuxVirtual()

    assert virtual is not None, 'test_LinuxVirtual: failed to create LinuxVirtual object'


# Generated at 2022-06-23 02:18:15.598317
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())

    vm = LinuxVirtual(module)

    assert vm.get_virtual_facts()['virtualization_role'] == "guest"

    module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list', elements='str', default=['!all', 'virtual'])))
    vm = LinuxVirtual(module)

    assert vm.get_virtual_facts()['virtualization_role'] == "guest"

    module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list', elements='str', default=['!all', 'virtual'])))
    vm = LinuxVirtual(module)

    assert vm.get_virtual_facts()['virtualization_type'] == "docker"



# Generated at 2022-06-23 02:18:28.204102
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    obj = LinuxVirtual()
    obj.module.run_command = MagicMock(return_value=(0, '', ''))
    lxc_info_out = """
Kernel Version: 3.10.0-862.3.2.el7.x86_64
Architecture: amd64
"""
    lscpu_out = 'Hypervisor vendor: KVM'
    virt_what_out = 'kvm'

# Generated at 2022-06-23 02:18:36.240835
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    res = Virtual(module)

    module.exit_json(changed=False, ansible_facts=dict(virtual=res))



# Generated at 2022-06-23 02:18:41.575623
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test LinuxVirtual constructor.
    :return:
    """

    module = AnsibleModule(argument_spec={})
    virtual_module = LinuxVirtual(module)
    assert isinstance(virtual_module, LinuxVirtual)
    module.fail_json(msg='Non-zero exit code is returned by module')



# Generated at 2022-06-23 02:18:43.395308
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = LinuxVirtualCollector()
    assert vc is not None

# Generated at 2022-06-23 02:18:47.840329
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtual().populate()
    assert facts['virtualization_type'] == 'NA'
    assert facts['virtualization_role'] == 'NA'
    assert not facts['virtualization_tech_guest']
    assert not facts['virtualization_tech_host']

# Generated at 2022-06-23 02:18:51.255116
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    result = LinuxVirtualCollector.collect(module, None)
    assert result is not None

# Generated at 2022-06-23 02:18:53.263669
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = mock.MagicMock()
    virtual = LinuxVirtual(module)
    assert virtual is not None

# Generated at 2022-06-23 02:18:58.592199
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Build a fake module
    module = AnsibleModule({})
    # Build an instance of our class and call get_virtual_facts
    lv = LinuxVirtual(module)
    out = lv.get_virtual_facts()
    for k, v in out.items():
        module.exit_json(msg="%s=%s" % (k, v))


# Generated at 2022-06-23 02:19:03.027835
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # pylint: disable=too-few-public-methods
    class CheckLinuxVirtualCollector(object):
        def __init__(self):
            self.module = AnsibleModuleMock()
            self.collector = LinuxVirtualCollector(self.module)

    obj = CheckLinuxVirtualCollector()
    assert obj.collector._fact_class is LinuxVirtual


# Generated at 2022-06-23 02:19:09.694437
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.linux import LinuxVirtualCollector
    from ansible.module_utils.facts.collector.linux import LinuxVirtual
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    lvc = LinuxVirtualCollector()
    assert isinstance(lvc,LinuxVirtualCollector)
    assert isinstance(lvc,BaseFactCollector)
    assert lvc.platform == 'Linux'



# Generated at 2022-06-23 02:19:12.421528
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test constructor of LinuxVirtualCollector.
    """
    obj = LinuxVirtualCollector()
    assert obj._fact_class == LinuxVirtual
    assert obj._platform == 'Linux'


# Generated at 2022-06-23 02:19:15.348440
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    sys_virtual = LinuxVirtual()
    assert sys_virtual.module is not None
    assert sys_virtual.facts is not None


# Generated at 2022-06-23 02:19:18.052642
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtualCollector = LinuxVirtualCollector()
    assert virtualCollector.facts == {}
    assert virtualCollector._platform == 'Linux'
    assert virtualCollector._fact_class == LinuxVirtual

# Generated at 2022-06-23 02:19:29.392270
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    linux_virtual.py:LinuxVirtual unit test

    Asserts that LinuxVirtual is able to set OS facts
    when LinuxVirtual is initialized with valid parameters.
    """
    module = AnsibleModule(argument_spec={})
    linux_virtual = LinuxVirtual(module)
    (virtual_facts, dummy) = linux_virtual.collect_facts()

    # Assert that the virtual_facts dictionary is not empty
    assert virtual_facts is not {}

    # Assert that the virtual_facts dictionary has a 'virtualization_role'
    # key in it that is not empty
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'] != ''

    # Assert that the virtual_facts dictionary has a 'virtualization_type'
    # key in it that is not empty

# Generated at 2022-06-23 02:19:31.778218
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """Test constructor for class LinuxVirtualCollector"""
    virtual_collector = LinuxVirtualCollector(None)
    assert virtual_collector._platform == 'Linux'

# Generated at 2022-06-23 02:19:33.691579
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModuleFake()
    module = LinuxVirtual(module)
    assert module


# Generated at 2022-06-23 02:19:37.358889
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils.facts.system.virtual import LinuxVirtual
    module_mock = AnsibleModuleMock()
    lv = LinuxVirtual(module_mock)
    assert isinstance(lv, LinuxVirtual)


# Generated at 2022-06-23 02:19:43.734828
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    module.exit_json = exit_json
    lv = LinuxVirtual(module)
    res_args = dict()
    res_args['virtualization_type'] = 'kvm'
    res_args['virtualization_role'] = 'host'
    res_args['virtualization_tech_host'] = set(['kvm'])
    res_args['virtualization_tech_guest'] = set([])
    res = lv.get_virtual_facts()
    module.exit_json(**res)


# Generated at 2022-06-23 02:19:52.502145
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    try:
        import __builtin__ as builtins
    except ImportError:  # python3
        import builtins

    import collections

    import ansible.module_utils.facts.virtual.linux as virtual_linux_module
    import ansible.module_utils.facts.virtual.common as virtual_common_module
    import ansible.module_utils.facts.virtual.common_ipxe as virtual_common_ipxe_module
    import ansible.module_utils.basic as basic_module
    import ansible.module_utils.urls as urls_module

    openstack_cic_content = "SOME OPENSTACK CIC CONTENT"
    vmware_vcenter_content = "SOME VMWARE VCENTER CONTENT"
    docker_content = 'docker1'
    containerd_content = 'containerd1'


# Generated at 2022-06-23 02:19:56.546374
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    obj = LinuxVirtualCollector
    LinuxVirtualCollector()

# =============================================
# collect_platform = Linux
# =============================================


# =============================================
# collect_platform = Darwin
# =============================================


# Generated at 2022-06-23 02:20:07.056600
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lxc_path = '/etc/lxc'
    cgroup_path = '/sys/fs/cgroup'
    lxc_version = '1.1.0'
    cgroup_version = '1.0'
    results = dict()
    results['paths'] = { 'lxc_path' : lxc_path, 'cgroup_path': cgroup_path }
    results['versions'] = { 'lxc_version' : lxc_version, 'cgroup_version': cgroup_version }
    virtual_obj = LinuxVirtual(results)
    

# Generated at 2022-06-23 02:20:16.493761
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Imports
    import json
    import os

    test_cases = ['test_case_get_virtual_facts_docker_guest_baremetal_host',
                  'test_case_get_virtual_facts_docker_guest_vmware_host']

    for test_case in test_cases:
        input_file = 'resources/LinuxVirtual-{}.json'.format(test_case)
        with open(input_file, 'r') as f:
            json_obj = json.load(f)

        virtual_obj = LinuxVirtual(module=None)
        virtual_facts = virtual_obj.get_virtual_facts()

        # Assert that the output JSON matches the expected JSON
        assert json_obj == virtual_facts

if __name__ == '__main__':
    # Test get_virtual_facts method
    test

# Generated at 2022-06-23 02:20:28.535911
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule({})
    linux_virtual = LinuxVirtual(module)
    assert linux_virtual.module == module

# Unit tests for methods of class LinuxVirtual

# Generated at 2022-06-23 02:20:32.665320
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict()
    )

    linux_virtual = LinuxVirtual(module)
    assert linux_virtual
    assert linux_virtual.module == module

# Generated at 2022-06-23 02:20:43.334508
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    class TestModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            self.exit_called = True

    def get_bin_path(name, required=False, opt_dirs=[]):
        if name in ('dmidecode', 'lscpu'):
            return name

    module = TestModule()
    module.get_bin_path = get_bin_path
    module.run_command = lambda *args, **kwargs: (0, '', '')

    # Dummy facts dict
    facts = dict()

    # Run constructor test
    linux_virtual = LinuxVirtual(module=module, facts=facts)
    linux_virtual.pop

# Generated at 2022-06-23 02:20:53.656333
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    m = AnsibleModule(argument_spec=dict())
    l = LinuxVirtual(m)
    res = l.get_virtual_facts()
    assert isinstance(res, dict)
    assert isinstance(res['virtualization_role'], str)
    assert isinstance(res['virtualization_type'], str)
    assert isinstance(res['virtualization_tech_guest'], set)
    assert isinstance(res['virtualization_tech_host'], set)
    assert isinstance(res['virtualization_tech_guest'].pop(), str)
    assert isinstance(res['virtualization_tech_host'].pop(), str)


# Generated at 2022-06-23 02:20:56.494952
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virt_collector = LinuxVirtualCollector()
    assert virt_collector._platform == 'Linux'

# Unit tests for testing the class' get_fact method

# Generated at 2022-06-23 02:21:01.219632
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    x = LinuxVirtualCollector(module)
    assert x._platform == 'Linux'
    assert x._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:21:03.804474
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    m = AnsibleModule(argument_spec={})
    d = LinuxVirtual(m)
    assert m == d.module

if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:21:06.321190
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector.platform == 'Linux'
    assert LinuxVirtualCollector.fact_class == LinuxVirtual

# Generated at 2022-06-23 02:21:07.782071
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = LinuxVirtualCollector()
    assert vc is not None


# Generated at 2022-06-23 02:21:16.710387
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # mock the module and fake the function
    module_mock = Mock()
    module_mock.run_command = Mock(return_value=(0, '', ''))
    module_mock.get_bin_path = Mock(return_value='')
    module_mock.get_file_content = Mock(return_value='')
    module_mock.get_file_lines = Mock(return_value=[])
    module = module_mock
    linux_virtual = LinuxVirtual(module)

    # test the method
    result = linux_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:21:28.603056
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    result = dict(
        changed=False,
        ansible_facts=dict(
            virtualization=dict(),
            ansible_virtualization=dict()
        )
    )

    dmidecode_path = 'dmidecode_path'
    lscpu_path = 'lscpu_path'
    virt_fh = open('/proc/self/status', 'r')


# Generated at 2022-06-23 02:21:34.086833
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Constructor for class LinuxVirtual
    '''
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    linux_virtual_testobj = LinuxVirtual(module)
    # Testing Attributes
    assert linux_virtual_testobj.module == module
    assert linux_virtual_testobj.virtual is None


# Generated at 2022-06-23 02:21:37.463478
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Unit test for constructor of LinuxVirtualCollector
    # The module will not be executed on the current Linux platform
    # if it fails here
    LinuxVirtualCollector(None)

# Generated at 2022-06-23 02:21:41.753435
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    virtual_collector = LinuxVirtualCollector(module=module)
    assert virtual_collector.platform == 'Linux'
    assert virtual_collector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:21:47.735597
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    facts = {}
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    set_module_args(dict(gather_subset='virtual'))
    linux_virtual_obj = LinuxVirtual(module)
    linux_virtual_obj.get_virtual_facts()
    module.exit_json(ansible_facts=dict(virtual=facts))


# Generated at 2022-06-23 02:21:52.234679
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    global _cls_linux_virtual_collector
    _cls_linux_virtual_collector = LinuxVirtualCollector()
    assert type(_cls_linux_virtual_collector) is LinuxVirtualCollector


# Generated at 2022-06-23 02:21:56.199140
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Just a simple test to create a LinuxVirtual object"""
    module = Mock()
    module.run_command.return_value = (0, "", "")
    l_virt = LinuxVirtual(module)
    assert l_virt is not None


# Generated at 2022-06-23 02:21:58.275851
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtualCollector(dict())
    assert facts._platform == 'Linux'
    assert isinstance(facts._fact_class(facts), LinuxVirtual)

# Generated at 2022-06-23 02:22:04.812508
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )

    linux_virtual = LinuxVirtual(module)
    virtual_facts = linux_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:22:13.229404
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import sys
    import os
    import tempfile
    import random
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir))
    from test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.exit_json = AnsibleExitJson
    module.fail_json = AnsibleFailJson
    tmpdir = tempfile.mkdtemp()
    is_chroot = random.choice((True, False))
    is_container = random.choice((True, False))

# Generated at 2022-06-23 02:22:17.675049
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    #
    # This test method has not been implemented by Ansible.
    #
    return
# END Unit test for method get_virtual_facts of class LinuxVirtual

# END Class LinuxVirtual

# BEGIN Class LinuxService

# BEGIN Unit test for method get_service_tools of class LinuxService

# Generated at 2022-06-23 02:22:19.471540
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert True


# Generated at 2022-06-23 02:22:22.915637
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    c = LinuxVirtualCollector()
    assert c._fact_class == LinuxVirtual
    assert c._platform == 'Linux'
    assert c._fact_names == ['virtualization_type', 'virtualization_role', 'virtualization_system', 'virtualization_host']
    assert c._ignore_values == ['NA']

# Generated at 2022-06-23 02:22:30.779818
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    vm = LinuxVirtual(module)

    # Constructor test
    if 'virtualization_type' not in vm.virtual_facts:
        module.fail_json(msg="There was a problem accessing virtual_facts. This should never happen.")

    # Check for valid return values
    if not vm.virtual_facts['virtualization_type'] in ('host', 'guest', 'NA'):
        module.fail_json(msg="Invalid return value for virtualization_type from LinuxVirtual. This should never happen.")


# Generated at 2022-06-23 02:22:40.716155
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test :meth:`ansible.module_utils.facts.system.virtual.get_virtual_facts`
    """
    # Dummy class to be used to "mock" the module parameter
    class AnsibleModule:
        def __init__(self):
            self.params = {}

    module = AnsibleModule()
    virtual_facts = LinuxVirtual.get_virtual_facts(module)

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:22:48.725795
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    lv = LinuxVirtual(module)
    assert "virtualization_role" in lv.get_virtual_facts()
    assert "virtualization_role_guest" not in lv.get_virtual_facts()
    assert "virtualization_role_host" not in lv.get_virtual_facts()
    assert "virtualization_type" in lv.get_virtual_facts()
    assert "virtualization_type_guest" not in lv.get_virtual_facts()
    assert "virtualization_type_host" not in lv.get_virtual_facts()
    assert "virtualization_tech_guest" in lv.get_virtual_facts()
    assert "virtualization_tech_host" in lv.get_virtual_

# Generated at 2022-06-23 02:22:58.970524
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Return summary of major facts'''

    linux_virtual = LinuxVirtual()
    virtual_facts = linux_virtual.collect()


# Generated at 2022-06-23 02:23:01.754076
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    # test the constructor
    virtual_obj = LinuxVirtual(module)
    assert virtual_obj


# Generated at 2022-06-23 02:23:04.713042
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    data = LinuxVirtualCollector(module)
    assert data
    assert isinstance(data, LinuxVirtualCollector)


# Generated at 2022-06-23 02:23:16.580776
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Instantiate an object of class LinuxVirtual
    linux_virtual = LinuxVirtual()

    # Call function collect() of the object linux_virtual
    linux_virtual.collect()
    # Check the return of function collect()
    assert linux_virtual.data["virtualization_type"] != "NA"
    assert linux_virtual.data["virtualization_role"] != "NA"
    if linux_virtual.data["virtualization_role"] != "guest":
        assert linux_virtual.data["virtualization_role"] == "host"

# Generated at 2022-06-23 02:23:23.680821
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert lv.host_tech == set()
    assert lv.guest_tech == set()
    assert lv.virtual_facts == {
        'virtualization_type': 'NA',
        'virtualization_role': 'NA',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }



# Generated at 2022-06-23 02:23:27.229766
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.collector.virtual import LinuxVirtualCollector
    import ansible.module_utils.facts.virtual.linux as linux_virtual_module
    module = linux_virtual_module.AnsibleModuleStub()
    fact_collector = LinuxVirtualCollector(module)
    assert(fact_collector._platform == 'Linux')

# Generated at 2022-06-23 02:23:35.757105
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # Create a LinuxVirtual class object
    lx_from_module = LinuxVirtual(module)
    # Example of getting facts from the sys module
    result = lx_from_module.get_virtual_facts()
    assert result['virtualization_type'] != 'NA'
    # There is no way to have a role of 'NA' if the type is not 'NA'
    assert result['virtualization_role'] != 'NA'
    # Examples of verifying the 'facts' being returned
    assert set(result['virtualization_tech_host'])
    assert set(result['virtualization_tech_guest'])

# Generated at 2022-06-23 02:23:45.454449
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    import inspect
    import os.path
    import sys
    import tempfile
    module_name = 'ansible_collections.ansible.community.plugins.module_utils.facts.virtual.linux_virtual'
    module_path = inspect.getfile(inspect.currentframe())
    module_realpath = os.path.realpath(module_path)
    module_dir = os.path.dirname(module_realpath)
    module_parent_dir = os.path.dirname(module_dir)