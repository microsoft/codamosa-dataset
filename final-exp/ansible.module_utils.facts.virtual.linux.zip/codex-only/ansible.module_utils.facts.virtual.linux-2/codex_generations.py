

# Generated at 2022-06-23 02:13:53.086402
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    facts = LinuxVirtualCollector(module).collect()['ansible_facts']
    assert type(facts['ansible_virtualization']['type']) == str
    assert facts['ansible_virtualization']['role'] == 'guest'
    assert type(facts['ansible_virtualization']['tech_guest']) == list
    assert type(facts['ansible_virtualization']['tech_host']) == list
    return


# Generated at 2022-06-23 02:14:05.436962
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    import json

    # Construct a test object.
    test_obj = LinuxVirtual(None)

    # For the purpose of this test, assume the master dictionary is not
    # yet present in the system.
    test_obj.facts = None

    # Test the LinuxVirtual constructor.
    test_obj.populate()

    # Verify that we have the facts in the master dictionary.
    assert test_obj.facts is not None

    # Verify that we have virtualization_type fact.
    assert 'virtualization_type' in test_obj.facts

    # Verify that we have virtualization_role fact.
    assert 'virtualization_role' in test_obj.facts

    # Verify that we have virtualization_tech_guest fact.
    assert 'virtualization_tech_guest' in test_obj.facts

    # Verify that we have virtualization_

# Generated at 2022-06-23 02:14:13.180597
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    if not HAS_PSUTIL:
        module.fail_json(msg='psutil required for this module')

    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    module.exit_json(ansible_facts={'ansible_virtualization_facts': virtual_facts})

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:14:15.991939
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    fc = LinuxVirtualCollector()
    assert fc.platform == 'Linux'
    assert fc.fact_class == LinuxVirtual

# Generated at 2022-06-23 02:14:21.370085
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    virtual_facts = linux_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:14:23.995065
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_facts = LinuxVirtualCollector()
    assert virtual_facts._platform == 'Linux'
    assert virtual_facts._fact_class.__name__ == 'LinuxVirtual'


# Generated at 2022-06-23 02:14:31.385536
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Validate the constructor of class LinuxVirtual.
    '''
    # Test with invalid module
    with pytest.raises(Exception) as err:
        lv = LinuxVirtual(None)
    assert err.value.args[0] == "module is required"

    # Test with valid module
    m = AnsibleModule(argument_spec = dict())
    lv = LinuxVirtual(m)
    assert isinstance(lv, LinuxVirtual)


# Generated at 2022-06-23 02:14:38.335971
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    lxvirt = LinuxVirtual(module)
    (found_virt, virtual_facts, guest_tech, host_tech) = lxvirt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert len(virtual_facts['virtualization_tech_host']) == 0

# Generated at 2022-06-23 02:14:48.527332
# Unit test for method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-23 02:14:50.146970
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    # Creating an instance
    lvirt = LinuxVirtual()
    assert(lvirt.__class__.__name__ == 'LinuxVirtual')


# Generated at 2022-06-23 02:14:52.528081
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    l_virtual = LinuxVirtual(module)
    assert l_virtual is not None
    assert l_virtual.module is not None


# Generated at 2022-06-23 02:15:03.720551
# Unit test for method get_virtual_facts of class LinuxVirtual

# Generated at 2022-06-23 02:15:14.308375
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    m = AnsibleModuleMock()
    virtual_check = LinuxVirtual(m)
    virtual_facts = virtual_check.get_virtual_facts()
    if len(virtual_facts) == 0:
        raise Exception('LinuxVirtual: get_virtual_facts: no output')
    elif 'virtualization_type' not in virtual_facts or 'virtualization_role' not in virtual_facts:
        raise Exception('LinuxVirtual: get_virtual_facts: missing keys')
    if virtual_facts['virtualization_role'] not in ('host', 'guest', 'NA'):
        raise Exception('LinuxVirtual: get_virtual_facts: virtualization_role invalid')

# Generated at 2022-06-23 02:15:19.415384
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    assert linux_virtual._facts['virtualization_type'] == 'NA'
    assert linux_virtual._facts['virtualization_role'] == 'NA'
    assert linux_virtual._facts['virtualization_tech_guest'] == set()
    assert linux_virtual._facts['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:15:21.166071
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    LinuxVirtualCollector().collect()

# Generated at 2022-06-23 02:15:23.818190
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual({})
    assert lv
    assert isinstance(lv, LinuxVirtual)



# Generated at 2022-06-23 02:15:25.342343
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert lv != None



# Generated at 2022-06-23 02:15:29.180208
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linuxVirtual = LinuxVirtualCollector()
    assert linuxVirtual._fact_class == LinuxVirtual
    assert linuxVirtual._platform == 'Linux'
    assert linuxVirtual.sources == ['dmi', 'cmdline', 'cgroup']


# Generated at 2022-06-23 02:15:31.180372
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    linux_virtual = LinuxVirtual()
    return linux_virtual

# Unit tests

# Generated at 2022-06-23 02:15:37.465385
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Constructing an object of LinuxVirtualCollector should give a LinuxVirtualCollector object
    x = LinuxVirtualCollector()
    assert isinstance(x, LinuxVirtualCollector)

    # Constructing an object of LinuxVirtualCollector should give a LinuxVirtualCollector object
    x = LinuxVirtualCollector(None)
    assert isinstance(x, LinuxVirtualCollector)

    # Constructing an object of LinuxVirtualCollector should give a FactCollector object
    y = FactCollector()
    x = LinuxVirtualCollector(y)
    assert isinstance(x, LinuxVirtualCollector)

    # Test for platform to be linux
    assert x.platform == 'Linux'


# Generated at 2022-06-23 02:15:42.155460
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector()
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxVirtual
    assert collector.fact_class().get_facts() == {}

# Generated at 2022-06-23 02:15:44.192336
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector(None)
    assert isinstance(collector.facts["virtual"], LinuxVirtual)


# Generated at 2022-06-23 02:15:54.315452
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # LinuxVirtual instantiation
    linux_virtual_instance = LinuxVirtual(dict(), None)
    # Test execution
    virtual_facts = linux_virtual_instance.get_virtual_facts()
    # Assertions
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_type'] is not None
    assert virtual_facts['virtualization_role'] is not None
    assert virtual_facts['virtualization_role'] == 'NA'
    assert isinstance(virtual_facts['virtualization_type'], six.string_types)
    assert isinstance(virtual_facts['virtualization_role'], six.string_types)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:15:57.367353
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """ Test LinuxVirtualCollector class """
    linux_virtual = LinuxVirtualCollector(None)
    assert linux_virtual.platform == 'Linux'


# Generated at 2022-06-23 02:16:01.407749
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test for constructor of class LinuxVirtual
    """
    linuxvirt = LinuxVirtual()
    facts = linuxvirt.populate()
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] in ('host', 'guest', 'NA')


# Generated at 2022-06-23 02:16:04.726478
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # LinuxVirtual class object creation
    linux_virtual = LinuxVirtual(module)

    # get_virtual_facts() method testing
    result = linux_virtual.get_virtual_facts()
    assert result

# Generated at 2022-06-23 02:16:11.263553
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    vm = LinuxVirtual(module)
    expected_virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set()
    }
    virtual_facts = vm.get_virtual_facts()
    assert virtual_facts == expected_virtual_facts
# /Unit test for method get_virtual_facts of class LinuxVirtual


# Generated at 2022-06-23 02:16:15.465608
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test LinuxVirtualCollector constructor
    """
    virtual_module_mock = MagicMock()
    assert isinstance(LinuxVirtualCollector(virtual_module_mock, 'Linux'), LinuxVirtualCollector)

# Generated at 2022-06-23 02:16:26.250689
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    host_data = {}

    host_data['system'] = 'Linux'
    host_data['system_family'] = 'Debian'
    host_data['system_release'] = '7'
    host_data['system_version'] = '71'
    host_data['distribution'] = 'Debian'
    host_data['distribution_version'] = '7.1'
    host_data['distribution_release'] = '7.1'

    host_data['architecture'] = 'x86_64'

    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.host_data = host_data
    module.get_bin_path = MagicMock(return_value='./bin/')

    lv = LinuxVirtual(module)

    assert lv.module == module

# Generated at 2022-06-23 02:16:38.814511
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # FIXME
    mock_module = MagicMock()
    mock_module.run_command = MagicMock()
    mock_module.run_command.return_value = (0, "", "")
    mock_module.get_bin_path = MagicMock()
    mock_module.get_bin_path.return_value = "/usr/bin/dmidecode"
    virtual = LinuxVirtual(mock_module)
    virtual_facts = virtual.get_virtual_facts()

# Generated at 2022-06-23 02:16:42.838449
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual = LinuxVirtualCollector(None)
    assert virtual._fact_class.__name__ == 'LinuxVirtual'
    assert virtual._platform == 'Linux'



# Generated at 2022-06-23 02:16:50.779432
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Testing constructor of class LinuxVirtual
    """
    # Test with invalid module
    module = Mock()
    module.get_bin_path.side_effect = OSError
    with pytest.raises(OSError):
        LinuxVirtual(module)
    # Test with valid module
    module = Mock()
    module.get_bin_path.side_effect = ["/usr/bin/dmidecode"]
    module.run_command.return_value = (0, "", "")
    result = LinuxVirtual(module)
    assert result is not None


# Generated at 2022-06-23 02:16:52.906054
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''Test constructor of LinuxVirtual class'''
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    assert lv.module != None
    assert lv.module.params == module.params


# Generated at 2022-06-23 02:17:02.803780
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Mock module input parameters
    module_params = {}

    # Instantiate LinuxVirtual class
    l_virtual = LinuxVirtual('/tmp', module_ansible_facts=module_params)
    # Call method get_virtual_facts of LinuxVirtual class with a mocked object
    virtual_facts = l_virtual.get_virtual_facts()

    # Assert method get_virtual_facts of class LinuxVirtual
    assert virtual_facts == {
        'virtualization_role': 'NA',
        'virtualization_type': 'NA',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }


# Generated at 2022-06-23 02:17:08.897648
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    linux_virtual = LinuxVirtual(module)
    # Test empty input
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'


# Generated at 2022-06-23 02:17:14.055402
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    module.exit_json(**lv.populate())

# import module snippets
from ansible.module_utils.basic import *

# Main function to kick off processing
if __name__ == '__main__':
    test_LinuxVirtual()

# Generated at 2022-06-23 02:17:19.864294
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)
    lv.populate()
    assert lv.facts['virtualization_type'] == 'NA'
    assert lv.facts['virtualization_role'] == 'NA'
    assert set(lv.facts['virtualization_tech_guest']) == set(['uml'])
    assert set(lv.facts['virtualization_tech_host']) == set(['virtualbox'])


# Generated at 2022-06-23 02:17:28.958945
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test get virtual facts, with bad dmidecode command
    """
    current = LinuxVirtual({})
    current.module = MagicMock()
    current.module.run_command = MagicMock(return_value=(1, '', ''))
    virtual_facts = current.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:17:33.757894
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Unit test
    """

    lv = LinuxVirtual()
    lv.collect()
    print(lv.data)
    print(lv.data['virtualization_role'])


# Run the unit test if invoked as a program
if __name__ == "__main__":
    test_LinuxVirtual()

# Generated at 2022-06-23 02:17:35.750895
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collect = LinuxVirtualCollector()
    assert isinstance(collect, LinuxVirtualCollector)



# Generated at 2022-06-23 02:17:39.764832
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    l_virtual = LinuxVirtual(module)
    assert l_virtual is not None


# Generated at 2022-06-23 02:17:50.239918
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    fact_collector = LinuxVirtualCollector()
    fact_collector.collect()
    assert fact_collector._facts['virtualization_role'] == 'guest'
    assert fact_collector._facts['virtualization_type'] == 'docker'

    assert 'kvm' in fact_collector._facts['virtualization_tech_guest']
    assert 'container' in fact_collector._facts['virtualization_tech_guest']

    assert 'kvm' in fact_collector._facts['virtualization_tech_host']
    assert 'docker' in fact_collector._facts['virtualization_tech_host']
    assert 'container' in fact_collector._facts['virtualization_tech_host']



# Generated at 2022-06-23 02:18:01.655433
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    def get_bin_path_mock(name):
        if name == "lscpu":
            return "lscpu"
        return None

    # Constructor test - case 1: /proc/self/cgroup doesn't exist
    module = AnsibleModuleMock()
    module.get_bin_path = get_bin_path_mock

    with patch("os.path.exists", return_value=False):
        virtual = LinuxVirtual(module)
        assert not virtual.cgroup_exists()

    # Constructor test - case 2: /proc/self/cgroup exists
    with patch("os.path.exists", return_value=True):
        virtual = LinuxVirtual(module)
        assert virtual.cgroup_exists()

    # Constructor test - case 3: /proc/self/cgroup exists but is not

# Generated at 2022-06-23 02:18:06.797570
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Creates an instance of LinuxVirtual
    module = LinuxVirtual()

    # Check return value on LinuxVirtual.get_virtual_facts()
    virtual_facts = module.get_virtual_facts()
    assert virtual_facts == {'virtualization_role': 'host',
                             'virtualization_type': 'NA',
                             'virtualization_tech_guest': set(),
                             'virtualization_tech_host': {'NA'}}

# -- end of code --

# Generated at 2022-06-23 02:18:17.097681
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
  linux_virtual_vendor_fact_file = """
GET /plugins/plugin[@name='LinuxVirtual']/fact[@name='virtualization_role']
  virtualization_role=host

GET /plugins/plugin[@name='LinuxVirtual']/fact[@name='virtualization_type']
  virtualization_type=kvm

GET /plugins/plugin[@name='LinuxVirtual']/fact[@name='virtualization_tech_guest']
  virtualization_tech_guest=RHEV

GET /plugins/plugin[@name='LinuxVirtual']/fact[@name='virtualization_tech_host']
  virtualization_tech_host=kvm
  virtualization_tech_host=RHEV

"""

  import StringIO

# Generated at 2022-06-23 02:18:19.914191
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector(None, None)
    assert lvc._platform == 'Linux'
    assert lvc._fact_class == LinuxVirtual



# Generated at 2022-06-23 02:18:21.885954
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    Test constructing an instance of LinuxVirtual
    '''
    module = AnsibleModule(argument_spec=dict())
    virtual_facts = LinuxVirtual(module)
    assert virtual_facts.get_virtual_facts() == {'virtualization_role': 'NA', 'virtualization_type': 'NA'}

# Generated at 2022-06-23 02:18:29.735286
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    obj = LinuxVirtual(module)
    facts = obj.get_virtual_facts()
    # Provides a set of known facts from a test VM
    assert facts == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(['kvm'])
    }


# Generated at 2022-06-23 02:18:38.574611
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils import basic
    if not basic._ANSIBLE_ARGS:
        args = {}
        basic._ANSIBLE_ARGS = args
    print(LinuxVirtual('test').get_virtual_facts()['virtualization_role'])


# Generated at 2022-06-23 02:18:43.666436
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Create an instance of the class to test
    linux_virtual_ins = LinuxVirtual(module=None)
    truth_virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'docker',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'docker', 'container'}
    }
    assert truth_virtual_facts == linux_virtual_ins.get_virtual_facts()




# Generated at 2022-06-23 02:18:47.272294
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == "Linux"
    assert type(lvc.facts) == dict
    assert lvc.collector == lvc._fact_class



# Generated at 2022-06-23 02:18:51.334485
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModuleMock()
    vcollector = LinuxVirtualCollector(module)
    assert vcollector is not None
    assert vcollector.facts is not None
    assert vcollector.platform == 'Linux'


# Generated at 2022-06-23 02:19:02.213821
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    Test get_virtual_facts method of class LinuxVirtual
    '''
    # Test get_file_content

# Generated at 2022-06-23 02:19:03.784965
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()
    assert lv.module is not None


# Generated at 2022-06-23 02:19:05.294149
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Test module constructor function."""
    LinuxVirtual()



# Generated at 2022-06-23 02:19:07.051332
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    print(linux_virtual.get_virtual_facts())
# Unit test to run all LinuxVirtual methods

# Generated at 2022-06-23 02:19:09.108004
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector._platform == 'Linux'
    assert linux_virtual_collector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:19:09.961506
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:19:14.412472
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # The constructor does not take any arguments
    LVC = LinuxVirtualCollector()
    # Therefore, we check that the object has been created.
    assert LVC is not None


# Generated at 2022-06-23 02:19:16.246764
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    actual = LinuxVirtualCollector()
    assert actual._platform == 'Linux'


# Generated at 2022-06-23 02:19:20.784835
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test LinuxVirtual class constructor
    """
    module = AnsibleModule(argument_spec=dict())
    my_obj = LinuxVirtual(module)
    module.exit_json(changed=False, meta=my_obj.get_virtual_facts())

# Import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 02:19:30.568322
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    linux_virtual = LinuxVirtual(module)
    out = linux_virtual.get_virtual_facts()

    assert isinstance(out, dict)
    assert 'virtualization_type' in out
    assert 'virtualization_role' in out
    assert 'virtualization_tech_guest' in out
    assert 'virtualization_tech_host' in out

    assert isinstance(out['virtualization_tech_guest'], set)
    assert out['virtualization_tech_guest']
    assert isinstance(out['virtualization_tech_host'], set)
    assert out['virtualization_tech_host']


# Generated at 2022-06-23 02:19:33.311073
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_col = LinuxVirtualCollector()
    assert linux_virtual_col.platform == 'Linux'
    assert isinstance(linux_virtual_col.facts, LinuxVirtual)


# Generated at 2022-06-23 02:19:38.412038
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc.platform == 'Linux'
    assert isinstance(lvc.facts, LinuxVirtual)


if __name__ == '__main__':
    # Run the collect() method
    collector = LinuxVirtualCollector()
    print(json.dumps(collector.collect()))

# Generated at 2022-06-23 02:19:41.018040
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """Unit test for constructor of class LinuxVirtual."""

    linux_virtual = LinuxVirtual(dict(module=AnsibleModuleMock()))
    assert isinstance(linux_virtual, LinuxVirtual)


# Generated at 2022-06-23 02:19:43.590939
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    class_name = 'LinuxVirtualCollector'
    c = LinuxVirtualCollector()

    assert c.platform == 'Linux'
    assert c.fact_class == LinuxVirtual

# Generated at 2022-06-23 02:19:50.108723
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mod = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    lv = LinuxVirtual(mod)
    assert(lv.get_virtual_facts() == {
        'virtualization_role': 'host',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': {'xen'}
    })

# Class LinuxService

# Generated at 2022-06-23 02:19:55.524614
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    test_module = AnsibleModuleFake(
        dict(
            config=dict(),
        )
    )
    test_linux = LinuxVirtual(test_module)
    assert isinstance(test_linux, LinuxVirtual)

# Unit tests for gather_virtual_facts()

# Generated at 2022-06-23 02:20:03.644938
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    result = None

    obj = LinuxVirtual()
    try:
        obj.module
    except Exception as e:
        obj.module = MagicMock()
    obj.module.run_command = MagicMock(return_value=(0, "", ""))
    obj.module.get_bin_path = MagicMock(return_value="")
    obj.module.params = {}

    try:
        result = obj.get_virtual_facts()
    except Exception as e:
        pass

    assert isinstance(result, dict)


# Generated at 2022-06-23 02:20:04.869194
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    l = LinuxVirtualCollector()
    assert isinstance(l, LinuxVirtualCollector)

# Generated at 2022-06-23 02:20:07.661945
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """ test class LinuxVirtualCollector """
    with pytest.raises(NotImplementedError):
        LinuxVirtualCollector(None)


# Generated at 2022-06-23 02:20:10.276528
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec=dict())
    linux_virtual = LinuxVirtual(module)
    result = linux_virtual.get_virtual_facts()
    assert result is not None

# Generated at 2022-06-23 02:20:19.196259
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    lv = LinuxVirtual(module)

    # FIXME: Remember that this test is dependent on the system it's running on.
    # This issue is a tradeoff of having a good unit test.
    virtual_facts = lv.get_virtual_facts()
    # Check the key list (in a set)
    assert set(virtual_facts.keys()) == set(['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host'])

    # Check the keys have the value we think they have.
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:20:30.071834
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    args = dict(
        ansible_facts=dict(
        ansible_facts={'ansible_command_module': False, 'ansible_module_name': 'setup'}),
        ansible_module=MagicMock(params=dict()),
        ansible_module_instance=MagicMock()
    )

    module_mock = args['ansible_module']
    module_mock.run_command.return_value = (0, '', '')

    get_file_content_mock = MagicMock()
    get_file_content_mock.return_value = 'value'
    setattr(_module_proxy, 'get_file_content', get_file_content_mock)

    get_file_lines_mock = MagicMock()
    get_file_lines_mock.return_value

# Generated at 2022-06-23 02:20:41.502372
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector.base import BaseFactCollector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda a, **kw: a

        def fail_json(self, a):
            print(a)
            return a

        def get_bin_path(self, a):
            return a

        def run_command(self, a):
            return 0, '', ''

        def get_file_content(self, a):
            return 'content'

    lf = ansible.module_utils.facts.LinuxFactCollector()
   

# Generated at 2022-06-23 02:20:51.320533
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Init LinuxVirtual
    class Args():
        def __init__(self):
            self.gather_subset = 'all'
            self.filter = None
            self.wantlist = True
            self.wants = []


    class module(object):
        def __init__(self):
            self.params = Args()
            self.run_command_environ_update = None
        def get_bin_path(self, path, opt_dirs=[]):
            return None
        def fail_json(self, *args, **kwargs):
            raise AnsibleFailJson(kwargs)
        def run_command(self, cmd, *args, **kwargs):
            return (0, '', '')
        def add_path(self, *args, **kwargs):
            return None

# Generated at 2022-06-23 02:20:56.401295
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule({})
    x = LinuxVirtual(module)
    assert x.get_virtual_facts() == {
            'virtualization_role': 'guest',
            'virtualization_type': 'NA',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set()
    }

#--- Ansible module

# Generated at 2022-06-23 02:21:03.031609
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    vc = LinuxVirtualCollector()
    facts = vc.collect()
    assert 'virtualization_type' in facts.keys()
    assert 'virtualization_role' in facts.keys()
    assert 'virtualization_tech_guest' in facts.keys()
    assert 'virtualization_tech_host' in facts.keys()

# Generated at 2022-06-23 02:21:07.083761
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    module.params = dict()
    l = LinuxVirtual(module)
    virtual_facts = l.get_virtual_facts()
    assert virtual_facts is not False


# Generated at 2022-06-23 02:21:09.810960
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.get_virtual_facts()


# Generated at 2022-06-23 02:21:20.250962
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtualCollector
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    import os
    import pytest
    import shutil
    import tempfile

    # Creating a temp directory
    temp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir, "proc"))
    os.makedirs(os.path.join(temp_dir, "sys/devices/virtual/dmi/id"))

# Generated at 2022-06-23 02:21:25.373604
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    facts = {}
    vird = LinuxVirtual(facts=facts, module=None)
    assert vird.host_tech_set == set()
    assert vird.guest_tech_set == set()
    assert vird.has_virt_subsystem == False
    assert vird.found_virt == False



# Generated at 2022-06-23 02:21:29.753724
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """ This only tests constructor
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict()
    )
    linux_virtual_obj = LinuxVirtual(module)
    assert linux_virtual_obj is not None



# Generated at 2022-06-23 02:21:32.102150
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec={})
    f_obj = LinuxVirtual(module)
    assert f_obj.get_virtual_facts()

# Generated at 2022-06-23 02:21:33.216496
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    instance = LinuxVirtualCollector()
    assert(instance)

# Generated at 2022-06-23 02:21:37.668837
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule({})
    virt_collector = LinuxVirtualCollector(module)
    assert virt_collector._platform == "Linux"
    assert virt_collector._fact_class == LinuxVirtual


# Generated at 2022-06-23 02:21:41.157050
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    lv = LinuxVirtual(module)
    assert lv.get_virtual_facts() == {}

# Generated at 2022-06-23 02:21:47.039133
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    lv = LinuxVirtual(module)
    virtual_facts = lv.get_virtual_facts()
    assert type(virtual_facts['virtualization_tech_guest']) == set
    assert type(virtual_facts['virtualization_tech_host']) == set


# Generated at 2022-06-23 02:21:51.527580
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    from ansible.module_utils.facts.system.distribution import Distribution
    dist = Distribution()
    l = LinuxVirtual(None, dist)
    assert(l.virtual_facts['virtualization_type'] == 'NA')
    assert(l.virtual_facts['virtualization_role'] == 'NA')



# Generated at 2022-06-23 02:21:53.824124
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    lvc = LinuxVirtualCollector()
    assert lvc._fact_class == LinuxVirtual
    assert lvc._platform == 'Linux'



# Generated at 2022-06-23 02:21:59.059095
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtual()
    lv.get_virtual_facts()
# =========================================================================
# END OF MODULE
# =========================================================================

if __name__ == '__main__':
    print ("Invoked from shell")
    print (linux_virtual_facts()['virtualization_type'])

# Generated at 2022-06-23 02:22:01.876737
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    mod = AnsibleModule()
    mod.exit_json = exit_json
    mod.fail_json = fail_json

    pytest_obj = LinuxVirtual(mod)
    pytest_obj.get_virtual_facts()

# Generated at 2022-06-23 02:22:04.277813
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    instance_1 = LinuxVirtual()
    assert not instance_1.module
    assert isinstance(instance_1.distribution, object)


# Generated at 2022-06-23 02:22:06.216505
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    virtual = LinuxVirtual()
    # first check the version of Linux OS
    assert virtual.kernel_version


# Generated at 2022-06-23 02:22:09.062134
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert(isinstance(LinuxVirtualCollector(), LinuxVirtualCollector))



# Generated at 2022-06-23 02:22:12.780085
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_collector = LinuxVirtualCollector()
    assert virtual_collector.platform == 'Linux'
    assert virtual_collector.fact_class == LinuxVirtualCollector._fact_class


# Generated at 2022-06-23 02:22:20.432176
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    tests = (
        (
            dict(),
            dict(virtualization_type='NA', virtualization_role='NA', virtualization_tech_guest=set(), virtualization_tech_host=set())
        ),
    )
    linux_virtual_ins = LinuxVirtual(module)
    for test_input, test_output in tests:
        virt_facts = linux_virtual_ins.get_virtual_facts()
        assert virt_facts == test_output

# Unit test class for class LinuxDistribution

# Generated at 2022-06-23 02:22:21.739771
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    collector = LinuxVirtualCollector(None)
    assert collector.platform == 'Linux'

# Generated at 2022-06-23 02:22:25.192027
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    ''' linux_virtual.py:LinuxVirtual.__init__ '''
    module = AnsibleModule(argument_spec={})
    lv = LinuxVirtual(module)

    # test return code and type
    assert type(lv) == LinuxVirtual


# Generated at 2022-06-23 02:22:27.887952
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModule(argument_spec=dict())
    assert LinuxVirtual(module).virtual() == {}


# Generated at 2022-06-23 02:22:36.511814
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    lv = LinuxVirtual()

    def dummy_run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
        return (0, '', '')

    lv.module.run_command = dummy_run_command

    virtual_facts = lv.get_virtual_facts()

    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    assert virtual_facts['virtualization_role'] != ""
    assert virtual_facts['virtualization_type'] != ""

# Generated at 2022-06-23 02:22:43.238302
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Test Module of LinuxVirtualCollector
    """
    module = AnsibleModule(argument_spec={})
    c = LinuxVirtualCollector(module)
    c.collect()
    facts = c.get_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts


# Generated at 2022-06-23 02:22:54.194173
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    distro_obj = LinuxDistribution()
    lv_obj = LinuxVirtual(module=None, distro=distro_obj)
    distro_obj.detect()
    lv_obj.collect_platform_facts(distro_obj)
    assert lv_obj.module == None
    assert lv_obj.distro == distro_obj
    assert lv_obj.system == 'Linux'
    assert lv_obj.platform == 'Linux'
    assert lv_obj.virtual == dict()
    assert lv_obj.virtual_facts == dict()
    assert lv_obj.get_virtual_facts() == lv_obj.virtual_facts
    assert lv_obj.get_platform_facts() == dict()
    assert lv_obj.get_all_facts() == dict()

# Unit

# Generated at 2022-06-23 02:23:00.140993
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    module = AnsibleModuleMock()
    lvm = LinuxVirtual(module)
    assert lvm.module == module

# Unit tests for function get_file_content

# Generated at 2022-06-23 02:23:08.076156
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    from ansible.module_utils.facts.virtual.linux import LinuxVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualFactCollector
    x = LinuxVirtualCollector()
    assert isinstance(x, VirtualFactCollector)
    assert hasattr(x, '_fact_class')
    assert x._fact_class == LinuxVirtual
    assert hasattr(x, '_platform')
    assert x._platform == 'Linux'
    assert hasattr(x, '_fact_class')
    assert x._fact_class == LinuxVirtual
    assert hasattr(x, '_platform')
    assert x._platform == 'Linux'


# Generated at 2022-06-23 02:23:14.043371
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    module = AnsibleModule(argument_spec={})
    isinstance(LinuxVirtualCollector(module), LinuxVirtualCollector)


# Generated at 2022-06-23 02:23:25.041057
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    '''
    linux_virtual.py

    This is a testing stub to provide a test environment for
    the linux_virtual.py class.
    '''
    ansible_module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list')
        },
        supports_check_mode=True
    )
    if PY3:
        linux_virtual = LinuxVirtual(ansible_module)
        result = linux_virtual.get_virtual_facts()
        ansible_module.exit_json(
            changed=False,
            ansible_facts=dict(virtualization=result))
    else:
        ansible_module.fail_json(msg="py3 is needed for this module")


if __name__ == '__main__':
    test_Linux

# Generated at 2022-06-23 02:23:26.096515
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    facts = LinuxVirtualCollector()
    assert facts.collect() != {}


# Generated at 2022-06-23 02:23:35.952689
# Unit test for constructor of class LinuxVirtual
def test_LinuxVirtual():
    """
    Test the constructor of class LinuxVirtual.
    """

    module = AnsibleModule(argument_spec={'path': dict(type='str', default='/')})

    # Check if we have all the required parameters.
    # We need to define the variables, since we can't access them from within the class.
    wanted_params = {'path': {'type': 'str', 'default': '/'}}
    if module._name == 'linux_virtual':
        module.fail_json(msg=missing_required_lib('ansible.module_utils.facts.system.virtual.linux_virtual'),
                         exception=SystemExit(1))
    else:
        module.fail_json(msg='linux_virtual was not loaded.')

    linux_virtual = LinuxVirtual(module)
    (rc, out, err) = module.run_command

# Generated at 2022-06-23 02:23:45.677115
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    current_directory = os.path.dirname(os.path.realpath(__file__))
    fake_file_path = os.path.join(current_directory, 'test', 'unit', 'ansible_collections', 'ansible', 'os', 'plugins', 'modules', 'system', 'linux_virtual.py')
    fake_cgroup_file_dir = os.path.join(current_directory, 'test', 'unit', 'ansible', 'os', 'plugins', 'modules', 'system')
    mocked_os_path_exists_dict = {fake_file_path: True, fake_cgroup_file_dir: True}
