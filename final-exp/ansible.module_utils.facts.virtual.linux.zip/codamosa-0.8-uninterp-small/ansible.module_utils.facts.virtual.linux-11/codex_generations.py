

# Generated at 2022-06-25 01:13:32.488511
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    tuple_0 = 'LinuxVirtual'
    linux_virtual_0 = LinuxVirtual(tuple_0, tuple_0)
    # get_virtual_facts() is an abstract method, it must be implemented by
    # subclasses.
    try:
        linux_virtual_0.get_virtual_facts()
    except NotImplementedError:
        return True
    except Exception:
        return False
    else:
        return False


# Generated at 2022-06-25 01:13:38.560251
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    tuple_1 = None
    linux_virtual_1 = LinuxVirtual(tuple_1, tuple_1)

    # Invoke get_virtual_facts
    dict_ret_1 = linux_virtual_1.get_virtual_facts()

    # Validate the return value
    assert dict_ret_1 is not None

# Generated at 2022-06-25 01:13:42.516284
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    tuple_0 = None
    linux_virtual_collector_0 = LinuxVirtualCollector(tuple_0, tuple_0)


# Generated at 2022-06-25 01:13:48.015840
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    tuple_0 = None
    linux_virtual_1 = LinuxVirtual(tuple_0, tuple_0)
    linux_virtual_collector_0 = LinuxVirtualCollector(linux_virtual_1)
    assert linux_virtual_collector_0._fact_class is linux_virtual_1
    assert linux_virtual_collector_0._platform == 'Linux'


# Generated at 2022-06-25 01:13:53.128929
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    tuple_0 = None
    linux_virtual_0 = LinuxVirtual(tuple_0, tuple_0)
    tuple_1 = None
    result = linux_virtual_0.get_virtual_facts(tuple_1)
    print(result)


# Generated at 2022-06-25 01:14:03.119147
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """
    Test get_virtual_facts method of class LinuxVirtual
    """
    print("Running get_virtual_facts unit tests")

    # Test #0
    class_inst_0 = LinuxVirtual(None, None)
    linux_virtual_get_virtual_facts_0 = class_inst_0.get_virtual_facts()
    print(linux_virtual_get_virtual_facts_0)
    print(type(linux_virtual_get_virtual_facts_0))

    # Test #1
    class_inst_1 = LinuxVirtual(None, None)
    linux_virtual_get_virtual_facts_1 = class_inst_1.get_virtual_facts()
    print(linux_virtual_get_virtual_facts_1)
    print(type(linux_virtual_get_virtual_facts_1))

    # Test #2

# Generated at 2022-06-25 01:14:05.981699
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    tuple_0 = None
    linux_virtual_0 = LinuxVirtual(tuple_0, tuple_0)
    # No exception thrown
    linux_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:13.297915
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    tuple_0 = None
    linux_virtual_0 = LinuxVirtual(tuple_0, tuple_0)
    virtual_facts = linux_virtual_0.get_virtual_facts()
    if set(virtual_facts.keys()) != set(['virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host']):
        raise Exception("Unexpected keys found in virtual_facts dictionary: %s" % (virtual_facts.keys()))

    if not (isinstance(virtual_facts['virtualization_role'], str) and
        isinstance(virtual_facts['virtualization_type'], str) and
        isinstance(virtual_facts['virtualization_tech_guest'], set) and
        isinstance(virtual_facts['virtualization_tech_host'], set)):
        raise Exception

# Generated at 2022-06-25 01:14:19.823325
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    with pytest.raises(Exception) as e_exception:
        tuple_0 = None
        linux_virtual_0 = LinuxVirtual(tuple_0, tuple_0)
        linux_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:26.685101
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    tuple_0 = None
    linux_virtual_0 = LinuxVirtual(tuple_0, tuple_0)
    facts = linux_virtual_0.get_virtual_facts()
    assert facts['virtualization_role'] == 'host'
    assert 'docker' in facts['virtualization_tech_host']
