

# Generated at 2022-06-25 01:12:25.000147
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert linux_virtual_collector_0.platform == "Linux"
    assert linux_virtual_collector_0._fact_class is LinuxVirtual
    assert linux_virtual_collector_0._fact_class.platform == "Linux"


# Generated at 2022-06-25 01:12:28.258835
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    linux_virtual_collector_1 = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector_1.get_virtual_facts(module)

# Run tests on specified test case ids

# Generated at 2022-06-25 01:12:38.363438
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from mock import patch
    from ansible.module_utils.facts.virtual.linux_virtual \
        import LinuxVirtualCollector
    from ansible.module_utils.facts.virtual.linux_virtual \
        import LinuxVirtual

    linux_virtual_collector = LinuxVirtualCollector()
    setattr(linux_virtual_collector.module, 'run_command',
            lambda x: (0, '', ''))
    setattr(linux_virtual_collector.module, 'get_bin_path', lambda x: '/bin/'+x)
    setattr(linux_virtual_collector, 'get_file_content',
            lambda x: '')
    setattr(linux_virtual_collector, 'get_file_lines',
            lambda x: [])

# Generated at 2022-06-25 01:12:45.954228
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_1 = LinuxVirtualCollector()

    # dmidecode is not available on MacOSX, but it should not fail miserably.
    if get_distribution() == 'MacOSX':
        return

    virtual_facts = linux_virtual_collector_1.get_virtual_facts()

    assert virtual_facts is not None
    assert isinstance(virtual_facts, dict)

    assert 'virtualization_type' in virtual_facts
    assert isinstance(virtual_facts['virtualization_type'], str)

    assert 'virtualization_role' in virtual_facts
    assert isinstance(virtual_facts['virtualization_role'], str)

    assert 'virtualization_tech_guest' in virtual_facts
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)


# Generated at 2022-06-25 01:12:52.742293
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    virtual_facts = (linux_virtual_collector_0.get_virtual_facts()).copy()
    if 'virtualization_type' in virtual_facts:
            virtualization_type = virtual_facts['virtualization_type']
    else:
            virtualization_type = ''
    if 'virtualization_role' in virtual_facts:
            virtualization_role = virtual_facts['virtualization_role']
    else:
            virtualization_role = ''
    if 'virtualization_tech_guest' in virtual_facts:
            virtualization_tech_guest = virtual_facts['virtualization_tech_guest']
    else:
            virtualization_tech_guest = ''
    if 'virtualization_tech_host' in virtual_facts:
            virtualization_

# Generated at 2022-06-25 01:12:57.197741
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # Set of test cases
    tests = [
        ['Test Case 0', 'test_case_0', {}],
    ]

    # Setup logging
    logger = logging.getLogger('Virtual Facts for Linux')
    logger.setLevel(logging.DEBUG)
    # Create and add the console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    logger.addHandler(ch)

    for test in tests:
        description = test[0]
        method = test[1]
        args = test[2]
        getattr(sys.modules[__name__], method)(**args)

if __name__ == '__main__':
    test_LinuxVirtualCollector()

# Generated at 2022-06-25 01:13:08.084718
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector_0.get_virtual_facts()
    if virtual_facts['virtualization_role'] == 'NA':
        if not (virtual_facts['virtualization_type'] == 'NA'):
            raise Exception('Virtualization type should be NA')
    if virtual_facts['virtualization_type'] == 'NA':
        if not (virtual_facts['virtualization_role'] == 'NA'):
            raise Exception('Virtualization role should be NA')
    if virtual_facts['virtualization_role'] == 'host':
        if not ((virtual_facts['virtualization_type'] == 'kvm') or (virtual_facts['virtualization_type'] == 'virtualbox')):
            raise Exception('Virtualization type should be kvm or virtualbox')


# Generated at 2022-06-25 01:13:09.705612
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert issubclass(LinuxVirtualCollector, VirtualCollector)
    assert LinuxVirtualCollector._platform == 'Linux'
    assert LinuxVirtualCollector._fact_class == LinuxVirtual



# Generated at 2022-06-25 01:13:13.039368
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] != None
    assert virtual_facts['virtualization_role'] != None

# Generated at 2022-06-25 01:13:17.925865
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    virtual_facts_dict = linux_virtual_collector_0.get_virtual_facts()
    for key in virtual_facts_dict:
        print("\n{}\n{}\n".format(key, virtual_facts_dict[key]))


if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()