

# Generated at 2022-06-25 01:13:36.293310
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    bool_0 = False
    linux_virtual_0 = LinuxVirtual(bool_0)
    linux_virtual_0.get_virtual_facts()

test_case_0()
test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:13:37.077426
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    os_0 = Os.LinuxVirtualCollector()


# Generated at 2022-06-25 01:13:42.619618
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Assign call
    bool_0 = False
    linux_virtual_0 = LinuxVirtual(bool_0)
    linux_virtual_0.module = mock.MagicMock()
    linux_virtual_0.module.run_command = mock.MagicMock(return_value=(0, '', ''))
    linux_virtual_0.get_file_content = mock.MagicMock(return_value='')
    linux_virtual_0.get_file_lines = mock.MagicMock(return_value=[''])
    dict_0 = {}
    dict_0['ansible_facts'] = {}
    dict_dict_0 = {}
    dict_dict_1 = {}
    dict_dict_0['virtualization_type'] = 'virtualbox'
    dict_dict_1['virtualization_role'] = 'guest'

# Generated at 2022-06-25 01:13:44.092353
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    bool_0 = False
    linux_virtual_collector_0 = LinuxVirtualCollector(bool_0)


# Generated at 2022-06-25 01:13:48.453370
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    bool_0 = False
    linux_virtual_0 = LinuxVirtual(bool_0)
    facts_0 = linux_virtual_0.get_virtual_facts
    assert facts_0


# Generated at 2022-06-25 01:13:59.059198
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.linux_virtual import LinuxVirtual
    # Boolean constructor argument
    bool_0 = False
    linux_virtual_0 = LinuxVirtual(bool_0)

    # Get the virtualization facts before running this test to try to answer some questions.
    before_result = linux_virtual_0.get_virtual_facts()
    assert before_result['virtualization_type'] == 'virtualbox'
    assert before_result['virtualization_role'] == 'guest'

    # Get the virtualization facts after running this test to try to answer some questions.
    after_result = linux_virtual_0.get_virtual_facts()
    assert after_result['virtualization_type'] == 'virtualbox'
    assert after_result['virtualization_role'] == 'guest'

    # Expect the virtualization facts to change

# Generated at 2022-06-25 01:14:01.929434
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert True


# Generated at 2022-06-25 01:14:06.504672
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    bool_0 = True
    linux_virtual_0 = LinuxVirtual(bool_0)
    assert linux_virtual_0.get_virtual_facts() == {'virtualization_type': 'NA', 'virtualization_role': 'NA', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 01:14:11.257367
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    (virtual_facts_actual_rc, virtual_facts_actual) = LinuxVirtual(False).get_virtual_facts()
    assert virtual_facts_actual_rc == 0
    assert 'virtualization_type' in virtual_facts_actual
    assert virtual_facts_actual['virtualization_type'] != ''


######
# main
######

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 01:14:12.500963
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    print('test_LinuxVirtualCollector')
    collector_0 = LinuxVirtualCollector()
    assert collector_0.platform == 'Linux'
