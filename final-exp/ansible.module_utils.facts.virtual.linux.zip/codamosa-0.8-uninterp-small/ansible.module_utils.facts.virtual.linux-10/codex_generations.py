

# Generated at 2022-06-25 01:13:35.073897
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    dict_1 = {}
    linux_virtual_collector_0 = LinuxVirtualCollector(dict_1)

# Generated at 2022-06-25 01:13:38.185083
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    dict_0 = {}
    linux_virtual_0 = LinuxVirtual(dict_0)
    ret = linux_virtual_0.get_virtual_facts()
    assert ret.get('virtualization_role') == "NA"

if __name__ == '__main__':
    test_case_0()
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:13:42.449518
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    dict_0 = {}
    linux_virtual_collector_0 = LinuxVirtualCollector(dict_0)

# Generated at 2022-06-25 01:13:53.830834
# Unit test for constructor of class LinuxVirtualCollector

# Generated at 2022-06-25 01:14:03.871686
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    dict_0 = {"module": None}
    linux_virtual_0 = LinuxVirtual(dict_0)
    dict_1 = linux_virtual_0.get_virtual_facts()
    dict_2 = dict_1.get("virtualization_tech_guest")
    dict_3 = dict_1.get("virtualization_tech_host")
    dict_4 = dict_1.get("virtualization_type")
    dict_5 = dict_1.get("virtualization_role")
    str_0 = "systemd-nspawn"
    assert all((True if dict_2 else False, True if dict_3 else False, True if dict_4 else False, True if dict_5 else False, dict_4 == str_0))


# Generated at 2022-06-25 01:14:06.882595
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    dict_0 = {}
    linux_virtual_0 = LinuxVirtual(dict_0)
    virtual_facts = linux_virtual_0.get_virtual_facts()
    for key, value in six.iteritems(virtual_facts):
        sys.stdout.write(key + ": " + str(value) + "\n")


# Generated at 2022-06-25 01:14:10.921091
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    dict_0 = {}
    obj_0 = LinuxVirtual(dict_0)
    obj_ret = obj_0.get_virtual_facts()
    print(obj_ret)

if __name__ == '__main__':
    test_case_0()
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:14:13.600339
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    dict_0 = {}
    linux_virtual_0 = LinuxVirtual(dict_0)
    result = linux_virtual_0.get_virtual_facts()
    assert type(result) == dict
    # TODO: Add more unittests

if __name__ == "__main__":
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:14:24.272455
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    dict_0 = {}
    dict_0['module'] = ModuleDummy()
    dict_0['set_fs_uuid'] = None
    dict_0['set_host_uuid'] = None
    dict_0['set_product_uuid'] = None
    dict_0['set_hypervisor_uuid'] = None
    dict_0['set_machine_id'] = None
    dict_0['set_dmi_id'] = None
    dict_0['set_virtual_subtype'] = None
    linux_virtual_0 = LinuxVirtual(dict_0)
    virtual_facts_0 = linux_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:14:27.800021
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    dict_0 = {}
    linux_virtual_0 = LinuxVirtual(dict_0)
    dict_virtual_facts_0 = linux_virtual_0.get_virtual_facts()
    assert(dict_virtual_facts_0['virtualization_role'] == 'guest')
