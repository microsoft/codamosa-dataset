

# Generated at 2022-06-25 01:13:45.371601
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_1 = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector_1.get_virtual_facts()

    assert isinstance(virtual_facts, dict)
    assert isinstance(virtual_facts['host_type'], str)
    assert virtual_facts['host_type'] in ('physical', 'virtual')
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert virtual_facts['virtualization_role'] in ('host', 'guest')
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-25 01:13:48.899594
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    linux_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:57.169631
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()

    # Unit test for LinuxVirtualCollector.get_virtual_facts
    # Test will fail if any of the following values are not set:
    # virtualization_type, virtualization_role
    virtual_facts = linux_virtual_collector_0.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

if __name__ == '__main__':
    test_case_0()
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:13:59.324573
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    linux_virtual_collector_0.get_virtual_facts()

test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:14:04.808654
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    assert_equals(linux_virtual_collector_0._platform, 'Linux')
    assert_equals(linux_virtual_collector_0._fact_class, LinuxVirtual)


# Generated at 2022-06-25 01:14:06.914612
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    facts = linux_virtual_collector_0.get_virtual_facts()
    print("Virtualization facts=", facts)


# Generated at 2022-06-25 01:14:08.762746
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert(linux_virtual_collector_0.fact_class() == LinuxVirtual)
    assert(linux_virtual_collector_0.platform() == 'Linux')


# Generated at 2022-06-25 01:14:11.429576
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert True == isinstance(LinuxVirtualCollector(), VirtualCollector), "LinuxVirtualCollector"


# Generated at 2022-06-25 01:14:14.062894
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test case 0
    linux_virtual_collector_0 = LinuxVirtualCollector()
    print("Start: test_LinuxVirtual_get_virtual_facts_0")
    print("Result: " + str(linux_virtual_collector_0.get_virtual_facts()))

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-25 01:14:23.562722
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()

    ret = linux_virtual_collector_0.get_virtual_facts()
    ans = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['docker', 'container', 'kvm']),
        'virtualization_tech_host': set(['kvm', 'docker', 'container']),
    }

    assert ans == ret

if __name__ == '__main__':
    test_case_0()

    test_LinuxVirtual_get_virtual_facts()