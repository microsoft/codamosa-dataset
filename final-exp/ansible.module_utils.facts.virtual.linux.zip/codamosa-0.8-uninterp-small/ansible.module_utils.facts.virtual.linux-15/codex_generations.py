

# Generated at 2022-06-25 01:12:58.925150
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    custom_facts = dict()
    custom_facts['virtualization_type'] = LinuxVirtualCollector.FAKE_VIRT_TYPE
    custom_facts['virtualization_role'] = LinuxVirtualCollector.FAKE_VIRT_ROLE
    module = FakeAnsibleModule(
        custom_facts=custom_facts
    )
    linux_virtual_collector = LinuxVirtualCollector(module=module)
    ret_val = linux_virtual_collector.get_virtual_facts()
    assert ret_val == module.custom_facts


# Generated at 2022-06-25 01:13:06.787397
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Test case 0: LinuxVirtualHost
    linux_virtual_collector_0 = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:13:07.906722
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector is not None


# Generated at 2022-06-25 01:13:18.671716
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    try:
        linux_virtual_collector_0 = LinuxVirtualCollector()
    except Exception as err:
        assert False, "Failed to instantiate LinuxVirtualCollector class due to error - %s" % str(err)
    else:
        assert True


# Generated at 2022-06-25 01:13:20.320597
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    if os.name == "posix" and platform.system() == "Linux":
        print(LinuxVirtualCollector())
    else:
        print("Skip")


# Generated at 2022-06-25 01:13:22.870660
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()


# Generated at 2022-06-25 01:13:28.225445
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector.get_virtual_facts()
    print ("virtual_facts = %s" % virtual_facts)


# Generated at 2022-06-25 01:13:34.098544
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    """
    Constructor of class LinuxVirtualCollector
    """
    linux_collector = LinuxVirtualCollector()
    if linux_collector.platform == 'Linux':
        pass
    else:
        raise Exception("Invalid platform")

    if linux_collector.facts['virtualization_type'] != 'NA':
        raise Exception("Incorrect Virtualization Type")

    if linux_collector.facts['virtualization_role'] != 'NA':
        raise Exception("Incorrect Virtualization Role")


# Generated at 2022-06-25 01:13:35.472860
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    linux_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:39.140788
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_1 = LinuxVirtualCollector()
    virtual_facts_dict_1 = linux_virtual_collector_1.get_virtual_facts()
    assert virtual_facts_dict_1
    virtual_facts_dict_1['virtualization_tech_guest'] = set()
    virtual_facts_dict_1['virtualization_tech_host'] = set()
    print(virtual_facts_dict_1)
