

# Generated at 2022-06-25 01:14:05.122116
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    if LINUX_DISTROS:
        linux_virtual_collector_1 = LinuxVirtualCollector()
        linux_virtual_collector_1.get_virtual_facts()

# Generated at 2022-06-25 01:14:06.442526
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    virtual_collector = LinuxVirtualCollector()
    assert virtual_collector is not None


# Generated at 2022-06-25 01:14:12.643862
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    ansible_virtual_facts_0 = {}
    ansible_virtual_facts_0['virtualization_role'] = 'guest'
    ansible_virtual_facts_0['virtualization_type'] = 'kvm'
    ansible_virtual_facts_0['virtualization_tech_guest'] = 'kvm'
    ansible_virtual_facts_0['virtualization_tech_host'] = ''
    virtual_facts_0 = linux_virtual_collector_0.get_virtual_facts()
    assert virtual_facts_0 == ansible_virtual_facts_0


# Generated at 2022-06-25 01:14:23.387666
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()

    # Test with a baremetal system with vmware tooling installed
    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'NA'
    virtual_facts['virtualization_role'] = 'NA'
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()
    assert linux_virtual_collector_0.get_virtual_facts() == virtual_facts

    # Test with a kvm/qemu/libvirt system
    os.environ["ANSIBLE_VIRTUAL_FILE_SYSTEM"] = "test_kvm_guest"
    module_instance = AnsibleModule(argument_spec={}, supports_check_mode=False)
    module_instance.run_command

# Generated at 2022-06-25 01:14:25.951824
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    result = linux_virtual_collector_0.get_virtual_facts()
    print("TEST PASSED: get_virtual_facts(): %s" % result)

test_case_0()
test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:14:34.856338
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    virtual_facts_0 = linux_virtual_collector_0.get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual_facts_0
    assert virtual_facts_0['virtualization_role'] == 'guest'
    assert virtual_facts_0['virtualization_tech_host'] == {'openvz'}
    assert virtual_facts_0['virtualization_type'] == 'openvz'

# Test to ensure that the set of virtualization_tech_guest is complete for all guests

# Generated at 2022-06-25 01:14:36.265637
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector



# Generated at 2022-06-25 01:14:45.777530
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Test for get_virtual_facts failure case, where file /proc/1/cgroup doesn't exist.
    linux_virtual_collector_0 = LinuxVirtualCollector()
    try:
        shutil.rmtree('/proc/1')
    except Exception:
        pass

    out = linux_virtual_collector_0.get_virtual_facts()

    assert (out['virtualization_type'] == 'physical')

    # Test for get_virtual_facts failure case, where file /proc/self/status doesn't exist.
    linux_virtual_collector_1 = LinuxVirtualCollector()
    try:
        shutil.rmtree('/proc/self')
    except Exception:
        pass

    out = linux_virtual_collector_1.get_virtual_facts()


# Generated at 2022-06-25 01:14:50.489156
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    assert linux_virtual_collector_0.get_virtual_facts() == {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set(['kvm'])}


# Generated at 2022-06-25 01:14:56.918688
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector.get_virtual_facts()
    print("Virtual Facts: " + pprint.pformat(virtual_facts))
