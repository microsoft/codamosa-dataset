

# Generated at 2022-06-25 01:13:13.850760
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_0 = LinuxVirtual()
    linux_virtual_get_virtual_facts_0 = linux_virtual_0.get_virtual_facts()
    for key in linux_virtual_get_virtual_facts_0:
        print("%s : %s" % (key, linux_virtual_get_virtual_facts_0[key]))
    keys = ('virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host', 'virtualization_type')
    assert all(key in linux_virtual_get_virtual_facts_0 for key in keys)


# Generated at 2022-06-25 01:13:17.486369
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    assert linux_virtual_collector_0 is not None
    assert linux_virtual_collector_0._platform == 'Linux'
    assert linux_virtual_collector_0._fact_class == LinuxVirtual


# Generated at 2022-06-25 01:13:21.519943
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    collector = LinuxVirtualCollector()
    # Verifying if the returned values of method get_virtual_facts are same
    # as expected values or not
    assert collector.get_virtual_facts() == {'virtualization_type': 'NA',
                                             'virtualization_role': 'NA',
                                             'virtualization_tech_guest': set(),
                                             'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:13:30.253185
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    # To generate test log
    with open('./ansible_collections/ansible/community/tests/unit/module_utils/network/cloudengine/facts/test_virtual_linux.py.log', 'w') as f_log:
        # To redirect stdout
        sys.stdout = f_log
        test_case_0()

# Unit test execution
if __name__ == '__main__':
    # To generate test log
    with open('./ansible_collections/ansible/community/tests/unit/module_utils/network/cloudengine/facts/test_virtual_linux.py.log', 'w') as f_log:
        # To redirect stdout
        sys.stdout = f_log
        test_case_0()

# Generated at 2022-06-25 01:13:36.169629
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_facts = {
        'virtualization_type': 'NA',
        'virtualization_role': 'NA',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }
    linux_virtual_collector_0 = LinuxVirtualCollector()
    assert isinstance(linux_virtual_collector_0, VirtualCollector)
    assert isinstance(linux_virtual_collector_0, LinuxVirtualCollector)
    assert linux_virtual_collector_0.facts == linux_virtual_facts


# Generated at 2022-06-25 01:13:37.430145
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector.__class__.__name__ == 'LinuxVirtualCollector'


# Generated at 2022-06-25 01:13:41.527825
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector.get_virtual_facts()
    for fact in [
        'virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host',
        'hypervisor_type', 'is_guest'
    ]:
        assert fact in virtual_facts


# Generated at 2022-06-25 01:13:44.640867
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Setup a fixture
    linux_virtual_collector_0 = LinuxVirtualCollector()
    linux_virtual_collector_0.module = None
    linux_virtual_collector_0.facts = {}

    # Call get_virtual_facts of class LinuxVirtual
    linux_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:48.971180
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    assert isinstance(linux_virtual_collector_0, LinuxVirtualCollector)


# Generated at 2022-06-25 01:13:57.794054
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }

    linux_virtual_collector_0 = LinuxVirtualCollector()
    results_0 = linux_virtual_collector_0.get_virtual_facts()
    print('results_0:')
    pprint.pprint(results_0)


if __name__ == '__main__':
    test_case_0()
    test_LinuxVirtual_get_virtual_facts()