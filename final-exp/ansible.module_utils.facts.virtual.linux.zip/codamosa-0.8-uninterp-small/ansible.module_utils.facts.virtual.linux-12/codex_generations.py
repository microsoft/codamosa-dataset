

# Generated at 2022-06-25 01:13:13.144455
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    print("###### Testing get_virtual_facts ######")
    linux_virtual_collector_0 = LinuxVirtualCollector()
    host_tech = set(['uml', 'openvz', 'container'])
    guest_tech = set(['docker', 'lxc', 'podman', 'openvz', 'container', 'uml'])
    virtual_facts = {'virtualization_type': 'uml', 'virtualization_role': 'guest', 'virtualization_tech_guest': guest_tech, 'virtualization_tech_host': host_tech}
    assert linux_virtual_collector_0.get_virtual_facts() == virtual_facts

test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:13:14.695148
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_0 = LinuxVirtual()
    linux_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:17.737964
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector(module=None)
    assert linux_virtual_collector_0._fact_class is LinuxVirtual
    assert linux_virtual_collector_0._platform == 'Linux'


# Generated at 2022-06-25 01:13:19.488637
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_1 = LinuxVirtualCollector()
    assert linux_virtual_collector_1.get_virtual_facts() == {}


# Generated at 2022-06-25 01:13:25.582700
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    # assert linux_virtual_collector_0.platform is 'Linux'
    assert linux_virtual_collector_0._fact_class == LinuxVirtual
    assert linux_virtual_collector_0._platform == 'Linux'


# Generated at 2022-06-25 01:13:28.631755
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # test case 0
    linuxVirtualCollector = LinuxVirtualCollector()
    virtual_facts = linuxVirtualCollector.get_virtual_facts()
    print(virtual_facts)


if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:13:30.767702
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    print("Testing constructor of class LinuxVirtualCollector")
    test_case_0()

# Collect and display all facts

# Generated at 2022-06-25 01:13:38.130502
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    # Test execution
    result = linux_virtual_collector_0.get_virtual_facts()

    # Test assertion (first line to check if the result is not None)
    assert result is not None
    # Test assertion
    assert len(result) == 3
    # Check if the key 'virtualization_role' exists in the result
    assert result.has_key('virtualization_role')
    # Check if the key 'virtualization_type' exists in the result
    assert result.has_key('virtualization_type')
    # Check if the key 'virtualization_tech_guest' exists in the result
    assert result.has_key('virtualization_tech_guest')
    # Check if the key 'virtualization_tech_host' exists in the result
    assert result

# Generated at 2022-06-25 01:13:40.384656
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector_0.get_virtual_facts()
    assert isinstance(virtual_facts, dict) and 'virtualization_tech_guest' in virtual_facts


# Generated at 2022-06-25 01:13:42.484047
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector is not None

