

# Generated at 2022-06-25 01:13:14.440846
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert(LinuxVirtualCollector._platform == 'Linux')
    assert(LinuxVirtualCollector._fact_class == LinuxVirtual)
    assert(LinuxVirtualCollector._fact_name == 'Virtual')


# Generated at 2022-06-25 01:13:16.664918
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert(linux_virtual_collector_0._fact_class == LinuxVirtual)
    assert(linux_virtual_collector_0._platform == 'Linux')

# Generated at 2022-06-25 01:13:18.979678
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_1 = LinuxVirtualCollector()

    assert(linux_virtual_collector_1._platform == 'Linux')
    assert(linux_virtual_collector_1._fact_class == LinuxVirtual)



# Generated at 2022-06-25 01:13:27.023239
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    """Test :meth:`ansible_collections.ansible.community.plugins.module_utils.facts.system.linux_virtual.LinuxVirtual.get_virtual_facts`."""
    linux_virtual_0 = LinuxVirtual()
    facts = {}
    virtual_facts = linux_virtual_0.get_virtual_facts(facts)
    print(virtual_facts)

if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:13:35.560411
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts = {}
    virtual_facts = get_virtual_facts()
    if virtual_facts['virtualization_type'] != 'docker':
        assert False
    if virtual_facts['virtualization_role'] != 'guest':
        assert False
    if 'docker' not in virtual_facts['virtualization_tech_guest']:
        assert False
    if 'lxc' not in virtual_facts['virtualization_tech_guest']:
        assert False
    if 'podman' not in virtual_facts['virtualization_tech_guest']:
        assert False
    if 'openvz' not in virtual_facts['virtualization_tech_guest']:
        assert False
    if 'container' not in virtual_facts['virtualization_tech_guest']:
        assert False

# Generated at 2022-06-25 01:13:37.334253
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector._fact_class == LinuxVirtual
    assert linux_virtual_collector._platform == 'Linux'


# Generated at 2022-06-25 01:13:39.202587
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert isinstance(linux_virtual_collector._fact_class, LinuxVirtual)
    assert linux_virtual_collector._platform == 'Linux'



# Generated at 2022-06-25 01:13:42.085955
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_case_0()

# Run all unit tests

# Generated at 2022-06-25 01:13:43.623446
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    print(linux_virtual_collector_0.get_virtual_facts())


# Generated at 2022-06-25 01:13:52.114305
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    assert linux_virtual_collector_0.get_virtual_facts() == {'virtualization_type': 'kvm', 'virtualization_role': 'host', 'virtualization_tech_host': {'kvm'}, 'virtualization_tech_guest': set()}

if __name__ == "__main__":
    test_LinuxVirtual_get_virtual_facts()