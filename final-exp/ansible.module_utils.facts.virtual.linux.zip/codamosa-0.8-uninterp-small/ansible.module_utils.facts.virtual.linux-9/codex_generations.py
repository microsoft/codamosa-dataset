

# Generated at 2022-06-25 01:13:03.749351
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_1 = LinuxVirtualCollector()

# Generated at 2022-06-25 01:13:05.871153
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector
    assert LinuxVirtualCollector._fact_class == LinuxVirtual
    assert LinuxVirtualCollector._platform == 'Linux'


# Generated at 2022-06-25 01:13:10.553475
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    virtual_facts = LinuxVirtualCollector.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_role' in virtual_facts.keys()

if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()
    test_case_0()

# Generated at 2022-06-25 01:13:15.664205
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual = LinuxVirtual()
    expected_virtual_facts = {
        'virtualization_role': 'host',
        'virtualization_type': 'virtualbox'
    }
    assert linux_virtual.get_virtual_facts() == expected_virtual_facts


# Generated at 2022-06-25 01:13:16.451040
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 01:13:24.682479
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # initialize module_utils
    linux_virtual_collector_1 = LinuxVirtualCollector()

    # mock __init__ parameter
    module = magicMock()
    module.get_bin_path.return_value = "/usr/sbin/dmidecode"
    module.run_command.return_value = (0, "", "")
    module.params = dict()
    module.check_mode = False

    linux_virtual_collector_1.module = module
    assert isinstance(linux_virtual_collector_1.get_virtual_facts(), dict)


# Generated at 2022-06-25 01:13:29.219361
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert isinstance(linux_virtual_collector, LinuxVirtualCollector)


# Generated at 2022-06-25 01:13:34.398717
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    # Create an object of class LinuxVirtual
    linux_virtual_0 = LinuxVirtual()

    # Call method get_virtual_facts of class LinuxVirtual
    virtual_facts = linux_virtual_0.get_virtual_facts()

    if virtual_facts:
        print("Virtual Facts are:")
        for key in virtual_facts:
            print(key, '=', virtual_facts[key])
    else:
        print("virtual facts not available")


# Generated at 2022-06-25 01:13:40.118119
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()


# Generated at 2022-06-25 01:13:41.848888
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    pass
