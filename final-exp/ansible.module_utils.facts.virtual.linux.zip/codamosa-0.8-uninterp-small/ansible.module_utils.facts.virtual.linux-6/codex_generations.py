

# Generated at 2022-06-25 01:13:26.381016
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    tuple_0 = ()
    linux_virtual_collector_0 = LinuxVirtualCollector(tuple_0)
    del linux_virtual_collector_0


# Generated at 2022-06-25 01:13:29.223910
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    tuple_0 = ()
    linux_virtual_collector_0 = LinuxVirtualCollector(tuple_0)
    print(linux_virtual_collector_0)

if __name__ == '__main__':
    test_LinuxVirtualCollector()

# Generated at 2022-06-25 01:13:34.097924
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    tuple_0 = ()
    linux_virtual_0 = LinuxVirtual(tuple_0)
    tuple_1 = ()
    linux_virtual_1 = LinuxVirtual(tuple_1)
    assert isinstance(linux_virtual_1.get_virtual_facts(), dict)

if __name__ == "__main__":
    test_case_0()
    test_LinuxVirtual_get_virtual_facts()
    exit()

# Generated at 2022-06-25 01:13:35.246478
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert LinuxVirtualCollector._platform == 'Linux'


# Generated at 2022-06-25 01:13:39.823246
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    get_virtual_facts = module.get_bin_path.side_effect = ['/usr/sbin/dmidecode', None, None]
    tuple_0 = (module, )
    linux_virtual_0 = LinuxVirtual(tuple_0)
    result_0 = linux_virtual_0.get_virtual_facts()
    assert len(result_0) == 3
    assert result_0['virtualization_role'] == 'host'
    assert result_0['virtualization_type'] == 'virtualbox'


# Generated at 2022-06-25 01:13:49.204601
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    tuple_0 = ()
    linux_virtualcollector_0 = LinuxVirtualCollector(tuple_0)
    dict_0 = linux_virtualcollector_0.collect()
    assert dict_0 == {
        'virtualization_role': 'NA',
        'virtualization_type': 'NA',
        'virtualization_tech_guest':
            ['container', 'hyperv', 'lxc', 'openvz', 'podman', 'xen'],
        'virtualization_tech_host':
            ['hyperv', 'kvm', 'lxc', 'openvz', 'powervm_lx86', 'VMware',
             'xen']}


# Generated at 2022-06-25 01:13:52.989567
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    tuple_0 = ()
    linux_virtual_collector_0 = LinuxVirtualCollector(tuple_0)


# Generated at 2022-06-25 01:13:54.325512
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    test_case_0()

if __name__ == '__main__':
    test_LinuxVirtualCollector()

# Generated at 2022-06-25 01:14:05.551885
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    tuple_0 = ()
    linux_virtual_0 = LinuxVirtual(tuple_0)

    linux_virtual_0.module_dummy = type('', (), {})()
    linux_virtual_0.module_dummy.run_command = MagicMock(return_value=(0, '', ''))
    linux_virtual_0.module_dummy.get_bin_path = MagicMock(return_value=None)
    linux_virtual_0.module = linux_virtual_0.module_dummy

    linux_virtual_0.get_virtual_facts()

    assert linux_virtual_0.module.run_command.call_count == 14
    assert linux_virtual_0.module.get_bin_path.call_count == 1

# Unit tests for method get_file_content of class LinuxVirtual

# Generated at 2022-06-25 01:14:12.959730
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    tuple_0 = ()
    linux_virtual_collector_0 = LinuxVirtualCollector(tuple_0)

if __name__ == '__main__':
    import os
    import sys
    import pytest

    file_path = os.path.realpath(__file__)
    test_dir_path = os.path.dirname(file_path)
    test_dir_path = os.path.join(test_dir_path, "..", "..", "..", "..", "..", "test")

    # For these tests, we need to add the ../../../.. module to sys.path
    test_dir_path = os.path.realpath(test_dir_path)
    ansible_base_path = os.path.dirname(test_dir_path)