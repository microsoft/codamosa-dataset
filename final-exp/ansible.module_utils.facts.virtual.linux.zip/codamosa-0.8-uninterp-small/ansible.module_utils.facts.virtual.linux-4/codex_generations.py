

# Generated at 2022-06-25 01:13:34.798335
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    with pytest.raises(Exception):
        linux_virtual_collector_0 = LinuxVirtualCollector(None)

# Unit test of function get_facts of class LinuxVirtualCollector

# Generated at 2022-06-25 01:13:36.058984
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    assert isinstance(linux_virtual_collector_0, LinuxVirtualCollector)


# Generated at 2022-06-25 01:13:38.069277
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector._platform == 'Linux'
    assert linux_virtual_collector._fact_class == LinuxVirtual


# Generated at 2022-06-25 01:13:41.140402
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    # Tested in docker container
    assert(linux_virtual_collector_0.get_virtual_facts() == {'virtualization_type': 'docker', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'container', 'docker'}, 'virtualization_tech_host': set()})


# Generated at 2022-06-25 01:13:46.574855
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    facts = linux_virtual_collector_0.collect()
    virtualization_tech_guest = facts['virtualization_tech_guest']
    virtualization_tech_host = facts['virtualization_tech_host']
    virtualization_type = facts['virtualization_type']
    virtualization_role = facts['virtualization_role']

# Test calling stand alone module

# Generated at 2022-06-25 01:13:48.203491
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()


# Generated at 2022-06-25 01:13:50.513748
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert type(LinuxVirtualCollector()).__name__ == 'LinuxVirtualCollector'


# Generated at 2022-06-25 01:13:58.252653
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector = LinuxVirtualCollector()
    virtual_facts_dictionary = linux_virtual_collector.get_virtual_facts()
    assert isinstance(virtual_facts_dictionary, dict)
    assert isinstance(virtual_facts_dictionary['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts_dictionary['virtualization_tech_host'], set)
    assert isinstance(virtual_facts_dictionary['virtualization_type'], str)


# Generated at 2022-06-25 01:14:02.331686
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector.get_virtual_facts()
    assert virtual_facts


# Generated at 2022-06-25 01:14:04.731061
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    lv = LinuxVirtualCollector()
    assert 'virtualization_type' in lv.get_virtual_facts()
