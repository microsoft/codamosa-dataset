

# Generated at 2022-06-25 01:13:23.168910
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Initial setup
    linux_virtual_collector_0 = LinuxVirtualCollector()
    # Call function get_virtual_facts
    virtual_facts = linux_virtual_collector_0.get_virtual_facts()
    # Assertions
    assert virtual_facts
    assert isinstance(virtual_facts, dict)
    assert len(virtual_facts) == 4
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert 'NA' in virtual_facts['virtualization_role']
    assert 'NA' in virtual_facts['virtualization_type']
    assert len

# Generated at 2022-06-25 01:13:25.009039
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(LinuxVirtualCollector(), VirtualCollector)


# Generated at 2022-06-25 01:13:33.326587
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector = LinuxVirtualCollector()
    if not linux_virtual_collector.facts_module.facts['virtualization_type']:
        linux_virtual_collector.facts_module.generate_facts()

    linux_virtual = LinuxVirtual(linux_virtual_collector.facts_module)
    virtual_facts = linux_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'NA'
    assert virtual_facts['virtualization_role'] == 'NA'
    assert virtual_facts['virtualization_tech_guest'] == set(['container', 'docker'])
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:13:36.136335
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    with patch('ansible_collections.ansible.community.plugins.module_utils.facts.virtual.LinuxVirtual.collect', side_effect = test_case_0):
        test = LinuxVirtualCollector()
        assert test._fact_class == LinuxVirtual
        assert test._platform == 'Linux'

# Generated at 2022-06-25 01:13:40.619517
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector_0 = LinuxVirtualCollector()

    # Test case-0
    # This is just smoke test because we won't have a RHEV/RHEL VM to test on
    virtual_facts = linux_virtual_collector_0.get_virtual_facts()

    # Below is expected output
    expected_facts = {
        'virtualization_role': 'NA',
        'virtualization_type': 'NA',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set([])
    }

    assert virtual_facts == expected_facts

test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:13:41.531196
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector = LinuxVirtualCollector()
    assert linux_virtual_collector



# Generated at 2022-06-25 01:13:42.236355
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_1 = LinuxVirtualCollector()



# Generated at 2022-06-25 01:13:53.634987
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():

    import shutil
    import tempfile

    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    linux_virtual_collector_test = LinuxVirtualCollector(module)
    # create temporary directory to create fake files
    test_dir = tempfile.mkdtemp()

    # create fake filesystem to test different scenarios
    # create test dir structure
    os.makedirs(os.path.join(test_dir, "sys", "devices", "system", "node"))
    os.makedirs(os.path.join(test_dir, "proc", "1", "cgroup"))
    os.makedirs(os.path.join(test_dir, "dev", "kvm"))

# Generated at 2022-06-25 01:13:58.359531
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert inspect.isclass(LinuxVirtualCollector)
    assert inspect.isclass(LinuxVirtual)
    test_case_0()


# Generated at 2022-06-25 01:14:02.366903
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert linux_virtual_collector_0._fact_class == LinuxVirtual
    assert linux_virtual_collector_0._platform == 'Linux'
