

# Generated at 2022-06-25 01:14:11.700935
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()


# Generated at 2022-06-25 01:14:12.524672
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()


# Generated at 2022-06-25 01:14:19.060474
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    '''
    unit test for method get_virtual_facts of class LinuxVirtual
    '''
    ansible_facts = {}
    linux_virtual_0 = LinuxVirtual(ansible_facts)
    # Call case 0
    linux_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:14:21.314524
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    str_0 = '{'
    linux_virtual_0 = LinuxVirtual(str_0)
    virtual_facts = linux_virtual_0.get_virtual_facts()
    pprint(virtual_facts)



# Generated at 2022-06-25 01:14:23.824601
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()


if __name__ == '__main__':
    test_LinuxVirtualCollector()
    # 'test_case_0' has it's own output, comment off to run it
    test_case_0()

# Generated at 2022-06-25 01:14:25.945269
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    str_0 = '{'
    linux_virtual_0 = LinuxVirtualCollector(str_0)

if __name__ == '__main__':
    test_case_0()
    test_LinuxVirtualCollector()

# Generated at 2022-06-25 01:14:33.931896
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    str_0 = '{'
    linux_virtual_0 = LinuxVirtual(str_0)
    virtual_facts = linux_virtual_0.get_virtual_facts()
    # Type check for variable 'virtual_facts' (line 355)
    assert isinstance(virtual_facts, dict), "Expected a type of <dict> but got {0}".format(type(virtual_facts).__name__)
    # Verify the length of the dictionary
    assert len(virtual_facts) == 3, "Expected length to be 3 but got {0}".format(len(virtual_facts))
    for key in virtual_facts:
        value = virtual_facts[key]
        # Type check for each value of the dictionary

# Generated at 2022-06-25 01:14:35.029289
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    str_0 = '{'
    linux_virtual_collector_0 = LinuxVirtualCollector(str_0)


# Generated at 2022-06-25 01:14:37.264995
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_0 = LinuxVirtualCollector()
    linux_virtual_collector_0.collect()


# Generated at 2022-06-25 01:14:39.246107
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # Instance of class LinuxVirtual for testing
    linux_virtual_0 = LinuxVirtual()
    linux_virtual_0.get_virtual_facts()
