

# Generated at 2022-06-25 01:12:56.914810
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_0 = LinuxVirtual()
    linux_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:13:07.087878
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_collector = LinuxVirtualCollector()
    virtual_facts = linux_virtual_collector.get_virtual_facts()
    print('Virtual Facts: %s' % virtual_facts)

    # For now, just confirm that all the keys are there and are not None
    assert virtual_facts.get('virtualization_type') is not None
    assert virtual_facts.get('virtualization_role') is not None
    assert virtual_facts.get('virtualization_tech_guest') is not None
    assert virtual_facts.get('virtualization_tech_host') is not None

if __name__ == '__main__':
    test_LinuxVirtual_get_virtual_facts()

    test_case_0()

# Generated at 2022-06-25 01:13:08.419083
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    test_case_0()


# Generated at 2022-06-25 01:13:14.293922
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    # FIXME: Improve this test to test all get_virtual_facts return values
    linux_virtual_collector_1 = LinuxVirtualCollector()
    linux_virtual_collector_1.get_virtual_facts()


# ====== Tests ======

# Generated at 2022-06-25 01:13:17.190610
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    assert isinstance(test_case_0()._fact_class, LinuxVirtual), 'Type error: expected LinuxVirtual'
    assert test_case_0()._platform == 'Linux', 'Platform error: expected Linux'


# Generated at 2022-06-25 01:13:21.492032
# Unit test for method get_virtual_facts of class LinuxVirtual
def test_LinuxVirtual_get_virtual_facts():
    linux_virtual_instance_0 = LinuxVirtualCollector()
    virtual_facts = linux_virtual_instance_0.get_virtual_facts()
    if not virtual_facts:
        raise AssertionError("LinuxVirtualCollector is not able to collect virtual facts")


if __name__ == '__main__':
    # Run unit tests for LinuxVirtualCollector and LinuxVirtual
    test_case_0()
    test_LinuxVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:13:25.167448
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_collector_test = LinuxVirtualCollector()
    if linux_collector_test is not None:
        print("\n%sCollector object created successfully%s\n"
              % (Back.GREEN, Style.RESET_ALL))



# Generated at 2022-06-25 01:13:31.003440
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():

    # Test default values in constructor of class LinuxVirtualCollector
    linux_virtual_collector = LinuxVirtualCollector()

    # Check if instance of LinuxVirtualCollector
    assert isinstance(linux_virtual_collector, LinuxVirtualCollector)

    # Check for private and public attributes of LinuxVirtualCollector
    assert json.dumps(sorted(linux_virtual_collector.__dict__.keys())) == '["_fact_class", "_platform", ' \
                                                                          '"_version", "module"]'



# Generated at 2022-06-25 01:13:33.778915
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    print('In test_LinuxVirtualCollector')
    obj = LinuxVirtualCollector()
    assert obj is not None
    assert obj._platform == 'Linux'
    assert obj._fact_class.__name__ == 'LinuxVirtual'


# Generated at 2022-06-25 01:13:35.986919
# Unit test for constructor of class LinuxVirtualCollector
def test_LinuxVirtualCollector():
    linux_virtual_collector_1 = LinuxVirtualCollector()
    assert linux_virtual_collector_1.facts['virtualization_type'] == 'virtualbox' or linux_virtual_collector_1.facts['virtualization_type'] == 'parallels'
