

# Generated at 2022-06-21 01:55:40.287502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.template
    from ansible.module_utils.six import PY2

    action_module = ActionModule(None, ansible.utils.template.Templar({}), PY2)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:55:51.556562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new function from default AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible_collections.misc.not_a_real_collection.plugins.modules.test_module import ActionModule as TestModule
    import os
    import tempfile

    test_args = dict()
    test_args['test_arg'] = "test_argument"
    test_args['test_flag'] = True
    args = dict(ANSIBLE_MODULE_ARGS=test_args, ANSIBLE_MODULE_CONSTANTS=dict())

    temp_dir = tempfile.mkdtemp()
    # temp_file is not a str in Python 3
    temp_file = to_text(tempfile.NamedTemporaryFile(dir=temp_dir).name)

    module = TestModule

# Generated at 2022-06-21 01:55:52.981694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The constructor should take 3 parameters
    am = ActionModule()

    assert isinstance(am, object)
    assert not hasattr(am, 'msg')
    assert not hasattr(am, 'var')
    assert not hasattr(am, 'verbosity')

# Generated at 2022-06-21 01:56:01.278701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule({}, {}, {'verbosity': 1})
    am._templar = FakeTemplar()
    am._display = FakeDisplay()
    am._task = FakeTask()

    # test case 1: verbosity lower than threshold
    am._task.args = {'msg': 'msg text', 'verbosity': 2}
    result = am.run()
    expected_result = {'_ansible_verbose_always': True, 'skipped': True, 'skipped_reason': 'Verbosity threshold not met.'}
    assert result == expected_result

    # test case 2: verbosity out of range, take default value 0
    am._task.args = {'msg': 'msg text', 'verbosity': 10}
    result = am.run()

# Generated at 2022-06-21 01:56:15.277076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.manager import VariableManager

    class AnsibleCallback(CallbackBase):
        """ ansible callback class """
        def __init__(self, *args, **kwargs):
            super(AnsibleCallback, self).__init__(*args, **kwargs)
            self.task_ok = {}
            self.task_unreachable = {}
            self.task_failed = {}
            self.task_skipped = {}
            self.task_status = {}

# Generated at 2022-06-21 01:56:16.803074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write a unit test for method run of class ActionModule
    pass

# Generated at 2022-06-21 01:56:18.426710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, {}), ActionModule)

# Generated at 2022-06-21 01:56:27.337930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule
    """
    # Test for simple structure of task
    task = type('Task', (object,), {'args': {'msg': 'Hello world'}})
    module = ActionModule(task, None)

    assert module._task.args['msg'] == 'Hello world'

    # Test for complex structure of task, i.e. args is a dictionary
    task = type('Task', (object,), {'args': {'var': '1'}})
    module = ActionModule(task, None)

    assert module._task.args['var'] == '1'

    # Test for complex structure of task, i.e. args is a list
    task = type('Task', (object,), {'args': {'var': ['1', '2']}})

# Generated at 2022-06-21 01:56:33.073568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        None, dict(
            action=dict(
                module_name='debug',
                module_args=dict(
                    msg='test_ActionModule',
                )
            ),
            task=dict(
                args=dict(
                    var='hello world!',
                )
            )
        )
    )

    assert action_module is not None
    assert isinstance(action_module, ActionModule)



# Generated at 2022-06-21 01:56:39.713996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test verbosity - 1, msg = 'Hello world!'
    input = {'ansible_verbosity': 1, 'ANSIBLE_DEBUG': True}
    at = ActionModule(None, dict(msg='Hello world!', verbosity=1), task_vars=dict(ansible_verbosity=1, ansible_debug=True))
    result = at.run(None, task_vars=input)
    assert not result['failed']
    assert 'msg' in result

    # test verbosity - 1, var = 'Hello world!'
    input = {'ansible_verbosity': 1, 'ANSIBLE_DEBUG': True}
    at = ActionModule(None, dict(var='Hello world!', verbosity=1), task_vars=dict(ansible_verbosity=1, ansible_debug=True))
    result = at

# Generated at 2022-06-21 01:56:48.538787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except Exception as e:
        raise AssertionError("Failed to instantiate ActionModule: %s" % e)

# Generated at 2022-06-21 01:56:55.798916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook import play
    from ansible.executor.task_queue_manager import TaskQueueManager

    task = Task()
    task._role = Role()
    play_context = play.PlayContext()
    play_context.connection = 'local'
    play_context.network_os = 'default'
    play_context.remote_addr = '192.168.0.1'
    play_context.port = 22
    play_context.remote_user = 'vagrant'
    play_context.password = None
    play_context.private_key_file = None
    play_context.become = False
    play_context.become_method = None


# Generated at 2022-06-21 01:56:56.677148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:57:05.348275
# Unit test for method run of class ActionModule
def test_ActionModule_run():


    class LoaderModule:
        def __init__(self):
            self.paths = None

    class FakeDisplay:
        verbosity = 0

        def v(self, *args, **kwargs):
            return ""


    class FakeTemplar:
        def template(self, *args, **kwargs):
            return ""


    class FakeTask:
        def __init__(self):
            self.args = {'verbosity': 0}

    class FakeActionModule:
        def run(self, *args, **kwargs):
            return {'failed': False}

    class FakeTaskVars:
        def __init__(self):
            self.run_state = {}

    # create object
    action_module = ActionModule()

    # create fake modules
    fake_loader_module = LoaderModule()


# Generated at 2022-06-21 01:57:08.312047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(None, None, {})
    assert a.run()['msg'] == 'Hello world!'

# Generated at 2022-06-21 01:57:16.462434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test = """
- debug:
    msg: "Hello world!"
- debug:
    var: hostvars[inventory_hostname]['ansible_facts']
- debug:
    verbosity: 1
    msg: "Goodbye world!"
- debug:
    var:
        - 1
        - 2
        - 3
- debug:
    var:
        key1: val1
        key2: val2
        key3: val3
- debug:
    var:
        key1: "{{ foo }}"
    vars:
        foo: "{{ 'bar' }}"
"""
    import textwrap
    from six import StringIO
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-21 01:57:18.179434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule(None)
    except Exception as e:
        raise e

# Generated at 2022-06-21 01:57:21.859529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    res = action.run(None, None)
    assert 'failed' in res
    assert res['failed'] is False
    assert 'msg' in res
    assert res['msg'] == 'Hello world!'

# Generated at 2022-06-21 01:57:26.285675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-21 01:57:30.325045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = None
    mock_path = None
    mock_display = None
    mock_templar = None

    print(str(ActionModule(mock_loader, mock_path,mock_display, mock_templar)))

# Generated at 2022-06-21 01:57:52.164728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            try:
                super(TestActionModule, self).run(tmp, task_vars)
            except:
                pass
            return self._task.args

    test_module = TestActionModule(dict(msg='test message'))
    assert test_module.run() == dict(msg='test message')

# Generated at 2022-06-21 01:58:00.136256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Note: The following code is an example of how to unit test actions.  This
# is *not* needed for a production action.  For example, none of ansible's
# actions are unit tested like this.
import ansible.utils.template as template
from ansible.utils import plugin_docs
from ansible.plugins.action import ActionBase
from ansible.plugins.action.debug import ActionModule as debug_amm


# Generated at 2022-06-21 01:58:12.823429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    myTestActionModule = ActionModule()
    myTestActionModule._task = dict()
    myTestActionModule._task.args = dict()
    myTest_task_vars = dict()

    # Test run when msg is in arguments
    myTestActionModule._task.args['msg'] = 'Hello world!'
    assert myTestActionModule.run(task_vars=myTest_task_vars)['msg'] == 'Hello world!'

    # Test run when var is in arguments
    myTestActionModule._task.args['var'] = 'asdf'
    assert myTestActionModule.run(task_vars=myTest_task_vars)['asdf'] == u'VARIABLE IS NOT DEFINED!'

    # Test run when var is in arguments and the var is defined

# Generated at 2022-06-21 01:58:25.258281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=protected-access
    # Check error on both msg and var arguments
    module = ActionModule()
    module._prepare_task_for_act_run('msg', {'msg' : 'some_message', 'var' : 'some_variable'}, {}, task_vars={})
    result = module.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == "'msg' and 'var' are incompatible options"

    # Check error on neither msg nor var
    module._prepare_task_for_act_run('msg', {}, {}, task_vars={})
    result = module.run(tmp=None, task_vars=None)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False



# Generated at 2022-06-21 01:58:26.870400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, {}, {})
    module.run()

# Generated at 2022-06-21 01:58:36.095308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    try:
        clss = ansible.plugins.action.ActionModule
    except ImportError:
        import sys
        from os.path import dirname, abspath
        sys.path.append(dirname(dirname(dirname(abspath(__file__)))))
        import ansible.plugins.action
        clss = ansible.plugins.action.ActionModule
    x = clss("invalid_parameter")
    assert x._VALID_ARGS == frozenset(("msg", "var", "verbosity"))
    x = clss(dict(msg="test_msg"))
    x._task = dict()
    x._task["args"] = dict(msg="test_msg")
    assert x.run()['msg'] == "test_msg"

# Generated at 2022-06-21 01:58:46.821948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook_path = 'test/test_action_debug/test_action_debug.yml'

    playbook = PlaybookExecutor(playbooks=[playbook_path],
                                inventory=inventory,
                                variable_manager=variable_manager,
                                loader=loader,
                                options=None,
                                passwords={})
    result = playbook.run

# Generated at 2022-06-21 01:58:51.653477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = {u'msg': u'Hello world!', u'changed': False, u'_ansible_verbose_always': True}
    assert t == ActionModule(dict(action='debug')).run(task_vars=dict(verbosity=1))

# Generated at 2022-06-21 01:59:03.822689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    input_variables = {
        'msg': 'Hello world!',
        'var': 'my_variable',
        'my_variable': 'my_value',
        'verbosity': 0
    }

    # init ActionModule
    action_module = ActionModule()
    action_module._task = {'args': input_variables}
    action_module._templar = get_templar()

    # call run of class ActionModule
    output_variables = action_module.run(tmp=None, task_vars=input_variables)

    # test run method
    assert output_variables['failed'] == False
    assert output_variables['msg'] == 'Hello world!'


# Generated at 2022-06-21 01:59:16.019984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock dependencies
    import __main__ as mainmod
    import ansible.module_utils.basic as basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.errors import AnsibleUndefinedVariable

    # Declare the Mocks
    class MockDisplay():
        verbosity = 2

    class MockTask():
        def __init__(self):
            self.args = {'msg': 'Hello World'}


# Generated at 2022-06-21 01:59:49.214842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils import basic

    mock_task = mock.Mock()
    mock_task.args = {}
    mock_task.action = 'debug'

    mock_connection = mock.Mock()
    mock_connection.module_implementation_preferences = ('.ps1', '.py')

    mock_display = mock.Mock()
    mock_display.verbosity = 1

    mock_templar = mock.Mock()
    mock_templar.template.return_value = 'test'

    mock_module = mock.Mock()
    mock_module.params = {'msg': 'test'}


# Generated at 2022-06-21 01:59:53.220952
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Ensure that 'print' is a valid action plugin
    assert "print" in ActionBase._action_plugins

    body = {
        'msg': 'Good morning',
        'verbosity': 0,
    }

    # The constructor should not throw an exception.
    ActionModule(body, 'test-host', '/somepath/testfile', {})


# Generated at 2022-06-21 01:59:56.605023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-21 02:00:05.356179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create an instance of AnsibleModule with dummy parameters
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    # Define temporary variables for AnsibleModule
    module._name = 'debug'
    module._aliases = frozenset()
    module._task_vars = {'test_var': 'test_value'}

    # Create an ActionModule with dummy parameters

# Generated at 2022-06-21 02:00:12.013673
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Construct an instance of ActionModule
    module = ActionModule()

    # Data structure to hold the arguments of method 'run'
    args = {'msg': "Hello world!"}

    # Test ActionModule run method
    assert module.run(args)


# Test the above code
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:00:16.695143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_text

    action = ActionModule(task=dict(action=dict(module_name='debug')))
    action.loader = None
    action.templar = None
    action.shared_loader_obj = None

    result = action.run(None, {})
    assert type(result) == TaskResult
    assert result.is_successful()
    assert 'msg' in result._result
    assert result._result['msg'] == u'Hello world!'


# Generated at 2022-06-21 02:00:27.085419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
        Unit test for method run of class ActionModule
    '''
    # Run this unit test with: "ansible-playbook tests/playbooks/unit_tests/lib_utils/action_plugins/test_action_module.yml"

    # Run this unit test.
    # If you have not modified the method run of class ActionModule,
    # this tests should run successfull.
    # As result, you can read the file /tmp/test_action_module.json
    #
    # Nb:
    # * File /tmp/test_action_module.json should be not present.
    # * If this file is present, we delete it
    # * If, at the end of the test, the file is not created, the test fails
    # * If the file is created, we try to read it.
    #   If

# Generated at 2022-06-21 02:00:30.252814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        result = ActionModule.run(ActionModule)
        assert result['failed'] == False



# Generated at 2022-06-21 02:00:35.064033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {
        'name': 'say hello',
        'action': {
            '__ansible_module__': 'debug',
            'msg': 'Hello world!'
        }
    }
    mock_connection = MockConnection()
    module = ActionModule(task, mock_connection)
    assert module.name == 'debug'

# Generated at 2022-06-21 02:00:46.286036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=too-many-function-args
    # args are used to mock
    action_module = ActionModule(None, {}, {}, '', '', '', '', '', None)
    assert not action_module.run()['failed']

    with pytest.raises(Exception) as exception:
        action_module.run({}, None)
        assert "task_vars cannot be None" in exception
    assert not action_module.run({}, {"foo": "bar"})['failed']
    assert not action_module.run({}, {"foo": "bar"}, verbosity=1)['failed']
    assert not action_module.run({}, {"foo": "bar"}, verbosity=1)['failed']

# Generated at 2022-06-21 02:01:33.279968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule("test_module","test_module_args","test_task")
    assert result._task.action == 'test_module'
    assert result._task.args == 'test_module_args'
    assert result._task=='test_task'

# Generated at 2022-06-21 02:01:33.889491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:01:38.152760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.TRANSFERS_FILES == False
    assert isinstance(action_module._VALID_ARGS, frozenset)

# Generated at 2022-06-21 02:01:38.629371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:01:46.672144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json 
    task_vars = {}
    # Adding the 'msg' arg in task.args
    task_args = {"msg" :"Hello world2"}
    # Create a ActionModule object
    actionModule = ActionModule(None, "dummy.yml", task_args, task_vars, None)
    # call method run
    results = actionModule.run(None, task_vars)
    # asserting the type of results is dictionary
    assert isinstance(results, dict)
    # asserting the key "failed" is present in results
    assert "failed" in results
    # asserting the value of results["failed"]
    assert results["failed"] == False
    # asserting the key "_ansible_verbose_always" is present in results
    assert results["_ansible_verbose_always"] == True 
    # asserting

# Generated at 2022-06-21 02:01:47.685860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:01:50.366714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check if object is an instance of ActionModule class
    assert(isinstance(ActionModule, object))

# Generated at 2022-06-21 02:02:01.052325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a test action module
    test_module = ActionModule(None, 'whatever', {}, None, {})
    # create a test results
    test_result = {}
    # define an undefined variable
    test_var = 'this_variable_is_not_defined'
    # add the undefined variable to the current task's argument
    test_module._task.args['var'] = test_var
    # run method 'run' of the test action module
    test_module.run(None, None)
    # capture the result of 'run'
    test_result['var'] = test_module.run(None, None)

    # debug output of the test result, comment the next line of code to hide the test result
    print(test_result)

    # assert if the test result is correct

# Generated at 2022-06-21 02:02:07.212243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Initialize 'task' variable of class ActionModule
    task = {
        'args': {
            'verbosity': 0
        }
    }

    # Create an instance of ActionModule class
    action_module_instance = ActionModule(task, {})

    # Assign value to '_display' variable of class ActionModule
    action_module_instance._display = {
        'verbosity': 0
    }

    # Assign value to '_task' variable of class ActionModule
    action_module_instance._task = {
        'args': {
            'verbosity': 0
        }
    }

    # Call method 'run' of class ActionModule
    value = action_module_instance.run({}, {})

    # Check the output
    assert value['_ansible_verbose_always'] == True

# Generated at 2022-06-21 02:02:14.378664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize some objects for test
    class FakeDisplay:
        class FakeOptions:
            verbosity = 0
        verbosity = 0
        options = FakeOptions()
    fake_display = FakeDisplay()
    class FakeTask:
        def __init__(self, args):
            self.args = args
    fake_task = FakeTask({'msg': 'Hello world!'})
    class FakeTemplar:
        def __init__(self, task_vars):
            self.task_vars = task_vars
        def template(self, *args, **kwargs):
            return args[0]
    fake_templar = FakeTemplar({'msg': 'Hello world!'})
    class FakeActionBase:
        def run(self, tmp, task_vars):
            return False

# Generated at 2022-06-21 02:04:38.483870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #assert not ActionModule()
    pass

# Generated at 2022-06-21 02:04:45.874969
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:04:55.755133
# Unit test for constructor of class ActionModule
def test_ActionModule():
  import sys
  import os

  sys.path.append(os.path.join('..','plugin','action','module','lib'))

  import json

  from ansible.plugins.action.debug import ActionModule

  # Create a test action and run
  #
  # Create invalid task
  task = "not a dict"
  # Create fake connection
  connection = "not a dict"
  # Create fake play_context
  play_context = "not a dict"
  # Create a ActionModule object with above invalid task and connection
  testAction = ActionModule(task, connection, play_context)
  # Create fake variable manager and templar
  variable_manager = "not a dict"
  templar = "not a dict"
  # Run the test action
  result = testAction.run(variable_manager, templar)



# Generated at 2022-06-21 02:05:08.002073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1, Execution completed successfully.

    # mock class for module_utils.common
    class MockCommon(object):
        class module_common(object):
            def __init__(self, argument_spec, bypass_checks):
                self.params = dict()
                self.res = dict()

    # mock class for module_utils.common
    class MockCommand(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False, check_invalid_arguments=True,
                     mutually_exclusive=None, required_together=None, required_one_of=None, add_file_common_args=False,
                     supports_check_mode=False, required_if=None):

            self.params = dict()
            self.res = dict()

    # mock class for ActionBase
   

# Generated at 2022-06-21 02:05:08.616766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t is not None

# Generated at 2022-06-21 02:05:12.977321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    action_module=action_loader.get('debug')
    assert action_module.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-21 02:05:26.933081
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    sys.path.append("../")
    from ansi.ansible.plugins.action import _action_module

    # Test case 1
    # pass valid values
    # msg
    task_args1 = {'msg': 'Hello world!'}
    task_vars1 = {}
    display1 = Display()
    templar1 = Templar(loader=None, variables=task_vars1)
    task1 = Task(args=task_args1)
    am1 = _action_module.ActionModule(task1, display1, templar1)
    am1._connection = Connection()
    am1._loader = None
    am1._templar = templar1
    result1 = am1.run(tmp=None, task_vars=task_vars1)