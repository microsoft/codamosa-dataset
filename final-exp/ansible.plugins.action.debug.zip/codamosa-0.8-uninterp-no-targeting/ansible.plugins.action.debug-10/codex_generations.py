

# Generated at 2022-06-21 01:55:43.927879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # AnsibleModule argument requires 'argument_spec' as a dict.
    module = ActionModule.ActionModule(
        dict(
            argument_spec = dict(
                msg = dict(type='str'),
                var = dict(type='str', aliases=['name']),
                verbosity = dict(type='int', default=0),
            ),
            supports_check_mode=False
        )
    )
    assert len(module._templar._available_variables) == 0
    assert ActionModule.TRANSFERS_FILES is False
    assert module._VALID_ARGS == frozenset(['msg', 'var', 'verbosity'])


# Generated at 2022-06-21 01:55:47.449377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass
        # obj = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_path=None, shared_loader_obj=None,
        #         variable_manager=None, template_loader=None)
        # assert obj is not None, "Failed to instantiate ActionModule"

# Generated at 2022-06-21 01:55:47.887024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-21 01:55:50.454381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None


# Generated at 2022-06-21 01:55:55.833703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # _VALID_ARGS definition
    valid_args = frozenset({'msg', 'var', 'verbosity'})
    assert (valid_args == ActionModule._VALID_ARGS)

    # Loaded module definition
    assert (ActionModule.TRANSFERS_FILES == False)

# Generated at 2022-06-21 01:56:04.143772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    task = Task()
    task._role = None
    task.args = {'msg': 'test_msg'}
    task.action = 'debug'

    my_vars = VariableManager()

    debug_mod = ActionModule(task, my_vars)
    assert debug_mod.run(task_vars=my_vars) == {'failed': False, 'msg': 'test_msg', '_ansible_verbose_always': True}

    # test msg option and verbosity
    task.args = {'msg': 'test_msg', 'verbosity': 2}
    debug_mod = ActionModule(task, my_vars)
    assert debug_mod.run(task_vars=my_vars)

# Generated at 2022-06-21 01:56:13.993245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init setup
    action_module = ActionModule(None, None)
    action_module._task = {'args' : {'msg':'Hello class', 'verbosity':1}}
    action_module._display = {'verbosity': 1}

    # setup expected result
    expected = {'failed': False, 'msg': 'Hello class', '_ansible_verbose_always': True}

    # perform actual test
    result = action_module.run(None, None)

    # assert test result and expected result
    assert result == expected

# Generated at 2022-06-21 01:56:15.649010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    print(action.run())

# Generated at 2022-06-21 01:56:23.563227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    _task = Task()
    _task.action = 'debug'
    _task.args = {
        'msg': 'test message',
        'verbosity': 2,
    }

    am = ActionModule(task=_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    result = am.run(tmp='/var/tmp', task_vars={'var': 'test_variable'})

    assert 'msg' not in result
    assert result['skipped'] == True
    assert result['skipped_reason'] == 'Verbosity threshold not met.'
    assert result['failed'] == False



# Generated at 2022-06-21 01:56:34.403575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockActionBase(object):
        def __init__(self):
            self.task = dict()
            self.task['args'] = dict()
            self.task['args']['verbosity'] = 3

            self.display = dict()
            self.display['verbosity'] = 2

    instance = ActionModule()
    instance._task = dict()
    instance._task['args'] = dict()
    instance._task['args']['msg'] = 'Hello world!'

    # modify parent class
    instance._templar = MockActionBase()
    instance.run()
    assert instance.run() == {
        '_ansible_verbose_always': True,
        'msg': 'Hello world!',
        'failed': False,
    }

    instance._task['args']['msg'] = None
    instance._task

# Generated at 2022-06-21 01:56:43.900626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    obj = ActionModule()
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-21 01:56:54.144711
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:57:04.434301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            msg = dict(type='str', required=False),
            var = dict(type='str', required=False),
            verbosity = dict(type='int', required=False, default=0)
        )
    )
    module.params['_ansible_verbosity'] = 0
    ActionModule._ANSIBLE_ARGS = None
    action_base = ActionBase()
    action_base._task = module
    action_module = ActionModule(action_base._task, action_base._connection, action_base._play_context, action_base._loader)
    action_module._display.verbosity = 0


# Generated at 2022-06-21 01:57:08.539199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    a = action.ActionModule(None, dict(), None, '', 0, 0, '')

    a._task.args = dict(msg=u'Hello')
    a._display = Display()
    a._display.verbosity = 0
    res = a.run({}, {})
    assert isinstance(res.get('msg'), AnsibleUnsafeText)
    assert res.get('msg') == u'Hello'
    assert res.get('failed') is False

    a._task.args = dict(msg=u'Hello')
    a._display = Display()
    a._display.verbosity = 1

# Generated at 2022-06-21 01:57:16.591477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    # Create a task to pass to the ActionModule
    task = dict(action=dict(module='debug', msg='Hello world!'))

    # Create a play to pass to the TaskQueueManager
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [dict(action=dict(module='debug', msg='Hello world!'))]
        )

# Generated at 2022-06-21 01:57:19.727160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct an instance of AnsibleTask
    a = ActionModule()

    # check if a is instance of ActionBase
    assert isinstance(a, ActionBase)


# Generated at 2022-06-21 01:57:31.800847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for class ActionModule
    am = ActionModule('Test_path/ansible/plugins/action', 'action_path', 'module_name', {'msg': 'hello', 'var': 'world'})
    assert am
    assert am._task.args['var'] == 'world'
    assert am._task.args['msg'] == 'hello'
    assert not am._task.action
    assert am._task.action_plugin_name == 'module_name'
    assert am._task.action_loader_name == 'action_path'
    assert am._task.module_name == 'module_name'
    assert am._task.module_loader_name == 'action_path'
    assert am._task.path_name == 'Test_path/ansible/plugins/action'



# Generated at 2022-06-21 01:57:40.263573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("in test_ActionModule")
    mod = ActionModule(action=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print("result = %s"%mod.TRANSFERS_FILES)
    print("result = %s"%str(mod._VALID_ARGS))

# Generated at 2022-06-21 01:57:48.973489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils
    from ansible.utils import plugins
    from collections import namedtuple

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, variable_manager=variable_manager,  host_list='tests/inventory')
    variable_manager.set_inventory(inventory)

    Options = namedt

# Generated at 2022-06-21 01:57:58.948970
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize test variables and compute expected result
    test_var = {'test_var': 'test_value'}
    test_msg = 'test message'
    result = {'failed': False, 'msg': test_msg}

    # Check that verbosity=1 and corresponding verbosity=0, provide the expected results
    for test_verbosity in range(2):
        task_vars = test_var
        task_vars['verbosity'] = test_verbosity
        action_module = ActionModule({'var': 'test_var', 'msg': test_msg, 'verbosity': test_verbosity}, {}, None, None, None)
        assert action_module.run(task_vars=task_vars) == result

    # Check that verbosity=2 provides the expected results
    test_verbosity = 2
    task_

# Generated at 2022-06-21 01:58:15.841387
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Setup the bare class.
    action_mod = ActionModule()

    assert 'msg' in action_mod._VALID_ARGS
    assert 'var' in action_mod._VALID_ARGS
    assert 'verbosity' in action_mod._VALID_ARGS

# Generated at 2022-06-21 01:58:26.225245
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.connection import Connection
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.cli import CLI
    from ansible.executor.task_executor import TaskExecutor

    # Define a role to use
    class Role:
        def __init__(self, name, tasks=None):
            self.name = name
            self.tasks = tasks
        def __getitem__(self, name):
            return self.tasks

    # Define a task to use
   

# Generated at 2022-06-21 01:58:27.102871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:58:31.218870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    results = module.run(None, dict())
    assert results.get('failed') is False
    assert results.get('msg') == 'Hello world!'

    results = module.run(None, dict())
    assert results.get('failed') is False
    assert results.get('msg') == 'Hello world!'

# Generated at 2022-06-21 01:58:44.936006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock as m

    # Unit test configuration
    # Inject mock variables
    inject = {'tmp': None, 'task_vars': {}}
    # Inject mock modules
    m_modules = {
        'ansible.plugins.action.ActionBase': m.MagicMock(ActionBase),
        'ansible.module_utils.six.string_types': string_types,
        'ansible.module_utils._text.to_text': to_text,
        'ansible.errors.AnsibleUndefinedVariable': AnsibleUndefinedVariable,
    }

    with m.patch.dict('sys.modules', m_modules):
        from ansible.plugins.action import debug as debug_module

        # Create instance of class ActionModule
        action_module = debug_module.ActionModule(None, None, inject)
        action

# Generated at 2022-06-21 01:58:51.565772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict()
    args['msg'] = 'Hello world!'
    args['verbosity'] = 0
    task = dict(action=dict(module='debug', args=args))
    result = ActionModule(task, dict()).run(dict(), dict())

    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'

# Generated at 2022-06-21 01:58:52.293602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:59:01.238137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    tmp = None
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'


# Generated at 2022-06-21 01:59:02.621108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unittests
    return


# Generated at 2022-06-21 01:59:15.563570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.debug import ActionModule
    class Task:
        def __init__(self):
            self.args = None
        def set_loader(self, loader):
            pass
    class PlayContext:
        pass
    class Play:
        def __init__(self):
            self.context = PlayContext()
    class Host:
        pass
    class Runner:
        def __init__(self):
            self.host_vars = {}
    class Connection:
        pass
    class Display:
        def __init__(self):
            self.verbosity = 0
    class Loader:
        def __init__(self):
            self.templates = None
    class TaskQueueManager:
        def __init__(self):
            self.host_vars = {}

# Generated at 2022-06-21 01:59:43.171062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 01:59:55.970144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init class
    am = ActionModule(
        task=dict(
            args=dict(
                var='{{var1}}',
                verbosity=0
            )
        )
    )
    assert am is not None

    # result of execution
    result = am.run(task_vars=dict(var1='Hello world!'))
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False

    # result of execution
    result = am.run(task_vars=dict(var1='Hello world!'))
    assert result['skipped_reason'] == 'Verbosity threshold not met.'
    assert result['skipped'] == True

    # result of execution

# Generated at 2022-06-21 01:59:56.365883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:00:00.489729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(load_fixture='test_action_ping.yml',
                          templar=None,
                          shared_loader_obj=None)
    assert module

# Verify 'ansible.utils.module_docs_fragments.ACTION_DOCS' dictionary is updated

# Generated at 2022-06-21 02:00:03.057383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    module = ActionModule(task=dict(args=dict(verbose=1)))
    assert module._task['args']['verbose'] == 1


# Generated at 2022-06-21 02:00:15.608628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Modules are not supposed to be run directly, so we need to mock the parts of an
    # action plugin.
    from ansible.playbook.task import Task

    class ActionModuleForTest(ActionModule):
        def load_file_common_arguments(self):
            pass

    task = Task()
    # The name of the module is the same as the class.
    task.action = 'ActionModuleForTest'
    # There is no task.args in a real Task instance, so we need to add it.
    task.args = dict()
    # The class needs to know it's _task so set it here.
    am = ActionModuleForTest(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # We also need to mock the display class so that

# Generated at 2022-06-21 02:00:25.595083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
        Unit test for constructor of class ActionModule
    '''
    obj = ActionModule(None, {}, {}, None)
    assert str(obj) == '<ActionModule None>'
    assert repr(obj) == '<ActionModule None>'
    assert obj.TRANSFERS_FILES == False
    assert obj.result == {}
    assert obj._task.name == None
    obj._display.verbosity = 0
    assert obj.task_vars == {}
    assert obj.tmpdir == None
    assert obj.task_vars == {}
    assert isinstance(obj.runner, object)

# Generated at 2022-06-21 02:00:36.974166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_action_module test case
    ansible = Ansible()
    ansible.PlayContext()
    ansible.runner = Runner()
    ansible.inventory = Inventory()
    ansible.inventory.add_host('localhost')
    ansible.inventory.get_host('localhost').set_variable('foo', 'foovalue')
    ansible.play = Play()
    ansible.play.play_context = ansible.play_context

    # Test with no argument
    task = Task()
    task.set_loader(DictDataLoader())
    task.args = dict()
    task_vars = dict()
    am = ActionModule(task, connection=None, play_context=ansible.play_context, loader=ansible.loader, templar=ansible.templar, shared_loader_obj=None)

# Generated at 2022-06-21 02:00:47.835704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import modules.test
    import modules.test.test_debug as debug_test
    import modules.test.test_action as action_test
    import sys
    import copy

    # create a mock display class
    class MockDisplay:
        def __init__(self, verbosity):
            self.verbosity = verbosity
            self.verbose = []

        def vv(self, msg, host=None):
            self.verbose.append(msg)

    # create a mock task class
    class MockTask:
        def __init__(self, args):
            self.args = args
            self.no_log = ''

    # create a mock templar class
    class MockTemplar:
        def __init__(self):
            self.fail_on_undefined = True
            self.convert_bare = True

# Generated at 2022-06-21 02:00:49.799934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule(load_plugins=False) is not None)

# Generated at 2022-06-21 02:01:39.964075
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:01:49.686583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockActionModule(ActionModule):
        def run(self, tmp, task_vars):
            return ActionModule.run(self, tmp, task_vars)
    am = MockActionModule({}, {'playbook_dir': '', 'playbook_path': ''}, load_plugins=False)

    assert am._VALID_ARGS>= frozenset(('msg', 'var', 'verbosity'))
    assert am._VALID_ARGS <= frozenset(('msg', 'var', 'verbosity'))

    am = MockActionModule({
                            "var": "test",
                            "verbosity": 1
                          }, {'playbook_dir': '', 'playbook_path': ''}, load_plugins=False)


# Generated at 2022-06-21 02:01:53.356301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #action module constructor
    am = ActionModule(task_vars=dict())
    #test against the correct object type
    assert type(am) == ActionModule

# Generated at 2022-06-21 02:01:55.341488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None)
    assert module is not None


# Generated at 2022-06-21 02:02:04.729762
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class StubTemplar(object):
        def template(self, templatevar, convert_bare, fail_on_undefined):

            if isinstance(templatevar, list) or isinstance(templatevar, dict):
                return 'test_list_dict'

            if templatevar == '{{test_msg}}':
                return templatevar

            if templatevar == 'test_msg':
                return 'test_msg_template'

            if templatevar == 'test_msg_verbosity':
                return 'test_msg_verbosity_template'

            if templatevar == 'undefined_var':
                return 'VARIABLE IS NOT DEFINED!'

            if templatevar == '{{not_exist_var}}':
                return 'VARIABLE IS NOT DEFINED!'


# Generated at 2022-06-21 02:02:07.324037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    assert isinstance(ActionModule(), ActionModule)


# Generated at 2022-06-21 02:02:10.381161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None)
    assert isinstance(a._VALID_ARGS, frozenset)

# Generated at 2022-06-21 02:02:20.866855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    
    # Create a fake task
    task=Task()
    task.args=dict(msg='Hello world!')
    
    # Create a fake display
    display=object()
    display.verbosity=1
    
    # Create a fake templar
    templar=object()
    
    # Instantiate the plugin class
    action_module=ActionModule(task, display, templar)
    
    # Run the plugin method run
    result=action_module.run()
    
    # Assert the result
    assert result['failed'] is False
    assert result['_ansible_verbose_always'] is True
    assert result['msg'] == 'Hello world!'



# Generated at 2022-06-21 02:02:21.845728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:02:23.517571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES is False
    assert ActionModule._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))


# Generated at 2022-06-21 02:04:35.678395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:04:44.735606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils import basic
    from ansible.module_utils.debug import AnsibleDebug

    ActionModule._ANSIBLE_ARGS = basic.AnsibleModuleArgs(args_path='./test_module.args')
    ActionModule._display = AnsibleDebug('./test_module.args')

    action_module = ActionModule(task=dict(action=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_module.__class__ == ActionModule
    assert action_module._task.action['_uses_shell'] == True
    assert action_module._task.action['_raw_params'] == 'echo "Hello world!"'



# Generated at 2022-06-21 02:04:54.734902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create task to test constructor
    task_to_test = dict(action=dict())
    task_to_test['action']['__ansible_module__'] = "debug"

    # Construct a class from a task
    task_instance = ActionModule(task_to_test, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Check result
    assert task_instance._name == "debug", "ActionModule has wrong name, expected=debug, actual=%s" % task_instance._name

# Generated at 2022-06-21 02:05:06.829721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import os

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager.set_inventory(inventory)

    inventory.add_host(host='hostname')
    host = inventory.get_host('hostname')
    host.set_variable('ansible_connection', 'local')

    playbook_path = u'some/file.yml'
    variable_manager.extra_vars = {'hostname': 'me', 'group_name': 'me'}


# Generated at 2022-06-21 02:05:08.238741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None)
    assert(a is not None)

# Generated at 2022-06-21 02:05:13.357802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    def run_test(test, mock_args=None, mock_kwargs=None, mock_task=None):
        '''
        Handle the definition of a test case

        :arg test: Dictionary containing the setup and the test elements of a single test case to execute.

        :kwarg mock_args: Arguments to pass to the method being tested instead of the default values.

        :kwarg mock_kwarg: Keyword arguments to pass to the method being tested instead of the default values.

        :kwarg mock_task: Mock task object to use as the task object to be run by the action
        '''
        import json
        from ansible.playbook.task_include import TaskInclude
        from ansible.playbook.task import Task

# Generated at 2022-06-21 02:05:26.977716
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class Options(object):
        def __init__(self, args=None):
            if args is None:
                args = []
            self.args = args

    class FakeTask(object):
        def __init__(self, args=None):
            self.args = dict()
            if args is not None:
                self.args = args

    class FakePlayContext(object):
        def __init__(self):
            self.verbosity = 0

    class FakeLoader(object):
        pass

    class FakeTemplar(object):
        def __init__(self):
            self.definitions = dict()

        def template(self, value, convert_bare=True, fail_on_undefined=True, overrides=None):
            return self.definitions[value]
