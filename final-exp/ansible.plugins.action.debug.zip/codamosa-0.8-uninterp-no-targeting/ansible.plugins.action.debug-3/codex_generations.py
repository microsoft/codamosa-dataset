

# Generated at 2022-06-21 01:55:41.472000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    assert action_module1.__name__ == 'action_module1'
    act_module1 = action_module1()
    assert isinstance(act_module1, ActionModule)
    assert action_module1.TRANSFERS_FILES == False
    assert act_module1._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))



# Generated at 2022-06-21 01:55:52.007676
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 01:56:01.013987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import collections
    import os
    import json
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.debug import ActionModule
    from ansible.plugins.action.debug import ActionModuleException

    # Mock variables for a task
    mock_task_vars = {
        'a': 1,
        'b': 'hello',
        'c': [1,2,3],
        'd': {
            'a': 1,
            'b': 'hello'
        }
    }

    # Mock variables for runtime environment
    mock_config = mock.MagicMock()
    mock_config.verbosity = 0

    mock_loader = mock.MagicMock()

    mock_templar = mock.MagicMock()

# Generated at 2022-06-21 01:56:02.460437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = True
    return result

# Generated at 2022-06-21 01:56:03.849766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #this test is a stub
    assert 1==1

# Generated at 2022-06-21 01:56:17.328932
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import mock
    import os
    import sys

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.action import ActionBase

    # A bit hacky but ActionBase is an old-style class so can't use super()
    # Patch the ActionBase.run method so we don't run the actual action portion
    def run_action_base_mock(self, *args, **kwargs):
        return {}

    ActionBase.run = run_action_base_mock

    # Put these imports under the patched ActionBase so we can mock
    # run_action_base_mock
    from ansible.plugins.action import ActionModule

    # Put this import under the mock_import block so we can mock
    # the ActionModule base class

# Generated at 2022-06-21 01:56:21.761008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    # Run tests
    assert mod.run()
    # Success
    assert mod.run(task_vars={"a": "b"})
    # Failure
    assert mod.run(task_vars={"a": "b"})

# Generated at 2022-06-21 01:56:33.488791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The commented lines are the unit test for the methods of the class
    # you can run the test using this command: python action_plugin.py -v
    #
    # all the unit test method must start with the prefix test_
    #
    # if you want to generate a custom excepthook to manage the exception
    # generated in the unit test (when you run this file as a script),
    # use this syntax:
    #
    # def excepthook(type, value, traceback):
    #    # your code
    # sys.excepthook = excepthook
    #

    # import modules used by this unit test
    import sys
    sys.path.append('/home/travis/build/ansible/ansible/lib/ansible/plugins/action')
    from test_utils import ActionModuleTestCase

# Generated at 2022-06-21 01:56:42.733477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t_module_args = {'msg': 'test', 'verbosity': 2}
    t_task_vars = {'verbosity': 2}
    t_loader = None
    t_paths = ''
    t_display = None
    t_templar = None

    action_module = ActionModule(
        t_module_args, t_task_vars, t_loader, t_paths, t_display, t_templar)
    assert 'msg' in action_module._task.args
    assert 'verbosity' in action_module._task.args
    assert not 'failed' in action_module.run(None, t_task_vars)

# Generated at 2022-06-21 01:56:49.887193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    the_params = {}
    the_params['msg'] = 'Hello world!'
    the_params['verbosity'] = 0
    the_module = ActionModule(the_params, '', '', '', '', 'localhost')
    assert the_module.run() == {
        'failed': False,
        'msg': 'Hello world!',
        '_ansible_verbose_always': True
    }

# Generated at 2022-06-21 01:56:58.636373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   module = ActionModule()
   results = module.run()
   assert(results.get('failed')==False)

# Generated at 2022-06-21 01:57:06.012217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import Mock, patch
    mock_task_args = {'msg': 'hello world'}
    mock_task_args1 = {'var':'variable_name'}
    mock_task_args2 = {'var': [1,2,3]}
    mock_task_args3 = {'var': {'Hello':'world'}}
    mock_task_args4 = {'verbosity': 1}
    mock_task_args5 = {'msg': 'hello world', 'verbosity': 1}
    mock_task_args6 = {'var':'variable_name', 'verbosity': 1}

# Generated at 2022-06-21 01:57:15.185541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod_obj = ActionModule(None, None)
    ansible_var = dict(foo='bar')
    task_var = dict(ansib_foo='ansib_bar')
    tmp = dict()
    verbosity = dict(verbosity=1)
    assert mod_obj.run(tmp, task_vars=task_var) == {
        'failed': True,
        'msg': "'msg' and 'var' are incompatible options"
    }
    assert mod_obj.run(tmp, task_vars=task_var, variable_manager=ansible_var) == {
        'failed': True,
        'msg': "'msg' and 'var' are incompatible options"
    }

# Generated at 2022-06-21 01:57:19.078102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(), "localhost", "remote", "my_module", "my_args", "my_params")
    assert action.TRANSFERS_FILES == False
    assert hasattr(action, '_VALID_ARGS') == True
    

# Generated at 2022-06-21 01:57:25.347692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    def side_effect_run(module_name, module_args=None, task_vars=None, tmp=None):
        if module_name == 'debug' and module_args.get('msg', '') == 'Hello world!':
            return {'failed': False, 'msg': 'Hello world!'}
        if module_name == 'debug' and module_args.get('msg', '') == 'foo':
            return {'failed': False, 'msg': 'foo'}

    def side_effect_templar(template, convert_bare=True, fail_on_undefined=True):
        if template == '{{ansible_hostname}}':
            return 'localhost'
        elif template == '{{ansible_host}}':
            return 'localhost'

# Generated at 2022-06-21 01:57:26.807725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-21 01:57:34.110982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_args(kwargs, expected):
        task = MagicMock()
        task.args = kwargs
        display = MagicMock()
        display.verbosity = 0
        templar = MagicMock()
        ac = ActionModule(task, display)
        ac._templar = templar
        if 'msg' in kwargs or 'var' in kwargs:
            assert ac.run() == {"failed": False, "msg": expected}
        else:
            assert ac.run() == {"failed": False, "_ansible_verbose_always": True, "msg": "Hello world!"}

    test_args({"msg": "var is undefined"}, "var is undefined")
    test_args({"var": "var"}, "VARIABLE IS NOT DEFINED!")

# Generated at 2022-06-21 01:57:34.994988
# Unit test for constructor of class ActionModule
def test_ActionModule():
	pass

# Generated at 2022-06-21 01:57:41.846867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate an instance of ActionModule with arguments
    action_module = ActionModule(dict(msg="Hello world", var="xyz",
                                      verbosity=0), None)
    # Validate partial results returned by constructor
    assert action_module._task.args['msg'] == "Hello world"
    assert action_module._task.args['var'] == "xyz"
    assert action_module._task.args['verbosity'] == 0


# Generated at 2022-06-21 01:57:51.305281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestAnsibleModule():
        def __init__(self, task_vars):
            self.args = {'msg':'Hello world!', 'verbosity':0}
            self.task_vars = task_vars
    class TestAnsibleTask():
        def __init__(self):
            self.args = {}
    class TestAnsibleResult():
        def __init__(self):
            self.result = {}
    class TestAnsibleModuleUtils():
        def __init__(self):
            self.result = {}
    class TestTemplar():
        def __init__(self):
            self.template = 'Hello world!'

    class TestAnsiblePlayContext():
        # class for verbosity to control the verbosity level of the module
        verbosity = 0


# Generated at 2022-06-21 01:58:05.614045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test
    '''
    # one ActionModule object
    obj = ActionModule(None, {}, None)
    # the object should be a instance of ActionModule
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-21 01:58:14.820612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod._task.args = {'verbosity': 0}
    # If verbosity is less than required, skipped reason should be set
    res = mod.run()
    assert res['skipped_reason'] == 'Verbosity threshold not met.'
    assert res['skipped'] == True

    mod._task.args = {'verbosity': 1}
    # If verbosity is equal to required, msg should be present
    res = mod.run()
    assert res['msg'] == 'Hello world!'
    # failed should be False for run
    assert res['failed'] == False
    # If msg is not present, verbosity should be ignored
    mod._task.args = {'verbosity': 2}
    res = mod.run()
    assert res['msg'] == 'Hello world!'

# Generated at 2022-06-21 01:58:15.664177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:58:16.669005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    aModule = ActionModule(Task.Task(), dict())
    assert aModule

# Generated at 2022-06-21 01:58:27.719431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils.template
    import ansible.vars
    import ansible.plugins.action
    import ansible.inventory.host
    import ansible.inventory.group
    host = ansible.inventory.host.Host('test')
    group = ansible.inventory.group.Group('test')
    task = ansible.plugins.action.ActionModule(host, group, 'test', dict(), dict(vebosity=0))
    assert task.INSTALL_IN_SELF is False
    # hard code the variables
    task._play_context = ansible.utils.context.Context()
    task._loader = ansible.parsing.dataloader.DataLoader()
    task._templar = ansible.utils.template.Templar(loader=task._loader)
    task._shared_loader_obj = None

# Generated at 2022-06-21 01:58:29.012711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 01:58:30.749315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x is not None


# Generated at 2022-06-21 01:58:34.651500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=dict(), play_context=dict())
    assert(module is not None)

# Generated at 2022-06-21 01:58:46.233725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run

    Parametrize the following attributes first:
    - _task.args

    Use the following logic to test method run:
    - The arg 'var' is included in _task.args.
    - The arg 'var' is not included in _task.args.
    - The arg 'msg' is included in _task.args.
    - The arg 'msg' is not included in _task.args.
    - The arg 'verbosity' is not included in _task.args.
    - The arg 'verbosity' is included in _task.args with value 0.
    - The arg 'verbosity' is included in _task.args with value 1.
    """
    import pytest
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-21 01:58:56.695461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask_ActionModule()

    # create a mock play context
    play_context = MockPlayContext()

    # create a mock options
    mock_options = MockOptions()

    # create a mock loader
    mock_loader = MockLoader()

    # create a mock variable manager
    mock_variable_manager = MockVariableManager()

    # create a test action
    test_action = ActionModule(task, play_context, mock_loader, mock_options, mock_variable_manager, MockConnection()) 

    # execute the run method
    results = test_action.run(tmp=None, task_vars=None)

    # test the results
    assert results['msg'] == 'Hello world!'
    assert results['_ansible_verbose_always']
    assert not results['failed']


# Unit test

# Generated at 2022-06-21 01:59:23.789936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of class ActionModule with empty dict as argument
    am = ActionModule({"action": "debug"})
    assert not am.TRANSFERS_FILES
    assert am._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-21 01:59:35.665930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.connection import Connection
    import ansible.constants as C
    import json

    loader = action_loader._create_action_plugins(C.DEFAULT_ACTION_PLUGIN_PATH, 'local', 'action_plugins')
    playbook = Playbook.load('playbook.yml', variable_manager=VariableManager(), loader=loader, options=dict(connection='local'))


# Generated at 2022-06-21 01:59:46.970363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import copy

    # Construct an instance of class Task
    # Instantiate a copy of the `defaults` dictionary
    task_ds = copy.deepcopy(Task._task_defaults)
    # Update the task_ds with the data we need to test
    task_ds.update({'name': AnsibleUnicode('Print hello'), 'action': 'print', '_ansible_verbose_always': True})

    # Instantiate a Task object
    task = Task.load(task_ds)

    # Construct the module_defaults dictionary
    module_defaults = {}

    # Instantiate an ActionModule object
    action = ActionModule(task, {}, module_defaults)
    # test the constructor


# Generated at 2022-06-21 01:59:48.060839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    testActionModule = ActionModule(None, None, None, None)
    assert testActionModule is not None

# Generated at 2022-06-21 01:59:50.210725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run(ActionModule, tmp=None, task_vars=None)
    assert(result['msg'], 'Hello world!')
    assert(result['failed'], False)


# Generated at 2022-06-21 01:59:57.802132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    class TestClass(unittest.TestCase):
        def test_constructor(self):
            # Test if member variables were initialized properly
            action_module = ActionModule()
            self.assertEqual(action_module._VALID_ARGS, frozenset(('msg', 'var', 'verbosity')))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestClass)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 02:00:05.698490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible import module_utils
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range

    for verbosity in [0, 1, 2]:
        for input_arg in ['msg', 'var']:
            for output_arg in ['msg', 'var']:
                for value in [[], {}, True, False, None, 0, 1, 2, '', 'Hello', 'World', u'Hello', u'World']:

                    module_args = {input_arg: value}
                    module_args['verbosity'] = verbosity


# Generated at 2022-06-21 02:00:07.817466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, {}, 'core', 'test') is not None

# Generated at 2022-06-21 02:00:08.651701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:00:11.730644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return

if __name__ == '__main__':
    print("Running unit tests for debug module")
    test_ActionModule()

# Generated at 2022-06-21 02:00:58.193662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    l = ActionModule(None, {})
    assert l._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-21 02:01:08.724905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    tmp = None
    task_vars = dict()
    task = dict()
    task['args'] = dict()
    task['args']['msg'] = 'test_1'
    task['args']['verbosity'] = 100
    result = action.run(tmp, task_vars)
    assert (result['msg'] == 'test_1')
    task['args']['var'] = 'test_2'
    result = action.run(tmp, task_vars)
    assert (result['test_2'] == 'VARIABLE IS NOT DEFINED!')
    task_vars['test_3'] = 'test_3'
    task['args']['var'] = 'test_3'
    result = action.run(tmp, task_vars)

# Generated at 2022-06-21 02:01:19.548205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    play_context._options = PlayContext._build_options({})
    play_context._options.connection = 'local'
    play_context._options.module_path = None
    play_context._options.forks = 1
    play_context._options.become = False
    play_context._options.become_method = None
    play_context._options.become_user = None
    play_context._options.remote_user

# Generated at 2022-06-21 02:01:24.761511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(
        task=dict(
            args=dict(msg='Hello, world!')
            ),
        runner_queue='test_runner_queue',
        task_queue='test_task_queue',
        loader=None,
        display=None,
        shared_loader_obj=None,
        connection=None
        )

    assert repr(mod) == '<debug.ActionModule>'
    assert mod._task_queue == 'test_task_queue'
    assert mod._runner_queue == 'test_runner_queue'
    assert mod._task.args['msg'] == 'Hello, world!'

# Generated at 2022-06-21 02:01:29.025978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock

    return_value = {'failed': False}

    action_module = ActionModule(None, None)

    assert action_module.run(tmp=None, task_vars=None) == return_value

# Generated at 2022-06-21 02:01:33.515854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert type(module).__name__ == 'ActionModule'
    assert module.TRANSFERS_FILES == False
    assert module._VALID_ARGS == frozenset(['verbosity', 'msg', 'var'])

# Generated at 2022-06-21 02:01:46.310131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test case 1: Test case when both msg and var is passed as arguments
    # For this action module, both msg and var cannot be passed together
    # because msg and var are two different options for print command 
    action_plugin = ActionModule()
    action_plugin._task.args = {'msg': 'Hello World', 'var': 'Hello'}
    action_plugin._display.verbosity = 0
    result = action_plugin.run()
    if result["failed"] == True and result["msg"] == "'msg' and 'var' are incompatible options":
        print("Unit testcase 1 for ActionModule.run was passed")
    else:
        print("Unit testcase 1 failed for ActionModule.run was passed")

    # Unit test case 2: Test case when verbosity value is less than display verbosity and var is present as argument
    action_plugin

# Generated at 2022-06-21 02:01:58.178188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class mock_self():
        def __init__(self):
            self.verbosity = 2
    class mock_task():
        def __init__(self):
            self.args = {'msg': 'Hello world!'}
            self.module_vars = {}
    class mock_display():
        def __init__(self):
            self.verbosity = 0
    class mock_ansible_env():
        def __init__(self):
            self.get_ansible_version = lambda : '2.5'

    self = mock_self()
    self._task = mock_task()
    self._display = mock_display()
    self._ansible = mock_ansible_env()
    self._templar = None
    self._loader = None
    self._connection = None
    self._play_context = None

# Generated at 2022-06-21 02:02:01.580070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule(None, None, None, None)
    assert isinstance(action_module, ansible.plugins.action.ActionModule)

# Generated at 2022-06-21 02:02:06.188294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule class
    action_module = ActionModule(None, None, load_options=lambda x: None)

    # Create a dummy task to set task arguments
    task_args = {'msg': 'Hello World'}

    # set task arguments in action module
    action_module._task.args = task_args

    # Invoke run method of action module
    result = action_module.run()

    assert result['_ansible_verbose_always'] is True
    assert result['failed'] is False
    assert result['msg'] == 'Hello World'


# Generated at 2022-06-21 02:04:35.536880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager

    # Create Context
    context = PlayContext()
    context.connection = "local"
    context.become = True
    context.become_method = "sudo"
    context.become_user = "root"
    context.network_os = "default"
    context.remote_addr = "default"
    context.remote_user = "default"
    context.port = 22
    context.passwords = dict()

    # Create Variable Manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    # Create task
    task = dict()
   

# Generated at 2022-06-21 02:04:45.061647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    import json

    module_path = 'tests/unit/plugins/modules/'
    module_name = 'action_plugins.debug_fail_var'
    options = {'args': {'msg': 'Hello world!', 'verbosity': 0}}
    task_vars = {'verbose_always': True, 'foo': 'bar'}
    task_name = 'action_plugin_test'

# Generated at 2022-06-21 02:04:52.981609
# Unit test for constructor of class ActionModule
def test_ActionModule():
	my_ActionModule = ActionModule()
	assert my_ActionModule._task == None
	assert my_ActionModule._connection == None
	assert my_ActionModule._play_context == None
	assert my_ActionModule._loader == None
	assert my_ActionModule._templar == None
	assert my_ActionModule._shared_loader_obj == None
	assert my_ActionModule._connection_loader == None
	assert my_ActionModule._action_loader == None



# Generated at 2022-06-21 02:05:05.571461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import errors
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase

    class FakeActionBase(ActionBase):
        _VALID_ARGS = frozenset(('msg', 'var', 'verbosity'))

        _task = None

        class PlayContext(PlayContext):
            def __init__(self):
                self.verbosity = 0
    
        def v2_runner_on_ok(self, result):
            self.PlayContext._task_vars = result.task_vars
            return super(FakeActionBase, self).v2_runner_on_ok(result)

        def run(self, tmp=None, task_vars=None):
            self.PlayContext._task_vars = task_vars

# Generated at 2022-06-21 02:05:09.368805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('action_plugins/debug.yml')
    assert module is not None


# Generated at 2022-06-21 02:05:10.516772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:05:15.795895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert 'Hello world!' == actionModule.run()['msg']
    assert 'Hello world!' == actionModule.run({'msg':'Hello world!'})['msg']

    import json
    actionModule = ActionModule(json.loads('"Hello world!"'))
    assert 'Hello world!' == actionModule.run()['msg']
    actionModule = ActionModule(json.loads('{"msg":"Hello world!"}'))
    assert 'Hello world!' == actionModule.run()['msg']

# Generated at 2022-06-21 02:05:19.635895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(dict(args=dict(), task=dict(), named_args=dict()))
    assert(actionmodule._VALID_ARGS == frozenset([b'msg', b'verbosity', b'var']))
    assert(actionmodule.TRANSFERS_FILES == False)

# Generated at 2022-06-21 02:05:29.649941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mocks for testing
    class MockTask:
        class MockArgs:
            def __init__(self):
                self.msg = "Hello world!"
                self.var = None
                self.verbosity = 0

        def __init__(self):
            self.args = self.MockArgs()

    mock_task = MockTask()

    class MockTemplar:
        def template(self, template, convert_bare=False, fail_on_undefined=False):
            return template

    mock_templar = MockTemplar()

    class MockDisplay:
        def __init__(self):
            self.verbosity = 0

    mock_display = MockDisplay()

    # create expected dictionary
    expected_dict = dict()
    expected_dict['msg'] = "Hello world!"
    expected_dict['failed']