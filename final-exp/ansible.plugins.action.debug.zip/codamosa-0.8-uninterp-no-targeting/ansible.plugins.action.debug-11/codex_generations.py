

# Generated at 2022-06-21 01:55:34.975095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.debug
    ansible.plugins.action.debug.test_ActionModule()

# Generated at 2022-06-21 01:55:45.958633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with verbosity 0
    module = ActionModule()

    # Test with msg
    task = {'args': {'msg': 'test'}}
    result = module.run(task_vars={}, task=task)
    assert(result['failed'] == False)
    assert(result['msg'] == 'test')

    # Test with var
    task['args'] = {'var': 'myvar'}
    result = module.run(task_vars={'myvar': 'test'}, task=task)
    assert(result['failed'] == False)
    assert(result['myvar'] == 'test')

    # Check that a bare var name is templated
    task['args'] = {'var': '{{myvar}}'}

# Generated at 2022-06-21 01:55:53.972693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task

    # We use the action plugin loader to setup the tasks for us
    task = Task()
    task.action = 'debug'
    loader = action_loader.get(task.action, class_only=True)()
    print('Instantiated debug plugin: %s' % loader)
    task.args = {'msg': 'This is a test output'}

    # Create the action module
    module = loader(task, connection=None, templar=None, shared_loader_obj=None)

    # Execute the code to be tested
    result = module.run(tmp=None, task_vars=None)

    # Check the result
    assert result.get('failed') == False

# Generated at 2022-06-21 01:55:54.488016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:56:00.141855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: This will be replaced by unit test module
    try:
        # Create an instance of class ActionModule
        module = ActionModule(load_fixture('test_action_debug.yml'),dict())
        # Run method run of class ActionModule
        result = module.run(task_vars=dict(verbosity=2), tmp=None)

        # Check result
        assert result['failed'] == False
        assert 'Hello world' in result['msg']
        return 0
    except:
        return 1

# Generated at 2022-06-21 01:56:06.108707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import pytest
    from ansible.plugins.action.copy import ActionModule
    from ansible.utils.vars import combine_vars

    CWD = os.path.dirname(__file__)
    TASK_DATA_PATH = os.path.join(CWD, 'task_data.json')

    # read task_data.json
    with open(TASK_DATA_PATH) as module_data_file:
        TASK_DATA = module_data_file.read()

    # Test ActionModule()
    action = ActionModule(task=TASK_DATA, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test ActionModule().run()

# Generated at 2022-06-21 01:56:11.201460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(a.run(tmp=None, task_vars=None), dict)

# Generated at 2022-06-21 01:56:21.874348
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Control data to compare
    control_result = {'msg': 'Hello world!'}

    # Create a mock task with a valid set of arguments
    mock_args = {'msg': 'Hello world!'}
    mock_task = create_mock_args(mock_args)
    mock_task_vars = dict()

    # Configure the action module with dummy display
    action_module = ActionModule(mock_task, dict())
    action_module._display = DummyDisplay()

    # Execute the method run
    result = action_module.run(None, mock_task_vars)

    # Compare the result to the control data
    assert result == control_result

#---------------------------------------------------------------------------------------------------
# Unit tests
#---------------------------------------------------------------------------------------------------

# Generated at 2022-06-21 01:56:33.569785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    module_name = "debug"

    play_context = dict()

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module=module_name, args=dict(msg="Hello world!")),
                 register='shell_out'),
            dict(action=dict(module=module_name, args=dict(var=123)),
                 register='shell_out'),
            dict(action=dict(module=module_name, args=dict(var=123, verbosity=1)),
                 register='shell_out')
        ]
    )

# Generated at 2022-06-21 01:56:42.582929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule.
    '''
    # Create a module argument spec
    module_args = {'msg': 'something', 'verbosity': 3}
    action_module_obj = ActionModule(None, module_args, None, None, None)
    assert action_module_obj._task.args['msg'] == 'something'
    assert action_module_obj._task.args['verbosity'] == 3

    # Create a module argument spec
    module_args = {'msg': 'something'}
    action_module_obj = ActionModule(None, module_args, None, None, None)
    assert action_module_obj._task.args['msg'] == 'something'
    assert action_module_obj._task.args['verbosity'] == 0

    # Create a module argument spec
    action_

# Generated at 2022-06-21 01:56:50.384824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {'var': 'abc'}
    am = ActionModule(None, module_args)
    assert isinstance(am, ActionModule)  # constructor
    assert am._task.args['var'] == 'abc'    # instance variable var is set correctly

# Generated at 2022-06-21 01:56:56.301103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    import ansible.plugins.action.debug as debug
    p = debug.ActionModule(None, dict(msg='foo'))
    assert p.run(None, dict()) == dict(failed=False, msg='foo')

# Generated at 2022-06-21 01:56:57.201356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:57:05.517241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys

    if sys.version_info[:2] == (2, 6):
        # The unittest module was deprecated in Python 2.7, 2.6 only has unittest2 which
        # is incompatible with Python 3.x
        import unittest2 as unittest
    else:
        import unittest

    def dummy_func(something):
        return something

    from ansible.plugins.action import ActionBase

    MOCK_ACTION_BASE = unittest.mock.MagicMock(spec=ActionBase)
    MOCK_ACTION_BASE._templar = unittest.mock.MagicMock(spec=ActionBase._templar)

# Generated at 2022-06-21 01:57:14.589328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new object of type AnsibleModuleTask
    # which will be used to call ActionModule run method
    at = AnsibleModuleTask()

    # Target function to call
    task = {'args': at.get_args()}

    # Create a new object of type ActionModule
    obj = ActionModule(task, at.get_connection(), at.get_loader(), at.get_templar(), at.get_shared_loader())
    res = obj.run(at.get_tmp_path(), at.get_task_vars())

    # Check if result is equal to the expected result
    assert(res['failed'] == at.get_expected_result()['failed'])
    assert(res['msg'] == at.get_expected_result()['msg'])


# Generated at 2022-06-21 01:57:20.471558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile

    tmp = tempfile.mkdtemp
    task_vars = {}
    ac = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = ac.run(tmp, task_vars)

    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'
    assert result['_ansible_verbose_always'] == True

# Generated at 2022-06-21 01:57:22.275318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    pass

# Generated at 2022-06-21 01:57:33.060577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.task import Task

    task = Task()
    task.action = 'debug'
    task.args = dict(msg='Hello world!')

    module = AnsibleModule(argument_spec=dict())
    am = ActionModule(task, module.params, module._socket_path)

    results = am.run(task_vars={})
    assert results.get('msg') == 'Hello world!'
    assert results.get('failed') == False

    task.action = 'debug'
    task.args = dict(msg=42)

    module = AnsibleModule(argument_spec=dict())
    am = ActionModule(task, module.params, module._socket_path)

    results

# Generated at 2022-06-21 01:57:43.734980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None

    # Test with verbosity 0 (default)
    action_plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_plugin._display.verbosity = 0

    # Test with verbosity 1
    action_plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_plugin._display.verbosity = 1

    # Test with 'msg' argument
    action_plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_plugin._task.args = dict

# Generated at 2022-06-21 01:57:54.958468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = 'ansible.plugins.action.debug'
    a = 'ActionModule'

    # instantiate a mock class to keep track of calls
    task_args = {'var': 'fixture_hostname'}
    display = Mock()
    display.verbosity = 0
    templar = Mock()
    templar.template = Mock(return_value='fixture.host')

    # instantiate the object that we're testing
    am = ActionModule(task=dict(args=task_args), task_vars=dict(), display=display)
    am._templar = templar

    result = am.run(task_vars=dict())
    print("Result output: %s" % (result))
    assert result['fixture_hostname'] == 'fixture.host'

    # instantiate a mock class to

# Generated at 2022-06-21 01:58:07.437876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: mock up a task and tmp path
    action = ActionModule()

# Generated at 2022-06-21 01:58:08.871598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(None, None)

# Generated at 2022-06-21 01:58:10.908732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None, None, None)
    assert module._VALID_ARGS == frozenset({})


# Generated at 2022-06-21 01:58:24.566965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['../../test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 01:58:28.757212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError) as excinfo:
        ActionModule()
    assert 'missing 2 required positional arguments' in str(excinfo.value)

# Test Run method of ActionModule class

# Generated at 2022-06-21 01:58:37.007745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule(connection=None, action='test', task_id='test', task_vars=dict(), templar=None, loader=None, display=None)
    assert t._task.action == 'test'

# Generated at 2022-06-21 01:58:46.969528
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #Create a instance of class ActionModule
    action_module = ActionModule(load_module_spec(False))

    task_vars = {'msg': 'Hello world!','var':{'Test':'Hello World','Test2':'Hello world2'},'verbosity':1}
    # run the method run from class ActionModule
    result = action_module.run(task_vars)
    assert (result ==  {'Hello world!': 'Hello world!'})

    task_vars = {'msg': 'Hello world!', 'verbosity': 1}
    # run the method run again with a different input
    result = action_module.run(task_vars)
    assert (result ==  {'Hello world!': 'Hello world!'})

    task_vars = {'var':'msg', 'verbosity': 1}


# Generated at 2022-06-21 01:58:49.263206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, '_VALID_ARGS')
    assert hasattr(ActionModule, 'TRANSFERS_FILES')

# Generated at 2022-06-21 01:58:53.411712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(loader=None,
                     connection=None,
                     play_context=None,
                     loader_obj=None,
                     templar=None,
                     shared_loader_obj=None,)

# Generated at 2022-06-21 01:58:56.938896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None)
    assert actionModule._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-21 01:59:28.020330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    class Options(object):
        """
        Options class dummy for testing
        """
        verbosity = 0
        debug = False
        no_log = False

        def __init__(self):
            super(Options, self).__init__()

        def __getattr__(self, name):
            """
            fake getattr
            """
            return None


# Generated at 2022-06-21 01:59:28.895417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-21 01:59:37.858750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys

    import ansible.utils.module_docs_fragments
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    playbook_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'action_plugins', 'debug_action_plugin.yml')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    loader = DataLoader()

# Generated at 2022-06-21 01:59:47.587743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test 1 : Testing for ActionBase class
    assert issubclass(ActionModule,ActionBase)

    # Test 2
    action = ActionModule(
        task=dict(action=dict(module_name='test'), args=dict(msg='test',verbosity=2)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action.__class__.__name__ == 'ActionModule'

    # Test 3

# Generated at 2022-06-21 01:59:55.599831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = dict()
    _task['action'] = dict()
    _task['args'] = dict()
    _task['action']['__ansible_module__'] = 'debug'
    _task['args']['msg'] = 'Hello World'
    _task['args']['verbosity'] = 1
    _task['action']['name'] = "Debugging"

    action = ActionModule()
    action.set_runner({})
    action.setup_conn()
    action.set_loader(1)
    action._task = _task
    print(action.run())

# Generated at 2022-06-21 02:00:00.656175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    assert mod.run() == {
        'changed': False,
        'failed': False,
        '_ansible_verbose_always': True,
        'msg': "Hello world!",
    }

# Generated at 2022-06-21 02:00:03.870815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.ACTION_VERSION == '1.0'
    assert a.TRANSFERS_FILES == False
    assert a._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert a.run() == {"failed": False}

# Generated at 2022-06-21 02:00:15.975150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    host_results = {}
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Adhoc Test Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', msg='ok'), register='debug_result'),
        ]
    )


# Generated at 2022-06-21 02:00:21.503521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Call constructor of class ActionModule and check if it returns an object of clas ActionModule
    assert isinstance(ActionModule(), ActionModule)

    # Call constructor of class ActionModule and check if it returns an object of clas ActionModule
    assert isinstance(ActionModule(), ActionModule)

    # Create object of class Task
    objTask = Task()

    # Create object of class Play
    play = Play()

    # Create object of class TaskQueueManager
    tqm = TaskQueueManager()

    # Create object of class ActionModule
    action_module = ActionModule()


# Generated at 2022-06-21 02:00:24.712717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import action_loader
    action_obj = action_loader.get('debug', class_only=True)()
    assert action_obj is not None
    assert action_obj._shared_loader_obj is not None

# Generated at 2022-06-21 02:01:17.643143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    task_vars = {'foo': 'FOO', 'bar': 'BAR'}
    result = action_module.run(tmp=None, task_vars=task_vars)

    # Test the warning message
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False

    # Test var option
    task_vars = {'foo': 'FOO', 'bar': {'baz': 'BAZ'}, 'a_list': [1,2,3], 'unicode': u'unicode string'}
    result = action_module.run(tmp=None, task_vars=task_vars)
    assert result['unicode'] == u'unicode string'

    # Test var option if var name is same as result

# Generated at 2022-06-21 02:01:24.761295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        import ansible
    except ImportError:
        raise Exception("Module 'ansible' not found")

    a = ansible.plugins.action.ActionModule()
    while True:
        try:
            print(a._load_params())
        except:
            pass

# Uit test for method _run_loop()

# Generated at 2022-06-21 02:01:33.883414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.utils.color import stringc
    action = ActionModule('test', 'msg="Test"', StringIO(), StringIO())
    result = action.run(task_vars={})

    assert result['failed'] is False
    assert result['msg'] == 'Test'
    assert 'skipped' not in result
    assert 'skipped_reason' not in result


# Generated at 2022-06-21 02:01:35.561300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-21 02:01:47.304955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    results = action_module.run(task_vars={'verbose':2})

    assert "skipped" not in results
    assert "skipped_reason" not in results
    assert "msg" in results
    assert "Hello world!" in results["msg"]
    assert results["failed"] == False

    results = action_module.run(task_vars={'verbose':1})

    assert "skipped" not in results
    assert "skipped_reason" not in results
    assert "msg" in results
    assert "Hello world!" in results["msg"]
    assert results["failed"] == False

    results = action_module.run(task_vars={'verbose':0})

    assert "skipped" in results
    assert "skipped_reason" in results
    assert "msg"

# Generated at 2022-06-21 02:01:56.005876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._display = MockDisplay()
    assert am.run(None, {'foo': 'bar'}) == {'failed': False, 'foo': 'bar'}
    assert am.run(None, {'foo': 'bar'}) == {'failed': False, 'unicode': u"VARIABLE IS NOT DEFINED!"}


from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-21 02:02:04.962571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ast
    import json
    import pytest
    
    ansible_module_path = 'ansible.plugins.action.debug'
    action_module = 'ActionModule'
    test_module_type = 'action'
    
    
    # init action module
    action_type = 'debug'
    action_class = 'ActionModule'
    action_module = 'debug'
    action_name = 'debug'
    module_args = {}
    
    # init task
    task = MockTask()
    task_vars = {}
    tmp = {}
    
    def raise_undefined_variable():
        raise AnsibleUndefinedVariable()
    
    # test 1
    # valid args
    # msg key is in task args
    # not skippend
    # var key is not in task args
    test_args

# Generated at 2022-06-21 02:02:05.738068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-21 02:02:15.788293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.task.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.plugins.loader import find_action_plugin
    import os
    import sys
    import unittest
    import ansible

# Generated at 2022-06-21 02:02:18.263679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    assert ActionModule is not None


# Generated at 2022-06-21 02:04:32.284342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule("test", "test", "test", "test", "test")
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 02:04:42.709078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ar = dict(msg="a")
    acm = ActionModule(dict(name="action_test", action=dict(module="debug", args=ar), task=None), dict(connection='local', become=None, become_method=None, become_user=None, check=False, diff=False, remote_user=None))
    assert acm.name == 'action_test'
    assert acm._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert acm.transfers_files == False
    assert acm._task == dict(name="action_test", action=dict(module="debug", args=ar))

# Generated at 2022-06-21 02:04:44.506953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 02:04:46.106499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    print (sys.path)

# Generated at 2022-06-21 02:04:46.604183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule


# Generated at 2022-06-21 02:04:47.989300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(None)
    # TODO: write these tests
    # assert m.run() == ()

# Generated at 2022-06-21 02:04:56.315585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.template import Templar

    t = Templar(None, loader=None)
    t.available_variables = dict(a=1,b=2,c=3,d=4)
    t.vars = dict(e=5,f=6,g=7,h=8)

    action = ActionModule(None, dict(a=1,b=2,c=3,d=4,e=5))
    action._task = Task()
    action._task.action = 'debug'
    action._task.args = dict(msg='Hello world!',verbosity=1)
    action._task.async_val = None
    action._task.notify = []
    action._templar = t

# Generated at 2022-06-21 02:05:07.461586
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:05:09.752994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''action_plugin.ActionModule
        - constructor
    '''
    action_plugin_ActionModule = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_plugin_ActionModule

# Generated at 2022-06-21 02:05:12.310926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert "failed" in ActionModule(dict(), dict()).run()