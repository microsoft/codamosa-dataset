

# Generated at 2022-06-21 01:55:33.086641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.debug import ActionModule
    am=ActionModule()
    assert am._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:55:35.885256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionClass():
        pass

    action = ActionModule(MockActionClass())

    real_run = action.run
    def run(self, *args, **kwargs):
        assert False

    action.run = run

    action.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 01:55:41.629190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = __import__('ansible.plugins.action.debug')
    action = module.ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert action.run() == {'_ansible_verbose_always': True, 'failed': False, 'msg': 'Hello world!'}

# Generated at 2022-06-21 01:55:52.061024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import Mock
    import json
    import os
    import sys

    if sys.version_info[0] == 2:
        from io import open

    # Set up required mocks
    a = Mock()
    b = Mock()
    a.verbosity = 2
    a.hostvars = {}
    a._templar = b
    b.template = lambda x, **kwargs: x
    tmp = ''
    task_vars = {}

    # Test 1:
    # - msg: {msg}
    # - var: {var}
    # - var['redis']['dir']
    # - var['redis']['dir'] | default('/var/lib/redis')
    # - var['redis']['dir'] | regex_replace('(')
    ret = []

# Generated at 2022-06-21 01:55:55.483863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize the class
    A = ActionModule()
    # execute the run method
    # This method returns an exit status
    # Add your tests here
    B = "Hello world!"
    C = A.run("msg", B)
    # check the exit status
    assert C.get("failed") == False
    assert C.get("msg") == B
    return True

# Generated at 2022-06-21 01:56:03.932646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task

    # Create empty task object
    # This is needed to create an empty task object by load_action_plugin
    fake_loader = None
    fake_task = None
    task = Task(fake_loader, fake_task)

    # Set task args to allow creation of ActionModule instance
    task.args = {"msg": "Hello world!"}

    # Create the module
    module = action_loader._create_action_plugin(task, 'debug', {})

    # Assert the module class
    assert isinstance(module, ActionModule)

    # Assert the module run function
    assert module.run({}, {}) == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}

# Generated at 2022-06-21 01:56:06.307897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None)
    assert actionModule is not None

# Generated at 2022-06-21 01:56:18.842608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action

    ActionModule._VALID_ARGS = frozenset(('msg', 'var', 'verbosity'))
    ActionModule.TRANSFERS_FILES = False

    task_vars_global = {}
    task_vars = {}
    task_vars['ansible_verbosity'] = 4

    # data
    task = {}
    task_ds = {}
    task_ds['action'] = 'debug'
    task_ds['args'] = {'verbosity': 2}

    # mock
    class MockTask():
        def __init__(self):
            self.args = task_ds['args']
    task['task'] = MockTask()

    # mock
    class MockPlayContext:
        verbosity = 2
    pc = MockPlayContext()

    # mock

# Generated at 2022-06-21 01:56:27.579782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.basic
    import ansible.plugins.action

    # Create a mock command so that it returns some data in its run method
    # as if it was called on the commandline
    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockCommand(object):
        def __init__(self):
            self.module = ansible.module_utils.basic.AnsibleModule(
                argument_spec=dict()
            )
            self.tmpdir = None
            self.task_vars = {}

    class MockTemplate(object):
        def __init__(self):
            self.template = ""

    class MockTask(object):
        def __init__(self):
            self.args = {}


# Generated at 2022-06-21 01:56:28.401735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 01:56:34.369246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-21 01:56:40.427692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.callbacks
    import ansible.playbook
    import ansible.plugins
    import ansible.template
    import ansible.utils.plugin_docs
    import ansible.vars
    import ansible.utils.vars

    module_path = None
    args = {'msg':'Hello world', 'var':'Rick'}
    task_vars = {'Rick':'Morty'}
    host = ansible.inventory.host.Host('localhost')
    play_context = ansible.playbook.PlayContext()
    new_stdin = None
    loader = None
    callback_loader = ansible.callbacks.DefaultRunnerCallbacks()
    ansible.plugins.action_loader=ansible.plugins.ActionBase

# Generated at 2022-06-21 01:56:43.777798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing the module constructor
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, ActionModule)
    return

# Generated at 2022-06-21 01:56:54.077220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts import FactCollector
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from collections import namedtuple

# Generated at 2022-06-21 01:56:56.296439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 01:57:00.261113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructorTest = ActionModule()
    assert constructorTest._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert constructorTest.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:57:12.520625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class args:
        def __init__(self, msg):
            self.msg = msg

    class Task:
        def __init__(self, args):
            self.args = args

    class MockModule():
        _task = Task(args('test_message'))
        def __init__(self, result):
            self.result = result

        def run(self, *args, **kwargs):
            return self.result

    class PlayContext:
        def __init__(self, verbosity):
            self.verbosity = verbosity

    class MockDisplay:
        # Testing that the verbosity is properly compared
        def __init__(self, verbosity, isDisplay):
            self.verbosity = verbosity
            self.isDisplay = isDisplay

    class AnsibleUndefinedVariable(Exception):
        pass


# Generated at 2022-06-21 01:57:13.075418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 01:57:15.005242
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor
    am = ActionModule()
    assert am

# Generated at 2022-06-21 01:57:23.805205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.templating import Templar

    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}

    display = Display()
    display.verbosity = 2

    my_vars = dict(e=dict(f="g", h="{{a}}", i="{{a|upper}}"), j="{{a}}")
    variable_manager.set_nonpersistent_facts(my_vars)

# Generated at 2022-06-21 01:57:37.272573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 01:57:44.862617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize parameters
    params = {}
    params['var'] = 'ansible_processor_count'
    params['verbosity'] = 1
    tmp = None
    task_vars = None
    am = ActionModule(tmp, params, task_vars)
    # Test if the task_vars is None
    assert am.run(tmp, task_vars)['failed'] is True
    # Test if the verbosity is grater than 0
    assert am.run(tmp, {'ansible_processor_count':2})['failed'] is False
    # Test if the params['var'] is availiable in task_vars
    assert am.run(tmp, {'ansible_processor_count':2})['failed'] is False

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 01:57:48.874091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #execute run method of class ActionModule and get result object
    result = ActionModule.run(ActionModule(), {'msg': 'Hello world!'}, {})

    #assert result object not contains key 'failed'
    assert 'failed' not in result


# Generated at 2022-06-21 01:57:54.096538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context

    context.CLIARGS = {'forks': 10, 'ask_pass': False, 'private_key_file': None, 'remote_user': None, 'ask_sudo_pass': False, 'ask_su_pass': False, 'diff': False, 'connection': 'ssh'}

    #action = ActionModule(None, None)
    return

# Generated at 2022-06-21 01:58:01.120064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    t = Task()
    t.args = {
        'msg': 'Hello world!',
        'verbosity': 0
    }
    am = ActionModule(t, {})
    result = am.run(None, {'verbosity': 0})
    assert not result['failed']
    assert result['msg'] == 'Hello world!'
    assert result['_ansible_verbose_always']



# Generated at 2022-06-21 01:58:12.787726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(None, None)
    task_vars = {
        "foo": "bar",
    }
    task_args = {
        u"var": u"foo",
        u"verbosity": 0,
    }
    a._task  = MockTask(task_args)
    a._display = MockDisplay()
    a._connection = MockConnection()
    a._loader = MockLoader()
    a._templar = MockTemplar(task_vars)
    results = a.run(None, task_vars)
    assert results == {
        u"failed": False,
        u"foo": u"bar",
        u"_ansible_verbose_always": True
    }


# Generated at 2022-06-21 01:58:13.961710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:58:25.652738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import utils
    from ansible.playbook.task import Task

    module_utils_path = utils.plugins.action_loader._find_plugin("debug")
    module_utils = utils.plugins.action_loader._get_action_module_class(module_utils_path)

    task = Task()
    action = module_utils(task=task)
    action.verbosity = 4
    task.args = {'msg':'Hello world!'}
    res = action.run(task_vars=None)
    assert res.get('msg') == 'Hello world!'
    assert res.get('failed') == False
    assert res.get('_ansible_verbose_always') == True

    task.args = {'msg': 'Hello world!', 'verbosity': 5}

# Generated at 2022-06-21 01:58:35.153190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os

    import sys
    if sys.version_info[0] == 2:
        from mock import MagicMock, patch
    else:
        from unittest.mock import MagicMock, patch

    from ansible.module_utils.six import TextIOWrapper

    from ansible_collections.ansible.debug.plugins.action import ActionModule

    if sys.version_info[0] == 2:  # python 2
        _builtin_open = '__builtin__.open'
    else:  # python 3
        _builtin_open = 'builtins.open'

    module_args = dict(msg="hello world")

    with patch(_builtin_open, create=True) as mock_open:
        mock_open.return_value = MagicMock(spec=file)
        fake_file_

# Generated at 2022-06-21 01:58:46.432060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    pb_ctx = PlayContext()
    task_q_mgr = TaskQueueManager(pb_ctx, lambda x: x, lambda x: x)
    am = ActionModule(task_q_mgr, pb_ctx, 'dummy', 'dummy')


# Generated at 2022-06-21 01:59:07.299951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-21 01:59:10.702384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = {'msg': 'TEST_INPUT'}

    task_vars = {'var1': 'TEST_VAR'}
    results = module.run(task_vars=task_vars)

    assert results['msg'] == 'TEST_INPUT'
    assert results['failed'] == False
    assert results['changed'] == False
    assert results['_ansible_verbose_always'] == True


# Generated at 2022-06-21 01:59:23.463047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define test data
    data = dict(ANSIBLE_MODULE_ARGS = dict(msg = 'Hello world!'))
    data2 = dict(ANSIBLE_MODULE_ARGS = dict(var = 'var_name'))
    data3 = dict(ANSIBLE_MODULE_ARGS = dict(msg = 'Hello world!', var = 'var_name'))
    # Test constructor of class ActionModule
    actionModule = ActionModule(None, data, False, None)
    actionModule2 = ActionModule(None, data2, False, None)
    actionModule3 = ActionModule(None, data3, False, None)
    # Assertion of test data
    assert actionModule._task.args.get('msg') == 'Hello world!'
    assert actionModule._task.args.get('var') == None
    assert actionModule

# Generated at 2022-06-21 01:59:35.511480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_hosts = ['testhost1']
    test_tasks = [dict(action=dict(module=u'Debug'))]

    from ansible.playbook import Play
    test_play = Play().load(dict(name=u'test_play',
                                 hosts=test_hosts,
                                 gather_facts=u'no',
                                 tasks=test_tasks),
                            variable_manager=None,
                            loader=None)


    from ansible.executor.task_queue_manager import TaskQueueManager
    test_tqm = TaskQueueManager(
                    inventory=None,
                    variable_manager=None,
                    loader=None,
                    options=None,
                    passwords=None,
                    stdout_callback='default',
                )

    import os
    import tempfile
    test_local

# Generated at 2022-06-21 01:59:38.050339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-21 01:59:41.499506
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create ActionModule instance
    obj = ActionModule(None, {})
    assert obj._task.args == {}


# Generated at 2022-06-21 01:59:49.145314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import mock
    import six
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.debug import ActionModule

    playbook = mock.Mock()
    play_context = mock.Mock()
    action_base = ActionBase(play_context)

    # Test case 1: Print statements with verbosity greater than 0
    mock_task = mock.Mock()
    mock_task.verbosity = 2

    # Tests for passing msg to debug module
    mock_task.args = dict(_ansible_verbosity=2, msg='Hello world!')
    am = ActionModule(action_base, mock_task, playbook)
    result = am.run()
    assert result['failed'] is False

# Generated at 2022-06-21 01:59:55.066157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_ActionModule_instantiate: make sure that the instance of the class could be created
    class Mock_Config(object):
        class _constant(object):
            class vars(object):
                def __init__(self):
                    self.debug = True
        debug = vars()
    config = Mock_Config()
    task = {"args": {"var1":"foo", "verbosity": "1"}}
    action_module = ActionModule(task, config)
    assert action_module != None

# Generated at 2022-06-21 02:00:05.025963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing without msg and var
    test_data = dict()

    test_data['task_vars'] = dict()

    test_data['task_vars']['verbosity'] = 3

    am = ActionModule(dict(), dict())
    am._display.verbosity = test_data['task_vars']['verbosity']
    result = am.run(task_vars=test_data['task_vars'])

    assert result['msg'] == 'Hello world!'
    assert type(result) is dict
    assert result['failed'] == False
    assert result['skipped'] == False

    # Testing with verbosity < 2
    test_data['task_vars']['verbosity'] = 0
    am._display.verbosity = 2

# Generated at 2022-06-21 02:00:05.754392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 02:00:47.891908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    b = ActionModule(1, 2)
    assert b

# Generated at 2022-06-21 02:00:55.470856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule(task=MockTask({'msg': 'test_message'}), connection=MockConnection(), play_context=MockPlayContext())
    actionModule._display.verbosity = 10
    result = actionModule.run(tmp=None, task_vars=None)
    assert result['msg'] == 'test_message'
    assert result['failed'] == False
    assert result['skipped_reason'] == 'Verbosity threshold not met.'
    assert result['skipped'] == True


# Generated at 2022-06-21 02:01:07.624595
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of class ActionModule for testing.
    action_module = ActionModule(load_module_spec=False, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Set up parameters and return values needed by method test_run.
    task_vars = {'ansible_verbosity': 1}
    tmp = ""
    result = action_module.run(tmp, task_vars)
    assert 'VARIABLE IS NOT DEFINED!' in result['var']

    # Set up parameters and return values needed by method test_run.
    task_vars = {'ansible_verbosity': 1}
    tmp = ""
    result = action_module.run(tmp, task_vars)
    assert 'skipped' in result

# Generated at 2022-06-21 02:01:10.382350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create ActionModule object with valid arguments
    am = ActionModule()
    am.run()

# Generated at 2022-06-21 02:01:20.112564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict()),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert module.run() == dict(msg='Hello world!', failed=False, _ansible_verbose_always=True)
    assert module.run(task_vars={'message': 'How are you'}) == dict(msg='Hello world!', failed=False, _ansible_verbose_always=True)
    assert module.run(task_vars={'message': 'How are you'}, verbosity=1) == dict(msg='Hello world!', failed=False, _ansible_verbose_always=True)

# Generated at 2022-06-21 02:01:28.014741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am._task.args = {"var": "test_var"}
    am._templar = ""
    am._display = ""
    ret = am.run()
    assert ret["failed"] == False
    assert ret["_ansible_verbose_always"] == True
    assert ret["test_var"] == "VARIABLE IS NOT DEFINED!"
    am._task.args = {"msg": "test_msg"}
    ret = am.run()
    assert ret["failed"] == False
    assert ret["_ansible_verbose_always"] == True
    assert ret["msg"] == "test_msg"

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-21 02:01:38.140243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            msg=dict(type='str', default='Hello world!'),
            var=dict(type='raw', default=None)
        )
    )

    am = ActionModule(module, dict())

    ret = am.run(task_vars=dict())

    assert not ret.get('failed')
    assert not ret.get('skipped')
    assert not ret.get('changed')
    assert ret.get('msg') == 'Hello world!'

    ret = am.run(task_vars=dict(echo_message='Hello Ansible!'))

    assert not ret.get('failed')
    assert not ret.get('skipped')
    assert not ret.get('changed')

# Generated at 2022-06-21 02:01:48.361484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.debug import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = InventoryManager(loader, 'localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = "name: debug_test"
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    task = play.get_tasks()[0]
    task_vars = dict()
    pm = ActionModule(task, variable_manager=variable_manager, loader=loader)
    assert isinstance(pm, ActionModule)

# Generated at 2022-06-21 02:02:00.167162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from __main__ import FakeModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.playbook.play_context import PlayContext

    ###############################
    # Unit test for __init__()
    # to_bytes(b'foo') == b'foo'
    # to_text(u'foo') == u'foo' == b'foo'
    ###############################
    module_args = dict(
        msg='Hello world!',
        verbosity=10,
    )
    play_context = PlayContext()
    play_context.prompt = ''
    play_context.remote_addr = ''
    play_context.remote_user = ''
    play_context.connection = ''

# Generated at 2022-06-21 02:02:06.558918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # For the constructor of class ActionModule
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Test 1 (normal case)
    task = Task()
    play_context = PlayContext()
    queue_manager = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)
    action_module = ActionModule(task, play_context, queue_manager)
    assert action_module._task.__dict__['args'] == {'msg': None, 'var': None, 'verbosity': 0}
    assert action_module._play_context.__dict__ == {}

# Generated at 2022-06-21 02:04:22.630500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module='debug', args=dict(msg='Hello world!'))),
        connection=None,
        play_context=dict(check_mode=False, verbosity=0),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert module.run() == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}

# Generated at 2022-06-21 02:04:31.862074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    # get an instantiated ActionModule instance or fail
    action = action_loader.get('debug', class_only=True)()
    # run the method and get it's result or fail
    result = action.run(tmp=None, task_vars=None)
    # print result to stdout (which will, as default, be captured by pytest)
    # this also allows debugging
    print(result)

# Generated at 2022-06-21 02:04:43.764726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import Mock
    # Mocking arguments and objects of run()
    mock_ansible_play_context = Mock()
    mock_ansible_play_context.check_mode = False
    mock_ansible_play_context.remote_addr = '1.1.1.1'
    mock_ansible_play_context.connection = Mock()
    mock_ansible_play_context.connection.transport = 'ssh'
    mock_ansible_play_context.connection.cipher = 'abc'

    mock_loader = Mock()
    actionBase = ActionBase()
    actionBase._loader = mock_loader
    actionBase._templar = Mock()
    actionBase._shared_loader_obj = Mock()
    actionBase._display = Mock()
    actionBase._display.verbosity = 1

    # Mocking task


# Generated at 2022-06-21 02:04:49.877641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_constructor = ActionModule(u'HELP', u'action_plugin')

    # Test object
    assert isinstance(test_constructor, object)

    # Test class of object
    assert isinstance(test_constructor, ActionModule)


# Generated at 2022-06-21 02:04:51.115894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule is not None), "ActionModule is undefined"

# Generated at 2022-06-21 02:04:55.830126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO

    class myDict(dict):
        def __getattr__(self, attr):
            return self[attr]

    # Dummy Data
    loader = DataLoader()
    inventory = myDict()

# Generated at 2022-06-21 02:05:07.248063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback='default',
        run_additional_callbacks=False,
        run_tree=False,
    )
    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote_addr = '192.168.56.101'
    play_context.remote_user = 'vagrant'
    play_context.password = 'vagrant'
    play_context.become = False
    play_

# Generated at 2022-06-21 02:05:08.044563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-21 02:05:08.879976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test failed due to missing module_utils
    assert ActionModule(None,{}) == None

# Generated at 2022-06-21 02:05:09.791976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass