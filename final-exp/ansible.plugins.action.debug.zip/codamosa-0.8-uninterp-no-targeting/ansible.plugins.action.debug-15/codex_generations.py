

# Generated at 2022-06-21 01:55:30.679889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-21 01:55:33.554804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 01:55:45.370682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    task = Task()
    templar = Templar(loader=None, variables=VariableManager())

    display = Display()
    display.verbosity = 0

    results = {'failed': False}

    # verbosity 0 and task verbosity 2
    task.args = {'verbosity': 2, 'msg': 'Hello world!'}
    module = ActionModule(task, display, templar)
    assert module.run(None, None) == {'skipped': True, 'skipped_reason': 'Verbosity threshold not met.', 'failed': False}

    # verbosity 2 and task verbosity 1

# Generated at 2022-06-21 01:55:54.852586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    # Construct args
    module_args = {
        'msg' : 'Hello world',
        'verbosity' : 0,
    }

    # Construct class
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Construct methods
    action.set_loader(loader=None)
    action.set_task(task=None)
    action.set_play_context(play_context=None)
    
    # Initialize result
    result = {
        'failed' : False,
        'skipped' : False,
        'skipped_reason' : "Verbosity threshold not met.",
    }

    # run() with an invalid verbosity

# Generated at 2022-06-21 01:56:03.505516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    my_task = dict(
        action = dict(
            module = "debug"
        ),
        args = dict(
            msg = "Hello world!"
        )
    )
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    am = ActionModule(my_task, loader, variable_manager)
    result = am.run(variable_manager, loader)
    assert result['msg'] == "Hello world!"
    assert result['failed'] == False

    # test with verbosity 0, msg should not be in result
    my_task['args']['verbosity'] = 0
    am = Action

# Generated at 2022-06-21 01:56:06.465954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(load_args=dict(msg = "Hello World"))
    assert module.name == "Hello World"

# Generated at 2022-06-21 01:56:06.789274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:56:09.351852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module=ActionModule(dict(args=dict(verbosity=True)))
    print('Testing ActionModule constructor')
    print(action_module._display.verbosity)

# Generated at 2022-06-21 01:56:12.101624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    
    assert module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-21 01:56:16.648666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()

# Generated at 2022-06-21 01:56:33.831132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    # Create an instance of class ActionModule
    test = ActionModule()

    # Init TaskBase
    test._task = TaskBase()

    # Create a TaskExecutionContext object
    task_execution_context = TaskExecutionContext()
    task_execution_context.remote_addr = "1.2.3.4"
    task_execution_context.connection = "local"
    test._task._task_execution_context = task_execution_context

    # Init Display
    display = Display()
    display.verbosity = 2
    test._display = display

    # Init variables
    test._templar = Templar(variables={})

    # Test with msg variable
    test._task.args = {'msg': 'Hello world!'}

# Generated at 2022-06-21 01:56:40.164116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class MockTask(object):
        def __init__(self, args):
            self.args = args

    class MockPlayContext(PlayContext):
        def __init__(self):
            super(MockPlayContext, self).__init__()
            self.verbosity = 0

    class MockDisplay(object):
        verbosity = 0

        def __init__(self):
            self.verbosity = 5


# Generated at 2022-06-21 01:56:45.178425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Execute constructor of ActionModule
    am = ActionModule()
    # Make sure _VALID_ARGS was initialized
    assert am._VALID_ARGS is not None

# Generated at 2022-06-21 01:56:45.897265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 01:56:54.935625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    # Create play context
    play_context = PlayContext()
    play_context._verbosity = 4
    play_context.remote_addr = '192.168.1.1'
    play_context.remote_user = 'foo'
    play_context.connection = 'ssh'
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'foo'

    # Create ansible variables
    ansible_vars = dict()
    ansible_vars['ansible_connection'] = 'ssh'
    ansible_vars['ansible_ssh_user'] = 'foo'

# Generated at 2022-06-21 01:57:04.751326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test: ansible.plugins.action.debug.ActionModule.run
    '''
    import os
    import sys
    import unittest
    import ansible
    from ansible.plugins.action.debug import ActionModule
    from ansible.utils.color import stringc
    from ansible.utils.display import Display

    if not hasattr(unittest.TestCase, 'assertIn'):
        unittest.TestCase.assertIn = lambda self, member, container, msg=None: self.assertTrue(member in container)
    if not hasattr(unittest.TestCase, 'assertNotIn'):
        unittest.TestCase.assertNotIn = lambda self, member, container, msg=None: self.assertTrue(member not in container)



# Generated at 2022-06-21 01:57:05.450123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 01:57:09.997074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule.
    '''
    class Task():
        def __init__(self):
            self.args = {'msg': "Hello world!", 'verbosity': 0}

    class Play():
        def __init__(self):
            self.name = "helloworld"

    class PlayContext():
        def __init__(self):
            self.verbosity = 0

    class TaskQueueManager():
        def __init__(self):
            self._play = Play()
            self.play_context = PlayContext()

        def get_vars(self):
            return {'ansible_version': {'full': 'test'}}

    class Options():
        timeout = 10
        verbosity = 0
        step = 0
        start_at_task = 0

# Generated at 2022-06-21 01:57:21.388215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # import dependencies
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.debug import ActionModule
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult

   

# Generated at 2022-06-21 01:57:32.740855
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # tests for the run method of class ActionModule
    # dummy task
    task = {"args":{}}

    # dummy connection
    connection = None

    # dummy tmp
    tmp = None

    # dummy display
    display = {"verbosity": 0}

    def templar(template, convert_bare=False, fail_on_undefined=False, overrides=None):
        return template

    # dummy play context
    play_context = {}

    # dummy arguments
    arguments = {}

    # call the module
    module = ActionModule(task, connection, tmp, display)
    result = module.run(task_vars={}, tmp=tmp, task_vars=task_vars)
    assert result["failed"] is False
    assert result["skipped"] is False
    assert result["changed"] is False

# Generated at 2022-06-21 01:57:58.089760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def construct_module(args):
        action = ActionModule(
            {'args': args},
            None,
            '/usr/lib/python2.7/site-packages/ansible/playbook/play_context.py',
        )
        action.display = Display()
        return action

    def run_module(args):
        action = construct_module(args)
        return action.run()

    # Fail if neither 'var' nor 'msg' are specified
    def test_no_msg_or_var():
        result = run_module({})
        assert 'failed' in result
        assert result['failed'] is True

    # Fail if both 'var' and 'msg' are specified

# Generated at 2022-06-21 01:57:58.717403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-21 01:57:59.156850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 01:58:04.428466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    display = MockDisplay()
    display.verbosity = 0
    class MockTemplar:
        def template(self, str, convert_bare=True, fail_on_undefined=True):
            return str
    task = { 'args': {'verbosity': 1}}
    action = ActionModule(task, task_vars, display, MockTemplar())
    result = action.run(None, task_vars)

    assert result.get('failed') is False
    assert result.get('msg') == 'Hello world!'
    task = { 'args': {'msg': 'Hello Ansible!', 'verbosity': 1}}
    action = ActionModule(task, task_vars, display, MockTemplar())
    result = action.run(None, task_vars)
    assert result

# Generated at 2022-06-21 01:58:11.110198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create object for ActionModule
    actionModuleObject = ActionModule(task="print", connection="local", play_context=dict(become=False, become_method=None, become_user=None, check_mode=False, diff_mode=False, verbosity=0), loader=None, templar=None, shared_loader_obj=None)
    print("Unit Test Case : " + str(actionModuleObject))

# import the test module to call its unit test function
import ansible.plugins.action.debug
print("Unit Test Case(s) : " + str(ansible.plugins.action.debug.test_ActionModule()))

# Generated at 2022-06-21 01:58:17.667428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    run: plugin method unit test
    """
    # Using object of class ActionBase to execute module.
    obj = ActionBase()

    # when verbosity <= display verbosity
    obj.run(verbosity=1)


# Generated at 2022-06-21 01:58:18.533131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:58:20.627280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, object)

# Generated at 2022-06-21 01:58:32.956161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of ActionModule class
    a = ActionModule()
    # create faux task object
    class FauxTask:
        def __init__(self):
            self.args = {"msg" : "Hello world!"}
    t = FauxTask()
    # create faux display object
    class FauxDisplay:
        verbosity = 0
    d = FauxDisplay()
    # assign faux task & display to ActionModule instance
    a._task = t
    a._display = d
    # call the run method of ActionModule class
    result = a.run()
    # check if result attribute has proper values
    if (result['msg'] != 'Hello world!') or (result['failed'] != False):
        raise AssertionError("Wrong result attribute in class ActionModule instance")
    # create faux task object

# Generated at 2022-06-21 01:58:45.464990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    tasks = [dict(action=dict(module='debug', args=dict(msg='foobar')))]
    mock_task = dict(action='debug')

    mock_task_copy = mock_task.copy()
    mock_task_copy.update(
        args=dict(msg='foobar'),
        action=dict(module_name='debug', module_args=dict(msg='foobar'))
    )

    display = Display()
    play_context = dict(verbosity=5)


# Generated at 2022-06-21 01:59:09.635046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {}, task=1)
    assert not ActionModule(None, {}, task=1)


# Generated at 2022-06-21 01:59:14.575136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actmod = ActionModule(
            task=dict(action=dict(module_name='debug', module_args=dict(msg='Hello world!'))),
            connection=None,
            play_context=dict(),
            loader=None,
            templar=None,
            shared_loader_obj=None)
    return actmod

# Generated at 2022-06-21 01:59:26.178780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test case for the method run of class ActionModule
    """

    action = ActionModule()
    task = dict(args=dict())
    task['args']['verbosity'] = 1

    # Testcase without msg and var
    task['args']['verbosity'] = 0
    result = action.run(tmp=None, task_vars=None)
    assert(result['skipped'] == True)

    # Testcase with msg
    task['args']['msg'] = 'Hello world!'
    task['args']['verbosity'] = 0
    result = action.run(tmp=None, task_vars=None)
    assert(result['skipped'] == True)

    # Testcase with var
    task['args']['var'] = 'Hello world!'
    task['args']['verbosity']

# Generated at 2022-06-21 01:59:27.633083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:59:36.574493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.module_utils.ansible_modlib.common._collections_compat import MutableMapping, MutableSequence
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.ansible_modlib.tests.test_module import DummyModule
    from ansible.module_utils.ansible_modlib.tests.test_module import DummyConnection

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types

    # initialize
    mod = DummyModule()
    mod.params = dict()
    mod._verbosity = 0
    mod._supports_async = False
    mod.module_name = 'debug'
    mod._connection = Dummy

# Generated at 2022-06-21 01:59:47.252437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()
    ansible_module_instance = AnsibleModuleMock()
    ansible_module_instance_2 = AnsibleModuleMock()
    ansible_module_instance_3 = AnsibleModuleMock()
    ansible_module_instance_4 = AnsibleModuleMock()
    ansible_module_instance_5 = AnsibleModuleMock()
    ansible_module_instance_6 = AnsibleModuleMock()
    ansible_module_instance_7 = AnsibleModuleMock()
    ansible_module_instance_8 = AnsibleModuleMock()
    ansible_module_instance_9 = AnsibleModuleMock()
    ansible_module_instance_10 = AnsibleModuleMock()
    ansible_module_instance_11 = AnsibleModuleMock()
    ansible

# Generated at 2022-06-21 01:59:49.843295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict()),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 01:59:50.487985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError()

# Generated at 2022-06-21 02:00:02.857466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=too-many-branches,too-many-statements,protected-access
    from ansible.playbook.play import Play

    test_play = Play()
    test_play._attributes = {'vars': {}}

    test_action = ActionModule(play=test_play, loader=None, templar=None, shared_loader_obj=None)
    assert type(test_action) == ActionModule
    assert test_action._loader == None
    assert test_action._templar == None
    assert test_action._shared_loader_obj == None
    assert test_action._task == None
    assert test_action._role == None
    assert test_action._play == test_play
    assert test_action._loader_name == None
    assert test_action._display.verbosity == 0

# Generated at 2022-06-21 02:00:15.479992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = 'test'
    mock_loader = "mock"
    mock_templar = "mock"
    mock_shared_loader_obj = "mock"
    mock_action_base_class = "mock"
    mock_display = "display"
    mock_options = "options"

    test = ActionModule(mock_loader, mock_templar, mock_shared_loader_obj, action=mock_action_base_class, task=module,
                        connection=mock_display, play_context=mock_options, loader=mock_loader, templar=mock_templar,
                        shared_loader_obj=mock_shared_loader_obj)
    assert test.action == mock_action_base_class
    assert test.task == module
    assert test.connection == mock_

# Generated at 2022-06-21 02:01:03.190413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert ActionModule.TRANSFERS_FILES == False


# Generated at 2022-06-21 02:01:11.497196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a proxy for class ActionModule, which we are testing
    class ActionModuleProxy(ActionModule):
        def __init__(self):
            # Init the parent class
            super(ActionModuleProxy, self).__init__()

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            tmp = "TESTTMP"
            task_vars['TESTTASKVARS'] = ["TESTTASKVARS1", "TESTTASKVARS2"]
            return super(ActionModuleProxy, self).run(tmp, task_vars)

    # Create a proxy for class ActionBase, which the class ActionModule is inheriting from
    class ActionBaseProxy(ActionBase):
        def __init__(self):
            self

# Generated at 2022-06-21 02:01:17.994935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    import ansible.constants as C
    import json

    loader = DataLoader
    options = PlaybookExecutor.default_options()
    variable_manager = VariableManager
    loader = DataLoader
    inventory = InventoryManager
    variable_manager = VariableManager
    variable

# Generated at 2022-06-21 02:01:18.880413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:01:23.669610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    params = {
        'msg': 'Hello world!',
        'var': 'msg',
    }
    action_module = ActionModule(params, { 'debug': {} })
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:01:26.475371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.debug
    actionModule = ansible.plugins.action.debug.ActionModule(task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert actionModule is not None

# Generated at 2022-06-21 02:01:28.668015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = __import__('action_plugins.debug', globals(), locals(), [], 0).ActionModule(None, {}, None, {})
    assert module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-21 02:01:29.284871
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:01:33.597496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        """ Unit test for testing module run """
        module = None
        tmp = None
        task_vars = None

        action1 = ActionModule(action=module, task=tmp, connection=tmp)
        result1 = action1.run(tmp, task_vars)
        assert result1 == {"failed": True, "msg": "'msg' and 'var' are incompatible options"}

        action2 = ActionModule(action=module, task=tmp, connection=tmp)
        self._task.args.update(dict(msg="Hello world!"))
        result2 = action2.run(tmp, task_vars)
        assert result2 == {"msg": "Hello world!", "_ansible_verbose_always": True, "failed": False}

# Generated at 2022-06-21 02:01:46.382822
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # mock
    import ansible.module_utils.facts as facts
    mock_display = facts.AnsibleDisplay()
    mock_module_utils = {'ActionBase': ActionBase}
    mock_task = {'vars': None, 'args': {'msg': 'Hello world!'}}
    mock_templar = facts.AnsibleUnsafeText('Hello world!')

    # action module
    am = ActionModule(mock_templar, mock_task, mock_display)

    # run
    am.run(mock_module_utils, None)
    # check
    assert am._task.args['msg'] == 'Hello world!'

    # run again
    am.run(mock_module_utils, None)
    # check
    assert am._task.args['msg'] == 'Hello world!'

# Generated at 2022-06-21 02:03:55.554208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    # test case 1 - no msg and no var
    module._task.args = dict()
    result = module.run()
    assert result['failed'] is False
    assert result['msg'] == 'Hello world!'
    # test case 2 - msg only
    module._task.args = dict(msg='Hello world!')
    assert module.run()['msg'] == 'Hello world!'
    # test case 3 - var only
    module._task.args = dict(var='Hello world!')
    assert module.run()['Hello world!'] == 'Hello world!'
    # test case 4 - msg and var
    module._task.args = dict(msg='Hello world!', var='Hello world!')
    assert module.run()['failed'] is True

# Generated at 2022-06-21 02:03:57.376797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(argument_spec={},
                     add_file_common_args=False)
    assert a._VALID_ARGS == frozenset(['msg', 'var', 'verbosity'])
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:03:58.719377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(True)

# Generated at 2022-06-21 02:04:05.852174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test set up
    import shutil
    import os
    tempdir = '/tmp/ansible_test/'
    if os.path.exists(tempdir):
        shutil.rmtree(tempdir)
    os.makedirs(tempdir)
    test_name = 'test_print.py'
    src_file = './plugins/action/%s.py' % test_name
    dest_file = './%s%s' % (tempdir, test_name)
    shutil.copy(src_file, dest_file)
    sys.path.append(tempdir)
    test = __import__(test_name)
    reload(test)
    action = getattr(test, "ActionModule")
    action_inst = action()

    # Test execution
    action_inst._display.verb

# Generated at 2022-06-21 02:04:08.314029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert not module


# Generated at 2022-06-21 02:04:16.263817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test data
    class MockActionBase:

        def __init__(self):
            self.verbosity = 0

        def run(self, tmp, task_vars):
            return {'changed': False, 'failed': False}

    class MockDisplay:

        def __init__(self):
            self.verbosity = 0

    class MockTask:

        def __init__(self):
            self.args = {'var': 'a'}

    class MockTemplar:

        def __init__(self):
            self.module_name = 'test'

            # Mock methods
        def template(self, sc):
            if sc is 'a':
                return 'b'
            else:
                return sc

            # Mock module
    class test:

        def __init__(self):
            self.params = {}



# Generated at 2022-06-21 02:04:25.209834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        module_arg_spec = dict(
            msg=dict(type='str', required=False),
            var=dict(type='str', required=False),
            verbosity=dict(type='int', required=False)
        )
        # create a dummy module to pass into ActionModule
        mock_module = type('AnsibleModule', (object,), dict(
            argument_spec=module_arg_spec,
            check_mode=False,
        ))

        task_vars = dict()

        def get_vars(name):
            return task_vars.get(name)

        # Create a dummy templar
        templar = type('Templar', (object,), dict(
            template=lambda x, y=None, z=None: x,
        ))

        # create a dummy display
        display = type

# Generated at 2022-06-21 02:04:35.613631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test object of type ActionModule
    test_obj = ActionModule(None, None, None, None, None, None, None)
    test_obj._task = ACTION_PLUGIN_KWARGS['task']
    test_obj._task.args = {'msg':'hello world', 'verbosity':1}
    test_obj._display = ACTION_PLUGIN_KWARGS['display']
    test_obj._connection = ACTION_PLUGIN_KWARGS['connection']
    test_obj._loader = ACTION_PLUGIN_KWARGS['loader']
    test_obj._templar = ACTION_PLUGIN_KWARGS['templar']
    tmp = None
    task_vars = dict()

# Generated at 2022-06-21 02:04:36.445988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 02:04:45.351279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # get function extract_local_facts of class ActionModule for testing
    from ansible.plugins.action import ActionModule
    am = ActionModule(None, dict(), True)
    am.check_mode = False

    # test with msg
    data = am.run(tmp = None,
                  task_vars = None)
    assert type(data) is dict
    assert 'msg' in data
    assert data['msg'] == 'Hello world!'

    # test with var
    data = am.run(tmp = None,
                  task_vars = None)
    assert type(data) is dict
    assert 'msg' in data
    assert data['msg'] == 'Hello world!'

    # test with var, verbosity
    data = am.run(tmp = None,
                  task_vars = None)