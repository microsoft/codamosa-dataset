

# Generated at 2022-06-21 01:55:41.784487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import test_utils
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    mock_variable_manager = test_utils.MockVariableManager()
    mock_loader = test_utils.MockLoader()
    play_context = PlayContext()
    play_context._loader = mock_loader
    play_context.CLIARGS = dict()
    mock_task = Task()
    mock_task.action = 'debug'
    mock_task._role = None
    mock_task._role_path = None


# Generated at 2022-06-21 01:55:52.133005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import yaml
    import json
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a copy of environment variable
    old_environment = dict(ANSIBLE_CONFIG=None, ANSIBLE_LIBRARY=None, ANSIBLE_MODULE_UTILS=None)
    old_environment.update(os.environ)

    os.environ['ANSIBLE_CONFIG'] = tmpdir
    os.environ['ANSIBLE_LIBRARY'] = tmpdir
    os.environ['ANSIBLE_MODULE_UTILS'] = tmpdir

    # Create modules directories
    module_utils = os.path.join(tmpdir, 'ansible', 'module_utils')
    os.makedirs(module_utils)

    # Create action plugin
    action

# Generated at 2022-06-21 01:56:01.036881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    sys.path.append('.')
    #from ansible.plugins.action import ActionModule

    config = AnsibleConfig()
    config._config_data = {}
    config._config_data['DEFAULT'] = {}
    config._config_data['DEFAULT']['roles_path'] = '.'
    ansible_playbook = PlayBook({'verbosity': 5, 'listhosts': True, 'listtasks': True, 'listtags': True, 'syntax': True},
                                [], None, None, config)

    task = ansible_playbook.get_task()
    action = ActionModule(task, ansible_playbook.connection, ansible_playbook.inventory)

    print (action)
    print (type(action))
    print (dir(action))



# Generated at 2022-06-21 01:56:02.537962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for the module run method."""
    pass

# Generated at 2022-06-21 01:56:12.319361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(
        task=dict(action=dict(module_name='my_action', module_args=dict(a=True, b='foo'))),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert x._task.action['module_name'] == 'my_action'
    assert x._task.action['module_args'] == dict(a=True, b='foo')

# Generated at 2022-06-21 01:56:22.912035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test result when verbosity is greater than verbosity in task
    action = ActionModule()
    action.set_task(dict(
        args=dict(verbosity=1),
    ))
    action.set_display(dict(
        verbosity=2,
    ))
    result = action.run()
    assert result['failed'] == False
    assert result['skipped'] == True
    assert result['skipped_reason'] == "Verbosity threshold not met."

    # Test result when verbosity equals to verbosity in task
    action = ActionModule()
    action.set_task(dict(
        args=dict(verbosity=1),
    ))
    action.set_display(dict(
        verbosity=1,
    ))
    result = action.run()
    assert result['failed'] == False

# Generated at 2022-06-21 01:56:34.057530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None,
                                 path_aliases=None,
                                 no_log=False,
                                 keep_remote_files=False,
                                 connection=None,
                                 shell=None,
                                 _uses_shell=False,
                                 module_implementation_preferences=None,
                                 become=False,
                                 become_method=None,
                                 become_user=None,
                                 become_ask_pass=False,
                                 become_flags=None,
                                 check=False,
                                 diff=None,
                                 task=None,
                                 environment=None,
                                 runner_path=None,
                                 name=None,
                                 branch=None)
    #assert_equal(action_module, )
    assert True



# Generated at 2022-06-21 01:56:40.288189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    # Initialize Ansible
    loader = DataLoader()

# Generated at 2022-06-21 01:56:42.054846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test for method run with basic functionality
    assert False



# Generated at 2022-06-21 01:56:47.586007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert mod._task.args is None
    assert isinstance(mod._VALID_ARGS, frozenset)

# Generated at 2022-06-21 01:57:03.953488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for _run_module of class ActionModule
    module = ActionModule()
    task = MockTask()
    setattr(task, 'args', {'msg': 'hello world'})
    res = module.run(task_vars={'hoge': 'foo'}, tmp=None, task_vars=None)
    assert res['msg'] == 'hello world'
    assert 'failed' in res
    assert not res['failed']

    # Unit test for _run_module of class ActionModule
    module = ActionModule()
    task = MockTask()
    setattr(task, 'args', {'msg': 'hello world', 'verbosity': 3})
    res = module.run(task_vars={'hoge': 'foo'}, tmp=None, task_vars=None)

# Generated at 2022-06-21 01:57:13.836101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile

    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.plugins.loader import action_loader
    for action_plugin in action_loader.all():
        obj = action_plugin.get_class()
        try:
            action_obj = obj()
        except:
            continue

        if not isinstance(action_obj, ActionBase):
            continue

        host_name = 'localhost'
        host = dict()
        host['hostname'] = host_name
        task = dict()
        task['action'] = 'test'

# Generated at 2022-06-21 01:57:14.197811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 01:57:15.402810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for test_ActionModule_run method
    pass

# Generated at 2022-06-21 01:57:23.911046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import ansible.compat
    import sys
    import json

    class test_ansible_module(object):
        def __init__(self, task_vars):
            self.task_vars = task_vars
            self.args = dict()
        
        def run(self):
            class test_con(object):
                def __init__(self):
                    self.verbosity = 0
            print("Testing ActionModule method run")
            act = ActionModule(self, test_con())
            result = act.run(None, self.task_vars)
            print(json.dumps(result, indent=4, sort_keys=True))
            return result


# Generated at 2022-06-21 01:57:25.088789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 01:57:29.510580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(name='debug', action=dict(msg='Hello world', verbosity=0), task=dict(action='debug', args=dict(msg='Hello world')))


# Generated at 2022-06-21 01:57:30.275473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 01:57:42.811118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host, Group

    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_vault_secrets(loader.get_vault_secrets(None))

    host = Host

# Generated at 2022-06-21 01:57:51.597131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    # create a dummy task
    play_context = dict(
        basedir='/tmp/test',
        remote_addr='127.0.0.10',
        port=22,
        remote_user='test'
    )
    task1 = TaskInclude()
    task_ds1=dict(
        name='debug 1',
        action='debug',
        args=dict(
            msg="Connected to {{ inventory_hostname }}",
            verbosity=4
        )
    )
    task1._load_task_data(task_ds1)

# Generated at 2022-06-21 01:58:04.246600
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert am._templar is not None
  assert am._display is not None

# Generated at 2022-06-21 01:58:05.709775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_raises(TypeError,ActionModule)

# Generated at 2022-06-21 01:58:08.732750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)
    assert(a != None)

# Generated at 2022-06-21 01:58:10.315440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module="debug", msg="Hello world!"))
    action = ActionModule(task, dict())
    assert action is not None

# Generated at 2022-06-21 01:58:24.940846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import mock
    from ansible.plugins.action.debug import ActionModule as class_to_test
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    sys.modules['ansible.module_utils.basic'] = mock.Mock()
    sys.modules['ansible.module_utils._text'] = mock.Mock()
    sys.modules['ansible.module_utils.six'] = mock.Mock()
    sys.modules['ansible.module_utils.urls'] = mock.Mock()
    # mock ansible.module_utils.basic.AnsibleModule.exit_json()
    sys.modules['ansible.module_utils.basic'].AnsibleModule.exit_json = mock.Mock

# Generated at 2022-06-21 01:58:29.077846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-21 01:58:37.150995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    from ansible.utils.vars import load_extra_vars
    
    from ansible.module_utils.facts import Facts
    from ansible.plugins.callback import CallbackBase
    
    class TestCallback(CallbackBase):
        pass
    
    class MyCallbackModule(CallbackBase):
        """
        A sample callback module, which prints to stdout
        """
        
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'sample'
        

# Generated at 2022-06-21 01:58:44.072304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test to check the constructor of ActionModule"""
    testActionModuleObj = ActionModule('test', dict(msg='Hello'))
    assert testActionModuleObj._task.args['msg'] == 'Hello'
    assert testActionModuleObj._task.args['var'] == None
    assert testActionModuleObj._task.args['verbosity'] == 0
    assert testActionModuleObj._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))


# Generated at 2022-06-21 01:58:53.411733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare required arguments for method run
    task_vars = dict()
    tmp = None
    # Create an instance of AnsibleModule to be passed to method run
    module_args = dict()
    module_args['msg'] = to_text("test")
    test_ActionModule = ActionModule(None, None, module_args, None)

    # Test method run
    result = test_ActionModule.run(tmp, task_vars)['msg']

    assert result == "test"


# Generated at 2022-06-21 01:59:00.569563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = {}
    task = {"args": {"msg": "Hello", "var": "var_name"}, "name": "test_action"}
    action = ActionModule(task, host, "/tmp")

    assert action._task.args == {"msg": "Hello", "var": "var_name"}, "Constructor of class ActionModule is not implemented properly"

# Generated at 2022-06-21 01:59:35.752979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_task_vars = dict()
    test_task_vars['result'] = False
    test_task_vars['msg'] = None
    test_task_vars['skipped'] = None
    test_task_vars['failed'] = None
    test_task_args = dict()
    test_task_args['msg'] = "Hello World!"
    test_task_args['var'] = None
    test_task_args['verbosity'] = '2'
    ansible_verbose_always = False
    ansible_verbose = 2

    test_task_action = ActionModule()
    test_action_result = test_task_action.run(None, test_task_vars)
    assert test_action_result['failed'] == False

# Generated at 2022-06-21 01:59:47.006187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def _task_executor_execute(self, task_vars=None):
        return {"changed": False}

    import ansible.plugins.action.debug
    ansible.plugins.action.debug.ActionModule._execute = _task_executor_execute
    assert(0 == ansible.plugins.action.debug.ActionModule.run({"msg":"test"})['msg'])
    assert("VARIABLE IS NOT DEFINED!" == ansible.plugins.action.debug.ActionModule.run({"var": "test"})['test'])
    assert("VARIABLE IS NOT DEFINED!" == ansible.plugins.action.debug.ActionModule.run({"var": "test", "verbosity": 1})['test'])

# Generated at 2022-06-21 01:59:48.731925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This test is here to make sure that just importing the ActionModule doesn't cause problems.
    module = ActionModule()
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-21 01:59:53.520536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action._display == None
    assert action._play_context == None
    assert action._task == None
    assert action._loader == None
    assert action._templar == None

# Generated at 2022-06-21 02:00:04.521190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict(msg='Hello world!', verbosity=0)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(module, ActionModule)

    module = ActionModule(
        task=dict(args=dict(var='msg', verbosity=0)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(module, ActionModule)


# Generated at 2022-06-21 02:00:16.116039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import tempfile

    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.action.debug import ActionModule

    from ansible.template import Templar
    from ansible.plugins import filter_loader, module_loader

    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'modules'))
    filter_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'filters'))

    task_vars = {}
    host_vars = {}

    task = dict(action=dict())
    play_context = PlayContext()
    play_context.check_mode = False
    play_context.become = None
    play_context.become

# Generated at 2022-06-21 02:00:27.059378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader

    import platform

    # Get access to private members of class ActionModule
    # This is basically a copy of the code in run() method
    am = action_loader.get('debug', task=None, connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)

    # no verbosity specified
    result = {'failed': False, '_ansible_verbose_always': True, 'msg': 'Hello world!'}
    am._task

# Generated at 2022-06-21 02:00:30.245233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """

    # PASS: Tested below in run()
    pass

# Generated at 2022-06-21 02:00:33.773841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(args=dict(verbosity=1)), display=1)
    result = action_module.run()
    assert result['msg'] == 'Hello world!'

# Generated at 2022-06-21 02:00:40.122163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy object of Display class
    display = Display()

    # Dummy object of PlayContext class
    play_context = PlayContext()

    # Dummy object of Task class
    task = Task()
    task.args = {
        'verbosity': 0,
    }

    # Dummy object of ActionModule class
    action_module = ActionModule(task, play_context, display)

    # Get task_vars
    task_vars = action_module.get_task_vars()

    # Call function run of class ActionModule
    result = action_module.run(task_vars=task_vars)
    assert result['failed'] == False


# Generated at 2022-06-21 02:01:24.212103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    assert type(actionModule.run()) is dict

# Generated at 2022-06-21 02:01:35.582278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor import task_queue_manager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    options = mock.Mock()
    loader = DataLoader()
    options.connection = 'local'
    options.module_path = '/usr/share/ansible/'
    options.forks = 1
    options.become = None
    options.become_method = None
    options.become_user = None
    options.check = False
    options.extra_vars = ['ansible_verbosity=vvv']
    options.tags = ['all']


# Generated at 2022-06-21 02:01:40.237263
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = {}
    data['action'] = 'debug'

    task_obj = ActionModule(data, None, None)
    assert task_obj is not None, "Failed to initialize the object"

# Generated at 2022-06-21 02:01:41.909043
# Unit test for constructor of class ActionModule
def test_ActionModule():
	act_obj = ActionModule()
	assert isinstance(act_obj, ActionModule) == True
	print("ActionModule constructor test passed !")

if __name__ == '__main__':
	test_ActionModule()

# Generated at 2022-06-21 02:01:45.541174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(args=dict(var="Hello world!")))
    assert action.run(task_vars=dict()) == {u'skipped': False, u'msg': 'Hello world!', u'failed': False, u'changed': False}


# Generated at 2022-06-21 02:01:51.478325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m._task.args = {u'msg': u'Hi'}
    result = m.run()
    assert(result)
    assert(not result['failed'])
    assert(result['msg'] == u'Hi')


# Generated at 2022-06-21 02:01:54.033251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run') and callable(ActionModule.run), 'ActionModule.run is not a function'
    assert hasattr(ActionModule, 'run') and callable(ActionModule.run), 'ActionModule.run is not a function'


# Test for run method of class ActionModule

# Generated at 2022-06-21 02:02:02.657011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #import sys
    #import lib.action.ActionModule as actionModules
    from Ansiballz.lib.ansiballz import AnsiballzBase
    import ansible.module_utils._text as _ansible_internal_text

    def to_text(arg):
        if arg is None:
            return ""
        if isinstance(arg, (list, dict)):
            return str(arg)
        if not isinstance(arg, str):
            arg = str(arg)
        if sys.version_info < (3,):
            arg = arg.decode('utf-8')
        return arg

    def to_bytes(arg):
        if arg is None:
            return b""
        if isinstance(arg, (list, dict)):
            return str(arg)

# Generated at 2022-06-21 02:02:15.122445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ModuleBase
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    class TestModuleBase(ModuleBase):
        def __init__(self):
            self.params = {}
            self.task = Task()
            self._task_vars = VariableManager()
            self._task_vars.extra_vars = {}

    m = TestModuleBase()
    m.params = {}

    # Both msg and var option is not allowed
    m.params['msg'] = 'Hello world'
    m.params['var'] = 'foo'
    result = m.run()
    assert 'msg' in result
    assert 'failed' in result
    assert 'foo' not in result

# Generated at 2022-06-21 02:02:18.124059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert len(action_module.run(None)) == 3

# Generated at 2022-06-21 02:04:44.214204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import os
    import sys

    testdir = os.path.dirname(os.path.realpath(__file__))
    testdir = os.path.join(testdir, 'test_data', 'action_module')
    sys.path.append(testdir)

    # Set Ansible config.
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._shared_loader_obj.module_loader = None
    action_module._shared_loader_obj.module_utils_loader = None
    action_module._templar._available_variables = None
    action_module._templar.environment = None

    # Create a fake AnsibleConfig object
    config = action_

# Generated at 2022-06-21 02:04:45.166879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:04:53.464204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# Method run will return a dictionary containing message and verbosity
	result = {}
	result['msg'] = "Hello world!"
	result['failed'] = False
	result['_ansible_verbose_always'] = True
	obj = ActionModule()
	assert obj.run(tmp = None, task_vars = None) == result

test_ActionModule_run()

# Generated at 2022-06-21 02:04:54.316332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:05:06.234092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Mock the display and the template to use:
    import ansible.plugins.action.debug


    print('### Testing ActionModule class constructor with verbosity 0 ###')
    action_module = ansible.plugins.action.debug.ActionModule({'verbosity': 0})
    print('verbosity = ' + str(action_module._display.verbosity))
    print('### Finished testing ActionModule class constructor with verbosity 0 ###\n')

    print('### Testing ActionModule class constructor with verbosity 1 ###')
    action_module = ansible.plugins.action.debug.ActionModule({'verbosity': 1})
    print('verbosity = ' + str(action_module._display.verbosity))
    print('### Finished testing ActionModule class constructor with verbosity 1 ###')



# Generated at 2022-06-21 02:05:09.368920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run(None, None))


# Generated at 2022-06-21 02:05:10.516325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:05:19.230906
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import errors
    from ansible.plugins.loader import action_loader
    my_task = dict(action=dict(module='debug', args=dict(msg='Hi there!')))
    action = action_loader.get('debug', my_task, {})
    assert isinstance(action, ActionModule)
    # Test valid arguments
    assert action._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    # Test invalid arguments
    my_task = dict(action=dict(module='debug', args=dict(foo='bar')))

# Generated at 2022-06-21 02:05:29.569865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # If we cannot import the module, skip the test
    try:
        from ansible.plugins.action import ActionModule
    except ImportError:
        return
    # Instantiate class and call run()
    class TestModule(object):
        def __init__(self):
            self.args = {'msg': 'This is a test'}
            self.tmp = '/tmp'
            self.task_vars = {'a': 42}
            self.action = 'test'

    class TestTaskRunner(object):
        def __init__(self):
            self.verbosity = 0

    class TestPlay(object):
        def __init__(self):
            self.verbosity = 0

    class TestInventory(object):
        def __init__(self):
            self.hosts = {'localhost': {}}
