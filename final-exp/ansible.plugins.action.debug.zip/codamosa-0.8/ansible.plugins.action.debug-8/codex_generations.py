

# Generated at 2022-06-11 11:31:43.167864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.TRANSFERS_FILES is False
    assert a._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-11 11:31:53.907133
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create variables
    action1 = dict()
    action1['skipped'] = True
    module_args1 = dict()
    module_args1['msg'] = "test_msg"
    module_args1['verbosity'] = 1

    # Create object for ActionModule
    action = ActionModule()

    # Execute method run
    result = action.run(module_args1, action1)

    # Check result of method run
    if result['skipped']:
        print("FAIL: action skipped")
        print(result)
        exit(1)
    if result['msg'] != "test_msg":
        print("FAIL: wrong msg")
        print(result)
        exit(1)
    if result['failed']:
        print("FAIL: action failed")
        print(result)
        exit(1)

# Generated at 2022-06-11 11:32:03.543275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import sys
    import copy
    import json

    from ansible.module_utils._text import to_bytes, to_text

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader


    class TestCallbackModule(CallbackBase):
        """A test callback module"""

        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'

# Generated at 2022-06-11 11:32:06.201244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.debug as debug
    a = debug.ActionModule(None, dict(a=1), False, 'Foo bar')
    assert a
    assert a.transfers

# Generated at 2022-06-11 11:32:11.053309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(msg="Hello World")), task_vars=dict())
    assert action.__class__ == ActionModule
    assert action._task == dict(args=dict(msg="Hello World"))
    assert action.task_vars == dict()
    assert action._task.action == "debug"
    assert action._task.args == dict(msg="Hello World")

# Unit test of run method

# Generated at 2022-06-11 11:32:21.432383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    context = PlayContext()
    inventory = InventoryManager(loader=None, sources=None, _hosts=None, vault_secrets=None)
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=None,
        loader=None,
        options=context.options,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
    )


# Generated at 2022-06-11 11:32:31.862232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader

    class PlayContext:
        def __init__(self):
            self.remote_addr = '127.0.0.1'

    class Task:
        def __init__(self):
            self.args = {'msg': 'Hello world!', 'verbosity': 2}
            self.action = 'debug'
            self.name = 'foo'

    class Block:
        def __init__(self):
            self.rescue = []
            self.always = []


# Generated at 2022-06-11 11:32:39.977080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    print:
        msg: hello world
    '''
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-11 11:32:49.904605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.utils
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils._text import to_text
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar

    noop_task = dict(action=dict(module='debug', args=dict(var='foo')))
    variables = dict(foo=42, bar='a')
    templar = Templar(variables=variables)
    action = ActionBase(task=noop_task, connection=None, play_context=None, loader=None, templar=templar, shared_loader_obj=None)

    # check if a class is a subclass of another class
    assert isinstance(action, ActionBase)

# Generated at 2022-06-11 11:32:57.119360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task
    args = {}
    args['verbosity'] = 2
    task = {}
    task['args'] = args

    # Create a fake ActionBase instance
    display = {}
    templar = {}
    ansible_modules_path = {}

    action = ActionModule(task, display, templar, ansible_modules_path)
    # ActionModule class does not use tmp and task_vars params.
    result = action.run(tmp=None, task_vars=None)

    d = {}
    d['msg'] = 'Hello world!'
    assert result == d

# Generated at 2022-06-11 11:33:04.816015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:33:11.660118
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup object under test
    module_args = {"msg": "Hello world!"}
    t = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Invoke method under test
    result = t.run(tmp=None, task_vars=dict())

    # Check results
    assert result == {"failed": False, "msg": "Hello world!", "_ansible_verbose_always": True}

# Generated at 2022-06-11 11:33:21.224926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    import json

    # Declare class instance
    action_module = ActionModule(
        task=dict(
            action=dict(module_name="debug"),
            args=dict(
                msg="hello world!",
                verbosity=0,
            ),
        ),
        connection=None,
        play_context=basic.AnsiblePlayContext(),
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )

    # Do actual method test
    result = action_module.run(None, None)

    assert result.get('failed') is False
    assert result.get('_ansible_verbose_always', False) is True
    assert result.get('msg') == 'hello world!'



# Generated at 2022-06-11 11:33:31.039251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Checks ActionModule run method"""

    module = ActionModule(play_context={}, templar={}, loader={})

    module._task.args = {'var': 'localhost'}
    module._templar.template = lambda x, convert_bare, fail_on_undefined: x
    assert module.run() == {'failed': False, 'localhost': 'localhost'}

    module._task.args = {'var': 'localhost', 'verbosity': 1}
    module._templar.template = lambda x, convert_bare, fail_on_undefined: x
    assert module.run() == {'failed': False, 'localhost': 'localhost'}

    module._task.args = {'var': 'localhost', 'verbosity': 1}
    module._display.verbosity = 2

# Generated at 2022-06-11 11:33:40.874901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize the class instance
    action_module = ActionModule(
        task=dict(args=dict(var='test string', msg=None, verbosity=2)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # Call method run of class ActionModule
    result = action_module.run(tmp=None, task_vars=None)
    # Display output
    print(result)

    # initialize the class instance
    action_module = ActionModule(
        task=dict(args=dict(var=None, msg='strings changed', verbosity=2)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

   

# Generated at 2022-06-11 11:33:49.933570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(args=dict(msg='foo')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    result = action.run(tmp=None, task_vars={})
    assert result == {
        'failed': False,
        'msg': 'foo'
    }

    # Test the use of a var argument
    action = ActionModule(
        task=dict(args=dict(var='msg')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    result = action.run(tmp=None, task_vars={'msg': 'foo'})

# Generated at 2022-06-11 11:33:59.740473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for verbosity set to 1
    test_args = {"msg": "Hello world", "verbosity": 1,}
    test_task = {"args": test_args,}
    test_loader = None
    test_templar = None
    test_shared_loader_obj = None
    test_play_context = None
    test_display = None
    test_action_plugin = ActionModule(test_task, test_connection, test_play_context, test_shared_loader_obj, test_display)
    test_action_plugin._templar = test_templar
    test_action_plugin.run(tmp, task_vars)

    # Test for verbosity set to 2
    test_args = {"msg": "Hello world", "verbosity": 2,}

# Generated at 2022-06-11 11:34:08.101798
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # the following are the test cases for ActionModule constructor
    testcase_ActionModule = dict()

    # the construction of ActionModule is correct with the given task
    testcase_ActionModule["correct_construction"] = {"task": {"action": "debug"}}

    # the construction of ActionModule is not correct with empty task
    # (Expected: failed)
    testcase_ActionModule["incorrect_construction_empty_task"] = {"task": {}}

    # the construction of ActionModule is not correct with empty action
    # (Expected: failed)
    testcase_ActionModule["incorrect_construction_empty_action"] = {"task": {"action": ""}}

    # the construction of ActionModule is not correct with unknown action
    # (Expected: failed)

# Generated at 2022-06-11 11:34:10.899524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule')
    action_module = ActionModule(None, None)
    print(action_module)

    print('Testing ActionModule members')
    action_module.run()
    print(action_module)

# Generated at 2022-06-11 11:34:11.928160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 11:34:31.763020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    module_name = 'action_plugin.py'
    module_args = ''

    # create the module instance
    action_module = ActionModule(module_name, module_args)

    # create test data
    tmp = None
    task_vars = {'var_name':'var_value'}
    action_module._task.args = {'msg':'Hello World!'}

    # run the module
    result = action_module.run(tmp, task_vars)

    # verify results
    assert result['msg'] == 'Hello World!'
    assert result['failed'] == False
    assert result['_ansible_verbose_always'] == True
    
    # create test data
    tmp = None
    task_vars = {'var_name':'var_value'}
    action_module

# Generated at 2022-06-11 11:34:40.920982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_display = {"verbosity": 0, "debug": False}
    fake_task = {"args": {"msg" : "Hello world!"}}
    fake_tmp = {"basedir": '/var/tmp'}
    am = ActionModule(fake_task, fake_display, fake_tmp)

    result = am.run(tmp=fake_tmp,task_vars=None)
    assert result == {"failed": False, "msg": "Hello world!", "_ansible_verbose_always": True}

    fake_task = {"args": {"var" : "testVar"}}
    am = ActionModule(fake_task, fake_display, fake_tmp)

    result = am.run(tmp=fake_tmp,task_vars={"testVar": "hello world"})

# Generated at 2022-06-11 11:34:50.897211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import ansible.constants as C

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # From the play context, set various defaults
    play_context.remote_user = C.DEFAULT

# Generated at 2022-06-11 11:34:54.441718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # create an instance of ActionModule class
    action = ActionModule()
    print("Instance created")
    # print string representation of ActionModule object
    print(str(action))
    # print doc string of ActionModule object
    print(ActionModule.__doc__)

# Generated at 2022-06-11 11:34:58.352589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create the mock objects for testing
    mock_task = MagicMock()
    mock_display = MagicMock()
    mock_templar = MagicMock()

    test_obj = ActionModule(mock_task, mock_display, mock_templar)
    assert test_obj._task.args['verbosity'] == 0

# Generated at 2022-06-11 11:35:08.870821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from collections import namedtuple
    from ansible.template import Templar

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    from ansible.vars.manager import VariableManager

    a = '''
    - name: Example

      debug:
        msg: 'Hello world'

      tags:
        - always
    '''
    b = '''
    - name: Example

      debug:
        msg: "{{var}}"
        var: " {{var}}"
      tags:
        - always
    '''
    c = '''
    - name: Example

      debug:
        msg: "{{var}}"
        var: 
          - "{{var}}"
      tags:
        - always
    '''
   

# Generated at 2022-06-11 11:35:10.191087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    test method run of class ActionModule
    '''
    pass

# Generated at 2022-06-11 11:35:20.297850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    aa = ActionModule(None, None, load_plugins=False)
    aa._display = Mock(verbosity=2)
    aa._templar = Mock(template=lambda x, **kwargs: x)
    aa._task = Mock(name="hello_world_task", args=dict(msg="Hello world", verbosity=1))
    aa.module = Mock(return_value=dict(rc=0))
    results = aa.run()
    assert results['failed'] == False
    assert results['msg'] == "Hello world"
    # test skipped results
    aa._task.args.update(dict(verbosity=3))
    results = aa.run()
    assert results['failed'] == False
    assert results['skipped'] == True

# Generated at 2022-06-11 11:35:21.577939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert( ActionModule.run(1,1) == 1 )

# Generated at 2022-06-11 11:35:23.482298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='debug'))
    assert ActionModule(task, dict())

# Generated at 2022-06-11 11:35:52.376553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock task
    class _task:
        def __init__(self, args):
            self.args = args

    # mock display
    class _display:
        def __init__(self, verbosity):
            self.verbosity = verbosity

    # mock templar
    class _templar:
        def template(self, template, convert_bare=None, fail_on_undefined=None):
            if template == u'{{test1}}':
                return u'test2'
            elif template == u'{{test2}}':
                return u'test3'
            elif template == u'{{test3}}':
                return u'test4'
            else:
                return u'test1'

    # initialize

# Generated at 2022-06-11 11:36:00.546765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    import ansible.playbook.task as task

    test_task = task.Task()
    test_task._role = None
    test_task.action = 'debug'
    test_task.args = dict()
    test_task.args['msg'] = 'Hello world!'
    test_task.args['verbosity'] = '0'

    test_module = ActionModule(task=test_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_module._display = Display()
    test_module._display.verbosity = 0
    test_module._display.deprecated('Some message')

    results = test_module.run()
    assert results['msg'] == 'Hello world!'

# Generated at 2022-06-11 11:36:09.536788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for action.module.run'''

    from ansible import errors
    from ansible.module_utils._text import to_native

    from units.mock.loader import DictDataLoader

    # Create a mock action module
    action = ActionModule(
        task={'args': {'var': 'foo', 'verbosity': 0}},
        connection=None,
        play_context=None,
        loader=DictDataLoader({}),
        templar=None,
        shared_loader_obj=None)

    # Mock action module's environment variables and data loader
    action.env = {'bar': 'baz'}
    action.loader.mock_add_directory({'template.j2': to_native('{{ bar }}')}, '.')

    # Initialize a list of variables
    task_

# Generated at 2022-06-11 11:36:13.616877
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Create fake object of class ActionBase
  actionBase = ActionBase()
  # Create object to test
  actionModule = ActionModule(actionBase._task, actionBase._connection, actionBase._play_context, actionBase._loader, actionBase._templar, actionBase._shared_loader_obj)

  # Test method run
  assert actionModule.run() == {'msg': 'Hello world!', '_ansible_verbose_always': True, 'failed': False}

# Generated at 2022-06-11 11:36:14.283447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:36:23.116612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for class to run action plugin
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock, MagicMock

    from ansible.plugins.action import ActionModule

    mock_ds= patch('ansible.plugins.action.action_debug.DebugActionModule._display')

    mock_task = MagicMock(spec_set=dict())
    mock_task.args = dict()
    mock_task_vars = MagicMock(spec_set=dict())
    action_plugin_object = ActionModule(task=mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 11:36:33.093063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing following results
    # 1. msg is present in args dict
    # 2. var is present in args dict
    # 3. var is list
    # 4. var is dict
    # 5. var is boolean
    # 6. var is integer
    # 7. var is string
    # 8. var is unicode string
    # 9. var is empty string
    # 10. var is not defined
    # 11. verbosity <= self._display.verbosity is not True
    # 12. Test for 'msg' and 'var' are incompatible options'

    from ansible.plugins import action

    from ansible.plugins.action.debug import ActionModule

    from ansible.executor.task_result import TaskResult

    task_result = TaskResult('')

    task_result._result = {'foo':'bar'}

    action_

# Generated at 2022-06-11 11:36:33.686457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:36:36.406737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = {}
    action = ActionModule(tmp, task_vars)
    assert(action.TRANSFERS_FILES == False)


# Generated at 2022-06-11 11:36:45.278625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up a fake module to test against.
    class FakeModule(ActionBase):
        def __init__(self, *args, **kwargs):
            super(FakeModule, self).__init__(*args, **kwargs)
            self.templar = MockTemplar()
            self._display = TextDisplay()
            self._task = Task()
            self._task.args = {'verbosity': 99}

        def run(self, *args):
            return super(FakeModule, self).run(*args)

    from ansible.module_utils.basic import AnsibleModule
    import collections

    AnsibleModule.run = lambda x: None

    # Set up a fake class for the display
    class TextDisplay(object):
        def __init__(self):
            self.verbosity = 0

    # Set up a fake class

# Generated at 2022-06-11 11:37:27.677359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action


# Generated at 2022-06-11 11:37:30.185397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-11 11:37:32.748666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.TRANSFERS_FILES == False
    assert isinstance(ActionModule._VALID_ARGS, frozenset)

# Generated at 2022-06-11 11:37:35.348125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-11 11:37:44.520107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    ansible_loader = DataLoader()
    ansible_inventory = InventoryManager(ansible_loader, sources=None)
    ansible_variable_manager = VariableManager(ansible_loader, ansible_inventory)
    ansible_play = ansible_inventory.get_playbook('example_playbook.yml')
    ansible_task = ansible_play.get_task('first_task')
    ansible_module = action_loader.get('debug', class_only=True)

# Generated at 2022-06-11 11:37:53.978811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = "localhost"

# Generated at 2022-06-11 11:37:54.848898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:38:03.500562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    class HostManager(object):
        def __init__(self):
            self.inventory = InventoryManager(loader=None, sources=None)
            self.variable_manager = VariableManager(loader=None, inventory=self.inventory)

    t = Task()
    h = HostManager()
    tqm = TaskQueueManager(
            inventory=h.inventory,
            variable_manager=h.variable_manager,
            loader=None,
        )

# Generated at 2022-06-11 11:38:11.907079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	"""
	If you wish to unit test a module or individual functions inside a module that is not a
	template plugin this is the most direct way to do so.
	You can also unit test other parts of functions that may be a template plugin by utilizing
	the AnsibleModule object as we do here.
	"""

	# Import necessary module
	try:
		import ansible.module_utils.basic
		import ansible.module_utils.six

	except ImportError as e:
		print ("failed=True message ='{0}'").format(e)
		sys.exit(1)

	# Setup the AnsibleModule

# Generated at 2022-06-11 11:38:21.838600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of ActionModule
    am = ActionModule()
    am._task = 'TASK'

    # create an instance of AnsibleOptions
    ao = AnsibleOptions()
    ao.verbosity = 2
    ao.connection = 'local'

    # create an instance of Display
    display = Display()
    display.verbosity = 2

    # create an instance of Options
    options = Options()
    options.connection = 'local'
    options.module_path = '/path/to/ansible/'

    # create an instance of PluginLoader
    pl = PluginLoader('./__init__.py', './__init__.py')
    pl.add_directory()

    # patch methods
    am._display = display
    am._templar = None

# Generated at 2022-06-11 11:40:18.653235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct an instance of class ActionModule
    # with test values for parameters, 'tmp', 'task_vars'
    actual_obj = ActionModule(tmp='tmp', task_vars='task_vars')
    assert actual_obj.TRANSFERS_FILES == False


# Generated at 2022-06-11 11:40:26.466457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if False:
        # Test action module constructor
        from ansible.plugins.action import ActionBase
        connection = "connection"
        yaml_data = "yaml_data"
        from ansible.utils.collection_loader import AnsibleCollectionLoader
        loader = AnsibleCollectionLoader()
        from ansible.parsing.dataloader import DataLoader
        dataloader = DataLoader()
        from ansible.vars.manager import VariableManager
        t_vars = dict()
        t_vars["inventory_hostname"] = "localhost"
        t_vars["group_names"] = ["ungrouped"]
        variables = VariableManager(loader=loader, inventory=host_list)
        task_uuid = "task_uuid"
        play_context = "play_context"

# Generated at 2022-06-11 11:40:34.915066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.debug
    from ansible.plugins.action.debug import ActionModule
    from ansible.module_utils._text import to_text

    mod = ansible.plugins.action.debug.ActionModule(
        task={"args": {"msg": "Hello_world"}},
        connection={"host": "localhost", "port": 80},
        play_context={"remote_addr": "localhost", "port": 80, "verbosity": 5},
        loader=None,
        templar=None,
        shared_loader_obj=None)
    result = mod.run(task_vars={"name": "Tam"}, tmp=None)
    assert result["msg"] == "Hello_world"
    assert result["failed"] == False

# Generated at 2022-06-11 11:40:35.477040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:40:42.761779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.modules.system
    
    test_module = ansible.modules.system
    module = AnsibleModule(
            argument_spec = test_module.ARGS,
            supports_check_mode=False
        )
    
    action_module = ActionModule(module=module,
            task=dict(args=dict(var = 'ansible_distribution'))
        )
    
    result = action_module.run()
    
    if ('msg' in result) or ('ansible_distribution' in result):
        assert True
    else:
        assert False

# Generated at 2022-06-11 11:40:51.064950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionModule:
        def __init__(self, *args):
            self.args = {}

        def set_task_args(self, args):
            self.args = args

    def run_mock_action_module(args, task_vars):
        mam = MockActionModule()
        mam.set_task_args(args)
        mam_instance = ActionModule(mam, None, tmp_path=None)
        return mam_instance.run(None, task_vars)

    assert run_mock_action_module({"msg": "hello"}, {}) == {
        "_ansible_verbose_always": True,
        "failed": False,
        "msg": "hello",
    }

# Generated at 2022-06-11 11:40:51.649072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:40:52.837059
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert ActionModule == type(ActionModule('', '', {}))


# Generated at 2022-06-11 11:41:01.215039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleError

    options = PlaybookExecutor.load_extra_vars()
    options['connection'] = 'local'
    options['forks'] = 1
    options['become'] = None
    options['become_method'] = None

# Generated at 2022-06-11 11:41:04.230324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, "run")
    assert hasattr(ActionModule, "_VALID_ARGS")
    assert hasattr(ActionModule, "TRANSFERS_FILES")
    assert isinstance(ActionModule._VALID_ARGS, frozenset)