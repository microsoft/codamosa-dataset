

# Generated at 2022-06-11 11:31:51.052217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import yaml
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_context = PlayContext()
    task = Task()
    task._role = None
    task.args = yaml.safe_load("""
        msg: "{{ lookup('pipe', 'hostname') }}"
        verbosity: 0
    """)

    am = ActionModule(task, play_context, '/path/to/ansible/lib')
    am.runner = MockRunner()
    result = am.run(task_vars={})

    assert (type(result) is dict)
    assert ('failed' in result)
    assert (not result['failed'])

# Generated at 2022-06-11 11:31:52.052829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:32:01.907721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    module = ActionModule(Task(), dict(msg='Hello world!', _ansible_check_mode=True))
    result = module.run(task_vars=dict(foo='bar'))
    assert result == {'msg': 'Hello world!'}

    module = ActionModule(Task(), dict(var='foo', _ansible_check_mode=True))
    result = module.run(task_vars=dict(foo='bar'))
    assert result == {'foo': 'bar'}

    module = ActionModule(Task(), dict(var='nested.var', _ansible_check_mode=True))
    result = module.run(task_vars=dict(nested={'var': 'bar'}))

# Generated at 2022-06-11 11:32:03.402182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res = ActionModule()
    value = res.run()
    print(value)

# Generated at 2022-06-11 11:32:11.010728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.color import stringc
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=["tests/inventory"])


# Generated at 2022-06-11 11:32:21.385858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

if __name__ == '__main__':
    import imp
    import sys
    import os
    import pdb

    if len(sys.argv) < 2:
        print("usage: %s unit_test|constructor" % sys.argv[0])
        sys.exit(1)

    test = sys.argv[1]

    if test == "unit_test":
        mpath = sys.path[0] + "/../"
        sys.path.append(mpath)

        PACKAGE_PARENT = '..'
        SCRIPT_DIR = os.path.dirname(os.path.realpath(os.path.join(os.getcwd(), os.path.expanduser(__file__))))

# Generated at 2022-06-11 11:32:25.685390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test empty ActionModule constructor
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

    # Test ActionModule with valid action plugin
    action_module = ActionModule(name='setup', valid_args=ActionModule._VALID_ARGS)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 11:32:34.993094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    def variable_manager_for_test():
        variable_manager = DummyVariableManager()
        variable_manager.get_vars({'playbook_dir': '/playbook'})
        variable_manager.set_play_context(PlayContext())
        return variable_manager

    dummy_loader = DummyLoader()
    dummy_display = DummyDisplay()
    dummy_templar = DummyTemplar()
    dummy_task = Task()
    dummy_task.args = {'msg': 'Test message'}

    action = ActionModule(dummy_loader, dummy_templar, dummy_display)
    action._task = dummy_task
    action._connection = DummyConnection()
    action._variables = variable

# Generated at 2022-06-11 11:32:35.469082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-11 11:32:36.396510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	assert True

# Generated at 2022-06-11 11:32:52.979824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile
    from ansible.plugins.action.debug import ActionModule
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    # Load play book with valid syntax to create temp playbook
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager

# Generated at 2022-06-11 11:32:53.624970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(isinstance(action_module,ActionBase))

# Generated at 2022-06-11 11:33:01.934755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    class_under_test = ActionModule(task=mock.Mock(), connection=mock.Mock(), play_context=mock.Mock(), loader=mock.Mock(), templar=mock.Mock(), shared_loader_obj=mock.Mock())
    assert hasattr(class_under_test, 'task')
    assert hasattr(class_under_test, 'connection')
    assert hasattr(class_under_test, 'play_context')
    assert hasattr(class_under_test, 'loader')
    assert hasattr(class_under_test, 'templar')
    assert hasattr(class_under_test, 'shared_loader_obj')
    assert class_under_test._task == mock.Mock()
    assert class_under_test._connection == mock.Mock

# Generated at 2022-06-11 11:33:08.266592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task

    task = Task()
    task._role = None
    task.args = {
        "msg": "Hello world!",
        "var": "test_var",
        "verbosity": 0
    }

    at = ActionModule(task, ImmutableDict())
    assert at != None


# Generated at 2022-06-11 11:33:10.156399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 11:33:10.796241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:33:11.380942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:33:13.687109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))


# Generated at 2022-06-11 11:33:18.702355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {'_ansible_verbosity': 0, '_ansible_no_log': True, '_ansible_debug': False}, {
        'msg': 'Hello world!',
    })
    assert action.run() == {'_ansible_verbose_always': True, 'failed': False, 'msg': 'Hello world!'}


# Generated at 2022-06-11 11:33:21.032051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule(dict(), 'fake host', 'fake task', connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None))


# Generated at 2022-06-11 11:33:32.688176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()


# Generated at 2022-06-11 11:33:42.716049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    input_result = {'_ansible_no_log': False,
                    '_ansible_verbose_always': True,
                    '_ansible_version': '2.10.1',
                    'ansible_loop_var': 'item',
                    'ansible_version': {'full': '2.10.1', 'major': 2, 'minor': 10, 'revision': 1, 'string': '2.10.1'},
                    'changed': False,
                    'failed': False,
                    'invocation': {'module_args': {}, 'module_name': 'debug'},
                    'item': 5}
    obj = ActionModule(input_result)
    assert obj._display.verbosity == 0, "Verbosity threshold not met."

# Generated at 2022-06-11 11:33:43.653022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 11:33:46.259985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None) # None is _shared_loader_obj of AnsibleModule
    assert module.run(None, None) == {"msg": 'Hello world!', "failed": False}



# Generated at 2022-06-11 11:33:54.960333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    # AnsibleModule test object.
    module = AnsibleModule(
        argument_spec={
            "msg": {'required': False},
            "var": {'required': False},
            "verbosity": {'required': False}
        },
        supports_check_mode=True
    )

    # Create data loader object.
    ds = DataLoader()
    # Create inventory manager object.
    im = InventoryManager(loader=ds, sources=[])
    # Set variable manager object.
    vm = VariableManager(loader=ds, inventory=im)

# Generated at 2022-06-11 11:34:04.312940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of class ActionModule
    action_module = ActionModule()

    # Assign arguments
    task = dict()
    task['args'] = dict()
    task['args']['msg'] = 'Hello world!'
    task['args']['verbosity'] = 0

    # Assign task_vars
    task_vars = dict()
    task_vars['var1'] = 'Hello'
    task_vars['var2'] = 'world'

    # Assign result
    result = dict()
    result['failed'] = False
    result['msg'] = 'Hello world!'

    # Test with known arguments
    assert(action_module.run(tmp=None, task_vars=task_vars) == result)


# Generated at 2022-06-11 11:34:06.097591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:34:15.974606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    variable_manager = VariableManager()
    loader = DataLoader()
    # hosts = Inventory(loader=loader, variable_manager=variable_manager, host_list='/etc/ansible/hosts')
    # variable_manager.set_inventory(hosts)

    print("test debug module")
    # set display
    options = dict()
    options['verbosity'] = 3
    display = Display()
    display.verbosity = options['verbosity']
    # set context
    play_context = PlayContext()
    play_context.check_mode = False

    # initial test module
    task = dict()
    task

# Generated at 2022-06-11 11:34:16.572071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:34:26.898864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-11 11:34:57.058654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.parsing.dataloader
    import ansible.vars
    import ansible.inventory
    import ansible.playbook.play
    from ansible.utils.vars import combine_vars
    from ansible.utils.sentinel import Sentinel

    my_sentinel = Sentinel()

    options = my_sentinel
    connection = my_sentinel
    play_context = my_sentinel
    loader = my_sentinel
    templar = my_sentinel
    shared_loader_obj = my_sentinel
    variable_manager = my_sentinel

    def get_ds_vars():
        return dict()
    def get_host_vars():
        return dict()

    def get_host_groups():
        return dict()

    def task_vars(host):
        return dict()

# Generated at 2022-06-11 11:35:07.829112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    task_vars = {'ansible_verbosity': 2}
    action_module = ActionModule(None, task_args, task_vars)

    res = action_module.run()
    assert res['failed'] is False
    assert 'msg' in res
    assert res['msg'] == 'Hello world!'

    # Test with var
    task_args = {'var': 'foo'}
    task_vars = {'foo': 'bar', 'ansible_verbosity': 0}
    action_module = ActionModule(None, task_args, task_vars)

    res = action_module.run()
    assert res['failed'] is False
    assert 'foo' in res
    assert 'bar' == res['foo']

   

# Generated at 2022-06-11 11:35:09.469915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of ActionModule")
    a = ActionModule()
    print("DONE")

# Generated at 2022-06-11 11:35:16.210533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an 'ActionModule' object
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    print('test_ActionModule: constructor: PASS')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:35:16.801655
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:35:17.521850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:35:19.409798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule(None, None)
    assert test_action_module != None

# Unit test of the method ActionModule.run

# Generated at 2022-06-11 11:35:29.474730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import PlayBook

    mytask = Task()
    mytask.name = 'Test task'
    mytask.action = 'debug'
    mytask.block = Block()
    mytask.block.parent_role = Role()
    mytask.block._load_role_data()

    myplay = Play()
    myplay.name = 'Test play'
    myplay.tasks = [mytask]
    myplay.tasks[0]._role_post_validate()
   

# Generated at 2022-06-11 11:35:36.399594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    from ansible.plugins import action
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import os

    class ModuleFailer:
        '''This module always fails'''
        def __init__(self, *args, **kwargs):
            self.results = {'failed': True, 'parsed': False}

        def exit_json(self, **kwargs):
            self.results.update(kwargs)
            self.results['parsed'] = True
            raise Exception('!')



# Generated at 2022-06-11 11:35:46.702743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    import ansible.module_utils.basic

    am_instance = ActionModule(None, None, None, None)
    task_vars = {
        'msg': 'Hello Universe!',
        'var': 'msg',
        'verbosity': 1,
    }
    am_instance._task.action = 'debug'
    am_instance._task.args = task_vars

    # test run
    result = am_instance.run(None, task_vars)
    assert result['msg'] == 'Hello Universe!'
    assert result['var'] == 'msg'
    assert result['verbosity'] == 1
    assert not result['failed']

    # negative test using invalid arguments

# Generated at 2022-06-11 11:36:40.859508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {}
    args['msg'] = 'Test message.'
    args['verbosity'] = 2
    task_args = args
    task = {
        'args': task_args,
    }

    result = {
        'failed': False,
        'changed': False,
        'skip_reason': '',
        'skipped': False,
    }

    class MockTemplar(object):
        def template(self, data, convert_bare=True, fail_on_undefined=True):
            return data

    class MockDisplay(object):
        def __init__(self, verbosity):
            self.verbosity = verbosity

    action = ActionModule(task, MockTemplar(), MockDisplay(1))
    output = action.run(task_vars={'name': 'test'})
    assert output == result

# Generated at 2022-06-11 11:36:49.322199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor set default value
    action_module = ActionModule('127.0.0.1', 'root', 'pass', '/root/', 'ansible_module_test')
    assert action_module._play_context.become is False
    assert action_module._play_context.become_user == 'root'
    assert action_module._play_context.check_mode is False
    assert action_module._play_context.connection == 'ssh'
    assert action_module._play_context.module_name == 'ansible_module_test'
    assert action_module._play_context.no_log is False
    assert action_module._play_context.remote_addr == '127.0.0.1'
    assert action_module._play_context.remote_user == 'root'
    assert action_module._play_context

# Generated at 2022-06-11 11:36:56.438036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display


# Generated at 2022-06-11 11:36:59.488833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule =  ActionModule()

    if (actionModule.TRANSFERS_FILES != False):
        assert False
    if (actionModule._VALID_ARGS != frozenset(('msg', 'var', 'verbosity'))):
        assert False


# Generated at 2022-06-11 11:37:10.891329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule(task={"args": {"verbosity": 2, "msg": "Hello world!"}})
    actionmodule._display.verbosity = 1
    result = actionmodule.run(task_vars={})
    if result["skipped"] == True:
        print(result["skipped_reason"])
    if result["failed"] == True:
        print(result["msg"])

    actionmodule = ActionModule(task={"args": {"verbosity": 1, "msg": "Hello world!"}})
    actionmodule._display.verbosity = 1
    result = actionmodule.run(task_vars={})
    if result["skipped"] == True:
        print(result["skipped_reason"])
    if result["failed"] == True:
        print(result["msg"])


# Generated at 2022-06-11 11:37:11.976359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-11 11:37:14.462730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule._VALID_ARGS == frozenset(('msg', 'var', 'verbosity')))
    assert(ActionModule.TRANSFERS_FILES == False)

# Generated at 2022-06-11 11:37:20.326642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict()).module_args == dict()
    assert ActionModule(dict(), dict(), dict(),
               module_args=dict(msg='Hello World')).module_args == dict(msg='Hello World')
    assert ActionModule(dict(), dict(), dict(),
               module_args=dict(var='result')).module_args == dict(var='result')
    assert ActionModule(dict(), dict(), dict(),
               module_args=dict(verbosity='1')).module_args == dict(verbosity='1')

# Generated at 2022-06-11 11:37:22.799927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_action_module.py:27: _ansible_verbose_always
    # test_action_module.py:21: msg
    # test_action_module.py:26: skipped
    # test_action_module.py:26: skipped_reason
    assert len(ActionModule.run(None, None)) == 4

# Generated at 2022-06-11 11:37:27.413101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of the class ActionModule
    mock_am = MockActionModule()

    # Execute the method run to see if it works correctly
    mock_am.run()

    # Assert that the msg key in result is 'Hello world!'
    assert 'msg' in mock_am.result.keys()
    assert mock_am.result['msg'] == 'Hello world!'


# Generated at 2022-06-11 11:39:20.570996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    
    # test 1: since task_args is not defined, args is an empty dict
    assert am.run(tmp=None) == {'failed': False}
    # test 2: if verbosity is greater than that of task, skipped_reason exists in dict
    assert am.run(tmp=None, task_vars=None, task_args={'verbosity': 2})['skipped_reason'] == "Verbosity threshold not met."
    # test 3: if verbosity is less than or equal to that of task, skipped_reason does NOT exist in dict
    assert 'skipped_reason' not in am.run(tmp=None, task_vars=None, task_args={'verbosity': 1})

# Generated at 2022-06-11 11:39:26.908437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestTask(object):
        def __init__(self, args):
            self.args = args
    assert not ActionModule(TestTask({}), {}).run()['failed']
    assert ActionModule(TestTask({'msg': 'test'}), {}).run()['msg'] == 'test'
    assert not ActionModule(TestTask({'var': 'msg'}), {'msg': 'test'}).run()['msg']
    assert not ActionModule(TestTask({'verbosity': 2}), {}).run()['skipped']
    assert ActionModule(TestTask({'verbosity': 10}), {}).run()['skipped']

# Generated at 2022-06-11 11:39:31.475377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest
    class ActionModuleTest(unittest.TestCase):

        def setUp(self):
            self.module = 'assert'
            self.action = ActionModule()

        def test_constructor_sets_action_name(self):
            self.assertIsInstance(self.action, ActionModule)

    test1 = ActionModuleTest()
    test1.setUp()
    test1.test_constructor_sets_action_name()

# Generated at 2022-06-11 11:39:39.686859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creating a new instance of ActionModule
    # The _task variable will be present in all instances of this class
    new_instance = ActionModule({'FOO': 'BAR'}, 'FAKE_TMP_PATH', 'FAKE_CONTEXT_PATH', 'FAKE_LOADER', 'FAKE_TEMPLAR', 'FAKE_DATASTORE')
    # Check the _task variable is initialized
    assert new_instance._task == {'FOO': 'BAR'}
    # Check an error is raised if the tmp path is not defined
    try:
        new_instance.run(None, 'FAKE_TASK_VARS')
    except Exception as exception:
        assert(exception.message == 'ActionModule._task.args is undefined')
        print(exception.message)

# Generated at 2022-06-11 11:39:49.251785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    import yaml

    loader = DataLoader()
    inv_manager = InventoryManager('/etc/ansible/hosts')
    variable_manager = VariableManager(loader, inv_manager)

    task_source = dict(
        name="debug",
        action="debug",
        args=dict(var='hello', msg="Hello world!")
    )
    task = Task.load(task_source, variable_manager=variable_manager)

    am = ActionModule(task, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 11:39:50.045662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:39:52.260870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule=ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:40:01.738846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_test_arguments = {}
    module_test_arguments.update({'verbosity': 0})
    module_test_arguments.update({'var': 'hostvars[inventory_hostname][\'inventory_hostname\']'})
    module_test_arguments.update({'no_log': False})
    module_test_arguments.update({'no_target_system': False})
    module_test_arguments.update({'_raw_params': '', '_uses_shell': False, '_uses_delegate': False, 'docker_extra_args': u''})
    module_test = AnsibleModule(argument_spec={})
    module_test.params = module_test_arguments
    result = module_test.run()

    assert result[u'skipped'], result[u'msg']

# Generated at 2022-06-11 11:40:02.272879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:40:05.764333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(args=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module