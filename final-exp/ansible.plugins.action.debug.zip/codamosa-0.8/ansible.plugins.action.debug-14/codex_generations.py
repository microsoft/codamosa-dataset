

# Generated at 2022-06-11 11:31:54.320554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup test environment
    import os
    os_env = dict(ANSIBLE_ROLES_PATH='/etc/ansible/roles')
    os.environ = os_env

    # test_import_library
    from ansible.plugins.action.debug import ActionModule
    test_library = ActionModule(task=dict(args=dict(verbosity=0, msg='Hello World')),
                                connection=dict(),
                                play_context=dict(),
                                loader=None,
                                templar=None,
                                shared_loader_obj=None)

    # test for run function

# Generated at 2022-06-11 11:32:03.989836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.common import set_module_args
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host

    loader = DataLoader()
    options = dict(connection='local', module_path='/home/tkuratomi/ansible/lib/ansible/modules/networking/nxos')

# Generated at 2022-06-11 11:32:11.490085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import sharedloader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor import task_executor
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.play_iterator import PlayIterator
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group

    # Create host, group and inventory
    host = Host()
    host.name = "localhost"
    host.set_variable("ansible_connection", "local")

    group = Group()


# Generated at 2022-06-11 11:32:16.774045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.template import Templar

    playbook = Playbook()
    templar = Templar(playbook = playbook)
    task = Task()

    test = ActionModule(task, 'localhost', templar)
    assert test.TRANSFERS_FILES == False

# Generated at 2022-06-11 11:32:17.357292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:32:17.988265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1 == 1

# Generated at 2022-06-11 11:32:18.586299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1 == 1

# Generated at 2022-06-11 11:32:19.183964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:32:23.063890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module='debug')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        tempdir=dict()
    )

    assert module._task.action['module'] == 'debug'

# Generated at 2022-06-11 11:32:32.476440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_path = 'ansible.plugins.action.debug'
    module_name = 'ActionModule'
    module_klass = getattr(__import__(module_path, fromlist=[module_name]), module_name)

    # create an object of class ActionModule
    module_obj = module_klass()

    # test whether type of module_obj is a class ActionModule
    assert type(module_obj) == module_klass

    # test whether task of module_obj is set correctly
    task_klass = getattr(module_klass, 'task')
    task_obj = task_klass()
    module_obj.task = task_obj
    assert type(module_obj.task) == task_klass



# Generated at 2022-06-11 11:32:48.359687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as action
    import ansible.plugins.action.debug
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.utils.template
    import sys

    class ActionBaseClass(object):
        def filter_loader(self, *args, **kwargs):
            return ansible.plugins.action.FilterModule(*args, **kwargs)

    class DisplayClass(object):
        verbosity = 0

    class TaskClass(object):
        verbosity = 0

        def __init__(self):
            self.args = {}

    class PlayContextClass(object):
        verbosity = 0
        def __init__(self):
            pass

    context = PlayContextClass()

# Generated at 2022-06-11 11:32:52.140212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create object of class ActionModule
    obj = ActionModule()
    obj._task = DummyTask()
    # Call method run with tmp=None and task_vars=None
    return obj.run(tmp=None, task_vars=None)


# Generated at 2022-06-11 11:32:56.184893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print("ActionModule %s" %module._VALID_ARGS)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:33:06.649574
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:33:11.280456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test for constructor of class ActionModule
    actionModule = ActionModule()
    assert type(actionModule) == ActionModule
    assert actionModule.TRANSFERS_FILES == False
    assert actionModule._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-11 11:33:12.653243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    target = ActionModule(None,None,None)

# Generated at 2022-06-11 11:33:19.323038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    # Creating instance of class ActionModule
    am = ActionModule(task=dict(action=dict(module_name='debug', module_args='msg=hello_world'), args=dict()),
                      connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Executing method run of class ActionModule
    am.run()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 11:33:21.288114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initial test to pass
    module = ActionModule()
    assert module.verbosity == 0

    module = ActionModule(verbosity=1)
    assert module.verbosity == 1

# Generated at 2022-06-11 11:33:31.079059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define the fake task
    fake_task_args = {
        'verbosity' : 0,
        'msg' : 'Hello world!'
    }
    fake_task = {
        'action' : 'debug',
        'args' : fake_task_args
    }
    # Define the fake task vars
    fake_task_vars = {}

    # Define the fake display
    fake_display = {
        'verbosity' : 0
    }

    # Define the fake templar
    fake_templar = {
        'template' : ''
    }

    # Define the fake action plugin

# Generated at 2022-06-11 11:33:40.923424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize the class object
    action_module = ActionModule( {}, {}, False, '/path/to/ansible_module' )

    # setting task_vars
    task_vars = {
        'ansible_facts': {
            'os_family': 'Darwin',
            'distribution': 'MacOSX'
    }}

    # setting arguments that will be passed to the run method
    args = {
        'ansible_facts': {
            'os_family': 'Darwin',
            'distribution': 'MacOSX'
    }, 'var': 'os_family'}

    # check if the run method returns expected output

# Generated at 2022-06-11 11:34:01.636162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule:
        def __init__(self, args=None, task=None, task_vars=None):
            self._task = task
            if args is None:
                args = dict()
            self.args = args
            pass
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            self.task_vars = task_vars

        # Following variables and functions are used for unit test
        _task = dict()
        args = dict()
        task_vars = dict()

    from ansible.module_utils._text import to_text

    # Test case 1: args['msg'] is specified
    task_args = {'msg' : "Hello world!", "verbosity" : 0}
    task_vars

# Generated at 2022-06-11 11:34:02.025674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:34:02.633463
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:34:06.060588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Test construct
  actionModule = ActionModule(None, None)
  # execute run
  result = actionModule.run(tmp=None, task_vars=None)
  # get result
  result_msg = result.get("msg")
  # test equality
  assert result_msg == "Hello world!"

# Generated at 2022-06-11 11:34:15.929155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Module code
    class AnsibleModuleFake(object):
        def __init__(self):
            self.argument_spec = {
                'var': {'required': False, 'type': 'str'},
                'msg': {'required': False, 'type': 'str'},
                'verbosity': {'required': False, 'type': 'int'},
                'test_args': {'required': False, 'type': 'str'},
            }
            self.params = {
                'var': None,
                'msg': None,
                'verbosity': 0,
                'test_args': None
            }
            self.args = {}

# Generated at 2022-06-11 11:34:18.833811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, ActionBase._load_params(dict(a='b')))
    assert action._task.action == 'debug'
    assert action._task.args == dict(a='b')



# Generated at 2022-06-11 11:34:19.409124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:34:22.491811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new object of the class
    action_module = ActionModule(loader=None, tmp_path=None)

    # Check that the object was created correctly
    assert(action_module is not None)

# Generated at 2022-06-11 11:34:32.234950
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:34:33.138662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-11 11:35:00.670091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, {}, None)

    # msg = 'Hello world!'
    action.run(tmp='string', task_vars={'var': 'string'})

    # msg = 'VARIABLE IS NOT DEFINED!'
    action.run(tmp=None, task_vars={'var': 'string2'})

    # type(var) = List
    action.run(tmp=None, task_vars={'var': ['list', 'of', 'variables']})

    # type(var) = Dictionary
    action.run(tmp=None, task_vars={'var': {'key1': 'value1', 'key2': 'value2'}})

if __name__ == "__main__":
    test_ActionModule_run( )

# Generated at 2022-06-11 11:35:07.505648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    test_class = ActionModule()
    test_class.get_action_args = ['msg', 'var', 'verbosity']
    test_class.run(task_vars)
    return True


if __name__ == '__main__':
    task_vars = dict()
    test_class = ActionModule()
    test_class.get_action_args = ['msg', 'var', 'verbosity']
    test_class.run(task_vars)

# Generated at 2022-06-11 11:35:09.870354
# Unit test for constructor of class ActionModule
def test_ActionModule():

	#create a new instance of ActionModule class
	actionModule1 = ActionModule()

	#check the instance of ActionModule class
	assert isinstance(actionModule1, ActionModule)

# Generated at 2022-06-11 11:35:20.027365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.six import string_types

    # Test msg argument
    action_module = ActionModule(None, dict(msg="Hello world!"))
    result = action_module.run()
    assert not result['failed']
    assert result['msg'] == "Hello world!"

    # Test var argument
    action_module = ActionModule(None, dict(var="blah"))
    result = action_module.run(task_vars=dict(blah="Hello world!"))
    assert not result['failed']
    assert result['blah'] == "Hello world!"

    action_module = ActionModule(None, dict(var=dict(a=1)))
    result = action_module.run()
    assert not result['failed']

# Generated at 2022-06-11 11:35:22.574116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return action

# Generated at 2022-06-11 11:35:26.380863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Checks if obj is of class ActionModule
    assert isinstance(obj, ActionModule)


# Generated at 2022-06-11 11:35:34.856625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestModule(object):
        def __init__(self):
            self._task = _task()
            self._display = _display()
            self._templar = _templar()

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            # get task verbosity
            verbosity = int(self.args.get('verbosity', 0))

            if verbosity <= self._display.verbosity:
                if 'msg' in self.args:
                    result['msg'] = self.args['msg']

# Generated at 2022-06-11 11:35:35.977685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert result is not None

# Generated at 2022-06-11 11:35:46.208173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of module
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Unit test for method run of class ActionModule with msg and verbosity
    task_args = {'msg': 'print message', 'verbosity': 2}
    task_vars = {'ansible_verbosity': 1}
    result = action_module.run(task_vars=task_vars, **task_args)
    assert result == {'msg': 'print message', '_ansible_verbose_always': True, 'failed': False}

    # Unit test for method run of class ActionModule with var and verbosity
    task_args = {'var': 'message', 'verbosity': 2}
    task_vars

# Generated at 2022-06-11 11:35:47.199212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 11:36:32.074971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:36:33.085348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test loading the class without any issues
    ActionModule()

# Generated at 2022-06-11 11:36:35.785260
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Arrange
    module_args = {}
    set_module_args(module_args)

    # Act
    result = my_module.run()

    # Assert
    assert result['msg'] == 'Hello world!'

# Generated at 2022-06-11 11:36:36.826628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 11:36:45.665434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # TODO: For some reason, I don't get the output of the debug module when I run the unit tests.
    #       The code below is copied from the ansible-playbook runner, so maybe it is missing something
    #       I'm not sure.
    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='tests/inventory')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 11:36:49.597684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(
        task=dict(arg='arg'),
        connection=dict(arg='arg'),
        play_context=dict(arg='arg'),
        loader=dict(arg='arg'),
        templar=dict(arg='arg'),
        shared_loader_obj=dict(arg='arg'),
    )



# Generated at 2022-06-11 11:36:50.815065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(None, None, None)
    assert m is not None

# Generated at 2022-06-11 11:36:57.234453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_result = dict()
    test_result['failed'] = False
    test_result['msg'] = 'Hello world!'

    # Test that verbosity threshold display all
    am = ActionModule(dict(verbosity=0))
    result = am.run(task_vars=dict())
    assert result == test_result

    # Test that verbosity 0 is default verbosity
    am = ActionModule()
    result = am.run(task_vars=dict())
    assert result == test_result

    # Test that verbosity threshold display msg
    am = ActionModule(dict(msg='Hello world!', verbosity=1))
    result = am.run(task_vars=dict())
    assert result == test_result

    # Test that verbosity threshold display var

# Generated at 2022-06-11 11:37:07.535592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    If a string is passed as the key
    If a list is passed as the key
    If a dictionary is passed as the key
    If a string is passed as the value
    If a list is passed as the value
    If a dictionary is passed as the value
    """
    #setup
    results = {}
    #test
    results['one'] = 1
    results['two'] = 2
    results['three'] = 3
    results['four'] = 4
    results['five'] = 5
    results['msg'] = 'Hello world!'
    #assert
    assert results['msg'] == 'Hello world!'
    assert results['one'] == 1
    assert results['two'] == 2
    assert results['three'] == 3
    assert results['four'] == 4
    assert results['five'] == 5

# Generated at 2022-06-11 11:37:17.421340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule._task.args = {'msg': 'Hello world!'}
    actionModule._display.verbosity = 0
    result = actionModule.run()

    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False
    assert result['skipped'] == False

    actionModule._task.args = {'msg': 'Hello world!'}
    actionModule._display.verbosity = 1
    result = actionModule.run()

    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False
    assert result['skipped'] == False

    actionModule._task.args = {'msg': 'Hello world!', 'verbosity': 2}
    actionModule._display.verbosity = 1
    result = actionModule.run()

    assert result['skipped'] == True

# Generated at 2022-06-11 11:38:56.436998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule constructor
    action1 = ActionModule()
    assert action1 is not None

# Generated at 2022-06-11 11:39:03.516885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test: Create an instance of ActionModule
    module = ActionModule(
        task=dict(action=dict(module='debug')),
        connection=dict(module='local', host='localhost', port=1234),
        play_context=dict(check_mode=True),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module is not None
    assert module._task == dict(action=dict(module='debug'))
    assert module._connection == dict(module='local', host='localhost', port=1234)
    assert module._play_context == dict(check_mode=True)

# Generated at 2022-06-11 11:39:11.670644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult

    # Raise a runtime error because of unkown option
    result = ActionModule.run({"failed": True, "msg": "'msg' and 'var' are incompatible options"})
    assert (result == {"failed": True, "msg": "'msg' and 'var' are incompatible options"})

    result = ActionModule.run({"_ansible_verbose_always": True,"msg": "verbose"})

    # Test __init__ of class TaskResult
    task_result = TaskResult(host=None)
    assert (task_result.rc == 0)
    assert (task_result.task_name is None)
    assert (task_result.item is None)
    assert (task_result.is_changed() == False)

# Generated at 2022-06-11 11:39:14.415049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test ActionModule")
    # TODO: define parameters to get a task instance
    # can't test with the test_action_plugin fixture as it is using the test_runner
    #task = ActionModule(runner)


# Generated at 2022-06-11 11:39:15.166177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert result

# Generated at 2022-06-11 11:39:20.299290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule([], [], {})
    assert a._VALID_ARGS == frozenset(('msg', 'var', 'verbosity', '_ansible_verbose_always'))
    assert a._task is None
    assert a._connection is None
    assert a._play_context is None
    assert a._loader is None
    assert a._templar is None
    assert a._shared_loader_obj is None
    assert a._task_vars is None
    assert a._loader_cache is None
    assert a._action is None
    assert a._result is None

# Generated at 2022-06-11 11:39:28.092568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({})
    result = module.run()
    assert result['failed'] is False
    assert result['msg'] == "Hello world!"
    assert result['_ansible_verbose_always'] is True

    result = module.run({'verbosity': 1})
    assert result['skipped'] is True
    assert result['skipped_reason'] == "Verbosity threshold not met."

    result = module.run({'verbosity': 0})
    assert result['skipped'] is None
    assert 'skipped_reason' not in result

    result = module.run({'verbosity': 1, 'msg': 'bye world'})
    assert result['skipped'] is True
    assert result['skipped_reason'] == "Verbosity threshold not met."


# Generated at 2022-06-11 11:39:33.396909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    print(module.run())
    print(module.run({'msg': "Hello World!"}))
    print(module.run({'var': "myvar"}))
    print(module.run({'var': "myvar", 'msg': ''}))
    print(module.run({'var': "myvar", 'msg': "Hello World!"}))
    print(module.run({'var': ['myvar', 'myvar2'], 'msg': "Hello World!"}))

# Generated at 2022-06-11 11:39:35.892091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_equals(ActionModule._VALID_ARGS, frozenset(('msg', 'var', 'verbosity')))
    assert_equals(ActionModule.TRANSFERS_FILES, False)

# Generated at 2022-06-11 11:39:44.459597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create inventory, since ActionBase._convert_static_inventory is not called by unit test
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/action/__init__.py#L32
    inventory = InventoryManager(loader=None, sources=[])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    task = Task()
    action = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(action) == ActionModule