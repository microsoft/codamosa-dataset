

# Generated at 2022-06-17 08:48:43.203128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:48:47.808488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-17 08:48:56.153777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:49:05.866094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 08:49:16.384854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-17 08:49:30.373813
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:49:43.437097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:49:48.226807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Run the method run of class ActionModule
    result = action_module.run()

    # Assert the result
    assert result == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}



# Generated at 2022-06-17 08:49:59.468414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    task_vars = {}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=task_vars, **task_args)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False

    # Test with var
    task_args = {'var': 'test_var'}
    task_vars = {'test_var': 'Hello world!'}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result

# Generated at 2022-06-17 08:50:09.117518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:50:25.407621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 08:50:34.576656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Run the action module
    result = action_module.run()

    # Check the result
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'


# Generated at 2022-06-17 08:50:43.340074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action = ActionModule({'msg': 'Hello world!'}, {}, {})
    assert action.run() == {'failed': False, 'msg': 'Hello world!'}

    # Test with valid arguments
    action = ActionModule({'var': 'msg'}, {'msg': 'Hello world!'}, {})
    assert action.run() == {'failed': False, 'msg': 'Hello world!'}

    # Test with valid arguments
    action = ActionModule({'var': 'msg'}, {'msg': 'Hello world!'}, {})
    assert action.run() == {'failed': False, 'msg': 'Hello world!'}

    # Test with valid arguments
    action = ActionModule({'var': 'msg'}, {'msg': 'Hello world!'}, {})

# Generated at 2022-06-17 08:50:45.119560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit tests for ActionModule.run()
    pass

# Generated at 2022-06-17 08:50:57.599705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:51:09.949746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:51:22.236003
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:51:23.609502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 08:51:33.916679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:51:42.864679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with verbosity 0
    task_args = {'verbosity': 0}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = task_args
    action_module._display.verbosity = 0
    result = action_module.run(tmp=None, task_vars=None)
    assert result['failed'] == False
    assert result['skipped'] == True
    assert result['skipped_reason'] == "Verbosity threshold not met."

    # Test with verbosity 1
    task_args = {'verbosity': 1}

# Generated at 2022-06-17 08:52:05.634955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 08:52:10.601642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Test the constructor of class ActionModule
    assert action_module is not None

# Generated at 2022-06-17 08:52:11.727138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:52:20.966152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.verbosity = 2
    tqm = None

# Generated at 2022-06-17 08:52:24.569524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), '/path/to/ansible/lib/ansible/modules/test_module.py')

# Generated at 2022-06-17 08:52:34.319042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}
    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action module
    action_module = ActionModule(task, display, templar)
    # Create a mock task_vars
    task_vars = {}
    # Call method run
    result = action_module.run(None, task_vars)
    # Assert result
    assert result == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}


# Generated at 2022-06-17 08:52:43.523881
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:52:47.391028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-17 08:52:55.632628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:53:02.455710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Run the action module
    result = action_module.run()

    # Check the result
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False


# Generated at 2022-06-17 08:53:34.995456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:53:43.877866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import merge_hash
   

# Generated at 2022-06-17 08:53:56.202754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import get_vars


# Generated at 2022-06-17 08:54:05.580870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action = ActionModule(dict(msg='Hello world!'), dict(verbosity=1))
    assert action._task.args['msg'] == 'Hello world!'
    assert action._task.args['verbosity'] == 1

    # Test with invalid arguments
    action = ActionModule(dict(msg='Hello world!', var='test'), dict(verbosity=1))
    assert action._task.args['msg'] == 'Hello world!'
    assert action._task.args['var'] == 'test'
    assert action._task.args['verbosity'] == 1

# Generated at 2022-06-17 08:54:15.639299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with verbosity 0
    task_args = {'verbosity': 0}
    task_vars = {}
    tmp = None
    display = None
    templar = None
    task = None
    action = ActionModule(task, templar, task_vars, display)
    result = action.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['skipped'] == True
    assert result['skipped_reason'] == "Verbosity threshold not met."

    # Test with verbosity 1
    task_args = {'verbosity': 1}
    task_vars = {}
    tmp = None
    display = None
    templar = None
    task = None
    action = ActionModule(task, templar, task_vars, display)
    result = action

# Generated at 2022-06-17 08:54:28.096086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._task == None
    assert action_module._connection == None
    assert action_module._play_context == None
    assert action_module._loader == None
    assert action_module._templar == None
    assert action_module._shared_loader_obj == None
    assert action_module._display.verbosity == 0
    assert action_module._display.deprecated_warning == False
    assert action_module._display.deprecated_version == None
    assert action_module._display.deprecated_alternative == None
    assert action_module._display.deprecated_expiration == None
    assert action_module._display.deprecated

# Generated at 2022-06-17 08:54:29.467623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 08:54:40.445707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['msg'] = 'Hello world!'
    task['args']['verbosity'] = 0
    task['action'] = 'debug'
    task['delegate_to'] = 'localhost'

    # Create a mock connection
    connection = dict()
    connection['playbook_basedir'] = '.'
    connection['play_basedir'] = '.'
    connection['host'] = 'localhost'
    connection['port'] = 22
    connection['name'] = 'localhost'
    connection['remote_addr'] = '127.0.0.1'
    connection['password'] = None
    connection['transport'] = 'smart'

# Generated at 2022-06-17 08:54:51.017482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 08:55:02.071804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 08:55:58.636472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 08:56:02.763052
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 08:56:12.359449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
   

# Generated at 2022-06-17 08:56:21.999820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:56:23.794201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 08:56:31.898071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = {
        'args': {
            'msg': 'Hello world!',
            'verbosity': 0,
        },
    }

    # Create a mock task_vars
    task_vars = {}

    # Create a mock display
    display = {
        'verbosity': 0,
    }

    # Create a mock templar
    templar = {
        'template': lambda x, convert_bare, fail_on_undefined: x,
    }

    # Create a mock ActionBase
    action_base = {
        'run': lambda x, task_vars: {},
    }

    # Create a mock ActionModule

# Generated at 2022-06-17 08:56:40.466102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:56:52.423010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create an instance of ActionModule
    action_module = ActionModule(task, display, templar, module_utils)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Test run method with msg option
    task.args = dict(msg="Hello world!")
    result = action_module.run(tmp, task_vars)
    assert result['msg'] == "Hello world!"

    # Test run method with var option

# Generated at 2022-06-17 08:57:05.669798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:57:14.975788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock variable manager
    variable_manager = MockVariableManager()
    # Create a mock action module
    action_module = ActionModule(task, display, templar, loader, variable_manager)

    # Test with msg
    task.args = {'msg': 'Hello world!'}
    result = action_module.run(task_vars=dict())
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False

    # Test with var
    task.args = {'var': 'test_var'}