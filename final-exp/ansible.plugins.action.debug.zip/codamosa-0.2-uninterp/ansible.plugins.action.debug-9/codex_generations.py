

# Generated at 2022-06-17 08:48:55.953882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleParserError
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 08:49:05.634800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:49:07.477539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-17 08:49:18.107556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:49:23.972005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:49:31.776448
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:49:43.925427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = {
        'args': {
            'msg': 'Hello world!',
            'verbosity': 0
        }
    }

    # Create a mock task_vars
    task_vars = {}

    # Create a mock display
    display = {
        'verbosity': 0
    }

    # Create a mock templar
    templar = {
        'template': lambda x, y, z: x
    }

    # Create a mock ActionModule
    action_module = ActionModule(task, display, templar)

    # Call method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Assert that the result is correct

# Generated at 2022-06-17 08:49:56.730978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:50:08.362818
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:50:14.377641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    action_module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False

    # Test with var
    task_args = {'var': 'test_var'}
    action_module = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-17 08:50:30.594826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    action_module = ActionModule(task=dict(action=dict(module_name='debug', module_args=dict(msg='Hello world!'))))
    assert action_module.run() == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}

    # Test with invalid parameters
    action_module = ActionModule(task=dict(action=dict(module_name='debug', module_args=dict(msg='Hello world!', var='test'))))
    assert action_module.run() == {'failed': True, 'msg': "'msg' and 'var' are incompatible options"}

# Generated at 2022-06-17 08:50:31.164286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:50:40.647721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 08:50:54.825272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:51:05.227709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock task
    task = MockTask()

    # Create a mock play
    play = MockPlay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock variable manager
    variable_manager = MockVariableManager()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Set attributes of mock object
    action_module._task = task
    action_module._play = play
    action_module._loader = loader
    action_module._display = display
    action_module._templar = templar
    action_module._variable_manager = variable_manager

    # Test case 1
    # Test when 'msg' is in task.

# Generated at 2022-06-17 08:51:08.404632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action = ActionModule()
    assert action._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:51:20.191120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Display
    display = Display()

    # Create an instance of class Templar
    templar = Templar(loader=None, variables=variable_manager)

    # Set attributes of objects
    action_module._task = task
    action_module._play_context = play_context
    action_module._loader = None
    action_module._templar = templar
    action_module._shared_loader_obj = None
    action_module._connection = None
    action_module._display = display
    action_

# Generated at 2022-06-17 08:51:30.894753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.plugins import get_all_plugin_loaders, get_all_plugins
    from ansible.utils.sentinel import Sentinel

# Generated at 2022-06-17 08:51:35.625889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:51:37.915934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:51:49.733771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 08:52:00.297567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(
        argument_spec=dict(
            msg=dict(type='str', default=None),
            var=dict(type='str', default=None),
            verbosity=dict(type='int', default=0),
        ),
        supports_check_mode=True,
    )

    # Test with msg
    action = ActionModule(module, dict(msg="Hello world!"))
    result = action.run(task_vars=dict())
    assert result['failed'] is False
    assert result['msg'] == "Hello world!"

    # Test with var
    action = ActionModule(module, dict(var="msg"))

# Generated at 2022-06-17 08:52:03.008667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:52:13.058563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:52:16.489190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with no args
    action_module = ActionModule(None, None, None, None, None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:52:31.927373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create an action module
    action_module = ActionModule(task, connection, play_context, loader=loader, templar=templar, shared_loader_obj=loader, module_utils=module_utils)

    # Test with verbosity 0
    display.verbosity = 0
    task.args = {'verbosity': 0}
    result = action

# Generated at 2022-06-17 08:52:42.006422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:52:50.888736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:53:01.002411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with verbosity 0
    task_args = {'verbosity': 0}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._display.verbosity = 0
    result = action_module.run(task_vars=None)
    assert result['failed'] == False
    assert result['skipped'] == True
    assert result['skipped_reason'] == "Verbosity threshold not met."
    assert 'msg' not in result
    assert 'var' not in result

    # Test with verbosity 1
    task_args = {'verbosity': 1}

# Generated at 2022-06-17 08:53:03.298277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:53:35.314753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:53:41.611770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module._task is None
    assert action_module._connection is None
    assert action_module._play_context is None
    assert action_module._loader is None
    assert action_module._templar is None
    assert action_module._shared_loader_obj is None


# Generated at 2022-06-17 08:53:45.809646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:53:56.352915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:54:08.557413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group

# Generated at 2022-06-17 08:54:18.007852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 08:54:28.475291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_

# Generated at 2022-06-17 08:54:39.950357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:54:44.030421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 08:54:54.245737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run of class ActionModule
    # The following call should return a dict with the key 'msg' and value 'Hello world!'
    assert ActionModule.run(None, None)['msg'] == 'Hello world!'
    # The following call should return a dict with the key 'msg' and value 'Hello world!'
    assert ActionModule.run(None, None, {'msg': 'Hello world!'})['msg'] == 'Hello world!'
    # The following call should return a dict with the key 'msg' and value 'Hello world!'
    assert ActionModule.run(None, None, {'msg': 'Hello world!', 'verbosity': 0})['msg'] == 'Hello world!'
    # The following call should return a dict with the key 'msg' and value 'Hello world!'

# Generated at 2022-06-17 08:55:53.748198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import json
    import tempfile
    import shutil
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.debug import ActionModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg

# Generated at 2022-06-17 08:56:02.734973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}
    task.args = {'var': 'Hello world!'}
    task.args = {'verbosity': 0}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Test run method
    result = action_module.run()
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False
    assert result['skipped'] == False
    assert result['skipped_reason'] == None

    # Test run method with verbosity threshold not met
    task.args

# Generated at 2022-06-17 08:56:12.478348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars

# Generated at 2022-06-17 08:56:22.042533
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:56:28.339809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule(None, None)
    assert am._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert am.TRANSFERS_FILES == False
    assert am._task == None
    assert am._connection == None
    assert am._play_context == None
    assert am._loader == None
    assert am._templar == None
    assert am._shared_loader_obj == None

# Generated at 2022-06-17 08:56:33.604720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.debug
    action_module = ansible.plugins.action.debug.ActionModule(None, None, None, None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:56:41.144087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:56:52.453466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = task_args
    action_module._display.verbosity = 0
    result = action_module.run(tmp=None, task_vars=None)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False
    assert result['skipped'] == False
    assert result['_ansible_verbose_always'] == True

    # Test with var
    task_args = {'var': 'test_var'}

# Generated at 2022-06-17 08:57:03.780520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock ActionModule
    action_module = ActionModule(task, display, templar)

    # Run the method
    result = action_module.run()

    # Assert the result
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'


# Generated at 2022-06-17 08:57:11.785547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task = dict(
        action=dict(
            module='debug',
            args=dict(
                msg='Hello world!'
            )
        )
    )
    task_vars = dict()
    result = ActionModule(task, task_vars).run(task_vars)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False

    # Test with var
    task = dict(
        action=dict(
            module='debug',
            args=dict(
                var='msg'
            )
        )
    )
    task_vars = dict(msg='Hello world!')
    result = ActionModule(task, task_vars).run(task_vars)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False

