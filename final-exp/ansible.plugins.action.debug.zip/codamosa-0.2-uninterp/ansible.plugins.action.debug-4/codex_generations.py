

# Generated at 2022-06-17 08:48:50.901255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:48:56.865798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Test the run method
    result = action_module.run()

    # Assert the result
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'


# Generated at 2022-06-17 08:49:05.045376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Run the method run of the action module
    result = action_module.run()

    # Check the result
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'


# Generated at 2022-06-17 08:49:15.318802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier

# Generated at 2022-06-17 08:49:22.719606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 08:49:27.788795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock variable manager
    variable_manager = MockVariableManager()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, loader, variable_manager, display)

    # Test with msg
    task.args = {'msg': 'Hello world!'}
    result = action_module.run(None, None)
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'

    # Test with var

# Generated at 2022-06-17 08:49:40.829906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Call method run of class ActionModule
    result = action_module.run()

    # Check the result
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'


# Generated at 2022-06-17 08:49:47.768749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module_utils/basic.py AnsibleModule class
    # This will be used by the ActionModule class to create the self.module object
    mock_module = MagicMock()
    mock_module.params = {}

    # Create a mock object for the module_utils/basic.py AnsibleModule class
    # This will be used by the ActionModule class to create the self.module object
    mock_module = MagicMock()
    mock_module.params = {}

    # Create a mock object for the Display class
    # This will be used by the ActionModule class to create the self._display object
    mock_display = MagicMock()
    mock_display.verbosity = 0

    # Create a mock object for the ActionBase class
    # This will be used by the ActionModule class to create the self._display object
    mock

# Generated at 2022-06-17 08:49:59.214427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object of class Task
    task_obj = Task()

    # Create a mock object of class AnsibleModule
    ansible_module_obj = AnsibleModule()

    # Create a mock object of class AnsibleModule
    ansible_module_obj = AnsibleModule()

    # Create a mock object of class AnsibleModule
    ansible_module_obj = AnsibleModule()

    # Create a mock object of class AnsibleModule
    ansible_module_obj = AnsibleModule()

    # Create a mock object of class AnsibleModule
    ansible_module_obj = AnsibleModule()

    #

# Generated at 2022-06-17 08:50:08.943123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action module
    action_module = ActionModule(task, display, templar)
    # Create a mock task_vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None

    # Test case 1: msg is not defined
    # Expected result: failed is False, msg is 'Hello world!'
    result = action_module.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'

    # Test case 2: msg is defined
    # Expected result: failed is False, msg is 'Hello world!'
    task

# Generated at 2022-06-17 08:50:25.814103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Test with verbosity 0
    display.verbosity = 0
    # Test with msg
    task.args = {'msg': 'Hello world!'}
    result = action_module.run()
    assert result == {'failed': False, '_ansible_verbose_always': True, 'msg': 'Hello world!'}
    # Test with var
    task.args = {'var': 'test'}
    result = action_module.run()

# Generated at 2022-06-17 08:50:36.470352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:50:39.071173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test to create an instance of ActionModule
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert action_module is not None

# Generated at 2022-06-17 08:50:46.890443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._task.args == dict()
    assert action_module._task.action == 'debug'
    assert action_module._task.name == 'debug'
    assert action_module._task.delegate_to is None
    assert action_module._task.delegate_facts is None
    assert action_module._task.loop is None
    assert action_module._task.loop_args is None
    assert action_module._task.notify is None
    assert action_module._task.register is None
    assert action_module._task.when is None
    assert action_module._task.async_val is None

# Generated at 2022-06-17 08:50:58.784673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    cfgfile = os.path.join(tmpdir, "ansible.cfg")
    with open(cfgfile, 'w') as f:
        f.write("[defaults]\nstdout_callback = json\n")

    # Create a temporary directory for inventory
    inventory_dir = os.path.join(tmpdir, "inventory")
    os.mkdir(inventory_dir)

    # Create a temporary inventory file
    inventory_file = os.path.join(inventory_dir, "hosts")

# Generated at 2022-06-17 08:51:11.031756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:51:20.458050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task
    task = {'args': {'msg': 'Hello world!'}}
    # Create a fake play
    play = {'verbosity': 0}
    # Create a fake loader
    loader = {}
    # Create a fake display
    display = {}
    # Create a fake templar
    templar = {}
    # Create a fake shared loader object
    shared_loader_obj = {}

    # Create an instance of ActionModule
    action_module = ActionModule(task, play, loader, display, templar, shared_loader_obj)

    # Assert that the instance of ActionModule is created
    assert action_module is not None

# Generated at 2022-06-17 08:51:25.431283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule(None, None)
    assert module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:51:32.826036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import merge_hash
   

# Generated at 2022-06-17 08:51:41.349025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:52:00.176775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False

    # Test with args
    action_module = ActionModule(None, dict(msg='msg', var='var', verbosity='verbosity'))
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-17 08:52:09.261136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import merge_hash
   

# Generated at 2022-06-17 08:52:20.112046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock action base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, module_utils)
    action_module._display = display

# Generated at 2022-06-17 08:52:34.588203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:52:43.439986
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:52:48.010113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:52:55.924670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host

# Generated at 2022-06-17 08:52:58.625311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.debug import ActionModule
    assert ActionModule

# Generated at 2022-06-17 08:53:06.805920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='debug',
            module_args=dict(
                msg='Hello world!',
                var='test_var',
                verbosity=0
            )
        )
    )
    # Create a mock connection
    connection = dict(
        host='localhost',
        port=22,
        user='vagrant',
        password='vagrant',
        transport='ssh'
    )
    # Create a mock play
    play = dict(
        name='test_play',
        hosts=['localhost'],
        gather_facts='no'
    )
    # Create a mock loader
    loader = dict(
        basedir='/home/vagrant/ansible'
    )
    # Create a mock inventory

# Generated at 2022-06-17 08:53:16.045609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 08:53:47.875734
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:53:56.727103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:54:08.905006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with verbosity 0
    task_args = {'verbosity': 0}
    action = ActionModule(task_args, {})
    action._display.verbosity = 0
    result = action.run(task_vars={})
    assert result['failed'] == False
    assert result['skipped'] == True
    assert result['skipped_reason'] == "Verbosity threshold not met."

    # Test with verbosity 1
    task_args = {'verbosity': 1}
    action = ActionModule(task_args, {})
    action._display.verbosity = 1
    result = action.run(task_vars={})
    assert result['failed'] == False
    assert result['skipped'] == False
    assert result['msg'] == 'Hello world!'

    # Test with verbosity 2

# Generated at 2022-06-17 08:54:18.025833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:54:28.964065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars={}, tmp=None, task_args=task_args)
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'

    # Test with var
    task_args = {'var': 'test_var'}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:54:40.271013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:54:50.844445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['msg'] = 'Hello world!'
    task['args']['verbosity'] = 0
    task['args']['var'] = 'foo'

    # Create a mock task_vars
    task_vars = dict()
    task_vars['foo'] = 'bar'

    # Create a mock display
    display = dict()
    display['verbosity'] = 0

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x, y, z: x

    # Create a mock ActionModule
    action_module = ActionModule(task, display, templar)

    # Call the run method of ActionModule

# Generated at 2022-06-17 08:55:02.071564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:55:10.818217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:55:17.065392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:56:04.985105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for ActionModule constructor
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:56:13.641299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:56:22.338134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    module = ActionModule(None, task_args, load_args_from_file=False)
    result = module.run(None, None)
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'
    assert 'skipped_reason' not in result
    assert 'skipped' not in result

    # Test with var
    task_args = {'var': 'my_var'}
    module = ActionModule(None, task_args, load_args_from_file=False)
    result = module.run(None, {'my_var': 'Hello world!'})
    assert result['failed'] == False
    assert 'msg' not in result
    assert result['my_var'] == 'Hello world!'

# Generated at 2022-06-17 08:56:32.829893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:56:40.733466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:56:48.923838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.debug import ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:56:57.962342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['msg'] = 'Hello world!'
    task['args']['verbosity'] = 0

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock display
    display = dict()
    display['verbosity'] = 0

    # Create a mock templar
    templar = dict()

    # Create a mock action_base
    action_base = dict()

    # Create a mock action_module
    action_module = ActionModule(task, display, templar, action_base)

    # Call method run of class ActionModule
    result = action_module.run(None, task_vars)

    # Asserts
    assert result['failed'] == False

# Generated at 2022-06-17 08:57:07.377609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1:
    #   msg:
    #       msg: Hello world!
    #   var:
    #       var: Hello world!
    #   verbosity:
    #       verbosity: 0
    #   expected result:
    #       msg: Hello world!
    #       failed: False
    #       _ansible_verbose_always: True
    #       skipped: False
    #       skipped_reason: None
    task_args = {
        'msg': 'Hello world!',
        'var': 'Hello world!',
        'verbosity': 0
    }
    expected_result = {
        'msg': 'Hello world!',
        'failed': False,
        '_ansible_verbose_always': True,
        'skipped': False,
        'skipped_reason': None
    }

# Generated at 2022-06-17 08:57:15.767161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.plugins import get_all_plugin_loaders, get_all_plugins
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 08:57:19.294033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None