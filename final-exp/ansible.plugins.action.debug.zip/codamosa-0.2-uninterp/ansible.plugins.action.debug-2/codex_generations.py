

# Generated at 2022-06-17 08:48:55.984380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 08:49:05.702011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:49:15.116377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.action import ActionModule
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess

# Generated at 2022-06-17 08:49:22.436637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module runner
    ansible_module_runner = MockAnsibleModuleRunner()

    # Create a mock ansible module runner
    ansible_module_runner = MockAnsibleModuleRunner()

    # Create a mock ansible module runner
    ansible_module_runner = MockAnsibleModuleRunner()

    # Create a mock ansible module runner
    ansible_module_runner = MockAnsibleModuleRunner()

    # Create a mock ansible module runner
    ansible_module_runner = MockAnsibleModuleRunner()

# Generated at 2022-06-17 08:49:27.188085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    test_action_module = ActionModule(None, None, None, None, None)
    assert test_action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert test_action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:49:33.785816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock PlayContext
    play_context = MockPlayContext()

    # Create a mock ActionBase
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar, display)

    # Run the method run of class ActionModule
    result = action_module.run()

    # Check the result
    assert result

# Generated at 2022-06-17 08:49:39.050489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:49:47.081268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

# Generated at 2022-06-17 08:49:48.792235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 08:49:59.787742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    task_vars = {}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=task_vars, **task_args)
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'
    assert 'skipped' not in result
    assert 'skipped_reason' not in result

    # Test with var
    task_args = {'var': 'Hello world!'}
    task_vars = {}

# Generated at 2022-06-17 08:50:09.392031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 08:50:18.385702
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:50:23.010258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:50:32.733111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:50:41.916976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host

# Generated at 2022-06-17 08:50:47.552775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(
        task=dict(action=dict(module='debug', args=dict(msg='Hello world!'))),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module

# Generated at 2022-06-17 08:50:59.262748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Test with verbosity 0
    display.verbosity = 0
    result = action_module.run()
    assert result['skipped'] == True
    assert result['skipped_reason'] == "Verbosity threshold not met."

    # Test with verbosity 1
    display.verbosity = 1
    result = action_module.run()
    assert result['msg'] == 'Hello world!'

    # Test with verbosity 2
    display.verbosity = 2
    result = action_module.run()

# Generated at 2022-06-17 08:51:11.229147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action module
    action_module = ActionModule(task, display, templar)
    # Create a mock task_vars
    task_vars = {}
    # Create a mock tmp
    tmp = None
    # Test run method of action module
    result = action_module.run(tmp, task_vars)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False
    assert result['skipped'] == False
    assert result['skipped_reason'] == None
    assert result['_ansible_verbose_always'] == True
    # Test run method of action module with verbosity

# Generated at 2022-06-17 08:51:22.833848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action module
    action_module = ActionModule(task, display, templar)
    # Create a mock task_vars
    task_vars = {'var1': 'value1', 'var2': 'value2'}

    # Test with verbosity 0
    display.verbosity = 0
    # Test with msg
    task.args = {'msg': 'Hello world!', 'verbosity': 0}
    result = action_module.run(task_vars=task_vars)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False
    assert result['skipped']

# Generated at 2022-06-17 08:51:32.214454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:51:51.107696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:52:01.015922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:52:12.515891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 08:52:21.374084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 08:52:27.872011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    test_action_module = ActionModule(None, None, None, None, None)
    assert test_action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert test_action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:52:39.176803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 08:52:49.310251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:53:01.306695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module_utils/basic.py AnsibleModule
    class AnsibleModule_mock:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None, add_file_common_args=False):
            class AnsibleModule_mock_params:
                def __init__(self):
                    self.argument_spec = argument_spec
                    self.bypass_checks = bypass_checks
                    self.no_log = no_log
                    self.check_invalid_arguments = check_invalid_arguments
                    self.mutually_exclusive = mutually_exclusive
                    self.required_together = required_together
                    self.required

# Generated at 2022-06-17 08:53:08.067597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 08:53:17.447019
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:53:48.801913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['msg'] = 'Hello world!'
    task['args']['verbosity'] = 0

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock display
    display = dict()
    display['verbosity'] = 0

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x, convert_bare, fail_on_undefined: x

    # Create a mock ActionModule
    action_module = ActionModule(task, display, templar)

    # Run the method run of class ActionModule
    result = action_module.run(task_vars=task_vars)

    # Asserts

# Generated at 2022-06-17 08:53:57.344122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test run method of class ActionModule
    # Create a test object of class ActionModule
    test_obj = ActionModule()
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule
    # Test run method of class ActionModule

# Generated at 2022-06-17 08:54:06.792839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Run the action module
    result = action_module.run()

    # Check the result
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'


# Generated at 2022-06-17 08:54:13.473565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict()

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Test with verbosity 0
    task.args['verbosity'] = 0
    result = action_module.run()
    assert result['failed'] is False
    assert result['skipped'] is True
    assert result['skipped_reason'] == "Verbosity threshold not met."

    # Test with verbosity 1
    task.args['verbosity'] = 1
    result = action_module.run()
    assert result['failed'] is False

# Generated at 2022-06-17 08:54:22.861712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action module object
    action_module = ActionModule(task, display, templar)

    # Create a mock task_vars object
    task_vars = {'var1': 'value1', 'var2': 'value2'}

    # Test with msg argument
    task.args = {'msg': 'Hello world!'}
    result = action_module.run(task_vars=task_vars)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False

    # Test with var argument
    task.args = {'var': 'var1'}
   

# Generated at 2022-06-17 08:54:36.460527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    task_vars = {}
    action = ActionModule(task_args, task_vars)
    result = action.run(task_vars)
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False

    # Test with var
    task_args = {'var': 'test_var'}
    task_vars = {'test_var': 'Hello world!'}
    action = ActionModule(task_args, task_vars)
    result = action.run(task_vars)
    assert result['test_var'] == 'Hello world!'
    assert result['failed'] == False

    # Test with var and verbosity

# Generated at 2022-06-17 08:54:49.103438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    task_vars = {}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=task_vars)
    assert result['msg'] == 'Hello world!'

    # Test with var
    task_args = {'var': 'Hello world!'}
    task_vars = {}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=task_vars)

# Generated at 2022-06-17 08:54:58.185524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 08:55:06.605300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate_keys
    from ansible.utils.vars import combine_v

# Generated at 2022-06-17 08:55:13.117874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import get_vars


# Generated at 2022-06-17 08:56:11.560248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:56:19.640733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Run the method run of class ActionModule
    result = action_module.run(None, None)

    # Assert the result
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'


# Generated at 2022-06-17 08:56:31.057281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_

# Generated at 2022-06-17 08:56:31.644003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-17 08:56:40.440687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 08:56:52.425738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json
    import yaml
    import ansible.plugins.action
    from ansible.plugins.action.debug import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unicode import to_unicode

    class TestActionModule(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup

# Generated at 2022-06-17 08:57:05.663712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:57:14.975578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 08:57:24.612350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no msg and no var
    action_module = ActionModule(dict(msg=None, var=None), dict(verbosity=0))
    result = action_module.run()
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'

    # Test with msg and no var
    action_module = ActionModule(dict(msg='Hello world!', var=None), dict(verbosity=0))
    result = action_module.run()
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'

    # Test with var and no msg
    action_module = ActionModule(dict(msg=None, var='test_var'), dict(verbosity=0))
    result = action_module.run()
    assert result['failed'] == False
    assert result['test_var']

# Generated at 2022-06-17 08:57:28.006861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)