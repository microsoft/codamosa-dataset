

# Generated at 2022-06-17 08:48:55.888570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Display
    display = Display()

    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class PlayContext

# Generated at 2022-06-17 08:49:04.072326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            msg=dict(type='str', default=None),
            var=dict(type='str', default=None),
            verbosity=dict(type='int', default=0),
        ),
        supports_check_mode=True
    )

    # Create a mock task
    task = dict(
        action=dict(
            module='debug',
            args=dict(
                msg='Hello world!',
                verbosity=1
            )
        )
    )

    # Create a mock play context

# Generated at 2022-06-17 08:49:14.983204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Run the method run
    result = action_module.run()

    # Assert that the result is correct
    assert result == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}

    # Create a mock task
    task = MockTask()
    task.args = {'var': 'msg'}

    # Create a mock display
    display = MockDisplay()

# Generated at 2022-06-17 08:49:22.382533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock action_base
    action_base = MockActionBase(task, display, templar, module_utils, connection)

    # Create an instance of ActionModule
    action_module = ActionModule(task, display, templar, module_utils, connection)

    # Call method run of class ActionModule
    result = action_module.run(None, None)

    # Check if the

# Generated at 2022-06-17 08:49:31.658656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:49:43.811252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:49:56.693063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with msg
    task_args = {'msg': 'Hello world!'}
    task_vars = {}
    action_module = ActionModule(task=task_args, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=task_vars)
    assert result['msg'] == 'Hello world!'

    # Test with var
    task_args = {'var': 'test_var'}
    task_vars = {'test_var': 'Hello world!'}
    action_module = ActionModule(task=task_args, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:50:08.291934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
   

# Generated at 2022-06-17 08:50:13.967605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:50:25.350040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group

# Generated at 2022-06-17 08:50:40.480661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args = dict(
            msg = "Hello world!",
            var = "test_var",
            verbosity = 0
        )
    )

    # Create a mock task_vars
    task_vars = dict(
        test_var = "test_var_value"
    )

    # Create a mock display
    display = dict(
        verbosity = 0
    )

    # Create a mock templar
    templar = dict(
        template = lambda x, convert_bare, fail_on_undefined: x
    )

    # Create a mock action_base
    action_base = dict(
        run = lambda x, task_vars: dict(
            failed = False
        )
    )

    # Create a mock action_module
    action_module

# Generated at 2022-06-17 08:50:50.154897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with verbosity 0
    action_module = ActionModule()
    action_module._task.args = {'verbosity': 0}
    action_module._display.verbosity = 0
    result = action_module.run()
    assert result['failed'] == False
    assert result['skipped'] == True
    assert result['skipped_reason'] == "Verbosity threshold not met."

    # Test with verbosity 1
    action_module = ActionModule()
    action_module._task.args = {'verbosity': 1}
    action_module._display.verbosity = 0
    result = action_module.run()
    assert result['failed'] == False
    assert result['skipped'] == True
    assert result['skipped_reason'] == "Verbosity threshold not met."

    # Test with verbosity 2
    action_

# Generated at 2022-06-17 08:50:56.293392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='debug',
            module_args=dict(
                msg='Hello world!',
                verbosity=0,
            )
        )
    )

    # Create a mock task result
    result = dict(
        _ansible_verbose_always=True,
        failed=False,
        msg='Hello world!',
    )

    # Create a mock display
    display = dict(
        verbosity=0,
    )

    # Create a mock templar
    templar = dict(
        template=lambda x, convert_bare, fail_on_undefined: x,
    )

    # Create a mock ActionBase

# Generated at 2022-06-17 08:51:05.368652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 08:51:08.555379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action = ActionModule()
    assert action._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:51:20.270085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:51:30.918991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Display
    display = Display()

    # Create an instance of class DataLoader
    data_loader = DataLoader()

    # Create an instance of class TaskQueueManager
    task_queue_manager = TaskQueueManager()

    # Create an instance of class ConnectionInfo
    connection_info = ConnectionInfo()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Play
    play = Play()

    #

# Generated at 2022-06-17 08:51:40.770074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:51:48.537793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = {
        'args': {
            'msg': 'Hello world!',
            'verbosity': 0
        }
    }

    # Create a mock connection

# Generated at 2022-06-17 08:51:59.446372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Display
    display = Display()

    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of class AnsibleModule
    ansible_module_2 = AnsibleModule()

    # Create an instance of class AnsibleModule
    ansible_module_3 = AnsibleModule()

    # Create an instance of class AnsibleModule
    ansible_module_4 = AnsibleModule()

    # Create an instance

# Generated at 2022-06-17 08:52:20.223231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(action=dict(module='debug', args=dict(msg='Hello world!')))

    # Create a mock play context
    play_context = dict(
        verbosity=0
    )

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock display
    display = dict(
        verbosity=0
    )

    # Create a mock action base
    action_base = dict()

    # Create a mock ansible module
    ansible_module = dict()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = dict()

    # Create an instance of ActionModule

# Generated at 2022-06-17 08:52:22.748827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 08:52:29.572046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am is not None

    # Test with arguments
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-17 08:52:39.834541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:52:49.547766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:53:01.345679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:53:11.039630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:53:17.807386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import merge_hash
   

# Generated at 2022-06-17 08:53:22.093573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:53:33.791967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.debug import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:53:56.786498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 08:54:06.286876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create an instance of ActionModule
    action_module = ActionModule(task, display, templar)

    # Call method run of class ActionModule
    result = action_module.run()

    # Assert result
    assert result['failed'] == False
    assert result['msg'] == 'Hello world!'


# Generated at 2022-06-17 08:54:16.064175
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 08:54:28.280827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action module
    action_module = ActionModule(task, display, templar)

    # Test run with msg
    task.args = {'msg': 'Hello world!'}
    result = action_module.run()
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False
    assert result['_ansible_verbose_always'] == True

    # Test run with var
    task.args = {'var': 'var1'}
    result = action_module.run()
    assert result['var1'] == 'var1'
    assert result['failed'] == False
    assert result

# Generated at 2022-06-17 08:54:39.784236
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 08:54:50.416182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:55:02.042480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}
    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0
    # Create a mock templar
    templar = MockTemplar()
    # Create an instance of ActionModule
    action_module = ActionModule(task, display, templar)
    # Create a mock tmp
    tmp = MockTmp()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)
    # Assert that the result is correct

# Generated at 2022-06-17 08:55:04.802070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:55:15.245478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    action_module = ActionModule(task=dict(args=dict(msg='Hello world!')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run() == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}

    # Test with invalid arguments
    action_module = ActionModule(task=dict(args=dict(msg='Hello world!', var='msg')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run() == {'failed': True, 'msg': "'msg' and 'var' are incompatible options"}

# Generated at 2022-06-17 08:55:21.327827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None, None, None)
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:56:11.983473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:56:20.555672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 08:56:32.267066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 08:56:40.828527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 08:56:52.453222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 08:57:05.663669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'msg': 'Hello world!'}

    # Create a mock display
    display = MockDisplay()
    display.verbosity = 0

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock variable manager
    variable_manager = MockVariableManager()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_utils
    connection = MockConnection()

    # Create a mock action plugin
    action_plugin = ActionModule(task, display, templar, loader, variable_manager, module_utils, connection)

    # Run the method run of class ActionModule

# Generated at 2022-06-17 08:57:09.737816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a fake task
    task = dict(action=dict(module='debug', args=dict(msg='Hello world!')))
    # create a fake play context
    play_context = dict(verbosity=1)
    # create a fake loader
    loader = 'fake loader'
    # create a fake templar
    templar = 'fake templar'
    # create a fake shared plugin loader obj
    shared_plugin_loader_obj = 'fake shared plugin loader obj'
    # create a fake display
    display = 'fake display'
    # create a fake options
    options = 'fake options'
    # create a fake ansible runner obj
    ansible_runner_obj = 'fake ansible runner obj'
    # create a fake connection
    connection = 'fake connection'
    # create a fake ansible runner connection obj
    ans

# Generated at 2022-06-17 08:57:12.190071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.debug import ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 08:57:18.869778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule(None, None, None, None, None, None)
    assert am._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-17 08:57:32.968483
# Unit test for method run of class ActionModule