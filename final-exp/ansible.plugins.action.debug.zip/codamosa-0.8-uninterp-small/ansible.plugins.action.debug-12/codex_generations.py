

# Generated at 2022-06-25 06:36:45.928207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:36:53.070514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1460.8028080427111
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_1 = 1126.9501
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, str_0, float_1)

    # parameter tmp with a default value of None

    # parameter task_vars with a default value of dict()
    task_vars = dict()

    result = action_module_0.run(None, task_vars)
    print(result)


# Generated at 2022-06-25 06:36:54.047370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Test instantiation for class ActionModule

# Generated at 2022-06-25 06:36:58.962046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1460.8028080427111
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_1 = 1126.9501
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, str_0, float_1)
    action_module_0.run()

# Generated at 2022-06-25 06:37:05.061537
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -5399.624205871911
    str_0 = 'hIpp2=Zr$r`<C`D`-L]'
    set_0 = set()
    set_1 = set()
    str_1 = '-Lc$j|1YF&[82oJw\x7fB'
    float_1 = -7723.484103341268
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, str_0, float_1)
    assert float_0 is float_0
    assert float_0 is float_0
    assert str_0 is str_0
    assert float_1 is float_1
    assert set_0 is set_0
    assert set_0 is set_0
    assert str_

# Generated at 2022-06-25 06:37:13.009873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0.display, AnsibleDisplay)
    assert action_module_0.templar == 'qY9_23'
    assert action_module_0.task_vars == 'l;K'
    assert action_module_0._task.action == '?|v*'
    assert action_module_0._task.args == '}(C*k`i'
    assert action_module_0._task.async_val == 0
    assert action_module_0._task.become_method == 'A7x?n'
    assert action_module_0._task.become_user == 'G@Io'
    assert action_module_0._task.changed_when == 'MQ'

# Generated at 2022-06-25 06:37:13.539083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 06:37:14.437142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    unit_test_case_0()


# Generated at 2022-06-25 06:37:25.449384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    float_0 = -1460.8028080427111
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_1 = 1126.9501
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, str_0, float_1)

    assert action_module_0.TRANSFERS_FILES == False
    assert len(action_module_0._VALID_ARGS) == 3
    assert action_module_0.run(tmp_0, task_vars_0)['_ansible_verbose_always'] == True

# Generated at 2022-06-25 06:37:27.747431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1460.8028080427111
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_1 = 1126.9501
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, str_0, float_1)
    tmp = None
    task_vars = dict()
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:37:42.650268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -2235.93
    set_0 = frozenset()
    str_0 = ':v>1i,f$3q%(W)j8z2'
    float_2 = -971.85796
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0._task.action == float_1
    assert action_module_0._task.args.get('msg') is None
    assert action_module_0._task.args.get('var') is None
    assert action_module_0._task.args.get('verbosity') is None
    assert action_module_0._

# Generated at 2022-06-25 06:37:46.556594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = None
    param_1 = None
    action_module_0 = ActionModule(param_0, param_1)
    param_2 = None
    param_3 = None
    assert action_module_0.run(param_2, param_3) == None



# Generated at 2022-06-25 06:37:53.249191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'IpE'
    float_0 = -578.26
    action_module_0 = ActionModule(float_0, float_0, set_0, set_0, str_0, float_0)
    var_0 = action_run(float_0)


# Generated at 2022-06-25 06:38:01.428144
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:38:06.647737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1.253
    float_1 = -1605.34
    set_0 = set()
    float_2 = 0.74
    str_0 = 'pK\x7f=-U[>a^D\x1c!\nc!4y4pFqYM\x0b^\x1eZS'
    str_1 = '#x\x7f=d^h'
    action_module_0 = ActionModule(float_0, float_1, set_0, set_0, str_0, float_2)
    result = action_module_0.run(str_1, set_0)
    assert result == "failed"
    assert output == "failed"


# Generated at 2022-06-25 06:38:15.709651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg_0 = None
    var_0 = 'jKx`\x0f,8\t'
    verbosity_0 = None
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(msg_0, var_0, verbosity_0, tmp_0, task_vars_0)

    # Testing if your test is working with the testing framework.
    assert True == True

    # Testing method run of class ActionModule
    # Testing if the method raises any exceptions.
    try:
        action_module_0.run()
    except:
        raise AssertionError("Raised Exception: method run")

    # Testing if the method raises any exceptions.

# Generated at 2022-06-25 06:38:16.492846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert not True


# Generated at 2022-06-25 06:38:23.382882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    
    try:
        action_module_0 = ActionModule(tmp, task_vars)
        var_0 = action_module_0.run(tmp, task_vars)
    except UnboundLocalError as err:
        print(err.args)
        print('Exception caught, expected')
    else:
        print('No exception caught, incorrect')

# Generated at 2022-06-25 06:38:24.707759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #### Not implemented!
    assert True == True # implement your test here


# Generated at 2022-06-25 06:38:32.414362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    str_1 = 'skipped'
    str_2 = 'skipped'
    bool_1 = str_1 in str_2
    # assert bool_1
    str_3 = action_module_run(action_module_0, float_1)
    # assert str_3 == 'Hello world!'
    int_0 = 1885
    str_4 = 'msg'
    str_5 = 'skipped'
   

# Generated at 2022-06-25 06:38:51.516252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    float_1 = 75.2
    set_0 = set()
    set_1 = set()
    str_0 = '6%JhCZ*EXW'
    float_2 = 54.8022
    action_module_0 = ActionModule(float_1, float_1, set_0, set_1, str_0, float_2)
    var_0 = action_module_0.run(float_0)



# Generated at 2022-06-25 06:38:57.460202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    var_0 = action_module_0.run(float_0)


# Generated at 2022-06-25 06:39:03.307124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)


# Generated at 2022-06-25 06:39:04.676764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_run(action_module)

# Generated at 2022-06-25 06:39:09.545042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'X@s+'
    float_0 = -1985.39
    ActionModule(float_0, float_0, set_0, set_0, str_0, float_0).run()



# Generated at 2022-06-25 06:39:20.069358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    float_1 = 598.29
    set_0 = set()
    str_0 = 'z?6xUM'
    float_2 = 598.29
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    tmp_0 = None
    task_vars_0 = None
    list_0 = [float_2, float_2]
    list_0.append(float_1)
    list_0.append(float_1)
    list_0.append(float_1)
    list_0.append(float_1)
    list_0.append(float_1)
    list_0.append(float_1)
    list_0.append(float_1)


# Generated at 2022-06-25 06:39:30.538763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule(0.0, 0.0, set(), set(), '', 0.0)
    assert isinstance(action_module_2, ActionModule)
    action_module_3 = ActionModule(-1491.54, -1491.54, set({}), set({}), '#%Z"IG_s&:HpXHew|\t', 1126.9501)
    assert isinstance(action_module_3, ActionModule)
    action_module_4 = ActionModule(0.0, 0.0, set({}), set({}), '#%Z"IG_s&:HpXHew|\t', 1126.9501)
    assert isinstance(action_module_4, ActionModule)


# Generated at 2022-06-25 06:39:39.856414
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Creating an object of class ActionModule
    action_module_0 = ActionModule()
    assert action_module_0 is not None, 'Unable to create an object of type ActionModule'
    assert isinstance(action_module_0, ActionModule) == True, \
    'isinstance returning false for class ActionModule'
    assert type(action_module_0) == ActionModule, 'type() returning false for class ActionModule'

    # Creating an object of class ActionModule
    str_0 = 'U6>\t7^u)`]T"7Vu@'
    action_module_0 = ActionModule(str_0)
    assert action_module_0 is not None, 'Unable to create an object of type ActionModule'

# Generated at 2022-06-25 06:39:51.352100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # A testcase is a dictionary.
    # In the dictionary, a testcase is composed of 
    # "input" - a list of variable inputs, 
    # "output" - a list of variable outputs, 
    # "action" - a function to execute the tested method, 
    # "name" - the name of the testcase (optional)
    testcases = []


# Generated at 2022-06-25 06:39:59.740016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()
    # AssertionError: Creating a new instance of ActionBase() is not permitted. Create a subclass instead.
    # AssertionError: ActionBase() takes exactly 2 arguments (0 given)
    # AssertionError: ActionBase() takes exactly 2 arguments (4 given)
    # AssertionError: ActionBase() takes exactly 2 arguments (8 given)
    # AssertionError: ActionBase() takes exactly 2 arguments (12 given)
    # AssertionError: ActionBase() takes exactly 2 arguments (16 given)


# Generated at 2022-06-25 06:40:24.016949
# Unit test for constructor of class ActionModule
def test_ActionModule():
  pass

# Generated at 2022-06-25 06:40:33.995998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = -0.18
    float_2 = -0.55
    set_0 = set()

# Generated at 2022-06-25 06:40:38.549176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 7.21
    float_1 = -1491.54
    set_0 = set()
    set_1 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_1, str_0, float_2)



# Generated at 2022-06-25 06:40:46.019120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    var_0 = action_module_0.run()
    msg_0 = var_0['msg']
    print(msg_0)


# Generated at 2022-06-25 06:40:51.639845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    action_module_0.run(float_0, dict())


# Generated at 2022-06-25 06:40:58.921185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # args.msg is string type and equals "Hello world!"
    # args.var is string type and equals "ansible_all_ipv4_addresses"
    # args.verbosity is integer type and equals 1
    # tmp is None
    # task_vars is dict type and equals {}
    set_0 = set()
    str_0 = 'Hello world!'
    str_1 = 'ansible_all_ipv4_addresses'
    int_0 = 1
    dict_0 = dict()
    action_module_0 = ActionModule(str_0, str_1, int_0, set_0, set_0, str_0)
    expected_0 = dict()
    expected_0["Hello world!"] = "VARIABLE IS NOT DEFINED!"

# Generated at 2022-06-25 06:40:59.383723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:41:02.645148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)

    var_0 = action_module_0.run(float_0)

if __name__ == '__main__':
    action_run()

# Generated at 2022-06-25 06:41:06.820103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)

    # Test method action_run
    # Test case 0
    float_0 = None
    var_0 = action_module_0.action_run(float_0)

# Generated at 2022-06-25 06:41:12.224946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 809.572
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    return action_module_0

# Generated at 2022-06-25 06:42:04.850977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    assert action_module_0._task.args['msg'] == None
    assert action_module_0._task.args['verbosity'] == 0
    assert action_module_0._task.args['var'] == None
    assert action_module_0._task.loop is None
    assert action_module_0._task.notify is None
    assert action_module_0._task.result is None
    assert action_module_0

# Generated at 2022-06-25 06:42:11.150916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)


# Generated at 2022-06-25 06:42:12.058733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0()

# Generated at 2022-06-25 06:42:20.266380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call method of class ActionModule with arguments:
    #
    #
    # Execute the method and get the output
    # var_0 = action_module_0.run(*[float_0])
    #
    # Test the result
    #
    # Test whether the method run of class ActionModule raised an Exception and if so,
    # test the type and message of the caught Exception
    #
    #
    #
    # Test the type of the output
    #
    assert isinstance(var_0, dict)
    # Test the value of the output
    #
    assert var_0["_ansible_verbose_always"]
    assert not var_0["failed"]
    assert var_0["msg"] == "Hello world!"


# Generated at 2022-06-25 06:42:27.056615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Ensure that constructor is correct and that class members are correct
    action_module_0 = ActionModule()
    if action_module_0._display.verbosity != 0:
        raise NameError("member is not correct")
    if action_module_0._task is not None:
        raise NameError("member is not correct")
    if action_module_0._loader is not None:
        raise NameError("member is not correct")
    if action_module_0._templar is not None:
        raise NameError("member is not correct")

    action_module_1 = ActionModule()
    if action_module_1._display.verbosity != 0:
        raise NameError("member is not correct")
    if action_module_1._task is not None:
        raise NameError("member is not correct")

# Generated at 2022-06-25 06:42:34.081795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    var_0 = ActionModule.run(float_0)


# Generated at 2022-06-25 06:42:39.919561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = None
    float_2 = -1491.54
    set_0 = set()
    set_1 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_3 = 1126.9501
    action_module_1 = ActionModule(float_2, float_2, set_1, set_0, str_0, float_3)
    var_0 = action_module_1.run(float_1)

# Generated at 2022-06-25 06:42:46.256496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    msg = 'Hello world!'
    var_0 = 'foobar'
    verbosity = 4
    # self, tmp=None, task_vars=None,
    action_module_0 = ActionModule(None, task_vars, None, None, None, None)
    # task_vars=None,
    action_run(action_module_0, None, task_vars, None, None, None, None)
    # msg=None, task_vars=None,
    action_run(action_module_0, None, task_vars, msg, None, None, None)
    # var=None, task_vars=None,
    action_run(action_module_0, None, task_vars, None, var_0, None, None)
    # verb

# Generated at 2022-06-25 06:42:50.329563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1830.41
    set_0 = set()
    set_1 = set()
    str_0 = 'zIgR4_h4H}Q'
    float_2 = -1345.44
    action_module_0 = ActionModule(float_1, float_1, set_0, set_1, str_0, float_2)


# Generated at 2022-06-25 06:42:55.862888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    with pytest.raises(TypeError):
        ActionModule()


# Generated at 2022-06-25 06:45:06.721050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_3 = None
    float_4 = 0.1412
    set_1 = set()
    float_5 = 2.386
    str_1 = 'mD2(oE.Lf[=bGX8Fv\x7fo'
    float_6 = -0.6022
    set_2 = set()
    str_2 = 'H!4~M\'\x7f$L|<8A@fYh^5\x7f'
    str_3 = '4oeV('
    float_7 = -878.5
    action_module_1 = ActionModule(float_4, float_5, set_1, set_2, str_2, float_6)
    var_1 = action_run(float_3)

# Generated at 2022-06-25 06:45:09.748390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2.52
    float_1 = None
    set_0 = set()
    action_module_0 = ActionModule(float_0, float_1, set_0)
    var_0 = action_module_0.run()

# Test class Action_run
# Method run(self)

# Generated at 2022-06-25 06:45:12.875495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)


# Generated at 2022-06-25 06:45:22.014720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # First test case to test constructor of class ActionModule
    # Assign parameters for the sake of testing
    tmp = None
    task_vars = dict()
    action_module_0 = ActionModule(tmp, task_vars)
    assert action_module_0._VALID_ARGS is not None
    assert action_module_0.TRANSFERS_FILES is False
    assert action_module_0._task is not None
    assert action_module_0._connection is not None
    assert action_module_0._play_context is not None
    assert action_module_0._loader is not None
    assert action_module_0._templar is not None
    assert action_module_0._shared_loader_obj is not None
    assert action_module_0._add_teardown_callback is not None
    assert action

# Generated at 2022-06-25 06:45:22.434839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:45:30.753198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    str_1 = action_module_0.action_plugin()
    str_2 = action_module_0.action_name()
    action_module_0.action_plugins(str_1)
    action_module_0.action_results(str_1)
    action_module_0.action_set_attributes()
    action_module_0.action_simple(str_1, str_1, str_1)

# Generated at 2022-06-25 06:45:32.603186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 06:45:36.929109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    assert(isinstance(action_module_0, ActionModule))

# Generated at 2022-06-25 06:45:43.062673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    var_0 = action_module_0.run(float_0)

# Generated at 2022-06-25 06:45:49.922599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    float_1 = -1491.54
    set_0 = set()
    str_0 = '#%Z"IG_s&:HpXHew|\t'
    float_2 = 1126.9501
    action_module_0 = ActionModule(float_1, float_1, set_0, set_0, str_0, float_2)
    assert action_module_0._task.action == 'setup'
    assert action_module_0._task._role is None
    assert action_module_0._loader._task_cache == set_0
    assert action_module_0._loader._data is None
    assert action_module_0._loader._defer_results is True
    assert action_module_0._loader._deferred_results == set_0
    assert action_