

# Generated at 2022-06-25 06:36:52.772185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import antigravity

    var_0 = sys.version_info
    var_1 = sys.version_info
    var_2 = sys.version_info
    var_3 = sys.version_info
    var_4 = sys.version_info
    var_5 = sys.version_info
    var_6 = sys.version_info
    var_7 = sys.version_info
    var_8 = sys.version_info
    var_9 = sys.version_info
    var_10 = sys.version_info
    # Constructor for ActionModule
    ActionModule()


# Generated at 2022-06-25 06:36:55.598811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.set_task_and_manager(None, None)
    assert isinstance(action.run(None, None), dict)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:37:03.883434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = 'j{1<x8i`Ni?;'
    dict_0['msg'] = str_0
    str_1 = '2qionVX~P)j,'
    bytes_0 = b'\xb1t\xd7\x11\x9e\xe2\xf9\x13\x90\xed\xfd\x03\xd3\x93'
    str_2 = 'pS8d@rz+D\x0b!}I'
    str_3 = 'tnd~l"E(x!\x1b#*'
    dict_0['verbosity'] = str_3
    str_4 = 'j{1<x8i`Ni?;'
    dict_0['msg'] = str_4
    str_

# Generated at 2022-06-25 06:37:10.788924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    str_2 = 'msg'
    str_3 = '\x01\xef\xf4\x0b\x0c\x1d\x90\n\xaas\xf3\xfb\x07\x1f\x08\xa1\x03\x9d\xe2\x12\x1e\x11\x83\x10\x00Y'
    action_module_1._task.args = {str_2: str_3}
    action_module_0.run()
    action_module_1.run()



# Generated at 2022-06-25 06:37:13.092801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arguments
    tmp = str()
    task_vars = None

    actionmodule = ActionModule()
    result = actionmodule.run(tmp, task_vars)
    assert result == {}


# Generated at 2022-06-25 06:37:17.344421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # get task verbosity
    verbosity = int(0)

    if verbosity <= 0:
        # force flag to make debug output module always verbose
        result_['_ansible_verbose_always'] = True
    else:
        result_['skipped_reason'] = "Verbosity threshold not met."
        result_['skipped'] = True

    result_['failed'] = False

    return result_

# Generated at 2022-06-25 06:37:24.643121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test if it initializes based on the options given.
    """
    # TODO: should we make sure that the task is a mock task?  we're not mocking the templar
    action_module = ActionModule()
    assert action_module.task_vars == {}
    assert action_module.tmp == None
    assert action_module.module_name == 'debug'


# Generated at 2022-06-25 06:37:35.401351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    params = {'verbosity': 0}
    task_vars = {}
    tmp = 'tmp'
    # Create an object of the class ActionModule
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Call method run with args tmp, task_vars, value of variable params and value of variable tmp
    # with values tmp, task_vars, params and tmp respectively
    result = obj.run(tmp, task_vars)
    # AssertionError: Expected result is of type dict but the actual type is not dict
    assert type(result) is dict


# Generated at 2022-06-25 06:37:44.605368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_base_0 = ActionBase()
    action_module_0 = ActionModule(action_base_0._task, action_base_0._connection, action_base_0._play_context, action_base_0._loader, action_base_0._templar, action_base_0._shared_loader_obj)
    str_0 = action_module_0.get_action_vars()
    str_1 = '\x15\x05\x02\x12\x0b\x1d\x1e\x1f\x1c\x11\x01\x15\x14\x1d'
    set_0 = {str_0, str_0, str_0, str_1}

# Generated at 2022-06-25 06:37:51.806039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = '2,\x17\n\n"\x1b'
    dict_2 = {str_0: str_0, str_1: str_1, str_0: str_0, str_0: str_0}
    str_2 = 'B*\n0\x1e'
    dict_3 = {str_0: str_0, str_1: str_1, str_2: str_2, str_0: str_0}
    str_3 = 'u{,v'

# Generated at 2022-06-25 06:38:06.108066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define vars needed by ansible
    task_vars = {}
    task_vars["verbosity"] = 1
    task_vars["msg"] = "Hello"
    task_vars["var"] = "test"

    # Call run method of ActionModule
    action_module_0 = ActionModule()
    assert action_module_0.run(task_vars) == {'ansible_facts': {}, 'ansible_included_var_files': [], '_ansible_verbose_always': True, 'msg': 'Hello'}


# Generated at 2022-06-25 06:38:09.231545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We must have a tmp and a task_vars to be able to run this
    action_module_1 = ActionModule()

    assert action_module_1.run() == "Hello world!"

# Generated at 2022-06-25 06:38:10.902922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 06:38:13.866578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\n\n\n")
    print("***********************************************************")
    print("Test Case 1: test_ActionModule")

    # test case 1:
    # test the constructor of class ActionModule

    print("******test case 1******")
    test_case_0()

# Generated at 2022-06-25 06:38:19.750498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object of action plugin and a mock of templar
    from ansible.plugins.action.debug import ActionModule
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    test_host = HostVars(hostname="test_host")

    action_plugin_0 = ActionModule()

# Generated at 2022-06-25 06:38:25.591830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Test when msg is given in the task args
    action_module._task.args['msg'] = 'Hello world!'
    output = action_module.run(tmp=None, task_vars={"var": "Data to put in the output"})
    assert output['msg'] == 'Hello world!'
    assert output['_ansible_verbose_always'] is True
    assert output['failed'] is False


# Generated at 2022-06-25 06:38:26.141610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 06:38:27.947231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module1 = ActionModule()
    action_module2 = ActionModule()
    action_module1.run()
    action_module2.run()

# Generated at 2022-06-25 06:38:31.577612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES==False
    assert action_module_0._VALID_ARGS==frozenset(('msg','var','verbosity'))
    assert action_module_0.run()==None

# Generated at 2022-06-25 06:38:42.030604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.set_runner(Dict({'status': 'failed', 'msg': '', 'skip_reason': ''}))

# Generated at 2022-06-25 06:38:57.950319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    assert type(action_module_0) == ActionModule

# Run tests in order
to_run = [test_case_0 ]
for test_case in to_run:
    test_case()

# Generated at 2022-06-25 06:39:09.117436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters testing
    action_module_0 = ActionModule()
    dict_0 = {'key_0': 'value_0'}
    list_0 = ['msg_0']
    dict_1 = {'key_1': 'value_1'}
    str_0 = 'msg_0'
    dict_2 = {'msg': str_0, 'skipped': 'skipped_1', 'skipped_reason': 'skipped_reason_1', 'changed': 'changed_1', 'failed': 'failed_1', 'warnings': 'warnings_1'}
    dict_3 = {'msg': 'skipped_1'}
    dict_4 = {'skipped_reason': 'skipped_reason_1'}
    str_1 = 'skipped_1'
    var_0 = ansible_

# Generated at 2022-06-25 06:39:19.959679
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Module to test
    import ansible.plugins.action as action

    # Case 0
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = action.ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = action_module_0.run()
    assert var_0 == dict_0

# Generated at 2022-06-25 06:39:27.888272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {bytes_0, set_0}
    float_0 = -854.532
    int_0 = 11
    str_0 = 'Bc_?\xee\xef\x8c\xe3\xb5\xa3\xd9\x15\xbe\xed\x0e\xa4\x8a\x84\x97\x1dt[\x91\x14\xeb\\\xed$'
    list_0 = [dict_0, set_0, int_0, str_0]
    dict_1 = dict_0
    str_1 = str_0
    action_module_0 = ActionModule(dict_0, float_0, list_0, str_0)
    var_0 = action_run(dict_1, str_1)

# Generated at 2022-06-25 06:39:34.348869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {'msg': 'Hello world!', 'verbosity': 0}
    task_vars_0 = {}
    action_module_0 = ActionModule(args_0, task_vars_0, None, None, None, None)
    action_run = action_module_0.run()
    assert action_run['msg_type'] == 'normal'
    assert action_run['task'] == 'say hello'
    assert action_run['verbose_override'] == False

# Generated at 2022-06-25 06:39:40.328555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = action_run()
    assert var_0 is not None


# Generated at 2022-06-25 06:39:46.805477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # You can do some initialization for action_module_0
    # perhaps by reading in some data from a file, or
    # initializing some shared resources, etc.
    # The return value of this method will be the input to other tests,
    # so you probably want to return something useful.
    var_0 = action_module_0.run()
    assert var_0 is not None

# Generated at 2022-06-25 06:39:55.368627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'zSf\x1c$\xec\x1bW\x8dv\xcc\xfb\n\x8f\x1c'
    dict_0 = {'py/object': 'ansible.plugins.action.normal', '_ansible_verbose_always': True, str_0: str_0}
    float_0 = 44.9
    set_0 = {str_0, float_0}
    bytes_0 = b'\xa8\x92\x1e\x9c\xefr\xaa\xe6\xe5\xbd\x95\xe1'
    list_0 = [float_0, set_0]
    str_1 = ''

# Generated at 2022-06-25 06:40:00.200453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # this var will be useful for testing if something was printed on stdout
    result = action_module_0.run(dict_0, list_0)
    print(bytes_0)

if __name__ == '__main__':
    # Wrapper function invoked by setuptools
    test_case_0()

# Generated at 2022-06-25 06:40:01.531992
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    obj = ActionModule()
    output = obj.run()
    assert output == "True"

# Generated at 2022-06-25 06:40:19.451351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with parameters
    try:
        action_module_0 = ActionModule({}, {}, {}, 'Y\x8c\x0e\xfa\xd5\x91\x14\xb3\xf5\x1c\x9c\x1f', {}, '\x18')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 06:40:22.714733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert False
        # Comment
        action_module_0 = ActionModule()
    except NameError as exception_0:
        print('NameError')
    except TypeError as exception_0:
        print('TypeError')


# Generated at 2022-06-25 06:40:27.048048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0._task.args['msg']
    assert action_module_0._task.args['var']
    assert action_module_0._task.args['verbosity']
    assert action_module_0._display.verbosity

# Generated at 2022-06-25 06:40:35.875917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = action_run()



if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:40:39.580310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '`s8\x10'
    action_module_0 = ActionModule(str_0)
    assert var_0 == list_0


# Generated at 2022-06-25 06:40:49.147985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = action_run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:40:57.057420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    str_1 = 'msg'
    str_2 = 'var'
    str_3 = 'verbosity'
    float_1 = float()
    float_2 = float()
    float_3 = float()


# Generated at 2022-06-25 06:41:03.701512
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:41:14.287280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_1 = {'O\x1e\x1e\x13\x14\x1cR\x1f': '\x0b\x0b\x18\x07\x1a\x0f\x1c'}
    float_1 = 0.041853888236861146
    set_1 = {'\x14\x17\x11\r\r\r\r': '\x1c\x0f\x0e\x07\n\x15\x01\x1c'}
    str_1 = 'm,\x08\x0c\x15\x00\x07\x00'

# Generated at 2022-06-25 06:41:21.875995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    assert action_module_0.action_module_0 == None

# Unit test of method run() of class ActionModule

# Generated at 2022-06-25 06:41:53.331683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:41:56.081811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(float_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:41:56.737250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-25 06:42:04.444861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = action_run()
    assert not var_0.failed

# Generated at 2022-06-25 06:42:05.585686
# Unit test for constructor of class ActionModule
def test_ActionModule():
  pass


# Generated at 2022-06-25 06:42:15.484247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = 0.6054723134071364
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    action_module_0.run({}, {'msg': {'msg': 'Hello world!'}})


# Generated at 2022-06-25 06:42:22.280801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:42:27.502469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = action_module_0.run()
    assert var_0 == undefined


# Generated at 2022-06-25 06:42:37.822437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -1.70211
    set_0 = {991}
    str_0 = '\x14A7\xa2(^\x7f'
    list_0 = [dict_0, set_0, float_0, str_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    assert action_module_0 is not None
    assert action_module_0._task is dict_0
    assert action_module_0._play_context is float_0
    assert action_module_0._loader is set_0
    assert action_module_0._templar is str_0
    assert action_module_0._shared_loader_obj is list_0

# Generated at 2022-06-25 06:42:42.609754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create class instance for testing
    dict_0 = dict()
    float_0 = float()
    set_0 = set()
    str_0 = str()
    list_0 = list()
    str_1 = str()
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_1)
    # Call run method with required args
    action_module_0.run(None, None)



# Generated at 2022-06-25 06:43:55.863720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    float_0 = float()
    set_0 = set()
    str_0 = str()
    list_0 = list()
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    dict_1 = dict()
    dict_1['msg'] = 'Hello world!'
    dict_1['failed'] = False
    dict_1['skipped'] = False
    dict_2 = dict()
    dict_2['dest'] = '/home/vagrant/.ansible/tmp/ansible-tmp-1463498526.74-173968147315978/source'
    dict_2['gid'] = 1000
    dict_2['group'] = 'vagrant'

# Generated at 2022-06-25 06:43:56.790267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:44:07.474715
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test cases
    # case_0: msg: 'test'

    dict_0 = {}
    str_0 = 'test'
    dict_1 = {'msg': str_0}
    action_module_0 = ActionModule(dict_0, str_0, dict_1)
    var_0 = action_module_0.run()
    # AssertionError: {'failed': False, 'msg': 'test'} != ['test']

    # case_1: var: test_variable

    dict_0 = {}
    str_0 = 'test_variable'
    dict_1 = {'var': str_0}
    action_module_0 = ActionModule(dict_0, str_0, dict_1)
    var_0 = action_module_0.run()
    # AssertionError: {'

# Generated at 2022-06-25 06:44:09.836626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x10\xecK<'
    str_0 = '4JF\xaa\x6d'
    int_1 = ActionModule(bytes_0, str_0)


# Generated at 2022-06-25 06:44:11.539046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    return action_module_0


# Generated at 2022-06-25 06:44:20.196079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xcf\xc4\xfdT\xfd'
    bytes_1 = b'\x9e\xae\x0f\x10\xc0'
    list_0 = [bytes_0, bytes_1]
    list_1 = [bytes_0, bytes_1]
    list_2 = [bytes_0, bytes_1]
    str_0 = 'Wz:5R\x12\xb6\x1b'
    str_1 = '{%c'
    str_2 = '\x15\x1c\xaa\x81\x8e\xfd\xed\xe70d\xb5\x8a'

# Generated at 2022-06-25 06:44:28.356508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'o\xd5\x1f\x1b\x17\xb8\x91\t\xd6\xfb\x8c\x1f'
    bytes_1 = b'\x00\x0b\x11\x05\x1f\n\n\x1a\x11\x04\n\x16'
    bytes_2 = b'^\x8f\xa7\x9c\x9a'
    str_0 = '\x01\x0b\x00\x03\x00\x0c\x02\x02\x06\x0f\x00\r'
    int_0 = -55

# Generated at 2022-06-25 06:44:32.790670
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_run_0 = {'failed': False,
                    'msg': 'Hello world!'}

    dict_0 = {'verbosity': 0}

    dict_1 = {'ansible_verbose_always': True,
              'msg': 'Hello world!'}

    assert (action_module_0.run(dict_0) == dict_1)


# Generated at 2022-06-25 06:44:37.206891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:44:46.070495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17-\x14X\x8e\xe1\xdd\xb2\x81\xc5\x83\xbd'
    dict_0 = {bytes_0: bytes_0}
    float_0 = -885.5055
    set_0 = {bytes_0, float_0}
    str_0 = 'OMU`*wd`]'
    list_0 = [dict_0, float_0]
    action_module_0 = ActionModule(dict_0, float_0, set_0, str_0, list_0, str_0)
    var_0 = 'verbosity'
    action_run_1 = action_module_0.run({'v'}, dict_0)
    assert isinstance(action_run_1, dict)

# Unit test