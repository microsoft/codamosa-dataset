

# Generated at 2022-06-25 06:36:54.909379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(None, None, None, None, None, None)
    assert action_module_0.run(tmp, task_vars) == {"failed": True, "msg": "'msg' and 'var' are incompatible options"}

    tmp = None
    task_vars = None
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0._task.args = {'msg': 'Hello world!', 'var': 'var'}
    assert action_module_0.run(tmp, task_vars) == {"failed": True, "msg": "'msg' and 'var' are incompatible options"}

    tmp = None
    task_vars = None

# Generated at 2022-06-25 06:37:03.224800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set({'5\x01\x00\x00\x00\x01'})
    str_0 = 'cio'
    set_1 = set()
    set_2 = set()
    action_module_0 = ActionModule(2, str_0, set_0, set_1, 'L\x9e\xfe\x8e\x1a\xa5\xda\xf7\xe4\x9c\xba\x8f\x1b\xd6\x88?', set_2)
    int_0 = 0

# Generated at 2022-06-25 06:37:11.464864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5
    bytes_0 = b'\xc0\x15k\x01\x8a\x8e'
    bytes_1 = b'\xcc\x8aET\x81\xeb\x1b\xab\x97\xc9m\xef\xba\xfd\xd2\xfd\xaag\x99\x8f\xbf\xd9'
    set_0 = {bytes_0, bytes_1}
    set_1 = {bytes_1, bytes_0}
    str_0 = '\x859\x17\x95\xa1\x16\x8a\x9aX\x9b\xfb\x8e\x07\xa4\x92\x01\x8d\x9d\x9a'

# Generated at 2022-06-25 06:37:21.502989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        task_vars_0 = {}
        task_vars_0 = {}
        task_vars_0 = {}
        task_vars_0 = {}
        task_vars_0 = {}
        task_vars_0 = {}
        print('Test case 0: no arguments')
        test_case_0()
    except AssertionError as e:
        print('Test case 0: Failed')
        print('AssertionError: ', e.args)
    except TypeError as e:
        print('Test case 0: Failed')
        print('TypeError: ', e.args)
    except ValueError as e:
        print('Test case 0: Failed')
        print('ValueError: ', e.args)
    print('Tests passed')

# Generated at 2022-06-25 06:37:29.781129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -61
    bytes_0 = b'\x8a^\x18\x86\xd1\xfa\xf9\xbc\xe0\t\xc7\xad\x8a\xad\x1f\xaf)#\x0c'
    dict_0 = dict()
    dict_0['msg'] = 'Hello world!'
    dict_1 = dict()
    bytes_1 = b'\xc4\x1e<\xe6\xab\xdb\x94\xa9\xb7\xac\xe1\xba\xa8\x8a_\xfe\x07]\xce\x9a\xac\xc1\xba\xad\x8c'
    dict_1[u'msg'] = u'Hello world!'
   

# Generated at 2022-06-25 06:37:36.553706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -6
    str_0 = '<'
    dict_0 = {str_0: int_0}
    str_1 = 'yf'
    int_1 = -1
    dict_1 = {str_1: int_1}
    action_module_0 = ActionModule(int_0, str_0, dict_0, dict_1)

    # Call method run
    action_module_0.run()


# Generated at 2022-06-25 06:37:44.264072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'0\x1b\xc8\x04(\x82\x88\x9b\x96\xce\xeb\xb1\xad\xc1\x8c\x0b'
    set_0 = {bytes_0}
    action_module_0 = ActionModule(1, b'\xe1\xed\x04\x9b\xa2\xf37\x04\x1d\xa0\x8e\xb5\xdb\x90\x9d\xad\xd5\x80\x0c', set_0, set_0, '-x', set_0)


# Generated at 2022-06-25 06:37:45.180471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 06:37:52.146530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Input parameters
    int_0 = -1338
    bytes_0 = b'\xb6;\xcd\xe0\xa96\xcc$'
    bytes_1 = b'\xcdF\xbb\xbas$\xfc\x8e6v\xa3I}\x94\xa3\xf1h'
    set_0 = {bytes_1, bytes_0}
    str_0 = 'Parool'

    # Expected result
    expected_result = None

    # Class instantiation
    action_module_0 = ActionModule(int_0, bytes_0, set_0, set_0, str_0, set_0)

    # Test procedure
    assert(action_module_0 is not None)
    assert(action_module_0.TRANSFERS_FILES == False)

# Generated at 2022-06-25 06:38:04.000675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'G\x1f'

# Generated at 2022-06-25 06:38:11.904717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule()
    return c

# test case
# class ActionModule:

# __getattribute__ = test_case_0


# Generated at 2022-06-25 06:38:15.333708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = {}
    res_0 = obj_0.run(tmp_0, task_vars_0)
    assert(res_0 == {'changed': False, '_ansible_verbose_always': True, 'msg': 'Hello world!'})

# Generated at 2022-06-25 06:38:26.449687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    str_0 = module_0.fail_json(msg = 'This is a test failure message.')
    str_1 = module_0.fail_json(msg = 'The parameter "dest" is required but no definition for it was found')
    str_2 = module_0.fail_json(msg = 'The path "/etc/ansible/hacking/test/sanity/code-smell/test_case_0.pyc" does not exist')
    str_3 = module_0.fail_json(msg = 'AnsibleUndefinedVariable: one or more undefined variables: \'dict object\' has no attribute \'foo\'')

# Generated at 2022-06-25 06:38:34.081164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test = {
        'play': {'name': 'test play', 'hosts': ['localhost'], 'gather_facts': 'no'},
        'hosts': [{'hostname': 'localhost'}],
        'vars': {'val': 'test_val'}
    }
    task = {'action': {'module': 'debug', 'args': {'verbosity': '1', 'msg': 'test'}}}
    play_context = dict()
    action_plugin = ActionModule(task, play_context)
    result = action_plugin.run(test)
    assert(result['msg'] == 'test')


# Generated at 2022-06-25 06:38:41.096916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    argv_1 = ['argv_1']
    argv_2 = [['argv_2']]
    argv_3 = {'argv_3': 'argv_3'}
    obj_4 = ActionModule(argv_1, argv_2, argv_3, 'argv_4')
    assert(obj_4.run()['failed'] == False)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:38:42.316733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == '\x1fG'

# Generated at 2022-06-25 06:38:49.373767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param = 'G\x1f'
    temp0 = ActionModule()
    temp1 = temp0.run(tmp=param, task_vars=None)
    temp2 = temp0.run(tmp=None, task_vars=None)
    temp3 = temp0.run(tmp=param, task_vars='G\x1f')
    temp4 = temp0.run(tmp=None, task_vars='G\x1f')
    temp5 = temp0.run(tmp='G\x1f', task_vars=None)
    temp6 = temp0.run(tmp='G\x1f', task_vars='G\x1f')
    temp7 = temp0.run(tmp='G\x1f', task_vars=param)

# Generated at 2022-06-25 06:38:52.289644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    value_0 = test_case_0()
    value_1 = map(str.strip, value_0)
    value_2 = '\n'.join(value_1)

# Generated at 2022-06-25 06:38:56.145941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Task'
    str_1 = 'debug'
    str_2 = 'debug'
    dict_0 = dict()
    dict_0['display'] = '('
    dict_0['task'] = 'task'
    action_module = ActionModule(str_0, str_1, str_2, dict_0)

# Generated at 2022-06-25 06:39:04.232069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test for the existence of the 'run' method
    assert hasattr(ActionModule, 'run'), 'ActionModule method run does not exist'
    # test for the existence of the 'msg' attribute
    assert hasattr(ActionModule, 'msg'), 'ActionModule attribute msg does not exist'
    # test for the existence of the 'var' attribute
    assert hasattr(ActionModule, 'var'), 'ActionModule attribute var does not exist'
    # test for the existence of the 'verbosity' attribute
    assert hasattr(ActionModule, 'verbosity'), 'ActionModule attribute verbosity does not exist'

# Generated at 2022-06-25 06:39:11.516621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:39:18.525613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # setup test data
    ansible_options = ansible.constants.Options()
    tqm = ansible.utils.module_docs.Sqm()
    task = ansible.utils.module_docs.Task()
    play_context = ansible.utils.module_docs.PlayContext()

    # constructor test
    action_module = ActionModule(ansible_options, tqm, task, play_context)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:39:30.216786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock task_vars
    task_vars = {}

    # mock task_vars['special_var_0']
    task_vars['special_var_0'] = undefined

    # mock task_vars['special_var_1']
    task_vars['special_var_1'] = None

    # app module
    # test singleton instance
    am = ActionModule(task=task, connection=conn, play_context=pc, loader=ldr, templar=tmp, shared_loader_obj=slo)

    # test 'msg' in _task.args
    # test 'var' in _task.args
    # test 'verbosity' in _task.args
    result = am.run(task_vars=task_vars)


# Generated at 2022-06-25 06:39:38.902906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('-' * 45)
    print('Unit testing code for method run of class ActionModule')

    # From test case 0 of 2-print
    args_0 = dict()
    args_0['msg'] = 'G\x1f'
    args_0['verbosity'] = 5
    task_vars = dict()
    tmp = None

    # Constructing object instance for class ActionModule with arguments
    obj_ActionModule_instance_for_test_case_0 = ActionModule(tuple(), args_0, tmp, task_vars)

    # Testing method run of class ActionModule
    # No exception thrown
    result = obj_ActionModule_instance_for_test_case_0.run()

# Generated at 2022-06-25 06:39:39.841503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:39:45.396489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the test variables
    tmp = None
    task_vars = None

    # Run the function
    ActionModule.run(tmp, task_vars)
    # Assert the result
    # We have no way of checking the contents of the ansible_facts since this is an action module


# Generated at 2022-06-25 06:39:48.926243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule.py")
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert obj is not None


# Generated at 2022-06-25 06:39:52.109344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True
    # assert False # TODO: implement your test here

test_data = [
    # TODO: add test cases here
]


# Generated at 2022-06-25 06:39:57.746870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # param tmp
    # param task_vars
    tmp = None
    task_vars = None

    # instance of class ActionModule to test
    instance = ActionModule(tmp, task_vars)

    # test method run of class ActionModule
    instance.run(tmp, task_vars)

# Generated at 2022-06-25 06:40:00.287381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (isinstance(ActionModule._VALID_ARGS, frozenset))
    assert (ActionModule.TRANSFERS_FILES == False)

test_case_0()

# Generated at 2022-06-25 06:40:17.432528
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:40:27.871803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization and Local Variable Declaration
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    action_module_0.run

# Generated at 2022-06-25 06:40:36.256461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)

# Generated at 2022-06-25 06:40:46.770643
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert str_0 == dict_0
    assert dict_0 == dict_0
    assert str_0 == str_0
    assert bool_0 == bool_0
    assert str_2 == bytes_0
    assert bool_0 == bool_0
    assert dict_0 == dict_0
    assert dict_0 == dict_0
    assert str_2 == dict_0
    assert dict_0 == dict_0
    assert dict_0 == dict_0
    assert dict_0 == dict_0
    assert str_1 == dict_0
    assert dict_0 == dict_0
    assert str_0 == dict_0
    assert dict_0 == dict_0
    assert str_1 == dict_0
    assert dict_0 == dict_0
    assert str_1 == dict_0
    assert dict_0 == dict_0

# Generated at 2022-06-25 06:40:55.100697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = '\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707
    str_1 = ',x\xda\xe9\xc2'
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)


# Generated at 2022-06-25 06:41:02.134059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_3 = '\x0ctDop2i1@"A'
    dict_1 = {str_3: str_3, str_3: str_3}
    bytes_1 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_1 = -1707.0
    str_4 = ' Ensure inventory basic rules, run after updates '
    bool_1 = False
    str_5 = 'o.&'
    list_1 = [dict_1, dict_1, dict_1, dict_1]
    action_module_1 = ActionModule(bytes_1, float_1, str_4, bool_1, str_5, list_1)
   

# Generated at 2022-06-25 06:41:09.067776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    assert not action_module_0.run(dict_0)

# Generated at 2022-06-25 06:41:10.194665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for f_0 in range(10):
        test_case_0()


# CLASSES

# Generated at 2022-06-25 06:41:19.300671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08\x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_0 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_1 = 'o.&'

# Generated at 2022-06-25 06:41:26.223385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = '\x0ctDop2i1@"A'
    dict_0 = {str_2: str_2, str_2: str_2}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_0 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_0, list_0)
    action_module_0.run(dict_0)

main()

# Generated at 2022-06-25 06:41:48.005449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)

# Generated at 2022-06-25 06:41:54.218653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_0 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_1 = 'o.&'
    action_module_0 = ActionModule(bytes_0, float_0, str_0, bool_0, str_1)


# Generated at 2022-06-25 06:42:04.416249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    var_0 = action_run(dict_0)

# Generated at 2022-06-25 06:42:09.011598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'msg': 'Hello world!'}
    action_module_0 = ActionModule(dict_0)
    assert action_module_0.task.args != ''
    assert action_module_0.task.args['msg'] == 'Hello world!'

# Generated at 2022-06-25 06:42:10.002553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False


# Generated at 2022-06-25 06:42:19.299046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)

# Generated at 2022-06-25 06:42:26.469484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    action_module_0.run(dict_0)

# Unit

# Generated at 2022-06-25 06:42:37.063226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    assert (action_module_0 != None)


# Generated at 2022-06-25 06:42:44.583933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    input0 = {}
    action_module_0 = ActionModule("fk~vF{W#l8$9Y_B", -0.0017789565, "sFb\x00", True, "bcl.T)T*9;\x1d\x1bk", [])
    var_0 = action_module_0.run(input0)
    assert var_0 == {}

    input1 = {}
    action_module_1 = ActionModule("L#&", -0.069663324, "k1x%c&F=+\x00H", True, "k0", [])
    var_1 = action_module_1.run(input1)
    assert var_1 == {}

    input2 = {}

# Generated at 2022-06-25 06:42:46.180894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == {"failed": False, "msg": "Hello world!"}



# Generated at 2022-06-25 06:43:30.607890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "loops"
    str_1 = '9\\'
    str_2 = '\xd4\x87'
    str_3 = "i12\xcf"
    float_0 = 0.05
    str_4 = '\x86\x90\x8a'
    str_5 = 'HU|l6\xac\x80\xee'

# Generated at 2022-06-25 06:43:38.218119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 06:43:48.762652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # dict_0 = {'!': '!', '!': '!'}
    dict_0 = dict()
    dict_0['msg'] = 'Hello world!'
    str_0 = '\x0ctDop2i1@"A'
    dict_0[str_0] = str_0
    dict_0[str_0] = str_0
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0

# Generated at 2022-06-25 06:43:56.908447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)


# Generated at 2022-06-25 06:44:01.972932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# This is a list of specific inputs that the unit test should use to test
# the function.  This is another way of saying that the input can be any
# string.  The unit test will iterate through all the inputs in the list and
# call the function with all of them.

# Generated at 2022-06-25 06:44:08.639811
# Unit test for method run of class ActionModule
def test_ActionModule_run():

	# Set up test environment
	var_11 = 'Test msg'
	var_12 = 'Test var'
	var_13 = 0
	var_14 = {var_11: ActionModule, var_12: var_12}
	
	# Call test method
	action_module_0 = ActionModule(var_11, var_12, var_13, var_14)
	var_15 = action_module_0.run(var_14)
	
	# Check output
	assert var_15 == {'msg': 'Test msg'}



# Generated at 2022-06-25 06:44:17.054775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    var_0 = action_run(dict_0)
    assert var

# Generated at 2022-06-25 06:44:25.837968
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:44:31.420945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_0 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_1 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_0, bool_0, str_1, list_0)


# Generated at 2022-06-25 06:44:36.191936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'G_7=\x00MM': 'G_7=\x00MM', 'G_7=\x00MM': 'G_7=\x00MM'}
    str_0 = 'J'
    str_1 = '3'
    int_0 = 0
    str_2 = '\x1a'
    list_0 = []
    action_module_0 = ActionModule(str_0, str_1, int_0, str_2, list_0, dict_0)
    assert True


# Generated at 2022-06-25 06:46:00.819580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    var_0 = action_module_0.run(dict_0)

# Generated at 2022-06-25 06:46:07.437665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    str_3 = 'msg'
    str_4 = 'var'

# Generated at 2022-06-25 06:46:08.016601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:46:15.466509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '5U\x10\x8e_\xb7\xbe\xb1\x94\x9c\x89\xae\x11\xbc\x19\xb0\x1d\x86\xdb\x98\x1a\x99\xab\xd7\xbb\x1f\xdd\x87\xae\x9e\xd7\x1c\x87\xc3\x18\x13\xa2\x0e\x0f\x9e'
    bool_0 = False
    int_0 = 332
    list_0 = []
    action_module_0 = ActionModule(str_0, bool_0, int_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 06:46:21.729123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)
    var_0 = action_run(dict_0)

# Unit

# Generated at 2022-06-25 06:46:22.377169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True



# Generated at 2022-06-25 06:46:27.890905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)

# Generated at 2022-06-25 06:46:37.005866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test object of class ActionModule
    str_0 = '\x0ctDop2i1@"A'
    dict_0 = {str_0: str_0, str_0: str_0}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_1 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_2 = 'o.&'
    list_0 = []
    action_module_0 = ActionModule(bytes_0, float_0, str_1, bool_0, str_2, list_0)

# Generated at 2022-06-25 06:46:44.984368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'\x0ctDop2i1@"A': '\x0ctDop2i1@"A', '\x0ctDop2i1@"A': '\x0ctDop2i1@"A'}
    bytes_0 = b'\xd0\xe0\xf5\xaa\x81\x04>\xc6dd\x08 \x1b\x9a0\xf3[`\x08'
    float_0 = -1707.0
    str_0 = ' Ensure inventory basic rules, run after updates '
    bool_0 = False
    str_1 = 'o.&'
    list_0 = []