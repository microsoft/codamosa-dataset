

# Generated at 2022-06-25 06:36:50.398350
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '^R"wr__ZjKk'
    tuple_0 = ()
    list_0 = []
    action_module_0 = ActionModule(str_0, tuple_0, str_0, list_0, list_0, str_0)


# Generated at 2022-06-25 06:36:52.631786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule('msg')


# Generated at 2022-06-25 06:36:56.390372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3YPw!Gjz45T2YbXF\nd)'
    tuple_0 = ()
    list_0 = []
    action_module_0 = ActionModule(str_0, tuple_0, str_0, list_0, list_0, str_0)


# Generated at 2022-06-25 06:37:00.589426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '^rT@'
    tuple_0 = ()
    list_0 = []
    dict_0 = dict()
    action_module_0 = ActionModule(str_0, tuple_0, str_0, list_0, list_0, str_0)
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:37:04.291141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'yGQ)C8>|7'
    tuple_0 = ()
    list_0 = []
    assert_raises(AnsibleUndefinedVariable, ActionModule, str_0, tuple_0, list_0, list_0, str_0, str_0, list_0, list_0)


# Generated at 2022-06-25 06:37:08.419078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3YPw!Gjz45T2YbXF\nd)'
    tuple_0 = ()
    list_0 = []
    action_module_0 = ActionModule(str_0, tuple_0, str_0, list_0, list_0, str_0)
    assert action_module_0.run()


# Generated at 2022-06-25 06:37:15.175727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '3YPw!Gjz45T2YbXF\nd)'
    tuple_0 = ()
    list_0 = []
    action_module_0 = ActionModule(str_0, tuple_0, str_0, list_0, list_0, str_0)
    tmp_0 = None
    task_vars_0 = {}
    try:
        action_module_0.run(tmp_0, task_vars_0)
    except Exception:
        exception_expected_0 = None
        raise Exception(exception_expected_0)


if __name__ == '__main__':
    try:
        test_case_0()
    except Exception:
        exception_expected_0 = None
        raise Exception(exception_expected_0)

# Generated at 2022-06-25 06:37:26.376852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Test with 1 argument
    default_args = dict(msg="Hello world!", verbosity=2)
    action = action_module_0.run(default_args)
    assert action.get('msg') == "Hello world!"

    # Test with 2 argument
    vars = dict(foo='bar')
    action = action_module_0.run(default_args, vars)
    assert action.get('msg') == "Hello world!"

    # Test with 'msg' and 'var' arguments being passed at the same time 
    vars = dict(foo='bar')
    default_args['var'] = 'foo'
    default_args['msg'] = "Hello world!"
    action = action_module_0.run(default_args, vars)

# Generated at 2022-06-25 06:37:27.172861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 06:37:38.113992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'junos_facts'
    str_1 = '192.168.0.2'
    dict_0 = {
    }
    dict_1 = {
        'failed': False,
        '_ansible_verbose_always': True,
        'msg': 'Hello world!'
    }

    # Set up mock Ansible module
    mock_ansible_module = MagicMock(**{
        'run_command.return_value': (0, '', ''),
        '_use_unsafe_shell': False,
        '_ansible_selinux_special_fs': dict_0,
    })
    mock_ansible_module.params = dict_0

    # Set up mock Juniper device connection

# Generated at 2022-06-25 06:37:46.702504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'msg'
    action_module_0 = ActionModule(str_0)


# Generated at 2022-06-25 06:37:55.097539
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = dict()
    task_vars_1 = task_vars_0
    tmp_0 = None
    action_module_0 = ActionModule(tmp_0)
    result_0 = action_module_0.run(task_vars_0)
    assert isinstance(result_0, dict)
    assert result_0 == {'failed': False, '_ansible_verbose_always': True, 'msg': 'Hello world!'}

# Generated at 2022-06-25 06:38:02.177801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg_0 = 'msg'
    verbosity_0 = 0
    var_0 = 'msg'
    action_module_0 = ActionModule(msg_0)
    tmp_0 = None
    task_vars_0 = {}
    try:
        action_module_0.run(tmp_0, task_vars_0)
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 06:38:13.026694
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create mock object for module_utils.basic.AnsibleModule
    module_args = {
        'provider': {
            'state': 'present',
            'network_type': 'gre',
            'segment': '10.10.10.0/24',
            'multicast_ip': '224.0.0.1',
            'multicast_port': '1234',
            'physical_network': 'physnet1',
            'segmentation_id': '10'
        }
    }
    ansible_module_0 = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    str_0 = 'neutron_network'
    action_module_0 = ActionModule(ansible_module_0)
    test_case_0

# Generated at 2022-06-25 06:38:16.045250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {'msg': 'msg'};
    action_module_0 = ActionModule('msg')
    result_0 = action_module_0.run('tmp', task_vars_0)
    assert not result_0['failed']
    assert result_0['msg'] == 'msg'

# Generated at 2022-06-25 06:38:22.004297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'msg'
    arg_0 = {'verbosity': 0, 'msg': 'Hello world!'}
    action_module_0 = ActionModule(str_0)
    result_0 = action_module_0.run(arg_0)
    result_1 = action_module_0.run(arg_0)

# Generated at 2022-06-25 06:38:26.106572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert test_case_0() == 'pass'
    except AssertionError as e:
        with open('/tmp/ansible_ActionModule', 'w') as f:
            f.write("{}".format(e))
            f.close()
        raise AssertionError

# Generated at 2022-06-25 06:38:33.384714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'msg'
    action_module_0 = ActionModule(str_0)

    tmp_0 = None

    task_vars_0 = dict()
    task_vars_0['ansible_check_mode'] = True

    dict_0 = action_module_0.run(tmp_0, task_vars_0)
    assert "VARIABLE IS NOT DEFINED!" in dict_0['msg']

    # Verify that we raise an exception if both msg and var are specified
    str_1 = 'var'
    dict_1 = dict()
    dict_1['msg'] = 'Hello World'
    dict_1['var'] = 'msg'
    action_module_1 = ActionModule(dict_1, str_1)


# Generated at 2022-06-25 06:38:40.705657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception:
        print("Exception in user code:")
        print('-'*60)
        traceback.print_exc(file=sys.stdout)
        print('-'*60)
        raise


if __name__ == "__main__":
    test_ActionModule()
    print(ActionModule.__doc__)
    print(ActionModule.run.__doc__)
    print(ActionModule.transfer_files.__doc__)

# Generated at 2022-06-25 06:38:43.625807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'msg'
    action_module_0 = ActionModule(str_0)
    list_0 = []
    dict_0 = {}
    action_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 06:38:53.655588
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg = 'msg'
    action_module = ActionModule(arg)


# Generated at 2022-06-25 06:38:58.077926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'msg'
    action_module_0 = ActionModule(str_0)
    str_1 = 'tmp'
    str_2 = 'task_vars'
    # mock tmp
    task_vars_0 = Dict()
    # call function run
    try:
        action_module_0.run(str_1,task_vars_0)
    except Exception:
        pass

# Generated at 2022-06-25 06:39:00.786934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'msg'
    action_module_0 = ActionModule(str_0)
    action_module_0 = ActionModule(None)
    str_1 = 'var'
    action_module_0 = ActionModule(str_1)
    action_module_0 = ActionModule(None)

# Generated at 2022-06-25 06:39:02.347814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case 0
    test_case_0()



# Generated at 2022-06-25 06:39:07.544910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'msg'
    action_module_0 = ActionModule(str_0)
    str_1 = 'msg'
    dict_0 = dict()
    dict_0['msg'] = str_1
    dict_1 = dict()
    dict_1['msg'] = str_1
    result = action_module_0._execute_module(module_name='debug', module_args=dict_1, task_vars=dict_0, wrap_async=False)
    # AssertionError: u'Hello world!' != 'msg'
    assert result['msg'] == str_1

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:39:11.949875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'msg'
    str_1 = 'var'
    int_2 = 0
    action_module_1 = ActionModule(str_0)
    assert action_module_1.run() == {'failed': False, 'msg': 'Hello world!'}
    action_module_2 = ActionModule(str_1)
    result = action_module_2.run()
    assert result =={"failed": False, "msg": "'msg' and 'var' are incompatible options"}
    action_module_3 = ActionModule(int_2)
    assert action_module_3.run() == {'failed': False, 'msg': 'Hello world!'}

# Generated at 2022-06-25 06:39:21.425233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
#        test_case_0()
        assert True # TODO: implement your test here
    except AssertionError as e:
        print(e)
        assert False

# Collect all test cases in this class
testcases_ActionModule = [
    "test_ActionModule",
]
suite_ActionModule = unittest.TestSuite(map(ActionModule, testcases_ActionModule))

##########################################################
#
#    Running this module from command line
#
##########################################################
if __name__ == "__main__":
    if unittest.TextTestRunner(verbosity=2).run(suite_ActionModule).wasSuccessful():
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-25 06:39:24.190292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'msg'
    # No exception should be thrown
    action_module_0 = ActionModule(str_0)



# Generated at 2022-06-25 06:39:27.101625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'msg'
    action_module_0 = ActionModule(str_0)
    str_1 = 'msg'
    assert action_module_0.run(str_1) == 'Hello world!'

# Generated at 2022-06-25 06:39:34.665833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'msg'
    action_module_0 = ActionModule(str_0)
    str_0 = 'verbosity'
    int_0 = 0
    dict_0 = {}
    str_1 = 'failed'
    bool_0 = False
    dict_1 = {str_1: bool_0}
    dict_2 = action_module_0.run(dict_0, dict_1)
    assert str_0 in dict_2
    assert int_0 == dict_2[str_0]
    assert not dict_2[str_1]


# Generated at 2022-06-25 06:39:44.884733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:39:49.935927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)


# Generated at 2022-06-25 06:39:56.814123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # create a playbook object

# Generated at 2022-06-25 06:40:05.597278
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:40:09.029438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = None
    action_module_0 = ActionModule(var_0, var_1)
    var_2 = action_module_0.run()
    assert var_2

# Generated at 2022-06-25 06:40:15.701786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0f\xb7\x1d\xe8\xb0\x11\x9f\xe8'
    bool_0 = False
    float_0 = 787.085751072
    int_0 = 237
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    var_0 = action_run()
    assert var_0 == 0

# Setting up the tests

# Generated at 2022-06-25 06:40:18.739712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    res_0 = action_module_0.run()


# Generated at 2022-06-25 06:40:26.346892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    
    # TODO : Need to find ActionBase.run definition
    # run_0 = action_module_0.run()
    # assert run_0 ==

# Generated at 2022-06-25 06:40:33.639725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case setup
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = True
    float_0 = 0.0499716
    int_0 = 128
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    task_vars_0 = dict()
    # Test case execution
    result = action_module_0.run(task_vars_0)
    # Test case verification
    assert result['hello'] == 'world'

# Generated at 2022-06-25 06:40:40.445211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0c\x80\xec\xc3\x07\xd1\x1f\x1a\x8e\x11\xbb\xd5\xbc\xf5\xf4\xc5-\x9a'
    bool_0 = False
    float_0 = 3.951045
    int_0 = 47
    str_0 = '{\'msg\':\'this is a debug message\',\'verbosity\':0}'
    float_1 = 4.9431223334615
    str_1 = '\x0c\x80\xec\xc3\x07\xd1\x1f\x1a\x8e\x11\xbb\xd5\xbc\xf5\xf4\xc5-\x9a'


# Generated at 2022-06-25 06:41:03.301498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert True

# Generated at 2022-06-25 06:41:09.728947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    int_0 = -67
    task_vars_0 = {'dict_0': {'float_0': -196.604425718, 'list_0': ['list_1', -65, -41, 'list_4', 'list_5', 'list_6', 'list_7', 'list_8', -3, 'list_10'], 'int_0': 'int_1', 'bool_1': False}, 'unicode_0': 'unicode_0', 'str_1': 'str_0', 'str_0': 'str_1', 'bool_0': 'bool_1', 'int_1': -15}
    assert type(ActionModule.run(tmp_0, task_vars_0)) is dict


# Generated at 2022-06-25 06:41:14.582692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)


# Generated at 2022-06-25 06:41:16.475322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('msg', 'var', 'verbosity')
    assert off(action_module_0) == None


# Generated at 2022-06-25 06:41:19.976248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    if __name__ == u'__main__':
        var_0 = test(action_run, action_run)

    return None


# Generated at 2022-06-25 06:41:23.087041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)

# Generated at 2022-06-25 06:41:25.485107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = dict()
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:41:27.229186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:41:31.479047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)


# Generated at 2022-06-25 06:41:33.414902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not None
    assert not 'ActionModule'
    assert not "ActionModule"
    assert not 'def '
    assert not 'assert'


# Generated at 2022-06-25 06:42:21.983487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    assert not action_module_0._supports_async, "instance variable '_supports_async' not initialized properly"
    assert not action_module_0._supports_check_mode, "instance variable '_supports_check_mode' not initialized properly"
    assert not action_module_0._uses_shell, "instance variable '_uses_shell' not initialized properly"

# Generated at 2022-06-25 06:42:26.666175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x07\x9f'
    bool_0 = True
    float_0 = 564.4824
    int_0 = 789
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    assert action_module_0._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module_0.TRANSFERS_FILES == False
    print('UnitTest End')

# Generated at 2022-06-25 06:42:33.508139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:42:34.266622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run("msg", 0) == 0

# Generated at 2022-06-25 06:42:42.642185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'P\xac\xa0n\xbc\xca\x1d\x9f\x4b\x1e\x04\xd6\x90\xab\xc1\x88\xa2\x9e\x95\xf7\x8as\x93\xd7\x89\x7f\x9a\xde'
    bool_0 = True
    float_0 = 869.382217
    int_0 = 83
    float_0 = 675.26342

# Generated at 2022-06-25 06:42:48.190380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    hash_0 = {'hello': 'world'}
    action_run(hash_0)

# Generated at 2022-06-25 06:42:53.881850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    assert action_module_0._task.args['verbosity'] == '0'
    action_module_0 = ActionModule(action_module_0._task, action_module_0._connection, action_module_0._play_context, action_module_0._loader, action_module_0._templar, action_module_0._shared_loader_obj)
    assert action_module_0._task.args['verbosity'] == '0'

#

# Generated at 2022-06-25 06:43:02.464040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['_ansible_parsed'] = '_ansible_parsed'
    dict_0['_ansible_verbose_always'] = True
    dict_0['_ansible_no_log'] = False
    dict_0['_ansible_item_label'] = '_ansible_item_label'
    dict_0['_ansible_diff'] = '_ansible_diff'
    dict_0['_ansible_selinux_special_fs'] = '_ansible_selinux_special_fs'
    dict_0['_ansible_no_log'] = True
    dict_0['_ansible_item_label'] = True
    dict_0['invocation'] = 'invocation'

# Generated at 2022-06-25 06:43:09.380317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    assert(action_module_0._task == bytes_0)
    assert(action_module_0._connection == bool_0)
    assert(action_module_0._play_context == float_0)
    assert(action_module_0._loader == int_0)
    assert(action_module_0._templar == float_0)
    assert(action_module_0._shared_loader_obj == bytes_0)

# Generated at 2022-06-25 06:43:13.344499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    assert boolean_0, string_0
    action_module_0.run(dict_0, task_vars=None)

# Generated at 2022-06-25 06:45:06.839993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)


# Generated at 2022-06-25 06:45:10.895894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    var_0 = type(action_module_0)
    assert var_0 == ActionModule


# Generated at 2022-06-25 06:45:14.826742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:45:15.468439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(test_case_0())


# Generated at 2022-06-25 06:45:24.499574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, float_0, int_0)
    str_0 = action_module_0.run()
    str_1 = action_module_0.run()
    str_2 = action_module_0.run()
    str_3 = action_module_0.run()
    str_4 = action_module_0.run()
    str_5 = action_module_0.run()
    str_6 = action_module_0.run()
    str_7 = action_module_0.run()
    str_8 = action_module_0.run()
    str

# Generated at 2022-06-25 06:45:33.679143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xaf\xb5\xec\xaf\xd0\xf9\x1e'
    bool_0 = True
    float_0 = 1715.2734
    int_0 = -26389
    float_0 = 3142.19
    bytes_0 = b'\x1f\x92\x9f\x9d\xbe\xe4\xd4\x00\x06f\x8f8\x1f'
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    var_0 = None
    dict_0 = dict()
    var_0 = action_module_0.run(var_0, dict_0)
    print(var_0)

# Generated at 2022-06-25 06:45:40.340971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc1\xe2\xecE;\xde\x90\x87\x8c\x97\xd1\x06\xc7\xe1'
    bool_0 = True
    float_0 = 184.1607
    int_0 = 3
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:45:45.241104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    assert action_module_0


# Generated at 2022-06-25 06:45:47.362803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test')
    action_module_0 = ActionModule()
    assert True


# Generated at 2022-06-25 06:45:55.457804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf2j\x1e"3\xe0C\xb7\x94'
    bool_0 = False
    float_0 = 914.467434
    int_0 = 649
    action_module_0 = ActionModule(bytes_0, bool_0, float_0, int_0, float_0, bytes_0)
    assert action_module_0._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module_0.TRANSFERS_FILES == False
