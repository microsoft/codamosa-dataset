

# Generated at 2022-06-25 06:36:48.704774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:36:51.596793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    buffer0 = {'skipped': True, 'skipped_reason': "Verbosity threshold not met."}
    buffer1 = ActionModule(skipped_reason='Verbosity threshold not met.', skipped=True)
    assert buffer0 == buffer1


# Generated at 2022-06-25 06:36:59.527889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 252.75203
    bytes_0 = b'\x83\x8d\xeblU\xa4\xd5A\xccy*\xca\xbd\n\xb0\x88'
    bool_0 = None
    int_0 = 3300
    action_module_0 = ActionModule(float_0, float_0, bytes_0, bool_0, int_0, bool_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:37:04.519671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 252.75203
    bytes_0 = b'\x83\x8d\xeblU\xa4\xd5A\xccy*\xca\xbd\n\xb0\x88'
    bool_0 = None
    int_0 = 3300
    action_module_0 = ActionModule(float_0, float_0, bytes_0, bool_0, int_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 06:37:09.594658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 252.75203
    bytes_0 = b'\x83\x8d\xeblU\xa4\xd5A\xccy*\xca\xbd\n\xb0\x88'
    bool_0 = None
    int_0 = 3300
    action_module_0 = ActionModule(float_0, float_0, bytes_0, bool_0, int_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 06:37:16.003150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid args
    args = {
        'msg': 'TEST_MSG'
    }
    float_0 = 252.75203
    bytes_0 = b'\x83\x8d\xeblU\xa4\xd5A\xccy*\xca\xbd\n\xb0\x88'
    bool_0 = None
    int_0 = 3300
    action_module_0 = ActionModule(float_0, float_0, bytes_0, bool_0, int_0, bool_0)
    action_module_0._task.args = args
    result = action_module_0.run()
    assert type(result) == dict
    assert result['msg'] == 'TEST_MSG'


# Generated at 2022-06-25 06:37:23.940786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 252.75203
    bytes_0 = b'\x83\x8d\xeblU\xa4\xd5A\xccy*\xca\xbd\n\xb0\x88'
    bool_0 = None
    int_0 = 3300
    action_module_0 = ActionModule(float_0, float_0, bytes_0, bool_0, int_0, bool_0)


# Generated at 2022-06-25 06:37:27.234042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_module_0 = ActionModule()
    except Exception as err:
        print(err)

# Generated at 2022-06-25 06:37:34.797322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 252.75203
    bytes_0 = b'\x83\x8d\xeblU\xa4\xd5A\xccy*\xca\xbd\n\xb0\x88'
    bool_0 = None
    int_0 = 3300
    action_module_1 = ActionModule(float_0, float_0, bytes_0, bool_0, int_0, bool_0)
    result = action_module_1.run()
    assert result

# Generated at 2022-06-25 06:37:37.312687
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_1 = ActionModule()

    assert isinstance(action_module_1, ActionModule), \
        "Instance should be of type ActionModule"


# Generated at 2022-06-25 06:37:44.269382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None

# Generated at 2022-06-25 06:37:49.012274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Description: Test for the run method of class ActionModule
    # Input: None
    # Expect: result = {
    #                   '_ansible_verbose_always': True,
    #                   'failed': False
    #                 }
    action_module_1 = ActionModule()
    result = action_module_1.run()
    assert sorted(result) == sorted({'failed': False, '_ansible_verbose_always': True})


# Generated at 2022-06-25 06:37:51.052749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 06:37:52.181909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule



# Generated at 2022-06-25 06:37:55.473816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    task_vars = dict()
    # Check type of the returned value
    assert isinstance(action_module.run( None, task_vars), dict)


# Generated at 2022-06-25 06:37:59.321262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    print(action_module_1)
    action_module_1._task = {'args': {'var': 'ansible_hostname'}}
    print(action_module_1.run)

# Generated at 2022-06-25 06:38:11.443301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.set_task_vars({'new_task_var':'new_task_value'})
    action_module_1.set_loader({'templates':['template1.j2'], 'files':['files1.txt']})
    action_module_1.set_shared_loader_obj({'new_shared_loader_var_1':'new_shared_loader_value_1', 'new_shared_loader_var_2':'new_shared_loader_value_2'}, True)
    action_module_1.set_loader({'new_loader_var_1':'new_loader_value_1', 'new_loader_var_2':'new_loader_value_2'})

# Generated at 2022-06-25 06:38:12.288955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 06:38:16.452631
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # arrange
    action_module = ActionModule()
    task_vars = {'_variable_name': 'hello'}
    task_args = ['hello', 'verbosity=2']

    # act
    result = action_module.run(None, task_vars, task_args)

    # assert
    assert result == {'failed': True, 'msg': "'msg' and 'var' are incompatible options"}


# Generated at 2022-06-25 06:38:27.602688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    if hasattr(action_module, '_filter_loader') is False:
        raise AssertionError("ActionModule doesn't have attribute '_filter_loader'")
    if hasattr(action_module, '_templar') is False:
        raise AssertionError("ActionModule doesn't have attribute '_templar'")
    if hasattr(action_module, '_name') is False:
        raise AssertionError("ActionModule doesn't have attribute '_name'")
    if hasattr(action_module, '_task') is False:
        raise AssertionError("ActionModule doesn't have attribute '_task'")

# Generated at 2022-06-25 06:38:36.017621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule) == type


# Generated at 2022-06-25 06:38:45.078573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # byte_0 string input
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    var_0 = action_module_0.run()

    # byte_0 string input
    bytes_0 = b'N\x93\x1d\xbf\x12\x04\xb7\x06n\x1f'

# Generated at 2022-06-25 06:38:51.181825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)


# Generated at 2022-06-25 06:38:56.885365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)


# Generated at 2022-06-25 06:39:00.008492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = 'test_param_0'
    action_module_0 = ActionModule(param_0)
    attr_0 = action_module_0.run(param_0)

# Generated at 2022-06-25 06:39:04.487719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    # validation for method run of class ActionModule
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 06:39:06.547664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(' \xa1\xb1H\xcePL\xd2', True, None, None, b'', 'Timeout when waiting for search string %s in %s:%s'), ActionModule)
    assert isinstance(ActionModule(' \xa1\xb1H\xcePL\xd2', True, None, None, b'', 'Timeout when waiting for search string %s in %s:%s'), object)


# Generated at 2022-06-25 06:39:15.121835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Hello world!'
    str_0 = 'AnsibleUndefinedVariable'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    var_0 = action_module_0.run(bytes_0)
    assert var_0 == {'failed': False, '_ansible_verbose_always': True, 'msg': 'Hello world!'}

# Generated at 2022-06-25 06:39:24.070117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiation of class ActionModule
    assert class_ActionModule(False, [('', '', '', '', '', '')], [('', '', '', '', '', '')], b'', '', [('', '', '', '', '', '')], [('', '', '', '', '', '')], [('', '', '', '', '', '')], [('', '', '', '', '', '')]) is True
    assert class_ActionModule(0.0, [2], [2], b'', '', [], [0], [''], ['']) is True
    assert class_ActionModule(b'', [], [], b'', '', [''], [], [''], ['']) is True

# Generated at 2022-06-25 06:39:29.256154
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:39:42.474196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError):
        ActionModule()


# Generated at 2022-06-25 06:39:49.308359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)


# Generated at 2022-06-25 06:39:53.342057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule('hello world')
    if var_0 == "hello world":
        var_1 = 5
    else:
        var_1 = 10
    var_2 = ActionModule()
    if var_2 == "goodbye world":
        var_3 = 5
    else:
        var_3 = 10


# Generated at 2022-06-25 06:39:59.215998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Write message'

    bool_0 = True
    tuple_0 = []
    str_1 = 'No module found for %s'
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, str_0, str_1)


# Generated at 2022-06-25 06:40:07.775797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    list_0 = []
    bool_1 = True
    if bool_1:
        site.blankout()

# Generated at 2022-06-25 06:40:14.846061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)


# Generated at 2022-06-25 06:40:25.416624
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:40:32.715144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    assert (action_module_0.run(bytes_0) == {'failed': False})


# Generated at 2022-06-25 06:40:39.891144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_1 = Action

# Generated at 2022-06-25 06:40:46.513734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    action_module_0.run(bytes_1)


# Generated at 2022-06-25 06:41:20.934761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float

# Generated at 2022-06-25 06:41:25.825576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    bytes_1 = b''
    action_module_0 = ActionModule(bytes_0, bool_0, tuple_0, tuple_0, bytes_1, bytes_0)


# Generated at 2022-06-25 06:41:33.420341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    b' \xa1\xb1H\xcePL\xd2'
    b''
    ' \xa1\xb1H\xcePL\xd2'
    'Timeout when waiting for search string %s in %s:%s'
    'Timeout when waiting for search string %s in %s:%s'
    ' \xa1\xb1H\xcePL\xd2'
    {{
    }}
    (None,)
    (None,)
    True
    action_module_0 = ActionModule('Timeout when waiting for search string %s in %s:%s', True, (None,), (None,), b'', 'Timeout when waiting for search string %s in %s:%s')



# Generated at 2022-06-25 06:41:35.020629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    state = True
    my_list = []
    my_int = 0
    my_str = ''
    my_dict = {}
    assert type(my_dict) is dict


# Generated at 2022-06-25 06:41:40.271202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    tmp_0 = None
    task_vars_0 = {}
    action_module_0.run(tmp_0, task_vars_0)
    assert var_0 == 'Dictionary. If var is a list or dict, use the type as key to display'


# Generated at 2022-06-25 06:41:48.418678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    str_0 = 'A'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''

# Generated at 2022-06-25 06:41:54.492808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    var_0 = action_module_0.action_run(bytes_0)

# Generated at 2022-06-25 06:42:01.066545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'Hello world!'
    str_0 = 'Hello world!'
    bool_0 = False
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b'action_strings'
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    action_module_0.run(bytes_0, bytes_1)

# Generated at 2022-06-25 06:42:06.797365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test prep
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    bytes_1 = b''
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    action_module_0 = ActionModule(str_0, True, (None,), (None,), bytes_1, str_0)
    tmp_0 = None
    task_vars_0 = None
    # Test call
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    # Test checks
    assert not (False)
    assert var_0 == {'msg': 'Hello world!', '_ansible_verbose_always': True}

# Unit tests for ActionModule.__init__

# Generated at 2022-06-25 06:42:14.342677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    var_0 = action_module_0(bytes_0)


# Generated at 2022-06-25 06:43:23.199633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    var_0 = action_module_run(bytes_0)



# Generated at 2022-06-25 06:43:28.355959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)



# Generated at 2022-06-25 06:43:32.075828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 06:43:38.123091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Declare objects to pass to the method
    str_0 = 'testString'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_0 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_0, str_0)
    bool_1 = False
    action_module_0.set_task_and_var_override(str_0, bool_1, str_0, str_0, str_0)
    #Run method
    action_module_0.run()

test_ActionModule_run()

# Generated at 2022-06-25 06:43:41.400233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Connect to remote host via %s: %s'
    bool_0 = False
    tuple_0 = (None,)
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, '', str_0)

# Generated at 2022-06-25 06:43:51.707546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'#copyright\xcc\x88\xc2\xa9'
    str_0 = 'roles/test'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b'\x10\x9e\x8c\x84\xd5\x87\x19\xd0\x1e\x80\xfb\x9a\x8a\x06'
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    str_1 = ''
    action_run(action_module_0)


# Generated at 2022-06-25 06:43:56.720083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_0 = b''
    str_1 = 'Timeout when waiting for search string %s in %s:%s'
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_0, str_1)
    action_module_0.run()


# Generated at 2022-06-25 06:44:05.769920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    tuple_0 = (complex_0,)
    bool_0 = True
    complex_0 = None
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    assert_equals(ActionModule._VALID_ARGS, 'p\x8f\xbd\x06u\xe6\x13')

# Generated at 2022-06-25 06:44:10.668264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)



# Generated at 2022-06-25 06:44:16.457724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
    var_0 = action_module_0.run(bytes_0)

# Generated at 2022-06-25 06:46:36.532241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	str_0  = 'Timeout when waiting for search string %s in %s:%s'
	bool_0 = True
	complex_0 = None
	tuple_0 = (complex_0,)
	bytes_0 = b''
	action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_0, str_0)

	# Test case for method run with default args
	var_0 = action_module_0.run()
	# Test case for method run with args tmp=None and task_vars=None

# Generated at 2022-06-25 06:46:41.441085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b' \xa1\xb1H\xcePL\xd2'
    str_0 = 'Timeout when waiting for search string %s in %s:%s'
    bool_0 = True
    complex_0 = None
    tuple_0 = (complex_0,)
    bytes_1 = b''
    action_module_0 = ActionModule(str_0, bool_0, tuple_0, tuple_0, bytes_1, str_0)
