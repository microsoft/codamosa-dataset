

# Generated at 2022-06-25 06:36:49.071277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:36:59.564872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    tuple_0 = (1, 0, 9)
    list_0 = []
    dict_0 = {}
    dict_1 = {}
    dict_2 = {"msg": "Good"}
    dict_3 = {'var': "msg"}
    dict_4 = {"var": dict_3}
    dict_5 = {"msg": "Hello world!"}
    dict_6 = {"var": dict_5}
    dict_7 = {"msg": "Hello world!", "_ansible_verbose_always": True}
    list_1 = [str, dict_0, dict_1, dict_2, dict_3, dict_4, dict_5, dict_6, dict_7, tuple_0, list_0, dict_0]

# Generated at 2022-06-25 06:37:03.932802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['msg'] = 'Hello world!'
    dict_0['verbosity'] = 0
    task_vars_0 = dict()
    action_module_1 = ActionModule(set(), set(), set(), tuple(), list(), list())
    result = action_module_1.run('>', task_vars_0)
    assert result == dict_0



# Generated at 2022-06-25 06:37:12.020230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    tuple_0 = ()
    list_0 = []
    list_1 = [set_0, tuple_0, list_0, tuple_0]
    dict_0 = {}
    dict_1 = {}
    dict_1['msg'] = u'set_0'
    dict_1['var'] = u'tuple_0'
    dict_1['verbosity'] = u'list_0'
    dict_0 = dict_1
    dict_1 = {}
    dict_1['msg'] = u'tuple_0'
    dict_1['var'] = u'set_0'
    dict_1['verbosity'] = u'list_0'
    dict_0 = dict_1
    list_2 = [dict_0]

# Generated at 2022-06-25 06:37:15.195884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    tuple_0 = ()
    list_0 = []
    action_module_0 = ActionModule(set_0, set_0, set_0, tuple_0, list_0, list_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:37:21.300761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    tuple_0 = ()
    list_0 = []
    list_1 = [set_0, tuple_0, list_0, tuple_0]
    action_module_0 = ActionModule(set_0, set_0, set_0, tuple_0, list_1, list_1)


# Generated at 2022-06-25 06:37:29.668693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    var_manager = VariableManager()
    play = Play().load(dict(
        name = "test play",
        hosts = "all",
        roles = [],
        tasks = [
            dict(
                block = Block(
                    tasks = [
                        Task().load(dict(
                            name = "test task",
                            action = "action_module_0",
                            args = dict(),
                            register = "test_task_register"
                        ))
                    ]
                )
            )
        ]
    ), var_manager=var_manager)


# Generated at 2022-06-25 06:37:37.264870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_0 = _create_task_object()
    task_vars_0 = _create_task_vars_object()
    action_module_0 = ActionModule(tmp, task_vars_0, task_0)
    verbosity = 0
    try:
        action_module_0.run(tmp, task_vars_0)

        # cleanup function as it does not cleanup correctly
        action_module_0._remove_tmp_path(tmp)
    except:
        raise AssertionError()


# Generated at 2022-06-25 06:37:41.787057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    set_1 = set()
    list_0 = []
    list_1 = [set_0, set_1, list_0]
    tuple_0 = ()
    action_module_0 = ActionModule(set_0, list_1, tuple_0, list_1, list_1, list_1)


# Generated at 2022-06-25 06:37:43.272500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:37:53.750680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    int_0 = 0
    obj_0 = ActionModule(var_0)
    tmp_0 = None
    task_vars_0 = None
    var_0 = obj_0.run(tmp_0, task_vars_0)
    assert False


# Generated at 2022-06-25 06:37:56.475138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    int_0 = 0
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:38:06.701304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    yaml_0 = Task.load('action_plugin/test_file_1')
    task_0 = Task.load('')
    tmp_0 = None
    task_vars_0 = dict()
    task_1 = ActionModule(task_0, tmp_0, task_vars_0)
    result_0 = task_1.run(tmp_0, task_vars_0)
    assert 'msg' in result_0
    assert result_0['failed'] == False
    assert result_0['_ansible_verbose_always'] == True
    assert result_0['msg'] == 'Hello world!'


# Generated at 2022-06-25 06:38:08.176575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement tests
    assert True # TODO: Implement tests


# Generated at 2022-06-25 06:38:11.537158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars_0 = None
    var_0 = ActionModule(task_vars_0)
    assert var_0 is not None
    print("unit test for ActionModule: Success")


# Generated at 2022-06-25 06:38:15.567744
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_0 = None
    conn_0 = None
    play_0 = None
    loader_0 = None
    templar_0 = None
    shared_loader_obj_0 = None
    app_0 = None

    action_module_0 = ActionModule(task_0, conn_0, play_0, loader_0, templar_0, shared_loader_obj_0, app_0)


# Generated at 2022-06-25 06:38:16.993602
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:38:21.547277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict()
    expected = dict()
    if var_0==0 and int_0==1:
        result['failed'] = False

    #Testing if the output of function run is equivalent to expected
    assert result == expected


# Generated at 2022-06-25 06:38:26.013006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=test_case_0(),
        connection=test_case_0(),
        play_context=test_case_0(),
        loader=test_case_0(),
        templar=test_case_0(),
        shared_loader_obj=test_case_0())


# Generated at 2022-06-25 06:38:33.334787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner_0 = None
    int_0 = 0
    bool_0 = False
    ansible_facts_0 = ActionModule(None, runner_0)

# Generated at 2022-06-25 06:38:44.523617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -90
    list_0 = []
    int_1 = 29
    set_0 = {int_0, int_1}
    tuple_0 = ()
    float_0 = -36.76
    tuple_1 = (float_0, set_0, tuple_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:38:46.070474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 'skipped_reason' in run()
    assert 'skipped' in run()

# Generated at 2022-06-25 06:38:48.369577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert(var_0 == 'Hello world!')



# Generated at 2022-06-25 06:38:56.304295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = -982
  list_0 = [int_0, int_0]
  int_1 = 1318
  int_2 = -1823
  set_0 = {int_1, int_2}
  tuple_0 = ()
  float_0 = -18.7243
  tuple_1 = (set_0, tuple_0, float_0, list_0)
  action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)

# Generated at 2022-06-25 06:38:59.755810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.variable import Variable

    task = Task()
    action = ActionModule(task, Variable())
    action.run()

# Generated at 2022-06-25 06:39:05.903426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Method run with arguments
    int_0 = -982
    list_0 = [int_0, int_0]
    int_1 = 1318
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -18.7243
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    action_module_0.run(list_0, list_0)
    # AssertionError: Traceback (most recent call last):
      # File "/home/vagrant/ansible/test/lib/ansible/plugins/action/debug.py

# Generated at 2022-06-25 06:39:08.542635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    assert class_type_0 == bool


# Generated at 2022-06-25 06:39:19.416297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {2, 3}
    var_0 = None
    var_1 = None
    tuple_0 = (var_0, set_0, var_1)
    var_2 = 0
    str_0 = 'Hello world!'
    var_3 = None
    var_4 = None
    tuple_1 = (var_2, var_3, var_4)
    var_5 = 2
    var_6 = None
    var_7 = None
    tuple_2 = (var_5, var_6, var_7)
    var_8 = 5
    var_9 = None
    var_10 = None
    tuple_3 = (var_8, var_9, var_10)
    var_11 = 4
    var_12 = None
    var_13 = None
    tuple_4

# Generated at 2022-06-25 06:39:22.839655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    tmp = object()
    task_vars = object()
    var_1 = var_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:39:33.738698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declarations
    int_0 = 974
    list_0 = [int_0, int_0]
    int_2 = 794
    int_3 = 727
    set_1 = {int_2, int_3}
    tuple_1 = ()
    float_0 = 66.4394
    tuple_0 = (set_1, tuple_1, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_0, list_0, tuple_0, list_0)
    int_6 = 1177
    dict_1 = dict(
        int_6=int_6,
        int_7=int_6
        )
    list_1 = ['var', int_6, dict_1]

# Generated at 2022-06-25 06:39:47.920839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg_0 = 'Hello world!'
    action_module_0 = ActionModule(msg_0)
    result_1 = action_module_0.run()
    assert result_1 == {'msg': 'Hello world!'}


# Generated at 2022-06-25 06:39:54.112289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    expected_results_0 = {"msg": 'Hello world!', '_ansible_verbose_always': True}
    var_0 = action_run()
    assert var_0 == expected_results_0

expected_results_1 = {'DICT': {'msg': 'Hello world!', '_ansible_verbose_always': True}, '_ansible_parsed': True, '_ansible_no_log': False}
var_1 = action_run()

var_2 = action_run()

var_3 = action_run()

# Generated at 2022-06-25 06:39:56.340145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 06:40:03.710281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 'action_run'
    var_1 = 'msg'
    var_2 = 'var'
    var_3 = 'verbosity'
    list_0 = [var_1, var_2, var_3]
    tuple_0 = ()
    tuple_1 = (list_0, tuple_0, tuple_0, list_0, tuple_0, list_0)
    action_module_0 = ActionModule(var_0, list_0, tuple_1, list_0, tuple_1, list_0)

# Unit test of class ActionModule

# Generated at 2022-06-25 06:40:05.619162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:40:14.049797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -982
    list_0 = [int_0, int_0]
    int_1 = 1318
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -18.7243
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)


# Generated at 2022-06-25 06:40:21.697454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = -982
  list_0 = [int_0, int_0]
  int_1 = 1318
  int_2 = -1823
  set_0 = {int_1, int_2}
  tuple_0 = ()
  float_0 = -18.7243
  tuple_1 = (set_0, tuple_0, float_0, list_0)
  action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
  var_0 = action_module_0.run()


# Generated at 2022-06-25 06:40:30.887313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 553
    list_0 = [int_0, int_0]
    int_1 = 553
    tuple_0 = ()
    list_1 = [int_1, tuple_0]
    list_2 = []
    list_3 = [list_2]
    tuple_1 = (list_3, list_3, list_2, list_3)
    list_4 = [list_2, tuple_1, list_1]
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_4, tuple_1, list_4)


# Generated at 2022-06-25 06:40:37.174814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -0.7138
    list_0 = [int_0, int_0]
    int_1 = -6357
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -4.4451
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:40:45.404837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -18
    float_0 = -13.991
    list_0 = [float_0, float_0]
    float_0 = -18.7243
    list_0 = [float_0, float_0, float_0]
    float_0 = -13.991
    list_0 = [float_0, float_0]
    action_module_0 = ActionModule(int_0, list_0, list_0, list_0, list_0, list_0)
    var_0 = action_run()
    var_1 = action_run()


# Generated at 2022-06-25 06:41:12.350872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:41:13.459612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:41:16.362151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = SomeType()
    task_vars = SomeType()
    action_module_0 = ActionModule(tmp, task_vars)
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 06:41:19.205928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0, task_vars_0 = None, None
    action_module_0 = ActionModule(None, None)
    var_0 = action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:41:24.223196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = TypeError
    str_0 = "''msg' and 'var' are incompatible options"
    dict_1 = {}
    dict_2 = {}
    dict_2['msg'] = str_0
    dict_1['failed'] = True
    dict_1['msg'] = str_0
    assert action_module_0.run() == dict_1
    dict_2['failed'] = False
    dict_2['msg'] = 'Hello world!'
    assert action_module_0.run(dict_2) == dict_2
    pass

# Generated at 2022-06-25 06:41:31.473060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -982
    list_0 = [int_0, int_0]
    int_1 = 1318
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -18.7243
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)

    return

# Generated at 2022-06-25 06:41:38.991095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -144
    list_0 = [int_0, int_0]
    int_1 = -957
    int_2 = -1908
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -6.3057
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)


# Generated at 2022-06-25 06:41:40.271186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # void test_case_0()
    test_case_0()


# Generated at 2022-06-25 06:41:48.418901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -982
    list_0 = [int_0, int_0]
    int_1 = 1318
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -18.7243
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    var_0 = action_module_0.run()
    action_module_0.run()
    int_3 = -822
    list_1 = [int_0, int_3]

# Generated at 2022-06-25 06:41:51.195120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run:")
    var_0 = ActionModule(None)
    var_0.run()


# Generated at 2022-06-25 06:42:47.860554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 862
    list_0 = [int_0, int_0]
    int_1 = 1676
    int_2 = -868
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -5.5
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    var_0 = action_module_0.run()
    assert isinstance(var_0, dict)

test_ActionModule_run()

# Generated at 2022-06-25 06:42:52.411767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create test environment
    int_0 = -982
    list_0 = [int_0, int_0]
    int_1 = 1318
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -18.7243
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    # AssertionError


# Generated at 2022-06-25 06:42:52.988197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 06:43:00.323064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -982
    list_0 = [int_0, int_0]
    int_1 = 1318
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -18.7243
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    var_0 = action_module_0.run()
    return var_0

# Generated at 2022-06-25 06:43:07.543968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -333
    list_0 = [-333, -333]
    int_1 = -506
    int_2 = -353
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -26.8432
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    # Constructor Call
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    # test for run() method of class ActionModule
    var_0 = action_module_0.run()
    # test for _run() method of class ActionModule
    var_1 = action_module_0._run()
    # test for _get_remote_user() method of

# Generated at 2022-06-25 06:43:09.997067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    var_0 = action_module_0.run(bool_0, float_0)
    assert var_0 == var_0

# Generated at 2022-06-25 06:43:18.479849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = -1823
    var_1 = [var_0, var_0]
    var_2 = {}
    var_3 = ()
    var_4 = [-18.7243]
    var_5 = (var_2, var_3, var_4, var_1)
    action_module_0 = ActionModule(var_0, var_1, var_5, var_1, var_5, var_1)
    var_6 = 'var'
    var_7 = 'msg'
    var_8 = {var_6: var_6, var_7: var_6}
    action_module_0._task.args = var_8
    var_9 = action_module_0.run()
    return var_9


# Generated at 2022-06-25 06:43:22.236048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_0 = AnsibleUndefinedVariable
    action_module_0 = ActionModule(ansible_0)
    result_0 = action_run()
    assert result_0



# Generated at 2022-06-25 06:43:23.095080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:43:24.361729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 06:45:22.347962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create object of class ActionModule
    action_module_0 = ActionModule()
    # Create object of class ActionModule
    action_module_1 = ActionModule()


# Generated at 2022-06-25 06:45:25.714549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    list_0 = []
    tuple_0 = ()
    dict_0 = {}
    dict_1 = {"var": dict_0}
    task_vars = dict_1
    action_module_0 = ActionModule(task_vars, tmp)

    test_case_0()


# Generated at 2022-06-25 06:45:32.818655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -982
    list_0 = [int_0, int_0]
    int_1 = 1318
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -18.7243
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:45:34.083492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = Data()
    var_0 = action_run()


# Generated at 2022-06-25 06:45:44.509851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError):
        action_module_0 = ActionModule(1, 3, 3, 2, 1, 2, 3)
        action_module_0 = ActionModule("", 2, 1, 2, 2, 2)
        action_module_0 = ActionModule("", "", 3, 3, 2, 1)
        action_module_0 = ActionModule("", 2, 3, 3, 3, 2)
        action_module_0 = ActionModule("", "", "", 1, 1, 2)
        action_module_0 = ActionModule("", "", 1, 1, 2, 3)
        action_module_0 = ActionModule("", 2, 3, 3, 1, 2)

if __name__ == '__main__':
    test_case_0()
    pytest.main()

# Generated at 2022-06-25 06:45:56.262948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -982
    list_0 = [int_0, int_0]
    int_1 = 1318
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -18.7243
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    assert action_module_0._task == int_1
    assert action_module_0._connection == list_0
    assert action_module_0._play_context == tuple_1
    assert action_module_0._loader == list_0
    assert action_module_0._tem

# Generated at 2022-06-25 06:45:57.808442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:46:04.322481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -982
    list_0 = [int_0, int_0]
    int_1 = 1318
    int_2 = -1823
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -18.7243
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    action_module_0.run()
    # TODO: Check return value

# Generated at 2022-06-25 06:46:08.582784
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Attributes
  assert ActionModule.TRANSFERS_FILES == False
  # 构造函数
  assert ActionModule(1, [], [], [], [], [])
  # test for return value
  # e.g. assert return value == 1
  # test for var

# Generated at 2022-06-25 06:46:15.933525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1006
    list_0 = [int_0, int_0]
    int_1 = -1821
    int_2 = -1260
    set_0 = {int_1, int_2}
    tuple_0 = ()
    float_0 = -19.722
    tuple_1 = (set_0, tuple_0, float_0, list_0)
    action_module_0 = ActionModule(int_0, list_0, tuple_1, list_0, tuple_1, list_0)
    list_1 = [int_0, int_0]
    int_3 = -1821
    int_4 = -1260
    set_1 = {int_3, int_4}
    tuple_2 = ()
    float_1 = -19.722
