

# Generated at 2022-06-25 06:36:53.104190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = '%1sK\x0c'
    bool_0 = False
    str_1 = '/O<D9'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_1)
    tmp_0 = None
    task_vars_0 = {}
    result = action_module_0.run(tmp_0, task_vars_0)
    assert result['msg'] == 'Hello world!'
    assert result['_ansible_verbose_always'] == True


# Generated at 2022-06-25 06:36:58.972440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    task_vars['verbosity'] = 0
    task_vars['msg'] = 'Hello world!'
    task_vars['var'] = 'foobar'
    task_vars['var_is_list'] = [1, 2, 3]
    task_vars['var_is_dict'] = {'one': 1, 'two': 2}
    task_vars['foobar'] = 'success!'
    test_case_0(task_vars)
    test_case_1(task_vars)



# Generated at 2022-06-25 06:37:02.353308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'n*oY'
    bool_0 = False
    str_1 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    dict_0 = {}
    result = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_1).run(dict_0)
    assert result['failed'] == False
    assert result['_ansible_verbose_always'] == True


# Generated at 2022-06-25 06:37:10.614799
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:37:19.126251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = '\tXZv'
    bool_0 = False
    str_1 = 'xO\x0bl#w'

    dict_0 = dict()
    dict_0['skipped'] = bool_0
    dict_1 = dict(skipped_reason="Verbosity threshold not met.", skipped=bool_0, _ansible_verbose_always=bool_0)

    dict_2 = dict()
    dict_3 = dict()
    dict_3['verbosity'] = 1
    dict_2['failed'] = bool_0
    dict_2['msg'] = 'Hello world!'
    dict_2['skipped_reason'] = "Verbosity threshold not met."
    dict_2['skipped'] = bool_0

    bool_1 = False
    dict_

# Generated at 2022-06-25 06:37:29.432123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_1 = set()
    str_3 = 'hw#\x17'
    bool_1 = True
    str_4 = 'XJY'
    action_module_1 = ActionModule(set_1, str_3, set_1, str_3, bool_1, str_4)
    tmp_0 = None
    task_vars_0 = dict()
    task_vars_0 = None
    task_vars_0 = {'c': 'Iq', 'e': 'iC', 'b': '1\tQ', 'h': 'sY', 'g': '7S', 'd': '\x04n\x16', 'i': 'G', 'f': '9'}
    tmp_0 = 'a'
    tmp_0 = 'b'
    tmp_0 = None


# Generated at 2022-06-25 06:37:35.168709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'xO\x0bl#w'
    bool_0 = False
    str_1 = '\tXZv'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_1)
    action_module_0.run(None, None)

# Generated at 2022-06-25 06:37:40.549030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = '7*u?K'
    bool_0 = False
    str_1 = '$D\x7f'
    dict_0 = dict()
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_1)
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:37:49.272411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_1 = '\tXZv'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_1)
    set_0 = set()
    str_1 = '\tXZv'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_1)
    set_0 = set()
    str_1 = '\tXZv'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_1)
    set_0 = set()
    str_1 = '\tXZv'

# Generated at 2022-06-25 06:37:55.380318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = ''
    set_1 = set()
    str_1 = ''
    bool_0 = False
    str_2 = ''
    action_module_0 = ActionModule(set_0, str_0, set_1, str_1, bool_0, str_2, set_0, set_0)
    action_module_0.run()

# Generated at 2022-06-25 06:38:12.587627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = bool()
    str_0 = 'x70'
    action_module_1 = ActionModule(None, str_0, None, str_0, bool_0, str_0)
    set_2 = set(['O'])
    task_vars_3 = dict()
    result = action_module_1.run(set_2, task_vars_3)
    assert result == {"failed": False, "msg": 'Hello world!', "_ansible_verbose_always": True}

# Generated at 2022-06-25 06:38:15.701615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing if verify_file is set to False by default
    assert ActionModule.verify_file == False
    # Testing if _uses_shell is set to True by default
    assert ActionModule._uses_shell == True
    # Testing if BYPASS_HOST_LO

# Generated at 2022-06-25 06:38:19.872874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule({}, 'foo', {}, 'foo', False, 'foo')
    assert module._supports_check_mode is True
    assert module._supports_async is False

# Generated at 2022-06-25 06:38:26.054619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = False
    str_0 = '\tXZv'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_0)
    tmp_0, task_vars_0 = None, None
    
    with pytest.raises(AnsibleUndefinedVariable): action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:38:29.067561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bool_0 = False
    str_0 = '\tXZv'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_0)


# Generated at 2022-06-25 06:38:32.831408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = False
    str_0 = '\tXZv'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_0)
    action_module_0.run()



# Generated at 2022-06-25 06:38:43.309701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 0
    str_0 = 'l=!1+XO57'
    set_0 = set()
    str_1 = '&\x1a\\'
    str_2 = '\x1a\\'
    str_3 = '\n0]6C\x00\x7f'
    str_4 = 'P#o'
    str_5 = '\x1a\\'
    str_6 = '@\x17\x7f"\x1fN'
    str_7 = '\x1a\\'
    str_8 = '\x1a\\'
    str_9 = '\tXZv'
    bool_0 = True
    str_10 = '\tXZv'

# Generated at 2022-06-25 06:38:48.873911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = set()
    arg_1 = str()
    arg_2 = set()
    arg_3 = str()
    arg_4 = bool
    arg_5 = str()
    action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:38:56.961581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bool_0 = False
    str_0 = '\tXZv'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_0)
    str_1 = ''
    dict_0 = {}
    dict_0['failed'] = True
    try:
        action_module_0.run(str_1, dict_0)
        assert False
    except SystemExit as exception_0:
        assert type(exception_0) == type(SystemExit())
        assert exception_0.code == 1
    else:
        assert False


# Generated at 2022-06-25 06:39:01.396311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bool_0 = False
    str_0 = 'JqT'
    action_module_0 = ActionModule(set_0, str_0, set_0, str_0, bool_0, str_0)


# Generated at 2022-06-25 06:39:22.803806
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:39:29.144148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bool_0, set_0, bool_1, bytes_0, int_0, bool_1)
    tmp_0 = None
    task_vars_0 = None
    var_1 = action_module_0.run(tmp_0, task_vars_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:39:37.301660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '5$zV7.\x1a'
    str_1 = '\x7f\x17x'
    tuple_0 = (str_0, str_1)
    bool_0 = False
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    bool_1 = True
    bytes_0 = b'0\x1a'
    int_0 = 8136
    action_module_0 = ActionModule(bool_0, set_0, bool_1, bytes_0, int_0, bool_1)
    action_module_0.run(tuple_0)


# Generated at 2022-06-25 06:39:48.641780
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:39:53.591747
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:40:04.528823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # AssertionError: Traceback (most recent call last):
    #   File "test_action_module.py", line 27, in test_ActionModule
    #     action_module_0 = ActionModule(bool_0, set_0, bool_1, bytes_0, int_0, bool_1)
    # NameError: name 'ActionModule' is not defined
    #
    #   File "test_action_module.py", line 27, in test_ActionModule
    #     action_module_0 = ActionModule(bool_0, set_0, bool_1, bytes_0, int_0, bool_1)
    # TypeError: __init__() takes at most 7 arguments (14 given)
    bool_0 = False
    set_0 = set()
    bool_1 = False
    bytes_0 = b''

# Generated at 2022-06-25 06:40:15.336772
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:40:19.957496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Starting test for constructor of class ActionModule")
    try:
        test_case_0()
        print("Test case 0 passed")
    except:
        print("Test case 0 failed")
    print("Finishing test for constructor of class ActionModule")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:40:30.963042
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:40:38.754373
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:41:11.930647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    i = 0
    while i < 100:
        # generate random inputs
        out_0 = random_int()
        out_1 = random_string()
        out_2 = random_bool()
        out_3 = random_long()
        out_4 = random_int()
        out_5 = random_bool()

        action_module_0 = ActionModule(out_0, out_1, out_2, out_3, out_4, out_5)
        action_module_0.run()
        i += 1


# Test case from yaml file

# Generated at 2022-06-25 06:41:20.747753
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:41:29.894720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\nS\x0b|A$P,/D/F\\Ut('
    str_1 = '\nf\x0c|r'
    tuple_0 = (str_0, str_1)
    bool_0 = True
    set_0 = {bool_0, bool_0, bool_0, bool_0}
    bool_1 = True
    bytes_0 = b'"'
    int_0 = 3249
    action_module_0 = ActionModule(bool_0, set_0, bool_1, bytes_0, int_0, bool_1)
    dict_0 = dict()
    var_0 = action_module_0.run(tmp=dict_0)

if __name__ == "__main__" :
    test_case_0()
    test_

# Generated at 2022-06-25 06:41:40.495121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Executing test_ActionModule_run ...')

# Generated at 2022-06-25 06:41:48.420106
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:41:51.497746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tuple_0 = (...)
  action_module_0 = ActionModule(...)
  var_0 = action_module_0.run(tuple_0)
  pass

# Generated at 2022-06-25 06:42:03.037399
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:42:14.604156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# class TestActionModuleMethods(unittest.TestCase):
#     def test_case_0(self):
#         str_0 = '\n    name: sequence\n    author: Jayson Vantuyl (!UNKNOWN) <jayson@aggressive.ly>\n    version_added: "1.0"\n    short_description: generate a list based on a number sequence\n    description:\n      - generates a sequence of items. You can specify a start value, an end value, an optional "stride" value that specifies the number of steps\n        to increment the sequence, and an optional printf-style format string.\n      - \'Arguments can be specified as key=value pair strings or as a shortcut form of the arguments string is also accepted: [start-]end[/stride][:format].\'\n     

# Generated at 2022-06-25 06:42:22.728640
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:42:28.028736
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:43:37.868430
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:43:42.242464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.task_vars = {}
    var_0 = action_module_0.run()
    if var_0['msg'] != 'Hello world!':
        raise ValueError('Value of var_0["msg"] != "Hello world!", var_0["msg"] = ' + var_0['msg'])


# Generated at 2022-06-25 06:43:53.264319
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:44:02.939897
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (3249, {True, True, True, True, True}, 'ansible/plugins/action/debug.py', b'\x13\x1f\x03\x0f', False, 'ansible/config/module_utils/urls.py', 'ansible/lib/ansible/runner/action_plugins', 1433, 'ansible/plugins/action/__init__.py', 'ansible/plugins/action/debug.py', b'\x0f\x07\r\r', 'ansible/plugins/action/debug.py', {True}, b'\x0f\x10\t\r')
    var_0 = ActionModule._run(tuple_0)


# Generated at 2022-06-25 06:44:08.263189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tmp = None
  task_vars = None
  msg = 'Hello world!'
  var = 'var'
  verbosity = 0
  ansible_verbose_always = True
  context = dict([('msg', msg), ('var', var), ('verbosity', verbosity), ('_ansible_verbose_always', ansible_verbose_always)])
  state = True
  assert state == ansible_verbose_always

# Generated at 2022-06-25 06:44:14.076464
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:44:19.355052
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:44:27.725389
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:44:34.226260
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:44:38.513220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bool_0, set_0, bool_1, bytes_0, int_0, bool_1)
    var_0 = action_run(tuple_0)

