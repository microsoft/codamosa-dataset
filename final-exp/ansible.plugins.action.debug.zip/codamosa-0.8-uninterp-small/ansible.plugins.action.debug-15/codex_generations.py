

# Generated at 2022-06-25 06:36:51.863773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    set_0 = set()
    tuple_0 = (set_0,)
    int_0 = -204
    float_0 = -2396.2251
    action_module_0 = ActionModule(dict_0, tuple_0, int_0, int_0, tuple_0, float_0)
    # assert action_module_0._task.args == {}
    # assert action_module_0.tasks == set_0
    # assert action_module_0.tasks_all
    # assert action_module_0.many_hosts
    # assert action_module_0.play_context == tuple_0
    assert action_module_0.delegate_to == int_0
    # assert action_module_0.variable_manager == tuple_0
    # assert action_module_0

# Generated at 2022-06-25 06:37:00.949176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = None
    set_0 = set()
    tuple_0 = (set_0,)
    int_0 = -204
    float_0 = -2396.2251
    action_module_0 = ActionModule(dict_0, tuple_0, int_0, int_0, tuple_0, float_0)
    int_1 = 68
    dict_0 = {
                'reduce_ciphers': 'False', 
                'validate_certs': 'True'
    }
    int_2 = 2
    action_module_0.run(dict_0, int_1, int_2)

# Generated at 2022-06-25 06:37:05.744578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_0['msg'] = 'Hello world!'
    dict_1 = {}
    dict_1['verbosity'] = 0
    dict_0['_ansible_verbose_always'] = True
    dict_0['failed'] = False
    dict_1['msg'] = dict_0
    dict_1['changed'] = False
    assert dict_1 == ActionModule.run(dict_0)


# Generated at 2022-06-25 06:37:11.279298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    set_0 = set()
    tuple_0 = (set_0,)
    int_0 = -204
    float_0 = -2396.2251
    action_module_0 = ActionModule(dict_0, tuple_0, int_0, int_0, tuple_0, float_0)
    # use str to convert result to str type instead of unicode type
    assert str(action_module_0) == str("ActionModule")

# unit test for run() of class ActionModule

# Generated at 2022-06-25 06:37:17.427708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    set_0 = set()
    tuple_0 = (set_0,)
    int_0 = -204
    float_0 = -2396.2251
    action_module_0 = ActionModule(dict_0, tuple_0, int_0, int_0, tuple_0, float_0)

# Generated at 2022-06-25 06:37:28.417016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    set_0 = set()
    tuple_0 = (set_0,)
    int_0 = -204
    float_0 = -2396.2251
    action_module_0 = ActionModule(dict_0, tuple_0, int_0, int_0, tuple_0, float_0)
    action_module_0.run()

    # Test assumption: type(test_case_0) == ActionModule
    assert True

    # Test assumption: tmp == None
    assert True

    # Test assumption: task_vars == None
    assert True

    # Test assumption: action_module_0.TRANSFERS_FILES == False
    assert True

    # Test assumption: action_module_0._VALID_ARGS == frozenset({'msg', 'var', 'verbosity'})


# Generated at 2022-06-25 06:37:39.206023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = None
    set_0 = set()
    tuple_0 = (set_0,)
    int_0 = -204
    float_0 = -2396.2251
    action_module_0 = ActionModule(dict_0, tuple_0, int_0, int_0, tuple_0, float_0)
    task_vars = {}
    task_vars.update({"foo": "-204", "bar": "-2396.2251"})
    task_vars.update({"baz": "-204", "foobar": "-2396.2251"})
    task_vars.update({"bazz": "-204", "foobarbazz": "-2396.2251"})
    result = action_module_0.run(dict_0, task_vars)

# Generated at 2022-06-25 06:37:48.409029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    set_0 = set()
    tuple_0 = (int(),)
    int_0 = -254
    tuple_1 = (set_0,)
    str_0 = str()
    float_0 = -12.4
    dict_1 = dict()
    dict_1["sudo"] = str_0
    dict_1["free_form"] = str_0
    dict_1["no_log"] = bool()
    dict_1["description"] = str_0
    dict_1["sudo_user"] = str_0
    dict_1["name"] = dict_1
    dict_1["delegate_to"] = str_0
    dict_1["remote_user"] = str_0
    dict_1["register"] = str_0

# Generated at 2022-06-25 06:38:00.342512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = None
    set_0 = set()
    tuple_0 = (set_0,)
    int_0 = -204
    float_0 = -2396.2251
    action_module_0 = ActionModule(dict_0, tuple_0, int_0, int_0, tuple_0, float_0)

    # Call method run of class ActionModule with arguments:
    # dict_0, dict_0
    # keyword argument: tmp
    # Return value: result
    # Temporary variable: result
    # Return type: dict
    result = action_module_0.run(dict_0, dict_0)

    # Check if result is:
    # (1) dict
    # (2) <class 'dict'>

    # Check if result contains key:
    # (1) failed
    # (2)

# Generated at 2022-06-25 06:38:09.756299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = None
    tuple_0 = (float(),)
    task_vars_0 = None
    int_0 = -10334.922
    action_module_0 = ActionModule(dict_0, tuple_0, int_0, int_0, tuple_0, int_0)
    result_0 = action_module_0.run(None, task_vars_0)
    print(result_0)
    assert isinstance(result_0, dict) == True

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:38:16.703545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = ({}, {})
    obj_0 = ActionModule()
    result_0 = obj_0.run()
    assert result_0 == ({}, {})

# Generated at 2022-06-25 06:38:20.972889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Constructor test\n")
    var_0 = {}
    var_1 = {}
    #case_0 = ActionModule(var_0,var_1)
    #test_case_0()
    pass

# Generated at 2022-06-25 06:38:22.893778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = ActionModule(var_0, var_1)

    exit()


# Generated at 2022-06-25 06:38:25.715082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    # Test for exception raise
    try:
        raise NotImplemented
    except NotImplemented:
        action_module.run()

# Generated at 2022-06-25 06:38:33.108409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mock data and params
    tmp_0 = None
    task_vars_0 = {}
    test_case_0_0 = {}
    test_case_0_1 = {}
    test_case_0_2 = {}
    test_case_0_3 = {}
    test_case_0_4 = {}
    test_case_0_5 = {}
    test_case_0_6 = {}
    test_case_0_7 = {}
    test_case_0_8 = {}

# Generated at 2022-06-25 06:38:38.694293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = {}

    var_1 = {}
    var_0 = {}

    var_0 = {}
    var_1 = {}

    ret = var_0.run(var_1)

    return ret

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:38:39.668247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:38:45.892000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = AnsibleModule(argument_spec={'var': {'required': False, ' type': 'str'}, 'verbosity': {'required': False, 'default': '0', ' type': 'int'}, 'msg': {'required': False, ' type': 'str'}}, supports_check_mode=False)
    var_2 = {}
    var_2['msg'] = 'hello world'
    var_2['verbosity'] = 2
    assert module_0.run(task_vars=var_2) == {'failed': False, 'msg': 'Hello world'}


# Generated at 2022-06-25 06:38:55.262500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = {}
    options = {}
    var_1 = u'Hello world!'
    options = {u'msg': var_1}
    var_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    var_0.run(tmp=None, task_vars=None)
    try:
        var_0.run(tmp=None, task_vars=options)
    except TypeError:
        pass
    try:
        var_0.run(tmp=None, task_vars=var_0)
    except TypeError:
        pass

# Generated at 2022-06-25 06:39:01.309933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    action_module._task.action = 'debug'
    action_module._task.args = {'msg': 'DEBUG_TEST_MESSAGE', 'var': 'MY_VAR'}
    action_module._task.set_loader(action_module._loader)
    action_module._task.set_default_vars(var_0)
    action_module._task.set_calculated_vars(var_1)


# Generated at 2022-06-25 06:39:14.087690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new instance of ActionModule class
    obj = ActionModule()
    # Test if obj is instance of ActionModule
    assert isinstance(obj, ActionModule), "obj should be an instance of class ActionModule"
    # Test if obj is instance of ActionBase
    assert isinstance(obj, ActionBase), "obj should be an instance of class ActionBase"
    # Test if obj is instance of object
    assert isinstance(obj, object), "obj should be an instance of class object"

# Generated at 2022-06-25 06:39:15.121944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO:
    assert True



# Generated at 2022-06-25 06:39:19.919802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    assert action._VALID_ARGS() == frozenset(('msg', 'var', 'verbosity'))
    assert action._shared_loader_obj == shared_loader_obj
    assert action._loader == loader
    assert action._templar == templar


# Generated at 2022-06-25 06:39:21.379122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule('exit')
    return var_0


# Generated at 2022-06-25 06:39:26.964696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule('test_case_0', '/Users/shubham/Downloads/ansible-2.5.5/lib/ansible/modules/system/debug.py', 'task_vars')
    print(var_0.run())

# test code for ActionModule class
if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 06:39:29.699040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  print("START: test_ActionModule_run")
  var_0 = exit()
  print("END: test_ActionModule_run")


# Generated at 2022-06-25 06:39:30.214055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 06:39:31.465558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = exit()



# Generated at 2022-06-25 06:39:33.596191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_0.run(tmp=None, task_vars={})


# Generated at 2022-06-25 06:39:35.290329
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:39:51.839108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:40:02.987114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 4343
    str_0 = "_\x05\x0e\x13\x03\x1b\x1c\x10\x1b\x1d\x0c\x12\x1f\x03\x00\x12\x0f\x04\x1b\x1f\x00\x1f\x03\x13\x03\x1c\x0f\x15\x11\x03\x13\x03\x1a\x1b\x1d\x1e"
    tuple_0 = ()
    list_0 = [int_0, tuple_0, str_0, int_0]
    int_1 = 4343
    float_0 = -2230.718
    tuple_1 = ()

# Generated at 2022-06-25 06:40:08.347869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "foobar"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'foobar'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    
    # run() initialization
    tmp = None
    task_vars = dict()
    # get task verbosity
    verbosity = int(action_module_0._task.args.get('verbosity', 0))


# Generated at 2022-06-25 06:40:09.645032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assert that placeholder
    assert True

# Generated at 2022-06-25 06:40:18.220982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)

# Generated at 2022-06-25 06:40:28.692442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_module_0.run(None, None)
    assert var

# Generated at 2022-06-25 06:40:36.872951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = 'FMfiA]qKr<%\tK\ta\\S'
    var_2 = ()
    var_3 = [var_2, var_2, var_1, var_0]
    var_4 = True

# Generated at 2022-06-25 06:40:47.141734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)

# Generated at 2022-06-25 06:40:48.784439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == None

# Generated at 2022-06-25 06:40:52.450463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    assert isinstance(action_module_0, ActionModule), "Error: constructor of class ActionModule"
    assert isinstance(action_module_0, object), "Error: constructor of class ActionModule"


# Generated at 2022-06-25 06:41:16.107531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Declaring objects for class ActionModule
    action_module_0 = None
    action_module_1 = None
    # Calling the constructor for class ActionModule
    action_module_1 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    action_module_1 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    # Calling method run()
    action_module_run()
    action_module_run()
    # Calling method load_module_args()
    action_module_load_module_args()
    # Calling method load_params()
   

# Generated at 2022-06-25 06:41:23.900432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "<m\x1d\\m\x0b\x01\x18\x1eVx'\\"
    tuple_0 = ()
    list_0 = [str_0, str_0, str_0, tuple_0]
    bool_0 = True
    str_1 = 'S1'
    list_1 = [str_1, str_0, bool_0, int_0]
    set_0 = {str_1, tuple_0, tuple_0}
    float_0 = -24.901
    action_module_0 = ActionModule(tuple_0, float_0, float_0, float_0, list_0, str_1)
    var_0 = action_run()

# Generated at 2022-06-25 06:41:33.707563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    int_1 = 9602

# Generated at 2022-06-25 06:41:43.458509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "D\x1c2jV\t\\o"
    tuple_0 = ()
    list_0 = [int_0, int_0, int_0]
    bool_0 = False
    str_1 = 'x[x1nX3\x0bP:\\'
    list_1 = [tuple_0, int_0, tuple_0]
    set_0 = {tuple_0, tuple_0}
    float_0 = -145.56
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    assert action_module_0._task.action == str_0
    assert action_module_0._task.args['msg'] == str_1
   

# Generated at 2022-06-25 06:41:49.831576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    str_0 = 'r&Gd#/9h*'
    tuple_0 = ()
    list_0 = [str_0, int_0]
    str_1 = 's9sQ_y'
    float_0 = 0.011765
    set_0 = {0}
    action_module_0 = ActionModule(tuple_0, list_0, float_0, set_0, str_0, int_0)
    # The constructor ActionModule of class ActionModule should have 4 args: 
    # self,play,new_play,loader 
    str_2 = 'k\x07\x1d+O\x1d\x0bZ'

# Generated at 2022-06-25 06:41:53.007266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    float_0 = float(str_0)
    str_0 = action_module_0.run(tuple_0)
    str_1 = str(str_0)
    str_0 = str_0.decode()

# Generated at 2022-06-25 06:42:03.725023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_run()
    action_module_1

# Generated at 2022-06-25 06:42:14.895284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -459
    tuple_0 = ()
    list_0 = [tuple_0]
    set_0 = {tuple_0}
    float_0 = -3298.906
    str_0 = 'gf\nVWeeB\x0b#MZ~'
    str_1 = "r'r9b\r=,d\x7f1cH"
    int_1 = 3820
    dict_0 = {'P9': str_1, '\x7f': set_0, 'Q': str_0, 'R;': set_0, 'D': list_0, 'U]': int_1, 'U@': list_0, 'Y': tuple_0}
    list_1 = [float_0, dict_0]
    bool_0 = False

# Generated at 2022-06-25 06:42:15.781281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 06:42:23.561917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    set_0 = {int_0, str_1}
    # action_module_0 = ActionModule(str_0, str_1, var_0, set_0, var_1, str_0)
    # test match
    action_module_0 = ActionModule(str_0, str_1, set_0)
    # test match
    action_module_1 = ActionModule(str_0, str_0, set_0)
    # test match
    action_module_2 = ActionModule(str_1, str_0, set_0)
    # test match


# Generated at 2022-06-25 06:42:56.571986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule("[(Kv;$D#W\x0cK\t", "^Y", [], set(), -255.7, 't')
    var_1 = action_run()
    assert var_1 == {"failed": False, "msg": "VARIABLE IS NOT DEFINED!"}

if (__name__ == "__main__"):
    main()

# Generated at 2022-06-25 06:43:04.747158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    assert not hasattr(action_module_0, 'tmp')
    assert not hasattr

# Generated at 2022-06-25 06:43:11.331618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "nRV\x05gZb\t8HwY;\x0e\x05yW\x7fv\x1b"
    tuple_0 = ()
    list_0 = [0, 0, tuple_0, tuple_0, tuple_0, tuple_0]
    bool_0 = True
    set_0 = {tuple_0, bool_0}
    str_1 = 'A\rZ\\r\\\r\r\\r\ra'
    list_1 = [0, tuple_0, 0]
    float_0 = -284.84795784
    action_module_0 = ActionModule(str_0, str_0, list_1, set_0, float_0, str_1)
    var_0 = action_

# Generated at 2022-06-25 06:43:13.199859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:43:18.653635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    assert_equal(action_module_0.run(), 0)
    action_module_

# Generated at 2022-06-25 06:43:28.312617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "f&M*9c%f#O-r\r\t[i]H"
    str_1 = ")ex=\x0c\x0b>m l@S$"
    list_0 = [None, "", 0, "4?1]%2&=`\x0b2Nn<}", 0]
    set_0 = {None, "NY!B3,c&\x0c\x0b_\x0cK"}
    float_0 = -7342.517206075
    str_2 = "r:?N%fzoGnC2KDK1h"
    action_module_0 = ActionModule(str_0, str_1, list_0, set_0, float_0, str_2)

    # parameter 1 of constructor is

# Generated at 2022-06-25 06:43:33.884731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = '#'
    tuple_0 = ()
    list_0 = [str_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'RX9;pG\x0b`f5\tS\t'
    list_1 = [tuple_0, tuple_0, tuple_0]
    set_0 = {str_0, int_0}
    float_0 = -0.835
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:43:39.272502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:43:50.185365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:43:54.221330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)


# Generated at 2022-06-25 06:44:58.642777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_run(action_module_0)
    action_module_

# Generated at 2022-06-25 06:45:06.403786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -7243
    str_0 = 'Rf\n@=V.\x0b\x17f*\n'
    str_1 = '.g\x11*h\x05'
    float_0 = 2408.056
    list_0 = [bool_0]
    dict_0 = {"h": list_1}
    action_module_0 = ActionModule(int_0, str_0, str_1, str_0, float_0, dict_0)
    assert_equal(action_module_0._display.verbosity, int_0, 'ActionModule._display.verbosity is incorrect')
    assert_equal(action_module_0.v2_runner_facts.runner_type, str_0, 'ActionModule.v2_runner_facts.runner_type is incorrect')


# Generated at 2022-06-25 06:45:12.948670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718

    # Init of class ActionModule
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    # AssertionError: assert len(action_module

# Generated at 2022-06-25 06:45:19.441177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = ""
    tuple_0 = ()
    list_0 = []
    bool_0 = True
    str_1 = ""
    list_1 = []
    set_0 = set()
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_run()
    var_1 = action_run()


# Generated at 2022-06-25 06:45:27.695866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:45:36.313651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = 'A<i'
    list_0 = []
    set_0 = {}
    float_0 = 3.2
    str_1 = "^oV7"
    action_module_0 = ActionModule(str_0, str_1, list_0, set_0, float_0, str_0)
    var_0 = action_run()
    print("var_0")
    print(var_0)
    print("var_0[int_0]")
    print(var_0[int_0])
    print("var_0[str_0]")
    print(var_0[str_0])
    print("var_0[list_0]")
    print(var_0[list_0])

# Generated at 2022-06-25 06:45:45.829657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:45:56.054216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = 'GG\x1dv%s7Au8&HxI.\x19T'
    tuple_0 = ()
    list_0 = [int_0, int_0, tuple_0, tuple_0]
    bool_0 = True
    str_1 = 'M*o\x1fBJe[5ax1\x00L(d'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {str_0, tuple_0}
    float_0 = -471.9
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)


# Generated at 2022-06-25 06:45:58.602813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for class ActionModule
    # action_module_0 = ActionModule(self, task, connection, play_context, loader, templar, shared_loader_obj)
    pass


test_case_0()

# Generated at 2022-06-25 06:46:06.237115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = "&m#X(!?Gj [I')I>1k\x0bS"
    tuple_0 = ()
    list_0 = [tuple_0, tuple_0, str_0, int_0]
    bool_0 = True
    str_1 = 'FMfiA]qKr<%\tK\ta\\S'
    list_1 = [int_0, tuple_0, int_0]
    set_0 = {tuple_0, str_1}
    float_0 = -2230.718
    action_module_0 = ActionModule(str_0, str_1, list_1, set_0, float_0, str_0)