

# Generated at 2022-06-25 06:36:56.353445
# Unit test for constructor of class ActionModule
def test_ActionModule():

    int_0 = 9
    complex_0 = complex(0, 0)
    set_0 = {int_0, complex_0, int_0}
    set_1 = {int_0, complex_0, int_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(int_0, complex_0, set_0, set_1, bool_0, bool_1)


# Generated at 2022-06-25 06:37:04.671282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_2 = None
    str_6 = None
    int_17 = 1017
    complex_0 = None
    bool_3 = False
    int_13 = 1072
    str_5 = None
    str_1 = None
    str_2 = None
    bool_2 = True
    str_4 = None
    str_0 = None
    bool_1 = True
    str_3 = None
    int_18 = 833
    complex_1 = None
    int_16 = 1130
    int_1 = 1019
    int_12 = 1034
    int_11 = 1049
    int_10 = 1075
    int_9 = 1019
    int_8 = 1060
    int_7 = 1008
    int_6 = 1081
    int_5 = 1062
    int_4

# Generated at 2022-06-25 06:37:08.497230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 16
    complex_0 = None
    set_0 = {False, complex_0, int_0}
    bool_0 = False
    action_module_0 = ActionModule(int_0, complex_0, set_0, set_0, bool_0, bool_0)
    action_module_0.run(int_0)

# Generated at 2022-06-25 06:37:12.087783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 1
    complex_0 = None
    set_0 = {complex_0, complex_0, int_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(int_0, complex_0, set_0, set_0, bool_0, bool_1)


# Generated at 2022-06-25 06:37:16.204927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 34
    complex_0 = {}
    set_0 = set()
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(int_0, complex_0, set_0, set_0, bool_0, bool_1)
    tmp = -94
    task_vars = {}
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:37:17.842199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:25.025715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    set_0 = {complex_0, complex_0, complex_0}
    bool_0 = False
    bool_1 = None
    action_module_0 = ActionModule(complex_0, complex_0, set_0, set_0, bool_0, bool_1)
    action_module_0.run(complex_0, complex_0)


# Generated at 2022-06-25 06:37:37.076037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1
    complex_0 = None
    set_0 = {complex_0, complex_0, int_0}
    bool_0 = None
    bool_1 = False
    action_module_0 = ActionModule(int_0, complex_0, set_0, set_0, bool_0, bool_1)
    dict_0 = dict()
    dict_0.update({"msg": "Hello world!"})
    dict_0.update({"failed": False})
    dict_1 = dict()
    dict_1.update({"verbosity": 0})
    dict_1.update({"msg": "Hello world!"})
    dict_0 = action_module_0.run(dict_0, dict_0)
    assert (dict_0 == dict_1)

    # test if verbosity > 2

# Generated at 2022-06-25 06:37:42.188850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module_0
    int_0 = 18
    complex_0 = None
    set_0 = {complex_0, complex_0, int_0}
    bool_0 = None
    bool_1 = False
    action_module_0 = ActionModule(int_0, complex_0, set_0, set_0, bool_0, bool_1)
    test_case_0()



if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:43.627630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:37:51.281134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:38:03.342298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    dict_0 = dict()
    dict_0['msg'] = 'Hello?'
    dict_0['verbosity'] = '1'
    dict_1 = dict()
    # Execution of run(tmp=None, task_vars=dict())
    result_1 = action_module_0.run(tmp=None, task_vars=dict_0)
    if dict_1 == result_1:
        print("[+] " + "Unit test for run() of class ActionModule passed.")
    else:
        print("[-] " + "Unit test for run() of class ActionModule failed.")

# Generated at 2022-06-25 06:38:08.588265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {}
    tmp_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    result = action_module_0.run(tmp_0)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:38:16.786145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_case_0():
        bool_0 = False
        action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
        action_module_0.set_loader(bool_0)
        bool_1 = False
        ansible_1 = {}
        ansible_1['failed'] = False
        ansible_1['failed'] = True
        str_0 = 'msg'
        str_1 = 'var'
        ansible_1[str_0] = str_1
        ansible_1['msg'] = 'VARIABLE IS NOT DEFINED!'
        var_results = 'results'
        str_2 = 'verbosity'
        str_3 = 'Hello world!'
        str_4 = 'msg'
        str_

# Generated at 2022-06-25 06:38:27.680129
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule with default values
    bool_0 = False
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    # Create an instance of class ActionModule with parameters
    bool_0 = False
    bool_1 = True
    task_0 = Task(bool_0, bool_0, bool_0)
    playbook_0 = Playbook(bool_1, bool_1)
    string_0 = "ansible.plugins.action.debug"
    string_1 = "debug"
    string_2 = "0"
    string_3 = "0"
    string_4 = "0"

# Generated at 2022-06-25 06:38:34.080894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    action_module_0.transfer_files = False
    action_module_0.new_module_args = {'var': ''}

    bool_1 = bool_0
    action_module_0.run(bool_1, bool_0)

if __name__ == '__main__':
    test_case_0()
    #test_ActionModule_run()

# Generated at 2022-06-25 06:38:44.245672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = "AnsibleUndefinedVariable"
    string_1 = "VARIABLE IS NOT DEFINED!"
    dict_0 = dict()
    dict_1 = dict()
    dict_0['verbosity'] = 0
    dict_0['msg'] = "Hello world!"
    dict_1['verbosity'] = 1
    dict_1['var'] = "yo"
    module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    string_2 = "msg"
    string_3 = "Hello world!"
    string_4 = "var"
    string_5 = "VARIABLE IS NOT DEFINED!"
    string_6 = "<type 'list'>"
    string_7 = "skipped_reason"
    string_

# Generated at 2022-06-25 06:38:54.099899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {}
    task_vars_0['msg'] = "msg"
    task_vars_0['_ansible_verbose_always'] = True
    task_vars_0['var'] = "var"
    task_vars_0['_ansible_verbose_override'] = False
    task_vars_0['verbosity'] = "verbosity"
    task_vars_0['skipped_reason'] = "skipped_reason"
    task_vars_0['skipped'] = True
    task_vars_0['failed'] = True
    task_vars_0['msg'] = "Hello world!"
    task_vars_0['skipped_reason'] = "Verbosity threshold not met."
    task_vars_0['skipped'] = True


# Generated at 2022-06-25 06:38:57.949381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    assert action_module_0.run() == None, 'ActionModule run method failed'
# Uncomment this line for test coverage for this module
# test_ActionModule()

# Generated at 2022-06-25 06:39:04.272341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.tmp = None
    action_module_0.task_vars = None
    # Call method run of class ActionModule
    action_module_0.run(action_module_0.tmp, action_module_0.task_vars)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:39:14.371533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = {}
    var_1 = action_module_0.run(var_0)
    print(var_1)

# Generated at 2022-06-25 06:39:19.997631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars_0 = test_case_0()
    tmp_0 = None

    # Call method run of action_module_0
    result = action_module_0.run(tmp_0, task_vars_0)
    assert result == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}


# Generated at 2022-06-25 06:39:21.112551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule() != None)


# Generated at 2022-06-25 06:39:23.582249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    obj = ActionModule(tmp, task_vars)
    obj.run()


# Generated at 2022-06-25 06:39:26.672856
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_vars = {}
    tmp = ""
    _task = ""

    test_name = "test_case_0"
    _task = test_case_0();
    # constructor
    _action_module = ActionModule(_task, tmp, task_vars)

# Generated at 2022-06-25 06:39:36.679103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = {}
    # Testing basic functionalities of class
    # test = ActionModule
    var_1 = {}
    var_2 = {}
    var_2 = test.run(var_0)
    # test = ActionModule
    var_1['msg'] = 'Hello world!'
    var_2 = test.run(var_0)
    # test = ActionModule
    var_1['verbosity'] = '10'
    var_2 = test.run(var_0)
    # test = ActionModule
    var_1['verbosity'] = '0'
    var_3 = {}
    var_3['_ansible_verbose_always'] = 'True'
    var_2 = test.run(var_0)
    # test = ActionModule

# Generated at 2022-06-25 06:39:39.179681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Creating a ActionModule class object
    obj_ActionModule = ActionModule()
    # Calling run method of the ActionModule class
    obj_ActionModule.run(var_0)

# Generated at 2022-06-25 06:39:50.551975
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:39:55.872765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    var_1 = action.run(task_vars=var_0)
    var_1 = action.run(tmp=var_0, task_vars=var_0)
    var_1 = action.run(tmp=None, task_vars=var_0)
    var_1 = action.run(tmp=var_1)
    var_1 = action.run()
    var_1 = action.run(tmp=var_1)
    var_1 = action.run(tmp=var_1, task_vars=var_0)

# Generated at 2022-06-25 06:40:04.050067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module_0 is not None
    assert module_0.run(tmp=None, task_vars=None) == {"failed": False, "msg": "Hello world!", "_ansible_verbose_always": True}
    assert module_0.run(tmp=None, task_vars=None) == {"failed": False, "skipped": True, "skipped_reason": "Verbosity threshold not met.", "_ansible_verbose_always": True}


# Generated at 2022-06-25 06:40:15.409992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}

    var_1 = ActionModule(var_0)
    assert isinstance(var_1, ActionModule)


# Generated at 2022-06-25 06:40:16.818210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}


# Generated at 2022-06-25 06:40:17.856994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert var_0 == {}


# Generated at 2022-06-25 06:40:18.739094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:40:29.272105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {}
    task_vars_160 = {}
    tmp_161 = None
    action_module_162 = ActionModule()
    result = action_module_162.run(tmp=tmp_161, task_vars=task_vars_160)
    # assert with test_case_0
    msg_163 = 'msg'
    assert result[msg_163] == 'Hello world!'
    # assert with test_case_0
    _ansible_verbose_always_164 = '_ansible_verbose_always'
    assert result[_ansible_verbose_always_164] == True
    # assert with test_case_0
    failed_165 = 'failed'
    assert result[failed_165] == False

if __name__ == '__main__':
    import sys, os

# Generated at 2022-06-25 06:40:32.301522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # string: var: AttributeError: 'ActionModule' object has no attribute '_task'
    args_0 = {}
    result = ActionModule.run(**args_0)


# Generated at 2022-06-25 06:40:34.769259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    test_case_0()

    # Run method
    result = run(tmp, task_vars)

    # Check result
    assert 0 == result



# Generated at 2022-06-25 06:40:36.293774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test_ActionModule")

    a_ActionModule = ActionModule()


# Generated at 2022-06-25 06:40:37.578156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:40:47.711587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\nDEBUG: Running test_ActionModule')
    task_vars_0 = test_case_0()
    action_module_0 = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    action_module_0.run(task_vars=task_vars_0)
    return True

if __name__ == '__main__':
    print('\nDEBUG: Running ansible_debug module as standalone')
    print('DEBUG: Ansible Module Name: %s' % __name__)
    print('DEBUG: Ansible Module args: %s' % sys.argv)

    test_ActionModule()

# Generated at 2022-06-25 06:41:01.538279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    assert action_module_0 is not None



# Generated at 2022-06-25 06:41:02.695446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:41:11.887382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 20
    var_0 = None
    bool_0 = True
    int_1 = 20
    var_1 = None
    bool_1 = True
    # Construction of ActionModule
    var_2 = ActionModule(int_0, var_0, bool_0, bool_1, bool_1, bool_1)
    # Parameter setup for test
    str_0 = "var"
    str_1 = "msg"
    int_2 = 32
    str_2 = "verbosity"
    # Call action_run method of class ActionModule
    var_3 = var_2.run(str_0, str_1, int_2, str_2)


# Generated at 2022-06-25 06:41:13.803726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 06:41:17.378883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = action_run()


# Generated at 2022-06-25 06:41:21.081170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    tmp = None
    task_vars = dict()
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:41:27.525101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = action_module_0._task
    if (var_1 == None) :
        raise ValueError('Expected not None')
    var_2 = action_module_0._connection
    if (var_2 == None) :
        raise ValueError('Expected not None')
    var_3 = action_module_0._play_context
    if (var_3 == None) :
        raise ValueError('Expected not None')
    var_4 = action_module_0._loader
    if (var_4 == None) :
        raise ValueError('Expected not None')
   

# Generated at 2022-06-25 06:41:35.497549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Configuration data
    var_0 = None
    bool_0 = False
    bool_1 = False
    bool_2 = False
    int_0 = 16
    bool_3 = True
    bool_4 = True
    bool_5 = True
    # Instantiation of the class
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_1, bool_2, bool_3)
    # Verifying the type of the object
    assert isinstance(action_module_0, ActionModule)
    # Verifying the attribute '_terminal_debug_msg'
    assert action_module_0._terminal_debug_msg is bool_4
    # Verifying the attribute '_terminal_supports_colors'

# Generated at 2022-06-25 06:41:42.348060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = action_module_0.task
    var_2 = action_module_0.connection
    var_3 = action_module_0.play_context
    var_4 = action_module_0.loader
    var_5 = action_module_0.templar
    var_6 = action_module_0.shared_loader_obj


# Generated at 2022-06-25 06:41:46.091435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Should work with no parameters specified.
    # assert method returns correctly

    # Should work with no parameters specified.
    # assert method returns correctly

    # Should work with 'msg' parameter specified.
    # assert method returns correctly

    # Should work with 'var' parameter specified.
    # assert method returns correctly

    # Should work with 'verbosity' parameter specified.
    # assert method returns correctly
    pass

# Generated at 2022-06-25 06:42:10.003123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_6 = action_module_0.action_run()
    return var_6


# Generated at 2022-06-25 06:42:16.107820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    assert_equals(action_module_0._VALID_ARGS, frozenset(('msg', 'var', 'verbosity')))
    assert_equals(action_module_0.TRANSFERS_FILES, False)

# Generated at 2022-06-25 06:42:18.236528
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # int_0, var_0, bool_0, bool_0, bool_0, bool_0
  assert action_module_0 is not None


# Generated at 2022-06-25 06:42:20.381334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 16
    var_0 = None
    bool_0 = False
    assert action_module_0.run(int_0, var_0)


# Generated at 2022-06-25 06:42:26.880469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    int_0 = 8
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    int_0 = 0
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    int_0 = 18
    var_0 = None
    bool_0 = False

# Generated at 2022-06-25 06:42:31.668599
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = action_run()


# Generated at 2022-06-25 06:42:40.530635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = action_module_0.run()
    # var_2 is an instance of ansible.executor.task_result.TaskResult
    assert(var_2.__class__.__name__ == "TaskResult")
    assert(var_2.failed == False)
    assert(var_2.skipped_reason == "Verbosity threshold not met.")
    assert(var_2.skipped == True)
    assert(var_2.changed == False)
    assert(var_2.exception == None)
    assert(var_2.task_execute_retry == None)
    assert(var_2._ansible_ignore_errors == False)
    assert(var_2.item == None)
    assert(var_2._ansible_item_label == None)

# Generated at 2022-06-25 06:42:42.441039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 06:42:43.060939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 06:42:44.577229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Result: ' + action_run())


# Generated at 2022-06-25 06:43:29.022885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    var_0 = None
    bool_0 = None
    bool_1 = None
    bool_2 = None
    bool_3 = None
    assert_raises(Exception, ActionModule, int_0, var_0, bool_0, bool_1, bool_2, bool_3)
    return 'unit_test_success'


# Generated at 2022-06-25 06:43:31.679245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = action_module_0.run()

# Generated at 2022-06-25 06:43:39.342577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = 16
    var_2 = None
    var_3 = False
    var_4 = False
    var_5 = False
    var_6 = False
    action_module_0 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_6)
    var_7 = 16
    var_8 = None
    var_9 = False
    var_10 = False
    var_11 = False
    var_12 = False
    action_module_1 = ActionModule(var_7, var_8, var_9, var_10, var_11, var_12)
    var_13 = 16
    var_14 = None
    var_15 = False
    var_16 = False
    var_17 = False
    var_18 = False
    action_

# Generated at 2022-06-25 06:43:47.845983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = to_text("VARIABLE IS NOT DEFINED!: [u'test_var']")
    var_1 = {}
    var_1['test'] = var_0
    var_2 = True
    var_3 = True
    var_4 = True
    var_5 = True
    var_6 = 16
    var_7 = None
    var_8 = True
    action_module_0 = ActionModule(var_6, var_7, var_8, var_3, var_4, var_5)
    action_module_0.run(var_7, var_1)

# Generated at 2022-06-25 06:43:49.797300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = action_run()


# Generated at 2022-06-25 06:43:53.622449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = action_run()


# Generated at 2022-06-25 06:43:59.049868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_1 = 30
    var_2 = None
    bool_1 = False
    bool_2 = False
    bool_3 = False
    bool_4 = False
    action_module_1 = ActionModule(int_1, var_2, bool_1, bool_2, bool_3, bool_4)
    assert(isinstance(action_module_1, ActionModule))

# Generated at 2022-06-25 06:44:00.674362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 4 == 4

# vim: expandtab

# Generated at 2022-06-25 06:44:05.265756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    bool_1 = False
    var_1 = action_module_0.run(bool_1)
    

# Generated at 2022-06-25 06:44:08.942096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # This method is overriden in action_plugins._ActionBase in order to remove the tmp argument
    action_module_1 = action_module_0.run()
    assert action_module_1 == None
    # TODO: maybe it should be decorated with @abc.abstractmethod


# Generated at 2022-06-25 06:45:38.437884
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # For setup, test a class-level member variable
    action_module_0 = ActionModule()
    action_module_0.some_class_variable = 1
    assert action_module_0.some_class_variable == 1

    # For setup, test an instance-level member variable
    action_module_0 = ActionModule()
    action_module_0.some_instance_variable = 2
    assert action_module_0.some_instance_variable == 2

    # For setup, test an instance-level method
    action_module_0 = ActionModule()
    assert action_module_0.run() == None

    # Test with an actual method call
    action_module_0 = ActionModule()
    assert action_module_0.run() == None

    # Test with an actual method call
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:45:44.698681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = None
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = {"failed": False, "skipped": False, "skipped_reason": "Verbosity threshold not met."}
    assert var_1 == action_module_0.run(None, task_vars)



# Generated at 2022-06-25 06:45:52.616414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 0
    var_1 = None
    var_2 = False
    var_3 = False
    var_4 = False
    var_5 = False
    var_6 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_7 = {'msg': 'Hello world!'}
    var_6.set_task_args(var_7)
    var_6.run()

# Generated at 2022-06-25 06:46:01.781433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    assert action_module_0.run() == {'failed': False, '_ansible_verbose_always': True, 'msg': 'Hello world!'}
    # assert action_module_0.run() == {'failed': False, '_ansible_verbose_always': True, 'msg': 'Hello world!', '_ansible_no_log': False}
    # assert action_module_0.run() == {'failed': False, '_ansible_verbose_always': True, '_ansible_no_log': False}

# Generated at 2022-06-25 06:46:04.322515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    arg_0 = None
    arg_1 = None
    var_0 = action_module_run(arg_0, arg_1);
    return var_0


# Generated at 2022-06-25 06:46:09.015388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = action_module_0.run()
    assert not var_1


# Generated at 2022-06-25 06:46:12.256010
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:46:13.507472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert result['msg'] == 'Hello world!'
    assert result['failed'] == False


# Generated at 2022-06-25 06:46:16.031700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = action_run()


# Generated at 2022-06-25 06:46:19.442471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 16
    var_0 = None
    bool_0 = False
    action_module_0 = ActionModule(int_0, var_0, bool_0, bool_0, bool_0, bool_0)
    var_1 = action_module_0.run(var_0, var_0)

if __name__ == "__main__":
    test_ActionModule()