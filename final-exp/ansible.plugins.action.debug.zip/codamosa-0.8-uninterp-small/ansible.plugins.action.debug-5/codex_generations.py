

# Generated at 2022-06-25 06:36:53.936629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n    \\[\n        (?:\n            [a-z]:[a-z]|                # one-char alphabetic range\n            [0-9]+:[0-9]+               # ...or a numeric one\n        )\n        (?::[0-9]+)?                    # numeric :step (optional)\n    \\]\n'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = 975.388996
    dict_0 = {list_0: str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, dict_0, float_0, dict_0)


# Generated at 2022-06-25 06:37:02.369828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 883.6
    dict_0 = {'key1': 'value1', 'key2': 'value2'}
    list_0 = ['value1', 'value2']
    list_1 = ['value3', 'value4']
    list_2 = ['value5']
    action_module_0 = ActionModule('msg', dict_0, float_0, list_0, float_0, dict_0)
    action_module_0._task.args[list_0[1]] = dict_0[list_0[0]]
    action_module_0._task.args[list_1[1]] = dict_0[list_1[0]]
    action_module_0._task.args[list_2[0]] = dict_0[list_2[0]]
    action_module_0._

# Generated at 2022-06-25 06:37:05.263727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(str_0, list_0, float_0, dict_0, float_0, dict_0)
    results = action_module_0.run(tmp, task_vars)
    print(results)

test_case_0()

# Generated at 2022-06-25 06:37:13.167754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = ['K!1:*', 'Dg,nJ', '_+', 'X.', 'Y\'%Cg<', 'L{H', '^O+']
    str_0 = '=0B'
    float_0 = 975.388996
    dict_0 = {list_0: str_0}
    float_1 = 1.816
    dict_1 = {str_0: '4P8'}
    action_module_0 = ActionModule(str_0, list_0, float_0, dict_0, float_1, dict_1)
    list_1 = ['K!1:*', 'Dg,nJ', '_+', 'X.', 'Y\'%Cg<', 'L{H', '^O+']

# Generated at 2022-06-25 06:37:24.157640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'j'
  list_0 = ['\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00']
  float_0 = 1.98292792
  dict_0 = {}
  action_module_0 = ActionModule(str_0, list_0, float_0, dict_0, float_0, dict_0)
  tmp_0 = None
  task_vars_0 = None
  str_1 = '>|'
  list_1 = [str_1, str_1, str_1, str_1]
  action_module_0.set_options(list_1)

  # Call action_module_0.run
  # str

# Generated at 2022-06-25 06:37:36.689942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test defaults
    assert(ActionModule._VALID_ARGS == frozenset(('msg', 'var', 'verbosity')))
    
    # test doc string attributes
    assert(ActionModule.__doc__ is not None)
    assert(ActionModule.__init__.__doc__ is not None)
    assert(ActionModule.run.__doc__ is not None)
    
    # test type of arguments
    action_module_arg_types = (str, list, float, dict, float, dict)
    assert(type(ActionModule("msg", "var", "verbosity", "tmp", "task_vars", "play_context")) == ActionModule)

# Generated at 2022-06-25 06:37:37.661456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(test_case_0())


# Generated at 2022-06-25 06:37:46.388965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'n\xf4'
    list_0 = [str_0, str_0, str_0, str_0]
    list_1 = [str_0, str_0, str_0, str_0]
    float_0 = 706.8
    dict_0 = {list_0: str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, dict_0, float_0, dict_0)
    task_vars = {"undefined_var": str_0}
    result = action_module_0.run(None, task_vars)
    assert not result['failed']
    result = action_module_0.run(None, None)
    assert not result['failed']

# Generated at 2022-06-25 06:37:58.810407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '\n    \\[\n        (?:\n            [a-z]:[a-z]|                # one-char alphabetic range\n            [0-9]+:[0-9]+               # ...or a numeric one\n        )\n        (?::[0-9]+)?                    # numeric :step (optional)\n    \\]\n'
    list_1 = [str_1, str_1, str_1, str_1]
    float_1 = 975.388996
    dict_1 = {list_1: str_1}
    assert callable(ActionModule)
    action_module_1 = ActionModule(str_1, list_1, float_1, dict_1, float_1, dict_1)


# Generated at 2022-06-25 06:38:11.197902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n    \\[\n        (?:\n            [a-z]:[a-z]|                # one-char alphabetic range\n            [0-9]+:[0-9]+               # ...or a numeric one\n        )\n        (?::[0-9]+)?                    # numeric :step (optional)\n    \\]\n'
    list_0 = [str_0, str_0, str_0, str_0]
    float_0 = 975.388996
    dict_0 = {list_0: str_0}
    action_module_0 = ActionModule(str_0, list_0, float_0, dict_0, float_0, dict_0)
    assert len(action_module_0._VALID_ARGS) == 3
    assert action_module

# Generated at 2022-06-25 06:38:17.996929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = None


# Generated at 2022-06-25 06:38:28.398491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = str()
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    var_13 = {}
    var_14 = {}
    var_15 = {}
    var_16 = {}
    var_17 = {}
    var_18 = {}
    var_19 = {}
    var_20 = {}
    var_21 = {}
    var_22 = {}
    var_23 = {}
    var_24 = {}
    var_25 = {}
    var_26 = {}
    var_27 = {}
    var_28 = {}
    var_29 = {}
    var

# Generated at 2022-06-25 06:38:39.040307
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:38:40.485166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:38:47.089163
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:38:51.442919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Initialize mock objects
  var_0 = None
  var_1 = None
  test = ActionModule(var_0, var_1)
  arg_0 = ""
  arg_1 = ""
  var_2 = test.run(arg_0, arg_1)
  assert var_2 == None


# Generated at 2022-06-25 06:38:52.630542
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_case_0()


# Generated at 2022-06-25 06:39:00.329490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = { 'key': 'value' } # var_0 = { 'key': 'value' }
    var_1 = True # var_1 = True
    
    action_module_0 = ActionModule(None, None, task_vars=[var_0], play_context=[var_1])
    var_2 = action_module_0.run()
    #assert compare_result_and_answer(var_3, None), "ActionModule.run() must return None."

# Generated at 2022-06-25 06:39:03.853962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = {"msg": "Hello world!"}
    var_3 = {'verbosity': 2, 'var': 'test_var'}
    var_4 = {'verbosity': 1, 'var': 'test_var'}
    var_5 = 'Hello world!'
    var_6 = {'var': 'test_var', 'verbosity': 1}
    var_7 = None
    var_8 = None


# Generated at 2022-06-25 06:39:09.276258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test 0: default input

    # get modules args
    result = test_case_0()
    assert result['failed'] == True
    assert result['msg'] == "'msg' and 'var' are incompatible options"
    assert result['skipped'] == True
    assert result['skipped_reason'] == "Verbosity threshold not met."


# Generated at 2022-06-25 06:39:18.610405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()

    var_1 = {"tmp": None, "task_vars": None}

    var_2 = var_0.run(**var_1)

    var_3 = {}


# Generated at 2022-06-25 06:39:23.441011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule(connection = "local", dispatcher = "copy", noop_on_check = False, play_context = "PlayContext", runner_path = "runner_path", templar = "templar")
    assert var_1 is not None


# Generated at 2022-06-25 06:39:25.626566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:39:26.574960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()


# Generated at 2022-06-25 06:39:36.589910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 06:39:38.737771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    action_module_0 = ActionModule(var_1)

    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:39:39.712951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_ActionModule = ActionModule()

# Generated at 2022-06-25 06:39:43.642254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = var_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:39:47.430462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = 1
    var_1 = "string"
    msg = 0
    var = 1
    verbosity = 0
    var_2 = ActionModule(var_0, var_1, msg, var, verbosity)


# Generated at 2022-06-25 06:39:50.396197
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test 1
    # Test case with no parameters
    try:
        assert test_case_0() == None
    except AssertionError as ae:
        raise AssertionError(ae)

# Generated at 2022-06-25 06:39:57.833314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionBase), "Check if ActionModule is of type 'ActionBase'"

test_case_0()

# Generated at 2022-06-25 06:40:00.567411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = ActionModule(var_0)
    var_2 = None
    var_3 = var_1.run(var_2, None)


# Generated at 2022-06-25 06:40:07.378928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule("ActionModule_0", None, None, None)
    var_1 = {"var": "verbosity"}
    var_2 = var_0.run()
    assert not var_2.failed
    assert var_2._ansible_verbose_always
    assert not var_2.skipped
    var_3 = var_0.run(var_1)
    assert not var_3.failed
    assert not var_3._ansible_verbose_always
    assert not var_3.skipped
    var_4 = {"var": "var"}
    var_5 = var_0.run(var_4)
    assert not var_5.failed
    assert var_5._ansible_verbose_always
    assert not var_5.skipped

# Generated at 2022-06-25 06:40:08.843428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:40:17.806826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # SETUP
    MOCK_ARGS = {
        'msg': None,
        'var': None,
        'verbosity': None
    }

    MOCK_TASK_VARS = {}

    MOCK_MODULE_UTILS_PATH = "ansible.module_utils.common.run_command"

    MOCK_TASK_MODULE_UTILS_PATH = "ansible.module_utils.basic.AnsibleModule"

    MOCK_TASK_MODULE_UTILS_SPEC = {
        "argument_spec": {
            "msg": {},
            "var": {},
            "verbosity": {}
        },
        "supports_check_mode": True
    }


# Generated at 2022-06-25 06:40:19.011451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_0.run()

# Generated at 2022-06-25 06:40:28.825025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = [0, 1, 2]
    var_2 = None
    var_2 = u'abc'
    var_3 = ActionModule()
    var_4 = {'msg': 'Hello world!'}
    var_4 = {'var': var_2}
    var_4 = {u'var': var_1}
    var_5 = dict()
    var_5 = dict()
    var_5 = dict()
    var_5 = {u'verbosity': 0}
    var_5 = {'verbosity': 1}
    var_6 = var_3.run(var_0, var_5)


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:40:37.503705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yaml_code = '''
- hosts: localhost
  tasks:
    - debug:
        msg: ""
        var: ""
        verbosity: "2"
'''
    import ansible.playbook.play_context
    play_context = ansible.playbook.play_context.PlayContext()
    import ansible.executor.task_queue_manager
    task_queue_manager = ansible.executor.task_queue_manager.TaskQueueManager(play_context=play_context)
    test_case = ActionModule(task=var_0, play_context=play_context, new_stdin=None, loader=var_0, shared_loader_obj=var_0)
    assert test_case.run(tmp=None, task_vars=dict()) == {'failed': False}

# Generated at 2022-06-25 06:40:38.695412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:40:42.764898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    try:
        result = action_module.run(None, None)
        assert result == {}
    except AttributeError:
        raise AssertionError("Testcase failed because the example returned an attribute error")


# Generated at 2022-06-25 06:41:05.531401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_vars = dict()
    tmp_directory = '.'
    task_vars = dict()
    tasks_on_hosts = dict()

    # test_case_0
    ac = ActionModule(task=var_0, connection=var_0, play_context=var_0, loader=var_0, templar=var_0, shared_loader_obj=var_0)
    assert ac.TRANSFERS_FILES == False
    assert ac._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

    # test_case_1
    tmp = None
    task_vars = None

# Generated at 2022-06-25 06:41:06.960938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()


# Generated at 2022-06-25 06:41:16.353110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = "Hello world!"
    var_2 = "VARIABLE IS NOT DEFINED!"
    var_3 = "VARIABLE IS NOT DEFINED!"

    # First test case, with a valid msg argument
    from ansible.plugins.action.debug import ActionModule

    var_0 = ActionModule({ 'msg': "Hello world!" }, { }, "test_case_0")
    var_0.run()
    assert var_0.task_result == { 'msg': var_1, '_ansible_verbose_always': True, 'failed': False }

    # Second test case, with a valid var argument
    var_0 = ActionModule({ 'var': "Hello world!" }, { }, "test_case_0")
    var_0.run()

# Generated at 2022-06-25 06:41:23.770395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arg
    var_0 = None
    assert run() == {"failed": False, "skipped_reason": "Verbosity threshold not met.", "skipped": True}

    # Test with passing msg and verbosity
    var_0 = {}
    assert run(var_0) == {"failed": False, "_ansible_verbose_always": True, "msg": "Hello world!"}

    # Test with passing msg and verbosity
    var_0 = None
    assert run(var_0) == 'Hello world!'

    # Test with passing msg and verbosity
    var_0 = {}
    assert run(var_0) == 'Hello world!'

    # Test with passing msg and verbosity
    var_0 = None
    assert run(var_0) == 'Hello world!'

    # Test with passing msg and verbosity


# Generated at 2022-06-25 06:41:30.364016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test case will cover main function of run method
    # result returned should be a dict object that contain
    # 'failed', 'msg', 'skipped' and 'skipped_reason' keys
    # with bool and string value
    action_module = ActionModule()
    result = action_module.run(tmp=None, task_vars=None)
    assert (result['failed'] or result['skipped']) is False
    assert isinstance(result['msg'], string_types)

# Generated at 2022-06-25 06:41:33.737429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule(var_0)
    try:
        assert (var_0.run() == "Hello world!")
    except AssertionError as e:
        print(str(e))
    finally:
        print(str(var_0.run()))


# Generated at 2022-06-25 06:41:36.216875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    scheduler = None
    task = None
    conne

# Generated at 2022-06-25 06:41:37.125460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None


# Generated at 2022-06-25 06:41:38.950417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:41:41.411854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    action_module.run()

# Generated at 2022-06-25 06:42:10.285181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call constructor method of parent class
    test_case_0()
    # Call method run()
    test_ActionModule.run()


# Generated at 2022-06-25 06:42:15.609233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_0 = [u"VARIABLE IS NOT DEFINED!"]
    var_0 = dict(var=u"VARIABLE IS NOT DEFINED!")
    # Template<({var})>
    test_var = (u"VARIABLE IS NOT DEFINED!")
    var_0 = {u"var": test_var}



# Generated at 2022-06-25 06:42:17.726179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case 0: test default case.
    # Expected execption: AnsibleUndefinedVariable, 'msg' and 'var' are incompatible options
    var_0 = None

# Generated at 2022-06-25 06:42:19.844029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test: instantiate class ActionModule ...")
    var_0 = ActionModule()
    print(var_0)
    print("End of test.")


# Generated at 2022-06-25 06:42:21.867383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None

    var_0 = ActionModule(var_0)
    var_1 = None

    var_0.run(tmp=var_1)



# Generated at 2022-06-25 06:42:22.627958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:42:23.813954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert isinstance(test_case_0(), dict)

# vim: filetype=python

# Generated at 2022-06-25 06:42:25.044275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("##### Testing class: constructor")
    action = ActionModule(None, dict())
    assert isinstance(action, ActionModule)


# Generated at 2022-06-25 06:42:29.349391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    try:
        var_1 = None
        var_2 = None
        var_0.run(var_1, var_2)
    except Exception as e:
        assert False, str(e)


# Generated at 2022-06-25 06:42:32.105245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for var_0 in [0]:
        action_module_0 = ActionModule()
        action_module_0.run(var_0)

# Generated at 2022-06-25 06:43:49.116821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    var_0 = None
    var_1 = None
    task_vars = dict()
    tmp = None
    task_vars_1 = dict()

    # Declaration
    action_module_1 = ActionModule(task=var_0, connection=var_0, play_context=var_0, loader=var_0, templar=var_0, shared_loader_obj=var_0)
    action_module_1.run(tmp=tmp, task_vars=task_vars_1)


# Generated at 2022-06-25 06:43:53.929112
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module_args = dict()
    module_args['msg'] = ''
    module_args['var'] = dict(3)

    # module_args['verbosity'] = ''

    tmp = None
    task_vars = dict()

    # test_case_0
    var_0 = test_case_0()

    obj = ActionModule(var_0)
    # obj.run()

# Generated at 2022-06-25 06:44:04.935078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp_1 = None
    temp_2 = None
    temp_3 = None
    temp_4 = None
    temp_5 = None
    temp_6 = None
    temp_7 = None
    temp_8 = None
    temp_9 = None
    temp_10 = None
    temp_11 = None
    temp_12 = None
    temp_13 = None
    temp_14 = None
    temp_15 = None
    temp_16 = None
    temp_17 = None
    temp_18 = None
    temp_19 = None
    temp_20 = None
    temp_21 = None
    temp_22 = None
    temp_23 = None
    temp_24 = None

    # Constructor test case
    temp_1 = ActionModule()

# Generated at 2022-06-25 06:44:08.071463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = ActionModule()

    var_0 = u'foo'
    task_vars_0 = {u'da_test': var_0}

    # Test function run with 1 arguments
    module_0.run(task_vars=task_vars_0)

# Generated at 2022-06-25 06:44:08.937357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 06:44:17.321760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = "hello world"
    var_1 = 42
    var_2 = [var_0, var_1]
    var_3 = {var_0: var_1}
    var_4 = {"msg": var_0, "verbosity": 2}
    var_5 = {"var": var_0, "verbosity": 2}
    var_6 = {"var": var_2, "verbosity": 2}
    var_7 = {"var": var_3, "verbosity": 2}
    var_8 = {"verbosity": 2}
    var_9 = {"msg": var_0, "verbosity": 0}
    var_10 = {"msg": var_0}
    var_11 = {"var": var_3}
    var_12 = {"var": var_0}

    # Init action module


# Generated at 2022-06-25 06:44:24.558062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    actionmodule = ActionModule()
    import ansible.plugins.action
    actionmodule._display = ansible.plugins.action.ActionBase()
    import ansible.utils.template
    actionmodule._templar = ansible.utils.template.AnsibleTemplar()
    var_1 = None
    var_1 = dict()
    var_2 = None
    var_3 = None
    var_3 = dict()
    var_4 = None
    var_4 = int()
    var_4 = actionmodule.run(var_0, var_1)
    pass




# Generated at 2022-06-25 06:44:31.845216
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:44:36.243937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_1 = {
        'var_0': None,
    }
    task_1 = {
        'var': task_vars_1['var_0'],
    }

    # Test the type of 'result'
    result_1 = ActionModule(task_1, task_vars_1).run()
    assert type(result_1) == dict, "result_1 should be <type 'dict'>. 'result_1' is type %s" % type(result_1)
    var_1 = None


# Generated at 2022-06-25 06:44:45.258949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from mock import create_autospec, ANY

    var_0 = create_autospec(ActionModule)
    var_1 = dict()
    var_2 = create_autospec(ActionModule)
    var_2.transfers_files = False
    var_2._task.args = {'var': 'var_0'}
    var_3 = 'var_3'
    var_3 = create_autospec(ActionBase)
    var_3._task.args = {'var': 'var_0'}
    var_4 = create_autospec(ActionBase)
    var_4._task.args = {'var': 'var_0'}
    var_4._task.args = {'var': 'var_0'}