

# Generated at 2022-06-25 06:36:59.600955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1127.51
    set_0 = {float_0, float_0, float_0}
    int_0 = -57
    bytes_0 = b'P\xce\xc0\x14\x95\x9b\xde\x9c\xdb\xe4\xda\xe4\xda\xe4\xda\xe4'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)

    # Call method run of class ActionModule with args float_0, set_0 and float_0
    # and return value result_0
    (result_0, ) = action_module_0.run(return_value, set_0, float_0)

    # Assertions

# Generated at 2022-06-25 06:37:01.318097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)


# Generated at 2022-06-25 06:37:03.396615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")

# Run test for class ActionModule
test_ActionModule()

# Generated at 2022-06-25 06:37:10.421278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1318.22
    set_0 = {float_0, float_0, float_0}
    int_0 = -82
    bytes_0 = b'r\x9a\x1d\x80\xba\xb0\x88\x9f\x89\x82\x17\x1d\x80\x18\x8c\x84\x9a\x89\x88\x18\x9f\x1d\xba\xba'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    return


# Generated at 2022-06-25 06:37:15.627580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)

    test_case_0()
    test_ActionModule()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:37:26.770046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockCursor:
        def __init__(self, params):
            self.params = params

        def execute(self, sql, params):
            pass

        def commit(self):
            pass

    float_0 = 4.539755155049933e+307
    set_0 = {float_0}
    set_1 = {'y', 'pwqfqd', 'z', 'pwqfqd'}
    bytes_0 = b'\xc2'
    int_0 = -1754
    action_module_0 = ActionModule(set_1, float_0, float_0, float_0, float_0, int_0)
    str_0 = action_module_0.run(set_0, set_1)
    assert str_0 == "Hello world!"

# Generated at 2022-06-25 06:37:32.731069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)

# Generated at 2022-06-25 06:37:38.025942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 06:37:41.881279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare parameter valid types
    tmp_0 = None # <type 'NoneType'>
    task_vars_0 = None # <type 'NoneType'>

    result = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)


# Generated at 2022-06-25 06:37:47.511093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create some dummy objects
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)

    # Test method run
    action_module_0.run('tmp', {})

# Generated at 2022-06-25 06:37:57.112087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    params_0 = None
    action_module_0 = ActionModule(Task(), params_0)
    var_0 = action_module_0.run(var_0, var_1)
    return var_0


# Generated at 2022-06-25 06:37:58.142741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:37:59.501635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = ActionModule()


# Generated at 2022-06-25 06:38:00.529203
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_case_0()

# Generated at 2022-06-25 06:38:03.853288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    var_0 = ActionModule(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:38:09.808624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=var_0, connection=var_1, play_context=var_2, loader=var_3, templar=var_4, shared_loader_obj=var_5)
    var_6 = None
    var_7 = None
    assert action_module.run(tmp=var_6, task_vars=var_7) == var_8

# Generated at 2022-06-25 06:38:17.550823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_0 = dict()
    test_1 = dict()
    test_2 = dict()

    expected_0 = dict()
    expected_1 = dict()
    expected_2 = dict()

    # Replace the system state with test fixture
    return_0 = test_case_0()

    args_0 = dict()
    args_0['msg'] = None
    args_0['var'] = None

    args_1 = dict()
    args_1['msg'] = None
    args_1['var'] = None

    args_2 = dict()
    args_2['msg'] = None
    args_2['var'] = None

    test_0['args'] = args_0
    test_1['args'] = args_1
    test_2['args'] = args_2

    # Make the assertion

# Generated at 2022-06-25 06:38:22.266179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    f = task_vars_0
    t = task_vars_1
    action_module = ActionModule(f, t)

    type_0 = type(list())
    type_1 = type(list())
    action_module.run(type_0, type_1)

# Generated at 2022-06-25 06:38:23.996587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = var_0.run()
#     assert test_case_0() == var_1

# Generated at 2022-06-25 06:38:32.226699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None

# Generated at 2022-06-25 06:38:42.706951
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()

    assert action_module_0._task.action in ['debug']
    assert action_module_0._VALID_ARGS == frozenset({'msg', 'var', 'verbosity'})
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 06:38:46.070474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_1 = ActionModule()
        assert(True)
    except NameError:
        assert(False)


# Generated at 2022-06-25 06:38:55.476668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    task_vars_0 = {}
    tmp_0 = None

    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0 is not None
    assert result_0['msg'] == 'Hello world!'
    assert result_0['failed'] is False
    assert result_0.get('changed') is None
    assert result_0['invocation'] is not None

    task_vars_1 = {}
    tmp_1 = None

    result_1 = action_module_0.run(tmp_1, task_vars_1)
    assert result_1 is not None
    assert result_1['msg'] == 'Hello world!'
    assert result_1['failed'] is False
    assert result_1.get('changed')

# Generated at 2022-06-25 06:38:56.342605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 06:38:59.038058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    assert action_module_1.run() is not False

# Generated at 2022-06-25 06:39:03.870830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(action_module_0, '_VALID_ARGS')
    assert action_module_0._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert hasattr(action_module_0, 'TRANSFERS_FILES')
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 06:39:06.925114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('msg', 'var'))
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-25 06:39:08.009311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:39:19.061078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp = None
    task_vars = {'foo': 'foo', 'bar': 'bar'}
    action_module_1._task.args = {'var': 'foo'}
    action_module_1._display.verbosity = 0
    result = action_module_1.run(tmp, task_vars)
    assert 'foo' == result['foo']
    assert result['failed'] == 'False'
    action_module_1._task.args = {'var': 'foo', 'verbosity': 2}
    action_module_1._display.verbosity = 3
    result = action_module_1.run(tmp, task_vars)
    assert 'foo' == result['foo']
    assert result['failed'] == 'False'
    action_module_1._

# Generated at 2022-06-25 06:39:19.884526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test case 0
    test_case_0()

# Generated at 2022-06-25 06:39:29.591438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -822.73
    int_0 = -1
    bytes_0 = b'\xb9\xbc\x97m'
    tuple_0 = (float_0, int_0, bytes_0, int_0)
    action_module_0 = ActionModule(float_0, tuple_0, int_0, tuple_0, bytes_0, int_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:39:32.714666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -14
    list_0 = [36, -97, -91, -97, 36]
    set_0 = {int_0, int_0, int_0}
    float_0 = -1073.4
    action_module_0 = ActionModule(int_0, set_0, float_0, set_0, list_0, float_0)
    int_1 = -87
    float_1 = -1138.9
    bytes_0 = b'\xdc\xd1'
    int_2 = -95
    action_module_0.run(int_1, float_1, bytes_0, int_2)


# Generated at 2022-06-25 06:39:37.450236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('action_module_0', 1141.27, -93, {1141.27, 1141.27, 1141.27}, {1141.27, 1141.27, 1141.27}, b'\x9e\x9e', -93)
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()


# Generated at 2022-06-25 06:39:38.313795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-25 06:39:39.266037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 06:39:47.531323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # argument 1 of type ActionBase
    # argument 2 of type set[str]
    # argument 3 of type int
    # argument 4 of type set[str]
    # argument 5 of type bytes
    # argument 6 of type int
    set_0 = {1, 2, 3}
    int_0 = 20
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(set_0, int_0, set_0, bytes_0, int_0)


# Generated at 2022-06-25 06:39:48.733747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:39:54.541947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    result = action_module_0.run(set_0, float_0)
    assert result == {'failed': False, 'msg': 'Hello world!'}

# Generated at 2022-06-25 06:39:56.081276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(test_case_0())

# Generated at 2022-06-25 06:40:01.448020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)


# Generated at 2022-06-25 06:40:25.234130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test 1 - module action.debug")
    float_0 = -966.34
    set_0 = {float_0, float_0, float_0}
    int_0 = -90
    bytes_0 = b'\xb5\xde'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    print("Test 2 - module action.debug")
    float_0 = -966.34
    set_0 = {float_0, float_0, float_0}
    int_0 = -90
    bytes_0 = b'\xb5\xde'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)

# Generated at 2022-06-25 06:40:32.876140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Constructor
        float_0 = -1141.27
        set_0 = {float_0, float_0, float_0}
        int_0 = -93
        bytes_0 = b'\x9e\x9e'
        action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    except:
        # Error
        print('Error raised by constructor')
    
    # Method run
    var_0 = test_case_0()
    assert var_0


# Generated at 2022-06-25 06:40:36.195487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    var_0 = action_module_0.action_run()

# Generated at 2022-06-25 06:40:42.477850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)

# Generated at 2022-06-25 06:40:47.671303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    print (action_module_0)


# Generated at 2022-06-25 06:40:55.692222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [1, 1, 0, 1, 1]
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    assert (action_module_0.run(bytes_0, list_0) == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True})

# Generated at 2022-06-25 06:41:02.575533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'qrB\x87\x7f\x1b\x7f'

# Generated at 2022-06-25 06:41:08.186461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'

    # Run constructor of class ActionModule where error is raise
    try:
        action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
        print(action_module_0)
    except TypeError:
        print('TypeError exception caught')

    # Run constructor of class ActionModule where error is raise

# Generated at 2022-06-25 06:41:13.375172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:41:17.942276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    assert action_module_0 is not None

# Generated at 2022-06-25 06:41:45.648784
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # variable declaration
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'

    # Creating object of ActionModule class
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    print("Created object of ActionModule class")

    # Calling function run()
    var_0 = action_module_0.run()

    return var_0

# Generated at 2022-06-25 06:41:48.737623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Create test cases
    # action_module_0 = ActionModule()
    # assert action_module_0.run() == expected, 'Expected different value than actual'
    pass

# Generated at 2022-06-25 06:41:56.468272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    assert_equals(action_module_0.float_0, -1141.27)
    assert_equals(action_module_0.set_0, {float_0, float_0, float_0})
    assert_equals(action_module_0.int_0, -93)
    assert_equals(action_module_0.bytes_0, b'\x9e\x9e')


# Generated at 2022-06-25 06:42:02.644641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    tmp_0 = None
    var_0 = action_run(tmp_0)


# Generated at 2022-06-25 06:42:09.710241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    var_0 = action_module_0.run()
    return var_0

# Generated at 2022-06-25 06:42:16.593778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule#run")
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    actual = action_module_0.run()
    expected = {'failed': True}
    assert actual == expected



# Generated at 2022-06-25 06:42:18.508467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # check whether ActionModule constructor creates an object of class ActionModule
    assert('_ActionModule__VALID_ARGS' in dir(ActionModule))

# Generated at 2022-06-25 06:42:22.962165
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Unit test for constructor")
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:42:26.193052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:42:32.981124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:43:37.530889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:43:38.551842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Empty arguments
    action_module_0 = ActionModule()



# Generated at 2022-06-25 06:43:44.325747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 458
    complex_0 = complex(632, int_0)
    str_3 = str(complex_0)
    action_module_0 = ActionModule(str_3, bool_0, complex_0, complex_0, int_0, complex_0)

    # Call method to test
    action_module_0.run(float_0, set_0)

# Test provides arguments 'verbosity', 'msg', etc

# Generated at 2022-06-25 06:43:45.294615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:43:52.172123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 06:43:58.828409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -269.24
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    int_1 = -93
    set_1 = {float_0, float_0, float_0}
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    dict_0 = dict()

# Generated at 2022-06-25 06:44:08.676088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1141.27
    set_0 = {float_0, float_0, float_0}
    int_0 = -93
    bytes_0 = b'\x9e\x9e'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)
    assert isinstance(action_module_0, ActionModule) == True
    assert action_module_0.run() == dict(skipped=True, skipped_reason='Verbosity threshold not met.')
    assert action_module_0.run(verbosity=1) == dict(msg='Hello world!', _ansible_verbose_always=True, failed=False)

# Generated at 2022-06-25 06:44:12.674568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        file_0 = open('', 'r')
        try:
            ActionModule(file_0, dict(), dict(), dict(), dict(), dict())
        finally:
            file_0.close()
    except Exception as inst:
        print(type(inst))
        print(inst.args)
        print(inst)


# Generated at 2022-06-25 06:44:16.664603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -914.57
    set_0 = {float_0, float_0, float_0}
    int_0 = -41
    bytes_0 = b'\xacn'
    action_module_0 = ActionModule(float_0, set_0, int_0, set_0, bytes_0, int_0)


# Generated at 2022-06-25 06:44:20.281573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test parameters:
    # Arguments:	tmp=None, task_vars=None
    # Result:	{}
    # Expected:	{}
    result = ActionModule.run(tmp=None, task_vars=None)
    assert {} == result

# Generated at 2022-06-25 06:46:39.034432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None)
    assert action_module_0._VALID_ARGS == frozenset({'msg', 'verbosity', 'var'})
    assert action_module_0.TRANSFERS_FILES == False
if __name__ == '__main__':
    test_ActionModule()

    # The flag -v shows the execution of each statement in the test function
    # for the action module
    test_case_0()

# Generated at 2022-06-25 06:46:41.095111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert 1 == 1
    except AssertionError:
        print('AssertionError raised in test_ActionModule.')
        raise
