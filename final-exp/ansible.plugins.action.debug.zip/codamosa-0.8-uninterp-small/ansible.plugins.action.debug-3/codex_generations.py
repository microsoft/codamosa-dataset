

# Generated at 2022-06-25 06:36:52.972148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\n\nTesting run()')
    # set up test env
    float_0 = 1041.14
    float_1 = float_0 + float_0
    str_0 = '%Tt{'
    str_1 = str_0 + str_0
    str_2 = str_1 + str_1
    str_3 = str_2 + str_2
    str_4 = str_3 + str_3
    str_5 = str_4 + str_4
    str_6 = str_5 + str_5
    str_7 = str_6 + str_6
    str_8 = str_7 + str_7
    str_9 = str_8 + str_8
    str_10 = str_9 + str_9
    str_11 = str_10 + str_10
    str

# Generated at 2022-06-25 06:36:55.755259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x.TRANSFERS_FILES == False
    assert x.VALID_ARGS == frozenset(['msg', 'var', 'verbosity'])


# Generated at 2022-06-25 06:36:57.684437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define no parameters
    # Create an instance of ActionModule
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:37:05.945963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1041.14
    str_0 = '%Tt{'
    set_0 = {str_0}
    dict_0 = {str_0: set_0, set_0: str_0}

    # Create acton module with args
    action_0 = ActionModule(task=dict_0, connection=dict_0, PlayContext=dict_0, loader=dict_0, templar=dict_0, shared_loader_obj=dict_0)

    # Run run method
    action_0.run(task_vars=dict_0)

    # Test run method with none args
    action_0.run()

    # Test run method with none task_vars
    action_0.run(task_vars=None)


# Generated at 2022-06-25 06:37:09.943697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module_0 = ActionModule()

    # Dummy data Dictionary to test method run
    # Create an instance of class ActionModule
    action_module_0 = ActionModule()

    data = {
        "failed": False,
        "msg": "Hello world!"
    }

    assert data == action_module_0.run()

# Generated at 2022-06-25 06:37:12.485374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1041.14
    str_0 = '%Tt{'
    set_0 = {str_0}
    dict_0 = {str_0: set_0, set_0: str_0}


# Generated at 2022-06-25 06:37:14.395842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    params_0 = '&*'
    # test ActionModule constructor
    action_module_0 = ActionModule(params_0)
    assert type(action_module_0) is ActionModule


# Generated at 2022-06-25 06:37:16.164611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_0 = Task()
    tmp_0 = None
    task_vars_0 = {}
    action_module_0 = ActionModule(task_0, tmp_0, task_vars_0)

# Generated at 2022-06-25 06:37:23.426240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 1041.14
    str_0 = '%Tt{'
    set_0 = {str_0}
    dict_0 = {str_0: set_0, set_0: str_0}
    __call__ = ActionModule(float_0, str_0, set_0, dict_0)
    __call__.run(float_0, str_0)


# Generated at 2022-06-25 06:37:30.869547
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    float_0 = float()
    float_1 = float()
    float_1.real = float_0.real

    str_0 = str()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    str_5 = str()
    str_6 = str()
    str_7 = str()
    str_8 = str()
    str_9 = str()
    str_10 = str()

    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()

    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []

    set_0 = set()

# Generated at 2022-06-25 06:37:45.257868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    action_module_0 = ActionModule()
    task_vars = dict()
    ret_val_task_run_0 = action_module_0.run(tmp=None, task_vars=task_vars)
    ret_val_task_run_1 = action_module_0.run(tmp=None, task_vars=task_vars)
    ret_val_task_run_2 = action_module_0.run(tmp=None, task_vars=task_vars)
    ret_val_task_run_3 = action_module_0.run(tmp=None, task_vars=task_vars)
    ret_val_task_run_4 = action_module_0.run(tmp=None, task_vars=task_vars)
   

# Generated at 2022-06-25 06:37:46.441741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Run unittests

# Generated at 2022-06-25 06:37:49.858459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run()  # == "Hello world!"

# Generated at 2022-06-25 06:37:53.785660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    assert action_module_1.run({}, {}) == action_module_1.run({}, {})
    assert action_module_1.run({}, {}) != action_module_1.run({}, {})

# Generated at 2022-06-25 06:37:57.939702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 0
    action_module_0 = ActionModule()
    assert action_module_0.run(tmp=None, task_vars=None) == {"failed": False, "msg": 'Hello world!', "_ansible_verbose_always": True}


# Generated at 2022-06-25 06:38:06.055178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check if ActionModule.run raises a NotImplementedError.
    #
    # The run() method of the superclass is not abstract, but it
    # isn't supposed to be invoked directly.  It is simply to be used
    # as the superclass for subclasses that override run().  So this
    # test is to make sure that happens.
    action_module_0 = ActionModule()
    assert_raises(NotImplementedError, action_module_0.run, None, None)


# Generated at 2022-06-25 06:38:09.935421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES is False
    assert list(action_module_0._VALID_ARGS) == ['var', 'msg', 'verbosity']



# Generated at 2022-06-25 06:38:13.078081
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    import json
    
    print("Unit test for constructor of class ActionModule")
    print()
    
    # Create an object of ActionModule
    actionModule = ActionModule()
    
    # Display object id of actionModule
    print("Object id of actionModule = %d" %id(actionModule))
    
    # Print attributes of actionModule
    print(json.dumps(actionModule.__dict__, indent=4))
    

# Generated at 2022-06-25 06:38:15.124842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if False:
        assert type(action_module_0) == object
#

# Generated at 2022-06-25 06:38:20.298552
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set up object
    action_module = ActionModule()
    action_module._task.args = {'var': 'test_variable', 'verbosity': 1}
    action_module._task.args = {'var': 'test_variable', 'verbosity': 1}
    action_module.run()

# Generated at 2022-06-25 06:38:32.522921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    action_module_obj.run()


# Generated at 2022-06-25 06:38:34.037803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module


# Generated at 2022-06-25 06:38:36.221992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:38:44.987579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n\n#######################\n# Unit test for method run of class ActionModule\n#######################")
    # Task definition
    task0 = dict(action=dict(module='debug'))
    task0['args'] = dict()
    task0['args']['msg'] = u'Hello world!'
    
    # Task execution
    action_module_0 = ActionModule()
    result = action_module_0.run(None, dict())

    # Unit test output
    assert result['failed'] == False, "ActionModule.run: 'assert result[failed] == False'"
    assert result['msg'] == 'Hello world!', "ActionModule.run: 'assert result[msg] == Hello world!'"
    print("\nOK\n")


# Generated at 2022-06-25 06:38:46.236841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

print(test_ActionModule_run())

# Generated at 2022-06-25 06:38:49.228776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yaml_input = """
- name: test
  debug:
    msg: TEST
"""
    yaml_output = action_module_0.run(yaml_input, None)
    assert yaml_output["msg"] == "TEST"

# Generated at 2022-06-25 06:38:52.855854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # arg: tmp, expected: None
    action_module_1 = ActionModule(tmp=None)
    # arg: task_vars, expected: None
    action_module_2 = ActionModule(task_vars=None)

# Generated at 2022-06-25 06:38:53.732122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # trivial tests
    test_case_0()

# Generated at 2022-06-25 06:38:54.896689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture_1 = ActionModule()
    fixture_1.run()

# Generated at 2022-06-25 06:39:00.586162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    result = dict()
    def _display(msg, color=None, stderr=False, screen_only=False, log_only=False):
        pass

    def _task(msg, color=None, stderr=False, screen_only=False, log_only=False):
        pass

    action_module_1 = ActionModule(task=_task(task_vars=task_vars), connection=None, play_context=None, loader=None, templar=_display(), shared_loader_obj=None)
    action_module_1.run()


# Generated at 2022-06-25 06:39:21.727621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act = ActionModule("module_name", "{}", False, False, False, "path")

    assert act.run("tmp", {"verbosity": 0}) == {"_ansible_verbose_always": True, "msg": "Hello world!", "failed": False}
    assert act.run("tmp", {"verbosity": 1, "msg": "baz"}) == {"failed": False, "msg": "baz", "_ansible_verbose_always": True}
    assert act.run("tmp", {"verbosity": 1, "var": "verb"}) == {"failed": False, "verb": "VARIABLE IS NOT DEFINED!", "_ansible_verbose_always": True}

# Generated at 2022-06-25 06:39:26.435802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '&6<bT'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    var_0 = action_module_0.run(None, None)

# Generated at 2022-06-25 06:39:36.510352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '*$'
    str_1 = '*+Kd'
    str_2 = '&>(+O'
    action_module_0 = ActionModule(str_0, str_1, str_2)
    str_3 = '=Gt$D'
    str_4 = '@8(#'
    list_0 = [str_3, str_4]
    str_5 = '9>d'
    str_6 = 'ds0_'
    str_7 = 'Zv'
    dict_0 = {str_5: str_6, str_7: str_7}
    str_8 = 'i'
    str_9 = '9#'
    list_1 = [str_8, str_9]
    str_10 = 'l'
    str_11

# Generated at 2022-06-25 06:39:40.364876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # str_0 = '&6<bT'
    # bool_0 = True
    # action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    pass


# Generated at 2022-06-25 06:39:44.826347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    # func_0 = func_1(obj_0)
    action_run_0 = ActionModule.run('$*^', str_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 06:39:49.542466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Example:
    # str_0 = '&6<bT'
    # bool_0 = True
    # action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    # var_0 = action_module_0.run()
    pass


# Generated at 2022-06-25 06:39:53.579732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '^+`X%8o'
    str_1 = 'N)lPT'
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(str_0, str_1, bool_0, bool_0, bool_1, str_1)


# Generated at 2022-06-25 06:40:04.528255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    str_0 = 'Hello world!'
    dict_0['msg'] = str_0
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, dict_0)
    dict_1 = action_module_0.run()
    dict_2 = dict()
    dict_3 = dict()
    dict_3['_ansible_verbose_always'] = True
    dict_3['failed'] = False
    dict_3['msg'] = str_0
    dict_2['msg'] = dict_3
    dict_4 = dict()
    dict_4['_ansible_verbose_always'] = True
    dict_4['failed'] = False
    dict_4['msg'] = str_0

# Generated at 2022-06-25 06:40:08.342522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '&6<bT'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:40:11.891950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case with zero arguments
    str_0 = '&6<bT'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    var_0 = action_run()
    
    assert var_0["msg"] == "Hello world!"
    assert var_0["_ansible_verbose_always"] == True
    assert var_0["failed"] == False
    
    # Test case with one argument
    dict_0 = dict()
    dict_0["msg"] = "This is a message"
    action_module_1 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, dict_0)
    var_1 = action_run()
    
   

# Generated at 2022-06-25 06:40:46.282706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test variables
    tmp = None
    task_vars = None

    # Setup mock objects
    original_run = ActionBase.run
    original_display = ActionBase._display
    original_templar = ActionBase._templar
    ActionBase.run = MagicMock(return_value={"failed": False})
    ActionBase._display = MagicMock()
    ActionBase._templar = MagicMock()

    # Run test case
    action_module_0 = ActionModule(None, None, False, False, False, None)
    var_0 = action_module_0.run(tmp, task_vars)

    # Reset test variables
    tmp = None
    task_vars = {"failed": False}

    # Run test case

# Generated at 2022-06-25 06:40:54.737256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case with default values
    result = ActionModule.run()
    assert result == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}, 'Incorrect value returned'
    msg = 'you are not allowed to do this'

# Generated at 2022-06-25 06:40:58.627780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg = 'Hello world!'
    var = 'ansible_hello_world'
    action_module = ActionModule('test', 'test', True, True, True, 'test')
    result = action_module.run(msg, var)
    assert(result['msg'] == 'Hello world!')
    assert(result['ansible_hello_world'] == 'Hello world!')
    assert(result['failed'] == False)

# Generated at 2022-06-25 06:41:02.540238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = '&6<bT'
    str_3 = '>'
    var_1 = ActionModule(str_2, str_3, True, True, True, str_3)
    str_4 = 'q'
    var_2 = var_1.run(str_4)
    var_1.run(str_2)


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:41:05.580922
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test for only msg option is given
    actmod_obj = ActionModule("", "", False, False, False, "")
    expected_result = {'msg': 'Hello world!'}
    actual_result = actmod_obj.run("", {}, {'msg': 'Hello world!'})
    test.equal(actual_result, expected_result, "Expected and actual results are equal")


# Generated at 2022-06-25 06:41:10.261975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test for constructor of class ActionModule
    str_0 = '&6<bT'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)

    # test case for run method without args
    action_module_0.run()

# Generated at 2022-06-25 06:41:15.035324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '&6<bT'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    # TODO: replace assert with appropriate check
    assert False, 'Unimplemented test: unit_test_0'


# Generated at 2022-06-25 06:41:20.794136
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case with existing catalog_id
    str_0 = 'h!uP7F'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    str_0 = 'NMK#0g'
    str_1 = 'U/)w'
    dict_0 = {str_0: str_1}
    var_0 = action_module_0.run(dict_0)




# Generated at 2022-06-25 06:41:23.915804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'P&'
    str_1 = '\x16'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    action_module_0.run(str_1, str_1)


# Generated at 2022-06-25 06:41:33.173893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {
            'msg': 'Hello world!',
            'verbosity': 4,
            'var': [1,2,3]
        }
    tmp = None
    task_vars = None
    _VALID_ARGS = frozenset(('msg', 'var', 'verbosity'))
    module_args = dict((k, v) for k, v in module_args.items() if k in _VALID_ARGS and v is not None)
    self._task.args.update(module_args)
    self._display.verbosity = 2
    action_module_0 = ActionModule(self, tmp, task_vars)
    action_module_0.run()
    return action_module_0.run()


# Generated at 2022-06-25 06:42:24.190473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct with int_0
    int_0 = 0
    bool_0 = True
    str_0 = 'g0<'
    action_module_0 = ActionModule(int_0, str_0, bool_0, bool_0, bool_0, str_0)
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 06:42:34.105601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/h3-@'
    bool_0 = False
    test_case_0(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    str_1 = '&e|J'
    bool_1 = False
    str_2 = 'G%c'
    test_case_0(str_2, str_1, bool_1, bool_1, bool_1, str_2)
    str_3 = '3q'
    bool_2 = False
    str_4 = 'dc'
    test_case_0(str_4, str_3, bool_2, bool_2, bool_2, str_4)
    str_5 = '7gd:$@'
    bool_3 = False

# Generated at 2022-06-25 06:42:37.311946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '&6<bT'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    assert action_module_0



# Generated at 2022-06-25 06:42:38.002528
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert True
  return

# Generated at 2022-06-25 06:42:41.438271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'O#|@B>'
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    test_case_0()


# Generated at 2022-06-25 06:42:47.273287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '='
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    bool_0 = False
    str_1 = '@+$>z'
    bool_1 = True
    action_module_0.runner = Runner(bool_0, bool_1, str_1, bool_0)
    action_module_0.Noop = bool_0
    bool_1 = False
    bool_2 = False
    action_module_0.display = Display(bool_1, bool_2)
    # Try to call method run()
    try:
        action_module_0.run()
    except Exception as exc_0:
        print(exc_0)
    else:
        print

# Generated at 2022-06-25 06:42:51.952483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    # Constructor test for class ActionModule
    # Instance attributes for class ActionModule
    # real_action_name = 'debug'
    # action_lacks_args_option = True
    # Argument 'action_name' (line 22)
    # Argument 'action_strings' (line 23)
    # Argument 'action_lacks_args_option' (line 24)
    # Argument 'supports_check_mode' (line 25)
    # Argument 'task_is_background' (line 26)
    # Argument 'connection_name' (line 27)


# Generated at 2022-06-25 06:42:56.843729
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Try to create an instance of ActionModule
  action_module_0 = ActionModule()
  # Check if type(action_module_0) is ActionModule
  if not isinstance(action_module_0, ActionModule):
    # Report error to web console
    print('Failed to create instance of ActionModule!')

if __name__ == "__main__":
  test_ActionModule()
  test_case_0()

# Generated at 2022-06-25 06:43:00.084450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '&6<bT'
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_1, str_0)

# Generated at 2022-06-25 06:43:07.377807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._play_context == None
    assert action_module_0._connection == None
    assert action_module_0._play == None
    assert action_module_0._name == None
    assert action_module_0._loader == None
    assert action_module_0._tqm == None
    assert action_module_0._task_vars == None
    assert action_module_0._templar == None
    assert action_module_0._task == None
    assert action_module_0._loader_name == None
    assert action_module_0._display == None

#TODO
#def action_run():
#    pass

#TODO
#def test_case_1():
#    str_0 = '()zcd]4'

# Generated at 2022-06-25 06:45:11.865833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 06:45:16.446317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a'
    bool_0 = True
    action_module_1 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    str_1 = 'Hello world!'
    dict_0 = {}
    str_2 = 'msg'
    dict_0[str_2] = str_1
    dict_1 = {}
    dict_1 = action_module_1.run(dict_0)
    print(dict_1)

# Generated at 2022-06-25 06:45:21.482898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '&6<bT'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    var_0 = action_module_0.run()
    var_0.run()


# Generated at 2022-06-25 06:45:27.660957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'w'
    str_0 = '9'
    bool_0 = True
    str_2 = 'G;2mY'
    boolean_0 = True
    boolean_1 = True
    str_3 = 'gf'
    str_4 = 'n'
    action_module_0 = ActionModule(str_1, str_0, bool_0, str_2, boolean_0, str_3, boolean_1, str_4)
    # AssertionError: Unsupported signature: ActionModule(str, str, bool, str, bool, str, bool, str)


# Generated at 2022-06-25 06:45:32.727411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '&6<bT'
    str_1 = ';~Nx`'
    action_module_0 = ActionModule(str_0, str_1, bool_0, bool_0, bool_0, str_0)
    assert action_module_0._VALID_ARGS == frozenset() and action_module_0.TRANSFERS_FILES == None



# Generated at 2022-06-25 06:45:35.762493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Verify this method raises an exception when called with a wrong number of parameters
    try:
        action_module_0.run()
    except TypeError as exception_0:
        assert True
    except Exception as exception_1:
        assert False

# Generated at 2022-06-25 06:45:40.583744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call to ActionModule('&6<bT', '&6<bT', True, True, True, '&6<bT')
    action_module_0 = ActionModule('&6<bT', '&6<bT', True, True, True, '&6<bT')
    # AssertionError


# Generated at 2022-06-25 06:45:45.693277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '&6<bT'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
    # Should fail
    task_vars = dict()
    var_0 = action_module_0.run(None, task_vars)
    assert (var_0['failed']) == True



# Generated at 2022-06-25 06:45:47.175734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(get_ansible_version() > '2.4')

# Generated at 2022-06-25 06:45:51.246658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'mfve'
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bool_0, bool_0, bool_0, str_0)
