

# Generated at 2022-06-25 06:36:53.060280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Unit tests for ActionModule

# Generated at 2022-06-25 06:36:58.473441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = None
    list_0 = [dict_0, dict_0, dict_0, dict_0]
    str_0 = 'IM'
    float_0 = -167.80378
    action_module_0 = ActionModule(list_0, str_0, float_0, str_0, dict_0, dict_0)
    result = action_module_0.run()
    print(result)
    assert result["failed"] == False

# Generated at 2022-06-25 06:37:01.995736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, 'test_name')
    # verify if all required attributes exist
    assert action_module_0._task
    assert action_module_0._connection
    assert action_module_0._play_context
    assert action_module_0._loader
    assert action_module_0._templar
    assert action_module_0._shared_loader_obj
    assert action_module_0.display



# Generated at 2022-06-25 06:37:07.926707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = None
    list_0 = [dict_0, dict_0, dict_0, dict_0]
    str_0 = 'b64_decode'
    float_0 = -47.92837
    action_module_0 = ActionModule(list_0, str_0, float_0, str_0, dict_0, dict_0)
    float_0 = float(50.3654)
    dict_1 = OrderedDict()
    str_1 = 'Y'
    str_2 = 'U'
    str_3 = '1'
    str_4 = 'G9'
    tuple_0 = (str_1, str_2, str_3, str_4)
    str_5 = '9u'
    str_6 = 'V'

# Generated at 2022-06-25 06:37:15.090887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = None
    list_0 = [dict_0, dict_0, dict_0, dict_0]
    str_0 = 'IM'
    float_0 = -167.80378
    action_module_0 = ActionModule(list_0, str_0, float_0, str_0, dict_0, dict_0)
    dict_1 = None
    dict_2 = None
    dict_3 = None
    dict_4 = None
    dict_5 = None
    list_1 = [dict_1, dict_2, dict_3, dict_4, dict_5]
    dict_6 = None
    dict_7 = None
    dict_8 = None
    dict_9 = None
    dict_10 = None

# Generated at 2022-06-25 06:37:26.297691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_1 = {}
    list_1 = [dict_1, dict_1, dict_1, dict_1]
    str_1 = 'Ym'
    float_1 = -9.138128
    action_module_1 = ActionModule(list_1, str_1, float_1, 'result', dict_1, dict_1)

    task_0 = action_module_1.run(dict_1, dict_1)

    assert task_0['msg'] == 'Hello world!'
    assert task_0['_ansible_verbose_always']
    assert not task_0['skipped']
    assert not task_0['failed']

    task_1 = action_module_1.run(dict_1, dict_1)

    assert task_1['msg'] == 'Hello world!'
    assert task_1

# Generated at 2022-06-25 06:37:28.696329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()
    print("Unit test finished.")

# Generated at 2022-06-25 06:37:39.473024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_1 = {}
    str_1 = 'msg'
    str_2 = 'Hello world!'
    str_3 = 'verbosity'
    int_1 = 0
    list_1 = [str_1, str_2, str_3, int_1]
    dict_2 = {}
    str_4 = 'module_args'
    str_5 = 'action'
    str_6 = 'debug'
    str_7 = 'action_plugin'
    str_8 = 'tasks'
    list_2 = [dict_2, str_4, str_5, str_6, str_7, str_8]
    float_1 = 55.4
    str_9 = 'AN'
    str_10 = '_'
    str_11 = 'S'
    str_12 = 'I'


# Generated at 2022-06-25 06:37:48.663508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    list_0 = [dict_0, dict_0, dict_0, dict_0]
    str_0 = 'IM'
    float_0 = -167.80378
    action_module_0 = ActionModule(list_0, str_0, float_0, str_0, dict_0, dict_0)
    assert action_module_0.TRANSFERS_FILES == False, \
        'ActionModule.TRANSFERS_FILES == False failed. Expected: True, Actual: %s' %action_module_0.TRANSFERS_FILES

# Generated at 2022-06-25 06:37:56.745037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    list_0 = [dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0]
    str_0 = 'b'
    float_0 = -467.5829
    action_module_0 = ActionModule(list_0, str_0, float_0, str_0, dict_0, dict_0)


# Generated at 2022-06-25 06:38:05.595023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:38:09.275456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'test_name'
    action_module_0 = ActionModule(str_0, str_0)
    assert type(action_module_0) is ActionModule


# Generated at 2022-06-25 06:38:11.975204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'test_name'
    str_1 = 'test_name'
    action_module_0 = ActionModule(str_0, str_1)


# Generated at 2022-06-25 06:38:13.067035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pass in a dict for connection info
    test_case_0()


# Generated at 2022-06-25 06:38:15.078161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Remove this test if the test_case_0 is not working
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:38:21.077374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('Hello World', 'Hello World')
    str_0 = 'msg'
    action_module_0.set_task(str_0)
    action_module_0.run()
    str_1 = 'var'
    action_module_0.set_task(str_1)
    action_module_0.run()


# Generated at 2022-06-25 06:38:22.097232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:38:25.798742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'test_name'
    action_module_0 = ActionModule(str_0, str_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:38:28.544153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'test_name'
    action_module_0 = ActionModule(str_0, str_0)
    result_dict = action_module_0.run()
    assert result_dict['failed'] == False


# Generated at 2022-06-25 06:38:31.181439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'test_name'
    action_module_0 = ActionModule(str_0, str_0)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:38:48.359109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'x'
    str_1 = 'Z6U'
    bytes_0 = b'\x98\x15\xa8\x8b\xb3\xaa\xf9'
    str_2 = 'O'
    list_0 = []
    str_3 = '<\x00'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    var_0 = action_module_0.run(bool_0)
    assert var_0 == False

# # Unit test for method load_module_utils of class ActionModule
# def test_ActionModule_load_module_utils():
#     bool_0 = False
#     str_0 = 'x'
#     str

# Generated at 2022-06-25 06:38:57.685589
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class Test_class:

        def test_0():

            bool_0 = False
            str_0 = 'G'
            str_1 = 'd,b'
            bytes_0 = b'\xe3\x86\x1c\xad'
            str_2 = ''
            list_0 = []
            str_3 = '%cx^C'
            action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
            var_0 = action_module_0._run(action_module_0.tmp, action_module_0.task_vars)

        def test_1():

            bool_0 = False
            str_0 = 'b,Ip'
            str_1 = '<'
            bytes_0 = b

# Generated at 2022-06-25 06:39:09.007668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '@PI'
    str_1 = "8/xAv"
    bytes_0 = b'\x00\xa2\xcf\x13\xfd\xcbn\xa8\xab\xb9$\x88\x02\x8c\x95\xb4\xd4\x1b\x9b\xf9\xcb\x95'
    str_2 = '|'
    list_0 = ['kmI', 'Bx;dV#-/&3', 'V\x85\x15\xcf']
    str_3 = '|'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    action_module_0.run()


# Generated at 2022-06-25 06:39:17.469426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    bool_0 = False
    bool_1 = bool_0
    tmp_0 = None
    dict_0 = dict()
    task_vars_0 = dict_0
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    test_0 = result_0


if __name__ == '__main__':
    # Test for method run of class ActionModule
    test_case_0()
    # Unit test for method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-25 06:39:18.777174
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # check if exception was raised
    assert not exception_raised()


# Generated at 2022-06-25 06:39:30.213056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'Uq['
    str_1 = '(|Za!$'
    bytes_0 = b'\x00y\xea\x83\x16\xb0\xc1\xe3\x15\x88\x18\xa8\x9e'
    str_2 = '*'
    list_0 = [b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7']
    str_3 = 't'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    var_0 = action_run(bool_0)
    #assert var_0 ==

# Generated at 2022-06-25 06:39:38.902786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'mbgS'
    str_1 = "'a,brb"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'DoO0B=NlA5v2Uh(GV'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    tmp_0 = 'doo0h\x84mz'
    task_vars_0 = []
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:39:50.305279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '\x0c'
    str_1 = 's\x95\x9c\xe8[\x0e\x0c\x95\x18\x0c\x96\xe6\x9c'
    bytes_0 = b'\x01\x98\x84\x10\x88\x93\x94\x8a\x08\xb6\x88\x90'

# Generated at 2022-06-25 06:39:57.001981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'l@YXQ\t7\xab\x93'
    str_1 = "Z_K$Bt}'d#u\x04[&"
    bytes_0 = b'\x87\xf8\x84\x15\x1e\xf9X\xf8\xbb%\x83!\x06\x1f\xc3\x94\x02\x06\x9f'
    str_2 = '#1=!\x15B\x8c'
    list_0 = []
    str_3 = ''
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    assert action_module_0.run_async == False

# Generated at 2022-06-25 06:40:04.157437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #first_arg = 'mbgS'
    #second_arg = "'a,brb"
    #third_arg = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    #fourth_arg = ''
    #fifth_arg = []
    #sixth_arg = 'DoO0B=NlA5v2Uh(GV'
    #action_module = ActionModule(first_arg, second_arg, third_arg, fourth_arg, fifth_arg, sixth_arg)
    pass

# Generated at 2022-06-25 06:40:32.260744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '2@Yw0'
    str_1 = ";S[\x19"
    bytes_0 = b'}4\x1a\xcb\xa4\x8a\\\x0f'
    str_2 = ''
    list_0 = []
    str_3 = '\x7f'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    var_0 = action_run(bool_0)

# Generated at 2022-06-25 06:40:39.597902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '2=_wR'
    str_1 = "v[q'k="
    bytes_0 = b'\x19=D\x81\xb0\xfc\xe1\xba3\xac\x06\xa5\x14\xe5\x0e\xe7!\x1f\x0f\x9d'
    str_2 = '%\xfbS'
    list_0 = []
    str_3 = 'u6\x1c7'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    assert(action_module_0._task == str_1)
    assert(action_module_0._connection == bytes_0)

# Generated at 2022-06-25 06:40:49.150535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    bool_0 = False
    str_0 = 'v$&\x8f!\x1f\xe3\x13\x81\xeb\xb0\xbd;\xf9\x80\xb7\xbc\x1d\x1d\x8e'
    str_1 = 'Y|\xed\x01\x9f\x8a\xce,\xda\xae\x1f\xac\x89\xd2\xde\x18\x96'
    bytes_0 = b'\x0c\x8f\x89\xd0\xb7\xce\xa8\x15\x1b\x0c\xda'
    str_2 = ''
    list_0 = []

# Generated at 2022-06-25 06:40:50.217172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:40:57.840522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test environment
    bool_0 = False
    str_0 = 'mbgS'
    str_1 = "'a,brb"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'DoO0B=NlA5v2Uh(GV'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    str_4 = 'BrR\njWU]Q6U#\x0ccHk\x0c'

# Generated at 2022-06-25 06:41:02.993062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # all variables except "tmp" and "task_vars" are initialized with values
    # corresponding to their names
    tmp = None
    task_vars = None
    module_1 = ActionModule('r', 'it', b'', '', [], 'ins')
    # method "run" called with arguments (tmp, task_vars)
    result = module_1.run(tmp, task_vars)
    # result is compared with expected value
    assert result == {'failed': False, 'msg': 'Hello world!', '_ansible_verbose_always': True}


# Generated at 2022-06-25 06:41:13.721618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x8e\xb3\xfe\xbc,\x1d\x88@\x1c,\xd5\x0f\x00x\xca\x1a\x92\xaa'
    str_1 = '\xbd\xda\xaa\x8f\x80\x81,\x10\xc2\xbc\xaf\x1e\x1b\x9d\xdd\xe6)\x03@1\xfa\x0bK\xfe'

# Generated at 2022-06-25 06:41:20.210164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'ms'
    str_1 = "'a,brb"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'DoO0B=NlA5v2Uh(GV'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)


# Generated at 2022-06-25 06:41:26.867479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'O91B~\x11FYk\x0c\x1a.\x11\x14"\x16!.\x04&\x1a\x0eN'
    str_1 = "msg"
    bytes_0 = b'\x06\x0eA\xe7\xe6\x94\x921\x80\xe8\xed\xe0\xd6\xcb\x1a\xef\x1c'
    str_2 = "hello world"
    str_3 = '\x12\x04\x1a\x06\x14\x06\x0e\x1a\x1c'

# Generated at 2022-06-25 06:41:27.925344
# Unit test for constructor of class ActionModule
def test_ActionModule():
	test_case_0()

# Generated at 2022-06-25 06:42:16.753525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'mbgS'
    str_1 = "'a,brb"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'DoO0B=NlA5v2Uh(GV'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    action_module_0.run(None, dict())


# Generated at 2022-06-25 06:42:24.667034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'L*j~F@'
    str_1 = "`<Xj*'aJ"
    bytes_0 = b'\x82\x85\xb7r\x0e\x7f\xaa\x80\xec\x04\x96\xba\xa5\x13\xf1\x08\x9e\x87\x1e\xb5\xae'
    str_2 = '9(vK'
    list_0 = [12, 3]
    str_3 = '%(l]#:Kk'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)

# Generated at 2022-06-25 06:42:34.631601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '*!S,0<'
    str_1 = "BB#h4,D4xE"
    bytes_0 = b'\xa1\x8c\xbf9\x1d\xeb\xfd\xab\x82\xc6\x86\xd5\x058\x9f\xcd\x01\x97'
    str_2 = 'm[Yc5r5oFm5'
    list_0 = [False]

# Generated at 2022-06-25 06:42:38.830422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_0 = ActionModule('p', '|', b'T\x11\x93\xf8\xfe', '^,\xeb\x1e\xa0\t', [], 'T=T!\xbd\xd2\xec\x07\x1e\xa0\t')



# Generated at 2022-06-25 06:42:45.651311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = ')'
    str_1 = '_'
    bytes_1 = b'\x11\x88\x01\x03&\xb0\x14S\xdc\x05\x93\x9e\x8d\x00\xae\x1dv,i\x8ez'
    str_2 = 'dH'

# Generated at 2022-06-25 06:42:52.502055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'C'
    str_1 = '*s'
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'xz%q3\x1c1\x06X'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    str_4 = '"'
    str_5 = "K"
    bytes_1 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str

# Generated at 2022-06-25 06:43:00.598173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'mbgS'
    str_1 = "'a,brb"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'DoO0B=NlA5v2Uh(GV'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    var_0 = action_module_run(action_module_0, bool_0)

# Generated at 2022-06-25 06:43:07.767095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = ' \x8a\xc2&\xc3\x83,'
    str_1 = ">$rox'\xad\xbc"
    str_2 = 'G*\x1c\xf9T'
    bytes_0 = b'\x80\xb1j\xc2\xb7\x01\xca'
    str_3 = ')l\xf8\xaa\x81\n'
    list_0 = ['^\x9a\x1e', '.!\xdf\xc0\xab']
    action_module_0 = ActionModule(str_0, str_1, str_2, bytes_0, str_3, list_0)

# Generated at 2022-06-25 06:43:14.871576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'mz,u'
    str_1 = "DoO0B=NlA5v2Uh(GV"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = 'A+($w!"#gf4F{sYkI'
    list_0 = []
    str_3 = "DoO0B=NlA5v2Uh(GV"
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    action_run(bool_0)

# Generated at 2022-06-25 06:43:25.254489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'xW'
    str_1 = 'k'
    bytes_0 = b'\xa6\xd5\xbe\x8f\xe5\x1a\x1c\xe2\x81\x9b\xc7\xec\x01\x06b\xaa\x9a\xcd\x9c\x87\x89\xc0\x02`\x8eGj\x04\xf6\x10'
    str_2 = ''
    list_0 = []
    str_3 = '\x99R_\xe7\xe4\xdb4\x89'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)


# Generated at 2022-06-25 06:45:20.586552
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:45:28.650997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '?8C?:'
    str_1 = 'H}`1Y8Wz,]gv'

# Generated at 2022-06-25 06:45:32.564550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'mbgS'
    str_1 = "'a,brb"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'DoO0B=NlA5v2Uh(GV'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    assert action_module_0._VALID_ARGS == frozenset(('msg', 'var', 'verbosity')
)


# Generated at 2022-06-25 06:45:38.752306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'cEz:2V7#?F0C{xN<*J'
    str_1 = ':'
    bytes_0 = b'\xaa\x94{n\x98\x96\x86\x04\x9a\xdaJ_\xb8r\xd7\xfe\xa49\xed\x8a\xa4\x9e\x98}\xf6\x8d\xa1'
    str_2 = 'y'
    list_0 = []
    str_3 = 'Z\x82|%\xe6\xe1,\xf0n\x9bn\x01\x8a\x1fY?\x97\x89!\x8d'

# Generated at 2022-06-25 06:45:45.830156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'mbgS'
    str_1 = "'a,brb"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'DoO0B=NlA5v2Uh(GV'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    action_module_0.run()

# Generated at 2022-06-25 06:45:48.377025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))

# Generated at 2022-06-25 06:45:52.465523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule(file_name, task_name, arguments, task_vars, loader, templar)
        print('Unit test for ActionModule ran successfully')
    except Exception:
        print('Unit test for ActionModule failed')

# Generated at 2022-06-25 06:45:53.773360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:46:01.247091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'mbgS'
    str_1 = "'a,brb"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'DoO0B=NlA5v2Uh(GV'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)
    return action_module_0

# Generated at 2022-06-25 06:46:06.291357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'msg'
    str_1 = "'a,brb"
    bytes_0 = b'\x16!\x01\xdb=`\xfaM\xee\x9b\xb9N\x15\xe024\xd7'
    str_2 = ''
    list_0 = []
    str_3 = 'DoO0B=NlA5v2Uh(GV'
    action_module_0 = ActionModule(str_0, str_1, bytes_0, str_2, list_0, str_3)

