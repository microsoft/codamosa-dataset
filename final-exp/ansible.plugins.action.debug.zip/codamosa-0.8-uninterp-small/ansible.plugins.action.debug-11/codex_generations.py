

# Generated at 2022-06-25 06:37:00.910612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)

    # Test attribute '_display'
    # Test if hasattr(action_module_0, '_display')
    assert hasattr(action_module_0, '_display')

    # Test attribute '_templar'
    # Test if hasattr(action_module_0, '_templar')
    assert hasattr(action_module_0, '_templar')

    #

# Generated at 2022-06-25 06:37:02.369456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:37:03.094148
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert type(ActionModule(tuple(), tuple(), dict(), dict(), tuple(), str())) == type(ActionModule)

# Generated at 2022-06-25 06:37:06.025443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    assert action_module_0.run(tmp, task_vars) is None


# Generated at 2022-06-25 06:37:13.636030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xdc\xd4\x8a\xac\x1c\x0c\x11\x8b\xf7\x00\x00\x00\x00\x00'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '2)5Kx\x1d\x14\x0f&\x03\x1f\x0e\x1c\x04\t\x1f\x1c\x04\x0b;\x02"\x19\x1a\x1d\'\x0c\x01\x1f\n'

# Generated at 2022-06-25 06:37:24.726960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (b'\xa7b\xbbS\x9c5\x90\x0e\x90',)
    tuple_1 = (b'\xa7b\xbbS\x9c5\x90\x0e\x90',)
    dict_0 = {}
    dict_1 = {}
    tuple_2 = (b'\xa7b\xbbS\x9c5\x90\x0e\x90',)
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_1, dict_0, dict_1, tuple_2, str_0)
    str_1 = ',u\x02'

# Generated at 2022-06-25 06:37:33.971624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    result = action_module_0.run()
    assert result['msg'] == 'Hello world!'

# Generated at 2022-06-25 06:37:41.914172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    # tests if an exception is thrown and if it is correct type
    try:
        action_module_0.run()
    except Exception as e:
        assert(isinstance(e, SystemExit))
    print('Test completed successfully')

# Generated at 2022-06-25 06:37:42.682093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:37:46.840985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'P'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)


# Generated at 2022-06-25 06:38:04.746294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = int()
    dict_0 = dict()
    dict_1 = dict()
    dict_1['msg'] = 'msg'
    dict_2 = dict()
    dict_2['var'] = 'var'
    dict_3 = dict()
    dict_3['verbosity'] = 'verbosity'
    tuple_0 = (dict_0, dict_1, dict_2, dict_3)
    dict_4 = dict()
    dict_4['msg'] = 'Hello world!'
    dict_4['_ansible_verbose_always'] = True
    dict_4['failed'] = False
    dict_5 = dict()
    dict_5['skipped_reason'] = 'Verbosity threshold not met.'
    dict_5['skipped'] = True

# Generated at 2022-06-25 06:38:12.105302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    return action_module_0


# Generated at 2022-06-25 06:38:13.212999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run(dict_0, dict_0) == dict_0


# Generated at 2022-06-25 06:38:24.200592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    bytes_1 = b'e\x00\x00\x00'
    tuple_0 = (bytes_0,)
    tuple_1 = (bytes_1,)
    set_0 = set()
    dict_0 = {}
    str_0 = 'test_case_0'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    result = action_module_0.run(set_0, tuple_1)
    assert not result['failed']
    result = action_module_0.run(set_0)
    assert not result['failed']
    result = action_module_0.run

# Generated at 2022-06-25 06:38:32.065009
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # print('Executing test_ActionModule_run')

    set_1 = set()
    bytes_1 = b'Pf\x01\xcc\x0b\x1d!\x95\x9b\xc3'

# Generated at 2022-06-25 06:38:40.296460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (b'\xa7b\xbbS\x9c5\x90\x0e\x90',)
    dict_0 = {}
    str_0 = 'T&?s\xa9\xd1\x02\xbf\\'
    action_module_0 = ActionModule((), (), {}, {}, tuple_0, str_0)
    var_0 = action_module_0.run()
    var_1 = action_module_0.run({})
    var_2 = action_module_0.run({}, {})


# Generated at 2022-06-25 06:38:47.928541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    tuple_0 = (b'\xa7b\xbbS\x9c5\x90\x0e\x90',)
    str_0 = 'B((sH4vY&/Cp"'
    dict_0 = {}
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    assert action_module_0.run(set_0, dict_0) == dict_0
    assert action_module_0.run(set_0, dict_0) == dict_0
    assert action_module_0.run(set_0, dict_0) == dict_0
    assert action_module_0.run(set_0, dict_0) == dict_0
    assert action

# Generated at 2022-06-25 06:38:54.577977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        set_0 = set()
        bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
        tuple_0 = (bytes_0,)
        dict_0 = {}
        str_0 = 'B((sH4vY&/Cp"'
        action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    except:
        print("Error")


# Generated at 2022-06-25 06:38:56.961679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Set up test values
  tmp = None
  task_vars = None
  # Call the method
  ActionModule.run(tmp, task_vars)


# Generated at 2022-06-25 06:39:03.596779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)


# Generated at 2022-06-25 06:39:24.049143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_1 = set()
    bytes_1 = b"\x86x\xcf^\xcd\x1e\xc3"
    tuple_1 = (bytes_1,)
    dict_1 = {}
    str_1 = ''
    str_2 = 'Hello world!'
    action_module_1 = ActionModule(tuple_1, tuple_1, dict_1, dict_1, tuple_1, str_1)
    var_1 = action_run(set_1)
    var_2 = action_run({'msg': str_2})
    assert (var_1 == var_2)
    str_3 = 'var'
    str_4 = 'var'
    var_3 = action_run({str_3: str_4})
    str_5 = 'var'

# Generated at 2022-06-25 06:39:34.439054
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case 0:
    from ansible.module_utils._text import to_bytes
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    bytes_1 = b'\xaa\xd4\x1d\x06\x81\x8d\x9f\x91"\xeb'
    bytes_2 = b'OX\x1f\x0e\x1dI\x9a\xde\x94\xe8\xf2'
    dict_0 = {}
    int_0 = -1414295835
    int_1 = -2122307792
    int_2 = 1726287916
    int_3 = 1288621259
    int_4 = -26718457
    int_

# Generated at 2022-06-25 06:39:46.037025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = (b'\x8f]\xfa\x81\xf4\x90',)
    dict_0 = {}
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, '}R')

if __name__ == '__main__':
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from units.mock.patch import Patch

    patch_obj = Patch()
    patch_obj.target = "ansible.plugins.action.ActionBase.run"
    patch_obj.object = ActionBase
    patch_obj.patch_method = patch_obj.get_original

# Generated at 2022-06-25 06:39:52.821531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    var_0 = action_module_0


# Generated at 2022-06-25 06:39:59.824232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (None,)
    dict_0 = {}
    str_0 = ']\xeb\x9e>\x1e\x85\xc2\xce'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    action_run(action_module_0)


# Generated at 2022-06-25 06:40:06.959953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    record_0 = action_run(set_0)
    assert record_0 == {'msg': 'Hello world!', '_ansible_verbose_always': True}
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)

# Generated at 2022-06-25 06:40:07.996228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:40:16.123750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xe6\xb0\xa0\x06\x1b\x02\x1fU\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    action_module_0.run(set_0, dict_0)


# Generated at 2022-06-25 06:40:21.653935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(set_0, tuple_0, dict_0, dict_0, tuple_0, str_0)


# Generated at 2022-06-25 06:40:28.956523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'E\xe6\x08\n\r\x8aP\xb3'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'X$2K\x14\x11Dp'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 06:41:02.157871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    var_0 = action_module_0.run(set_0)

test_case_0()

# Generated at 2022-06-25 06:41:05.697913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xb6\xcc\x91=Z\x97G\x98\xf9\x1a'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'Q6U`7Vu8'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)


# Generated at 2022-06-25 06:41:09.224821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# ansible.module_utils.basic._ANSIBLE_ARGS = None


# Generated at 2022-06-25 06:41:17.060633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_1 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    var_0 = action_module_1.run(set_0)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:41:23.527234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    var_0 = action_module_0.result
    var_0 = action_module_0.skipped
    var_0 = action_module_0.skipped_reason
    var_0 = action_module_0.changed


# Generated at 2022-06-25 06:41:25.825313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global set_0
    assert (False)


# Generated at 2022-06-25 06:41:33.738283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    action_module_1 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    # TODO: Test fails due to object comparison. See #39328
    # assert action_module_0 == action_module_1

# Generated at 2022-06-25 06:41:36.535753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = (0,)
    dict_1 = {}


# Generated at 2022-06-25 06:41:44.597550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    str_0 = 'SYb.aZ4vY&/Cp"'
    action_module_1 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    str_0 = 'B((sH4vY&/Cp"'

# Generated at 2022-06-25 06:41:53.904738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    var_0 = action_module_0.run()
    
    assert (var_0 == 'Hello world!')

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:42:50.135041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    var_0 = action_module_0.run(set_0)

# Tests the run method of class ActionModule

# Generated at 2022-06-25 06:42:52.566927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(10,False,True,10,False)
    str_0 = 'kwX'
    action_module_0.action_run(str_0)


# Generated at 2022-06-25 06:42:58.340091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)


# Generated at 2022-06-25 06:43:05.811033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    assert isinstance(action_module_0, action_module_0.__class__)
    assert hasattr(action_module_0, '_task')
    assert hasattr(action_module_0, '_connection')
    assert hasattr(action_module_0, '_play_context')

# Generated at 2022-06-25 06:43:10.199215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    assert type(action_module_0).__name__ == 'ActionModule'
    assert action_module_0._task.args.has_key('msg') != true

# Generated at 2022-06-25 06:43:17.071252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bytes_0 = b'\x1c\xdd\xcc\x10\xbb\x0c\xc7s\x8a\xa0\x19\xb1O'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '$Z.04h\n@\t\x16\x0f'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 06:43:23.094132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = None
    tuple_1 = (tuple_0,)
    dict_0 = {}
    str_0 = 'a'
    action_module_0 = ActionModule(tuple_0, tuple_1, dict_0, dict_0, tuple_1, str_0)
    assert(action_module_0.TRANSFERS_FILES == True)



# Generated at 2022-06-25 06:43:31.141583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg_0 = 'm`Sf-I\x84X\x17\x06\x0cU'
    var_0 = b'`\xae\x0e\xbb\xd5\xfd\x1f\xeb\xc2\xc8\x1e\xbf\x83\xaf\xef\xd6\xa9\xac\x9f\xcc\x86\x97\x1f\xfc\x1b7\xc5\x9e\x9d\x17\x81\r\xc2\xec\xde\x83\xc4\x8d\xa4\xab\x1a\xd0\xba\xdf\x06\xbd@p\xf9T'

# Generated at 2022-06-25 06:43:33.455519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance_0 = ActionModule(set(), set(), {}, {}, set(), "test")
    assert isinstance(instance_0, ActionModule)



# Generated at 2022-06-25 06:43:39.502630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bytes_0 = b'\xd1T"\x91E\x8b\x0c\xc4^'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '=>q\x02\xcf\xcc\xd0\xbb\xeb\xdb\xb1'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    assert isinstance(action_module_0.run(set_0), dict)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:45:49.533185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    var_0 = action_module_0.run(set_0)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 06:45:51.029279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = ''
    task_vars = ''
    # Run method of ActionModule with different arguments
    result = ActionModule.run(tmp, task_vars)


# Generated at 2022-06-25 06:46:00.201452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = u'VARIABLE IS NOT DEFINED!'
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    var_1 = action_run(set_0)
    del var_0, set_0, bytes_0, tuple_0, dict_0, str_0, action_module_0

# Generated at 2022-06-25 06:46:06.263783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    assert action_module_0._VALID_ARGS == frozenset(('msg', 'var', 'verbosity'))
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 06:46:12.719686
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Create object of class ActionModule to test
  set_0 = set()
  bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
  tuple_0 = (bytes_0,)
  dict_0 = {}
  str_0 = 'B((sH4vY&/Cp"'
  action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
  # Test call of method run of class ActionModule
  var_0 = action_module_0.run(set_0)



# Generated at 2022-06-25 06:46:16.289336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    list_0 = ['09']
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    tuple_0 = (bytes_0,)
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)


# Generated at 2022-06-25 06:46:23.229848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    action_module_0.action_run(set_0)


# Generated at 2022-06-25 06:46:28.820787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests that run () calls the run () function of ActionBase
    set_0 = set()
    bytes_0 = b'\xa7b\xbbS\x9c5\x90\x0e\x90'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = 'B((sH4vY&/Cp"'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)
    var_0 = action_module_0.run(set_0)

# Generated at 2022-06-25 06:46:34.601583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\x8e\x01\x92\xaa)\xe4\x9a\xcd\x1a\x85\xeb'
    tuple_0 = (bytes_0,)
    dict_0 = {}
    str_0 = '<'
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, dict_0, tuple_0, str_0)


# Generated at 2022-06-25 06:46:36.317898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert True
    except:
        print('Failure')
