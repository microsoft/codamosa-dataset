

# Generated at 2022-06-25 06:36:56.315984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #test case 0
    float_0 = 485.76337
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 499
    set_0 = {int_0}
    bytes_0 = b'k\x84='
    action_module_0 = ActionModule(dict_0, int_0, float_0, set_0, bytes_0, bytes_0)


# Generated at 2022-06-25 06:36:58.586219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Unit test for constructor of class ActionModule")
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:36:59.425129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:37:07.747084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 760.6
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 524
    set_0 = {int_0}
    bytes_0 = b'\x94\xea\xf6\x87\x99'
    action_module_0 = ActionModule(dict_0, int_0, float_0, set_0, bytes_0, bytes_0)
    float_1 = 669.25
    dict_1 = {float_1: float_1, float_1: float_1}
    int_1 = 582
    set_1 = {int_1}
    bytes_1 = b"'"

# Generated at 2022-06-25 06:37:13.755779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 470.3396
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 499
    set_0 = {int_0}
    bytes_0 = b'\t\xc8\x9d\x82'
    action_module_0 = ActionModule(dict_0, int_0, float_0, set_0, bytes_0, bytes_0)
    bool_0 = False
    action_module_0.run(bool_0)
    action_module_0.run(bool_0)
    action_module_0.run(bool_0)

# Generated at 2022-06-25 06:37:23.106204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {76.462449: 76.462449, 76.462449: 76.462449}
    int_0 = 545
    float_0 = 516.852251
    set_0 = {int_0}
    bytes_0 = b'\xd9K\x00\x00\x00\x00IEND\xaeB`\x82'
    bytes_1 = b'IEND\xaeB`\x82'
    action_module_0 = ActionModule(dict_0, int_0, float_0, set_0, bytes_0, bytes_1)


# Generated at 2022-06-25 06:37:29.007805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 3
    float_0 = 0.5
    set_0 = set()
    bytes_0 = b'\xf4L\xf0\x8a'
    bytes_1 = b'\x16\xc7\x9e\x03\x97\xbe\x99\x0b\x05'
    action_module_0 = ActionModule(dict_0, int_0, float_0, set_0, bytes_0, bytes_1)
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 06:37:39.735761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    float_0 = 485.76337
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 499
    set_0 = {int_0}
    bytes_0 = b'k\x84='
    action_module_0 = ActionModule(dict_0, int_0, float_0, set_0, bytes_0, bytes_0)
    bytes_1 = b'k\x84='

# Generated at 2022-06-25 06:37:45.579390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 485.76337
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 499
    set_0 = {int_0}
    bytes_0 = b'k\x84='
    action_module_0 = ActionModule(dict_0, int_0, float_0, set_0, bytes_0, bytes_0)


# Generated at 2022-06-25 06:37:58.314893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = 485.76337
    dict_1 = {float_1: float_1, float_1: float_1}
    int_1 = 499
    set_1 = {int_1}
    bytes_1 = b'k\x84='
    action_module_1 = ActionModule(dict_1, int_1, float_1, set_1, bytes_1, bytes_1)
    float_2 = 485.76337
    dict_2 = {float_2: float_2, float_2: float_2}
    int_2 = 499
    set_2 = {int_2}
    bytes_2 = b'k\x84='
    action_module_1.run(dict_2, int_2, (set_2, bytes_2), bytes_2)

# Generated at 2022-06-25 06:38:04.948609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 06:38:06.107766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule()


# Generated at 2022-06-25 06:38:08.850259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'Unit test for constructor of class ActionModule'
    var_0 = print(str_1)


# Generated at 2022-06-25 06:38:12.844576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Since __init__ method do nothing, and run method does not use instance
    # variables, a empty class is created for unit test
    class EmptyActionModule(ActionModule):
        def __init__(self):
            pass

        def run(self):
            pass

    test_case_0()


# Generated at 2022-06-25 06:38:18.962716
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case for when 'msg' and 'var' are incompatible options
    var_1 = ActionModule()
    var_2 = {'msg': True, 'var': True}
    var_3 = var_1.run(task_vars=var_2)
    var_4 = {'msg': u"'msg' and 'var' are incompatible options", 'failed': True}
    assert var_3 == var_4


if __name__ == '__main__':
    import sys
    import nose
    import logging

    logging.basicConfig(level=logging.DEBUG)

    params = ['-s', '-x', '--all-modules', '--with-coverage', '--cover-package=ansible.plugins.action']

    sys.argv.extend(params)

    nose.runmodule()

# Generated at 2022-06-25 06:38:19.774336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Test runner.

# Generated at 2022-06-25 06:38:22.096487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'Unit test for method run of class ActionModule'
    var_1 = print(str_1)

# Main method

# Generated at 2022-06-25 06:38:23.981351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:38:28.285881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {'msg': 'Hello', 'var': 'var_1'}
    obj_0 = ActionModule(tmp, task_vars)
    result = obj_0.run()
    print(result)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:38:31.255357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Unit test for constructor of class ActionModule'
    var_0 = print(str_0)
    str_0 = 'TODO: implement unit tests'
    var_0 = print(str_0)


# Generated at 2022-06-25 06:38:39.793131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == False


# Generated at 2022-06-25 06:38:41.705099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    print("Unit test of ActionModule is done.")

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:38:43.899383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.TRANSFERS_FILES == False
    assert module._VALID_ARGS == frozenset(("msg", "var", "verbosity"))

# Generated at 2022-06-25 06:38:47.911552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	action_module_1 = ActionModule()
	t = action_module_1.run()
	assert(t['skipped'] is True)
	assert(t['skipped_reason'] == 'Verbosity threshold not met.')
	assert(t['failed'] is False)

# Generated at 2022-06-25 06:38:54.551149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.deprecated_variables = dict()
    action_module_0.deprecated_variables['tags'] = [1, 2, 3]
    action_module_0.deprecated_variables['names'] = [2, 3, 4]
    action_module_0.deprecated_variables['ids'] = [3, 4, 5]
    action_module_0.deprecated_variables['frozenset'] = 'frozenset'


# Generated at 2022-06-25 06:38:56.961613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase) , \
    'ActionModule is not a subclass of ActionBase'
    return __name__ == '__main__'


# Generated at 2022-06-25 06:38:58.315517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:39:00.739532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    import nose2
    nose2.main()

# Generated at 2022-06-25 06:39:01.898404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    print("value:", action_module_0.run())



# Generated at 2022-06-25 06:39:03.510937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

    assert(action_module_1 is not None)

# Generated at 2022-06-25 06:39:16.068700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:39:18.142968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule() # Instantiate an object of type ActionModule


# Generated at 2022-06-25 06:39:22.630353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.verbosity == 0
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.run() == "Hello world!"

# Generated at 2022-06-25 06:39:23.386903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None

# Generated at 2022-06-25 06:39:27.885213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
#    action_module_0 = ActionModule()
#    tmp = 'TEST_VALUE_FOR_tmp'
#    task_vars = 'TEST_VALUE_FOR_task_vars'
#    action_module_0.run(tmp, task_vars)
    assert True == True


# Generated at 2022-06-25 06:39:37.583589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._task.args == {}, "action_module_0._task.args == {}"
    assert action_module_0._task.action != "notify", "action_module_0._task.action != \"notify\""
    assert action_module_0._shared_loader_obj == None, "action_module_0._shared_loader_obj == None"
    assert action_module_0._task.action == "debug", "action_module_0._task.action == \"debug\""
    assert action_module_0._task._role == None, "action_module_0._task._role == None"
    assert action_module_0._loader._all_files == {}, "action_module_0._loader._all_files == {}"
    assert action_

# Generated at 2022-06-25 06:39:47.968259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_0 = Mock()
    task_0.args = {}
    display_0 = Mock()
    display_0.verbosity = 238
    action_module_0 = ActionModule(task_0,display_0)
    assert action_module_0._task is task_0
    assert action_module_0._display is display_0
    assert action_module_0._connection is None
    assert action_module_0._loader is None
    assert action_module_0._templar is None
    assert action_module_0._shared_loader_obj is None
    assert action_module_0._task_vars is None

# test for run function: 'msg' in self._task.args and 'var' in self._task.args

# Generated at 2022-06-25 06:39:48.933726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(action_module_0)

# Test for run method

# Generated at 2022-06-25 06:39:50.217920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    assert action_module_1 != None


# Generated at 2022-06-25 06:39:56.941813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    testing_variable_0 = {}

    testing_variable_1 = {}

    testing_variable_2 = {}

    testing_variable_3 = {}

    testing_variable_4 = {}

    testing_variable_5 = {}

    testing_variable_6 = {}

    testing_variable_7 = {}

    testing_variable_8 = {}

    testing_variable_9 = {}

    testing_variable_10 = {}

    testing_variable_11 = {}

    testing_variable_12 = {}

    testing_variable_13 = {}

    testing_variable_14 = {}

    testing_variable_15 = {}

    testing_variable_16 = {}

    testing_variable_17 = {}

    testing_variable_18 = {}

    testing_variable_19 = {}

    testing_variable_20 = {}

# Generated at 2022-06-25 06:40:17.063236
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    str_0 = 'i9V{R-8|90uI7lzT3'
    bytes_0 = b'I\x98\xdf9\x85\x8b\x7f\x04\xab\x92\x8d\xad'
    dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
    action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)
    var_0 = action_module_0.run(dict_0)

# Generated at 2022-06-25 06:40:25.099999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '`b\xb8:H\x03\xaf\xaa\xc0\x9d\x84\x11\x10\x8f\x19\xbc'
    action_module_0 = ActionModule(str_0)
    str_1 = '_\xed;\xd1\xce\xfb\xab\x89\x9a\x12\x15\x91\x14\x99\x10'
    float_0 = 0.5
    action_module_1 = ActionModule(str_1, float_0)


# Generated at 2022-06-25 06:40:34.704797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global var_0
    float_0 = 0.5
    str_0 = 'P i\rs|6>?=P=A*t=f'
    bytes_0 = b'+U\x9b\x97W\xc6\x97\xad'
    dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
    action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)
    var_0 = action_module_0.run(float_0)
    assert var_0 == 0

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:40:35.341524
# Unit test for constructor of class ActionModule
def test_ActionModule():
  pass

# Generated at 2022-06-25 06:40:44.078861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    str_0 = '~'
    bytes_0 = b'\x13'
    dict_0 = {bytes_0: str_0, str_0: str_0, str_0: bytes_0, str_0: bytes_0}
    action_module_0 = ActionModule(str_0, float_0, float_0, float_0, float_0, float_0)
    var_0 = action_module_0.run(tmp=float_0, task_vars=dict_0)
#

# Generated at 2022-06-25 06:40:52.751233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    str_0 = 'P i\rs|6>?=P=A*t=f'
    bytes_0 = b'+U\x9b\x97W\xc6\x97\xad'
    dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
    action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)
    var_0 = action_module_0.run(float_0)
    assert var_0 == float_0

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:40:54.074689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, "var", None, None, None, None)



# Generated at 2022-06-25 06:40:55.766698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  float_0 = 0.5
  arg1 = float_0
  var_0 = run(arg1)


# Generated at 2022-06-25 06:41:02.591706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    str_0 = 'P i\rs|6>?=P=A*t=f'
    bytes_0 = b'+U\x9b\x97W\xc6\x97\xad'
    dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_3[str_0] = str_0
    dict_3[str_0] = dict_1
    dict_3[str_0] = str_0
    dict_3[str_0] = str_0
    dict_3[str_0] = dict_2

# Generated at 2022-06-25 06:41:04.736279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_0 = ActionModule('hello world', '', '', {}, {}, {})
    assert isinstance(class_0, object)
    assert isinstance(class_0, ActionBase)


# Generated at 2022-06-25 06:41:27.841438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 06:41:34.581492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    str_0 = 'P i\rs|6>?=P=A*t=f'
    bytes_0 = b'+U\x9b\x97W\xc6\x97\xad'
    dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
    action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)
    action_module_0.run(tmp=float_0)


# Generated at 2022-06-25 06:41:43.699548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '^a<,r;{'
    bytes_0 = b'o\xdb\x8d\xce\xfb\x9e'
    dict_0 = {str_0: bytes_0}
    dict_1 = {}
    dict_0 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_4 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}

# Generated at 2022-06-25 06:41:48.984426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    kwargs_0 = {}
    kwargs_0['task_vars'] = {'msg': 'Hello world!', 'failed': False, '_ansible_verbose_always': True}
    action_module_0 = ActionModule('Hello world!', kwargs_0)
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:41:50.605917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == expected_0

# Generated at 2022-06-25 06:41:53.818545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0) == assert_equals(action_module_0, expected_result_0))


# Generated at 2022-06-25 06:42:04.297293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    str_0 = 'P i\rs|6>?=P=A*t=f'
    bytes_0 = b'+U\x9b\x97W\xc6\x97\xad'
    dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
    dict_1 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
    dict_2 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}

# Generated at 2022-06-25 06:42:12.539075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    for var_0 in range(10):
        str_0 = 'P i\rs|6>?=P=A*t=f'
        bytes_0 = b'+U\x9b\x97W\xc6\x97\xad'
        dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
        action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)


# Generated at 2022-06-25 06:42:18.977558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe4\xd9\x8b\x81\xca\x14\xaa\xf8\xee\xc1\xa7L\xd9\xe8\xe2'
    str_0 = '('
    action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)
    float_0 = 0.5
    var_0 = action_run(float_0)


# Use this class to test ActionModule.run_async.

# Generated at 2022-06-25 06:42:24.080521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)
    assert action_module_0.task_name == 'test'
    assert action_module_0.loader == 'test'
    assert action_module_0.lookup_plugin == 'test'
    assert action_module_0.action_plugin == 'test'
    assert action_module_0.task == 'test'
    assert action_module_0.args == 'test'


# Generated at 2022-06-25 06:43:27.607843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global obj_ActionModule
    obj_ActionModule = ActionModule()


# Generated at 2022-06-25 06:43:29.799817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '+U\x9b\x97W\xc6\x97\xad'
    var_0 = ActionModule(str_0)


# Generated at 2022-06-25 06:43:35.510407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    str_0 = 'P i\rs|6>?=P=A*t=f'
    bytes_0 = b'+U\x9b\x97W\xc6\x97\xad'
    dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
    action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)



# Generated at 2022-06-25 06:43:43.910890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import string_types

    # Call function with arguments
    bytes_0 = b'D\x87\xf9\xaf\xa8\xac\x87'
    str_1 = 'Vf\xb6\x08e\xc9\xb5\xae'
    bytes_2 = b'r\xec\x8e\xcb\xad\xb9\x05'
    dict_0 = {bytes_0: str_1, bytes_0: bytes_2, str_1: str_1, bytes_0: bytes_2}
    dict_1 = {str_1: str_1, str_1: bytes_0, bytes_0: str_1, str_1: bytes_0}

# Generated at 2022-06-25 06:43:54.630906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # unit test for method run of class ActionModule
        float_0 = 0.5
        str_0 = 'P i\rs|6>?=P=A*t=f'
        bytes_0 = b'+U\x9b\x97W\xc6\x97\xad'
        dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
        action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)
        var_0 = action_module_0.run(float_0)
        assert var_0 is None # TypeError - Could not convert object of type to bytes
    except TypeError as e:
        print

# Generated at 2022-06-25 06:44:05.228640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5

# Generated at 2022-06-25 06:44:12.088587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test with correct parameters
    string_0 = 'F)3f$'
    bytes_0 = b'cGxlYXN1cmUu'
    dict_0 = {string_0: string_0, bytes_0: string_0}
    action_module_0 = ActionModule(string_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)
    var_0 = action_module_0.run(0.0, dict_0)
    assert(isinstance(var_0, dict))
    assert(len(var_0) == 3)
    assert(var_0['_ansible_verbose_always'] == True)
    assert(var_0['failed'] == False)
    assert(var_0['msg'] == 'Hello world!')

    # test with

# Generated at 2022-06-25 06:44:20.796232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0._task.args, dict)
    assert isinstance(action_module_0._connection, Connection) == False
    assert isinstance(action_module_0._display, Display) == False
    assert isinstance(action_module_0._loader, DataLoader) == False
    assert isinstance(action_module_0._templar, Templar) == False
    assert isinstance(action_module_0._shared_loader_obj, DataLoader) == False
    assert isinstance(action_module_0._task_vars, dict) == False
    assert isinstance(action_module_0._tmp, str) == False
    dict_0 = dict()
    dict_0['msg'] = 'Hello world!'

# Generated at 2022-06-25 06:44:28.883142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # str_0 = 'P i\rs|6>?=P=A*t=f'
    # bytes_0 = b'+U\x9b\x97W\xc6\x97\xad'
    # dict_0 = {bytes_0: bytes_0, str_0: str_0, bytes_0: str_0, bytes_0: str_0}
    # action_module_0 = ActionModule(str_0, bytes_0, bytes_0, dict_0, dict_0, dict_0)
    # assert action_module_0.run(0.5) == (b'Hello world!', False, True)

    action_module_0 = ActionModule('playbook', 'play_name', 'action', {'msg': 'Hello world!'}, {'verbosity': '0'}, {})

# Generated at 2022-06-25 06:44:36.062313
# Unit test for constructor of class ActionModule
def test_ActionModule():


    str_0 = 'i'
    float_0 = 0.85564562183
    bytes_0 = b'0\x8a\x1c\x00\x85WI\x84S\x0eM'
    list_0 = [b'{\x81\x0e\xad\x93', b'\xb1\xa5\xa9', b'0\x8a\x1c\x00\x85WI\x84S\x0eM']
    dict_0 = {list_0[1]: list_0[0], list_0[1]: list_0[0], list_0[1]: list_0[1], list_0[1]: list_0[2]}