

# Generated at 2022-06-14 17:06:04.322515
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from tf1 import TF1IE
    assert(TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')


# Generated at 2022-06-14 17:06:05.564961
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1=TF1IE()

# Generated at 2022-06-14 17:06:06.180367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-14 17:06:07.221596
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("1")

# Generated at 2022-06-14 17:06:09.953976
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE();
    ie._downloader.urlopen(ie._VALID_URL);

# Generated at 2022-06-14 17:06:10.546321
# Unit test for constructor of class TF1IE
def test_TF1IE():
	pass

# Generated at 2022-06-14 17:06:13.543098
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    tfie = TF1IE()
    assert tfie != None


# Generated at 2022-06-14 17:06:25.685122
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._TESTS[0]['info_dict']['tags'] == ['intégrale', 'quotidien', 'Replay']
    assert TF1IE._TESTS[0]['info_dict']['duration'] == 1738
    assert TF1IE._TES

# Generated at 2022-06-14 17:06:35.261191
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1 = TF1IE()
    assert tf1._VALID_URL == tf1._VALID_URL_TEST
    assert tf1._TESTS == tf1._TESTS_TEST
    assert tf1._real_extract(url) == tf1._real_extract_TEST(url)
    return 'Unit test completed !'


# Generated at 2022-06-14 17:06:38.803971
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-14 17:06:46.958557
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testClass = TF1IE('')
    try:
        testClass
    except:
        assert False, 'unit test for constructor of class TF1IE has failed.'

# Generated at 2022-06-14 17:06:50.223689
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE(url)._VALID_URL == url

# Generated at 2022-06-14 17:06:51.641587
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("")

# Generated at 2022-06-14 17:06:53.660501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Unit test for constructor of class TF1IE """
    TF1IE()

# Generated at 2022-06-14 17:06:54.688495
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()

# Generated at 2022-06-14 17:07:04.753651
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    # Assert that the link provided is valid and is working
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # Assert that the tests are correct

# Generated at 2022-06-14 17:07:12.350748
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    assert re.match(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html', url)
    assert True

# Generated at 2022-06-14 17:07:16.718836
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-14 17:07:20.848844
# Unit test for constructor of class TF1IE
def test_TF1IE():
    spider = TF1IE()
    assert spider._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-14 17:07:21.505143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-14 17:07:34.249611
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    obj = TF1IE() 


# Generated at 2022-06-14 17:07:35.258252
# Unit test for constructor of class TF1IE
def test_TF1IE():
  assert isinstance(TF1IE() , TF1IE)

# Generated at 2022-06-14 17:07:39.582154
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-14 17:07:46.356369
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == '(?:https?://)?(?:www\.)?wat\.tv/(?:videos/video|embed/iframe)/(?P<id>[0-9]+)(?:[?].*)?'
    assert TF1IE().IE_NAME == 'tf1'

# Generated at 2022-06-14 17:07:51.733604
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TypeError: __init__() takes at least 2 arguments (1 given)
    # IE_DESC = 'TF1'
    # IE_NAME = 'tf1'
    # _VALID_URL = r'https?://(?:www\.)?tf1\.fr/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # ie = TF1IE(IE_NAME, IE_DESC)

    # TypeError: __init__() takes at least 4 arguments (2 given)
    ie = TF1IE("TF1", "tf1", {}, None)

    assert ie.IE_NAME == "TF1"
    assert ie.IE_DESC == "tf1"

# Generated at 2022-06-14 17:07:52.860380
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-14 17:07:54.122683
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().ie_key() == 'tf1'

# Generated at 2022-06-14 17:08:02.326396
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import unittest
    class TF1IETest(unittest.TestCase):
        def test_temp(self):
            obj = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
            self.assertEqual("14343357",obj.id)
    unittest.main()


# Generated at 2022-06-14 17:08:04.082853
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(TF1IE._downloader, TF1IE._VALID_URL, {}, {})

# Generated at 2022-06-14 17:08:04.564660
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test loading of __init__.py
    pass

# Generated at 2022-06-14 17:08:35.677822
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Test of constructor of the class TF1IE.
    '''
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    # Call the constructor of class TF1IE
    t = TF1IE()
    val = t._real_extract(url)
    # We compare the program slug with its expected value
    assert val['_type']=='url_transparent', 'It is not a Wat video!'
    assert val['id']=='13641379', 'The video id does not match the expected value!'

# Generated at 2022-06-14 17:08:42.119898
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.get_info('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-14 17:08:44.344156
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert 'tf1' in tf1._VALID_URL

# Generated at 2022-06-14 17:08:44.940309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-14 17:08:56.331063
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-14 17:09:00.592635
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-14 17:09:09.572070
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Begin Test_TF1IE")
    # Imports
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../../..")
    from src.youtube_dl.tf1.TF1 import TF1IE

    wtf1ie = TF1IE()
    with open("TF1IE.json") as f:
        test_json = json.load(f)
    for element in test_json:
        actual_result = wtf1ie.extract(element["url"])
        expected_result = element["result"]
        assert actual_result == expected_result
    print ("End Test_TF1IE")


# Generated at 2022-06-14 17:09:15.545614
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE', 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-14 17:09:19.618983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-14 17:09:24.518111
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test valid inputs
    # Input: None
    # Expected output: instance of TF1IE
    test = InfoExtractor.get('TF1')
    assert isinstance(test, TF1IE)

    # Test invalid inputs
    # Input: str()
    # Expected output: raise an error
    try:
        test = InfoExtractor.get(str())
    except Exception:
        pass
    else:
        raise AssertionError('If I get here, I didn\'t raise an error')

# Generated at 2022-06-14 17:10:14.863437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert t!=None

# Generated at 2022-06-14 17:10:16.024406
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-14 17:10:17.542424
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-14 17:10:23.107323
# Unit test for constructor of class TF1IE
def test_TF1IE():
  # Test construction of class TF1IE
  url, expected_title = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'Koh-Lanta'
  t1_IE = TF1IE(url)
  assert_equals(expected_title, t1_IE.title)


# Test function _real_extract of class TF1IE

# Generated at 2022-06-14 17:10:23.856702
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None

# Generated at 2022-06-14 17:10:24.496932
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-14 17:10:25.109020
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-14 17:10:25.710192
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE()

# Generated at 2022-06-14 17:10:27.881494
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-14 17:10:36.194087
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print('\nTesting TF1IE')
    video = TF1IE()
    # Set the values for each key
    video.ie_key = 'TF1'
    video.video_id = '13641379'
    video.video_slug = 'quotidien-premiere-partie-11-juin-2019'
    video.program_slug = 'quotidien-avec-yann-barthes'
    video.url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-14 17:12:56.534073
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_downloader import get_testcases
    from .wittyfeed import WittyFeedIE
    for testcase in get_testcases(WittyFeedIE, {'extract_flat': 'in_playlist'}):
        testcase['url'] = TF1IE._VALID_URL % {'program_slug': testcase['_url_re'][0], 'id': testcase['_url_re'][1]}
        yield testcase

# Generated at 2022-06-14 17:12:57.281966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-14 17:12:57.821837
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-14 17:13:02.078659
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.IE_NAME == "tf1"
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-14 17:13:05.372191
# Unit test for constructor of class TF1IE
def test_TF1IE():
	given_TF1IE = TF1IE()
	assert given_TF1IE is not None


# Generated at 2022-06-14 17:13:06.299675
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-14 17:13:14.028988
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-14 17:13:21.152603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert isinstance(tf1.url, str)
    assert isinstance(tf1.program_slug, str)
    assert isinstance(tf1.slug, str)
    assert isinstance(tf1._VALID_URL, str)
    assert isinstance(tf1.program_slug, str)

# Generated at 2022-06-14 17:13:24.918247
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'grille.tf1.fr and wat.tv'

# Generated at 2022-06-14 17:13:25.821243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global tf1
    tf1 = TF1IE()