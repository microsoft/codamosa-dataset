

# Generated at 2022-06-22 08:18:41.877522
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.construct_url(
        ie._VALID_URL,
        'Koh-Lanta',
        'koh-lanta-22-mai-2015') == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-22 08:18:51.516711
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert t.title == "test titre"
    assert t.description == "test description"
    assert t.thumbnail == "test thumbnail"
    assert t.duration == "test duration"
    assert t.upload_date == "test upload_date"
    assert t.season_number == "test season_number"
    assert t.episode_number == "test episode_number"
    assert t.tags == "test tags"
    assert t.series == "test series"
    assert t.id == "test id"

# Generated at 2022-06-22 08:18:55.307868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie != None

# Generated at 2022-06-22 08:19:01.911616
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE.suitable(url)
    assert TF1IE(url)

# Generated at 2022-06-22 08:19:03.437348
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:19:11.395088
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst.get_url() == 'https://www.tf1.fr/graphql/web'
    assert inst.get_media().get_id() == '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'
    assert inst._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-22 08:19:13.327383
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # TODO
    return

# Generated at 2022-06-22 08:19:23.722546
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:19:34.764778
# Unit test for constructor of class TF1IE
def test_TF1IE():
    #case 1:
    #Test case 1 of the constructor of class TF1IE
    #Test the case in which a right url is given as parameter
    url = "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    tf1 = TF1IE(url)
    assert(tf1._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html")

# Generated at 2022-06-22 08:19:41.430170
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:19:49.650182
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().match("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:19:52.879759
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    instance = TF1IE(url)
    assert isinstance(instance, TF1IE)

# Generated at 2022-06-22 08:20:03.087749
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert tf1ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert tf1ie.suitable('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == True

# Generated at 2022-06-22 08:20:13.999484
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # Test it is initialized correctly
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0].get("url") == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie._TESTS[1].get("url") == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert ie._

# Generated at 2022-06-22 08:20:24.012497
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('TF1IE', 'tf1.fr')
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:26.907621
# Unit test for constructor of class TF1IE
def test_TF1IE():
    module = sys.modules[__name__]
    class_ = getattr(module, 'TF1IE')
    obj = class_(None)
    assert obj != None


# Generated at 2022-06-22 08:20:37.900306
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Correct test media
    correct = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    # Wrong test media
    wrong = 'https://www.tf1.fr/mediaplayer/video/xxxx'
    # TF1IE constructor test
    tf1ie = TF1IE('test')
    # Correct test
    assert tf1ie._VALID_URL == re.compile(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert tf1ie._match_id(correct) is not None
    assert tf1ie._match_id(wrong) is None
   

# Generated at 2022-06-22 08:20:43.330812
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from izi.utils import determine_ext

    # No exception should be thrown
    TF1IE({})

    # just to see what the constructor returns
    print(TF1IE({}))

    # just to see what the determine_ext function returns
    print(determine_ext(r'foo.bar'))
    print(determine_ext('bar.foo'))

# Generated at 2022-06-22 08:20:44.204960
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE({})


# Generated at 2022-06-22 08:20:54.196558
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("tf1.fr")
    assert(tf1.is_valid_url("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"))
    assert(tf1.is_valid_url("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"))
    assert(not tf1.is_valid_url("https://www.youtube.com/channel/UCHK5YvxIcL_8NyjRbX9Ndvw"))

# Generated at 2022-06-22 08:21:16.762071
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # Class instantiation
    class_instantiation = TF1IE(url)
    # Call of method _real_extract of class TF1IE
    result = class_instantiation._real_extract(url)
    # Asserts
    assert result['id'] == '13641379'
    assert result['ext'] == 'mp4'
    assert result['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'
    assert result['description'] == 'md5:a02cdb217141fb2d469d6216339b052f'

# Generated at 2022-06-22 08:21:18.161976
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('TF1IE')
    print(instance)

# Generated at 2022-06-22 08:21:19.236195
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:21:26.630013
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._test_url("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", 
        "http://wat.tv/get/android/{program_id}/{video_id}".format(program_id = "b60be0cad06fc69e5c5b", video_id = "9u5fkx"),
        "Koh Lanta : L'Île des Héros - La première étape de l'aventure commence", 
        "Koh Lanta : L'Île des Héros - La première étape de l'aventure commence", 
        None, True, False)

# Generated at 2022-06-22 08:21:37.077894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TF1IE test case 1
    test_case_1 = TF1IE()
    _VALID_URL_1 = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    test_case_1._real_extract(_VALID_URL_1)
    # TF1IE test case 2
    test_case_2 = TF1IE()
    _VALID_URL_2 = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    test_case_2._real_extract(_VALID_URL_2)
    # TF1IE test case 3


# Generated at 2022-06-22 08:21:40.496109
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:21:50.238560
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # regular case
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # url with a missing program slug
    assert tf1ie._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == {'_type': 'url_transparent', 'id': 'Replay:Koh-Lanta:22-mai-2015', 'tags': [], 'url': 'wat:Replay:Koh-Lanta:22-mai-2015'}

# Generated at 2022-06-22 08:21:52.111730
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    print(t)


# Generated at 2022-06-22 08:21:54.628312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """test_TF1IE"""
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-22 08:22:05.849697
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:22:30.657018
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:22:32.182339
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for class TF1IE
    assert TF1IE

# Generated at 2022-06-22 08:22:33.836546
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()


# Generated at 2022-06-22 08:22:34.721071
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:22:35.807079
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE().test()

# Generated at 2022-06-22 08:22:40.942124
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie.ie_key() == 'TF1')
    assert(ie._VALID_URL)
    assert(ie._TESTS)
    #assert(ie.BROWSER)

# Generated at 2022-06-22 08:22:43.138676
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-22 08:22:43.990700
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-22 08:22:44.830564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst is not None

# Generated at 2022-06-22 08:22:47.062209
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(None)

    assert (tf1.ie_key() == 'TF1')

# Generated at 2022-06-22 08:23:32.273584
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:23:35.050875
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('md5:4d842f7d5a5cac093526e4b8ee8b9fc9');

# Generated at 2022-06-22 08:23:37.743413
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:23:41.452774
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 != None
    assert tf1.ie_key() == 'TF1IE'
    assert tf1.ie_name() == 'TF1'

# Generated at 2022-06-22 08:23:52.904777
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:23:54.890322
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE", "tf1.fr")

# Generated at 2022-06-22 08:23:56.721287
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie_test = TF1IE()
    assert tf1_ie_test

# Generated at 2022-06-22 08:23:58.078993
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test if TF1IE is instantiated.
    """
    TF1IE()

# Generated at 2022-06-22 08:23:59.918868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-22 08:24:07.982000
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:10.000905
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:26:13.962523
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = InfoExtractor(TF1IE)
    assert ie.ie_key() == 'TF1'

# Generated at 2022-06-22 08:26:23.536271
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:26:31.571581
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert (ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'))
    assert not (ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015'))
    assert not (ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc'))

# Generated at 2022-06-22 08:26:33.236712
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """test the constructor TF1IE"""
    TF1IE()

# Generated at 2022-06-22 08:26:34.193660
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x

# Generated at 2022-06-22 08:26:38.457178
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE(None, None)
    except:
        assert False

if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-22 08:26:46.060447
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import unittest
    test_suites = unittest.TestLoader().loadTestsFromTestCase(TF1IE)

    # Load all tests in a test suite
    all_tests = unittest.TestSuite(test_suites)

    # Run all tests
    unittest.TextTestRunner(verbosity=2).run(all_tests)

# TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:26:50.163518
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        print(e)
        print(type(e))
        print(e.args)
        print(type(e.args))
        print(isinstance(e,Exception))

# Generated at 2022-06-22 08:26:53.192440
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    x = TF1IE('test')