

# Generated at 2022-06-22 08:18:42.970779
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    IE._VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:18:45.121090
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')



# Generated at 2022-06-22 08:18:54.692226
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # example url: https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html
    tf1 = TF1IE()
    matches = tf1._VALID_URL_RE.findall('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert matches[0][0] == 'tf1/koh-lanta'
    assert matches[0][1] == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-22 08:18:55.539497
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    return t

# Generated at 2022-06-22 08:19:06.590076
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Tests the constructor of the class TF1IE
    tf1_ie = TF1IE()
    # Checks the _VALID_URL attribute
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # Checks the _TESTS attribute

# Generated at 2022-06-22 08:19:17.258819
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with url
    url = 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1 = TF1IE(url)
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1.program_slug == 'quotidien-avec-yann-barthes'
    assert tf1.slug == "quotidien-premiere-partie-11-juin-2019.html"

# Generated at 2022-06-22 08:19:19.176427
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception:
        assert False
    assert True

# Generated at 2022-06-22 08:19:21.008351
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("\n ======= Test constructor of TF1IE ======= \n")
    return TF1IE()

# Generated at 2022-06-22 08:19:22.411843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Testing TF1IE object creation")
    assert TF1IE() is not None

# Generated at 2022-06-22 08:19:30.354693
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:49.141479
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test with a random url
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1_url = TF1IE()

    #check if the url field was correctly set
    assert tf1_url.url == url
    #check if the regex field was correctly set
    assert tf1_url._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:50.521374
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    except:
        return False
    return True

# Generated at 2022-06-22 08:20:00.011638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants
    from .common import extractor_constants

# Generated at 2022-06-22 08:20:02.984354
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test the constructor of class TF1IE. """
    tf1 = TF1IE()
    assert tf1



# Generated at 2022-06-22 08:20:03.473734
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:04.602970
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:20:10.237343
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert ie.IE_NAME == 'tf1'
    assert ie.VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:13.791087
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == \
            r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:18.657119
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print('Testing TF1IE constructor')
    IEClass = TF1IE
    my_IEClass = IEClass(IEClass.ie_key())
    ie = my_IEClass
    ie = my_IEClass({}, {})
    ie = my_IEClass({}, {}, {})
    print('Testing TF1IE constructor: Done')


# Generated at 2022-06-22 08:20:22.224511
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    # test for an existing program
    actual_result = tf1.IE_NAME in TF1IE.ie_key()

    assert actual_result == True

# Generated at 2022-06-22 08:20:44.372414
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor
    test_obj = TF1IE()
    # Check attrs
    assert test_obj._WORKING is True, 'Invalid _WORKING attr'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html', 'Invalid _VALID_URL attr'
    assert test_obj._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', 'Invalid _TESTS attr'

# Generated at 2022-06-22 08:20:47.327008
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(" ", " ")

# Generated at 2022-06-22 08:20:48.958294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.ie_key() == 'tf1'


# Generated at 2022-06-22 08:20:52.894504
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:20:54.286357
# Unit test for constructor of class TF1IE
def test_TF1IE():
	test_TF1IE = TF1IE()

test_TF1IE()

# Generated at 2022-06-22 08:20:55.897081
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print (TF1IE._VALID_URL)

# Generated at 2022-06-22 08:20:59.399498
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Assert that TF1IE is a subclass of InfoExtractor
    assert issubclass(
        TF1IE,
        InfoExtractor
    )


# Generated at 2022-06-22 08:21:01.764260
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE(None)
    assert isinstance(test, TF1IE)


# Generated at 2022-06-22 08:21:05.915289
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t1 = TF1IE()
    assert t1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:21:08.191873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_IE = TF1IE()
    tf1_IE.extract('test')

# Generated at 2022-06-22 08:21:34.162893
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test method constructor of class TF1IE
    """
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE()(url)

# Generated at 2022-06-22 08:21:35.198977
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("")


# Generated at 2022-06-22 08:21:40.285848
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:21:41.334648
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE())

# Generated at 2022-06-22 08:21:47.111977
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test class variables _VALID_URL and _TESTS
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert len(tf1IE._TESTS) == 3

    # Test _real_extract() method

# Generated at 2022-06-22 08:21:49.248419
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-22 08:21:59.356164
# Unit test for constructor of class TF1IE
def test_TF1IE():
	import sys
	sys.path.append(".")
	from TF1IE import TF1IE
	
	# Saves the ID of the url in id_, and downloads the data in the dictionary data_
	id_, data_ = TF1IE().extract_data_from_url("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
	assert id_ == "13641379"
	assert data_['_type'] == 'url_transparent'
	assert data_['id'] == "13641379"
	assert data_['url'] == "wat:13641379"

# Generated at 2022-06-22 08:22:04.716675
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:22:05.369299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:22:06.478408
# Unit test for constructor of class TF1IE
def test_TF1IE():
    the_test = TF1IE()
    assert the_test is not None

# Generated at 2022-06-22 08:23:06.617936
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert re.match(
        ie.url_re.pattern,
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:23:07.521478
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('r')

# Generated at 2022-06-22 08:23:09.013117
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE."""
    tf1IE = TF1IE()
    tf1IE

# Generated at 2022-06-22 08:23:10.832241
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    test_obj = "test"
    assert obj.suitable(test_obj) == False
    return

# Generated at 2022-06-22 08:23:15.373510
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# main (to be called if this program is executed)
if __name__ == '__main__':
    print(__name__)

# Generated at 2022-06-22 08:23:26.083176
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Instantiation of the instance to test
    instance_to_test = TF1IE()
    assert isinstance(instance_to_test, TF1IE)

    # Creation of a fake url
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"

    # Getting the expected result

# Generated at 2022-06-22 08:23:27.235254
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE(None)

# Generated at 2022-06-22 08:23:28.444832
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert test

# Generated at 2022-06-22 08:23:34.528201
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1IE.IE_NAME == 'tf1'
    assert hasattr(tf1IE, '_real_extract')

# Generated at 2022-06-22 08:23:37.318769
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None
    assert TF1IE._TESTS is not None
    assert TF1IE._download_json is not None

# Generated at 2022-06-22 08:25:47.685389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'



# Generated at 2022-06-22 08:25:56.117433
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE(None)
    assert x._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:07.772893
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE('www.tf1.fr', 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

    # test for _VALID_URL
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

    # test for _TESTS

# Generated at 2022-06-22 08:26:17.556921
# Unit test for constructor of class TF1IE
def test_TF1IE():
    input_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    expected_url = 'https://www.tf1.fr/tf1/quotidien-avec-yann-barthes/videos/replay-quotidien-premiere-partie-11-juin-2019.html'
    expected_delivery = 'wat'
    expected_program_slug = 'quotidien-avec-yann-barthes'
    expected_slug = 'replay-quotidien-premiere-partie-11-juin-2019'

    ie = TF1IE(input_url)

    assert ie.delivery == expected_delivery

# Generated at 2022-06-22 08:26:18.476177
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:26:30.299070
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:26:32.506689
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'


# Generated at 2022-06-22 08:26:38.106980
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()
    assert a
    assert a._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:39.677108
# Unit test for constructor of class TF1IE
def test_TF1IE():
    watid = TF1IE()
    assert(watid.ie_key() == 'wat')

# Generated at 2022-06-22 08:26:46.271885
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

    assert tf1IE.ie_key() == 'tf1', "TF1IE should have ie_key equal 'tf1'"
    assert tf1IE.ie_name() == 'TF1', "TF1IE should have ie_name equal 'TF1'"
    assert isinstance(tf1IE._VALID_URL, str), "TF1IE should have string valid URL match"
    assert isinstance(tf1IE._TESTS, list), "TF1IE should have test cases"