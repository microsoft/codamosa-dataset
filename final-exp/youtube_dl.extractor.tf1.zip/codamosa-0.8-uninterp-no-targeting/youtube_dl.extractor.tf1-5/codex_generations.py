

# Generated at 2022-06-22 08:18:42.156858
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.SUFFIX == r'/tf1/tf1/wiz-bienvenue/videos/1603899015.html'
    assert i.test() is True
    assert '57d7bb31f77b60af0b8b330f39e1c56d' in i._real_extract(i.SUFFIX)['title']
    assert i.num_entries == 1

# Generated at 2022-06-22 08:18:44.842547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/lc-i/videos/des-matelas-a-la-decouverte-du-pays-basque.html')

# Generated at 2022-06-22 08:18:47.273244
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor test
    """
    TF1IE("wat:v_13641379")

# Generated at 2022-06-22 08:18:48.281993
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE = constructor(TF1IE)

# Generated at 2022-06-22 08:18:51.709370
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert ie.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-22 08:18:55.529877
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:18:56.064792
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-22 08:19:09.055193
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:19:19.569374
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:25.279481
# Unit test for constructor of class TF1IE
def test_TF1IE():
    match = TF1IE._VALID_URL(TF1IE)
    assert 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html' == match.url
    assert 'koh-lanta' == match.program_slug
    assert 'replay-koh-lanta-22-mai-2015' == match.id

# Generated at 2022-06-22 08:19:34.646511
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    TF1IE()._real_initialize(url)

# Generated at 2022-06-22 08:19:45.910896
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:19:49.057706
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:19:49.609216
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:50.238213
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("")

# Generated at 2022-06-22 08:19:52.470211
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    assert test_TF1IE
    print("Unit test for constructor of class TF1IE passed")


# Generated at 2022-06-22 08:19:58.385526
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # Extract a video from a given URL
    assert ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    # Test that both the constructor and the WATIE are loaded correctly
    assert 'WatIE' in ie._ies and 'TF1IE' in ie._ies

# Generated at 2022-06-22 08:20:08.082876
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1.suitable('www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert tf1.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert tf1.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == True

# Generated at 2022-06-22 08:20:13.451485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:14.033205
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:20:24.854488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t

# Generated at 2022-06-22 08:20:27.530714
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-22 08:20:32.710664
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test constructor of TF1IE by checking if its attribute has been well initialized.
    """
    IE = TF1IE()
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:35.863735
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie.ie_key() == 'tf1'
    assert tf1_ie.ie_name() == 'tf1'

# Generated at 2022-06-22 08:20:40.048020
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:40.617722
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:47.827358
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    # Test quering for an invalid url
    with tf1.assertRaisesRegexp(ExtractorError, 'Invalid URL'):
        tf1.url_result('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai.html')
    # Test quering for a valid url
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1.url_result(url)

# Generated at 2022-06-22 08:20:48.530948
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:49.575336
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:50.820010
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-22 08:21:21.317362
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE(None)
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:21:23.446532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE."""
    TF1IE()

# Generated at 2022-06-22 08:21:25.081396
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)



# Generated at 2022-06-22 08:21:28.391191
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:21:32.740755
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert(tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-22 08:21:34.602794
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance._VALID_URL_TESTS()
    instance._TESTS()

# Generated at 2022-06-22 08:21:35.253810
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:21:38.822052
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except NameError:
        pass
    except:
        raise
    else:
        raise Exception('No exception raised when class is instantiated')

# Generated at 2022-06-22 08:21:43.052521
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Initialization of the class T01IE
    tf = TF1IE()
    # Test to check if the _TESTS array is initiliazed and no empty
    assert tf._TESTS is not None
    assert len(tf._TESTS) != 0


# Generated at 2022-06-22 08:21:44.129385
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TestTF1IE(TF1IE)



# Generated at 2022-06-22 08:22:27.833356
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Creation of a class TF1IE
    """
    ie = TF1IE()
    assert ie is not None

# Generated at 2022-06-22 08:22:29.960157
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test the TF1IE constructor
    """
    tf1ie = TF1IE()

# Generated at 2022-06-22 08:22:36.105158
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.IE_NAME == 'tf1'
    assert IE.IE_DESC == 'Tf1'
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:22:42.728471
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor_test(TF1IE, [
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ])

# Generated at 2022-06-22 08:22:43.705944
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-22 08:22:46.104823
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test if TF1IE can be constructed and if it has the correct class attribute
    assert_raises(
        AttributeError,
        TF1IE,
        'notanurl'
    )

# Generated at 2022-06-22 08:22:57.111852
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE("Test url")
    print(instance)
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert instance._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert instance._TESTS[1]['url'] == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert instance._T

# Generated at 2022-06-22 08:23:02.631613
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    test_tf1 = TF1IE()
    assert test_tf1.suitable(url) == True
    assert test_tf1._real_extract(url != None)

# Generated at 2022-06-22 08:23:06.111631
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:23:09.853802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:25:05.169045
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert t.get_info('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:25:16.571519
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL, "Checking if _VALID_URL property is assigned a value."
    assert tf1._downloader.params["nocheckcertificate"]
    assert tf1._TESTS, "Checking if _TESTS property is assigned a value."
    assert tf1.IE_NAME, "Checking if IE_NAME property is assigned a value."
    assert not tf1.BR_DESC, "Checking if BR_DESC property is not assigned a value."
    assert tf1.BUILD_ID, "Checking if BUILD_ID property is assigned a value."
    assert not tf1.BUILD_LOCALE, "Checking if BUILD_LOCALE property is not assigned a value."

# Generated at 2022-06-22 08:25:25.003630
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for https://www.tf1.fr/tf1/les-feux-de-l-amour/videos/replay-les-feux-de-l-amour-5766-du-27-juin.html
    url = 'https://www.tf1.fr/tf1/les-feux-de-l-amour/videos/replay-les-feux-de-l-amour-5766-du-27-juin.html'

# Generated at 2022-06-22 08:25:28.797020
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie._VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:25:29.382335
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-22 08:25:33.845438
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract_url('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:25:39.076917
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:25:45.116272
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("TF1IE", "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert( ie == True )


# Generated at 2022-06-22 08:25:49.639843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    InfoExtractor.test_video_class('tf1', TF1IE)

# Generated at 2022-06-22 08:26:01.278633
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor throws an exception for bad URL
    for bad_url in ['foobar', 'http://www.tf1.fr/tmc/bad-url.html']:
        try:
            TF1IE().suitable(bad_url)
        except Exception:
            pass
        else:
            assert False, "URL '%s' should have failed" % bad_url

    # Test the main case
    main_testcode = 'TmcReplayIE.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")'
    try:
        exec(main_testcode)
    except Exception as e:
        assert False, "URL '%s' should have passed (%s)"