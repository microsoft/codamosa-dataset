

# Generated at 2022-06-22 08:18:42.281745
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:18:43.915200
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE(InfoExtractor())
    assert tf1IE != None

# Generated at 2022-06-22 08:18:47.023453
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor())._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-22 08:18:48.431223
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.name == 'tf1'

# Generated at 2022-06-22 08:18:49.455410
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-22 08:18:55.626419
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'TF1'
    assert ie.IE_SHORT_NAME == 'TF1'
    assert ie.VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie.params == {'skip_download': True, 'format': 'bestvideo'}

# Generated at 2022-06-22 08:19:08.607370
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE()._real_extract("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert info["id"] == "13641379"
    assert info["ext"] == "mp4"
    assert info["title"] == "md5:f392bc52245dc5ad43771650c96fb620"
    assert info["description"] == "md5:a02cdb217141fb2d469d6216339b052f"
    assert info["upload_date"] == "20190611"
    assert info["timestamp"] == 1560273989
    assert info["duration"] == 1738

# Generated at 2022-06-22 08:19:10.625161
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()

# Generated at 2022-06-22 08:19:15.293412
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/vieo/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:19:24.793443
# Unit test for constructor of class TF1IE
def test_TF1IE():
    expected_test = {
        'id': '13641379',
        'ext': 'mp4',
        'title': 'md5:f392bc52245dc5ad43771650c96fb620',
        'description': 'md5:a02cdb217141fb2d469d6216339b052f',
        'upload_date': '20190611',
        'timestamp': 1560273989,
        'duration': 1738,
        'series': 'Quotidien avec Yann Barthès',
        'tags': ['intégrale', 'quotidien', 'Replay'],
    }

    assert TF1IE._TESTS[0]['info_dict'] == expected_test

# Generated at 2022-06-22 08:19:46.743587
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:47.358960
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:53.181619
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', None)
    assert ie.program_slug == 'quotidien-avec-yann-barthes'
    assert ie.id == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-22 08:19:55.377755
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        print("Error:", e)

# Generated at 2022-06-22 08:19:57.920524
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-22 08:20:01.248444
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    except Exception as e:
        assert False, e.args[0]

# Generated at 2022-06-22 08:20:02.667975
# Unit test for constructor of class TF1IE
def test_TF1IE():
    my_tf1 = TF1IE()

# Generated at 2022-06-22 08:20:10.147991
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test TF1IE constructor
    """
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tvshow = TF1IE()
    assert tvshow.suitable(url) == True
    assert tvshow._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-22 08:20:11.500299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE()
    assert infoExtractor is not None

# Generated at 2022-06-22 08:20:14.971475
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test constructor TF1IE 
    """
    TestTF1IE=TF1IE()
    assert TestTF1IE._VALID_URL
    assert TestTF1IE._TESTS
    assert TestTF1IE._real_extract

# Generated at 2022-06-22 08:20:37.594836
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    tf1IE = TF1IE(InfoExtractor())

# Generated at 2022-06-22 08:20:39.457794
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _test_TF1IE = TF1IE(None)
    print(_test_TF1IE)

# Generated at 2022-06-22 08:20:41.453636
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor test
    """
    assert TF1IE

# Generated at 2022-06-22 08:20:44.834865
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test the creation of a class by provide the expected url regular expression
    TF1IE(TF1IE.ie_key(), 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')



# Generated at 2022-06-22 08:20:46.721655
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:48.524192
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst=TF1IE()
    print (inst)


# Generated at 2022-06-22 08:20:49.575451
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-22 08:20:50.385488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:54.474703
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL_RE == re.compile(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-22 08:21:02.472787
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert a.url == 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-22 08:21:46.324608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('wat:13641379', 'wat', {})

# Generated at 2022-06-22 08:21:47.329979
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-22 08:21:52.319099
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    # This test should pass if the execution of the previous line ends normally.
    assert True

# Generated at 2022-06-22 08:21:56.445873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert isinstance(tf1, TF1IE)

# Generated at 2022-06-22 08:22:00.166771
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Unit test for constructor of class TF1IE """
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    pass

# Generated at 2022-06-22 08:22:04.445311
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:22:05.081137
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-22 08:22:07.822079
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:22:08.931257
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("")

# Generated at 2022-06-22 08:22:16.712948
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()

    # No tests for instance attributes
    #def test_init_fields(info_extractor):
    #    assert info_extractor._VALID_URL == ''
    #    assert info_extractor._downloader == None
    #    assert info_extractor._download_webpage = None

    test_constructor = info_extractor.__init__
    test_constructor(downloader=True)

    assert info_extractor._downloader == True

    # No tests for private attributes and instance attributes
    #def test_extract(info_extractor):
    #    assert info_extractor._real_extract == None

# Generated at 2022-06-22 08:23:13.678960
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie.url == url
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:23:16.689452
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test creating an instance of TF1IE."""
    tf1_ie = TF1IE(FOO_ARGS)
    assert tf1_ie

# Generated at 2022-06-22 08:23:20.416533
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of TF1IE."""
    _download_json = TF1IE._download_json
    TF1IE._download_json = lambda self, * args, **kwargs: {}
    try:
        obj = TF1IE(None)
    finally:
        TF1IE._download_json = _download_json

# Generated at 2022-06-22 08:23:23.458202
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:23:28.339806
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # self.assertRaises(ValueError, TF1IE, 'TS1')
    print("\n")
    # print(TF1IE.suitable(url))
    # print(TF1IE.extract(url))


test_TF1IE()

# Generated at 2022-06-22 08:23:29.317800
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t= TF1IE.TF1IE()

# Generated at 2022-06-22 08:23:32.973197
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("abc")
    assert (ie.ie_key() == 'TF1IE')
    assert (ie.video_id == "abc")
    assert (ie._VALID_URL == ie._TESTS[0]['url'])

# Generated at 2022-06-22 08:23:36.221062
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Check TF1IE constructor test.
    '''
    test_object = TF1IE()
    assert isinstance(test_object, TF1IE)


# Generated at 2022-06-22 08:23:37.610561
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    print(tf1ie)

# Generated at 2022-06-22 08:23:46.122949
# Unit test for constructor of class TF1IE
def test_TF1IE():
    data = {
        '_type': 'url_transparent',
        'id': '1234',
        'url': 'wat:1234',
        'title': 'Video title',
        'thumbnails': [{
            'url': 'http://example.com/thumbnail.jpg',
            'width': 100,
        }],
        'description': 'Video description',
        'timestamp': 1234,
        'duration': 123,
        'tags': ['tag1', 'tag2'],
        'series': 'Program name',
        'season_number': 12,
        'episode_number': 34,
    }
    TF1IE(data)

# Generated at 2022-06-22 08:25:48.665035
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:25:54.606364
# Unit test for constructor of class TF1IE
def test_TF1IE():
    with open("test_TF1IE.json") as f:
        # The json file must be in the same directory as this script
        args = json.load(f)
        f = TF1IE(args["url"])
        print ("\nURL: " + f.url + "\n")
        assert f.url == args["url"]
        print ("\nID: " + f.video_id + "\n")
        assert f.video_id == args["video_id"]
        assert f.title == args["title"]
        assert f.description == args["description"]
        assert f.thumbnail == args["thumbnail"]
        assert f.duration == args["duration"]
        assert f.view_count == args["view_count"]
        assert f.formats == args["formats"]

# Generated at 2022-06-22 08:25:57.967344
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__dict__['_VALID_URL']
    assert TF1IE.__dict__['IE_NAME']
    assert TF1IE.__dict__['_TESTS']

# Generated at 2022-06-22 08:25:59.055990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() != None


# Generated at 2022-06-22 08:26:01.243161
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst.constructor == TF1IE
    assert inst.constructor.__name__ == 'TF1IE'

# Generated at 2022-06-22 08:26:12.721856
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor
    from .wat import WATIE
    from .youtube import YoutubeIE

    # Test whether YouTubeIE is the first in successors of TF1IE
    ie = TF1IE(InfoExtractor())
    ie.succsessor = YoutubeIE(InfoExtractor())
    ie.succsessor.succsessor = WATIE(InfoExtractor())
    assert isinstance(ie.succsessor, YoutubeIE)

    # Test whether WATIE is the second in successors of TF1IE
    ie = TF1IE(InfoExtractor())
    ie.succsessor = WATIE(InfoExtractor())
    ie.succsessor.succsessor = YoutubeIE(InfoExtractor())
    assert isinstance(ie.succsessor.succsessor, WATIE)

# Generated at 2022-06-22 08:26:20.541605
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:24.901920
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    except:
        raise AssertionError("TF1IE constructor fails !")

# Generated at 2022-06-22 08:26:26.608788
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-22 08:26:27.270336
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE