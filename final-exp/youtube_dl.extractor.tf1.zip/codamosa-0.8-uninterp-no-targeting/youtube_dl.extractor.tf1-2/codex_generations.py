

# Generated at 2022-06-22 08:18:41.641325
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._download_json(
        "https://www.tf1.fr/graphql/web",
        "qwertyuiop",
        query={
            "id": "9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f",
            "variables": json.dumps({"programSlug": "program", "slug": "slug"})
        }
    )

# Generated at 2022-06-22 08:18:43.269508
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance != None
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-22 08:18:45.082638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global TF1IE
    TF1IE = TF1IE()
    assert (TF1IE is not None)


# Generated at 2022-06-22 08:18:49.123890
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE().extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert info['id'] == '13641379'

# Generated at 2022-06-22 08:18:50.001822
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-22 08:18:53.826218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Function to test the constructor of class TF1IE.
    """
    g = globals()
    for key in g:
        if key.startswith('TF1IE'):
            assert key in globals(), f'{key} not in globals'

# Generated at 2022-06-22 08:18:59.238486
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import datetime
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1IE = TF1IE(url, datetime.datetime.now())
    print(tf1IE)
    print(tf1IE.url)
    print(tf1IE.id)
    print(tf1IE.title)
    print(tf1IE.description)
    print(tf1IE.upload_date)
    print(tf1IE.thumbnails)
    print(tf1IE.timestamp)
    print(tf1IE.duration)
    print(tf1IE.series)
    print(tf1IE.tags)
    print(tf1IE.season_number)

# Generated at 2022-06-22 08:18:59.857081
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-22 08:19:02.129528
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test only the TF1IE constructor."""
    # Run the constructor
    TF1IE(None)

# Generated at 2022-06-22 08:19:02.794817
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:11.553295
# Unit test for constructor of class TF1IE
def test_TF1IE():
  """Test class constructor"""
  TF1IE('http://www.tf1.fr') == TF1IE('www.tf1.fr')

# Generated at 2022-06-22 08:19:14.951786
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.test(["https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"])

# Generated at 2022-06-22 08:19:17.852633
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:19:19.453600
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE == TF1IE

# Generated at 2022-06-22 08:19:24.016630
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url= "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    test = TF1IE()
    assert test.suitable(url)
    assert len(test._TESTS) == 3


# Generated at 2022-06-22 08:19:28.523327
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Construct an instance of class TF1IE for testing purposes
    ie = TF1IE()
    ie.ie_key()  # does nothing, but prevents pylint from complaining of unused function


# Generated at 2022-06-22 08:19:31.186100
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None
    assert TF1IE._TESTS is not None

# Generated at 2022-06-22 08:19:36.329359
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-22 08:19:38.689223
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test for passing instance of class TF1IE
    #asser
    instance = TF1IE(1)
    assert instance.name == 'tf1'

# Generated at 2022-06-22 08:19:43.131857
# Unit test for constructor of class TF1IE
def test_TF1IE():
    downloader = TF1IE()
    downloader.download("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:20:02.790645
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Instantiate TF1IE instance
    # tf1 = TF1IE()
    # tf1.sua
    # class_name = tf1.__class__.__name__
    # print(class_name)
    # class_name = type(tf1)
    # print(class_name)
    # import inspect
    # print(inspect.getmembers(tf1))
    # print(tf1.__class__.__dict__)
    # print(tf1.dir())
    # attrs = vars(tf1)
    # print ('\n'.join("%s: %s" % item for item in attrs.items()))
    pass

# Generated at 2022-06-22 08:20:08.034780
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-22 08:20:10.871243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    # print("ie",ie)
    print("ie.params",ie.params)
# test_TF1IE()

# Generated at 2022-06-22 08:20:18.352374
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')


# Generated at 2022-06-22 08:20:27.135044
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    url='https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE._download_json = lambda self, *args, **kwargs: json.load(open('test_data/tf1.json', 'r'))
    video = ie.extract(url)
    assert video['title'] == 'Quotidien du mercredi 12 juin 2019, 1ère partie'

test_TF1IE()

# Generated at 2022-06-22 08:20:31.318669
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    string = TF1IE._real_extract(url)
    print(string)

# Generated at 2022-06-22 08:20:38.222033
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert TF1IE.suitable(
            TF1IE._VALID_URL % ('quotidien-avec-yann-barthes', '13641379'))
        assert TF1IE.suitable(
            TF1IE._VALID_URL % ('koh-lanta', '13641379'))
        assert TF1IE.suitable(
            TF1IE._VALID_URL % ('mylene-farmer-d-une-icone', '13641379'))
    except AssertionError:
        raise AssertionError("Unit test(s) for constructor of class TF1IE failed!")

# Generated at 2022-06-22 08:20:43.398069
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('url')
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:53.451233
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-22 08:21:05.766575
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_constructor = getattr(TF1IE, 'suitable')
    # tf1:video_id
    assert class_constructor(TF1IE.ie_key(), 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html?xtor=EPR-109')
    # tf1:program_slug/video_id.html
    assert class_constructor(TF1IE.ie_key(), 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html?xtor=EPR-109')
    # tf1:program_slug/video_id
    assert class_constructor

# Generated at 2022-06-22 08:21:39.148348
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('wat:123', 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:21:40.866595
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-22 08:21:43.973938
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:21:48.081475
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == "TF1"
    assert t.VALID_URL.match("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")


# Generated at 2022-06-22 08:21:49.233094
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert 'TF1IE' == TF1IE.ie_key()

test_TF1IE()

# Generated at 2022-06-22 08:21:52.713331
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    tf1IE = TF1IE(TF1IE._downloader)
    tf1IE._real_extract(url)

# Generated at 2022-06-22 08:21:58.872632
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
# /Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:21:59.882668
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:22:03.682268
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("test_TF1IE")
    assert isinstance(tf1ie, TF1IE)

# Generated at 2022-06-22 08:22:05.490640
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:13641379')

# Generated at 2022-06-22 08:23:00.859826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('id')




# Generated at 2022-06-22 08:23:02.517462
# Unit test for constructor of class TF1IE
def test_TF1IE():
    mytf1 = TF1IE()
    assert mytf1 is not None

# Generated at 2022-06-22 08:23:04.338684
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert('TF1IE' == tf1ie._sort_key)

# Generated at 2022-06-22 08:23:09.013775
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None
    assert TF1IE._TESTS is not None

# Generated at 2022-06-22 08:23:11.017415
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract(None)

# Generated at 2022-06-22 08:23:13.744990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_constructor = TF1IE()

# Generated at 2022-06-22 08:23:18.327455
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(TF1IE.ie_key()).extract(
        'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-22 08:23:19.890563
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:23:23.498344
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:23:24.655225
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:25:32.435738
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:25:36.079007
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:25:37.857501
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:25:38.606608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-22 08:25:48.665057
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('wat:KdI2FF1DKkxn')
    assert ie.extractor_key() == 'TF1'
    assert ie.WAT_URL == 'https://wat.tf1.fr/wat/videos'
    wat_id = ie.extract_id('wat:KdI2FF1DKkxn')
    assert wat_id == 'KdI2FF1DKkxn'
    assert re.search(ie.VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:25:50.115512
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:25:56.246007
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie.AJAX_HEADERS == {b'Origin': b'https://www.tf1.fr'}
    assert tf1_ie.SUCCESS_REGEX == re.compile(b'^success$')

# Generated at 2022-06-22 08:25:58.784257
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""

    result = TF1IE()
    assert isinstance(result, TF1IE)


# Generated at 2022-06-22 08:26:02.844109
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:03.474696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()