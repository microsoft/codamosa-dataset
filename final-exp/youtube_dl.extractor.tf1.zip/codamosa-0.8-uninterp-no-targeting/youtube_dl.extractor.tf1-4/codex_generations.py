

# Generated at 2022-06-22 08:18:38.332859
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:18:41.283510
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:18:44.088876
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-22 08:18:46.306338
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()

# Generated at 2022-06-22 08:18:47.323420
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert(t)

# Generated at 2022-06-22 08:18:58.582497
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test parameters
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # Test constructor of class TF1IE
    ie = TF1IE(url)
    # Validate parameters
    assert ie.url.find('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') > 0
    assert ie.url.find('_id') > 0
    assert ie.url.find('_format') > 0
    assert ie.url.find('_channel') > 0
    assert ie.url.find('_publisher') > 0

# Generated at 2022-06-22 08:18:59.229487
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:19:02.047328
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for class TF1IE constructor
    """
    tf1 = TF1IE()
    assert bool(tf1)



# Generated at 2022-06-22 08:19:03.169637
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-22 08:19:11.480796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE({})
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'TF1'

# Generated at 2022-06-22 08:19:19.645869
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'tf1'
    assert ie.ie_key() in TF1IE.ie_key()


# Generated at 2022-06-22 08:19:21.058875
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.initialize()


# Generated at 2022-06-22 08:19:28.139634
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """
    TF1IE("md5:f392bc52245dc5ad43771650c96fb620", "md5:a02cdb217141fb2d469d6216339b052f", "1560273989", "1738", "Quotidien avec Yann Barthès", "13641379", "https://www.tf1.fr/graphql/web", "9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f")


# Generated at 2022-06-22 08:19:32.204643
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:19:41.856244
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor
    from .common import InfoExtractorTest
    from .common import parse_duration
    from .common import parse_iso8601
    from .common import unescapeHTML
    from .common import unsmuggle_url
    from ..utils import (
        int_or_none,
        parse_iso8601,
        try_get,
    )

    _VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:42.744542
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._download_json('', '')

# Generated at 2022-06-22 08:19:43.473559
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()
    print(result)

# Generated at 2022-06-22 08:19:44.541038
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-22 08:19:45.178550
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:51.794569
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.IE_NAME == 'tf1'
    assert obj.url_re == re.compile(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert obj.js_to_json == 'eval'

# Generated at 2022-06-22 08:20:06.177526
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_instance = TF1IE()
    assert test_instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:07.154175
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-22 08:20:17.196927
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    regex = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    program_slug = 'quotidien-avec-yann-barthes'
    slug = 'quotidien-premiere-partie-11-juin-2019'
    # Act
    instance = TF1IE(url)
    result_regex = instance._VALID_URL
    result_program_slug, result_slug = instance._real

# Generated at 2022-06-22 08:20:27.991267
# Unit test for constructor of class TF1IE
def test_TF1IE():
    query = {
        'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
        'variables': json.dumps({
            'programSlug': 'program_slug',
            'slug': 'slug',
        })
    }
    tf1_ie = TF1IE('http://www.tf1.fr/program_slug/videos/slug.html')
    assert tf1_ie._download_json(
        'https://www.tf1.fr/graphql/web', 'slug', query
    )['data']['videoBySlug']

# Generated at 2022-06-22 08:20:31.087064
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie != None

# Generated at 2022-06-22 08:20:31.797047
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-22 08:20:39.509135
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-22 08:20:41.454848
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1', 'TF1')



# Generated at 2022-06-22 08:20:43.097275
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(FakeYDL()).assert_success(FakeIE('tf1.fr'))

# Generated at 2022-06-22 08:20:45.641996
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global TF1IE
    ie = TF1IE
    global InfoExtractor
    InfoExtractor = IE
    object1 = ie("a")
    object2 = ie("a")
    assert object1 == object2

# Generated at 2022-06-22 08:21:08.190207
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("test")._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-22 08:21:11.804022
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert TF1IE._VALID_URL == tf1._VALID_URL
    assert TF1IE._TESTS == tf1._TESTS

# Generated at 2022-06-22 08:21:15.207199
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit Test for TF1IE"""
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    assert TF1IE()._TESTS == TF1IE._TESTS

# Generated at 2022-06-22 08:21:16.252788
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.i

# Generated at 2022-06-22 08:21:20.357021
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except TypeError:
        return False
    return True

# Generated at 2022-06-22 08:21:21.505761
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-22 08:21:23.377043
# Unit test for constructor of class TF1IE
def test_TF1IE():
    s = TF1IE()
    assert s is not None

# Generated at 2022-06-22 08:21:25.718464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE('TF1', 'tf1')
    assert isinstance(i, TF1IE)

# Generated at 2022-06-22 08:21:28.116472
# Unit test for constructor of class TF1IE
def test_TF1IE():
    name = "tf1"
    info_extractor = globals()[name + 'IE']()
    assert re.match(info_extractor._VALID_URL, url)

# Generated at 2022-06-22 08:21:31.312529
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.construct_url(None, ie._TESTS[0]['url'], ie._TESTS[0]['info_dict'])


# Generated at 2022-06-22 08:22:15.519955
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    tf1_ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:22:24.389696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert IE.description == 'md5:a02cdb217141fb2d469d6216339b052f'
    assert IE.id == '13641379'
    assert IE.tags == ['intégrale', 'quotidien', 'Replay']
    assert IE.title == 'Replay Koh-Lanta'
    assert IE.ext == 'mp4'
    assert IE.upload_date == '20190611'
    assert IE.timestamp == 1560273989
    assert IE.duration == 1738
    assert IE.series == 'Quotidien avec Yann Barthès'

# Generated at 2022-06-22 08:22:29.379320
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(initial_url='https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html' 

# Generated at 2022-06-22 08:22:30.702978
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj is not None

# Generated at 2022-06-22 08:22:32.943018
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert isinstance(tf1_ie, object)

# Generated at 2022-06-22 08:22:43.118171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert re.match(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html', 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:22:43.661606
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:22:45.441996
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj

if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-22 08:22:46.972365
# Unit test for constructor of class TF1IE
def test_TF1IE():
    v = TF1IE()

# Generated at 2022-06-22 08:22:52.623261
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    test_object = TF1IE(url)
    assert test_object.url == "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"

# Generated at 2022-06-22 08:24:39.641379
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(8, 'koh-lanta', "videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:24:40.708532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

# Generated at 2022-06-22 08:24:45.259148
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

    assert(tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-22 08:24:53.674044
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert ie._TESTS[0]['info_dict']['id'] == 13641379

# Generated at 2022-06-22 08:24:54.759517
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-22 08:25:04.827877
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_cases = [['https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'Replay Koh-Lanta - 22 mai 2015'],
                  ['http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'Replay Koh-Lanta - 22 mai 2015'],
                  ['http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', 'Mylène Farmer, d\'une icône']]
    for test_case in test_cases:
        test_url, expected_title = test_case
        real_extract_result = TF1IE

# Generated at 2022-06-22 08:25:08.833106
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-22 08:25:09.495171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:25:12.769347
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:25:16.859861
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('TF1IE', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',{})