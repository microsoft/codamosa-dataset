

# Generated at 2022-06-22 08:18:39.396501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    loader = TF1IE()
    assert TF1IE.suitable(loader.ie_key())
    assert TF1IE.IE_NAME == loader.ie_key()
    assert TF1IE.IE_DESC == loader.ie_key()

# Generated at 2022-06-22 08:18:50.880582
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:18:55.268731
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.tf1ie.real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:18:55.871706
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE()

# Generated at 2022-06-22 08:19:01.284382
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with wrong url
    TF1IE("http://tf1.fr")
    # Test with correct url
    TF1IE("http://tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:19:01.964579
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:03.063387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    aIE = TF1IE()

# Generated at 2022-06-22 08:19:05.097707
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable(TF1IE._TESTS[0]['url'])


# Generated at 2022-06-22 08:19:07.432803
# Unit test for constructor of class TF1IE
def test_TF1IE():
    object = TF1IE('test')
    expected =  'TF1IE'
    actual = object._TYPE
    assert expected == actual

# Generated at 2022-06-22 08:19:12.338642
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.name == 'tf1'

# Generated at 2022-06-22 08:19:28.802268
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:19:31.328760
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    print("Constructor of class TF1IE work correctly")


# Generated at 2022-06-22 08:19:33.594659
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE", {}, {'filename': "hello"})



# Generated at 2022-06-22 08:19:38.099745
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This is just a unit test for the constructor of the class,
    # so no need to fill in more parameters
    TF1IE('http://www.tf1.fr/dummy')



# Generated at 2022-06-22 08:19:41.060792
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.ie_key() == 'TF1'
    assert IE.ie_name() == 'TF1'

# Generated at 2022-06-22 08:19:46.457239
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_name = "TF1IE"
    Args = {
        "url": "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html",
    }
    klass = globals()[class_name]
    instance = klass(*(None,) * (len(klass.__bases__) + 2))
    res = instance.suitable(Args["url"])
    assert res, "suitable() failed on %s with url %s" % (class_name, Args["url"])

    instance = instance.extract(Args["url"])
    assert instance, "extract() failed on %s with url %s" % (class_name, Args["url"])

# Generated at 2022-06-22 08:19:48.637708
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.name == 'tf1'

# Generated at 2022-06-22 08:19:50.190852
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie.extract(test_TF1IE.__name__)

# Generated at 2022-06-22 08:19:52.097005
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == "TF1IE"

if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-22 08:20:01.429218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert t._TESTS[0]['info_dict']['id'] == '13641379'
    assert t._TESTS[0]['info_dict']['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'

# Generated at 2022-06-22 08:20:19.348703
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.set_cookiejar()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-22 08:20:20.077972
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:23.966798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from youtube_dl.utils import SearchInfoExtractor
    obj = SearchInfoExtractor()
    assert obj.ie_key() == 'TF1'
    assert obj.IE_NAME in globals()

# Generated at 2022-06-22 08:20:31.142370
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:20:35.005658
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE();
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:37.951961
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from ..utils import load_module
    IE = load_module(TF1IE, True)

    # Test for new instance of class TF1IE
    assert IE() is not None

# Generated at 2022-06-22 08:20:40.762344
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.suite()

# Generated at 2022-06-22 08:20:41.714849
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)

# Generated at 2022-06-22 08:20:44.122287
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test=".../videos/quotidien-premiere-partie-11-juin-2019.html"
    i=TF1IE()


# Generated at 2022-06-22 08:20:52.910025
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('foo')._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE('foo')._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE('foo')._TESTS[0]['info_dict']['id'] == '13641379'


# Generated at 2022-06-22 08:21:22.119460
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("test_TF1IE begins")
    url="https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    tf1ie = TF1IE(url)
    print("test_TF1IE ends")

# Generated at 2022-06-22 08:21:24.024351
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None).IE_NAME == 'tf1'

# Generated at 2022-06-22 08:21:30.789929
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor=TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    print(extractor.program_slug)
    print(extractor.slug)
    print(extractor.season_num)
    print(extractor.episode_num)
    
    
    
    


# Generated at 2022-06-22 08:21:32.204772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Test of TF1IE constructor
    '''
    TF1IE()

# Generated at 2022-06-22 08:21:36.675490
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test for success
    test_instance = TF1IE()
    assert test_instance != None

    # Test for negative assertions
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    test_instance.url_result(url)
    assert test_instance != None

# Generated at 2022-06-22 08:21:48.008880
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit_test = TF1IE()
    assert type(unit_test) == TF1IE
    assert unit_test._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:21:53.408383
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-22 08:21:54.180578
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(dict())
    assert tf1ie

# Generated at 2022-06-22 08:21:56.263060
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    _VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert i.regex.match(_VALID_URL)



# Generated at 2022-06-22 08:22:07.524186
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie.__name__ == 'tf1:tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert ie.IE_NAME == 'tf1'
    assert ie.http_headers == {}
    assert ie.host == 'www.tf1.fr'
    assert ie.ie_key() == 'tf1'


# Generated at 2022-06-22 08:23:10.737505
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:23:13.690438
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1ie = TF1IE()

# Generated at 2022-06-22 08:23:14.728542
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:23:16.539334
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie.ie_key()

# Generated at 2022-06-22 08:23:20.338281
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert obj._VALID_URL
    assert obj._TESTS
    assert obj._REAL_EXT

# Generated at 2022-06-22 08:23:21.459577
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:23:22.286711
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-22 08:23:28.358014
# Unit test for constructor of class TF1IE
def test_TF1IE():
    def test_constructor(url, expected_program_slug, expected_id, expected_host):
        tf1 = TF1IE(url)
        assert tf1._program_slug == expected_program_slug
        assert tf1._id == expected_id
        assert tf1._host == expected_host
    
    # This test is based on the article from 
    # https://www.w3ctech.com/topic/166
    test_constructor(
        "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
        "koh-lanta",
        "replay-koh-lanta-22-mai-2015",
        "www.tf1.fr")

# Generated at 2022-06-22 08:23:33.216749
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert(instance.name == 'tf1')
    assert(instance.ie_key() == 'tf1')

# Generated at 2022-06-22 08:23:35.656916
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert isinstance(tf1, TF1IE)


# Generated at 2022-06-22 08:25:47.556477
# Unit test for constructor of class TF1IE
def test_TF1IE():
    URL = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    TEST_CASE = [{
        'url': URL,
        'only_matching': True,
    }]
    ie = TF1IE()
    assert ie.suitable(URL)
    assert ie._VALID_URL == URL
    assert ie._TESTS == TEST_CASE


# Generated at 2022-06-22 08:25:48.054247
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:25:48.752355
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:25:58.884798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html");
    assert tf1ie.url == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html';
    assert tf1ie.id == 'TF1';
    assert tf1ie.name == 'TF1';
    assert tf1ie.state == '1';

# Generated at 2022-06-22 08:26:00.488662
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:26:01.634037
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:26:04.608819
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:26:05.211688
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:26:16.311294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:19.312380
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Constructor test of class.
    TF1IE inherits from InfoExtractor.
    '''
    ie = TF1IE()
    print(ie)