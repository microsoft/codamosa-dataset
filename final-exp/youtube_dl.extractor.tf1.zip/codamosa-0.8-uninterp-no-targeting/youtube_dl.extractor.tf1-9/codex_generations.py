

# Generated at 2022-06-22 08:18:36.873098
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:18:39.345438
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1'
    assert tf1.ie_name() == 'TF1'

# Generated at 2022-06-22 08:18:42.940681
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE.__doc__ == 'TF1.fr extractor'

# Generated at 2022-06-22 08:18:44.136863
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from wat.extractor.tf1 import TF1IE
    assert TF1IE

# Generated at 2022-06-22 08:18:51.188764
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie.ie_key() == 'tf1'
    assert tf1_ie.ie_desc() == 'TF1'
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:18:54.644009
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:18:55.289371
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:01.849117
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
        ok = True
    except:
        ok = False
    assert(ok)

# Generated at 2022-06-22 08:19:03.384314
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == TF1IE.ie_key()

# Generated at 2022-06-22 08:19:04.538767
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-22 08:19:15.974550
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_input = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    expected_output = "TF1IE(program_slug='quotidien-avec-yann-barthes', id='quotidien-premiere-partie-11-juin-2019')"
    assert str(TF1IE(test_input)) == expected_output, "Wrong constructor value"

# Generated at 2022-06-22 08:19:16.996702
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()
    assert(result)

# Generated at 2022-06-22 08:19:20.502453
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE.
    """
    from .common import InfoExtractor
    from .tf1 import TF1IE

    assert isinstance(TF1IE({}), InfoExtractor)



# Generated at 2022-06-22 08:19:22.530430
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test the constructor of class TF1IE """
    TF1IE()
    print("Passed constructor test class TF1IE")


# Generated at 2022-06-22 08:19:23.085485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:23.872110
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1ie = TF1IE('tp');

# Generated at 2022-06-22 08:19:24.865374
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().ie_key() == 'TF1'

# Generated at 2022-06-22 08:19:30.033711
# Unit test for constructor of class TF1IE
def test_TF1IE():
    handler = TF1IE()
    assert handler
    assert isinstance(handler, InfoExtractor)
    assert isinstance(handler, TF1IE)

# Test for method real_extract()

# Generated at 2022-06-22 08:19:35.167244
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:44.301464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    wat_id = "111927ed-8042-4e86-a8c1-7ff6370dae11"
    url = "http://www.wat.tv/video/quotidien-premiere-partie-11-juin-2019-13641379cw2l_.html"
    expected = {
        "_type": "url_transparent",
        "id": "111927ed-8042-4e86-a8c1-7ff6370dae11",
        "url": "wat:" + wat_id
    }
    assert TF1IE()._real_extract(url) == expected

# Generated at 2022-06-22 08:19:59.756021
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
        print("Unit test for tf1.py passes!\n")
    except:
        print("Unit test for tf1.py fails.\n")

# Generated at 2022-06-22 08:20:06.225575
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    config = {'extractor': "TF1IE"}
    extractor = InfoExtractor.get_info_extractor(url, config)
    assert isinstance(extractor, TF1IE)

# Generated at 2022-06-22 08:20:07.012437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:16.700549
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE.__doc__ == None

# Generated at 2022-06-22 08:20:21.009641
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:20:22.590083
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract({})

# Generated at 2022-06-22 08:20:24.333617
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.download(test_TF1IE.test_url)

# Generated at 2022-06-22 08:20:32.074287
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
          'Quotidien avec Yann Barthès', '13641379',
          'md5:f392bc52245dc5ad43771650c96fb620', 'md5:a02cdb217141fb2d469d6216339b052f', 'intégrale',
          'quotidien', 'Replay')

# Generated at 2022-06-22 08:20:32.713261
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:20:44.276309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:21:06.059095
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE({})
    assert t.ie_key() == 'tf1'

# Generated at 2022-06-22 08:21:09.987149
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # unit test for constructor of class TF1IE
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:21:13.566694
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert obj

# Generated at 2022-06-22 08:21:15.052076
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    print(tf1ie)

# Generated at 2022-06-22 08:21:20.614540
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import sys
    sys.path.append("..")
    from tests.test_youtube_dl import YoutubeDL
    ydl_opts = {}
    ydl = YoutubeDL(ydl_opts)
    (retCode, msg) = ydl.download(['https://www.tf1.fr/telefoot/videos/replay-telefoot-16-juin-2019.html'])
    assert(retCode == 0)

# Generated at 2022-06-22 08:21:24.794620
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-22 08:21:27.016637
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE("TF1IE", True)
    assert "TF1IE" == IE.ie_key()

# Generated at 2022-06-22 08:21:38.719438
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert TF1IE.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert not TF1IE.suitable("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/something-else.html")
    assert not TF1IE.suitable("https://www.youtube.com/watch?v=odmBmf7oQlQ")


# Generated at 2022-06-22 08:21:41.286443
# Unit test for constructor of class TF1IE
def test_TF1IE():
    module = 'TF1IE'
    c = getattr(__import__(module), module)
    d = c(None)
    assert d.test()

# Generated at 2022-06-22 08:21:43.742896
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except TypeError:
        return True
    else:
        raise TypeError('Test function failed.')

# Generated at 2022-06-22 08:22:38.109774
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    obj = ie.ie_key()
    assert obj == 'TF1', 'Test failed : wrong ie_key'
    ie_urls = [
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ]

# Generated at 2022-06-22 08:22:42.886704
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # URL with channel
    TF1IE('wat:90755036')

    # URL with channel and id
    TF1IE('wat:90755036/20150720T153509_90755036_102')

    # URL with channel, id and vod or replay
    TF1IE('wat:90755036/20150720T153509_90755036_102/vod')

# Generated at 2022-06-22 08:22:44.342165
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-22 08:22:48.340030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Verifies constructor of TF1IE works
    """
    test_class = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

    assert("TF1IE" in test_class.__class__)

# Generated at 2022-06-22 08:22:49.304222
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-22 08:22:49.887562
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:22:50.859129
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unittest.main()

# Generated at 2022-06-22 08:22:52.766012
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test.initialize()
    assert( isinstance(test, TF1IE) )

# Generated at 2022-06-22 08:22:56.593338
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')



# Generated at 2022-06-22 08:23:06.328336
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.get_id() == TF1IE.get_id()
    assert t.get_id() == 'TF1IE'
    assert t.get_name() == TF1IE.get_name()
    assert t.get_name() == 'TF1'
    assert t.get_description() == TF1IE.get_description()
    assert t.get_description() == "TF1 (l'une des chaînes de télévision généralistes françaises de référence, avec France 2, France 3 et Canal+) est une chaîne de télévision généraliste nationale française privée à vocation commerciale."
    assert t.get_query() == TF1IE.get_query()

# Generated at 2022-06-22 08:25:07.830181
# Unit test for constructor of class TF1IE
def test_TF1IE():
    example_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE(example_url)
    assert ie.get_id() == '13641379'
    assert ie.get_name() == 'md5:f392bc52245dc5ad43771650c96fb620'

# Generated at 2022-06-22 08:25:11.394817
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test for exist URL
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:25:16.145057
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE._download_json = lambda *args, **kwargs: {}
    TF1IE._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:25:20.219986
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"


# Generated at 2022-06-22 08:25:29.379698
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie_object = TF1IE()
    assert tf1ie_object._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:25:32.530391
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    assert TF1IE()._TESTS == TF1IE._TESTS

# Generated at 2022-06-22 08:25:34.007632
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ret = TF1IE()
    assert ret is not None



# Generated at 2022-06-22 08:25:36.408437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(None)
    assert obj is not None

# Generated at 2022-06-22 08:25:37.451247
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:25:38.902681
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)