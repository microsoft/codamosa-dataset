

# Generated at 2022-06-22 08:18:45.142835
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert tf1.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not tf1.suitable('https://www.google.fr')

# Generated at 2022-06-22 08:18:46.823605
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert isinstance(tf1, TF1IE)


# Generated at 2022-06-22 08:18:48.686370
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("test", "test")
    assert isinstance(tf1, TF1IE)

# Generated at 2022-06-22 08:18:57.690234
# Unit test for constructor of class TF1IE
def test_TF1IE():
    Unit_test = TF1IE()
    result = Unit_test.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert result == True
    result = Unit_test.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert result == True
    result = Unit_test.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert result == True

# Generated at 2022-06-22 08:19:03.870680
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract(url="https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:19:07.343970
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE().match('https://www.tf1.fr/tf1/the-voice/videos/the-voice-10-mai-2015.html')

# Generated at 2022-06-22 08:19:16.282891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_id = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    slugs = re.match(TF1IE._VALID_URL, video_id).groups()
    query = {
                'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
                'variables': json.dumps({
                    'programSlug': slugs[0],
                    'slug': slugs[1],
                })
            }

# Generated at 2022-06-22 08:19:16.786309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:25.281019
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if __file__.startswith('_'):
        return
    import sys
    import unittest

    from .test_common import test_class_common_behaviour

    class TestTF1IE(unittest.TestCase):
        # Test constructor of class TF1IE
        def test_constructor(self):
            test_class_common_behaviour(
                self, TF1IE, [
                    'tf1', 'https://www.tf1.fr/tf1/les-zamours/videos/les-zamours-mercredi-12-mars-2014.html', 'replay-les-zamours-mercredi-12-mars-2014.html'])

    unittest.main()

# Generated at 2022-06-22 08:19:27.429861
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__doc__ is not None


# Generated at 2022-06-22 08:19:34.130602
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.test()

# Generated at 2022-06-22 08:19:35.876947
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE()

# Generated at 2022-06-22 08:19:43.087139
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test TF1IE constructor."""
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie.url == url
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'
    assert ie.program_slug == 'tf1/koh-lanta'

# Generated at 2022-06-22 08:19:44.090707
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE("TF1IE")

# Generated at 2022-06-22 08:19:46.116369
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Simple test to initialize TF1IE.
    """
    TF1IE()


# Generated at 2022-06-22 08:19:47.764355
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-22 08:19:49.538830
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie is not None, "Error: constructor failed"

# Generated at 2022-06-22 08:19:51.073296
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    print(info_extractor.IE_NAME)

# Generated at 2022-06-22 08:19:52.630412
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert isinstance(obj, TF1IE)
# test type of obj

# Generated at 2022-06-22 08:19:53.186213
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:20:09.853809
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # From http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html
    assert TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-22 08:20:18.408708
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:22.267620
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:20:23.230802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-22 08:20:27.606913
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE(None)
    assert i._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:28.175514
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:20:35.307463
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_urls = ['https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
                'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html']
    for url in test_urls:
        assert TF1IE._VALID_URL.match(url) is not None

# Generated at 2022-06-22 08:20:36.435159
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testing_class = TF1IE()
    return testing_class

# Generated at 2022-06-22 08:20:38.735227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert(tf1IE)
    assert(tf1IE._VALID_URL)



# Generated at 2022-06-22 08:20:49.117801
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Use constructor of class TF1IE to create TF1IE object
    tf1 = TF1IE()

    assert (tf1._VALID_URL is
        None or isinstance(
        tf1._VALID_URL,
        (str, unicode))),\
        "The attribute '_VALID_URL' of class TF1IE is not a string"

    assert (tf1._TESTS is
        None or all(
        isinstance(element, dict) for element in tf1._TESTS)),\
        "The attribute '_TESTS' of class TF1IE contains an element which is not a dictionary"


# Generated at 2022-06-22 08:21:13.298982
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor of TF1IE
    test = TF1IE(None)
    assert(test)


# Generated at 2022-06-22 08:21:22.388440
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html'

# Generated at 2022-06-22 08:21:23.399415
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._TESTS

# Generated at 2022-06-22 08:21:24.279062
# Unit test for constructor of class TF1IE
def test_TF1IE():
  TF1IE()

# Generated at 2022-06-22 08:21:25.060923
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-22 08:21:25.722003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:21:37.252346
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()._real_extract(
        "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    )
    assert result["id"] == "13290113"
    assert result["title"] == "Koh-Lanta (1/2)"
    assert result["upload_date"] == "20150522"
    assert result["duration"] == 2640
    assert result["tags"] == [
        "intégrale",
        "koh-lanta",
        "Replay",
        "Vidéo",
    ]
    assert result["season_number"] == 16
    assert result["episode_number"] == 2
    assert result["series"] == "Koh-Lanta"

# Generated at 2022-06-22 08:21:41.128133
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_utils import init_test_unit
    from .wat import WatIE
    init_test_unit()
    assert TF1IE() is not None
    assert TF1IE() == WatIE()

# Generated at 2022-06-22 08:21:47.284295
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # Test using real data
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie.extract(url)
    # Test using returned values from a previous test
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie.extract(url)

# Generated at 2022-06-22 08:21:50.758395
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.md5 is None
    assert tf1ie.duration is None


# Generated at 2022-06-22 08:22:40.334230
# Unit test for constructor of class TF1IE
def test_TF1IE():

    TF1_object = TF1IE(InfoExtractor())
    data = TF1_object.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    print(data)

# Generated at 2022-06-22 08:22:45.831174
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"



# Generated at 2022-06-22 08:22:47.447341
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

# Generated at 2022-06-22 08:22:48.644299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)

# Generated at 2022-06-22 08:22:50.289215
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == TF1IE._VALID_URL


# Generated at 2022-06-22 08:22:50.908996
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:22:53.204830
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('http://www.tf1.fr/')
    assert tf1.IE_NAME == 'tf1'



# Generated at 2022-06-22 08:22:55.910377
# Unit test for constructor of class TF1IE
def test_TF1IE():
    Test = TF1IE("")
    Test.suite()

if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-22 08:22:59.527075
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infos = TF1IE()._extract_tf1_info('13641379')
    assert infos['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'

# Generated at 2022-06-22 08:23:08.499126
# Unit test for constructor of class TF1IE
def test_TF1IE():
    #For that test, the url should be a valid url of the class TF1IE
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE_test = TF1IE()
    #We verify that the url is recognized
    assert TF1IE_test._match_id(url) is not None
    #We verify that the returned object has the good type
    assert TF1IE_test.suitable(url)
    #We verify that the result of the extraction is not empty
    assert TF1IE_test.extract(url) is not None

# Generated at 2022-06-22 08:25:09.870210
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie is not None

# Generated at 2022-06-22 08:25:20.780772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    response = TF1IE().extract(url)

    assert response['_type'] == 'url_transparent'
    assert response['id'] == '13641379'
    assert response['url'] == 'wat:' + '13641379'
    assert response['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'
    assert response['description'] == 'md5:a02cdb217141fb2d469d6216339b052f'
    assert response['upload_date'] == '20190611'
    assert response['timestamp'] == 15602739

# Generated at 2022-06-22 08:25:23.336426
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create an instance of TF1IE
    tf1 = TF1IE()
    # Assert that the instance is of type InfoExtractor
    assert isinstance(tf1, InfoExtractor)


# Generated at 2022-06-22 08:25:28.140956
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:25:29.391992
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor of class TF1IE.
    """
    TF1IE()

# Generated at 2022-06-22 08:25:29.958138
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:25:31.549960
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-22 08:25:43.175942
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE('https://www.tf1.fr/tmc/quotidien/videos/quotidien-avec-yann-barthes-nouvelle-saison-du-8-juillet-2019.html')
    assert TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta.html')

# Generated at 2022-06-22 08:25:46.904759
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf = TF1IE()
    assert( tf._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html' )


# Generated at 2022-06-22 08:25:53.977495
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert obj.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html") == True
    assert obj.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html") == True
    assert obj.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html") == True