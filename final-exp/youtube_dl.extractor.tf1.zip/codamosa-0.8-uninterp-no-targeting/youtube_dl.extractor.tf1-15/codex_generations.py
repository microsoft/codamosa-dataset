

# Generated at 2022-06-22 08:18:35.994603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:18:36.954195
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract()

# Generated at 2022-06-22 08:18:39.034876
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(str(TF1IE) == "<class 'tf1.TF1IE'>")


# Generated at 2022-06-22 08:18:40.729262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("test_tf1").url == "test_tf1"

# Generated at 2022-06-22 08:18:41.338303
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:18:43.043173
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-22 08:18:54.232145
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit_test = TF1IE('tf1', 'tf1', 'tf1')
    unit_test._VALID_URL = TF1IE._VALID_URL
    unit_test._TESTS = TF1IE._TESTS
    unit_test._download_webpage = lambda url: 'url'
    unit_test._search_regex = lambda pattern, string, name, default: 'name'
    unit_test._sleep = lambda seconds: 'seconds'
    unit_test._html_search_regex = lambda pattern, string, name: 'name'
    unit_test._og_search_title = lambda webpage: 'title'
    unit_test._og_search_description = lambda webpage: 'description'
    unit_test._og_search_video_url = lambda webpage: 'video_url'
    unit_test._html_

# Generated at 2022-06-22 08:18:56.974723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert tf1.test() == True

# Generated at 2022-06-22 08:19:01.673709
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')



# Generated at 2022-06-22 08:19:11.996379
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.PLAYLIST_ENTRY_TEMPLATE == 'https://www.tf1.fr/graphql/web?id=937068b0d3ebd3f3cc7bcaa3bcf9c0a37f23d5c25b0adfef36c5d2d5aa21c1ba&variables=%7BvideoId%3A%22%s%22%2CpageNumber%3A%s%2CpageSize%3A%s%2CorderBy%3A%22RANKING%22%2Cfilter%3A%7Bstatuses%3A%5B%22PUBLISHED%22%5D%7D%7D'
    assert t.IE_NAME == 'TF1'

# Generated at 2022-06-22 08:19:26.181106
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE(None)
    # Test for the __init__ method
    assert IE.__dict__['_VALID_URL'] == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:27.187188
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_initialize()

# Generated at 2022-06-22 08:19:33.093989
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(
        TF1IE._downloader,
        TF1IE._downloader.params,
        TF1IE._VALID_URL)
    TF1IE(
        TF1IE._downloader,
        TF1IE._downloader.params,
        'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:19:33.824485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:35.437239
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:40.758354
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE(None)._real_initialize()
    assert info._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:41.759600
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-22 08:19:42.386150
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TestClass = TF1IE
    TestClass()

# Generated at 2022-06-22 08:19:43.065003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-22 08:19:44.762732
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE._TESTS[0])
    TF1IE = TF1IE()

# Generated at 2022-06-22 08:19:59.081290
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = TF1IE()
    print(tester)
    test = tester._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    print(test)

# Generated at 2022-06-22 08:20:09.780742
# Unit test for constructor of class TF1IE
def test_TF1IE():
    #Test_bad_url
    with pytest.raises(ExtractorError) as excinfo:
        TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert "Cannot identify player" in str(excinfo)

    #Test_good_url
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:20:13.694446
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        obj = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
        print(obj.__dict__.keys())
    except Exception as e:
        print(e)

# Generated at 2022-06-22 08:20:23.720485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('TF1IE', 'www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie.tf1_id == '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'
    assert ie.tf1_program_slug == 'quotidien-avec-yann-barthes'
    assert ie.tf1_slug == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-22 08:20:24.874908
# Unit test for constructor of class TF1IE
def test_TF1IE():
  test_instance = TF1IE()
  assert test_instance

# Generated at 2022-06-22 08:20:27.189308
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.set_downloader(None)
    assert ie.get_downloader() is None

# Generated at 2022-06-22 08:20:28.608658
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == "tf1.fr"

# Generated at 2022-06-22 08:20:29.554532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-22 08:20:38.570894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-22 08:20:48.285728
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    instance.expected_warning()

# Generated at 2022-06-22 08:21:10.522584
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-22 08:21:15.001814
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    testUrl = TF1IE(url)
    assert testUrl._VALID_URL == url


# Generated at 2022-06-22 08:21:19.071381
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_instance = TF1IE(None)
    assert tf1_instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:21:22.530242
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:21:25.718450
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:21:26.443028
# Unit test for constructor of class TF1IE
def test_TF1IE():
    T = TF1IE({})


# Generated at 2022-06-22 08:21:30.747773
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:21:42.451597
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test.url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert test.url == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', test.url
    assert test.program_slug == 'tmc/quotidien-avec-yann-barthes', test.program_slug
    assert test.slug == 'quotidien-premiere-partie-11-juin-2019', test.slug

# Generated at 2022-06-22 08:21:45.888717
# Unit test for constructor of class TF1IE
def test_TF1IE():

    class TestImplementation(TF1IE):
        pass

    ie = TestImplementation()

    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie.IE_NAME == 'tf1'

# Generated at 2022-06-22 08:21:47.146215
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except (ValueError, TypeError):
        raise AssertionError()

# Generated at 2022-06-22 08:22:30.552344
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:22:31.262579
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE()

# Generated at 2022-06-22 08:22:37.359002
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.IE_NAME == 'tf1'
    assert IE.IE_DESC == 'TF1'
    assert IE.VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:22:42.295042
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t.set_url(url)
    t.get_url()
    t.get_extractor()
    t.get_extractor(url)

# Generated at 2022-06-22 08:22:50.757422
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test cases with most important parameters
    test_cases = [
        {
            "url": "https://wat.tv/video/test_video_id_1.html"
            },
        {
            "url": "https://www.wat.tv/video/test_video_id_2.html"
            },
        ]
    for test_case in test_cases:
        url = test_case.get("url")
        assert url
        tf1_ie = TF1IE(url)
        assert tf1_ie.url == url
        assert tf1_ie.video_id == "test_video_id_2"
        assert tf1_ie.display_id == "test_video_id_2"
        assert tf1_ie.ie_key() == "WatTV"

# Generated at 2022-06-22 08:22:52.819461
# Unit test for constructor of class TF1IE
def test_TF1IE():
   tf1ie = TF1IE()
   assert tf1ie is not None


# Generated at 2022-06-22 08:23:04.079698
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test_1
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    test_1 = TF1IE(url)
    # test_2
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    test_2 = TF1IE(url)
    # test_3
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    test_3 = TF1IE(url)

# Generated at 2022-06-22 08:23:08.623218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE({'tf1': {'api_key': 'foo'}})

# Generated at 2022-06-22 08:23:11.052299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Test for initialisation of TF1IE class
    '''
    tf1 = TF1IE()
    assert tf1
    assert tf1.ie_key() == 'TF1'

# Generated at 2022-06-22 08:23:18.144922
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test the constructor of class TF1IE"""

    # No error should be raised when building an instance with a valid url
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert TF1IE(url) is not None

# Generated at 2022-06-22 08:25:15.947811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        pass


# Generated at 2022-06-22 08:25:18.659440
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-22 08:25:22.526182
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:25:33.418560
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:25:39.445903
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    tf1._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:25:42.341465
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1 = TF1IE()

# Generated at 2022-06-22 08:25:43.117097
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj_tf1 = TF1IE()

# Generated at 2022-06-22 08:25:51.327749
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit = TF1IE()
    assert unit._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:25:55.599409
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == TF1IE._VALID_URL
    assert obj._TESTS == TF1IE._TESTS

# Generated at 2022-06-22 08:26:07.205947
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Init TF1IE instance
    test_instance = TF1IE()
    # Check URL pattern
    assert re.match(TF1IE._VALID_URL, TF1IE._TESTS[0]['url'])
    # Check extraction of wat_id