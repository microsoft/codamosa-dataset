

# Generated at 2022-06-22 08:18:37.645352
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:18:40.772636
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html") == True


# Generated at 2022-06-22 08:18:44.542046
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if __name__ == '__main__':
        t = TF1IE()

# Generated at 2022-06-22 08:18:46.402691
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("watch", "wat")

# Generated at 2022-06-22 08:18:51.553044
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst.name == 'TF1'
    assert inst._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'



# Generated at 2022-06-22 08:18:53.528022
# Unit test for constructor of class TF1IE
def test_TF1IE():
     tf1 = TF1IE()

# Generated at 2022-06-22 08:18:56.339688
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:19:01.043319
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:19:06.473458
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testerIE = TF1IE()
    assert testerIE.ie_key() == 'tf1fr'
    assert testerIE.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not testerIE.suitable('http://www.tmc.com/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:19:14.023322
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not TF1IE.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:19:28.382015
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test build_request_body of class TF1IE."""
    program_slug = 'koh-lanta'
    slug = 'replay-koh-lanta-22-mai-2015'
    expected_request_body_data = \
        '{"id":"9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f","variables":{"programSlug":"%s","slug":"%s"}}' \
        % (program_slug, slug)

    tf1ie = TF1IE(None)
    request_body_data = tf1ie.build_request_body_data(program_slug, slug)
    assert request_body_data == expected_request_body_data

# Generated at 2022-06-22 08:19:29.928574
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:33.278820
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test constructor of TF1IE
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-22 08:19:42.579535
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-22 08:19:47.596173
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test constructor of TF1IE class.
    """
    t1 = TF1IE()
    assert t1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:52.634476
# Unit test for constructor of class TF1IE
def test_TF1IE():
	url_to_check = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
	tf1 = TF1IE(url_to_check)
	assert tf1 is not None
	assert tf1.tf1_url == url_to_check


# Generated at 2022-06-22 08:19:57.803456
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    TF1IE.constructor
    """
    # Should not raise a NameError
    try:
        TF1IE('', {})._real_extract('')
    except NameError:
        raise Exception('Constructor of class TF1IE should not raise a NameError')

# Generated at 2022-06-22 08:20:04.501733
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('TF1IE')
    assert(tf1ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-22 08:20:14.075041
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from youtube_dl.compat import compat_str
    from youtube_dl.utils import ExtractorError
    url = 'https://www.tf1.fr/d8/secret-story/videos/secret-story-replay-int%C3%A9grale-du-vendredi-17-juillet-2015.html'

# Generated at 2022-06-22 08:20:16.725212
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.get_id() is None
    assert i.get_id_videos() is None

# Generated at 2022-06-22 08:20:30.523070
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:20:37.423361
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:20:42.849765
# Unit test for constructor of class TF1IE
def test_TF1IE():
    args = ["https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"]

    TF1IE("TF1IE", *args)
    TF1IE("TF1IE", None, *args)

# Generated at 2022-06-22 08:20:44.483773
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        assert False, "TF1IE constructor crashed!"

# Generated at 2022-06-22 08:20:52.568812
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    assert(TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# End of function unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:20:54.287067
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Check if the constructor of TF1IE class is working fine.
    """
    TF1IE()

# Generated at 2022-06-22 08:21:01.399454
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    t = TF1IE()
    assert t.suitable(tf1_url) is True
    assert t.IE_NAME == 'tf1'
    assert t.valid_url(tf1_url) is True

# Generated at 2022-06-22 08:21:07.204399
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE({})
    except TypeError as e:
        assert False

    try:
        TF1IE(None, url='https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    except Exception as e:
        assert False


# Generated at 2022-06-22 08:21:08.704528
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert hasattr(TF1IE(object()),'_download_json')

# Generated at 2022-06-22 08:21:20.192598
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor raises exception if wat is not installed
    # Here, a fake wat is created, with return code 1
    try:
        from subprocess import call
        call('exit 1', shell=True)
    except ImportError:
        from subprocess import Popen
        Popen(['exit', '1'])
    import os
    os.environ['PATH'] += ':' + os.getcwd()
    os.mkdir('wat')

# Generated at 2022-06-22 08:21:43.414703
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-22 08:21:44.030869
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:21:50.494353
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test case 1
    test_TF1IE = TF1IE()
    # Test case 2
    test_TF1IE = TF1IE('test', '', {'test': 'test'})
    # Test case 3
    test_TF1IE = TF1IE('test', '', {'test': 'test'})
    # Test case 4
    test_TF1IE = TF1IE('test')
    # Test case 5
    test_TF1IE = TF1IE(1)
    # Test case 6
    test_TF1IE = TF1IE('test', 1)
    # Test case 7
    test_TF1IE = TF1IE('test', 1, 'test')
    test_TF1IE = TF1IE('test', 'test')

# Generated at 2022-06-22 08:21:51.364850
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:21:56.686907
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:22:07.971046
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:22:12.232894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(test_TF1IE.test_ie, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html').__name__ == 'TF1IE'

# Generated at 2022-06-22 08:22:16.824218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.name() == 'tf1'
    assert ie.IE_NAME == 'tf1'
    assert ie.VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie.LANG == 'fr'

# Generated at 2022-06-22 08:22:19.479833
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:22:31.123298
# Unit test for constructor of class TF1IE
def test_TF1IE():
    wat_id = '94705700'
    tf1ie1 = TF1IE.suitable('wat:94705700')
    tf1ie2 = TF1IE.suitable('http://wat.tv/video/94705700')
    assert(tf1ie1 is not None)
    assert(tf1ie2 is not None)
    assert(tf1ie1 == tf1ie2)
    assert(tf1ie1.ie_key() == tf1ie2.ie_key() == 'wat')
    assert(re.match(TF1IE._VALID_URL, tf1ie1.url_result('wat:' + wat_id)) is not None)

# Generated at 2022-06-22 08:23:07.903088
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.suitable('http://www.tf1.fr/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert not tf1.suitable('http://www.tf1.fr/')

# Generated at 2022-06-22 08:23:08.454004
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-22 08:23:13.081324
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructing instance of class TF1IE
    """
    t = TF1IE()
    assert isinstance(t, InfoExtractor)
    assert t.IE_NAME.find('tf1') != -1
    assert t._VALID_URL.find('tf1') != -1
    assert t.BROWSER_PARAMS.find('tf1') != -1
    assert t.BROWSER_HEADERS.find('tf1') != -1
    assert t.USER_AGENT_TEMPLATE.find('tf1') != -1

# Generated at 2022-06-22 08:23:18.849681
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import unittest
    
    class TestTF1IE(unittest.TestCase):
        def test_tf1(self):
            self.assertEqual(1,1)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestTF1IE)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-22 08:23:21.379965
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE(None)
    assert test_TF1IE

# Generated at 2022-06-22 08:23:23.209729
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except BaseException as e:
        print(e)

# Generated at 2022-06-22 08:23:25.238920
# Unit test for constructor of class TF1IE
def test_TF1IE():
    f = TF1IE()

# Generated at 2022-06-22 08:23:25.924092
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:id', {})


# Generated at 2022-06-22 08:23:31.085625
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.__class__.__name__ == "TF1IE"
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:23:42.901293
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie.url == "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:24:56.430811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (
        type(TF1IE().IE_NAME) == str
    )
    assert (
        TF1IE().IE_NAME == 'TF1'
    )
    assert (
        TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    )
    assert (
        len(TF1IE()._TESTS) == 3
    )
    assert (
        TF1IE()._TESTS[1]['only_matching'] is True
    )

# Generated at 2022-06-22 08:25:00.084098
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE({'tf1': 1})._TF1IE__init_tf1_ie_extractor() == {'tf1': 1}
    assert TF1IE(None)._TF1IE__init_tf1_ie_extractor() == {'tf1': 1}

# Generated at 2022-06-22 08:25:02.458389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie,TF1IE)

# Generated at 2022-06-22 08:25:07.064970
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    # Test if _VALID_URL is correctly set
    # Test if _TESTS is correctly set
    # _download_json should be able to return a dict from a GraphQL query

# Generated at 2022-06-22 08:25:08.491076
# Unit test for constructor of class TF1IE
def test_TF1IE():

    tf1 = TF1IE()

    assert tf1 is not None

# Generated at 2022-06-22 08:25:09.595183
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()

# Generated at 2022-06-22 08:25:11.838462
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-22 08:25:13.435848
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Initializes the class
    """
    TF1IE()

# Generated at 2022-06-22 08:25:16.715838
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    # Verify the expected instance variables exist
    assert t._VALID_URL is not None
    assert t._TESTS is not None


# Generated at 2022-06-22 08:25:21.082811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:27:25.242391
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-22 08:27:30.574944
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test1: test valid url
    test1 = TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert test1 == True

    # Test2: test invalid url
    test2 = TF1IE.suitable('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert test2 == False

# Generated at 2022-06-22 08:27:38.345052
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("TEST")._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:27:45.463310
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with a valid URL and skip_download
    assert True == TF1IE('wat:13641379')._download_webpage_handle(
        'wat:13641379', {'format': 'bestvideo'}).skip_download

    # Test with an invalid URL
    with pytest.raises(ExtractorError):
        TF1IE('wat:12345')._download_webpage_handle(
            'wat:12345', {'format': 'bestvideo'})

# Generated at 2022-06-22 08:27:57.202502
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'
    assert tf1.VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:27:59.274583
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie


# Generated at 2022-06-22 08:28:00.689667
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-22 08:28:03.407280
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:28:04.996042
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass


# Generated at 2022-06-22 08:28:05.520973
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE