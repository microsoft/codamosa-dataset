

# Generated at 2022-06-22 08:18:36.744363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:18:46.673683
# Unit test for constructor of class TF1IE
def test_TF1IE():
        url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
        ie = TF1IE
        assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
        assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-22 08:18:53.260924
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    This function is used to test the constructor of a TF1IE object.
    '''
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    object = TF1IE(url)
    print(object)


# Generated at 2022-06-22 08:18:53.856221
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:18:56.600131
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert obj is not None

# Generated at 2022-06-22 08:19:03.290912
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE()._fetch_webpage, object)
    assert isinstance(TF1IE()._download_json, object)
    assert isinstance(TF1IE()._real_extract, object)
    assert isinstance(TF1IE()._VALID_URL, object)
    assert isinstance(TF1IE()._TESTS, list)


# Generated at 2022-06-22 08:19:09.176557
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert not info_extractor.suitable("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:19:10.019768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:11.225792
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()

# Generated at 2022-06-22 08:19:22.458720
# Unit test for constructor of class TF1IE
def test_TF1IE():
    entry_instance = TF1IE()
    assert entry_instance._VALID_URL == re.compile(entry_instance._VALID_URL)

# Generated at 2022-06-22 08:19:30.406647
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test case for TF1IE constructor """
    TF1IE(InfoExtractor())

# Generated at 2022-06-22 08:19:35.932464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    construct_test(TF1IE, 0, {
        'url': 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'only_matching': True,
    })

# Generated at 2022-06-22 08:19:38.101301
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE.tf1ie = TF1IE()

test_TF1IE()

# Generated at 2022-06-22 08:19:42.257029
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:52.390333
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TF1IE constructor
    t = TF1IE()
    # TF1IE constructor with name
    t = TF1IE('name')
    # TF1IE constructor with name, url
    t = TF1IE('name', 'url')
    # TF1IE constructor with name, url and {}
    t = TF1IE('name', 'url', {})
    # TF1IE constructor with {} and name
    t = TF1IE({}, 'name')
    # TF1IE constructor with {}
    t = TF1IE({})
    # TF1IE constructor with url
    t = TF1IE('url')
    # TF1IE constructor with name, url and {'expected_status': 1}
    t = TF1IE('name', 'url', {'expected_status': 1})
    # TF1IE constructor with {'ie_key

# Generated at 2022-06-22 08:20:00.261749
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract_info("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    ie.extract_info("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    ie.extract_info("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-22 08:20:05.503877
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    # Accessing the public attributes of the test instance
    assert True

# Generated at 2022-06-22 08:20:09.007543
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import requests
    downloader = InfoExtractor()
    assert TF1IE(downloader, 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')



# Generated at 2022-06-22 08:20:09.964797
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat')

# Generated at 2022-06-22 08:20:13.817010
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
      TF1IE()
    except Exception as e:
      raise Exception('TF1IE constructor fails: %s' % e)

# Generated at 2022-06-22 08:20:35.219639
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:20:38.630001
# Unit test for constructor of class TF1IE
def test_TF1IE():
   TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:20:41.231818
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert 'TF1' == ie.IE_NAME

# Generated at 2022-06-22 08:20:42.894128
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("TF1IE")
    assert (tf1ie != None)

# Generated at 2022-06-22 08:20:47.440593
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0].keys() == {'url', 'info_dict', 'params', 'skip', 'skip_download'}

# Generated at 2022-06-22 08:20:48.192619
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-22 08:20:50.172823
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert( isinstance(tf1IE, InfoExtractor) )

# Generated at 2022-06-22 08:20:54.057164
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_IE = TF1IE('tf1_ie.TF1IE',{}, None)
    assert tf1_IE.ie_key() == 'TF1'
    assert len(tf1_IE.ie_key()) != 0

# Generated at 2022-06-22 08:20:54.773294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:21:00.997065
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie._VALUE_OBJECT["checksum"] == 'cc3f3c3e57d3b8a685f9ed9bcfa9bdfd'

# Generated at 2022-06-22 08:21:28.066464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == re.escape('https?://(?:www\.)?tf1\.fr/[^/]+/') + r'(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+).html'



# Generated at 2022-06-22 08:21:28.700160
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:21:29.754282
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()

# Generated at 2022-06-22 08:21:30.378033
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert True

# Generated at 2022-06-22 08:21:32.205261
# Unit test for constructor of class TF1IE
def test_TF1IE():
    c = TF1IE()
    c2 = TF1IE()
    assert c == c2

# Generated at 2022-06-22 08:21:43.973760
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:21:44.802740
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-22 08:21:47.429479
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_class = TF1IE('yt')
    assert test_class.ie_key() == 'tf1'

    # test that class TF1IE implements the method ie_key()

# Generated at 2022-06-22 08:21:50.475637
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE()
    assert isinstance(test_obj, TF1IE)

# Generated at 2022-06-22 08:21:51.358861
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-22 08:22:39.133941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Testing TF1IE for initialization")
    instance = TF1IE()
    assert instance



# Generated at 2022-06-22 08:22:40.528701
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-22 08:22:45.829308
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """
    # Tests with no exception raised
    assert TF1IE('') is not None
    # Tests with an exception raised
    # No exception should be raised
    assert TF1IE(' ') is not None

# Generated at 2022-06-22 08:22:49.262983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-22 08:22:54.825018
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test specification https://github.com/ytdl-org/youtube-dl/pull/19788#issuecomment-404047770
    tf1_ie = TF1IE(dict())
    {'value': 'wat'} == tf1_ie._downloader.params
    tf1_ie._downloader.params = {'wat': False}
    {'wat': False} == tf1_ie._downloader.params

# Generated at 2022-06-22 08:22:55.716851
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:22:57.411309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE(TF1IE()._downloader)


# Generated at 2022-06-22 08:22:58.072945
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:23:01.849861
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        tf1ie = TF1IE()
        assert tf1ie
    except:
        pass



# Generated at 2022-06-22 08:23:10.842099
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME.lower() == 'tf1'
    ie_class = ie.__class__
    assert ie_class._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:25:13.391478
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE()._real_extract == TF1IE._real_extract
    assert TF1IE()._TESTS == TF1IE._TESTS
    assert TF1IE().test()

# Generated at 2022-06-22 08:25:23.520437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_pattern = (r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html')
    test_class = TF1IE()

    assert (test_class._VALID_URL == test_pattern)
    assert (test_class._TESTS[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert (test_class._TESTS[0]['info_dict']['id'] == '13641379')

# Generated at 2022-06-22 08:25:28.621757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert type(ie) == TF1IE

# Generated at 2022-06-22 08:25:31.477769
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Run test for class TF1IE
    """
    tf1 = TF1IE()
    assert(tf1.__class__.__name__ == 'TF1IE')


# List of test to run for TF1IE

# Generated at 2022-06-22 08:25:35.925628
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('foo', 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:25:44.322750
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie.extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:25:44.871696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:25:50.668885
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tst = TF1IE()
    assert tst._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:25:51.829675
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:26:01.993448
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with the parameters of the first test of the TESTS constant
    ie = TF1IE()
    ie._downloader = None
    ie.url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie.program_slug = 'quotidien-avec-yann-barthes'
    ie.id = 'quotidien-premiere-partie-11-juin-2019'
    # Test with another url
    ie.url = 'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ie.program_slug = 'documentaire'
    ie.id