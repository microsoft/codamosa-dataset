

# Generated at 2022-06-22 08:18:38.794145
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class TF1IE"""
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-22 08:18:39.461099
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-22 08:18:50.918510
# Unit test for constructor of class TF1IE

# Generated at 2022-06-22 08:18:54.241894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('wat')
    tf1._real_extract('https://wat.tf1.com/wat/blabla')

# Generated at 2022-06-22 08:18:55.465038
# Unit test for constructor of class TF1IE
def test_TF1IE():
	sut = TF1IE()
	assert(sut is not None)

# Generated at 2022-06-22 08:18:59.077501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:19:02.294139
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    # Check if constructor returns correct instance
    assert(isinstance(tf1_ie, TF1IE))

# Generated at 2022-06-22 08:19:04.246488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    test = IE.ie_key()
    assert test == 'TF1'

# Generated at 2022-06-22 08:19:08.522082
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1IE = TF1IE(url)
    assert tf1IE.suitable(url)



# Generated at 2022-06-22 08:19:16.570671
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Calling without an url must fail
    with pytest.raises(TypeError):
        TF1IE()
    # Calling with an empty argument must fail
    with pytest.raises(AttributeError):
        TF1IE('')
    # Calling with an incorrect url must fail
    with pytest.raises(extractor.ExtractorError):
        TF1IE('https://www.tf1.fr/')
    # Calling with a correct url must succed
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:19:22.859915
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:25.324534
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        _obj = TF1IE()
    except Exception as e:
        raise AssertionError("Instance creation test failed for TF1IE class") from e


# Generated at 2022-06-22 08:19:35.074606
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL== r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1ie._TESTS[0]['url'] =='https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1ie._TESTS[0]['info_dict']['id']== '13641379'
    assert tf1ie._TESTS[0]['info_dict']['ext']== 'mp4'
    assert tf1ie._

# Generated at 2022-06-22 08:19:43.463025
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # First check if constructor of class TF1IE is indeed implemented

    ie = TF1IE(TestInfoExtractor.create_ytdl())
    assert isinstance(ie, TF1IE)

    # Second check if correct URL is returned for this test
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie.extract_url(url) == 'wat:13641379'

# Generated at 2022-06-22 08:19:43.921913
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:52.892179
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert result is not None
    assert result.group() == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert result.group('program_slug') == 'tf1/koh-lanta'
    assert result.group('id') == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-22 08:19:57.505903
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for constructor of class TF1IE
    """
    tf1 = TF1IE()
    assert tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:07.320314
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from tests.test_utils import create_test_app, with_httpretty
    from httpretty import HTTPretty

    @with_httpretty
    def dummy_callback(app):
        url = 'https://www.tf1.fr/graphql/web'

# Generated at 2022-06-22 08:20:10.446684
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE(None, 'TF1IE')
    assert tf1_ie.get_class('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == TF1IE

# Generated at 2022-06-22 08:20:13.321038
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)

# Generated at 2022-06-22 08:20:26.419033
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()
# end of class TF1IE

# Generated at 2022-06-22 08:20:27.101517
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:28.494501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t= TF1IE() 

test_TF1IE()

# Generated at 2022-06-22 08:20:33.065362
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_0 = TF1IE("h", "i")
    assert TF1IE_0._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:40.143523
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE("")
    tf1_ie.extract("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
#print(TF1IE().extract("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"))

# Generated at 2022-06-22 08:20:40.710824
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:41.322777
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:42.291551
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._real_extract()

# Generated at 2022-06-22 08:20:46.394986
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    raised = False
    try:
        tf1ie._real_extract(url)
    except:
        raised = True
    assert raised == False

# Generated at 2022-06-22 08:20:47.809640
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)



# Generated at 2022-06-22 08:21:18.464363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    wat_id = "56770983"
    program_slug = "koh-lanta"

    assert re.match(TF1IE._VALID_URL, url)


# Generated at 2022-06-22 08:21:19.608894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('')._VALID_URL

# Generated at 2022-06-22 08:21:24.610994
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract(url='https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract(url='http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:21:25.900802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, None)



# Generated at 2022-06-22 08:21:32.001387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == "tf1"
    assert t._VALID_URL == "(?i)(?:https?://)?(?:www\.)?tf1\.fr/(?:[^/]+/)*videos/(?P<id>[^/?&#]+)(?:\.html)?(?:\?.*)?"
    assert t.IE_DESC == "tf1.fr"

# Generated at 2022-06-22 08:21:32.633666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-22 08:21:35.301892
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor of TF1IE class
    tf1IE = TF1IE(None)

    # assert that tf1IE is a instance of TF1IE class
    assert tf1IE is not None

# Generated at 2022-06-22 08:21:40.025351
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor.ie_key() == 'tf1'
    assert extractor.IE_NAME == 'tf1'

# Generated at 2022-06-22 08:21:43.495171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor of class TF1IE
    """
    ie = TF1IE('www.tf1.fr')
    assert ie.SUCCESS == 'SUCCEEDED'

# Generated at 2022-06-22 08:21:44.930576
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie != None

# Generated at 2022-06-22 08:22:35.650661
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    # Constructor should not raise Exception
    assert IE
# Unit test to know if the class has a working _real_extract method

# Generated at 2022-06-22 08:22:45.408687
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f')
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t._downloader.params.get('noplaylist') is True

# Generated at 2022-06-22 08:22:49.173337
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'tf1'
    assert ie.ie_name() == 'TF1'
    assert ie.supported_domains == ['tf1.fr']



# Generated at 2022-06-22 08:23:00.538183
# Unit test for constructor of class TF1IE
def test_TF1IE():
    klass = TF1IE

# Generated at 2022-06-22 08:23:03.392785
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:23:10.201465
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('TF1IE', 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', {'format': 'bestvideo'})
    assert instance.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert instance.IE_NAME == 'TF1'
    assert instance.IE_DESC == 'Dailymotion, TF1, TMC, TFX and TF1 Séries Films'

# Generated at 2022-06-22 08:23:13.852897
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-22 08:23:16.428914
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-22 08:23:18.293547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tF1IE = TF1IE()
    assert isinstance(tF1IE, InfoExtractor)

# Generated at 2022-06-22 08:23:27.422894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import unittest
    import requests
    import json

    class testTF1IE(unittest.TestCase):

        def setUp(self):
            self.request_files_urls = [
                'https://www.tf1.fr/graphql/web?id=9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f&variables=%7B%22programSlug%22%3A%22koh-lanta%22%2C%22slug%22%3A%22replay-koh-lanta-22-mai-2015%22%7D'
            ]

# Generated at 2022-06-22 08:25:36.458284
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-22 08:25:41.301885
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE.TF1IE(None)

    # Test default values of variables
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:25:47.263520
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().support_url(r'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html').support_url(r'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:25:55.644690
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = {
        'slug': 'this-is-a-video',
        'title': 'This is a video',
        'streamId': '123456',
        'date': '2015-12-24T22:00:00+01:00',
        'tags': [{'label': 'foo'}],
        'programLabel': 'Foo show',
        'season': '1',
        'episode': '2',
        'publicPlayingInfos': {'duration': 987},
        'decoration': {
            'description': 'Hello there',
            'image': {
                'sources': [{
                    'url': 'http://www.tf1.fr/thumbnail.jpg',
                    'width': 480,
                }],
            },
        },
    }
    info_dict = TF1IE._

# Generated at 2022-06-22 08:25:56.641578
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-22 08:25:57.207705
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:26:05.259058
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test case 1
    program_slug: str = "test_program_slug"
    slug: str = "test_slug"
    # Expected result (return value)
    expected_result = re.compile(r'^https?://(?:www\.)?tf1\.fr/[^/]+/{0}/videos/{1}\.html$'\
        .format(re.escape(program_slug), re.escape(slug)))

    # Test case 1
    # Assertion
    assert TF1IE._VALID_URL.match(expected_result.pattern)

# Generated at 2022-06-22 08:26:13.536748
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # RSTDOC: Unit test for constructor of class TF1IE
    assert TF1IE("tf1.fr", "TF1IE.test_TF1IE()").host == "www.tf1.fr"
    assert TF1IE("tf1.fr", "TF1IE.test_TF1IE()")._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:15.425702
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert isinstance(tf1ie, TF1IE)

# Generated at 2022-06-22 08:26:19.672509
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
