

# Generated at 2022-06-22 08:18:43.269741
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    m = re.match(ie._VALID_URL, "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert m and m.group('program_slug') == 'quotidien-avec-yann-barthes' and m.group('id') == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-22 08:18:44.493445
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor.TF1IE

# Generated at 2022-06-22 08:18:46.412798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()



# Generated at 2022-06-22 08:18:48.688120
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_youtube_dl import FakeYoutubeDL
    youtube_dl = FakeYoutubeDL({})
    TF1IE(youtube_dl)

# Generated at 2022-06-22 08:18:50.535145
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("tf1")
    assert tf1ie.name == "tf1"

# Generated at 2022-06-22 08:18:51.141370
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:18:58.326312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_urls = ["http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
        "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"]
    for url in test_urls:
        tf1 = TF1IE(url)
        assert tf1.name == 'TF1'

# Generated at 2022-06-22 08:19:05.830414
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')



# Generated at 2022-06-22 08:19:07.964717
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create a test TF1IE object
    tf1_ie = TF1IE()
    assert tf1_ie == test_TF1IE()

# Generated at 2022-06-22 08:19:09.789500
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-22 08:19:16.945549
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testObj = TF1IE("md5")
    assert testObj is not None

# Generated at 2022-06-22 08:19:17.464569
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:20.294720
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(None)
    assert tf1 is not None, "Unexpected error, TF1IE object is None"

# Generated at 2022-06-22 08:19:22.733070
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except (TypeError, IndexError, AttributeError) as e:
        assert False, 'cannot initialize TF1IE instance: {}'.format(e)

# Generated at 2022-06-22 08:19:34.103233
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == (
        r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    )

# Generated at 2022-06-22 08:19:40.973837
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.suitable("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert tf1.IE_NAME in tf1.ie_key()
    assert tf1._WORKING == True

# Generated at 2022-06-22 08:19:41.610127
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:47.119157
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Testing with the following url:
    # http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html
    # The input url should be valid
    tf1ie = TF1IE()
    assert tf1ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:19:48.827397
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE(InfoExtractor())
    except Exception as e:
        print(e)

# Generated at 2022-06-22 08:19:49.737084
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-22 08:20:06.273571
# Unit test for constructor of class TF1IE
def test_TF1IE():
    with open('test_watch_html.html') as f:
        content = f.read()
    assert TF1IE._match_id(content).group('id') is not None
    assert TF1IE._match_id(content).group('program_slug') is not None
    assert TF1IE._match_id(content).group('id') is not None

# Generated at 2022-06-22 08:20:09.675283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:15.057061
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test constructor, basic properties of class TF1IE """
    test_item = TF1IE(None)
    assert isinstance(test_item, TF1IE)
    assert hasattr(test_item, '_VALID_URL')
    assert hasattr(test_item, '_TESTS')

# Generated at 2022-06-22 08:20:19.498447
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Tests for constructors of classes
    # Original class
    TF1IE()
    # Since BaseIE is an abstract class, we cannot directly make a object of it
    # We have to make object of derived class
    assert TF1IE()._downloader != False, "Failed to make object of TF1IE class"



# Generated at 2022-06-22 08:20:21.098455
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:20:24.565718
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", "test_TF1IE")

# Generated at 2022-06-22 08:20:35.048407
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_TEST = TF1IE()

# Generated at 2022-06-22 08:20:37.190868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE("TF1IE")
    assert (tf1_ie != None)

# Generated at 2022-06-22 08:20:40.613537
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url="https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE(url, download=False).extract(url)

# Generated at 2022-06-22 08:20:42.296900
# Unit test for constructor of class TF1IE
def test_TF1IE():
	# Here we test the constructor
	tf1 = TF1IE()

# Generated at 2022-06-22 08:21:04.700389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Creates a simple instance
    TF1IEInstance = TF1IE()

# Generated at 2022-06-22 08:21:07.695369
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:21:09.708353
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-22 08:21:11.540896
# Unit test for constructor of class TF1IE
def test_TF1IE():
    module = type(TF1IE)
    assert module.IE_DESC == 'TF1'
    assert module.i

# Generated at 2022-06-22 08:21:16.201790
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('wat', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1.test()

test_TF1IE()

# Generated at 2022-06-22 08:21:17.192624
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = TF1IE(InfoExtractor())

# Generated at 2022-06-22 08:21:21.063125
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = globals()['TF1IE']
    assert class_ is not None
    instance = class_()
    assert instance is not None

# Generated at 2022-06-22 08:21:24.024352
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__bases__[0].__name__ == InfoExtractor.__name__

# Generated at 2022-06-22 08:21:26.115484
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert repr(tf1) == '<TF1IE>'

# Generated at 2022-06-22 08:21:28.493241
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("wat:12345")
    assert ie.url == "wat:12345"

# Generated at 2022-06-22 08:22:11.565229
# Unit test for constructor of class TF1IE
def test_TF1IE():
    d = TF1IE(None)
    assert d

# Generated at 2022-06-22 08:22:22.197285
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:22:23.573070
# Unit test for constructor of class TF1IE
def test_TF1IE():
    InfoExtractor.test_IE('TF1')

# Generated at 2022-06-22 08:22:26.419480
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.ie_key() == 'TF1'
    tf1 = TF1IE(None)
    assert isinstance(tf1, InfoExtractor)

# Generated at 2022-06-22 08:22:27.228480
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert True

# Generated at 2022-06-22 08:22:28.262450
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://wat')

# Generated at 2022-06-22 08:22:32.134227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert isinstance(x, TF1IE)


# Generated at 2022-06-22 08:22:33.786208
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('13641379')

# Generated at 2022-06-22 08:22:38.340134
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit tests for TF1IE constructor class."""
    obj = TF1IE(TF1IE.IE_NAME)
    assert obj.ie_key() == TF1IE.IE_KEY
    assert obj.ie_name() == TF1IE.IE_NAME
    assert obj.ie_version() == '0.0'

# Generated at 2022-06-22 08:22:38.954971
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:24:32.889613
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('')
    assert tf1 is not None

# Generated at 2022-06-22 08:24:35.083752
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().__class__()
    assert TF1IE(InfoExtractor()).__class__()


# Generated at 2022-06-22 08:24:36.171738
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:24:37.416315
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-22 08:24:48.547686
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE(InfoExtractor())._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:24:54.135226
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check if the constructor of class TF1IE is functioning correctly
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    video_info_extractor = TF1IE()
    try:
        video_info_extractor(url)
    except:
        # The constructor of class should raise an exception
        assert False

    expected_output = '13641379'
    assert video_info_extractor._real_extract(url)['id'] == expected_output

# Generated at 2022-06-22 08:24:58.956363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html";
    tf1IE = TF1IE(url)
    assert tf1IE != None, "Test tf1 constructor"

# Generated at 2022-06-22 08:25:08.652933
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    assert test_TF1IE._VALID_URL == "r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'"

# Generated at 2022-06-22 08:25:11.004039
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-22 08:25:21.778106
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._downloader == None
    assert ie.suitable == 'tf1.fr'
    assert ie._NETRC_MACHINE == 'wat'
    assert ie._TEST == 'wat:13641379'
    assert ie._download_webpage_handle == None
    assert ie._download_json_handle == None
    assert ie._download_xml_handle == None
    assert ie._download_json == None
    assert ie._search_regex == None
    assert ie._html_search_regex == None
    assert ie._html_search_