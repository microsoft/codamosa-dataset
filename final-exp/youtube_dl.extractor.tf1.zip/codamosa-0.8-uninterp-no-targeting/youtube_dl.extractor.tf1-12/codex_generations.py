

# Generated at 2022-06-22 08:18:41.001984
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE.__doc__ != None

    instance = TF1IE()
    assert isinstance(instance, TF1IE)
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_NAME == 'tf1'
    assert instance.IE_DESC == 'TF1'
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert instance._TESTS != None


# Generated at 2022-06-22 08:18:44.420936
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1 = TF1IE(TF1IE.create_ie(url))
    tf1

# Generated at 2022-06-22 08:18:50.887074
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_downloader import TestDownloader
    test_downloader = TestDownloader(None)
    ie = TF1IE(test_downloader)
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:18:58.648139
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE(1)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:10.637644
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:19:14.893542
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:19:24.704481
# Unit test for constructor of class TF1IE
def test_TF1IE():
    QA_URL = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    QA_ID = '13641379'
    QA_SERIE = 'Quotidien avec Yann Barthès'
    KOH_URL = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    KOH_ID = '13559729'
    KOH_SERIE = 'Koh Lanta'

    qa = TF1IE._real_extract(TF1IE(), QA_URL)
    assert qa["id"] == QA_ID


# Generated at 2022-06-22 08:19:33.987590
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:AC0000029B');
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html');
    TF1IE('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html');
    TF1IE('https://www.tf1.fr/tf1/koh-lanta-les-4-terres/videos/replay-koh-lanta-les-4-terres-du-5-fevrier-2016.html');

# Generated at 2022-06-22 08:19:40.099518
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert(tf1ie._VALID_URL == 'http://.*tf1\.fr/.*/.*/videos/.*\.html')

# Generated at 2022-06-22 08:19:40.511956
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:53.835032
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_geo_restricted_videos import test_constructor_for_api_only
    test_constructor_for_api_only(TF1IE)

# Generated at 2022-06-22 08:19:55.566495
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE()
    assert test_obj.ie_key() == 'tf1'


# Generated at 2022-06-22 08:19:56.139429
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:19:57.987277
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('tf1.fr/foo/bar')
    assert ie.NAME == 'tf1.fr'
    return



# Generated at 2022-06-22 08:20:07.736550
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor = TF1IE('title', 'description', 'id', 'timestamp', 'upload_date', 'series', 'season_number',
                        'episode_number', 'duration', 'formats', True, 'url', 'ext')
    assert constructor.title == 'title'
    assert constructor.description == 'description'
    assert constructor.id == 'id'
    assert constructor.timestamp == 'timestamp'
    assert constructor.upload_date == 'upload_date'
    assert constructor.series == 'series'
    assert constructor.season_number == 'season_number'
    assert constructor.episode_number == 'episode_number'
    assert constructor.duration == 'duration'
    assert constructor.formats == 'formats'
    assert constructor.age_limit == True
    assert constructor.url == 'url'

# Generated at 2022-06-22 08:20:08.732003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor_test(
        TF1IE,
    )

# Generated at 2022-06-22 08:20:16.917457
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1'
    assert tf1.ie_name() == 'TF1'
    assert tf1.ie_description() == 'Videos from TF1 TV channel'
    assert tf1.ie_can_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1.ie_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:20:19.349776
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for constructor of class TF1IE
    """
    assert TF1IE

# Generated at 2022-06-22 08:20:24.884689
# Unit test for constructor of class TF1IE
def test_TF1IE():
    sample_url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    message = "Couldn\'t create an instance of class TF1IE"
    assert TF1IE(TF1IE._downloader)._match_id(sample_url), message

# Generated at 2022-06-22 08:20:34.887091
# Unit test for constructor of class TF1IE
def test_TF1IE():
    u = TF1IE()
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    u.url_result(url)
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    u.url_result(url)
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    u.url_result(url)

# Generated at 2022-06-22 08:21:04.698899
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-22 08:21:08.108358
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    This is a constructor test.
    """
    TF1IE()

# Generated at 2022-06-22 08:21:13.195150
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    assert TF1IE.suitable(test_url)
    assert TF1IE.IE_NAME == 'TF1'

# Generated at 2022-06-22 08:21:16.761506
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-22 08:21:17.229127
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:21:20.101930
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance_TF1IE = TF1IE()
    instance_TF1IE

# Generated at 2022-06-22 08:21:21.588228
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert "TF1IE" == TF1IE.ie_key()

# Generated at 2022-06-22 08:21:24.983781
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Simple test to check the constructor of class TF1IE

    """
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    # No need to download the whole video for this test
    ie = TF1IE(TF1IE._downloader, params={'skip_download': True})
    ie.extract(url)



# Generated at 2022-06-22 08:21:34.490879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1.program_slug == 'koh-lanta'
    assert tf1.slug == 'replay-koh-lanta-22-mai-2015'
    assert tf1.url_type == 'video'
    assert tf1.display_id == 'replay-koh-lanta-22-mai-2015'
    assert tf1.video_id == '58103418'
    assert tf1.video_url == 'wat:58103418'

# Generated at 2022-06-22 08:21:37.524324
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:22:04.326664
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:22:08.192480
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_video = TF1IE('TF1IE', 'tf1.fr')
    object_tf1_video = TF1IE('TF1IE', 'tf1.fr')
    assert tf1_video == object_tf1_video

# Generated at 2022-06-22 08:22:17.305433
# Unit test for constructor of class TF1IE
def test_TF1IE():

    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-22 08:22:19.537301
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
        assert(True)
    except:
        assert(False)

# Generated at 2022-06-22 08:22:24.278321
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert inst.NAME == 'tf1'

# Generated at 2022-06-22 08:22:29.295808
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:22:32.630928
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == TF1IE._VALID_URL
    assert ie._TESTS == TF1IE._TESTS

# Generated at 2022-06-22 08:22:37.577843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Test if the class constructor works as expected

# Generated at 2022-06-22 08:22:38.157654
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:22:40.249140
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = InfoExtractor(TF1IE)
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    #Check if url is properly parsed by regex
    assert re.match(tester._VALID_URL, url) is not None

# Generated at 2022-06-22 08:23:08.882586
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-22 08:23:10.139533
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE"""
    TF1IE()

# Generated at 2022-06-22 08:23:22.190024
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.IE_NAME == "tf1"
    assert i.VALID_URL == "^https?://(?:www\\.)?tf1\\.fr/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html$"

# Generated at 2022-06-22 08:23:23.082698
# Unit test for constructor of class TF1IE
def test_TF1IE():
    example = TF1IE(None)
    assert example

# Generated at 2022-06-22 08:23:28.673836
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor of class TF1IE (inherited from the class InfoExtractor)
    tf1IE = TF1IE()
    assert tf1IE

    # Check the class attributes of class TF1IE
    (_VALID_URL, _TESTS) = (
        TF1IE._VALID_URL,
        TF1IE._TESTS,
    )
    assert _VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert len(_TESTS) == 3

# Generated at 2022-06-22 08:23:29.644598
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-22 08:23:30.992856
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    print(test_TF1IE)

# Generated at 2022-06-22 08:23:32.743247
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE();
    assert tf1ie is not None

# Generated at 2022-06-22 08:23:34.219717
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()


# Generated at 2022-06-22 08:23:36.276284
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .base import BaseIE
    cls = BaseIE.for_site('tf1.fr')
    cls()

# Generated at 2022-06-22 08:24:44.739767
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/', 'wat')

# Generated at 2022-06-22 08:24:46.173019
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(None)
    assert isinstance(obj, TF1IE)

# Generated at 2022-06-22 08:24:47.991722
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-22 08:24:50.852485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie is not None

# Generated at 2022-06-22 08:24:56.221683
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1', ie.ie_key()
    assert ie.metadata_to_id(ie.url_result('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')) == '13641379'


# Generated at 2022-06-22 08:25:02.080178
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert 'c25e8e05634657e883d4a3e82a8a4f6c' == TF1IE()._download_webpage(
        'https://www.wat.tv/get/android5/c25e8e05634657e883d4a3e82a8a4f6c'
        '/13641379/13641379/13641379/medium-mp4-video.mp4',
        '13641379'
    )

# Generated at 2022-06-22 08:25:03.763444
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert len(TF1IE._TESTS)>0

# Generated at 2022-06-22 08:25:05.141534
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, {}, {}, None, None, None, None)

# Generated at 2022-06-22 08:25:10.065171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE({})
    assert tf1IE != None
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:25:13.911982
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:09.658117
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1 = TF1IE()
    tf1.match(url)
    print(tf1.match(url))


# Generated at 2022-06-22 08:26:21.156866
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("test_TF1IE")
    # tf1_ie = TF1IE()
    # test_url = "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    # tf1_ie.extract(test_url)
    # test_url = "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    # tf1_ie.extract(test_url)
    test_url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE().extract

# Generated at 2022-06-22 08:26:33.043410
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:35.359844
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == TF1IE._TESTS[0]['url']

# Generated at 2022-06-22 08:26:38.712399
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.SUFFIX == "tf1.fr"
    assert ie.ie_key() == "TF1"

# Generated at 2022-06-22 08:26:42.056744
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE(test_url)

# Generated at 2022-06-22 08:26:43.554161
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as ex:
        assert False
        print(ex)

# Generated at 2022-06-22 08:26:45.675216
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('someURL')
    assert ie.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-22 08:26:50.816715
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, InfoExtractor)
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:26:52.708165
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)