

# Generated at 2022-06-22 08:18:44.930794
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Missing some of the tests, maybe because of the cookies
    ie = TF1IE()
    assert ie.ie_key() == "Tf1"
    assert ie.ie_key() == "Tf1"
    assert ie.extract("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie.extract("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

test_TF1IE()

# Generated at 2022-06-22 08:18:46.499765
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    No test yet.
    """
    pass

# Generated at 2022-06-22 08:18:50.786999
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == 'tf1'
    assert obj.ie_url() == 'https://www.tf1.fr/'
    assert obj.ie_name() == 'TF1'
    assert obj.ie_description() == 'Videos from TF1'

# Generated at 2022-06-22 08:18:56.339505
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', {})
    ie.extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', {})

# Generated at 2022-06-22 08:19:00.378463
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:19:01.204177
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE()

# Generated at 2022-06-22 08:19:08.268470
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None).suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not TF1IE(None).suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019-2.html')

# Generated at 2022-06-22 08:19:11.282829
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'TF1'
    assert ie._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-22 08:19:15.142696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html'

# Generated at 2022-06-22 08:19:15.874206
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-22 08:19:26.979852
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True
    assert t.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') ==True
    assert t.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == True

# Generated at 2022-06-22 08:19:31.023292
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.match('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-22 08:19:40.571217
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from utils import FakeIE
    class TF1IE(FakeIE):
        _VALID_URL ='http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
        _TESTS = [{
            'url': 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
            'only_matching': True,
        }]
        def _real_extract(self, url):
            return self._TESTS
    info_dict = TF1IE()._TESTS[0]

# Generated at 2022-06-22 08:19:41.072085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-22 08:19:42.078547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert isinstance(tf1_ie, TF1IE)

# Generated at 2022-06-22 08:19:43.541973
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for constructor of TF1IE class
    """
    obj = TF1IE()
    assert obj.name == 'tf1'

# Generated at 2022-06-22 08:19:44.609303
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-22 08:19:45.543072
# Unit test for constructor of class TF1IE
def test_TF1IE():
    input = TF1IE()

# Generated at 2022-06-22 08:19:52.414369
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor basic usage
    url=TF1IE._VALID_URL
    matches = re.match(TF1IE._VALID_URL, url)
    groups = matches.groups()
    program_slug, slug = re.match(TF1IE._VALID_URL, url).groups()
    print("program_slug=",program_slug)
    print("slug=",slug)

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-22 08:19:56.392113
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-22 08:20:06.738490
# Unit test for constructor of class TF1IE
def test_TF1IE():
    #Test if we create a TF1 link
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:08.457010
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert isinstance(tf1IE, InfoExtractor)

# Generated at 2022-06-22 08:20:09.056966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:20:09.815012
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-22 08:20:17.247995
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-22 08:20:22.407173
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.name == 'tf1'
    assert ie.ie_key() == 'TF1'
    assert ie.description == 'Videos from tf1.fr.'

# Test function for post process

# Generated at 2022-06-22 08:20:23.367753
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    print(obj)

# Generated at 2022-06-22 08:20:24.698252
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.TF1_URL_PATTERN

# Generated at 2022-06-22 08:20:27.564826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extracted_data = TF1IE.TF1IE()
    assert extracted_data.name == 'tf1'
    assert len(extracted_data.url_styles) == 1

# Generated at 2022-06-22 08:20:28.492309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('9876')

# Generated at 2022-06-22 08:20:41.542629
# Unit test for constructor of class TF1IE
def test_TF1IE():
	from ykdl.extractors import TF1IE
	extractor = TF1IE()

# Generated at 2022-06-22 08:20:43.182887
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = InfoExtractor()
    info_extractor.add_info_extractor(TF1IE)

# Generated at 2022-06-22 08:20:53.203351
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert e._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-22 08:20:54.191056
# Unit test for constructor of class TF1IE
def test_TF1IE():
	ie = TF1IE()

# Generated at 2022-06-22 08:20:59.161743
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''Test for TF1IE constructor.'''
    tf1_ie = TF1IE()
    assert tf1_ie.ie_key() == 'aybtv'
    assert tf1_ie.ie_url() == 'http://www.tf1.fr/'

# Generated at 2022-06-22 08:21:11.455003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1'
    assert tf1.M3U8_URL == 'http://wat.tv/get/iphone/%s.m3u8'
    assert tf1.SUCCESS_KEY == 'SUCCESS'
    assert tf1.ERROR_KEY == 'ERROR'
    assert tf1.extract_format(tf1.config['M3U8_URL'] % '123')['id'] == '123'
    assert tf1.extract_format(tf1.config['M3U8_URL'] % '123')['ext'] == 'mp4'

# Generated at 2022-06-22 08:21:18.772092
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-22 08:21:21.668269
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        print('FAIL: test_TF1IE: ' + str(e))


# Generated at 2022-06-22 08:21:23.067970
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('TF1IE')
    assert obj.ie_key() == 'TF1'

# Generated at 2022-06-22 08:21:25.000198
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, 'foo')


# Generated at 2022-06-22 08:21:51.691182
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        my_TF1IE = TF1IE()
        assert my_TF1IE is not None
    except:
        raise AssertionError("Unit test for TF1IE failed")
    return None


# Generated at 2022-06-22 08:21:55.020177
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie.suitable, RegexpExtractor.suitable)

# Generated at 2022-06-22 08:22:00.319947
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not tf1ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-22 08:22:06.023331
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-22 08:22:07.106043
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-22 08:22:07.728316
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:22:08.881477
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:22:09.616223
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance

# Generated at 2022-06-22 08:22:10.373233
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-22 08:22:14.638935
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
        Test case for constructor of class TF1IE
    """
    url = "https://www.tf1.fr"

    try:
        TF1IE(url)
    except Exception:
        assert False, "Constructor of class TF1IE failed"
    assert True

# Generated at 2022-06-22 08:23:09.492522
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:23:10.023192
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:23:16.620512
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-22 08:23:20.673990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infos = TF1IE(None).extract_info(url=None)
    for output in ["id", "url", "description", "title", "ext", "duration", "timestamp", "upload_date", "tags", "series", "episode_number", "season_number", "thumbnails", "subtitles"]:
        assert(output in infos)

# Generated at 2022-06-22 08:23:24.258410
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie.url_result('wat:12345') == {
        '_type': 'url_transparent',
        'url': 'wat:12345'
    }

# Generated at 2022-06-22 08:23:25.014064
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:23:26.468363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-22 08:23:28.972385
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert isinstance(IE, InfoExtractor)
    assert IE.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-22 08:23:31.815903
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE
    assert len(class_.IE_NAME) > 0
    assert len(class_._VALID_URL) > 0
    assert len(class_._TESTS) > 0

# Generated at 2022-06-22 08:23:34.376111
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE([], {}, {})
    assert type(instance) == TF1IE

# Generated at 2022-06-22 08:25:45.678751
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html').test()

# Generated at 2022-06-22 08:25:52.253058
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # First version with only url
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    # Second version with url and ie
    assert TF1IE('TF1')._VALID_URL == TF1IE._VALID_URL
    # Third version with url, ie and video id
    assert TF1IE('TF1', '13641379')._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-22 08:25:56.292392
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    a = TF1IE._VALID_URL
    b = TF1IE._TESTS
    c = TF1IE._real_extract

# Generated at 2022-06-22 08:25:58.433853
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.description == 'WAT'
    assert ie.suitable == False

# Generated at 2022-06-22 08:26:03.328004
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    test = TF1IE(test_url)
    assert isinstance(test, TF1IE)

# Generated at 2022-06-22 08:26:05.113580
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert isinstance(tf1, InfoExtractor)


# Generated at 2022-06-22 08:26:10.754197
# Unit test for constructor of class TF1IE
def test_TF1IE():
	# succeed with correct url
	url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
	TF1IE(url)

	# fail with wrong url
	wrong_url = 'https://youtube.com/watch?v=n0n0'
	try:
		TF1IE(wrong_url)
	except:
		print("Error while testing if constructor of class TF1IE works with wrong url")

# Generated at 2022-06-22 08:26:13.223124
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-22 08:26:18.151860
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

test_TF1IE()

# Generated at 2022-06-22 08:26:19.017652
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie is not None