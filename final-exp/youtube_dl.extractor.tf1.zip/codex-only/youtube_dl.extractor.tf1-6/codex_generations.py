

# Generated at 2022-06-24 13:08:25.020363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('url')

# Generated at 2022-06-24 13:08:28.078197
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:08:31.571604
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE(url)

# Generated at 2022-06-24 13:08:35.294604
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('TF1')
    assert ie
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:42.260944
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test for TF1IE, Test for constructor of TF1IE"""
    constructor_test_case = TestCase()
    assert_equal(TF1IE.ie_key(), 'TF1')
    assert_equal(TF1IE.ie_key(), 'TF1')
    assert_equal(TF1IE.ie_key(), 'TF1')
    assert_equal(TF1IE.ie_key(), 'TF1')
    assert_equal(TF1IE.ie_key(), 'TF1')
    assert_equal(TF1IE.ie_key(), 'TF1')
    constructor_test_case.assert_no_error()



# Generated at 2022-06-24 13:08:43.448192
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:08:50.393767
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE_test = TF1IE()
    assert hasattr(IE_test, '_VALID_URL')
    assert hasattr(IE_test, '_download_webpage_handle')
    assert hasattr(IE_test, '_real_extract')
    assert IE_test._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:08:51.725079
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import TF1IE
    assert(TF1IE)

# Generated at 2022-06-24 13:09:00.158952
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor for test
    ie = TF1IE()

    # Check for correct class name
    assert ie.IE_NAME == 'tf1'

    # Check for correct url regex
    assert re.match(ie._VALID_URL, ' https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

    # Check for correct check_valid_url() function
    assert not ie.check_valid_url('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019html')

# Generated at 2022-06-24 13:09:01.756871
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .filenames import FilenamesTest
    return FilenamesTest(TF1IE)

# Generated at 2022-06-24 13:09:05.149265
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:09:06.695124
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # The test for the constructor of TF1IE
    assert(TF1IE)

# Generated at 2022-06-24 13:09:12.948094
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.IE_NAME == 'tf1'
    assert IE.IE_DESC == 'tf1.fr'
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert not IE._TESTS

# Generated at 2022-06-24 13:09:15.388129
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", {}, {}, {}, {})

    assert str(t).startswith("<TF1IE http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:09:17.783348
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test construct without params
    TF1IE()
    # test construct with params
    TF1IE(TF1IE.ie_key())

# Generated at 2022-06-24 13:09:18.521219
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        raise e

# Generated at 2022-06-24 13:09:19.503367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:09:26.242182
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1 = TF1IE(TF1IE.IE_NAME, tf1_url)
    assert tf1.sequence_number == 0
    assert tf1.video_id == '12606488'
    assert tf1.slug == 'replay-koh-lanta-22-mai-2015'
    assert tf1.program_slug == 'koh-lanta'
    assert (tf1.url == tf1_url
            and tf1.name == TF1IE.IE_NAME
            and tf1.ie_key() == TF1IE.ie_key())

# Generated at 2022-06-24 13:09:31.430624
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(TF1IE._TESTS[0]).list_quality_formats() == [{
        'url': 'wat:13641379',
        'quality': 2,
        'format_id': 'wat:13641379',
        'ext': 'mp4'
    }]

# Generated at 2022-06-24 13:09:40.961283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor
    from .common import compat_HTTPError
    from .common import compat_urllib_error
    from .common import compat_urllib_request
    from .common import compat_urlparse
    from ..utils import std_headers
    from ..utils import compat_kwargs

    # Encoding import
    import codecs
    codecs.register(lambda name: codecs.lookup('utf-8') if name == 'cp65001' else None)

    # Disable stdout
    import os
    f = open(os.devnull, 'w')
    old_stdout = os.dup(1)
    os.dup2(f.fileno(), 1)

    # Test parsing

# Generated at 2022-06-24 13:09:42.620262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TF1IE.__init__
    assert TF1IE()

# Generated at 2022-06-24 13:09:43.528771
# Unit test for constructor of class TF1IE
def test_TF1IE():
    [TF1IE(TF1IE())]

# Generated at 2022-06-24 13:09:44.422876
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:09:52.239007
# Unit test for constructor of class TF1IE
def test_TF1IE():

	print("\n*** Test_TF1IE : Test begin ***\n")

	# Create instance
	tf1 = TF1IE()

	# Test properties
	assert list(tf1._TESTS[0].keys()) == ['url', 'info_dict', 'params']
	assert tf1._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
	assert list(tf1._TESTS[0]['info_dict'].keys()) == ['id', 'ext', 'title', 'description', 'upload_date', 'timestamp', 'duration', 'series', 'tags']

# Generated at 2022-06-24 13:09:53.216339
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:1234')

# Generated at 2022-06-24 13:10:02.595519
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t1 = TF1IE(TF1IE._VALID_URL, 'tf1.fr')
    t1._real_initialize()
    assert t1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t1._TESTS[0].keys() == ['url', 'info_dict', 'params']
    assert t1._TESTS[0]['info_dict'].keys() == ['id', 'ext', 'title', 'description', 'upload_date', 'timestamp', 'duration', 'series', 'tags']

# Generated at 2022-06-24 13:10:03.638782
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t is not None

# Generated at 2022-06-24 13:10:07.758948
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # If this is working, then I can initialize a class of TF1IE
    tf1ie_unit_test = TF1IE()
    # It is expected to return a new object of TF1IE
    assert isinstance(tf1ie_unit_test,TF1IE)


# Generated at 2022-06-24 13:10:08.826242
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:10:11.382761
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:12.583608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie.tf1_get_json()

# Generated at 2022-06-24 13:10:16.720136
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor())._VALID_URL == TF1IE._VALID_URL
    assert TF1IE(InfoExtractor())._TESTS == TF1IE._TESTS
    assert TF1IE(InfoExtractor()).__doc__ == TF1IE.__doc__

# Generated at 2022-06-24 13:10:17.366180
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("test:test:test")

# Generated at 2022-06-24 13:10:18.138350
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None) is not None

# Generated at 2022-06-24 13:10:22.950220
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """
    tfi = TF1IE()
    assert tfi.name == "TF1"
    assert tfi._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:25.769567
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.name == "TF1"
    assert tf1.description == 'md5:f6b3d6e15f6b13e6d8c6e9f4c583161b'

# Generated at 2022-06-24 13:10:28.816219
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE(url)

# Generated at 2022-06-24 13:10:29.609402
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:33.461677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:34.326188
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)

# Generated at 2022-06-24 13:10:35.470870
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == 'tf1.fr'

# Generated at 2022-06-24 13:10:36.677564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)

# Generated at 2022-06-24 13:10:47.353861
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:10:55.659363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:58.240211
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("tf1", "tf1")
    assert obj._VALID_URL is not None
    assert obj._TESTS is not None


# Generated at 2022-06-24 13:11:00.710858
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert hasattr(TF1IE, '_VALID_URL')
    assert hasattr(TF1IE, '_TESTS')

# Generated at 2022-06-24 13:11:04.669016
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wwww.tf1.fr/tf1/emissions/koh lanta.html')
    TF1IE('wwww.tf1.fr/tf1/emissions/koh lanta/videos/koh lanta replay.html')

# Generated at 2022-06-24 13:11:10.089297
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    ie = TF1IE(url)
    assert ie.name == "TF1"
    assert ie.url == url
    assert ie.is_playable
    assert ie.program_slug == "koh-lanta"
    assert ie.slug == "replay-koh-lanta-22-mai-2015"

# Generated at 2022-06-24 13:11:13.077448
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.IE_NAME == 'tf1'

# Unit test of method _real_extract of class TF1IE

# Generated at 2022-06-24 13:11:14.991797
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._TESTS[0] == TF1IE._TESTS[1]

# Generated at 2022-06-24 13:11:19.658730
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE()
    ie._real_initialize()
    ie._real_extract(url)

# Generated at 2022-06-24 13:11:20.540650
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = TF1IE()


# Generated at 2022-06-24 13:11:22.169461
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(parsed_url='https://example.com/videos/tf1/%s' % 'a')

# Generated at 2022-06-24 13:11:24.895124
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor._VALID_URL is not None, "TF1IE._VALID_URL is not set to a value."

# Generated at 2022-06-24 13:11:29.094146
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.(?P<ext>(html))'

# Generated at 2022-06-24 13:11:29.943008
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:11:37.901894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    test = TF1IE(url)
    result = test.extract(url)
    assert result['id'] == "13641379"
    assert result['title'] == "Quotidien - Première partie - 11 juin 2019"
    assert result['description'] == "Emmanuel Macron a fixé un nouveau cap pour l’Europe. Il défend un projet de pacte ...\nRetrouvez la suite de l’émission avec Yann Barthès en replay."
    assert result['upload_date'] == "20190611"
    assert result['timestamp'] == 1560

# Generated at 2022-06-24 13:11:38.484387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:11:39.617278
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-24 13:11:40.719578
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:11:49.684723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import WatTestCase
    test = WatTestCase()
    tf1 = TF1IE()

    assert 'https://www.tf1.fr/graphql/web' == tf1._TF1_API_BASE_URL
    assert '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f' == tf1._TF1_API_GRAPHQL_QUERY_ID

    assert tf1._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'


# Generated at 2022-06-24 13:11:51.898388
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:11:54.298222
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    obj.extract()
    print("Downloading...")
    print("Downloaded")


# Generated at 2022-06-24 13:11:57.587951
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    IE = TF1IE(url)
    assert re.match(IE._VALID_URL, url).groups() == IE._get_program_slug_and_slug(url)

# Generated at 2022-06-24 13:12:02.315011
# Unit test for constructor of class TF1IE
def test_TF1IE():
    value = TF1IE()._VALID_URL
    assert value == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:12:04.776214
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE(url)

# Generated at 2022-06-24 13:12:05.298188
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:07.258415
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.extract("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:12:11.020401
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:12:22.363867
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import os
    import mock
    from wat.wat_api import WatIE

    def construct_watIE(self, *args, **kwargs):
        return WatIE(*args, **kwargs)

    def mock_construct_watIE(self, *args, **kwargs):
        raise KeyError(123)

    test_cases = []
    valid_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    test_cases.append({
        'url': valid_url,
        'filepath': os.path.join('test_data', 'test_video.mp4')
    })


# Generated at 2022-06-24 13:12:26.884462
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE()
    test_TF1IE_url = test_obj._VALID_URL
    assert test_TF1IE_url == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:29.785067
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:12:32.607823
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True

# Generated at 2022-06-24 13:12:33.262898
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:35.370070
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('real_url')._VALID_URL == TF1IE._VALID_URL



# Generated at 2022-06-24 13:12:36.245236
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()

# Generated at 2022-06-24 13:12:38.897033
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = input("Enter the url: ")
    tf1_ie = TF1IE()
    print(tf1_ie.extract(test_url))
if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-24 13:12:39.468574
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:12:40.314347
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1



# Generated at 2022-06-24 13:12:41.662397
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.SUITES


# Generated at 2022-06-24 13:12:42.909136
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie is not None

# Generated at 2022-06-24 13:12:44.140966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert isinstance(t, InfoExtractor)

# Generated at 2022-06-24 13:12:45.868578
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._BUILD_GET_VIDEO._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:12:56.033774
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE()
    url ='https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    result = test_obj._real_extract(url)
    assert result['id'] == '13641379'
    assert result['ext'] == 'mp4'
    assert result['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'
    assert result['description'] == 'md5:a02cdb217141fb2d469d6216339b052f'
    assert result['upload_date'] == '20190611'
    assert result['timestamp'] == 1560273989

# Generated at 2022-06-24 13:12:59.520002
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert instance.extractor.name == "TF1"

# Generated at 2022-06-24 13:13:00.680687
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().ie_key() == 'TF1'

# Generated at 2022-06-24 13:13:05.942360
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE."""
    # Initialization
    tf1IE = TF1IE()

    # Check the attribute values
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert len(tf1IE._TESTS) == 3

# Generated at 2022-06-24 13:13:09.412144
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._TESTS[1]['url'] == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    return

# Generated at 2022-06-24 13:13:10.084985
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:12.559562
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert isinstance(obj, TF1IE)
    assert isinstance(obj, InfoExtractor)


# Generated at 2022-06-24 13:13:13.164992
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:14.498887
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE()(url)

# Generated at 2022-06-24 13:13:15.182660
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:19.415845
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.ie_key() == 'TF1'
    assert t.ie_name() == 'TF1'
    assert t.ie_info()['id'] == 'TF1'
    assert t.ie_info()['name'] == 'TF1'
    assert t.ie_info()['description']

# Generated at 2022-06-24 13:13:23.977386
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    TF1IE(url)

# Generated at 2022-06-24 13:13:24.919526
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()

# Generated at 2022-06-24 13:13:26.447148
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:13:33.346983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    IE.get_info = lambda url: IE._real_extract(url)
    assert IE.get_info('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == {
        '_type': 'url_transparent',
        'id': '20745068',
        'url': 'wat:20745068',
        'title': 'Koh-Lanta (Replay) - Saison 13 - Episode 12',
        'series': 'Koh-Lanta',
        'season_number': 13,
        'episode_number': 12,
    }

# Generated at 2022-06-24 13:13:42.240389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test case with valid input
    test_TF1IE_1 = TF1IE(TF1IE.extract_info('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'))
    assert test_TF1IE_1 is not None

    # Test case with invalid input
    test_TF1IE_2 = TF1IE(TF1IE.extract_info('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'))
    assert test_TF1IE_2 is not None

    # Test case with invalid input

# Generated at 2022-06-24 13:13:43.601760
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None


# Generated at 2022-06-24 13:13:46.151919
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert re.match(obj._VALID_URL, obj._VALID_URL)

# Generated at 2022-06-24 13:13:57.033895
# Unit test for constructor of class TF1IE
def test_TF1IE():

    tmc_url = 'https://www.tmc.tv/lists/equipe-de-france/videos/4-mai-2019' 
    tf1_url = 'https://www.tf1.fr/tmc/ltm-la-toute-maison/videos/la-velo-est-reine.html' 
        
    # We check the constructor of class TF1IE
    ie = TF1IE(tf1_url)
    tmc_ie = TF1IE(tmc_url)

    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:00.432126
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:01.408247
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:11.023390
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:12.631167
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == "TF1IE"

# Generated at 2022-06-24 13:14:16.054910
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:14:26.971588
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.tf1_liz_id = 'testtf1id'
    ie.tf1_liz_key = 'testkey'

    assert ie.tf1_liz_id == 'testtf1id'
    assert ie.tf1_liz_key == 'testkey'
    assert ie.LIZ_URL == 'https://ws.tf1.fr/liz/1.0/'
    assert ie.LIZ_URL_1 == 'https://ws.tf1.fr/liz/1.0/{}'
    assert ie.LIZ_URL_2 == 'https://ws.tf1.fr/liz/1.0/{}/{}'


# Generated at 2022-06-24 13:14:27.585225
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:14:28.567520
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
assert t

# Generated at 2022-06-24 13:14:29.560168
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('www.tf1.fr')

# Generated at 2022-06-24 13:14:32.410657
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-24 13:14:34.628670
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Instantiation of the class
    tf1 = TF1IE()
    assert tf1 is not None, 'Instantiation'


# Generated at 2022-06-24 13:14:43.920985
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:14:45.173455
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert(instance._download_json == InfoExtractor._download_json)

# Generated at 2022-06-24 13:14:50.379718
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print('Test for constructor of class TF1IE')
    # TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    tf1IE = TF1IE(_TESTS[0]['url'])
    assert tf1IE.url == url

# Generated at 2022-06-24 13:14:51.810772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor
    return

# Generated at 2022-06-24 13:14:54.414479
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test the constructor of class TF1IE."""
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    assert TF1IE()._TESTS == TF1IE._TESTS

# Generated at 2022-06-24 13:14:57.372595
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:03.867617
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('tf1', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:04.824163
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_class = TF1IE("")

# Generated at 2022-06-24 13:15:06.598317
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-24 13:15:07.565335
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('tf1', 'tf1.fr')

# Generated at 2022-06-24 13:15:08.511983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('TF1')

# Generated at 2022-06-24 13:15:11.204001
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert tf1 is not None

# Generated at 2022-06-24 13:15:18.236522
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test TF1IE constructor with TF1 URL"""
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    tf1IE = TF1IE(url)
    assert tf1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:29.299452
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:30.577119
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Instantiation of class TF1IE
    assert TF1IE

# Generated at 2022-06-24 13:15:33.791304
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    mytf1 = TF1IE()
    mytf1.suitable(url)
    mytf1.extract(url)

# Generated at 2022-06-24 13:15:35.357218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:15:36.969190
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This is the constructor for TF1IE
    TF1IE('wat:1234567')

# Generated at 2022-06-24 13:15:38.256759
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a= TF1IE()

# Generated at 2022-06-24 13:15:49.326260
# Unit test for constructor of class TF1IE
def test_TF1IE():

	assert TF1IE.__name__ == 'TF1IE' # test constructor name
	
	assert TF1IE._VALID_URL == \
	'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html' # test regex url
	
	assert TF1IE._TESTS[0]["url"] == \
	'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html' # test url
	assert TF1IE._TESTS[0]["info_dict"]["id"] == \
	'13641379' # test returned

# Generated at 2022-06-24 13:15:53.105284
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert_equals(ie._VALID_URL, 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:15:53.826178
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:56.836348
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:58.741594
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.extract_videos("http://tf1.fr/test/test.html")

# Generated at 2022-06-24 13:16:01.135556
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x.tf1_base_url == 'http://wat.video.tf1.fr'

# Generated at 2022-06-24 13:16:01.718922
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:16:03.147018
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Unit test to run TF1IE

# Generated at 2022-06-24 13:16:06.059109
# Unit test for constructor of class TF1IE
def test_TF1IE():
    youtube_ie = TF1IE()
    assert youtube_ie.ie_key() == 'TF1'
    assert youtube_ie.suitable(None) == False

# Generated at 2022-06-24 13:16:07.442089
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.can_handle_url(TF1IE._VALID_URL)

# Generated at 2022-06-24 13:16:08.549845
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t

# Generated at 2022-06-24 13:16:09.510121
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:16:11.108147
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()

# Generated at 2022-06-24 13:16:11.705485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:17.252764
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    test_obj = TF1IE(test_url)
    print("test_obj.program_slug: " + test_obj.program_slug)
    print("test_obj.slug: " + test_obj.slug)

# Generated at 2022-06-24 13:16:26.315691
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    ie = TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    # This particular video can be watched in multiple formats so we have to use regex in the Unit test
    assert ie.get_real_id("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    # This particular video can be watched in multiple formats so we have to use regex in the Unit test

# Generated at 2022-06-24 13:16:37.049574
# Unit test for constructor of class TF1IE
def test_TF1IE():
    desc = 'md5:a02cdb217141fb2d469d6216339b052f'
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    id_ = '13641379'
    ext = 'mp4'
    title = 'md5:f392bc52245dc5ad43771650c96fb620'
    duration = 1738
    timestamp = 1560273989
    series = 'Quotidien avec Yann Barthès'
    tags = ['intégrale', 'quotidien', 'Replay']

    tf1ie = TF1IE()

    result = tf1ie._real_extract(url)

# Generated at 2022-06-24 13:16:37.786898
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf = TF1IE()
    assert tf is not None

# Generated at 2022-06-24 13:16:38.844704
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert('TF1IE' in str(obj))

# Generated at 2022-06-24 13:16:41.911520
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:16:52.291336
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:16:54.000449
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception:
        assert False, 'Could not create TF1IE'

# Generated at 2022-06-24 13:16:55.400884
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Should not raise
    # No exception: constructor test successful
    TF1IE()

# Generated at 2022-06-24 13:16:58.197295
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("tf1.fr/")
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:59.235022
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t != None

# Generated at 2022-06-24 13:17:01.650352
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert type(TF1IE('').filename) == str
    assert 're' in dir(TF1IE('')._real_extract)

# Generated at 2022-06-24 13:17:10.748251
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    result = ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:11.971296
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()
    print(a)


# Generated at 2022-06-24 13:17:13.215908
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('TF1IE')
    # No assert needed.

# Generated at 2022-06-24 13:17:16.316652
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except TypeError:
        pass
    else:
        raise Exception('Unit test for initializing TF1IE class shall fail!')

# Generated at 2022-06-24 13:17:17.944638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:17:20.368123
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t._download_json = lambda *args, **kwargs: {}
    t._real_extract(t._VALID_URL)

# Generated at 2022-06-24 13:17:30.273437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test on https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html
    video = TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert video['_type'] == 'url_transparent'
    assert video['id'] == '13641379'
    assert video['title'] == 'TMC Quotidien - Première partie - 11 juin 2019'

# Generated at 2022-06-24 13:17:30.761327
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:17:36.147202
# Unit test for constructor of class TF1IE
def test_TF1IE():
    to_test = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    expected_result = "13e9de2b29d0a278a2a1cdf87930f55b"
    assert expected_result == str(TF1IE(to_test)._md5_ID(to_test))


# Generated at 2022-06-24 13:17:36.751773
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:40.589447
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:41.532882
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:17:48.561426
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE', True)
    TF1IE('TF1IE', 'tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', True)
    TF1IE('TF1IE', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', True)

# Generated at 2022-06-24 13:17:54.518534
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    # TF1IE(downloader=None, ie_key=None, ext=None, fake_opts=None)
    # Unit test for functions of TF1IE class
    # We don't have a real page, so we fake it.
    # The method _real_initialize is never called
    # TODO: find a real page to test
    class FakeDownloader(object):
        pass

    class FakeOptions(object):
        pass

    downloader = FakeDownloader()
    options = FakeOptions()
    options.test = False
    options.username = None
    options.password = None
    options.ap_username = None
    options.ap_password = None
    options.ap_mso = None
    options.ap_list = None
    options.listformats = None

# Generated at 2022-06-24 13:17:58.329187
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test default case.
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:18:06.683305
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Given
    url = 'https://www.tf1.fr/tf1/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    # When
    tf1 = TF1IE(url)

    # Then
    assert tf1.url == url
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:09.570337
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE(InfoExtractor())
    assert e.extractor_key == "TF1"
    assert e.IE_NAME == "TF1"

# Generated at 2022-06-24 13:18:13.699551
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import WatIE
    ie = TF1IE(WatIE()._downloader)
    ie.download('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:18:14.983138
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit = TF1IE()

# Generated at 2022-06-24 13:18:19.565240
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("test")
    try:
        obj.get_constants()
        assert False
    except ValueError:
        assert True

    obj = TF1IE("test", "test")

    try:
        obj.get_constants()
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 13:18:24.675275
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import run_ie

    run_ie(TF1IE(), 'tf1:13641379')
    run_ie(TF1IE(), 'tf1:13641379', '--dry-run')
    run_ie(TF1IE(), 'tf1:13641379', '--format', 'bestvideo')
    run_ie(TF1IE(), 'tf1:13641379', '--format', 'bestvideo', '--dry-run')