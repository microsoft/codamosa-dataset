

# Generated at 2022-06-24 13:08:23.204602
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('TF1IE', 'tf1.fr').ie_key() == 'TF1'

# Generated at 2022-06-24 13:08:23.688597
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:08:25.821771
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    return True

# Generated at 2022-06-24 13:08:35.927237
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:43.911499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:49.996416
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test the constructor of class TF1IE
    arg1 = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"  # url was taken from _TESTS above
    t = TF1IE(arg1)
    assert t is not None

if __name__ == "__main__":
    # Do the test of class TF1IE
    test_TF1IE()

# Generated at 2022-06-24 13:08:54.089865
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("TF1IE", "tf1")
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:54.978282
# Unit test for constructor of class TF1IE
def test_TF1IE():
  assert TF1IE('1', '2')

# Generated at 2022-06-24 13:08:55.927833
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert isinstance(t, TF1IE)


# Generated at 2022-06-24 13:08:57.633312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ie = TF1IE()
    assert ie.IE_NAME in ie.ie_key()

# Generated at 2022-06-24 13:09:08.517759
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert (tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert (tf1_ie._TESTS[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert (tf1_ie._TESTS[0]['info_dict']['id'] == '13641379')

# Generated at 2022-06-24 13:09:09.834093
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.suite()


# Generated at 2022-06-24 13:09:11.757223
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('md5:f392bc52245dc5ad43771650c96fb620')

# Generated at 2022-06-24 13:09:20.627609
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_cases = [
        {
            'url': 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
            'match': {
                'program_slug': 'koh-lanta',
                'id': 'replay-koh-lanta-22-mai-2015',
            },
        },
    ]
    for test_case in test_cases:
        match = re.match(TF1IE._VALID_URL, test_case['url'])
        assert match is not None
        assert match.groupdict() == test_case['match']

# Generated at 2022-06-24 13:09:25.112941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    parser = InfoExtractor._get_parser(TF1IE)
    assert (parser('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is not None)
    assert (parser('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is not None)

# Generated at 2022-06-24 13:09:36.379213
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:36.950179
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:38.409424
# Unit test for constructor of class TF1IE
def test_TF1IE():
	return TF1IE

# Generated at 2022-06-24 13:09:44.251810
# Unit test for constructor of class TF1IE
def test_TF1IE():
    input_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1 = TF1IE(input_url)
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert_equals(url, tf1.url)

# Generated at 2022-06-24 13:09:47.188347
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    u"""
    Test case for constructor of class TF1IE
    """
    # Test for constructor of TF1IE Class
    dl_obj = TF1IE()
    assert dl_obj is not None, "Constructor of TF1IE is not working"

# Generated at 2022-06-24 13:09:48.093608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:09:54.620696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance.url_re.groups == 3
    assert instance.url_re.groupindex == {'program_slug': 1, 'id': 2}
    assert instance.ie_key() == 'TF1'
    assert instance.server_url == 'https://www.tf1.fr/graphql/web'
    assert instance.short_name == 'TF1'
    assert instance.logo_url == 're:^https?://.*\.png'

# Generated at 2022-06-24 13:09:59.782437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'tf1.fr'
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:10:00.762024
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()


# Generated at 2022-06-24 13:10:03.906990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert result != None

# Generated at 2022-06-24 13:10:04.530679
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:10:07.003371
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.ie_key() == 'tf1'
    assert TF1IE.ie_key() in InfoExtractor._AVAILABLE_IE

# Generated at 2022-06-24 13:10:07.613602
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:10:09.246803
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE()
    assert TF1IE._VALID_URL == infoExtractor._VALID_URL
    assert TF1IE._TESTS == infoExtractor._TESTS

# Generated at 2022-06-24 13:10:12.857082
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    except:
        assert False

# Generated at 2022-06-24 13:10:23.027922
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    program_slug, slug = re.match(tf1._VALID_URL, url).groups()
    assert len(program_slug) > 0, 'Failed to extract program slug from url'
    assert len(slug) > 0, 'Failed to extract slug from url'

# Generated at 2022-06-24 13:10:26.014585
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Testing constructor of class TF1IE")
    try:
        test_TF1IE = TF1IE()
        print("Class TF1IE is valid")
    except:
        print("Class TF1IE is invalid")



# Generated at 2022-06-24 13:10:28.339700
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:10:32.530373
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    tf1IE.extract('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:38.840699
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_info = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
                       'https://www.tf1.fr/graphql/web')
    assert video_info._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert video_info.testURL

test_TF1IE()

# Generated at 2022-06-24 13:10:49.650717
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/([^/]+)/videos/([^/?&#]+)\\.html'
    assert instance._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert instance._TESTS[0]['only_matching'] == False
    assert instance._TESTS[0]['params']['skip_download'] == True

# Generated at 2022-06-24 13:10:50.921171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test: constructor of class TF1IE
    assert TF1IE()

# Generated at 2022-06-24 13:10:51.585220
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('url', {})

# Generated at 2022-06-24 13:10:54.023834
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert TF1IE()._WORKING == True
        assert TF1IE._WORKING == True
    except Exception:
        assert False ,'Unit test for TF1IE failed.'


# Generated at 2022-06-24 13:10:58.428693
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    main = TF1IE.TF1IE()
    main.suitable(url)
    main.extract(url)

# Generated at 2022-06-24 13:10:59.956228
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This should not raise an exception
    TF1IE()


# Generated at 2022-06-24 13:11:02.131367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.IE_NAME
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-24 13:11:11.007976
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE('tf1', 'TF1')
    assert tf1IE.IE_NAME == 'tf1'
    assert tf1IE.ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:12.279237
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst is not None

# Generated at 2022-06-24 13:11:22.207426
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:25.282293
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert isinstance(tf1, TF1IE)
    assert isinstance(tf1, InfoExtractor)


# Generated at 2022-06-24 13:11:26.926560
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception:
        assert False
    assert True

# Generated at 2022-06-24 13:11:27.718229
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE(None)
    assert a.SUFFIX == 'tf1'

# Generated at 2022-06-24 13:11:33.525568
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Initialisation of test variables
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    program_slug = 'koh-lanta'
    slug = 'replay-koh-lanta-22-mai-2015'
    tf1_ie = TF1IE(url)
    assert tf1_ie._VALID_URL == url
    assert tf1_ie._TESTS[0]['url'] == url
    assert tf1_ie._TESTS[0]['info_dict']['id'] == '13641379'
    assert tf1_ie._real_extract(url)['id'] == '16578633'

# Generated at 2022-06-24 13:11:34.203477
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()

# Generated at 2022-06-24 13:11:40.302655
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Initialization test with too few arguments
    assert TF1IE()._VALID_URL is None

    # Initialization test with non-matching url
    assert TF1IE('https://www.francetvinfo.fr/')._VALID_URL is None
    assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')._VALID_URL is not None

# Generated at 2022-06-24 13:11:41.001607
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:11:42.720330
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_test = TF1IE()
    # nothing to test, constructor has no argument.
    return class_test

# Generated at 2022-06-24 13:11:48.865410
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('http://www.wat.tv/video/koh-lanta-22-mai-2015-le-retour-de-6ghjw_2ky7f_.html')
    assert tf1.SUFFIX == '.html'
    assert tf1.VIDEO_ID == '6ghjw_2ky7f_'
    assert tf1.wat_id == '6ghjw_2ky7f_'
    assert tf1.url == '6ghjw_2ky7f_'

# Generated at 2022-06-24 13:11:49.685465
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert test

# Generated at 2022-06-24 13:11:50.950557
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_c = TF1IE();
    assert(test_c is not None)

# Generated at 2022-06-24 13:11:52.169808
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert isinstance(test, TF1IE)


# Generated at 2022-06-24 13:11:54.036601
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:03.823553
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    # assertEqual(instance.URL, r'https?://(?:www\.)?tf1\.fr/[^/]+/videos/(?P<id>[^/?&#]+)\.html')
    assert instance.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True
    assert instance.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True

# Generated at 2022-06-24 13:12:06.539265
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', 'MD5')

# Generated at 2022-06-24 13:12:08.829565
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:12:10.238617
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:11.274941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:15.311713
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:12:16.569994
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:20.034729
# Unit test for constructor of class TF1IE
def test_TF1IE():
	u = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
	TF1IE(u)

# Generated at 2022-06-24 13:12:20.651989
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:22.658311
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test that creating a TF1IE instance does not throw an error."""
    instance = TF1IE()

# Generated at 2022-06-24 13:12:26.171285
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE('test')
    assert tf1IE.ie_key() == 'TF1'
    assert tf1IE.ie_key() in TF1IE.ie_key_map
    assert tf1IE.ie_key() in TF1IE._IES

# Generated at 2022-06-24 13:12:33.402857
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('url', 'program_slug', 'slug', 'wat_id')
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:37.028209
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert isinstance(tf1_ie, TF1IE)


# Generated at 2022-06-24 13:12:38.962264
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert instance

# Generated at 2022-06-24 13:12:42.197060
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = globals()['TF1IE']
    ins = class_()
    assert ins._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:43.343217
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test

# Generated at 2022-06-24 13:12:45.454053
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._match_id('md5:0e66f29839a9a16f20c7e58fec3654c8')

# Generated at 2022-06-24 13:12:47.691850
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    obj.extract()

# Generated at 2022-06-24 13:12:51.256953
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html').constructor == TF1IE

# Generated at 2022-06-24 13:12:52.656754
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:12:54.162228
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance.suite()

test_TF1IE()

# Generated at 2022-06-24 13:12:57.726594
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert_equal(ie._VALID_URL, 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:13:05.415790
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # fixture
    video_id = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    # test
    tf1ie = TF1IE(url)
    assert tf1ie.name == 'TF1'
    assert tf1ie.url_test(video_id)
    assert tf1ie.url_test(url) == True

# Generated at 2022-06-24 13:13:08.106006
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:13:18.383709
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE().ie_key() == 'TF1'

# Generated at 2022-06-24 13:13:19.911243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Fail when given url is None"""
    assert TF1IE(None) == None

# Generated at 2022-06-24 13:13:20.527514
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:24.288604
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # create an instance of TF1IE
    t = TF1IE()
    # check type
    assert str(type(t)) == "<class 'youtube_dl.extractor.tf1.TF1IE'>"

# Generated at 2022-06-24 13:13:26.117412
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None
    assert TF1IE._TESTS is not None

# Generated at 2022-06-24 13:13:27.340709
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE()

# Generated at 2022-06-24 13:13:30.400894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:30.956883
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:32.122063
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:13:34.980793
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.IE_NAME == 'tf1'
    assert obj.playlist_title == obj._PLAYLIST_TITLE
    assert obj.ie_key() == 'TF1'

# Generated at 2022-06-24 13:13:37.887983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._download_webpage('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:13:40.777696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:13:51.804882
# Unit test for constructor of class TF1IE
def test_TF1IE():
    m_info_extractor = InfoExtractor() # class TF1IE

    m_wat_id = "1234567"
    m_title = "Title"
    m_thumbnails = [{"url": "https://example.com/thumbnail.jpg", "width": 1280}]
    m_description = "Description"
    m_timestamp = 1560273989 # epoch
    m_duration = 1738
    m_tags = ["tag1", "tag2"]
    m_series = "Series"
    m_season_number = 2
    m_episode_number = 3

    # Full parameters test

# Generated at 2022-06-24 13:13:52.925417
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:13:56.713636
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract(
        "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    """Test the constructor of class TF1IE."""

# Generated at 2022-06-24 13:13:57.902943
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == 'TF1'
    assert obj.ie_key_legacy() == 'Wat'

# Generated at 2022-06-24 13:13:58.262096
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:14:04.044694
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie is not None, "Could not instantiate TF1IE"
    assert ie.extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")[0]["title"] == "Koh-Lanta, Fidji", "Wrong title"

# Generated at 2022-06-24 13:14:14.540895
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:18.442248
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    print(tf1ie._VALID_URL)
    print(tf1ie._TESTS)

# Generated at 2022-06-24 13:14:19.344597
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t

# Generated at 2022-06-24 13:14:20.987562
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class constructor for TF1IE class"""
    instance = TF1IE()

# Generated at 2022-06-24 13:14:26.225442
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE()
    assert infoExtractor.info_extractors == [TF1IE]
    assert infoExtractor.info_extractors == [TF1IE]
    assert infoExtractor.info_extractors == [TF1IE]
    assert infoExtractor.info_extractors == [TF1IE]


# Generated at 2022-06-24 13:14:28.755087
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert str(type(ie)) == "<class 'youtube_dl.extractor.tf1.TF1IE'>"



# Generated at 2022-06-24 13:14:32.944879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._TESTS[0]['info_dict']['id'] == '13641379'
    assert TF1IE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:14:33.419917
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf_1 = TF1IE()

# Generated at 2022-06-24 13:14:37.231977
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('md5:f392bc52245dc5ad43771650c96fb620') == '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'

# Generated at 2022-06-24 13:14:42.529312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable(ie.IE_NAME, '1')
    ie.suitable(ie.IE_NAME, '2')
    ie.suitable(ie.IE_NAME, '3')
    ie.suitable(ie.IE_NAME, '4')
    ie.suitable(ie.IE_NAME, '5')


# Generated at 2022-06-24 13:14:43.753309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:14:45.798867
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.search(r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html',
                     TF1IE._VALID_URL)

# Generated at 2022-06-24 13:14:46.731778
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:50.406430
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:14:51.040185
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:14:58.599908
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:14:59.864869
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert not t

# Generated at 2022-06-24 13:15:03.969974
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor of TF1IE class, new method
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:15:04.543950
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:15:09.288415
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TF1IE
    assert TF1IE.ie_key() == 'tf1'
    assert TF1IE.IE_NAME == 'tf1'
    assert TF1IE.IE_DESC == 'TF1'
    assert TF1IE.VALID_URL == TF1IE._VALID_URL
    assert TF1IE.TEST == TF1IE._TESTS

# Generated at 2022-06-24 13:15:10.959276
# Unit test for constructor of class TF1IE
def test_TF1IE():

    #test for instance creation
    tf1 = TF1IE()
    assert tf1
    

# Generated at 2022-06-24 13:15:11.804603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test object creation
    object = TF1IE()

# Generated at 2022-06-24 13:15:12.610324
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.test()

# Generated at 2022-06-24 13:15:14.048591
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE
    assert class_ is not None, 'Can not find class TF1IE'

# Generated at 2022-06-24 13:15:24.927716
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1IE = TF1IE(test_url)
    assert tf1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1

# Generated at 2022-06-24 13:15:25.511401
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:27.034618
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().get_instance() != None


# Generated at 2022-06-24 13:15:27.576827
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('')

# Generated at 2022-06-24 13:15:28.534728
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('')

# Generated at 2022-06-24 13:15:31.856739
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE(None)
    assert isinstance(instance, TF1IE)
    assert isinstance(instance.suitable, bool)
    assert instance.ie_key() == 'TF1'
    assert instance.video_id is None


# Generated at 2022-06-24 13:15:44.121826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
        Tests for the constructor of TF1IE.
    '''
    tf1_ie = TF1IE()

    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:48.680545
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert obj.program_slug == 'documentaire'
    assert obj.slug == 'mylene-farmer-d-une-icone'

# Generated at 2022-06-24 13:15:57.151627
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE('tf1', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert test.params == {'skip_download': True, 'format': 'bestvideo'}
    assert test._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:58.434300
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie is not None

# Generated at 2022-06-24 13:16:03.792796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie.program_slug == "koh-lanta"
    assert ie.slug == "replay-koh-lanta-22-mai-2015"

# Generated at 2022-06-24 13:16:04.436445
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:16:10.351452
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, InfoExtractor)
    assert TF1IE.suitable(URL)
    assert TF1IE.suitable(URL2)
    assert TF1IE.suitable(URL3)
    assert TF1IE.suitable(URL4)
    assert TF1IE.suitable(URL5)
    assert not TF1IE.suitable(URL6)


# Generated at 2022-06-24 13:16:12.321306
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:16:13.269650
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:16:19.581388
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test for issue #10019
    info_extractor = TF1IE()
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert re.match(info_extractor._VALID_URL, url)
    assert info_extractor.suitable(url)

# Generated at 2022-06-24 13:16:22.091802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except TypeError as e:
        assert False, "TF1IE constructor throws TypeError"
    else:
        assert True


# Generated at 2022-06-24 13:16:22.439367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:27.221070
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Invoking constructor of class TF1IE
    wat = TF1IE()
# Assigning values to variable 'url'
url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
# Calling method 'suitable' of object 'wat'
result_wat = wat.suitable(url)
assert(result_wat == False)

# Generated at 2022-06-24 13:16:36.575611
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('tf1', 'tf1')
    assert ie.NAME == 'tf1'
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'tf1.fr'
    assert ie.BROWSER_UA == 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
    assert ie.BROWSER_JSON_HEADERS == {'accept': 'application/json, text/plain, */*', 'x-requested-with': 'XMLHttpRequest'}

# Generated at 2022-06-24 13:16:41.690840
# Unit test for constructor of class TF1IE
def test_TF1IE():
    example_video_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    video_page = TF1IE(example_video_url, {})
    assert video_page.ie_key() == 'TF1'
    assert video_page.ie_name() == 'TF1'
    

# Generated at 2022-06-24 13:16:42.290003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:45.779163
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    test_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    t = TF1IE()
    x = t._real_extract(test_url)
    print(x)

# Generated at 2022-06-24 13:16:47.153378
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None).IE_NAME in ('TF1', 'wat')

# Generated at 2022-06-24 13:16:48.490174
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie

# Generated at 2022-06-24 13:16:52.944354
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    unit test for constructor of class TF1IE
    """
    test_obj = TF1IE()
    response = test_obj.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    print(response)

# Generated at 2022-06-24 13:17:03.020425
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL in 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', '_VALID_URL not contained in URL'

# Generated at 2022-06-24 13:17:03.564417
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:04.108744
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:05.500461
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:17:07.379061
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie is not None

# Generated at 2022-06-24 13:17:08.287846
# Unit test for constructor of class TF1IE
def test_TF1IE():
    InfoExtractor(TF1IE)

# Generated at 2022-06-24 13:17:09.557019
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_constructor = getattr(TF1IE, '__init__')
    assert class_constructor != None

# Generated at 2022-06-24 13:17:19.534565
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == "TF1IE"
    tf1IE = TF1IE()
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    tf1IE.extract(url=url)
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    tf1IE.extract(url=url)
    url = "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    tf1IE.extract(url=url)

# Generated at 2022-06-24 13:17:20.458961
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie=TF1IE()

# Generated at 2022-06-24 13:17:24.861163
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    obj = TF1IE(url)

    # Act
    obj.real_extract(url)

    # Assert
    assert True

# Generated at 2022-06-24 13:17:33.207726
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for video with a single video of a program
    TF1IE_test_dict = {
        'url': 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'only_matching': True}
    instance_TF1IE = TF1IE()
    instance_TF1IE.suitable(TF1IE_test_dict['url'])
    instance_TF1IE.extract(TF1IE_test_dict['url'])
    assert instance_TF1IE.suitable(TF1IE_test_dict['url']) == TF1IE_test_dict['only_matching']
    # Test for video with a single video of a program
    TF1IE_

# Generated at 2022-06-24 13:17:34.064116
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert("TF1IE" in globals())

# Generated at 2022-06-24 13:17:41.261966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    video = ie._real_extract("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    info = ie._get_description(video)
    assert info is not None
    assert info != ""

# Generated at 2022-06-24 13:17:41.855839
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:17:51.535250
# Unit test for constructor of class TF1IE
def test_TF1IE():
    opt = {'ext': 'mp4', 'title': 'md5:f392bc52245dc5ad43771650c96fb620', 'description': 'md5:a02cdb217141fb2d469d6216339b052f', 'upload_date': '20190611', 'timestamp': 1560273989, 'duration': 1738, 'series': 'Quotidien avec Yann Barthès', 'tags': ['intégrale', 'quotidien', 'Replay'], 'id': '13641379'}
    assert TF1IE().extract({'url': 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'}) == opt

# Generated at 2022-06-24 13:18:02.005837
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'
    assert tf1._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1._TESTS[0]['info_dict']['id'] == '13641379'
    assert tf1._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:18:07.988079
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    request = TF1IE._download_webpage(url, None, None)
    tf1ie = TF1IE(url, request)
    assert tf1ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:10.060030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE

# Generated at 2022-06-24 13:18:15.853305
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    VIDEO_URL=("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    # Act
    tf1 = TF1IE(None)
    # Assert
    if tf1._VALID_URL != VIDEO_URL:
        raise AssertionError("Incorrect valid url for TF1")

# Generated at 2022-06-24 13:18:17.119884
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()

# Generated at 2022-06-24 13:18:21.058997
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    print(tf1_ie._VALID_URL)
    print(tf1_ie._TESTS)
    print(len(tf1_ie._TESTS))
    assert len(tf1_ie._TESTS) != 0

# Generated at 2022-06-24 13:18:27.601514
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'