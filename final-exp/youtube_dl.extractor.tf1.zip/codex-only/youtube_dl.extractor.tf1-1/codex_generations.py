

# Generated at 2022-06-24 13:08:22.285760
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('foobar')


# Generated at 2022-06-24 13:08:23.971201
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-24 13:08:25.451778
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:08:35.506813
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    pattern = re.compile(tf1._VALID_URL)

    match = pattern.match('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert(match)
    assert('program_slug' in match.groupdict())
    assert('id' in match.groupdict())
    assert('koh-lanta' == match.group('program_slug'))
    assert('replay-koh-lanta-22-mai-2015' == match.group('id'))
    assert(match.groupdict()['program_slug'] == 'koh-lanta')

# Generated at 2022-06-24 13:08:36.060995
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:40.773312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = r'https?://(?:www\.)?tf1\.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    _ = TF1IE()._real_extract(test_url)
    assert TF1IE().suitable(test_url)
    assert TF1IE()._VALID_URL == test_url

# Generated at 2022-06-24 13:08:41.910571
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == 'TF1'

# Generated at 2022-06-24 13:08:48.406666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    result = ie.extract()

    assert result != None
    assert result['tags'] == ['intégrale', 'quotidien', 'Replay']
    assert result['duration'] == 1738

# Generated at 2022-06-24 13:08:53.793367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'tf1.fr'

# Generated at 2022-06-24 13:08:55.649221
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:56.163881
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:08:57.955528
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for instantiation
    test_url = "http://www.tf1.fr/";
    TF1IE(test_url);

# Generated at 2022-06-24 13:09:08.854666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE(TF1IE)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:09.790228
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() is not None

# Generated at 2022-06-24 13:09:12.071130
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE(InfoExtractor)
    assert tf1_ie.ie_key() == 'tf1'

# Generated at 2022-06-24 13:09:21.930530
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    test_TF1IE = TF1IE(url)

    assert test_TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:09:26.989761
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert isinstance(IE,InfoExtractor)
    assert IE.IE_NAME == 'tf1'
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:31.802095
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == "TF1IE"
    assert TF1IE.__doc__ == "Information extractor for TF1"
    assert TF1IE._TESTS[0]["url"] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert TF1IE._TESTS[0]["info_dict"]["id"] == "13641379"
    assert TF1IE._TESTS[0]["info_dict"]["title"] == "Quotidien (première partie) - 11 juin 2019"

# Generated at 2022-06-24 13:09:32.472323
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:36.285775
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1 = TF1IE()
	assert(tf1.asset)
	assert(tf1._downloader)
	assert(tf1._download_webpage_handle)
	assert(tf1._download_json)
	assert(tf1._real_extract)

# Generated at 2022-06-24 13:09:44.537505
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("")
    assert tf1ie._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:09:45.448798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().supported_ie

# Generated at 2022-06-24 13:09:46.000978
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:09:47.504507
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert isinstance(t, TF1IE)


# Generated at 2022-06-24 13:09:50.560235
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:09:51.679662
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:09:53.548991
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("")
    assert "TF1IE" in str(t)


# Generated at 2022-06-24 13:09:58.709898
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Initialize instance of class TF1IE
    tf1ie = TF1IE()

    # Output should be true
    print(tf1ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'))

# Generated at 2022-06-24 13:10:02.346547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'
    assert tf1._VALID_URL == TF1IE._VALID_URL
    assert tf1._TESTS == TF1IE._TESTS

# Generated at 2022-06-24 13:10:04.161538
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:10:13.946338
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.url == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._TESTS[0]['url'] is 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:10:24.025877
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.IE_NAME == 'tf1'
    assert IE.IE_DESC == 'tf1.fr and wat.tv'
    assert IE.VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:30.030742
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not TF1IE().suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:33.838127
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    if ie.__class__.__name__ == 'TF1IE':
        print("Unit test for constructor of class TF1IE passed.")
    else:
        print("Unit test for constructor of class TF1IE failed.")


# Generated at 2022-06-24 13:10:37.441065
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    params_dic = {'program_slug': 'tf1/koh-lanta', 'id': 'replay-koh-lanta-22-mai-2015'}
    url = ie._VALID_URL % params_dic
    assert ie._real_extract(url)

# Generated at 2022-06-24 13:10:42.741432
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE, InfoExtractor)
    info_extractor = TF1IE(IE_NAME)

    assert info_extractor.ie_key() == 'tf1'
    assert info_extractor.ie_name() == 'tf1.fr'
    assert info_extractor.ie_url() == 'https://www.tf1.fr/'

# Generated at 2022-06-24 13:10:43.506140
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:48.026831
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test for constructor of class TF1IE """
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(test_url)

# Generated at 2022-06-24 13:10:48.655608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst is not None

# Generated at 2022-06-24 13:10:49.252871
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:10:49.819484
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:57.036488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/[^/]+/videos/[^/?&#]+\\.html'

# Generated at 2022-06-24 13:11:04.817821
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
          'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
          'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:11:09.633075
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_id = 'Quotidien-premiere-partie-11-juin-2019'
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._match_url(url) == ('13641379', '13641379', video_id)
    assert TF1IE._match_url(url) == ('13641379', '13641379', video_id)

# Generated at 2022-06-24 13:11:11.626924
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('TF1')
    assert tf1ie.get_name() == 'tf1'

# Generated at 2022-06-24 13:11:12.499797
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:11:17.112354
# Unit test for constructor of class TF1IE
def test_TF1IE():
    VideoIE = type('VideoIE', (object,), {
        '_real_extract': object(),
        '_download_json': object(),
        '_match_id': object(),
    })
    t = TF1IE.__new__(TF1IE)
    assert t.suitable(VideoIE)

# Generated at 2022-06-24 13:11:18.793825
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(str(TF1IE).startswith("TF1IE(InfoExtractor"))


# Generated at 2022-06-24 13:11:19.739132
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE=TF1IE()

# Generated at 2022-06-24 13:11:21.732462
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance = TF1IE("TF1IE")
    assert isinstance(instance, TF1IE) == True


# Generated at 2022-06-24 13:11:28.834536
# Unit test for constructor of class TF1IE
def test_TF1IE():
    player = TF1IE()
    assert player.ie_key() == 'TF1'
    assert player.ie_key() == TF1IE.ie_key()
    assert player.extractor_key() == player.ie_key()
    assert player.extractor_key() == TF1IE.extractor_key()
    assert player.SUFFIX == 'tf1.fr'
    assert player.SUFFIX == TF1IE.SUFFIX

# Generated at 2022-06-24 13:11:29.399671
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:32.627289
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(url)

# Generated at 2022-06-24 13:11:36.635275
# Unit test for constructor of class TF1IE
def test_TF1IE():
    wat_id = '0f0cdcaac35fc8f12cb1a0a7a76e0e60'
    url = 'wat:' + wat_id
    url_transparent = TF1IE._url_for_id(url)
    ie = TF1IE._build_url_result(url_transparent)
    assert ie.video_id == wat_id

# Generated at 2022-06-24 13:11:40.715145
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Constructor of class TF1IE")
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE(url)


# Generated at 2022-06-24 13:11:42.103149
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.ie_key() == 'TF1'

# Generated at 2022-06-24 13:11:43.382215
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'

# Generated at 2022-06-24 13:11:44.701884
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE.tf1ie = TF1IE();

# Generated at 2022-06-24 13:11:46.647552
# Unit test for constructor of class TF1IE
def test_TF1IE():	
    tf1 = TF1IE()
    # Test if the URL is valid
    tf1.test_valid_url()


# Generated at 2022-06-24 13:11:50.424754
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert(tf1.IE_NAME == "tf1")
    assert(tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:11:53.767363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    To test constructor of class "TF1IE"
    '''
    tf1_ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1_ie is not None


# Generated at 2022-06-24 13:11:54.776598
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:11:55.599561
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:12:05.492015
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    tf1ie = TF1IE(
        Extractor=InfoExtractor,
        RegexNotFoundError=RegexNotFoundError,
    )
    # Act
    tf1ie._real_initialize(url)
    # Assert
    assert tf1ie._VALID_URL == r'^https?://(?:www\.)tf1\.fr/([^/]+)/.*/videos/(?P<id>[^/?&#]+)\.html$'

# Generated at 2022-06-24 13:12:09.283263
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """

    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(url)
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE(url)
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    TF1IE(url)

# Generated at 2022-06-24 13:12:20.888848
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie.get_url('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie.get_id('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:12:24.462198
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Unit test

# Generated at 2022-06-24 13:12:30.703526
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert i.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not i.suitable('https://www.fight-kings.com/ninja-warrior-2018-les-temps-forts-des-finale/')

# Generated at 2022-06-24 13:12:32.247757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        return False
    else:
        return True

# Generated at 2022-06-24 13:12:36.166185
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create constructor of class TF1IE
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

    # Check docstring
    assert TF1IE.__doc__

# Generated at 2022-06-24 13:12:38.224654
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE('TF1IE', True)
    assert tf1IE.name == 'TF1IE'
    assert tf1IE._downloader is True

# Generated at 2022-06-24 13:12:39.308795
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("tf1", "1", 1, "test")

# Generated at 2022-06-24 13:12:40.083726
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:12:45.963569
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:12:56.131511
# Unit test for constructor of class TF1IE
def test_TF1IE():
    args = {
        'url': 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    }
    mocker = Mock()

# Generated at 2022-06-24 13:13:02.661499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert TF1IE._VALID_URL == TF1IE.VALID_URL
    assert TF1IE._TESTS == TF1IE.TESTS
    assert TF1IE._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')['id'] == '13641379'

# Generated at 2022-06-24 13:13:07.291843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(None)
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1ie.IE_NAME == '1fichier:wat'

# Generated at 2022-06-24 13:13:07.897188
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)

# Generated at 2022-06-24 13:13:11.967719
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE()
    ie.extract(url)

# Generated at 2022-06-24 13:13:12.564156
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:13:15.125080
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:13:18.158768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Class is instantiated successfully
    assert hasattr(TF1IE, '_real_extract')

    # Subclass of InfoExtractor
    assert issubclass(TF1IE, InfoExtractor)

# Generated at 2022-06-24 13:13:24.789572
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

    assert_equal(ie._VALID_URL, r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert_equal(ie.ie_key(), 'TF1')
    assert_equal(ie.host, 'www.tf1.fr')

# Generated at 2022-06-24 13:13:25.516701
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:13:26.542321
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst != None

# Generated at 2022-06-24 13:13:27.344400
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:27.972863
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:13:30.281779
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj_ie = TF1IE()
    assert obj_ie.ie_key() == 'TF1'
    assert obj_ie.ie_name() == 'TF1'


# Generated at 2022-06-24 13:13:34.714215
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    
    """
    test_url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    tf1ie = TF1IE()
    extracted_url = tf1ie.extract(test_url)


# Generated at 2022-06-24 13:13:40.364218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert (tf1ie.program_slug == "quotidien-avec-yann-barthes")
    assert (tf1ie.slug == "quotidien-premiere-partie-11-juin-2019")

# Generated at 2022-06-24 13:13:42.548707
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:13:54.180939
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE"""
    # Test valid URL
    json_data = {
        'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
        'variables': json.dumps({
            'programSlug': 'tmc/quotidien-avec-yann-barthes',
            'slug': 'quotidien-premiere-partie-11-juin-2019',
        })
    }
    program_slug = 'tmc/quotidien-avec-yann-barthes'
    slug = 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:14:03.261434
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .wat import WatIE
    from .tf1_video import TF1VideoIE
    from .francetv import FranceTVIE


# Generated at 2022-06-24 13:14:06.825384
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'



# Generated at 2022-06-24 13:14:09.198767
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:14:16.668799
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'
    assert ie.target_id == 'replay-koh-lanta-22-mai-2015'
    assert ie.video_id == '461720'

# Generated at 2022-06-24 13:14:26.173615
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = TF1IE()._VALID_URL
    program_slug, slug = re.match(test_url,
                                  'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html').groups()
    assert program_slug and slug
    test_url = TF1IE()._VALID_URL
    program_slug, slug = re.match(test_url,
                                  'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html').groups()
    assert program_slug and slug

# Generated at 2022-06-24 13:14:29.045819
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:14:31.121334
# Unit test for constructor of class TF1IE
def test_TF1IE():

    t1ie = TF1IE();

    # Test if the TF1IE constructor returns a non-null value
    assert t1ie != None;

# Generated at 2022-06-24 13:14:33.332725
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check if TF1IE constructor creates a valid instance of the class
    assert TF1IE is not None
    IE = tf1IE()

# Generated at 2022-06-24 13:14:41.926900
# Unit test for constructor of class TF1IE
def test_TF1IE():
    my_object = TF1IE('TF1IE', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', 'My test')
    # Unit test for __init__ method of class TF1IE
    assert my_object.name == 'TF1IE', "__init__ method of class TF1IE failed"
    assert my_object.url == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', "__init__ method of class TF1IE failed"

# Generated at 2022-06-24 13:14:42.377913
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:14:43.248712
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == 'tf1'

# Generated at 2022-06-24 13:14:47.145863
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # Static test for TF1IE __init__() function
    assert TF1IE(url)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:14:49.551011
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.TF1IE == True

# Generated at 2022-06-24 13:14:53.853667
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor = TF1IE().__class__
    assert len(constructor._TESTS) == 3
    assert constructor._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:54.925471
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test with good and bad url's
    test_good_url()
    test_bad_url()


# Generated at 2022-06-24 13:15:02.414896
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Setup
    test_object = TF1IE()
    test_object._download_json = lambda url, video_id, query: \
        {'data': {'videoBySlug': {}}}
    test_object.add_default_headers = lambda: None

    # Execute
    test_case = test_object._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

    # Assert
    assert test_case['_type'] == 'url_transparent'
    assert test_case['url'] == 'wat:'

# Generated at 2022-06-24 13:15:12.189993
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:15:13.395326
# Unit test for constructor of class TF1IE
def test_TF1IE():
  ie = TF1IE()

# Generated at 2022-06-24 13:15:23.716539
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    test_obj = TF1IE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert test_obj.suitable(test_url) == True
    assert test_obj._TESTS[0]['url'] == test_url
    assert test_obj._TESTS[0]['only_matching'] == False

# Generated at 2022-06-24 13:15:28.259508
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor

    assert isinstance(InfoExtractor.TF1IE, type)
    assert hasattr(InfoExtractor.TF1IE, 'suitable')
    assert hasattr(InfoExtractor.TF1IE, 'can_handle_url')
    assert hasattr(InfoExtractor.TF1IE, '_real_extract')

# Generated at 2022-06-24 13:15:29.705058
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.initialize()

# Generated at 2022-06-24 13:15:30.836145
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test non-video URL should be ignored
    ie = TF1IE('http://www.tf1.fr/')
    assert ie.result() is False

# Generated at 2022-06-24 13:15:41.775143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # A test case to make sure that the constructor of TF1IE works properly
    test_instance = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert test_instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:48.221052
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie
    assert ie._VALID_URL
    assert ie._TESTS
    assert ie._WAT_TEMPLATE
    assert ie._download_json
    assert ie._extract_urls
    assert ie._extract_wowza_formats
    assert ie._extract_wowza_formats_from_smil
    assert ie._real_extract
    assert ie.ie_key()

# Generated at 2022-06-24 13:15:52.512972
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_instance = TF1IE()
    assert tf1_instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:02.605309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:03.596205
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, None)

# Generated at 2022-06-24 13:16:11.108226
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tests = [("TEST_VIDEO_ID_1", "TEST_PROGRAM_SLUG_1", "https://www.tf1.fr/TEST_PROGRAM_SLUG_1/videos/TEST_VIDEO_ID_1.html")]
    for video_id, program_slug, url in tests:
        tf1ie = TF1IE(url="url")
        assert tf1ie.video_id == video_id
        assert tf1ie.program_slug == program_slug

# Generated at 2022-06-24 13:16:12.412911
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1 = TF1IE()
    return TF1


# Generated at 2022-06-24 13:16:19.345868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE_TEST = TF1IE()
    # Test _VALID_URL
    assert IE_TEST._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # Test __init__
    assert IE_TEST._downloader == None
    # Test _real_extract
    assert IE_TEST._real_extract == None

# Generated at 2022-06-24 13:16:26.715376
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_cases = [
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html',
    ]
    for test in test_cases:
        assert TF1IE._VALID_URL.match(test), 'Invalid test: {}'.format(test)
    assert True

# Generated at 2022-06-24 13:16:27.766161
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-24 13:16:38.255112
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    assert ie.VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:16:42.286171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1._download_json = lambda *args, **kwargs: {}
    tf1._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:16:44.046233
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')


# Generated at 2022-06-24 13:16:46.166514
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', 'Quotidien avec Yann Barthès')

# Generated at 2022-06-24 13:16:47.892552
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # a simple test, only check if it can be instantiated
    assert TF1IE();


# Generated at 2022-06-24 13:16:56.335515
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()

# Generated at 2022-06-24 13:16:56.886999
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:59.235012
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://wat.tv')
    assert(ie.__class__.__name__ == "TF1IE")

# Generated at 2022-06-24 13:17:01.074929
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    url  = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    t.suitable(url)

# Generated at 2022-06-24 13:17:03.020332
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """
    url = "test"
    TF1IE(url)

# Generated at 2022-06-24 13:17:04.572636
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Static constructor test case of class TF1IE
    """
    TF1IE()



# Generated at 2022-06-24 13:17:05.626336
# Unit test for constructor of class TF1IE
def test_TF1IE():
    loader = TF1IE()
    instance = loader

# Generated at 2022-06-24 13:17:15.107865
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:16.184074
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Simple smoke test
    ie = TF1IE()

# Generated at 2022-06-24 13:17:17.282343
# Unit test for constructor of class TF1IE
def test_TF1IE():
	ie = TF1IE('TF1IE')

# Generated at 2022-06-24 13:17:22.712950
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('tf1ie')
    # Test if all required attributes are set
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:25.932227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:30.494351
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE().suitable(url)
    assert TF1IE().IE_NAME == 'tf1'

# Generated at 2022-06-24 13:17:31.116299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:17:33.851166
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie.ie_key() == 'TF1')
    assert(ie.ie_name() == 'TF1')
    assert(ie.SUCCESS == True)

# Generated at 2022-06-24 13:17:34.755941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Tested in test_TF1IE
    pass

# Generated at 2022-06-24 13:17:35.699566
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:17:36.659460
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("", "", "")

# Generated at 2022-06-24 13:17:37.230469
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:38.922931
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie_instance = TF1IE()
    print(tf1ie_instance)

# Generated at 2022-06-24 13:17:44.031710
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1'
    assert tf1.ie_name() == 'TF1'
    assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True

# Generated at 2022-06-24 13:17:44.644061
# Unit test for constructor of class TF1IE
def test_TF1IE():
	pass

# Generated at 2022-06-24 13:17:48.562426
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('TF1IE', 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert instance.info()

# Generated at 2022-06-24 13:17:48.894940
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:17:49.464617
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:17:50.311120
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:17:51.710309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        raise


# Generated at 2022-06-24 13:17:52.777466
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:18:02.597808
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    expected_json_keys = ['id', 'ext', 'title', 'description', 'upload_date', 'timestamp', 'duration', 'series', 'tags']
    assert tf1ie._TESTS[0]['info_dict'].keys() == set(expected_json_keys)

# Generated at 2022-06-24 13:18:06.095085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    params = {
        'url': 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'info_dict': 'md5:f392bc52245dc5ad43771650c96fb620',
        'params': {
            'skip_download': True,
        }
    }
    return TF1IE()._test_extraction(params)

# Generated at 2022-06-24 13:18:11.588700
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.SUFFIX == 'tf1.fr'
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:22.107867
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    obj = TF1IE(url)

    assert re.match('https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html', url) is not None
    assert obj.get_url() == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert obj.get_program_slug() == 'koh-lanta'