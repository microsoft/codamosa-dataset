

# Generated at 2022-06-24 13:08:22.704790
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Provide arguments to constructor of TF1IE
    and check if object is correctly initialized
    """
    tf1_entry = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1_entry._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Check if correct InfoExtractor is returned by TF1IE

# Generated at 2022-06-24 13:08:25.825739
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.ie_key() == "TF1"
    assert tf1ie.ie_name() == "TF1"

# Generated at 2022-06-24 13:08:28.948000
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:08:34.047916
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.ie_key() == 'TF1'
    assert tf1ie.ie_name() == 'TF1'
    assert tf1ie.ie_description() == 'tf1.fr'
    assert tf1ie.ie_version() != None
    assert tf1ie.IE_DESC == 'tf1.fr'

# Generated at 2022-06-24 13:08:35.252616
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if __name__ == '__main__':
        main()
    TF1IE()

# Generated at 2022-06-24 13:08:36.873773
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1'

# Generated at 2022-06-24 13:08:44.485484
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL=='https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:08:45.534836
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()



# Generated at 2022-06-24 13:08:46.566664
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() != None

# Generated at 2022-06-24 13:08:49.132789
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    TF1 IE constructor test
    """
    TF1IE('https://www.wat.tv/video/france-video-interactive-5z5c2.html')

# Generated at 2022-06-24 13:08:58.265390
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert tf._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:04.673735
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)

    assert ie.test()

    assert not re.match(ie.VALID_URL, None)
    assert re.match(ie.VALID_URL, "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert re.match(ie.VALID_URL, "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert re.match(ie.VALID_URL, "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

    assert ie

# Generated at 2022-06-24 13:09:05.618113
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is TF1IE


# Generated at 2022-06-24 13:09:10.157131
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE()
    ie._downloader = None
    ie.extract(url)

# Generated at 2022-06-24 13:09:11.176128
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-24 13:09:11.938157
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:09:18.410837
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert tf1.program_slug == "quotidien-avec-yann-barthes"
    assert tf1.slug == "quotidien-premiere-partie-11-juin-2019"

# Generated at 2022-06-24 13:09:19.748305
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:09:26.810144
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:37.623977
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.url = "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    assert tf1._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-24 13:09:42.328721
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    if ie is None:
        raise AssertionError("Unit test for TF1IE failed: Constructor expected is not None")
    return True


# Generated at 2022-06-24 13:09:49.397280
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with a valid url
    tf1 = TF1IE()
    assert tf1._match_id('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1._match_id('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

    # Test with an invalid url
    assert tf1._match_id('http://www.tf1.fr/tf1/koh-lanta/') is None
    assert tf1._match_id('http://www.tf1.fr/tf1/koh-lanta/videos.html') is None

# Generated at 2022-06-24 13:09:50.387788
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:09:54.473466
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if __name__ == "__main__":
        ie = TF1IE()
        ie.download_webpage('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:09:56.438946
# Unit test for constructor of class TF1IE
def test_TF1IE():
    s = TF1IE()
    assert s.url == 'https://www.tf1.fr/graphql/web'

# Generated at 2022-06-24 13:10:07.157342
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor test
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE()._match_id(url) == ('quotidien-avec-yann-barthes', 'quotidien-premiere-partie-11-juin-2019')
    assert TF1IE()._match_id(url, False) == '13641379'
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-24 13:10:16.587242
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test the constructor of class TF1IE
    #
    # Args:
    #    TF1IE (TF1IE): the class to be tested
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    obj_TF1IE = TF1IE('mocked url')

    assert obj_TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html', \
        'The mock object TF1IE has wrong attribute _VALID_URL'


# Generated at 2022-06-24 13:10:18.604385
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf = TF1IE()
    assert tf is not None


# Generated at 2022-06-24 13:10:21.030122
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('wat', 'wat')
    assert ie.ie_key() == 'wat'
    assert ie.suitable('wat') is True
    assert ie.working

# Generated at 2022-06-24 13:10:27.476614
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:10:37.036121
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    first_test = TF1IE()
    assert first_test._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:38.163743
# Unit test for constructor of class TF1IE
def test_TF1IE():
    expected = TF1IE
    TF1IE()
    assert TF1IE is expected

# Generated at 2022-06-24 13:10:45.049407
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Given a valid url,
    When the TF1IE constructor is called with this url,
    Then the result is an instance of TF1IE.
    """
    result = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert(isinstance(result, TF1IE))


# Generated at 2022-06-24 13:10:45.652488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-24 13:10:54.742655
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    print(ie.suitable(ie.IE_NAME, "Quotidien avec Yann Barthès - Première partie du 11 juin 2019 - #6UneNouvelleVieDepuisLa"
                                   "NaissanceDeMaFilleOdette#6UneNouvelleVieDepuisLaNaissanceDeMaFilleOdette")
          , ie.suitable(ie.IE_NAME, "md5:f392bc52245dc5ad43771650c96fb620"))

# Generated at 2022-06-24 13:10:56.857022
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_test = TF1IE('')
    assert isinstance(TF1IE_test, InfoExtractor)

# Generated at 2022-06-24 13:11:02.683944
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ != 'TF1IE'
    instance = TF1IE()
    assert instance.__name__ == 'TF1IE'
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:03.876873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-24 13:11:10.537581
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.get_domain() == "tf1.fr"
    assert t.get_expected_url_regex() == r"https://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"
    assert t.get_patterns() == [r"https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"]

# Generated at 2022-06-24 13:11:11.711058
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)



# Generated at 2022-06-24 13:11:16.993265
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('md5:d41d8cd98f00b204e9800998ecf8427e');
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:20.750410
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(
        url="http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
        name="koh-lanta",
        comment="Replay Koh Lanta du 22 mai 2015")

# Generated at 2022-06-24 13:11:22.052424
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try_get(0, lambda x: x['publicPlayingInfos']['duration'])

# Generated at 2022-06-24 13:11:25.282801
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Tests a simple constructor of the class to check if it's working
    """
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:11:33.731258
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    m = re.match(TF1IE._VALID_URL, url)
    assert m.group(1) == 'tmc'
    assert m.group(2) == 'quotidien-premiere-partie-11-juin-2019'
    assert m.group(1) == 'tmc'
    assert m.group(2) == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:11:43.521164
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html?param=test')
    ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html#test')
    ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html?param=test#test')

# Generated at 2022-06-24 13:11:45.169335
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE({})
    expected = TF1IE
    actual = obj.__class__
    assert actual == expected

# Generated at 2022-06-24 13:11:47.798335
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except NameError as e:
        ok = 'name \'TF1IE\' is not defined' in str(e)
        if not ok:
            raise e


# Generated at 2022-06-24 13:11:48.471726
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:55.809116
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test if the constructor of class TF1IE work fine
    video = TF1IE()

    assert video.ie_key() == 'TF1'
    assert video.host() == 'www.tf1.fr'
    assert video.extract_program_slug('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == 'quotidien-avec-yann-barthes'
    assert video.extract_program_slug('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == 'koh-lanta'
    assert video.extract_program_slug

# Generated at 2022-06-24 13:11:59.773283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    except:
        assert False

# Generated at 2022-06-24 13:12:00.278683
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_instance = TF1IE()
    return

# Generated at 2022-06-24 13:12:05.720439
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Init")
    tf1 = TF1IE()

    print("Comparing")
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

    print("Testing")
    for test in tf1._TESTS:
        assert tf1._real_extract(test['url'])

    print("Test passed")

# Generated at 2022-06-24 13:12:07.348218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:12:10.182242
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("test")
    classname = tf1ie.__class__.__name__
    assert classname == "TF1IE"

# Generated at 2022-06-24 13:12:12.207416
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('tmc', 'Quotidien avec Yann Barthès', '13641379')

# Generated at 2022-06-24 13:12:13.191588
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()


# Generated at 2022-06-24 13:12:15.101956
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract(test_TF1IE.__name__)

# Generated at 2022-06-24 13:12:25.615185
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._TESTS[0]['url'] ==  'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._TESTS[0]['info_dict']['id'] == '13641379'
    assert TF1IE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert TF1IE._TESTS[0]['info_dict']['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'

# Generated at 2022-06-24 13:12:26.420483
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:12:33.259595
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE() 
    assert instance.IE_NAME == 'tf1'
    test_url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert instance._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'
    assert instance._real_extract(test_url)

# Generated at 2022-06-24 13:12:35.710475
# Unit test for constructor of class TF1IE
def test_TF1IE():

    tf1 = TF1IE()

    assert tf1.tf1_url == 'http://www.tf1.fr/videos'

# Generated at 2022-06-24 13:12:36.562430
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

# Generated at 2022-06-24 13:12:39.013766
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert 'Quotidien avec Yann Barthès' == TF1IE()._real_extract({
        'data': {
            'videoBySlug': {
                'decoration': {
                    'programLabel': 'Quotidien avec Yann Barthès'
                }
            }
        }
    })['series']

# Generated at 2022-06-24 13:12:44.630495
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True
    assert ie.suitable('http://www.wat.tv/video/koh-lanta-22-mai-2015-replay-1dptx_1dvt0_.html') == False

# Generated at 2022-06-24 13:12:50.967921
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1ie = TF1IE(url=url)
    program_slug = tf1ie.program_slug
    slug = tf1ie.slug
    assert program_slug == 'koh-lanta'
    assert slug == 'replay-koh-lanta-22-mai-2015'


# Generated at 2022-06-24 13:12:53.327791
# Unit test for constructor of class TF1IE
def test_TF1IE():
    preprocess_json = lambda x: x
    TF1IE(test_TF1IE, TF1IE._VALID_URL,preprocess_json)

# Generated at 2022-06-24 13:12:55.846411
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor.name == 'tf1.fr'
    assert info_extractor.title == 'tf1.fr'

# Generated at 2022-06-24 13:12:59.354067
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t._VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:00.804811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except (AttributeError, TypeError):
        assert False
    assert True

# Generated at 2022-06-24 13:13:03.807899
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert TF1IE._VALID_URL == url


# Generated at 2022-06-24 13:13:04.766059
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.suite()

# Generated at 2022-06-24 13:13:08.146956
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:18.065063
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[1] == { 'url': 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'only_matching': True }
    assert TF1IE._TESTS[2] == { 'url': 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', 'only_matching': True }


# Generated at 2022-06-24 13:13:19.203448
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()


# Generated at 2022-06-24 13:13:30.003860
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"))
    assert(TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"))
    assert(TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"))
    assert(TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"))


# Generated at 2022-06-24 13:13:32.612864
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:13:36.413915
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test a constructor of class TF1IE."""
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:13:38.408783
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test if the TF1IE object is instantiated
    ie = TF1IE()
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-24 13:13:39.317420
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)

# Generated at 2022-06-24 13:13:40.193911
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:51.145787
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE('www.tf1.fr/tf1/plus-belle-la-vie/videos/belle-la-vie-la-quotidienne-du-lundi-13-avril-2015.html')
    assert info._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'
    assert info._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:14:00.847868
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test extracting wat IDs

    assert TF1IE._real_extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')['id'] == '13649424'

    # Test extracting program slug and slug

    assert TF1IE._real_extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')['_type'] == 'url_transparent'

    # Test extracting title

    assert TF1IE._real_extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')['title'] == "Mylène Farmer, d'une icône à l'autre"

    # Test extracting

# Generated at 2022-06-24 13:14:03.771899
# Unit test for constructor of class TF1IE
def test_TF1IE():
    #without specifying wat_id to get the dict fields
    TF1IE('wat', None, None, None)
    #with specifying wat_id to get the dict fields
    TF1IE('wat', None, None, None, wat_id='13641379')

# Generated at 2022-06-24 13:14:12.123193
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE();
    assert tf1ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html');
    assert tf1ie.suitable('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html');
    assert not tf1ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html');

# Generated at 2022-06-24 13:14:14.067961
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global tf1
    tf1 = TF1IE()


# Generated at 2022-06-24 13:14:20.123954
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('TF1IE', {})
    assert isinstance(instance, TF1IE)
    assert isinstance(instance, InfoExtractor)
    assert hasattr(TF1IE, '_VALID_URL')
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert hasattr(TF1IE, '_TESTS')
    assert len(TF1IE._TESTS) == 3

# Generated at 2022-06-24 13:14:23.328423
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.ie_name() == 'TF1'
    assert ie.http_headers() is None
    assert ie.working

# Generated at 2022-06-24 13:14:24.373354
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()


# Generated at 2022-06-24 13:14:28.140718
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE("TF1IE")
    if test_obj.suitable("TF1IE"):
        assert("TF1IE statisfied")
    else:
        assert("TF1IE not statisfied")


# Generated at 2022-06-24 13:14:30.571881
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE('abcdefghijk')
    # assert x.constructor_output == 'abcdefghijklmnopqrst'
    # assert len(x) == 23

# Generated at 2022-06-24 13:14:36.209764
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    # raise a ValueError if constructor fails
    # as the __init__ method of the parent class InfoExtractor
    # has a assert to check the declaration of _VALID_URL
    instance.url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:14:37.305342
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie

# Generated at 2022-06-24 13:14:44.294108
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url=url, page_url=url)
    assert(ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html')
    assert(ie.name._NAME == 'tf1')

# Generated at 2022-06-24 13:14:46.897787
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    tf1IE.test_page_info_number = 0
    assert tf1IE.test_page_info() == 1
    assert tf1IE.test_page_info_number == 1



# Generated at 2022-06-24 13:14:52.125524
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    obj = TF1IE(url)
    assert obj == TF1IE(obj.url)

# Generated at 2022-06-24 13:14:59.101790
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test single video
    t1 = TF1IE()
    t1_test = t1._real_extract(t1._TESTS[0]['url'])
    assert (t1_test['id'] == '13641379')
    assert (t1_test['title'] == 'md5:f392bc52245dc5ad43771650c96fb620')
    assert (t1_test['description'] == 'md5:a02cdb217141fb2d469d6216339b052f')
    assert (t1_test['tags'] == ['intégrale', 'quotidien', 'Replay'])
    # Test constructor of class

# Generated at 2022-06-24 13:15:01.199870
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    This test will pass for sure since we have tested it in 
    the extractor. So its only a sanity check
    """
    TF1IE()

# Generated at 2022-06-24 13:15:04.494471
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE('www.tf1.fr/tf1/koh-lanta')
    assert isinstance(i, TF1IE)

# Test that constructor of class TF1IE fails on an invalid url

# Generated at 2022-06-24 13:15:08.550219
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE_instance = TF1IE()
    # print(tf1IE_instance._VALID_URL)
    print(tf1IE_instance.__class__.__name__) # print this module class name
    print(tf1IE_instance.__class__.__bases__) # print this module base class name

# Generated at 2022-06-24 13:15:12.500085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    print(ie.format_url(''))

test_TF1IE()

# Generated at 2022-06-24 13:15:14.366757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(None)
    assert tf1.get_supported_extensions() == ['mp4', 'm3u8']

# Generated at 2022-06-24 13:15:16.886326
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_info = TF1IE()

    video_info.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:15:27.940695
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.is_valid_url("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie.is_valid_url("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie.is_valid_url("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    # these urls are not valid
    assert not ie.is_valid_url("http://www.tf1.fr/tf1/koh-lanta.html")


# Generated at 2022-06-24 13:15:29.762390
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)


# Generated at 2022-06-24 13:15:30.494572
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'

# Generated at 2022-06-24 13:15:31.630970
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:15:32.121619
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:34.449048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .constructor import IEConstructor
    TF1IE.construct = IEConstructor(TF1IE)

# Generated at 2022-06-24 13:15:35.979053
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1._real_extract("")

# Generated at 2022-06-24 13:15:39.305905
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://example.com")
    TF1IE("http://example.com/foo.bar")
    TF1IE("http://example.com/foo.bar?baz")

# Generated at 2022-06-24 13:15:45.406593
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')


if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:15:46.996451
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

test_TF1IE()

# Generated at 2022-06-24 13:15:51.753943
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert IE.get_id() == "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"

# Generated at 2022-06-24 13:15:53.153023
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)


# Generated at 2022-06-24 13:15:54.578312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()
    assert(result != None)

# Generated at 2022-06-24 13:15:55.181677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:05.862464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for the TF1 embed URL
    embed_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    embed_query = {'id': '13641379', 'ext': 'mp4', 'title': 'md5:f392bc52245dc5ad43771650c96fb620', 'description': 'md5:a02cdb217141fb2d469d6216339b052f', 'upload_date': '20190611', 'timestamp': 1560273989, 'duration': 1738, 'series': 'Quotidien avec Yann Barthès', 'tags': ['intégrale', 'quotidien', 'Replay']}

# Generated at 2022-06-24 13:16:16.693203
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test with url that has episode
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1ie = TF1IE(url)

    assert tf1ie.url == url, 'url of the object is not the same as given url'

    assert tf1ie.program_slug == 'koh-lanta', 'program_slug is not the same as expected'

    assert tf1ie.slug == 'replay-koh-lanta-22-mai-2015', 'slug is not the same as expected'

    assert tf1ie.name == tf1ie.IE_NAME, 'name is not the same as expected'


# Generated at 2022-06-24 13:16:21.378293
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test that the constructor is working.
    #
    # This doesn't actually do anything, but if the constructor fails then it
    # will be caught by the unit test framework.
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:16:23.347273
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL
    assert instance._TESTS
    assert instance._download_json

# Generated at 2022-06-24 13:16:24.095229
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:16:26.926658
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:16:31.601564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    rd = TF1IE()
    # Tests the constructor of tf1.py
    assert rd._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html', "Incorrect constructor"

# Generated at 2022-06-24 13:16:34.136000
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(TF1IE.IE_NAME, TF1IE._VALID_URL).suitable(TF1IE._VALID_URL)

# Generated at 2022-06-24 13:16:36.715188
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE('non-used-url')
    print(infoExtractor.parameters)
    assert infoExtractor.parameters

# Generated at 2022-06-24 13:16:39.610879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE.TF1IE()
    assert isinstance(ie, (InfoExtractor, TF1IE))
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_VALID_URL')

# Generated at 2022-06-24 13:16:41.183417
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(TF1IE(), InfoExtractor)

# Generated at 2022-06-24 13:16:49.437141
# Unit test for constructor of class TF1IE
def test_TF1IE():
    module = 'youtube_dl.extractor.tf1.TF1IE'
    class_name = 'TF1IE'
    expected_attributes = ['_VALID_URL', '_TESTS', '_real_extract']
    init = True
    instance = globals()[class_name]()
    for attr in expected_attributes:
        if not hasattr(instance, attr):
            print('%s has no %s attribute' % (class_name, attr))
            init = False
    if init:
        print('%s is well initialized' % class_name)


# Generated at 2022-06-24 13:16:50.084360
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:51.684194
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_common import do_test_class
    do_test_class(TF1IE)

# Generated at 2022-06-24 13:16:52.178644
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:02.125323
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:11.143565
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'

    expected = {
        'url': 'wat:13661532',
        'id': '13661532',
        'title': 'Mylène Farmer, d\'une icône',
        'description': 'md5:7c27d57e64feecbf64e8da610c0b5683',
        'timestamp': 1557835060,
        'duration': 8967,
        'tags': ['Hd', 'intégrale', 'Replay'],
        'series': 'Documentaire',
        'season_number': 1,
        'episode_number': 1,
    }


# Generated at 2022-06-24 13:17:12.013866
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('pouf pouf')

# Generated at 2022-06-24 13:17:12.576651
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:22.205116
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') is not None
    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is not None
    assert re.match(TF1IE._VALID_URL, 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') is not None

# Generated at 2022-06-24 13:17:29.223695
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_html5_media_info import test_html5_media_info
    # test instance creation and running the _real_extract() method
    instance = TF1IE()
    assert instance._downloader is not None
    assert instance._WORKING is True
    
    info = instance._extract_info('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert info is not None
    test_html5_media_info(info)

# Generated at 2022-06-24 13:17:32.345183
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.get_url_re() == TF1IE._VALID_URL
    assert ie.get_name() == TF1IE.ie_key()
    assert ie.get_supported_domains() == ['tf1.fr']

# Generated at 2022-06-24 13:17:36.007810
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('tf1', 'tf1')._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:38.788040
# Unit test for constructor of class TF1IE
def test_TF1IE():
	ie = TF1IE()
	assert class_name(ie) == 'TF1IE'
	assert class_type(ie) == 'constructor'


# Generated at 2022-06-24 13:17:39.769619
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suite()

# Generated at 2022-06-24 13:17:42.485594
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:17:46.755085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.info_extractors.get('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == TF1IE._real_extract

# Generated at 2022-06-24 13:17:49.673372
# Unit test for constructor of class TF1IE
def test_TF1IE():
        TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:51.564379
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('TF1', False, 'www.tf1.fr')
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 13:17:58.630661
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('tf1')
    assert tf1.url_result('http://wat.tf1.fr/tf1/voice-kids/videos/replay-the-voice-kids-saison-4-episode-4-25-mai-2016.html')
    assert 'wat' in tf1.playlist_result('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/')[0]['url']

# Generated at 2022-06-24 13:17:59.249477
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:17:59.639625
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:18:01.863722
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    obj = ie.ie_key()
    assert obj == 'TF1'
    obj = repr(ie)
    assert obj == '<TF1IE>'
    obj = str(ie)
    assert obj == 'TF1'

# Generated at 2022-06-24 13:18:03.589475
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.extractor_key() == 'TF1.fr'

# Generated at 2022-06-24 13:18:10.213723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit_test = TF1IE()

    # Test invalid URL
    assert unit_test.suitable('http://www.tf1.fr') == False
    assert unit_test.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert unit_test.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True

    # Test extract() : bad format parameter

# Generated at 2022-06-24 13:18:21.102950
# Unit test for constructor of class TF1IE