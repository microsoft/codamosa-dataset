

# Generated at 2022-06-24 13:08:22.076113
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE({})

# Generated at 2022-06-24 13:08:25.771630
# Unit test for constructor of class TF1IE
def test_TF1IE():
    with open('tf1.txt') as f:
        content = f.read()
    p = TF1IE()
    p.suitable(content)
    p.extract(content)
    p.download_webpage('http://foo.com/bar', content)

# Generated at 2022-06-24 13:08:27.365940
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception:
        assert False, "Instantiation failed"


# Generated at 2022-06-24 13:08:28.543770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test.suite()

# Generated at 2022-06-24 13:08:36.528730
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("test_TF1IE 1")
    # Test case 1
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1 = TF1IE()
    tf1.url = url
    (program_slug, slug) = tf1._real_extract(url)
    assert program_slug == 'quotidien-avec-yann-barthes'
    assert slug == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:08:39.240892
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", None, False)

# Generated at 2022-06-24 13:08:39.826465
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('...','...')

# Generated at 2022-06-24 13:08:40.924638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        unit = TF1IE()
    except Exception as e:
        unit = e

    assert unit is None

# Generated at 2022-06-24 13:08:43.208701
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test if TF1IE is working
    """
    tf1 = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert type(tf1) == TF1IE

# Generated at 2022-06-24 13:08:43.789757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:08:45.133601
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    return


# No constructor parameter

# Generated at 2022-06-24 13:08:54.977704
# Unit test for constructor of class TF1IE
def test_TF1IE():

    liste_url = [
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ]

    for url in liste_url:
        print("URL : " + url)
        ie = TF1IE(url)
        print("\nExtracting...")
        ie._real_extract(url)
        print("\nDone\n")

# Generated at 2022-06-24 13:09:04.817981
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_downloader import Downloader
    from .test_extractor import Extractor

    class TF1MockDownloader(Downloader):
        def __init__(self, params):
            pass
        
        def to_screen(self, string):
            pass
        
        def report_warning(self, msg):
            pass

    class TF1MockExtractor(Extractor):
        def __init__(self, downloader=None, params=None):
            pass
        
        def to_screen(self, string):
            pass
        
        def report_warning(self, msg):
            pass

        def _download_webpage(self, url, video_id, fatal=True):
            return None

        def _real_extract(self, url):
            return None

    # Test if an instance of TF1IE

# Generated at 2022-06-24 13:09:16.145575
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE('test')

    assert TestTF1IE._VALID_URL == x._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:16.618114
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:09:22.536203
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:09:28.211450
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert(instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:09:29.720277
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE"""
    TF1IE()

# Generated at 2022-06-24 13:09:39.852098
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:45.087164
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:09:45.614677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()

# Generated at 2022-06-24 13:09:47.549605
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert 'wat' in TF1IE._downloader.params['protocols']
    except AssertionError:
        print('AssertionError')


# Generated at 2022-06-24 13:09:51.904473
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.name == 'tf1'
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:57.199243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    instance._real_extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:09:58.609656
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Tests TF1IE constructor"""
    TF1IE("")

# Generated at 2022-06-24 13:09:59.856952
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None).extract(None)

# Generated at 2022-06-24 13:10:04.883020
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.IE_NAME == "TF1"
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Test with live data

# Generated at 2022-06-24 13:10:08.978386
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:11.801720
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.url_result('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') is not None

# Generated at 2022-06-24 13:10:12.757170
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:22.913026
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie.webpage_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1ie.webpage_id = '13641379'
    tf1ie.webpage_title = 'Quotidien - Première partie'

# Generated at 2022-06-24 13:10:25.077116
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:10:29.940659
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # First, instanciate the class
    t = TF1IE();

    # Then, test its method
    assert(t.suitable('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'))

# Generated at 2022-06-24 13:10:30.558241
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:31.332844
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE

# Generated at 2022-06-24 13:10:32.790061
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("TF1IE", {})

# Generated at 2022-06-24 13:10:36.815810
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'tf1'
    assert ie.ie_key_long() == 'TF1'
    assert ie.RATING_REGEX == r'(?:Notez ce programme :|Vous avez noté) (?P<rating>\d+)\/5'
    assert ie.get_playlist_title() == 'featured'

# Generated at 2022-06-24 13:10:37.296601
# Unit test for constructor of class TF1IE
def test_TF1IE():
	pass

# Generated at 2022-06-24 13:10:42.142085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Constructor of class TF1IE should return a tf1ie-object"""
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(url)

# Generated at 2022-06-24 13:10:44.179980
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor())._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:10:45.139941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-24 13:10:54.357132
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = InfoExtractor("test_TF1IE", True, watch_url="")
    info_extractor.add_info_extractor("TF1IE")
    test_info = info_extractor.extract("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert test_info["title"] == "Quotidien première partie - 11 juin 2019"
    assert test_info["_type"] == "url_transparent"
    assert test_info["id"] == "13641379"
    assert test_info["upload_date"] == "20190611"

# Generated at 2022-06-24 13:10:56.808527
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE('www.tf1.fr/tf1-series-films/')
    assert extractor


# Generated at 2022-06-24 13:10:57.383870
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:07.911853
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie._TESTS[0]['info_dict']['id'] == '13641379'
    assert ie._

# Generated at 2022-06-24 13:11:11.479239
# Unit test for constructor of class TF1IE
def test_TF1IE():
    content = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    extractor = TF1IE.ie_key_for_url(content)
    assert extractor == 'TF1', 'Test for class TF1IE has failed!'

# Generated at 2022-06-24 13:11:13.173796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_instance = TF1IE()
    assert TF1IE_instance

# Generated at 2022-06-24 13:11:15.500128
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """run the constructor of the TF1IE class"""
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:11:16.709327
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()


# Generated at 2022-06-24 13:11:18.359412
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    tf1.extract()

# Generated at 2022-06-24 13:11:25.396043
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1', 'TF1 test failed!'
    assert tf1.suitable('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1.suitable('http://www.tf1.fr/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:11:30.943356
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Basic test
    """
    # Check that the class constructor is able to instantiate the class
    instance = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    # Check that the expected value is returned by the _real_extract method

# Generated at 2022-06-24 13:11:31.994605
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE


# Generated at 2022-06-24 13:11:37.799435
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('wat:' + '2ceb5ca5-871e-4f45-88a9-c84f99a59006')
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'tf1.fr and wat.tv'
    assert ie.returns_wget_downloads is True

# Generated at 2022-06-24 13:11:42.466664
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:49.573937
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    query = {
        'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
        'variables': json.dumps({
            'programSlug': 'koh-lanta',
            'slug': 'replay-koh-lanta-22-mai-2015',
        })
    }
    assert i._download_json("https://www.tf1.fr/graphql/web", 'replay-koh-lanta-22-mai-2015.html', query) == True

# Generated at 2022-06-24 13:11:53.801442
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import doctest
    TF1IE._download_json = lambda *a: {
        'data': {
            'videoBySlug': {
                'title': 'Replay Koh-Lanta - 22 mai 2015',
                'streamId': '42',
                'decoration': {
                    'programLabel': 'Koh-Lanta',
                }
            },
        }
    }
    doctest.testmod()

# Generated at 2022-06-24 13:12:03.547053
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        from . import _common as common
        from . import _download_json
        from . import _extract_info
        from . import _get_info
        from . import _url_basename
        from . import _url_basename_from_url
        from . import _url_basename_from_url
        from . import _xpath_text
        import os
        import re
        import unittest
        import urllib
        import xpath
    except ImportError as ex:
        if os.getcwd() == os.path.dirname(__file__):
            raise ex
        # else working on an installed version


# Generated at 2022-06-24 13:12:05.728004
# Unit test for constructor of class TF1IE
def test_TF1IE():

    tf1IE = TF1IE()
    tf1IE._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:06.587606
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:08.028857
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Code for detecting which extractor is needed for a URL

# Generated at 2022-06-24 13:12:09.381422
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i

# Generated at 2022-06-24 13:12:10.688585
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:12:12.310595
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:12:16.003277
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.download('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:19.378931
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except ValueError as err:
        assert str(err) == "The tf1 extractor must be called with a URL"
    else:
        assert False, "Did not raise ValueError on TF1IE()"

# Generated at 2022-06-24 13:12:28.309677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # NOTE: TF1IE is imported by some other IE tests
    # (test_youtube.py, test_crackle.py, test_crunchyroll.py).
    # Instead of disabling them, we just skip this test for python 2.
    # See https://github.com/rg3/youtube-dl/issues/18299 for details.
    import sys
    if sys.version_info < (3, 0):
        return TestVideoIE.skipTest('Unit test for TF1IE has been temporarily removed for python 2.')

    ie = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert ie.is_extractable is True

# Generated at 2022-06-24 13:12:30.152728
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie.suite()


# Generated at 2022-06-24 13:12:31.672570
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE('Quotidien avec Yann Barthes')
    assert IE.SUFFIX == '.html'

# Generated at 2022-06-24 13:12:40.486221
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Constructor for TF1IE
    # Input:
    #       ie: Instance of InfoExtractor
    # Output: An object of TF1IE
    assert TF1IE(InfoExtractor({}))._VALID_URL == r'(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE(InfoExtractor({}))._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE(InfoExtractor({}))._TESTS[0]['params']['format'] == 'bestvideo'

# Generated at 2022-06-24 13:12:41.560564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:44.502052
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:12:54.655528
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.wat.tv/video/quotidien-premiere-partie-11-juin-2019-7ijf4.html"
    t = TF1IE()
    assert t._VALID_URL == re.compile(
        r'^https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html$')
    m = re.match(t._VALID_URL, url)
    assert m is not None
    assert m.groupdict() == {"program_slug": "tmc/quotidien-avec-yann-barthes", "id": "quotidien-premiere-partie-11-juin-2019"}
    assert t._

# Generated at 2022-06-24 13:12:57.880283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().extract(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:12:58.418374
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__doc__ is not None

# Generated at 2022-06-24 13:12:58.782092
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _ = TF1IE

# Generated at 2022-06-24 13:13:00.337408
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("TF1IE")
    assert obj.name == "TF1IE"

# Generated at 2022-06-24 13:13:04.841167
# Unit test for constructor of class TF1IE
def test_TF1IE():
    expected = '<TF1IE(https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html)>'
    instance = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    result = instance.__repr__()
    assert result == expected

# Generated at 2022-06-24 13:13:05.764119
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie)

# Generated at 2022-06-24 13:13:08.847089
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:13:16.774313
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:13:20.028521
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:21.569235
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:13:22.797065
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:13:23.411983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:13:24.754829
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:13:28.692805
# Unit test for constructor of class TF1IE
def test_TF1IE(): # FIXME: unittest
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:13:29.628361
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)

# Generated at 2022-06-24 13:13:31.384947
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:13:32.519203
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

# Generated at 2022-06-24 13:13:41.625958
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE('TF1IE', 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert extractor.IE_NAME == 'TF1'
    assert extractor.IE_DESC == 'TF1'
    assert extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:44.277848
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test.extract("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-24 13:13:45.549667
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:13:53.085085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert TF1IE.suitable(tf1.ie_key())
    assert TF1IE.suitable(tf1.ie_key(),url="http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert not TF1IE.suitable(tf1.ie_key(),url="The URL is not a TF1 video URL")

# Generated at 2022-06-24 13:14:02.504257
# Unit test for constructor of class TF1IE
def test_TF1IE():
	test = TF1IE();

# Generated at 2022-06-24 13:14:12.220183
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(TF1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert(TF1IE._TESTS[0]['info_dict']['id'] == '13641379')

# Generated at 2022-06-24 13:14:14.540042
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL




# Generated at 2022-06-24 13:14:17.307881
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:14:19.167677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # print( TF1IE()._VALID_URL )
    pass

# Generated at 2022-06-24 13:14:27.715627
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not ie.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:14:28.707085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("Tf1")

# Generated at 2022-06-24 13:14:30.427162
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import TF1IE
    tf1IE = TF1IE(None)
    print(tf1IE)

# Generated at 2022-06-24 13:14:34.164925
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .tf1 import TF1IE
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:35.149051
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()

# Generated at 2022-06-24 13:14:43.136487
# Unit test for constructor of class TF1IE
def test_TF1IE():
    parser = TF1IE()
    assert parser._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:48.620021
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test real cases
    TF1IE()._real_extract(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    # Test default cases
    TF1IE()._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE()._real_extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:14:50.940066
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE({'tf1ie': 'tf1ie'}) == TF1IE({'tf1ie': 'tf1ie'})

# Generated at 2022-06-24 13:14:52.695082
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Description: Test of constructor of class TF1IE
    """
    TF1IE()


# Generated at 2022-06-24 13:14:59.371477
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    print(tf1)
    for i in tf1._TESTS:
        print(i)
        if i['url'] == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html':
            print(i)
        if i['url'] == 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html':
            print(i)

if __name__ == '__main__':
    test_TF1IE

# Generated at 2022-06-24 13:15:09.459167
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == 'tf1'
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:10.339253
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:15:19.554856
# Unit test for constructor of class TF1IE
def test_TF1IE():

    test_tf1 = TF1IE(None)

    assert test_tf1.tf1_get_source_url() == "https://wat.tf1.fr/wat/integration/externalId/?externalId="
    assert test_tf1.tf1_get_external_id_url("abcdefg") == "https://wat.tf1.fr/wat/integration/externalId/?externalId=abcdefg"

    assert test_tf1.tf1_get_get_supported_tags() == [
        "intégrale",
        "best of",
        "Koh-Lanta"
    ]


# Generated at 2022-06-24 13:15:20.566791
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()

# Generated at 2022-06-24 13:15:21.258296
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:15:22.111875
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:15:23.050960
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:32.589155
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:44.169324
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:15:45.948103
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(None).playlist, type(None))

# Generated at 2022-06-24 13:15:47.001153
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_result = TF1IE()

# Generated at 2022-06-24 13:15:49.576095
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:15:50.750491
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:15:59.643817
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with url
    TF1IE_test_class = TF1IE()
    assert TF1IE_test_class.get_url() == "None"
    # Test with url and video_id
    TF1IE_test_class = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html", "quotidien-premiere-partie-11-juin-2019")
    assert TF1IE_test_class.get_url() == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert TF1

# Generated at 2022-06-24 13:16:00.717786
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:16:01.520571
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:16:02.554605
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract()

# Generated at 2022-06-24 13:16:09.467879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.tf1_id == None
    assert t.tf1_url == None
    assert t.tf1_title == None
    assert t.tf1_description == None
    assert t.tf1_thumbnail == None
    assert t.tf1_timestamp == None
    assert t.tf1_duration == None
    assert t.tf1_series == None
    assert t.tf1_season_number == None
    assert t.tf1_episode_number == None

# Generated at 2022-06-24 13:16:11.437411
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
        assert 1
    except Exception:
        assert 0

# Generated at 2022-06-24 13:16:19.579703
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    tf1.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    tf1.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    return True

# Generated at 2022-06-24 13:16:27.402512
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit = TF1IE(InfoExtractor())
    assert unit._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:29.071667
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert isinstance(tf1, TF1IE)

# Generated at 2022-06-24 13:16:30.087238
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1

# Generated at 2022-06-24 13:16:39.800668
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .wat import WatIE
    test_TF1IE = TF1IE.construct_instance(TF1IE.suitable, 'http://www.wat.tv/video/exemple-7bzou_2c2o2_.html')
    assert isinstance(test_TF1IE, WatIE)
    assert test_TF1IE.video_id == 'exemple'
    assert test_TF1IE.video_ext == 'mp4'
    assert test_TF1IE.title == 'exemple'
    assert test_TF1IE.timestamp == 1308847683
    assert test_TF1IE.duration == 516

# Generated at 2022-06-24 13:16:42.288510
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html");

# Generated at 2022-06-24 13:16:44.046304
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")


# Generated at 2022-06-24 13:16:45.779795
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE(url)

# Generated at 2022-06-24 13:16:46.174242
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:53.392267
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:00.316626
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html?query=test')

# Generated at 2022-06-24 13:17:01.299592
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)

# Generated at 2022-06-24 13:17:02.554553
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:17:03.768401
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._real_initialize()

# Generated at 2022-06-24 13:17:06.173808
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj_test_TF1IE = TF1IE()
    obj_test_TF1IE.test(test_TF1IE._TESTS[0]["url"])

# Generated at 2022-06-24 13:17:10.349975
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('test_TF1IE')
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Unit test with valid url

# Generated at 2022-06-24 13:17:16.447542
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for the constructor of TF1IE class
    """
    # Included to check non regression on the _VALID_URL value
    url_test = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1ie = TF1IE(url_test)
    assert tf1ie._match_id is not None

# Generated at 2022-06-24 13:17:21.135140
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('abc')
    valid_url = re.compile(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert tf1._VALID_URL == valid_url

# Generated at 2022-06-24 13:17:22.072467
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Verify constructor of class
    t = TF1IE()

# Generated at 2022-06-24 13:17:24.908286
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:17:25.889290
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() == TF1IE

# Generated at 2022-06-24 13:17:26.528615
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = TF1IE()
    video.initialize()

# Generated at 2022-06-24 13:17:27.139557
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

# Generated at 2022-06-24 13:17:31.164812
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor by calling a method that should not raise an exception
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:40.496652
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Initialization
    instance = TF1IE()

    # Properties
    assert isinstance(instance.ie_key(), unicode)
    assert instance.ie_key() == u'wat'
    assert isinstance(instance.ie_url(), unicode)
    assert instance.ie_url() == u'http://wat.tv/'

    # Class methods
    assert isinstance(instance.suitable, types.MethodType)
    assert isinstance(instance._real_extract, types.MethodType)
    assert isinstance(instance._real_initialize, types.MethodType)
    assert isinstance(TF1IE._initialize_geo_bypass, types.FunctionType)
    assert isinstance(TF1IE._initialize_geo_bypass_by_country, types.FunctionType)

# Generated at 2022-06-24 13:17:41.797135
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Just to avoid a linting error
    assert not TF1IE

# Generated at 2022-06-24 13:17:51.478155
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Construction d'un objet "Test"
    test_objet = TF1IE()
    # Récupération d'une variable de l'objet (ici, l'URL qui sert de base)
    test_url = test_objet._VALID_URL

    # On peut maintenant tester cette variable :
    # Vérifie que la variable est une chaîne de caractères
    assert isinstance(test_url, str)
    # Vérifie que l'URL est bien formée et valide (et donc peut être utilisée)

# Generated at 2022-06-24 13:17:52.857823
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, True, "help", True)


# Generated at 2022-06-24 13:17:58.413423
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TP = TF1IE(dict())
    assert TP.IE_NAME == 'TF1'
    assert TP._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:58.975948
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:18:03.083903
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Call the constructor of class TF1IE
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:18:03.906741
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:18:05.999094
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract_info_from_url("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:18:11.807386
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:22.280294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE != None
    assert tf1IE._VALID_URL != None
    assert tf1IE._download_webpage != None
    assert tf1IE._real_extract != None
    assert tf1IE.suitable != None
    assert tf1IE.IE_DESC != None

    # Test with a valid URL
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert tf1IE.suitable(url) == True
    assert tf1IE._VALID_URL == tf1IE._match_id(url)
    assert tf1IE.IE_DESC == "TF1"

    # Test with a