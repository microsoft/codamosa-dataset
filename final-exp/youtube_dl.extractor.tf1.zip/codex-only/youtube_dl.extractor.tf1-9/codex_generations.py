

# Generated at 2022-06-24 13:08:24.922087
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    t = TF1IE(url)
    assert t.re.search(t._VALID_URL, url)
    assert t.program_slug == 'koh-lanta'
    assert t.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-24 13:08:27.325739
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Basic test for TF1IE
    """
    tf1_ie = TF1IE()
    assert isinstance(tf1_ie, InfoExtractor)

# Generated at 2022-06-24 13:08:28.162650
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:34.204143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    if tf1 == None:
        print("instance of TF1IE is not created")
    else:
        print("instance of TF1IE is created")
    tf1.extract("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    print("extract() of TF1IE is called ")

# Generated at 2022-06-24 13:08:42.734129
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    expected_result = {
        'program_slug': 'koh-lanta',
        'id': 'replay-koh-lanta-22-mai-2015',
        'version': '12.6'
    }
    # test the constructor of TF1IE
    ie = TF1IE(expected_result)
    assert expected_result['program_slug'] == ie._program_slug
    assert expected_result['id'] == ie._id
    expected_result['program_slug'] == ie._program_slug
    assert expected_result['program_slug'] == ie._slug
    assert expected_result['version'] == ie

# Generated at 2022-06-24 13:08:43.698153
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE")

# Generated at 2022-06-24 13:08:44.313978
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:53.238560
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1ie._TESTS
    assert tf1ie._TESTS[0]['params']['skip_download'] == True
    assert tf1ie._TESTS[0]['params']['format'] == 'bestvideo'
    assert tf1ie._TESTS[1]['only_matching']
    assert tf1ie._TESTS[2]['only_matching']


# Generated at 2022-06-24 13:08:56.598957
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE.__doc__ == 'TF1 (tf1.fr) extractor'
    assert TF1IE._VALID_URL is not None
    assert TF1IE._TESTS is not None

# Generated at 2022-06-24 13:08:57.452289
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()

# Generated at 2022-06-24 13:09:01.453970
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL
    tester = TF1IE(InfoExtractor())
    assert isinstance(tester, InfoExtractor)
    assert hasattr(tester, 'url')
    assert hasattr(tester, 'name')
    assert hasattr(tester, 'description')
    assert hasattr(tester, 'thumbnail')
    assert hasattr(tester, '_TESTS')

# Generated at 2022-06-24 13:09:12.266927
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'
    assert tf1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1IE._TESTS[0]['info_dict']['id'] == '13641379'
    assert tf1IE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert tf1IE

# Generated at 2022-06-24 13:09:16.141099
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:09:23.744754
# Unit test for constructor of class TF1IE
def test_TF1IE():
    parse_url = TF1IE._VALID_URL
    parse_url1 = re.match(parse_url, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    parse_url2 = re.match(parse_url, 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    parse_url3 = re.match(parse_url, 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:09:25.781759
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test the TF1IE constructor"""
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:09:37.063415
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # With an URL
    assert ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:09:45.066785
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test function for constructor of TF1IE class
    """
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    tf1 = TF1IE(url)
    assert tf1.url == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    return tf1


# Generated at 2022-06-24 13:09:48.851724
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Here, we check whether the struct which will be returned by the
    # constructor is correct
    # In order to do that, we give to the constructor only the url
    # of the video and then we compare the struct we got with the
    # struct we defined.
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    info = TF1IE()._real_extract(url)
    assert info['_type'] == "url_transparent"
    assert info['title'] == "KOH-LANTA"
    assert info['id'] == "13586626"


# Generated at 2022-06-24 13:09:49.899981
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()


# Generated at 2022-06-24 13:09:53.264119
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    extractor.url_result(url)

# Generated at 2022-06-24 13:10:02.594113
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not TF1IE.suitable('https://tfou.fr/')
    assert TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/[^/]+/videos/[^/?&#]+\\.html'

# Generated at 2022-06-24 13:10:06.743340
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:08.222570
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    # assert(tf1ie.ie_key() == 'tf1')
    assert(tf1ie.ie_key() == 'wat')

# Generated at 2022-06-24 13:10:17.360560
# Unit test for constructor of class TF1IE
def test_TF1IE():
  from .test_exceptions import assert_call_rejected
  assert_call_rejected(TF1IE, ['https://www.tf1.fr/tf1/les-feux-de-lamour/videos/replay-les-feux-de-l-amour-du-mercredi-12-juin-2019.html'])
  assert_call_rejected(TF1IE, ['https://www.tf1.fr/tf1/the-voice-la-plus-belle-voix/videos/the-voice-la-plus-belle-voix-du-coach-du-samedi-18-mai-2019-rediffusion.html'])

# Generated at 2022-06-24 13:10:18.006315
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()

# Generated at 2022-06-24 13:10:18.709800
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:10:26.358909
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:36.245156
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE('www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', 'tf1.json')
    assert a._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert a.suitable('www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:38.698623
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:10:39.402731
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE)

# Generated at 2022-06-24 13:10:40.032966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:10:43.451745
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:47.157692
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()
    assert a.get_info('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is not 'None'

# Generated at 2022-06-24 13:10:49.903235
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:10:57.080830
# Unit test for constructor of class TF1IE
def test_TF1IE():
        tf1 = TF1IE()
        tf1.tf1_IE_Unit_Test()
        array_result = tf1.arr_result

# Generated at 2022-06-24 13:11:07.639584
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Correctly passing arguments
    TF1IE(None, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

    # Incorrectly passing arguments

# Generated at 2022-06-24 13:11:08.476656
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()

# Generated at 2022-06-24 13:11:09.254148
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE)

# Generated at 2022-06-24 13:11:09.738777
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:11:10.945750
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()

# Generated at 2022-06-24 13:11:11.591031
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:11:12.933594
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:13.511951
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:17.352196
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:11:23.295960
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor
    from .TF1IE import TF1IE
    from ..compat import compat_urllib_parse_unquote
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    query = compat_urllib_parse_unquote(url.split('?', 1)[1])
    TF1IE()._real_extract(query)
    InfoExtractor()._real_extract(query)

# Generated at 2022-06-24 13:11:24.357945
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE().ie_key(), str)

# Generated at 2022-06-24 13:11:24.998681
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("")

# Generated at 2022-06-24 13:11:28.513730
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie.constructor()
    class_name = tf1ie.__class__.__name__
    assert class_name == 'TF1IE'

# Generated at 2022-06-24 13:11:37.053247
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test extract of a video
    extraction = TF1IE().extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

    # Test extraction of video ID
    assert extraction['id'] == '13641379'

    # Test extraction of video title
    assert extraction['title'] == 'Quotidien, première partie - 11 juin 2019'

    # Test extraction of video description
    assert extraction['description'] == 'L\'actualité, décryptée par Yann Barthès et ses chroniqueurs. Au programme, des interviews de personnalités, des reportages inédits et la mise en lumière de l\'info de manière originale. Présentation : Yann Barthès.'



# Generated at 2022-06-24 13:11:41.635446
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('TF1IE', True)
    assert tf1ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:42.241938
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:11:43.515822
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_instance = TF1IE()
    assert class_instance != None


# Generated at 2022-06-24 13:11:44.092084
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:46.023741
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.tf1 = {'key': 'value'}
    assert ie.tf1 == {'key': 'value'}

# Generated at 2022-06-24 13:11:53.728591
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:11:54.201677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:54.938836
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:11:58.696223
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:04.021552
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_downloader import TEST_ALL, __test_generic_download
    from . import testers
    TF1IE().download = testers.download_return_fakeurl
    __test_generic_download(
        TF1IE(),
        list(filter(lambda x: x['url'] == 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', TEST_ALL)))

# Generated at 2022-06-24 13:12:07.258393
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:19.080637
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.extractor = None
    # Tests for _VALID_URL
    m1 = re.match(t._VALID_URL, 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert m1 is not None
    m2 = re.match(t._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert m2 is not None
    m3 = re.match(t._VALID_URL, 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:20.596848
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE({'extractor': 'TF1IE'})

# Generated at 2022-06-24 13:12:21.552523
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:12:23.173803
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t._download_json()

# Generated at 2022-06-24 13:12:26.421414
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not extractor.suitable('https://www.tf1.fr/hds7/videos/l-hebdo-cine-samedi-16-mars-2019.html')


# Generated at 2022-06-24 13:12:34.845161
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    match = tf1._match_id(url)
    assert match == ('koh-lanta', 'replay-koh-lanta-22-mai-2015')
    assert tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1._real_extract('whatever') == None

# Generated at 2022-06-24 13:12:36.401332
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_TF1IE import test_TF1IE
    test_TF1IE()

# Generated at 2022-06-24 13:12:43.662192
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:12:50.032542
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert tf1ie.is_suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html") == True
    assert tf1ie.is_suitable("http://www.francetvinfo.fr/") == False

# Generated at 2022-06-24 13:12:59.846552
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test youtube_ie constructor
    tf1 = TF1IE()
    # Test tf1._VALID_URL
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # Test tf1._TESTS
    assert len(tf1._TESTS) == 3
    assert tf1._TESTS[1] == {'url': 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'only_matching': True}

# Generated at 2022-06-24 13:13:05.223302
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test constructor and methods of class TF1IE
    """
    from .common import InfoExtractor
    from ..utils import (
        int_or_none,
        parse_iso8601,
        try_get,
    )
    watch_url = r'https://www.tf1.fr/tf1/josephine-ange-gardien/videos/replay-josephine-ange-gardien-06-juin-2018.html'
    TF1IE(InfoExtractor,watch_url)

# Generated at 2022-06-24 13:13:09.041772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_test = TF1IE(None)
    assert tf1_test._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:15.835388
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:13:16.729242
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("test_TF1IE");

# Generated at 2022-06-24 13:13:17.776557
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()

# Generated at 2022-06-24 13:13:18.989832
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:13:29.843512
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

    assert(re.match(tf1._VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'))
    assert(re.match(tf1._VALID_URL, 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'))
    assert(re.match(tf1._VALID_URL, 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'))

# Generated at 2022-06-24 13:13:33.368568
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert instance.url == "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"

# Generated at 2022-06-24 13:13:40.314529
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    TF1IE("https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert True

# Generated at 2022-06-24 13:13:40.926041
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:13:41.450508
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:13:52.707613
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._real_initialize()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:55.393078
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE()._VALID_URL)
    print(TF1IE().IE_NAME)
    print(TF1IE()._TEST)

# Generated at 2022-06-24 13:13:57.443776
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == 'TF1'
    assert obj.ie_key() is not None

# Generated at 2022-06-24 13:13:58.039569
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE

# Generated at 2022-06-24 13:14:00.681198
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test if constructor of TF1IE class is working properly
    try:
        TF1IE()
    except:
        print('constructor of TF1IE class is not working properly')


# Generated at 2022-06-24 13:14:01.983507
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception:
        pass

# Generated at 2022-06-24 13:14:02.589938
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:04.081507
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create instance of class TF1IE
    tf1ie = TF1IE()


# Generated at 2022-06-24 13:14:05.686320
# Unit test for constructor of class TF1IE
def test_TF1IE():

    test_TF1IE = TF1IE(TF1IE)
    assert test_TF1IE is not None

# Generated at 2022-06-24 13:14:09.548392
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtract = TF1IE()

    for url in infoExtract._TESTS:
        obj = infoExtract._real_extract(url["url"])
        print(obj)

        # Test constructor
        assert obj['url'] != "wat:" + obj['id']

# Generated at 2022-06-24 13:14:11.355723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Test for constructor of class TF1IE
    '''
    return TF1IE

# Generated at 2022-06-24 13:14:12.039557
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:20.603059
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:26.281594
# Unit test for constructor of class TF1IE
def test_TF1IE():

    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html";
    TF1IE_instance = TF1IE(extractor_key="TF1")
    TF1IE_instance._real_extract(url)

# Generated at 2022-06-24 13:14:31.806717
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie.program_slug == "quotidien-avec-yann-barthes"
    assert ie.slug == "quotidien-premiere-partie-11-juin-2019"

# Generated at 2022-06-24 13:14:32.776579
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()

# Generated at 2022-06-24 13:14:35.363475
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:14:36.385843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:14:40.250665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert isinstance(x, TF1IE)
    # Test templated method _real_extract
    assert x._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:14:42.441692
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # assert(ie.valid_url is not None)
    # assert(ie._VALID_URL is not None)


# Generated at 2022-06-24 13:14:45.273561
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == 'TF1'
    assert obj.ie_id() == 'TF1'
    assert obj.BASE_URL == 'https://www.tf1.fr'

# Generated at 2022-06-24 13:14:46.695317
# Unit test for constructor of class TF1IE
def test_TF1IE():
    def test():
        return TF1IE(None)._VALID_URL

# Generated at 2022-06-24 13:14:48.654016
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:14:50.213710
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE("testString")
    assert instance.__class__ == TF1IE

# Generated at 2022-06-24 13:14:51.226627
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:14:54.909260
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .wat import WatIE
    assert TF1IE.ie_key() == 'tf1'
    assert TF1IE.ie_key() is TF1IE.ie_key()
    assert TF1IE.ie_key() == 'wat'
    assert TF1IE.ie_key() is WatIE.ie_key()

# Generated at 2022-06-24 13:14:56.174806
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    print(x)
    assert x



# Generated at 2022-06-24 13:14:56.939780
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-24 13:14:58.790704
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from youtube_dl.extractor.TF1IE import TF1IE
    # Instantiate the class
    TF1IE()


# Generated at 2022-06-24 13:15:08.865523
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .wat import WatIE
    from ..compat import compat_http_server
    from ..utils import url_basename

    class Handler(compat_http_server.SimpleHTTPRequestHandler):
        server_version = "WAT/test"

        def do_GET(self):
            if self.path == '/wat/videos/my-id.html':
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b'404 Not Found')
                return
            if self.path == '/wat/videos/my-id':
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'[["my-id"]]')
                return

# Generated at 2022-06-24 13:15:14.376920
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test basic functionality
    expected_TF1IE = 'TF1IE'
    assert TF1IE._class_name == expected_TF1IE,"TF1IE's constructor return something different"
    # Test if TF1IE takes name and age as arguments
    assert TF1IE._VALID_URL != None,"TF1IE's constructor return something different"
    assert TF1IE._TESTS != None,"TF1IE's constructor return something different"
    assert TF1IE._real_extract != None,"TF1IE's constructor return something different"

# Generated at 2022-06-24 13:15:19.471482
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1ie = TF1IE()
    tf1ie.match(url) == False

    assert tf1ie.match(url) == True
    assert tf1ie.suitable(url) == True

# Generated at 2022-06-24 13:15:20.998788
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ins = TF1IE()
    assert ins.name == 'tf1'

# Generated at 2022-06-24 13:15:24.684220
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert(True)


if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-24 13:15:25.437812
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # The actual constructor
    TF1IE(rarbgIE)


# Generated at 2022-06-24 13:15:28.865818
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:32.376037
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    if ie == None:
        raise Exception

# Unit test of the extraction method of class TF1IE

# Generated at 2022-06-24 13:15:44.170227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ This is a test case for TF1IE constructor

    This test case will create a TF1IE object and test its attributes.
    """
    t = TF1IE(None)

    assert t.name == 'tf1'
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t.age_limit == 16

    # Test cases for tf1.ie

# Generated at 2022-06-24 13:15:50.271826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html' 
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:51.432071
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test instantiation of class
    TF1VideoIE()

# Generated at 2022-06-24 13:15:52.731701
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE.__doc__)


# Generated at 2022-06-24 13:16:02.951544
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import urllib.parse
    query = urllib.parse.urlencode(dict(
        id='9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
        variables=json.dumps(dict(
            programSlug='tf1',
            slug='atomik-circus-le-film-a-la-tete-des-affaires'
        ))
    ))
    url = 'https://www.tf1.fr/graphql/web?%s' % query

# Generated at 2022-06-24 13:16:14.079713
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:15.085981
# Unit test for constructor of class TF1IE
def test_TF1IE():
    vid = TF1IE()

# Generated at 2022-06-24 13:16:16.596506
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()
    b = InfoExtractor()

# Generated at 2022-06-24 13:16:17.576302
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit = TF1IE()

# Generated at 2022-06-24 13:16:18.515978
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:16:27.065464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    def test_tf1ie(url, program_slug, slug):
        assert re.match(TF1IE._VALID_URL, url)
        assert program_slug == re.match(TF1IE._VALID_URL, url).group('program_slug')
        assert slug == re.match(TF1IE._VALID_URL, url).group('id')

    test_tf1ie('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', 'tmc/quotidien-avec-yann-barthes', 'quotidien-premiere-partie-11-juin-2019')

# Generated at 2022-06-24 13:16:37.740055
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert t == TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:16:38.197652
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:47.339048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_urls = [
        "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html",
        "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
        "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"]
    for test_url in test_urls:
        print(test_url)
        TF1IE().suitable(test_url)

# Generated at 2022-06-24 13:16:47.961191
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    pass

# Generated at 2022-06-24 13:16:50.765892
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Test creation of TF1IE instance")
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-24 13:17:00.366050
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert re.match(TF1IE._VALID_URL, url)


# Generated at 2022-06-24 13:17:01.692261
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1



# Generated at 2022-06-24 13:17:02.257664
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:10.310288
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # If a video exists at the location
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1_ie = TF1IE(url)
    assert tf1_ie.url == url

    # If a video does not exist at the location and it the result is None
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1_ie = TF1IE(url)
    assert tf1_ie.url == url

# Generated at 2022-06-24 13:17:11.504987
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.ie_key() == 'TF1'

# Generated at 2022-06-24 13:17:13.087170
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('wat', 'wat')
    assert t.constructor == 'TF1IE', 'constructor'

# Generated at 2022-06-24 13:17:13.969676
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('wat:x')

# Generated at 2022-06-24 13:17:16.193938
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE()._real_extract(url)

# Generated at 2022-06-24 13:17:18.964856
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL
    assert re.compile(TF1IE._VALID_URL)
    assert bool(TF1IE.__doc__)


# Generated at 2022-06-24 13:17:22.164259
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:23.141018
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()

# Generated at 2022-06-24 13:17:24.488976
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL

# Generated at 2022-06-24 13:17:28.535781
# Unit test for constructor of class TF1IE
def test_TF1IE():
    watIE = TF1IE()
    assert watIE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:31.783570
# Unit test for constructor of class TF1IE
def test_TF1IE():
    b = TF1IE()
    c = TF1IE('TF1')
    d = TF1IE(merge_url_template='http://tf1.fr/{0}')
    assert str(b) == str(c) == str(d)
    assert 'TF1' in str(b)

# Generated at 2022-06-24 13:17:37.916958
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1 = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
	assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:17:41.059852
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:44.405335
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor = globals()['TF1IE']
    instance = constructor()
    instanceUrl = instance.suitable('https://www.tf1.fr/')

if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-24 13:17:46.655828
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(None)
    assert tf1ie
    assert tf1ie.name == "TF1"

# Generated at 2022-06-24 13:17:48.052766
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:17:50.418471
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE({})
    obj = ie.suitable('hls')
    assert obj
    obj = ie.suitable('dash')
    assert obj

# Generated at 2022-06-24 13:17:51.522869
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:17:55.879383
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('TF1', 'http://tf1.fr/titi/videos/toto-1.html')
    assert t.program_slug == 'titi'
    assert t.slug == 'toto-1'

# Generated at 2022-06-24 13:17:59.096552
# Unit test for constructor of class TF1IE
def test_TF1IE():
    api = TF1IE()
    print("test_TF1IE", api)
    assert api._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    print("test_TF1IE: done")


# Generated at 2022-06-24 13:18:04.319418
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.extractor_key == 'TF1'
    assert ie.url == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert ie.video_id == 'reveil-tres-difficile-ou-pas-pour-les-aventuriers'
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'reveil-tres-difficile-ou-pas-pour-les-aventuriers'


# Generated at 2022-06-24 13:18:05.402355
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # type: () -> None
    info_extractor = TF1IE()

# Generated at 2022-06-24 13:18:07.796058
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x._VALID_URL == "(?i)https?://(?:www\\.)?tf1\\.fr/[^/]+/[^/]+/videos/[^/?&#]+\\.html$"

# Generated at 2022-06-24 13:18:09.913842
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t != None


# Generated at 2022-06-24 13:18:18.408044
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.enable_test_mode()
    program_slug = 'koh-lanta'
    slug = 'replay-koh-lanta-22-mai-2015'

    #Assert the url has the correct format
    url = r'http://www.tf1.fr/'+program_slug+'videos/'+slug+'.html'
    m = re.match(TF1IE._VALID_URL, url)
    assert m
    assert m.group('program_slug') == program_slug
    assert m.group('id') == slug

# Generated at 2022-06-24 13:18:19.565191
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

# Generated at 2022-06-24 13:18:20.562238
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE() != None)

# Generated at 2022-06-24 13:18:27.368522
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.get_testcases()[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert obj.get_testcases()[1]['url'] == "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert obj.get_testcases()[2]['url'] == "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"

    obj = TF1IE()