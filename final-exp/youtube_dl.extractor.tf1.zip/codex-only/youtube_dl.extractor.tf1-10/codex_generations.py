

# Generated at 2022-06-24 13:08:25.731241
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:08:30.423146
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'



# Generated at 2022-06-24 13:08:31.043750
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:37.288499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

    # Test that the constructor correctly determines the ID of the video
    assert i._id == '13641379'
    assert i._program_slug == 'quotidien-avec-yann-barthes'
    assert i._slug == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:08:39.950716
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE
    except NameError:
        TF1IE = None

    if TF1IE is None:
        assert False, 'Could not import TF1IE\'s constructor'
    else:
        assert True

# Generated at 2022-06-24 13:08:41.761991
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE = TF1IE('test_TF1IE', 'fancy_test')
    assert isinstance(TF1IE, object)

# Generated at 2022-06-24 13:08:43.010987
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:53.051929
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert TF1IE.suitable(url) == True
    assert TF1IE.IE_NAME == 'tf1'
    assert TF1IE.IE_DESC == 'Tf1 videos'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    tf1 = TF1IE(url)
    assert tf1.url == url

# Generated at 2022-06-24 13:08:57.146867
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor = TF1IE

    assert(constructor.__name__) == "TF1IE"
    assert(constructor._VALID_URL) == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:03.947699
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    url_upload = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    url_upload_2 = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    url_upload_3 = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    TF1IE_object = TF1IE(url_upload)
    TF1IE_object_2 = TF1IE(url_upload_2)

# Generated at 2022-06-24 13:09:08.091330
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    class_ie = TF1IE()
    assert class_ie.match(url)

# Generated at 2022-06-24 13:09:10.894225
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE."""
    o = TF1IE()
    assert o.ie_key() == 'tf1'
    assert o.ie_name() == 'tf1'

# Generated at 2022-06-24 13:09:16.853016
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    # The following test is not important, it is only to make sure the constructor works
    m = re.match(TF1IE._VALID_URL, url)
    assert (m is not None)

# Generated at 2022-06-24 13:09:24.707968
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert not t._TESTS
    assert t._SUCCESS_MARK == '<title>'
    assert t._NETRC_MACHINE == 'tf1'
    assert t._LOGIN_URL == 'https://login.tf1.fr/'

# Generated at 2022-06-24 13:09:25.478836
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:09:31.535827
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert i.domain == 'www.tf1.fr'
    assert i.url == 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'

# Generated at 2022-06-24 13:09:33.401605
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()
    assert result
# Test case for method _real_extract

# Generated at 2022-06-24 13:09:34.029310
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:09:35.123143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE(None)
    except Exception as exception:
        # Assert that the exception was raised by the correct class
        assert type(exception) is KeyError

# Generated at 2022-06-24 13:09:35.827770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:09:36.805003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)

# Generated at 2022-06-24 13:09:37.808349
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:09:38.665226
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:39.265337
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:09:39.854437
# Unit test for constructor of class TF1IE
def test_TF1IE():
	return TF1IE

# Generated at 2022-06-24 13:09:41.070811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test that a TF1IE object can be constructed
    tfe = TF1IE()

# Generated at 2022-06-24 13:09:48.531605
# Unit test for constructor of class TF1IE
def test_TF1IE():
    expected_result = 'wat:13641379'
    actual_result = TF1IE._download_json(
        'https://www.tf1.fr/graphql/web',
        'quotidien-premiere-partie-11-juin-2019',
        query={
            'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
            'variables': json.dumps({
                'programSlug': 'quotidien-avec-yann-barthes',
                'slug': 'quotidien-premiere-partie-11-juin-2019',
            })
        })['data']['videoBySlug']['streamId']

# Generated at 2022-06-24 13:09:54.922464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.extractor == 'tf1'
    assert tf1ie.IE_NAME == 'tf1'
    assert tf1ie.IE_DESC == 'TF1'
    assert tf1ie.VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:10:00.517381
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .wat import WatIE
    ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert isinstance(ie, WatIE)
    assert ie._VALID_URL == TF1IE._VALID_URL
    assert ie._TESTS == TF1IE._TESTS

# Generated at 2022-06-24 13:10:03.133489
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .tf1 import TF1IE
    infoExtractor = TF1IE(None)
    infoExtractor._download_json(None, None, None)
    assert infoExtractor

# Generated at 2022-06-24 13:10:04.578235
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie


# Generated at 2022-06-24 13:10:06.636956
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from tf1 import TF1IE
    tf1 = TF1IE(None)



# Generated at 2022-06-24 13:10:14.406170
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:10:19.423361
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ test_TF1IE """
    # Information extraction
    tf1 = TF1IE()
    tf1.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:22.517159
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert TF1IE.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert not TF1IE.suitable("http://google.com")



# Generated at 2022-06-24 13:10:23.917244
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(TF1IE._VALID_URL, TF1IE()._VALID_URL) is not None

# Generated at 2022-06-24 13:10:28.482475
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE(TF1IE.DEFAULT_WORKER_NAME)
    assert instance._VALID_URL==r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:10:31.998275
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test empty constructor
    x = TF1IE()
    assert isinstance(x, TF1IE)

    # Test empty constructor
    y = InfoExtractor()
    assert isinstance(y, InfoExtractor)

# Generated at 2022-06-24 13:10:33.592128
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test TF1IE constructor.
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:10:35.486234
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:10:36.636253
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:10:37.148285
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-24 13:10:37.648202
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:10:42.195476
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url_test = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE('')._real_extract(url_test)

# Generated at 2022-06-24 13:10:52.177607
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1IE = TF1IE(url)
    assert tf1IE.program_slug == 'koh-lanta'
    assert tf1IE.slug == 'replay-koh-lanta-22-mai-2015'
    assert tf1IE.video_id == '8e8d16c2-7fbd-4ab1-8f4b-4e35b4e9cb9d'

    # https://www.tf1.fr/hd1/

# Generated at 2022-06-24 13:11:01.309383
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE.__doc__ == 'TF1 url IE'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:02.961180
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE()
    assert (info != None)

# Generated at 2022-06-24 13:11:05.163000
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor())._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:11:07.698092
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:11:08.241481
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:11:09.598828
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_fixture = TF1IE(None)
    assert test_fixture is not None


# Generated at 2022-06-24 13:11:14.409901
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie.valid()
    assert isinstance(ie.extract(), dict)

# Generated at 2022-06-24 13:11:14.994411
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:17.889808
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:11:21.330786
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()
    assert a._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:22.168552
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.suite()

# Generated at 2022-06-24 13:11:26.779435
# Unit test for constructor of class TF1IE
def test_TF1IE():
  url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
  TF1IE(url)._real_extract()

# Generated at 2022-06-24 13:11:35.057156
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Sometimes wat serves the whole file with the --test option
    info_extractor = TF1IE()
    assert info_extractor.ie_key() == 'tf1', info_extractor.ie_key()
    assert info_extractor.suitable(None) == False
    assert info_extractor.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert info_extractor.suitable('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == True

# Generated at 2022-06-24 13:11:36.231844
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)

# Generated at 2022-06-24 13:11:40.623050
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .wat import WatIE
    
    assert "TF1IE" == TF1IE()._real_extract.__name__
    assert "WatIE" == TF1IE()._real_extract("")._type
    assert "WatIE" == TF1IE()._real_extract("")._type

# Generated at 2022-06-24 13:11:49.609343
# Unit test for constructor of class TF1IE
def test_TF1IE():
    base_url = 'https://www.tf1.fr/tmc/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url=base_url)

    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._downloader.params.get('nocheckcertificate')
    # test if video returns the same video ID
    video_id = 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-24 13:11:50.133302
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:11:55.957376
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from unittest import TestCase

    class TestTF1IE(TestCase):

        def test_TF1IE_Instantiation_Should_Set_Original_Url_And_Original_Id(self):
            tf1IE = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
            self.assertEquals(tf1IE.original_url, 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html' )

# Generated at 2022-06-24 13:11:57.243020
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test constructor of class TF1IE """
    assert TF1IE

# Generated at 2022-06-24 13:12:06.771052
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:12:09.485859
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:12:20.888014
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # testing constructor
    Test = TF1IE()

    # testing validation
    assert Test._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:28.822030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-1re-partie-12-juin-2019.html')
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS
    assert ie._downloader
    assert ie._download_webpage
    assert ie._html_search_regex
    assert ie._type
    assert ie._download_json

# Generated at 2022-06-24 13:12:29.657789
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:12:31.511383
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert type(IE) == TF1IE
    assert IE.ie_key() == 'TF1'



# Generated at 2022-06-24 13:12:34.102193
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:12:35.062515
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE.__name__ == 'TF1IE')

# Generated at 2022-06-24 13:12:38.450398
# Unit test for constructor of class TF1IE
def test_TF1IE():
    mytest = TF1IE()
    res = mytest._real_extract("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert len(res) > 0

# Generated at 2022-06-24 13:12:44.984764
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable(TF1IE.ie_key())
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:48.034701
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') is not None



# Generated at 2022-06-24 13:12:53.328160
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-24 13:12:56.646596
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is not None

# Generated at 2022-06-24 13:12:57.015029
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:04.965758
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie != None
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:05.545657
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _ = TF1IE

# Generated at 2022-06-24 13:13:15.550639
# Unit test for constructor of class TF1IE
def test_TF1IE():
	class_ = TF1IE()
	assert type(class_) == TF1IE
	assert class_.host == "www.tf1.fr"
	assert class_.ie_key == "TF1"
	assert class_.ie_desc == "TF1"
	assert class_.SEARCH_KEY == 'tf1'
	assert class_.DEFAULT_SEARCH == 'ytsearch'
	assert class_.HEADERS == {'User-Agent': 'Wget/1.14 (linux-gnu)'}
	assert class_.IE_NAME == 'TF1.fr'
	assert class_.VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
	assert class_.NETRC_

# Generated at 2022-06-24 13:13:17.469395
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:13:19.860439
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie_TF1 = TF1IE()
    assert ie_TF1
    assert isinstance(ie_TF1, InfoExtractor)

# Generated at 2022-06-24 13:13:27.007337
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    assert test_TF1IE
    assert 'TF1IE' == test_TF1IE.IE_NAME
    assert test_TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'
    assert test_TF1IE._TESTS

# Generated at 2022-06-24 13:13:32.749757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test yt.com/watch?v=3N3-5A8_pEs
    # Given
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    # When
    tf1 = TF1IE(url)

    # Then
    assert tf1.name == 'tf1'
    assert tf1.IE_NAME == 'wat'
    assert tf1._VALID_URL == url


# Generated at 2022-06-24 13:13:34.578575
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'



# Generated at 2022-06-24 13:13:42.889435
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert 'TF1IE' in ie.__class__.__name__
    assert ie.IE_NAME == 'tf1'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:44.110800
# Unit test for constructor of class TF1IE
def test_TF1IE():
    iev = TF1IE()
    assert iev.__name__ == "TF1IE"

# Generated at 2022-06-24 13:13:53.420770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .noco import NocoIE
    from .wat import WatIE
    from .generic_extractor import GenericIE

    ie = InfoExtractor()
    ie._generate_extractors()

    # NocoIE and WatIE can handle TF1IE's url
    assert ie._extractors[0][0].__class__ is NocoIE
    assert ie._extractors[0][1].__class__ is WatIE

    # TF1IE is the last of all Extractors
    assert ie._extractors[-1][0].__class__ is GenericIE
    assert ie._extractors[-1][1].__class__ is TF1IE

# Generated at 2022-06-24 13:13:59.668202
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE("tf1")
    assert test.suitable("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert test.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert not test.suitable("https://www.tf1.fr")

# Generated at 2022-06-24 13:14:01.150361
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL
    assert tf1_ie._TESTS

# Generated at 2022-06-24 13:14:01.899245
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_class = TF1IE()

# Generated at 2022-06-24 13:14:05.667846
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1 = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1 != None

#Unit test for method _real_extract() of class TF1IE

# Generated at 2022-06-24 13:14:16.438458
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test a known video link
    info_dict = TF1IE._extract_info(TF1IE._build_url_result('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'),
                                    '', '', '', '')

    assert info_dict['id'] == '13641379'
    assert info_dict['ext'] == 'mp4'
    assert info_dict['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'
    assert info_dict['description'] == 'md5:a02cdb217141fb2d469d6216339b052f'
    assert info_dict['upload_date'] == '20190611'
    assert info_dict['timestamp'] == 15602739

# Generated at 2022-06-24 13:14:22.076172
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    # test if it is tf1 ie
    assert ie.is_tf1('wat:123')
    assert not ie.is_tf1('http://www.wat.tv/123.html')

    # test return TF1SchemeHandler for wat scheme
    assert 'TF1SchemeHandler' in str(type(ie.url_result('wat:123')))



# Generated at 2022-06-24 13:14:29.471983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    exp = TF1IE()
    assert exp.html_template == 'https://www.tf1.fr/graphql/web'
    assert exp.root_url == 'https://www.tf1.fr'
    assert exp.name == 'tf1'
    assert exp.video_id_regex == r'(?<!\d)(?P<value>[0-9A-Z-]+)(?:[Pp]-\d{2}-[0-9]{2})?(?!\d)'
    assert exp._FILE_FORMAT == 'wat'

# Generated at 2022-06-24 13:14:31.569119
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("https://wat.tv/get/android5/13641379").tf1_id == "13641379"

# Generated at 2022-06-24 13:14:40.717399
# Unit test for constructor of class TF1IE
def test_TF1IE():  # pylint: disable=redefined-outer-name
    # Test with uploaded video
    tf1 = TF1IE('www.tf1.fr', 'www.tf1.fr/videos/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1.program_slug == 'quotidien-avec-yann-barthes'
    assert tf1.slug == 'quotidien-premiere-partie-11-juin-2019'

    # Test with live video

# Generated at 2022-06-24 13:14:41.880838
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:14:42.493321
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:45.312529
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test that the constructor doesn't raise any exceptions
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:14:45.808841
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:14:46.262288
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:48.143791
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE
    if not TF1IE.is_enabled():
        return
    assert class_(None)._VALID_URL == class_._VALID_URL

# Generated at 2022-06-24 13:14:53.069776
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # The following _VALID_URL is directly copied from `_TESTS`
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    tf1ie = TF1IE()
    match = re.match(tf1ie._VALID_URL, url)
    assert match is not None, 'url should match'

    program_slug, slug = match.groups()
    assert program_slug == 'tmc/quotidien-avec-yann-barthes'
    assert slug == 'quotidien-premiere-partie-11-juin-2019'


# Generated at 2022-06-24 13:14:55.204634
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:14:56.537387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1



# Generated at 2022-06-24 13:15:03.133624
# Unit test for constructor of class TF1IE
def test_TF1IE():

    TF1_URL = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1_video_id = '13641379'

    tf1_ie = TF1IE()

    assert tf1_ie.suitable(TF1_URL) is True

    tf1_info = tf1_ie.extract(TF1_URL)

    assert tf1_info['id'] == TF1_video_id

# Generated at 2022-06-24 13:15:06.404673
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:15:07.034201
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:09.756908
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:15:10.301437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:14.327455
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE('test', 'test_TF1IE')
    assert(IE.IE_NAME == 'tf1')
    assert(IE.IE_DESC == 'tf1.fr')
    assert(IE._VALID_URL == IE.VALID_URL)
    assert(IE._TESTS == IE.__dict__['_TESTS'])

# Generated at 2022-06-24 13:15:15.136498
# Unit test for constructor of class TF1IE
def test_TF1IE():
    b = TF1IE()
    assert b


# Generated at 2022-06-24 13:15:16.636449
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extractor = 'TF1'

# Generated at 2022-06-24 13:15:17.225280
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:19.382343
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == (
        'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:15:19.945813
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:21.082593
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:15:23.052683
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE', 'tf1.fr')

# Generated at 2022-06-24 13:15:32.588406
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Case 1:
    url = "https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    assert TF1IE.suitable(url) == True
    assert TF1IE.ie_key() == "wat"

    # Case 2:
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert TF1IE.suitable(url) == True

    # Case 3:
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert TF1IE.suitable(url) == True

# Generated at 2022-06-24 13:15:33.927591
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("wat:1234")

# Generated at 2022-06-24 13:15:40.629549
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
        TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    except:
        assert False


# Generated at 2022-06-24 13:15:45.491551
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    ie = TF1IE()
    ie._real_extract(url)

# Generated at 2022-06-24 13:15:46.636709
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tst = TF1IE("")

# Generated at 2022-06-24 13:15:53.146250
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TF1IE() and TF1IE().gen_extractors() are tested in test_tf1.py

    test_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE()
    ie.get_urls = lambda url: url

    url = ie.construct_url(test_url)
    assert url == test_url, 'must return the same url'

# Generated at 2022-06-24 13:15:53.822708
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:15:55.177975
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    assert TF1IE()

# Generated at 2022-06-24 13:16:00.916268
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
        assert TF1IE.suitable(url)
        assert TF1IE._VALID_URL.match(url) != None
        TF1IE.test()
    except AssertionError:
        assert False

# Generated at 2022-06-24 13:16:12.109886
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'tf1'
    assert ie.ie_name() == 'tf1.fr'
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie.matches_url(url)
    assert ie.extract_id(url) == '13641379'
    assert ie.extract_url(url) == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie.download('wat:123')

# Generated at 2022-06-24 13:16:15.264438
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test construction of TF1IE object
    tf1ie = TF1IE()
    # check that the tf1ie object extends the InfoExtractor class
    assert(isinstance(tf1ie, InfoExtractor))

# Generated at 2022-06-24 13:16:16.645323
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE('test')
    assert tf1_ie is not None

# Generated at 2022-06-24 13:16:17.623366
# Unit test for constructor of class TF1IE
def test_TF1IE():
    sys = TF1IE()

# Generated at 2022-06-24 13:16:18.563269
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1")

# Generated at 2022-06-24 13:16:21.379757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Initialization of object which inherits from InfoExtractor
    tf1IE = TF1IE('TF1IE')
    assert tf1IE != None



# Generated at 2022-06-24 13:16:23.182938
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:33.029580
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:41.339266
# Unit test for constructor of class TF1IE
def test_TF1IE():
    responseUrl = 'https://www.tf1.fr/graphql/web'
    slug = 'quotidien-premiere-partie-11-juin-2019'
    id = '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'
    variables = '{"programSlug":"tmc","slug":"quotidien-premiere-partie-11-juin-2019"}'
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:16:51.755559
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Class to test implementation
    """
    url = "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    result = TF1IE._real_extract(TF1IE(), url)
    assert result['id'] == "13641379"
    assert result['ext'] == "mp4"
    assert result['title'] == "Quotidien du mercredi 12 juin 2019 (1ère partie)"
    assert result['upload_date'] == "20190611"
    assert result['timestamp'] == 1560273989
    assert result['duration'] == 1738
    assert result['series'] == "Quotidien avec Yann Barthès"

# Generated at 2022-06-24 13:16:52.539638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

# Generated at 2022-06-24 13:17:00.272459
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('wat_id')
    assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:09.549134
# Unit test for constructor of class TF1IE
def test_TF1IE():
    data1 = {
        'id': '8e0c1bd9-1063-4a11-8a25-c1597b1432f5',
        'url': 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
    }

    data2 = {
        'id': '8e0c1bd9-1063-4a11-8a25-c1597b1432f5',
        'url': 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
    }

    res1 = TF1IE()
    res2 = TF1IE()

    assert res1.suitable

# Generated at 2022-06-24 13:17:10.021010
# Unit test for constructor of class TF1IE
def test_TF1IE():
        TF1IE()

# Generated at 2022-06-24 13:17:10.753298
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:17:14.921499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tF1IE = TF1IE()
    assert(tF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')



# Generated at 2022-06-24 13:17:16.050103
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = TF1IE()
    url.IE_NAME

# Generated at 2022-06-24 13:17:25.889727
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1i = TF1IE()
    #assert(tf1i.entries_list == [])
    assert(tf1i.entries_re == re.compile(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'))
    assert(tf1i.module_name == 'TF1')
    assert(tf1i.IE_NAME == 'tf1')
    assert(tf1i.info_dict == {})
    assert(tf1i.params == {})
    assert(tf1i.title == None)
    assert(tf1i.url == None)
    assert(tf1i.query == None)

# Generated at 2022-06-24 13:17:26.479349
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:27.421995
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()

# Generated at 2022-06-24 13:17:30.815900
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)._real_extract(
                'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:17:33.898086
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    print("Unit test for constructor of class TF1IE")
    # Asserts that a given bool condition is true.
    # bool(x) returns True when the argument x is true, False otherwise.
    assert bool(obj)

# Generated at 2022-06-24 13:17:34.808535
# Unit test for constructor of class TF1IE
def test_TF1IE():
    res = TF1IE()

# Generated at 2022-06-24 13:17:41.998958
# Unit test for constructor of class TF1IE
def test_TF1IE():
    with open('test.json', 'r') as f:
        json_str = f.read()
    tf1ie = TF1IE(None)
    result = tf1ie._real_extract(json.loads(json_str), "10987654321")
    expected_result = [{'upload_date': '20131027', 'title': "Une erreur est survenue", '_type': 'url_transparent', 'id': '10987654321', 'url': "wat:10987654321"}]
    assert result == expected_result


# Generated at 2022-06-24 13:17:43.034725
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)

# Generated at 2022-06-24 13:17:44.076856
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:17:45.403174
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE();
    assert(tf1IE != None);

# Generated at 2022-06-24 13:17:49.283420
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")


# Generated at 2022-06-24 13:17:50.160154
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()

# Generated at 2022-06-24 13:17:50.960882
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()

# Generated at 2022-06-24 13:17:57.220689
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE_TF1 = TF1IE()
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    IE_TF1 = TF1IE()
    assert IE_TF1.suitable(test_url), 'objects tf1 not suitable'

# Generated at 2022-06-24 13:17:58.157577
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance

# Generated at 2022-06-24 13:17:59.054960
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(0);

# Generated at 2022-06-24 13:18:00.244723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(TF1IE._VALID_URL)

# Generated at 2022-06-24 13:18:02.720567
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:18:06.510546
# Unit test for constructor of class TF1IE
def test_TF1IE():
    cls = TF1IE
    sIE = cls(None)
    assert hasattr(sIE, '_VALID_URL')
    assert hasattr(sIE, '_TEST')
    assert hasattr(sIE, '_download_json')
    assert hasattr(sIE, '_download_json')
    assert hasattr(sIE, '_real_extract')

# Generated at 2022-06-24 13:18:10.523156
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-24 13:18:14.982461
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.IE_NAME = "tf1"
    tf1.MSG_FAILED = "Failed"
    tf1.FUNC_NAME = "test func"
    assert tf1.MSG_FAILED in tf1.raise_geo_restricted(None)

# Generated at 2022-06-24 13:18:15.937137
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE._TESTS

# Generated at 2022-06-24 13:18:22.362709
# Unit test for constructor of class TF1IE
def test_TF1IE():
  url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
  instance = TF1IE()
  assert instance._VALID_URL == TF1IE._VALID_URL
  assert instance._TESTS == TF1IE._TESTS
  assert instance._real_extract == TF1IE._real_extract