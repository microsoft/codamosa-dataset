

# Generated at 2022-06-24 13:08:25.509108
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-24 13:08:28.998545
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('test', 'test')
    assert ie is not None, 'Could not construct TF1IE'
    assert ie.ie_key() == 'TF1'
    assert ie.ie_name() == 'TF1'

# Generated at 2022-06-24 13:08:29.951189
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:33.924560
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1 = TF1IE({}, {}, {})
    tf1._build_url(url)

# Generated at 2022-06-24 13:08:34.792365
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj != None

# Generated at 2022-06-24 13:08:37.098429
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")


# Generated at 2022-06-24 13:08:43.070949
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert ie.gen_extractors() == [TF1IE]
    assert ie.url_result('wat:2872376') == 'https://www.wat.tv/video/mylene-farmer-d-une-icone-2zkn1.html'
    assert ie._extract_url(ie.url_result('wat:2872376')) == 'wat:2872376'

# Generated at 2022-06-24 13:08:51.940427
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    j = t._download_json(
        'https://www.tf1.fr/graphql/web',
        'quotidien-premiere-partie-11-juin-2019',
        query={
            'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
            'variables': json.dumps({
                'programSlug': 'quotidien-avec-yann-barthes',
                'slug': 'quotidien-premiere-partie-11-juin-2019'
            })
        })
    return j

# Generated at 2022-06-24 13:08:56.324142
# Unit test for constructor of class TF1IE
def test_TF1IE():
    parser = TF1IE()
    assert parser.test('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert parser.test('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:08:57.812194
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-24 13:08:59.925779
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE(InfoExtractor())
    assert tf1IE.ie_key() == 'TF1'

# Generated at 2022-06-24 13:09:02.688885
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:09:13.697956
# Unit test for constructor of class TF1IE
def test_TF1IE():
	from youtube_dl.YoutubeDL import YoutubeDL
	from youtube_dl.extractor.common import InfoExtractor
	from youtube_dl.utils import _parse_json
	from youtube_dl.extractor.tf1 import TF1IE
	from youtube_dl.utils import std_headers
	from youtube_dl.utils import unescapeHTML
	from youtube_dl.utils import clean_html
	from youtube_dl.compat import compat_str
	from youtube_dl.compat import compat_urllib_parse
	from youtube_dl.compat import compat_urllib_request
	from youtube_dl.utils import ExtractorError
	from youtube_dl.utils import RegexNotFoundError
	from youtube_dl.extractor import YoutubeIE
	from unittest.mock import MagicMock

# Generated at 2022-06-24 13:09:16.529344
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    tf1IE = TF1IE(None)
    # Act
    # Assert
    assert tf1IE != None

# Generated at 2022-06-24 13:09:18.233684
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE({'IE_NAME': 'tf1', 'test': True, 'downloader': 'internal'})

# Generated at 2022-06-24 13:09:19.240323
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:09:20.963440
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Get URL from website
    ''' #TODO
    #print(TF1IE.constructor(''))
    #assert False


# Generated at 2022-06-24 13:09:27.196320
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('TF1IE', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', {})
    assert ie.ie_key() == 'TF1', ie.ie_key()
    assert ie.video_id == '13641379', ie.video_id
    assert ie.title == 'md5:f392bc52245dc5ad43771650c96fb620', ie.title
    assert ie.description == 'md5:a02cdb217141fb2d469d6216339b052f', ie.description
    assert ie.upload_date == '20190611', ie.upload_date
    assert ie.timestamp == 1560273989, ie

# Generated at 2022-06-24 13:09:27.801757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance.suite()

# Generated at 2022-06-24 13:09:28.880127
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() is not None

# Generated at 2022-06-24 13:09:29.932984
# Unit test for constructor of class TF1IE
def test_TF1IE():
  test = TF1IE()

# Generated at 2022-06-24 13:09:31.231760
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()


# Generated at 2022-06-24 13:09:31.840882
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-24 13:09:32.841787
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-24 13:09:33.499529
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor()).IE_NAME == 'tf1'

# Generated at 2022-06-24 13:09:36.094100
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t1 = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:09:42.560395
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        print('Beginning unit test for TF1IE...')
        print('Should be a valid instance of InfoExtractor (InfoExtractor object)')
        print('Should be an invalid instance of Downloader (Downloader object)')
        _ = TF1IE(True)
    except Exception as e:
        print('Exception:', str(e))

if __name__ == '__main__':
    try:
        print('Testing a valid TF1IE...')
        test_TF1IE()
        print('Valid TF1IE passed')
    except Exception as e:
        print('Exception:', str(e))

# Generated at 2022-06-24 13:09:43.901078
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

# Test for method _real_extract of class TF1IE

# Generated at 2022-06-24 13:09:51.849120
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert obj.program_slug == 'quotidien-avec-yann-barthes'
    assert obj.slug == 'quotidien-premiere-partie-11-juin-2019'
    assert obj.episode_number is None
    assert obj.season_number is None
    assert obj.tags == []

# Generated at 2022-06-24 13:09:52.433558
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:59.822849
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_ = TF1IE()

    # Test for invalid URL
    expected_value = False
    current_value = TF1IE_.suitable('invalid URL')
    assert current_value == expected_value

    # Test for valid URL
    expected_value = True
    current_value = TF1IE_.suitable('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert current_value == expected_value

# Generated at 2022-06-24 13:10:00.434506
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:10:11.317067
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:13.411548
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test the constructor of TF1IE class
    """
    tf1 = TF1IE(None)
    assert isinstance(tf1, TF1IE)

# Generated at 2022-06-24 13:10:14.768408
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("")
    assert tf1 is not None

# Generated at 2022-06-24 13:10:15.493598
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:10:21.694478
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    from TF1IE import TF1IE
    from youtube_dl.utils import urljoin
    url = urljoin("https://www.tf1.fr/","a/a/")
    assert TF1IE(url)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:31.430004
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie.extractor_key() == 'TF1'
    assert ie.headers() is None
    assert ie.base_url() == 'https://www.tf1.fr'
    assert ie.uploader() == 'TF1'
    assert ie.version() is None
    assert ie.mplayer_config() is None
    assert ie.embed_webpage() is None
    assert ie.geo_verification_headers() is None
    assert ie.go_to_mainpage() is None
    assert ie.is_logged() is None
    assert ie.perform_logged() is None

# Generated at 2022-06-24 13:10:33.879366
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:10:35.107707
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL is not None


# Generated at 2022-06-24 13:10:35.820249
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:36.666622
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:10:37.804908
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert TF1IE == t.__class__

# Generated at 2022-06-24 13:10:42.395751
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:47.399599
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.IE_NAME == 'tf1'
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:10:49.421456
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ in globals()

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:10:54.248669
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with a correct URL
    x = TF1IE()
    assert(x.suitable == 'SUITABLE' and x.ie_key() == "TF1")
    assert(x.ie_key() == "TF1")

    # Test with an incorrect URL
    y = TF1IE()
    y.url = "https://www.youtube.com/"
    assert(y.suitable == 'NOT_SUITABLE')

# Generated at 2022-06-24 13:10:55.980389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert type(t) is TF1IE

# Generated at 2022-06-24 13:11:02.218288
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x.SUFFIX == "_tf1"
    assert x.BASE_URL == "https://www.tf1.fr"
    assert x._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

test_TF1IE()

# Generated at 2022-06-24 13:11:03.191254
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("")

# Generated at 2022-06-24 13:11:04.965886
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE('wat:2394844'), TF1IE) is True

# Generated at 2022-06-24 13:11:06.234123
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:11:06.952709
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:11:13.708445
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(ie._downloader == None)
    assert(ie._match_id == None)
    assert(ie._download_webpage == None)
    assert(ie.report_warning == None)
    assert(ie._download_json == None)
    assert(ie._download_xml == None)
    assert(ie._html_search_regex == None)
    assert(ie._search_regex == None)
    assert(ie._html_search_meta == None)
    assert(ie._html_get_attribute == None)

# Generated at 2022-06-24 13:11:14.897920
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()

# Generated at 2022-06-24 13:11:24.002549
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE("TF1IE", "tf1")
    assert inst._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:25.646431
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().extract_info.__module__ == 'tf1'

# Generated at 2022-06-24 13:11:35.409635
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None, None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE(None, None)._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE(None, None)._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-24 13:11:45.128084
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    # Test for 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert IE.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is None

# Generated at 2022-06-24 13:11:49.105082
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()

    # Assert that the constructor is correct
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:51.933736
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:52.595311
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE
    assert obj.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:11:54.791151
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'



# Generated at 2022-06-24 13:12:00.799969
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie.url == url
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-24 13:12:08.863472
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # API call 
    ii = TF1IE()
    # Object type
    assert isinstance(ii, InfoExtractor)
    # URL matches
    assert ii.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ii.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ii.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    # No matching URL or download

# Generated at 2022-06-24 13:12:20.844011
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:24.416448
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:28.666607
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Try to build TF1IE instance with invalid url
    # Assert that an exception is raised
    # Exception must be an instance of class ExtractorError
    # Exception message must be "Invalid URL"
    try:
        TF1IE("")
    except Exception as e:
        assert isinstance(e, ExtractorError)
        assert e.message == "Invalid URL"

# Generated at 2022-06-24 13:12:32.123633
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:12:33.056598
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:12:34.526121
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:12:35.791858
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('foo')

# Generated at 2022-06-24 13:12:36.818755
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_tf1ie = TF1IE('tf1', False, None)
    assert test_tf1ie

# Generated at 2022-06-24 13:12:38.374822
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test TF1IE.playlist_result;
    TF1IE().playlist_result("watch:222223", None, None, None, None)
    assert True

# Generated at 2022-06-24 13:12:40.626485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:90000153529',
          {'slug': 'replay-koh-lanta-22-mai-2015', 'programSlug': 'koh-lanta'})

# Generated at 2022-06-24 13:12:41.612268
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # should not fail
    TF1IE()

# Generated at 2022-06-24 13:12:46.035021
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """test for constructor of class TF1IE"""
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t = TF1IE()
    t._real_extract(url)

# Generated at 2022-06-24 13:12:52.217627
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE({'extractor': 'TF1'}, {})
    assert tf1.title == 'TF1'
    assert tf1.description == 'md5:73eb4dd3b4d4e25c1e0a4f579c9b9fad'
    assert tf1.ie_key() == 'TF1'
    assert tf1.thumbnail == 're:^https?://.*\.png$'
    assert tf1.duration == 0

# Generated at 2022-06-24 13:12:57.132291
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This test fails with: ImportError: No module named 'hashlib'
    #  To avoid creating a separate file for this, this test is already excluded from the
    #  list of tests in the module.
    #  On ubuntu 17.04, 'import hashlib' works if first 'sudo apt-get install python-crypto'
    #  is executed.
    pass

# Generated at 2022-06-24 13:12:58.826821
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test TF1IE instance creation
    instance = TF1IE()
    assert isinstance(instance, object)

# Generated at 2022-06-24 13:13:00.604950
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE_obj = TF1IE()
	assert TF1IE_obj.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:13:02.012828
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test constructor of TF1IE.
    """
    TF1IE("test", "test")


# Generated at 2022-06-24 13:13:03.939370
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:13:13.725790
# Unit test for constructor of class TF1IE
def test_TF1IE():
    object_TF1IE = TF1IE({})
    assert object_TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:14.257413
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:123456')

# Generated at 2022-06-24 13:13:14.796091
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:15.317555
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:13:16.056598
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.constructor_name == 'TF1IE'

# Generated at 2022-06-24 13:13:21.727791
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE().to_screen('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE().to_screen('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE().to_screen('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:13:24.095632
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test case failures: 1
    IE = TF1IE()
    assert len(IE._TESTS) == 2



# Generated at 2022-06-24 13:13:25.513011
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global TF1IE
    TF1IE(InfoExtractor())



# Generated at 2022-06-24 13:13:29.673026
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:31.469891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test.register_ie(['tf1', 'wat'])


if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:13:40.962619
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    tf1ie = TF1IE(url)
    assert tf1ie.url == url
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:45.359953
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE({})
    assert t.search_regex('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', TF1IE._VALID_URL)

# Generated at 2022-06-24 13:13:54.462048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract(
        'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract(
        'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    ie.extract(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:13:55.100819
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE

# Generated at 2022-06-24 13:13:57.535130
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test constructor of class TF1IE
    """
    test_object = TF1IE(None)
    assert isinstance(test_object, TF1IE)


# Generated at 2022-06-24 13:14:04.585249
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:14:05.850612
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check if the constructor works as expected
    assert TF1IE() is not None

# Generated at 2022-06-24 13:14:07.161154
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie is not None

# Generated at 2022-06-24 13:14:10.771741
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie.ie_key() == 'TF1'
    assert tf1_ie.ie_name() == 'TF1'
    assert tf1_ie.ie_description() == 'TF1 Group'

# Generated at 2022-06-24 13:14:19.921635
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:14:22.784419
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-24 13:14:24.726495
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        test_TF1IE()
    except:
        print("test_TF1IE FAILED")

# Generated at 2022-06-24 13:14:34.996689
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE = tf1ie.TF1IE
# test 1, attribute _VALID_URL
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
# test 2, attribute _TESTS
    assert len(TF1IE._TESTS) == 3

# Generated at 2022-06-24 13:14:44.293884
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check for input of invalid URL
    try:
        TF1IE('https://www.google.com/')
    except TypeError:
        pass
    else:
        assert False, "Should raise type error if URL is invalid"
    # Check for input of valid URL
    try:
        TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    except TypeError:
        assert False, "Should not raise type error if URL is valid"
    # Check for input of invalid program_slug

# Generated at 2022-06-24 13:14:49.994493
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Use its constructor.
    """
    actual_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    expected_url = 'https://www.tf1.fr/graphql/web?id=9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f&variables={"programSlug":"quotidien-avec-yann-barthes","slug":"quotidien-premiere-partie-11-juin-2019"}'
    expected_id = '13641379'
    expected_format = 'wat'

# Generated at 2022-06-24 13:14:54.230391
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:56.249074
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj
    assert obj.ie_key() == 'TF1'
    assert obj.ie_key() == 'TF1'

# Generated at 2022-06-24 13:14:57.685345
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)
    assert ie._TESTS

# Generated at 2022-06-24 13:15:00.342520
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE(url)

# Generated at 2022-06-24 13:15:01.718308
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.name == 'tf1.fr'

# Generated at 2022-06-24 13:15:11.608367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html' # noqa: 501

# Generated at 2022-06-24 13:15:14.629106
# Unit test for constructor of class TF1IE
def test_TF1IE():
    r = TF1IE()
    assert r.ie_key() == 'TF1'
    assert r.example_url() is not None
    assert r._VALID_URL == r._TEST.get('valid_url')
    assert r._WORKING is not None



# Generated at 2022-06-24 13:15:15.452132
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:15:16.637028
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:15:27.722934
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:28.312698
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:15:35.569013
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor.url_result(
        'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert info_extractor.url_result(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:15:38.877404
# Unit test for constructor of class TF1IE
def test_TF1IE():
    def test_constructor_TF1IE(self):
        '''
            test the constructor of TF1IE
            :return:
        '''
        pass



# Generated at 2022-06-24 13:15:40.535739
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t1 = TF1IE()
    assert t1.suitable(url)

# Generated at 2022-06-24 13:15:44.762596
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:46.532394
# Unit test for constructor of class TF1IE
def test_TF1IE():
    "test_TF1IE"
    TF1IE(None, None)

# Generated at 2022-06-24 13:15:47.209751
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:48.220368
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("TF1IE")

# Generated at 2022-06-24 13:15:49.188295
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == 'tf1'

# Generated at 2022-06-24 13:15:49.856044
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:51.522811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._TESTS[0]


# Generated at 2022-06-24 13:15:56.322478
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(_VALID_URL)
    if (obj.slug is None or obj.program_slug is None):
        raise Exception('constructor must set slug and program_slug attributes for %s' % _VALID_URL)
    assert obj.slug == 'quotidien-premiere-partie-11-juin-2019'
    assert obj.program_slug == 'quotidien-avec-yann-barthes'

# Generated at 2022-06-24 13:15:58.959230
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tF1IE = TF1IE()
    expected = 'https://www.tf1.fr/graphql/web'
    assert tF1IE._download_json._URL == expected

# Generated at 2022-06-24 13:15:59.648309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-24 13:16:03.000759
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:16:05.911453
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:16:16.738861
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert i._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-24 13:16:19.966226
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check if TF1IE constructor can be called with only one argument
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:16:22.432526
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tcase = InfoExtractor(TF1IE)
    for i in tcase._TESTS:
        tcase.assertTrue(tcase._VALID_URL in i['url'])

# Generated at 2022-06-24 13:16:23.948139
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.HOST == 'www.tf1.fr'



# Generated at 2022-06-24 13:16:24.788230
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)



# Generated at 2022-06-24 13:16:35.427681
# Unit test for constructor of class TF1IE
def test_TF1IE():
    filename = 'test_TF1IE_download.json'
    with open(filename, 'rb') as myfile:
        data = myfile.read()

# Generated at 2022-06-24 13:16:36.251458
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:16:37.416305
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:16:38.433085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert list(IE) == []

# Generated at 2022-06-24 13:16:38.969645
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:40.897756
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE.tf1 = TF1IE()
    assert test_TF1IE.tf1

# Generated at 2022-06-24 13:16:51.376093
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE(downloader=None)
    assert info_extractor.ie_key() == 'TF1'
    assert info_extractor.ie_id() == 'TF1'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:56.794795
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Testing constructor of class TF1IE...", end='')
    assert TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html") is not None
    assert TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html") is not None
    print("Done.")


# Generated at 2022-06-24 13:16:58.317108
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE(InfoExtractor())
    assert class_ != None

# Generated at 2022-06-24 13:16:59.376738
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()


# Generated at 2022-06-24 13:17:01.056047
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE()
    assert class_
test_TF1IE()

# Generated at 2022-06-24 13:17:03.517198
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test the construction of class TF1IE
    """
    TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:17:08.293018
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('/w9/a-la-recherche-du-buzz-perdu/videos/replay-a-la-recherche-du-buzz-perdu-20-mai-2015.html')
    assert TF1IE('/w9/transparent/videos/id.html')

# Unit test constructor of class TF1IE

# Generated at 2022-06-24 13:17:09.840921
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("tf1", "tf1fr", "http://www.tf1.fr/")

# Generated at 2022-06-24 13:17:12.355416
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:13.257038
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:17:20.274812
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from ..TF1 import TF1IE
    from ..utils import TEST_RESOURCES_DIR
    from .test_utils import TestVideoIE
    from io import StringIO

    for filename, test in TestVideoIE.load_dump_tests(TF1IE, TEST_RESOURCES_DIR).items():
        input_file = StringIO(test)
        results = TestVideoIE(TF1IE).run_dump_test(input_file)
        for res in results:
            print(res)

# Generated at 2022-06-24 13:17:25.796547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    example_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._TESTS[0]['url'] == example_url
    assert TF1IE._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-24 13:17:29.779874
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    IE.suitable(IE._VALID_URL)
    assert IE.IE_NAME == 'tf1'
    assert IE.IE_SHORT_NAME == 'tf1'
    assert IE.ie_key() == 'tf1'

# Generated at 2022-06-24 13:17:30.244003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:17:34.670187
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    t.extract('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:17:42.265817
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')



# Generated at 2022-06-24 13:17:43.327491
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)

# Generated at 2022-06-24 13:17:47.876061
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE([])
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    

# Generated at 2022-06-24 13:17:48.950045
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:49.841886
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:17:50.408884
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:51.522622
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == "TF1"

# Generated at 2022-06-24 13:17:52.563742
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t != None

# Generated at 2022-06-24 13:17:54.324992
# Unit test for constructor of class TF1IE
def test_TF1IE():
	"""Unit test for TF1IE class"""
	tf1IE = TF1IE()
	assert tf1IE != None

# Generated at 2022-06-24 13:17:57.268294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("tf1")
    assert t.IE_NAME == "tf1:tf1"

# Generated at 2022-06-24 13:18:01.921319
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'
    assert tf1.IE_DESC == 'TF1'
    assert tf1.VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:05.153549
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor_test(TF1IE, {
        'url': 'https://www.tf1.fr/tf1/jt-20h/videos/450-000-chomeurs-de-plus-en-un-an.html',
        'only_matching': True,
    })

# Generated at 2022-06-24 13:18:15.781786
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    program_slug, slug = re.match(tf1._VALID_URL, url).groups()
    data = tf1._download_json(
        'https://www.tf1.fr/graphql/web', slug, query={
            'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
            'variables': json.dumps({
                'programSlug': program_slug,
                'slug': slug,
            })
        })

# Generated at 2022-06-24 13:18:24.309333
# Unit test for constructor of class TF1IE
def test_TF1IE():
    example_inputs = [
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ]
    tf1 = TF1IE()
    for example_input in example_inputs:
        assert tf1.suitable(example_input)