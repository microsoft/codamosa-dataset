

# Generated at 2022-06-24 13:08:21.242637
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:23.684258
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create instance of class TF1IE
    tf1_ie = TF1IE()
    # Check if instance is type of InfoExtractor
    assert isinstance(tf1_ie, InfoExtractor)

# Generated at 2022-06-24 13:08:24.463816
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return assert_true(True)

# Generated at 2022-06-24 13:08:25.731114
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE()


# Generated at 2022-06-24 13:08:30.043748
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:39.197606
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create a video object for test
    test_video = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    # Check that the object has been initialized properly
    assert test_video._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:42.532496
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'



# Generated at 2022-06-24 13:08:52.622105
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:55.915132
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:56.451715
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:57.659777
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:08:59.804855
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None
    assert TF1IE._TESTS is not None

# Generated at 2022-06-24 13:09:05.658577
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:09:06.482829
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:08.613727
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExt = InfoExtractor()
    inst = TF1IE()
    infoExt.add_info_extractor(inst)

# Generated at 2022-06-24 13:09:19.374058
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE._build_url_result(
        "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html",
        "TF1",
        "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html",
        "Quotidien avec Yann Barthès",
        "13641379",
        "Quotidien",
        "11 juin 2019"
    )
    assert(result["episodes"] == 1)
    assert(result["id"] == "13641379")

# Generated at 2022-06-24 13:09:21.726896
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:22.211089
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:09:23.779615
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._extract_urls('https://www.tf1.fr/tf1/koh-lanta/videos.html')

# Generated at 2022-06-24 13:09:24.266887
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:25.388720
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:27.400263
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_test = TF1IE("test", "test")

# Generated at 2022-06-24 13:09:31.231464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert video

# Generated at 2022-06-24 13:09:32.257079
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:09:35.330886
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:09:39.207881
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    print(t.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'))

if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-24 13:09:39.797680
# Unit test for constructor of class TF1IE
def test_TF1IE():
   pass

# Generated at 2022-06-24 13:09:42.098566
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance.ie_key() == 'TF1'
    assert instance.ie_name() == 'TF1'

# Generated at 2022-06-24 13:09:42.711191
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE

# Generated at 2022-06-24 13:09:44.037593
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test that TF1IE constructor accepts an empty url
    TF1IE("")
    assert True

# Generated at 2022-06-24 13:09:47.286374
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:48.452263
# Unit test for constructor of class TF1IE
def test_TF1IE():
	pass # unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:09:52.243721
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:52.851803
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:53.545964
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:10:02.781885
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert(IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert(IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
   

# Generated at 2022-06-24 13:10:13.502822
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:15.441456
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('tf1', 'tf1')
    assert ie._VALID_URL

# Generated at 2022-06-24 13:10:24.914006
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This url is available for testing
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    # This is a method of the test module
    # Selects the first result returned by the ie
    ie = get_info_extractor('TF1')
    info = ie.extract(url)
    assert info['id'] == '13641379'
    assert info['title'] == 'Quotidien 1ère partie - 11 juin 2019'

# Generated at 2022-06-24 13:10:29.349187
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (TF1IE()._VALID_URL == "^https?:\/\/(?:www\.)?tf1\.fr\/[^\/]+\/(?P<program_slug>[^\/]+)\/videos\/(?P<id>[^\/?&#]+)\.html")


# Generated at 2022-06-24 13:10:31.099549
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('md5:f392bc52245dc5ad43771650c96fb620')

# Generated at 2022-06-24 13:10:33.939762
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:10:43.599405
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tIE=TF1IE()
    assert tIE._VALID_URL==r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:53.238863
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('TF1IE')
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:03.729128
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import unittest
    from tools import match_url, get_url_info
    from TF1IE import TF1IE

    subject = TF1IE()
    # init unit test for get_url_info function
    # NOTE: example from website
    E1 = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    I1 = get_url_info(E1)
    # init unit test for match_url function
    # NOTE: example from website
    E2 = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    I2 = match_url(E2)

    # print url.match.group(1) + "-"

# Generated at 2022-06-24 13:11:07.343949
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:11.537493
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Check if the class constructor works"""
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.ie_id() == 'tf1'
    assert ie.SUCCESS.get('tf1') == 'wat:.*'
    assert ie.extract('http://www.wat.tv/video/test-lg-12a7o_12a7p_.html') is not None

# Generated at 2022-06-24 13:11:16.845972
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("self", "url", "tf1", "program_slug", "slug")
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:18.530964
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Smoke test
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:11:20.162454
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a_test_TF1IE = TF1IE()
    print(a_test_TF1IE)

# Generated at 2022-06-24 13:11:23.539868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_object = TF1IE()
    assert tf1_object._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:24.320693
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.test()

# Generated at 2022-06-24 13:11:27.828416
# Unit test for constructor of class TF1IE
def test_TF1IE():
    wat_id = '13641379'
    url = 'wat:' + wat_id

    instance = TF1IE()
    instance._real_extract(url)

    assert isinstance(instance, TF1IE)

# Generated at 2022-06-24 13:11:28.371677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:11:29.309734
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:11:31.562818
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:11:38.161879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert TF1IE.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert not TF1IE.suitable('http://www.tf1.fr/')

# Generated at 2022-06-24 13:11:39.316710
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE')

# Generated at 2022-06-24 13:11:40.811919
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-24 13:11:49.769952
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html')

# Generated at 2022-06-24 13:11:53.152481
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert(tf1.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'))
    assert(not tf1.suitable('https://www.youtube.com/watch?v=BaW_jenozKc'))
    assert(tf1.ie_key() == 'wat')

# Generated at 2022-06-24 13:11:57.564623
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor test
    obj = TF1IE()
    assert obj.IE_NAME == 'TF1'
    assert obj.IE_DESC == 'Télévision française 1'
    assert obj._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:03.584507
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.download("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie.url == 'http://wat.tv/get/flash/'+ie.video_id+'.html'
    assert ie.video_id == '13641379'

# Generated at 2022-06-24 13:12:13.002759
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:16.796506
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None).tf1_token == '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'

# Generated at 2022-06-24 13:12:18.144389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    new_TF1IE = TF1IE()
    assert new_TF1IE is not None

# Generated at 2022-06-24 13:12:22.054303
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:12:24.731787
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        tf1=TF1IE(TF1IE.__name__)
        print(tf1)
    except Exception as e:
        print(e)

# Generated at 2022-06-24 13:12:27.007493
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:33.967738
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with URL of type 'https://www.tf1.fr/.../quotidien/videos/quotidien-premiere-partie-11-juin-2019.html'
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:34.800561
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:37.621227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    example_url = TF1IE.working_quick_entries[0]
    url = TF1IE.url_result(example_url)['url']
    instance = TF1IE()
    instance._real_extract(url)

# Generated at 2022-06-24 13:12:42.576059
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor
    
    info_extractor = InfoExtractor()
    
    # Test for video with only one video
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    result = info_extractor._real_extract(info_extractor, url)
    assert result['id'] == '13641379'
    assert result['timestamp'] == 1560273989
    assert result['description'] == 'md5:a02cdb217141fb2d469d6216339b052f'

# Generated at 2022-06-24 13:12:43.505501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:12:53.574332
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor test
    result = TF1IE()
    # Check type
    assert(isinstance(result, TF1IE) == True)
    # Check attributes
    assert(result._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(isinstance(result._TESTS, list) == True)

# Generated at 2022-06-24 13:12:54.949367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie is not None)

# Generated at 2022-06-24 13:12:55.936835
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:12345')

# Generated at 2022-06-24 13:13:01.902773
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE(None)._result(True)
    assert result["id"] == "9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f"
    assert result["url"] == "https://www.tf1.fr/graphql/web"
    assert result["ie_key"] == "TF1"
    assert result["query"]["variables"] == '{"programSlug": "program_slug", "slug": "slug"}'

# Generated at 2022-06-24 13:13:03.921541
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert TF1IE
    except NameError:
        raise AssertionError("Class TF1IE is not defined !")

# Generated at 2022-06-24 13:13:06.259847
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:13:07.548670
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # No error raised
    TF1IE(None)



# Generated at 2022-06-24 13:13:11.191412
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_file = "TF1IE"
    class_ = TF1IE
    assert class_file == class_.ie_key()
    assert class_file.split("IE")[1] == class_.ie_key_short()


# Generated at 2022-06-24 13:13:12.559420
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for the constructor of TF1
    """
    TF1IE()

# Generated at 2022-06-24 13:13:13.164947
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:13.981920
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Tests TF1IE constructor"""
    # Tests for error cases
    assert TF1IE() is not None

# Generated at 2022-06-24 13:13:14.498190
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import TF1IE
    TF1IE()

# Generated at 2022-06-24 13:13:16.263606
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert(tf1.ie_key() == 'tf1')

# Generated at 2022-06-24 13:13:17.692854
# Unit test for constructor of class TF1IE
def test_TF1IE():
  obj = TF1IE()
  assert obj.IE_NAME == 'TF1'

# Generated at 2022-06-24 13:13:28.827419
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # assert instance._TESTS == [{
    #     'url': 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
    #     'info_dict': {
    #         'id': '13641379',
    #         'ext': 'mp4',
    #         'title': 'md5:f392bc52245dc5ad43771650c96fb620',
    #

# Generated at 2022-06-24 13:13:29.759408
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:13:30.155692
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:34.849800
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    url = 'https://wat.tv/video/telefoot-du-12-mars-2017-saison-6-jeu-13-5gf58.html'

    # Act
    tf1_ie = TF1IE(url)

    # Assert
    assert tf1_ie._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:13:37.755802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global tf1
    tf1 = TF1IE()
    tf1._download_json = lambda *args: {}
    assert isinstance(tf1, TF1IE)

test_TF1IE()


# Generated at 2022-06-24 13:13:39.701966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:13:40.551308
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE();
    assert inst != None;

# Generated at 2022-06-24 13:13:43.472703
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE().extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:13:55.196719
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test case for constructor of class TF1IE """

    tf1_ie = TF1IE()

    # Assert the correct Compatibility Identifier
    assert tf1_ie.compat_id() is None

    # Assert the correct extractor type
    assert tf1_ie.extractor_type() == 'general'

    # Assert the correct extractor type
    assert tf1_ie.is_suitable(None) is False
    assert tf1_ie.is_suitable({"url": "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"}) is True

# Generated at 2022-06-24 13:14:03.980600
# Unit test for constructor of class TF1IE
def test_TF1IE():
    input = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1 = TF1IE(input)
    assert (tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:14:10.372784
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import TestCase
    from .common import InfoExtractor

    # check that unittest is running
    TestCase("test").assertTrue(True)
    print("UnitTest for TF1IE is running\n")

    # check that TF1IE inherits InfoExtractor
    TestCase("test").assertTrue(issubclass(TF1IE, InfoExtractor))

    # check that the object of TF1IE is created
    TestCase("test").assertIsNotNone(TF1IE("test"))

# Generated at 2022-06-24 13:14:11.027351
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:14:19.859874
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_user_video_ie import UserVideoIE
    from .common import InfoExtractor

    assert isinstance(TF1IE, type)
    assert issubclass(TF1IE, InfoExtractor)
    assert isinstance(TF1IE, type)
    assert issubclass(TF1IE, InfoExtractor)
    assert isinstance(TF1IE, type)
    assert issubclass(TF1IE, InfoExtractor)
    assert isinstance(TF1IE, type)
    assert issubclass(TF1IE, InfoExtractor)
    assert isinstance(TF1IE, type)
    assert issubclass(TF1IE, InfoExtractor)
    assert isinstance(TF1IE, type)
    assert issubclass(TF1IE, InfoExtractor)

# Generated at 2022-06-24 13:14:28.046402
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:14:29.421788
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie = TF1IE('TF1IE')

# Generated at 2022-06-24 13:14:32.640986
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    assert TF1IE()._TESTS == TF1IE._TESTS
    assert TF1IE()._real_extract == TF1IE._real_extract

# Generated at 2022-06-24 13:14:33.382787
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:14:37.316860
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:37.827109
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:41.673568
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Make sure that constructors do not raise exceptions
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:14:44.608644
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('username', 'password')
    expected_type = 'TF1IE'
    actual_type = repr(tf1ie).split(' ')[0].replace('.', '')
    assert actual_type == expected_type

# Generated at 2022-06-24 13:14:50.118758
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    # Checks whether it is an instance of TF1IE
    assert isinstance(ie, TF1IE)
    # Checks whether it is an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:14:52.995501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
        print("[+] Test for TF1IE constructor succeed")
    except Exception as e:
        print("[-] Test for TF1IE constructor fail")


# Generated at 2022-06-24 13:14:58.650798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html').program_slug == 'quotidien-avec-yann-barthes'
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html').slug == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:14:59.228333
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:00.543231
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.ie_key() == 'TF1'

# Generated at 2022-06-24 13:15:03.086533
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:15:12.864496
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("%s/examples/tf1.fr/13641379.html" % __file__.split("__")[0])
    assert ie.get_url() == 'https://www.tf1.fr/tf1/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie.get_params() == {'skip_download':True, 'format':'bestvideo'}
    assert ie.get_program_slug() == 'quotidien-avec-yann-barthes'
    assert ie.get_slug() == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:15:15.647211
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert obj.name == "TF1IE"

# Generated at 2022-06-24 13:15:16.113407
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:27.450891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1 = TF1IE()
    tf1._downloader = Mock()

# Generated at 2022-06-24 13:15:29.968489
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:15:31.168355
# Unit test for constructor of class TF1IE
def test_TF1IE():
    name = 'tf1'
    TF1IE(name) == TF1IE

# Generated at 2022-06-24 13:15:42.742243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:44.657044
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(youtube_ie = youtube_ie, morph_ie = morph_ie, local_ie = local_ie)

# Generated at 2022-06-24 13:15:54.678251
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:59.890861
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('TF1IE', 'tf1.fr')
    sample_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1.suitable(sample_url)
    assert tf1._real_extract(sample_url)

# Generated at 2022-06-24 13:16:05.913379
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien/videos/quotidien-avec-yann-barthes-11-juin-2019.html')
    TF1IE('https://www.tf1.fr/tmc/quotidien/videos/quotidien-avec-yann-barthes-11-juin-2019.html')

# Generated at 2022-06-24 13:16:06.538785
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('wat:')

# Generated at 2022-06-24 13:16:07.141306
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:08.689516
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE('test')

test_TF1IE()

# Generated at 2022-06-24 13:16:19.632295
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1ie = TF1IE(url)
    assert tf1ie.url == url
    assert tf1ie.program_slug == 'quotidien-avec-yann-barthes'
    assert tf1ie.slug == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:16:27.448311
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:29.453261
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert isinstance(tf1IE, TF1IE)


# Generated at 2022-06-24 13:16:32.979117
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:16:33.679615
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:16:39.429244
# Unit test for constructor of class TF1IE
def test_TF1IE():
    example_url = TF1IE._VALID_URL
    url_parts = re.match(TF1IE._VALID_URL, example_url)
    program_slug, slug = url_parts.groups()
    tf1_ie = TF1IE(tf1_ie)
    assert tf1_ie.program_slug == program_slug
    assert tf1_ie.slug == slug
    assert tf1_ie.cache_slug == tf1_ie._VALID_URL

# Generated at 2022-06-24 13:16:40.624313
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE == TF1IE()

# Generated at 2022-06-24 13:16:51.121672
# Unit test for constructor of class TF1IE
def test_TF1IE():
    module = 'TF1IE'
    class_name = 'TF1IE'
    pattern = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:51.651883
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:57.432815
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie.program_slug == 'quotidien-avec-yann-barthes'
    assert ie.slug == 'quotidien-premiere-partie-11-juin-2019'
    assert ie._real_extract(ie._VALID_URL)['title'] == 'Quotidien première partie -- 11 juin 2019'

# Generated at 2022-06-24 13:17:06.088000
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = TF1IE()
    print(("TESTER:", tester))
    print("TESTER IS INSTANCE InfoExtractor:", isinstance(tester, InfoExtractor))
    print("TESTER IS INSTANCE YoutubeIE:", isinstance(tester, YoutubeIE))
    print("TESTER IS INSTANCE YoutubeDL:", isinstance(tester, YoutubeDL))
    print("TESTER IS INSTANCE YoutubeBaseInfoExtractor:", isinstance(tester, YoutubeBaseInfoExtractor))
    print("TESTER IS INSTANCE YoutubeDL:", isinstance(tester, YoutubeDL))
    return tester

# Get the test case from the webpage by specifying the URL
# Do not change anything below this line

# Generated at 2022-06-24 13:17:13.969879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert i.test(i)

    i = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert i.test(i)

    i = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert i.test(i)

# Generated at 2022-06-24 13:17:16.817284
# Unit test for constructor of class TF1IE
def test_TF1IE():
    sub_class_name = TF1IE.__name__
    assert sub_class_name == 'TF1IE', "Subclass name is not correct"

# Generated at 2022-06-24 13:17:26.516749
# Unit test for constructor of class TF1IE
def test_TF1IE():

    url = 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    program_slug = 'quotidien-avec-yann-barthes'
    slug = 'quotidien-premiere-partie-11-juin-2019'

    assert_equal(TF1IE._VALID_URL, r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:17:34.054079
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    sample_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie.suitable(sample_url) is True
    assert ie.IE_NAME == 'tf1'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:43.982995
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"
    assert TF1IE._TESTS[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert TF1IE._TESTS[0]['info_dict']['id'] == "13641379"
    assert TF1IE._TESTS[0]['info_dict']['ext'] == "mp4"

# Generated at 2022-06-24 13:17:50.863975
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"
    assert tf1._TESTS[0]["url"] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

# Generated at 2022-06-24 13:17:52.066349
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:17:52.692842
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:55.879887
# Unit test for constructor of class TF1IE
def test_TF1IE():
	ie = TF1IE()
	assert ie._VALID_URL is not None
	assert ie._TESTS is not None


# Generated at 2022-06-24 13:17:57.033486
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:17:58.072441
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1.fr'

# Generated at 2022-06-24 13:17:59.972190
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    @return: A test
    @rtype: L{TestCase}
    """
    x = TF1IE()

# Generated at 2022-06-24 13:18:04.349740
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1 = TF1IE()
    assert TF1.ie_key() == 'TF1'
    assert isinstance(TF1.ie_key(), str)
    assert TF1.NAME == 'TF1'
    assert isinstance(TF1.NAME, str)
    assert TF1.description == 'TF1'
    assert isinstance(TF1.description, str)

# Generated at 2022-06-24 13:18:04.996231
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE

# Generated at 2022-06-24 13:18:05.651279
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:18:08.761667
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create instance of TF1IE by calling its constructor.
    tf1_ie = TF1IE()
    # Assert that TF1IE's method _real_extract exists.
    assert (tf1_ie._real_extract != None)

# Generated at 2022-06-24 13:18:10.581186
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()


# Generated at 2022-06-24 13:18:13.263188
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test the class is constructed properly
    tf1IE = TF1IE('TF1IE', 'tf1')
    assert tf1IE.ie_key() == 'wat'

# Generated at 2022-06-24 13:18:16.332405
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:18:25.420672
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.name == 'tf1'
    assert IE.IE_NAME == 'tf1'
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert IE._TESTS[0]['info_dict']['id'] == '13641379'