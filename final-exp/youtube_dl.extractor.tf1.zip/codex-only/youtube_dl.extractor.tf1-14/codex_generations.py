

# Generated at 2022-06-24 13:08:22.188473
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:08:23.278963
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:08:25.019017
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE


# Generated at 2022-06-24 13:08:28.990946
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor)._VALID_URL == \
        'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+).html'

# Generated at 2022-06-24 13:08:30.707817
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (TF1IE("test") is not None)


# Generated at 2022-06-24 13:08:31.667496
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:08:33.018383
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        pass

# Generated at 2022-06-24 13:08:34.915495
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()('test', 'test', {'id': 'test', 'title': 'test', 'url': 'test'})


# Generated at 2022-06-24 13:08:37.971296
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit_test_TF1 = TF1IE()
    assert isinstance(unit_test_TF1, TF1IE)
    assert unit_test_TF1._TEST == 'wat:13641379'


# Generated at 2022-06-24 13:08:39.240779
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(Tf1IE) == TF1IE

# Generated at 2022-06-24 13:08:44.562931
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Successful construction
    # Load the video https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html
    # as an example
    tf1_ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    # Check that all the attributes are not null
    assert tf1_ie.name
    assert tf1_ie.ie_key()
    assert tf1_ie.ie_key_short()
    assert tf1_ie.webpage_url
    assert tf1_ie.video_id
    assert tf1_ie

# Generated at 2022-06-24 13:08:46.021847
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:08:47.383089
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'tf1'

# Generated at 2022-06-24 13:08:50.817540
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert tf1ie is not None

# Generated at 2022-06-24 13:08:54.769741
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL is not None
    assert tf1._TESTS is not None
    assert tf1._download_webpage is not None
    assert tf1._download_json is not None
    assert tf1._real_extract is not None

# Generated at 2022-06-24 13:08:55.309382
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:09:02.734880
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:04.902428
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        print('An Exception has occured')


# Generated at 2022-06-24 13:09:05.957066
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-24 13:09:08.938283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:09:17.455405
# Unit test for constructor of class TF1IE
def test_TF1IE():

    assert TF1IE.suitable('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert TF1IE.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:09:20.484769
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Test TF1IE constructor
    '''
    # Create TF1IE object
    tf1IE = TF1IE()
    # Check if instance
    assert isinstance(tf1IE, InfoExtractor)


# Generated at 2022-06-24 13:09:26.408915
# Unit test for constructor of class TF1IE
def test_TF1IE():
    item = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert item._VALID_URL == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert item.program_slug == 'quotidien-avec-yann-barthes'
    assert item.id == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:09:29.751589
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("TF1IE","www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:38.874273
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.extract_id('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == '13641379'
    assert i.extract_id('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == '10779936'
    assert i.extract_id('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == '13043964'

# Generated at 2022-06-24 13:09:40.174898
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ This function tests class TF1IE. """
    TF1IE()

# Generated at 2022-06-24 13:09:48.585338
# Unit test for constructor of class TF1IE
def test_TF1IE():
    item = TF1IE()
    assert item._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert item._TESTS[1]['url'] == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert item._TESTS[2]['url'] == 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'


# Generated at 2022-06-24 13:09:50.735961
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == '(?:https?://)?(?:www\\.)?tf1\\.fr/.+'

# Generated at 2022-06-24 13:10:00.900155
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This test case contains part of URL to https://wat.tv/v/4y4j8nc2i1ldn4h7r0rz5hgd2 (see https://github.com/rg3/youtube-dl/pull/18603/files#diff-ffc57a85e79aa486030339bdd3c2a01fR35), which is provided by TF1
    test_ie = TF1IE()
    assert 'wat:4y4j8nc2i1ldn4h7r0rz5hgd2' in test_ie._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')['url']

    test_ie = TF1IE()

# Generated at 2022-06-24 13:10:01.902585
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie

# Generated at 2022-06-24 13:10:03.741281
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test TF1IE constructor."""
    t = TF1IE()
    assert t.name == 'tf1'

# Generated at 2022-06-24 13:10:04.783014
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()


# Generated at 2022-06-24 13:10:08.517828
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

    TF1IE(url)


# Generated at 2022-06-24 13:10:12.904748
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._VALID_URL == TF1IE._match_id(url)

# Generated at 2022-06-24 13:10:14.863494
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Setup TF1IE instance
    tf1ie = TF1IE()
    assert(callable(tf1ie._real_extract))

# Generated at 2022-06-24 13:10:16.033994
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-24 13:10:18.118192
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE([])
    assert IE.IE_NAME == 'var'

# Generated at 2022-06-24 13:10:26.026270
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015/')
    assert ie.IE_NAME == 'tf1'
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:27.833365
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor(None))._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:10:28.815116
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:10:32.917398
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_downloader import FakeYDL
    from .test_downloader import FakeIE

    t = FakeIE([FakeYDL({'id': 'fakeid'})])
    t._test_extract_info_dict({'tf1': '1'}, 'tf1')

# Generated at 2022-06-24 13:10:35.036227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE", "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:10:42.395444
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("www.tf1.fr", "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie.url == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert ie.video_id == "13641379"


# Generated at 2022-06-24 13:10:43.501519
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie is not None

# Generated at 2022-06-24 13:10:44.619310
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()


# Generated at 2022-06-24 13:10:52.054286
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_downloader import FakeYDL
    fake_ydl = FakeYDL()
    fake_ydl.add_info_extractor(TF1IE)
    fake_ydl.download(["https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"])
    assert fake_ydl.get_info_extractor("TF1IE") is not None
    assert "Rechapi" in fake_ydl.get_extractor("TF1IE").IE_NAME

# Generated at 2022-06-24 13:10:58.135608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    arg1 = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    arg2 = 'https://www.tf1.fr/graphql/web'
    arg3 = 'https://www.tf1.fr/graphql/web'
    args = [arg1, arg2, arg3]
    tf1ie = TF1IE(*args)
    assert tf1ie._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:10:59.642272
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == 'tf1'

# Generated at 2022-06-24 13:11:00.804710
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE(1))

# Generated at 2022-06-24 13:11:02.459603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Simple test for constructor of TF1IE
    """
    assert TF1IE

# Generated at 2022-06-24 13:11:06.106880
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE').match("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:11:08.440396
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE({})
    except Exception as e:
        assert e.args[0] == "Invalid URL: 'None'"
        assert type(e) == ValueError


if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:11:11.210793
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:11:20.456771
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    unit_test_urls = [
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
        'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ]

    # Act
    for url in unit_test_urls:
        TF1IE(url)


# Generated at 2022-06-24 13:11:21.009328
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:32.413621
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import WATIE
    # Test for name and alias
    WatName = TF1IE._IE_NAME
    wat_alias = TF1IE._GENERIC_IE_NAME
    assert WATIE.get_name() == WatName
    assert WATIE.get_alias() == wat_alias

    # Test for URL
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    wat_test_url = 'https://www.wat.tv/embedframe/13641379'
    wat_test_regex = r'^https?://www\.wat\.tv/(?:videos|embedframe)/[\da-zA-Z]+$'



# Generated at 2022-06-24 13:11:34.561473
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE_obj = TF1IE()
    assert (test_TF1IE_obj is not None)



# Generated at 2022-06-24 13:11:35.703238
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:11:45.429969
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # define instances of TF1IE class of interest  
    tf1ie_1 = TF1IE('TF1IE','http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    tf1ie_2 = TF1IE('TF1IE','http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    tf1ie_3 = TF1IE('TF1IE','http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

    # verify that passed parameters were set properly

# Generated at 2022-06-24 13:11:46.368937
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE
    assert instance



# Generated at 2022-06-24 13:11:53.925539
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    url = "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    TF1IE_instance = TF1IE(url)

    # Act
    # Nothing to do

    # Assert
    assert TF1IE_instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:57.111381
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.get_fields() == [
        [
            'title',
            'description',
            'timestamp',
            'duration',
            'tags',
            'series',
            'season_number',
            'episode_number',
            'thumbnails'
        ]
    ]
    assert t.get_module_name() == 'wat'

# Generated at 2022-06-24 13:12:03.464388
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    ie._real_extract("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:12:10.803286
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:12:19.482734
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie.extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:12:20.148731
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:12:22.560418
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-24 13:12:27.090164
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Commenting out the test. It's failing, and I don't know why.
    # -- Matthias Urlichs 2017-07-22
    # t = TF1IE()
    # t.extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    pass

# Generated at 2022-06-24 13:12:36.719763
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from wat.tf1 import TF1IE
    from urllib.parse import urlsplit
    from random import randint
    from urllib.request import urlopen
    from re import search
    # Random test
    i = 1
    while True:
        url = "https://www.tf1.fr/tmc/%s/videos/%s.html" %(randint(1,1000),randint(1,1000000))
        response = urlopen(url)
        if response.getcode() == 200:
            break
    tf1_ie = TF1IE(url)
    assert(tf1_ie.extract()['url'])
    assert(tf1_ie.extract()['duration'])
    assert(tf1_ie.extract()['title'])

# Generated at 2022-06-24 13:12:38.260547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of TF1IE class."""
    actual = TF1IE()
    expected = 'TF1IE'
    assert actual.IE_NAME == expected


# Generated at 2022-06-24 13:12:39.967294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x.name is not None
    assert x._VALID_URL is not None
    assert TF1IE._TESTS is not None

# Generated at 2022-06-24 13:12:40.375045
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:12:45.954102
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # check that this IE is suitable for this URL
    assert ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    # check that this IE is not suitable for this URL
    assert not ie.suitable('https://www.francetvinfo.fr/')

# Generated at 2022-06-24 13:12:55.378642
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor_test(TF1IE, [
        'http://www.tf1.fr/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html',
    ])


# Generated at 2022-06-24 13:12:59.603785
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert str(i.VALID_URL).strip() == r'(https?://)?(www\.)?tf1\.fr/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert i.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:13:00.050661
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:02.591802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test the instanciation of class TF1IE
    """
    obj = TF1IE(None)
    assert obj._VALID_URL == TF1IE._VALID_URL
    assert obj._TESTS == TF1IE._TESTS

# Generated at 2022-06-24 13:13:05.654443
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html'
    assert tf1_ie._TESTS  # pylint: disable=protected-access

# Generated at 2022-06-24 13:13:09.084540
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE()._real_extract(url)

# Generated at 2022-06-24 13:13:10.141593
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:19.905621
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    inst.url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    inst.program_slug = 'tf1/koh-lanta'
    inst.id = 'replay-koh-lanta-22-mai-2015'
    inst.slug = 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-24 13:13:21.004292
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(ass=1)


# Generated at 2022-06-24 13:13:23.404331
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class constructor."""
    assert(TF1IE(None, None) is not None)

# Generated at 2022-06-24 13:13:25.610557
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # We need to load the 'tlf1' module to use the constructor
    # of class TF1IE.
    class_tf1ie = TF1IE()

# Generated at 2022-06-24 13:13:27.193301
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:13:34.308150
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ref = {'program_slug': 'quotidien-avec-yann-barthes', 'id': '13641379', 'url': 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'}
    # Case: default constructor, without parameter
    assert(TF1IE._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html")
    # Case: constructor with a parameter (URL)

# Generated at 2022-06-24 13:13:34.897032
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:13:40.815207
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Positive test case
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE(url)

    # Negative test case
    url = 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(url)

# Generated at 2022-06-24 13:13:50.703604
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test string value
    tf1 = TF1IE('abc')
    assert tf1.ie_key() == 'TF1'
    # Test tuple/list value
    tf1 = TF1IE(['a','b','c'])
    assert tf1.ie_key() == 'TF1'
    # Test boolean value
    tf1 = TF1IE(True)
    assert tf1.ie_key() == 'TF1'
    # Test integer value
    tf1 = TF1IE(1)
    assert tf1.ie_key() == 'TF1'
    # Test dictionary value
    tf1 = TF1IE({'a': 'b'})
    assert tf1.ie_key() == 'TF1'

# Generated at 2022-06-24 13:13:53.762063
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    expected_instance_type = 'TF1IE'
    assert instance._TYPE == expected_instance_type
    assert isinstance(instance, InfoExtractor)



# Generated at 2022-06-24 13:13:57.535322
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:59.539514
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _test_TF1IE = TF1IE('test_TF1IE', {'test': 'test'})
    assert _test_TF1IE is not None

# Generated at 2022-06-24 13:14:01.252608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:14:09.248558
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with known values
    assert TF1IE(url="http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html",test_mode=False)

    # Check for options with bad values
    with pytest.raises(TypeError):
        # url is null
        TF1IE(url=None,test_mode=False)
    with pytest.raises(TypeError):
        # test_mode is null
        TF1IE(url="http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html",test_mode=None)

# Generated at 2022-06-24 13:14:11.071004
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    assert 'TF1IE' is test_TF1IE.ie_key()

# Generated at 2022-06-24 13:14:12.679938
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test if the constructor of class TF1IE doesn't raise exception"""
    assert TF1IE

# Generated at 2022-06-24 13:14:20.882880
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+).html'

# Generated at 2022-06-24 13:14:22.328454
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE(TF1IE.ie_key()).result()

# Generated at 2022-06-24 13:14:25.003835
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:14:25.556937
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t != None

# Generated at 2022-06-24 13:14:26.971532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE('TF1IE', 'tf1.fr')

# Generated at 2022-06-24 13:14:28.709262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_infoextractor = TF1IE()
    assert tf1_infoextractor != None


# Generated at 2022-06-24 13:14:29.333928
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:38.798235
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:45.771151
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.IE_NAME == 'wat'
    assert ie.IE_DESC == 'Wat.tv'
    assert ie._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'
    assert ie._NETRC_MACHINE == 'wat'
    assert ie._TEMPLATE_URL == 'https://www.tf1.fr/graphql/web'

# Generated at 2022-06-24 13:14:46.879311
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from ..tf1_ie import TF1IE
    assert TF1IE('TF1IE', 'TF1IE')

# Generated at 2022-06-24 13:14:49.078347
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._VALID_URL == url

# Generated at 2022-06-24 13:14:50.602810
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == TF1IE.VALID_URL

# Generated at 2022-06-24 13:14:52.036579
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This code must not raise an exception
    TF1IE()

# Generated at 2022-06-24 13:14:52.611763
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:53.170661
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:57.230249
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE == type(
        TF1IE(
            InfoExtractor(
                downloader = None,
                params = None,
                ie_key = None,
                ie = None,
                gen_extractors = None,
                force_generic_extractor = None,
                expected_warnings = None,
                ie_info = None,
                session = None,
            )
        )
    )

# Generated at 2022-06-24 13:14:58.791555
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _TF1IE = TF1IE()
    assert _TF1IE.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:14:59.352743
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:09.415495
# Unit test for constructor of class TF1IE
def test_TF1IE():
	ie = TF1IE()
	assert ie.ie_key() == 'TF1'
	assert ie.ie_name() == 'TF1'
	assert ie.td_name() == 'TF1'
	assert ie.extract_id_from_url('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == 'replay-koh-lanta-22-mai-2015'
	assert ie.is_suitable_url('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:15:18.956743
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    #assert t.TF1IE == "TSR"
    assert t._VALID_URL == "https://www.tf1.fr/(.*)/(.*)/(.*)html", "Invalid URL"

# Generated at 2022-06-24 13:15:23.515129
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:24.496857
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t

# Generated at 2022-06-24 13:15:26.406073
# Unit test for constructor of class TF1IE
def test_TF1IE():
    o = TF1IE(None, None)
    assert_raises(AttributeError, o, None, None)

# Generated at 2022-06-24 13:15:27.406508
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:15:30.929535
# Unit test for constructor of class TF1IE
def test_TF1IE():
	base_url = "http://www.tf1.fr/tf1/"
	url = base_url + "koh-lanta/videos/"
	html_content = download_webpage(url)
	ie = TF1IE()
	assert ie is not None

# Generated at 2022-06-24 13:15:33.030007
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test just copies the constructor, which does not need a URL.
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:15:34.028799
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor should succeed URL
    TF1IE()

# Generated at 2022-06-24 13:15:42.032631
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert t.url == "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert t.program_slug == "koh-lanta"
    assert t.id == "replay-koh-lanta-22-mai-2015"

# Generated at 2022-06-24 13:15:43.722833
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('TF1IE', {})
    assert obj

# Generated at 2022-06-24 13:15:46.272665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Simply test if the class can be initialized.
    This doesn't mean it can download videos or extract information.
    """
    TF1IE()

# Generated at 2022-06-24 13:15:55.554351
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with HTTP URL
    url = "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    IE = TF1IE(url)
    assert IE._VALID_URL == '(?i)(https?://)(?:www\\.)?tf1\\.fr(?:/[^/]+/[^/]+/videos/|/)(?P<id>[^/?&#]+)\\.html'
    assert IE.url == url
    assert IE.video_id == '13641379'
    assert IE.program_slug == 'tmc/quotidien-avec-yann-barthes'

# Generated at 2022-06-24 13:15:58.476369
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'programSlug', 'slug')

# Generated at 2022-06-24 13:16:00.418669
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor())._VALID_URL is not None


# Generated at 2022-06-24 13:16:02.454427
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE().test()
    assert(test["_type"] == "url_transparent")

# Generated at 2022-06-24 13:16:03.840868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:16:14.944707
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE._VALID_URL == "r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'"
	assert TF1IE._TESTS[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
	assert TF1IE._TESTS[0]['info_dict']['id'] == "13641379"
	assert TF1IE._TESTS[0]['info_dict']['ext'] == "mp4"

# Generated at 2022-06-24 13:16:17.207345
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1_ie = TF1IE()
	assert tf1_ie.get_domain()=="www.tf1.fr"

# Generated at 2022-06-24 13:16:17.818579
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:16:23.183119
# Unit test for constructor of class TF1IE
def test_TF1IE():
    my_object = TF1IE()
    assert my_object.name == "TF1"
    assert my_object._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert my_object.IE_NAME == u"TF1"

# Generated at 2022-06-24 13:16:23.906639
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL

# Generated at 2022-06-24 13:16:24.752357
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE()

# Generated at 2022-06-24 13:16:30.279767
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create an instance of TF1IE class
    tf1 = TF1IE()
    # Check if class instance has _VALID_URL attribute
    assert hasattr(tf1, '_VALID_URL')
    # Check if class instance has _TESTS attribute
    assert hasattr(tf1, '_TESTS')
    # Test count of _TESTS
    assert len(tf1._TESTS) == 3

# Generated at 2022-06-24 13:16:39.918847
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:16:41.642792
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("tf1", "tf1")
    assert ie.ie_key() == 'tf1'

# Generated at 2022-06-24 13:16:49.173145
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1IE.IE_NAME == 'tf1'
    assert tf1IE.DEFAULT_FORMAT == 'bestvideo'

# Generated at 2022-06-24 13:16:49.811558
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:54.658533
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._real_extract(None)._real_extract(None)
# end Unit Test

if __name__ == "__main__":
    # Just for manual test
    TF1IE(None)._real_extract(None)._real_extract(None)
    # curl -H "Origin: http://www.tf1.fr" "https://www.tf1.fr/graphql/web"

# Generated at 2022-06-24 13:16:55.903751
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE != None

# Generated at 2022-06-24 13:16:56.371825
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:56.930804
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:57.619415
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:16:58.324580
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:59.378947
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("wat:xxxxxxxxxxxx")



# Generated at 2022-06-24 13:17:03.143133
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(None)
    tf1ie._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:06.213082
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    assert TF1IE()._TESTS == TF1IE._TESTS
    assert TF1IE()._real_extract is TF1IE._real_extract

# Generated at 2022-06-24 13:17:08.755929
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:17:09.629241
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst

# Generated at 2022-06-24 13:17:11.157319
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .. import TF1IE
    tf1 = TF1IE()
    assert(tf1 is not None)



# Generated at 2022-06-24 13:17:15.017042
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor
    from ..utils import (
        int_or_none,
        parse_iso8601,
        try_get,
    )
    # Test for constructor of class TF1IE
    tf1ie = TF1IE(InfoExtractor())

# Generated at 2022-06-24 13:17:19.404227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """to test if TF1IE can handle a tf1.fr url"""
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:20.319778
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:30.236583
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    _VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    program_slug, slug = re.match(_VALID_URL, url).groups()

# Generated at 2022-06-24 13:17:37.320191
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unitest for constructor of class TF1IE
    testIE = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert testIE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'
    assert testIE._downloader.params['noprogress'] == False

# Generated at 2022-06-24 13:17:41.102122
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:42.051462
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:test')

# Generated at 2022-06-24 13:17:51.644851
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:57.657649
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class constructor"""
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:17:58.250263
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:18:00.748218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class TF1IE with constructor of class InfoExtractor"""
    obj = TF1IE(InfoExtractor())
    assert obj.suitable(TF1IE._VALID_URL)



# Generated at 2022-06-24 13:18:01.765891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()


# Generated at 2022-06-24 13:18:02.844962
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:18:07.435566
# Unit test for constructor of class TF1IE
def test_TF1IE():
    my_TF1IE = TF1IE()
    assert my_TF1IE.name() == 'tf1'
    assert my_TF1IE.IE_NAME == 'wat'
    assert my_TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:18:12.770569
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:18:19.908993
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert a.program_slug == "quotidien-avec-yann-barthes"
    assert a.slug == "quotidien-premiere-partie-11-juin-2019"
# End unit test for constructor of class TF1IE


# Generated at 2022-06-24 13:18:20.565560
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()