

# Generated at 2022-06-24 13:08:34.017377
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # When
    t = TF1IE()

    # Then
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:35.598379
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.name == "TF1"
    assert TF1IE.ie_key() == "tf1"

# Generated at 2022-06-24 13:08:37.191626
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 == TF1IE('TF1', 'tf1')

# Generated at 2022-06-24 13:08:40.488586
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE.TF1IE(TF1IE, "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert ie.program_slug is None
    assert ie.slug is None

# Generated at 2022-06-24 13:08:41.332023
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-24 13:08:43.543106
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)

# Generated at 2022-06-24 13:08:53.563781
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:54.390746
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:58.455997
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:09:09.200924
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # constructor of class TF1IE
    tf1_ie = TF1IE("TF1IE")

    # check main attributes
    assert tf1_ie.ie_key() == 'TF1'
    assert tf1_ie.ie_urls[0][0] == 'tf1.fr'
    assert tf1_ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1_ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'


# Generated at 2022-06-24 13:09:12.799048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True

# Generated at 2022-06-24 13:09:19.749399
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.ie_key() == 'tf1'
    t = TF1IE()
    assert t.ie_key() == 'tf1'
    assert t.SUFFIX == 'tf1.fr'
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t.__name__ == 'TF1'

# Generated at 2022-06-24 13:09:26.845425
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:37.670652
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:09:41.239841
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('tf1.fr/wat')
    assert ie.ie_key() == 'wat'
    assert ie.ie_name() == 'tf1.fr'
    assert str(ie) == 'TF1IE(tf1.fr/wat)'

# Generated at 2022-06-24 13:09:42.926141
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE.ie_key() == 'tf1')

# Generated at 2022-06-24 13:09:44.503517
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test TF1IE constructor"""
    tf1ie = TF1IE()
    assert tf1ie != None

# Generated at 2022-06-24 13:09:45.740379
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    TF1IE._VALID_URL

# Generated at 2022-06-24 13:09:47.322547
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # The following constructor works fine !
    assert(TF1IE(TF1IE._downloader, TF1IE._VALID_URL) != None)

# Generated at 2022-06-24 13:09:55.424457
# Unit test for constructor of class TF1IE
def test_TF1IE():
    db = InfoExtractor(
        {
            "TF1": {
                'TF1': r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html',
            },
            "Nop": {},
            "Wat": {
                'Wat': r'wat:',
            },
        }
    )
    assert db.TF1IE is TF1IE
    assert db.NopIE is  None
    assert db.WatIE is None

# Generated at 2022-06-24 13:09:59.783318
# Unit test for constructor of class TF1IE
def test_TF1IE():
    arg = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE(TF1IE._downloader, arg, None)

# Unit test to check that TF1IE is not the correct IE to extract this resource

# Generated at 2022-06-24 13:10:05.372203
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert(IE.ie_key() == 'tf1')
    assert(IE.ie_name() == 'tf1')
    assert(IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:10:08.567926
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance.suitable(instance.IE_NAME, 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:10:17.577336
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE()
    assert infoExtractor.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True
    assert infoExtractor.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert infoExtractor.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == True

# Generated at 2022-06-24 13:10:19.406255
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:25.667537
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")



# Generated at 2022-06-24 13:10:33.129665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:10:40.229156
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert isinstance(IE.VALID_URL, type(IE._VALID_URL))
    assert IE.VALID_URL == IE._VALID_URL
    assert IE.IE_NAME == 'tf1'
    assert isinstance(IE.TESTS, list)
    assert isinstance(IE.BR_DESC, bool)
    # Unit test for _real_extract of class TF1IE
    IE._real_extract(
        url='https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:41.993372
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert "TF1IE" in IE.name

# Generated at 2022-06-24 13:10:46.236967
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:47.981806
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('TF1IE', 'TF1.fr')._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:10:48.820700
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.name == 'tf1'

# Generated at 2022-06-24 13:10:56.482879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t1ie = TF1IE()

    # Test of the method 
    def _extract(self, url):
        program_slug, slug = re.match(self._VALID_URL, url).groups()
        video = self._download_json(
            'https://www.tf1.fr/graphql/web', slug, query={
                'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
                'variables': json.dumps({
                    'programSlug': program_slug,
                    'slug': slug,
                })
            })['data']['videoBySlug']
        wat_id = video['streamId']

        tags = []

# Generated at 2022-06-24 13:10:57.105045
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:00.807038
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:11:03.189619
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TF1IE should be a subclass of InfoExtractor
    assert issubclass(TF1IE, InfoExtractor)

# Generated at 2022-06-24 13:11:05.353532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    r = TF1IE()
    assert isinstance(r, TF1IE)


# Generated at 2022-06-24 13:11:09.361451
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    try:
        t = TF1IE._real_extract(url)
        print(t)
    except:
        print("Exception caught!")
        return False
    return True


if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-24 13:11:15.213947
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Given
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    # When
    instance_IE = TF1IE()
    url_explicit = instance_IE._real_extract(url)
    # Then
    assert url_explicit is not None



# Generated at 2022-06-24 13:11:17.352710
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj is not None
    assert(isinstance(obj, TF1IE))

# Generated at 2022-06-24 13:11:25.454187
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1ie.__name__ == 'TF1'
    assert tf1ie.ie_key() == 'tf1'

# Generated at 2022-06-24 13:11:26.581643
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj != None

# Generated at 2022-06-24 13:11:29.265523
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == TF1IE._VALID_URL
    assert ie._TESTS == TF1IE._TESTS

# Generated at 2022-06-24 13:11:35.057961
# Unit test for constructor of class TF1IE
def test_TF1IE():

    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    obj = TF1IE()

    # TODO: test _real_extract

    assert obj.suitable(url)
    assert obj.IE_NAME == 'tf1'
    assert obj.IE_DESC == 'Tf1.fr'

# Generated at 2022-06-24 13:11:44.785913
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE_test = TF1IE()

    # Act
    res = TF1IE_test._real_extract(url)

    # Assert
    assert(res['_type'] == 'url_transparent')
    assert(res['url'] == 'wat:13641379')
    assert(res['id'] == '13641379')
    assert(res['title'] != None)
    assert(res['tags'] == ['intégrale', 'quotidien', 'Replay'])
    assert(res['series'] == 'Quotidien avec Yann Barthès')

# Generated at 2022-06-24 13:11:45.347471
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:48.315564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE({})._extract_url('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:11:53.600261
# Unit test for constructor of class TF1IE
def test_TF1IE():
    u = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1IE = TF1IE(TF1IE.suitable(u), u)
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1IE._TESTS[0]['url'] == u
    assert tf1IE._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-24 13:11:54.303045
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor_test(TF1IE)

# Generated at 2022-06-24 13:11:55.717455
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.IE_NAME == 'TF1'

# Generated at 2022-06-24 13:12:04.299152
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE
    obj = TF1IE(std_headers={}, _fetch_url={})
    assert obj.execute()
    assert obj.to_screen()
    assert obj.to_json()
    assert obj.to_xml()
    assert obj.to_string()
    assert obj.to_array()
    assert obj.to_df()
    assert obj.to_geojson()
    assert obj.to_html()
    assert obj.to_image()
    assert obj.to_markdown()
    assert obj.to_pandas()
    assert obj.to_table()
    assert obj.to_tabulate()
    assert obj.to_yaml()

# Generated at 2022-06-24 13:12:06.146245
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert a == 'TF1IE'

# Generated at 2022-06-24 13:12:09.027796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert test._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:14.270921
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t = TF1IE(url)

    assert(t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:12:19.536905
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    ie.extract("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-24 13:12:21.363318
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        assert False, 'TF1IE class constructor does not work'

# Generated at 2022-06-24 13:12:27.624262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', '')

# Generated at 2022-06-24 13:12:29.357701
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        pass

# Generated at 2022-06-24 13:12:36.874279
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Basic tests to ensure that the constructor works
    # These are not exhaustive
    # Constructor has one required argument and one optional
    instance = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    instance_with_downloader = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', downloader=None)

# Generated at 2022-06-24 13:12:37.502491
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = TF1IE()


# Generated at 2022-06-24 13:12:43.360418
# Unit test for constructor of class TF1IE
def test_TF1IE():
    importer = TF1IE(None)
    assert importer._VALID_URL == "https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html"
    assert importer.__name__ == "TF1IE"
    assert importer.IE_DESC == "TF1"
    assert importer.__doc__ == "TF1IE(InfoExtractor) support for TF1"
    assert importer.EXTENSIONS == ['mp4']
    assert importer.IE_NAME == "tf1"

# Generated at 2022-06-24 13:12:44.630133
# Unit test for constructor of class TF1IE
def test_TF1IE():
    my_TF1IE = TF1IE()
    assert my_TF1IE

# Generated at 2022-06-24 13:12:45.579014
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE("wat:80655868"))

# Generated at 2022-06-24 13:12:46.799512
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check if Wat can be instanciated
    TF1IE()

# Generated at 2022-06-24 13:12:57.045345
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:04.996395
# Unit test for constructor of class TF1IE
def test_TF1IE():
    def _test(url, video_id, program_slug, slug):
        m = re.match(TF1IE._VALID_URL, url)
        assert m.group('id') == video_id
        assert m.group('program_slug') == program_slug
        assert m.group('slug') == slug

    _test('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
          'replay-koh-lanta-22-mai-2015', 'koh-lanta', 'replay-koh-lanta-22-mai-2015')

# Generated at 2022-06-24 13:13:14.931788
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test with URL http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html
    # Should return Koh-Lanta
    test_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ydl = YoutubeDL({})
    t = TF1IE(ydl)
    t.extract(test_url)
    assert t.title == 'Koh-Lanta'

    # Test with URL http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html
    # Should return Mylène Farmer, d'une icône à une femme


# Generated at 2022-06-24 13:13:17.099137
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor test
    """
    info_extractor = TF1IE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:18.390275
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:13:19.451913
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract(TF1IE._TESTS)

# Generated at 2022-06-24 13:13:24.379993
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:32.934989
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:13:33.503571
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:13:34.938218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE({})
    assert tf1.tf1

# Generated at 2022-06-24 13:13:38.891993
# Unit test for constructor of class TF1IE
def test_TF1IE():
    URL = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert isinstance(TF1IE(TF1IE._downloader).extract(URL), TF1IE)

# Generated at 2022-06-24 13:13:40.595943
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        assert False, e
    assert True

# Generated at 2022-06-24 13:13:51.712703
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Basic test for TF1IE module
    """
    # Test unit constructor
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1._NETRC_MACHINE == 'tf1'
    assert tf1.BROKEN_URL == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1.RETURN_PAGE_NOT_FOUND == True

# Generated at 2022-06-24 13:13:53.616003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t1 = TF1IE()
    print("Unit Test says : %s" % t1._VALID_URL)

# Generated at 2022-06-24 13:14:02.318317
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.tf1_lang == 'fr'
    assert ie.tf1_site == 'www.tf1.fr'
    assert ie.tf1_auth_url == 'https://oauth-public.api.tf1.fr/v1/auth'
    assert ie.tf1_auth_header == 'X-API-Auth'
    assert ie.tf1_auth_token == 'F0a61b88-d3b7-4d83-b112-0b4c4a0f4d84'
    assert ie.tf1_auth_headerData == 'Bearer F0a61b88-d3b7-4d83-b112-0b4c4a0f4d84'

# Generated at 2022-06-24 13:14:06.560873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    unit_test = TF1IE()
    # Check the instance of class
    assert isinstance(unit_test, InfoExtractor)
    # Check URL
    assert url == unit_test._VALID_URL

# Generated at 2022-06-24 13:14:08.618538
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("")
    assert_equal(ie.ie_key(), 'TF1')

# Generated at 2022-06-24 13:14:10.033737
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    tf1_ie = TF1IE();

# Generated at 2022-06-24 13:14:11.452988
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:14:12.588973
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE(InfoExtractor())

# Generated at 2022-06-24 13:14:17.890227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE
    # Valid URL
    assert class_._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # Instance of InfoExtractor
    assert issubclass(TF1IE, InfoExtractor)

# Generated at 2022-06-24 13:14:24.578534
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This test is not supposed to be executed,
    # only to check if TF1IE object is created properly
    # There is an error in the constructor _real_extract (line 52)
    # that is why the url and the video_id are None
    ie = TF1IE(None, None)
    assert(ie.title == "TF1")
    assert(ie.description == "TF1 Télévision en ligne")
    assert(ie.IE_NAME == "tf1")

# Generated at 2022-06-24 13:14:30.983176
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:40.251051
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:41.892993
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'Tf1.fr'

# Generated at 2022-06-24 13:14:42.864978
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:14:43.421407
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:49.506745
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    url_without_http = url[5:]
    url_without_www = url[11:]
    url_without_https = url[8:]
    url_without_www_or_https = url[19:]
    url_without_tf1 = url[23:]
    ie = TF1IE(url = url)
    ie = TF1IE(url = url_without_www)
    ie = TF1IE(url = url_without_https)
    ie = TF1IE(url = url_without_www_or_https)
    ie = TF1IE(url = url_without_tf1)


# Generated at 2022-06-24 13:14:53.124741
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('https://www.tf1.fr/fr/programme/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert type(instance).__name__ == 'TF1IE'

# Generated at 2022-06-24 13:14:56.934886
# Unit test for constructor of class TF1IE
def test_TF1IE():
    wat_id = '13641379'
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    IF1IE()._real_extract('wat:' + wat_id)

# Generated at 2022-06-24 13:14:57.806327
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()


# Generated at 2022-06-24 13:14:58.705643
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie

# Generated at 2022-06-24 13:15:07.666048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not ie.suitable('http://www.tf1.fr/')

# Generated at 2022-06-24 13:15:08.290640
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:15:10.214615
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor of class TF1IE is allowed to take None for all of its arguments.
    TF1IE(None, None, None, None)

# Generated at 2022-06-24 13:15:11.045418
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None

# Generated at 2022-06-24 13:15:12.280691
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    assert(test_TF1IE.name == "TF1")

# Generated at 2022-06-24 13:15:12.941155
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:15:14.709883
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE("www.tf1.fr");
    assert(tf1IE.name() == 'TF1');

# Generated at 2022-06-24 13:15:16.225920
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE("TF1IE")
    assert test_obj.ie_key() == 'TF1'

# Generated at 2022-06-24 13:15:22.909064
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1'
    assert tf1.ie_name() == 'TF1'
    assert tf1.ie_url() == 'wat'
    assert tf1.search_key() == 'tf1'
    assert tf1.search_name() == 'tf1'
    assert tf1.search_url() == 'https://www.tf1.fr/recherche.html'

# Generated at 2022-06-24 13:15:24.496499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    my_TF1IE = TF1IE()
    assert(my_TF1IE)

# Generated at 2022-06-24 13:15:26.768716
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test the constructor TF1IE and its _VALID_URL class attribute
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:27.716290
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    print(instance)

# Generated at 2022-06-24 13:15:28.763138
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1 = TF1IE()

# Generated at 2022-06-24 13:15:32.313030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor = TF1IE().__class__
    assert constructor.__name__ == TF1IE.__name__
    assert len(constructor.__bases__) == len(TF1IE.__bases__)
    assert list(constructor.__bases__) == list(TF1IE.__bases__)

# Generated at 2022-06-24 13:15:35.777464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test constructor of TF1IE class
    """
    test_instance = TF1IE(self)
    assert_equal(test_instance.ie_key(), 'TF1')

# Generated at 2022-06-24 13:15:37.602580
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE"""
    TF1IE()

# Generated at 2022-06-24 13:15:39.304909
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE(None)
    assert test_obj

# Generated at 2022-06-24 13:15:50.217082
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == "https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html"

# Generated at 2022-06-24 13:15:57.975257
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert(ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+)\.html')

# Generated at 2022-06-24 13:15:59.383534
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This test is expected to succeed with no exception thrown.
    TF1IE()

# Generated at 2022-06-24 13:16:10.512490
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:16:12.812814
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class TF1IE."""
    # Write a random test case for the class TF1IE
    for i in range(10):
        print(i)

# Generated at 2022-06-24 13:16:13.421176
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:23.630581
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .wat import WatIE
    from ..compat import compat_str
    from ..utils import extract_attributes

    # Test building of a WatIE
    tf1_ie = TF1IE('https://www.tf1.fr/videos/tf1s-en-direct.html')
    assert isinstance(tf1_ie, TF1IE)
    assert type(tf1_ie) is TF1IE

    # Test building of a WatIE
    wat_ie = TF1IE('wat:123456789')
    assert isinstance(tf1_ie, TF1IE)
    assert type(wat_ie) is WatIE

    # Test building of a TF1IE

# Generated at 2022-06-24 13:16:28.387847
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TF1IE constructor tests
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:16:29.026634
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:36.575122
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:16:38.267757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE(tf1_tests.Tf1TestCase)
    return extractor.targets

# Generated at 2022-06-24 13:16:48.897207
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.IE_NAME == 'tf1'
    assert TF1IE.IE_DESC == 'tf1.fr and lci.fr'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:50.263263
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert type(t) == TF1IE

# Generated at 2022-06-24 13:16:51.879346
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(TF1IE.ie_key()).ie_key() == 'TF1'


# Generated at 2022-06-24 13:17:01.389272
# Unit test for constructor of class TF1IE
def test_TF1IE():
    def test_with(url):
        ie = TF1IE()
        result = ie.match(url)
        assert result is not None

    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    test_with(url)
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    test_with(url)
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    test_with(url)

# Generated at 2022-06-24 13:17:02.638316
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check that the constructor of class TF1IE doesn't fail
    ie = TF1IE()

# Generated at 2022-06-24 13:17:03.516921
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    return tf1

# Generated at 2022-06-24 13:17:05.241816
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    print(tf1IE.__class__.__name__)

# Generated at 2022-06-24 13:17:08.011989
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test1 = TF1IE()
    assert test1._VALID_URL==r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert test1._TESTS[1]['url']=='http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-24 13:17:10.085008
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.download('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:17:11.889027
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE("tf1")
    assert info_extractor.IE_NAME == "tf1"
    assert info_extractor.IE_DESC == "tf1"

# Generated at 2022-06-24 13:17:12.789951
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    return IE

# Generated at 2022-06-24 13:17:13.345708
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:21.941874
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    obj_tf1 = tf1_ie
    obj_tf1._VALID_URL = 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    obj_tf1._TESTS = [{'url': 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', 'only_matching': True}]

# Generated at 2022-06-24 13:17:22.865401
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == 'tf1'

# Generated at 2022-06-24 13:17:32.057475
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.ie_key() == 'tf1'
    assert i.ie_name() == 'tf1'
    assert i.ie_version() == '0.0.1'
    assert i.get_host_and_id(i.VALID_URL) is not None
    assert i.get_host_and_id(i.VALID_URL)[0] == 'www.tf1.fr'
    assert i.get_host_and_id(i.VALID_URL)[1] == 'koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert i.is_suitable(i.VALID_URL) == True
    assert i.get_info(i.VALID_URL) is not None

# Generated at 2022-06-24 13:17:33.178781
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:17:34.061790
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()

# Generated at 2022-06-24 13:17:37.959955
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test method constructor TF1IE"""
    assert type(TF1IE) == type
    t = TF1IE()
    assert type(t) == TF1IE
    # Test the __radd__ method
    assert type(0 + t) == TF1IE


# Generated at 2022-06-24 13:17:38.965456
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:17:42.100258
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(TMPlayerIE(), 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:51.674076
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.IE_NAME == 'tf1'
    assert IE.IE_DESC == 'TF1'
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:02.128121
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    #assert t.avail_formats == {
    #    'high': 'hd',
    #
    assert t.needs_subtitle() == [{
        'lang': 'fr',
        'link': 'https://www.tf1.fr/graphql/subtitle',
        'query': {
            'id': '7a85c1faa53c79fde8c69ef9f982a274a4892f10fc8f812a750c78f18d6e7c87',
            'variables': json.dumps({
                'mediaId': 'WAT_ID',
            })
        }
    }]

    assert t.ie_key() == 'TF1'


# Generated at 2022-06-24 13:18:02.900183
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass
# end of test for constructor of class TF1IE


# Generated at 2022-06-24 13:18:03.934468
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert isinstance(tf1_ie, TF1IE)


# Generated at 2022-06-24 13:18:09.112196
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor of class TF1IE
    tmc_slug = 'quotidien-avec-yann-barthes'
    tmc_id = '13641379'

    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

    # Test constructor of class TF1IE

# Generated at 2022-06-24 13:18:10.109882
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:18:21.058469
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:22.950862
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor != None
    assert info_extractor.suitable(None) == False