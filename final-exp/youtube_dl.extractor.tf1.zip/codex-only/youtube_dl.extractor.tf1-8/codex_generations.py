

# Generated at 2022-06-24 13:08:27.489628
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == 'TF1'
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:31.998139
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:08:36.098666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test constructor of class TF1IE
    """
    tf1ie = TF1IE()

    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:39.154013
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:08:45.686562
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t1 = TF1IE(InfoExtractor)
    t1._download_webpage = lambda *args, **kwargs: ''
    t1._search_regex = lambda *args, **kwargs: 'program_slug'
    t1._download_json = lambda *args, **kwargs: {'data': {'videoBySlug': {'streamId': 'wat:id'}}}

# Generated at 2022-06-24 13:08:49.416336
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.ie_id() == 'TF1'
    assert ie.SUCCESS == True
    assert ie.SUCCESS == True
    assert ie.content_id() == 'TF1'

# Generated at 2022-06-24 13:08:58.494364
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Testing for url 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # Should return the following
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:09:00.993544
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('TF1', True)
    assert tf1.name == 'TF1'
    assert tf1.report_download_webpage == True

# Generated at 2022-06-24 13:09:03.576498
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_id = '12345'
    url = 'wat:' + video_id
    TF1IE().suitable(url)

# Generated at 2022-06-24 13:09:08.892766
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    info_extractor.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    info_extractor.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:09:19.628417
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Run test for TF1IE class
    """
    # Check if we can test TF1IE instance
    assert TF1IE.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"), "Class TF1IE should be able to be instantiated"
    # Instantiate TF1IE class
    test_TF1IE = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    # Check if instance can be used

# Generated at 2022-06-24 13:09:22.681558
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test is to confirm that TF1IE is an instance of the class InfoExtractor
    # See https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/YoutubeDL.py#L1402
    assert isinstance(TF1IE(), InfoExtractor)

# Generated at 2022-06-24 13:09:28.319436
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # When TF1IE constructor is called, it initiates a request to a certain url
    instance_TF1IE = TF1IE()
    # assert the request-response data to be the expected value
    assert instance_TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert instance_TF1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert instance_TF1IE._TESTS[0]['info_dict']['id']

# Generated at 2022-06-24 13:09:38.747943
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:40.732691
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        from . import test_TF1IE
        return test_TF1IE
    except ImportError:
        pass
    return TF1IE

# Generated at 2022-06-24 13:09:44.125524
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html').extract()

# Generated at 2022-06-24 13:09:52.003201
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test the constructor of class TF1IE
    ie = TF1IE()
    assert ie.sub_domain == 'www'
    assert ie.ie_key == 'TF1'

# Generated at 2022-06-24 13:09:52.939517
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:10:01.341018
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.url = "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    ie.program_slug = "documentaire"
    ie.slug = "mylene-farmer-d-une-icone"
    assert ie.url == "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    assert ie.program_slug == "documentaire"
    assert ie.slug == "mylene-farmer-d-une-icone"

# Function to test class TF1IE

# Generated at 2022-06-24 13:10:02.787171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:10:09.383494
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test the TF1IE constructor"""

    # Given the following arguments:
    args = ['self']

    # Create an instance of TF1IE and assert the values of its
    # attributes
    instance = TF1IE(*args)
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:09.999271
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-24 13:10:19.915352
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE = TF1IE()
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:20.719108
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:10:29.507710
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Run all unit test for the TF1IE
    """
    from . import _parse_json
    from .common import InfoExtractor
    from .wat import WatIE

    ie = TF1IE()
    ie.extract(ie._TESTS[0])
    test_module_name = ie._TESTS[0]['url'][ie._TESTS[0]['url'][:50].rfind('/') + 1:ie._TESTS[0]['url'].rfind('.')]
    print(test_module_name + " : OK")
    

# Generated at 2022-06-24 13:10:33.041887
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """

    url = 'https://google.com'
    # only_matching = False
    # expected = True
    TF1IE(url)
    # assert expected == actual


# Generated at 2022-06-24 13:10:35.510757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-24 13:10:39.243753
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == '(?i)(https?://)(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)(.html)'

# Generated at 2022-06-24 13:10:46.189271
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1IE = TF1IE(url)
    assert tf1IE.url == url
    assert tf1IE.program_slug == 'koh-lanta'
    assert tf1IE.slug == 'replay-koh-lanta-22-mai-2015'


# Generated at 2022-06-24 13:10:54.916585
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert not ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/')
    assert not ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos')
    assert not ie.suitable('https://www.tf1.fr')
    assert not ie.suitable('')
    assert not ie.suitable('kkk')
    assert not ie.su

# Generated at 2022-06-24 13:10:55.890300
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:59.028517
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test the constructor of class TF1IE
    """
    t = TF1IE()
    t.to_screen(["This is the test of class TF1IE that just instantiated it without parameters."])

# Generated at 2022-06-24 13:10:59.642325
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:09.545539
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(object(), 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert obj._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'
    assert obj._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert obj._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-24 13:11:19.525325
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('videos/quotidien-premiere-partie-11-juin-2019.html')._download_webpage(
    'https://www.tf1.fr/graphql/web', 'quotidien-premiere-partie-11-juin-2019', query={
        'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
        'variables': json.dumps({
            'programSlug': 'quotidien-avec-yann-barthes',
            'slug': 'quotidien-premiere-partie-11-juin-2019',
        })
    })

# Generated at 2022-06-24 13:11:20.866907
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert ie is not None

# Generated at 2022-06-24 13:11:21.674686
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:26.246400
# Unit test for constructor of class TF1IE
def test_TF1IE():
    creator = TF1IE(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert creator

# Generated at 2022-06-24 13:11:29.010151
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:11:35.684400
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:11:45.429449
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:11:46.717048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        print(e)
        return False
    return True


# Generated at 2022-06-24 13:11:47.280978
# Unit test for constructor of class TF1IE
def test_TF1IE():
	pass

# Generated at 2022-06-24 13:11:48.580253
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except NameError:
        assert False
    else:
        assert True

# Generated at 2022-06-24 13:11:49.171942
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test creation of instance
    TF1IE()

# Generated at 2022-06-24 13:11:50.514867
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance.ie_key() == 'tf1'

# Generated at 2022-06-24 13:11:57.082869
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_urls = [
        ('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', '13641379'),
        ('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', '15072469'),
        ('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', '15072469'),
    ]
    for test_url, expected_id in test_urls:
        assert TF1IE()._match_id(test_url) == expected_id

# Generated at 2022-06-24 13:11:58.971784
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.TF1IE is TF1IE

# Generated at 2022-06-24 13:12:00.942479
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url= 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE()
    ie.extract(url)

# Generated at 2022-06-24 13:12:01.716938
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor

# Generated at 2022-06-24 13:12:09.579386
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert instance._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert instance._TESTS[0]['info_dict']['id'] == '13641379'
    assert instance._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:12:11.539968
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidian-premiere-partie-du-12-juin-2019.html")

# Generated at 2022-06-24 13:12:12.305858
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie is not None)

# Generated at 2022-06-24 13:12:14.534596
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(None, None)
    assert isinstance(tf1, TF1IE)


# Generated at 2022-06-24 13:12:17.813453
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('tf1', 'youtube', 'tf1', 'tf1')
    TF1IE('tf1', 'youtube', 'tf1')
    TF1IE('tf1', 'youtube')

# Generated at 2022-06-24 13:12:18.430673
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE

# Generated at 2022-06-24 13:12:21.174126
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = InfoExtractor()
    test = TF1IE(test)
    assert test.__class__.__name__ == 'TF1IE'



# Generated at 2022-06-24 13:12:24.732778
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE('TF1IE', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:12:25.172750
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:12:30.714715
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    IE = TF1IE()
    assert IE.get_url_data(url)
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:32.246642
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE();
    assert tf1_ie.get_id() == 'tf1';

# Generated at 2022-06-24 13:12:40.974356
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._TESTS[1]['url'] == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-24 13:12:42.477437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == TF1IE._TESTS[0]['url']

# Generated at 2022-06-24 13:12:46.079005
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:12:54.754359
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE()._real_extract(url)
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE()._real_extract(url)
    url = "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    TF1IE()._real_extract(url)

# Generated at 2022-06-24 13:12:57.217706
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:12:57.824940
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:12:59.479061
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE(None)
    assert isinstance(instance , TF1IE)
    

# Generated at 2022-06-24 13:13:01.864407
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
        print("Construtor of class TF1IE is ok")
    except:
        print("Error on constructor of class TF1IE")

test_TF1IE()

# Generated at 2022-06-24 13:13:07.981184
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # When no url is given
    try:
        TF1IE()
    except TypeError as e:
        assert "__init__() missing 1 required positional argument: 'url'" in str(e)

    # When an unsupported url is given
    try:
        TF1IE("https://www.google.com/")
    except ValueError as e:
        assert "tf1.fr" in str(e)

    # When a supported url is given
    tmc = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:13:10.913290
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie is not None
    assert type(tf1_ie) == TF1IE


# Generated at 2022-06-24 13:13:16.119446
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()
    if a.playlist_result(a.url_result('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')) is None:
        raise Exception('Constructor of class TF1IE does not work')
    return False

# Generated at 2022-06-24 13:13:23.100711
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tF1IE = TF1IE()
    assert re.fullmatch(tF1IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tF1IE.IE_NAME == 'tf1'
    assert tF1IE.IE_DESC == 'TF1, TMC, TFX, TF1 Séries Films, LCI'

# Generated at 2022-06-24 13:13:32.192785
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ test constructor of class TF1IE """
    # Check if it raises a ValueError when url not valid
    url_invalid = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015'
    invalid = re.match(TF1IE._VALID_URL, url_invalid)
    try:
        assert invalid is None
    except AssertionError:
        raise ValueError('Url not valid')
    # Check if it raise no error when url valid
    url_valid = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    valid = re.match(TF1IE._VALID_URL, url_valid)

# Generated at 2022-06-24 13:13:32.736928
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:33.284595
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:34.103484
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:13:38.757321
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:13:42.257755
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:47.122283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = {
        'id': '13641379',
        'ext': 'mp4',
        'title': 'md5:f392bc52245dc5ad43771650c96fb620',
        'description': 'md5:a02cdb217141fb2d469d6216339b052f',
        'upload_date': '20190611',
        'timestamp': 1560273989,
        'duration': 1738,
        'series': 'Quotidien avec Yann Barthès',
        'tags': ['intégrale', 'quotidien', 'Replay'],
    }
    assert TF1IE(video)

# Generated at 2022-06-24 13:13:56.435918
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

    assert x.name == "tf1"
    assert x.suitable("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert not x.suitable("https://tf1.fr/")

    assert x.VALID_URL == "https://www\\.tf1\\.fr/[^/]+/[^/]+/videos/[^/?&#]+\\.html"

# Generated at 2022-06-24 13:13:58.191821
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', '13641379')

# Generated at 2022-06-24 13:13:58.708462
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:13:59.080861
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:02.386053
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:04.908395
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html") is not None


# Generated at 2022-06-24 13:14:05.849443
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor_test(TF1IE)

# Generated at 2022-06-24 13:14:16.593232
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:27.624204
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor of TF1IE (type TF1IE)
    TF1IE_instance = TF1IE("test")
    assert type(TF1IE_instance) == TF1IE, "%r is not an instance of TF1IE()" % type(TF1IE_instance)
    assert TF1IE_instance.ie_key() == 'TF1', "%r is not an instance of TF1IE()" % type(TF1IE_instance)
    assert TF1IE_instance.ie_key() == 'TF1', "%r is not an instance of TF1IE()" % type(TF1IE_instance)
    assert TF1IE_instance.ie_key() == 'TF1', "%r is not an instance of TF1IE()" % type(TF1IE_instance)

# Generated at 2022-06-24 13:14:37.316325
# Unit test for constructor of class TF1IE
def test_TF1IE():
    full_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[0]['url'] == full_url
    assert TF1IE._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-24 13:14:42.276393
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Unit test for constructor of class TF1IE")
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE_test = TF1IE()
    TF1IE_test.extract(url)



# Generated at 2022-06-24 13:14:49.741955
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE()._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:14:51.547685
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    TF1IE()



# Generated at 2022-06-24 13:14:53.166476
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE()
    assert test_obj.__class__.__name__ == "TF1IE"

# Generated at 2022-06-24 13:14:55.280360
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.ie_key() == 'tf1'
    assert t.ie_key() in InfoExtractor._AVAILABLE_IE

# Generated at 2022-06-24 13:15:01.438172
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_parse_url = lambda url : TF1IE()._match_id(url)
    assert(tf1_parse_url(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    )) == (
        'quotidien-avec-yann-barthes',
        'quotidien-premiere-partie-11-juin-2019'
    )

# Generated at 2022-06-24 13:15:04.352985
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test instance of TF1IE
    assert TF1IE(url='', extractor=None) is not None
    # No need to test with Real videos
test_TF1IE()

# Generated at 2022-06-24 13:15:06.503347
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import json
    import unittest
    assert TF1IE
    # Unit tests are weak
    assert unittest.TestCase
    assert json

# Generated at 2022-06-24 13:15:15.117706
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test variable _VALID_URL
    match = re.match(TF1IE._VALID_URL, 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert match.group('program_slug') == 'quotidien-avec-yann-barthes'
    assert match.group('id') == 'quotidien-premiere-partie-11-juin-2019'
    assert match.groups() == ('quotidien-avec-yann-barthes', 'quotidien-premiere-partie-11-juin-2019')

    # Test variable _TESTS
    assert TF1IE._TESTS[2]['url']

# Generated at 2022-06-24 13:15:18.273262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert_true(isinstance(ie, TF1IE))
    assert_equal(ie.ie_key(), 'wat')
    assert_equal(ie.IE_NAME, 'tf1')

# Generated at 2022-06-24 13:15:19.510570
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()


# Generated at 2022-06-24 13:15:30.271287
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:15:30.822684
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()

# Generated at 2022-06-24 13:15:34.348468
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._real_extract(
        "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:15:36.701478
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE({}, {})
    assert tf1_ie
    assert isinstance(tf1_ie, InfoExtractor)

# Generated at 2022-06-24 13:15:39.929983
# Unit test for constructor of class TF1IE
def test_TF1IE():    
    tf1ie = TF1IE()
    assert(tf1ie._VALID_URL is not None)
    assert(tf1ie._TESTS is not None)

# Generated at 2022-06-24 13:15:51.158647
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:15:53.463114
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Basic unit test of class TF1IE
    """
    # Just test if we can create a new object
    TF1IE('www.tf1.fr')

# Generated at 2022-06-24 13:15:54.818156
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VERSION == '1.0.0'

# Generated at 2022-06-24 13:15:56.072853
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE();
    assert tf1IE is not None

# Generated at 2022-06-24 13:15:57.647992
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE("1", "2")
    assert x != None

# Generated at 2022-06-24 13:16:01.061422
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_instance = TF1IE()
    assert test_instance.ie_key() == 'TF1'
    assert test_instance.ie_key() == TF1IE.ie_key()
    assert test_instance.SUITABLE_U

# Generated at 2022-06-24 13:16:09.738770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst.suitable('wat:9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f')
    assert inst.suitable(
        'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert not inst.suitable('https://wat.tv/get/android/9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f')

# Generated at 2022-06-24 13:16:13.033069
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create a TF1IE instance
    tf1IE_instance = TF1IE()
    assert tf1IE_instance
    # Assert constructor of class TF1IE
    assert tf1IE_instance._VALID_URL

# Generated at 2022-06-24 13:16:14.370611
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.test()

# Generated at 2022-06-24 13:16:17.768243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE(url)

# Generated at 2022-06-24 13:16:22.809321
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """tests constructor of TF1IE"""
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    result = TF1IE()
    result.suitable(url)
    result.extract(url)

# Generated at 2022-06-24 13:16:23.446101
# Unit test for constructor of class TF1IE
def test_TF1IE():
		x = TF1IE()

# Generated at 2022-06-24 13:16:26.506195
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        t = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    except:
        return False
    return True

# Generated at 2022-06-24 13:16:32.469540
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is not None
    assert re.match(TF1IE._VALID_URL, 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') is not None

# Generated at 2022-06-24 13:16:33.574481
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj

# Generated at 2022-06-24 13:16:35.146854
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE(None)
    assert t.get_supported_ext

# Generated at 2022-06-24 13:16:41.685005
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Given a TF1 website
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # When instanciate a TF1IE object
    obj = TF1IE(url)
    # Then the expected values are retrieved
    assert obj._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # And the object is correctly initialized
    assert obj.SUCCESS == 'SUCCESS'

# Generated at 2022-06-24 13:16:44.022341
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == '1fichier'

# Generated at 2022-06-24 13:16:47.918853
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor for class TF1IE should not accept invalid URLs
    """
    tf1IE = TF1IE()

    # WHen the URL is not valid
    invalid_url = "http://wwww.invalid.com/tf1/jt/videos/invalid.html"
    assert(tf1IE._VALID_URL_RE.match(invalid_url) == None)

    # When the URL is valid
    valid_url = "http://www.tf1.fr/0000/jt/videos/test.html"
    assert(tf1IE._VALID_URL_RE.match(valid_url) != None)



# Generated at 2022-06-24 13:16:48.543048
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    # assert class exists
    TF1IE()

# Generated at 2022-06-24 13:16:49.241143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_class = TF1IE()
    assert test_class



# Generated at 2022-06-24 13:16:49.857873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:57.686967
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test if class TF1IE works"""
    tf1 = TF1IE()
    assert tf1._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"
    assert tf1._TESTS[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert tf1._TESTS[2]['url'] == "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"

# Generated at 2022-06-24 13:17:03.809728
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html", "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html", {}, {}, {'use_cipher_signature': False})

# Generated at 2022-06-24 13:17:07.220701
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE()
    ie.extract(url)

# Generated at 2022-06-24 13:17:08.592074
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html').test()

# Generated at 2022-06-24 13:17:15.057798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from youtube_dl.downloader.http import YoutubeDLHttpError
    from youtube_dl.extractor.tf1 import TF1IE

# Generated at 2022-06-24 13:17:16.184532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:17:18.192314
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:17:19.141273
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    IE.working = True

# Generated at 2022-06-24 13:17:22.335472
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html") is not None

# Generated at 2022-06-24 13:17:24.073624
# Unit test for constructor of class TF1IE
def test_TF1IE():
    index = InfoExtractor('TF1IE', TF1IE)
    print(index)


# Generated at 2022-06-24 13:17:32.770191
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test for case with multiple matches
    from .tf1 import TF1IE
    from .common import InfoExtractor
    from ..utils import (
        int_or_none,
        parse_iso8601,
        try_get,
    )
    assert TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:17:40.248164
# Unit test for constructor of class TF1IE
def test_TF1IE():
    new_ie = TF1IE()
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    (program_slug, slug) = re.match(new_ie._VALID_URL, test_url).groups()
    assert (program_slug == 'quotidien-avec-yann-barthes')
    assert (slug == 'quotidien-premiere-partie-11-juin-2019')

# Generated at 2022-06-24 13:17:43.473673
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:46.357035
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Constructor test of class TF1IE"""

    # Instanciating
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1'

# Generated at 2022-06-24 13:17:48.647058
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:17:51.534267
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE({})
    assert tf1_ie.ie_key() == 'TF1'
    assert tf1_ie.ie_name() == 'TF1'
    assert tf1_ie.SITE_NAME == 'tf1.fr'



# Generated at 2022-06-24 13:17:53.284089
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Tests of constructor of class TF1IE
    obj = TF1IE()
    assert obj is not None

# Generated at 2022-06-24 13:17:57.033456
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    content = test.url_result("wat:13641379")
    assert content['id'] == "wat:13641379"

# Generated at 2022-06-24 13:17:58.328419
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for constructor
    constructor_test(InfoExtractor, [TF1IE])

# Generated at 2022-06-24 13:17:59.318296
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

# Generated at 2022-06-24 13:18:00.395528
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.ie_key() == 'TF1'

# Generated at 2022-06-24 13:18:08.318282
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:12.127248
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE(url)

# Generated at 2022-06-24 13:18:14.241297
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        assert False, "Exception raised: {}".format(e)

# Generated at 2022-06-24 13:18:15.540347
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t

# Generated at 2022-06-24 13:18:22.950879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # create url
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    # create TF1IE object
    tf1 = TF1IE()
    tf1._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    print('TF1IE object created')