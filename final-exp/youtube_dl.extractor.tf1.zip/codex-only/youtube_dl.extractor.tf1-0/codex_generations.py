

# Generated at 2022-06-24 13:08:24.223178
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
# eof

# Generated at 2022-06-24 13:08:25.686662
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("")

# Generated at 2022-06-24 13:08:26.620898
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:08:27.159797
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:08:37.288001
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE({})
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1IE._TESTS[0]['info_dict']['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'

# Generated at 2022-06-24 13:08:41.532030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.pattern == ie.ie_key() + ':%s'
    assert ie.name == 'Télévision française 1'
    assert ie.description == 'TF1 is a privately owned television channel in France, the first to have been created in the country (as La Première Chaîne de l\'État).'
    assert ie.valid_url('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')[0] == True

# Generated at 2022-06-24 13:08:46.809854
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:08:52.573174
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    # Check if the object is an instance of TF1IE
    assert isinstance(tf1_ie, TF1IE)
    # Check for the value of expected attribute
    assert tf1_ie._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-24 13:08:57.174553
# Unit test for constructor of class TF1IE
def test_TF1IE():
    res = TF1IE()._real_extract(r"https://www.tf1.fr/the-voice/saison-8/videos/the-voice-2020-la-plus-belle-voix-le-best-of-du-9-fevrier-2019.html")
    assert(res["title"] == "The Voice 2020 - La plus belle voix Le Best of du 9 février 2019")

# Generated at 2022-06-24 13:08:58.302547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Smoke test the constructor of TF1IE
    TF1IE()

# Generated at 2022-06-24 13:09:00.953807
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Should not raise exception
    try:
        TF1IE()
    except Exception as e:
        raise Exception("Error in test_TF1IE: {}".format(e))

# Generated at 2022-06-24 13:09:01.912493
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE()._TESTS)

# Generated at 2022-06-24 13:09:03.259272
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE(None)

# Generated at 2022-06-24 13:09:07.333308
# Unit test for constructor of class TF1IE
def test_TF1IE():
    InfoExtractor._download_json = lambda x, y, z: {'data': {'videoBySlug': {}}}  # hack
    tf1_ie = TF1IE("")
    assert tf1_ie.ie_key() == 'wat', tf1_ie.ie_key()

# Generated at 2022-06-24 13:09:08.755061
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf = TF1IE()
    assert tf is not None

# Generated at 2022-06-24 13:09:10.061464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor of TF1IE raises no exception
    TF1IE()

# Generated at 2022-06-24 13:09:11.980524
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('url')


if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:09:14.367273
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor

    tfi = InfoExtractor("TF1")
    assert tfi.IE_NAME == "tf1"

# Generated at 2022-06-24 13:09:17.163976
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor.__class__.__name__ == 'TF1IE'


# Generated at 2022-06-24 13:09:20.259284
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(None)
    tf1.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:09:27.278113
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:28.361813
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:29.830784
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test to see if TF1IE constructor works properly"""
    TF1IE()

# Generated at 2022-06-24 13:09:39.933199
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:09:40.818690
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:09:41.639661
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TODO
    return TF1IE('test')

# Generated at 2022-06-24 13:09:50.302883
# Unit test for constructor of class TF1IE
def test_TF1IE():
    network = 'tf1'

    # Tests for private method _real_extract
    assert 'tf1.fr' in TF1IE._real_download('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', None)
    assert 'tf1.fr' in TF1IE._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

    # Tests for public method suitable
    assert TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not TF1IE.su

# Generated at 2022-06-24 13:09:51.273417
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(backend='optional')

# Generated at 2022-06-24 13:09:58.922578
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', {})
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._downloader._download_json == ie._download_json


# Generated at 2022-06-24 13:09:59.522488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:10:04.732793
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert not extractor.suitable("http://www.youtube.com/watch?v=SBjQ9tuuTJQ")

# Generated at 2022-06-24 13:10:07.609489
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/chuck-norris/videos/replay-chuck-norris-4-novembre-2019.html')

# Generated at 2022-06-24 13:10:11.316921
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:12.211133
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('url');

# Generated at 2022-06-24 13:10:14.391031
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:10:19.818430
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    tf1ie = TF1IE()
    info = tf1ie._real_extract(url)
    assert tf1ie._TESTS[2]['only_matching'] == info['_type']

# Generated at 2022-06-24 13:10:22.753539
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    tf1_ie.extract("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:10:32.789841
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:36.527629
# Unit test for constructor of class TF1IE
def test_TF1IE():
   TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
   TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:10:37.028569
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:40.671010
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance.url_result('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:43.353556
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE"""
    extractor = TF1IE()
    assert extractor.SUCCESS == 'SUCCESS'

# Generated at 2022-06-24 13:10:46.283672
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:10:47.254916
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance.suite()

# Generated at 2022-06-24 13:10:48.221728
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()



# Generated at 2022-06-24 13:10:50.696690
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1 is not None
    #assert tf1.get_filename() == '57b6d03b7617cbb1e0b5864d'
    assert tf1.props['title'] == 'Koh-Lanta'

# Generated at 2022-06-24 13:10:52.587873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        assert False, 'TF1IE class constructor failed'


# Generated at 2022-06-24 13:10:53.409753
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE(_test_filename)
    return t

# Generated at 2022-06-24 13:10:56.666772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:10:57.292344
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:11:07.835265
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test class TF1IE
    """
    tf1_sample_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1_video_regex = TF1IE._VALID_URL
    tf1_video_id_regex = r'.*?.com/(?P<program_id>[^/]+)/videos/(?P<id>[^/?&#]+).html'
    tf1_video_id = '13641379'
    tf1_video_title = 'Quotidien - intégrale - Yann Barthès, l’acoolique'
    tf1_video_program_id = 'quotidien-avec-yann-barthes'

   

# Generated at 2022-06-24 13:11:08.976133
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:11:14.716378
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    try:
        info = TF1IE()._real_extract(url)
    except:
        return False
    return info.get('id') == '13641379'

# Generated at 2022-06-24 13:11:21.084662
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/ktotv/videos/ktotv-du-28-juin-2018.html"
    x = TF1IE(url)
    assert x.program_slug == 'tf1_ktotv'
    assert x.slug == 'ktotv-du-28-juin-2018'
    assert x.url == url
    assert x.type == 'TF1'
    assert x.context['type'] == 'TF1'

# Generated at 2022-06-24 13:11:25.186648
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:11:35.269650
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1_data = TF1IE()._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1_data['_type'] == 'url_transparent'
    assert tf1_data['id'] == '19312'
    assert tf1_data['url'] == 'wat:19312'
    assert tf1_data['title'] == 'Replay Koh-Lanta'

# Generated at 2022-06-24 13:11:42.454843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_cases = [
        (
            'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
            {
                'url': 'https://api.wat.tv/get/video/13641379',
                'id': '13641379',
                'only_matching': True,
            },
        )
    ]
    for test_case in test_cases:
        run_test(test_case)

# Generated at 2022-06-24 13:11:44.829893
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_general import test
    from .test_general import filter_tmp
    test({'tf1': {'constructor': TF1IE}})
    filter_tmp()

# Generated at 2022-06-24 13:11:47.107164
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:11:52.819727
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:55.403777
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:56.253338
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert True

# Generated at 2022-06-24 13:11:57.129151
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, {}, {})

# Generated at 2022-06-24 13:11:59.040929
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-24 13:12:04.035409
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/[^/]+/videos/[^/?&#]+.html'

# Generated at 2022-06-24 13:12:07.143039
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:13.095447
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:18.050357
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This is to ensure that the TF1IE object don't holds
    # any hardcoded info in the class object
    # this is to ensure that the object is just an object
    TF1IE_obj = TF1IE(None)
    assert(TF1IE_obj.__class__) is TF1IE

# Generated at 2022-06-24 13:12:21.951144
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert (ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'))

# Generated at 2022-06-24 13:12:24.324763
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:12:28.602978
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/myurl"
    t = TF1IE()
    assert t._VALID_URL == "http://www.tf1.fr/myurl"
    assert t._TESTS[0]["url"] == "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert t._TESTS[1]["url"] == "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"

# Generated at 2022-06-24 13:12:30.072387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Check if it constructs
    """
    inst = TF1IE()

# Generated at 2022-06-24 13:12:31.305527
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(TF1IE.ie_key()) is not None

# Generated at 2022-06-24 13:12:39.944304
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert TF1IE._VALID_URL == tf1IE.extractor._VALID_URL
    assert TF1IE._TESTS == tf1IE.extractor._TESTS
    assert tf1IE.extractor.test_cases[0]['url'] == tf1IE.test_cases[0]['url']
    assert tf1IE.extractor.test_cases[0]['info_dict']['tags'] == tf1IE.test_cases[0]['info_dict']['tags']
    assert tf1IE.extractor._download_json == tf1IE._download_json

# Generated at 2022-06-24 13:12:46.005493
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    extractor = TF1IE(url)

    # Assert
    assert type(extractor) is TF1IE
    assert extractor.program_slug == "koh-lanta"
    assert extractor.slug == "replay-koh-lanta-22-mai-2015"

# Generated at 2022-06-24 13:12:56.177792
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[0] == ('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', 'md5:f392bc52245dc5ad43771650c96fb620')
    assert TF1IE._TESTS[1] == ('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', None)


# Generated at 2022-06-24 13:12:56.791886
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-24 13:13:00.490427
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test cases for TF1IE"""
    from ..utils import create_extractor
    from .common import InfoExtractor

    # test empty:
    obj = create_extractor(TF1IE)
    assert isinstance(obj, TF1IE)
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 13:13:01.292994
# Unit test for constructor of class TF1IE
def test_TF1IE():
    cur_TF1IE = TF1IE()

# Generated at 2022-06-24 13:13:07.559813
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    This test must be done with the following commands:

    cd .../youtube-dl
    python -m unittest test_TF1IE
    """
    from youtube_dl.utils import youtube_dl_options

    result = TF1IE(youtube_dl_options())

    assert result._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:17.736386
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # Creation of an instance of class TF1IE
    tf1_instance = TF1IE()
    # Creation of an object of class InfoExtractor
    info_extractor_object = tf1_instance._real_extract(url)
    # Testing the instance created
    assert info_extractor_object[u'_type'] == u'url_transparent'
    assert info_extractor_object[u'url'] == u'wat:13641379'
    assert info_extractor_object[u'title'] == u'Quotidien 1ère partie - 11 juin 2019'

# Generated at 2022-06-24 13:13:23.702312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.assertCanHandleURL('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.assertCanHandleURL('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:13:26.726377
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor of class TF1IE should return an instance of TF1IE class
    """
    tf1IE = TF1IE()
    assert isinstance(tf1IE, TF1IE)

# Generated at 2022-06-24 13:13:32.192904
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    This test checks if the following URL can be used as a valid input:
    https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html
    """
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:13:41.359404
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:13:41.891114
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:44.631772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class TestTF1IE(TF1IE):
        IE_NAME = 'TF1IE'
    assert TestTF1IE.IE_NAME == 'TF1IE'

# Generated at 2022-06-24 13:13:49.887912
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()
    assert result.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not result.suitable('https://www.tf1.fr/')


# Generated at 2022-06-24 13:13:52.684972
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    __test_TF1IE = TF1IE()
    __test_TF1IE._real_extract(url)
    # test with tester
    # tester = Tester()
    # tester(__test_TF1IE, 'your input URL')

# Generated at 2022-06-24 13:13:59.412348
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_cases = [
        (
            'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
            {
                'id': '13412266',
                'slug': 'replay-koh-lanta-22-mai-2015',
            }
        ),
    ]
    for url, expected in test_cases:
        extractor = TF1IE(None)
        assert extractor._match_id(url) == expected

# Generated at 2022-06-24 13:14:06.688696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert(tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:14:09.151486
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    # Check whether the _VALID_URL is set
    assert instance._VALID_URL is not None

# Generated at 2022-06-24 13:14:12.220018
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:14:17.419420
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check for video urls
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:14:28.664364
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:29.288273
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:14:30.982389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for constructor method of TF1IE
    """
    TF1IE(None)


# Generated at 2022-06-24 13:14:31.991603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE()

# Generated at 2022-06-24 13:14:33.841695
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.ie_key() == 'TF1'



# Generated at 2022-06-24 13:14:43.753389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    # Test with an invalid argument
    try:
        TF1IE("invalid")
        assert False
    except Exception as e:
        assert True

    # Test with a valid one
    tf1ie = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

    # Test that the constructor has correctly been processed
    assert tf1ie._VALID_URL =="https://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html"
    assert tf1ie._NETRC_MACHINE == None

# Generated at 2022-06-24 13:14:48.382996
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test TF1IE class constructor."""
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    t = TF1IE(url)
    assert t.url == url
    assert t.program_slug == 'tf1-koh-lanta'
    assert t.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-24 13:14:57.138797
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t1 = TF1IE()
    assert t1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:58.309424
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:14:58.882693
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:02.460600
# Unit test for constructor of class TF1IE
def test_TF1IE():
    example_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    t = TF1IE(example_url)
    assert t.ie_key() == 'TF1'

# Generated at 2022-06-24 13:15:03.090589
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:15:04.122416
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:15:07.418839
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-24 13:15:14.699634
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_dict = {
        'ext': 'mp4',
        'title': 'md5:f392bc52245dc5ad43771650c96fb620',
        'description': 'md5:a02cdb217141fb2d469d6216339b052f',
        'upload_date': '20190611',
        'timestamp': 1560273989,
        'duration': 1738,
        'series': 'Quotidien avec Yann Barthès',
        'tags': ['intégrale', 'quotidien', 'Replay'],
    }
    assert TF1IE._TESTS[0] == test_dict


# Generated at 2022-06-24 13:15:17.566840
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:15:21.783827
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:29.568204
# Unit test for constructor of class TF1IE
def test_TF1IE():

    with open("tests/youtube_cipher_js/tf1.fr.js") as file:
        data = file.read()

    # Test extraction
    ie = TF1IE()
    ie._decrypt_cipher(data)
    ie._extract_video_info(
        "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
        "a6c08e2cd0e611e494d64e60778b0a7a")


# Generated at 2022-06-24 13:15:31.438221
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Initialize an instance of class TF1IE
    # Asserts the constructor does not raise an exception
    tf1_ie = TF1IE()

# Generated at 2022-06-24 13:15:31.935742
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:35.723536
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:15:38.094623
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE"""
    tf1ie = TF1IE()
    print(tf1ie)

# Generated at 2022-06-24 13:15:39.719890
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor of class TF1IE
    tf1 = TF1IE()

# Generated at 2022-06-24 13:15:41.678910
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()

    assert tf1_ie.ie_key() == 'TF1'

# Generated at 2022-06-24 13:15:48.913295
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_constructor = getattr(TF1IE, 'suitable')
    assert class_constructor(TF1IE.ie_key(), {'url': 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'})
    assert not class_constructor(TF1IE.ie_key(), {'url': 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'})

# Generated at 2022-06-24 13:15:52.105932
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _TF1IE = TF1IE('tf1', 'tf1.fr')
    assert _TF1IE.ie_key() == 'TF1'
    assert _TF1IE.ie_name() == 'TF1'

# Generated at 2022-06-24 13:15:57.312369
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(_download_json, 'https://www.tf1.fr/graphql/web', 'slug', {'id': 'id', 'variables': 'variables'})._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:58.212643
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:15:59.644160
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 13:16:11.061498
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Save file locally
    f = open("tf1_tests.json", "w")

# Generated at 2022-06-24 13:16:12.016876
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:16:19.077833
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("""
        https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html
    """)
    assert str(t) == "TF1IE(" + """
        https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html
    """ + ")"

# Generated at 2022-06-24 13:16:27.285752
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test of constructor of class TF1IE"""
    # Test with old URL
    TF1IE._VALID_URL = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE._TESTS = [{
        'url': 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'only_matching': True,
    }]
    TF1IE('wat:blahblah')

    # Test with new URL

# Generated at 2022-06-24 13:16:28.011280
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:38.406891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE_test_obj = TF1IE()
    print("Unit test for class constructor of TF1IE...")
    print("Object of class TF1IE created with success\n")
    print(tf1IE_test_obj)
    #
    # print("Instance id: " + tf1IE_test_obj.ie_key())
    #
    # print("Object is an instance of class InfoExtractor: " + str(isinstance(tf1IE_test_obj, InfoExtractor)))
    #
    # print("Object is an instance of class TF1IE: " + str(isinstance(tf1IE_test_obj, TF1IE)))
    #
    # print("Object is an instance of class YoutubeIE: " + str(isinstance(tf1IE_test_obj, YoutubeIE)))

test_TF1IE()

# Generated at 2022-06-24 13:16:49.082051
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie == 'https://www.tf1.fr/graphql/web'
    assert ie._download_json == 'https://www.tf1.fr/graphql/web'
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:50.080613
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:16:50.670093
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:54.153989
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:16:56.113989
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test that the TF1IE class is instantiated
    tf1_ie = TF1IE()
    assert tf1_ie is not None


# Generated at 2022-06-24 13:16:58.316964
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Instantiation testing """
    tf1 = TF1IE()
    assert isinstance(tf1, TF1IE)

# Generated at 2022-06-24 13:17:04.274488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'
    assert ie.url == url
    assert ie.id == '13641379'

# Generated at 2022-06-24 13:17:08.367093
# Unit test for constructor of class TF1IE
def test_TF1IE():
  url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"

  tf1 = TF1IE(url)

  # Assert the URL is contained in the 'url' attribute
  assert tf1.url == url

# Generated at 2022-06-24 13:17:09.548090
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('fake-arguments', 'fake-obj')

# Generated at 2022-06-24 13:17:19.536734
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = IE_Test(TF1IE, 'TF1IE')

    expected_error_1 = 'Incorrect id: demo'
    expected_error_2 = 'Incorrect slug: tf1'

    assert_raises_regex(ie, expected_error_1, TF1IE, url="http://www.tf1.fr/demo/tf1/videos/demo.html")
    assert_raises_regex(ie, expected_error_2, TF1IE, url="http://www.tf1.fr/tf1/tf1/videos/demo.html")

    expected_title_1 = 'Quotidien - Première partie - 11 juin 2019'
    expected_id_1 = '13641379'

# Generated at 2022-06-24 13:17:20.456126
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()

# Generated at 2022-06-24 13:17:23.372302
# Unit test for constructor of class TF1IE
def test_TF1IE():
    with TF1IE('test', '') as tf1IE:
        assert tf1IE.ie_key() == 'TF1'
        assert tf1IE.ie_key() == tf1IE.ie_key()

# Generated at 2022-06-24 13:17:32.347882
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:17:34.453895
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert ie.url_result('wat:sdfsdf12312')[0] == 'wat'

# Generated at 2022-06-24 13:17:37.320634
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = TF1IE()
    video._download_webpage('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:17:41.492959
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert isinstance(ie, TF1IE)


# Generated at 2022-06-24 13:17:42.101672
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:17:45.402911
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Init object
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:17:49.966988
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:17:50.445222
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:17:54.237675
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = class_to_test(TF1IE)
    assert hasattr(IE, '_VALID_URL')
    assert hasattr(IE, '_TESTS')
    assert hasattr(IE, '_real_extract')
    assert not hasattr(IE, 'suitable')


# Generated at 2022-06-24 13:18:04.423771
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()

# Generated at 2022-06-24 13:18:07.470286
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tF1=TF1IE()
    assert tF1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:18:08.761195
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('url')

# Generated at 2022-06-24 13:18:13.028836
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:18:13.658878
# Unit test for constructor of class TF1IE
def test_TF1IE():
  assert TF1IE

# Generated at 2022-06-24 13:18:23.772476
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/(?:[^/]+/)*(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'