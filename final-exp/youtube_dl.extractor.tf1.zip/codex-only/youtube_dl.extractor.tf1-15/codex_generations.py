

# Generated at 2022-06-24 13:08:23.853643
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test URL: https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html
    info_extractor = TF1IE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert info_extractor._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert info_extractor

# Generated at 2022-06-24 13:08:27.737689
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(Downloader())
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:32.931819
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-24 13:08:41.685309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor test of class TF1IE.
    """
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:08:43.687387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:08:53.699880
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie._TESTS[0]['info_dict']['id'] == '13641379'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:08:54.601604
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()

# Generated at 2022-06-24 13:09:00.965401
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1IE = TF1IE(url)
    assert tf1IE._VALID_URL == url
    assert tf1IE.program_slug == "koh-lanta"
    assert tf1IE.slug == "replay-koh-lanta-22-mai-2015"
    assert tf1IE._TESTS[0].get("url") == url
    assert tf1IE._TESTS[0].get("only_matching") == True

# Generated at 2022-06-24 13:09:01.950230
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()


# Generated at 2022-06-24 13:09:11.176747
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._download_json(
        'https://www.tf1.fr/graphql/web', 'quotidien-premiere-partie-11-juin-2019', query={
            'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
            'variables': json.dumps({
                'programSlug': 'quotidien-avec-yann-barthes',
                'slug': 'quotidien-premiere-partie-11-juin-2019',
            })
        })

# Generated at 2022-06-24 13:09:13.697530
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert ie.RATING_REGEX == r'\(c\)\s*([^)]+)'

# Generated at 2022-06-24 13:09:15.518328
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE
    assert class_ is not None

# Generated at 2022-06-24 13:09:16.761147
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:09:17.733431
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)

# Generated at 2022-06-24 13:09:18.281848
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:20.824134
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("")
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:22.208477
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This just checks the object was created and seems to be fine
    TF1IE('wat:123123123')

# Generated at 2022-06-24 13:09:23.878352
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_download import options
    ie = TF1IE(options)
    assert ie.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:09:25.657704
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TODO: Add tests
    pass

# Generated at 2022-06-24 13:09:27.725111
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._real_extract('test')

# Generated at 2022-06-24 13:09:31.941513
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('foo')._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:34.973634
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE.TF1IE("wat")
    except TypeError:
        assert True
    except:
        assert False
    try:
        TF1IE.TF1IE(1)
    except TypeError:
        assert True
    except:
        assert False
    try:
        TF1IE.TF1IE("wat",1)
    except TypeError:
        assert True
    except:
        assert False

# Generated at 2022-06-24 13:09:35.955287
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert ie

# Generated at 2022-06-24 13:09:37.715341
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

##############################################################################
# Main program
# Display all of the results

# Generated at 2022-06-24 13:09:47.181661
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:09:57.705366
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Class is not a subclass of InfoExtractor
    import pytest
    #with pytest.raises(TypeError):
    #    tf1 = TF1IE()
    tf1 = TF1IE()
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert tf1.suitable(url) == True
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:02.207852
# Unit test for constructor of class TF1IE
def test_TF1IE():
    p=TF1IE()
    s=p._VALID_URL
    assert s=='https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:10:04.059091
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE(InfoExtractor())
    assert type(tf1IE) == TF1IE

# Generated at 2022-06-24 13:10:08.620742
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"


# Generated at 2022-06-24 13:10:09.638891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    WatIE('wat:123')

# Generated at 2022-06-24 13:10:10.109990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:11.486602
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Make sure that the constructor of TF1IE does not raise an exception
    TF1IE()


# Generated at 2022-06-24 13:10:12.397461
# Unit test for constructor of class TF1IE
def test_TF1IE():
  TF1IE()


# Generated at 2022-06-24 13:10:15.587893
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:20.819104
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('TF1IE')
    # This test may need adjustments in the future
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:21.669359
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie

# Generated at 2022-06-24 13:10:31.383538
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for TF1IE  (constructor of class TF1IE)
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # Please ensure your url is legal (avoid downloading large files for test)
    url = url.replace(" ", "%20")
    TF1IE(url).download(preference='video')
    # TF1IE(url).download(preference='audio')  # Constructor of class TF1IE can download both audio and video
    # TF1IE(url).download(preference=None)  # Constructor of class TF1IE can download both audio and video
    # TF1IE(url).download()  # Constructor of class TF1IE can download

# Generated at 2022-06-24 13:10:32.485177
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:13641379')

# Generated at 2022-06-24 13:10:35.937262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    instance = TF1IE()
    assert instance.suitable(url) == True

# Generated at 2022-06-24 13:10:42.143781
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor test
    t = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert t.program_slug == 'quotidien-avec-yann-barthes'
    assert t.slug == 'quotidien-premiere-partie-11-juin-2019'


# Generated at 2022-06-24 13:10:50.075820
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE();
    assert ie.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html");
    assert ie.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html");
    assert ie.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html");

# Generated at 2022-06-24 13:10:51.675399
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Test constructor of TF1IE
    '''
    t = TF1IE()

# Generated at 2022-06-24 13:10:53.007561
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:10:53.672794
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-24 13:10:54.815615
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """instance of TF1IE should be created"""
    assert TF1IE

# Generated at 2022-06-24 13:10:55.847568
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:57.198278
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.name == "TF1"

# Generated at 2022-06-24 13:10:59.217587
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    expected = 'instance of TF1IE'
    assert(str(instance) == expected)

# Generated at 2022-06-24 13:11:02.169925
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:11:03.680293
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE({})
    assert tf1ie is not None

# Generated at 2022-06-24 13:11:11.813648
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(object())
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:13.993978
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:16.569267
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.ie_key() == 'TF1'
    assert IE._VALID_URL
    assert IE._TESTS

# Generated at 2022-06-24 13:11:17.710201
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("test")

# Generated at 2022-06-24 13:11:18.273855
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:20.918084
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Constructor of InfoExtractor does not need any arguments
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.VERSION == '0.1.1'

# Generated at 2022-06-24 13:11:21.896075
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("unicode_text")

# Generated at 2022-06-24 13:11:22.878374
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:23.482925
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:11:24.808332
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.__class__.__name__ == "TF1IE"


# Generated at 2022-06-24 13:11:28.319485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.SUFFIX == 'tf1.fr'
    assert ie.ie_key() == 'tf1'
    assert ie.KNOWN_EXTENSIONS == ['mp4']

# Generated at 2022-06-24 13:11:31.206940
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # pylint:disable=redefined-outer-name
    """Unit test for constructor of class TF1IE"""
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:31.956187
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE()

# Generated at 2022-06-24 13:11:33.276099
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-24 13:11:42.720976
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:11:51.264103
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ex = TF1IE()
    # Test: https://www.wat.tv/video/quotidien-premiere-partie-11-juin-2019-13641379.html
    url = 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ex.match(url) == True

# Generated at 2022-06-24 13:11:53.386778
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    assert TF1IE().__class__ == TF1IE
    assert TF1IE()._TESTS == TF1IE._TESTS

# Generated at 2022-06-24 13:11:54.064999
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE('TF1IE')

# Generated at 2022-06-24 13:11:57.420556
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE()
    e.extract_url('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    # Test re
    assert e._VALID_URL.match('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:00.032726
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf = TF1IE('wat', 'wat')
    assert tf.ie_key() == 'wat'

# Generated at 2022-06-24 13:12:01.376676
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global TF1IE
    assert issubclass(TF1IE, InfoExtractor) == True

# Generated at 2022-06-24 13:12:03.862343
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:11.072046
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_main import main
    from . import test_main


# Generated at 2022-06-24 13:12:22.438383
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assertequal(tf1._VALID_URL, 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html') 

# Generated at 2022-06-24 13:12:25.263182
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create instance of class TF1IE
    tf1ie = TF1IE()

    # Make sure URL matches regex
    assert tf1ie._VALID_URL == re.compile(tf1ie._VALID_URL)

# Generated at 2022-06-24 13:12:27.500835
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:34.400461
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t1 = TF1IE()
    assert t1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:36.484037
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test that creation of TF1IE object works"""
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:12:37.321748
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()


# Generated at 2022-06-24 13:12:37.816717
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:12:38.329947
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(isinstance(TF1IE, InfoExtractor))

# Generated at 2022-06-24 13:12:38.915093
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE({})

# Generated at 2022-06-24 13:12:43.473344
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE("TF1IE", "https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html", {})
    assert test.test_url == "https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    assert test.id == "https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    assert test.ie_key == "TF1"
    assert test.suitable == "SUITABLE"


# Generated at 2022-06-24 13:12:49.362294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        # Function should return a dict
        wat_id = '5a1d5b8f-4573-4a7d-8f85-e7d4a1c4a7af'
        t = TF1IE(None);
        d = t._real_extract(wat_id)
    except Exception as e:
        assert False, 'Function fails with exception: ' + str(e)

    assert isinstance(d, dict), 'Function does not return a dict'

# Generated at 2022-06-24 13:12:51.320176
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    assert test_TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:59.562341
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor test.
    """
    ie = TF1IE()
    assert ie.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'Télévision française 1 - tf1'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:04.995345
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not i.suitable('https://wat.tv/video/koh-lanta-replay-koh-lanta-22-mai-2015-s02e01-aventure-solution-vostfr-c-f9do9.html')
    assert i.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:13:10.584583
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert(TF1IE._VALID_URL == TF1IE._TESTS[1]['only_matching'])
    assert(TF1IE.suitable(url))
    assert(TF1IE.IE_DESC == 'tf1')


# Generated at 2022-06-24 13:13:18.296956
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE."""
    ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.url == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-24 13:13:19.810889
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:13:30.518015
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("url")
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:37.666118
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x.EXTENSIONS == ('mp4',)
    assert x.IE_NAME == 'tf1'
    assert x.SUFFIX == ''
    assert x._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'
    assert x.DEFAULT_FORMAT == 'bestvideo'
    assert x.LAST_UPDATED == '20180822'

# Generated at 2022-06-24 13:13:43.466522
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # check correct constructor
    # assert_raises(TypeError, TF1IE.__init__)
    assert_raises(TypeError, TF1IE)
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE(url)
    # check wrong constructor
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert_raises(TypeError, TF1IE.__init__, url)

# Generated at 2022-06-24 13:13:55.196438
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x.playlist_mincount == 1
    assert x.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not x.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/')
    assert not x.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not x.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:13:56.264568
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        raise AssertionError('Exception was raised: ' + str(e))

# Generated at 2022-06-24 13:14:00.882210
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE(url)
    assert isinstance(ie, TF1IE)

    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert isinstance(ie, TF1IE)

    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ie = TF1IE(url)
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-24 13:14:02.471317
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('test')
    assert tf1.name == 'tf1'



# Generated at 2022-06-24 13:14:03.377240
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:04.867463
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE)

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:14:09.054184
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_instance = TF1IE()
    assert TF1IE_instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:10.031588
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:12345')

# Generated at 2022-06-24 13:14:10.618932
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:14.541358
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ie = TF1IE()
    assert ie.suitable(url) is True
    return

# Generated at 2022-06-24 13:14:17.307376
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:18.464481
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:19.343855
# Unit test for constructor of class TF1IE
def test_TF1IE():
    loader = TF1IE()

# Generated at 2022-06-24 13:14:22.634973
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:14:24.121432
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert(instance is not None)

# Generated at 2022-06-24 13:14:28.285597
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:30.008909
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor.IE_NAME == 'TF1'

# Generated at 2022-06-24 13:14:32.131816
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert 'TF1IE' == t.IE_NAME
    assert 'tf1.fr' in t._VALID_URL

# Generated at 2022-06-24 13:14:33.239256
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('x')

# Generated at 2022-06-24 13:14:36.117237
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:14:37.054143
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE(None)._VALID_URL

# Generated at 2022-06-24 13:14:41.585356
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(downloader=None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:14:45.156541
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert hasattr(TF1IE, "_download_json")
    assert hasattr(TF1IE, "_real_extract")

    # Adding a new attribute to the class TF1IE
    TF1IE.test = 'test'
    assert hasattr(TF1IE, "test")


# Generated at 2022-06-24 13:14:51.469065
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test instance of class TF1IE
    tf1 = TF1IE()

    assert tf1.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert tf1.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == True
    assert tf1.suitable('http://www.tf1.fr/tf1/enquete-exclusive/videos/enquete-exclusive-le-malo-les-jours-de-gloire.html') == True

# Generated at 2022-06-24 13:14:56.760279
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    r = re.search(TF1IE._VALID_URL, url)
    assert r.group(1) == 'quotidien-avec-yann-barthes'
    assert r.group(2) == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:14:57.608431
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE([])


# Generated at 2022-06-24 13:14:59.864884
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.ie_key() == 'TF1'
    assert i.server_url() == 'https://www.tf1.fr'

# Generated at 2022-06-24 13:15:01.294520
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:15:05.731730
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create instance
    instance = TF1IE()
    # Assert the downloader of the instance
    assert instance.downloader is None
    assert instance.ie_key() == 'TF1'
    assert instance.ie_key() == instance.IE_KEY
    assert instance.root_dir is None

# Generated at 2022-06-24 13:15:06.306977
# Unit test for constructor of class TF1IE
def test_TF1IE():
  TF1IE()

# Generated at 2022-06-24 13:15:07.285180
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('youtube-dl')
    assert ie.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:15:10.007465
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:15:17.497945
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._downloader.cache.store('https://www.tf1.fr/graphql/web', '{"data":{"videoBySlug":{"streamId":"1","title":"2","tags":[{"label":"3"}],"decoration":[{"description":"4","programLabel":"5","image":{"sources":[{"url":"6","width":"7"}]}}],"date":"8","publicPlayingInfos":{"duration":9},"season":10,"episode":11}}}')
    ie.url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

    # test the test; this is the only thing needed to be tested in this file
    assert ie._real_extract(ie.url)['id'] == '1'

# Generated at 2022-06-24 13:15:19.103968
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(len(TF1IE._TESTS) > 0)

# Generated at 2022-06-24 13:15:25.979436
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for video
    tf1 = TF1IE()
    video = tf1.extract('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert video['id'] == '13641379'
    assert video['title'] == 'Quotidien - Première partie - 11/06/2019'



# Generated at 2022-06-24 13:15:27.127868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-24 13:15:29.659831
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('', {})
    assert tf1ie.tf1_url == 'https://www.tf1.fr/graphql/web'

# Generated at 2022-06-24 13:15:30.579857
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1_ie = TF1IE()
    assert TF1_ie.ie_key() == 'tf1'

# Generated at 2022-06-24 13:15:31.134666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("test")

# Generated at 2022-06-24 13:15:36.131883
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert re.match(ie._VALID_URL, 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == None

# Generated at 2022-06-24 13:15:37.970030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:15:46.004619
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    # Parsing of a valid URL, only_matching should be False
    assert TF1IE(TF1IE.ie_key())._match_id(url) == False
    # Parsing of an invalid URL, only_matching should be True
    url += "asd"
    assert TF1IE(TF1IE.ie_key())._match_id(url) == True

# Generated at 2022-06-24 13:15:47.428887
# Unit test for constructor of class TF1IE
def test_TF1IE():
  # Simple creation of an instance of TF1IE
  TF1IE()

# Generated at 2022-06-24 13:15:50.604566
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test TF1IE constructor
    """
    # Check for correct URL
    valid_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    try:
        tf1 = TF1IE(valid_url)
    except:
        raise AssertionError('Invalid URL: %s' % valid_url)

# Generated at 2022-06-24 13:15:58.099482
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE({})
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:01.802417
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:16:03.199780
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().extractor_key == 'TF1'

# Generated at 2022-06-24 13:16:05.768281
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # https://stackoverflow.com/a/37178001
    assert issubclass(TF1IE, InfoExtractor)

# Generated at 2022-06-24 13:16:14.223285
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') is not None
    assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is not None
    assert TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') is not None

# Generated at 2022-06-24 13:16:17.997139
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_object = TF1IE()
    assert class_object.suitable(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:16:26.774130
# Unit test for constructor of class TF1IE
def test_TF1IE():
	obj = TF1IE()
	assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:28.201089
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:16:38.559207
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:16:44.813020
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie.get_id() == "koh-lanta-merveilleux-sont-les-inities-episode-1"
    assert 'merveilleux' in ie.get_title()

# Generated at 2022-06-24 13:16:48.033451
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:16:50.126320
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    return TF1IE()._test_factory(TF1IE._TESTS)

# Generated at 2022-06-24 13:16:55.790456
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test to instantiate TF1IE
    tf1IE = TF1IE()
    assert tf1IE.ie_key() == 'TF1'
    assert tf1IE.server_url == "www.tf1.fr"
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1IE._TESTS[0]

# Generated at 2022-06-24 13:16:58.668812
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:01.861836
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for a valid case
    obj = TF1IE(None, extractor='test')
    obj._VALID_URL = "test"
    obj.test_test_test()


# Generated at 2022-06-24 13:17:04.787892
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Useful for debugging
    # import os;os.system('firefox -p wat -new-tab ' + url)
    url = TF1IE()._TESTS[0]['url']
    TF1IE()._real_extract(url)

# Generated at 2022-06-24 13:17:06.170733
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from wat import WatIE
    TF1IE(WatIE(expat=True))

# Generated at 2022-06-24 13:17:09.712285
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # type: () -> None
    """
    Geo restricted videos are not supported
    """
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:17:19.705499
# Unit test for constructor of class TF1IE
def test_TF1IE():
  test_obj = TF1IE()
  assert test_obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:20.278078
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:21.715985
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(None, None)
    assert obj is not None

# Generated at 2022-06-24 13:17:31.233860
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with URL as input
    params = {
        'url': 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
    }
    test_class = TF1IE(params)
    assert test_class.url_re.match(params['url']) is not None
    assert test_class._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert test_class.program_slug == params['url'].split('/')[4]
    assert test_class.slug == params['url'].split('/')[6].split

# Generated at 2022-06-24 13:17:36.615263
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(0)
    matched = tf1ie._VALID_URL_RE.match(tf1ie._TESTS[0]['url'])
    assert matched is not None
    assert matched.group('program_slug') == 'quotidien-avec-yann-barthes'
    assert matched.group('id') == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:17:38.646222
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-24 13:17:41.751891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test function of constructor class TF1IE
    """

    t1 = TF1IE()

    # Test attributes
    assert t1.ie_key() == 'wat'
    assert t1.host() == 'tf1.fr'

# Generated at 2022-06-24 13:17:51.488643
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = (
        'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    )

# Generated at 2022-06-24 13:17:52.001172
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:17:53.885194
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('')
    assert tf1.TF1IE == TF1IE

# Generated at 2022-06-24 13:17:55.880288
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("tf1_stories")

# Generated at 2022-06-24 13:18:04.903354
# Unit test for constructor of class TF1IE
def test_TF1IE():
    m = TF1IE()
    assert m._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:05.516542
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()
    TF1IE('TF1')

# Generated at 2022-06-24 13:18:12.982278
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:18:15.028983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('www.tf1.fr/')
    assert TF1IE('www.tf1.fr')

# Generated at 2022-06-24 13:18:19.055293
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:18:21.917760
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import tf1
    ie = tf1.TF1IE()
    assert ie.name == 'tf1'
    assert ie.decryptor.suitable
    assert ie.decryptor.name == 'Wat'