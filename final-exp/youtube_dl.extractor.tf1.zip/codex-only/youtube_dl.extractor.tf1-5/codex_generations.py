

# Generated at 2022-06-24 13:08:24.410939
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() is not None

# Generated at 2022-06-24 13:08:25.669078
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE('test', 'test', 'test', 'test')._match_id('test')

# Generated at 2022-06-24 13:08:29.948247
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == '^https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'


# Generated at 2022-06-24 13:08:30.569539
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:31.189018
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:31.770315
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:32.423890
# Unit test for constructor of class TF1IE
def test_TF1IE():
    [TF1IE]

# Generated at 2022-06-24 13:08:35.040671
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert t



# Generated at 2022-06-24 13:08:37.741564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1-hd/documents/videos/replay-koh-lanta-le-choc-des-heroes-episode-5-fidji.html')

# Generated at 2022-06-24 13:08:44.955779
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE()._TESTS[0]["url"] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE()._TESTS[1]["url"] == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-24 13:08:49.177008
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Function test_TF1IE
    """
    assert TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:08:52.954584
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor())._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:01.064506
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:08.472901
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    test = TF1IE()
    assert test._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    test._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:09:11.296050
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:09:12.587970
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:09:14.417625
# Unit test for constructor of class TF1IE
def test_TF1IE():
    with tf1_ie as ie:
        assert ie is not None

# Test for TF1IE.extract()

# Generated at 2022-06-24 13:09:19.830747
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    new_url = ie.result(ie.extract(ie.suitable('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')))
    assert new_url['_type'] == 'url_transparent'

# Generated at 2022-06-24 13:09:20.293127
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:21.948781
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tests = [
        iE(TF1IE()),
    ]

# We only test that the class to be instanciated

# Generated at 2022-06-24 13:09:23.010829
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    print(type(x))

# Generated at 2022-06-24 13:09:23.803152
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-24 13:09:25.257420
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:09:26.238253
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:09:28.669180
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)


# Generated at 2022-06-24 13:09:33.714106
# Unit test for constructor of class TF1IE
def test_TF1IE():
    invalid_args = [{}, {'u': 'http://www.xxx.com'}, {'url': 'http://www.xxx.com'} ]
    for current_args in invalid_args:
        with pytest.raises(Exception):
            TF1IE(current_args)

# Unit tests for private methods of class TF1IE

# Generated at 2022-06-24 13:09:35.523855
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert str(type(instance)) == "<class '__main__.TF1IE'>"

# Generated at 2022-06-24 13:09:36.419032
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test = TF1IE(test)
    assert isinstance(test, TF1IE)

# Generated at 2022-06-24 13:09:43.055143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.cleanVideoTag("bonjour");
    tf1.cleanVideoTag("bonjour ?");
    tf1.cleanVideoTag("bonjour ?");
    tf1.cleanVideoTag("bonjour");
    tf1.cleanVideoTag("bonjour ?");
    tf1.cleanVideoTag("bonjour ?");
    tf1.cleanVideoTag("bonjour");
    tf1.cleanVideoTag("'bonjour ?'");
    tf1.cleanVideoTag("'bonjour ?");
    tf1.cleanVideoTag("'bonjour ?'");

# Generated at 2022-06-24 13:09:46.312775
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE('TF1')
    assert(IE.extractor_key == 'TF1')
    assert(IE.IE_NAME == 'tf1')
    assert(IE.IE_DESC == 'TF1 (tf1.fr)')


# Generated at 2022-06-24 13:09:49.432941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:59.623796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert not re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/')
    assert not re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015-1.html')

# Generated at 2022-06-24 13:10:02.286083
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:10:13.051180
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie.program_slug = 'koh-lanta'
    ie.id = 'replay-koh-lanta-22-mai-2015'
    ie._VALID_URL = re.compile(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:10:16.521227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE().extract("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:10:19.328067
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(TF1IE.IE_NAME, "").get_info(False)["title"] == TF1IE.IE_DESC



# Generated at 2022-06-24 13:10:24.165658
# Unit test for constructor of class TF1IE
def test_TF1IE():
	obj = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
	assert obj._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:10:34.446652
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("\nUnit test for constructor of class TF1IE:")
    # test for normal website
    print("\ntest for normal website:")
    video_urls = ['https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html']
    for video_url in video_urls:
        print("\ntest for video with url = {}".format(video_url))
        assert TF1IE._VALID_URL == TF1IE._match_id(video_url)
    # test for special website
    print("\ntest for special website:")

# Generated at 2022-06-24 13:10:38.610178
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE(None)
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1IE.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:10:41.788029
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:10:42.400851
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:10:45.550766
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert(tf1ie.__class__.__name__ == 'TF1IE')
    assert(tf1ie.SUFFIX == 'tf1.fr')



# Generated at 2022-06-24 13:10:49.110520
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test instance creation
    tf1ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1ie != None

# Generated at 2022-06-24 13:10:50.031601
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:10:50.970349
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("url")

# Generated at 2022-06-24 13:10:55.187062
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    video_info = tf1ie.extract(test_url)
    assert video_info['id'] == '13641379'

# Generated at 2022-06-24 13:10:56.344559
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, None)

# Generated at 2022-06-24 13:10:57.712036
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_object = TF1IE({})
    assert test_object


# Generated at 2022-06-24 13:10:58.385131
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:02.641239
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    # Check attributes of constructor
    assert tf1IE.ie_key() == 'TF1'
    assert tf1IE.ie_name() == 'TF1'
    assert tf1IE.ie_version() == '1.0'



# Generated at 2022-06-24 13:11:04.817307
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_test = TF1IE('test', 'test')
    assert t_test is not None

# Generated at 2022-06-24 13:11:09.913611
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test for constructor of class TF1IE."""
    TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")



# Generated at 2022-06-24 13:11:17.752083
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert ie._VALID_URL == ie.match_url(url)
    ie = TF1IE()
    url = 'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    assert ie._VALID_URL == ie.match_url(url)

# Generated at 2022-06-24 13:11:18.278923
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()
    assert a is not None

# Generated at 2022-06-24 13:11:22.818644
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:33.321098
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    ie = TF1IE(url)
    assert ie.url == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert ie.slug == "quotidien-premiere-partie-11-juin-2019"
    assert ie.program_slug == "quotidien-avec-yann-barthes"
    assert ie.decoration is None or ie.decoration == {}

# Generated at 2022-06-24 13:11:42.813128
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._HTML_CONTENT_REGEX = r'^<html>.*test</html>$'
    ie._VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:44.476679
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)


# Generated at 2022-06-24 13:11:45.044941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:45.941463
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check by doing nothing
    pass

# Generated at 2022-06-24 13:11:53.670010
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert isinstance(instance, InfoExtractor)
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:56.904995
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    test = TF1IE(url)
    assert test.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:11:58.742206
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("develop")
    assert tf1ie is not None

# Generated at 2022-06-24 13:12:02.107182
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:02.762015
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL is not None

# Generated at 2022-06-24 13:12:04.016386
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert isinstance(info_extractor, TF1IE)

# Generated at 2022-06-24 13:12:07.713811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor.ie_key() == 'TF1'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:08.680855
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:13641379')

# Generated at 2022-06-24 13:12:10.035277
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:12:21.221379
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert instance._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:12:22.511048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    pass

# Generated at 2022-06-24 13:12:30.936562
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert_raises(RegexNotFoundError, TF1IE, 'foo')
    assert_raises(ExtractorError, TF1IE, 'http://www.tf1.fr')
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert_raises(ExtractorError, TF1IE, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:32.165153
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("url","program_slug", "id")

# Generated at 2022-06-24 13:12:35.067327
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:38.746891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie is not None
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'



# Generated at 2022-06-24 13:12:39.273001
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tfi = TF1IE()

# Generated at 2022-06-24 13:12:43.343864
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert tf1.program_slug == "koh-lanta"
    assert tf1.slug == "replay-koh-lanta-22-mai-2015"

# Generated at 2022-06-24 13:12:45.452259
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This "pass" is actually a failure, as the constructor needs an url argument
    # which is not provided
    TF1IE()

# Generated at 2022-06-24 13:12:46.668108
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception:
        pass

# Generated at 2022-06-24 13:12:47.562347
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-24 13:12:49.150122
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()
    assert a != 0


# Generated at 2022-06-24 13:12:51.421593
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor())._VALID_URL
    assert TF1IE(InfoExtractor())._TESTS

# Generated at 2022-06-24 13:12:55.661798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    args = ['https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html']
    tf1 = TF1IE(*args)
    assert tf1.match()

# Generated at 2022-06-24 13:13:04.008447
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.SUFFIX == ''
    assert ie.ie_key() == 'tf1'
    assert ie.server_urls == {}
    assert ie.url_re == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie.video_url_template is None
    assert ie._API_TEMPLATE == 'https://www.tf1.fr/graphql/web'
    assert ie.video_id_re == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:04.533575
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:05.058263
# Unit test for constructor of class TF1IE
def test_TF1IE():

    ie = TF1IE

# Generated at 2022-06-24 13:13:08.847110
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:13:09.401180
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:10.085324
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:12.203080
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('http://www.tf1.fr/tml/')

# Generated at 2022-06-24 13:13:13.161133
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL

# Generated at 2022-06-24 13:13:13.730330
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:14.101403
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:13:19.997743
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._download_webpage('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', {})
    ie._download_webpage('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', {})

# Generated at 2022-06-24 13:13:30.628188
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from wat import WatIE
    from .common import InfoExtractor
    from . import compat_urllib_request

    _VALID_URL = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

    infoExtractor = InfoExtractor()

    m = infoExtractor._call_search_ie(TF1IE.ie_key(), _VALID_URL).result()

    assert m.group('program_slug') == 'koh-lanta'
    assert m.group('id') == 'replay-koh-lanta-22-mai-2015'
    assert isinstance(infoExtractor._ies[WatIE.ie_key()], WatIE)


# Generated at 2022-06-24 13:13:31.512597
# Unit test for constructor of class TF1IE
def test_TF1IE():
    m = TF1IE()

# Generated at 2022-06-24 13:13:40.999523
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    if re.match(ie._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is None:
        raise Exception("URL in class TF1IE is not valid")

# Generated at 2022-06-24 13:13:42.174299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj != None


# Generated at 2022-06-24 13:13:42.715349
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:47.188782
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:49.259725
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE", "url",)

# Generated at 2022-06-24 13:13:49.891851
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:13:52.055035
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE(url)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:13:53.567080
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie1 = TF1IE() 
    assert ie1 is not None


# Generated at 2022-06-24 13:13:54.657629
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert(t)

# Generated at 2022-06-24 13:13:58.573726
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    #assert ie.constructor_compatibility_test()
    assert ie.id == 'TF1'
    assert ie.pattern == 'https?://(?:www\.)?tf1\.fr/[^/]+/.+/videos/.+\.html'
    assert ie.name == 'TF1'

# Generated at 2022-06-24 13:13:59.154143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:14:03.491135
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test constructor
    tf1ie = TF1IE("")
    assert tf1ie is not None
    # test that constructor has _VALID_URL
    tf1ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert tf1ie._VALID_URL is not None


# Generated at 2022-06-24 13:14:06.725319
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:14:10.325320
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert isinstance(obj, TF1IE)


# Generated at 2022-06-24 13:14:11.830705
# Unit test for constructor of class TF1IE
def test_TF1IE():
    Test_TF1IE = TF1IE()



# Generated at 2022-06-24 13:14:14.540014
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert TF1IE._VALID_URL == tf1._VALID_URL

test_TF1IE()

# Generated at 2022-06-24 13:14:15.743950
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance.IE_NAME == 'tf1'
    assert instance._VALID_URL
    assert instance._TESTS

# Generated at 2022-06-24 13:14:17.110524
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert isinstance(t, TF1IE)

# Generated at 2022-06-24 13:14:18.916937
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'



# Generated at 2022-06-24 13:14:22.535834
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    # check that attributes exists
    assert instance.suitable
    assert instance._VALID_URL
    assert instance._download_webpage
    assert instance._download_json
    assert instance._real_extract

# Generated at 2022-06-24 13:14:32.868992
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test the constructor of TF1IE class.
    """
    TF1IE_instance = TF1IE()
    # Test the value of _VALID_URL class attribute
    pattern = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE_instance._VALID_URL == pattern
    # Test the value of IE_NAME class attribute
    assert TF1IE_instance.IE_NAME == 'tf1'
    # Test the value of _TEST class attribute

# Generated at 2022-06-24 13:14:34.349366
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)

# Generated at 2022-06-24 13:14:43.839534
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # A unit test for TF1IE class
    # Creating a TF1IE object
    tf1 = TF1IE()
    # It should work for a url of the form
    # http://www.tf1.fr/tf1/dallas/videos/dallas-le-feu-s-eteint-pour-j-r.html
    url = 'http://www.tf1.fr/tf1/dallas/videos/dallas-le-feu-s-eteint-pour-j-r.html'
    # The expected id of the video is:
    # 85833
    expected_id = 85833
    # Extracting the id from the url
    extracted_id = tf1._extract_id(url)
    # Checking if it matches the expected value
    assert extracted_id == expected_id
    # Checking

# Generated at 2022-06-24 13:14:44.551032
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()(URL)

# Generated at 2022-06-24 13:14:46.055075
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE._download_json('https://www.tf1.fr/graphql/web', 'replay-koh-lanta-22-mai-2015')

# Generated at 2022-06-24 13:14:49.134015
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE
    assert class_ is not None
    object_ = class_()
    assert object_ is not None
    # test_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    # assert class_.suitable(test_url)


# Generated at 2022-06-24 13:14:57.586212
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.suitable('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:14:59.182428
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert "TF1IE" is tf1ie._ie_key()

# Generated at 2022-06-24 13:15:09.247487
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:17.004474
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._NETRC_MACHINE == 'tf1'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/1507807800001/default_default/index.html?videoId=%s'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie

# Generated at 2022-06-24 13:15:18.449060
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test if class can be instantiated
    """
    TF1IE()

# Generated at 2022-06-24 13:15:24.399012
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE('test')
    assert tf1IE != None
    assert str(TF1IE) == 'tf1'
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:33.305122
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    # Test constructor of class InfoExtractor
    assert IE._downloader == None
    assert IE._download_webpage == None
    assert IE._download_webpage_handle == None
    assert IE._download_json == None
    assert IE._match_id == None
    # Test attributes of class TF1IE
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:36.499826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert result.tf1_video

# Generated at 2022-06-24 13:15:41.982910
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    assert TF1IE().extract_url(TF1IE()._VALID_URL) is not None
    assert TF1IE().extract_url(TF1IE()._VALID_URL) == TF1IE()._TESTS[0]

# Generated at 2022-06-24 13:15:52.818152
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:54.959674
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = TF1IE._TESTS[0]['url']
    obj = TF1IE(test_url)
    assert obj is not None

# Generated at 2022-06-24 13:16:05.609892
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(0, "www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", "")
    assert obj.getType() == "url_transparent"
    assert obj.getId() == "1064099"
    assert obj.getUrl() == "wat:1064099"
    assert obj.getTitle() == "md5:2d4ba736efcd4db3df4c4b88fecb7e8b"
    assert obj.getDescription() == "md5:9e9f9d0c0b2e02f7c2cc5daebaf7c1b5"
    assert obj.getTimestamp() == 1432340960
    assert obj.getDuration() == 3452

# Generated at 2022-06-24 13:16:16.451289
# Unit test for constructor of class TF1IE

# Generated at 2022-06-24 13:16:17.397631
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:13641379')

# Generated at 2022-06-24 13:16:25.397561
# Unit test for constructor of class TF1IE
def test_TF1IE():
    input = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1IE = TF1IE()

    assert tf1IE.suitable(input) == True, 'Should be True'
    assert tf1IE.IE_DESC == 'TF1', 'Should be TF1'
    assert tf1IE._VALID_URL ==  r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html', 'Should match URL'


# Generated at 2022-06-24 13:16:26.136218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:16:26.888885
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:16:27.957182
# Unit test for constructor of class TF1IE
def test_TF1IE():

    TF1IE(None, None)

# Generated at 2022-06-24 13:16:38.370499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Constructor test of class TF1IE"""
    if "TF1IE" not in globals().keys() or not inspect.isclass(TF1IE):
        return

    # Instantiation of class TF1IE
    ie_obj = TF1IE()

    # Test for the presence of the class attribute _VALID_URL
    assert ie_obj._VALID_URL is not None

    # Test for the presence of the class attribute _TESTS
    assert ie_obj._TESTS is not None

    # Test for the presence of the class attribute IE_NAME
    assert ie_obj.IE_NAME is not None

    # Test for the presence of the class attribute _TEST
    assert ie_obj._TEST is not None

    # Test for the presence of the class attribute _NETRC_MACHINE
    assert ie_obj._NETRC_

# Generated at 2022-06-24 13:16:40.250932
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('1')
    assert str(instance) == 'tf1.fr'

# Generated at 2022-06-24 13:16:43.644945
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Test that the constructor raises an error if the URL is wrong
    print("Test the constructor of the class TF1IE")
    with pytest.raises(TypeError):
        TF1IE()

# Generated at 2022-06-24 13:16:47.983105
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE("TF1", "tf1", "tf1")
    assert(tf1_ie._VALID_URL== r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-24 13:16:49.303319
# Unit test for constructor of class TF1IE
def test_TF1IE(): # pylint: disable=no-member
    TF1IE()

# Generated at 2022-06-24 13:16:54.267853
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert(video.program_slug == 'quotidien-avec-yann-barthes')
    assert(video.slug == 'quotidien-premiere-partie-11-juin-2019')

# Generated at 2022-06-24 13:16:55.077303
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()

# Generated at 2022-06-24 13:16:57.316442
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:17:07.295699
# Unit test for constructor of class TF1IE
def test_TF1IE():

    query = {
        'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
        'variables': json.dumps({
            'slug': 'quotidien-premiere-partie-11-juin-2019',
            'programSlug': 'quotidien-avec-yann-barthes',
        })
    }

    # Test if the json is fetched from the given URL
    try:
        result = InfoExtractor._download_json('https://www.tf1.fr/graphql/web', 'slug', query)
    except Exception as e:
        assert False, e

# Generated at 2022-06-24 13:17:08.352076
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert(tf1.ie_key() == 'TF1')

# Generated at 2022-06-24 13:17:11.503733
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:12.746593
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor of class TF1IE
    TF1IE(None)

# Generated at 2022-06-24 13:17:13.968854
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE(None)
    print(instance)

# Generated at 2022-06-24 13:17:15.523552
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == 'tf1'

# Generated at 2022-06-24 13:17:19.834772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(TF1IE.IE_NAME, False)._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-24 13:17:20.758110
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-24 13:17:23.554692
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:17:30.389894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert obj.url == "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert obj.program_slug == "koh-lanta"
    assert obj.slug == "replay-koh-lanta-22-mai-2015"

# Generated at 2022-06-24 13:17:31.298787
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj != None

# Generated at 2022-06-24 13:17:38.414103
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert not TF1IE.suitable('https://www.tf1.fr/')
    assert not TF1IE.suitable('https://www.tf1.fr/my-tf1/')

# Generated at 2022-06-24 13:17:39.768329
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.constructor_test()

# Generated at 2022-06-24 13:17:41.016278
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE([None])
    except TypeError:
        pass

# Generated at 2022-06-24 13:17:41.998587
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TODO: add this test
    pass

# Generated at 2022-06-24 13:17:43.034352
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)

# Generated at 2022-06-24 13:17:43.670088
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:17:44.644456
# Unit test for constructor of class TF1IE
def test_TF1IE():
    s = TF1IE()

# Generated at 2022-06-24 13:17:48.903120
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:49.621833
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'

# Generated at 2022-06-24 13:17:50.587840
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("test")

# Generated at 2022-06-24 13:17:51.079505
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-24 13:17:52.392471
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    TF1IE()

# Generated at 2022-06-24 13:18:02.884377
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_info = {
        "id": "13641379",
        "ext": "mp4",
        "title": "md5:f392bc52245dc5ad43771650c96fb620",
        "description": "md5:a02cdb217141fb2d469d6216339b052f",
        "upload_date": "20190611",
        "timestamp": 1560273989,
        "duration": 1738,
        "series": "Quotidien avec Yann Barthès",
        "tags": ["intégrale", "quotidien", "Replay"]
    }

# Generated at 2022-06-24 13:18:08.186764
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TF1IE.__init__
    inst = TF1IE()
    inst.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    inst.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    inst.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:18:10.728777
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL is not None
    assert t._TESTS is not None

# Generated at 2022-06-24 13:18:21.403262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    tf1IE.url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1IE.program_slug = 'quotidien-avec-yann-barthes'
    tf1IE.id = 'quotidien-premiere-partie-11-juin-2019'
    print("Testing TF1IE class constructor")
    assert tf1IE.url == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', "TF1IE class constructor failed"

# Generated at 2022-06-24 13:18:22.642779
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-24 13:18:22.989050
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:18:25.213260
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'