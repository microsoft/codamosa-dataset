

# Generated at 2022-06-24 13:08:26.044329
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except NameError:
        try:
            assert False
        except AssertionError:
            print("Class TF1IE is not defined")
        else:
            print("Class TF1IE is defined")
    else:
        print("Class TF1IE is defined")

# Generated at 2022-06-24 13:08:36.142890
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie_obj = TF1IE(1)
    expected_url = "https://www.tf1.fr/graphql/web"
    assert ie_obj._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"
    assert ie_obj._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie_obj._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-24 13:08:37.787680
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:08:38.492098
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.suite()

# Generated at 2022-06-24 13:08:43.574546
# Unit test for constructor of class TF1IE
def test_TF1IE():
    m = TF1IE("constructor")
    # Testing the _VALID_URL
    valid_urls = [("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"),
                  ("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"),
                  ("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"),
                  ]

    for url in valid_urls:
        m.is_suitable(url)
        # m.extract(url)

# Generated at 2022-06-24 13:08:44.174372
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:08:44.774876
# Unit test for constructor of class TF1IE
def test_TF1IE(): main(TF1IE())

# Generated at 2022-06-24 13:08:48.547752
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(None)
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:08:50.441021
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert isinstance(t, TF1IE)


# Generated at 2022-06-24 13:08:51.771748
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(None);
    assert(tf1ie is not None);

# Generated at 2022-06-24 13:08:59.903312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (TF1IE(None)._VALID_URL == 'r'
            '^(?P<proto>https?://)(?P<url>www\..+?\.fr)(?!/(?:videos|player)/)(?P<videoid>[0-9A-Za-z_-]+)$')
    assert TF1IE(None).suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert TF1IE(None).suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True

# Generated at 2022-06-24 13:09:00.426689
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-24 13:09:01.379391
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-24 13:09:05.109482
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:09:06.656401
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    print(t.__class__.__name__)

# Generated at 2022-06-24 13:09:17.837716
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class."""
    TF1IE = class_of(TF1IE)
    assert_greater(len(TF1IE.__name__), 0)
    assert_greater(len(TF1IE._VALID_URL), 0)
    assert_greater(len(TF1IE.__doc__), 0)
    assert_greater(len(TF1IE.IE_DESC), 0)
    assert_greater(len(TF1IE.ie_key()), 0)
    ie = TF1IE()
    assert_not_none(ie)
    assert_true(isinstance(ie, TF1IE))
    assert_true(isinstance(ie, InfoExtractor))
    assert_true(hasattr(ie, '_real_extract'))

# Generated at 2022-06-24 13:09:18.829820
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    print(tf1_ie._VALID_URL)

# Generated at 2022-06-24 13:09:19.633266
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'


# Generated at 2022-06-24 13:09:20.637479
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE();
    assert isinstance(ie,TF1IE) == True;

# Generated at 2022-06-24 13:09:21.433022
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-24 13:09:23.079521
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', print)

# Generated at 2022-06-24 13:09:23.882648
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None

# Generated at 2022-06-24 13:09:35.955386
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert not i.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html?query_string")
    assert i.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:09:40.260279
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor())._VALID_URL == \
        r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:09:43.323386
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test the constructor of class TF1IE
    """
    ie = TF1IE()

    # Test that the object actually implements the InfoExtractor interface
    assert ie.suitable("foo")

# Generated at 2022-06-24 13:09:44.209126
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('TF1IE')

# Generated at 2022-06-24 13:09:52.063449
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert(IE.__name__ == 'tf1')
    assert(IE.extract_url_from_string('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:10:01.795098
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE('TF1', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert(test.program_slug == 'tmc/quotidien-avec-yann-barthes')
    assert(test.slug == 'quotidien-premiere-partie-11-juin-2019')

# Generated at 2022-06-24 13:10:04.882208
# Unit test for constructor of class TF1IE
def test_TF1IE():
    for test, expected in TF1IE._TESTS:
        ie = TF1IE(test)
        assert ie.url == test
        assert tf1ie._TESTS[0] == expected

# Generated at 2022-06-24 13:10:12.003547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    i = TF1IE(url)
    assert i.valid_url == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

# Generated at 2022-06-24 13:10:13.125885
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE([])
    assert ie == type(ie)



# Generated at 2022-06-24 13:10:20.690389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie.IE_NAME == 'tf1.fr'
    assert tf1_ie.IE_DESC == 'TF1 (Télévision française 1)'
    assert tf1_ie.VALID_URL == TF1IE._VALID_URL
    assert tf1_ie.BRAND == TF1IE._BRAND
    assert tf1_ie.REAL_NAME == TF1IE._REAL_NAME
    assert TF1IE._TESTS


# Generated at 2022-06-24 13:10:26.202301
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert instance.url == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:10:36.091176
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor test
    assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True
    assert TF1IE.suitable('https://www.tf1.fr/mytf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert TF1IE.suitable('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == True

# Generated at 2022-06-24 13:10:37.024047
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    

# Generated at 2022-06-24 13:10:47.786588
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == (
        'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/'
        '(?P<id>[^/?&#]+)\.html'
    )

    ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-'
               '22-mai-2015.html')
    assert ie._VALID_URL == (
        'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/'
        '(?P<id>[^/?&#]+)\.html'
    )

# Generated at 2022-06-24 13:10:49.057744
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None


# Generated at 2022-06-24 13:10:53.036037
# Unit test for constructor of class TF1IE
def test_TF1IE():
    loader = TF1IE()
    # Load url
    loader.url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    loader._real_extract(loader.url) # no error == test passed

# Generated at 2022-06-24 13:10:59.738636
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    t = TF1IE(url)
    assert t._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'
    assert t._TESTS is not None
    assert t._TESTS[2]['only_matching']

# Generated at 2022-06-24 13:11:07.055471
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    request = TF1IE(url)
    assert request.video_id == '13641379'
    assert request.program_slug == 'quotidien-avec-yann-barthes'
    assert request.slug == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:11:08.238542
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from inspect import signature
    assert len(signature(TF1IE).parameters) == 1

# Generated at 2022-06-24 13:11:10.650332
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable(ie.IE_NAME, ie._VALID_URL)
    assert not ie.suitable(ie.IE_NAME, ie._VALID_URL + 'whatever')

# Generated at 2022-06-24 13:11:11.710886
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test functionality of the class constructor
    TF1IE()

# Generated at 2022-06-24 13:11:12.126990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:13.126941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE


# Generated at 2022-06-24 13:11:17.303772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:11:18.974061
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Unit tests for method _real_extract of class TF1IE

# Generated at 2022-06-24 13:11:20.585553
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(None, None)
    assert tf1 is not None

# Generated at 2022-06-24 13:11:21.283823
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:26.087748
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1IE = TF1IE(url)

    assert tf1IE.extract() is not None
    assert tf1IE.program_slug == 'quotidien-avec-yann-barthes'
    assert tf1IE.id == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-24 13:11:27.388768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE();

# Generated at 2022-06-24 13:11:29.808517
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:11:30.370457
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-24 13:11:36.213436
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_downloader import MockYDL
    assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not TF1IE.suitable('https://www.tf1.fr/')
    assert TF1IE.IE_NAME == 'tf1'
    assert TF1IE.IE_DESC == 'MyTF1'

# Generated at 2022-06-24 13:11:37.396806
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(InfoExtractor()), TF1IE)

# Generated at 2022-06-24 13:11:40.859680
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test TF1IE constructor"""
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:11:42.238480
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-24 13:11:42.828646
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:44.088306
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:11:46.731774
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from youtube_dl.utils import SearchInfoExtractor

    "Constructor of class TF1IE should create an instance of SearchInfoExtractor"
    assert isinstance(TF1IE(), SearchInfoExtractor)

# Generated at 2022-06-24 13:11:47.089178
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:53.245095
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE("www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    # test the constructor to make sure the regex is working
    assert IE.suitable("www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert not IE.suitable("www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:11:53.664847
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:11:56.905540
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return_value = TF1IE()
    assert return_value._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:06.368206
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t0 = TF1IE()
    
    # Calling the method extract with a valid video url as argument
    video1 = t0.extract("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert_equals(video1.get("id"), "11170896")
    assert_equals(video1.get("title"), "Koh Lanta")

    video2 = t0.extract("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert_equals(video2.get("id"), "13641379")

# Generated at 2022-06-24 13:12:08.140659
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE() # initializing variable
    tf1.constructor() # should not get an error


# Generated at 2022-06-24 13:12:10.743342
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('TF1IE', True)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-24 13:12:16.690714
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    URL = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert IE.match(URL)
    assert IE.get_id(URL) == 'a-koh-lanta-22-mai-2015'

# Generated at 2022-06-24 13:12:17.671416
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()


# Generated at 2022-06-24 13:12:20.357556
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-24 13:12:25.042802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .GenericIE import GenericIE
    from .GenericIE import test_GenericIE
    ie = TF1IE('wat:12345')
    assert isinstance(ie, GenericIE)
    assert ie._VALID_URL == TF1IE._VALID_URL
    assert ie._TESTS == TF1IE._TESTS
    test_GenericIE(ie)

# Generated at 2022-06-24 13:12:26.298053
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-24 13:12:35.709990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'
    #assert tf1.ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:12:37.385073
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._VALID_URL = None
    assert ie._download_webpage is not None
    assert ie._download_json is not None

# Generated at 2022-06-24 13:12:38.487391
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:12:39.279800
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x

# Generated at 2022-06-24 13:12:40.099030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie =  TF1IE()
    assert tf1_ie

# Generated at 2022-06-24 13:12:41.360365
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE().ie_key() == 'tf1')

# Generated at 2022-06-24 13:12:45.451850
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'



# Generated at 2022-06-24 13:12:55.569798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .wat import WATIE
    from .youtube import YoutubeIE
    youtube_ie = YoutubeIE()
    tf1_ie = TF1IE()
    assert tf1_ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1_ie == TF1IE._create_ie('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', youtube_ie)
    assert youtube_ie == TF1IE._create_ie('http://www.youtube.com/watch?v=BaW_jenozKc', youtube_ie)

# Generated at 2022-06-24 13:13:03.938299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(InfoExtractor(), 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:05.896453
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t=TF1IE()

# Generated at 2022-06-24 13:13:06.846555
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-24 13:13:07.763632
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-24 13:13:14.837230
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-24 13:13:19.461717
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor of tf1ie
    sample_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1_ie = TF1IE()
    # Test tf1ie._download_json for given url

# Generated at 2022-06-24 13:13:20.429759
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE.name == 'TF1'

# Generated at 2022-06-24 13:13:23.456995
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        assert False, "TF1IE class not accessible"


# Generated at 2022-06-24 13:13:30.885206
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == "https://www.tf1.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html"
    assert ie._TESTS[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert ie._TESTS[0]['params'] == {'skip_download': True, 'format': 'bestvideo'}

# Generated at 2022-06-24 13:13:31.774053
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert test != None

# Generated at 2022-06-24 13:13:32.480876
# Unit test for constructor of class TF1IE
def test_TF1IE():
	pass

# Generated at 2022-06-24 13:13:33.952366
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie.tf1ie()

# Generated at 2022-06-24 13:13:34.892938
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)

# Generated at 2022-06-24 13:13:43.064185
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:13:45.862723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test class has `_VALID_URL` attribute
    assert hasattr(TF1IE, '_VALID_URL') and isinstance(TF1IE._VALID_URL, str)

    # Test class has `IE_NAME` attribute and it's correct
    assert hasattr(TF1IE, 'IE_NAME') and TF1IE.IE_NAME == 'tf1'

# Generated at 2022-06-24 13:13:47.339903
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE("test")
    assert isinstance(x, TF1IE)

# Generated at 2022-06-24 13:13:49.887368
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_TF1IE = TF1IE("test case")
    assert(class_TF1IE)

# Generated at 2022-06-24 13:13:52.030471
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:\w+\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-24 13:13:53.182148
# Unit test for constructor of class TF1IE
def test_TF1IE():
	obj=TF1IE()

# Generated at 2022-06-24 13:13:54.703308
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None

# Generated at 2022-06-24 13:14:03.910054
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    ie.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    ie.suitable("http://www.tf1.fr/on-nest-pas-que-des-cobayes/videos/on-nest-pas-que-des-cobayes-c-est-pas-sorcier-.html")

    ie.extract("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:14:09.492823
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Set up unit test
    extractor = TF1IE()
    # Run unit test
    extractor._real_extract(
        url="https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert extractor is not None, "Failed to create TF1IE"

# Generated at 2022-06-24 13:14:19.126428
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:14:23.219168
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-24 13:14:23.865271
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:14:29.250788
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert obj.IE_NAME == 'tf1'
    assert obj.IE_DESC == 'TF1'

# Generated at 2022-06-24 13:14:30.937854
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for TF1IE
    """
    test_TF1IE = TF1IE()
    assert 1

# Generated at 2022-06-24 13:14:40.210462
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie._VALID_URL == r'^https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html$'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie._TESTS[0]['info_dict']['id'] == '13641379'
   

# Generated at 2022-06-24 13:14:43.419109
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Testing creating TF1IE instance")
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:14:44.924501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    print('TF1IE initialized.')
    return


# Generated at 2022-06-24 13:14:46.320983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(None)
    assert tf1.IE_NAME == TF1IE.ie_key()

# Generated at 2022-06-24 13:14:47.200454
# Unit test for constructor of class TF1IE
def test_TF1IE():
    WatIE(TF1IE, ['-f', 'bestvideo'])

# Generated at 2022-06-24 13:14:56.902413
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert not t.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert t.suitable("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-24 13:15:06.744211
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class args:
        def __init__(self):
            self.age_limit=None
            self.download_with_rtmpdump=False
            self.fatal_warnings=False
            self.format=None
            self.include_ads=False
            self.no_warnings=False
            self.noplaylist=False
            self.playlist_items=None
            self.playlist_reverse=False
            self.playlist_start=1
            self.playlistend=None
            self.postprocessors=None
            self.progress_with_newline=False
            self.proxy=None
            self.ratelimit=None
            self.retries=10
            self.skip_download=False
            self.test=False
            self.verbose=False
            self.xattr_set_files

# Generated at 2022-06-24 13:15:09.543073
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/plus-belle-la-vie/videos/plus-belle-la-vie-episode-3786.html')

# Generated at 2022-06-24 13:15:11.859766
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    assert TF1IE()._TESTS == TF1IE._TESTS

# Generated at 2022-06-24 13:15:18.694761
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.IE_NAME
    assert ie.IE_NAME == 'tf1'
    ie.IE_DESC
    assert ie.IE_DESC == 'tf1.fr'
    ie._VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    ie._TESTS

# Test for real_extract method of class TF1IE

# Generated at 2022-06-24 13:15:29.659736
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1 = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert test_TF1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert test_TF1._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-24 13:15:30.232532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:15:31.705437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.tf1ie_has_been_tested == 1

# Generated at 2022-06-24 13:15:43.970610
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test TF1IE constructor
    tf1 = TF1IE()
    assert tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:15:48.173509
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-24 13:15:51.386520
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .tf1 import TF1IE
    assert TF1IE(TF1IE.IE_NAME, 'http://safds.fr').get_name() == TF1IE.IE_NAME

# Generated at 2022-06-24 13:15:55.417535
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not info_extractor.suitable('https://www.tf1.fr/')

# Generated at 2022-06-24 13:15:57.282854
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor of class TF1IE
    TF1IE(None, 'TF1IE', {})

# Generated at 2022-06-24 13:15:58.563860
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE
    assert ie.__name__ == 'TF1IE'

# Generated at 2022-06-24 13:16:01.960821
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE","https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")


# Generated at 2022-06-24 13:16:02.614169
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-24 13:16:10.103702
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_main import main
    import sys
    url = sys.argv[1]
    if main(TF1IE, {'url': url, 'origin': 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes'}) is not None:
        print("Extraction succeeded")
    else:
        print("Extraction failed")

if __name__ == '__main__':
    import sys
    test_TF1IE()
    sys.exit(0)

# Generated at 2022-06-24 13:16:14.751446
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    test_url = TF1IE.test.test_download_test(TF1IE, url)
    test_url.testIfSuccess()

# Generated at 2022-06-24 13:16:15.868675
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

# Generated at 2022-06-24 13:16:17.252376
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('<url>')

# Generated at 2022-06-24 13:16:26.314879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test for TF1IE constructor."""
    info_extractor = TF1IE('www')
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:37.049658
# Unit test for constructor of class TF1IE
def test_TF1IE():
	
	x = TF1IE()
	s = 'TEST'
	y = x.suitable(s)
	print ("Test for method suitable returned: " + str(y))
	assert(y == False)
	
	x = TF1IE()
	s = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
	y = x.suitable(s)
	print ("Test for method suitable returned: " + str(y))
	assert(y == True)
	
	x = TF1IE()

# Generated at 2022-06-24 13:16:38.332666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-24 13:16:48.986148
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE ("1")
    assert i._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:52.743058
# Unit test for constructor of class TF1IE
def test_TF1IE():
    mytf1ie = TF1IE()
    assert mytf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:16:53.570347
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None).download('wat:0000000000')

# Generated at 2022-06-24 13:16:54.385789
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(1)

# Generated at 2022-06-24 13:16:56.560571
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-24 13:16:58.950843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_common import TEST_TF1, construct_IE
    ie = construct_IE(TF1IE.ie_key())
    assert isinstance(ie, TF1IE) == True
    ie_test = ie.suitable(TEST_TF1)
    assert ie_test == True

# Generated at 2022-06-24 13:17:01.389171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:17:02.296879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-24 13:17:05.712712
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()
    assert(a._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+?)\\.html')

# Generated at 2022-06-24 13:17:06.239234
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.test()


# Generated at 2022-06-24 13:17:07.792524
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # TODO: write tests

# Generated at 2022-06-24 13:17:09.088671
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This constructed object shall not raise an exception
    TF1IE('foo', 'http://www.wat.tv/foo')

# Generated at 2022-06-24 13:17:19.053846
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:29.045597
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Add a test case for TF1IE ie
    ie = "TF1IE()"
    # Valid inputs
    valid_urls = [
        "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html",
        "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
        "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html",
    ]
    # Invalid inputs

# Generated at 2022-06-24 13:17:30.815639
# Unit test for constructor of class TF1IE
def test_TF1IE():
    myTest = TF1IE("TF1IE", "tf1.fr")
    assert myTest.ie_key() == 'TF1'

# Generated at 2022-06-24 13:17:31.377118
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:17:34.112017
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', {})
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-24 13:17:38.006830
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-24 13:17:42.098826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit testing for TF1IE class constructor
    """
    info = TF1IE("tf1ie", "TF1IE")
    assert "TF1IE" == info.IE_NAME
    assert "tf1ie" == info.ie_key()
    assert "TF1IE" == info.ie_key()

# Generated at 2022-06-24 13:17:45.757492
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE('%s')" % ('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'))


# Generated at 2022-06-24 13:17:47.646056
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE({})
    assert isinstance(instance, TF1IE)

# Generated at 2022-06-24 13:17:48.229577
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-24 13:17:51.098647
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from youtube_dl.extractor import gen_extractor_classes
    tf1ie = next((c for c in gen_extractor_classes() if c.IE_NAME == 'tf1'))
    assert tf1ie is not None

# Generated at 2022-06-24 13:17:57.746703
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:SzJZG1HrrIP1OuYIjwQ4')
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-24 13:18:06.238169
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie.url == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert ie.valid()
    assert ie.get_id() == "13641379"
    assert ie.get_title() == "md5:f392bc52245dc5ad43771650c96fb620"
    assert ie.get_description() == "md5:a02cdb217141fb2d469d6216339b052f"
   

# Generated at 2022-06-24 13:18:08.559263
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie_instance = TF1IE()
    assert tf1ie_instance is not None
    assert isinstance(tf1ie_instance, TF1IE)

# Generated at 2022-06-24 13:18:10.727518
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert "TF1IE" == IE.ie_key()

# Generated at 2022-06-24 13:18:21.403541
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    test constructor of class TF1IE
    """
    temp = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert(temp._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html")
    assert(temp._TESTS[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-24 13:18:24.416483
# Unit test for constructor of class TF1IE
def test_TF1IE():
	ie = TF1IE()
	assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'