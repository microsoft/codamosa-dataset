

# Generated at 2022-06-26 12:41:41.872580
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_0 = TF1IE()


# Generated at 2022-06-26 12:41:44.268482
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:41:44.915754
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:41:46.301825
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:41:49.689091
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        # Unit test for constructor of class TF1IE
        test_case_0()
    except:
        print("Error")

# Generated at 2022-06-26 12:41:52.843249
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert t_f1_i_e_0 == t_f1_i_e_0


# Generated at 2022-06-26 12:41:57.680692
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Positive case
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    try:
        TF1IE(url)
    except Exception as e:
        print(e)

    # Negative case
    try:
        TF1IE(url + 'abc')
    except Exception as e:
        print(e)


# Generated at 2022-06-26 12:41:58.006394
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:42:09.391440
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    # Assertion of type of instance:
    # Here we test if the type of the instance is TF1IE
    assert isinstance(t_f1_i_e, TF1IE)
    # Assertion of the values and types of the instance:
    # Here we test if the instance has the given value and type
    # of each of its attributes
    assert t_f1_i_e.name == "TF1"
    assert isinstance(t_f1_i_e.name, str)

# Generated at 2022-06-26 12:42:14.305226
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    t_f1_i_e_0.developer_key = t_f1_i_e.developer_key  # need to assign developer_key to test constructor TF1IE


# Generated at 2022-06-26 12:42:21.907389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE()
    pass # TO BE MODIFIED



# Generated at 2022-06-26 12:42:22.519447
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-26 12:42:31.423881
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._LOGIN_URL == 'https://www.tf1.fr/tf1/identifiants/connexion.html'
    assert TF1IE(None)._LOGIN_FORM_URL == 'https://www.tf1.fr/graphql/web'
    assert TF1IE(None)._LOGIN_FORM_ID == 'ae66a6a9e1b9efb3dfc0a1a5051eab402ebc879076f38de0f0678d945e9a8a6b'
    assert TF1IE(None)._LOGIN_FORM_VARIABLE_NAME == 'login'
    assert TF1IE(None)._LOGIN_FORM_KEY_NAME == 'password'

# Generated at 2022-06-26 12:42:32.826498
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(object)

# Generated at 2022-06-26 12:42:35.060665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(None)  # instance of class TF1IE
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-26 12:42:36.789749
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()
    assert(result.IE_NAME == 'tf1')

# Generated at 2022-06-26 12:42:37.865506
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t is not None


# Generated at 2022-06-26 12:42:38.636338
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:42:47.268441
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = TF1IE()
    assert tester._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:48.693883
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE, type)

# Generated at 2022-06-26 12:43:01.138550
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-26 12:43:04.371909
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    print(ie._VALID_URL)
    print(ie._TESTS)
    print(ie._real_extract)

# Generated at 2022-06-26 12:43:11.656124
# Unit test for constructor of class TF1IE
def test_TF1IE():
  tf1_ie_valid_url = TF1IE._VALID_URL
  assert tf1_ie_valid_url == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:14.111436
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)


# Generated at 2022-06-26 12:43:17.070683
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = TF1IE._TESTS[0]['url']
    info_extractor = TF1IE()
    assert info_extractor.suitable(test_url) == True
    assert info_extractor._real_extract(test_url) == TF1IE._TESTS[0]['info_dict']
    assert info_extractor.IE_NAME == 'tf1'

# Generated at 2022-06-26 12:43:18.035152
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:20.258582
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 != None

# Generated at 2022-06-26 12:43:21.664922
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()

# Generated at 2022-06-26 12:43:30.753294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-26 12:43:35.793499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(1, url=None)
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:59.540400
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-26 12:44:00.980851
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:13641379')

# Generated at 2022-06-26 12:44:08.145179
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test link with subtitles
    instance = TF1IE()
    instance._real_initialize()
    instance._real_extract("http://www.tf1.fr/tf1/grand-public/videos/premiere-partie-01-mars-2016.html")
    # Test link without subtitles
    instance = TF1IE()
    instance._real_initialize()
    instance._real_extract("http://www.tf1.fr/tf1/grand-public/videos/replay-premiere-partie-01-mars-2016.html")

# Generated at 2022-06-26 12:44:11.293308
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie._real_initialize()
    assert True

# Generated at 2022-06-26 12:44:13.403559
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL.find('://') > 0

# Generated at 2022-06-26 12:44:23.657140
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('video/tf1ie.py')
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1ie._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-26 12:44:33.761167
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test if working on a basic TF1 video http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html
    """

    # Create instance of class TF1IE
    ie = TF1IE(None)

    # Test if instance variable _VALID_URL is set with correct url
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

    # Test if TESTS are not empty
    assert len(ie._TESTS) > 0

    test = ie._TESTS[0]

# Generated at 2022-06-26 12:44:34.800862
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Check that the test in the test file actually works

# Generated at 2022-06-26 12:44:35.865512
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.TF1IE_constructor()

# Generated at 2022-06-26 12:44:39.885427
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE()._build_constructor_test(lambda: TF1IE(), 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:45:33.553644
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert "TF1IE" in str(type(TF1IE))

# Generated at 2022-06-26 12:45:38.951560
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._TESTS[0]['info_dict']['id'] == '13641379'
    assert TF1IE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:45:41.202982
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE().suitable(url)

# Generated at 2022-06-26 12:45:44.786996
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:45:46.485950
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE(None, None)
    except TypeError:
        return
    assert False

# Generated at 2022-06-26 12:45:49.026844
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://videotheque.tf1.fr/videos/une/emissions/13641379/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:45:50.509280
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == 'TF1'

# Generated at 2022-06-26 12:45:53.555942
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')


# Generated at 2022-06-26 12:45:55.260309
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor: TF1IE(IE_NAME, True)
    assert isinstance(TF1IE('TF1', True), TF1IE)

# Generated at 2022-06-26 12:45:57.115299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'
    assert tf1.IE_DESC == 'tf1.fr'

# Generated at 2022-06-26 12:48:09.929555
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE(None)
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:48:11.105355
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert repr(ie) == '<TF1IE>'

# Generated at 2022-06-26 12:48:12.483671
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructing unit tests of TF1IE.
    """
    return TF1IE

# Generated at 2022-06-26 12:48:12.980656
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:17.866547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    e = TF1IE()
    e.suitable(url)
    e.extract(url)
    return e


# Generated at 2022-06-26 12:48:18.488992
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:48:19.319900
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x

# Generated at 2022-06-26 12:48:25.611486
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()

# Generated at 2022-06-26 12:48:26.879218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("1", "2", "3") # using 3 arguments only

# Generated at 2022-06-26 12:48:28.746037
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')