

# Generated at 2022-06-26 12:41:42.019848
# Unit test for constructor of class TF1IE
def test_TF1IE():

    TF1IE()


# Generated at 2022-06-26 12:41:43.812807
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()


# Generated at 2022-06-26 12:41:46.587559
# Unit test for constructor of class TF1IE

# Generated at 2022-06-26 12:41:50.394188
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_TF1IE()

# Generated at 2022-06-26 12:41:53.230299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test_case_0
    t_f1_i_e_0 = TF1IE()

# Generated at 2022-06-26 12:41:55.186472
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:42:08.477239
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:08.859672
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:42:10.273751
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-26 12:42:16.828860
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Init class
    t_f1_i_e_0 = TF1IE()
    # Test variable
    assert t_f1_i_e_0._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:23.330916
# Unit test for constructor of class TF1IE
def test_TF1IE():
    s = TF1IE()
    assert s

# Generated at 2022-06-26 12:42:24.678657
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, None)

# Generated at 2022-06-26 12:42:26.297328
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("TF1IE")

# Generated at 2022-06-26 12:42:27.534035
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:42:32.966559
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert isinstance(tf1IE, TF1IE)

# Generated at 2022-06-26 12:42:35.469811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Instantiate a TF1IE object."""
    TF1IE('TF1IE', 'TF1')

# Generated at 2022-06-26 12:42:36.790620
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-26 12:42:38.165378
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert (ie.name =="TF1")



# Generated at 2022-06-26 12:42:42.271266
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.ie_key() == 'TF1'
    assert i.IE_NAME == 'TF1'
    assert i.ie_codec() == 'wat'

# Generated at 2022-06-26 12:42:46.815491
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    result = TF1IE._build_url_result(url)
    assert result == ['13641379', 'quotidien-premiere-partie-11-juin-2019']

# Generated at 2022-06-26 12:43:04.455333
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_constructor = getattr(TF1IE, 'suitable')
    assert class_constructor(TF1IE({})._build_url(
        'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ))

# Generated at 2022-06-26 12:43:06.010482
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract("")

# Generated at 2022-06-26 12:43:14.317503
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie_test = TF1IE()
    assert ie_test.ie_key() == 'TF1'
    assert ie_test.ie_slug() == 'tf1'
    assert ie_test.suitable() == None
    # assert ie_test.describe() == 'décrit la vidéo'
    assert ie_test.get_url_re() == ie_test._VALID_URL

# Generated at 2022-06-26 12:43:17.232312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert instance._downloader is None
    assert instance._match_id is None
    assert instance._WORKING is True

# Generated at 2022-06-26 12:43:26.010390
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    # url
    url_expected = 'https://www.tf1.fr/graphql/web'
    url_real = tf1_ie._download_json('https://www.tf1.fr/graphql/web')
    assert url_expected == url_real

# Generated at 2022-06-26 12:43:37.903459
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE._download_json = lambda *args, **kwargs: {}
    test_obj = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert test_obj.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not test_obj.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie.html')

# Generated at 2022-06-26 12:43:38.711359
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:43:40.601082
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor(), '', {})._real_extract('')

# Generated at 2022-06-26 12:43:44.636109
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Getting an example TV show
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

    # Checking if the class TF1IE can be instantiated with the URL
    TF1IE(url)

# Generated at 2022-06-26 12:43:46.420972
# Unit test for constructor of class TF1IE
def test_TF1IE():
    abr = TF1IE()

# Generated at 2022-06-26 12:44:09.561709
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:15.017922
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:18.843363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.IE_NAME == 'TF1'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:19.770325
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

# Generated at 2022-06-26 12:44:21.545763
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # should not raise
    TF1IE()


# Generated at 2022-06-26 12:44:22.634748
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('1234')._VALID_URL

# Generated at 2022-06-26 12:44:23.871564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.__new__(TF1IE, url=URL)

# Generated at 2022-06-26 12:44:27.496994
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.ie_key() == 'tf1'
    assert IE.ie_code() == 'TF1'
    assert IE.info_domain() == 'tf1.fr'



# Generated at 2022-06-26 12:44:32.627091
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not TF1IE('https://wat.tf1.fr/wat/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:44:38.073545
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert isinstance(tf1, InfoExtractor)
    assert isinstance(tf1, TF1IE)
    assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1.IE_NAME == 'TF1'
    assert tf1.IE_DESC == 'TF1.fr'

# Generated at 2022-06-26 12:45:35.168162
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:45:36.104086
# Unit test for constructor of class TF1IE
def test_TF1IE():
    for url in TESTS_TF1IE:
        print(url['url'])

# Generated at 2022-06-26 12:45:38.504081
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert 'videos/mylene-farmer-d-une-icone.html' in str(i)
    assert 'https://www.youtube.com/watch?v=oHg5SJYRHA0' not in str(i)

# Generated at 2022-06-26 12:45:45.737791
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for the TF1IE class"""
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert TF1IE._VALID_URL == re.compile(TF1IE._VALID_URL, re.VERBOSE | re.DOTALL)
    assert TF1IE._TESTS[0]["url"] == url
    assert TF1IE._TESTS[0]["id"] == "13641379"
    assert TF1IE._TESTS[0]["ext"] == "mp4"

# Generated at 2022-06-26 12:45:50.237693
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE
    instance = class_()
    assert isinstance(instance, InfoExtractor)
    assert hasattr(instance, "_download_json")
    assert hasattr(instance, "_real_extract")
    assert hasattr(instance, "_VALID_URL")
    assert hasattr(instance, "_TESTS")

# Generated at 2022-06-26 12:45:50.740926
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:45:54.931223
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert t.program_slug == 'koh-lanta'
    assert t.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-26 12:45:57.745607
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.match_url("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert not t.match_url("http://www.tf1.fr/")

# Generated at 2022-06-26 12:46:08.733646
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.download_webpage = MagicMock()
    ie.extract_info = MagicMock()
    program_slug = 'program_slug'
    slug = 'slug'
    ie.download_webpage.return_value = {
        'data': {
            'videoBySlug': {
                'streamId': '123',
            }
        }
    }
    ie.extract_info.assert_not_called()
    ie._real_extract(ie._VALID_URL)

# Generated at 2022-06-26 12:46:16.581779
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    # Check TF1IE object implements the correct interface
    from youtube_dl.extractor import InfoExtractor
    assert isinstance(TF1IE(), InfoExtractor)

    # Check whether the provided url is valid
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert TF1IE._VALID_URL(url)
    assert TF1IE(url)

    # Check whether the provided url is not valid
    url = "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    assert TF1IE._VALID_URL(url)


# Generated at 2022-06-26 12:48:37.371068
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(None)
    assert tf1ie._VALID_URL == (r'https?://(?:www\.)?tf1\.fr/'
                                r'[^/]+/(?P<program_slug>[^/]+)/'
                                r'videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-26 12:48:45.622169
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from unittest import TestCase
    from sys import version_info as python_version
    from io import StringIO, BytesIO

    class TF1IETestCase(TestCase):

        def setUp(self):
            self.ie = TF1IE()

        def test_tf1ie(self):
            tmc_url = 'http://www.tf1.fr/tmc/koh-lanta/videos/'
            www_tf1_fr_content = '<div><ul class="tf1-menu__list"><li><a href="{url}">Koh-Lanta</a></li></ul></div>'.format(url=tmc_url)

# Generated at 2022-06-26 12:48:48.695072
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:48:49.466717
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()

# Generated at 2022-06-26 12:48:58.288442
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_downloader import TestDownloader
    from .test_format_selection import FormatsList
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..downloader.http import HttpRequest

    class MockHttpFD(HttpFD):
        def _do_download(self, *args, **kwargs):
            content = b'{"status":200}'
            return content, {'content-type': 'application/json'}

    class MockFileDownloader(FileDownloader):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            FileDownloader.__init__(self, *args, **kwargs)


# Generated at 2022-06-26 12:48:59.318295
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    tf1 = TF1IE()

# Generated at 2022-06-26 12:49:02.136012
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    No test for this class.
    """
    # Test example from https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/tf1.py
    #
    # No other test examples in git

# Generated at 2022-06-26 12:49:05.394531
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')


# Generated at 2022-06-26 12:49:06.116166
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    print(ie)

# Generated at 2022-06-26 12:49:07.467630
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE != None