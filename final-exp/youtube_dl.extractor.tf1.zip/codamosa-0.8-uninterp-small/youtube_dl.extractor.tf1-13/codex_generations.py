

# Generated at 2022-06-26 12:41:49.829106
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None
    assert isinstance(TF1IE._VALID_URL, str)
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS is not None
    assert isinstance(TF1IE._TESTS, list)
    assert TF1IE._TESTS is not []

# Generated at 2022-06-26 12:41:51.543411
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_case_0()

# Generated at 2022-06-26 12:41:53.762485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert test_case_0() == None


# Generated at 2022-06-26 12:41:55.144477
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:42:08.449527
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    t_f1_i_e_1 = TF1IE()
    assert t_f1_i_e_1._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-26 12:42:10.206449
# Unit test for constructor of class TF1IE
def test_TF1IE():
	return None


# Generated at 2022-06-26 12:42:19.008615
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().is_suitable_url("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert TF1IE().is_suitable_url("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert TF1IE().is_suitable_url("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")


# Generated at 2022-06-26 12:42:19.345911
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-26 12:42:22.280434
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert t_f1_i_e


# Generated at 2022-06-26 12:42:23.689833
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert callable(TF1IE)

# Generated at 2022-06-26 12:42:36.715480
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This test is meant to detect errors with the construction of the
    # TF1IE class, rather than its execution.

    # pylint: disable=unused-variable
    TF1IE("wat:b", "wat", "wat")
    # Make sure this does not raise an error
    TF1IE("wat:b", "wat", "wat", "wat")

    # Dummy extraction
    TF1IE("wat:b", "wat", "wat", "wat").extract("wat:b")

# Generated at 2022-06-26 12:42:38.989666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:42:39.448550
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:42:47.848435
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == url
    assert ie._TESTS[0]['only_matching'] == False
    assert ie._TESTS[1]['only_matching'] == True
    assert ie._TESTS[2]['only_matching'] == True

# Generated at 2022-06-26 12:42:54.202297
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:58.670492
# Unit test for constructor of class TF1IE
def test_TF1IE():
    URL = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    result = TF1IE._build_url_result(URL)
    expected = ('koh-lanta', 'replay-koh-lanta-22-mai-2015')
    assert result == expected

# Generated at 2022-06-26 12:43:03.022917
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert TF1IE.__name__ == "TF1IE"
    assert tf1_ie != None
    assert tf1_ie.ie_key() == 'TF1'

# Generated at 2022-06-26 12:43:08.510659
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE(url)._VALID_URL == url
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    assert TF1IE(url)._VALID_URL == url

# Generated at 2022-06-26 12:43:16.557342
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Simple URL
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # Get the unit under test
    uut = TF1IE()
    # Get the information about the URL
    result = uut.extract(url)
    # Print the result for debugging
    print(result)

# Run the unit test from the command line
if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-26 12:43:22.700357
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("")
    assert tf1ie._VALID_URL == "https?://(?:www\.)?tf1\.fr/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-26 12:43:34.672277
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Return a TF1IE instance
    '''
    tf1 = TF1IE()
    assert isinstance(tf1, TF1IE)

# Generated at 2022-06-26 12:43:42.429490
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    t1 = TF1IE(url)
    print(t1.VALID_URL)
    print(t1.TESTS)
    print(t1.IE_NAME)
    print(t1.BRIGHTCOVE_URL_TEMPLATE)

# Generated at 2022-06-26 12:43:43.324081
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE("test", "test").__class__ == TF1IE

# Generated at 2022-06-26 12:43:43.822803
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_test_instance = TF1IE()

# Generated at 2022-06-26 12:43:45.149382
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
assert(tf1)

# Generated at 2022-06-26 12:43:54.157655
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE(
        tf1s_url='https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'
    

# Generated at 2022-06-26 12:43:59.476361
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:44:00.335601
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:01.209965
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:05.264864
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create a new instance of class TF1IE
    TF1IE_instance = TF1IE()

    # Checks if the instance created is of type TF1IE
    assert isinstance(TF1IE_instance, TF1IE)

# Generated at 2022-06-26 12:44:27.572889
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:28.897130
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    print(test_TF1IE)



# Generated at 2022-06-26 12:44:31.534770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:44:32.826516
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE("TF1IE")

    assert instance.ie_key() == "TF1"



# Generated at 2022-06-26 12:44:35.249428
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:44:37.616184
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert TF1IE._VALID_URL == info_extractor._VALID_URL



# Generated at 2022-06-26 12:44:38.496050
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE(None)

# Generated at 2022-06-26 12:44:40.511558
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert type('tf1IE') == str

# Generated at 2022-06-26 12:44:50.059892
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE().extract_info(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        download=False,
    )
    assert info.get('id') == '13641379'
    assert info.get('ext') == 'mp4'
    assert info.get('title') == 'Quotidien - Première partie (11/06/2019)'
    assert info.get(
        'description') == 'Le décryptage de Yann Barthès avec son équipe d’experts : une quotidienne indispensable pour comprendre l\'actualité !'
    assert info.get('upload_date') == '20190611'


# Generated at 2022-06-26 12:45:01.123003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:45:59.594768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    res = TF1IE(_download_json, "https://www.tf1.fr/graphql/web", None)
    assert(res.WAT_URL == "https://wat.tf1.fr/");

# Generated at 2022-06-26 12:46:01.818136
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class constructor of TF1IE"""
    tf1 = TF1IE()
    assert isinstance(tf1, TF1IE)

# Generated at 2022-06-26 12:46:04.146073
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Testing TF1IE constructor")
    try:
        TF1IE()
        print("Test for TF1IE constructor succeeded")
    except:
        print("Test for TF1IE constructor failed")


# Generated at 2022-06-26 12:46:09.051841
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:46:14.171104
# Unit test for constructor of class TF1IE
def test_TF1IE():
    for url in ['http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html',
                'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html']:
        assert TF1IE(TF1IE.IE_NAME, {}).extract({'url': url}) == {'url_transparent': True}

# Generated at 2022-06-26 12:46:14.953038
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie

# Generated at 2022-06-26 12:46:18.215556
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE_instance = TF1IE()
    assert tf1IE_instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:28.018206
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE(InfoExtractor())
    result = tf1IE._real_extract(url='https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
                                 ie=InfoExtractor())
    assert(result['_type'] == 'url_transparent')
    assert(result['id'] == '13641379')
    assert(result['url'] == 'wat:13641379')
    assert(result['title'] == 'md5:f392bc52245dc5ad43771650c96fb620')
    assert(result['description'] == 'md5:a02cdb217141fb2d469d6216339b052f')

# Generated at 2022-06-26 12:46:28.539720
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-26 12:46:30.305281
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-26 12:48:47.924873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    print("Unit test success")

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-26 12:48:49.321513
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE(None)
    assert i.name == 'tf1'


# Generated at 2022-06-26 12:48:50.437715
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

# Generated at 2022-06-26 12:48:53.391704
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:48:54.991965
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert(TF1IE)
    except NameError:
        raise AssertionError("Class TF1IE not implemented")


# Generated at 2022-06-26 12:48:56.258694
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert(tf1IE is not None)

# Generated at 2022-06-26 12:49:03.611162
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for test_TF1IE
    tf1IE = TF1IE('extractor')
    assert tf1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1IE.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:49:06.052037
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('md5:3b3f9a9eec6c95b6fb8d6e21e6d1b6f8')

# Generated at 2022-06-26 12:49:14.096708
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import pprint
    pp = pprint.PrettyPrinter(indent=4)
    tf1ie = TF1IE()

    try:
        from subprocess import getoutput
    except:
        from commands import getoutput
    def _get_wget_output(url):
        return getoutput('wget -O - -q "' + url + '"')


# Generated at 2022-06-26 12:49:14.806710
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()