

# Generated at 2022-06-26 12:41:48.044937
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    t_f_1_i_e = TF1IE()
    actual_result = t_f_1_i_e.suitable(url)
    expected_result = True
    assert actual_result == expected_result


# Generated at 2022-06-26 12:41:58.376791
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert t_f1_i_e_0._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t_f1_i_e_0.__name__ == 'TF1IE'
    assert t_f1_i_e_0.IE_NAME == 'tf1'
    assert t_f1_i_e_0.IE_DESC == 'Clip TF1'

# Generated at 2022-06-26 12:42:02.585197
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # 1
    t_f1_i_e_1 = TF1IE()

    assert isinstance(t_f1_i_e_1, TF1IE)


# Generated at 2022-06-26 12:42:04.124723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert 'TF1IE'


# Generated at 2022-06-26 12:42:06.291084
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert t_f1_i_e is not None

# Generated at 2022-06-26 12:42:07.882123
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() is not None


# Generated at 2022-06-26 12:42:10.409914
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()



# Generated at 2022-06-26 12:42:15.923972
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-26 12:42:16.600118
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert not TF1IE

# Generated at 2022-06-26 12:42:29.106559
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # login = 'test_user'
    # password = 'test_password'
    # video_id = 'test_video_id'
    # url = 'test_url'
    # video_password = 'test_video_password'
    # video_url = 'test_video_url'
    # title = 'test_title'
    # thumbnail = 'test_thumbnail'
    # uploader = 'test_uploader'
    # uploader_id = 'test_uploader_id'
    # upload_date = 'test_upload_date'
    # description = 'test_description'
    # player_url = 'test_player_url'
    t_f1_i_e = TF1IE()
    # assert(t_f1_i_e.login == login), 'Got ' + t_f1

# Generated at 2022-06-26 12:42:38.633251
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie_tf1 = TF1IE('TF1IE', True, {'network_module': 'tf1'})
    assert ie_tf1.name == 'TF1IE'

# Generated at 2022-06-26 12:42:42.986732
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(TF1IE._VALID_URL,
                    'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')




# Generated at 2022-06-26 12:42:45.640837
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/.*/videos/.*\.html'

# Generated at 2022-06-26 12:42:58.323077
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_test = TF1IE(None)
    assert TF1IE_test._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html',\
        'TF1IE _VALID_URL ERROR (1)'
    assert TF1IE_test._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', \
        'TF1IE _TESTS[0][\'url\'] ERROR (1)'

# Generated at 2022-06-26 12:43:04.851802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This test only check if the constructor work,
    t = TF1IE()
    # Test if t is an instance of InfoExtractor and of TF1IE
    assert isinstance(t, InfoExtractor)
    assert isinstance(t, TF1IE)
    # Test the output of t.ie_key()
    assert t.ie_key() == "TF1"


# Generated at 2022-06-26 12:43:12.068665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for the construction of TF1IE
    """
    from .common import InfoExtractor
    from .generic_downloader import GenericIE

    TestTF1IE = type('TestTF1IE', (TF1IE, InfoExtractor, GenericIE), {'_real_extract': lambda x, y: x})

    TestTF1IE({})

# Generated at 2022-06-26 12:43:13.651930
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE(InfoExtractor())
    info_extractor.suitable(TF1IE._VALID_URL)
    assert(1==1)

# Generated at 2022-06-26 12:43:14.499076
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-26 12:43:17.508904
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None
    assert tf1ie.IE_NAME == 'tf1'

# Generated at 2022-06-26 12:43:19.250384
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-26 12:43:35.669966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie.IE_NAME == 'tf1'

# Generated at 2022-06-26 12:43:36.472479
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:37.964222
# Unit test for constructor of class TF1IE
def test_TF1IE():
	y = TF1IE()


# Generated at 2022-06-26 12:43:38.780616
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:40.678341
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE('wat:123') == TF1IE('wat:123'))

# Generated at 2022-06-26 12:43:42.016178
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check that the class initialization works
    assert TF1IE

# Generated at 2022-06-26 12:43:48.420823
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:57.653917
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:02.939933
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', True)

# Generated at 2022-06-26 12:44:03.466682
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE();
    ie.extract();

# Generated at 2022-06-26 12:44:32.256861
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.program_slug == 'koh-lanta' and ie.slug == 'replay-koh-lanta-22-mai-2015'



# Generated at 2022-06-26 12:44:33.412364
# Unit test for constructor of class TF1IE
def test_TF1IE():
	print("In test_TF1IE")
	TF1IE()


# Generated at 2022-06-26 12:44:34.218796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE','TEST',1)

# Generated at 2022-06-26 12:44:44.316285
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert isinstance(tf1_ie, TF1IE)
    assert tf1_ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1_ie.IE_NAME == 'tf1'
    assert tf1_ie.NAME == 'TF1'
    assert re.match(tf1_ie._VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:44:52.272985
# Unit test for constructor of class TF1IE

# Generated at 2022-06-26 12:44:52.810903
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:56.515918
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE(url)

# Generated at 2022-06-26 12:44:57.810120
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-26 12:45:03.468880
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # create an instance of the TF1IE class
    tf1_instance = TF1IE()

    # check if the url attribute has been set
    assert tf1_instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:45:07.738436
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.get_url() == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'


# Generated at 2022-06-26 12:46:15.162851
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Tests an example ID
    example_id = TF1IE("https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert example_id == "https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html", "ID is incorrect"
    assert example_id.title == "Mylène Farmer, d'une icône...", "Title is incorrect"
    assert example_id.description == "Qui est cette reine de la pop qui, malgré le temps qui passe, fascine toujours les Français ?", "Description is incorrect"
    assert example_id.upload_date == "20191025", "Upload date is incorrect"

# Generated at 2022-06-26 12:46:17.329001
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie.name == "TF1")
    assert(ie.suitable == "general")
    assert(ie.ie_key() == "TF1")
    assert(ie.age_limit == 0)

# Generated at 2022-06-26 12:46:24.497793
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Just to test the "constructor"
    '''
    tf1ie = TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert_equal(tf1ie.url, "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-26 12:46:25.090371
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:46:34.202306
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create an instance of class TF1IE
    tf1_ie = TF1IE()
    assert tf1_ie != None

    # Test all _TESTS function
    for test in tf1_ie._TESTS:
        tf1_ie.url = test['url']
        result = tf1_ie._real_extract(test['url'])

        # Check expected title
        assert(result['title'] == test['info_dict']['title'])
        print(result['title'])

        # Check expected description
        assert(result['description'] == test['info_dict']['description'])
        print(result['description'])

        # Check expecting upload date
        assert(result['upload_date'] == test['info_dict']['upload_date'])
        print(result['upload_date'])


# Generated at 2022-06-26 12:46:34.941186
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-26 12:46:37.060052
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._download_json = lambda *args: {}
    ie.url_result = lambda *args: {}
    ie.extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:46:39.914834
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("TF1IE", "tf1.fr", True)
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:48.252048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE("TF1IE")
    assert test_obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:49.873102
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", "")

# Generated at 2022-06-26 12:49:17.304085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-26 12:49:20.509290
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    obj.extract()
    assert True

if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-26 12:49:20.951146
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-26 12:49:21.946072
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE({})

# Generated at 2022-06-26 12:49:24.709943
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

    print(tf1.program_slug)
    print(tf1.slug)



# Generated at 2022-06-26 12:49:25.852262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check for correct TF1IE object being created
    t1 = TF1IE()
    assert(isinstance(t1, TF1IE))

# Generated at 2022-06-26 12:49:29.861573
# Unit test for constructor of class TF1IE
def test_TF1IE():
  url = "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
  tf1 = TF1IE.TF1IE()
  tf1.extract(url)

# Generated at 2022-06-26 12:49:31.368085
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:49:35.396266
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import os
    import tempfile

    with tempfile.NamedTemporaryFile(delete=False) as f:
        try:
            f.write(b'Hi')
            f.close()
            tempFilePath = os.path.abspath(f.name)
        finally:
            os.remove(f.name)

    assert tempFilePath in TF1IE().get_thumbnail(tempFilePath)
    assert "Hi" in TF1IE().get_thumbnail(tempFilePath)

# Generated at 2022-06-26 12:49:35.999670
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE",None)