

# Generated at 2022-06-26 12:41:40.160736
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:41:42.223101
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:41:47.955183
# Unit test for constructor of class TF1IE
def test_TF1IE():
  url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
  tf1IE = TF1IE()
  tf1IE._real_extract(url)
  expected = 'koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
  assert expected == tf1IE.program_slug

# Generated at 2022-06-26 12:41:49.474414
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass


# Generated at 2022-06-26 12:41:51.235968
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_case_0()

# Generated at 2022-06-26 12:41:52.843590
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:41:55.523161
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_utils import test_utils
    from .tf1 import TF1IE
    assert test_utils.test_class(TF1IE, ["http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"])


# Generated at 2022-06-26 12:41:56.935302
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (TF1IE() is not None)


# Generated at 2022-06-26 12:41:59.217162
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:42:06.918976
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Given
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    # When
    tf1ie = TF1IE()
    result = tf1ie.extract({
        'url': url,
    })

    # Then
    assert len(result) == 1



# Generated at 2022-06-26 12:42:14.149954
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.ie_key().lower() == ie.WORKING_IE_NAME.lower()

# Generated at 2022-06-26 12:42:16.399676
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()


if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-26 12:42:20.546770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html'

# Generated at 2022-06-26 12:42:25.031454
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Simple test for the constructor of TF1IE
    """
    tester = TF1IE()
    assert tester is not None
    assert tester.ie_key() == 'TF1'


# Generated at 2022-06-26 12:42:27.157890
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None


# Generated at 2022-06-26 12:42:28.082433
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:42:36.849032
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1._TESTS[2]['url'] == "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"

# Generated at 2022-06-26 12:42:39.538268
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Simple test for constructor of class TF1IE
    ifile = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ifile is not None

# Generated at 2022-06-26 12:42:44.416866
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') is not None


# Generated at 2022-06-26 12:42:45.774578
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert bool(x)

# Testing with a correct input (url)

# Generated at 2022-06-26 12:43:08.336176
# Unit test for constructor of class TF1IE

# Generated at 2022-06-26 12:43:18.014948
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE.__doc__ == InfoExtractor.__doc__
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:21.447001
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE()._real_extract(TF1IE._TESTS[0]['url'])


# Generated at 2022-06-26 12:43:23.753705
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Should load TF1IE constructor without errors
    assert(TF1IE)

# Generated at 2022-06-26 12:43:24.946870
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE('TF1IE')

# Generated at 2022-06-26 12:43:36.831221
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_case = [
        'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ]

    for url in test_case:
        assert TF1IE.suitable(url), f'URL {url} is NOT suitable for TF1IE'

# Generated at 2022-06-26 12:43:39.868874
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('https://www.tf1.fr/');
    assert tf1.ie_key() == 'TF1';

# Generated at 2022-06-26 12:43:43.181870
# Unit test for constructor of class TF1IE
def test_TF1IE():
	print(TF1IE.__bases__)
	print(TF1IE.__module__)
	print(TF1IE.__name__)
	print(TF1IE.__qualname__)
	print(TF1IE.__doc__)
	print(TF1IE._TESTS[0].__doc__)
    # Loading unit test data
	return

# Generated at 2022-06-26 12:43:43.580540
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-26 12:43:44.366770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:08.926354
# Unit test for constructor of class TF1IE
def test_TF1IE():
    main(TF1IE)

# Generated at 2022-06-26 12:44:13.710162
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:44:15.031359
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE()
    assert e.should_skip_url('tf1://59b5a357f45ba7d1c63aec0a9b8a0c1e')

# Generated at 2022-06-26 12:44:16.428036
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-26 12:44:17.734624
# Unit test for constructor of class TF1IE
def test_TF1IE():
    new_TF1IE = TF1IE()
    assert new_TF1IE

# Generated at 2022-06-26 12:44:23.952264
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from youtube_dl.YoutubeDL import YoutubeDL
    ie = YoutubeDL({}).extract_info(
        'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
        download=False)
    assert ie._type == 'url_transparent'
    assert ie.url == 'wat:13641379'

# Generated at 2022-06-26 12:44:27.259412
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance.IE_NAME == 'tf1'
    assert instance._VALID_URL == TF1IE._VALID_URL
    assert instance._TESTS == TF1IE._TESTS

# Generated at 2022-06-26 12:44:33.296655
# Unit test for constructor of class TF1IE
def test_TF1IE():
  from tf1 import TF1IE
  # Instantiate an instance of class TF1IE
  tf1ie = TF1IE(None)
  # Call method _real_extract() on instance tf1ie of class TF1IE
  # The URL mentioned below is the first element of the list of the test URLs mentioned in TF1IE._TESTS
  tf1ie._real_extract(str(tf1ie.TESTS[0]['url']))



# Generated at 2022-06-26 12:44:34.194906
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-26 12:44:34.702080
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:45:32.939118
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE()._real_extract(
        u'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:45:38.657793
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_js_extractors import JS_TESTS

    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', '')
    for js_info in JS_TESTS:
        if js_info['url'] == 'http://www.tf1.fr/js/jquery.js':
            continue
        JS_TESTS[0]['url'] = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-26 12:45:41.459583
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:45:51.044265
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert(tf1.suitable("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"))
    assert(not tf1.suitable("https://www.non-tf1.com"))
    assert(tf1.IE_NAME == 'tf1')
    assert(tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(tf1.IE_DESC == 'tf1.fr')
    assert(tf1.get_browser().get_url() == 'https://www.tf1.fr/')

# Generated at 2022-06-26 12:45:52.490002
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('wat', 'wat')
    # Test your code here.

# Generated at 2022-06-26 12:45:55.226022
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(
        'wat:123456')._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html'



# Generated at 2022-06-26 12:45:56.024514
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:45:59.081299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test constructor of class TF1IE
    # Without arguments, should raise a TypeError
    from ..utils import _get_suitable_extractor

    extractor = _get_suitable_extractor('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert extractor.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-26 12:46:07.108251
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    test_cases = [
        ('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
         'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ]
    
    for (url, expected_url) in test_cases:
        assert extractor._match_id(url) == expected_url

# Generated at 2022-06-26 12:46:15.576313
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1ie = TF1IE()
	assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
	assert tf1ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
	assert tf1ie._TESTS[0]['info_dict']['id'] == '13641379'
	assert tf1ie._TESTS[0]['info_dict']['ext'] == 'mp4'
	assert tf1ie._

# Generated at 2022-06-26 12:48:37.066679
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__doc__ is not None

# Generated at 2022-06-26 12:48:44.613586
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_download import options

    tf1_test = TF1IE()
    tf1_test.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    tf1_test._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    tf1_test.download(tf1_test._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')['url'], options)

# Generated at 2022-06-26 12:48:45.778560
# Unit test for constructor of class TF1IE
def test_TF1IE():
    cls = TF1IE
    cls.suite()

# Generated at 2022-06-26 12:48:48.846086
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Tests specific to TF1IE"""
    tf1_ie = TF1IE()
    assert tf1_ie.ie_key() == 'TF1'


# Generated at 2022-06-26 12:48:49.911973
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE(InfoExtractor())

# Generated at 2022-06-26 12:48:58.354159
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("TF1IE", "TF1", "MDwwDQYJKoZIhvcNAQEBBQADKwAwKAIhAOgHGkN6UW2/U4C6E4/4UOTw6mJknFkOXnYnpx1rXrAgMBAAE=")
    assert obj.name == "TF1IE"
    assert obj.IE_NAME == "TF1"
    assert obj.token == "MDwwDQYJKoZIhvcNAQEBBQADKwAwKAIhAOgHGkN6UW2/U4C6E4/4UOTw6mJknFkOXnYnpx1rXrAgMBAAE="

# Generated at 2022-06-26 12:49:03.611381
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert obj.title == obj.id
    assert obj.get_url() == obj.url
    assert obj.duration == 0
    assert obj.description
    assert obj.url == 'wat:f588a7ff-abea-4596-8f46-cabdc7e9f9c8'

# Generated at 2022-06-26 12:49:07.244128
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:49:14.839016
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from pprint import pprint
    from .common import test_template
    from .common import main
    from .common import init_for_test

    init_for_test()
    case = test_template(main, [
        "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html",
    ], [
        "tf1.fr/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
    ])

# Generated at 2022-06-26 12:49:21.890735
# Unit test for constructor of class TF1IE
def test_TF1IE():
	# Test for a video
	url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
	tf1IE = TF1IE(url)

	assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
	assert tf1IE._program_slug == 'tf1/tmc/quotidien-avec-yann-barthes'
	assert tf1IE._slug == 'quotidien-premiere-partie-11-juin-2019'
	assert tf1