

# Generated at 2022-06-26 12:41:40.386810
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert True

# Generated at 2022-06-26 12:41:47.193462
# Unit test for constructor of class TF1IE
def test_TF1IE():
    def test_case_1():
        t_f1_i_e_1 = TF1IE()
    def test_case_2():
        t_f1_i_e_2 = TF1IE()
    def test_case_3():
        t_f1_i_e_3 = TF1IE()
    def test_case_4():
        t_f1_i_e_4 = TF1IE()


# Generated at 2022-06-26 12:41:49.469289
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._downloader.params[
        'test'] == False

# Generated at 2022-06-26 12:41:55.390254
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-26 12:41:59.450037
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    t_f1_i_e.tf1_download()


# Generated at 2022-06-26 12:42:01.486764
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_0 = TF1IE()

# Generated at 2022-06-26 12:42:08.937553
# Unit test for constructor of class TF1IE
def test_TF1IE():
    expected_value_0 = 'https://www.tf1.fr/graphql/web'
    actual_value_0 = TF1IE._GRAPHQL_URL
    assert actual_value_0 == expected_value_0
    expected_value_1 = '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'
    actual_value_1 = TF1IE._GRAPHQL_QUERY
    assert actual_value_1 == expected_value_1


# Generated at 2022-06-26 12:42:09.541651
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_case_0()

# Generated at 2022-06-26 12:42:14.447409
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_0 = TF1IE()
    assert t_f1_i_e_0._VALID_URL
    assert t_f1_i_e_0._TESTS


# Generated at 2022-06-26 12:42:16.584917
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE(), "Unit test for constructor of class TF1IE")


# Generated at 2022-06-26 12:42:24.589547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE(None)
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert info_extractor._TESTS[1]['only_matching']

# Generated at 2022-06-26 12:42:28.683657
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1
    assert tf1._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-26 12:42:29.752317
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:42:35.506485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:37.003392
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-26 12:42:47.285651
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    extractor = TF1IE(TF1IE._create_get_video_info(url))
    assert extractor.program_slug == 'quotidien-avec-yann-barthes'
    assert extractor.slug == 'quotidien-premiere-partie-11-juin-2019'
    assert extractor.vars['programSlug'] == 'quotidien-avec-yann-barthes'
    assert extractor.vars['slug'] == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-26 12:42:52.208831
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-26 12:42:55.086540
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _test = TF1IE()
    _test._VALID_URL
    _test._TESTS

# Generated at 2022-06-26 12:42:58.526268
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Unit test for constructor of class TF1IE. """
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:08.819563
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable("https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert ie.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert not ie.suitable("https://www.tf1.fr/tf1")
    assert not ie.suitable("https://www.tf1.fr/")

# Generated at 2022-06-26 12:43:23.676637
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    test = tf1.tf1_constructor(tf1)
    assert test


# Generated at 2022-06-26 12:43:25.242762
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:43:26.422276
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1 = TF1IE('tf1')

# Generated at 2022-06-26 12:43:38.346604
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import json
    from nose.tools import assert_equal,assert_not_equal,assert_raises
    from .common import InfoExtractor

    # Try with a valid url
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1IE = TF1IE(InfoExtractor)
    assert_equal(tf1IE._VALID_URL, tf1IE.ie._VALID_URL)

    # Try with an invalid url
    url = 'https://www.wat.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
   

# Generated at 2022-06-26 12:43:41.270079
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        instance = TF1IE()
    except TypeError as e:
        assert False
    except Exception:
        assert True

# Generated at 2022-06-26 12:43:53.424427
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("************* This is test_TF1IE of TF1IE *************")
    print("Test case : URL = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'")
    program_slug, slug = re.match(TF1IE._VALID_URL, "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html").groups()
    print("program_slug = %s" % program_slug)
    print("slug = %s" % slug)

# Generated at 2022-06-26 12:43:54.416816
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    tf1_ie = TF1IE()
    assert tf1_ie is not None

# Generated at 2022-06-26 12:44:07.387961
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for constructor of class TF1IE
    """
    # Test case 1
    tf1ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert len(tf1ie.program_slug) > 0
    assert len(tf1ie.slug) > 0
    assert len(tf1ie.video) > 0
    assert len(tf1ie.wat_id) > 0

    # Test case 2

# Generated at 2022-06-26 12:44:17.907509
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == \
        {'_type': 'url_transparent', 'id': '13741291', 'url': 'wat:13741291', 'title': 'Koh-Lanta', 'thumbnail': 
         're:https://(?:www\.)?wat\.tv/picture/a8/e8/[^"]+', 'description': 'Replay Koh-Lanta', 'timestamp': 1432125600, 
         'duration': 3599}

# Generated at 2022-06-26 12:44:24.436912
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    print (ie._VALID_URL)
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:48.762184
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == 'TF1'

# Generated at 2022-06-26 12:44:58.694128
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(downloader = None)
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert obj._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert obj._TESTS[0]['info_dict']['id'] == '13641379'
    assert obj._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:44:59.908067
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    print(obj)

# Generated at 2022-06-26 12:45:01.292682
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert 'TF1IE' == TF1IE.ie_key()

# Generated at 2022-06-26 12:45:09.346113
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Valid URL
    TF1IE._valid_url('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE._valid_url('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    TF1IE._valid_url('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE._valid_url('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

    # Invalid URL

# Generated at 2022-06-26 12:45:14.053427
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test class constructor
    """
    url = "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    tf1 = TF1IE(url)
    assert tf1.url == url


# Generated at 2022-06-26 12:45:16.862074
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-26 12:45:21.413522
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert(tf1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-26 12:45:23.463517
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-26 12:45:24.438299
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

# Generated at 2022-06-26 12:46:17.267801
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-26 12:46:21.917346
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    test_class = TF1IE()
    regex_result = re.match(test_class._VALID_URL, url).groups()
    assert(regex_result)

# Generated at 2022-06-26 12:46:22.975778
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:46:26.323623
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:46:34.836754
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:37.408115
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-26 12:46:38.606675
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert isinstance(ie, TF1IE)
    

# Generated at 2022-06-26 12:46:40.282443
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_extractor = TF1IE()
    assert tf1_extractor is not None
    assert tf1_extractor.ie_key() == 'TF1'

# Generated at 2022-06-26 12:46:48.631533
# Unit test for constructor of class TF1IE

# Generated at 2022-06-26 12:46:54.557631
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:49:19.071275
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('www.tf1.fr')
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # The code segment below is based on the code in the method _real_extrac() from file 'extractor/TF1IE.py'
    tf1._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1.program_slug == 'koh-lanta'

# Generated at 2022-06-26 12:49:19.636669
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:49:20.508357
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE= TF1IE()

# Generated at 2022-06-26 12:49:21.131617
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()

# Generated at 2022-06-26 12:49:27.062864
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import unitTest
    test = unitTest.UnitTest()
    match = re.match(TF1IE._VALID_URL, "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    page_url = "/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    test.assertEqual(match.groupdict(),{'program_slug': 'tf1', 'id': 'replay-koh-lanta-22-mai-2015'})

# Generated at 2022-06-26 12:49:29.827558
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        pass

# Generated at 2022-06-26 12:49:31.844164
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE();
    print ("test_Tf1IE: ")
    if infoExtractor == None:
        assert ("failed")
        return
    assert ("succeeded")
  # End unit test

# Unit test
test_TF1IE()

# Generated at 2022-06-26 12:49:33.611815
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-26 12:49:34.434092
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-26 12:49:35.291229
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert 'TF1IE' in globals()
