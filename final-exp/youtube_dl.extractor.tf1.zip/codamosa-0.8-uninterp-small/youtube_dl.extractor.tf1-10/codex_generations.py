

# Generated at 2022-06-26 12:41:40.813464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_case_0()

# Generated at 2022-06-26 12:41:43.276508
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:41:45.039054
# Unit test for constructor of class TF1IE
def test_TF1IE():
    current = TF1IE()
    assert(current is not None)


# Generated at 2022-06-26 12:41:46.420129
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-26 12:41:48.673428
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_1 = TF1IE()


# Generated at 2022-06-26 12:41:51.083815
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie != None

# Generated at 2022-06-26 12:41:54.526038
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    # 
    test_case_0()

# 
test_TF1IE()

# Generated at 2022-06-26 12:41:55.547999
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

# Generated at 2022-06-26 12:41:57.017215
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:41:59.372923
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:42:08.054702
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True

# Generated at 2022-06-26 12:42:15.218057
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:42:18.052563
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert "tf1" in tf1ie.IE_NAME

# Generated at 2022-06-26 12:42:21.026627
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract(TF1IE._TESTS[0]['url'])

# Generated at 2022-06-26 12:42:31.282319
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_downloader import _test_downloader
    from .test_downloader import _test_preferredencoding
    from .test_downloader import _test_nopreview
    from .test_downloader import _test_nopreview_open_mock

    tf1 = TF1IE()

    # Test constructor of class TF1IE
    assert(tf1.tf1 == 'tf1')
    assert(tf1.real_download == 'real_download')
    assert(tf1.suitable == 'suitable')
    assert(tf1.report_download_webpage == 'report_download_webpage')
    assert(tf1.report_extraction == 'report_extraction')
    assert(tf1.downloader == 'downloader')
    assert(tf1.params == 'params')

# Generated at 2022-06-26 12:42:32.685628
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-26 12:42:34.637627
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.get_id() == "TF1"

# Generated at 2022-06-26 12:42:35.341760
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-26 12:42:39.529528
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("wat:")
    assert ie.watched == {}
    assert ie.last_video == ""

# Unit tests for method _real_extract of class TF1IE

# Generated at 2022-06-26 12:42:41.459447
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()
    TF1IE(InfoExtractor)

# Generated at 2022-06-26 12:42:53.843408
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert (ie, TF1IE)

# Generated at 2022-06-26 12:43:00.551348
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_main import test_all
    from .main import InfoExtractor
    from .common import InfoExtractor
    from ..utils import (
        int_or_none,
        parse_iso8601,
        try_get,
    )
    from .tf1 import (
        TF1IE,
        _VALID_URL,
        _download_json,
        _,
        _TESTS,
        )
    from .common import InfoExtractor


    test_all(TF1IE,_TESTS,module_name="tf1")
    IE = InfoExtractor()
    # assert test_all(IE,_TESTS,module_name=__name__) == 1

# Generated at 2022-06-26 12:43:02.039067
# Unit test for constructor of class TF1IE
def test_TF1IE():
	try:
		ie = TF1IE()
		assert True
	except Exception as exc:
		assert False, "Exception thrown in constructor of class TF1IE"


# Generated at 2022-06-26 12:43:03.394287
# Unit test for constructor of class TF1IE
def test_TF1IE():
    new_test = TF1IE()

# Generated at 2022-06-26 12:43:04.066215
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:06.405173
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert 'TF1' == ie._NETRC_MACHINE
    assert 'https://www.tf1.fr/graphql/web' == ie._API_BASE_URL

# Generated at 2022-06-26 12:43:07.692901
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("")

# Generated at 2022-06-26 12:43:09.165537
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:10.497136
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global TF1IE
    TF1IE()

# Generated at 2022-06-26 12:43:18.641532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:47.994376
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_item = TF1IE.TF1IE(
        'TF1IE',
        'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    )

    assert test_item.get_tf1_program_slug() == 'koh-lanta'
    assert test_item.get_tf1_slug() == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-26 12:43:53.880329
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'



# Generated at 2022-06-26 12:43:59.327707
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:44:00.198585
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:04.775492
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    wat = "wat:2b4364aec2264c633dfa9bbd3e8c7470"
    tf1.url_result(wat)


# Generated at 2022-06-26 12:44:10.129621
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testie = TF1IE()
    assert '<class' in str(testie)
    assert 'TF1IE' in str(testie)
    assert testie.ie_key() == 'TF1'
    assert testie.ie_key() in testie.suitable()

# Generated at 2022-06-26 12:44:17.483416
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE(TF1IE.__name__, 'www.tf1.fr/')
    assert test._VALID_URL is not None, "TF1IE does not have a VALID_URL"
    assert test.name == 'tf1', "TF1IE does not have a name"
    assert test.ie_key() == 'TF1', "TF1IE does not have a name"
    assert test._TEST is not None, "TF1IE does not have a _TEST"

# Generated at 2022-06-26 12:44:21.424472
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-26 12:44:22.597099
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE
    obj = ie(None)

# Generated at 2022-06-26 12:44:23.471489
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().extract()


# Generated at 2022-06-26 12:45:19.783303
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert e.__class__.__name__ == 'TF1IE'
    assert e._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:45:21.304261
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:45:29.133619
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:45:34.822087
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE()
    ie.extract(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:45:35.533476
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.url


# Generated at 2022-06-26 12:45:36.230283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE({'info_dict'})

# Generated at 2022-06-26 12:45:36.880010
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-26 12:45:45.397077
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_utils import TestIE
    from .test_utils import TestVideoIE

    # tests whether constructor of class VideoInfoExtractor generates description of class TF1IE correctly
    TestIE.generate_description(TF1IE)

    # tests whether constructor of class VideoInfoExtractor generates test cases correctly

# Generated at 2022-06-26 12:45:46.553984
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == 'tf1'

# Generated at 2022-06-26 12:45:47.502532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:00.168755
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:48:07.462247
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:48:08.890887
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1 = TF1IE()
	assert tf1 != None


# Generated at 2022-06-26 12:48:11.491277
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(None)
    assert tf1ie is not None
    assert tf1ie.DATE_FORMATS == ['%Y-%m-%dT%H:%M:%S%z']

# Generated at 2022-06-26 12:48:12.009725
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:15.494095
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert 'wat:' == t.suitable("wat:")
    #assert 'wat:' == t.suitable("wat:123")
    #assert 'wat:' == t.suitable("http://www.wat.tv/video/video-test-2a8f8.html")

# Generated at 2022-06-26 12:48:18.695639
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE().suitable(url)

# Generated at 2022-06-26 12:48:25.998783
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert isinstance(IE._VALID_URL, type(re.compile('')))
    assert re.match(IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert re.match(IE._VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not re.match(IE._VALID_URL, 'https://tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
   

# Generated at 2022-06-26 12:48:27.886468
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        assert False, 'Unit test of class TF1IE in test_TF1IE() failed.'

# Generated at 2022-06-26 12:48:30.727607
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test standard entry points
    constructor = TF1IE(TF1IE.test_case())

    # Test that case when failed: Exception
    constructor = TF1IE(TF1IE.test_case(url=None))