

# Generated at 2022-06-26 12:41:43.888943
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert t_f1_i_e is not None


# Generated at 2022-06-26 12:41:50.442866
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert t_f1_i_e_0._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-26 12:41:52.687528
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert t_f1_i_e_0 != None


# Generated at 2022-06-26 12:41:54.760181
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(t_f1_i_e_0 != None)


# Generated at 2022-06-26 12:41:56.698930
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert ('TF1IE', True) == (tf1ie.IE_NAME, isinstance(tf1ie, InfoExtractor))

# Generated at 2022-06-26 12:41:58.826216
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE())


# Generated at 2022-06-26 12:42:00.324478
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() is not None, "TF1IE constructor not working"


# Generated at 2022-06-26 12:42:01.201866
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:42:02.671527
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:42:04.198093
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:42:11.152788
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-26 12:42:15.569171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", "")

# Generated at 2022-06-26 12:42:17.593273
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test TF1IE constructor
    """
    assert TF1IE

# Generated at 2022-06-26 12:42:19.515706
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE({}), TF1IE)

# Generated at 2022-06-26 12:42:30.853275
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = {
        'url': 'http://www.tf1.fr/series-us/esprits-criminels/videos/replay-esprits-criminels-saison-9-episode-17-11-mars-2015.html',
        'only_matching': True,
    }

    ie = TF1IE()._real_extract(test['url'])
    assert ie['id'] == '14561628'
    assert ie['ext'] == 'mp4'
    assert ie['title'] == 'Replay Esprits criminels - Saison 9 - Épisode 17 - 11 mars 2015'
    assert ie['description'] == 'md5:1b48d47e8f1c22d972b65c4fdd29dc8c'

# Generated at 2022-06-26 12:42:32.813900
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test the constructor of class TF1IE
    """
    tf1IE = TF1IE()

    if tf1IE is None:
        print("Error: TF1IE() constructor returned None")
        exit(1)
    return

# Generated at 2022-06-26 12:42:38.790603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    tf1 = TF1IE()
    assert tf1._VALID_URL == r"https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-26 12:42:44.499091
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('?url=https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html&program_slug=quotidien-avec-yann-barthes&id=quotidien-premiere-partie-11-juin-2019')

# Generated at 2022-06-26 12:42:48.797574
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')



# Generated at 2022-06-26 12:42:59.484051
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Prepare options (none)
    options = None
    # Instantiate the class
    # There should be no error
    x = TF1IE(options)
    # Check the URL
    url = x._extract_formats(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert url == 'wat:13641379'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # Check the test

# Generated at 2022-06-26 12:43:11.405645
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:17.052886
# Unit test for constructor of class TF1IE
def test_TF1IE():
    VIDEO_URL = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    VIDEO_URL2 = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

    # Creation and testing of the unit TF1IE
    ie = TF1IE(VIDEO_URL)
    ie2 = TF1IE(VIDEO_URL2)

    # Creation of the expected results
    expected_title = "md5:f392bc52245dc5ad43771650c96fb620"

# Generated at 2022-06-26 12:43:18.035655
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-26 12:43:29.167406
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_cases = [
        {
            'url' : 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
            'program_slug' : 'koh-lanta',
            'slug' : 'replay-koh-lanta-22-mai-2015',
            'id' : '13641379'

        }
    ]

    for test_case in test_cases:
        url = test_case['url']
        ie = TF1IE(url)

        program_slug = test_case['program_slug']
        assert ie.program_slug == program_slug

        slug = test_case['slug']
        assert ie.slug == slug

        id = test_

# Generated at 2022-06-26 12:43:30.772381
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE().to_screen()

# Generated at 2022-06-26 12:43:35.501735
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Tests of class TF1IE
    class_ = TF1IE

    base_url = class_._VALID_URL
    video_id = class_._TESTS[0]['url'].split('/')[-1].split('.')[0]
    program_slug = class_._TESTS[0]['url'].split('/')[-3]

    # Check if video_id was extracted correctly
    assert video_id == class_._TESTS[0]['info_dict']['id']
    # Check if program_slug was extracted correctly
    assert program_slug == class_._TESTS[0]['info_dict']['series']
    # Check if URL was extracted correctly
    assert class_._download_json(base_url, video_id) is not None

# Generated at 2022-06-26 12:43:40.200807
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check that tf1 returns an instance of TF1IE
    assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:43:43.189578
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

    # Test that the constructor creates the correct class instance
    assert ie.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-26 12:43:44.563444
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.tf1 == 'tf1'

# Generated at 2022-06-26 12:43:46.932946
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = TF1IE()
    video._download_json()

# Generated at 2022-06-26 12:44:12.461444
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()
    assert result.extractor_key == 'TF1'


# Generated at 2022-06-26 12:44:23.157181
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == '"https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"'

# Generated at 2022-06-26 12:44:33.297154
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class for TF1IE object"""
    from youtube_dl import YoutubeDL
    ydl = YoutubeDL({'verbose': True})
    IE = ydl.get_info_extractor('TF1IE')
    assert IE

    # Tests for valid URLs

# Generated at 2022-06-26 12:44:35.046247
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())._download_json('https://www.tf1.fr/graphql/web', 'test')

# Generated at 2022-06-26 12:44:40.042237
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with TF1IE instantiation
    inst_test = TF1IE()

    # Test with TF1IE constructor, hence return False when url is not valid
    url_invalid = 'http://www.lequipe.fr/'
    assert TF1IE.suitable(url_invalid) == False, 'Should be False since URL is not valid'

# Generated at 2022-06-26 12:44:40.664676
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:43.535004
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('wat:13641379')
    assert instance._VALID_URL == TF1IE._VALID_URL
    assert instance._TESTS == TF1IE._TESTS

# Generated at 2022-06-26 12:44:44.846345
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # check if TF1IE class is successfully created
    assert TF1IE._VALID_URL

# Generated at 2022-06-26 12:44:48.140194
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor(),"http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-26 12:44:48.725334
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:45:47.614766
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert ie


# Generated at 2022-06-26 12:45:49.355325
# Unit test for constructor of class TF1IE
def test_TF1IE():
	import urllib
	f = TF1IE(urllib.request.build_opener())
	assert f.ie_key() == 'TF1'

# Generated at 2022-06-26 12:45:55.692626
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.mobj.group('program_slug') == 'quotidien-avec-yann-barthes'
    assert t.mobj.group('id') == 'quotidien-premiere-partie-11-juin-2019'
    assert t._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t.ie_key() == 'TF1'

# Generated at 2022-06-26 12:45:57.880458
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
        assert True
    except:
        assert False

# Generated at 2022-06-26 12:45:58.993337
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    # ValueError likely due to a module missing
    assert instance

# Generated at 2022-06-26 12:46:07.022371
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:46:15.508709
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:17.109049
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._TESTS[0]['title'] == TF1IE._TESTS[1]['info_dict']['title']

# Generated at 2022-06-26 12:46:19.786728
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE(url)


# Generated at 2022-06-26 12:46:23.834009
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE()._real_extract(url)

# Generated at 2022-06-26 12:48:43.139924
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:44.059587
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testObj = TF1IE()
    assert testObj

# Generated at 2022-06-26 12:48:53.611042
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'TF1'
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:49:01.928513
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert TF1IE.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert not TF1IE.suitable("http://www.w9.fr/divertissement/publication/annuaires/decideurs-en-communication/fiche/93/vanessa-mara.html")
    assert not TF1IE.suitable("http://www.tf1.fr/")
    assert not TF1IE.suitable("http://www.replay.mytf1.fr/")

# Generated at 2022-06-26 12:49:07.999914
# Unit test for constructor of class TF1IE
def test_TF1IE():
    (TF1IE(),
     TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'),
     TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'),
     TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
     )

# Generated at 2022-06-26 12:49:10.054119
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create an instance of TF1IE class
    TF1IE_instance = TF1IE()

    # Check if its an instance of InfoExtractor class
    assert isinstance(TF1IE_instance, InfoExtractor)

# Generated at 2022-06-26 12:49:10.746282
# Unit test for constructor of class TF1IE
def test_TF1IE():
	t = TF1IE()

# Generated at 2022-06-26 12:49:11.412821
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE() 


# Generated at 2022-06-26 12:49:13.726073
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TestCase = get_testcase()

    TestCase.assertIsInstance(
        TF1IE(), InfoExtractor
    )

# Generated at 2022-06-26 12:49:20.573463
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert tf1_ie._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"