

# Generated at 2022-06-26 12:41:43.198553
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_case_0()

# Generated at 2022-06-26 12:41:46.587440
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

    assert t_f1_i_e.IE_NAME == 'tf1:tf1'
    assert t_f1_i_e.IE_DESC == 'Tf1'

# Generated at 2022-06-26 12:41:58.043390
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert t_f1_i_e_0._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t_f1_i_e_0._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert t_f1_i_e_0._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-26 12:42:00.661275
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert t_f1_i_e._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:10.011795
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t_f1_i_e_1 = TF1IE()
    t_f1_i_e_1_extracted = t_f1_i_e_1._real_extract(url)
    assert t_f1_i_e_1_extracted['id'] == '13641379'
    assert t_f1_i_e_1_extracted['ext'] == 'mp4'
    assert t_f1_i_e_1_extracted['timestamp'] == 1560273989

# Generated at 2022-06-26 12:42:19.724455
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Checks for constructor of class TF1IE
    if (not hasattr(TF1IE, '_VALID_URL') or
        not hasattr(TF1IE, 'IE_NAME') or
        not hasattr(TF1IE, '_TESTS')):
        assert False

    video_webpage_regex = TF1IE._VALID_URL
    if (type(video_webpage_regex) is not str or
        len(video_webpage_regex) == 0):
        assert False

    ie_name = TF1IE.IE_NAME
    if (type(ie_name) is not str or
        len(ie_name) == 0):
        assert False

    tests = TF1IE._TESTS

# Generated at 2022-06-26 12:42:21.515717
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_case_0()


# Generated at 2022-06-26 12:42:24.607899
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # declare test_case_0 instance of TF1IE
    t_f1_i_e_0 = TF1IE()


# Generated at 2022-06-26 12:42:26.251792
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None


# Generated at 2022-06-26 12:42:28.610285
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert issubclass(TF1IE, InfoExtractor) == True
    except Exception:
        print("Failed to check if TF1IE is a subclass of InfoExtractor")


# Generated at 2022-06-26 12:42:35.646615
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('tf1')

# Generated at 2022-06-26 12:42:40.517679
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    print(tf1IE.get_url())

# Generated at 2022-06-26 12:42:41.232858
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-26 12:42:48.654367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable(TF1IE.ie_key())
    assert TF1IE.suitable('TF1IE')
    assert TF1IE.suitable('http://www.tf1.fr/')
    assert TF1IE.suitable('http://www.tf1.fr/tf1/les-feux-de-l-amour/videos/')
    assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert TF1IE.suitable('https://www.tf1.fr/graphql/web')
    assert TF1IE.suitable('wat://13983834')

# Generated at 2022-06-26 12:42:53.072401
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html") == None

# Generated at 2022-06-26 12:42:56.237936
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from wat.TF1IE import TF1IE
    from wat.extractor import gen_extractors
    extractors = gen_extractors()
    assert TF1IE in extractors

# Generated at 2022-06-26 12:42:56.950058
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert True

# Generated at 2022-06-26 12:43:00.928207
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-26 12:43:02.890371
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE', 'tf1.fr')

# Generated at 2022-06-26 12:43:08.196787
# Unit test for constructor of class TF1IE
def test_TF1IE():
    watIE = TF1IE()
    assert watIE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True
    assert watIE.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True

# Generated at 2022-06-26 12:43:29.236638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE()
    assert e.IE_NAME == 'TF1'
    assert e.IE_DESC == 'TF1'
    assert e.valid_url('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert e.valid_url('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert e.valid_url(TF1IE._VALID_URL, 'program_slug', 'id')
    assert e.valid_url(TF1IE._VALID_URL, 'program_slug', 'id', expected_status=404)

# Generated at 2022-06-26 12:43:34.302458
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-26 12:43:41.451006
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # tf1.fr has different kinds of URL
    urls = ['http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
            'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html',
            'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html']

    for url in urls:
        assert ie.suitable(url) == True
        assert ie.IE_NAME == 'tf1'
        assert ie.valid_url(url) == True

# Generated at 2022-06-26 12:43:42.228591
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-26 12:43:43.499346
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE')

# Generated at 2022-06-26 12:43:44.810387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    o = TF1IE()
    assert o is not None

# Generated at 2022-06-26 12:43:56.474476
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'
    assert ie.id == '11056195'
    assert ie.wat_id == '11056195'
    assert ie.title == 'Koh-Lanta'
    assert ie.decoration.get('description') == 'Toute l\'actualité de Koh-Lanta - la guerre des chefs'
    assert ie.decoration.get('programLabel') == 'Koh-Lanta'
    assert ie.tags == None

# Generated at 2022-06-26 12:43:57.338482
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:44:03.458262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:10.426700
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-26 12:44:35.204441
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extraction_test = InfoExtractor('TF1IE')
    assert info_extraction_test.ie_key() == 'TF1'

# Generated at 2022-06-26 12:44:35.695634
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:41.546292
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:42.511471
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:45.278491
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html");

# Generated at 2022-06-26 12:44:49.546988
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with simple url
    test_TF1IE = TF1IE()
    assert test_TF1IE.url == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

# Generated at 2022-06-26 12:44:59.997228
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_cases = [
        ('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'),
        ('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'),
    ]
    for test_case in test_cases:
        TF1IE()._download_json(test_case[0])

# Generated at 2022-06-26 12:45:02.464356
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:45:05.927288
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("url")
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-26 12:45:09.858580
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(url='http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    tf1ie = TF1IE(url='http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert tf1ie

# Generated at 2022-06-26 12:46:08.772465
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('')

# Generated at 2022-06-26 12:46:10.636664
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ test_TF1IE: test the constructor of class TF1IE """

    tf1IE = TF1IE()
    assert tf1IE is not None

# Generated at 2022-06-26 12:46:14.912324
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    result = t.extract(url)
    assert result.get('description') == 'md5:1911f3cae6c348935d6927e75e2a4077'

# Generated at 2022-06-26 12:46:16.699701
# Unit test for constructor of class TF1IE
def test_TF1IE():
  from .common import InfoExtractor
  from .tf1 import TF1IE
  tf1ie = TF1IE(InfoExtractor())
  assert isinstance(tf1ie, TF1IE)

# Generated at 2022-06-26 12:46:17.790177
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor of class TF1IE
    info = TF1IE()

# Generated at 2022-06-26 12:46:20.830580
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html");
    video.download();

# Generated at 2022-06-26 12:46:30.577243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://unittest_url'
    test_class = TF1IE()

    # Ensure URL matches expected Regex
    test_true = test_class._VALID_URL
    test_str = str(test_true)
    test_str = test_str.replace('https?://(?:www\\.)?', url)
    test_str = test_str.replace('program_slug', 'test_program_slug')
    test_str = test_str.replace('id', 'test_id')
    assert test_class._match_id(test_str)

    # Ensure right type is returned
    assert isinstance(test_class, InfoExtractor) or issubclass(test_class, InfoExtractor)

# Generated at 2022-06-26 12:46:33.512500
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-26 12:46:39.703582
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:40.646753
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1',True,'0',True,True)

# Generated at 2022-06-26 12:49:06.179093
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    # Get instance of class InfoExtractor
    assert t.IE is not None

# Generated at 2022-06-26 12:49:09.691611
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:49:13.013308
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    # We would like to test the following
    ie = TF1IE(url=url)
    ie._real_extract(url)

# Generated at 2022-06-26 12:49:13.824715
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:49:15.020222
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Tests if TF1IE constructor succesfully creates an object
    TF1IE = TF1IE()

# Generated at 2022-06-26 12:49:15.470622
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:49:21.257041
# Unit test for constructor of class TF1IE
def test_TF1IE():

    assert('TF1IE' in globals())
    tf1ie = globals()['TF1IE']

    assert(tf1ie.__name__ == 'TF1IE')
    assert(isinstance(tf1ie, type))
    assert(tf1ie is not InfoExtractor)

    # Instantiation
    instance = tf1ie(None)

    assert(instance.__class__ == tf1ie)
    assert(isinstance(instance, TF1IE))
    assert(isinstance(instance, InfoExtractor))

    # _real_extract
    assert('_real_extract' in dir(instance))
    assert(callable(instance._real_extract))

# Generated at 2022-06-26 12:49:22.011804
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:49:22.437024
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:49:29.863074
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE(None)
    IE._parse_json = None