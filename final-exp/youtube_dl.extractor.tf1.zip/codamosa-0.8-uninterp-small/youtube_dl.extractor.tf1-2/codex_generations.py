

# Generated at 2022-06-26 12:41:43.290873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()



# Generated at 2022-06-26 12:41:45.044012
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert t_f1_i_e_0 is not None


# Generated at 2022-06-26 12:41:49.543711
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    TF1IE(url)

# Generated at 2022-06-26 12:41:50.710542
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert True

# Generated at 2022-06-26 12:41:52.303059
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:41:54.372944
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)


# Generated at 2022-06-26 12:41:55.514865
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_case_0()


# Generated at 2022-06-26 12:41:56.354708
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:41:57.828215
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()


# Generated at 2022-06-26 12:42:00.139077
# Unit test for constructor of class TF1IE
def test_TF1IE():
    c = TF1IE()

# Generated at 2022-06-26 12:42:08.287553
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert isinstance(t, TF1IE)

# Generated at 2022-06-26 12:42:12.070322
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.tf1 = 'tf1'
    tf1.tf1 == 'tf1'
    return True

# Generated at 2022-06-26 12:42:17.874222
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == 'tf1'
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t.BROWSER_SIZE == (1200, 800)

# Generated at 2022-06-26 12:42:21.933530
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert TF1IE._VALID_URL is not None
    assert tf1ie.lookup() is False



# Generated at 2022-06-26 12:42:31.641333
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    Test.assertEquals(TF1IE()._VALID_URL, 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    Test.assertEquals(TF1IE()._TESTS, [{'url': 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', 'only_matching': True}])

# Generated at 2022-06-26 12:42:32.132768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-26 12:42:33.520696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # There are no test cases for constructor for now
    pass

# Generated at 2022-06-26 12:42:37.079869
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE is not None
    #assert tf1IE.__name__ == "TF1IE"

# Generated at 2022-06-26 12:42:41.786283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    tf1IE._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    return

# Generated at 2022-06-26 12:42:44.250534
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        tf1.tf1IE
    except:
        assert False # The TF1IE constructor should exist

# Generated at 2022-06-26 12:43:07.174613
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from youtube_dl.utils import SearchInfoExtractor

# Generated at 2022-06-26 12:43:08.112433
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:17.062813
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert t._VALID_URL.match('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f' in t._download_json

# Generated at 2022-06-26 12:43:18.727665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)



# Generated at 2022-06-26 12:43:25.370700
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Valid URL test
    assert TF1IE() is not None
    # Invalid URL test
    assert TF1IE()._real_initialize(url='https://www.francetvinfo.fr/replay-jt/france-2/') is False
    # None test
    assert TF1IE()._real_initialize(url=None) is False

# Generated at 2022-06-26 12:43:30.032396
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-26 12:43:39.754893
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE

    assert(tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

    assert(tf1._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert(tf1._TESTS[0]['info_dict']['id'] == '13641379')
    assert(tf1._TESTS[0]['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-26 12:43:42.153686
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("Koh Lanta")
    assert type(t) is TF1IE


# Generated at 2022-06-26 12:43:44.610339
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie.get_fields() == ["id", "ext", "title", "description", "upload_date", "timestamp", "duration", "series", "tags"]

# Generated at 2022-06-26 12:43:47.556738
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert isinstance(tf1_ie, TF1IE)

# Generated at 2022-06-26 12:44:16.054798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor should work with a url without http:// before
    url = "www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    tf1ie = TF1IE(url)
    assert tf1ie

# Generated at 2022-06-26 12:44:17.014515
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.suite()

# Generated at 2022-06-26 12:44:17.568644
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:44:28.669638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(None)
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:31.719418
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from io import StringIO
    from .common import test_tf1
    
    test_tf1("test_TF1IE", TF1IE, "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html", "test_tf1.mp4", dest=StringIO())

# Generated at 2022-06-26 12:44:37.926611
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test construction of object by calling constructor without arguments
    video = TF1IE();
    # Check that members exist
    assert video._VALID_URL is not None;
    assert video._TESTS is not None;
    # Check that regexp compiles
    regexp = re.compile(video._VALID_URL);
    # Check that members can be called
    url='http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html';
    assert video._match_id(url) == 'replay-koh-lanta-22-mai-2015.html';

# Generated at 2022-06-26 12:44:39.309246
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.ie_key() == 'TF1'

# Generated at 2022-06-26 12:44:49.610773
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

    # With specified URL
    tf1IE = TF1IE(url='https://www.tf1.fr/tf1-series-films/quotidien/videos/quotidien-du-mardi-07-mai-2019.html')
    assert tf1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1IE._PROGRAM_SLUG == 'tf1-series-films/quotidien'
    assert tf1IE._SLUG == 'quotidien-du-mardi-07-mai-2019'

    # Without specified URL
    tf1IE = TF1

# Generated at 2022-06-26 12:44:52.340239
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Try initializing empty instance of class TF1IE"""
    try:
        TF1IE()
    except TypeError as exception:
        if '__init__() takes at least 2 arguments' in exception.message:
            # "super" initialization failed
            assert False

# Generated at 2022-06-26 12:44:53.485527
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-26 12:45:52.364202
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('wat_id','title')
    except:
        assert False

# Generated at 2022-06-26 12:45:53.295626
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("tf1", "tf1")

# Generated at 2022-06-26 12:45:57.207523
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie.url == url
    assert ie.program_slug == 'koh-lanta'
    assert ie.id == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-26 12:45:58.857224
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Preliminary unit test for TF1IE class
    try:
        TF1IE()
    except Exception:
        assert False
    assert True

# Generated at 2022-06-26 12:46:09.893710
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert not tf1_ie.initialized()
    assert isinstance(tf1_ie, InfoExtractor)
    assert tf1_ie.IE_NAME == 'tf1.fr'
    assert tf1_ie.IE_DESC == 'tf1.fr videos'
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:11.584655
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_obj = TF1IE()
    return tf1_obj # check if tf1_obj is a valid object

# Generated at 2022-06-26 12:46:12.406422
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t is not None

# Generated at 2022-06-26 12:46:14.697457
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.name == 'tf1'
    assert ie.domain == 'tf1.fr'
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-26 12:46:19.980362
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert isinstance(IE.suitable, staticmethod)
    assert IE.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not IE.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:20.753433
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:48.920597
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Basic test to ensure constructor of TF1IE class.
    """
    ie = TF1IE(downloader=None)
    assert ie.SUFFIX == '.json'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/%s/' + ie.BRIGHTCOVE_ID + '_default/index.min.js'


if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-26 12:48:49.704321
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-26 12:48:54.479401
# Unit test for constructor of class TF1IE
def test_TF1IE():
    r = TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert r['title'] == 'Quotidien – Première partie (11 juin 2019)'
    assert r['id'] == '13641379'

# Generated at 2022-06-26 12:49:00.715384
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html");
    print("test_TF1IE - url '%s' ok" % tf1ie.url);
    tf1ie = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html", None, None);
    print("test_TF1IE - url '%s' ok" % tf1ie.url);

# Generated at 2022-06-26 12:49:04.773860
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # URL of TF1 website
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    tf1IE = TF1IE()
    tf1IE.extract(url)



# Generated at 2022-06-26 12:49:05.658437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-26 12:49:08.717315
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable(ie.IE_NAME, ie.IE_VERSION, ie.IE_DESC)
    assert ie.extract(ie.IE_NAME, TestURLs.test_data) == TestURLs.expected_results

# Generated at 2022-06-26 12:49:11.093121
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:49:12.754476
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE = TF1IE()
    TF1IE.run()

# Generated at 2022-06-26 12:49:15.764556
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    test_video = test.url_result(test_url)
    test_video.download()