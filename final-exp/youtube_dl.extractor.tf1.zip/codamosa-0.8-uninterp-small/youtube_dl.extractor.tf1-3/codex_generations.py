

# Generated at 2022-06-26 12:41:39.228857
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:41:40.253053
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert callable(TF1IE)


# Generated at 2022-06-26 12:41:42.373676
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-26 12:41:42.847627
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-26 12:41:44.345491
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:41:45.721336
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__bases__[0] == InfoExtractor
    assert TF1IE.__bases__[1] == object
    assert TF1IE.__bases__[2] == object


# Generated at 2022-06-26 12:41:49.028798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert isinstance(t_f1_i_e, TF1IE)


# Generated at 2022-06-26 12:41:51.390722
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:41:52.998130
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()


# Generated at 2022-06-26 12:41:55.970389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert_raises_regexp(TypeError, TF1IE.__name__ + '.*__init__.*arguments', TF1IE)


# Generated at 2022-06-26 12:42:05.681289
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-26 12:42:07.147549
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test class constructor without arguments
    obj = TF1IE()
    assert obj.name == 'tf1'

# Generated at 2022-06-26 12:42:10.812731
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.name == 'tf1'
    assert tf1.ie_key() == 'TF1'

# Generated at 2022-06-26 12:42:12.965839
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE', 'tf1.fr')

# Generated at 2022-06-26 12:42:18.932086
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        info_dict = TF1IE()._real_extract("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
        assert info_dict['id'] == "TF1-Live"
        assert info_dict['series'] == "Koh-Lanta"
    except:
        print("An error occured on unit test for TF1IE constructor")
        raise


# Generated at 2022-06-26 12:42:24.745043
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie
    assert ie._TESTS

# Generated at 2022-06-26 12:42:26.357669
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE({}, {}, {});

# Generated at 2022-06-26 12:42:38.654440
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

# Generated at 2022-06-26 12:42:41.930612
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_instance = TF1IE()
    assert int_or_none(test_instance._VALID_URL) != None
    assert test_instance._TESTS != None
    assert int_or_none(test_instance._real_extract) != None

# Generated at 2022-06-26 12:42:46.195006
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.test()[0]['title'] == 'Quotidien, 1ère partie du 11 juin 2019'
    assert t.test()[1]['title'] == 'md5:bf0a6a19f6c8fac6e5ae97c8e8f9e943'

# Generated at 2022-06-26 12:43:01.771974
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, InfoExtractor)
    assert isinstance(instance, TF1IE)
    assert instance._VALID_URL
    assert instance._TESTS


# Generated at 2022-06-26 12:43:04.454239
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
        assert False
    except Exception as e:
        assert e is not None


# Generated at 2022-06-26 12:43:10.010295
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

test_TF1IE()

# Generated at 2022-06-26 12:43:12.068771
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert type(x) == TF1IE

# Generated at 2022-06-26 12:43:19.046744
# Unit test for constructor of class TF1IE
def test_TF1IE():
	video = TF1IE()
	print(video)
	#print(video.get_info('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'))
	#print(video.get_info('https://www.tf1.fr/tf1/koh-lanta-fidji/videos/ep2-la-revanche-de-l-ile-aux-jungles-partie-1.html'))
	#print(video.get_info('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'))

# Generated at 2022-06-26 12:43:20.636031
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-26 12:43:25.753547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    except Exception as e:
        assert False, e
        return
    
    assert True

# Generated at 2022-06-26 12:43:30.763294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-26 12:43:33.409643
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    except Exception as e:
        print(e)
        return False, "Unit test failed in TF1IE.py"
    return True, "Unit test successful in TF1IE.py"

# Generated at 2022-06-26 12:43:33.939608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE in info_extractor_map

# Generated at 2022-06-26 12:43:58.191425
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-26 12:43:59.615347
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Nothing to test for the moment
    pass

# Generated at 2022-06-26 12:44:05.703277
# Unit test for constructor of class TF1IE
def test_TF1IE():
	test = TF1IE()
	test_video_url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
	test._real_extract(test_video_url)

# Generated at 2022-06-26 12:44:11.364435
# Unit test for constructor of class TF1IE
def test_TF1IE():
    for test_case in TF1IE._TESTS:
        tf1ie = TF1IE()
        if 'only_matching' in test_case:
            continue
        else:
            tf1ie._real_extract(test_case['url'])

# Generated at 2022-06-26 12:44:13.402780
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie is not None

# Generated at 2022-06-26 12:44:15.018250
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("a", "b")
    t.suite()

# Generated at 2022-06-26 12:44:16.434818
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == 'tf1:videos'

# Generated at 2022-06-26 12:44:17.009578
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:27.383871
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit_test_TF1IE = TF1IE()
    InputURL = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    OutputURL = 'https://www.tf1.fr/graphql/web'
    OutputQuery = {
        'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
        'variables': json.dumps({
            'programSlug': 'koh-lanta',
            'slug': 'replay-koh-lanta-22-mai-2015',
        })
    }

# Generated at 2022-06-26 12:44:30.538062
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Simple constructor test
    # Instanciate the module
    try:
        TF1IE(None)
    except TypeError:
        pass


# Generated at 2022-06-26 12:45:24.987278
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_kaltura import KalturaIE
    instance = TF1IE()
    assert isinstance(instance, infoextractor.InfoExtractor)
    assert isinstance(instance._downloader, kaltura.KalturaIE)
    assert isinstance(instance._downloader.ie, KalturaIE)

# Generated at 2022-06-26 12:45:25.985633
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.TF1IE() == tf1

# Generated at 2022-06-26 12:45:28.429096
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-26 12:45:33.756950
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test case 1
    res = TF1IE(_VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert res.program_slug == 'quotidien-avec-yann-barthes'
    assert res.slug == 'quotidien-premiere-partie-11-juin-2019'
    assert res.url == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert res.ie_key() == 'TF1'

# Generated at 2022-06-26 12:45:36.543047
# Unit test for constructor of class TF1IE
def test_TF1IE():
        sample_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
        ie = TF1IE()
        ie.extract(sample_url)

# Generated at 2022-06-26 12:45:38.342417
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-26 12:45:39.034071
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-26 12:45:39.755598
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-26 12:45:49.077387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit = TF1IE('TF1IE', 'tf1.fr', 'md5', 'md5')
    assert unit._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert unit._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-26 12:45:50.546344
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1', 'http://www.tf1')

# Generated at 2022-06-26 12:47:55.568452
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:47:56.568734
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_class = TF1IE()
    assert type(test_class) == TF1IE

# Generated at 2022-06-26 12:47:56.996251
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:47:57.583937
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-26 12:48:07.119279
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie._TESTS[0]['info_dict']['id'] == '13641379'
    assert ie._TESTS[0]['info_dict']['upload_date'] == '20190611'


# Generated at 2022-06-26 12:48:14.424025
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Ideal case")
    test1 = TF1IE()
    print("Unkown video")
    test2 = TF1IE(TF1IE._download_json("http://wat.tv/get/android6/eL6DiPpR.json", None, None)['url'])
    print("Non-json response")
    test3 = TF1IE("http://www.wat.tv/video/dans-l-oeil-de-cyril-hanouna-" +
                  "4x4-juin-2015-5k2h2_2hjzr_.html")

    assert test1
    assert test2
    assert test3

# Generated at 2022-06-26 12:48:17.771746
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1', "ie_key() should be TF1"
    assert ie.ie_key() == 'tfi', "ie_key() should be tfi"

# Generated at 2022-06-26 12:48:19.835665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("test_TF1IE")    
    tf1 = TF1IE()
    assert_true(isinstance(tf1, InfoExtractor))


# Generated at 2022-06-26 12:48:20.247331
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:20.971834
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert "TF1IE" in globals()