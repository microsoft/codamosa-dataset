

# Generated at 2022-06-26 12:41:44.268817
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print('Testing constructor of TF1IE')
    t_f1_i_e_0 = TF1IE()


# Generated at 2022-06-26 12:41:45.004731
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert t_f1_i_e_0


# Generated at 2022-06-26 12:41:52.456962
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    t_f1_i_e._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')


# Generated at 2022-06-26 12:41:55.764496
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Assert constructor, must return value of class TF1IE
    assert TF1IE, "Constructor of class TF1IE must return value of class TF1IE"


# Generated at 2022-06-26 12:41:59.909441
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert t_f1_i_e == t_f1_i_e

# Generated at 2022-06-26 12:42:00.747559
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:42:02.227862
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert test_case_0()

# Generated at 2022-06-26 12:42:04.348811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert 'TF1IE' == TF1IE.__name__


# Generated at 2022-06-26 12:42:07.035685
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    # Check that instance is created
    assert t_f1_i_e is not None


# Generated at 2022-06-26 12:42:09.168826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(
    )

# Generated at 2022-06-26 12:42:18.327725
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test error on MediaID not present in JSON
    assert TF1IE._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') is not None

# Generated at 2022-06-26 12:42:21.862786
# Unit test for constructor of class TF1IE
def test_TF1IE():
  try:
      assert isinstance(TF1IE(), InfoExtractor)
  except AssertionError as e:
      raise AssertionError(e)

# Generated at 2022-06-26 12:42:27.871383
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check constructor of class TF1IE
    tf1ie = TF1IE()
    # Check str(tf1ie), it should return the TF1IE instance
    assert str(tf1ie) == '<TF1IE>'
    # Check repr(tf1ie), it should return the TF1IE instance
    assert repr(tf1ie) == '<TF1IE>'

# Generated at 2022-06-26 12:42:31.491722
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE("tf1.fr")
    assert("TF1IE" == tf1_ie.IE_NAME)

# Generated at 2022-06-26 12:42:32.098994
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-26 12:42:36.594823
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for the TF1IE class.
    """
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-26 12:42:38.943769
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:42:43.079071
# Unit test for constructor of class TF1IE
def test_TF1IE():
  """
  Unit test for constructor of class TF1IE
  """
  
  tmc = TF1IE(1, "Quotidien avec Yann Barthes")
  assert tmc.videoId == 1
  assert tmc.videoUrl == "wat:1"

# Generated at 2022-06-26 12:42:45.707955
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-26 12:42:53.698039
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test case to test constructor TF1IE. """
    # Create
    tf1_ie = TF1IE()

    # Check
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:07.263184
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE().assert_match(TF1IE()._WORKING_URL)

# Generated at 2022-06-26 12:43:09.308474
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        pass


# Generated at 2022-06-26 12:43:15.622269
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE(TF1IE._VALID_URL, url)
    print(ie)
    '''
    #print(vars(ie))
    pass

# Generated at 2022-06-26 12:43:18.179951
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # Test for class attribute
    assert ie.ie_key() == 'TF1'

# Generated at 2022-06-26 12:43:24.805350
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.name == 'tf1'
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:25.459597
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:30.132398
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i.name == 'TF1'
    assert i.ie_key() == 'TF1'
    assert i.success == False

# Generated at 2022-06-26 12:43:39.784542
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[0]['url'] == url
    assert TF1IE._TESTS[0]['info_dict']['id'] == '13641379'
    assert TF1IE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:43:40.683048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        assert False, e

# Generated at 2022-06-26 12:43:42.599487
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:44:05.999813
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.suite()

# Generated at 2022-06-26 12:44:17.565835
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE", "www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html", "13641379", "mp4")
    TF1IE("TF1IE", "www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html", "13641379", "mp4")
    TF1IE("TF1IE", "www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", "13641379", "mp4")

# Generated at 2022-06-26 12:44:18.105402
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-26 12:44:21.993937
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('wat:999999999999')
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:44:29.597851
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
        Check that the constructor of TF1IE is working.
    """
    tf1_ie = TF1IE()

    """
        Check that build_request_body method works.
    """
    result = tf1_ie.build_request_body({"variables": "test"})
    expected = {"id": "9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f", "variables": "test"}
    assert result == expected

# Generated at 2022-06-26 12:44:36.658669
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    print(obj._TESTS[0]['url'])
    print(obj._TESTS[0]['info_dict'])
    assert obj._TESTS[0]['info_dict']['id'] == '13641379'
    assert obj._TESTS[0]['info_dict']['duration'] == 1738
    assert obj._TESTS[0]['info_dict']['upload_date'] == '20190611'

# Generated at 2022-06-26 12:44:38.620671
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:44:39.313670
# Unit test for constructor of class TF1IE
def test_TF1IE():
	
	pass

# Generated at 2022-06-26 12:44:49.611391
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    if tf1_ie._VALID_URL.match('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'):
        print(tf1_ie.match['program_slug'])
        print(tf1_ie.match['id'])

    if (tf1_ie._VALID_URL.match('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')):
        print(tf1_ie.match['program_slug'])
        print(tf1_ie.match['id'])


# Generated at 2022-06-26 12:44:52.612790
# Unit test for constructor of class TF1IE
def test_TF1IE():
  ie = TF1IE()
  ie.ie_key() == 'TF1'
  ie.ie_key() == ie.IE_NAME
  ie.ie_key() != 'Liste des émissions'
  ie.ie_key() != 'Liste des émissions (2)'

# Generated at 2022-06-26 12:45:51.155950
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE == TF1IE

# Generated at 2022-06-26 12:45:53.294621
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """
    tf1 = TF1IE()
    assert tf1 != None


# Generated at 2022-06-26 12:45:55.549307
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert "TF1IE" in str(instance)
    assert re.search(r'https?://(?:www\.)?tf1\.fr/', instance._VALID_URL)

# Generated at 2022-06-26 12:45:59.158833
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.matches('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not t.matches('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:46:02.634600
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:04.035391
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE();
    assert t != None;
    assert 'TF1IE' in str(t);

# Generated at 2022-06-26 12:46:05.740433
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:46:09.690021
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_module = TF1IE()
    t_module._real_extract('https://www.tf1.fr/jt-20h/videos/replay-jt-20h-du-27-juin.html')

# Generated at 2022-06-26 12:46:10.206483
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:46:12.793642
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:48:35.079795
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-26 12:48:35.735376
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    print(t)

# Generated at 2022-06-26 12:48:38.850968
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('https://www.tf1.fr/tf1/dallas/videos/dallas-replay-episode-1-saison-3.html')
    assert t.id == 'dallas-replay-episode-1-saison-3'

# Generated at 2022-06-26 12:48:44.357057
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Without args
    TF1IE()
    # With non-video-id args
    TF1IE(url='http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE(url='https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:48:45.859291
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1'

# Generated at 2022-06-26 12:48:46.967759
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:48.119155
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:48:52.589390
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html", "TF1IE")
    assert ie.program_slug == 'koh-lanta'
    assert ie.id == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-26 12:48:53.354873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-26 12:48:54.410040
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test TF1IE constructor"""
    obj = TF1IE()
    assert obj