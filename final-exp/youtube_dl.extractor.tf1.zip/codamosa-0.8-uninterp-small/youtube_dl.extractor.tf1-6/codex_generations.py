

# Generated at 2022-06-26 12:41:38.790731
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-26 12:41:41.038442
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_case_0()

# Generated at 2022-06-26 12:41:49.783390
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Set up some mock objects
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    # Call the constructor for TF1IE
    t_f1_i_e = TF1IE()

    # Call the _real_extract method for TF1IE
    info_dict = t_f1_i_e._real_extract(url)

    # Assert the expected values
    assert info_dict['id'] == '13641379'
    assert info_dict['ext'] == 'mp4'
    assert info_dict['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'

# Generated at 2022-06-26 12:41:52.225527
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_0 = TF1IE()


# Generated at 2022-06-26 12:41:56.647871
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:42:09.013238
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert t_f1_i_e_0._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:10.880625
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_0 = TF1IE()


# Generated at 2022-06-26 12:42:19.968153
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    #
    # self.format_id = format_id
    # try: self.format_id = int(format_id)
    # except (TypeError, ValueError): self.format_id = format_id
    # self.urls = ['http://www.wat.tv/get/%s.mp4' % format_id,
    #              'http://www.wat.tv/get/%s.flv' % format_id,
    #              'http://www.wat.tv/get/%s.m3u8' % format_id]
    # self.ie = WatIE(format_id)
    # self.title = self.ie.title
    # self.description = self.ie.description
    # self.thumbnail = self.ie

# Generated at 2022-06-26 12:42:22.351480
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().__name__ == 'TF1IE'

# Generated at 2022-06-26 12:42:22.958526
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Verify test results
    assert True


# Generated at 2022-06-26 12:42:33.679332
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    ie.extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    ie.extract("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-26 12:42:35.064365
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:42:46.803818
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE(None)
    assert IE.IE_NAME == 'tf1'
    assert IE.IE_DESC == 'TF1 Replay'
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:49.756143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        raise Exception("Error in constructor of class TF1IE")

# Generated at 2022-06-26 12:42:57.434937
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie.url == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

# Generated at 2022-06-26 12:43:08.421682
# Unit test for constructor of class TF1IE

# Generated at 2022-06-26 12:43:16.526311
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'


# Generated at 2022-06-26 12:43:20.634593
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie is not None
    tf1ie = TF1IE(TF1IE())
    assert tf1ie is not None

# Generated at 2022-06-26 12:43:25.734911
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:28.729494
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert isinstance(inst, TF1IE)

# Generated at 2022-06-26 12:43:39.402623
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:40.368855
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_object = TF1IE()
    assert(TF1IE_object.ie_key() == "tf1")

# Generated at 2022-06-26 12:43:42.411054
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Tests for TF1IE"""
    # This is needed in order for the tests for TF1IE to run properly
    TF1IE.ie_key = 'wat'

    # TF1IE.__init__() returns a TF1IE object
    assert isinstance(TF1IE(), TF1IE)

# Generated at 2022-06-26 12:43:42.840361
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:43:45.766448
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-26 12:43:52.717144
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _ = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    # assert False, 'Test TF1IE'
    # assert False, 'Test for testing constructor of class TF1IE'



# Generated at 2022-06-26 12:43:53.345065
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().get_url_regex() == TF1IE._VALID_URL

# Generated at 2022-06-26 12:43:55.887498
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_constructor = getattr(TF1IE, 'suitable')
    assert class_constructor("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html") == True

# Generated at 2022-06-26 12:43:58.829516
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert isinstance(tf1, TF1IE)


# Generated at 2022-06-26 12:44:01.623797
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('test_TF1IE', 'tf1.fr/test/test.html')

# Generated at 2022-06-26 12:44:25.472513
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    return TF1IE().suitable(url)


# Generated at 2022-06-26 12:44:26.674668
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-26 12:44:27.532674
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test.initialize()

# Generated at 2022-06-26 12:44:30.980422
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:44:38.345498
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import requests
    tf1_page = requests.get('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    wat_id = re.search(r"streamId\s*=\s*'([^']+)'", tf1_page.text).group(1)

    # Test whether the constructor of InfoExtractors works,
    # whether the returned InfoExtractor has the right type,
    # and whether the expected JSON metadata was extracted.
    tf1_ie = TF1IE(tf1_page.url)
    assert tf1_ie.__class__.__name__ == TF1IE.__name__
    assert tf1_ie.IE_NAME == TF1IE.IE_NAME

# Generated at 2022-06-26 12:44:44.123604
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('id')
    assert tf1.IE_NAME == 'tf1'
    assert tf1._VALID_URL == (
        'https?://(?:www\\.)?tf1\\.fr/[^/]+/'
        '(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html')


# Generated at 2022-06-26 12:44:50.722148
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url_test_first = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    url_test_second = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    tf1_ie_object = TF1IE()
    assert tf1_ie_object._real_extract(url_test_first)
    assert tf1_ie_object._real_extract(url_test_second)

# Generated at 2022-06-26 12:44:52.535718
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Class to test TF1IE constructor"""
    test_obj = TF1IE(None)
    assert test_obj is not None

# Generated at 2022-06-26 12:44:53.405878
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert(1 == 1)

# Generated at 2022-06-26 12:45:04.368312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'



# Generated at 2022-06-26 12:45:58.318368
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test the constructor of class TF1IE
    global InfoExtractor

    InfoExtractor = TF1IE

# Generated at 2022-06-26 12:45:59.061805
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a=TF1IE()

# Generated at 2022-06-26 12:46:01.933620
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-26 12:46:02.483138
# Unit test for constructor of class TF1IE
def test_TF1IE():
  TF1IE()

# Generated at 2022-06-26 12:46:12.912124
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html';
    tf1 = TF1IE(test_url, 'test');
    assert (tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html');
    assert (tf1.program_slug == 'quotidien-avec-yann-barthes');
    assert (tf1.slug == 'quotidien-premiere-partie-11-juin-2019');

# Generated at 2022-06-26 12:46:14.877464
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t2 = TF1IE()
    assert t.__class__ == t2.__class__
    assert t.__class__ == TF1IE

# Generated at 2022-06-26 12:46:15.911852
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import WatTest

    return WatTest(TF1IE).run()

# Generated at 2022-06-26 12:46:16.846193
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie

# Generated at 2022-06-26 12:46:21.104191
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:46:21.653295
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:31.472949
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-26 12:48:33.570933
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-26 12:48:34.025820
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:35.236858
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Succeeds to build an info extractor object
    IE = TF1IE()
    assert IE

# Generated at 2022-06-26 12:48:43.366577
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE(None)
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:48:52.992302
# Unit test for constructor of class TF1IE

# Generated at 2022-06-26 12:48:56.388924
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''
    Test to check whether the object of class TF1IE has been constructed properly
    '''
    obj = TF1IE('tf1', 'tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015')
    assert obj.ie_key() == 'TF1'

# Generated at 2022-06-26 12:49:05.462646
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test constructor of class TF1IE
    
    It test with a valid url and with an invalid url
    """
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    
    assert TF1IE().working == True
    
    assert TF1IE().suitable(url) == True
    assert TF1IE().suitable("https://www.tf1.fr/invalid") == False
    

# Generated at 2022-06-26 12:49:07.370882
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == TF1IE._VALID_URL

test_TF1IE()

# Generated at 2022-06-26 12:49:09.723859
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'