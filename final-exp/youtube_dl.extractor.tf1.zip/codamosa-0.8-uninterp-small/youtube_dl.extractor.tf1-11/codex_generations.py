

# Generated at 2022-06-26 12:41:41.871248
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:41:43.658861
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE() != None)

# Generated at 2022-06-26 12:41:45.245908
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:41:57.516493
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE()._TESTS[0].get('info_dict').get('id') == '13641379'
    assert TF1IE()._TESTS[0].get('info_dict').get('title') == 'md5:f392bc52245dc5ad43771650c96fb620'
    assert TF1IE()._TESTS[0].get('info_dict').get('description') == 'md5:a02cdb217141fb2d469d6216339b052f'

# Unit tests for "def _real_extract"

# Generated at 2022-06-26 12:42:02.846424
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert isinstance(t_f1_i_e, TF1IE)

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-26 12:42:10.673368
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_1 = TF1IE()
    assert t_f1_i_e_1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:12.827744
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_1 = TF1IE()


# Generated at 2022-06-26 12:42:18.213993
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE()._real_extract(url) == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-26 12:42:29.977862
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert t_f1_i_e._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)'

# Generated at 2022-06-26 12:42:31.907181
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_1 = TF1IE()


# Generated at 2022-06-26 12:42:48.204863
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    t_f1_i_e = TF1IE()
    assert url == t_f1_i_e.url
    assert 'TF1' == t_f1_i_e._NETRC_MACHINE
    assert 'WAT' == t_f1_i_e._API_KEY
    assert 'https://www.tf1.fr/graphql/web' == t_f1_i_e._GRAPHQL_URL

# Generated at 2022-06-26 12:42:50.723765
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_0 = TF1IE()

# Generated at 2022-06-26 12:42:54.202041
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Testing constructor of class TF1IE")
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:42:55.922463
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert test_case_0() == None


# Generated at 2022-06-26 12:43:01.353575
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert t_f1_i_e
    assert_equal(type(t_f1_i_e), TF1IE)

# Test for member function _real_extract of class TF1IE

# Generated at 2022-06-26 12:43:02.136562
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f_1_i_e = TF1IE()


# Generated at 2022-06-26 12:43:03.898721
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:43:11.560405
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:43:13.569668
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert(t_f1_i_e.test_test_test() == 'test')
# t_f1_i_e_0= TF1IE()
# test_TF1IE()

# Generated at 2022-06-26 12:43:14.949772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:43:31.775610
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:43:33.158824
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE


# Generated at 2022-06-26 12:43:35.517944
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import WatIE, TF1IE

    ie = WatIE('wat:13641379')
    assert isinstance(ie, TF1IE)

# Generated at 2022-06-26 12:43:46.521297
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        info_dict = TF1IE()._real_extract(
            "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
        assert info_dict['id'] == '2c79d3ef5c0622b17e70d30e9ae70171aafb21fb0e559848d97866b829c61873'
    except Exception as e:
        print(e)
    try:
        TF1IE()._real_extract(
            "https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-26 12:43:47.351700
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:43:53.950217
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t.__name__ == 'TF1'

# Generated at 2022-06-26 12:43:55.511110
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t

# Generated at 2022-06-26 12:44:07.960843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1.fr'
    assert ie.IE_DESC == 'tf1.fr'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:10.490865
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testcase = TF1IE()
    assert testcase


# Generated at 2022-06-26 12:44:20.180045
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert tf1.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert tf1.IE_NAME == 'TF1'
    assert tf1.ie_key() == 'TF1'
    assert tf1.VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:45.064791
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-26 12:44:50.836698
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    test_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert TF1IE(test_url, None).compile_url(test_url) == TF1IE(test_url, None).url
    assert TF1IE(test_url, None).compile_id(test_url) == TF1IE(test_url, None).suitable(test_url)

# Generated at 2022-06-26 12:44:52.340498
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from yle_dl.extractors.tf1 import TF1IE
    assert TF1IE is not None

# Generated at 2022-06-26 12:44:59.996226
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    a = TF1IE(url)
    assert a.program_slug == 'quotidien-avec-yann-barthes'
    assert a.slug == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-26 12:45:01.034499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()

# Generated at 2022-06-26 12:45:02.679636
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.ie_key = 'TF1'
    return t

# Generated at 2022-06-26 12:45:04.846703
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:45:06.672941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global TF1IE
    TF1IE = __import__("tf1").TF1IE
    TF1IE._VALID_URL = XD

# Generated at 2022-06-26 12:45:07.456097
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor_test(TF1IE)

# Generated at 2022-06-26 12:45:08.232629
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL

# Generated at 2022-06-26 12:46:09.335415
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:46:12.873874
# Unit test for constructor of class TF1IE
def test_TF1IE():
    desired_value = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert(desired_value==TF1IE._VALID_URL)

# Generated at 2022-06-26 12:46:15.399229
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    TF1IE._real_extract(TF1IE(), url)

# Generated at 2022-06-26 12:46:16.394838
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test TF1IE constructer """
    TF1IE()

# Generated at 2022-06-26 12:46:18.333497
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE( 'tf1', 'tf1' )
    assert( t.get_info_extractor() == TF1IE )

# Generated at 2022-06-26 12:46:18.827544
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:46:20.079667
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE
    assert tf1_ie

# Generated at 2022-06-26 12:46:28.192916
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert obj._VALID_URL == "https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html"
    assert obj.program_slug == "koh-lanta"
    assert obj.slug == "replay-koh-lanta-22-mai-2015"


# Generated at 2022-06-26 12:46:28.977076
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import TF1IE
    assert TF1IE

# Generated at 2022-06-26 12:46:31.362545
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert "TF1IE" == tf1.IE_NAME

# Generated at 2022-06-26 12:48:45.100023
# Unit test for constructor of class TF1IE
def test_TF1IE():

    t = TF1IE()


# Generated at 2022-06-26 12:48:54.510674
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TFIE = TF1IE()
    assert TFIE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-26 12:48:59.678923
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    extractor = TF1IE().get_IE(test_url)

    assert extractor.__class__.__name__ == 'TF1IE'
    assert extractor._VALID_URL == TF1IE._VALID_URL


# Generated at 2022-06-26 12:49:02.726206
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:49:03.200977
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:49:07.113789
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE();
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:49:09.726093
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:49:14.434858
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/video/replay-koh-lanta-22-mai-2015.html")
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:49:15.588328
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie = TF1IE(ie)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:49:16.557726
# Unit test for constructor of class TF1IE
def test_TF1IE():
   ie = TF1IE('id','url')
   ie.extract()