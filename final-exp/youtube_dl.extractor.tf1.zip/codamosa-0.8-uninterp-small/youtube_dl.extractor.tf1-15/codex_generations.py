

# Generated at 2022-06-26 12:41:41.574083
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print('*** Test case 0 ***')
    test_case_0()

# Generated at 2022-06-26 12:41:46.271227
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (t_f1_i_e_0 is not None), "TF1IE constructor failed"
    assert (str(type(t_f1_i_e_0)) == "<class '__main__.TF1IE'>" ), "Object created is not of type TF1IE"

# Generated at 2022-06-26 12:41:47.757655
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() is not None

# Generated at 2022-06-26 12:41:48.741262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-26 12:41:51.161619
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_0 = TF1IE()



# Generated at 2022-06-26 12:41:52.003166
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:41:53.532738
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()

# Generated at 2022-06-26 12:41:55.946770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert isinstance(t_f1_i_e, TF1IE)


# Generated at 2022-06-26 12:42:01.265830
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_0 = TF1IE()
    if not t_f1_i_e_0:
        raise ValueError('Cannot instantiate TF1IE')


# Generated at 2022-06-26 12:42:03.380996
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_1 = TF1IE()


# Generated at 2022-06-26 12:42:12.136513
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("www.index.com")
    assert ie.tf1_urls == "www.index.com"

# Generated at 2022-06-26 12:42:14.981822
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE().__class__
    instance = IE(IE._build_url(
        'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'))
    assert instance.url == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-26 12:42:16.776983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_initialize()

# Generated at 2022-06-26 12:42:18.120128
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(InfoExtractor)

# Generated at 2022-06-26 12:42:19.514652
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie

# Generated at 2022-06-26 12:42:30.825373
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:31.255569
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:42:35.958708
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("testing", "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    return

# Generated at 2022-06-26 12:42:38.498886
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1._real_extract("")
    tf1._download_json("")

# Generated at 2022-06-26 12:42:40.984893
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE('wat')
    assert x.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-26 12:42:52.859501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE')

# Generated at 2022-06-26 12:42:55.078595
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # make sure the constructor behaves properly
    assert TF1IE()

# Generated at 2022-06-26 12:42:56.354950
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie == TF1IE('TF1.fr')

# Generated at 2022-06-26 12:42:57.600640
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()

# Generated at 2022-06-26 12:43:01.632223
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    print(instance._VALID_URL)
    print(instance._TESTS)
    print(instance._real_extract)

# Generated at 2022-06-26 12:43:03.844426
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    tf1.extract("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-26 12:43:08.196201
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('koh-lanta').assert_match('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('documentaire').assert_match('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:43:17.968317
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    global TF1IE
    TF1IE = IE
    TF1IE._download_json = lambda *args, **kwargs: {}

# Generated at 2022-06-26 12:43:25.370400
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    t.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-26 12:43:31.945264
# Unit test for constructor of class TF1IE
def test_TF1IE():
    input_object = 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE(input_object)


# Generated at 2022-06-26 12:43:55.316564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/publicite/')

# Generated at 2022-06-26 12:43:58.330333
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._downloader.params.get('nocheckcertificate', False) == True

# Generated at 2022-06-26 12:44:07.421060
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1 = TF1IE()
    tf1._downloader = Downloader(params={})
    tf1._real_initialize(url)
    assert tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:44:08.927152
# Unit test for constructor of class TF1IE
def test_TF1IE():
    resp = TF1IE()

# Generated at 2022-06-26 12:44:10.135878
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:14.086211
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:44:15.017891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('abc', 'abc', 'abc')

# Generated at 2022-06-26 12:44:17.143609
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    with open("test_constructor.txt","w") as f1:
        f1.write(str(ie))

# Generated at 2022-06-26 12:44:19.531174
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.name == 'tf1'
    assert ie.ie_key() == 'tf1'
    assert ie.host == 'tf1.fr'

# Generated at 2022-06-26 12:44:27.053548
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import extractor
    ie = extractor.TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert(ie.url == 'https://www.tf1.fr/graphql/web')
    assert(ie.title == None)
    assert(ie.slug == 'replay-koh-lanta-22-mai-2015')
    assert(ie.program_slug == 'koh-lanta')

# Generated at 2022-06-26 12:45:13.722431
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:45:14.494645
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE({}).tf1i

# Generated at 2022-06-26 12:45:21.268796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testobj = TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert testobj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:45:23.343994
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test if the class can be initialized
    tf1_ie = TF1IE(None)
    assert isinstance(tf1_ie, TF1IE)

# Generated at 2022-06-26 12:45:31.542409
# Unit test for constructor of class TF1IE
def test_TF1IE():
	url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'


# Generated at 2022-06-26 12:45:36.713796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor_test(
        TF1IE,
        [
            # It's the only way to trigger the wat: url_transparent
            ('wat:ko', {
                'id': 'ko',
                'url': 'wat:ko',
                'info_dict': {
                    'id': 'ko',
                    'ext': 'mp4',
                },
            }),
        ],
        # Can't use the usual tests because the wat: scheme isn't supported
        # by FileDownloader
        test_module=False,
        test_py_version_lower='2.7.9',
    )

# Generated at 2022-06-26 12:45:37.283206
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('md5')

# Generated at 2022-06-26 12:45:45.869827
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(object)
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:45:47.502996
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE
    TF1IE.suite()


# Generated at 2022-06-26 12:45:54.047544
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('http', {}, 'tf1.fr')
    assert obj.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert obj._VALID_URL == '^https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html$', 'not equal'

# Generated at 2022-06-26 12:47:57.162245
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(None)
    assert obj != None


# Generated at 2022-06-26 12:48:06.066332
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:48:09.230360
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:48:10.177311
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("")

# Generated at 2022-06-26 12:48:17.630429
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:48:19.490258
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # only test the constructor. They function is too coplex to be tested
    instance = TF1IE()

# Unit tests for the method extract()

# Generated at 2022-06-26 12:48:25.733129
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1._download = lambda *args, **kwargs: {
        'data': {
            'videoBySlug': {
                'streamId': '13641379'
            }
        }
    }

# Generated at 2022-06-26 12:48:28.731677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.IE_NAME
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    ie

# Generated at 2022-06-26 12:48:30.456613
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if __name__ == '__main__':
        print(TF1IE)

# Generated at 2022-06-26 12:48:30.999122
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass