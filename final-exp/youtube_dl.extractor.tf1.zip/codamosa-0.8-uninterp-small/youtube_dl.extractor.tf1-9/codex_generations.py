

# Generated at 2022-06-26 12:41:41.870972
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()


# Generated at 2022-06-26 12:41:42.706602
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_ = TF1IE()

# Generated at 2022-06-26 12:41:47.068326
# Unit test for constructor of class TF1IE
def test_TF1IE():
    args = ['', '']
    t_f1_i_e = TF1IE(*args)
    assert t_f1_i_e._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:41:49.394199
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)


# Generated at 2022-06-26 12:41:58.728963
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:06.128163
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e = TF1IE()
    assert_equals(t_f1_i_e._VALID_URL, r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')


# Generated at 2022-06-26 12:42:18.640804
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_0 = TF1IE()
    assert t_f1_i_e_0._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:21.027042
# Unit test for constructor of class TF1IE
def test_TF1IE():
    checker = tf1_ie.TF1IE()



# Generated at 2022-06-26 12:42:21.416198
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-26 12:42:23.341957
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t_f1_i_e_new = TF1IE()


# Generated at 2022-06-26 12:42:29.761325
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract()

# Generated at 2022-06-26 12:42:33.673244
# Unit test for constructor of class TF1IE
def test_TF1IE():
    u"""Basic test cases."""

    # construct an object to test
    tf1ie = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert tf1ie

    # test the ie_key is correct
    assert tf1ie.ie_key() == "TF1"

    # test the ie_id is correct
    assert tf1ie.ie_id() == "TF1IE"

    # test the url is correct
    assert tf1ie.url == "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"

    # test if regular expression is correct

# Generated at 2022-06-26 12:42:46.461678
# Unit test for constructor of class TF1IE

# Generated at 2022-06-26 12:42:54.419621
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create instance of TF1IE class
    tf1 = TF1IE()
    # Check if _VALID_URL is set
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:42:55.233901
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class constructor of TF1IE."""
    TF1IE()

# Generated at 2022-06-26 12:42:56.742096
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE = TF1IE(extractor=None)
    assert(TF1IE is not None)

# Generated at 2022-06-26 12:43:01.845278
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from ..ttvn import TTVNIE
    # constructor
    tf1ie = TF1IE()
    # format_id should be replaced
    assert tf1ie._format_id('thumbnail') == 'video-information-thumbnail'

# Generated at 2022-06-26 12:43:03.217947
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE


# Generated at 2022-06-26 12:43:05.271868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_html import test_tf1_programme_build
    test_tf1_programme_build(TF1IE())

# Generated at 2022-06-26 12:43:10.081660
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-26 12:43:30.292232
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE_dummy_obj = InfoExtractor()
    IE_dummy_obj.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    IE_dummy_obj.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    IE_dummy_obj.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    #Test when url doesn't match

# Generated at 2022-06-26 12:43:32.110028
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("tf1.fr", "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

test_TF1IE()

# Generated at 2022-06-26 12:43:33.194899
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-26 12:43:35.691680
# Unit test for constructor of class TF1IE
def test_TF1IE():
  x = TF1IE({})
  assert isinstance(x, InfoExtractor)
  assert x.ie_key() == 'TF1'
  assert x.IE_NAME == '1fichier'
  assert x.geo_countries == ['FR']
  assert x.host == 'www.tf1.fr'

# Generated at 2022-06-26 12:43:43.996379
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.get_program_slug('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie.get_slug('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-26 12:43:45.358548
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t

# Generated at 2022-06-26 12:43:47.069232
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-26 12:43:52.306938
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://wat.tf1.fr/videos/5_5_547_36sedh5pfzu5x5x5x5x5x5x5x5x5.mp4"
    TF1IE(url)

# Generated at 2022-06-26 12:43:53.914266
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance,TF1IE)

# Generated at 2022-06-26 12:43:59.905033
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == "tf1"
    assert obj.ie_id() == None
    assert obj.ie_name() == "TF1"
    assert obj.info_extractors() == [TF1IE]

# Generated at 2022-06-26 12:44:23.029904
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert isinstance(x, TF1IE)


# Generated at 2022-06-26 12:44:23.910001
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-26 12:44:24.441972
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:26.294673
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('tf1:wat123456', 'mediaId', 'mediaTitle')

# Generated at 2022-06-26 12:44:30.495216
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    tf1 = TF1IE(url)
    assert tf1.SUFFIX == 'tf1'

# Generated at 2022-06-26 12:44:34.218793
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from_url = TF1IE._build_url_result(TF1IE._TESTS[0], TF1IE)
    assert from_url.url == TF1IE._TESTS[0]['url']
    assert from_url.result['id'] == TF1IE._TESTS[0]['info_dict']['id']

# Generated at 2022-06-26 12:44:44.316444
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    a = TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert a['_type'] == 'url_transparent'
    b = TF1IE()._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert b is None
    c

# Generated at 2022-06-26 12:44:44.894092
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:44:47.219043
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = InfoExtractor("TF1")
    assert(info_extractor.IE_NAME == "TF1")

# Generated at 2022-06-26 12:44:50.426955
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    TF1IE.suitable(url)

    TF1IE(url)._real_initialize()

# Generated at 2022-06-26 12:45:55.152984
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_constructor = getattr(TF1IE, '__init__')
    assert 'proxy' in class_constructor.__code__.co_varnames
    assert 'ie' in class_constructor.__code__.co_varnames
    assert 'url' in class_constructor.__code__.co_varnames
    assert 'display_id' in class_constructor.__code__.co_varnames
    assert 'downloader' in class_constructor.__code__.co_varnames
    assert len(class_constructor.__code__.co_varnames) == 5
    assert '_download_json' in dir(TF1IE)
    assert '_download_webpage' in dir(TF1IE)
    assert '_real_extract' in dir(TF1IE)

# Generated at 2022-06-26 12:46:00.169237
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-26 12:46:01.614069
# Unit test for constructor of class TF1IE
def test_TF1IE():
    _obj = TF1IE()
    assert _obj is not None

# Generated at 2022-06-26 12:46:03.960723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-26 12:46:08.258647
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.ie_name() == 'TF1'

# Generated at 2022-06-26 12:46:10.086535
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().get_count() == 0

# Must to create an instance of class TF1IE
tf1 = TF1IE()


# Generated at 2022-06-26 12:46:11.468491
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """test of test_TF1IE constructor."""

    TF1IE(None, None)

# Generated at 2022-06-26 12:46:14.411242
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie.ie_key() == 'tf1'
    assert tf1_ie.ie_key() in TF1IE.ie_key()
#Unit test for tf1_ie.extract()

# Generated at 2022-06-26 12:46:15.474076
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-26 12:46:18.633775
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE("dummy")
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:48:37.060257
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:39.526826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:48:43.424137
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == 'tf1'
    assert t._VALID_URL == [r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html']

# Generated at 2022-06-26 12:48:43.978749
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-26 12:48:44.533669
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-26 12:48:54.015241
# Unit test for constructor of class TF1IE
def test_TF1IE():
	instance = TF1IE({})
	assert isinstance(instance, InfoExtractor)
	assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:48:55.298834
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        assert True

# Generated at 2022-06-26 12:49:03.472070
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ret_obj = TF1IE()
    assert ret_obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-26 12:49:07.113055
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    # Check name of the class
    assert IE.IE_NAME == 'tf1'
    # Check if the URL is valid
    assert IE.working == True
    # Check if it is working
    assert IE.test()

# Generated at 2022-06-26 12:49:10.450190
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # load url to assert that the next url has loaded
    info_extractor = InfoExtractor({}, tf1=True)
    info_extractor._real_initialize()
    assert info_extractor._VALID_URL == TF1IE._VALID_URL
    assert info_extractor._TESTS[0] == TF1IE._TESTS[0]

