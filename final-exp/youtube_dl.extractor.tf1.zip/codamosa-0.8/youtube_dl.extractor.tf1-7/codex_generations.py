

# Generated at 2022-06-12 18:17:34.418485
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE._call_api()
    info['program_slug'] = 'le-debat'
    info['slug'] = 'le-debat-22-novembre-2018'
    tf1 = TF1IE()
    assert tf1.match('https://www.tf1.fr/tf1/le-debat/videos/le-debat-22-novembre-2018.html')
    assert tf1._VALID_URL == '^https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html$'

# Generated at 2022-06-12 18:17:36.438522
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert TF1IE
    except NameError:
        assert False, "Class TF1IE don't implemented"

# Generated at 2022-06-12 18:17:38.957694
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:17:49.740732
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit tests of class TF1IE"""
    # Constructor
    extractor = TF1IE()
    assert extractor.IE_NAME == 'telefilm'
    assert TF1IE.IE_NAME == 'telefilm'
    assert extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:17:52.003991
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('','groupe-tf1')
    TF1IE('','faites-entrer-l-accuse')

# Generated at 2022-06-12 18:17:53.496768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x=TF1IE()
    print(x)

# Generated at 2022-06-12 18:17:56.077900
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(info_extractor_test)

if __name__ == "__main__":
    test_TF1IE()

# Generated at 2022-06-12 18:17:57.875802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("TF1IE")._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:17:58.893287
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("test case")

# Generated at 2022-06-12 18:18:00.117200
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert TF1IE
    except AssertionError:
        assert False

# Generated at 2022-06-12 18:18:09.282286
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.name == "TF1"
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:18.904564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.demo_mode
    assert ie.workflow
    assert ie.context
    assert ie.context.get('id') == '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'
    assert ie.context.get('variables') == {'programSlug': 'test', 'slug': 'test'}
    assert ie.json_query == 'https://www.tf1.fr/graphql/web'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:24.516802
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE()

# Generated at 2022-06-12 18:18:34.980747
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    ie = tf1IE._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie['id'] == '13641379'
    assert ie['ext'] == 'mp4'
    assert ie['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'

# Generated at 2022-06-12 18:18:35.862473
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-12 18:18:36.538239
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE

# Generated at 2022-06-12 18:18:37.566878
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('TF1IE') == TF1IE

# Generated at 2022-06-12 18:18:39.569599
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == TF1IE._VALID_URL



# Generated at 2022-06-12 18:18:40.408967
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Unit tests for class TF1IE

# Generated at 2022-06-12 18:18:42.518894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as ex:
        print(ex)


# Generated at 2022-06-12 18:18:58.818359
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .factory import Factory
    from .wat import WatIE
    ie = Factory.create(TF1IE)
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert isinstance(ie, TF1IE)

    ie = Factory.create(WatIE)
    ie.extract('wat:13641379')
    assert isinstance(ie, WatIE)

# Generated at 2022-06-12 18:19:02.494592
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test existence of module
    try:
        x = TF1IE
    except NameError:
        raise NameError("This module doesn't exist")
    # Test constructor
    Tests = TF1IE()
    assert(Tests.__class__.__name__ == "TF1IE")

# Generated at 2022-06-12 18:19:04.415088
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test for the constructor of TF1IE
    """
    t = TF1IE()
    assert t.SUITABLE_FORMATS == ['wat']

# Generated at 2022-06-12 18:19:05.647873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert isinstance(inst, TF1IE)

# Generated at 2022-06-12 18:19:10.376646
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for one of the cases for which TF1IE.suitable
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-12 18:19:11.460276
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()

# Generated at 2022-06-12 18:19:12.737742
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-12 18:19:16.863760
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE("tf1IE")
    except NameError as e:
        assert str(e) == "name 'TF1IE' is not defined"
    except Exception as e:
        assert False, e.__class__.__name__
    else:
        assert True

# Generated at 2022-06-12 18:19:18.103879
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:19:18.996454
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.test()

# Generated at 2022-06-12 18:19:43.414966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    test = tf1.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert test

# Generated at 2022-06-12 18:19:51.605685
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_class=TF1IE()
    assert test_class._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:53.106022
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Tests whether constructor of class TF1IE can pass"""
    tf1 = TF1IE()
    assert tf1 != None

# Generated at 2022-06-12 18:19:54.870078
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.server_url == 'https://www.tf1.fr/graphql/web'

# Generated at 2022-06-12 18:19:57.585259
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert re.match(TF1IE._VALID_URL, tf1.VALID_URL)



# Generated at 2022-06-12 18:20:01.164352
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(url)._extract()

# Generated at 2022-06-12 18:20:02.559095
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_ie = TF1IE(None)
    assert test_ie._VALID_URL

# Generated at 2022-06-12 18:20:03.413468
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, None)

# Generated at 2022-06-12 18:20:04.196822
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._TESTS

# Generated at 2022-06-12 18:20:13.177539
# Unit test for constructor of class TF1IE
def test_TF1IE():
    #  test_url is the url that we send as argument to the constructor of the class
    #  We can check the type of the class by using the type() function
    test_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE().suitable(test_url)
    #  We check if the instance of the class has a method named _real_extract
    assert hasattr(TF1IE(), '_real_extract')
    #  The following if statement checks if the retuned value for the method
    # _real_extract is a dictionary

# Generated at 2022-06-12 18:20:57.480445
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = TF1IE()
    assert tester.init_params_and_vm_args() == (
        {'behaviours': 'store+extract'},
        {'force-download': 'no'})



# Generated at 2022-06-12 18:21:00.788319
# Unit test for constructor of class TF1IE
def test_TF1IE():
	class_instance = TF1IE()
	assert class_instance.__class__.__name__ == TF1IE.__name__

if __name__ == "__main__":
	test_TF1IE()

# Generated at 2022-06-12 18:21:01.624132
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('tf1')
    assert obj

# Generated at 2022-06-12 18:21:02.785555
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # check the existence of TF1IE instance
    assert TF1IE()

# Generated at 2022-06-12 18:21:03.674810
# Unit test for constructor of class TF1IE
def test_TF1IE():
  test_TF1IE = TF1IE()

# Generated at 2022-06-12 18:21:08.050006
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from . import assert_equal
    assert_equal(str(TF1IE([''])), '<TF1IE(tf1)>')
    assert_equal(str(TF1IE(['https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'])), '<TF1IE(tf1)>')

# Generated at 2022-06-12 18:21:15.020207
# Unit test for constructor of class TF1IE
def test_TF1IE():
    create_TF1IE = lambda url: TF1IE(FakeInfoExtractor(), url)
    TF1IE(FakeInfoExtractor(), 'http://www.tf1.fr/uhd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    TF1IE(FakeInfoExtractor(), 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    TF1IE(FakeInfoExtractor(), 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:21:16.902887
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-12 18:21:20.379554
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test class constructor of TF1IE """
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:21:23.982262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert 3 == TF1IE.get_video_id('wat:12345678')
    assert 5 == TF1IE.get_video_id('wat:1234567890')

# Generated at 2022-06-12 18:23:12.446625
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert issubclass(TF1IE, InfoExtractor)

# Generated at 2022-06-12 18:23:13.796160
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:23:14.401734
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE("")

    assert info.ie_key() == 'TF1'

# Generated at 2022-06-12 18:23:14.870490
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()

# Generated at 2022-06-12 18:23:15.594067
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE(None)

# Generated at 2022-06-12 18:23:17.007345
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    assert info_extractor
    assert info_extractor.extract()

# Generated at 2022-06-12 18:23:26.689655
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test for checking if the TF1IE constructor works"""
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    watIE = TF1IE(url)
    info = watIE._real_extract(url)
    assert info['id'] == info['_type'] == 'url_transparent'
    assert info['url'] == 'wat:13641379'
    assert info['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'
    assert info['description']
    assert info['timestamp'] == 1560273989
    assert info['duration'] == 1738
    assert len(info['tags']) == 2

# Generated at 2022-06-12 18:23:29.185049
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert isinstance(ie, TF1IE)

# Unit tests for method _real_extract of class TF1IE, that checks the correct behaviour of the function

# Generated at 2022-06-12 18:23:32.410971
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert (
        IE.ie_key() ==
        'TF1'
    )
    assert (
        IE._VALID_URL ==
        r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    )

# Generated at 2022-06-12 18:23:35.637144
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.host == 'www.tf1.fr'
    assert ie.IE_NAME == 'tf1'
    assert 'https://www.tf1.fr/' in ie._VALID_URL
    assert ie._TESTS