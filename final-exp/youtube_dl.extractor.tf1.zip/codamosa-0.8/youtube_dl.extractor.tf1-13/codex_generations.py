

# Generated at 2022-06-12 18:17:28.001808
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:17:37.801557
# Unit test for constructor of class TF1IE
def test_TF1IE():
	"""Test for TF1IE"""

	test = TF1IE()
	assert test.tf1ie_base == 'https://www.wat.tv/interface/contentv3/%s'
	assert test.tf1ie_player_base == 'http://wat.tv/get/ipad/%s.m3u8'
	assert test.tf1ie_token_url == 'http://token.wat.tv/aki/bulk_token'
	assert test.tf1ie_token_params == {'s': 'json', 'bulk': 1, 'a': ''}
	assert test.tf1ie_player_params == {
		'auth': '', 'context': 'swf2root', 'pubid': 'tf1', 'device': 'iPad'}

# Generated at 2022-06-12 18:17:38.612615
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-12 18:17:41.859840
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert 'TF1IE' == ie.ie_key()
    assert ie.ie_key() in ie.ie_key_map

# Generated at 2022-06-12 18:17:46.677564
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    from unittest import TestCase

    class TestCaseTF1(TestCase):
        """Local class for test"""

        def test_tf1(self):
            """Test for constructor of class TF1IE"""
            TF1IE({})

    TestCaseTF1("test_tf1").test_tf1()

# Generated at 2022-06-12 18:17:54.885807
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._VALID_URL == TF1IE.VALID_URL
    assert TF1IE.IE_NAME == 'tf1'
    assert TF1IE.IE_DESC == 'tf1.fr'
    assert TF1IE._TESTS == TF1IE.TESTS

# Generated at 2022-06-12 18:17:56.438019
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        assert False



# Generated at 2022-06-12 18:17:59.995361
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._real_extract(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:18:04.996794
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html', 'https://www.tf1.fr/graphql/web', '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f', '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f')

# Generated at 2022-06-12 18:18:13.747050
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """test the constructor of class TF1IE"""
    data = {
        'id': 'test_TF1IE',
        'url': 'test_TF1IE_URL',
        'title': 'test_TF1IE_TITLE',
        'description': 'test_TF1IE_DESCRIPTION',
        'timestamp': 123,
        'duration': 456,
        'series': 'test_TF1IE_SERIES',
        'season_number': 1,
        'episode_number': 1,
        'tags': ['intégrale', 'quotidien', 'Replay']
    }
    test_TF1IE = TF1IE(data)
    assert (test_TF1IE.id == 'test_TF1IE')
    assert (test_TF1IE.url == 'test_TF1IE_URL')

# Generated at 2022-06-12 18:18:20.113180
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-12 18:18:25.199806
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == "TF1"
    assert ie.ie_name() == "TF1"
    assert ie.ie_urls() == ["https://www.tf1.fr/"]

# Generated at 2022-06-12 18:18:35.360945
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015')
    assert not TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html/')
    assert not TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html/random')
    assert TF

# Generated at 2022-06-12 18:18:36.217815
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Check for instance
    TF1IE()

# Generated at 2022-06-12 18:18:40.433244
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = globals()['TF1IE']
    obj_ = class_('www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    print(vars(obj_))

# Generated at 2022-06-12 18:18:45.933575
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'MyTF1, TF1, TMC, TFX and TF1 Séries Films'
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:51.188315
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()
    info_extractor.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert info_extractor is not None

# Generated at 2022-06-12 18:18:53.436197
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie != None

# Generated at 2022-06-12 18:19:01.641448
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class constructor (pytest)"""
    TF1IEClass = TF1IE()
    assert TF1IEClass.IE_NAME == 'tf1'
    assert TF1IEClass._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IEClass.BRAND == 'tf1'
    assert TF1IEClass.DOMAIN == 'www.tf1.fr'
    assert TF1IEClass.URL_REGEX == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:02.541594
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:19:17.139363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    initializer = TF1IE.ie_key()
    initializer('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:19:18.742954
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("unit-test")
    assert obj.TF1IE == True
# End of test_TF1IE

# Generated at 2022-06-12 18:19:20.696003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x != None

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-12 18:19:23.248809
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = IE(url='https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie.extract()

# Generated at 2022-06-12 18:19:32.670466
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Invalid video
    info_extractor = TF1IE()

# Generated at 2022-06-12 18:19:34.907875
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-12 18:19:36.540717
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.TF1IE

# Generated at 2022-06-12 18:19:38.063610
# Unit test for constructor of class TF1IE
def test_TF1IE():
    def test():
        return TF1IE()

    assert test()

# Generated at 2022-06-12 18:19:39.376603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("TF1IE")

# Generated at 2022-06-12 18:19:46.401952
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # Force the slug since it depends on the current date
    # The output of TF1IE.suitable() might also change depending on the current date
    from .common import get_testcases_from_urls
    get_testcases_from_urls([url], TF1IE)

# Generated at 2022-06-12 18:20:17.735479
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:19.741927
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    # TODO: check unit test
    pass

# Generated at 2022-06-12 18:20:22.470859
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html');

# Generated at 2022-06-12 18:20:22.975488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:20:25.533326
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for parsing tf1.fr
    TF1IE("www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-12 18:20:27.133466
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor of class TF1IE should return an instance of TF1IE
    assert isinstance(TF1IE(), TF1IE)

# Generated at 2022-06-12 18:20:28.692843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert hasattr(TF1IE, '_VALID_URL')
    assert hasattr(TF1IE, '_TESTS')


# Generated at 2022-06-12 18:20:33.295195
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert(IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-12 18:20:35.785083
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())._real_initialize()



# Generated at 2022-06-12 18:20:37.813857
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL


# Test that the regular expression returns only the program_slug and the slug from the URL

# Generated at 2022-06-12 18:21:33.256343
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    obj = TF1IE(url)
    obj.extract_info()

# Generated at 2022-06-12 18:21:34.018657
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-12 18:21:40.152893
# Unit test for constructor of class TF1IE
def test_TF1IE():
    res = TF1IE()
    assert res._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:21:45.537329
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert t.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') is True
    assert t.suitable('https://www.wat.tv/video/koh-lanta-finale-speciale-sept-2015-3hq3w_3hwl5_.html') is False

# Unit Test for method _real_extract


# Generated at 2022-06-12 18:21:46.613143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, None)

# Generated at 2022-06-12 18:21:48.357937
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)


# Generated at 2022-06-12 18:21:49.085899
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-12 18:21:49.795953
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:21:52.474327
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:22:02.150960
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    result = IE.extract(url)
    assert result['id'] == 'c097f6f16c3b7a8b45fabbc7a43b9a9d7e8ccc017e0e17ccb76fa92ad7fa8d80'
    assert result['url'] == 'wat:c097f6f16c3b7a8b45fabbc7a43b9a9d7e8ccc017e0e17ccb76fa92ad7fa8d80'
    assert result['title'] == 'Mystère Farmer'

# Generated at 2022-06-12 18:24:10.807770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-12 18:24:13.898387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    


# Generated at 2022-06-12 18:24:15.393772
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ret = TF1IE()
    assert ret.__class__.__name__ == "TF1IE"

# Generated at 2022-06-12 18:24:16.680671
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE("tf1")
    assert tf1_ie.name == "tf1"

# Generated at 2022-06-12 18:24:17.893421
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE is not None



# Generated at 2022-06-12 18:24:18.548526
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-12 18:24:19.400507
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 18:24:20.012169
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()

# Generated at 2022-06-12 18:24:21.406259
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE.ie_key('wat:12345')
    assert info.KEY == 'wat'
    assert info.ie_key() == 'WatIE'

# Generated at 2022-06-12 18:24:21.773031
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()