

# Generated at 2022-06-12 18:17:28.543891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except Exception as e:
        assert False, "I could not initialize class TF1IE for some reason. Change the constants and try again."
    else:
        assert True

# Generated at 2022-06-12 18:17:33.695370
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE._VALID_URL is not None
    assert IE._TESTS is not None
    assert IE.__name__ is not None
    assert IE.working() is True
    assert IE.IE_NAME is not None
    assert hasattr(IE, '_real_extract') is True

# Generated at 2022-06-12 18:17:36.474502
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create the TF1IE object
    tf1ie = TF1IE()
    # Check that the class is created
    assert tf1ie is not None, 'The TF1IE object is not created'


# Generated at 2022-06-12 18:17:37.884492
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('TF1IE').ie_key() == 'TF1'

# Generated at 2022-06-12 18:17:48.745637
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tags = ['intégrale', 'quotidien', 'Replay']
    title = 'Quotidien - Premier partie - 11 juin 2019'
    description = '''Le chanteur Nolwenn Leroy, Tristan Carné (scénariste du film "Les Crevettes pailletées") et Oscar Coop-Phane (directeur du label disques "Maison des Crevettes") sont les invités du premier "Quotidien" de la semaine. Ils répondront aux questions de Yann Barthès et de ses chroniqueurs.'''
    duration = 17

# Generated at 2022-06-12 18:17:49.620868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('', '', '', '')

# Generated at 2022-06-12 18:17:50.781656
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t is not None


# Generated at 2022-06-12 18:17:52.891028
# Unit test for constructor of class TF1IE
def test_TF1IE():
    reload(TF1IE)
    TF1IE.TF1IE()

# Generated at 2022-06-12 18:17:55.522621
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._LOGIN_URL == "https://login-wat.tf1.fr/publicapi/authentication/connect"



# Generated at 2022-06-12 18:18:00.237649
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(InfoExtractor).suitable(video_url)
    TF1IE(InfoExtractor).extract(video_url)

# Generated at 2022-06-12 18:18:10.026148
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-12 18:18:12.041535
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test expected parameters for TF1IE
    """
    assert TF1IE._VALID_URL
    assert TF1IE._TESTS

# Generated at 2022-06-12 18:18:13.368638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj_TF1IE = TF1IE()

# Generated at 2022-06-12 18:18:22.297381
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """
    # Test with a test url
    TF1IE(False).extract(
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    # Test with an invalid url
    TF1IE(False).extract(
        'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    # Test extractor without a url
    TF1IE(False).extract(None)
    # Test extractor with an invalid url

# Generated at 2022-06-12 18:18:24.615784
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Check that constructor doesn't raise any exception"""
    TF1IE()

# Generated at 2022-06-12 18:18:29.264352
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """ Test case for testing constructor of class TF1IE """
    ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    print(ie)

# Generated at 2022-06-12 18:18:38.169601
# Unit test for constructor of class TF1IE
def test_TF1IE():
	# Tests constructor of this class
	# Checks whether class contains needed attributes
	
	c_instance = TF1IE()
	
	assert hasattr(c_instance, '_VALID_URL')
	assert hasattr(c_instance, '_TESTS')
	assert hasattr(c_instance, '_download_webpage_handle')
	assert hasattr(c_instance, '_real_extract')
	assert hasattr(c_instance, '_login')
	assert hasattr(c_instance, '_signature')
	assert hasattr(c_instance, '_hidden_inputs')
	assert hasattr(c_instance, '_NETRC_MACHINE')
	assert hasattr(c_instance, '_download_webpage')

# Generated at 2022-06-12 18:18:47.740362
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie.url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    tf1ie.id = "13641379"
    tf1ie.ext = "mp4"
    tf1ie.title = "md5:f392bc52245dc5ad43771650c96fb620"
    tf1ie.description = "md5:a02cdb217141fb2d469d6216339b052f"
    tf1ie.upload_date = "20190611"
    tf1ie.timestamp = 1560273989
    tf1ie.duration = 1738

# Generated at 2022-06-12 18:18:58.688625
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1.params == {
        'skip_download': True,
        'format': 'bestvideo',
        'format': 'bestvideo',
        'page_id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
        'page_url': 'https://www.tf1.fr/graphql/web',
        'page_json': True,
    }

# Generated at 2022-06-12 18:19:01.690040
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:19:07.612790
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:19:11.608985
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Check if the constructor is working as it should
    IE = TF1IE()
    assert("TF1IE" == IE.ie_key())
    assert("TF1" == IE.ie_key())


# Generated at 2022-06-12 18:19:14.055559
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create instance of class TF1IE
    instance = TF1IE()
    # Check if instance not null
    assert instance is not None

# Generated at 2022-06-12 18:19:14.664181
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:19:15.628208
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-12 18:19:22.319906
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None).extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE(None).extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE(None).extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:19:30.201121
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:19:36.381810
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1._get_urls_from_text = lambda a: ['http://foo.bar']
    tf1._real_extract(tf1._get_urls_from_text('foo')[0])

# Generated at 2022-06-12 18:19:37.597405
# Unit test for constructor of class TF1IE
def test_TF1IE():
    f = TF1IE(InfoExtractor())

# Generated at 2022-06-12 18:19:48.685837
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:07.274169
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1._TITLE_RE == r'(.*?) \| TF1'

# Generated at 2022-06-12 18:20:17.001074
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Check TF1IE works
    """
    # Test things to test
    assert TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html").check_valid()

    # Test instances
    assert isinstance(TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"), InfoExtractor)

    # Test fields

# Generated at 2022-06-12 18:20:22.513634
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE(int())
    assert IE.host == 'www.tf1.fr'
    assert IE.ie_key() == 'TF1'
    assert IE.ie_key() in IE.extractors
    assert 'https://www.tf1.fr/' in IE._VALID_URL
    assert '/videos/' in IE._VALID_URL
    assert '.html' in IE._VALID_URL

# Generated at 2022-06-12 18:20:23.618431
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie != None

# Generated at 2022-06-12 18:20:32.912250
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Tests for constructor.
    # Create an instance of class TF1IE with invalid URL
    with pytest.raises(RegexMatchError):
        TF1IE("https://www.tf1.fr/")

    # Create an instance of class TF1IE with valid URL
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")



# Generated at 2022-06-12 18:20:35.785043
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.ie_key() == 'TF1'

# Generated at 2022-06-12 18:20:36.254289
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:20:37.813098
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(None)
    assert isinstance(tf1ie, TF1IE)

# Generated at 2022-06-12 18:20:43.685930
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE()
    e.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    e.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert not e.suitable('http://www.tf1.fr/tf1/les-mysteres-de-l-amour/videos/mysteres-de-l-amour-saison-9-episode-105-nouvelle-fortune.html')

# Generated at 2022-06-12 18:20:52.123146
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert t.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert not t.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-12 18:21:19.833361
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert tf1ie is not None

# Generated at 2022-06-12 18:21:21.982995
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)

# Generated at 2022-06-12 18:21:30.850304
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # url is of type string.
    url = "string"
    # ie is of type TF1IE.
    ie = TF1IE(url)
    assert ie.__class__.__name__ == "TF1IE"
    # The below variables are used to assert the values of attributes of an instance of TF1IE.
    _VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:21:32.493941
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE is not None


# Generated at 2022-06-12 18:21:35.770288
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(TF1IE.create_ie(url))

# Generated at 2022-06-12 18:21:38.421878
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (TF1IE().ie_key() == 'tf1')

# Generated at 2022-06-12 18:21:43.330204
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:21:49.515206
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._download_webpage = lambda *args, **kwargs: None

# Generated at 2022-06-12 18:22:00.169598
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:22:00.698900
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:22:58.244825
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    tf1 = TF1IE(url)
    assert tf1.IE_NAME == 'tf1'
    assert tf1.ie._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/[^/]+/videos/[^/?&#]+\\.html'

# Generated at 2022-06-12 18:22:59.003956
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-12 18:23:03.445259
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = TF1IE()
    assert tester.classname == "TF1IE"
    assert tester.ie == "TF1"
    assert tester.ie_key == "tf1"
    assert tester.name == "TF1"
    assert tester.domain == "tf1.fr"

# Generated at 2022-06-12 18:23:06.363239
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:23:09.306261
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create instance of class TF1IE with a url
    TF1IE_instance = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

    # Check if instance exists and type is correct
    assert TF1IE_instance is not None and isinstance(TF1IE_instance, TF1IE)


# Generated at 2022-06-12 18:23:10.859685
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match(
        TF1IE._VALID_URL,
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:23:16.715730
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    tf1.download("https://www.tf1.fr/graphql/web", "tf1.fr/graphql/wat")
    tf1.real_extract("https://www.tf1.fr/graphql/web", "tf1.fr/graphql/wat")

# Generated at 2022-06-12 18:23:17.172942
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:23:19.390584
# Unit test for constructor of class TF1IE
def test_TF1IE():
	m = TF1IE()
	assert m

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-12 18:23:20.620307
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Tests TF1IE() constructor
    """
    return TF1IE('')

# Generated at 2022-06-12 18:25:27.840750
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:25:28.368536
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:25:29.079516
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()

# Generated at 2022-06-12 18:25:30.953571
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE(None)
    assert type(inst) == TF1IE

# Generated at 2022-06-12 18:25:32.752838
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print('The test succeeded!')



# Generated at 2022-06-12 18:25:33.286243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:25:35.692443
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .tf1 import TF1IE
    assert issubclass(TF1IE, InfoExtractor)
    assert issubclass(TF1IE, InfoExtractor)

# Generated at 2022-06-12 18:25:36.660723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-12 18:25:40.105206
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test class TF1IE has initialized correctly
    """
    valid_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._VALID_URL == valid_url

# Generated at 2022-06-12 18:25:42.340853
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.extractor_key == "tf1"
    assert tf1.IE_NAME == "tf1.fr"
    assert tf1._VALID_URL.sample()
    assert tf1._TESTS