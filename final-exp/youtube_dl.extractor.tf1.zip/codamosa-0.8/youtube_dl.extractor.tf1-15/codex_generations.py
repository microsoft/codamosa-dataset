

# Generated at 2022-06-12 18:17:25.709422
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:17:33.244778
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert TF1IE.suitable(url) is True
    tf1 = TF1IE(url)
    assert tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:17:36.204969
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:17:37.219495
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE('', {})

# Generated at 2022-06-12 18:17:41.619402
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-12 18:17:42.606640
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor = TF1IE()

# Generated at 2022-06-12 18:17:48.466798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test extraction of TF1 videos
    """
    ie = TF1IE()
    ie.extract("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    ie.extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:17:59.107416
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert(tf1._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html")

# Generated at 2022-06-12 18:18:02.163617
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie=TF1IE("TF1IE")
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:04.427032
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:17.057716
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert_raises(AttributeError, TF1IE, 'test', 'test')

# Generated at 2022-06-12 18:18:24.175825
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor attributes of the class TF1IE"""
    TF1IE()
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:28.126040
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Instanciating TF1IE()
    test_TF1IE = TF1IE()
    # Assert that test_TF1IE is not none
    assert test_TF1IE is not None
    # Assert that url of test_TF1IE is 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert test_TF1IE._VALID_URL == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    return

# Generated at 2022-06-12 18:18:29.088422
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    test_TF1IE = TF1IE()
    assert test_TF1IE

# Generated at 2022-06-12 18:18:29.933262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE()
    assert infoExtractor is not None, 'TF1IE() returned None!'

# Generated at 2022-06-12 18:18:38.054976
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Run unit test
    import unittest

    class TestTF1(unittest.TestCase):
        def setUp(self):
            self.tf1 = TF1IE()

        def test_instance(self):
            self.assertIsInstance(self.tf1, TF1IE)

        def test_entries(self):
            entries = self.tf1.extract_entries()
            self.assertGreater(len(entries), 0)

        def test_urls(self):
            entries = self.tf1.extract_urls()
            self.assertGreater(len(entries), 0)

    unittest.main()

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-12 18:18:41.057349
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(TF1IE._VALID_URL)
    # Assert the constructor of class TF1IE has no input argument
    assert(tf1ie.paramTypes == [])

# Generated at 2022-06-12 18:18:42.422650
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)

# Generated at 2022-06-12 18:18:48.820745
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_cases = [
        ("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html",
             TF1IE._VALID_URL),
        ("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
             TF1IE._VALID_URL)
    ]
    for i in test_cases:
        url = i[0]
        match = re.match(i[1], url)
        assert match

# Generated at 2022-06-12 18:18:50.163973
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.suite()

# Generated at 2022-06-12 18:19:03.923668
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:19:09.674524
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.set_username("test_username")
    ie.set_password("test_password")
    ie.set_cookies("test_cookies")
    assert ie.get_username() == "test_username"
    assert ie.get_password() == "test_password"
    assert ie.get_cookies() == "test_cookies"

# Generated at 2022-06-12 18:19:19.680208
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Unit test for constructor of class TF1IE
    # Input:
    #     -
    # Expected output:
    #     TF1IE
    #     assertType
    #     assertEqual
    tf1_ie = TF1IE()
    assert tf1_ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1_ie.IE_NAME == 'tf1'
    assert tf1_ie.VALID_URL == 'https?://(?:www\\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-12 18:19:27.695327
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:31.454335
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


########################################################################################################################

# test for constructor of class InfoExtractor

# Generated at 2022-06-12 18:19:36.381958
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:19:45.129988
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:19:53.001454
# Unit test for constructor of class TF1IE
def test_TF1IE():
    wat = TF1IE()
    assert wat._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert wat._TESTS[0]["url"] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert wat._TESTS[0]["info_dict"]["id"] == '13641379'
    assert wat._TESTS[0]["info_dict"]["ext"] == 'mp4'

# Generated at 2022-06-12 18:19:53.521021
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.test()

# Generated at 2022-06-12 18:19:55.621704
# Unit test for constructor of class TF1IE
def test_TF1IE():
    temp = TF1IE("test")
    assert temp.extractor_key == "TF1"
    assert temp.name == "TF1"


# Generated at 2022-06-12 18:20:08.310531
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE', 'TF1IE', 'TF1IE')

# Generated at 2022-06-12 18:20:09.558933
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert(tf1 is not None)

# Generated at 2022-06-12 18:20:10.415159
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE();

# Generated at 2022-06-12 18:20:13.422703
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('http://www.tf1.fr/m6/princes-de-lamour/videos/replay-les-princes-de-lamour-saison-2-episode-77.html')

# Generated at 2022-06-12 18:20:14.932623
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test calling constructor of class TF1IE
    try:
        TF1IE()
    except TypeError:
        pass

# Generated at 2022-06-12 18:20:16.570201
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-12 18:20:18.683807
# Unit test for constructor of class TF1IE
def test_TF1IE():
    
    tf1 = TF1IE(downloader=None)
    assert hasattr(tf1, '_download_json')

# Generated at 2022-06-12 18:20:23.656478
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_object = TF1IE()
    assert test_object.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert test_object.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    pass

# Generated at 2022-06-12 18:20:29.429296
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_main import main
    import sys
    import os
    import shutil
    out_folder = "temp"
    if not os.path.exists(out_folder):
        os.makedirs(out_folder)
    _file_path = os.path.join(out_folder, "__TF1IE.log")
    sys.stdout = open(_file_path, "w")
    test_TF1IE = TF1IE()
    main(test_TF1IE, number_of_videos=25)
    sys.stdout = sys.__stdout__
    shutil.rmtree(out_folder)

# Generated at 2022-06-12 18:20:37.502952
# Unit test for constructor of class TF1IE
def test_TF1IE():
    original_constructor = TF1IE.__init__
    
    def __init__(self, url_or_provider_id):
        if not url_or_provider_id:
            url_or_provider_id = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
        original_constructor(self, url_or_provider_id)
    TF1IE.__init__ = __init__
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    
    TF1IE.__init__ = original_constructor

# Generated at 2022-06-12 18:20:59.780622
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:21:00.710319
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

# Generated at 2022-06-12 18:21:08.820086
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1._GEO_COUNTRIES == ['FR']
    assert tf1._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-12 18:21:13.746342
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Simple unit test for class TF1IE
    """
    TF1class = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/replay-integrale-quotidien-edition-de-13h-du-10-juin-2019.html', None )
    print(TF1class.url)
    print(TF1class.real_download)
    print(TF1class.real_download())
    print(TF1class.real_download()['formats'])
    return TF1class.real_download()['formats'][0]['format_id']


# Generated at 2022-06-12 18:21:17.632001
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    tfn = ie.TF1IE()
    print (tfn._TESTS)

# Generated at 2022-06-12 18:21:22.875319
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    
    # test with valid url
    tf1ie = TF1IE(tf1ie)
    tf1ie.extract(video)
    assert tf1ie.isAvailable() == True, "tf1.fr is available"
    
    # test with invalid url
    tf1ie = TF1IE(tf1ie)
    tf1ie.extract('https://youtu.be/C0DPdy98e4c')
    assert tf1ie.isAvailable() == False, "tf1.fr is not available"

# Generated at 2022-06-12 18:21:31.431943
# Unit test for constructor of class TF1IE
def test_TF1IE():
    wat_id = 'a1b2c3d4e5f6g7'
    tf1ie_instance = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'wat:' + wat_id)
    assert tf1ie_instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html'
    assert tf1ie_instance._NETRC_MACHINE == 'tf1'
    assert tf1ie_instance.program_slug == 'koh-lanta'

# Generated at 2022-06-12 18:21:33.553380
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:21:39.949753
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    test if the class has been correctly initialized
    """
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1_ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1_ie._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-12 18:21:48.510020
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:22:41.488722
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:22:47.606266
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test instance with
    assert any(TF1IE.suitable(x) for x in [
        "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html",
        "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
    ])

# Generated at 2022-06-12 18:22:55.787743
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Tested URLs
    assert TF1IE('wat:13690836') == {
        '_type': 'url_transparent',
        'ie_key': None,
        'url': 'wat:13690836',
        'id': '13690836'
    }
    assert TF1IE('wat:13690836', 'wat') == {
        '_type': 'url_transparent',
        'ie_key': 'wat',
        'url': 'wat:13690836',
        'id': '13690836'
    }

# Generated at 2022-06-12 18:23:00.163003
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-12 18:23:08.120371
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

    tf1 = TF1IE()

    assert(tf1._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html")
    assert(tf1._real_extract("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html") is None)

# Generated at 2022-06-12 18:23:17.744675
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE('wat', 'wat')
    assert inst._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-12 18:23:19.431275
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This just tests the class itself.
    assert TF1IE

# Generated at 2022-06-12 18:23:22.643043
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert 'wat:' in tf1._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')['url']

# Generated at 2022-06-12 18:23:23.881087
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-12 18:23:29.218685
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE.init_from_url('http://site.com/abc.html')
    assert isinstance(inst, TF1IE)
    assert inst.url == 'http://site.com/abc.html'
    assert inst.is_suitable('http://site.com/abc.html')
    assert not inst.is_suitable('http://site.com/xyz.html')

# Generated at 2022-06-12 18:25:46.475990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:25:47.349991
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_class = TF1IE()
    assert test_class


# Generated at 2022-06-12 18:25:49.395347
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert(not(
            TF1IE(TF1IE())._VALID_URL == None))
    except AssertionError:
        return False

    return True

# Generated at 2022-06-12 18:25:53.190979
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (
        TF1IE(None)._VALID_URL ==
            r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
# Add tests on TF1IE.extract

# Generated at 2022-06-12 18:26:02.331097
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ut = TF1IE(None)
    assert ut._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ut.__name__ == 'tf1'
    assert ut.IE_NAME == 'tf1'
    assert ut.NAME == 'tf1'
    assert ut.NAMESPACE == 'tf1'
    assert ut.TITLE == 'tf1'
    assert ut.API_KEY == 'tf1'

# Generated at 2022-06-12 18:26:05.682690
# Unit test for constructor of class TF1IE
def test_TF1IE():
	test_object = TF1IE()
	assert hasattr(test_object, '_download_webpage_handle')

# Generated at 2022-06-12 18:26:10.743514
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test normal constructor
    ie = TF1IE()
    assert ie.extractor_key == 'TF1'
    assert ie.IE_NAME == 'tf1:video'
    assert ie.VALID_URL == TF1IE._VALID_URL
    assert ie._TESTS == TF1IE._TESTS

# Generated at 2022-06-12 18:26:14.462411
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert t.get_full_id() == '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'

# Generated at 2022-06-12 18:26:18.453207
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    return True



# Generated at 2022-06-12 18:26:20.007700
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()