

# Generated at 2022-06-12 18:17:33.379825
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:17:38.710552
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # The following test is obsolete.
    # It is left in here only until the migration to "update-check --regex"
    # is complete.
    # It can eventually be removed without harm.
    new_ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert new_ie.__class__.__name__ == 'TF1IE'

# Generated at 2022-06-12 18:17:40.036959
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie is not None

# Generated at 2022-06-12 18:17:40.886174
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:17:50.706364
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE().suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE().suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert TF1IE().suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:18:01.466381
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1_IE = TF1IE()
    assert TF1_IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:03.021748
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    if ie:
        pass

# Generated at 2022-06-12 18:18:12.845011
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Grab a video from test fixtures and download it
    fixture_data = tf1.tf1_test.extractors.common.load_fixture('tf1.json')
    result = TF1IE()._real_extract(fixture_data['url'])

    # Verify each field in the result
    assert result['_type'] == 'url_transparent'
    assert result['id'] == fixture_data['id']
    assert result['url'] == fixture_data['url']
    assert result['title'] == fixture_data['title']
    assert result['thumbnails'] == fixture_data['thumbnails']
    assert result['description'] == fixture_data['description']
    assert result['timestamp'] == fixture_data['timestamp']
    assert result['duration'] == fixture_data['duration']

# Generated at 2022-06-12 18:18:14.218830
# Unit test for constructor of class TF1IE
def test_TF1IE():
    module=TF1IE()

# Generated at 2022-06-12 18:18:19.083985
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # Create an instance of class TF1IES
    tf1_ie = TF1IE()

    # Check instance attributes
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:30.517066
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:33.740171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1.tf1()

# Generated at 2022-06-12 18:18:34.713806
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE(InfoExtractor())

# Generated at 2022-06-12 18:18:38.624720
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = ['TF1IE', '1.0', 'tf1', 'tf1.fr']
    tf1_test = TF1IE(tf1)
    assert tf1_test

# Generated at 2022-06-12 18:18:39.570973
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert repr(TF1IE('wat:123'))

# Generated at 2022-06-12 18:18:42.052478
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        raise AssertionError("Error in class TF1IE")

# Generated at 2022-06-12 18:18:45.386544
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    tf1IE.tf_id = 'test'
    tf1IE.prog_slug = 'test_prog_slug'
    tf1IE.video = {'streamId': 'tv_stream_id'}
    tf1IE.title = 'Test title'
    tf1IE.timestamp = 1234

# Generated at 2022-06-12 18:18:47.804666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE();

# Generated at 2022-06-12 18:18:51.376638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of TF1IE
    """
    TF1IE('tf1.fr', 'TF1')


if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-12 18:19:00.732819
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    A test-case for TF1IE constructor.
    """
    video_info_url = "https://www.tf1.fr/graphql/web"
    query = {
                    'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
                    'variables': json.dumps({
                        'programSlug': "quotidien-avec-yann-barthes",
                        'slug': "quotidien-premiere-partie-11-juin-2019"
                    })
                }
    # Getting the response of the request and storing it in the variable 'response'.

# Generated at 2022-06-12 18:19:26.706628
# Unit test for constructor of class TF1IE
def test_TF1IE():
    webpage = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(webpage)
    assert ie.match(webpage)
    assert ie.extract_id(webpage)

# Generated at 2022-06-12 18:19:30.360153
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-12 18:19:36.244030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:45.066804
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Valid URL
    ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie.VALID_URL == TF1IE._VALID_URL
    assert ie.program_slug == 'tmc/quotidien-avec-yann-barthes'
    assert ie.slug == 'quotidien-premiere-partie-11-juin-2019'
    assert ie.playlist == None
    assert ie.playlist_start == 0

    # Test case: Invalid URL
    # Test case: Valid URL, but age restricted
    # Test case: Valid URL, but contains multiple videos
    # Test case: Valid URL, but unsupported video

# Generated at 2022-06-12 18:19:46.796670
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_object = TF1IE()
    assert test_object.IE_NAME == 'tf1'


# Generated at 2022-06-12 18:19:54.009195
# Unit test for constructor of class TF1IE
def test_TF1IE():
    a = TF1IE('TF1_URL','TF1_SLUG')
    #assert a.constructor == TF1IE
    assert a._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:58.074675
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert ie.NAME == "TF1"

    # 
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    


# Generated at 2022-06-12 18:19:58.727800
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-12 18:20:02.491590
# Unit test for constructor of class TF1IE
def test_TF1IE():
    sp = TF1IE()
    assert sp.ie_key() == 'TF1'
    assert sp.ie_name() == 'TF1'
    assert sp.ie_id() == 'tf1.fr'
    assert sp.server_url() == 'https://www.tf1.fr/graphql/web'

# Generated at 2022-06-12 18:20:04.861461
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-12 18:20:28.957178
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    return TF1IE().url_result('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:20:30.924138
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()
    assert True

# Generated at 2022-06-12 18:20:32.310906
# Unit test for constructor of class TF1IE
def test_TF1IE():
    unit = TF1IE()
    assert type(unit) is TF1IE

# Generated at 2022-06-12 18:20:35.077356
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:20:41.051209
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testurl = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1ie = TF1IE()._real_extract(testurl)
    assert tf1ie['url'] == 'wat:13641379'

# Generated at 2022-06-12 18:20:46.197931
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-12 18:20:46.933268
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:20:51.085313
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE("")
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:58.741613
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert not t.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:21:07.251019
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Case 1: TV show (only one video)
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE()._real_extract(url)
    # Case 2: TV show (with multiple videos)
    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    TF1IE()._real_extract(url)
    # Case 3: Documentaries
    url = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'

# Generated at 2022-06-12 18:22:02.655976
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # This function tests a TF1IE constructor
    test_TF1IE = TF1IE()
    # If no error occurred, return True
    return True

# Generated at 2022-06-12 18:22:04.228199
# Unit test for constructor of class TF1IE
def test_TF1IE():
    r = TF1IE()
    assert r.constructor == TF1IE

# Generated at 2022-06-12 18:22:04.868222
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:22:07.271289
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    # Test only the constructor itself, no need to test different URLs
    assert "TF1IE" in t.IE_NAME

# Generated at 2022-06-12 18:22:08.890691
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-12 18:22:11.395372
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t._download_json = lambda *args, **kwargs: {'data': {'videoBySlug': {}}}

# Generated at 2022-06-12 18:22:14.191705
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # check that the constructor of InfoExtractor
    # raises an exception if the URL of the video is not
    # provided as an argument
    with pytest.raises(TypeError):
        ie = TF1IE()


# Generated at 2022-06-12 18:22:16.852804
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except NameError:
        assert False

# Generated at 2022-06-12 18:22:19.805283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(len(ie._TESTS) == 3)

# Generated at 2022-06-12 18:22:21.547912
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("tf1ie")

# Generated at 2022-06-12 18:24:33.696212
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import unittest

    class TestTF1IE(unittest.TestCase):
        def setUp(self):
            self.ie = TF1IE()

        def test_TF1IE(self):
            self.assertIsInstance(
                self.ie, TF1IE
            )
    unittest.main()

# Generated at 2022-06-12 18:24:35.578006
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:24:37.245238
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('')

# Generated at 2022-06-12 18:24:47.521113
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:24:51.392832
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
# End unit test

# Generated at 2022-06-12 18:24:52.423726
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())



# Generated at 2022-06-12 18:24:58.368322
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE(url)
    assert ie.url == url
    assert ie.slug == 'quotidien-premiere-partie-11-juin-2019'
    assert ie.program_slug == 'quotidien-avec-yann-barthes'
    assert ie.id == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-12 18:24:59.574995
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-12 18:25:03.357816
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:25:06.761088
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Starting Unit Test...")
    f = TF1IE()
    assert (f.ie_key() == 'TF1')
    print("Test Passed.")