

# Generated at 2022-06-12 18:17:24.588665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)

# Generated at 2022-06-12 18:17:27.599412
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.mytf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:17:28.921482
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert isinstance(instance, TF1IE)

# Generated at 2022-06-12 18:17:38.334143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (TF1IE._TESTS[0]['info_dict']['title'] ==
            TF1IE._TESTS[1]['info_dict']['title'])
    assert (TF1IE._TESTS[0]['info_dict']['description'] ==
            TF1IE._TESTS[1]['info_dict']['description'])
    assert (TF1IE._TESTS[0]['info_dict']['tags'] ==
            TF1IE._TESTS[1]['info_dict']['tags'])
    assert (TF1IE._TESTS[0]['info_dict']['series'] ==
            TF1IE._TESTS[1]['info_dict']['series'])

# Generated at 2022-06-12 18:17:39.477708
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj is not None

# Generated at 2022-06-12 18:17:50.027126
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:17:51.469184
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-12 18:17:55.831491
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')



# Generated at 2022-06-12 18:17:56.847475
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)

# Generated at 2022-06-12 18:18:04.745934
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert ('wat:3400905', TF1IE) == TF1IE.suitable('/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ('wat:3400905', TF1IE) == TF1IE.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ('wat:3400905', TF1IE) == TF1IE.suitable('wat:3400905')
    assert ('wat:1234', TF1IE) == TF1IE.suitable('wat:1234')

# Generated at 2022-06-12 18:18:19.785326
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    query = 'https://www.tf1.fr/graphql/web'
    id = '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f'
    variables = '{"programSlug":"quotidien-avec-yann-barthes","slug":"quotidien-premiere-partie-11-juin-2019"}'
    url = ie._build_graphql_call(query, id, variables)
    video = ie._download_json(url, None)['data']['videoBySlug']
    decoration = video.get('decoration')
    description = decoration.get('description')

# Generated at 2022-06-12 18:18:23.948989
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for extractor of the url
    assert TF1IE._VALID_URL
    # Test for extractor with the url
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1ie = TF1IE(TF1IE._VALID_URL)
    tf1ie._real_extract(url)

# Generated at 2022-06-12 18:18:25.725752
# Unit test for constructor of class TF1IE
def test_TF1IE():
  TF1IE('wat:123')

# Generated at 2022-06-12 18:18:27.617023
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:18:29.468594
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("file:./test.html", None)._real_extract("file:./test.html")

# Generated at 2022-06-12 18:18:31.911025
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, TF1IE)
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 18:18:34.295367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    klass = TF1IE('email@example.com', 'password')
    assert klass.username == 'email@example.com'
    assert klass.password == 'password'

# Generated at 2022-06-12 18:18:45.796368
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('https://www.tf1.fr/mystere/videos/replay-mystere-avec-camille-combal-integrale-du-mardi-11-decembre-2018.html')
    assert instance.url == 'https://www.tf1.fr/mystere/videos/replay-mystere-avec-camille-combal-integrale-du-mardi-11-decembre-2018.html'
    assert instance.program_slug == 'mystere'
    assert instance.slug == 'replay-mystere-avec-camille-combal-integrale-du-mardi-11-decembre-2018'

# Generated at 2022-06-12 18:18:47.398237
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:18:52.803499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'Koh lanta')
    assert t.program_slug == 'koh-lanta'
    assert t.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-12 18:19:04.317893
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE"""

    TF1IE()

# Generated at 2022-06-12 18:19:08.893532
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE', 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', 'md5:f392bc52245dc5ad43771650c96fb620')

# Generated at 2022-06-12 18:19:09.925191
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-12 18:19:19.947775
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable(t._VALID_URL)
    assert t.suitable('https://website.com/video/12345.html') is False
    assert t.suitable('https://website.com/video.html') is False
    assert t.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert t.suitable('http://www.tf1.fr/tf1/koh-lanta/replay-koh-lanta-22-mai-2015.html') is False
    assert t.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta') is False


# Generated at 2022-06-12 18:19:31.489311
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE("")
    assert test_TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:32.462831
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:19:33.687828
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:19:35.853789
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:19:37.291367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert(tf1IE != None)

# Generated at 2022-06-12 18:19:41.617677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:20:12.755429
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:20:22.810884
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-12 18:20:27.604768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Instantiate test object
    tf1IE = TF1IE()

    # Call real_extract
    tf1IE._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:20:36.184744
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_cases = [
        {
            'url': 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
            'id': '11415076'
        },
        {
            'url': 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
            'id': '13641379'
        }
    ]
    for test_case in test_cases:
        test_url = test_case['url']
        test_id = test_case['id']
        IE = TF1IE(tf1ie.common.InfoExtractor)

# Generated at 2022-06-12 18:20:36.896496
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE()

# Generated at 2022-06-12 18:20:39.308121
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:20:40.252243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # No assert. Just make sure the import does not crash.
    TF1IE()

# Generated at 2022-06-12 18:20:52.031796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert ie._TESTS[0]['info_dict']['id'] == '13641379'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:20:55.461497
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().constructor('md5:a02cdb217141fb2d469d6216339b052f')

# Generated at 2022-06-12 18:21:00.111628
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .constructor import ie_key
    from .. import ExtractorError
    obj = TF1IE(None)
    assert ie_key(obj) == 'TF1IE'
    with assertRaisesRegexp(ExtractorError, 'This extractor only supports storage.tf1.fr URLs'):
        TF1IE('http://foo.bar/')

# Generated at 2022-06-12 18:21:57.583574
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL
    assert TF1IE()._TESTS == TF1IE._TESTS
    assert TF1IE()._real_extract == TF1IE._real_extract

# Generated at 2022-06-12 18:21:58.840857
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)  # will fail if the constructor fails

# Generated at 2022-06-12 18:22:08.575755
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE
    assert ie.__name__ in globals()
    assert hasattr(ie, 'ie_key')
    assert ie.ie_key() == 'tf1'
    assert ie.ie_key() == ie.__class__.ie_key()
    assert ie.__doc__.startswith(TF1IE.__name__)
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == ie.__class__._VALID_URL
    assert ie.__name__ in ie._VALID_URL
    assert hasattr(ie, '_TESTS')
    assert len(ie._TESTS)

# Generated at 2022-06-12 18:22:13.629361
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    r = TF1IE().extract_info(url, {})
    assert(r['id'] == '13641379')
    assert (r['title'] == "Koh-Lanta")

# Generated at 2022-06-12 18:22:16.857935
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert re.match('^md5:[0-9a-f]{32}$', TF1IE._md5(b'42')) is not None
    assert TF1IE._VALID_URL is not None
    assert TF1IE._TESTS is not None

# Generated at 2022-06-12 18:22:18.556367
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-12 18:22:19.576600
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE, object)

# Generated at 2022-06-12 18:22:20.197078
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:22:21.535788
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:22:22.178659
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:24:39.001824
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:24:40.224864
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-12 18:24:41.169618
# Unit test for constructor of class TF1IE
def test_TF1IE():
    initial = TF1IE(InfoExtractor())

# Generated at 2022-06-12 18:24:41.717565
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:24:42.555798
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_object = TF1IE()

# Generated at 2022-06-12 18:24:48.546708
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE()
    ie.extract(url)
    assert ie._VALID_URL
    assert ie._TESTS
    assert ie.IE_NAME == 'TF1'
    assert ie.BROWSER_UA == 'tf1'

test_TF1IE()

# Generated at 2022-06-12 18:24:57.666966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    with open('./extractor/test/tf1-ie.json') as data_file:
        json_data = json.load(data_file)
    extractor = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    extractor.download(extractor.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'))

# Generated at 2022-06-12 18:24:58.094158
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:25:00.458370
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:25:01.933556
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('user', 'pass')