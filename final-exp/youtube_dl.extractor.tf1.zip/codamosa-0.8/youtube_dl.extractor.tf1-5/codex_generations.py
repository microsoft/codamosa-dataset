

# Generated at 2022-06-12 18:17:32.614777
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(None)
    url = tf1ie._VALID_URL
    program_slug, slug = re.match(tf1ie._VALID_URL, url).groups()
    video = tf1ie._download_json(
        'https://www.tf1.fr/graphql/web', slug, query={
            'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
            'variables': json.dumps({
                'programSlug': program_slug,
                'slug': slug,
            })
        })['data']['videoBySlug']
    wat_id = video['streamId']

    tags = []

# Generated at 2022-06-12 18:17:40.488597
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    ie = TF1IE(url)
    expected_id = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    expected_url = "13641379"
    expected_ie_key = "TF1"
    expected_title = "md5:f392bc52245dc5ad43771650c96fb620"
    
    assert expected_id == ie.id
    assert expected_url == ie.url

# Generated at 2022-06-12 18:17:41.519109
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t.test()

# Generated at 2022-06-12 18:17:51.172540
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:18:01.765027
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert TF1IE.IE_NAME == 'TF1'
    assert TF1IE.IE_DESC == 'Le site de TF1'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:04.486440
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-12 18:18:07.717714
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    TF1IE(url)

# Generated at 2022-06-12 18:18:12.042320
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(InfoExtractor())
    assert tf1.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert not tf1.suitable('https://www.dailymotion.com/video/x6zv6g3')

# Generated at 2022-06-12 18:18:12.939232
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:15.827313
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:18:22.514199
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-12 18:18:28.428926
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of TF1IE"""
    exp_url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    extractor = TF1IE(exp_url)
    assert exp_url == extractor._VALID_URL

# Generated at 2022-06-12 18:18:29.050072
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE()

# Generated at 2022-06-12 18:18:32.520535
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import re

    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:18:33.101449
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:35.820605
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('md5:50c2d1e9f7740df9f8a8deccdbc726e5')
    assert ie.__name__ == 'TF1'

# Generated at 2022-06-12 18:18:46.103394
# Unit test for constructor of class TF1IE
def test_TF1IE():
  # Test constructor of class TF1IE
  print('Test constructor of class TF1IE')
  # Test if the object TF1IE is an instance of a subclass of InfoExtractor
  assert issubclass(TF1IE, InfoExtractor)
  # Test the constructor of class TF1IE
  TF1IE_object = TF1IE()
  # Test if the constructor creates a valid TF1IE object
  assert TF1IE_object._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:46.737086
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:47.922639
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance

# Generated at 2022-06-12 18:18:51.832493
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE( 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',None)

# Generated at 2022-06-12 18:19:01.731030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(url)

# Generated at 2022-06-12 18:19:02.622786
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()


# Generated at 2022-06-12 18:19:04.194816
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert any(TF1IE.can_handle_url(url) for url in TF1IE._TESTS)

# Generated at 2022-06-12 18:19:15.540090
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE().extract(u'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:19:16.456559
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("1234567")

# Generated at 2022-06-12 18:19:18.105588
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor of class TF1IE
    assert isinstance(TF1IE, InfoExtractor)

# Generated at 2022-06-12 18:19:18.764674
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == 'tf1'

# Generated at 2022-06-12 18:19:30.390908
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("TF1IE", False)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html' 

# Generated at 2022-06-12 18:19:36.264243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_ = TF1IE
    instance = class_()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:45.068932
# Unit test for constructor of class TF1IE
def test_TF1IE():
    wat_id = "V14781565"
    replay_url = "https://www.wat.tv/embedframe/" + wat_id
    expected_info = {
		'id': wat_id,
        'url': 'wat:' + wat_id,
        'title': "L'intégrale",
        'creator': 'Amir',
        'upload_date': None,
        'timestamp': None,
        'duration': None,
        'view_count': None,
        'like_count': None,
        'comment_count': None,
        'average_rating': None,
        'formats': None}
    tf1 = TF1IE(expected_info)

# Generated at 2022-06-12 18:19:59.796081
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.getURLPattern() == tf1IE.TF1IE._VALID_URL
    assert t.getURLRegex() == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert t.getInvalidURLPattern() == r'https?://www\.tf1\.fr/[^/]+/videos/[^/?&#]+\.html'
    assert t.getParametersList() == ['skip_download', 'format']
    assert t.getRealExtract().__name__ == 'TF1IE._real_extract'
    assert len(t.getTests()) == 3
    assert len(t.getTests()[0]) == 3

# Generated at 2022-06-12 18:20:03.078521
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:12.949322
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html");
    assert TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")._VALID_URL == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html";

# Generated at 2022-06-12 18:20:19.895318
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')


# Don't unit test that until the constructor of class TF1IE is changed to
# construct TF1IE first, then pass the constructed instance to InfoExtractor
# test_TF1IE()

# Generated at 2022-06-12 18:20:20.997197
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() is not None

# Generated at 2022-06-12 18:20:23.386688
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except TypeError as e:
        assert(str(e) == "__init__() missing 2 required positional arguments: 'id' and 'url'")

# Generated at 2022-06-12 18:20:23.918746
# Unit test for constructor of class TF1IE
def test_TF1IE(): TF1IE()

# Generated at 2022-06-12 18:20:25.011270
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-12 18:20:35.309387
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert ie.get_url() == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    
    expected_program_name = 'quotidien-avec-yann-barthes'
    actual_program_name = re.match(ie.VALID_URL, ie.get_url()).group('program_slug')
    assert expected_program_name == actual_program_name
    

# Generated at 2022-06-12 18:20:39.929694
# Unit test for constructor of class TF1IE
def test_TF1IE():
    o = TF1IE()
    assert o.ie_key() == 'TF1'
    assert o.ie_name() == 'TF1'
    assert o.ie_url() == 'https://www.tf1.fr/'

# Generated at 2022-06-12 18:20:54.972180
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:20:56.299826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-12 18:20:57.481418
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-12 18:20:58.369779
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:21:00.205184
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # testing that TF1IE constructor doesn't fail
    test_obj = ie.TF1IE()

# Generated at 2022-06-12 18:21:01.143508
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:21:02.001743
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE.suite()

# Generated at 2022-06-12 18:21:06.815904
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:21:10.851752
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test TF1IE constructor"""
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(url)

# Generated at 2022-06-12 18:21:11.692750
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('wat://')
    t._download_json

# Generated at 2022-06-12 18:21:44.300083
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

    assert(t is not None)

# Generated at 2022-06-12 18:21:46.053638
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test the instantiation of this class
    TF1IE()

# Generated at 2022-06-12 18:21:50.524694
# Unit test for constructor of class TF1IE
def test_TF1IE():

    tf1_ie = TF1IE(0)
    assert tf1_ie.ie_key() == 'TF1'
    assert tf1_ie.ie_name() == 'TF1'
    assert tf1_ie.ie_description() == 'TF1'
    assert tf1_ie.ie_version() == [1]
    assert tf1_ie.ie_app_name() == 'TF1'
    assert tf1_ie.ie_app_version() == [1]

# Generated at 2022-06-12 18:21:51.075364
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:21:56.187144
# Unit test for constructor of class TF1IE
def test_TF1IE():
    "Constructor of class should not throw exception"
    # Constructor should not throw exception
    TF1IE("http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-12 18:21:58.549290
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:22:00.010971
# Unit test for constructor of class TF1IE
def test_TF1IE():
    Foo = TF1IE("a", "b", {})
    assert Foo is not None

# Generated at 2022-06-12 18:22:04.418983
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    try :
        TF1IE(url)
    except :
        print("Unit test failed")

if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-12 18:22:05.614868
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test default constructor
    TF1IE()

# Generated at 2022-06-12 18:22:12.993936
# Unit test for constructor of class TF1IE
def test_TF1IE():
    original_TF1IE = TF1IE
    TF1IE = get_embed_info_extractor(TF1IE, {'id': '13641379'})

# Generated at 2022-06-12 18:23:15.469856
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE({})
    assert isinstance(instance, TF1IE)

# Generated at 2022-06-12 18:23:16.847348
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == (TF1IE._VALID_URL)



# Generated at 2022-06-12 18:23:17.573830
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:23:20.549783
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.ie_key() == 'tf1'
    assert t.ie_url() == 'tf1.fr'
    assert t.SUCCEEDED == 0

# Generated at 2022-06-12 18:23:26.980021
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("www.tf1.fr")
    TF1IE("tf1.fr")
    TF1IE("www.tf1.fr/tf1")
    TF1IE("tf1.fr/tf1")
    TF1IE("https://www.tf1.fr/tf1")
    TF1IE("https://tf1.fr/tf1")
    TF1IE("http://www.tf1.fr/tf1")
    TF1IE("http://tf1.fr/tf1")


# Generated at 2022-06-12 18:23:29.841932
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:23:35.341431
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test the constructor: TF1IE
    tf1_ie = TF1IE('tf1_ie', 'tf1')
    assert tf1_ie
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:23:36.772496
# Unit test for constructor of class TF1IE
def test_TF1IE():
  TF1IE

# Generated at 2022-06-12 18:23:39.044480
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.IE_NAME == 'tf1'

# Generated at 2022-06-12 18:23:40.000707
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert (isinstance(x, InfoExtractor))

# Generated at 2022-06-12 18:25:44.926402
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:25:47.574506
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html';
    tf1IE = TF1IE(InfoExtractor());
    tf1IE.extract(url, False);

# Generated at 2022-06-12 18:25:52.437851
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TF1IE
    tf1 = TF1IE()
    tf1._real_extract("https://www.tf1.fr/tfx/les-vacances-des-anges/videos/les-vacances-des-anges-premiere-partie-saison-2-episode-1-23-avril-2019.html")

# Generated at 2022-06-12 18:26:02.989200
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == [
        'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html',
        'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html',
    ]

    # Test to check url return value

# Generated at 2022-06-12 18:26:13.866312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:26:15.234283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-12 18:26:16.744681
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._downloader = None
    TF1IE()._download = None

# Generated at 2022-06-12 18:26:25.676526
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tester = TF1IE()
    assert tester._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:26:28.900824
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE()
    assert infoExtractor._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
# Test if the description field is correctly extracted

# Generated at 2022-06-12 18:26:30.821595
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

    raise NotImplementedError