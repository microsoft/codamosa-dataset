

# Generated at 2022-06-12 18:17:29.757865
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert (TF1IE(None).suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'))

# Generated at 2022-06-12 18:17:31.374782
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj is not None


# Generated at 2022-06-12 18:17:36.877627
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-12 18:17:39.477356
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')



# Generated at 2022-06-12 18:17:45.282204
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.download_webpage = lambda url: '<html><body><script>myWatId = "123456789";</script></body></html>'
    assert ie.format_id('wat:123456789') == '123456789'
    assert ie.suitable(ie.url_result('wat:123456789'))

# Generated at 2022-06-12 18:17:46.294296
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert "TF1IE"

# Generated at 2022-06-12 18:17:49.356603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    tf1ie._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:17:51.954373
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:17:59.328233
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Url : https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    ie = TF1IE()
    ie._real_extract(url)

# Generated at 2022-06-12 18:18:00.197058
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor)

# Generated at 2022-06-12 18:18:06.565784
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:09.122651
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:18:10.457952
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor())

# Generated at 2022-06-12 18:18:12.514656
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of TF1IE"""
    tf1ie = TF1IE({})
    assert isinstance(tf1ie, InfoExtractor)

# Generated at 2022-06-12 18:18:13.069167
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-12 18:18:17.730746
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for  http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html
    assert TF1IE._VALID_URL == '^https?://(?:www\\.)?tf1\\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\\.html$'

# Generated at 2022-06-12 18:18:24.080457
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_obj = TF1IE("TF1IE", "tf1.fr")
    assert test_obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:24.473020
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE()

# Generated at 2022-06-12 18:18:25.838690
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie is not None

# Generated at 2022-06-12 18:18:26.906036
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie is not None

# Generated at 2022-06-12 18:18:38.743948
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://someurl/', None)

# Generated at 2022-06-12 18:18:43.997553
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALIDA_URL == re.compile(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert tf1_ie._TESTS

# Generated at 2022-06-12 18:18:47.272032
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE();
    res = t._VALID_URL
    if not res:
        print('\nError : must be a valid url to connect TF1.fr')
    else:
        print('\nSuccess, the url is : %s' %res)

# Generated at 2022-06-12 18:18:49.657396
# Unit test for constructor of class TF1IE
def test_TF1IE():
    params = {'username': '1', 'password': '2'}
    TF1IE(params)



# Generated at 2022-06-12 18:19:00.397091
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:19:01.519220
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-12 18:19:02.412701
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-12 18:19:03.635363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE();
    assert tf1IE is not None

# Generated at 2022-06-12 18:19:14.561529
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("test")
    assert tf1.test_test("test") is True
    assert tf1.test_test("test1") is False
    assert tf1.test("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html") is True
    assert tf1.test("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html") is True
    assert tf1.test("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html") is True

# Generated at 2022-06-12 18:19:17.316555
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    inst.url_result('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:19:45.178078
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # init with url
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    tf1ie = TF1IE(url)

    assert tf1ie._VALID_URL == "https://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html"

# Generated at 2022-06-12 18:19:46.090531
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-12 18:19:53.662813
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE.__version__ == '0.1'
    TF1 = TF1IE()
    assert TF1 is not None
    assert TF1.geo_verification_headers() is None
    assert TF1.IE_NAME == 'tf1'
    assert TF1.ie_key() == 'TF1'
    assert TF1.PAGE_URL == 'https://www.tf1.fr/%s.html'
    assert TF1.GEO_COUNTRIES == ['FR'], (
        'TF1.GEO_COUNTRIES = %r' % TF1.GEO_COUNTRIES)

# Generated at 2022-06-12 18:19:57.414783
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert test._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    #assert test._real_extract() == '<url_transparent>'
    #assert test._TESTS == '<url_transparent>'

# Generated at 2022-06-12 18:20:03.335188
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE(url)

    assert ie.url == url
    assert ie.program_slug == 'quotidien-avec-yann-barthes'
    assert ie.slug == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-12 18:20:04.532650
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:20:13.472452
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE()._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE()._TESTS[1]['url'] == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-12 18:20:15.571578
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html').extract()

# Generated at 2022-06-12 18:20:19.783970
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-12 18:20:21.861466
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t._API_BASE_URL == 'https://www.tf1.fr/graphql/web'

# Generated at 2022-06-12 18:21:05.053547
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test constructor of class TF1IE
    """
    class_tf1ie = TF1IE("")
    assert class_tf1ie is not None

# Generated at 2022-06-12 18:21:06.290506
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().ie_key() == "TF1"

# Generated at 2022-06-12 18:21:08.265329
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('test_id', {'test_key': 'test_value'})
    assert tf1.name == 'TF1IE'



# Generated at 2022-06-12 18:21:10.883193
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test to see if we have a good constructor for TF1IE
    """
    tf1IE = TF1IE({})

    assert isinstance(tf1IE, TF1IE)


# Generated at 2022-06-12 18:21:16.613481
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

    assert(ie != None)
    assert(ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(ie._TESTS[0]["url"] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert(ie._TESTS[0]["info_dict"]["id"] == '13641379')
    assert(ie._TESTS[0]["info_dict"]["ext"] == 'mp4')

# Generated at 2022-06-12 18:21:19.488908
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._real_extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:21:21.549793
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:21:29.004550
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert tf1.program_slug == "koh-lanta"
    assert tf1.slug == "replay-koh-lanta-22-mai-2015"
    assert tf1.url == "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"

# Generated at 2022-06-12 18:21:35.125300
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    ie = TF1IE(url)
    assert ie.name == 'TF1'
    assert ie.supported_domains == ['tf1.fr']
    assert ie.ie_key() == 'TF1'
    assert ie.url_result.get().url == url


# Generated at 2022-06-12 18:21:47.320806
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create an instance of class TF1IE
    tf1 = TF1IE()
    # Test _VALID_URL
    assert tf1._VALID_URL is not None
    match = re.match(TF1IE._VALID_URL, "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert match
    assert match.group("id") == "replay-koh-lanta-22-mai-2015"
    assert match.group("program_slug") == "koh-lanta"
    # Test _TESTS
    for test in TF1IE._TESTS:
        assert test
        # Test 'url'
        url = test['url']
        assert url
        # Test 'only_

# Generated at 2022-06-12 18:23:40.713220
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:23:42.721475
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._download_json = lambda *a, **kw: None
    ie._real_extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:23:43.302665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('')

# Generated at 2022-06-12 18:23:44.867469
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for constructor of class TF1IE"""
    tf1_ie = TF1IE()
    assert tf1_ie.name == 'tf1'
    assert tf1_ie.ie_key() == 'tf1'

# Generated at 2022-06-12 18:23:49.506359
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert hasattr(TF1IE, 'ie_key')
    assert hasattr(TF1IE, '_VALID_URL')
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE.ie_key() == 'TF1'
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-12 18:23:59.336856
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:24:00.877403
# Unit test for constructor of class TF1IE
def test_TF1IE():
	"""TF1IE"""
	tf1ie = TF1IE()
	assert tf1ie is not None
	return tf1ie

# Generated at 2022-06-12 18:24:01.979596
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE(5,6,7)

# Generated at 2022-06-12 18:24:10.966141
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie.url == url
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

# Generated at 2022-06-12 18:24:12.406909
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE();
    assert(obj is not None)