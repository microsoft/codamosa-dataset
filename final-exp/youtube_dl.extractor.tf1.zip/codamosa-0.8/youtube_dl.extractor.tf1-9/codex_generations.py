

# Generated at 2022-06-12 18:17:27.747523
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:17:37.490425
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_id = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1ie = TF1IE(TestInfoExtractor.create_ytdl(dict(age_limit=0)))._real_extract(video_id)

# Generated at 2022-06-12 18:17:38.463265
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE('wat', {})

# Generated at 2022-06-12 18:17:40.982289
# Unit test for constructor of class TF1IE
def test_TF1IE():
  tf1IE = TF1IE()


# Unit test of method _real_extract of class TF1IE

# Generated at 2022-06-12 18:17:41.573249
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:17:51.206739
# Unit test for constructor of class TF1IE
def test_TF1IE():
	# If there is an error with URL and title, we can use this code to determine
	# Source code: https://github.com/ytdl-org/youtube-dl/issues/17338
	TF1IE()._real_extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
	TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
	TF1IE()._real_extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:17:54.753499
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Unit test run successfully")

# Please run this code to test the constructor of class TF1IE
if __name__ == '__main__':
    test_TF1IE()

# Generated at 2022-06-12 18:17:56.270063
# Unit test for constructor of class TF1IE
def test_TF1IE():
    testobj = TF1IE()
    assert isinstance(testobj, TF1IE)

# Generated at 2022-06-12 18:18:04.427687
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE = tf1IE = TF1IE()
    assert tf1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:06.686470
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE"""
    tf1ie = TF1IE()
    assert isinstance(tf1ie, TF1IE)

# Generated at 2022-06-12 18:18:19.167824
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t



# Generated at 2022-06-12 18:18:24.331808
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test constructor of class TF1IE"""
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1 = TF1IE(url)
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1._TESTS[0]['url'] == url
    assert tf1._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-12 18:18:26.208301
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i is not None


# Generated at 2022-06-12 18:18:27.262508
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_ie_can_construct(TF1IE)

# Generated at 2022-06-12 18:18:29.956492
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor for TF1IE.
    """
    ie = TF1IE()
    ie._real_extract(ie._TESTS[0]['url'])

# Generated at 2022-06-12 18:18:40.974757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-12 18:18:43.155682
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE("tf1.fr/test")
    assert i.__name__ == "tf1"

# Generated at 2022-06-12 18:18:46.426269
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL[-1] != '$', "TF1IE should have a valid _VALID_URL"
    assert ie._TEST[-1] != '$', "TF1IE should have a valid _TEST"

# Generated at 2022-06-12 18:18:51.239863
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable(TF1IE._VALID_URL)
    assert not TF1IE.suitable(TF1IE._TESTS[1]['url'])
    assert not TF1IE.suitable(TF1IE._TESTS[2]['url'])

# Generated at 2022-06-12 18:18:55.019102
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-12 18:19:17.844579
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj != None

# Generated at 2022-06-12 18:19:18.743555
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE != None

# Generated at 2022-06-12 18:19:19.283241
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:19:22.389688
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE(None)
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:32.364626
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert i.ie_key() == 'TF1'
    assert i.ie_id() == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert i.url == 'TF1', 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert i.title == 'TF1'
    assert i.description == 'TF1'
    assert i.thumbnail == 'TF1'

# Generated at 2022-06-12 18:19:35.145525
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:19:38.064386
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test the case where there is no parameter passed
    assert TF1IE()
    # test the case where there are some parameter passed
    assert TF1IE(12345)

# Generated at 2022-06-12 18:19:39.376716
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-12 18:19:49.494143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:58.721519
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:22.089654
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test TF1IE
    tf1ie_test = TF1IE()
    assert tf1ie_test

# Generated at 2022-06-12 18:20:26.994698
# Unit test for constructor of class TF1IE
def test_TF1IE():
    module_name = 'test_TF1IE'
    module = __import__(module_name)
    print('------------------------------------------------')
    print('test_TF1IE')
    test = TF1IE("tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert test.url == "tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"

# Generated at 2022-06-12 18:20:33.957352
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("tf1")
    assert tf1.suitable("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert tf1.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-12 18:20:36.116363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE(tf1ie)
    assert tf1ie == TF1IE

# Generated at 2022-06-12 18:20:38.787326
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with a known video
    TF1IE('tf1', 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html').test()

# Generated at 2022-06-12 18:20:40.013667
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert hasattr(tf1IE, '_TESTS')

# Generated at 2022-06-12 18:20:40.682664
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-12 18:20:41.608052
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE is not None

# Generated at 2022-06-12 18:20:52.891169
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Test TF1IE constructor
    """
    instance = TF1IE()
    assert instance._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:54.788074
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE()

# Generated at 2022-06-12 18:21:50.525797
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    print(x)

# Generated at 2022-06-12 18:21:53.998957
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:21:55.806130
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE(None)
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-12 18:21:56.788850
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("FAKE_URL")

# Generated at 2022-06-12 18:22:00.374727
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Use url for constructor of class TF1IE
    assert TF1IE(url='http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-12 18:22:01.544857
# Unit test for constructor of class TF1IE
def test_TF1IE():

    tf1IE = TF1IE(None)

    assert tf1IE is not None

# Generated at 2022-06-12 18:22:06.691728
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE("")
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1ie.IE_NAME == "tf1"

# Generated at 2022-06-12 18:22:08.074610
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-12 18:22:09.708569
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-12 18:22:12.167307
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_name = "TF1IE"
    obj = TF1IE("TF1IE")
    assert isinstance(obj, TF1IE)


# Generated at 2022-06-12 18:24:24.528766
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.url
    ie.slug
    ie.videoByDefinition
    ie.get_id

# Generated at 2022-06-12 18:24:34.105925
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for url: https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html
    video_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t = TF1IE()
    assert t.suitable(video_url), "Url error: " + video_url
    assert t.extract(video_url)['title'] == 'md5:f392bc52245dc5ad43771650c96fb620', "Title error: " + video_url

# Generated at 2022-06-12 18:24:37.131575
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.ie_key() == 'TF1'

# Generated at 2022-06-12 18:24:39.874701
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE({})
    assert isinstance(instance, TF1IE)


# Generated at 2022-06-12 18:24:41.532338
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert isinstance(tf1, InfoExtractor)


# Generated at 2022-06-12 18:24:48.581768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    classOptions = dict(
        id=13641379,
        ext='mp4',
        title='md5:f392bc52245dc5ad43771650c96fb620',
        description='md5:a02cdb217141fb2d469d6216339b052f',
        upload_date='20190611',
        timestamp=1560273989,
        duration=1738,
        series='Quotidien avec Yann Barthès',
        tags=['intégrale', 'quotidien', 'Replay'],
    )
    ie = TF1IE(classOptions)

# Generated at 2022-06-12 18:24:50.704562
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'

# Generated at 2022-06-12 18:24:51.278389
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:24:52.925501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('tf1')
    assert instance.ie_key() == 'tf1'


# Generated at 2022-06-12 18:24:57.954926
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    result = tf1._VALID_URL
    assert type(result) == str
    result = tf1._TESTS
    assert type(result) == list
    result = tf1._real_extract("url")
    assert type(result) == dict
    result = tf1._real_extract("url")
    assert type(result) == dict
    result = tf1._real_extract("url")
    assert type(result) == dict
