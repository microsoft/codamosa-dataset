

# Generated at 2022-06-12 18:17:25.753677
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-12 18:17:27.220964
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf = TF1IE()
    assert isinstance(tf, InfoExtractor)

# Generated at 2022-06-12 18:17:28.140501
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:17:34.418525
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == 'tf1'
    assert tf1.IE_KEY == 'wat'
    assert TF1IE.IE_NAME == 'tf1'
    assert TF1IE.IE_KEY == 'wat'
    assert TF1IE.ie_key() == 'wat'
    assert TF1IE.ie_name() == 'tf1'
    assert TF1IE.ie_key() == 'wat'
    assert TF1IE.ie_name() == 'tf1'

# Generated at 2022-06-12 18:17:35.450643
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1.TF1IE()

# Generated at 2022-06-12 18:17:41.716769
# Unit test for constructor of class TF1IE
def test_TF1IE():

    wat_id = 'Q76F7R'

    expected_result = {
        '_type': 'url_transparent',
        'id': wat_id,
        'url': 'wat:' + wat_id,
        'ie_key': 'Wat'
    }

    # Test the constructor of class TF1IE
    result = TF1IE._build_url_result(wat_id)

    assert result == expected_result

# Generated at 2022-06-12 18:17:51.303863
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]+\.html'

# Generated at 2022-06-12 18:17:55.684849
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:17:57.045301
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE is not None

# Generated at 2022-06-12 18:18:01.464757
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    kwargs = {'reader': True, 'view_count': True}
    assert TF1IE(url, **kwargs)

    TF1IE(url)

# Generated at 2022-06-12 18:18:22.772439
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert t.compat_url('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == 'wat:13641379'
    assert t.compat_url('http://www.tf1.fr/tf1/koh-lanta/') == 'http://www.tf1.fr/tf1/koh-lanta/'

# Generated at 2022-06-12 18:18:23.355156
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:26.109410
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:18:30.468929
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create the instance of class TF1IE
    tf1ie_instance = TF1IE()
    assert isinstance(tf1ie_instance, TF1IE)
    # Call _real_extract()
    tf1ie_instance._real_extract(tf1ie_instance._TESTS[0]['url'])

# Generated at 2022-06-12 18:18:33.968429
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:37.686825
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    assert ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:38.332737
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()


# Generated at 2022-06-12 18:18:45.053434
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE();

    # Parse URL
    # Extract Video ID, Program ID and post_id
    # Check if extracted data is correct.
    # Download the video
    # Check if video is correct.
    # Test failed if the URL is incorrect.
    if(tf1.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') != True):
        raise Exception('URL Parsing Failed')

# Generated at 2022-06-12 18:18:47.165443
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:58.540769
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    t._VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:32.749583
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert tf1_ie._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert tf1_ie._TESTS[1]['url'] == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-12 18:19:37.941763
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    TF1IE(TF1IE.ie_key(), url)

# Generated at 2022-06-12 18:19:48.685800
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from youtube_dl.compat import compat_str
    from collections import OrderedDict

# Generated at 2022-06-12 18:19:50.320768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL.find('(?P<id>') < 0

# Generated at 2022-06-12 18:19:51.122666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-12 18:20:00.626327
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url="https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    obj=TF1IE(test_url)
    assert obj._VALID_URL== "^https?://(?:www\\.)?tf1\\.fr/[^/]+/[^/]+/videos/[^/?&#]+\\.html$"
    assert obj._TESTS[0]['url']== "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

# Generated at 2022-06-12 18:20:04.427673
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create test object
    tf1 = TF1IE()

    url = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

    # Check if URL is valid
    assert tf1._VALID_URL == tf1._match_id(url)

# Generated at 2022-06-12 18:20:05.500822
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except:
        pass

# Generated at 2022-06-12 18:20:09.349652
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()

    assert(instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-12 18:20:15.424125
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert( obj.url == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html" )


# Generated at 2022-06-12 18:20:43.221869
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE.
    """
    TF1IE('tf1', 'tf1')

# Generated at 2022-06-12 18:20:53.404048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    s = TF1IE()
    assert s.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True
    assert s.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert s.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == True

# Generated at 2022-06-12 18:20:55.459007
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE is not None

# Generated at 2022-06-12 18:20:56.340989
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE("1")

# Generated at 2022-06-12 18:20:57.192994
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:20:58.182780
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE()

# Generated at 2022-06-12 18:21:04.285282
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .common import InfoExtractor
    tf1_ie = InfoExtractor(dict())
    tf1_ie._download_webpage = lambda url, video_id: ""
    tf1_ie._sleep = lambda seconds, video_id: None

    video_url = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert tf1_ie.suitable(video_url)
    tf1_ie.extract(video_url)

# Generated at 2022-06-12 18:21:05.133256
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-12 18:21:05.656242
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:21:06.565633
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('test_TF1IE', True)

# Generated at 2022-06-12 18:22:18.068625
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test TF1IE with the examples from the docs
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    # test TF1IE with the examples from the README
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    # test TF1IE with the examples from the examples folder

# Generated at 2022-06-12 18:22:22.716451
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert(obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-12 18:22:25.197273
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'
    assert TF1IE.__doc__ == 'tf1.fr and tf1.fr'

# Generated at 2022-06-12 18:22:25.979990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for TF1IE
    TF1IE()

# Generated at 2022-06-12 18:22:28.351099
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.ie_key() == 'TF1'
    assert IE.ie_name() == 'TF1'

# Generated at 2022-06-12 18:22:34.388523
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie_obj = TF1IE("https://www.tf1.fr")
    assert(tf1ie_obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(tf1ie_obj._TESTS[0]["url"] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-12 18:22:35.698691
# Unit test for constructor of class TF1IE
def test_TF1IE():
    constructor = TF1IE.__init__
    instance = TF1IE(constructor)
    assert isinstance(instance, TF1IE)

# Generated at 2022-06-12 18:22:40.691958
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert isinstance(tf1ie, TF1IE)
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:22:44.001984
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-12 18:22:45.142159
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print(TF1IE)

# Generated at 2022-06-12 18:25:13.086894
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE)

# Generated at 2022-06-12 18:25:13.574177
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:25:20.402375
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instruction = ('1 - Choose the TF1 video page to extract\n'
    '2 - Open developer tools (F12) on your browser and switch to the "Network" tab\n'
    '3 - Refresh the video page and filter the URL requests to get the JSON containing the video information\n'
    '4 - Copy and paste the URL of the request containing the video information\n'
    '\n')

    url = input(instruction)
    assert re.search(TF1IE._VALID_URL, url)

    url = re.search(TF1IE._VALID_URL, url).group()
    program_slug, slug = re.match(TF1IE._VALID_URL, url).groups()
    json_input = input('5 - Copy and paste the content of the JSON file\n')

    video_json = json.loads

# Generated at 2022-06-12 18:25:22.787529
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoextractor = TF1IE()
    assert infoextractor is not None

# Generated at 2022-06-12 18:25:23.379101
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:25:25.902539
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract(url="https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:25:26.410169
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:25:29.374579
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_info = 'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    test_webpage = test_TF1IE(test_info)
    assert (test_webpage == TF1IE(test_info))

# Generated at 2022-06-12 18:25:32.787586
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert 'TF1IE' in str(type(t))
    assert 'TF1' in t.IE_NAME


# Generated at 2022-06-12 18:25:34.651185
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert TF1IE._VALID_URL.match(url)
    assert TF1IE._TESTS[0]['url'] == url