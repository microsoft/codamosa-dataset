

# Generated at 2022-06-12 18:17:34.011317
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:17:41.232584
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'tf1'
    assert ie.ie_key() == 'TF1'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:17:46.485984
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    ie = TF1IE(url)
    assert ie is not None
    assert ie._VALID_URL == TF1IE._VALID_URL
    assert ie._TESTS == TF1IE._TESTS

# Generated at 2022-06-12 18:17:47.439077
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    return tf1

# Generated at 2022-06-12 18:17:55.665237
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import re
    from ..utils import try_get
    from ..post import WatIE
    testurl = 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    urlid = 'replay-koh-lanta-22-mai-2015'
    testprogram = 'koh-lanta'
    ie = TF1IE()
    ie_download_json = ie._download_json
    ie_download_webpage = ie._download_webpage


# Generated at 2022-06-12 18:18:01.614657
# Unit test for constructor of class TF1IE
def test_TF1IE():

    class NoException(Exception):
        pass

    def parse_url(url):
        try:
            _ = TF1IE()._real_extract(url)
            raise NoException
        except Exception as e:
            print('Error raised while parsing URL : {}'.format(url))
            print(e)

    [parse_url('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')]

# Generated at 2022-06-12 18:18:12.681239
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(TF1IE._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert(TF1IE._TESTS[2]['url'] == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:18:21.317430
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Testing the url 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # In the unit test the context variable is set to true because the unit test is active.
    context = True
    # Extraction of the url to test
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    # Definition of the attributes of the constructor of the class TF1IE
    # In the unit test the download is set to false because we are not downloading the content in the unit test
    download = False
    # In the unit test the verbose is

# Generated at 2022-06-12 18:18:33.009788
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test valid url
    obj = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # Test some functions
    assert isinstance(obj, InfoExtractor)
    # Test private function

# Generated at 2022-06-12 18:18:33.610696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:42.932235
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')


# Generated at 2022-06-12 18:18:43.839404
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-12 18:18:46.764349
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        e = TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
        print(type(e))
    except:
        print("")

# Generated at 2022-06-12 18:18:48.338393
# Unit test for constructor of class TF1IE
def test_TF1IE():
    infoExtractor = TF1IE();
    expectedValue = 'TF1IE';
    assert infoExtractor._VALID_URL == expectedValue

# Generated at 2022-06-12 18:18:59.695037
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True
    assert ie.suitable('https://www.youtube.com/watch?v=zwiI_P6UaCM') == False
    assert ie.suitable('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html') == True
    assert ie.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert ie.r

# Generated at 2022-06-12 18:19:08.890287
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test URL of video page
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert TF1IE._TESTS[0]['url'] == url
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert TF1IE._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-12 18:19:10.323330
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t != None, "Test failed!"

# Generated at 2022-06-12 18:19:11.416538
# Unit test for constructor of class TF1IE
def test_TF1IE():
	TF1IE('test', 'test')

# Generated at 2022-06-12 18:19:21.134942
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:25.323193
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from wat.TF1IE import TF1IE
    tf1 = TF1IE()
    assert(isinstance(tf1, TF1IE),
           "tf1 should be an instance of TF1IE")

# Generated at 2022-06-12 18:19:36.490550
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-12 18:19:38.022869
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__name__ == 'TF1IE'

# Generated at 2022-06-12 18:19:43.460212
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == 'tf1'
    assert TF1IE()._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:44.375812
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-12 18:19:47.853663
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert hasattr(t, '_VALID_URL')
    assert hasattr(t, '_TESTS')
    assert hasattr(t, '_download_json')
    assert hasattr(t, '_real_extract')

# Generated at 2022-06-12 18:19:53.543319
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        from .test_utils import load_test_data_from_file
    except ImportError:
        from test_utils import load_test_data_from_file
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    test_info_dict = load_test_data_from_file("tf1.json")
    file = TF1IE()._real_extract(url)
    assert(file == test_info_dict)

# Generated at 2022-06-12 18:19:56.732078
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    obj.extract()

# Generated at 2022-06-12 18:19:58.537696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.IE_NAME == "TF1"



# Generated at 2022-06-12 18:19:59.892608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie=TF1IE()
    ie._VALID_URL

# Generated at 2022-06-12 18:20:00.838775
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE("", []))

# Generated at 2022-06-12 18:20:29.328667
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == "https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"

# Generated at 2022-06-12 18:20:31.400200
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.get_sources()

# Generated at 2022-06-12 18:20:38.249072
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video = TF1IE('tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert video.program_slug == 'tmc/quotidien-avec-yann-barthes'
    assert video.slug == 'quotidien-premiere-partie-11-juin-2019'

# Generated at 2022-06-12 18:20:39.570762
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE('TF1', False, [])
    assert t.ie_key() == 'TF1'

# Generated at 2022-06-12 18:20:42.872197
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # See https://github.com/ytdl-org/youtube-dl/issues/14164
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    ie = TF1IE()
    ie.extract(url)



# Generated at 2022-06-12 18:20:47.458105
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:20:51.539082
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE.ie_key() == "TF1"
    assert tf1IE.extractor_key() == "TF1"
    assert tf1IE.suitable(tf1IE._VALID_URL) == True


# Generated at 2022-06-12 18:20:56.045809
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE('TEST', 'TEST')

    assert obj.name == 'tvmultiplex'
    assert obj.ie_key == 'tvmultiplex:tf1'

# Generated at 2022-06-12 18:20:59.330811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-12 18:21:04.812411
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    #TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    #TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:22:08.197243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:22:12.568608
# Unit test for constructor of class TF1IE
def test_TF1IE():
    input = "https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    output = 'wat:13641379'
    TF1IE()._real_extract(input)

# Generated at 2022-06-12 18:22:15.583364
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE();
    assert(ie.description == None)
    assert(ie.extractor_key == 'TF1')
    assert(ie.name == 'TF1')
    assert(ie.ie_key == 'Wat')

# Generated at 2022-06-12 18:22:16.928540
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(InfoExtractor)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:22:20.068313
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.program_slug == 'koh-lanta'
    assert ie.slug == 'replay-koh-lanta-22-mai-2015'

# Generated at 2022-06-12 18:22:23.364813
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE('tf1')
    assert tf1IE is not None, 'Failed to create instance of tf1IE'
    return
# end unit test of constructor

# Generated at 2022-06-12 18:22:24.290254
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("test")

# Generated at 2022-06-12 18:22:26.166855
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert isinstance(tf1ie, InfoExtractor)

# Generated at 2022-06-12 18:22:34.388984
# Unit test for constructor of class TF1IE
def test_TF1IE():
    print("Unit test for constructor of class TF1IE")

    # Test with a valid URL
    example_url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    video = TF1IE()._real_extract(example_url)

    # Test return value

# Generated at 2022-06-12 18:22:36.085962
# Unit test for constructor of class TF1IE
def test_TF1IE():
    InfoExtractor().TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
# End unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:24:50.606467
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'https://wat.tf1.fr/wat/MEDIA/1671463568/4')

# Generated at 2022-06-12 18:24:52.925629
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:24:53.426684
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-12 18:24:54.619429
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Simple test for TF1IE.
    """
    obj = TF1IE()

# Generated at 2022-06-12 18:24:57.190723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.get_metadata_tag_map().get('title', {}).get('xpath') == '//title[not(@data-vars-name)]'

# Generated at 2022-06-12 18:25:02.842016
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert instance.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert instance.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert instance.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:25:03.361570
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:25:13.611096
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:25:20.417696
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test 1
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    result = TF1IE().extract(url)
    assert result['_type'] == 'url_transparent'
    assert result['id'] == '13641379'
    assert result['title'] == 'md5:f392bc52245dc5ad43771650c96fb620'
    assert result['description'] == 'md5:a02cdb217141fb2d469d6216339b052f'
    assert result['upload_date'] == '20190611'
    assert result['timestamp'] == 1560273989
    assert result['duration'] == 1738
   

# Generated at 2022-06-12 18:25:29.374844
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert obj._VALID_URL == "^https?://(?:www\\.)?tf1\\.fr/[^/]+/[^/]+/videos/[^/?&#]+.html$"
    assert obj._TESTS[0]["url"] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert obj._TESTS[0]["info_dict"]["id"] == "13641379"
    assert obj