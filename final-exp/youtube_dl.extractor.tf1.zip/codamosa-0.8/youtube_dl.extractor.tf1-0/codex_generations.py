

# Generated at 2022-06-12 18:17:36.734632
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert tf1.url == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert tf1.program_slug == "tmc/quotidien-avec-yann-barthes"
    assert tf1.id == "quotidien-premiere-partie-11-juin-2019"

# Generated at 2022-06-12 18:17:37.795390
# Unit test for constructor of class TF1IE
def test_TF1IE():
    parser = TF1IE()

# Generated at 2022-06-12 18:17:38.606474
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE



# Generated at 2022-06-12 18:17:45.705949
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.set_id('id')
    assert ie.get_id() == 'id'
    class_ = 'TF1IE'
    assert ie.get_class() == class_
    assert ie.get_sharing_url() == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
#

# Generated at 2022-06-12 18:17:50.231878
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().suit() == [
        'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html',
        'http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html'
    ]

# Generated at 2022-06-12 18:18:01.045744
# Unit test for constructor of class TF1IE
def test_TF1IE():
	tf1ie = TF1IE()
	assert tf1ie.IE_NAME == 'tf1'
	assert tf1ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
	assert tf1ie.IE_DESC == 'Télévision Française 1'
	assert tf1ie.IE_VERSION == '1.0'
	assert tf1ie.TEST == True
	assert tf1ie.BR_DESC == 'tf1'

# Generated at 2022-06-12 18:18:02.316179
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:18:12.763537
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:18:16.565322
# Unit test for constructor of class TF1IE
def test_TF1IE():
	print("\nUnit test :: instantiate class TF1IE(" + TF1IE._VALID_URL + ")")
	test_instance = TF1IE()
	assert test_instance._VALID_URL == TF1IE._VALID_URL


# Generated at 2022-06-12 18:18:18.388686
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/telefoot/videos/telefoot-3-mai-2020.html')

# Generated at 2022-06-12 18:18:26.614856
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 18:18:36.374843
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    # Test that run constructors of InfoExtractor
    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'TF1'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:43.192946
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie._real_extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:18:52.375132
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # assert the class is constructed with the correct regex
    assert TF1IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # assert that the regex matches the URL
    assert re.match(TF1IE._VALID_URL, 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    # re.match returns a MatchObject which contains the matched part, in this case the whole string, it will be
    # used to extract the program slug and the slug.

# Generated at 2022-06-12 18:19:01.104660
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:05.034420
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance
    instance = TF1IE()
    assert instance
    instance = TF1IE()
    assert instance
    instance = TF1IE()
    assert instance
    instance = TF1IE()
    assert instance
    instance = TF1IE()
    assert instance
    instance = TF1IE()
    assert instance

# Generated at 2022-06-12 18:19:05.610171
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:19:11.609789
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie.url == "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"

# Generated at 2022-06-12 18:19:12.833684
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

# Generated at 2022-06-12 18:19:15.187666
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE()
    except TypeError:
        pass
    except Exception:
        print('Failed')


# Generated at 2022-06-12 18:19:31.133030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()
    assert x.name == "tf1"
    assert x.title == None
    assert x.thumbnail == None
    assert x.description == None
    assert x.timestamp == None
    assert x.duration == None
    assert x.tags == None
    assert x.program_label == None
    assert x.season_number == None
    assert x.episode_number == None

# Generated at 2022-06-12 18:19:35.442050
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    assert tf1ie.IE_NAME == tf1ie.ie_key()

# Generated at 2022-06-12 18:19:37.596283
# Unit test for constructor of class TF1IE
def test_TF1IE():
    import unittest

    tester = TF1IE()

    return tester


# Generated at 2022-06-12 18:19:38.907034
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-12 18:19:40.930031
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_class = TF1IE
    assert test_class


# Generated at 2022-06-12 18:19:49.349679
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE('https://www.tf1.fr/dafttg/kim-kardashian/videos/kim-kardashian-aime-les-soutiens-gorge-triangulaires.html')
    assert e.url == 'https://www.tf1.fr/dafttg/kim-kardashian/videos/kim-kardashian-aime-les-soutiens-gorge-triangulaires.html'
    assert e.program_slug == 'kim-kardashian'
    assert e.id == 'kim-kardashian-aime-les-soutiens-gorge-triangulaires'

# Generated at 2022-06-12 18:19:50.517383
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert_raises(TypeError, TF1IE, None)

# Generated at 2022-06-12 18:19:59.893081
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()
    # the constructor of InfoExtractor doesn't take arguments
    assert(tf1ie.mbr == False)
    assert(tf1ie.age_limit == 0)
    assert(tf1ie.ie_key() == 'TF1')
    assert(tf1ie.ie_key() == 'TF1')
    assert(tf1ie.ie_key() == 'TF1')
    assert(tf1ie.ie_key() == 'tf1')
    assert(tf1ie.ie_key() == 'TF1')
    assert(tf1ie.ie_key() == 'TF1')
    assert(tf1ie.ie_key() == 'tf1')
    assert(tf1ie.ie_key() == 'TF1')

# Generated at 2022-06-12 18:20:00.352924
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()

# Generated at 2022-06-12 18:20:00.782161
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-12 18:20:30.552914
# Unit test for constructor of class TF1IE
def test_TF1IE():

    # test url with title and id
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    regexp = r'https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/(?P<id>[^/?&#]+)\.html'
    m = re.match(regexp, url)
    assert m, 'url = ' + url + ', regexp = ' + regexp
    prog_id = m.group('id')
    assert prog_id == 'quotidien-premiere-partie-11-juin-2019'

    # test url with title and id

# Generated at 2022-06-12 18:20:38.678907
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert(test.suitable("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"))
    assert(not test.suitable("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"))
    assert(not test.suitable("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015"))

# Generated at 2022-06-12 18:20:39.920646
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1.test()


test_TF1IE = test_TF1IE()

# Generated at 2022-06-12 18:20:44.424549
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Arrange
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

    # Act
    tf1ie_inst = TF1IE()

    # Assert
    assert tf1ie_inst.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') is not None
    assert tf1ie_inst._real_extract(url) is not None

# Generated at 2022-06-12 18:20:53.714141
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """test for the constructor of the class  TF1IE"""
    ie = TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert ie.url == 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html', \
        "incorrect url"
    assert ie.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html") == True, \
        "suitable fails"

# Generated at 2022-06-12 18:20:57.241809
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie is not None
    print(ie)

# Generated at 2022-06-12 18:21:06.489285
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert TF1IE._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/[^/]+/videos/[^/?&#]+\\.html'

# Generated at 2022-06-12 18:21:09.862681
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info = TF1IE()._real_extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert info["id"] == "13718682"
    assert info["title"] == "Koh-Lanta"

# Generated at 2022-06-12 18:21:11.639257
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == '(?i)https?://(?:www\.)?tf1\.fr/(?:[^/]+/)*(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:21:12.464908
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:22:11.315507
# Unit test for constructor of class TF1IE
def test_TF1IE():
    '''Check that class constructor is not broken.'''
    ie = TF1IE({'_type': 'url_transparent'})
    assert ie

# Generated at 2022-06-12 18:22:18.904924
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.name == 'TF1'
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert obj.host == 'www.tf1.fr'
    assert obj.ie_key() == 'TF1'
    assert obj.ie_key() == 'TF1'
    assert obj.tld == 'fr'
    assert obj.external() == False
    assert obj.json() == True
    assert obj.search_title == 'TF1'
    assert obj.__version__ == '0.0.16'
    assert obj.test() == True

# Generated at 2022-06-12 18:22:19.802440
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1 is not None

# Generated at 2022-06-12 18:22:30.566856
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # 1
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    _VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    mobj = re.match(_VALID_URL, url)
    assert mobj.groups()[0] == 'tf1', 'Should get program slug \"tf1\"'
    assert mobj.groups()[1] == 'replay-koh-lanta-22-mai-2015', 'Should get slug \"replay-koh-lanta-22-mai-2015\"'

# Generated at 2022-06-12 18:22:33.263911
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(tf1ie)(url)

# Generated at 2022-06-12 18:22:35.861163
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    # This should fail
    assert not IE.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:22:36.704531
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if __name__ == '__main__':
        TF1IE().download_test()

# Generated at 2022-06-12 18:22:46.390089
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()

    assert ie.IE_NAME == 'tf1'
    assert ie.IE_DESC == 'tf1.fr'
    assert ie._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-12 18:22:54.871688
# Unit test for constructor of class TF1IE
def test_TF1IE():
	# Test on replay of a whole show
	show = TF1IE(TF1IE()).extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
	assert show['id'] == '13641379'
	assert show['ext'] == 'mp4'
	assert show['title'] == 'Quotidien / Première partie'

# Generated at 2022-06-12 18:22:57.608493
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    if isinstance(instance, TF1IE) is not True:
        raise TypeError("TF1IE is not of type tf1")

# Generated at 2022-06-12 18:25:16.805765
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test a valid URL
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

    # Test an invalid URL
    try:
        TF1IE('http://www.tf1.fr/')
    except ValueError as e:
        assert e.args[0] == 'Invalid URL: http://www.tf1.fr/'
    else:
        assert False

# Generated at 2022-06-12 18:25:17.241113
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE

# Generated at 2022-06-12 18:25:21.416303
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video_info = TF1IE().extract_info("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert video_info["url"] == "wat:4723f36a-d8f2-4e17-9b9e-f47d3b3f3d36"
    assert video_info["id"] == "4723f36a-d8f2-4e17-9b9e-f47d3b3f3d36"

# Generated at 2022-06-12 18:25:22.077363
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('TF1IE')

# Generated at 2022-06-12 18:25:29.344398
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    assert tf1.IE_NAME == "tf1"
    assert tf1.ie_key() == 'TF1'
    assert tf1.VIDEO_URL_TEMPLATE == r'https?://www.wat.tv/get/android2/%s'
    assert tf1.IE_DESC == "Télévision Française 1"
    assert tf1.webpage_url_hook == None
    assert tf1.requires_webpage == False
    assert tf1._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-12 18:25:32.513030
# Unit test for constructor of class TF1IE
def test_TF1IE():
    with InfoExtractor() as ie:
        assert ie.extract(TF1IE._VALID_URL)

# Generated at 2022-06-12 18:25:33.940990
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == ie._TESTS[0]['url']

# Generated at 2022-06-12 18:25:38.594603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._real_initialize(url='https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie.url == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'

# Generated at 2022-06-12 18:25:39.078153
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:25:39.524654
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()