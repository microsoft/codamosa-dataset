

# Generated at 2022-06-12 18:17:25.706135
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:17:28.580780
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-12 18:17:30.391929
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:17:31.054308
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:17:34.633385
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.download('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:17:35.969783
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)._constructor_test(TF1IE.__name__)

# Generated at 2022-06-12 18:17:36.976572
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE() == TF1IE

# Generated at 2022-06-12 18:17:38.288759
# Unit test for constructor of class TF1IE
def test_TF1IE():
    global IE_CLASS
    TF1IE('test_IE', True)

# Generated at 2022-06-12 18:17:43.612685
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    assert tf1IE.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert not tf1IE.suitable("https://www.leprogres.fr/")



# Generated at 2022-06-12 18:17:44.542544
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().ie_key() == 'TF1'

# Generated at 2022-06-12 18:17:57.184091
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:17:59.955164
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE()
    assert e.ie_key() == 'tf1'
    assert e.ie_name() == "tf1"
    assert e.get_url_re() is not None


# Generated at 2022-06-12 18:18:00.811428
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL

# Generated at 2022-06-12 18:18:07.034891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(TF1IE.ie_key())
    ie_tests = ie._TESTS

    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:09.873851
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test constructor:
    # TF1IE
    t = TF1IE()
    assert t.ie_key() == 'TF1'
    assert t.ie_code() == 'TF1'
    assert t.name() == 'TF1'

# Generated at 2022-06-12 18:18:13.861760
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.NAME == 'tf1.fr'
    assert t._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:17.554154
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Constructor will raise on error
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:18:18.350048
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-12 18:18:25.062362
# Unit test for constructor of class TF1IE
def test_TF1IE():
  test = TF1IE(None)
  assert (test.ie_key() == 'TF1')
  assert (test._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-12 18:18:25.843791
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:46.168613
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    t = TF1IE('TF1IE', 'TF1', 'Tf1')
    assert t.name == 'TF1IE'
    assert t.ie_key() == 'tf1'
    assert t.ie_key() == 'TF1'
    assert t.IE_NAME == 'Tf1'
    assert t.ie_key() != None

# Generated at 2022-06-12 18:18:48.280882
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie == TF1IE()

# Generated at 2022-06-12 18:18:59.702981
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Basic test of TF1IE class constructor
    """

# Generated at 2022-06-12 18:19:03.215932
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(None).extract(url)

# Generated at 2022-06-12 18:19:04.622906
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    # The constructor of TF1IE should have 4 parameters
    assert len(tf1IE.__init__.__code__.co_varnames) == 4

# Generated at 2022-06-12 18:19:05.163918
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:19:06.233465
# Unit test for constructor of class TF1IE
def test_TF1IE():
    info_extractor = TF1IE()

# Generated at 2022-06-12 18:19:08.889421
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('wat')
    assert isinstance(tf1, InfoExtractor)

# Generated at 2022-06-12 18:19:19.039845
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # First step
    constructor = InfoExtractor
    constructor._VALID_URL = r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    id1 = '13641379'
    title1 = 'md5:f392bc52245dc5ad43771650c96fb620'
    description1 = 'md5:a02cdb217141fb2d469d6216339b052f'
    upload_date1 = '20190611'
    timestamp1 = 1560273989
    duration1 = 1738
    series1 = 'Quotidien avec Yann Barthès'

# Generated at 2022-06-12 18:19:20.336986
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'tf1'

# Generated at 2022-06-12 18:19:40.969080
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:19:41.823281
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    TF1IE('wat:13641379')

# Generated at 2022-06-12 18:19:44.462313
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE(None)
    assert isinstance(instance, TF1IE)
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-12 18:19:52.546954
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:55.252881
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor for class TF1IE.
    """
    # Use constructor of class
    t = TF1IE
    # The constructor of class should return a subclass of InfoExtractor
    assert issubclass(t, InfoExtractor)


# Generated at 2022-06-12 18:19:59.616793
# Unit test for constructor of class TF1IE
def test_TF1IE():
	connection = urlopen('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
	print("")
	print("Unit test for constructor of class TF1IE")
	assert connection != None

# Generated at 2022-06-12 18:20:00.579719
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Testing constructor of TF1IE
    assert TF1IE

# Generated at 2022-06-12 18:20:02.178229
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert_raises(AssertionError, TF1IE, "Not an URL")

# Generated at 2022-06-12 18:20:03.334062
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE("test", {})
    assert tf1 is not None

# Generated at 2022-06-12 18:20:10.078834
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:20:52.690282
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test.construct()

# Generated at 2022-06-12 18:20:55.562710
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE("TF1IE")
    assert tf1_ie is not None

# Generated at 2022-06-12 18:20:58.741810
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:21:03.075040
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor test of TF1IE
    """
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    tf1 = TF1IE()

    # TODO: check what it is supposed to do
    tf1.extract(url)

# Generated at 2022-06-12 18:21:06.958805
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.__class__.__name__ == 'TF1IE'
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:21:08.014031
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if __name__ == '__main__':
        TF1IE()()

# Generated at 2022-06-12 18:21:08.725004
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:21:10.955483
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    TF1IE(url)

# Generated at 2022-06-12 18:21:11.667374
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    pass

# Generated at 2022-06-12 18:21:12.067268
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:22:57.505184
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:23:00.120157
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test for TF1IE constructor"""
    return TF1IE(TrucAvecYoutubeDl()).__class__

# Generated at 2022-06-12 18:23:00.911062
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:23:01.511211
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None) is not None

# Generated at 2022-06-12 18:23:03.040723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        assert TF1IE() is None
    except AssertionError:
        assert False

# Generated at 2022-06-12 18:23:06.002806
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert re.match(TF1IE._VALID_URL, url)



# Generated at 2022-06-12 18:23:06.809709
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if TF1IE() is not None:
        pass

# Generated at 2022-06-12 18:23:12.467012
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Testing with a bad url
    from .test_utils import make_bad_assumptions_test
    make_bad_assumptions_test(
        TF1IE, ['http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'])

    # Testing with a good url
    from .test_utils import make_good_assumptions_test
    from .test_utils import make_response
    from .test_utils import make_url_request
    from .test_utils import make_urlopen_test

# Generated at 2022-06-12 18:23:19.141429
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Tests for class TF1IE"""
    video_url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    video_id = "replay-koh-lanta-22-mai-2015"
    if not TF1IE._WORKING:
        raise Exception('TF1 downloader currently not working')
    TF1IE(IE_NAME, IE_SHORT_NAME).download_video(video_url, video_id)

# Generated at 2022-06-12 18:23:20.041091
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()