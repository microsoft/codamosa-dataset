

# Generated at 2022-06-12 18:17:35.080905
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE(None)
    assert instance.IE_NAME == 'tf1'
    assert instance.IE_DESC == 'TF1'
    assert instance._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:17:41.715288
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert_equal(TF1IE._VALID_URL, r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')

# Generated at 2022-06-12 18:17:42.702988
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE is not None

# Generated at 2022-06-12 18:17:43.365694
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:17:50.474184
# Unit test for constructor of class TF1IE
def test_TF1IE():
    d = TF1IE({'downloader': 'a', 'age_limit': 18})
    assert d.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert not d.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert d.IE_NAME == 'wat'

# Generated at 2022-06-12 18:17:53.386517
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.TF1IE == TF1IE
    assert t.IE_NAME == 'TF1'

# Generated at 2022-06-12 18:18:00.473947
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html",
          "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html",
          "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-12 18:18:02.447521
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:18:04.169933
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:18:05.068596
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:11.863566
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()


# Generated at 2022-06-12 18:18:16.342486
# Unit test for constructor of class TF1IE
def test_TF1IE():
	url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
	ie = TF1IE()
	ie.extract(url)

test_TF1IE()

# Generated at 2022-06-12 18:18:17.426216
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor(),"")

# Generated at 2022-06-12 18:18:20.281565
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-12 18:18:32.388918
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie._VALID_URL == \
        r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:18:39.662826
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test an URL of a program that has not been aired yet
    to_test = TF1IE._build_url_result(
            'https://www.tf1.fr/tf1/touche-pas-a-mon-poste/videos/replay-tpmp-14-janvier-2015.html')
    assert to_test == {
        '_type': 'url_transparent',
        'url': 'wat:replay-tpmp-14-janvier-2015',
        'ie_key': 'wat'
    }

    # Test an URL of a program that is not on TF1
    to_test = TF1IE._build_url_result(
            'https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:18:40.307592
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    print('test over')

# Generated at 2022-06-12 18:18:42.045494
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie == 'TF1'

# Generated at 2022-06-12 18:18:43.361840
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_instance = TF1IE()
    assert class_instance

# Generated at 2022-06-12 18:18:44.646264
# Unit test for constructor of class TF1IE
def test_TF1IE():
    return TF1IE()

# Test for TF1IE.extract

# Generated at 2022-06-12 18:18:58.262754
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE(None)
    assert ie

# Generated at 2022-06-12 18:18:58.982831
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-12 18:19:00.059881
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t is not None

# Generated at 2022-06-12 18:19:10.566949
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1ie.program_slug == 'koh-lanta'
    assert tf1ie.slug == 'replay-koh-lanta-22-mai-2015'
    assert tf1ie.query == {
        'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f',
        'variables': '{"programSlug": "koh-lanta", "slug": "replay-koh-lanta-22-mai-2015"}'
    }
    assert tf1ie.url

# Generated at 2022-06-12 18:19:20.497613
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Set the expected values that will be returned by the module `WatIE`
    expected_video_id = '1234'
    expected_title = 'Video title'
    expected_description = 'Video description'
    expected_thumbnail = 'https://example.com/video-thumbnail.jpg'
    expected_timestamp = 1473016932
    expected_duration = 1234
    expected_tags = ['Tag 1', 'Tag 2']
    expected_series = 'Video series'
    expected_season_number = 1
    expected_episode_number = 2

    # Initialize the constructor of class TF1IE with the URL of the video to download

# Generated at 2022-06-12 18:19:24.960936
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE('tf1', 'tf1')
    assert str(IE) == 'TF1'
    assert IE.IE_NAME == 'tf1'
    assert IE.IE_DESC == 'tf1'
    assert IE._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:28.357166
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()
    ie = TF1IE()

# Generated at 2022-06-12 18:19:29.948262
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """The constructor of TF1IE should return an instance of class TF1IE without fail."""
    return TF1IE()

# Generated at 2022-06-12 18:19:32.947357
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert(TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert(TF1IE().ie_key() == 'TF1')

# Generated at 2022-06-12 18:19:37.980534
# Unit test for constructor of class TF1IE
def test_TF1IE():
    IE = TF1IE()
    assert IE.IE_NAME == 'tf1'
    assert IE.EXPECTED_URL_TEMPLATE == 'https://www.tf1.fr/%(program_slug)s/videos/%(id)s.html'


# Generated at 2022-06-12 18:20:08.122032
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test for the URL
    tf1 = TF1IE(10)
    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:09.349257
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()
    tf1IE.get_info()

# Generated at 2022-06-12 18:20:13.101607
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    TF1IE('https://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:20:23.164549
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert test
    assert test._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:30.274930
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    inst = TF1IE(url)
    assert inst is not None
    assert inst._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert inst._TESTS[0]['url'] == url
    assert inst._TESTS[0]['only_matching'] is False
    assert inst._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-12 18:20:35.529977
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:20:41.546711
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")._download_json("https://www.tf1.fr/graphql/web", "replay-koh-lanta-22-mai-2015", query={'id': '9b80783950b85247541dd1d851f9cc7fa36574af015621f853ab111a679ce26f', 'variables': json.dumps({'programSlug': 'koh-lanta', 'slug': 'replay-koh-lanta-22-mai-2015'})})

# Generated at 2022-06-12 18:20:42.871812
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE(cachedir=None)
    assert isinstance(tf1_ie, TF1IE)

# Generated at 2022-06-12 18:20:51.367698
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test class constructor"""
    tf1ie = TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert tf1ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:53.221311
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.__module__ == 'tf1'

# Generated at 2022-06-12 18:22:00.209904
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('test')
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:22:07.270105
# Unit test for constructor of class TF1IE
def test_TF1IE(): 
    # Call the constructor of TF1IE
    tf1IE = TF1IE()
    # Test _VALID_URL attribute of constructor
    expected = tf1IE._VALID_URL
    assert expected == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    # Test _TESTS attribute of constructor
    expected = len(tf1IE._TESTS)
    assert expected == 3

# Generated at 2022-06-12 18:22:08.890597
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:22:09.786502
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:22:16.892980
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1ie.url == 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert tf1ie.slug == 'replay-koh-lanta-22-mai-2015'
    assert tf1ie.program_slug == 'tf1/koh-lanta'


# Test for constructor of class TF1IE

# Generated at 2022-06-12 18:22:17.686736
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('url')

# Generated at 2022-06-12 18:22:19.101135
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(InfoExtractor('test-IE'))

# Generated at 2022-06-12 18:22:25.344313
# Unit test for constructor of class TF1IE
def test_TF1IE():
    extractor = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert 'https://www.tf1.fr/graphql/web' in extractor._downloader._request('https://www.tf1.fr/graphql/web').text

# Generated at 2022-06-12 18:22:33.807698
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert ie._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:22:34.320373
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:24:53.531494
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:24:54.046218
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-12 18:24:54.841010
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:24:56.518517
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.ie_key() == 'TF1'
    assert ie.ie_id() == 'tf1'

# Generated at 2022-06-12 18:24:58.212226
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE('tf1:replay-koh-lanta-22-mai-2015') is not None


# Generated at 2022-06-12 18:24:59.417029
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # TODO: Check the implementation of the test
    # assert isinstance(TF1IE, object)
    pass

# Generated at 2022-06-12 18:25:08.504743
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    test_url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert test._VALID_URL == re.compile(r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html')
    assert test._real_extract(test_url)['title'] == "Quotidien Première partie - 11 Juin 2019"

# Generated at 2022-06-12 18:25:09.266292
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None)

# Generated at 2022-06-12 18:25:16.587876
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert test._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert test._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert test._TESTS[0]['info_dict']['id'] == '13641379'

# Generated at 2022-06-12 18:25:22.535915
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert t.suitable("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")
    assert not t.suitable("https://wat.tv/video/koh-lanta-2015-jungle-indonésienne-67g7y.html")
    assert not t.suitable("https://www.wat.tv/video/koh-lanta-2015-jungle-indonesienne-67g7y.html")