

# Generated at 2022-06-12 18:17:28.686326
# Unit test for constructor of class TF1IE
def test_TF1IE():
    new_TF1IE = TF1IE(None)
    assert new_TF1IE is not None

# Generated at 2022-06-12 18:17:34.068519
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None).IE_NAME == "tf1.fr"
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:17:35.500273
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj


# Generated at 2022-06-12 18:17:38.677850
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE()
    assert obj.ie_key() == 'tf1'
    assert obj.working == True
    assert obj.server_url == 'https://www.tf1.fr/graphql/web'


# Generated at 2022-06-12 18:17:43.612603
# Unit test for constructor of class TF1IE
def test_TF1IE():
    Instance = TF1IE()

# Generated at 2022-06-12 18:17:45.349327
# Unit test for constructor of class TF1IE
def test_TF1IE():
    from .test_expected_output import TF1IE_test_expected_output
    # Test for updated code since new code for TF1, no need for database access
    TF1IE_test_expected_output(TF1IE)

# Generated at 2022-06-12 18:17:47.849706
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:17:48.427966
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:17:49.680250
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    assert tf1_ie

# Generated at 2022-06-12 18:17:57.586643
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert t.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert t.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    assert not t.suitable('https://www.tf1.fr/')
    assert not t.suitable('https://www.tf1.fr/foo/bar/baz')
    assert not t.su

# Generated at 2022-06-12 18:18:10.179490
# Unit test for constructor of class TF1IE
def test_TF1IE():
    obj = TF1IE("")
    assert obj.IE_NAME == 'TF1'

# Generated at 2022-06-12 18:18:10.729294
# Unit test for constructor of class TF1IE
def test_TF1IE():
    pass

# Generated at 2022-06-12 18:18:12.041461
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test = TF1IE()
    assert type(test) == TF1IE

# Generated at 2022-06-12 18:18:14.079243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    inst = TF1IE()
    assert inst.__class__ == TF1IE

# Generated at 2022-06-12 18:18:15.643509
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suite()

# Generated at 2022-06-12 18:18:22.094141
# Unit test for constructor of class TF1IE
def test_TF1IE():
    try:
        TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    except (ValueError, AttributeError):
        # If either of these exceptions are thrown, the TF1IE constructor does not exist or does not do what it is supposed to (according to the design).
        fail('TF1IE constructor does not exist or does not do what it is supposed to.')
    else:
        pass # Do nothing if the TF1IE constructor does exist and does what it is supposed to.


# Generated at 2022-06-12 18:18:22.789393
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:34.192218
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:18:34.808494
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:18:40.393476
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert re.search(r'r\'^https?://(?:www\.)?tf1\.fr/[^/]+/[^/]+/videos/[^/?&#]\+.html\',', str(ie))
    assert ie.IE_NAME == 'tf1'

# Generated at 2022-06-12 18:19:00.760385
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html') == True
    assert t.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == True
    assert t.suitable('https://www.wat.tv/') == False
    assert t.suitable('https://www.wat.tv/17782967_cj9t4.html') == False

# Generated at 2022-06-12 18:19:04.452201
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE_test_1 = TF1IE();
    assert TF1IE_test_1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:06.572174
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie_constructor = TF1IE('test_TF1IE')
    assert tf1_ie_constructor



# Generated at 2022-06-12 18:19:07.187792
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:19:13.859698
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()
    tf1_valid_url = 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html'
    assert tf1._VALID_URL == re.compile(TF1IE._VALID_URL)
    assert tf1._VALID_URL.match(tf1_valid_url)

# Generated at 2022-06-12 18:19:17.493956
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE(None)._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'


# Generated at 2022-06-12 18:19:19.764245
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None, "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:19:21.290486
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE.suitable([TF1IE._VALID_URL]) == True


# Generated at 2022-06-12 18:19:22.944343
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # pylint: disable=protected-access
    assert TF1IE(None)._VALID_URL == TF1IE._VALID_URL

# Generated at 2022-06-12 18:19:27.034723
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Example of URL that has a dash (-) in its ID, this was causing an
    # exception to be raised
    url = 'https://www.tf1.fr/tf1/eurosport-player/videos/rallye-rallye-du-mexique-samedi-10-mars-2018.html'
    t = TF1IE()
    # Verify it doesn't raise the exception
    t._real_extract(url)

# Generated at 2022-06-12 18:19:58.891120
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:07.089768
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    instance.url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert instance._TESTS[0]['url'] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

# Generated at 2022-06-12 18:20:08.176926
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()

# Generated at 2022-06-12 18:20:08.823770
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t is not None

# Generated at 2022-06-12 18:20:14.416424
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test with valid url
    assert TF1IE().suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

    # Test with invalid url
    assert not TF1IE().suitable('http://www.wat.tv/my_video.html')
    assert not TF1IE().suitable('http://www.tf1.fr/')
    assert not TF1IE().suitable('http://www.tf1.fr/video_invalid_url')

# Generated at 2022-06-12 18:20:23.350706
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie._download_json = lambda url, video_id, query: {
        'data': {
            'videoBySlug': {
                'title': 'title',
                'streamId': 'video_id',
            }
        }
    }
    info = ie._real_extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert info == {
        '_type': 'url_transparent',
        'id': 'video_id',
        'url': 'wat:video_id',
        'title': 'title',
    }

# Generated at 2022-06-12 18:20:25.044811
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_instance = TF1IE()
    if tf1_instance.__class__ == TF1IE:
        return True
    else:
        return False

# Generated at 2022-06-12 18:20:25.543139
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:20:26.802137
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:20:27.644419
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-12 18:21:19.343924
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie_new_class = TF1IE()
    tf1ie_new_class.extract(tf1ie_new_class._TESTS[0]['url'])

# Generated at 2022-06-12 18:21:24.159125
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.extract('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:21:27.195624
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE({}, 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html', True).TF1_download()

# Generated at 2022-06-12 18:21:29.613796
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(None,"http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html",{})

# Generated at 2022-06-12 18:21:31.577562
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()

    assert(tf1_ie.IE_NAME == 'tf1')

# Generated at 2022-06-12 18:21:36.307585
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Test the constructor of TF1IE."""
    obj = TF1IE()
    assert obj.IE_NAME == 'tf1'
    assert obj.IE_DESC == 'TF1'
    assert obj._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
 

# Generated at 2022-06-12 18:21:39.368601
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().IE_NAME == 'tf1.fr'

# Generated at 2022-06-12 18:21:48.235269
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test video URL
    video_url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    # Create class TF1IE
    t1 = TF1IE()

    # Test constructor
    assert isinstance(t1, TF1IE) is True
    assert t1.suitable(video_url) is True
    assert t1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:21:50.246665
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    print(tf1_ie)


# Generated at 2022-06-12 18:21:55.999416
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Create an instance of TF1IE class
    tf1 = TF1IE()
    # Check if created instance has attribute _VALID_URL or not
    assert hasattr(tf1, '_VALID_URL') == True
    # Check if created instance has attribute _TESTS or not
    assert hasattr(tf1, '_TESTS') == True


# Generated at 2022-06-12 18:24:08.375922
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()
    assert t.name == 'tf1'

# Generated at 2022-06-12 18:24:10.848932
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE('abc')

# Generated at 2022-06-12 18:24:18.756427
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert 'TF1IE' == i.ie_key()
    assert 'TF1' == i.ie_key_short()
    assert '//www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html' == i._match_id('//www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')

# Generated at 2022-06-12 18:24:19.826891
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Just test that the constructor of TF1IE class
    """
    assert TF1IE()

# Generated at 2022-06-12 18:24:22.623093
# Unit test for constructor of class TF1IE
def test_TF1IE():
    params = {
        '_VALID_URL':r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html',
        'test': 'abc'
    }
    tf1 = TF1IE(params)
    assert tf1.test == 'abc'

# Generated at 2022-06-12 18:24:26.588421
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:24:27.276403
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("TF1IE", "tf1")

# Generated at 2022-06-12 18:24:28.201462
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_TF1IE = TF1IE()
    assert test_TF1IE

# Generated at 2022-06-12 18:24:31.936864
# Unit test for constructor of class TF1IE
def test_TF1IE():
	obj = TF1IE()
	assert obj.get_urls("https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:24:35.098313
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')