

# Generated at 2022-06-12 18:17:27.107079
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert(instance)

# Generated at 2022-06-12 18:17:28.046582
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE()

# Generated at 2022-06-12 18:17:29.005621
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()

# Generated at 2022-06-12 18:17:29.882598
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE(tf1.com)

# Generated at 2022-06-12 18:17:33.410045
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert tf1ie.constructor() == tf1ie


# Generated at 2022-06-12 18:17:38.964869
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE('http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    assert tf1_ie._VALID_URL == 'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:17:43.512959
# Unit test for constructor of class TF1IE
def test_TF1IE():
	info_extractor = TF1IE(None, 'https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
	info_extractor.extract()


# Generated at 2022-06-12 18:17:44.760397
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert isinstance(TF1IE(), TF1IE)

# Generated at 2022-06-12 18:17:45.330971
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:17:54.441779
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE().extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html') == {
			'_type': 'url_transparent',
			'id': '13641379',
			'url': 'wat:13641379',
			'title': 'md5:f392bc52245dc5ad43771650c96fb620',
			'description': 'md5:a02cdb217141fb2d469d6216339b052f',
			'timestamp': 1560273989,
			'tags': ['intégrale', 'quotidien', 'Replay'],
	}

# Generated at 2022-06-12 18:18:06.887917
# Unit test for constructor of class TF1IE
def test_TF1IE():
    class_obj = TF1IE({})
    assert isinstance(class_obj, InfoExtractor)

# Generated at 2022-06-12 18:18:07.759238
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._TESTS

# Generated at 2022-06-12 18:18:17.554341
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/l-integrale-du-22-mai-2015.html')
    ie.suitable('https://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
    ie

# Generated at 2022-06-12 18:18:23.667522
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    url = "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"
    assert ie.suitable(url) is True
    url = "http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html"
    assert ie.suitable(url) is True
    url = "http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html"
    assert ie.suitable(url) is True

# Generated at 2022-06-12 18:18:34.804587
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_object = TF1IE()
    assert test_object._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'
    assert test_object._TESTS[0]['url'] == 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    assert test_object._TESTS[0]['info_dict']['id'] == '13641379'
    assert test_object._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert test_object._

# Generated at 2022-06-12 18:18:37.248377
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    assert ie.IE_NAME == 'TF1'

# Generated at 2022-06-12 18:18:38.485579
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1IE = TF1IE()

# Generated at 2022-06-12 18:18:42.748254
# Unit test for constructor of class TF1IE
def test_TF1IE():
    i = TF1IE()
    assert i._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-12 18:18:45.089322
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie = TF1IE()
    ie.get_info("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-12 18:18:48.019518
# Unit test for constructor of class TF1IE
def test_TF1IE():
    video= TF1IE()
    print(video)
    assert(video)

# Generated at 2022-06-12 18:18:59.693616
# Unit test for constructor of class TF1IE
def test_TF1IE():
    t = TF1IE()

# Generated at 2022-06-12 18:19:01.125488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    e = TF1IE(0)
    assert e is not None

# Generated at 2022-06-12 18:19:02.708256
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Constructor test.
    """
    assert TF1IE(None) is not None

# Generated at 2022-06-12 18:19:13.762142
# Unit test for constructor of class TF1IE
def test_TF1IE():
    loader = TF1IE()
    with pytest.raises(AttributeError):
        loader.program_slug
    with pytest.raises(AttributeError):
        loader.slug
    with pytest.raises(AttributeError):
        loader.wat_id
    with pytest.raises(AttributeError):
        loader.tags
    with pytest.raises(AttributeError):
        loader.thumbnails
    with pytest.raises(AttributeError):
        loader.description
    with pytest.raises(AttributeError):
        loader.timestamp
    with pytest.raises(AttributeError):
        loader.duration
    with pytest.raises(AttributeError):
        loader.series
    with pytest.raises(AttributeError):
        loader.season_number

# Generated at 2022-06-12 18:19:14.852905
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()



# Generated at 2022-06-12 18:19:21.057931
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t = TF1IE(url)

# Generated at 2022-06-12 18:19:31.588873
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE('www.tf1.fr', 'tf1', '1234', 'koh-lanta')

    assert tf1._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:35.016266
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE().extractor_key == TF1IE.ie_key()

# Generated at 2022-06-12 18:19:42.924343
# Unit test for constructor of class TF1IE
def test_TF1IE():
    temp = TF1IE()
    assert temp._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:19:43.858751
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()
    return 0

# Generated at 2022-06-12 18:20:06.308374
# Unit test for constructor of class TF1IE
def test_TF1IE():
    ie_obj = TF1IE(None)
    ie_obj.constructor_test() 


# Generated at 2022-06-12 18:20:11.131668
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._VALID_URL is not None
    assert TF1IE.__name__ is not None
    tf1ie = TF1IE()
    assert tf1ie.__name__ is not None
    assert tf1ie._real_extract is not None
    assert tf1ie._VALID_URL is not None
    assert tf1ie._TESTS is not None

# Generated at 2022-06-12 18:20:11.566170
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:20:14.729312
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # Test if the constructor is correctly implemented
    assert TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html").name == "TF1IE"

# Generated at 2022-06-12 18:20:18.925279
# Unit test for constructor of class TF1IE
def test_TF1IE():
    # test URL with "docu" as well as "documentaire" (pending to find out if both are the same species)
    assert_equal(TF1IE(TF1IE.class_)._VALID_URL, TF1IE.class_._VALID_URL)

# Generated at 2022-06-12 18:20:25.009581
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-12 18:20:25.810243
# Unit test for constructor of class TF1IE
def test_TF1IE():
    x = TF1IE()


# Generated at 2022-06-12 18:20:28.491469
# Unit test for constructor of class TF1IE
def test_TF1IE():
    instance = TF1IE()
    assert instance._VALID_URL == r'https?://(?:www\.)?tf1\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html'

# Generated at 2022-06-12 18:20:32.981445
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE()._VALID_URL == 'https?://(?:www\\.)?tf1\\.fr/[^/]+/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\\.html'

# Generated at 2022-06-12 18:20:35.463160
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:21:28.863143
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'http://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'

    ie = TF1IE(url)

    assert ie.url == url
    assert ie.id == "13641379"
    assert ie._download_json == ie._download_json_impl

# Generated at 2022-06-12 18:21:31.794590
# Unit test for constructor of class TF1IE
def test_TF1IE():
    if __name__ == '__main__':
        tf1ie = TF1IE()
        print(tf1ie)
        print(dir(TF1IE))

# Generated at 2022-06-12 18:21:38.682457
# Unit test for constructor of class TF1IE
def test_TF1IE():
	assert TF1IE.suitable('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')
	assert TF1IE.suitable('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
	assert TF1IE.suitable('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')

# Generated at 2022-06-12 18:21:44.485413
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Extracting test for Wat site"""
    from tests.test_download import check_info_extraction
    check_info_extraction(TF1IE, 'tf1', 'http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')


# Generated at 2022-06-12 18:21:48.803148
# Unit test for constructor of class TF1IE
def test_TF1IE():
    url = 'https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html'
    t = TF1IE()
    t._real_extract(url)

# Generated at 2022-06-12 18:21:59.518141
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE._BASE_URL == "https://www.tf1.fr/"
    assert TF1IE._VALID_URL == r"https?://(?:\w+\.)?tf1\.fr/(?P<program_slug>[^/]+)/videos/(?P<id>[^/?&#]+)\.html"
    assert TF1IE._TESTS[0]["url"] == "https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

# Generated at 2022-06-12 18:22:00.411834
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1ie = TF1IE()

# Generated at 2022-06-12 18:22:08.540437
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """
    Unit test for constructor of class TF1IE
    """
    ie = TF1IE()
    ie.extract('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    ie.extract('http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html')
    ie.extract('https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html')

# Generated at 2022-06-12 18:22:09.745207
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()

# Generated at 2022-06-12 18:22:16.325203
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")
    assert TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")
    assert TF1IE("http://www.tf1.fr/hd1/documentaire/videos/mylene-farmer-d-une-icone.html")

# Generated at 2022-06-12 18:24:33.269351
# Unit test for constructor of class TF1IE
def test_TF1IE():
    test_url="https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html"

    tf1IE = TF1IE()
    assert tf1IE._VALID_URL == TF1IE._VALID_URL
    assert tf1IE._TESTS == TF1IE._TESTS
    assert tf1IE._NAME == TF1IE._NAME

    assert tf1IE._download_webpage(test_url,"").__class__ == str
    assert tf1IE._download_json("https://www.tf1.fr/graphql/web","",query={}).__class__ == dict

# Generated at 2022-06-12 18:24:33.715774
# Unit test for constructor of class TF1IE
def test_TF1IE():
    assert TF1IE

# Generated at 2022-06-12 18:24:40.742081
# Unit test for constructor of class TF1IE
def test_TF1IE():
    """Unit test for TF1IE"""
    class_ = TF1IE
    obj = class_('http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html')
    assert obj.__class__ == class_
    

# Generated at 2022-06-12 18:24:43.344434
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("https://www.tf1.fr/tmc/quotidien-avec-yann-barthes/videos/quotidien-premiere-partie-11-juin-2019.html")

# Generated at 2022-06-12 18:24:51.460174
# Unit test for constructor of class TF1IE

# Generated at 2022-06-12 18:24:52.463401
# Unit test for constructor of class TF1IE
def test_TF1IE():
    result = TF1IE()



# Generated at 2022-06-12 18:24:55.058848
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE()._real_extract(
        TF1IE._TESTS[0].get('url'))
    assert 'TF1IE' in globals()

# Generated at 2022-06-12 18:24:57.042488
# Unit test for constructor of class TF1IE
def test_TF1IE():
    TF1IE("http://www.tf1.fr/tf1/koh-lanta/videos/replay-koh-lanta-22-mai-2015.html")

# Generated at 2022-06-12 18:24:58.131199
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1_ie = TF1IE()
    tf1_ie.should_skip()

# Generated at 2022-06-12 18:25:03.127007
# Unit test for constructor of class TF1IE
def test_TF1IE():
    tf1 = TF1IE(None)
    assert isinstance(tf1, TF1IE)
    assert tf1.IE_NAME == 'TF1'
    # The URL to extract the information
    assert tf1._VALID_URL is not None
    # The dict which includes the data
    assert tf1._TESTS is not None