

# Generated at 2022-06-23 17:05:56.147068
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GP = GoogleParser()
    GP.add_section(Section("Args", "params", SectionType.MULTIPLE))
    assert GP.sections["Args"] == Section("Args", "params", SectionType.MULTIPLE)


# Generated at 2022-06-23 17:06:08.255699
# Unit test for function parse
def test_parse():
    def foo(p1, p2 = None, *p3, p4, **p5):
        """Short description.

        Long description.

        :param p1: First parameter.
        :param p2: Second parameter.
        :type p2: str
        :param p3: Variable number of arguments
        :param p4: Required parameter.
        :type p4: bytes
        :param p5: Optional parameter.
        :type p5: str
        :return: Nothing.
        :rtype: None
        :raises ValueError: When something bad happens
        """
        pass


# Generated at 2022-06-23 17:06:15.364016
# Unit test for constructor of class Section
def test_Section():
    a = Section('aaa','bbb', 0)
    assert a.title == 'aaa'
    assert a.key == 'bbb'
    assert a.type == 0
    assert a == a
    b = Section('bbb','ccc', 1)
    assert b.title == 'bbb'
    assert b.key == 'ccc'
    assert b.type == 1
    assert b == b


# Generated at 2022-06-23 17:06:27.952808
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test method parse of class GoogleParser"""
    docstr = """
    A method by Li.
    Args:
        arg1 (str): The first argument.
        arg2: The second argument. Defaults to None.
    Raises:
        ValueError: If any argument is None.
    Return:
        bool: The return value. True for success, False otherwise.
    """

    d = Docstring()
    d.short_description = "A method by Li."
    d.blank_after_short_description = True
    d.blank_after_long_description = False
    d.long_description = ""

# Generated at 2022-06-23 17:06:38.615623
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # ---- ---------- ---------- ---------- ---------- ---------- ---------- ----------
    # ---- Test case 1
    # ---- ---------- ---------- ---------- ---------- ---------- ---------- ----------
    #
    # Inputs
    #       None
    #
    # Expectation
    #       Type: Docstring
    #       Length: 0
    #
    # Actual
    #       Type: Docstring
    #       Length: 0
    #
    # Note:
    #       Tested
    # ---- ---------- ---------- ---------- ---------- ---------- ---------- ----------
    googleparser = GoogleParser()
    assert type(googleparser) is GoogleParser, "Should be GoogleParser"
    assert len(googleparser.sections) == len(DEFAULT_SECTIONS), "Should be " + str(len(DEFAULT_SECTIONS))

# Unit test

# Generated at 2022-06-23 17:06:39.236075
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert isinstance(GoogleParser(), GoogleParser)


# Generated at 2022-06-23 17:06:49.736918
# Unit test for function parse
def test_parse():
    def f(var_1, var_2=None):
        """Short desc
        Long desc

        Args:
          var_1 (int): var1. Defaults to True.
          var_2: str?, var2, optional.
        """
        pass

    docstring = parse(inspect.getdoc(f))
    assert docstring.short_description == "Short desc"
    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == "var1."
    assert docstring.meta[0].default == "True"
    assert docstring.meta[0].arg_name == "var_1"
    assert docstring.meta[0].type_name == "int"

    assert docstring.meta[1].description == "var2"

# Generated at 2022-06-23 17:07:00.147114
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Check add section"""
    parser = GoogleParser(title_colon=True)
    sections = parser.sections
    assert len(sections) == len(DEFAULT_SECTIONS)
    # Check if first section is in sections
    assert DEFAULT_SECTIONS[0] in sections.values()
    # Add new section
    parser.add_section(Section("Hello", "hello", SectionType.SINGULAR_OR_MULTIPLE))
    sections = parser.sections
    assert len(sections) == len(DEFAULT_SECTIONS) + 1
    assert sections[DEFAULT_SECTIONS[0].title] == DEFAULT_SECTIONS[0]
    assert sections["Hello"] == Section("Hello", "hello", SectionType.SINGULAR_OR_MULTIPLE)
    # Add new section with same title as another section

# Generated at 2022-06-23 17:07:03.594990
# Unit test for constructor of class Section
def test_Section():
    # Test instance
    s = Section("test_title", "test_key", SectionType.SINGULAR)
    assert s.title == "test_title"
    assert s.key == "test_key"
    assert s.type == 0



# Generated at 2022-06-23 17:07:10.570081
# Unit test for function parse
def test_parse():
    d = """Returns True if the input is even, otherwise False.
    Examples:
        is_even(2)
            True
        is_even(3)
            False
    """
    p = parse(d)
    assert p.short_description == 'Returns True if the input is even, otherwise False.'
    assert len(p.meta) == 3
    assert p.meta[0].args == ['examples', 'is_even(2)']
    assert p.meta[0].description == 'True'
    assert p.meta[1].args == ['examples', 'is_even(3)']
    assert p.meta[1].description == 'False'

# Generated at 2022-06-23 17:07:22.025335
# Unit test for function parse
def test_parse():
    text = """
        Clean function.

        Usage::

            clean(a1, a2, a3=3)

        Parameters
        ----------
        a1 : str
            Description of a1.

        a2 : str, int
            Description of a2.

        a3 : str, optional
            Description of a3. Defaults to 3.

        Returns
        -------
        str
            Description of return value.

        Raises
        ------
        ValueError
            If a4 is not valid.

        Examples
        --------
        >>> clean(a1, a2, a3=3)
        'Cleaned'

    """

    doc = parse(text)
    assert doc.short_description == "Clean function."
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description

# Generated at 2022-06-23 17:07:26.803609
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    title_colon = True # title_colon = True means to require colon after section title. False means to not require.
    sections = DEFAULT_SECTIONS
    assert GoogleParser(sections, title_colon).title_colon == True
    assert GoogleParser(sections).title_colon == True
    assert GoogleParser(sections, False).title_colon == False
    assert GoogleParser(None, False).title_colon == False
    assert GoogleParser(None).title_colon == True


# Generated at 2022-06-23 17:07:30.777614
# Unit test for function parse
def test_parse():
    parser = GoogleParser()
    docstring = parser.parse('''
    db_name:
        The name of the database
        in which the table resides
        on InfoBright's MySQL
        server.

        Defaults to 'my_first_database'.
    ''')


# Generated at 2022-06-23 17:07:35.685406
# Unit test for constructor of class Section
def test_Section():
    new_section = Section("Example", "examples", SectionType.SINGULAR)
    print(new_section)
    print(new_section.title)
    print(new_section.key)
    print(new_section.type)



# Generated at 2022-06-23 17:07:40.551949
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Parameters
    ----------
    x : int
        Description
    y : str, optional
        Description
    Returns
    -------
    None
    '''
    docstring = GoogleParser().parse(text)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == "Description"
    assert docstring.meta[0].arg_name == "x"
    assert docstring.meta[0].type_name == "int"
    assert docstring.meta[1].description == "Description"
    assert docstring.meta[1].arg_name == "y"
    assert docstring.meta[1].type_name == "str"
    assert docstring.meta[1].is_

# Generated at 2022-06-23 17:07:43.610035
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test add section of GoogleParser
    :return error if there are some
    """
    parser = GoogleParser()
    parser.add_section(Section('Test', 'param', SectionType.MULTIPLE))
    return parser.sections

# Generated at 2022-06-23 17:07:51.061853
# Unit test for function parse
def test_parse():
    parser = GoogleParser(title_colon=False)
    docstring = """
    Short description.

    Long description.

    Args:
        arg1: first arg
        arg2 (int): second arg

    Returns:
        None

    Raises:
        ValueError if something wrong

    """
    parsed = parser.parse(docstring)
    assert parsed.short_description == "Short description."
    assert parsed.long_description == "Long description."
    assert len(parsed.meta) == 4
    returns_meta = parsed.meta[3]
    assert isinstance(returns_meta, DocstringReturns)
    assert len(returns_meta.args) == 1
    assert returns_meta.description == "None"
    assert returns_meta.is_generator is False

# Generated at 2022-06-23 17:08:01.959353
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ret = Docstring()
    # Test None
    assert(GoogleParser().parse(None)==ret)
    # Test empty string
    assert(GoogleParser().parse("")==ret)
    # Test docstring with short description 
    text1 = """short description."""
    ret1 = Docstring()
    ret1.short_description = "short description."
    assert(GoogleParser().parse(text1)==ret1)
    # Test docstring with long description
    text2 = """short description.
    long description."""
    ret2 = Docstring()
    ret2.short_description = "short description."
    ret2.blank_after_short_description = True
    ret2.long_description = "long description."
    ret2.blank_after_long_description = True

# Generated at 2022-06-23 17:08:08.393188
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    from .numpy import NumpyParser
    from .sphinx import SphinxParser
    tmp1 = GoogleParser()
    tmp2 = GoogleParser(sections=DEFAULT_SECTIONS, title_colon=True)
    tmp3 = GoogleParser([])
    assert isinstance(tmp1, GoogleParser)
    assert isinstance(tmp2, GoogleParser)
    assert isinstance(tmp3, GoogleParser)


# Generated at 2022-06-23 17:08:18.577625
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    title1 = "Argument"
    title2 = "Raises"
    title3 = "Returns"
    title4 = "AaA"
    section1 = Section(title1, "param", SectionType.MULTIPLE)
    section2 = Section(title2, "raises", SectionType.MULTIPLE)
    section3 = Section(title3, "returns", SectionType.SINGULAR_OR_MULTIPLE)
    section4 = Section(title4, "AaA", SectionType.SINGULAR)
    sections = [section1, section2, section3, section4]
    parser = GoogleParser(sections)
    assert parser.sections[title1] == section1
    assert parser.sections[title2] == section2
    assert parser.sections[title3] == section3
    assert parser.sections

# Generated at 2022-06-23 17:08:30.979242
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # setup values
    d = GoogleParser()
    text = """Insertion Sort:
    A simple sorting algorithm that sorts a list by continuously comparing
    values to their right and inserting them into their correct position.

    Example:
        >>> l = [6,3,1,8,4,2]
        >>> insertion_sort(l)
        >>> l
        [1, 2, 3, 4, 6, 8]

    Parameters:
        :list l: a list of numeric values or string characters

    Returns:
        A sorted list.

    Raises:
        ValueError: if inputted list contains non-numeric
        TypeError: if inputted list contains non-integer values

    """

    # execute method
    result = d.parse(text)

    # verify results
    assert isinstance(result, Docstring)
    # assert len(meta

# Generated at 2022-06-23 17:08:37.590715
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Authors", "author", SectionType.MULTIPLE))
    authors = "Guang Zeng\nXuejiao Wang"
    meta = parser.parse("Authors:\n  %s" % authors)
    assert len(meta.meta[0].args) == 2
    assert meta.meta[0].args[1] == authors

# Generated at 2022-06-23 17:08:40.097279
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("MySection", "mysection", SectionType.SINGULAR))


# Generated at 2022-06-23 17:08:42.254518
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser(DEFAULT_SECTIONS)
    match = gp.titles_re.match('Returns: ')
    assert match is not None


# Generated at 2022-06-23 17:08:49.005039
# Unit test for constructor of class Section
def test_Section():
    """
    This function tests if the object of class Section can be constructed
    """
    Section("returns", "returns", SectionType.SINGULAR)
    Section("returns", "returns", SectionType.MULTIPLE)
    Section("returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)


# Generated at 2022-06-23 17:08:54.399873
# Unit test for constructor of class Section
def test_Section():
    try:
        SectionBase = namedtuple("SectionBase", "title")
        s = SectionBase("Hello World!") # should fail
    except TypeError:
        pass
    else:
        assert False, "SectionBase instantiation must fail"
    s = Section("Hello World!", "hello", 3)
    assert s.title == "Hello World!" and s.key == "hello" and s.type == 3


# Generated at 2022-06-23 17:09:06.674513
# Unit test for constructor of class Section
def test_Section():
    section1 = Section('Parameter', 'parameter', SectionType.SINGULAR)
    section2 = Section('Parameter', 'parameter', SectionType.SINGULAR)
    section3 = Section('parameter', 'parameter', SectionType.SINGULAR)
    section4 = Section('Parameter', 'Parameter', SectionType.SINGULAR)
    section5 = Section('Parameter', 'parameter', SectionType.MULTIPLE)
    print('Unit test for constructor of class Section')
    print('The initial input of section1 is:')
    print('Parameter parameter SectionType.SINGULAR')
    print('The initial input of section2 is:')
    print('Parameter parameter SectionType.SINGULAR')
    print('The initial input of section3 is:')
    print('parameter parameter SectionType.SINGULAR')

# Generated at 2022-06-23 17:09:09.808016
# Unit test for constructor of class Section
def test_Section():
    assert Section("title", "key", SectionType.SINGULAR).title=="title"
    assert Section("title", "key", SectionType.SINGULAR).key=="key"
    assert Section("title", "key", SectionType.SINGULAR).type==SectionType.SINGULAR

# Generated at 2022-06-23 17:09:15.857323
# Unit test for function parse
def test_parse():
    test_docstring = """Example function with types documented in the docstring.

Args:
    param1 (int): The first parameter.
    param2 (str): The second parameter.

Returns:
    bool: The return value. True for success, False otherwise.
"""

    assert test_docstring == str(parse(test_docstring))


# Generated at 2022-06-23 17:09:20.797263
# Unit test for constructor of class Section
def test_Section():
    """Check if constructor for Section works correctly."""
    title = "Parameter"
    key = "param"
    type = SectionType.MULTIPLE
    param = Section(title, key, type)
    assert param.title == title
    assert param.key == key
    assert param.type == type

# Generated at 2022-06-23 17:09:26.237076
# Unit test for function parse
def test_parse():
    """Test parses docstrings in Numpy style"""
    def f(*args, **kwargs):
        """:param x: the x position"""
        pass
    doc = parse(f.__doc__)
    print(f.__doc__)
    print(doc.short_description)
    assert(doc.short_description == None)
    assert(doc.meta[0].description=='the x position')

# Generated at 2022-06-23 17:09:38.313315
# Unit test for function parse
def test_parse():
    docstring = r"""
    This is a docstring
    with a second line.

    This is a long description
    which spans multiple lines.

    Parameters
    ----------
    size : float
        The size of something.

    Returns
    -------
    float
        The size of something.
    """

    doc = parse(docstring)
    assert doc.short_description == "This is a docstring with a second line."
    assert doc.long_description == "This is a long description which spans multiple lines."
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description


# Generated at 2022-06-23 17:09:40.664932
# Unit test for constructor of class Section
def test_Section():
    from enum import IntEnum
    print(Section)
    print(SectionType)
    print(SectionType.SINGULAR)
    


# Generated at 2022-06-23 17:09:54.015363
# Unit test for function parse
def test_parse():
    class Example(object):
        """Example class.

        :param a: first argument
        :type a: str
        :param b: second argument
        :type b: bool
        :param c: third argument
        :type c: float
        :param d: fourth argument
        :type d: int

        :Example:

            >>> e = Example('a', True, 3.0, 4)
            >>> e.multiply(3)
            12

        :Raises TypeError: if argument types are not str, bool, float, int
        :Raises ValueError: if an argument is not in range
        :Raises RuntimeError: something went wrong
        :Returns: description of return value

        """

        # Using annotations

# Generated at 2022-06-23 17:10:01.940510
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Example", "example", SectionType.SINGULAR)
    ]
    googleParser = GoogleParser(sections)
    sections = [
        Section("Example", "example", SectionType.SINGULAR),
        Section("Example", "example", SectionType.SINGULAR)
    ]
    googleParser = GoogleParser(sections)
    sections = [
        Section("Example", "example", SectionType.SINGULAR),
        Section("Example", "example", SectionType.SINGULAR),
        Section("Example", "example", SectionType.SINGULAR)
    ]
    googleParser = GoogleParser(sections)

# Generated at 2022-06-23 17:10:07.323439
# Unit test for function parse
def test_parse():
    text="""
    Args:
        a (int): The first parameter.
        b (str): The second parameter. Defaults to 'b'.
        c (bool): The third parameter. Defaults to True.
    Returns:
        int: The return value.
    Raises:
        ValueError: If `a` is negative.
    """
    parsed_doc = parse(text)
    assert len(parsed_doc.meta) == 4

# Generated at 2022-06-23 17:10:18.893909
# Unit test for function parse
def test_parse():
    text = """\
    Short description of foo.

    Long description of foo.

    Args:
        a: This is argument a.
        b: This is argument b.

    Returns:
        This is the return value.
    """
    doc = parse(text)
    assert doc.short_description == "Short description of foo."
    assert doc.long_description == "Long description of foo."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.meta[0].args == ["Arguments", "a: This is argument a."]
    assert doc.meta[0].description == "This is argument a."
    assert doc.meta[1].args == ["Arguments", "b: This is argument b."]

# Generated at 2022-06-23 17:10:21.153438
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    a = GoogleParser()
    assert a != None

# Generated at 2022-06-23 17:10:32.718227
# Unit test for function parse
def test_parse():
    doc = """
        Parse the Google-style docstring into its components.

        :returns: parsed docstring

        Raises:
            ParseError: If a section is missing a colon.

        Parameters
        ----------
        text : str
            The text content of the docstring.

        Yields
        ------
        DocstringMeta
            The parsed docstring.
        """

    parsed = parse(doc)
    assert parsed.short_description == "Parse the Google-style docstring into its components."
    assert parsed.long_description == "Raises:\n    ParseError: If a section is missing a colon."
    assert parsed.blank_after_short_description and parsed.blank_after_long_description
    assert len(parsed.meta) == 3

# Generated at 2022-06-23 17:10:42.792867
# Unit test for function parse
def test_parse():
    def test_function(x):
        # Forms:
        # Args:
        #     x:

        # Args:
        #     x (int):

        # Args:
        #     x (int, optional):

        ...

    docstring = inspect.getdoc(test_function)
    print(docstring)
    assert parse(docstring).meta[0].description == "Forms:"
    assert parse(docstring).meta[0].arg_name is None
    assert parse(docstring).meta[1].arg_name == "x"
    assert parse(docstring).meta[1].type_name is None
    assert parse(docstring).meta[2].arg_name == "x"
    assert parse(docstring).meta[2].type_name == "int"

# Generated at 2022-06-23 17:10:54.039022
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    p.add_section(Section("Args", "param", SectionType.MULTIPLE))
    p.add_section(Section("Params", "param", SectionType.MULTIPLE))
    p.add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    p.add_section(Section("Exceptions", "raises", SectionType.MULTIPLE))
    p.add_section(Section("Except", "raises", SectionType.MULTIPLE))
    p.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))
    p.add_section(Section("Example", "examples", SectionType.SINGULAR))
    p.add_section(Section("Examples", "examples", SectionType.SINGULAR))
    p

# Generated at 2022-06-23 17:11:02.775545
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """\
    """
    result = parser.parse(text)
    assert result.short_description == ""
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False
    assert result.long_description == None
    assert result.meta == []
    text = """\
    Short description.

    Long description.
    """
    result = parser.parse(text)
    assert result.short_description == "Short description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.long_description == "Long description."
    assert result.meta == []
    text = """\
    Short description.

    Long description.

    """

# Generated at 2022-06-23 17:11:14.902414
# Unit test for function parse
def test_parse():
    """Test that functions parse the expected docstring."""
    def _test_parse(text: str, docstring: Docstring):
        parser = GoogleParser()
        assert parser.parse(text) == docstring

    _test_parse(
        "A function with a single returns section.",
        Docstring(
            short_description="A function with a single returns section.",
            blank_after_short_description=True,
            blank_after_long_description=False,
            meta=[
                DocstringReturns(
                    args=["returns"], description=None, type_name=None, is_generator=False
                )
            ],
        ),
    )


# Generated at 2022-06-23 17:11:18.712228
# Unit test for constructor of class Section
def test_Section():
    section = Section(title='title1', key='key1', type=0)
    assert(section.title, 'title1')
    assert(section.key, 'key1')
    assert(section.type, 0)


# Generated at 2022-06-23 17:11:25.685118
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """One line summary.

Longer description.

Args:
    x: bla bla
    y: something, optional.
    z: something else, optional.

Returns:
    something
"""
    assert str(parse(text)) == """One line summary.

Longer description.

Args:
    x: bla bla
    y: something, optional. Defaults to None.
    z: something else, optional. Defaults to None.

Returns:
    something"""


# Generated at 2022-06-23 17:11:37.759581
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = GoogleParser().parse(
        """
    This is a google style docstring
    ---------------------------------

    :param x: first parameter
    :type x: int
    :param y: second parameter
    :type y: int
    :param z: third parameter
    :type x: bool, optional

    :returns: sum of x, y, z
    :rtype: int
    """
    )
    assert docstr is not None
    assert docstr.short_description == "This is a google style docstring"
    assert len(docstr.meta) == 5

    # parameters
    assert docstr.meta[0] is not None
    assert docstr.meta[0].description == "first parameter"
    assert docstr.meta[0].args[0] == "param"
    assert docstr.meta[0].args

# Generated at 2022-06-23 17:11:41.134143
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("MySection", "my_key", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(new_section)
    assert parser.sections["MySection"] is new_section

# Generated at 2022-06-23 17:11:44.069168
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    assert parser.sections["Arguments"].key == "param"
    parser.add_section(Section("Arguments", "other", SectionType.MULTIPLE))
    assert parser.sections["Arguments"].key == "other"

# Generated at 2022-06-23 17:11:56.473394
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        :param x:
            The X coordinate.
        :param y:
            The Y coordinate.
        :param: z
            The Z coordinate.
        """

# Generated at 2022-06-23 17:12:00.902389
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    import doctest
    doctest.run_docstring_examples(obj.parse, globals())

test_GoogleParser_parse.__test__ = False # to not appear in the documentation

# Generated at 2022-06-23 17:12:12.611889
# Unit test for function parse
def test_parse():
    docstring1 = inspect.cleandoc("""\
        Args:
            a: 我是参数
        Returns:
            b: 我是返回
        """)
    docstring2 = inspect.cleandoc("""\
        Args:
        Returns:
        """)
    docstring3 = inspect.cleandoc("""\
        Args:
            a: 我是参数
            b: 我是参数2
        Returns:
            b: 我是返回
        """)

    assert parse(docstring1).meta[0].description == "我是参数"
    assert parse(docstring2).meta[0].description == None

# Generated at 2022-06-23 17:12:24.424153
# Unit test for function parse
def test_parse():
    d = """
        Function for adding two numbers.
        
        Long description with examples:
        
            example = 5
        
        Args:
          a (int): First number
          b (int): Second number

        Returns:
          int: The sum of a + b
    """
    res = parse(d)
    assert res.short_description == "Function for adding two numbers."
    assert res.long_description == "Long description with examples:\n\n    example = 5"
    assert res.blank_after_long_description
    assert res.blank_after_short_description
    assert len(res.meta) == 2
    assert res.meta[0].args == ["param", "a (int)"]
    assert res.meta[0].description == "First number"

# Generated at 2022-06-23 17:12:31.113722
# Unit test for constructor of class Section
def test_Section():
    sec1 = Section(title="test", key="test", type="test")
    assert sec1.title == "test"
    assert sec1.key == "test"
    assert sec1.type == "test"
    sec2 = Section(title = "test")
    assert sec2.title == "test"
    assert sec2.key == None
    assert sec2.type == None

# Generated at 2022-06-23 17:12:39.114976
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("").long_description is None
    # test section longer than docstring
    assert GoogleParser().parse("test").long_description is None
    assert GoogleParser().parse("test").short_description == "test"
    assert GoogleParser().parse("test").short_description == "test"
    assert GoogleParser().parse("test").blank_after_short_description is False
    assert GoogleParser().parse("test").blank_after_long_description is False
    # test section shorter than docstring
    assert GoogleParser().parse("test test").long_description == "test test"
    assert GoogleParser().parse("test test").short_description == "test"
    assert GoogleParser().parse("test test").blank_after_short_description is False
    assert GoogleParser().parse("test test").blank_after_long_description is True
    # test

# Generated at 2022-06-23 17:12:49.771140
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:12:51.428590
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser()
    assert isinstance(p, GoogleParser)


# Generated at 2022-06-23 17:13:01.398271
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:13:10.245041
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
    A google style docstring parser.

    Parameters
    ----------
    text: str
        input, the text of the docstring.
    """

    doc = parse(text)
    assert len(doc.meta) == 1
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "text"

    p = GoogleParser()
    p.add_section(Section("Args", "param", SectionType.MULTIPLE))
    doc = p.parse(text)
    assert len(doc.meta) == 1
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "text"
    assert doc.meta[0].args[1] == "text: str"

# Generated at 2022-06-23 17:13:21.906914
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    my_sections = [
        Section("Attribute", "attribute", SectionType.MULTIPLE),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
        Section("Exceptions", "raises", SectionType.MULTIPLE),
        Section("Except", "raises", SectionType.MULTIPLE),
        Section("Examples", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    gp = GoogleParser()
    for s in my_sections:
        gp.add_section(s)

# Generated at 2022-06-23 17:13:28.853008
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .google import parse
    from .common import RETURNS_KEYWORDS, RAISES_KEYWORDS
    s = parse(
        """This is a short description.

        This can have multiple lines.

        This is a long description.

        Args:
            arg1 (int): The first parameter.
            arg2 (str): The second parameter.
                The second argument.  Defaults to 'b'.
            arg3 (Optional[int]): The third parameter.

        Raises:
            ValueError: If `b` > `a`.


        A second paragraph in the long description.

        This is a paragraph that contains *inline* **markdown**.
        """
    )
    assert s.short_description == "This is a short description."

# Generated at 2022-06-23 17:13:31.735292
# Unit test for function parse
def test_parse():
    doc = """
        Parse the Google-style docstring into its components.

        :returns: parsed docstring
    """
    print(parse(doc))


# Generated at 2022-06-23 17:13:41.862889
# Unit test for function parse
def test_parse():
    # Test docstring with single section
    text = '''
        Docstring with a single section.

        Params:
            a: Param one
            b: Param two. Defaults to "1".
    '''

    s = GoogleParser().parse(text)
    assert s.short_description == "Docstring with a single section."
    assert s.long_description is None
    assert len(s.meta) == 2
    p0 = s.meta[0]
    p1 = s.meta[1]
    assert isinstance(p0, DocstringParam)
    assert isinstance(p1, DocstringParam)
    assert p0.arg_name == "a"
    assert p0.type_name is None
    assert p0.is_optional is None
    assert p0.default is None
    assert p0.description

# Generated at 2022-06-23 17:13:53.932686
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import unittest

# Generated at 2022-06-23 17:13:59.759284
# Unit test for constructor of class Section
def test_Section():
    section = Section("Title", "key", SectionType.MULTIPLE)
    assert section.__class__.__name__ == "Section"
    assert section.__doc__ == "A docstring section."
    assert section.title == "Title"
    assert section.key == "key"
    assert section.type == 1


# Generated at 2022-06-23 17:14:03.498590
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    test_section = Section('test_title', 'test_key', SectionType.SINGULAR)
    gp = GoogleParser()
    gp.add_section(test_section)
    assert(gp.sections['test_title'] == test_section)

# Generated at 2022-06-23 17:14:12.419385
# Unit test for function parse
def test_parse():
    text = """Converts a tensor from a TensorFlow ExponentialLinearUnit (ELU) to a PyTorch ELU.

    Args:
        tensor: A tensor of shape (B, ...)
        alpha: A float which carries the extra information about the ELU activation.

    Returns:
        A tensor with the same shape as the input tensor.
    """
    d = parse(text)
    assert not d.short_description
    assert d.long_description.strip() == "Converts a tensor from a TensorFlow ExponentialLinearUnit (ELU) to a PyTorch ELU."

# Generated at 2022-06-23 17:14:25.370780
# Unit test for function parse
def test_parse():
    assert GoogleParser().parse("") == Docstring()

    # Test short description only
    output = Docstring(
        short_description="A test docstring.",
    )
    assert GoogleParser().parse("A test docstring.") == output

    # Test short description and long description
    output = Docstring(
        short_description="A test docstring.",
        long_description="This is a test docstring. It is multiline.",
    )
    assert GoogleParser().parse("A test docstring.\n\nThis is a test docstring. It is multiline.") == output
    assert GoogleParser().parse("A test docstring.\n\nThis is a test docstring. It is multiline.") == output

    # Test short description, long description, and examples

# Generated at 2022-06-23 17:14:29.546916
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert list(GoogleParser().sections.keys()) == DEFAULT_SECTIONS
    assert list(GoogleParser(title_colon=False).sections.keys()) == DEFAULT_SECTIONS
    assert list(GoogleParser(sections=[Section('A', 'a', SectionType.SINGULAR)]).sections.keys()) == ['A']


# Generated at 2022-06-23 17:14:41.520341
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test = GoogleParser()

# Generated at 2022-06-23 17:14:48.726747
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("Keywords", "keywords", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(new_section)
    # Now it should be able to handle the new section
    docstring = Docstring()
    docstring.meta.append(DocstringMeta(args=["keywords", "int"], description="Integers"))
    docstring.meta.append(DocstringMeta(args=["keywords", "float"], description="Floats"))
    assert parser.parse("Keywords:\n    int: Integers\n    float: Floats") == docstring

# Generated at 2022-06-23 17:14:59.333322
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    Unit test for method add_section of class GoogleParser
    """
    # Case 1: default test
    google_parser = GoogleParser()
    section = Section("Attributes", "attribute", SectionType.MULTIPLE)
    assert section.title == "Attributes"
    assert section.type == SectionType.MULTIPLE
    assert section.key == "attribute"
    google_parser.add_section(section)
    assert google_parser.sections["Attributes"] == section
    assert google_parser.sections["Attributes"] != DEFAULT_SECTIONS[-2]
    
    # Case 2: replace existing section
    google_parser = GoogleParser()
    section = Section("Attributes", "attribute", SectionType.SINGULAR)
    assert section.title == "Attributes"
    assert section.type == SectionType.SINGULAR

# Generated at 2022-06-23 17:15:07.970588
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr1 = "This is a test \nThis is a test 2"
    docstr2 = "This is a test \n\nThis is a test 2"
    docstr3 = "This is a test \n\n\nThis is a test 2"
    d = GoogleParser()
    assert d.parse(docstr1).short_description == "This is a test"
    assert d.parse(docstr1).long_description == "This is a test 2"
    assert d.parse(docstr2).short_description == "This is a test"
    assert d.parse(docstr2).long_description == "This is a test 2"
    assert d.parse(docstr3).short_description == "This is a test"
    assert d.parse(docstr3).long_description == "This is a test 2"


# Generated at 2022-06-23 17:15:20.812304
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """Here is a description.

Attributes
----------
aaa: aaa.
"""
    sections = []
    sections.append(Section("Attributes", "attribute", SectionType.MULTIPLE))
    parser = GoogleParser(sections)
    sections = parser.sections
    parser._setup()
    parser.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))
    assert parser.sections == sections
    sections.append(Section("Attributes", "attribute", SectionType.MULTIPLE))
    parser.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))
    assert parser.sections != sections
    test_parser = GoogleParser(sections)
    output = test_parser.parse(text)
    assert output.meta[0].section == "attribute"

# Generated at 2022-06-23 17:15:27.826879
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Persona", "persona", SectionType.MULTIPLE))
    assert gp.sections["Persona"] == Section("Persona", "persona", SectionType.MULTIPLE)

    gp.add_section(Section("Pais", "pais", SectionType.SINGULAR))
    assert gp.sections["Pais"] == Section("Pais", "pais", SectionType.SINGULAR)

    gp.add_section(Section("Raza", "raza", SectionType.SINGULAR_OR_MULTIPLE))
    assert gp.sections["Raza"] == Section("Raza", "raza", SectionType.SINGULAR_OR_MULTIPLE)


# Generated at 2022-06-23 17:15:40.917107
# Unit test for constructor of class Section
def test_Section():
    # Case 1: Case normal
    assert Section("Arguments", "param", SectionType.MULTIPLE) is not None

    # Case 2: Case normal
    assert Section("Args", "param", SectionType.MULTIPLE) is not None

    # Case 3: Case normal
    assert Section("Parameters", "param", SectionType.MULTIPLE) is not None

    # Case 4: Case normal
    assert Section("Params", "param", SectionType.MULTIPLE) is not None

    # Case 5: Case normal
    assert Section("Raises", "raises", SectionType.MULTIPLE) is not None

    # Case 6: Case normal
    assert Section("Exceptions", "raises", SectionType.MULTIPLE) is not None

    # Case 7: Case normal

# Generated at 2022-06-23 17:15:53.029213
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    assert parser.sections["Arguments"].title == "Arguments"
    assert parser.sections["Arguments"].key == "param"
    assert parser.sections["Arguments"].type == SectionType.MULTIPLE

    parser.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    assert parser.sections["Arguments"].title == "Arguments"
    assert parser.sections["Arguments"].key == "param"
    assert parser.sections["Arguments"].type == SectionType.MULTIPLE

    parser.add_section(Section("Arguments", "param", SectionType.SINGULAR_OR_MULTIPLE))