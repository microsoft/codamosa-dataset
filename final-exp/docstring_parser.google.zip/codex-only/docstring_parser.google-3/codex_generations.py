

# Generated at 2022-06-23 17:06:00.987033
# Unit test for function parse
def test_parse():
    docstring = """
    Parse the Google-style docstring into its components.

    Args:
        text (str): Docstring text to parse.

    Returns:
        Parsed docstring (instance of :py:class:`gordo.docstring.Docstring`)

    Raises:
        ParseError: If docstring can't be parsed.
    """
    parsed = parse(docstring)
    print(parsed)
    print(parsed.short_description)
    print(parsed.long_description)

    print(parsed.param_list)
    print(parsed.returns)
    print(parsed.raises)

test_parse()

# Generated at 2022-06-23 17:06:03.732423
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:06:16.105182
# Unit test for function parse
def test_parse():
    text = """
One line summary.

    One line extended description.
    
    Args:
        arg1 (int): Description of arg1
        arg2 (str, optional): Description of arg2. Defaults to 'default'.
    
    Returns:
        str: Description of return value.
    """
    p = GoogleParser()
    doc = p.parse(text)
    assert doc.short_description == "One line summary."
    assert len(doc.meta) == 3
    assert doc.meta[0].args[0] == 'One line extended description.'
    assert doc.meta[1].args[0] == 'param'
    assert doc.meta[1].args[1] == 'arg1 (int)'
    assert doc.meta[1].arg_name == 'arg1'
    assert doc.meta[1].type_

# Generated at 2022-06-23 17:06:29.145652
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """This function does something.

Args:
    a_param (str): A parameter.
    another_param (int): Another parameter.

Returns:
    str: something

Raises:
    ValueError : If something goes wrong.
"""
    doc = parser.parse(docstring)

    assert doc.short_description == "This function does something."
    assert doc.long_description == "Args:\n    a_param (str): A parameter.\n    another_param (int): Another parameter."
    assert doc.meta[0].args[0] == "param"
    assert doc.meta[0].args[1] == "a_param (str)"
    assert doc.meta[1].args[0] == "param"

# Generated at 2022-06-23 17:06:34.453063
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("Notes", "notes", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(new_section)
    assert parser.sections["Notes"] == new_section
    assert parser.titles_re.search("Notes:") is not None



# Generated at 2022-06-23 17:06:42.988227
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser(title_colon=False).title_colon == False
    assert GoogleParser(title_colon=True).title_colon == True
    assert GoogleParser().title_colon == True
    assert GoogleParser().sections['Arguments'] == Section('Arguments','param',SectionType.MULTIPLE)
    assert GoogleParser().sections['Args'] == Section('Args','param',SectionType.MULTIPLE)
    assert GoogleParser().sections['Parameters'] == Section('Parameters','param',SectionType.MULTIPLE)
    assert GoogleParser().sections['Params'] == Section('Params','param',SectionType.MULTIPLE)
    assert GoogleParser().sections['Raises'] == Section('Raises','raises',SectionType.MULTIPLE)

# Generated at 2022-06-23 17:06:48.802634
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE).title == "Arguments"
    assert Section("Args", "param", SectionType.MULTIPLE).key == "param"
    assert Section("Parameters", "param", SectionType.MULTIPLE).type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:06:51.813067
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE

# Generated at 2022-06-23 17:07:01.629078
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    gp = GoogleParser(sections)
    assert gp.title_colon == True

# Generated at 2022-06-23 17:07:09.000654
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_test = """Google-style docstring parsing.
    
    Parse the Google-style docstring into its components.
    
    :param sections: Recognized sections or None to defaults.
    :param title_colon: require colon after section title.
    :param test: test
    """
    doc = GoogleParser().parse(str_test)
    assert doc.short_description == "Google-style docstring parsing."
    assert doc.long_description == "Parse the Google-style docstring into its components."
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == True

    param_list = [x for x in doc.meta if x.key == "param"]

    assert param_list[0].args == ['param', 'sections']
    assert param_list[0].arg

# Generated at 2022-06-23 17:07:14.884293
# Unit test for function parse
def test_parse():
    text = """
    Test function to test parsing Google-style docstrings.

    More details.

    Another paragraph.

    Args:
        argument1 (str): some string.
        argument2 (int): some int. Defaults to 6.

    Kwargs:
        keyword1 (bool): some bool. Defaults to True.

    Examples:
        Some example.

    Another example.

    Returns:
        str: some description of return.
    """

# Generated at 2022-06-23 17:07:20.142685
# Unit test for function parse
def test_parse():
    retStr = '''This is for testing.

:param a: Desc of a.
:type a: int

:returns: Desc of returns.
:rtype: int
'''
    ret = parse(retStr)
    print(ret.meta)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:07:29.300840
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    # Test with one title
    test_sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
        Section("Params", "param", SectionType.MULTIPLE),
    ]
    test_parser = GoogleParser(sections=test_sections)

    test_title = "Returns"
    test_section = Section(test_title, "returns", SectionType.SINGULAR)
    test_parser.add_section(test_section)

# Generated at 2022-06-23 17:07:34.515430
# Unit test for function parse
def test_parse():
    text = """
Arguments:
    name: The name that should be found in the database.
    age: Age of the person to search for.

Returns:
    Person: The person, if it can be found.

Raises:
    NotFound: If the person is not present in the database.
    ConnectionError: If unable to connect to the database.
    """
    res = parse(text)
    assert str(res) == text

# Generated at 2022-06-23 17:07:42.265476
# Unit test for function parse
def test_parse():
    assert parse("").meta == []
    assert parse("Test docstring").meta == [
        DocstringMeta(args=["short_description"], description="Test docstring")
    ]
    assert parse(
        """
        Test docstring

        Meaningless line.
        """
    ).meta == [
        DocstringMeta(
            args=["short_description"], description="Test docstring"
        ),
        DocstringMeta(
            args=["long_description"], description="Meaningless line."
        ),
    ]

# Generated at 2022-06-23 17:07:50.331772
# Unit test for constructor of class GoogleParser
def test_GoogleParser():

    # GoogleParser(sections = ..., title_colon = ...)
    #
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE)
    ]
    title_colon = True
    #
    google_sections = GoogleParser(
        sections=sections, title_colon=title_colon
    )
    assert google_sections.sections["Arguments"].title == "Arguments"
    assert google_sections.sections["Arguments"].key == "param"
    assert google_sections.sections["Arguments"].type == SectionType.MULTIPLE
    assert google_sections.titles_re.pattern == "^(Arguments):[ \t\r\f\v]*$"

    # GoogleParser(title_colon = ...)
    #
    title_colon = False

# Generated at 2022-06-23 17:07:58.667948
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Fish", "fish", SectionType.SINGULAR_OR_MULTIPLE))
    expected_titles_re = re.compile(
        '^('
        + '|'.join('(%s)' % t for t in ['Fish'])
        + ')'
        + ':'
        + '[ \t\r\f\v]*$',
        flags=re.M,
    )
    assert parser.titles_re == expected_titles_re

# Generated at 2022-06-23 17:08:06.190108
# Unit test for function parse
def test_parse():
    assert parse("This is a way to test the parse function")
    assert parse('This is a way to test the parse function\n\ndetails:\n\nthis is a detail')
    assert parse('This is a way to test the parse function\n\nthis is a detail')
    assert parse('This is a way to test the parse function\n\nthis is a detail')
    assert parse('\nThis is a way to test the parse function\n\nthis is a detail')
    assert parse('\nThis is a way to test the parse function\n\nthis is a detail')


# Generated at 2022-06-23 17:08:12.669595
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    g.add_section(Section("test", "test", SectionType.SINGULAR))
    print(inspect.getsourcelines(g.parse))
    assert g.parse("test: test") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=["test"], description="test")],
    )

    g.add_section(
        Section("new_test", "new_test", SectionType.SINGULAR_OR_MULTIPLE)
    )
    print(inspect.getsourcelines(g.parse))

# Generated at 2022-06-23 17:08:14.395192
# Unit test for constructor of class Section
def test_Section():
    section = Section("Param", "param", SectionType.MULTIPLE)
    assert section.title == "Param"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:08:20.217677
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    w = GoogleParser()
    w.add_section(Section("Up", "up", SectionType.MULTIPLE))
    x = GoogleParser()
    x.add_section(Section("Down", "down", SectionType.MULTIPLE))
    assert w.sections != x.sections



# Generated at 2022-06-23 17:08:27.723916
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    gp = GoogleParser()

    # Test case where a new title is added
    new_section = Section("Test1", "test1", SectionType.SINGULAR)
    gp.add_section(new_section)
    assert gp.sections["Test1"] == new_section

    # Test case where a title is replaced
    new_section = Section("Example", "test2", SectionType.SINGULAR)
    gp.add_section(new_section)
    assert gp.sections["Example"] == new_section

    return

# Generated at 2022-06-23 17:08:35.436651
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
            """
    text_cleaned = inspect.cleandoc(text)  # noqa: S305
    parser = GoogleParser()
    docString = parser.parse(text)
    assert docString.short_description == None
    assert docString.long_description == None
    assert docString.meta == []
    assert docString.blank_after_short_description == False
    assert docString.blank_after_long_description == False


# Generated at 2022-06-23 17:08:39.052471
# Unit test for constructor of class Section
def test_Section():
	# Example given in the class definition
	section = Section('Title', 'Key', 0)
	assert section.title == 'Title'
	assert section.key == 'Key'
	assert section.type == 0


# Generated at 2022-06-23 17:08:50.124430
# Unit test for function parse
def test_parse():
    parse("")
    d = parse("Not Google-style.")

    p = parse("""
        Short desc.

        Long desc.
    """)
    assert p.short_description == "Short desc."
    assert p.long_description == "Long desc."

    p = parse("""
        Short desc.

        Long desc.

        Returns:
            Something
    """)
    assert p.short_description == "Short desc."
    assert p.long_description == "Long desc."
    assert p.meta[0].description == "Something"

    p = parse("""
        Short desc.

        Long desc.

        Returns:
            Something:
                Longer
    """)
    assert p.short_description == "Short desc."
    assert p.long_description == "Long desc."
    assert p.meta[0].description

# Generated at 2022-06-23 17:08:55.324406
# Unit test for function parse
def test_parse():
    """Test the parse method"""
    input_string = \
    """This is the brief description.
    
    Args:
        arg1: The first argument.
        arg2: The second argument.
        
        This description should be associated with the second argument.
        This line is good.
        
        This line is bad.
    """
    docstring = parse(input_string)
    return docstring



# Generated at 2022-06-23 17:08:58.038608
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert isinstance(gp, GoogleParser)
    assert gp.title_colon == True


# Generated at 2022-06-23 17:09:09.729073
# Unit test for function parse
def test_parse():
    text = """A function.

    Args:
        item (str): The item to use.
        count (int): The count of items to use.

    Returns:
        The result of the function.

    Raises:
        KeyError: If the key is not present.
    """
    docstring = parse(text)
    assert docstring.short_description == "A function."
    assert docstring.long_description is None

# Generated at 2022-06-23 17:09:14.246023
# Unit test for constructor of class Section
def test_Section():
    sections = Section("Arguments", "param", SectionType.MULTIPLE)
    assert sections.title == "Arguments"
    assert sections.key == "param"
    assert sections.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:09:25.744393
# Unit test for function parse
def test_parse():
    p = GoogleParser()
    docstring = """This is the top line.

This is a longer description.

Args:
    arg1 (int): Arg1.
    arg2 (str): Arg2.
        Defaults to 'hello'.
    arg3 (Optional[str]): Arg3.
    arg4 (List[str]): Arg4.
    arg5 (str, optional): Arg5.
    arg6 (str?): Arg6.

Returns:
    int: An int.

Raises:
    ValueError: If something raises this.

"""

# Generated at 2022-06-23 17:09:36.885752
# Unit test for constructor of class Section
def test_Section():
    # Create a section and test its first fields
    sec1 = Section(title = 'Section Title', key = 'Section Key', type = SectionType.MULTIPLE)
    print(sec1)
    # Create a section and test its first fields
    sec2 = Section(title = 'Section Title Default', key = 'Section Key Default', type = SectionType.SINGULAR_OR_MULTIPLE)
    print(sec2)
    print(sec2._fields)
    # Create a section and test its first fields
    sec3 = Section(title = 'Section Title Singular', key = 'Section Key Singular', type = SectionType.SINGULAR)
    print(sec3)
    print(sec3._fields)


# Generated at 2022-06-23 17:09:44.222145
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("toto", "titi", SectionType.SINGULAR)
    parser.add_section(new_section)
    assert parser.titles_re.search("toto:") != None
    new_section = Section("tutu", "titi", SectionType.SINGULAR)
    parser.add_section(new_section)
    assert parser.titles_re.search("tuto:") != None
    new_section = Section("titi", "titi", SectionType.SINGULAR)
    try:
        parser.add_section(new_section)
        assert(False)
    except ValueError:
        pass

if __name__ == "__main__":
    test_GoogleParser_add_section()

# Generated at 2022-06-23 17:09:48.065323
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    a = GoogleParser()
    assert str(a) == "<__main__.GoogleParser object at 0x0000028E09D8BAC8>"



# Generated at 2022-06-23 17:09:58.691290
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().sections == DEFAULT_SECTIONS
    sections = [
        Section("blah", "param", SectionType.MULTIPLE),
        Section("blah", "blah", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    assert GoogleParser(sections).sections == dict(
        [
            ("blah", sections[0]),
            ("blah", sections[1]),
        ]
    )
    sections = [
        Section("blah", "param", SectionType.MULTIPLE),
        Section("boo", "boo", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    assert GoogleParser(sections).sections == dict(
        [
            ("blah", sections[0]),
            ("boo", sections[1]),
        ]
    )
   

# Generated at 2022-06-23 17:10:05.471271
# Unit test for constructor of class Section
def test_Section():
    """
    单元测试
    :return: 单元测试结果
    """
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE



# Generated at 2022-06-23 17:10:06.696025
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert isinstance(GoogleParser(), GoogleParser)


# Generated at 2022-06-23 17:10:17.985790
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Case 1: default settings
    gp = GoogleParser()

# Generated at 2022-06-23 17:10:31.076837
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse("""
    This is a summary.

    This is an extended description.

    Parameters:
        a (str): The first parameter.
        b (str): The second parameter. This can be long.
        c (str): Optional.
        d (str): No default.

    Raises:
        ValueError: If something goes wrong.

    Returns:
        str: The return value.
    """)


# Generated at 2022-06-23 17:10:41.889693
# Unit test for function parse
def test_parse():
    docstring = parse("""
    hello, world
    Return a friendly greeting.

    Args:
        name (str): The name of the person to greet.

    Returns:
        str: A greeting for the person.

    Raises:
        ValueError: If the person provided is not valid.
    """)
    assert docstring.short_description == "hello, world"
    assert docstring.long_description == "Return a friendly greeting."
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "name (str)"]
    assert docstring.meta[0].is_optional is False
    assert docstring.meta[0].arg_name == "name"
    assert docstring.meta[0].type_name == "str"

# Generated at 2022-06-23 17:10:48.296212
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    docstring = "hello world, I'm a docstring!"
    google_parser = GoogleParser()
    new_section = Section("NewSection", "new_section", SectionType.SINGULAR_OR_MULTIPLE)
    google_parser.add_section(new_section)
    assert "NewSection" in google_parser.sections


# Generated at 2022-06-23 17:10:51.812404
# Unit test for constructor of class Section
def test_Section():
    s = Section("Example", "examples", SectionType.SINGULAR)
    assert s.title == "Example"
    assert s.key == "examples"
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:10:59.895788
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("Title A", "a", SectionType.SINGULAR), Section("Title B", "b", SectionType.SINGULAR_OR_MULTIPLE), Section("Title C", "c", SectionType.MULTIPLE)]
    parser = GoogleParser(sections, True)

    assert len(parser.sections) == 3
    assert parser.sections["Title A"] == Section("Title A", "a", SectionType.SINGULAR)
    assert parser.sections["Title B"] == Section("Title B", "b", SectionType.SINGULAR_OR_MULTIPLE)
    assert parser.sections["Title C"] == Section("Title C", "c", SectionType.MULTIPLE)

# Generated at 2022-06-23 17:11:12.890754
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """ Unit test for method parse of class GoogleParser. """
    # Short description
    doc = GoogleParser().parse("Short description.")
    assert doc.short_description == "Short description."

    # Short description with no trailing new line
    doc = GoogleParser().parse("Short description")
    assert doc.short_description == "Short description"

    # Long description
    doc = GoogleParser().parse("Short description.\n\nLong description.")
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    # Long description with no trailing new line
    doc = GoogleParser().parse("Short description.\n\nLong description")
    assert doc.long_description == "Long description"
    assert doc.blank_after_short_description

# Generated at 2022-06-23 17:11:20.488979
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    print("Start test_GoogleParser_add_section()")
    parser = GoogleParser()
    google_parser_sections_list = parser.sections
    print(google_parser_sections_list)
    section = Section("Section", "section", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(section)
    new_sections = parser.sections
    print(new_sections)
    assert len(new_sections) == (len(google_parser_sections_list) + 1)
    assert new_sections.get("Section") == section


# Generated at 2022-06-23 17:11:22.423266
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert len(DEFAULT_SECTIONS) == 17
    gp = GoogleParser(DEFAULT_SECTIONS, True)
    assert len(gp.sections) == 17



# Generated at 2022-06-23 17:11:27.506214
# Unit test for constructor of class Section
def test_Section():
    Section1 = Section("Arguments", "param", SectionType.MULTIPLE)
    assert Section1.title == 'Arguments'
    assert Section1.key == 'param'
    assert Section1.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:11:32.778818
# Unit test for constructor of class Section
def test_Section():
    # Verify Section
    title = "abc"
    key = "abc"
    type = SectionType.SINGULAR
    section = Section(title, key, type)
    assert section.title == title
    assert section.key == key
    assert section.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:11:38.402539
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    title = "New Title"
    section = Section(title, "new", SectionType.MULTIPLE)
    chk = GoogleParser()
    assert title not in chk.sections
    chk.add_section(section)
    assert title in chk.sections
    chk.add_section(section)
    assert title in chk.sections


# Generated at 2022-06-23 17:11:47.463909
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
        This is a Google-style docstring.

        It has a short description, a long description, and return metadata.
        It has indented example snippets, arguments, and returns. It also has
        a section for exceptions. If a parameter has a default value, the
        default should be listed in the argument.

        Args:
            arg1 (int): Description of `arg1`.
            arg2 (str, optional): Description of `arg2`. Defaults to 'foo'.
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.

        Raises:
            ValueError: Raises an exception.

        Returns:
            bool: True if successful, False otherwise.
    """
    result = parser.parse(docstring)
    result_str = Docstring.__repr__

# Generated at 2022-06-23 17:11:55.957525
# Unit test for constructor of class Section
def test_Section():
    title = "Title"
    key = "key"
    type = SectionType.SINGULAR
    sec = Section(title, key, type)
    if title != sec.title:
        print("Title: %s != %s" % (title, sec.title))
    if key != sec.key:
        print("key: %s != %s" % (key, sec.key))
    if type != sec.type:
        print("type: %s != %s" % (type, sec.type))


# Generated at 2022-06-23 17:11:58.523829
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        """
    doc = GoogleParser().parse(text)
    print(doc)
    print(doc.meta)

# Generated at 2022-06-23 17:12:03.585314
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    # Add section
    g.add_section(Section("New", "new", SectionType.SINGULAR))
    # Replace section
    g.add_section(Section("Args", "new_args", SectionType.SINGULAR))


# Generated at 2022-06-23 17:12:13.568987
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test_1 = GoogleParser()
    assert re.search("^(Example|Examples):[ \t\r\f\v]*$",test_1.titles_re.pattern)
    assert not re.search("^(Example|Examples|Raises):[ \t\r\f\v]*$",test_1.titles_re.pattern)
    assert re.search("^(Raises):[ \t\r\f\v]*$",GoogleParser(title_colon=False).titles_re.pattern)
    assert not re.search("^(Raises):[ \t\r\f\v]*$",GoogleParser(title_colon=True).titles_re.pattern)

# Generated at 2022-06-23 17:12:14.650393
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    pass



# Generated at 2022-06-23 17:12:25.981585
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    #Test case 1: Create an object of class GoogleParser
    parser = GoogleParser()
    #Test case 2: Add a section on the object of class GoogleParser
    section = Section("New Section", "new_section", SectionType.SINGULAR)
    parser.add_section(section)
    #Test case 3: Add a section on the object of class GoogleParser
    section = Section("Section", "section", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(section)
    #Test case 4: Create an object of class GoogleParser with specified sections
    custom_sections = [section]
    parser = GoogleParser(custom_sections)
    #Test case 5: Add a section on the object of class GoogleParser
    section = Section("New Section", "new_section", SectionType.SINGULAR)

# Generated at 2022-06-23 17:12:29.500603
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """Test for GoogleParser constructor."""
    assert GoogleParser().sections == GoogleParser(sections=None).sections
    assert GoogleParser(title_colon=False).title_colon == False

# Generated at 2022-06-23 17:12:31.475609
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert type(gp) == GoogleParser


# Generated at 2022-06-23 17:12:32.915833
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = GoogleParser()
    assert doc.parse("") ==""


# Generated at 2022-06-23 17:12:45.629516
# Unit test for function parse
def test_parse():

    def foo(a=1, b=2, c=3):
        """Sum values.

        :param a: Value 1.
        :param b: Value 2.
        :param c: Value 3.
        :type a: int, optional
        :type b: int, optional
        :type c: int, optional
        :returns: sum result.
        :rtype: int
        :raises TypeError: if any value type isn't int
        :Example:
            >>> print(foo(1, 2, 3))
            6
        """
        pass  # pragma: no cover

    docstring = parse(inspect.getdoc(foo))
    assert docstring.short_description == "Sum values."
    assert docstring.blank_after_short_description is True
    assert docstring.long_description is None

# Generated at 2022-06-23 17:12:48.916805
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert isinstance(GoogleParser().parse(""), Docstring)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:12:53.893975
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()
    if sections:
        GoogleParser(sections)
    else:
        GoogleParser(sections=[Section("Arguments", "param", SectionType.MULTIPLE)])
    GoogleParser(title_colon=True)
    GoogleParser(sections, False)


# Generated at 2022-06-23 17:12:55.726918
# Unit test for constructor of class Section
def test_Section():
    m = Section("Arguments", "param", "multiple")
    print(m)


# Generated at 2022-06-23 17:13:06.630453
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:13:14.570056
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_text_1 = [
        """
    A short description of the FOOBAR.

    Args:
        one: the first argument
        two: the second argument
        three (None): the third argument

    Returns:
        True if len(args) == 0: False if not

    Raises:
        AttributeError: The ``FOOBAR`` object has no ``args`` attribute.
    """,
        None,
    ]
    test_text_2 = [
        """
    A short description of the FOOBAR.

    Args:
        one: the first argument
        two: the second argument
        three (None): the third argument
    """,
        None,
    ]


# Generated at 2022-06-23 17:13:20.053299
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    entry = Section("Arguments", "param", SectionType.MULTIPLE)
    parser = GoogleParser()
    parser.add_section(entry)
    sections = parser.sections
    assert len(sections) == 1
    assert "Arguments" in sections
    assert sections["Arguments"] == entry


# Generated at 2022-06-23 17:13:24.229295
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    docString = GoogleParser()
    newSection = Section("Description", "desc", SectionType.MULTIPLE)
    docString.add_section(newSection)
    assert "Description" in docString.title_colon


# Generated at 2022-06-23 17:13:37.021461
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:13:44.717565
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = '''
    Google-style docstring
    ----------------------
    First line is short description, until a blank line.
    It should be brief, which is why it is restricted to a single line.
    If it spans more than one line, it will be considered as part of
    the long description. The same applies to the last paragraph.
    Second line is the long description. The description may have
    as many lines as you like.

    Arguments
    ---------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.
    arg3, optional
        The third argument. Defaults to None.
        And this is a long description.
        Second line of long description.

    Returns
    -------
    int
        The return value.
    '''

    docstring = GoogleParser().parse(doc)

# Generated at 2022-06-23 17:13:48.703186
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert gp.sections == DEFAULT_SECTIONS
    assert gp.title_colon
    assert gp.titles_re
    assert gp.titles_re.pattern == (
        '^(|'
        '(Arguments)|'
        '(Args)|'
        '(Parameters)|'
        '(Params)|'
        '(Raises)|'
        '(Exceptions)|'
        '(Except)|'
        '(Attributes)|'
        '(Example)|'
        '(Examples)|'
        '(Returns)|'
        '(Yields)'
        '):[ \\t\\r\\f\\v]*$'
    )

# Generated at 2022-06-23 17:13:59.721079
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test method add_section for class GoogleParser"""
    # Setup of test
    google_parser = GoogleParser()
    section_1 = Section("SECTION_1", "key 1", SectionType.SINGULAR)
    section_2 = Section("SECTION_2", "key 2", SectionType.SINGULAR_OR_MULTIPLE)
    section_3 = Section("SECTION_3", "key 3", SectionType.MULTIPLE)
    # Exercise method add_section
    google_parser.add_section(section_1)
    google_parser.add_section(section_2)
    google_parser.add_section(section_3)
    # Check results

# Generated at 2022-06-23 17:14:09.797026
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:14:14.441175
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    result = parser.add_section(Section(title='UnitTest1', key='unitTest1', type=SectionType.SINGULAR))

    if result == 0:
        print('Passed')
    else:
        print('Failed')


# Generated at 2022-06-23 17:14:20.964884
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit tests for GoogleParser_parse."""
    doc_string = """Returns True if the object argument appears callable, False if not.
        If this returns true, it is still possible that a call fails, but if
        it is false, calling object will never succeed."""

# Generated at 2022-06-23 17:14:31.112188
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = """Summary line.

    Extended description of function.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
    Raises:
        ValueError: When arg2 is not provided.

    """
    out = GoogleParser().parse(docstr)
    assert isinstance(out, Docstring)
    assert out.short_description == 'Summary line.'
    assert out.long_description == 'Extended description of function.'
    assert out.blank_after_long_description == True
    assert out.blank_after_short_description == False
    assert isinstance(out.meta, list)
    assert len(out.meta) == 2
    assert out.meta[0].args == ('param', 'arg1 (int)')

# Generated at 2022-06-23 17:14:32.676763
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print(GoogleParser().parse("""
    a
    """))

# Generated at 2022-06-23 17:14:45.692977
# Unit test for function parse
def test_parse():
    def function():
        """
        This function does something.

        Args:
            arg1: The first argument.
            arg2 (str): The second argument.

        Example:
            Examples can be given using either the ``Example`` or ``Examples``
            sections. Sections support any reStructuredText formatting, including
            literal blocks::

                $ python example_google.py

        Parameters
            ----------
            param1 : int
                The first parameter.
            param2 : str
                The second parameter.

        Returns
            -------
            bool
                True if successful, False otherwise.

        """

    d = parse(inspect.cleandoc(function.__doc__))
    assert d.short_description == "This function does something."

# Generated at 2022-06-23 17:14:57.584168
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class C:
        """Groups parameters of the same type together and adds quotes """


    class D:
        """Example of google style"""


    class E:
        """
        Args:
            arg1: bla bla
            arg2: bla bla
        """


    class F:
        """
        Args:
            arg1: bla bla
            arg1: bla bla
        """


    class G:
        """
        Args:
            arg1: bla bla
        Args:
            arg1: bla bla
        """


    class H:
        """
        Args:
            arg1 (int): bla bla
            arg2 (int): bla bla
        """



# Generated at 2022-06-23 17:15:07.146337
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:15:19.807719
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    TP = Docstring
    TA = DocstringParam
    TB = DocstringReturns
    TC = DocstringRaises
    TD = DocstringMeta
    import pprint
    print("test_GoogleParser_parse")
    
    # Test 1
    text = """This is a long description.
    This is a long description.
    This is a long description.

    Args:
        arg1 (str): This is a long description.
            This is a long description.
        arg2 (str): This is a long description.
            This is a long description.

    """
    parser = GoogleParser()
    actual = parser.parse(text)

# Generated at 2022-06-23 17:15:27.926429
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Default setup
    a = GoogleParser()
    # The above code ends without any errors because it is the default setup
    # Invalid Sections
    try:
        b = GoogleParser(sections="Invalid")
    except TypeError:
        print("GoogleParser constructor can detect invalid sections")
    try:
        c = GoogleParser(sections=None)
    except TypeError:
        print("GoogleParser constructor can detect invalid sections")
    # Valid Sections
    d = GoogleParser(sections=[Section("Arguments", "param", SectionType.MULTIPLE)])
    if d.sections.get("Arguments"):
        print("GoogleParser constructor can handle valid Sections")
    # Invalid title_colon

# Generated at 2022-06-23 17:15:29.675156
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    pass


# Generated at 2022-06-23 17:15:41.790592
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        This is a regular summary.
    
        This is the long description.
    
        Args:
            param1(str): This is the first parameter.
            param2(int): This is a second parameter.
            optionalParam1(:obj:`int`): This is an optional parameter.
            optionalParam2(int, optional): This is an alternative optional parameter.
            optionalParam3(int?, optional): This is another optional parameter.
    
        Returns:
            bool: This is a description of the return value.
    
        Raises:
            AttributeError, KeyError: The exception(s) raised.
        
        Examples:
            Examples should be written in doctest format, and should illustrate how
            to use the function.
    """

# Generated at 2022-06-23 17:15:47.379988
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:15:59.477689
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()

    text = '''
    Google-Style Docstring
    ----------------------

    :param param1: The first parameter.
    :param param2: The second parameter.
    :returns: Description of return value.
    :raises keyError: The exception description.

    Example:
        Examples can be given using either the ``Example`` or ``Examples``
        sections. Sections support any reStructuredText formatting, including
        literal blocks::

            $ python ex.py

        The ``Examples`` section of the docstring goes here.
        >>> print()
        >>> print()

    '''

    parser = GoogleParser()
    docstring = parser.parse(text)

    assert len(docstring.meta) == 5
    assert docstring.short_description == 'Google-Style Docstring'