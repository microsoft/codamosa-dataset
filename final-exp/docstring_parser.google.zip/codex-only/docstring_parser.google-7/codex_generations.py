

# Generated at 2022-06-23 17:06:02.798769
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Summary line.

    Extended description.

    Args:
        arg1 (int): Description of `arg1`.
        arg2 (:obj:`list` of :obj:`str`): Description of `arg2`

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

    """
    docstring = GoogleParser().parse(text)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta[0].keyword)
    print(docstring.meta[0].arg_name)
    print(docstring.meta[0].description)
    print(docstring.meta[1].keyword)
    print(docstring.meta[1].arg_name)

# Generated at 2022-06-23 17:06:15.492513
# Unit test for function parse
def test_parse():
    """Test for function parse."""

    def test(text, expected):
        """Test for docstring parsing.

        :param text: docstring text as string
        :param expected: expected content as Docstring
        """
        res = parse(text)
        assert res == expected

    test(
        text="",
        expected=Docstring(),
    )

    test(
        text="""Test.""",
        expected=Docstring(
            short_description="Test.",
            blank_after_short_description=False,
            blank_after_long_description=False,
        ),
    )


# Generated at 2022-06-23 17:06:23.769428
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    parser = GoogleParser(sections = sections)
    assert(parser.sections["Arguments"].title == "Arguments")
    new_section = Section("Test", "test", SectionType.SINGULAR)
    parser.add_section(new_section)
    assert(parser.sections["Test"].title == "Test")
    assert(parser.sections["Test"].type == SectionType.SINGULAR)


# Generated at 2022-06-23 17:06:25.940150
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser(sections=[Sections("Arguments", "param", SectionType.MULTIPLE)])
    assert p.sections["Arguments"] == Section("Arguments", "param", SectionType.MULTIPLE)


# Generated at 2022-06-23 17:06:29.092708
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()


if __name__ == "__main__":
    parser = GoogleParser(sections=DEFAULT_SECTIONS)
    print(parser.sections)

# Generated at 2022-06-23 17:06:39.521457
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    text = """
    A very short description.

    A longer description, which can span multiple
    lines if needed.

    This attributes does something useful:
        x: first parameter
        y: second parameter
        z: third parameter

    This function returns something useful:
        int: The return value.
    """

    docstring = parse(text)

    assert(docstring.short_description == 'A very short description.')
    assert(docstring.long_description == 'A longer description, which can span multiple\nlines if needed.')
    assert(docstring.blank_after_short_description == True)
    assert(docstring.blank_after_long_description == True)
    assert(len(docstring.meta) == 2)
    assert(len(docstring.meta[0].args) == 3)

# Generated at 2022-06-23 17:06:42.201301
# Unit test for constructor of class Section
def test_Section():
    title = 'title'
    key = 'key'
    type = 'type'
    section = Section(title, key, type)
    assert section.title == title
    assert section.key == key
    assert section.type == type

# Generated at 2022-06-23 17:06:43.526950
# Unit test for constructor of class Section
def test_Section():
    print(Section)

# Generated at 2022-06-23 17:06:47.444670
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    print(gp.sections)
    print(gp.titles_re)
    print(gp.title_colon)
    print(gp.sections.keys())


# Generated at 2022-06-23 17:06:58.724794
# Unit test for function parse
def test_parse():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Return", "returns", SectionType.MULTIPLE),
    ]

# Generated at 2022-06-23 17:07:07.349673
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gP = GoogleParser()
    assert gP.parse("") == Docstring()

    gP = GoogleParser()
    assert gP.parse("short desc\n") == Docstring(
        short_description="short desc", blank_after_short_description=True
    )

    gP = GoogleParser()
    assert gP.parse("short desc\n\nlong desc") == Docstring(
        short_description="short desc",
        blank_after_short_description=True,
        long_description="long desc",
        blank_after_long_description=False,
    )

    gP = GoogleParser()

# Generated at 2022-06-23 17:07:13.181522
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    GoogleStyleParser will parse the following GoogleStyle.
    Arguments:
        foo: A Foo argument.
        bar (int): A bar argument.
        baz: A baz argument.
    Attributes:
        foo_attribute (int): A Foo attribute.
        bar_attribute: A bar attribute.
        baz_attribute (str): A baz attribute.
    Raises:
        ValueError: If something bad happens.
    Returns:
        Some value.
    '''
    assert type(GoogleParser().parse(docstring)) == Docstring
    assert GoogleParser().parse(docstring).meta[0].args == ['param', 'foo']
    assert GoogleParser().parse(docstring).meta[0].description == 'A Foo argument.'

# Generated at 2022-06-23 17:07:23.221958
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse:
    parse a google-style docstring with no sections
    and only one line of description
    """
    x = "This is a test Google docstring.\n"

    def func():
        """This is a test Google docstring."""

    y = parse(func.__doc__)

    # Test long description
    assert x in y.long_description
    # Test short description
    assert y.short_description == "This is a test Google docstring."
    # Test that the rest of the docstring is correct
    assert y.meta == []
    # Test that there is no blank line after the short description
    assert not y.blank_after_short_description
    # Test that there is no blank line after the long description
    assert not y.blank_after_long_description


# Generated at 2022-06-23 17:07:32.958622
# Unit test for function parse

# Generated at 2022-06-23 17:07:39.849475
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    >>> parser = GoogleParser()
    >>> e_section = Section("Example", "example", SectionType.SINGULAR)
    >>> parser.add_section(e_section)
    >>> print(parser.sections["Example"])
    Section(title='Example', key='example', type=<SectionType.SINGULAR: 0>)
    >>> parser.add_section(Section("Example", "example", SectionType.SINGULAR))
    >>> print(parser.sections["Example"])
    Section(title='Example', key='example', type=<SectionType.SINGULAR: 0>)
    """
    pass


# Generated at 2022-06-23 17:07:42.743036
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    prev_len = len(parser.sections)
    section = Section("NewSection", "newSection", SectionType.MULTIPLE)
    parser.add_section(section)
    assert section == parser.sections["NewSection"]
    assert len(parser.sections) == prev_len + 1


# Generated at 2022-06-23 17:07:50.609664
# Unit test for function parse
def test_parse():
    google_docstring = '''
    This function does something.

    Args:
        param1: The first parameter.
        param2: The second parameter.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    '''
    docstring = parse(google_docstring)
    assert docstring.short_description == "This function does something."

# Generated at 2022-06-23 17:08:01.743750
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:08:06.278343
# Unit test for constructor of class Section
def test_Section():
    foo_section = Section("Args", "param", SectionType.MULTIPLE)
    assert foo_section.title == "Args"
    assert foo_section.key == "param"
    assert foo_section.type == SectionType.MULTIPLE



# Generated at 2022-06-23 17:08:09.052582
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Test", "test", SectionType.SINGULAR)
    parser.add_section(section)
    assert parser.sections["Test"] == section

# Generated at 2022-06-23 17:08:19.279947
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-23 17:08:30.448423
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """
    Unit test for GoogleParser constructor
    """
    p = GoogleParser()
    # test default settings
    assert p.title_colon == True
    assert p.sections['Arguments'] == Section("Arguments", "param", SectionType.MULTIPLE)

    # test custom settings
    p = GoogleParser(title_colon=False)
    assert p.title_colon == False
    p.add_section(Section("Args", "param", SectionType.MULTIPLE))
    assert p.sections['Args'] == Section("Args", "param", SectionType.MULTIPLE)
    assert p.sections['Arguments'] == Section("Arguments", "param", SectionType.MULTIPLE)



# Generated at 2022-06-23 17:08:33.596945
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser(title_colon=False).title_colon == False
    assert GoogleParser(title_colon=True).title_colon == True



# Generated at 2022-06-23 17:08:42.806870
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """ \n
        This is a description.

        This is a longer description.

        This is the last line.
        Arguments:
            a: This is a short description of a.
            b: This is a short description of b. This line should be wrapped
                after the colon.
            c: This is a short description of c.
                It should be wrapped in two lines
                after the colon.
            d (Optional[float]): This is a short description of d.
        Returns:
            This is a description of what is returned.
            It should be wrapped in two lines.
    """
    docstring = GoogleParser().parse(text)
    print(docstring)

# Generated at 2022-06-23 17:08:48.340089
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test: if class GoogleParser is defined
    if 'GoogleParser' in globals():
        print('*** test_GoogleParser: PASSED')
    else:
        print('*** test_GoogleParser: FAIL')

test_GoogleParser()


# Generated at 2022-06-23 17:08:52.508040
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    new_section = Section("New title", "new_title", SectionType.MULTIPLE)
    google_parser = GoogleParser()
    google_parser.add_section(new_section)
    assert google_parser.sections[new_section.title] == new_section

# Generated at 2022-06-23 17:08:59.738796
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    docstring = """Summary line.
            Extended description of function.
            Args:
                arg1 (str): Description of arg1
                arg2 (:obj:`int`, optional): Description of arg2
            Returns:
                bool: Description of return value
            """
    ret = p.parse(docstring)
    print(ret)


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:09:10.946423
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("One line.") == Docstring(
        short_description="One line."
    )
    assert parse("One line.\n\nLonger explanation.") == Docstring(
        short_description="One line.",
        long_description="Longer explanation.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("One line.\n\nLonger explanation.\n\n") == Docstring(
        short_description="One line.",
        long_description="Longer explanation.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-23 17:09:13.343102
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text="""
        
        """
    parser=GoogleParser()
    parser.parse(text)

# Generated at 2022-06-23 17:09:24.962770
# Unit test for function parse
def test_parse():
    # Google style
    text = '''\
        Parse the Google-style docstring into its components.

        :returns: parsed docstring
        :rtype: Docstring
    '''
    docst = parse(text)
    assert docst.short_description == "Parse the Google-style docstring into its components."
    assert not docst.blank_after_short_description
    assert docst.long_description == None
    assert docst.blank_after_long_description == False
    assert len(docst.meta) == 2
    assert docst.meta[0] == DocstringMeta(args=['returns'], description="parsed docstring")

    # Numpy style

# Generated at 2022-06-23 17:09:37.181806
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    expected_result = {
        "short_description": "Module docstring.",
        "long_description": None,
        "blank_after_short_description": False,
        "blank_after_long_description": False,
        "meta": [
            {
                "args": ["param", "arg: str\n       Description of 'arg'."],
                "description": "Description of 'arg'.",
                "arg_name": "arg",
                "type_name": "str",
                "is_optional": None,
                "default": None,
            }
        ],
    }

    actual_result = GoogleParser().parse(
        """Module docstring.

Params:
    arg (str): Description of 'arg'.
"""
    )


# Generated at 2022-06-23 17:09:44.623116
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("ARG", "arg", SectionType.MULTIPLE))
    ret = parser.parse("""
        Short description.

            Long description.

            ARG:
                x - description of x.
                y - description of y.

            Arguments:
                z - description of z.
    """)
    assert ret.short_description == "Short description."
    assert ret.blank_after_short_description
    assert ret.long_description == "Long description."
    assert ret.blank_after_long_description
    for meta in ret.meta:
        if meta.args[0] == "arg":
            assert meta.description == "description of x."
        elif meta.args[1] == "x":
            assert meta.description == "description of y."
       

# Generated at 2022-06-23 17:09:56.625578
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_input = '''
    My class summary line.

    My class description.

    Attributes:
        attr1 (int): My first attribute.
                    Initialize with 2.
        attr2 (str): My second attribute.
                    Initialize with [1,2,3].

    Raises:
        KeyError: Raises an exception.
        OtherError: Raises another exception.

    Returns:
        bool: True if successful, False otherwise.

    Examples:
        Examples should be written in doctest format, and should illuminate
        how to use the function.

        >>> print([i for i in example_gen()])
        [0, 1, 2, 3]
    '''


# Generated at 2022-06-23 17:10:00.221476
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    assert parser.sections == {s.title: s for s in DEFAULT_SECTIONS}
    section = Section("New_title", "new_key", SectionType.SINGULAR)
    parser.add_section(section)
    assert parser.sections == {s.title: s for s in DEFAULT_SECTIONS + [section]}

# Generated at 2022-06-23 17:10:03.437876
# Unit test for constructor of class Section
def test_Section():
    class_section = Section("Title", "key", SectionType.MULTIPLE)
    print(class_section)


if __name__ == "__main__":
    test_Section()

# Generated at 2022-06-23 17:10:11.904763
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #Test case no 1
    object1 = GoogleParser()
    output1 = object1.parse("""Return True if value is an empty string, else False.\n\n    Following values are considered empty strings:\n\n    - An empty string, ''.\n    - None.\n    - An empty list [].\n    - An empty dictionary, {}.\n    - An empty tuple, ().\n    """)
    assert type(output1) == Docstring
    assert output1.short_description == "Return True if value is an empty string, else False."
    assert output1.blank_after_short_description

# Generated at 2022-06-23 17:10:15.739133
# Unit test for constructor of class Section
def test_Section():
    assert (Section(title='Attribute', type=SectionType.MULTIPLE, key='attribute') ==
            Section(title='Attribute', type=SectionType.MULTIPLE, key='attribute'))
    

# Generated at 2022-06-23 17:10:24.048666
# Unit test for function parse
def test_parse():
    # pylint: disable=no-self-use
    def func(x, y=10):
        """Add integers.

        Args:
            x: First number.
            y: Second number.

        Returns:
            The sum of ``x`` and ``y``.

        """

    # pylint: enable=no-self-use
    docstring = parse(inspect.cleandoc(func.__doc__))
    assert docstring.short_description == "Add integers."
    assert docstring.long_description == ""
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "x: First number."]
    assert docstring.meta

# Generated at 2022-06-23 17:10:28.235236
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Create an instance of class GoogleParser
    gP = GoogleParser()
    
    # Create an instance of class Section
    Sec = Section("Test", "test", SectionType.SINGULAR)
    
    # Add the Section instance to GoogleParser
    gP.add_section(Sec)
    
    # Check if the section was added correctly
    # If the section was added correctly, the method sections should return the key "Test"
    # which indicates that the section was added correctly.
    assert(gP.sections.get("Test"))


# Generated at 2022-06-23 17:10:33.753146
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Parse the Google-style docstring into its components.

    Returns:
        parsed docstring
    """

    try:
        GoogleParser().parse(text)
    except ParseError:
        pass
    else:
        assert False

    try:
        GoogleParser().parse(text)
    except ParseError:
        assert False

# Generated at 2022-06-23 17:10:43.576012
# Unit test for function parse
def test_parse():

    class Foo:
        """
        This is a short description.

        This is a long description.

        Attributes:
            arg1: This is arg1.
            arg2: This is arg2.
            arg3: This is arg3.
            arg4: This is arg4.
        Examples:
            Examples should be written in doctest format, and
            should illustrate how to use the function/class.
            >>> import foo
            >>> foo.Foo()
        """


# Generated at 2022-06-23 17:10:48.961147
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("NewTitle", "new_key", SectionType.SINGULAR)
    parser.add_section(new_section)
    assert parser.sections["NewTitle"] == new_section
    parser.add_section(new_section)
    assert parser.sections["NewTitle"] == new_section


# Generated at 2022-06-23 17:10:50.830152
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test constructor with no arguments
    googleParser = GoogleParser()
    assert googleParser is not None


# Generated at 2022-06-23 17:11:00.397948
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1: given an empty docstring, expected empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test case 2: given a short description, expected short description
    assert GoogleParser().parse("Test case 4.") == Docstring(
        short_description="Test case 4", blank_after_short_description=True, blank_after_long_description=False, long_description=""
    )

    # Test case 3: given a long description, expected long description
    assert GoogleParser().parse("Test case 4.\n\nTest case 4.") == Docstring(
        short_description="Test case 4", blank_after_short_description=False, blank_after_long_description=True, long_description="Test case 4"
    )

    # Test case 4: given a short description, long description, and Examples section, expected short description

# Generated at 2022-06-23 17:11:03.028511
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser()
    assert(len(p.sections)>=len(DEFAULT_SECTIONS))


# Generated at 2022-06-23 17:11:15.155238
# Unit test for constructor of class Section

# Generated at 2022-06-23 17:11:23.840275
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()

# Generated at 2022-06-23 17:11:30.891519
# Unit test for function parse
def test_parse():
    doc = """Returns all of the numbers in the specified range.

:param int first: The first number in the range.
:param int second: The second number in the range.
:returns: A list of numbers.
:rtype: list
"""


# Generated at 2022-06-23 17:11:42.156416
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    p = GoogleParser(title_colon=False)
    p.add_section(Section("NewSection", "new", SectionType.MULTIPLE))

    test_docstring = """This is a google-style docstring
    This is line 2 of the docstring
    NewSection
        A: 1
        B: 2
    """

    result = p.parse(test_docstring)

    assert(len(result.meta) == 1)

    assert(result.meta[0].args == ['new', 'A'])
    assert(result.meta[0].description == '1')
    assert(result.meta[0].arg_name == 'A')
    assert(result.meta[0].type_name == None)
    assert(result.meta[0].is_optional == None)

# Generated at 2022-06-23 17:11:44.647483
# Unit test for function parse
def test_parse():
    docstring = """Options:
    -o : output
    -i : input
    """
    # print(parse(docstring))
    print(parse.__doc__)


# Generated at 2022-06-23 17:11:56.911524
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-23 17:12:04.035810
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Setup
    docstring = GoogleParser()
    # Exercise
    docstring.add_section(Section(title = "This is a title",
                                  key = "notes",
                                  type = SectionType.MULTIPLE))
    # Verify
    assert docstring.sections['This is a title'] == Section(title='This is a title', key='notes', type=1)
    # Cleanup


# Generated at 2022-06-23 17:12:14.317116
# Unit test for function parse
def test_parse():
    def f1():
        """Summary line.

        Extended description of function.

        Parameters
        ----------
        arg1 : str
            Description of arg1
        arg2 : int
            Description of arg2

        Returns
        -------
        str
            Description of return value

        """

    def f2():
        """Summary line.

        Extended description of function.

        Parameters
        ----------
        arg1 : str
            Description of arg1
        arg2 : int
            Description of arg2

        Returns
        -------
        str
            Description of return value

        Yields
        ------
        str
            Description of yielded value

        Raises
        ------
        ValueError
            If `arg2` is equal to `arg1`.

        """


# Generated at 2022-06-23 17:12:19.507345
# Unit test for constructor of class Section
def test_Section():
    name = 'Topic'
    key = 'key'
    type = SectionType.SINGULAR
    s = Section(name, key, type)
    assert s.title == name
    assert s.key == key
    assert s.type == type


# Generated at 2022-06-23 17:12:23.179076
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    #print(google_parser.parse)
    assert (google_parser.parse("""test""") == str(Docstring()))

test_GoogleParser_parse()

# Generated at 2022-06-23 17:12:29.826497
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert {} == GoogleParser().parse(None)
    assert {} == GoogleParser().parse("")
    assert {"short_description": "some description"} == GoogleParser().parse("some description")
    assert {"short_description": "some description", "long_description": "some long description\r\n"} == GoogleParser().parse("some description\r\nsome long description\r\n")
    assert {"short_description": "some description", "blank_after_short_description": True, "blank_after_long_description": True, "long_description": "some long description"} == GoogleParser().parse("some description\r\n\n\n\nsome long description\r\n\n\n")
    assert {"short_description": "some description", "meta": [{"args": ["Args", "arg1"], "description": "arg1 description."}]}

# Generated at 2022-06-23 17:12:31.776649
# Unit test for function parse
def test_parse():
    from .test_common import check_parse
    check_parse(parse)

# Generated at 2022-06-23 17:12:40.704249
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """\
    Short summary

    Long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        The return value. True for success, False otherwise.
    """

    docstring = GoogleParser().parse(doc)

    assert docstring.short_description == "Short summary"
    assert docstring.long_description == "Long description."

    assert docstring.meta[0].args[0] == "Args"
    assert docstring.meta[0].args[1] == "arg1"
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[0].arg_name == "arg1"

    assert docstring.meta[1].args[0] == "Args"

# Generated at 2022-06-23 17:12:46.371929
# Unit test for function parse
def test_parse():
    import pytest
    docstring = parse('''
    """Convert a string to an corrected integer.

    Args:
        s: The string to be converted

    Returns:
        An integer representation of the string.

    Raises:
        ValueError: If the string cannot be converted to an integer.

    Examples:
        >>> print(convert2int('-105'))
        -105
        >>> print(convert2int('105'))
        105
        >>> print(convert2int('one thousand five'))
        ValueError: invalid literal for int() with base 10: 'one thousand five'
    """
    ''')
    assert(docstring.short_description == "Convert a string to an corrected integer.")
    assert(docstring.blank_after_short_description == False)

# Generated at 2022-06-23 17:12:53.381363
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE
    assert None == section.__doc__
    assert section.__slots__ == ()
    assert section.__module__ == __name__
    assert section.__getnewargs__() == ("Arguments", "param", SectionType.MULTIPLE)
    assert repr(section) == "Section(title='Arguments', key='param', type=0)"
    assert "%r" % section == "Section(title='Arguments', key='param', type=0)"
    assert "%s" % section == "Section(title='Arguments', key='param', type=0)"
    assert section.__dict__ == {}


# Generated at 2022-06-23 17:12:54.910343
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().parse("") == Docstring()


# Generated at 2022-06-23 17:12:58.024432
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser()
    assert str(g) == "GoogleParser()"
    assert g.title_colon
    assert g.sections["Example"] == Section("Example", "examples", 0)

# Generated at 2022-06-23 17:13:08.391507
# Unit test for function parse

# Generated at 2022-06-23 17:13:09.202047
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    pass



# Generated at 2022-06-23 17:13:12.533933
# Unit test for function parse
def test_parse():
    print(parse(
        """Summary line.

        Extended description. Extended description continued.

        Args:
            arg1(int): Description of arg1
            arg2(str): Description of arg2

        Returns:
            bool: Description of return value

        Raises:
            AttributeError, KeyError: Description of exceptions raised

        """
    ))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:13:13.938349
# Unit test for constructor of class Section
def test_Section():
    s = Section("Args", "param", 2)
    assert s.title == "Args"
    assert s.key == "param"
    assert s.type == 2

# Generated at 2022-06-23 17:13:24.979129
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_string = """
    Compute the great circle distance between two points
    on the earth (specified in decimal degrees)

    Arguments:
        lat1: Latitude of the first point.
        lon1: Longitude of the first point.
        lat2: Latitude of the second point.
        lon2: Longitude of the second point.
        earth_radius: The radius of the earth, default is 6371.0 km.
    Returns:
        The distance between the two points in kilometers.
    Note:
        Code adapted from http://www.johndcook.com/python_longitude_latitude.html
    """
    doc_string_parser = GoogleParser()
    parsed = doc_string_parser.parse(text_string)
    parsed_short = parsed.short_description
    parsed_long = parsed.long_description

# Generated at 2022-06-23 17:13:30.988193
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_parsed = parse('''
    This is a short description.

    This is a long description.
    It spans multiple lines.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        int: The return value.
    ''')


# Generated at 2022-06-23 17:13:37.021565
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    print(gp.sections)
    print(gp.sections.keys())

    section = Section("shang", "shang", SectionType.SINGULAR)
    gp.add_section(section)
    print(gp.sections)
    print(gp.sections.keys())

if __name__ == "__main__":
    test_GoogleParser_add_section()

# Generated at 2022-06-23 17:13:41.423731
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from pprint import pprint
    import textwrap
    from .tests import GOOGLE_DRIVER_DOCSTRING

    docstring = parse(GOOGLE_DRIVER_DOCSTRING)
    pprint(docstring.__dict__)


# Generated at 2022-06-23 17:13:46.540911
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    example_section = Section("Examples", "examples", SectionType.SINGULAR)
    p.add_section(example_section)
    sections = {}
    sections["Examples"] = example_section
    assert p.sections == sections



# Generated at 2022-06-23 17:13:49.622373
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser=GoogleParser()
    parser.add_section(Section("Jabba", "jabba", 2))
    assert parser.sections["Jabba"] == Section("Jabba", "jabba", 2)


# Generated at 2022-06-23 17:14:00.439377
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    foo = """Summary line here.

This paragraph is the detailed description. It explains what the method does
and how it can be used.

This is an optional longer description of the method. It can have multiple
paragraphs and even require multiple sections.

Args:
    arg1 (str): Description of arg1
    arg2 (int): Description of arg2
    arg3 (str): Description of arg3. Defaults to \"value\".
    kwarg1 (int): Description of kwarg1
    kwarg2 (int): Description of kwarg2. Defaults to 42.

Returns:
    bool: Whether the operation succeeded.
"""

# Generated at 2022-06-23 17:14:07.534406
# Unit test for constructor of class Section
def test_Section():
    # no arguments provided
    Section = namedtuple("SectionBase", "title key type")
    assert Section().title is None
    assert Section().key is None
    assert Section().type is None

    # arguments provided
    Section = namedtuple("SectionBase", "title key type")
    assert Section("foo", "bar", "baz").title == "foo"
    assert Section("foo", "bar", "baz").key == "bar"
    assert Section("foo", "bar", "baz").type == "baz"


# Generated at 2022-06-23 17:14:12.601168
# Unit test for constructor of class Section
def test_Section():
    section = Section("This is the title", "This is the key", "This is the type")
    assert section.title == "This is the title"
    assert section.key == "This is the key"
    assert section.type == "This is the type"

# Generated at 2022-06-23 17:14:15.621456
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    if __name__ == "__main__":
        parser = GoogleParser()
        print(parser.sections)


# Generated at 2022-06-23 17:14:20.321487
# Unit test for constructor of class Section
def test_Section():
    docstring_obj = Section("description", "description", SectionType.SINGULAR)

    assert docstring_obj.title == "description"
    assert docstring_obj.key == "description"
    assert docstring_obj.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:14:30.281980
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("Short") == Docstring(
        short_description="Short", blank_after_short_description=False
    )

    assert parse(
        """Short

        Long"""
    ) == Docstring(
        short_description="Short", blank_after_short_description=False,
        long_description="Long", blank_after_long_description=False
    )

    assert parse(
        """Short
        Long"""
    ) == Docstring(
        short_description="Short", long_description="Long",
        blank_after_short_description=True, blank_after_long_description=False
    )


# Generated at 2022-06-23 17:14:31.032753
# Unit test for constructor of class Section
def test_Section():
    Section()


# Generated at 2022-06-23 17:14:44.211639
# Unit test for function parse
def test_parse():
    def foo(a, *, b):
        """This is a test.
        
        Singular sections are easy:
        
        Example:
            the place to go
            
        But what about multiple sections?
        
        Arguments:
            a:
                no problem here
            b:
                one arg per line.
            c:
                or two!
                
                Like this!
        """
        return 0

    ds = parse(foo.__doc__)
    assert ds.short_description == "This is a test."
    assert ds.long_description == "Singular sections are easy:"
    assert ds.blank_after_short_description is True
    assert ds.blank_after_long_description is False
    assert len(ds.meta) == 4

# Generated at 2022-06-23 17:14:56.866070
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    print("\nUnit test for method add_section of class GoogleParser")

    # Create an instance of the GoogleParser
    google_parser = GoogleParser()

    # Check if the attribute sections of the instance is empty
    print("\ncheck if the attribute sections of the instance is empty")
    if not google_parser.sections:
        print("the attribute sections of the instance is empty")

    # Add a section named Test
    print("\nadd a section named Test")
    test_section = Section("Test", "test", SectionType.SINGULAR)
    google_parser.add_section(test_section)

    # Check if the attribute sections of the instance is not empty
    print("\ncheck if the attribute sections of the instance is not empty")
    if google_parser.sections:
        print("the attribute sections of the instance is not empty")



# Generated at 2022-06-23 17:15:04.297833
# Unit test for constructor of class Section
def test_Section():
    x = Section("Arguments", "param", SectionType.MULTIPLE)
    assert x.title == "Arguments"
    assert x.key == "param"
    assert x.type == SectionType.MULTIPLE
    y = Section("Args", "param", SectionType.MULTIPLE)
    assert y.title == "Args"
    assert y.key == "param"
    assert y.type == SectionType.MULTIPLE
    z = Section("Parameters", "param", SectionType.MULTIPLE)
    assert z.title == "Parameters"
    assert z.key == "param"
    assert z.type == SectionType.MULTIPLE
    w = Section("Params", "param", SectionType.MULTIPLE)
    assert w.title == "Params"

# Generated at 2022-06-23 17:15:16.896684
# Unit test for function parse
def test_parse():
    assert parse("""
        This is a single-line docstring.
    """) == Docstring(
        short_description="This is a single-line docstring.",
        meta=[],
    )

    assert parse("""
        This is a multi-line docstring.
        It has a short and long part.
    """) == Docstring(
        short_description="This is a multi-line docstring.",
        long_description="It has a short and long part.",
        meta=[],
    )

    assert parse("""
        This is a multi-line docstring.

        It has a short and long part.
    """) == Docstring(
        short_description="This is a multi-line docstring.",
        long_description="It has a short and long part.",
        meta=[],
    )


# Generated at 2022-06-23 17:15:19.808314
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser1 = GoogleParser()
    parser2 = GoogleParser(title_colon=False)
    assert parser1.titles_re != parser2.titles_re


# Generated at 2022-06-23 17:15:29.107523
# Unit test for constructor of class Section
def test_Section():
    c1 = Section("Arguments", "param", SectionType.MULTIPLE)
    c2 = Section("Args", "param", SectionType.MULTIPLE)
    c3 = Section("Parameters", "param", SectionType.MULTIPLE)
    c4 = Section("Params", "param", SectionType.MULTIPLE)
    c5 = Section("Raises", "raises", SectionType.MULTIPLE)
    c6 = Section("Exceptions", "raises", SectionType.MULTIPLE)
    c7 = Section("Except", "raises", SectionType.MULTIPLE)
    c8 = Section("Attributes", "attribute", SectionType.MULTIPLE)
    c9 = Section("Example", "examples", SectionType.SINGULAR)

# Generated at 2022-06-23 17:15:31.273450
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert len(parser.titles_re.pattern) > 0


# Generated at 2022-06-23 17:15:43.045761
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    ret = GoogleParser().parse(docstring)
    assert ret.short_description is None
    assert ret.blank_after_short_description is True
    assert ret.blank_after_long_description is True
    assert ret.long_description is None
    assert ret.meta[0].args[1] == 'param1 (int)'
    assert ret.meta[0].description == 'The first parameter.'
    assert ret.meta[0].arg_name == 'param1'
    assert ret.meta[0].type_name == 'int'
    assert ret.meta[0].is_optional is False

# Generated at 2022-06-23 17:15:46.850889
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("MyArg", "my_arg", SectionType.MULTIPLE))
    doc = parser.parse("MyArg:\n  Describe my arg here")
    param = doc.meta[0]
    assert param.args == ["my_arg", "Describe my arg here"]
    assert param.description == None
    assert param.arg_name == "Describe"
    assert param.type_name == None
    assert param.is_optional == None
    assert param.default == None


# Generated at 2022-06-23 17:15:59.346144
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Example") == Docstring(
        short_description="Example", blank_after_short_description=True, meta=[
            DocstringMeta(
                args=["example", "Example"], description=None,
            )
        ],
    )
    assert parse("Example:\n    more\n    more") == Docstring(
        short_description="Example:", blank_after_short_description=True, meta=[
            DocstringMeta(
                args=["example", "Example"], description="more\nmore",
            )
        ],
    )