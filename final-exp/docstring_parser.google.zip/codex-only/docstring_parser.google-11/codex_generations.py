

# Generated at 2022-06-23 17:06:02.548006
# Unit test for constructor of class Section
def test_Section():
    print("test Section")
    # default constructor
    section1 = Section("Arguments", "param", 2)
    assert(section1.title == "Arguments")
    assert(section1.key == "param")
    assert(section1.type == 2)
    # title = ""
    section1 = Section("", "param", 2)
    assert(section1.title == "")
    assert(section1.key == "param")
    assert(section1.type == 2)
    # key = ""
    section1 = Section("Arguments", "", 2)
    assert(section1.title == "Arguments")
    assert(section1.key == "")
    assert(section1.type == 2)


# Generated at 2022-06-23 17:06:05.663840
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    assert (google_parser.sections["Example"].title == "Example")
    assert (google_parser.sections["Example"].key == "examples")
    assert (google_parser.sections["Example"].type == SectionType.SINGULAR)
    assert (google_parser.title_colon)


# Generated at 2022-06-23 17:06:07.668296
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text_01 = '''
    Class to parse docstrings complying with the Google Python Style Guide
    '''


# Generated at 2022-06-23 17:06:18.686938
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.sections == {t.title: t for t in DEFAULT_SECTIONS}
    assert parser.title_colon == True
    parser = GoogleParser(title_colon=False)
    assert parser.sections == {t.title: t for t in DEFAULT_SECTIONS}
    assert parser.title_colon == False
    parser = GoogleParser(sections=[Section("Example", "examples", SectionType.SINGULAR)])
    assert parser.sections == {"Example": Section("Example", "examples", SectionType.SINGULAR)}
    assert parser.title_colon == True
    parser = GoogleParser([Section("Example", "examples", SectionType.SINGULAR)], title_colon=False)

# Generated at 2022-06-23 17:06:21.900897
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Global Spam
    ===========

    .. versionadded:: 3.2

    Enables spam globally.
    '''
    parse(text)


# Generated at 2022-06-23 17:06:25.387705
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text="""This function is only used by test.
        :param parameter1: The first parameter.
        :param parameter2: The second parameter.
        :returns: The return value.
        :raises keyError: raises an exception
        """
    result = GoogleParser().parse(text) 
    assert result.short_description == "This function is only used by test."

# Generated at 2022-06-23 17:06:27.685668
# Unit test for function parse
def test_parse():
    assert parse.__doc__ == parse(parse.__doc__).to_rst()



# Generated at 2022-06-23 17:06:28.769529
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert gp is not None

# Generated at 2022-06-23 17:06:34.027550
# Unit test for function parse
def test_parse():
    assert parse.__doc__ != parse.__annotations__['text'].__doc__
    assert parse.__annotations__['text'].__doc__ is None
    assert parse.__doc__ is not None
    assert parse.__doc__.startswith('Parse the Google-style docstring')


__all__ = [
    "parse",
]

# Generated at 2022-06-23 17:06:42.700333
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str1 = "Docstring for a class."
    str2 = "Docstring for a class.\n\n\nMore info."
    str3 = "Param a: This is a.\n\nParam b: This is b."
    str4 = "Return: Hello world."
    str5 = "Raise: Hello world."
    str6 = "Example: Hello world."
    str7 = "Example:\nHello world."
    str8 = "Example:\n\n\nHello world."
    str9 = """
    Arguments:
        name (str): The name to use.

    Returns:
        str: Hello name."""
    str10 = """
    Args:
        name (str): The name to use.

    Returns:
        str: Hello name."""

# Generated at 2022-06-23 17:06:45.260514
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    assert type(google_parser).__name__ == "GoogleParser"

# Generated at 2022-06-23 17:06:55.083398
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    docstring = """Construct a new 'GoogleParser'

        :param sections: Recognized sections or None to defaults.
        :param title_colon: require colon after section title.
        :return:
        """
    result = parser._build_meta(docstring, "Raises")
    expected = DocstringRaises(
        args=['raises', ":param sections: Recognized sections or None to defaults.\n        :param title_colon: require colon after section title.\n        :return:"],
        description="Construct a new 'GoogleParser'",
        type_name="Raises",
    )
    assert result == expected


# Generated at 2022-06-23 17:07:05.185685
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Function Description.

    ----------------------------------------------------------------------
    Args:
        arg_a: Description of `arg_a`.
        arg_b: Description of `arg_b`.
        arg_c (int): Description of `arg_c`.
    Raises:
        TypeError: The operation failed.
    Returns:
        int: Description of return value.
    Yields:
        int: Description of yielded value.
    """

# Generated at 2022-06-23 17:07:10.450778
# Unit test for constructor of class Section
def test_Section():
    a = Section("Outputs", "returns", 0)
    assert a.title == "Outputs"
    assert a.key == "returns"
    assert a.type == 0
    b = Section("Outputs", "returns", 0)
    assert b.title == "Outputs"
    assert b.key == "returns"
    assert b.type == 0
    assert a == b
    assert hash(a) == hash(b)


# Generated at 2022-06-23 17:07:18.634088
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("A", "a", SectionType.MULTIPLE),
        Section("B", "b", SectionType.SINGULAR),
        Section("C", "c", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    gp = GoogleParser(sections)
    sections_org = gp.sections
    gp.add_section(Section("B", "b", SectionType.MULTIPLE))
    sections_updated = gp.sections
    assert sections_updated != sections_org

# Generated at 2022-06-23 17:07:28.008406
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section1 = Section("Section1", "key1", SectionType.SINGULAR)
    section2 = Section("Section2", "key2", SectionType.SINGULAR)
    section3 = Section("Section3", "key3", SectionType.SINGULAR)
    parser = GoogleParser([section1, section2])
    parser.add_section(section3)

    assert parser.sections["Section1"] == section1
    assert parser.titles_re.search("Section1")
    assert parser.sections["Section2"] == section2
    assert parser.titles_re.search("Section2")
    assert parser.sections["Section3"] == section3
    assert parser.titles_re.search("Section3")


# Generated at 2022-06-23 17:07:29.142582
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass


# Generated at 2022-06-23 17:07:37.072658
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:07:42.849215
# Unit test for function parse
def test_parse():
    # missing colon after section title
    parser = GoogleParser()
    ds = """A module for parsing Google-style docstrings

Args:
  arg1 (str): missing colon
  arg2 (bool): is optional. Defaults to True.
"""
    elements = parser.parse(ds)
    print(elements)
    assert "<BLANKLINE>" in elements.short_description
    assert "A module for parsing Google-style docstrings" in elements.short_description
    assert elements.meta[2].description == "is optional. Defaults to True."
    assert elements.meta[2].key in PARAM_KEYWORDS


# Generated at 2022-06-23 17:07:50.651250
# Unit test for function parse
def test_parse():
    """Test GoogleParser.parse() function."""
    ds = \
    """The function to compute distance between two points $p1 = (x_1, y_1)$ and 
       $p2 = (x_2, y_2)$ is defined as 
       $d(p_1, p_2) = |p_2 - p_1| = \sqrt{(x_1-x_2)^2 + (y_1-y_2)^2}.$
       
       Args:
           p1 (tuple(float, float)): the coordinate of first point
           p2 (tuple(float, float)): the coordinate of second point
           
       Returns: 
           float: the distance between two points.
    """
    assert docstring_to_str(parse(ds)) == ds




# Generated at 2022-06-23 17:07:54.988223
# Unit test for constructor of class Section
def test_Section():
    sections = Section('a', 'b', 'c')
    assert sections.title == 'a'
    assert sections.key == 'b'
    assert sections.type == 'c'


# Generated at 2022-06-23 17:08:03.202531
# Unit test for constructor of class Section
def test_Section():
    section1 = Section("Examples", "examples", SectionType.SINGULAR)
    section2 = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert (section1.title, section1.key, section1.type) == ("Examples", "examples", SectionType.SINGULAR)
    assert (section2.title, section2.key, section2.type) == ("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)


# Generated at 2022-06-23 17:08:10.654650
# Unit test for function parse
def test_parse():
    """Testing function parse."""

# Generated at 2022-06-23 17:08:20.137310
# Unit test for function parse
def test_parse():
    # Test example
    text = """
    Params:
        arg1 (int): The first argument.
        arg2 (int): The second argument.

    Returns:
        int: The return value.
    """

# Generated at 2022-06-23 17:08:31.853036
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))

    ret = parser.parse('"""\nArgs:\n    text: Text\n"""')
    assert ret.short_description is None
    assert ret.long_description is None

    assert len(ret.meta) == 1
    assert ret.meta[0].title == "param"
    assert ret.meta[0].text[0] == "Args"
    assert ret.meta[0].text[1] == "text: Text"

    ret = parser.parse('"""\nArgs:\n    text: Text\n\n"""')
    assert ret.short_description is None
    assert ret.long_description is None

    assert len(ret.meta) == 1

# Generated at 2022-06-23 17:08:41.801548
# Unit test for function parse
def test_parse():
    text = """Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """

if __name__ == "__main__":

    text = """Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """

    ret = parse(text)
    print(ret)
    print(ret.short_description)
    print(ret.long_description)
    print(ret.blank_after_short_description)
    print(ret.blank_after_long_description)
    for meta in ret.meta:
        print(meta.__class__.__name__)
        print(meta.args)

# Generated at 2022-06-23 17:08:47.656616
# Unit test for function parse
def test_parse():
    parts = parse.__doc__
    assert parts.short_description == "Parse the Google-style docstring into its components."
    assert not parts.blank_after_short_description
    assert not parts.blank_after_long_description
    assert parts.long_description == ":returns: parsed docstring"


# Generated at 2022-06-23 17:08:54.275226
# Unit test for constructor of class Section
def test_Section():
    assert Section("title", "key", SectionType.SINGULAR).title == "title"
    assert Section("title", "key", SectionType.SINGULAR).key == "key"
    assert Section("title", "key", SectionType.SINGULAR).type == 0
    assert Section("title", "key", SectionType.MULTIPLE).type == 1
    assert Section("title", "key", SectionType.SINGULAR_OR_MULTIPLE).type == 2


# Generated at 2022-06-23 17:09:06.561852
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()

    assert parse('Ok\n') == Docstring(
        short_description='Ok',
        blank_after_short_description=True,
        long_description=None,
    )

    assert parse('Ok\n\n') == Docstring(
        short_description='Ok',
        blank_after_short_description=True,
        long_description=None,
    )

    assert parse('Ok\n\n\n') == Docstring(
        short_description='Ok',
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=True,
    )

    docstring = parse('''
    Ok

    Ok.
    ''')

# Generated at 2022-06-23 17:09:12.736293
# Unit test for function parse
def test_parse():
    from .numpydoc import NumpyDocString
    from .numpydoc_parser import parse as nd_parse

    text = '''
        Short summary
        -------------

        Long description.

        This can have multiple paragraphs.

        Attributes
        ----------
        bla : list
            List of blaa.

        Raises
        ------
        OSError
            If a file was not found.
            And there was fire.
        ValueError
            If blub was invalid.
        IOError
            On network timeout.

        Returns
        -------
        str
            The result.
        '''

    r1 = parse(text)

    nd_test = nd_parse(text)

    assert r1.short_description == nd_test.short_description
    assert r1.long_description == nd_

# Generated at 2022-06-23 17:09:16.569903
# Unit test for function parse
def test_parse():
    parts = parse(test_parse.__doc__)
    assert parts.short_description == "Unit test for function parse"
    assert parts.long_description == "Added by @deniszhang"
    assert parts.blank_after_short_description == False
    assert parts.blank_after_long_description == False
    assert len(parts.meta) == 0

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:09:27.118475
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:09:31.998318
# Unit test for constructor of class Section
def test_Section():
    # Test with no argument
    section = Section('title', 'key', SectionType.SINGULAR)
    assert section.title == "title"
    assert section.key == 'key'
    assert section.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:09:41.654328
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    title_to_key = {
        "ABC": "abc",
        "XYZ": "xyz",
        "DEF": "def",
        "GHI": "ghi"
    }

    sections = [
        Section(title, title_to_key[title], SectionType.MULTIPLE) for title in title_to_key
    ]


# Generated at 2022-06-23 17:09:54.708477
# Unit test for function parse
def test_parse():
    doc_string = """
    This is a docstring with an attribute, returns and raises.

    :returns: The return value.
    :raises NoSuchNameError: The exception type to be raised.
    :param x: X parameter
    :output:
    """
    doc = GoogleParser().parse(doc_string)
    assert doc.short_description == "This is a docstring with an attribute, returns and raises."
    assert doc.long_description is None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    for meta in doc.meta:
        if meta.args == ["returns"]:
            assert meta.description == "The return value."

# Generated at 2022-06-23 17:10:04.910542
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:10:08.495516
# Unit test for constructor of class Section
def test_Section():
    sec = Section("test_title", "test_key", SectionType.SINGULAR_OR_MULTIPLE)
    assert sec.title == "test_title"
    assert sec.key == "test_key"
    assert sec.type == SectionType.SINGULAR_OR_MULTIPLE




# Generated at 2022-06-23 17:10:10.311079
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser(sections=DEFAULT_SECTIONS, title_colon=True)
    assert isinstance(g, GoogleParser)

# Generated at 2022-06-23 17:10:21.525010
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with no docstring
    print("Test with no docstring")
    d = GoogleParser().parse("")
    assert not d.short_description
    assert not d.long_description
    assert not d.meta
    # Test with a docstring with only short description
    print("Test with a docstring with only short description")
    d = GoogleParser().parse("Short description")
    assert d.short_description == "Short description"
    assert not d.long_description
    assert not d.meta
    # Test with a docstring with short description, blank line and long description
    print(
        "Test with a docstring with short description, blank line and long description"
    )

# Generated at 2022-06-23 17:10:23.869966
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert len(GoogleParser().sections) == len(DEFAULT_SECTIONS)


# Generated at 2022-06-23 17:10:28.720278
# Unit test for constructor of class Section
def test_Section():
    section = Section("test_title", "test_key", SectionType.SINGLE)
    assert section.title == "test_title"
    assert section.key == "test_key"
    assert section.type == SectionType.SINGLE



# Generated at 2022-06-23 17:10:39.782065
# Unit test for function parse
def test_parse():
    text = '''
        This is a sample docstring.

        This is the long description:
                * One
                * Two
                * Three

        This is an example.

        Args:
            arg1 (str): The first parameter.
            arg2 (int): The second one.

            Examples:
                Example 3

        Returns:
            str: Some return value.

        Raises:
            Exception1: An exception
            Exception2: Another exception

        Yields:
            str: A yielded value.
    '''
    docstring = parse(text)

    assert docstring.short_description == "This is a sample docstring."
    assert not docstring.blank_after_short_description
    assert docstring.long_description == '''This is the long description:
        * One
        * Two
        * Three'''


# Generated at 2022-06-23 17:10:52.759183
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # No docstring or empty docstring
    assert GoogleParser().parse(None) == Docstring()
    assert GoogleParser().parse("") == Docstring()
    # Single line docstring
    assert GoogleParser().parse("A docstring.") == Docstring(
        short_description="A docstring.",
        blank_after_short_description=False,
    )
    assert GoogleParser().parse(" A docstring.") == Docstring(
        short_description="A docstring.",
        blank_after_short_description=False,
    )
    assert GoogleParser().parse("\nA docstring.") == Docstring(
        short_description="A docstring.",
        blank_after_short_description=True,
    )

# Generated at 2022-06-23 17:11:00.061409
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) == Section("Arguments", "param", SectionType.MULTIPLE)
    assert Section("Arguments", "param", SectionType.MULTIPLE) != Section("Args", "param", SectionType.MULTIPLE)
    assert Section("Arguments", "param", SectionType.MULTIPLE) != Section("Arguments", "args", SectionType.MULTIPLE)
    assert Section("Arguments", "param", SectionType.MULTIPLE) != Section("Arguments", "param", SectionType.SINGULAR)


# Generated at 2022-06-23 17:11:12.939030
# Unit test for function parse
def test_parse():
    doc = GoogleParser().parse("""
        This is a short description.

        This is a long description.

        Args:
            arg1 (str): The first argument.
            arg2 (Optional[str]): The second argument.
            arg3 (str): The third argument.
                This continues over two lines.

        Parameters:
            param1 (int): The first parameter.
            param2: The second parameter.

        Exceptions:
            AttributeError: The variable is not found.

        Returns:
            generator: The return value.
            int: The second return value.

        Yields:
            None: No value is yielded.
    """)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert not doc.blank_after_short_

# Generated at 2022-06-23 17:11:14.580957
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    print(google_parser.sections)
    assert google_parser.sections is not None
    assert google_parser.sections["Yields"] is not None
    

# Generated at 2022-06-23 17:11:19.087809
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse('"""\nGoogle-style docstring parsing.\n"""') == Docstring(short_description='Google-style docstring parsing.', long_description=None, meta=[], blank_after_short_description=True, blank_after_long_description=False)


# Generated at 2022-06-23 17:11:30.454592
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    from .common import DOCSTRING_NO_INDENT
    p = GoogleParser(sections=[Section("Args", "param", SectionType.MULTIPLE)])

# Generated at 2022-06-23 17:11:39.126380
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_doc_string = GoogleParser().parse("""
        Parameters
        ----------
        text: str
            input text.
            
        Returns
        -------
        output: str
            result of transformation.
    """)
    assert isinstance(test_doc_string, Docstring)
    assert test_doc_string.short_description == 'Parameters'
    assert test_doc_string.blank_after_short_description == True
    assert test_doc_string.blank_after_long_description == False
    assert test_doc_string.long_description == '--------'


# Generated at 2022-06-23 17:11:46.841809
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse.
    """
    google_single_meta_string = """
    Single line
    """
    print(google_single_meta_string)
    google_single_meta_string_with_blank_before = """

    Single line
    """
    print(google_single_meta_string_with_blank_before)
    google_single_meta_string_with_blank_after = """
    Single line

    """
    print(google_single_meta_string_with_blank_after)
    google_multiple_meta_string = """
    Multiple line:
        test
    """
    print(google_multiple_meta_string)
    google_multiple_meta_string_with_blank_before = """

    Multiple line:
        test
    """

# Generated at 2022-06-23 17:11:52.282096
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Kwargs", "arg", SectionType.MULTIPLE))
    assert len(gp.sections) == 27

    gp.add_section(Section("Kwargs", "arg", SectionType.SINGULAR))
    assert len(gp.sections) == 27

# Generated at 2022-06-23 17:12:00.948611
# Unit test for constructor of class Section

# Generated at 2022-06-23 17:12:12.611688
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:12:24.424005
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_string = """
    Args:
        b: If b == 1, return a.
    Raises:
        ValueError: If a < 0 or b < 0 or a + b < 0.
    """
    doc = GoogleParser.parse(doc_string)
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is None
    assert doc.blank_after_long_description is None
    assert len(doc_meta) == 2
    assert doc_meta[0].args == ["param", "b"]
    assert doc_meta[0].description == "If b == 1, return a."
    assert doc_meta[0].arg_name == "b"
    assert doc_meta[0].type_name is None

# Generated at 2022-06-23 17:12:35.717549
# Unit test for function parse
def test_parse():
    docstring_1 = """
    Converts an angle measurement from radians to degrees.

    :param angle: An angle measurement in radians.
    :type angle: float
    :returns: The equivalent angle in degrees.
    :raises TypeError: If the ``angle`` parameter is not a ``float``.
    """
    docstring_2 = """
    Converts an angle measurement from radians to degrees.

    :param angle: An angle measurement in radians.
    :raises TypeError: If the ``angle`` parameter is not a ``float``.
    :returns: The equivalent angle in degrees. 
    """

# Generated at 2022-06-23 17:12:37.775045
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test_GoogleParser = GoogleParser()
    assert test_GoogleParser

# Generated at 2022-06-23 17:12:42.769010
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser(
        sections=[Section("Arguments", "param", SectionType.MULTIPLE)]
    )

    section = Section("Parameters", "param", SectionType.MULTIPLE)
    parser.add_section(section)

    assert parser.sections["Parameters"] == section



# Generated at 2022-06-23 17:12:46.281615
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Test Section", "test_section", SectionType.SINGULAR))
    assert parser.sections["Test Section"].key == "test_section"

# Generated at 2022-06-23 17:12:49.842159
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    obj = GoogleParser()
    obj.add_section(Section("This", "asdf", SectionType.MULTIPLE))
    obj.add_section(Section("This", "asdf", SectionType.SINGULAR))
    assert(obj.sections['This'].type == SectionType.SINGULAR)

# Generated at 2022-06-23 17:12:53.714865
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Returns", "returns", SectionType.MULTIPLE)
    assert sec.title == "Returns"
    assert sec.key == "returns"
    assert sec.type == SectionType.MULTIPLE

# Generated at 2022-06-23 17:12:57.257126
# Unit test for function parse
def test_parse():
    docs = inspect.getdoc(parse)
    assert parse(docs) == parse('"""Parse the Google-style docstring into its components.\n\n:returns: parsed docstring\n"""')
    assert parse(docs) == GoogleParser().parse(docs)


# Generated at 2022-06-23 17:13:07.898071
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .examples_google import (
        EXAMPLE_MODULE_GOOGLE,
        EXAMPLE_PACKAGE_GOOGLE,
        EXAMPLE_FUNCTION_GOOGLE,
        EXAMPLE_CLASS_GOOGLE,
        EXAMPLE_CONSTRUCTOR_GOOGLE,
        EXAMPLE_METHOD_GOOGLE,
    )

    assert GoogleParser().parse(EXAMPLE_MODULE_GOOGLE)
    assert GoogleParser().parse(EXAMPLE_PACKAGE_GOOGLE)
    assert GoogleParser().parse(EXAMPLE_FUNCTION_GOOGLE)
    assert GoogleParser().parse(EXAMPLE_CLASS_GOOGLE)
    assert GoogleParser().parse(EXAMPLE_CONSTRUCTOR_GOOGLE)

# Generated at 2022-06-23 17:13:14.018517
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    test_docstring = """This function add two numbers.
    It takes two arguments, a and b, and return their sum.

    :param a: First argument
    :param b: Second argument
    :returns: sum of two numbers
    """
    parser.parse(test_docstring)
    #test_docstring = """This function add two numbers.
#    It takes two arguments, a and b, and return their sum.

 #   :param a: First argument
  #  :param b: Second argument
  #  :returns: sum of two numbers
  #  """


# Generated at 2022-06-23 17:13:25.077219
# Unit test for function parse
def test_parse():
    text = """\
    This is a short description.

    This is a longer description.

    Args:
        param1: This is a parameter.
        param2: This is another paramter.

    Returns:
        This is a return description.
        This is another return description."""
    docstring = parse(text)

    # Test doctring
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a longer description."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False

    # Test meta information
    param1 = docstring.meta[0]
    assert isinstance(param1, DocstringParam)
    assert param1.description == "This is a parameter."
    assert param1.arg

# Generated at 2022-06-23 17:13:29.719200
# Unit test for constructor of class Section
def test_Section():
    Section0 = Section(title="Arguments", key="param", type=SectionType.MULTIPLE)
    # Check if the 'title' of Section0 is "Arguments"
    assert Section0.title == "Arguments"
    # Check if the 'key' of Section0 is "param"
    assert Section0.key == "param"
    # Check if the 'type' of Section0 is MULTIPLE
    assert Section0.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:13:33.263576
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("This", "example", SectionType.SINGULAR))
    assert(gp.sections["This"] == Section("This", "example", SectionType.SINGULAR))

# Generated at 2022-06-23 17:13:38.634398
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Miscs", "misc", SectionType.MULTIPLE))
    sections = gp.sections
    assert sections["Miscs"].title == "Miscs"
    assert sections["Miscs"].key == "misc"
    assert sections["Miscs"].type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:13:45.568575
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    import re
    import inspect
    import collections
    
    
    def parse(text):
        parser = GoogleParser()
        parser.add_section(Section("Section", "elements", SectionType.MULTIPLE))
        return parser.parse(text)
    
    
    # Create Google-style docstring text
    
    GOOGLE_TYPED_ARG_REGEX = re.compile(r"\s*(.+?)\s*\(\s*(.*[^\s]+)\s*\)")
    GOOGLE_ARG_DESC_REGEX = re.compile(r".*\. Defaults to (.+)\.")
    MULTIPLE_PATTERN = re.compile(r"(\s*[^:\s]+:)|([^:]*\]:.*)")
   

# Generated at 2022-06-23 17:13:56.250537
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("hello") == Docstring(short_description="hello")
    assert (
        GoogleParser().parse("hello\nworld\n")
        == Docstring(
            short_description="hello",
            long_description="world",
            blank_after_short_description=True,
            blank_after_long_description=False,
        )
    )

    parser = GoogleParser()
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))

# Generated at 2022-06-23 17:13:56.906259
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-23 17:14:02.374370
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert len(parser.titles_re.pattern) == 33
    assert len(parser.titles_re.flags) == 2

    parser = GoogleParser(title_colon=False)
    assert len(parser.titles_re.pattern) == 27
    assert len(parser.titles_re.flags) == 2


# Generated at 2022-06-23 17:14:08.801614
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

    parser.add_section(Section("Name", "name", SectionType.MULTIPLE))
    # Testing adding multiple same sections
    parser.add_section(Section("Name", "name", SectionType.MULTIPLE))

    # This is a counting variable that keeps a track of how many times a sections are
    # being added.
    name_count = 0
    parameter_count = 0
    name_found = False
    parameter_found = False
    for key in parser.sections:
        if key == "Name":
            name_found = True
            name_count += 1
        if key == "Parameters":
            parameter_found = True
            parameter_count += 1
    assert name_found, "Name is not found in section list"
    assert parameter_found,  "Parameters is not found in section list"

# Generated at 2022-06-23 17:14:21.473056
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Test Google-style docstring.

Args:
    param1 (str): The first parameter.
    param2 (str): The second parameter.

Returns:
    str: The return value. True for success, False otherwise.

"""   

# Generated at 2022-06-23 17:14:26.173017
# Unit test for constructor of class Section
def test_Section():
    title = 'Abc'
    key = 'def'
    type = 'ghi'
    result = Section(title, key, type)
    assert result.title == title
    assert result.key == key
    assert result.type == type


# Generated at 2022-06-23 17:14:33.484794
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser(title_colon=False)
    assert gp.sections == {'Returns': Section(title='Returns', key='returns', type=2),
                           'Parameters': Section(title='Parameters', key='param', type=1),
                           'Example': Section(title='Example', key='example', type=0),
                           'Args': Section(title='Args', key='param', type=1),
                           'Yields': Section(title='Yields', key='yields', type=2),
                           'Raises': Section(title='Raises', key='raises', type=1)}
    assert gp.title_colon is False


# Generated at 2022-06-23 17:14:40.973819
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("hello") == Docstring(
        short_description="hello"
    )
    assert (
        GoogleParser()
        .parse("hello\nto you\n\nmore\n\nstuff")
        == Docstring(
            short_description="hello",
            blank_after_short_description=True,
            long_description="to you\n\nmore\n\nstuff".strip("\n"),
            blank_after_long_description=True,
        )
    )

# Generated at 2022-06-23 17:14:43.489236
# Unit test for function parse
def test_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()
    docstring = parse("Short description.\n\nLong description.")
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."



# Generated at 2022-06-23 17:14:55.980731
# Unit test for function parse
def test_parse():
    docstring = """
    Example Google-style docstring.

    This is an example of Google-style docstring.

    This is the description of the foo function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise - this is an example.

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "Example Google-style docstring."
    assert parsed.long_description == """This is an example of Google-style docstring.

This is the description of the foo function."""
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long

# Generated at 2022-06-23 17:15:03.820901
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = []
    title_colon = True
    gp = GoogleParser(sections, title_colon)

# Generated at 2022-06-23 17:15:07.610068
# Unit test for constructor of class Section
def test_Section():
    sec = Section("test", "test", 0)
    assert sec.title is "test"
    assert sec.key is "test"
    assert sec.type is 0



# Generated at 2022-06-23 17:15:16.418571
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    '''Unittest for method add_section of class GoogleParser'''
    from .common import DocstringReturns, DocstringRaises, DocstringParam

    # Test 1
    parser = GoogleParser()
    text_1 = \
        """
        This is a test for the method add_section of class GoogleParser
        :test: This is a test
        :param name: short description.
            long description\n
            test
        :param age: this is age
        :return: return value\n
        """
    ret = parser.parse(text_1)

# Generated at 2022-06-23 17:15:26.735246
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("Short") == Docstring(
        short_description="Short",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )
    assert parse("Short\n") == Docstring(
        short_description="Short",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )
    assert parse("Short\nLong") == Docstring(
        short_description="Short",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="Long",
        meta=[],
    )

# Generated at 2022-06-23 17:15:39.940942
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse('Description.\n\n    Args:\n        param1 (int, optional): Description. Defaults to 1.\n        param2 (int): Description.')
    assert(docstring.short_description == 'Description.')
    assert(docstring.long_description is None)
    assert(docstring.blank_after_short_description is False)
    assert(docstring.blank_after_long_description is True)
    assert(len(docstring.meta) == 2)

    docstring_param = docstring.meta[0]
    assert(docstring_param.description == 'Description.')
    assert(docstring_param.type_name == 'int, optional')
    assert(docstring_param.arg_name == 'param1')

# Generated at 2022-06-23 17:15:43.548868
# Unit test for constructor of class Section
def test_Section():
    section1 = Section("Arguments", "param", SectionType.MULTIPLE)
    print(section1)
    assert section1.title == 'Arguments'
    assert section1.key == 'param'
    assert section1.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:15:50.387349
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("test") == Docstring(short_description='test')
    assert parse("test\n\ntest") == Docstring(short_description='test', long_description='test', blank_after_short_description=True, blank_after_long_description=True)
    assert parse("test\ntest") == Docstring(short_description='test', long_description='test')
    assert parse("    test") == Docstring(short_description='test')
    assert parse("Arguments:\ntest") == Docstring(short_description=None, meta=[DocstringParam(args=['Arguments', 'test'], description=None, arg_name=None, type_name=None, is_optional=None, default=None)])

# Generated at 2022-06-23 17:16:00.836546
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text1 = r'''Single line docstring.'''
    ds1 = parse(text1)
    assert ds1.short_description == "Single line docstring."
    assert ds1.long_description == None

    text2 = r'''    Single line docstring.'''
    ds2 = parse(text2)
    assert ds2.short_description == "Single line docstring."
    assert ds2.long_description == None

    text3 = r'''
    Single line docstring.
    '''
    ds3 = parse(text3)
    assert ds3.short_description == "Single line docstring."
    assert ds3.long_description == None

    text4 = r'''Single paragraph docstring.

    Second line of the docstring.
    '''