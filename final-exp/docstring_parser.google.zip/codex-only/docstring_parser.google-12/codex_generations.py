

# Generated at 2022-06-23 17:05:59.628514
# Unit test for constructor of class Section
def test_Section():
    mySection = Section("Arguments", "param", SectionType.SINGULAR_OR_MULTIPLE)
    assert(mySection.title == "Arguments")
    assert(mySection.key == "param")
    assert(mySection.type == SectionType.SINGULAR_OR_MULTIPLE)

# Generated at 2022-06-23 17:06:07.075499
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """
    One line summary.

    More detailed description. Can contain several paragraphs.
    Each of them should be separated by an empty line.

    Args:
        arg1: description of arg1
            can span several lines,
            using indentation.

        arg2 (str): description of arg2
        arg3 (:obj:`int`, optional): description of arg3

    Returns:
        int. description of return value

    Raises:
        ValueError: If `arg2` is equal to `arg1`.

    .. _Google Python Style Guide:
       http://google.github.io/styleguide/pyguide.html

    """
    parsed = parser.parse(text)

# Generated at 2022-06-23 17:06:12.772122
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("name", "param", SectionType.MULTIPLE))
    print(parser.sections["name"])

if __name__ == "__main__":
    test_GoogleParser_add_section()

# Generated at 2022-06-23 17:06:14.723353
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE)

# Generated at 2022-06-23 17:06:16.310840
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "Arrange: something\nAct: something\nAssert: something"
    assert parse(text).long_description == text


# Generated at 2022-06-23 17:06:29.344212
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("   ") == Docstring()

    s = "blah\nblah"
    assert parse(s) == Docstring(short_description="blah", long_description="blah")
    assert parse("blah blah\nblah blah") == Docstring(
        short_description="blah blah",
        long_description="blah blah",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("\nblah blah") == Docstring(
        short_description="blah blah",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    s = "\nblah blah\n  blah blah"


# Generated at 2022-06-23 17:06:33.396444
# Unit test for constructor of class Section
def test_Section():
    section = Section("hi", "bye", SectionType.SINGULAR)
    assert section.title == "hi"
    assert section.key == "bye"
    assert section.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:06:42.301654
# Unit test for function parse
def test_parse():
    """Test parsing of Google-style docstring."""

    # A simple example
    text = """Short summary.

    Long summary.

    Args:
        arg1 (int): The first parameter.
        arg2 (str): The second parameter.
    Returns:
        str: The return value.
    Raises:
        ValueError: if `arg2` is equal to `arg1`.
    """

# Generated at 2022-06-23 17:06:46.335185
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    d = GoogleParser()
    print(d)

    d2 = GoogleParser(title_colon=False)
    print(d2)


# Generated at 2022-06-23 17:06:57.493506
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # GoogleParser: Test if using default constructor
    G = GoogleParser()
    set_default_sections = set(DEFAULT_SECTIONS)
    set_sections = {}
    for title, section in G.sections.items():
        set_sections[title] = section
    assert set_default_sections == set(set_sections.values())
    # GoogleParser: Test if using specified constructor
    Section = namedtuple("SectionBase", "title key type")
    sections = [
        Section("new_title1", "param", SectionType.SINGULAR),
        Section("new_title2", "param", SectionType.SINGULAR_OR_MULTIPLE)
    ]
    G2 = GoogleParser(sections=sections)
    set_sections2 = {}
    for title, section in G2.sections.items():
        set_

# Generated at 2022-06-23 17:07:03.500169
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
        Here are some examples of docstring:
        :param int a: some integer
        :returns: 3
        """
    p = GoogleParser()
    p.add_section(Section("Description", "description", SectionType.SINGULAR))
    docstring = p.parse(text)
    assert docstring.long_description is None
    assert docstring.short_description == "Here are some examples of docstring"


# Generated at 2022-06-23 17:07:11.982122
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

    # Test method if you add a section to the class GoogleParser
    new_section = Section("Method", "method", SectionType.SINGULAR)
    parser.add_section(new_section)

    # Test if the section was added

# Generated at 2022-06-23 17:07:23.397295
# Unit test for constructor of class GoogleParser
def test_GoogleParser():

    # Test init and setup
    gp = GoogleParser()

# Generated at 2022-06-23 17:07:33.130575
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    a = GoogleParser()

# Generated at 2022-06-23 17:07:41.534242
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert len(parser.sections) == 13
    assert parser.title_colon == True
    assert "Arguments" in parser.sections
    assert "Args" in parser.sections
    assert "Parameters" in parser.sections
    assert "Params" in parser.sections
    assert "Raises" in parser.sections
    assert "Exceptions" in parser.sections
    assert "Except" in parser.sections
    assert "Attributes" in parser.sections
    assert "Example" in parser.sections
    assert "Examples" in parser.sections
    assert "Returns" in parser.sections
    assert "Yields" in parser.sections
    assert parser.sections["Arguments"].title == "Arguments"
    assert parser.sections["Arguments"].key == "param"
    assert parser.sections["Arguments"].type

# Generated at 2022-06-23 17:07:47.987519
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    - Test if sections exist before and after add_section is called
    """
    # Case where section is not added by default
    dp = GoogleParser(sections=[])
    assert len(dp.sections) == 0

    # Case where section is added by default
    dp = GoogleParser()
    assert len(dp.sections) > 0
    assert dp.sections['Arguments'] != None

    # Case where section is added by default
    dp = GoogleParser()
    assert len(dp.sections) > 0
    assert dp.sections['Arguments'] != None

# Generated at 2022-06-23 17:07:53.767287
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_for_public_method_parse = "Return parsed docstring."
    result = parse(docstring_for_public_method_parse)
    assert result.short_description == "Return parsed docstring."
    assert result.long_description is None


# Generated at 2022-06-23 17:08:05.006978
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google = GoogleParser()
    docstring = """
    Single line summary.

    Multi-line description.

    Args:
        arg1 (str): Argument 1.
        arg2 (str): Argument 2.

    Returns:
        str: Result.
    """
    parsed = google.parse(docstring)
    assert parsed.short_description == "Single line summary."
    assert parsed.long_description == "Multi-line description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].description == "Argument 1."
    assert parsed.meta[1].description == "Argument 2."
    assert parsed.meta[2].description == "Result."



# Generated at 2022-06-23 17:08:15.133170
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    #Initialize
    text = """Parameter:
        The text to parse.
        :param str text: text to parse"""
    parser = GoogleParser(sections=[Section("Parameter", "param", SectionType.MULTIPLE)])
    new_section = Section("Parameter", "attr", SectionType.MULTIPLE)
    parser.add_section(new_section)

    # parse and assert
    result = parser.parse(text)
    assert len(result.meta) == 1
    assert isinstance(result.meta[0], DocstringMeta)
    assert result.meta[0].args == ["attr", "text"]
    assert result.meta[0].description == "The text to parse."

# Generated at 2022-06-23 17:08:28.050434
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Tests the functionality of method add_section of class GoogleParser
    # The test adds a section to the default sections and ensures that the 
    # Parse function parses the string with the new section
    # The test also ensures that adding a new section that already exists replaces
    # the old section

    # Setting up GoogleParser with default sections
    gp = GoogleParser()
    # Adding a new section and ensuring that it is added to the list of sections
    # Also ensuring that the the parser parses correctly with the new section
    new_section = Section("Test", "test", SectionType.SINGULAR)
    gp.add_section(new_section)
    assert new_section in gp.sections.values()
    assert gp.parse("Test:\nTest test")[0].args == [new_section.key]

    # Adding another section
    gp = Google

# Generated at 2022-06-23 17:08:32.065398
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:08:43.270922
# Unit test for function parse
def test_parse():
    from .common import Docstring
    from .common import DocstringParam
    from .common import DocstringMeta
    from .common import DocstringReturns
    from .common import DocstringRaises


# Generated at 2022-06-23 17:08:55.208889
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:09:07.517580
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:09:15.431424
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:09:19.681107
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Gompute the absolute value of an integer.

    :param x: int
    :return: int
    """
    parser = GoogleParser()
    assert parser.parse(docstring)


# Generated at 2022-06-23 17:09:22.745470
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    section = Section("Test", "test", SectionType(1))
    google_parser.add_section(section)
    assert section in google_parser.sections.values()


# Generated at 2022-06-23 17:09:29.995969
# Unit test for function parse
def test_parse():
    docstring = """
    Example google style docstring

    This function does something.

    Args:
        param1: The first parameter.
        param2: The second parameter. Default: None.
            The second line of the second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    result = parse(docstring)
    assert len(result.meta) == 3
    assert result.short_description == "Example google style docstring"
    assert result.long_description.startswith("This function does something")
    assert result.long_description.endswith("for success, False otherwise.")
    assert isinstance(result.meta[0], DocstringMeta)
    assert isinstance(result.meta[1], DocstringParam)
    assert isinstance(result.meta[2], DocstringReturns)

# Generated at 2022-06-23 17:09:31.771905
# Unit test for function parse
def test_parse():
    pass

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:09:35.542754
# Unit test for constructor of class Section
def test_Section():
    info = Section("Title", "key", SectionType.SINGULAR)
    assert info.title == "Title"
    assert info.key == "key"
    assert info.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:09:38.815732
# Unit test for constructor of class Section
def test_Section():
    sections = Section("Arguments", "param", SectionType.MULTIPLE)
    assert sections.title == "Arguments"
    assert sections.key == "param"
    assert sections.type == SectionType.MULTIPLE



# Generated at 2022-06-23 17:09:45.397565
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    example = """
    examples:
        >>> a = [1, 2, 3]
        >>> print(a)
        [1, 2, 3]
    """
    expected_example = DocstringMeta(
        args=["examples", ">>> a = [1, 2, 3]\n>>> print(a)\n[1, 2, 3]"],
        description=None,
    )
    expected_result = Docstring(
        short_description=None,
        long_description=None,
        meta=[expected_example],
        blank_after_short_description=None,
        blank_after_long_description=None,
    )

    result = GoogleParser(["examples:"]).parse(example)
    assert result == expected_result


# Generated at 2022-06-23 17:09:49.284334
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key", SectionType.SINGULAR)
    assert section.title == "title"
    assert section.key == "key"
    assert section.type == SectionType.SINGULAR

# Generated at 2022-06-23 17:09:55.011300
# Unit test for function parse
def test_parse():
    """Test parse function."""
    docstr = """
Parse the Google-style docstring into its components.

:returns: parsed docstring
"""
    assert parse(docstr).short_description == "Parse the Google-style docstring into its components."
    assert parse(docstr).long_description == ":returns: parsed docstring"


# Generated at 2022-06-23 17:09:58.179314
# Unit test for function parse
def test_parse():
    try:
        q = parse.__doc__
        print(q)
    except Exception as e:
        print(str(e))


if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:10:03.608887
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    print(section.title)
    print(section.key)
    print(section.type)
    print()


# Generated at 2022-06-23 17:10:07.655799
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """\
        This is a description of a function.
        
          def function(arg1, arg2):
        """
    result = parser.parse(text)
    #   print(result)
    assert result is not None

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:10:14.812236
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """To test the parse method of GoogleParser class.
    """

# Generated at 2022-06-23 17:10:23.617790
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """Example:
    my_func(10)

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.
    """

    result = GoogleParser().parse(text)
    assert result.short_description == "Example:"
    assert result.long_description == "my_func(10)"
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False

    param1 = result.meta[0]
    assert param1.description == "The first parameter."
    assert param1.arg_name == "param1"
    assert param1.type_name == "int"
    assert param1.is_optional == False
    assert param1.default == None

    param2 = result.meta[1]

# Generated at 2022-06-23 17:10:27.403092
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    s = Section("Test", "test", SectionType.SINGULAR)
    p.add_section(s)
    assert p.sections["Test"] == s
    return

# Generated at 2022-06-23 17:10:34.635373
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = """The quick brown fox jumps over the lazy dog.

The quick brown fox jumps over the lazy dog.

Arguments:
    var1 (str): variable 1
    var2 (str): variable 2
    var3 (str): variable 3

Example:
    line 1
    line 2

Example:
    line 4
    line 5

Return:
    str: the result
"""
    docstring = GoogleParser().parse(docstr)
    docstring.short_description
    docstring.long_description
    docstring.blank_after_short_description
    docstring.blank_after_long_description

# Generated at 2022-06-23 17:10:43.968219
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing method parse")

# Generated at 2022-06-23 17:10:49.718698
# Unit test for constructor of class Section
def test_Section():
    test_title = "Arguments"
    test_key = "param"
    test_type = SectionType.MULTIPLE
    test_section = Section(test_title, test_key, test_type)
    assert test_section.title == test_title
    assert test_section.key == test_key
    assert test_section.type == test_type

# Generated at 2022-06-23 17:10:52.378198
# Unit test for constructor of class Section
def test_Section():
    sec = Section("section", "section", "section")
    assert sec.title == "section"
    assert sec.key == "section"
    assert sec.type == "section"

# Generated at 2022-06-23 17:11:01.612197
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pp = GoogleParser()

# Generated at 2022-06-23 17:11:09.697247
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    my_section = Section("Foo", "foo", SectionType.SINGULAR)
    my_text = "Foo: my_text"
    my_parser = GoogleParser()
    my_parser.add_section(my_section)
    my_result = my_parser.parse(my_text)
    assert my_result.meta[0].args[0] == "foo"


# Generated at 2022-06-23 17:11:12.890548
# Unit test for constructor of class Section
def test_Section():
    foo = Section("a", "b", SectionType.MULTIPLE)
    assert foo.title == "a"
    assert foo.key == "b"
    assert foo.type == SectionType.MULTIPLE

# Generated at 2022-06-23 17:11:22.203746
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    stack_sections = list()
    stack_sections.append(Section("Section", "section", SectionType.SINGULAR))
    stack_sections.append(Section("Sections", "sections", SectionType.MULTIPLE))
    parser = GoogleParser(stack_sections)
    assert parser.sections is not None
    assert len(parser.sections) == 2
    assert parser.sections.get("section") is not None
    assert parser.sections.get("sections") is not None

    new_section = Section("New Section", "new_section", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(new_section)
    assert parser.sections is not None
    assert len(parser.sections) == 3
    assert parser.sections.get("new_section") is not None



# Generated at 2022-06-23 17:11:27.284878
# Unit test for constructor of class Section
def test_Section():
    title = "section_title"
    key = "section_key"
    type = SectionType.SINGULAR
    section = Section(title,key,type)
    assert section.title == title
    assert section.key == key
    assert section.type == type


# Generated at 2022-06-23 17:11:39.276291
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    # test_google_parser_parse_with_google_docstring_type
    assert google_parser.parse("""A simple docstring.""") == Docstring(short_description='A simple docstring.')
    
    # test_google_parser_parse_with_google_docstring_parameters
    assert google_parser.parse("""Params:
    x: The value of x.""") == Docstring(short_description=None, long_description=None, meta=[DocstringMeta(args=['param', 'x: The value of x.'], description='The value of x.')])
    
    # test_google_parser_parse_with_google_docstring_returns

# Generated at 2022-06-23 17:11:46.321267
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("A", "a", SectionType.SINGULAR))
    assert parser.sections["A"].title == "A"
    assert parser.sections["A"].key == "a"
    assert parser.sections["A"].type == SectionType.SINGULAR
    assert parser.title_colon == True
    assert parser.titles_re.pattern == r"^((A)|(Args)|(Params)|(Raises)|(Attributes)|(Exceptions)|(Example)|(Examples)|(Returns)|(Yields)):[ \t\r\f\v]*$"


# Generated at 2022-06-23 17:11:54.868584
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test if the class GoogleParser could be initialized
    gp = GoogleParser()
    assert gp.sections != None
    assert gp.title_colon != None
    # Test if the class GoogleParser could be initialized with expected values
    sections = DEFAULT_SECTIONS
    title_colon = False
    gp = GoogleParser(sections,title_colon)
    assert gp.sections == sections
    assert gp.title_colon == title_colon
    assert gp.titles_re != None


# Generated at 2022-06-23 17:11:58.297054
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser([Section("Exaples", "examples", SectionType.SINGULAR)])
    expected = {
        "Exaples": Section("Exaples", "examples", SectionType.SINGULAR)
    }
    assert parser.sections == expected


# Generated at 2022-06-23 17:12:11.087619
# Unit test for constructor of class GoogleParser
def test_GoogleParser():

    test_sections = [
        Section("a", "b", SectionType.SINGULAR),
        Section("c", "d", SectionType.MULTIPLE),
        Section("e", "f", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    test_google_parser = GoogleParser(test_sections, title_colon=False)
    assert test_google_parser.sections == {
        "a": Section("a", "b", SectionType.SINGULAR),
        "c": Section("c", "d", SectionType.MULTIPLE),
        "e": Section("e", "f", SectionType.SINGULAR_OR_MULTIPLE),
    }
    assert test_google_parser.title_colon == False
    assert test_google_parser.titles_re == re.comp

# Generated at 2022-06-23 17:12:19.283535
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    assert isinstance(google_parser, GoogleParser)

    text = "Example docstring.\n\nExample of good docstring.\n    >>> print(True)\n\n"
    text += "Examples\n    >>> print(1 + 2)\n    3\n"
    google_parser.parse(text)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:12:20.905378
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser()
    assert isinstance(g, GoogleParser)


# Generated at 2022-06-23 17:12:28.698808
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ret = GoogleParser().parse("   \n \t \n")
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert ret.meta == []

    ret = GoogleParser().parse("Test\n")
    assert ret.short_description == "Test"
    assert ret.long_description is None
    assert ret.blank_after_short_description is True
    assert ret.blank_after_long_description is False
    assert ret.meta == []

    ret = GoogleParser().parse("Test\nLong test\n")
    assert ret.short_description == "Test"
    assert ret.long_description == "Long test"
    assert ret.blank_after_short_description is False

# Generated at 2022-06-23 17:12:32.734233
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Atttributes", "attribute", SectionType.MULTIPLE))
    assert parser.sections["Atttributes"] == Section("Atttributes", "attribute", SectionType.MULTIPLE)

# Generated at 2022-06-23 17:12:45.332437
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test empty docstring
    assert parse("") == Docstring()
    
    # Test only short description
    docstring = parse("short description")
    assert docstring.short_description == "short description"
    assert docstring.long_description == None
    assert docstring.meta == []
    
    # Test short description and long description (with newline before and after long description)
    docstring = parse("short description\n\nlong description")
    assert docstring.short_description == "short description"
    assert docstring.long_description == "long description"
    assert docstring.meta == []
   
    # Test short description and long description (with newline before long description)
    docstring = parse("short description\nlong description")
    assert docstring.short_description == "short description"
    assert docstring.long_description

# Generated at 2022-06-23 17:12:50.934537
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section = Section("Hello", "hello", SectionType.SINGULAR)
    parser = GoogleParser()
    parser.add_section(section)
    assert parser.sections["Hello"].title == "Hello"
    assert parser.sections["Hello"].key == "hello"
    assert parser.sections["Hello"].type == 0


# Generated at 2022-06-23 17:12:57.503457
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Create a parser
    google_parser = GoogleParser()
    # Add a section
    google_parser.add_section(Section("SectionA", "sectiona", SectionType.SINGULAR))
    # Get the titles of the parser
    titles = google_parser.sections.keys()
    # Create the expected result
    expected_result = ['SectionA']
    # If the titles are not the same as the expected result, then throw an assertion error
    assert titles == expected_result


# Generated at 2022-06-23 17:13:06.071794
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = "Main function for training a model.\n\nThe model is trained with\n  the given training data, using the parameters defined by\n  the model itself, or by the tuning object.\n"
    doc = GoogleParser().parse(d)
    assert doc.short_description == "Main function for training a model."
    assert doc.blank_after_short_description == True
    assert doc.long_description == "The model is trained with the given training data, using the parameters defined by the model itself, or by the tuning object."
    assert doc.blank_after_long_description == False
    return 0

# Generated at 2022-06-23 17:13:13.037819
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
Before

Args:
  A: 1
  B: 2
  C: 3

After"""
    doc = parse(text)
    assert doc.meta[0].args == ["args", "A"]
    assert doc.meta[0].description == "1"
    assert doc.meta[1].args == ["args", "B"]
    assert doc.meta[1].description == "2"
    assert doc.meta[2].args == ["args", "C"]
    assert doc.meta[2].description == "3"

    parser = GoogleParser()
    parser.add_section(Section("TITLE", "titles", SectionType.SINGULAR))
    doc = parser.parse(text)
    assert doc.meta[0].args == ["titles"]

# Generated at 2022-06-23 17:13:23.512202
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = GoogleParser().sections
    assert sections['Arguments'].key == 'param'
    assert sections['Args'].key == 'param'
    assert sections['Parameters'].key == 'param'
    assert sections['Params'].key == 'param'
    assert sections['Raises'].key == 'raises'
    assert sections['Exceptions'].key == 'raises'
    assert sections['Except'].key == 'raises'
    assert sections['Attributes'].key == 'attribute'
    assert sections['Example'].key == 'examples'
    assert sections['Examples'].key == 'examples'
    assert sections['Returns'].key == 'returns'
    assert sections['Yields'].key == 'yields'

# Generated at 2022-06-23 17:13:36.153438
# Unit test for function parse

# Generated at 2022-06-23 17:13:44.285773
# Unit test for function parse
def test_parse():
    text1 = '''\
    This function does something useful.

    Args:
        foo (str): foo parameter. Defaults to "bar".
        bar (str): bar parameter.

    Returns:
        str: The return value.
    '''
    doc1 = parse(text1)
    assert doc1.short_description == 'This function does something useful.'
    assert doc1.long_description == '.'
    assert len(doc1.meta) == 3
    assert doc1.meta[0].args == ['param', 'foo (str)']
    assert doc1.meta[0].description == 'foo parameter. Defaults to "bar".'
    assert doc1.meta[0].arg_name == 'foo'
    assert doc1.meta[0].type_name == 'str'

# Generated at 2022-06-23 17:13:55.628587
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse(" ") == Docstring()

    docstring = GoogleParser().parse("Makes a sandwich.")
    assert docstring.short_description == "Makes a sandwich."
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.meta == []

    docstring = GoogleParser().parse("  Makes a sandwich.\n")
    assert docstring.short_description == "Makes a sandwich."
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description

# Generated at 2022-06-23 17:14:04.274665
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section_keywords = {
        "keyword1": Section("keyword1", "section1", SectionType.SINGULAR),
        "keyword2": Section("keyword2", "section2", SectionType.MULTIPLE),
        "keyword3": Section("keyword3", "section3", SectionType.SINGULAR_OR_MULTIPLE),
    }

    parser = GoogleParser()

    assert parser.sections == {}

    for keyword in section_keywords:
        parser.add_section(section_keywords[keyword])
        assert parser.sections == section_keywords



# Generated at 2022-06-23 17:14:12.880852
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
       This is a short description.

       Params:
        a: This is a parameter to the function
        b: This is a second parameter to the function

        Returns:
            Raises:
        Raises:
            TypeError: Always raised.

            Yields:
        Yields:
            TypeError: Always yielded.

        Attributes:
            This is a short description.
        """
    res = GoogleParser().parse(docstring)
    assert res.short_description == 'This is a short description.'
    assert res.blank_after_long_description is True
    assert res.blank_after_short_description is False
    assert res.long_description == ""

# Generated at 2022-06-23 17:14:25.937132
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse
    """
    docstr = """
    This is a test docstring.

    It has 4 paragraphs.
    """
    parsed_docstr = parse(docstr)
    assert parsed_docstr.short_description == "This is a test docstring."
    assert parsed_docstr.blank_after_short_description == False
    assert parsed_docstr.long_description == "It has 4 paragraphs."
    assert parsed_docstr.blank_after_long_description == True

    docstr = """
    This is a test docstring.
    It has 4 paragraphs.
    """
    parsed_docstr = parse(docstr)
    assert parsed_docstr.short_description == "This is a test docstring."
    assert parsed_docstr.blank_after_short_description == False
    assert parsed

# Generated at 2022-06-23 17:14:29.610349
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    import pytest
    p = GoogleParser(title_colon=True)
    with pytest.raises(re.error):
        p.titles_re.search("Params:")
    with pytest.raises(re.error):
        p.titles_re.search("Params :")


# Generated at 2022-06-23 17:14:33.591933
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    sections = google_parser.sections
    assert len(sections) == len(DEFAULT_SECTIONS)
    for section in sections:
        assert sections[section].title == section
        assert sections[section].key == DEFAULT_SECTIONS[section].key
        assert sections[section].type == DEFAULT_SECTIONS[section].type

# Generated at 2022-06-23 17:14:46.070622
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    google_parser.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    google_parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    google_parser.add_section(Section("Parameters", "param", SectionType.MULTIPLE))
    google_parser.add_section(Section("Params", "param", SectionType.MULTIPLE))
    google_parser.add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    google_parser.add_section(Section("Exceptions", "raises", SectionType.MULTIPLE))
    google_parser.add_section(Section("Except", "raises", SectionType.MULTIPLE))
    google_parser.add_section

# Generated at 2022-06-23 17:14:57.898998
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Return", "returns", SectionType.SINGULAR),
    ]
    parser = GoogleParser(sections)
    assert parser.sections["Arguments"].title == "Arguments"
    assert parser.sections["Return"].type == 2
    sections[0] = Section("Args", "param", SectionType.MULTIPLE)
    sections.append(Section('Yields', 'yields', 2))
    parser.add_section(sections[0])
    assert parser.sections["Args"].key == "param"
    assert parser.sections["Yields"].type == 2
    del sections[1]
    del parser.sections["Return"]

# Generated at 2022-06-23 17:15:07.208844
# Unit test for function parse

# Generated at 2022-06-23 17:15:17.894284
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    section = Section("Return", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    parser = GoogleParser([section], True)
    sections = parser.sections
    #sections = parser.parse(
    #    'Arguments\n'
    #    '    arg1 (str): The first argument. Defaults to "foo".\n'
    #    '    arg2 (int): The second argument.\n'
    #    'Raises\n'
    #    '    ValueError: The first argument is greater than the second.\n'
    #    'Returns: The return value.\n'
    #)
    print(sections)


if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:15:27.688330
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Test:
        def __init__(self):
            pass

        def func(self):
            """Short description.

            Long description.

            Args:
                arg1 (str): arg1 description
                arg2 (str): arg2 description
                arg3 (str): arg3 description

            Returns:
                str: return description
            """
            pass

    parsed = parse(Test.func.__doc__)
    assert parsed.short_description == "Short description."
    assert parsed.blank_after_short_description
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 3
    assert parsed.meta[0].type == "param"
    assert parsed.meta[1].type == "param"

# Generated at 2022-06-23 17:15:40.867105
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    assert g.parse("Short description.\n\nLong description.") == Docstring(
        [],
        "Short description.",
        None,
        None,
        True,
        "Long description.",
        True,
        None,
    )
    assert g.parse("Short description.\n\nLong description.\n") == Docstring(
        [],
        "Short description.",
        None,
        None,
        True,
        "Long description.",
        False,
        None,
    )
    assert g.parse("Short description.\n\nLong description.\n\n") == Docstring(
        [],
        "Short description.",
        None,
        None,
        True,
        "Long description.",
        False,
        None,
    )

# Generated at 2022-06-23 17:15:52.921010
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.title_colon

# Generated at 2022-06-23 17:15:56.445225
# Unit test for constructor of class Section
def test_Section():
    s = Section("Title", "key", SectionType.MULTIPLE)
    assert s.title == "Title"
    assert s.key == "key"
    assert s.type == SectionType.MULTIPLE