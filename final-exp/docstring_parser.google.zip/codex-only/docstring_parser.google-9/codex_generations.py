

# Generated at 2022-06-23 17:06:07.013932
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Hello") == Docstring(short_description="Hello")
    assert parse("Hello\n") == Docstring(short_description="Hello")
    assert parse("Hello\n\n") == Docstring(short_description="Hello")
    assert parse("Hello\n\n\n") == Docstring(short_description="Hello")
    assert parse("\nHello\n") == Docstring(short_description="Hello")
    assert parse("\n\nHello\n") == Docstring(short_description="Hello")
    assert parse("\n\n\nHello\n") == Docstring(short_description="Hello")

    assert parse("Hello\nWorld") == Docstring(
        short_description="Hello", long_description="World"
    )

# Generated at 2022-06-23 17:06:18.318485
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # construct a new GoogleParser object
    google_parser = GoogleParser()
    # test case: add a valid new section
    # construct a new Section object
    title = "test_title"
    key = "test_key"
    type = SectionType.SINGULAR
    section = Section(title, key, type)
    # add a section
    google_parser.add_section(section)
    # get the result
    result = google_parser.sections
    # get the expected output
    expected_result = {title: section}
    # check the result
    assert result == expected_result
    # test case: modify a section
    title_1 = "test_title_1"
    key_1 = "test_key_1"
    type_1 = SectionType.SINGULAR_OR_MULTIPLE
    section_

# Generated at 2022-06-23 17:06:30.342883
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:06:42.243696
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", 0)
    assert section.title == "Arguments", "title should be 'Arguments'"
    assert section.key == "param", "key should be 'param'"
    assert section.type == 0, "type should be 0"

    section = Section("Args", "param", 1)
    assert section.title == "Args", "title should be 'Args'"
    assert section.key == "param", "key should be 'param'"
    assert section.type == 1, "type should be 1"

    section = Section("Parameters", "param", 2)
    assert section.title == "Parameters", "title should be 'Parameters'"
    assert section.key == "param", "key should be 'param'"
    assert section.type == 2, "type should be 2"


# Generated at 2022-06-23 17:06:46.279314
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", 2)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == 2

# Generated at 2022-06-23 17:06:56.637662
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = GoogleParser().sections
    assert(len(sections))
    assert('Parameters' in sections)
    sections['Test1'] = Section(title= 'Test1', key='param', type=0)
    assert('Test1' in sections)
    sections['Test2'] = Section(title= 'Test2', key='param', type=2)
    assert('Test2' in sections)
    assert(len(sections) == len(DEFAULT_SECTIONS) + 2)
    sections.pop('Test1')
    assert(len(sections) == len(DEFAULT_SECTIONS) + 1)
    sections.pop('Test2')
    assert(len(sections) == len(DEFAULT_SECTIONS))


# Generated at 2022-06-23 17:07:06.251281
# Unit test for constructor of class Section
def test_Section():
    item = Section("Arguments", "param", 0)
    if not isinstance(item, tuple):
        raise ValueError("%s is not an instance of tuple", type(item))
    if len(item) != 3:
        raise ValueError("%s have wrong length", item)
    if not isinstance(item[0], str):
        raise ValueError("%s is not a string", item[0])
    if not isinstance(item[1], str):
        raise ValueError("%s is not a string", item[1])
    if not isinstance(item[2], int):
        raise ValueError("%s is not an integer", item[2])
    if not isinstance(item, Section):
        raise ValueError("%s is not an instance of Section", type(item))


# Generated at 2022-06-23 17:07:16.465631
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    # Add a new section to the default sections
    parser.add_section(Section("New Section", "new", SectionType.MULTIPLE))
    
    # Test that the section was added
    assert len(parser.sections) == 13
    assert parser.sections["New Section"].key == "new"
    assert parser.sections["New Section"].type == SectionType.MULTIPLE
    assert parser.sections["New Section"].title == "New Section"
    
    # Add the same section again to test if it will replace the old one
    parser.add_section(Section("New Section", "new", SectionType.SINGULAR))
    
    # Test that the section was replaced
    assert len(parser.sections) == 13
    assert parser.sections["New Section"].key == "new"

# Generated at 2022-06-23 17:07:25.553900
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Tests for singular empty
    assert GoogleParser().parse("Some text").short_description == "Some text"
    assert GoogleParser().parse("Some text\n\n").short_description == "Some text"
    assert GoogleParser().parse("Some text\n").short_description == "Some text"
    assert GoogleParser().parse("Some text\n\n\n").short_description == "Some text"
    assert GoogleParser().parse("Some text\n\n").long_description == None

    # Tests for singular with description
    assert GoogleParser().parse("Some text\n\nMore text").long_description == "More text"
    assert GoogleParser().parse("Some text\nMore text").long_description == "More text"
    assert GoogleParser().parse("Some text\n\nMore text\n").long_description == "More text"
   

# Generated at 2022-06-23 17:07:35.775694
# Unit test for function parse
def test_parse():
    docstring = """
    This is the short description.

    This is the long description.

    Args:
        parameters: description
        description: description
            description. Defaults to description.
        other_parameter: description
        other_description: description
        description. Defaults to description.
        final_parameter: description
        final_description: description
            description. Defaults to description.
    Returns:
        returns: description
    Raises:
        KeyError: none
    """

# Generated at 2022-06-23 17:07:36.662469
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert(GoogleParser().sections['Args'].key == 'param')


# Generated at 2022-06-23 17:07:42.520382
# Unit test for constructor of class Section
def test_Section():
    test_title = 'title'
    test_key = 'key'
    test_type = 2
    test_section = Section(test_title, test_key, test_type)
    if test_section.title != test_title or test_section.key != test_key or test_section.type != test_type:
        raise Exception("constructor test failed")
    else:
        print("constructor test passed")


# Generated at 2022-06-23 17:07:50.491208
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    title_colon = True

    google_parser = GoogleParser(title_colon=title_colon)

    docstring = """
        Sums two numbers.

        :param arg1: The first number.
        :type arg1: int
        :param arg2: The second number.
        :type arg2: int
        :returns: The sum of the two numbers.
        :rtype: int
    """
    result = google_parser.parse(docstring)

    assert result.short_description == 'Sums two numbers.'
    assert result.long_description == ''
    assert len(result.meta) == 3
    assert result.meta[0].args == ('param', 'arg1')
    assert result.meta[1].args == ('param', 'arg2')

# Generated at 2022-06-23 17:07:54.001201
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Param", "param", SectionType.MULTIPLE)
    parser.add_section(section)

# Generated at 2022-06-23 17:08:05.338766
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "A short description.\n\n"
    text += "A long description.\n"
    text += "\n"
    text += "Args:\n"
    text += "    arg1 (str): The first argument.\n"
    text += "    arg2 (int): The second argument.\n"
    text += "    arg3 (bool): The third argument.\n"
    text += "\n"
    text += "Raises:\n"
    text += "    ValueError: If `arg2` is equal to `arg3`.\n"
    text += "\n"
    text += "Returns:\n"
    text += "    str: The return value.\n"
    text += "\n"
    text += "Example:\n"
    text += "        >>> func(42)\n"
    text

# Generated at 2022-06-23 17:08:16.625204
# Unit test for function parse
def test_parse():
    docstring = """Google-style docstring parsing.

:param text: The text to parse.
:param keys: A mapping of keys to values to be replaced.

:returns: The parsed text.
:rtype: str
"""
    parsed = parse(docstring)
    assert parsed.short_description == 'Google-style docstring parsing.'
    assert parsed.blank_after_short_description
    assert parsed.long_description == ""
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 2
    assert parsed.meta[0].args == ['param', 'text']
    assert parsed.meta[0].arg_name == 'text'
    assert parsed.meta[0].description == 'The text to parse.'
    assert parsed.meta[0].type_name is None
    assert parsed.meta

# Generated at 2022-06-23 17:08:21.023339
# Unit test for constructor of class Section
def test_Section():
    section = Section("Args", "param", 2)
    assert section.title == "Args"
    assert section.key == "param"
    assert section.type == 2

# Generated at 2022-06-23 17:08:31.852439
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Summary line.
    Extended summary.

    Args:
        arg1(bool): Description of arg1.
        arg2(str): Description of arg2.
        arg3(List[str]): Description of arg3
        arg4(List[str], optional): Description of arg4.
        arg5(List[str]?, optional): Description of arg5.
        kwarg1: Description of kwarg1.
        kwarg2(str, optional): Description of kwarg2.
        kwarg3(int, optional): Description of kwarg3.
        kwarg4(bool). Defaults to True. Description of kwarg4.
    """
    doc = parse(text)
    assert len(doc.meta) == 10

# Generated at 2022-06-23 17:08:43.122696
# Unit test for constructor of class Section
def test_Section():
    section = Section('Arguments', 'param', SectionType.MULTIPLE)
    assert section.title == 'Arguments'
    assert section.key == 'param'
    assert section.type == SectionType.MULTIPLE
    section = Section('Args', 'param', SectionType.MULTIPLE)
    assert section.title == 'Args'
    assert section.key == 'param'
    assert section.type == SectionType.MULTIPLE
    section = Section('Parameters', 'param', SectionType.MULTIPLE)
    assert section.title == 'Parameters'
    assert section.key == 'param'
    assert section.type == SectionType.MULTIPLE
    section = Section('Params', 'param', SectionType.MULTIPLE)
    assert section.title == 'Params'

# Generated at 2022-06-23 17:08:49.641759
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Other", "other", SectionType.SINGULAR))
    text = """
    Other: I write something
    """
    docstring = parser.parse(text)
    assert docstring.meta[0].args == ["other"]
    assert docstring.meta[0].description == "I write something"

# Generated at 2022-06-23 17:08:57.768311
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    def assert_ret(text: str, result: Docstring):
        if GoogleParser().parse(text) != result:
            raise Exception(GoogleParser().parse(text))
        else:
            pass

    def assert_exception(text: str):
        try:
            GoogleParser().parse(text)
        except:
            pass
        else:
            raise Exception(GoogleParser().parse(text))

    # Testcase 1
    text = "Docstring desc"
    result = Docstring(
        short_description="Docstring desc",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert_ret(text, result)

    # Testcase 2

# Generated at 2022-06-23 17:09:04.584834
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    formatter = GoogleParser()
    formatter._build_meta('param ~ast.AST\n        tree', 'Args')
    formatter._build_meta('param ~collections.abc.Hashable key\n        Key.', 'Params')
    formatter._build_meta('example\n        >>> print(unparse(parse("x=1")))', 'Example')
    formatter._build_meta('returns int\n        Something', 'Returns')
    formatter._build_meta('yields int\n        Something', 'Yields')



# Generated at 2022-06-23 17:09:13.788742
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # For method parse
    # Case 1 :
    print("\nCase 1 :\n")
    text1 = """
    Google-style docstring parsing.

    Args:
       param1(int):  a parameter
       b(float):
       param3:  another parameter
       param3(str):  another parameter

    Returns:
       None
    """
    print(GoogleParser().parse(text1))

    # Case 2 :
    print("\nCase 2 :\n")
    text2 = """

    Args:
       param1(int):  a parameter
       b(float):
       param3:  another parameter
       param3(str):  another parameter

    Returns:
       None

    """
    print(GoogleParser().parse(text2))

    # Case 3 :

# Generated at 2022-06-23 17:09:25.369437
# Unit test for function parse
def test_parse():
    """Test parse()"""
    from .napoleon import parse as napoleon_parse
    
    docstrings = [
        """Test function for doc string parsing.

        This function does absolutely nothing.

        Arguments:
            argument1: The first argument.
            argument2: The second argument.

        Returns:
            str: The return value. True for success, False otherwise.

        """
    ]
    for docstring in docstrings:
        print(docstring)
        
        print("-----------")
        print("GoogleParser")
        gp = GoogleParser()
        gp.parse(docstring)
        print(gp.parse(docstring))
        
        print("-----------")
        print("napoleon.parse")
        napoleon_parse(docstring)
        print(napoleon_parse(docstring))
        

# Generated at 2022-06-23 17:09:37.560486
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    custom_sections = [
        Section("Arg", "param", SectionType.MULTIPLE),
        Section("Return", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    # Test docstring without position and without any section
    text_1 = """
        One-line summary.
        
        Args:
            s: Argument.
        
        Returns:
            Empty.
    """
    parser_1 = GoogleParser(custom_sections)
    parser_1.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    result_1 = parser_1.parse(text_1)
    assert result_1.short_description == "One-line summary"
    assert result_1.blank_after_short_description

# Generated at 2022-06-23 17:09:39.513502
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test for call the constructor of class GoogleParser
    if GoogleParser():
        assert True
    else:
        assert False



# Generated at 2022-06-23 17:09:42.665387
# Unit test for function parse
def test_parse():
    text = """Return x + 1.
    
    :param int x: Value to increment.
    :return: Incremented value
    :rtype: int
    """

    print(parse(text))



# Generated at 2022-06-23 17:09:49.453205
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    input_section = Section("Hello", "hi", SectionType.MULTIPLE)
    asn = GoogleParser()
    asn.add_section(input_section)
    answer = asn.sections["Hello"]
    assert (answer.title == "Hello" and answer.key == "hi" and answer.type == 1)


# Generated at 2022-06-23 17:09:59.525408
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = DEFAULT_SECTIONS
    sections.append(Section("TestSection1", "test1", SectionType.MULTIPLE))
    sections.append(Section("TestSection2", "test2", SectionType.MULTIPLE))
    parser = GoogleParser(sections)

# Generated at 2022-06-23 17:10:00.982730
# Unit test for function parse
def test_parse():
    pass

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:10:10.476721
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import to_docstring
    from .common import to_dict
    from .common import assert_docstrings_equal
    do_nothing = lambda text: text
    to_str = lambda s: s.strip()

# Generated at 2022-06-23 17:10:11.761476
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    return


# Generated at 2022-06-23 17:10:14.288217
# Unit test for constructor of class Section
def test_Section():
    print(Section("title", "key", SectionType.MULTIPLE))



# Generated at 2022-06-23 17:10:23.343919
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

# Generated at 2022-06-23 17:10:29.101877
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstr = """
        This is summary.

        This is description.

        Args:
            arg1: description of arg1.
            arg2 (str): description of arg2.
        Returns:
            description of return value.
        """
    print(parser.parse(docstr))


# Generated at 2022-06-23 17:10:38.201282
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    First line.

    Long description.

    Args:
        arg1 (str): Description.
        arg2 (int): Description.

    Returns:
        str: Description.
    """

    # The docstring is parsed into the components
    googlep = GoogleParser()
    result = googlep.parse(text)
    assert result.short_description == "First line."
    assert result.long_description == "Long description."
    assert result.meta[0].args[0] == "param"
    assert result.meta[0].args[1] == "arg1 (str)"
    assert result.meta[0].arg_name == "arg1"
    assert result.meta[0].type_name == "str"
    assert result.meta[0].description == "Description."

# Generated at 2022-06-23 17:10:47.972131
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE),
                Section("Args", "param", SectionType.MULTIPLE),
                ]
    title_colon = True
    obj1 = GoogleParser(sections)
    obj2 = GoogleParser(sections, title_colon)
    # Check that obj1 and obj2 have the same value
    assert obj1.sections == obj2.sections
    assert obj1.title_colon == obj2.title_colon



# Generated at 2022-06-23 17:10:58.013977
# Unit test for function parse
def test_parse():
    docstring = """Foo bar baz.

Attribute:
    attr1: Attribute 1.
    attr2: Attribute 2.
    attr3: Attribute 3.

Args:
    arg1: Argument 1.
    arg2: Argument 2.
    arg3: Argument 3.

Raises:
    ValueError: if something goes wrong.

Returns:
    None

Yields:
    str: a unit
    str: another unit

Examples:
    >>> say_hello()
    Hello, World!

    >>> say_hello('Python')
    Hello, Python!
"""

    d = parse(docstring)

    assert d.short_description == "Foo bar baz."

# Generated at 2022-06-23 17:11:02.857212
# Unit test for function parse
def test_parse():
    def method():
        """TODO: Documentation

        Example:
            # Here is a usage example

            method()
            >>> 1+1
            2

        Returns:
            A function which returns True.
        """

    docstring = parse(inspect.getdoc(method))
    print(docstring)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:11:06.536009
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:11:11.125375
# Unit test for constructor of class Section
def test_Section():
    sec = Section("arguments", "param", 1)
    assert sec.title == "arguments"
    assert sec.key == "param"
    assert sec.type == 1


# Generated at 2022-06-23 17:11:21.312169
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert (
        GoogleParser().parse(
            """
        Short description.

        Long description.
        """
        )
        == Docstring(
            short_description="Short description.",
            long_description="Long description.",
            blank_after_short_description=True,
            blank_after_long_description=False,
            meta=[],
        )
    )

# Generated at 2022-06-23 17:11:33.996500
# Unit test for function parse
def test_parse():
    def _test(string):
        print(string)
        docstring = parse(string)
        print(docstring)

    _test(
        'This function does something.\n\nArgs:\n'
        '    a: description of a\n    b: description of b\n'
    )
    _test(
        'This function does something.\n\nArgs:\n'
        '    a: description of a\n    b: description of b\n    '
    )
    _test(
        'This function does something.\n\nArgs:\n'
        '    a: description of a\n    b: description of b\n\n'
    )

# Generated at 2022-06-23 17:11:43.901277
# Unit test for function parse
def test_parse():
    assert parse('') == Docstring()
    assert parse('short\nlong') == Docstring(
        short_description='short',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description='long',
        meta=[]
    )
    assert parse('short\n\nlong') == Docstring(
        short_description='short',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description='long',
        meta=[]
    )

# Generated at 2022-06-23 17:11:56.289418
# Unit test for constructor of class Section
def test_Section():
    assert Section("title", "key", SectionType.SINGULAR) == Section("title", "key", SectionType.SINGULAR)
    assert Section("title", "key", SectionType.SINGULAR) != Section("title2", "key", SectionType.SINGULAR)
    assert Section("title", "key", SectionType.SINGULAR) != Section("title", "key2", SectionType.SINGULAR)
    assert Section("title", "key", SectionType.SINGULAR) != Section("title", "key", SectionType.MULTIPLE)
    assert Section("title", "key", SectionType.SINGULAR) != Section("title", "key", SectionType.SINGULAR_OR_MULTIPLE)

# Generated at 2022-06-23 17:12:09.625175
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    class CustomerParser(GoogleParser):
        def __init__(self):
            GoogleParser.__init__(self)

    parser = CustomerParser()
    parser.add_section(Section("New_Keyword", "new_keyword", SectionType.SINGULAR))

    assert parser._build_single_meta(parser.sections["New_Keyword"], "hello") == DocstringMeta(
        ["new_keyword"], "hello"
    )
    assert parser._build_multi_meta(parser.sections["New_Keyword"], "hello", None) == DocstringMeta(
        ["new_keyword", "hello"], None
    )
    assert parser.parse("New_Keyword: hello")

# Generated at 2022-06-23 17:12:22.388558
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:12:34.145582
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    a = GoogleParser()
    assert a.title_colon == True

# Generated at 2022-06-23 17:12:37.720501
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser()
    assert len(g.sections) == 14
    assert g.sections["Arguments"].title == "Arguments"

# Generated at 2022-06-23 17:12:41.410882
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Title", "key", SectionType.SINGULAR))
    assert parser.sections == {"Title": Section("Title", "key", SectionType.SINGULAR)}

# Generated at 2022-06-23 17:12:50.922657
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    try:
        GoogleParser().parse("A module-level docstring")
    except ParseError as error:
        pass
    else:
        assert False, "Construction without sections should fail"
    try:
        GoogleParser(sections = [
            Section("Arguments", "param", SectionType.SINGULAR),
            Section("Raises", "raises", SectionType.SINGULAR),
            Section("Returns", "returns", SectionType.SINGULAR),
        ]).parse("Raises:\nNot enough arguments")
    except ParseError as error:
        pass
    else:
        assert False, "Construction with argument as single should fail"

# Generated at 2022-06-23 17:12:58.136256
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_string = """Convert a tensor from Cartesian coordinates to equatorial coordinates.
    Args:
      tensor: A `Tensor` with shape [..., 3] in Cartesian coordinates.
      name: A name for this operation (optional).
    Returns:
      A `Tensor` with the same type and shape as `tensor`.
    """
    d = GoogleParser().parse(doc_string)
    #print(d)
    return d

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:13:02.800150
# Unit test for constructor of class Section
def test_Section():
    title = "Title"
    key = "key"
    type = SectionType.MULTIPLE
    section = Section(title, key, type)
    assert section.title == title
    assert section.key == key
    assert section.type == type


# Generated at 2022-06-23 17:13:08.675389
# Unit test for constructor of class Section
def test_Section():
    s = Section(title="Raises", key="raises", type=SectionType.MULTIPLE)
    assert s.title == "Raises"
    assert s.key == "raises"
    assert s.type == SectionType.MULTIPLE
    assert s[0] == "Raises"
    assert s[1] == "raises"
    assert s[2] == SectionType.MULTIPLE
    with pytest.raises(IndexError):
        s[3]


# Generated at 2022-06-23 17:13:15.958713
# Unit test for function parse
def test_parse():
    test_text = """A google docstring parser.

Args:
    text (str): The text to parse

Returns:
    a (DocString)
    b (str): The first line of the text."""

    docstring = parse(test_text)
    assert docstring.short_description is not None
    assert docstring.long_description is None
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "text (str)"]
    assert docstring.meta[0].arg_name == "text"
    assert docstring.meta[0].type_name == "str"
    assert not docstring.meta[0].is_optional
    assert docstring.meta[1].args == ["returns", "a (DocString)"]

# Generated at 2022-06-23 17:13:25.632370
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:13:37.455612
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:13:42.641997
# Unit test for constructor of class Section
def test_Section():
    section_test = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE



# Generated at 2022-06-23 17:13:54.364235
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()

# Generated at 2022-06-23 17:13:57.169053
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # construct a GoogleParser object
    googleParser = GoogleParser()
    assert googleParser.parse("") == Docstring()


# Generated at 2022-06-23 17:13:59.139329
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 17:14:08.681200
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("SECTION_ONE", "PARAM_ONE", SectionType.MULTIPLE),
        Section("SECTION_TWO", "PARAM_TWO", SectionType.MULTIPLE)
    ]
    G1 = GoogleParser(sections)
    G2 = GoogleParser(title_colon=False)
    G3 = GoogleParser()
    assert G1.sections.keys() == sections[0].title.lower() and sections[1].title.lower()
    assert isinstance(G1, GoogleParser)
    assert isinstance(G2, GoogleParser)
    assert isinstance(G3, GoogleParser)
    assert G2.title_colon == False
    assert G3.title_colon == True


# Generated at 2022-06-23 17:14:21.474490
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

    new_section = Section("Section", "section", SectionType.SINGULAR)
    parser.add_section(new_section)

    new_section = Section("Section", "section", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(new_section)

    new_section = Section("Section", "section", SectionType.MULTIPLE)
    parser.add_section(new_section)

    assert("Section" in parser.sections)



# Generated at 2022-06-23 17:14:25.753299
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    stack_section = Section("stack", "stack", SectionType.SINGULAR)
    g.add_section(stack_section)
    assert g.sections["stack"] == stack_section


# Generated at 2022-06-23 17:14:26.348840
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-23 17:14:32.609773
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    google_parser.add_section(Section("Test", "test", SectionType.SINGULAR))
    assert google_parser.sections == {'Test': Section("Test", "test", SectionType.SINGULAR)}
    google_parser.add_section(Section("Title", "title", SectionType.MULTIPLE))
    assert google_parser.sections == {'Test': Section("Test", "title", SectionType.SINGULAR), 'Title': Section("Title", "title", SectionType.MULTIPLE)}
    assert google_parser.title_colon == True
    google_parser = GoogleParser(title_colon = False)
    assert google_parser.title_colon == False
    assert google_parser.sections == {s.title: s for s in DEFAULT_SECTIONS}

#

# Generated at 2022-06-23 17:14:45.648190
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    '''
    Example usage of GoogleParser.parse() that works on Python 3.6+

    This method is just a unit test, no need to run it
    '''

# Generated at 2022-06-23 17:14:57.491291
# Unit test for function parse
def test_parse():
    func = """
        Compute the inverse of a square matrix.

        Parameters
        ----------
        a : (M, M) array_like
            Matrix to be inverted.
        overwrite_a : bool, optional
            Allow overwriting data in a (may improve performance)

        Returns
        -------
        ainv : (M, M) ndarray or matrix
            Inverse of the matrix a.
        """

    expected_description = """Compute the inverse of a square matrix."""
    func_description = parse(func).short_description
    assert func_description == expected_description, 'short description error'


# Generated at 2022-06-23 17:15:01.434513
# Unit test for constructor of class Section
def test_Section():
    section = Section("Title", "key", SectionType.SINGULAR)
    assert section.title == "Title"
    assert section.key == "key"
    assert section.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:15:05.816419
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    def test_GoogleParser_sections(sections: T.Optional[T.List[Section]]):
        if not sections:
            sections = DEFAULT_SECTIONS
        s = GoogleParser(sections)
        assert s.sections == {s.title: s for s in sections}

    test_GoogleParser_sections([])
    test_GoogleParser_sections(None)


# Generated at 2022-06-23 17:15:14.248240
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section1 = Section(title="section1", key="section1", type=SectionType.MULTIPLE)
    section2 = Section(title="section2", key="section2", type=SectionType.MULTIPLE)
    googleParser = GoogleParser()
    googleParser.add_section(section1)
    googleParser.add_section(section2)
    assert googleParser.sections["section1"] == section1
    assert googleParser.sections["section2"] == section2


# Generated at 2022-06-23 17:15:17.881246
# Unit test for constructor of class Section
def test_Section():
    sec = Section("a", "b", 0)
    assert(sec.title == "a")
    assert(sec.key == "b")
    assert(sec.type == 0)


# Generated at 2022-06-23 17:15:27.688508
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    :return:
    """
    # A standard class docstring with examples
    text1 = """
    This is a module-level docstring.

    This is the long description. It may contain multiple paragraphs. There
    should be a blank line separating each paragraph. The first sentence
    should not end with a period.
    
    Attributes
    ----------
    attr1 : float, optional
        Description of attr1.
        Default value is 2.
    attr2 : float
        Description of attr2

    Returns
    -------
    int
        Description of return value.
    """

    result1 = GoogleParser().parse(text1)

# Generated at 2022-06-23 17:15:40.867302
# Unit test for function parse
def test_parse():
    assert parse("test").short_description == "test"
    assert parse("test\n\n").short_description == "test"
    assert parse("test\n").short_description == "test"
    assert parse("test\n  more").short_description == "test"
    assert parse("test\n  more\n").short_description == "test"
    assert parse("test\n  \n").short_description == "test"
    assert parse("test\n\n  more").long_description == "more"
    assert parse("test\n\n  more").blank_after_short_description
    assert parse("test\n\n  more\n").long_description == "more"
    assert parse("test\n\n  more\n").blank_after_short_description

# Generated at 2022-06-23 17:15:52.920596
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """Test the constructor of GoogleParser"""
    # Test default parameter of class GoogleParser
    gp = GoogleParser()

# Generated at 2022-06-23 17:16:01.996635
# Unit test for function parse
def test_parse():
    def test_func():
        """Test function.

        :param x: an integer
        :param y: a float
        :return: x + y
        """
        pass
