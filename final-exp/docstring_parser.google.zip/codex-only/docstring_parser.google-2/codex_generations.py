

# Generated at 2022-06-23 17:05:57.628330
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleParser = GoogleParser()
    assert isinstance(googleParser, GoogleParser)

# Generated at 2022-06-23 17:05:59.320196
# Unit test for function parse
def test_parse():
    # TODO
    pass


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:06:06.861611
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(TypeError):
        Section(1, 2, 3)
    with pytest.raises(ValueError):
        Section("title", "key", "type")
    with pytest.raises(ValueError):
        Section("title", "key", 3)
    with pytest.raises(ValueError):
        Section("title", "key", -1)
    with pytest.raises(TypeError):
        Section("title", "key", SectionType.MULTIPLE)
    with pytest.raises(TypeError):
        Section("title", "key", SectionType.SINGULAR)
    section = Section("title", "key", SectionType.SINGULAR_OR_MULTIPLE)
    assert section.title == "title"
    assert section.key == "key"

# Generated at 2022-06-23 17:06:14.655023
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    text = "Args:\n"
    match = parser.titles_re.search(text)
    assert match
    assert match.group(1) == "Args"


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    test_GoogleParser_add_section()

# Generated at 2022-06-23 17:06:27.036155
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # method signature
    # GoogleParser.parse(text: str) -> Docstring:
    google = GoogleParser()
    docstring = google.parse("Get the square root of x.\n\nArgs:\n  x: The number for which the square root is to be computed.\n\nReturns:\n  float: The square root of x.")
    # assert return type
    assert isinstance(docstring, Docstring)
    # test attributes of return type
    assert docstring.short_description == "Get the square root of x."
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == None
    assert docstring.meta[0].args == ['param', 'x']

# Generated at 2022-06-23 17:06:37.500989
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert gp.sections[0].title == "Arguments"
    assert gp.sections[1].title == "Args"
    assert gp.sections[2].title == "Parameters"
    assert gp.sections[3].title == "Params"
    assert gp.sections[4].title == "Raises"
    assert gp.sections[5].title == "Exceptions"
    assert gp.sections[6].title == "Except"
    assert gp.sections[7].title == "Attributes"
    assert gp.sections[8].title == "Example"
    assert gp.sections[9].title == "Examples"
    assert gp.sections[10].title == "Returns"
    assert gp.sections[11].title == "Yields"


# Generated at 2022-06-23 17:06:45.360404
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(TypeError):
        Section(title=7,key="param",type=0)
    with pytest.raises(TypeError):
        Section(title="",key="param",type=0)
    with pytest.raises(TypeError):
        Section(title="t",key="",type=0)
    with pytest.raises(TypeError):
        Section(title="t",key="param",type="")
    with pytest.raises(TypeError):
        Section(title="t",key="param",type=0)
    with pytest.raises(TypeError):
        Section(title="t",key="param",type=0)
    with pytest.raises(TypeError):
        Section(title="t",type=0)

# Generated at 2022-06-23 17:06:56.405422
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    def func(x: int, y: int) -> int:
        """Return the sum of x and y.

        :type x: int
        :param x: first number
        :type y: int
        :param y: second number
        :return: sum of x and y
        """
        return x + y

    doc = inspect.getdoc(func)
    if doc is None:
        doc = ""
    print(doc)
    gp = GoogleParser()
    gp.add_section(Section("Return", "returns", SectionType.SINGULAR))
    gp.add_section(Section("Param", "params", SectionType.MULTIPLE))
    doc_parsed = gp.parse(doc)
    print(doc_parsed)

# Generated at 2022-06-23 17:07:06.093395
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section_title = 'Greeting'
    section_key = 'greeting'
    section_type = SectionType.SINGULAR

    section = Section(section_title, section_key, section_type)
    parser.sections[section.title] = section

    def test_func():
        """Greeting: Hello world!

        :param name: the name
        """
        pass

# Generated at 2022-06-23 17:07:13.841231
# Unit test for function parse
def test_parse():
    def test():
        """Short description.

        Subsequent paragraph of function's long description.

        Args:
            arg1: Description of arg1
            arg2: Description of arg2

        Returns:
            Description of return value
        """
        pass

    text = inspect.getdoc(test)
    doc = parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == """\
Subsequent paragraph of function's long description.
"""
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "Description of arg1"

# Generated at 2022-06-23 17:07:16.874099
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    test_GoogleParser = GoogleParser()
    test_GoogleParser.add_section(Section("asd", "asd", SectionType.MULTIPLE))
    assert (test_GoogleParser.sections["asd"] == Section("asd", "asd", SectionType.MULTIPLE))

# Generated at 2022-06-23 17:07:20.116129
# Unit test for constructor of class Section
def test_Section():
    s = Section("Test", "test", SectionType.SINGULAR)
    assert s.title == "Test"
    assert s.key == "test"
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:07:21.331600
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()


# Generated at 2022-06-23 17:07:29.979050
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
        Short description.
        
        Long description.
        
        Args:
            First arg (str): Description of first arg.
            Second arg (int): Description of second arg.
        
        Returns (str): Description of return value.
    '''
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 3
    assert doc.meta[0].arg_name == "First arg"
    assert doc.meta[0].type_name == "str"
    assert doc.meta[0].description == "Description of first arg."
    assert doc.meta[1].arg_name == "Second arg"
    assert doc.meta[1].type_name == "int"


# Generated at 2022-06-23 17:07:40.325697
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("A.") == Docstring(
        short_description="A.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("A.\n") == Docstring(
        short_description="A.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("A.\n\n") == Docstring(
        short_description="A.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

# Generated at 2022-06-23 17:07:41.245165
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()



# Generated at 2022-06-23 17:07:49.666663
# Unit test for function parse
def test_parse():
    class A:
        """A class.

        Args:
            a: A
            b: B

        Raises:
            ValueError: If c is not a string.

        Returns:
            str: A nicely formatted string.
        """

        def __init__(self, a: str, b: int):
            pass

        def method(self, c: T.Union[int, float]) -> None:
            """Do something.

            Args:
                c: c.

            Raises:
                ValueError: c is not valid.
            """
            pass


# Generated at 2022-06-23 17:07:53.311314
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    import doctest
    doctest.run_docstring_examples(p.parse, globals(), name='parse')

# Generated at 2022-06-23 17:08:00.378995
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

    # Test adding new section
    section = Section("Arguments new", "param", SectionType.MULTIPLE)
    parser.add_section(section)
    assert parser.sections['Arguments new'] == section

    # Test updating existing section
    section = Section("Arguments", "param new", SectionType.SINGULAR)
    parser.add_section(section)
    assert parser.sections['Arguments'] == section


# Generated at 2022-06-23 17:08:01.789322
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sp = GoogleParser()
    assert sp.title_colon == True

# Generated at 2022-06-23 17:08:14.219621
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    #Test for adding new section for GoogleParser
    #Test case for input
    section_input = Section("Running_Time","Running_Time",SectionType.SINGULAR)
    #Test case for output
    output_expected = "Running_Time"

    #Test case with predifined list of sections and colon
    parser1 = GoogleParser()

    #Test case with userdefined list of sections and colon
    parser2 = GoogleParser([section_input])

    #Test case with userdefined list of sections and no colon
    parser3 = GoogleParser([section_input],False)

    #Test case with default list of sections and colon
    parser4 = GoogleParser(DEFAULT_SECTIONS)

    #Test case with default list of sections and no colon
    parser5 = GoogleParser(DEFAULT_SECTIONS,False)

    #Test cases for the return value

# Generated at 2022-06-23 17:08:27.017169
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """Test constructor of class GoogleParser"""


# Generated at 2022-06-23 17:08:27.576628
# Unit test for constructor of class Section
def test_Section():
    pass


# Generated at 2022-06-23 17:08:39.900160
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:08:42.253534
# Unit test for constructor of class Section
def test_Section():
    S = Section("Title", "KeyName", 0)
    assert S.title == "Title"
    assert S.key == "KeyName"
    assert S.type == 0


# Generated at 2022-06-23 17:08:54.565719
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    This function tests the method add_section of class GoogleParser.
    """
    parser = GoogleParser()
    if parser.sections.__contains__("Returns"):
        raise Exception(
            "Default section title \"Returns\" not found in parser.sections."
        )
    if parser.sections.__contains__("Ret"):
        raise Exception("Default section title \"Ret\" not found in parser.sections.")
    ret_title = "Returns"
    section = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(section)
    if not parser.sections.__contains__("Returns"):
        raise Exception(
            "Default section title \"Returns\" found in parser.sections."
        )
    parser = GoogleParser()
    ret_title = "Ret"

# Generated at 2022-06-23 17:09:06.911637
# Unit test for function parse
def test_parse():
    import os
    import sys
    import unittest

    if sys.version_info.major < 3:
        import __builtin__ as builtins
    else:
        import builtins

    from .common import DocstringMeta, DocstringParam, DocstringRaises
    from .common import DocstringReturns, Docstring, ParseError

    # Unit test class

# Generated at 2022-06-23 17:09:13.753161
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    p.add_section(Section("Warning", "warning", SectionType.SINGULAR_OR_MULTIPLE))
    n = p.parse(
        """
    Short D
    Long D

    Warning:
        Warning D1
        Warning D2
    """
    )

    assert len(n.meta) == 2
    assert n.meta[0].args == ["warning", "Warning D1"]
    assert n.meta[0].description == "Warning D1"
    assert n.meta[1].args == ["warning", "Warning D2"]
    assert n.meta[1].description == "Warning D2"

# Generated at 2022-06-23 17:09:21.955299
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test method parse of class GoogleParser"""
    google_parser = GoogleParser()
    test_doc = '''
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    '''
    try:
        assert google_parser.parse(test_doc)
        assert google_parser.parse('')
    except AssertionError:
        print("Test case test_GoogleParser_parse failed")
        return
    print("Test case test_GoogleParser_parse succeded")


# Generated at 2022-06-23 17:09:23.494796
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert len(GoogleParser().sections) == len(DEFAULT_SECTIONS)


# Generated at 2022-06-23 17:09:26.927737
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    schema = GoogleParser()
    schema.add_section(Section('Added title', 'added-title', SectionType.MULTIPLE))
    assert 'Added title' in schema.sections.keys() and len(schema.sections) == len(DEFAULT_SECTIONS)+1

# Generated at 2022-06-23 17:09:28.944821
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert(GoogleParser().sections['Args'].title == 'Args')


# Generated at 2022-06-23 17:09:30.659126
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser

# Generated at 2022-06-23 17:09:40.745198
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    from .common import Docstring, DocstringParam, DocstringReturns, DocstringRaises

    docstring = GoogleParser().parse(
        """\
        This is the short description.

        This is the long description.

        This is a section.

        This is another section.
        """
    )

    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert isinstance(docstring.meta[0], DocstringMeta)
    assert docstring.meta[0].args == ["This is a section."]
    assert docstring

# Generated at 2022-06-23 17:09:48.395938
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Example", "example", SectionType.SINGULAR),
        Section("Examples", "example", SectionType.SINGULAR)
    ]
    assert len(sections) == 2
    assert sections[0].title == "Example"
    assert sections[1].title == "Examples"
    assert sections[0].key == "example"
    assert sections[1].key == "example"


# Generated at 2022-06-23 17:09:53.377043
# Unit test for constructor of class Section
def test_Section():
    """Unit test for Section constructor."""

    s = Section(title='Arguments', key='param', type=SectionType.MULTIPLE)
    assert s.title == 'Arguments'
    assert s.key == 'param'
    assert s.type == SectionType.MULTIPLE



# Generated at 2022-06-23 17:09:54.055097
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    initialize
    """
    print(text)


# Generated at 2022-06-23 17:10:04.820733
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser(title_colon=True)

# Generated at 2022-06-23 17:10:08.449437
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    input_section = Section("test_section", "test_key", SectionType.SINGULAR)
    p = GoogleParser()
    p.add_section(input_section)
    output_section = p.sections["test_section"]
    assert(input_section == output_section)


# Generated at 2022-06-23 17:10:10.595982
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    
    assert len(sections) == 1
    assert sections[0].title == "Arguments"

# Generated at 2022-06-23 17:10:17.956940
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    new_section = Section("New Section Title", "NEW", SectionType.MULTIPLE)
    google_parser.add_section(new_section)
    assert google_parser.sections[new_section.title].title == "New Section Title"
    assert google_parser.sections[new_section.title].key == "NEW"
    assert google_parser.sections[new_section.title].type == SectionType.MULTIPLE



# Generated at 2022-06-23 17:10:31.032006
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        Google-style docstring with:
        - A one line summary ending in a period.
        - A blank line
        - A one line description of the parameters (not required).
        - A blank line
        - A one line description of the return value (not required).
        - A blank line

        :param str a: description of parameter a.
        :param str b: description of parameter b.
        :param str c: description of parameter c.
        :param int d: description of parameter d.
        :param int e: description of parameter e.

        :returns: description of return value.
        :rtype: str
    """
    docstring = GoogleParser().parse(text)

    assert docstring.short_description == 'Google-style docstring with'

# Generated at 2022-06-23 17:10:41.889166
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is the short description.

    This is the long description. It contains two paragraphs.

    Args:
        arg1(int): The first argument.
        arg2(str): The second argument.
    Returns:
        bool: The return value. True for success, False otherwise.
    """
    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert(doc.short_description == 'This is the short description.')
    assert(doc.blank_after_short_description == True)
    assert(doc.long_description == 'This is the long description. It contains two paragraphs.')
    assert(doc.blank_after_long_description == True)
    meta = doc.meta
    assert(meta[0].args[0] == 'param')

# Generated at 2022-06-23 17:10:49.950570
# Unit test for function parse
def test_parse():
    docstring = '''
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    '''

#    d = parse(docstring)
#    assert d.short_description == 'Parse the Google-style docstring into its components.'
#    assert d.long_description is None
#    assert d.blank_after_short_description is True
#    assert d.blank_after_long_description is True

    return 0


# Generated at 2022-06-23 17:10:58.665086
# Unit test for function parse
def test_parse():
    test_string = """
        This is a short description.

        This is a long description.

        :param foo: test
        :returns: True
        """
    result = parse(test_string)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert len(result.meta) == 2
    assert result.meta[0].args[0] == "param"
    assert result.meta[0].arg_name == "foo"
    assert result.meta[0].description == "test"
    assert result.meta[1].args[0] == "returns"
    assert result.meta[1].description == "True"

# Generated at 2022-06-23 17:11:10.971092
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    class DefaultsParser(GoogleParser):
        pass
    class NoTitleColonParser(GoogleParser):
        def __init__(self):
            super().__init__(title_colon=False)
    class AdditionalSectionParser(GoogleParser):
        def __init__(self):
            super().__init__()
            self.add_section(Section("My_Section", "my_section", SectionType.MULTIPLE))


# Generated at 2022-06-23 17:11:20.543289
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''Summary line.

    Extended description of function.

    Args:
        param1: Description of `param1`
        param2: Description of `param2`
        param3: Description of `param3` (optional, defaults to 42)

    Returns:
        Description of return value 1
        Description of return value 2

    Raises:
        IOError: An error occurred accessing the bigtable.Table object.
    '''

    parser = GoogleParser()
    result = parser.parse(docstring)

    assert len(result.short_description) == 12
    assert len(result.long_description) == 40
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False

    assert len(result.meta) == 5

# Generated at 2022-06-23 17:11:27.096143
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    import pytest
    from .test_common import EXAMPLE_SECTION_1, EXAMPLE_SECTION_2, EXAMPLE_SECTION_3
    from .test_common import EXAMPLE_TITLE_1, EXAMPLE_TITLE_2, EXAMPLE_TITLE_3

    gs = GoogleParser(sections=[EXAMPLE_SECTION_1, EXAMPLE_SECTION_2])

    assert gs.parse(EXAMPLE_TITLE_1 + EXAMPLE_SECTION_1) == gs.parse(
        EXAMPLE_TITLE_2 + EXAMPLE_SECTION_2
    )
    with pytest.raises(ParseError):
        gs.parse(EXAMPLE_SECTION_3)

# Generated at 2022-06-23 17:11:33.288979
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        This is a docstring example.

        This is the long description.

        Args:
            arg1 (int): First argument description.
            arg2 (str): Second argument description.

            Third argument description.

        Returns:
            int: Return description.

        Examples:
            Examples should be written in doctest format, and should illustrate how
            to use the function.

            >>> print([i for i in example_generator(4)])
            [0, 1, 2, 3]
    """
    google_parser_obj = GoogleParser()
    parsed_doc = google_parser_obj.parse(text)
    assert parsed_doc.docstring_type == 'Google'

# Generated at 2022-06-23 17:11:43.535814
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Params", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    doc = parser.parse("""

        Args:
            arg1: text1

        Raises:
            ValueError: if something bad happens

        Params:
            param1: text2
    """)
    assert doc.meta[0].description == "text1"
    assert doc.meta[1].description == "text2"
    assert doc.meta[2].description == "if something bad happens"

# Generated at 2022-06-23 17:11:52.851109
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Custom section", "custom", SectionType.MULTIPLE))
    doc = parser.parse(
        """\
        Short summary.

        Args:
            arg1 (str): some argument
        Custom section:
            elem1
            elem2
        """
    )
    assert doc.meta[0].args == ['arg1']
    assert doc.meta[1].args == ['custom', 'elem1']
    assert doc.meta[2].args == ['custom', 'elem2']

# Generated at 2022-06-23 17:12:01.156005
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE)
    assert Section("Args", "param", SectionType.MULTIPLE)
    assert Section("Parameters", "param", SectionType.MULTIPLE)
    assert Section("Params", "param", SectionType.MULTIPLE)
    assert Section("Raises", "raises", SectionType.MULTIPLE)
    assert Section("Exceptions", "raises", SectionType.MULTIPLE)
    assert Section("Except", "raises", SectionType.MULTIPLE)
    assert Section("Attributes", "attribute", SectionType.MULTIPLE)
    assert Section("Example", "examples", SectionType.SINGULAR)
    assert Section("Examples", "examples", SectionType.SINGULAR)

# Generated at 2022-06-23 17:12:09.884982
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("Example", "example", SectionType.SINGULAR)]
    gp = GoogleParser(sections)

    assert gp is not None
    assert gp.sections is not None
    assert len(gp.sections) == 1
    assert gp.sections["Example"] is not None

    assert gp.title_colon == True
    assert gp._setup is not None
    assert gp.titles_re is not None
    assert gp.titles_re.pattern == r"^(Example):[ \t\r\f\v]*$"


# Generated at 2022-06-23 17:12:10.687282
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser(title_colon=False)

# Generated at 2022-06-23 17:12:13.387236
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    assert isinstance(obj.parse(""), Docstring)

# Generated at 2022-06-23 17:12:25.016234
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup test
    from .common import DocstringReturns, DocstringMeta, Docstring, DocstringParam, DocstringRaises
    from .common import RETURNS_KEYWORDS, PARAM_KEYWORDS, RAISES_KEYWORDS

    ret_empty = Docstring()
    parser = GoogleParser()

    # Test

# Generated at 2022-06-23 17:12:29.346165
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Fields", "field", SectionType.SINGULAR))

    assert gp.parse("Fields:\n    test").meta[0].description == "test"

# Generated at 2022-06-23 17:12:34.634405
# Unit test for function parse
def test_parse():
    text = """
    The short description
    and description continued
    
    
    Arguments:
        first (str): The first parameter
        second: The second parameter
        
    Raises:
        ValueError: The exception
    """
    doc = parse(text)
    print(doc)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:12:46.938430
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    from .default import DEFAULT_SECTIONS
    from .common import DocstringMeta
    from .parser import Section
    
    test1_section = Section("test1", "test1", SectionType.MULTIPLE)
    test2_section = Section("test2", "test2", SectionType.SINGULAR_OR_MULTIPLE)
    test3_section = Section("test3", "test3", SectionType.SINGULAR)

    # test1_section added
    test1_google_parser = GoogleParser(DEFAULT_SECTIONS)
    test1_google_parser.add_section(test1_section)
    test1_docstring = test1_google_parser.parse("test1:\n  title1\n \ttitle2")

# Generated at 2022-06-23 17:12:49.804874
# Unit test for constructor of class Section
def test_Section():
    title, key, type = "test", "test", SectionType.MULTIPLE
    section = Section(title, key, type)
    assert section.title == title
    assert section.key == key
    assert section.type == type


# Generated at 2022-06-23 17:13:00.206255
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Unit test for method parse of class GoogleParser
    """
    docstring = '''
    A simple example of a docstring
    '''
    expected_docstring = Docstring(
        long_description=None,
        short_description="A simple example of a docstring",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[]
    )
    assert GoogleParser().parse(docstring) == expected_docstring

    docstring = '''
    A simple example of a docstring
    
    Some longer text to go here
    '''

# Generated at 2022-06-23 17:13:02.211129
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from inspect import getdoc

    assert getdoc(GoogleParser.parse) == parse.__doc__



# Generated at 2022-06-23 17:13:05.503221
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()

    section = Section("MySection", "mysection", SectionType.SINGULAR)
    google_parser.add_section(section)
    assert(google_parser.sections["MySection"] == section)


# Generated at 2022-06-23 17:13:08.431629
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    googleparser = GoogleParser(title_colon=True)
    section = Section("Args", "param", SectionType.MULTIPLE)
    googleparser.add_section(section)
    assert googleparser.sections["Args"] == section

# Generated at 2022-06-23 17:13:15.797384
# Unit test for function parse

# Generated at 2022-06-23 17:13:25.191189
# Unit test for function parse
def test_parse():
    text = """
    A function.

    Args:
        arg1 (str): The first argument.

        arg2 (int): The second argument.

        arg3 (bool: optional, defaults to True): The third argument.

    Raises:
        ValueError: If arg2 < 0.

    Returns:
        str: The result of the function.
    """
    doc = parse(text)
    assert doc.short_description == "A function."
    assert doc.long_description == ""

# Generated at 2022-06-23 17:13:32.264492
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [Section("foo", "foo", SectionType.SINGULAR), Section("bar", "bar", SectionType.SINGULAR)]
    # test an empty string
    parser = GoogleParser(sections)
    text = ""
    ret = parser.parse(text)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert ret.meta == []
    # test a trivial empty case
    parser = GoogleParser(sections)
    text = """
    foo:
    bar:
    """
    ret = parser.parse(text)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is False

# Generated at 2022-06-23 17:13:42.182710
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("Short description.\n") == Docstring(short_description="Short description.")
    assert parse("Short description.\n\nLong description.\n") == Docstring(short_description="Short description.", \
        long_description="Long description.")
    assert parse("Arguments: a.\n") == Docstring(short_description=None, long_description=None, meta=[DocstringMeta(\
        args=['param', 'a'], description=None, arg_name=None, type_name=None, is_optional=None, default=None)])

# Generated at 2022-06-23 17:13:46.158818
# Unit test for function parse
def test_parse():
    """Basic test for function parse"""
    ds = parse.__doc__
    print(ds)
    print(GoogleParser().parse(ds))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:13:51.857514
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    doc_str = \
    '''
    
    
    prints today's date
    
    Returns:
    date (datetime object)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    '''
    doc = google_parser.parse(doc_str)
    assert(len(doc.meta) == 0)
    assert(doc.short_description == "prints today's date")
    assert(doc.long_description == None)
    assert(doc.blank_after_short_description == True)
    assert(doc.blank_after_long_description == False)



# Generated at 2022-06-23 17:13:56.368719
# Unit test for constructor of class Section
def test_Section():
    test_section = Section(
        title="Arguments",
        key="param",
        type=SectionType.MULTIPLE
    )
    assert test_section.title == "Arguments"
    assert test_section.key == "param"
    assert test_section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:14:07.171597
# Unit test for function parse
def test_parse():
    # Setup
    def foo(a: int, b: str) -> str:
        """
        Short description.
        More description.

        Args:
        Doesn't match.

        Args:
        a (int): Description of a.
        b (str): Description of b.

        Returns:
        str: Description of return value.

        Raises:
        TypeError: if invalid argument types.
        ValueError: if invalid argument value.
        AttributeError: if attribute assignment error.
        """
        return 0

    # Test 1
    docstring = foo.__doc__
    actual = parse(docstring)

# Generated at 2022-06-23 17:14:11.892518
# Unit test for constructor of class Section
def test_Section():
    s = Section("name", "title", SectionType.SINGULAR)
    assert (s.title, s.key, s.type) == ("name", "title", SectionType.SINGULAR)


# Generated at 2022-06-23 17:14:24.933394
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """
    res = GoogleParser().parse(text)
    assert str(res) == 'Docstring(short_description="Parse the Google-style docstring into its components.", blank_after_short_description=True, long_description=None, blank_after_long_description=False, meta=[DocstringMeta(args=[\'returns\'], description=\'parsed docstring\')])'

if __name__ == "__main__":
    # Unit test
    import sys

    text = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """
    res = GoogleParser().parse(text)
    print(res)

    res = parse(text)
   

# Generated at 2022-06-23 17:14:33.695428
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        Hello!

        This function does something very useful. It takes a lot of
        arguments, and it also raises a lot of exceptions. This is
        a description of a very long text. It will be shown in
        an expanded form.

        Parameters
        ----------
        a : int
            This is the first argument.
        b : float
            This is the second argument.
        c : str
            This is the third argument.
        d : bool
            This is the fourth argument.

        Raises
        ------
        AttributeError
            Whenever something goes wrong.
        TypeError
            Whenever you provide the wrong type.
        ValueError
            Sometimes we just don't like the value.

        Returns
        -------
        True
            In case of success.
        False
            Otherwise.
    """

    result = GoogleParser().parse

# Generated at 2022-06-23 17:14:41.742004
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        DocstringMeta(args=["examples", "Example 1"], description="Example1"),
        DocstringMeta(args=["examples", "Example 2"], description="Example2")
    ]
    new_section = Section("Example", "examples", SectionType.MULTIPLE)
    text = """
        """

    googleParser = GoogleParser()
    googleParser.add_section(new_section)
    assert googleParser.parse(text).meta == sections



# Generated at 2022-06-23 17:14:43.928383
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleParser = GoogleParser()
    print(googleParser.titles_re)



# Generated at 2022-06-23 17:14:44.940606
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
	GoogleParser()
	return 8


# Generated at 2022-06-23 17:14:54.445945
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test method add_section of class GoogleParser."""

    from .common import DocstringReturns

    gp = GoogleParser()
    gp.add_section(Section("Return", "returns", SectionType.SINGULAR))
    assert gp.parse("Return: x") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringReturns(args=["returns"], description="x", type_name=None)],
    )

# Generated at 2022-06-23 17:15:02.910223
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:15:04.668559
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().title_colon
    assert not GoogleParser(title_colon=False).title_colon

# Generated at 2022-06-23 17:15:09.104684
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Params", "param", SectionType.MULTIPLE))
    return parser

# Generated at 2022-06-23 17:15:21.642122
# Unit test for function parse
def test_parse():
    assert parse("test text") == Docstring("test text", None, False, False)

    d = parse("test text\n\nMore test text")
    assert d.short_description == "test text"
    assert d.long_description == "More test text"
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert not d.meta

    d = parse("test text\nMore test text")
    assert d.short_description == "test text"
    assert d.long_description == "More test text"
    assert not d.blank_after_short_description
    assert d.blank_after_long_description
    assert not d.meta

    d = parse("test text:\n\n")
    assert d.short_description == "test text:"
    assert d.long

# Generated at 2022-06-23 17:15:25.557488
# Unit test for constructor of class Section
def test_Section():
    # test __init__
    section_new = Section("Title", "key", SectionType.SINGULAR)
    assert section_new.title == "Title"
    assert section_new.key == "key"
    assert section_new.type == SectionType.SINGULAR

# Generated at 2022-06-23 17:15:32.253631
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    goog_parser = GoogleParser(sections=None)
    goog_parser.add_section(Section("Returns", "RETURNS", SectionType.SINGULAR_OR_MULTIPLE))
    goog_parser.add_section(Section("Notes", "NOTES", SectionType.SINGULAR))
    goog_parser.add_section(Section("Raises", "RAISES", SectionType.MULTIPLE))
    goog_parser.add_section(Section("Parameters", "PARAMETER", SectionType.MULTIPLE))
    assert len(goog_parser.sections) == 4
    text = "Raises\n    TypeError\n        If a is not an integer."
    meta = goog_parser.parse(text).meta
    assert meta[0].type == "raises"

# Generated at 2022-06-23 17:15:43.712127
# Unit test for function parse
def test_parse():
    docstring = """Inner text of the docstring.
    Args:
        arg1: The first argument. Defaults to None.
        arg2: The second argument.
    Returns:
        None.
    """
    result = parse(docstring)
    assert result.short_description == "Inner text of the docstring."
    assert result.blank_after_short_description
    assert result.long_description == ""
    assert not result.blank_after_long_description

    assert len(result.meta) == 3
    assert result.meta[0].args == ["param", "arg1"]
    assert result.meta[0].description == "The first argument. Defaults to None."
    assert result.meta[0].arg_name == "arg1"
    assert result.meta[0].type_name is None
    assert result

# Generated at 2022-06-23 17:15:57.398686
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Testing GoogleParser._build_meta()
    parser = GoogleParser()
    docstr = parser.parse(
        "This function does something."
        ":param name: The name of ..."
        ":param int size: The size of ..."
        ":raises ValueError: If something goes wrong."
        ":returns: Something."
    )
    params_expected = [
        DocstringParam(
            "param",
            "name",
            "The name of ...",
            None,
            None,
            None,
            None
        ),
        DocstringParam(
            "param",
            "int size",
            "The size of ...",
            None,
            None,
            None,
            None
        ),
    ]