

# Generated at 2022-06-23 17:05:55.558370
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("Test", "test", SectionType.MULTIPLE)
    parser.add_section(new_section)
    assert "Test" in parser.sections.keys()


# Generated at 2022-06-23 17:05:59.207955
# Unit test for constructor of class Section
def test_Section():
    section = Section('A', 'B', 2)
    assert section.title == 'A'
    assert section.key == 'B'
    assert section.type == 2


# Generated at 2022-06-23 17:06:03.726561
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    new_section = Section("Additional", "additional", SectionType.SINGULAR)
    parser = GoogleParser()
    assert 'Additional' not in parser.sections
    # Add new section
    parser.add_section(new_section)
    assert 'Additional' in parser.sections
    # Replace old section
    parser.add_section(new_section)
    assert 'Additional' in parser.sections


# Generated at 2022-06-23 17:06:09.731868
# Unit test for function parse

# Generated at 2022-06-23 17:06:19.606050
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Verifiy section is added to sections dictionary as expected
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    sections_dictionary = {s.title: s for s in sections}
    parser = GoogleParser(sections=sections)
    assert parser.sections == sections_dictionary
    parser.add_section(Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE))
    sections_dictionary["Yields"] = Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE)

# Generated at 2022-06-23 17:06:27.684537
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    assert len(google_parser.sections) == 15

    section = Section("Raises", "raises", SectionType.MULTIPLE)
    old_section = google_parser.sections[section.title]

    assert section.title in google_parser.sections
    assert google_parser.sections[section.title] == old_section

    google_parser.add_section(section)

    assert section.title in google_parser.sections
    assert google_parser.sections[section.title] == section

# Generated at 2022-06-23 17:06:32.345426
# Unit test for function parse
def test_parse():
    def add(a, b):
        """This function adds two number.
        Arguments:
            a(int): first number.
            b(int): second number.
        Returns:
            int: the result.
        """
        return a + b
    print(parse(inspect.getdoc(add)))

test_parse()

# Generated at 2022-06-23 17:06:37.886358
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    docstring = GoogleParser()
    assert docstring.parse('') == Docstring()
    assert docstring.parse('Some string.') == Docstring(description='Some string.')
    # assert docstring.parse('Args: Some string.') == Docstring(description='Some string.')
    assert docstring.parse('Arguments: Some string.') == Docstring(description='Some string.')

# Generated at 2022-06-23 17:06:44.886876
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    input = inspect.cleandoc(
        """Short description.
    
    Long description.
    
    Args:
        arg1(str): Description of arg1.
        arg2(str, optional): Description of arg2. Defaults to None.
        arg3(str, optional): Description of arg3. Defaults to None.
    
    Returns(str): Description of return value.
    
    Yields(str): Description of yielded value.
    """
    )

# Generated at 2022-06-23 17:06:56.306256
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_obj = inspect.getdoc(parse)
    docstring_parsed = parse(docstring_obj)

    # Test short_description
    assert docstring_parsed.short_description == "Parse the Google-style docstring into its components."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == False

    # Test long_description

# Generated at 2022-06-23 17:07:03.908639
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    # Create a new class
    class MySection(Section):
        def __init__(self):
            super().__init__(
                title="Hello",
                key="hola",
                type=SectionType.SINGULAR,
            )

    # Test
    GoogleParser().add_section(MySection())
    GoogleParser().add_section(MySection())
    GoogleParser().add_section(MySection())

    # Raise an error
    with raises(AssertionError):
        GoogleParser().add_section(Section(title="Hello", key="hola", type="test"))

# Generated at 2022-06-23 17:07:06.942939
# Unit test for constructor of class Section
def test_Section():
    test_section = Section('Returns', 'returns', 2)
    assert test_section.title == 'Returns'
    assert test_section.key == 'returns'
    assert test_section.type == 2



# Generated at 2022-06-23 17:07:18.261809
# Unit test for constructor of class Section
def test_Section():
    print(Section('Arguments', 'param', SectionType.MULTIPLE))
    print(Section('Args', 'param', SectionType.MULTIPLE))
    print(Section('Parameters', 'param', SectionType.MULTIPLE))
    print(Section('Params', 'param', SectionType.MULTIPLE))
    print(Section('Raises', 'raises', SectionType.MULTIPLE))
    print(Section('Exceptions', 'raises', SectionType.MULTIPLE))
    print(Section('Except', 'raises', SectionType.MULTIPLE))
    print(Section('Attributes', 'attribute', SectionType.MULTIPLE))
    print(Section('Example', 'examples', SectionType.SINGULAR))
    print(Section('Examples', 'examples', SectionType.SINGULAR))
    print

# Generated at 2022-06-23 17:07:21.835562
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser=GoogleParser()
    section=Section("Argument", "param", SectionType.MULTIPLE)
    parser.add_section(section)
    assert parser.sections["Argument"] == section


# Generated at 2022-06-23 17:07:28.970280
# Unit test for function parse
def test_parse():
    # no docstring
    assert parse(None) == Docstring()

    # simple docstring
    assert parse("Summary line.\n") == Docstring(
        short_description="Summary line.",
        long_description=None,
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("Summary line.\n\n") == Docstring(
        short_description="Summary line.",
        long_description=None,
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-23 17:07:39.212974
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gParser = GoogleParser()
    assert gParser.parse("This is a short desc.") == Docstring(short_description='This is a short desc.',
                                                                long_description=None,
                                                                blank_after_short_description=False,
                                                                blank_after_long_description=False,
                                                                meta=[])
    assert gParser.parse("This is a short desc.\n\nThis is a long desc.") == Docstring(short_description='This is a short desc.',
                                                                                        long_description='This is a long desc.',
                                                                                        blank_after_short_description=True,
                                                                                        blank_after_long_description=False,
                                                                                        meta=[])

# Generated at 2022-06-23 17:07:42.980974
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # First, create new GoogleParser
    gp = GoogleParser()

    # Add section in it
    gp.add_section(Section("Test", "test", SectionType.SINGULAR))

    # Check if the section is added
    assert gp.sections["Test"] == Section("Test", "test", SectionType.SINGULAR)

# Generated at 2022-06-23 17:07:49.141837
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    docstring = """Takes a photo of a cat.

    Raises:
        FileNotFoundError: If there is no cat.
        CatNotFoundError: If the cat disappears.
    """

    GoogleParser().parse(docstring)

    GoogleParser().add_section(Section("Raises", "raises", SectionType.MULTIPLE))

    docstring = """Takes a photo of a cat.

    Raises:
        FileNotFoundError: If there is no cat.
        CatNotFoundError: If the cat disappears.
    """

    GoogleParser().parse(docstring)

# Generated at 2022-06-23 17:07:53.562752
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:07:56.689610
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    new_section = Section("Keywords", "keyword", SectionType.MULTIPLE)
    parser = GoogleParser()
    parser.add_section(new_section)
    parser.parse("Keywords:\n")

# Generated at 2022-06-23 17:08:00.233468
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) == Section("Arguments", "param", SectionType.MULTIPLE)


# Generated at 2022-06-23 17:08:12.521067
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_repr = parse("""    :param list_of_foos: A list of foos
    :type list_of_foos: list
    :param float foo: A float
    :param int bar: An integer
    :example:

        >>> import os
        >>> os.path.abspath("foo")
        '/foo'
    :returns: A string of the concatenated foos
    :rtype: str
    """
    )
    assert len(docstring_repr.meta) == 5
    assert docstring_repr.meta[0].key == "param"
    assert docstring_repr.meta[0].arg_name == "list_of_foos"
    assert docstring_repr.meta[0].type_name == "list"
    assert docstring_repr.meta

# Generated at 2022-06-23 17:08:21.073842
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Examples", "examples", SectionType.SINGULAR),
    ]
    p = GoogleParser(sections)
    assert p.sections == {
        "Arguments": Section("Arguments", "param", SectionType.MULTIPLE),
        "Args": Section("Args", "param", SectionType.MULTIPLE),
        "Example": Section("Example", "examples", SectionType.SINGULAR),
        "Examples": Section("Examples", "examples", SectionType.SINGULAR),
    }

# Generated at 2022-06-23 17:08:33.199357
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:08:37.478193
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class TestClass:
        def __init__(self, a, b, c=3, **kwargs) -> None:
            """Initialize.

            :param a: a
            :param b: b
            :param c: c
            :param kwargs: kwargs
            """


# Generated at 2022-06-23 17:08:45.831048
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:08:49.379500
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleParser = GoogleParser()
    print(googleParser.sections)
    print(googleParser.title_colon)
    print(googleParser._setup())


# Generated at 2022-06-23 17:08:54.362192
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text = """
    Google-style docstring parsing.

    :Args:
        text: docstring to parse
        sections: Recognized sections or None to defaults.
        title_colon: require colon after section title.
    """
    parser = GoogleParser(sections=DEFAULT_SECTIONS, title_colon=True)
    assert(isinstance(parser, GoogleParser))



# Generated at 2022-06-23 17:08:55.469630
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    obj = GoogleParser()


# Generated at 2022-06-23 17:09:07.786051
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    bad_result_1 = p.parse("")
    assert bad_result_1.short_description is None
    assert bad_result_1.long_description is None
    assert bad_result_1.blank_after_short_description is False
    assert bad_result_1.blank_after_long_description is False
    assert len(bad_result_1.meta) == 0

    bad_result_2 = p.parse("bad_text")
    assert bad_result_2.short_description == "bad_text"
    assert bad_result_2.long_description is None
    assert bad_result_2.blank_after_short_description is False
    assert bad_result_2.blank_after_long_description is False
    assert len(bad_result_2.meta) == 0

   

# Generated at 2022-06-23 17:09:10.199268
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Test", "test", SectionType.SINGULAR_OR_MULTIPLE))
    assert "Test" in parser.sections

# Generated at 2022-06-23 17:09:20.337446
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Testing add_section method of the class GoogleParser.
    """
    obj = GoogleParser()
    section_1 = Section("Arguments", "param", SectionType.MULTIPLE)
    expected_1 = True
    actual_1 = section_1.title in obj.sections
    assert actual_1 == expected_1
    new_section_1 = Section("New_Arguments", "param", SectionType.MULTIPLE)
    obj.add_section(new_section_1)
    expected_2 = True
    actual_2 = new_section_1.title in obj.sections
    assert actual_2 == expected_2


# Generated at 2022-06-23 17:09:21.398904
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    pass


# Generated at 2022-06-23 17:09:29.372149
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test_function(val: int) -> T.List[int]:
        """Description.

        Args:
            val (int): value to square.

        Returns:
            List[int]: squared values.

        """
        return [val ** 2]

    docstring = inspect.getdoc(test_function)
    assert isinstance(docstring, str)
    parsed_google = GoogleParser().parse(docstring)
    assert isinstance(parsed_google, Docstring)
    assert len(parsed_google.meta) == 2
    assert isinstance(parsed_google.meta[0], DocstringParam)
    assert isinstance(parsed_google.meta[1], DocstringReturns)
    assert parsed_google.meta[0].args == ['param', 'val']

# Generated at 2022-06-23 17:09:39.667666
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleParser = GoogleParser()
    assert googleParser is not None
    assert googleParser.sections is not None
    assert googleParser.sections['Arguments'].title == 'Arguments'
    assert googleParser.sections['Arguments'].key == 'param'
    assert googleParser.sections['Arguments'].type == 0
    assert googleParser.sections['Raises'].title == 'Raises'
    assert googleParser.sections['Example'].title == 'Example'
    assert googleParser.sections['Example'].key == 'examples'
    assert googleParser.sections['Returns'].title == 'Returns'
    assert googleParser.sections['Returns'].key == 'returns'
    assert googleParser.titles_re is not None


# Generated at 2022-06-23 17:09:52.471897
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Testing GoogleParser class constructor
    assert(GoogleParser() != None)
    assert(GoogleParser().sections != None)
    assert(GoogleParser().title_colon == True)
    # Testing with your own sections
    assert(
        GoogleParser([Section("Arguments", "Arguments", SectionType.MULTIPLE)]
        ).sections["Arguments"].title == "Arguments"
    )
    assert(
        GoogleParser([Section("Arguments", "Arguments", SectionType.MULTIPLE)]
        ).sections["Arguments"].key == "Arguments"
    )
    assert(
        GoogleParser([Section("Arguments", "Arguments", SectionType.MULTIPLE)]
        ).sections["Arguments"].type == SectionType.MULTIPLE
    )
    # Testing with title_colon set to false
   

# Generated at 2022-06-23 17:10:01.304208
# Unit test for function parse
def test_parse():
    text = """
    '''
    Create a new blob.

    :param str key: Key of the blob.
    :param str value: Value of the blob.
    :param int version: Version of the blob.
    '''
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "Create a new blob."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "key: Key of the blob."
    assert docstring.meta[0].description == None

# Generated at 2022-06-23 17:10:07.154109
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    docstring="""
    :param task_id: the id of the task
    :type task_id: int
    :param task_name: the name of the task
    :type task_name: str
    :return: the status of the task
    :rtype: str
    """

    result=GoogleParser().parse(docstring)
    assert isinstance(result, Docstring)
    assert len(result.meta)==3


# Generated at 2022-06-23 17:10:14.448637
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Summarize the function.

    This is a one-line summary.

    This is the full description. It can have multiple paragraphs.

    Args:
        arg1 (str): Description of arg1
        arg2 (str, optional): Description of arg2. Defaults to "foo".

    Returns:
        bool: Description of return value.

    Raises:
        ValueError: Description of exception.
    """

    returned = GoogleParser().parse(text)
    assert returned.short_description == "Summarize the function."
    assert returned.long_description == """This is the full description. It can have multiple paragraphs."""
    assert returned.blank_after_short_description == True
    assert returned.blank_after_long_description == False
    assert len(returned.meta) == 4
    # Returned.meta[0

# Generated at 2022-06-23 17:10:23.423341
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from pytest import raises

    meta = parse("this is a short description\nthis is longer description")
    assert meta.short_description == "this is a short description"
    assert (
        meta.long_description
        == "this is longer description\n\n"
    )

    meta = parse(
        "this is a short description\n"
        "this is longer description\n"
        "with an extra line"
    )
    assert meta.short_description == "this is a short description"
    assert (
        meta.long_description
        == "this is longer description\nwith an extra line\n\n"
    )


# Generated at 2022-06-23 17:10:33.980412
# Unit test for function parse

# Generated at 2022-06-23 17:10:43.659479
# Unit test for function parse
def test_parse():
    '''Test function to test parse function above'''
    raw_text = '''\
    This is a doc string.

    This is a longer description.

    Args:
        a (str): base.
        b (str, optional): base.
        c (str): base. Defaults to 17.

    Returns:
        The square of the input.

    Raises:
        ValueError: If x is too big.
    '''
    parsed = parse(raw_text)
    assert parsed.short_description == 'This is a doc string.'
    assert parsed.long_description == 'This is a longer description.'
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ['param', 'a (str)']
    assert parsed.meta[0].description == 'base.'

# Generated at 2022-06-23 17:10:46.078218
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    test_section = Section("Test", "test", SectionType.MULTIPLE)
    parser.add_section(test_section)
    test_text = "Test:\n"
    assert parser.titles_re.match(test_text)


# Generated at 2022-06-23 17:10:55.703096
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Set up documentation for function f
    # docstring is based on example from Google Python Style Guide
    docstring = """\
    Args:
        param1: The first parameter.
        param2: The second parameter.
    Returns:
        True if successful, False otherwise.
    """
    # Parse the docstring
    result = GoogleParser().parse(docstring)
    # Check that short description is appropriate
    assert(result.short_description == None)
    # Check that there is a blank line after the short description
    assert(result.blank_after_short_description)
    # Check that the blank line after the short description is as expected
    assert(result.blank_after_long_description)
    # Check that the long description is appropriate
    assert(result.long_description == None)
    # Check that the meta-data is as

# Generated at 2022-06-23 17:10:58.895606
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE



# Generated at 2022-06-23 17:11:05.529252
# Unit test for function parse
def test_parse():
    from .utils import console_formatted_docstring
    from .examples import google_style_function_docstring

    console_formatted_docstring(google_style_function_docstring)
    parsed = GoogleParser().parse(google_style_function_docstring)
    assert parsed.short_description == "Builds a trapezoid region."
    assert parsed.blank_after_short_description

    assert not parsed.meta[1].args[1].startswith("top_left")
    assert not parsed.meta[1].args[1].startswith("top.left")
    assert parsed.meta[1].kwargs["top_left"]
    assert parsed.meta[1].kwargs["top_left"].startswith("top_left")
    assert parsed.meta[1].kwargs["top_left"].startswith

# Generated at 2022-06-23 17:11:10.697091
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    g.add_section(Section("Test", "test", SectionType.SINGULAR))
    assert g.sections["Test"] == Section("Test", "test", SectionType.SINGULAR)


# Generated at 2022-06-23 17:11:16.157032
# Unit test for function parse
def test_parse():
    s = docstring_parse(GoogleParser)
    assert s[0] == 'Short description'
    assert s[1] == 'Long description'
    assert len(s[2]) == 1
    assert s[2][0][0] == 'Args'
    assert s[2][0][1] == 'arg1'
    assert s[2][0][2] == 'Description of arg1'


# Generated at 2022-06-23 17:11:26.687110
# Unit test for function parse
def test_parse():
    def Foo():
        """\
        Short description.

        Long description.

        Args:
            par1 (int): the first parameter.
            par2 (:class:`my.AwesomeClass`, optional): the second parameter.

        Returns:
            int or str: the return value.
        """
        pass

    result = parse(Foo.__doc__)
    assert result.short_description == "Short description."
    assert result.long_description == "Long description."
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 3
    assert result.meta[0].key == "param"
    assert result.meta[0].description == "the first parameter."
    assert result.meta[0].arg_name == "par1"
    assert result

# Generated at 2022-06-23 17:11:33.774913
# Unit test for function parse
def test_parse():
    code = """
    This is a method for test\n
    :param name: this is name\n
    :param name2: this is name2\n
    :param name3: this is name3\n
    :param name4: this is name4\n
    
    : returns: returns1\n
    : returns: returns2\n
    :yields: yields1\n
    :yields: yields2\n
    :raises: raises1\n
    :raises: raises2\n
    """

    ret = parse(code)
    print(ret)
    print(ret.short_description)
    print(ret.long_description)
    print(ret.meta[:3])
    print(ret.meta[3:5])
    print(ret.meta[5:7])


# Generated at 2022-06-23 17:11:36.560409
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Arg", "param", SectionType.MULTIPLE))
    gp.add_section(Section("Arg", "param", SectionType.MULTIPLE))
    assert len(gp.sections) == 2
    assert 1 == len(gp.sections) == 2



# Generated at 2022-06-23 17:11:45.409756
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Find all occurrences of the pattern in the sequence. Return a list of indices of all matches.
    
    Args:
      pattern: A string representing the regular expression.
      sequence: A list or string to be searched.
    
    Returns:
      A list of indices of all matches
    '''
    docstring = parse(text)
    assert docstring.short_description == "Find all occurrences of the pattern in the sequence. Return a list of indices of all matches."
    assert docstring.long_description == "pattern: A string representing the regular expression.\n    sequence: A list or string to be searched.\n\nReturns:\n    A list of indices of all matches"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-23 17:11:57.460274
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    goog_parser = GoogleParser()
    TEST_DOCSTRING = '''title:
    arg: arg_name - arg description.
    '''
    docstring_obj = goog_parser.parse(TEST_DOCSTRING)
    assert docstring_obj.short_description == 'title'
    assert docstring_obj.meta[0].args[1] == 'arg: arg_name - arg description.'
    assert docstring_obj.meta[0].description == docstring_obj.meta[0].args[1]
    assert docstring_obj.meta[0].description == 'arg: arg_name - arg description.'
    assert docstring_obj.meta[0].arg_name == 'arg_name'
    assert docstring_obj.meta[0].type_name == None


# Generated at 2022-06-23 17:12:01.926416
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert(s.title == "Arguments")
    assert(s.key == "param")
    assert(s.type == SectionType.MULTIPLE)

# Generated at 2022-06-23 17:12:07.975257
# Unit test for function parse
def test_parse():
    """Test the parsing of Google docstring."""

# Generated at 2022-06-23 17:12:12.985239
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    tit = "Titulo"
    tipo = SectionType.SINGULAR
    palavra = "palavra"
    s = Section(tit, palavra, tipo)
    p = GoogleParser()
    p.add_section(s)
    eq_(p.sections, {s.title:s})

# Generated at 2022-06-23 17:12:24.681278
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test a docstring with all supported sections
    text = """
    All supported sections:

    Short description.

    Long description.

    Arguments:
        name (str): First parameter
        age (int): Second parameter

    Example:
        An example

    Examples:
        Examples

    Attributes:
        attr1: First attribute
        attr2: Second attribute

    Return:
        Return description

    Raises:
        Exception: Raises description

    Yield:
        Yield description
    """
    doc = parse(text)

    assert doc.short_description == "All supported sections"
    assert doc.long_description == "Long description."
    assert not doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert len(doc.meta) == 8


# Generated at 2022-06-23 17:12:29.709950
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    def test_fn():
        """Returns True.

        :param a: test parameter
        :returns: True
        :raises Exception: test exception
        """
        pass

    assert parse(test_fn.__doc__)



# Generated at 2022-06-23 17:12:33.246554
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser("",[Section("Arguments", "param", SectionType.MULTIPLE)])
    GoogleParser(title_colon=False)
    GoogleParser("",title_colon=False)


# Generated at 2022-06-23 17:12:38.811691
# Unit test for constructor of class Section
def test_Section():
    secure_section = Section('Secure', 'secure', SectionType.SINGULAR_OR_MULTIPLE)
    assert secure_section.title == 'Secure'
    assert secure_section.key == 'secure'
    assert secure_section.type == SectionType.SINGULAR_OR_MULTIPLE

# Generated at 2022-06-23 17:12:45.851619
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    s = Section("Results", "result", SectionType.SINGULAR_OR_MULTIPLE)
    parser = GoogleParser(title_colon=False)
    parser.add_section(s)
    assert parser.sections["Results"] == s
    assert parser.title_colon == False
    assert not parser.titles_re.search(": Examples\n")
    assert parser.titles_re.search("Results\n")



# Generated at 2022-06-23 17:12:56.029703
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    sec1 = Section("SectionName", "SectionKey", SectionType.MULTIPLE)
    sec2 = Section("SectionName", "SectionKey", SectionType.SINGULAR_OR_MULTIPLE)
    # Replace existing section
    gp.add_section(sec1)
    assert gp.sections[sec1.title] == sec1
    # Override dynamic regex to check new section
    gp._setup()
    gp.add_section(sec2)
    assert gp.sections[sec2.title] == sec2
    # Override dynamic regex to check new section
    gp._setup()


# Generated at 2022-06-23 17:13:06.673349
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    with open("./doc.txt", "r") as f:
        text = f.read()
    result = gp.parse(text)
    assert result.short_description == "Launches and waits for a container.\n"
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True
    assert result.long_description == ''
    assert isinstance(result.meta[0], DocstringParam)
    assert result.meta[0].description == 'Container name or ID.'
    assert isinstance(result.meta[1], DocstringParam)

# Generated at 2022-06-23 17:13:09.411130
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().sections == {s.title:s for s in DEFAULT_SECTIONS}
    assert GoogleParser().title_colon == True


# Generated at 2022-06-23 17:13:21.873204
# Unit test for constructor of class Section
def test_Section():
    print("first call:")
    print(Section("Arguments", "param", SectionType.MULTIPLE))
    print("second call:")
    print(Section("Args", "param", SectionType.MULTIPLE))
    print("third call:")
    print(Section("Parameters", "param", SectionType.MULTIPLE))
    print("fourth call:")
    print(Section("Params", "param", SectionType.MULTIPLE))
    print("fifth call:")
    print(Section("Raises", "raises", SectionType.MULTIPLE))
    print("sixth call:")
    print(Section("Exceptions", "raises", SectionType.MULTIPLE))
    print("seventh call:")
    print(Section("Except", "raises", SectionType.MULTIPLE))
   

# Generated at 2022-06-23 17:13:24.727886
# Unit test for constructor of class Section
def test_Section():
    section=Section("examples", "examples", 2)
    assert section.title=="examples"
    assert section.key=="examples"
    assert section.type==2
    

# Generated at 2022-06-23 17:13:33.101039
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    chunk = 'Raises:\n    Exception: The exception description.'
    result = GoogleParser().parse(chunk)
    assert isinstance(result, Docstring)
    assert result.short_description is None
    assert result.long_description is None
    assert isinstance(result.meta[0], DocstringRaises)
    assert result.meta[0].args == ['raises', 'Exception']
    assert result.meta[0].description == 'The exception description.'
    assert result.meta[0].type_name == 'Exception'

# Generated at 2022-06-23 17:13:40.964455
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Unit test for method add_section of class GoogleParser."""
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    gp = GoogleParser(sections, title_colon=True)
    test_section = Section("Args", "args", SectionType.MULTIPLE)
    expected_sections = [Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Args", "args", SectionType.MULTIPLE)]
    gp.add_section(test_section)
    assert gp.sections == {s.title: s for s in expected_sections}


# Generated at 2022-06-23 17:13:46.538523
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    test_section = Section("Test_section", "Test_section", SectionType.SINGULAR)
    parser.add_section(test_section)

    assert test_section.title in parser.sections
    assert parser.sections[test_section.title] == test_section

# Generated at 2022-06-23 17:13:51.905764
# Unit test for constructor of class Section
def test_Section():
    assert DEFAULT_SECTIONS[0].title == "Arguments"
    assert DEFAULT_SECTIONS[0].key == "param"
    assert DEFAULT_SECTIONS[0].type == 0
    assert DEFAULT_SECTIONS[4].title == "Example"
    assert DEFAULT_SECTIONS[4].key == "examples"
    assert DEFAULT_SECTIONS[4].type == 0
    assert DEFAULT_SECTIONS[-1].title == "Yields"
    assert DEFAULT_SECTIONS[-1].key == "yields"
    assert DEFAULT_SECTIONS[-1].type == 2


# Generated at 2022-06-23 17:14:01.887887
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    # Setup GoogleParser with empty sections
    parser = GoogleParser(title_colon=False)

    # Define some new sections
    new_sections = [
        Section("NewSection1", "new_key1", SectionType.SINGULAR),
        Section("NewSection2", "new_key2", SectionType.MULTIPLE),
    ]

    # Add new sections
    for new_section in new_sections:
        parser.add_section(new_section)

    # Test if title were added
    assert len(parser.sections) == len(new_sections)

    # Test if new sections titles were added
    for new_section in new_sections:
        assert new_section.title in parser.sections

    # Tests if new sections were added

# Generated at 2022-06-23 17:14:11.326481
# Unit test for function parse
def test_parse():
    def func(a, b=None):
        """Summary line.

        Long description

        Args:
            a: first parameter
            b: second parameter with a long description Defaults to None.

        Returns:
            Described return value.

        Raises:
            Exception if error occurred.
        """
        pass

    d = parse(inspect.getdoc(func))
    assert isinstance(d, Docstring)
    assert d.short_description == "Summary line."
    assert d.long_description == "Long description"
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert len(d.meta) == 4
    assert d.meta[0].key == "param"
    assert d.meta[0].args == ("param", "a")

# Generated at 2022-06-23 17:14:13.585768
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("Section", "sect", SectionType.SINGULAR)
    parser.add_section(new_section)
    assert parser.sections["Section"] == new_section


# Generated at 2022-06-23 17:14:19.982715
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:14:30.116988
# Unit test for function parse
def test_parse():
    #from .google import parse
    from .common import DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns
    from .common import Docstring, Parameter
    from .numpy import parse as numpy_parse

    def f(x, y):
        """Docstring for function f.

        Arguments:
            x: Blablabla one.
            y (int): Blablabla two.

        Returns:
            str: Blabala.

        Examples:
            >>> f(1,2)
            3
        """
        return x + y

    d = parse(f.__doc__)
    #print
    #print d
    assert d.short_description == "Docstring for function f."

# Generated at 2022-06-23 17:14:42.596911
# Unit test for function parse
def test_parse():
    assert parse("foo") == Docstring(
        short_description="foo", long_description=None, meta=[]
    )
    assert parse("foo\nbar") == Docstring(
        short_description="foo",
        long_description="bar",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )
    assert parse("foo\n\nbar") == Docstring(
        short_description="foo",
        long_description="bar",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )

# Generated at 2022-06-23 17:14:50.365071
# Unit test for function parse
def test_parse():
    def foo(a, b):
        """Load dataset.

        Args:
            a: First one
            b: Second one

        Returns:
            Tuple with ``(inputs, targets)``.
        """
        return a, b

    d = parse(foo.__doc__)
    # print(d)
    assert d.short_description == 'Load dataset.'
    assert len(d.meta) == 3
    assert d.meta[0].key == 'param'
    assert d.meta[1].key == 'param'
    assert d.meta[2].key == 'returns'
    assert d.meta[2].type_name == 'Tuple with ``(inputs, targets)``.'


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:15:00.448100
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert Docstring.from_yaml("""{
        "short_description": "Foo.",
        "long_description": null,
        "meta": []
    }""") == parse("""
        Foo.
    """)

    assert Docstring.from_yaml("""{
        "short_description": "Foo.",
        "long_description": "Bar.",
        "meta": []
    }""") == parse("""
        Foo.
        Bar.
    """)


# Generated at 2022-06-23 17:15:08.636689
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse("Test the Google docstring parsing.\n\
        Args:\n\
        the_input (str, optional): The input string.\n\
        the_output (str): The output string.\n\
        Returns:\n\
        tuple: A tuple containing the input and output strings")

    assert docstring.short_description == "Test the Google docstring parsing."
    assert docstring.long_description == None

    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'the_input']
    assert docstring.meta[0].description == "The input string."
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[0].is_optional == True
    assert docstring.meta[0].arg_

# Generated at 2022-06-23 17:15:16.049922
# Unit test for constructor of class Section
def test_Section():
    # 1) Create an empty Section() object
    section = Section()

    # 2) Assert that the instance created is of type Section
    assert type(section) == Section

    # 3) Assert that the instance has the bewlo attributes
    assert hasattr(section, 'title')
    assert hasattr(section, 'key')
    assert hasattr(section, 'type')

    # 4) Check that the instance has the below default attribute values
    assert section.title == ''
    assert section.key == ''
    assert section.type == ''

    # 5) Check that the object has the right number of attributes
    assert len(section) == 3


# Generated at 2022-06-23 17:15:20.569376
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    docstring = """Attributes:
          filename (str): The name of the file.
          data (str): The content of the file.
    """
    assert GoogleParser().sections.__len__() == 15
    assert len(GoogleParser().sections) == 15


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 17:15:26.851560
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("NewSection1", "param", SectionType.MULTIPLE),
        Section("NewSection2", "raises", SectionType.MULTIPLE),
        Section("NewSection3", "attribute", SectionType.MULTIPLE),
        Section("NewSection4", "examples", SectionType.SINGULAR),
        Section("NewSection5", "returns", SectionType.SINGULAR_OR_MULTIPLE),
        Section("NewSection6", "yields", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    GoogleParser(sections)



# Generated at 2022-06-23 17:15:29.838999
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert len(GoogleParser().sections) is len(DEFAULT_SECTIONS)



# Generated at 2022-06-23 17:15:38.833934
# Unit test for function parse
def test_parse():
    assert (parse('''Example of Google-style docstring
    Return:
        Docstring
    ''')).__dict__ == {'short_description': 'Example of Google-style docstring', 
                       'blank_after_short_description': False, 
                       'blank_after_long_description': False, 
                       'long_description': None, 
                       'meta': [DocstringReturns(args=['returns', 'Docstring'], 
                                                description='', 
                                                type_name='Docstring', 
                                                is_generator=False)]}


# Generated at 2022-06-23 17:15:45.266631
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """ Google docstring
    This is a simple example google docstring
    :var test1: This is test1
    :var test2: This is test2
    :param test3: This is param1
    :param test4: This is param2
    :type test3: str
    :param test5: This is param3
    :type test5: str
    :yields: test6
    :yields: test7
    :raises ValueError: raises valueerror
    :returns: test8
    :rtype: str
    :examples: test9
    :returns: test10
    :rtype: str
    """

    google_parser = GoogleParser()
    res = google_parser.parse(docstring)

# Generated at 2022-06-23 17:15:58.486182
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    doc = """
        :param name: name of the person
        :type name: str
        :param age: age of the person
        :type age: int

        :Example:

        >>> g = Person("Guido")
        >>> g.age = 42
    """
    docstring = parser.parse(doc)
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args[0] == 'param'
    assert docstring.meta[0].args[1] == 'name: name of the person'
    assert docstring.meta[0].arg_name == 'name'
    assert docstring.meta[0].type_name == 'str'
