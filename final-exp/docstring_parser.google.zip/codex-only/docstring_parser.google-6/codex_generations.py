

# Generated at 2022-06-23 17:06:02.793782
# Unit test for function parse
def test_parse():
    text = """\
    Short description.

    Long description.

    Args:
        name (str): The name of the example.
        value (int): The value of the example.

    Returns:
        bool: True if long enough, False if too short.

    Raises:
        ValueError: invalid value of name

    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 3
    assert doc.meta[0].title() == "Args"
    assert doc.meta[1].title() == "Returns"
    assert doc.meta[2].title() == "Raises"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:06:15.491770
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = GoogleParser(title_colon=False)
    sections.add_section(Section("Descriptions", "description", 0))
    sections.add_section(Section("Another Section", "description", 1))


# Generated at 2022-06-23 17:06:21.121374
# Unit test for constructor of class Section
def test_Section():
    section = Section("Title", "key_word", SectionType.SINGULAR)
    # Check that the attributes of a section have the expected values
    assert section.title == "Title"
    assert section.key == "key_word"
    assert section.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:06:23.118126
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #  TODO: create tests
    return True


__all__ = ["GoogleParser", "parse"]

# Generated at 2022-06-23 17:06:25.284366
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GoogleParser().add_section(Section("Charmander", "Pokemon", SectionType.MULTIPLE))

# Generated at 2022-06-23 17:06:36.679512
# Unit test for function parse
def test_parse():
    docstring = """
    Metric functions are to be supplied in the metrics parameter of the
    :class:`~keras.callbacks.History` callback.
    """
    assert inspect.cleandoc(docstring) == parse(docstring).short_description

    docstring = """Example network.

    Shows how to build a dataset, configure a network, and start the training
    process.

    Arguments:
        do_training (bool): Whether to build training or inference graph.
        log_dir (str): Directory where to write TensorBoard logs.

    Returns:
        dict: Dictionary of training and evaluation results.
    """
    ds = parse(docstring)
    assert ds.short_description == "Example network."

# Generated at 2022-06-23 17:06:44.260488
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Main Python documentation parser.

    This parser can be used for Sphinx projects or for any other documentation
    generator that uses Google-like docstrings.

    :param path: path to documentation root
    :type path: str

    :returns: parsed docstring
    '''
    obj = GoogleParser()
    result = obj.parse(text);
    assert result.short_description == "Main Python documentation parser."
    assert result.long_description == "This parser can be used for Sphinx projects or for any other documentation\ngenerator that uses Google-like docstrings."
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True
    assert 'param' in result.meta[0].args
    assert 'path' in result.meta[0].args

# Generated at 2022-06-23 17:06:50.140365
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    global DEFAULT_SECTIONS
    p = GoogleParser()
    print(p.sections)
    p.add_section(Section("Arg", "arg", SectionType.MULTIPLE))
    print(p.sections)
    p.add_section(Section("Arguments", "arguments", SectionType.MULTIPLE))
    print(p.sections)


# Generated at 2022-06-23 17:07:01.237306
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test = GoogleParser()
    print("Sections:")
    for section in test.sections.keys():
        print(section)

    print("title_colon:", test.title_colon)
    print("titles_re:", test.titles_re)

    print("\n")

    test = GoogleParser(sections=[Section(title="X", key="x", type=SectionType.SINGULAR)])
    print("Sections:")
    for section in test.sections.keys():
        print(section)

    print("title_colon:", test.title_colon)
    print("titles_re:", test.titles_re)

    print("\n")

    test = GoogleParser(title_colon=False)
    print("Sections:")

# Generated at 2022-06-23 17:07:02.214402
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()


# Generated at 2022-06-23 17:07:10.872565
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_docstring = """\
    Args:
      x: blah blah blah
      x (int): blah blah
      x (int): blah blah blah blah blah. Defaults to 'hello'.
      x (int): blah blah blah blah blah.
    """
    result = GoogleParser().parse(test_docstring)

    assert(result.short_description is None)
    assert(not result.blank_after_short_description)
    assert(result.long_description is None)
    assert(result.blank_after_long_description)
    assert(result.meta[0].args == ["args", "x"])
    assert(result.meta[0].description == "blah blah blah")

    assert(result.meta[1].args == ["args", "x (int)"])

# Generated at 2022-06-23 17:07:22.130043
# Unit test for function parse
def test_parse():
    docstring = """Summary line for function.
     
    Args:
        arg1: Description of arg1
        arg2 (str): Description of arg2
         
        arg3 (str, optional): Description of arg3

    Returns:
            Description of return value.
    """

# Generated at 2022-06-23 17:07:33.393998
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    assert len(parser.sections)==len(DEFAULT_SECTIONS)
    parser.add_section(Section("ABC", "abcd", SectionType.MULTIPLE))
    assert len(parser.sections)==len(DEFAULT_SECTIONS)+1
    parser.add_section(Section("ABC", "efgh", SectionType.SINGULAR))
    assert len(parser.sections)==len(DEFAULT_SECTIONS)+1
    parser.add_section(Section("ABC", "ijkl", SectionType.SINGULAR_OR_MULTIPLE))
    assert len(parser.sections)==len(DEFAULT_SECTIONS)+1


# Generated at 2022-06-23 17:07:40.863074
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.titles_re.pattern == '^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields):[ \t\r\f\v]*$'
    assert parser.sections.keys() == {'Arguments', 'Args', 'Parameters', 'Params', 'Raises', 'Exceptions', 'Except', 'Attributes', 'Example', 'Examples', 'Returns', 'Yields'}
    for key in parser.sections.keys():
        assert key not in {'Tuple', 'List', 'Dict'}
    assert isinstance(parser.sections['Arguments'], Section) == True


# Generated at 2022-06-23 17:07:49.392643
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Example(object):
        def __init__(self, arg1, arg2=[]):
            """Create an Example.

            :param arg1: arg1. Defaults to 1.
            :param arg2: arg2. Defaults to [].
            """
            self.arg1 = arg1
            self.arg2 = arg2

    parser = GoogleParser()

    assert parser.parse("") == Docstring()

    assert parser.parse("a") == Docstring(
        short_description="a", long_description=None, blank_after_short_description=None, blank_after_long_description=None, meta=[]
    )


# Generated at 2022-06-23 17:08:00.995800
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a docstring.

    This is the long description.

    Arguments:
        arg1: The first argument.
        arg2 (str): The second argument.
        arg3 (int, optional):
            The third argument. Defaults to 3.

    Example:
        Examples can be given using either the ``Example`` or ``Examples``
        sections. Sections support any reStructuredText formatting, including
        literal blocks::

            $ python example_google.py

    Attributes:
        attr1 (int): The first attribute.
        attr2 (str): The second attribute.

    Raises:
        AttributeError: The Raises section is a list of all exceptions
            that are relevant to the interface.
    """
    obj = GoogleParser().parse(text)
    # assert obj == text
    assert obj.short_

# Generated at 2022-06-23 17:08:03.945316
# Unit test for constructor of class Section
def test_Section():
    sec = Section("title", "key", "type")
    assert sec.title == "title"
    assert sec.key == "key"
    assert sec.type == "type"


# Generated at 2022-06-23 17:08:11.100674
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Single line docstr
    assert GoogleParser().parse("foo") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        long_description=None,
        meta=[],
    )

    # Two line docstr, short descr and long descr
    assert GoogleParser().parse("foo\nbar") == Docstring(
        short_description="foo",
        blank_after_short_description=True,
        long_description="bar",
        meta=[],
    )

    # Single line docstr with colon
    assert GoogleParser().parse("foo:") == Docstring(
        short_description="foo",
        blank_after_short_description=False,
        long_description=None,
        meta=[],
    )

    # Two line docstr with colon, short descr and long

# Generated at 2022-06-23 17:08:12.905470
# Unit test for constructor of class Section
def test_Section():
    section1 = Section("a", "b", SectionType.MULTIPLE)
    assert section1.title == "a"
    assert section1.key == "b"
    assert section1.type == SectionType.MULTIPLE
    print("Section unit test passed")


# Generated at 2022-06-23 17:08:21.253013
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """This function does something.
    Args:
        param1: The first parameter.
        param2: The second parameter. Defaults to True.
    Returns:
        int: The return value. True for success, False otherwise.
    """
    res = parser.parse(text)
    print(res)
    print("===============================")
    for m in res.meta:
        print("{} => {}".format(m.args, m.description))
        print("{} => {}".format(m.args, m.arg_name))
        print("{} => {}".format(m.args, m.type_name))
        print("{} => {}".format(m.args, m.is_optional))

# Generated at 2022-06-23 17:08:26.956326
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    _temp = GoogleParser()
    _temp = GoogleParser(sections=[])
    _temp = GoogleParser(sections=[DEFAULT_SECTIONS[0], DEFAULT_SECTIONS[1]])
    _temp = GoogleParser(sections=[DEFAULT_SECTIONS[0], DEFAULT_SECTIONS[1]], title_colon=False)
    return


# Generated at 2022-06-23 17:08:38.141273
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    # Test that default values are added as section
    assert "Arguments" in google_parser.sections.keys()
    # Test that adding new section will overide the old one if conflict
    new_section = Section("Example", "Example", SectionType.SINGULAR)
    google_parser.add_section(new_section)
    assert "Example" in google_parser.sections.keys()
    # Test that the new section was created with the right parameters
    assert google_parser.sections["Example"].title == "Example"
    assert google_parser.sections["Example"].key == "Example"
    assert google_parser.sections["Example"].type == SectionType.SINGULAR


# Generated at 2022-06-23 17:08:46.043022
# Unit test for function parse
def test_parse():
    text=("""
        Split the string at the first occurrence of sep, and return a 3-tuple
        containing the part before the separator, the separator itself, and the
        part after the separator.  If the separator is not found, return a 3-tuple
        containing the string itself, followed by two empty strings.

        Arguments:
        sep (str): The delimiter string.

        Returns:
        Tuple[str, str, str]: A tuple containing the part before the separator,
        the separator itself, and the part after the separator.

        Raises:
        ValueError: If the separator is not found.
        """)

# Generated at 2022-06-23 17:08:56.332678
# Unit test for constructor of class Section
def test_Section():
    Argument = Section("Arguments", "param", SectionType.MULTIPLE)
    Args = Section("Args", "param", SectionType.MULTIPLE)
    Parameters = Section("Parameters", "param", SectionType.MULTIPLE)
    Params = Section("Params", "param", SectionType.MULTIPLE)
    Raises = Section("Raises", "raises", SectionType.MULTIPLE)
    Exceptions = Section("Exceptions", "raises", SectionType.MULTIPLE)
    Except = Section("Except", "raises", SectionType.MULTIPLE)
    Attributes = Section("Attributes", "attribute", SectionType.MULTIPLE)
    Example = Section("Example", "examples", SectionType.SINGULAR)

# Generated at 2022-06-23 17:09:08.706789
# Unit test for function parse
def test_parse():
    assert parse(
        """Do something
    better than nothing.
    """
    ).short_description == "Do something"

    assert parse(
        """Do something
    better than nothing.
    """
    ).blank_after_short_description is True

    assert parse(
        """Do something
    better than nothing.
    """
    ).blank_after_long_description is False

    # Note: the original docstring is being parsed as:
    #    """Do something better than nothing.
    #
    #    Maybe.
    #    """
    #
    # Which results in:
    #    short_description: 'Do something better than nothing.'
    #    blank_after_short_description: True
    #    blank_after_long_description: False
    #    long_description: 'Maybe.'
    #    returns: Doc

# Generated at 2022-06-23 17:09:10.659005
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) == \
        Section("Arguments", "param", SectionType.MULTIPLE)

# Generated at 2022-06-23 17:09:14.952611
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    text = '''Method for adding a new node.
    '''
    instance = parse(text)
    assert instance.short_description == "Method for adding a new node."


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:09:22.064592
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    ]
    gparser = GoogleParser(sections)

    # assertEqual(gparser.sections, sections)
    # assertEqual(gparser.title_colon, title_colon)
    assert gparser.sections == sections
    assert gparser.title_colon == True



# Generated at 2022-06-23 17:09:31.829767
# Unit test for function parse

# Generated at 2022-06-23 17:09:37.942616
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long description.

    Args:
        arg1 - First argument.
    """
    parser = GoogleParser()
    doc = parser.parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 1
    assert doc.get_meta("param", "arg1").arg_name == "arg1"



# Generated at 2022-06-23 17:09:38.537387
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-23 17:09:51.306548
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Use this function
    
    :param i: integer
    :raises ValueError: if i > 0
    :return: -i
    """
    parsed_docstring = GoogleParser().parse(docstring)
    # print("--------------")
    # print(docstring)
    # print("--------------")
    # print("{} {} {} {} {} {}".format(
    #     parsed_docstring.short_description, parsed_docstring.long_description, parsed_docstring.blank_after_short_description,
    #     parsed_docstring.blank_after_long_description, parsed_docstring.meta, len(parsed_docstring.meta)))
    # for i in parsed_docstring.meta:
    #     print("{} {} {} {} {} {} {} {} {} {}".format(type(i

# Generated at 2022-06-23 17:10:00.642949
# Unit test for function parse
def test_parse():
    doc = parse(
        """
    This is the short description.
    
    This is the long description.
    
    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.
    arg3 : list
        The third argument.
    arg4 : str, optional
        The fourth argument.
    arg5 : str?, optional
        The fifth argument.
    arg6 : int?
        The sixth argument.
    arg7 : str. Defaults to 'test'.
        The seventh argument.
        
    Example
    -------
    This is an example.
    
    Returns
    -------
    str
        The type of this element is str.
    
    Yields
    ------
    str
        The type of this element is str.
    """
    )
    expected

# Generated at 2022-06-23 17:10:04.040400
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    print(section.title)
    print(section.key)
    print(section.type)


# Generated at 2022-06-23 17:10:12.244571
# Unit test for function parse
def test_parse():
    docstring = '''\
    This is the first line
    and the second.

    This is a paragraph.

    Args:
      a: The first argument
      b (int, optional): The second argument. Defaults to 2.
        Aaaaa bbbbb
        ccccc ddddd

      c: The third argument
    Raises:
      Exception: When an error occurs.
    Returns:
      an int
    '''

    o = parse(docstring)

    assert o.short_description == 'This is the first line and the second.'
    assert o.blank_after_short_description == True

    assert o.long_description == 'This is a paragraph.'
    assert o.blank_after_long_description == True

    assert o.meta[0].args[0] == 'args'

# Generated at 2022-06-23 17:10:17.505382
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.title_colon == True
    assert parser.sections['Arguments'] == Section("Arguments", "param", SectionType.MULTIPLE)
    assert parser.sections['Example'] == Section("Example", "examples", SectionType.SINGULAR)


# Generated at 2022-06-23 17:10:24.799889
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:10:25.998196
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()


# Generated at 2022-06-23 17:10:35.754631
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Testing Section class
    test_section = Section("Test Title", "test", SectionType.MULTIPLE)
    assert test_section.title == "Test Title"
    assert test_section.key == "test"
    assert test_section.type is SectionType.MULTIPLE
    assert str(test_section) == "Test Title"
    assert repr(test_section) == "Section(title='Test Title', key='test', type=<SectionType.MULTIPLE: 1>)"

    # Testing GoogleParser class
    gp = GoogleParser()
    # Adding test_section to the GoogleParser instance
    gp.add_section(test_section)
    assert list(gp.sections)[-1] == "Test Title"
    assert gp.sections["Test Title"] == test_section

# Generated at 2022-06-23 17:10:44.531242
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:10:49.327878
# Unit test for constructor of class Section
def test_Section():
    test_data = [SectionType.SINGULAR, SectionType.SINGULAR_OR_MULTIPLE, SectionType.MULTIPLE]
    for data in test_data:
        assert GoogleParser(sections = [Section("section_name", "section_key", data)])


# Generated at 2022-06-23 17:10:53.528052
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp_instance = GoogleParser()
    new_section = Section("New_Name", "New_Key", SectionType.MULTIPLE)

    gp_instance.add_section(new_section)
    assert gp_instance.sections[new_section.title] == new_section


# Generated at 2022-06-23 17:11:02.447843
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        Args:
            foo (str): foo
            bar (str): bar
            baz (int): baz

        Raises:
            Exception: alfa
            Exception: bravo

        Returns:
            str
        """
    result = GoogleParser().parse(text)
    assert result.short_description is None
    assert result.long_description is None
    assert not result.blank_after_short_description
    assert not result.blank_after_long_description
    assert len(result.meta) == 5
    assert result.meta[0].description == "foo"
    assert result.meta[1].description == "bar"
    assert result.meta[2].description == "baz"
    assert result.meta[3].description == "alfa"

# Generated at 2022-06-23 17:11:07.848905
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    def check_GoogleParser(sections, title_colon):
        '''
        sections: list
            Sections to be added to GoogleParser
        title_colon: bool
            Require colon after section title
        '''
        # Define an instance of class GoogleParser
        gp = GoogleParser(sections=sections, title_colon=title_colon)
        # Exclude the last section and save it in 'last_section'
        last_section = sections.pop()
        # Add last_section to the section list of GoogleParser
        gp.add_section(last_section)
        # Check if the sections of GoogleParser equal 'sections'
        assert gp.sections == {s.title: s for s in sections}
        # Check if the attribute titles_re of GoogleParser is correctly set
        assert gp.titles_re == re.compile

# Generated at 2022-06-23 17:11:10.252861
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().parse("") == Docstring()



# Generated at 2022-06-23 17:11:20.647164
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    title_colon=True

# Generated at 2022-06-23 17:11:33.028178
# Unit test for function parse
def test_parse():
    txt = '''
Such a signature is followed by an empty line and the docstring::

    def f(x: int,
          y: int,
          z: int = 0,
          w: int = None) -> int:
        """Do something."""

Args:
    x:
        The first parameter.
        There is no default value so it is required.
    y:
        The second parameter.
    z:
        The third argument. Defaults to 0.
    w:
        The fourth argument.
        Defaults  to  None.'''

    txt = '''
Such a signature is followed by an empty line and the docstring::

    def f(x: int,
          y: int,
          z: int = 0,
          w: int = None) -> int:
        """Do something."""
'''

# Generated at 2022-06-23 17:11:39.026986
# Unit test for constructor of class Section
def test_Section():
    title = 'Validate'
    key = 'validate'
    type = SectionType.SINGULAR_OR_MULTIPLE
    section = Section(title, key, type)
    print(section)
    assert (section.title == 'Validate') and (section.key == 'validate') and (section.type == SectionType.SINGULAR_OR_MULTIPLE)


# Generated at 2022-06-23 17:11:46.796450
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:11:57.461437
# Unit test for constructor of class Section
def test_Section(): 
    assert Section("Arguments", "param", SectionType.MULTIPLE) == Section("Arguments", "param", SectionType.MULTIPLE)
    assert Section("Args", "param", SectionType.MULTIPLE) != Section("Arguments", "param", SectionType.MULTIPLE)
    assert Section("Arguments", "param", SectionType.MULTIPLE).__str__() == "Section(title='Arguments', key='param', type=SectionType.MULTIPLE)"
    assert Section("Arguments", "param", SectionType.MULTIPLE).__repr__() == "Section(title='Arguments', key='param', type=SectionType.MULTIPLE)"


# Generated at 2022-06-23 17:12:10.284791
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = \
        "Args:\n" \
        "  arg1 (int): The first value.\n" \
        "  arg2 (str): The second value.\n" \
        "Returns:\n" \
        "  int: The return value.\n"
    
    result = GoogleParser().parse(docstring)
    
    assert result.short_description == None
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False
    assert result.long_description == None

    assert len(result.meta) == 3
    
    assert result.meta[0].args == ['param', 'arg1 (int)']
    assert result.meta[0].description == 'The first value.'
    assert result.meta[0].arg_name == 'arg1'

# Generated at 2022-06-23 17:12:12.650088
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Test", "test", SectionType.MULTIPLE))
    assert "test" in gp.sections


# Generated at 2022-06-23 17:12:24.425271
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        Args:
            arg1 (str): The first argument.
            arg2 (str): The second argument.

        """

    # Instantiate a GoogleParser object
    p = GoogleParser()

    # Parse
    docstring = p.parse(text)
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "arg1 (str)"
    assert docstring.meta[0].args[2] == None
    assert docstring.meta[0].is_optional == None

# Generated at 2022-06-23 17:12:35.717725
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """This method does something.

Args:
    param1 (str): This is the first param.
    param2 (str): This is a second param.
Raises:
    KeyError: Raises an exception.
Returns:
    str: The return value. True for success, False otherwise.
Exceptions:
    ValueError: If `param2` is equal to `param1`.
"""
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This method does something."
    assert doc.long_description == ""
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 5
    assert doc.meta[0].key == "param"

# Generated at 2022-06-23 17:12:47.677425
# Unit test for function parse
def test_parse():
    """Test parse."""
    text = """
        Testing Find

        Function to test find.
    """
    assert parse(text).short_description == "Testing Find"
    assert parse(text).long_description == "Function to test find."

    text = """
        Testing Find
        Function to test find.
    """
    assert parse(text).short_description == "Testing Find"
    assert parse(text).long_description == "Function to test find."

    text = """
        Testing Find
        Function to test find.

    """
    assert parse(text).short_description == "Testing Find"
    assert parse(text).long_description == "Function to test find."

    text = """
        Testing Find
        Function to test find.

        """
    assert parse(text).short_description == "Testing Find"

# Generated at 2022-06-23 17:12:54.224672
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = DEFAULT_SECTIONS
    g = GoogleParser(sections)
    g.add_section(Section('Section', 'args', 1))
    for i in range(len(sections)):
        assert g.sections[sections[i].title] == sections[i]
    assert g.sections['Section'] == Section('Section', 'args', 1)

# Generated at 2022-06-23 17:13:05.726169
# Unit test for function parse
def test_parse():
    assert(str(parse('''
    This is the short description.
    ''')) ==
    "short_description: 'This is the short description.'")

    assert(str(parse('''
    This is the short description.

    This is the long description.
    ''')) ==
    "short_description: 'This is the short description.'\n"
    "long_description: 'This is the long description.'"
    "blank_after_short_description: True")


# Generated at 2022-06-23 17:13:08.284490
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse('') == Docstring()
    assert parser.parse('Test with no sections.') == Docstring(short_description='Test with no sections.')



# Generated at 2022-06-23 17:13:20.445237
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
    ]
    parser = GoogleParser(sections)

    text = """
    def f(x: int, y: int) -> int:
        """ + "\"\"\"" + """
            Sum x and y.

            :param x: First number
            :param y: Second number
            :return: Sum
            """ + "\"\"\"" + """
            return x + y
    """
    result = parser.parse(text)
    assert result.short_description == "Sum x and y."
    assert result.blank_after_short_description

# Generated at 2022-06-23 17:13:29.170904
# Unit test for function parse
def test_parse():
    docstring = '''short description

long description

Args:
    arg1 (int): The first argument.
    arg2 (str): The second argument.
Returns:
    bool: The return value. True for success, False otherwise.
'''
    result = parse(docstring)
    assert result.short_description == "short description"
    assert result.long_description == "long description"
    assert result.meta[0].key == "Args"
    assert result.meta[1].key == "Returns"
    assert result.meta[0].args == ["Args", "arg1 (int): The first argument.\n    arg2 (str): The second argument."]
    assert result.meta[1].args == ["Returns", "bool: The return value. True for success, False otherwise."]

# Generated at 2022-06-23 17:13:35.357174
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections= [Section("Arguments", "param", SectionType.MULTIPLE)]
    gp = GoogleParser(sections, True)
    assert gp.title_colon is True
    assert len(gp.sections.keys()) == 1
    assert 'Arguments' in gp.sections.keys()
    assert gp.sections['Arguments'] == Section("Arguments", "param", SectionType.MULTIPLE)


# Generated at 2022-06-23 17:13:38.498184
# Unit test for constructor of class Section
def test_Section():
    section1 = Section("Arguments", "param", SectionType.MULTIPLE)
    section2 = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)


# Generated at 2022-06-23 17:13:42.572755
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    1. get user info from database
    2. get user info from database
    3. get user info from database
    '''
    res = GoogleParser().parse(text)
    assert res.short_description == '1. get user info from database'
    assert res.long_description == '2. get user info from database\n\n3. get user info from database'

# Generated at 2022-06-23 17:13:47.235894
# Unit test for constructor of class Section
def test_Section():
    title = "Return"
    key = "return"
    type1 = SectionType.SINGULAR
    section = Section(title, key, type1)

    assert section.title == title
    assert section.key == key
    assert section.type == type1


# Generated at 2022-06-23 17:13:55.221602
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    parser.parse(
        """
    This is the docstring summary.

    This is part of the docstring description.

    This is also a part of the docstring description.

    Arguments:
        arg1: The first parameter.
        arg2: The second parameter.
        arg3: The third parameter. (default: 10)
        arg4: The fourth parameter.

    Returns:
        The return value. 1

    Yields:
        The yielded value. 2

    Raises:
        Exception: Raised if error occurs.
    """
    )

# Generated at 2022-06-23 17:14:01.610971
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gparser = GoogleParser()
    gparser.add_section(Section("Setting", "setting", SectionType.MULTIPLE))
    assert gparser.titles_re.pattern == "^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields|Setting):[ \t\r\f\v]*$"


# Generated at 2022-06-23 17:14:05.172789
# Unit test for constructor of class Section
def test_Section():
    section = Section('Raises', 'raises', SectionType.MULTIPLE)
    assert section.title == 'Raises'
    assert section.key == 'raises'
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:14:13.415708
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text = """
        This is a quick brief
        function
        :param arg1: int argument
    """

# Generated at 2022-06-23 17:14:26.338420
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def f1(i:int) -> int:
        """Computes i!
        :param i: this is the parameter i
        :type i: int
        :return: the factorial of i
        :rtype: int
        """
        s = 1
        for j in range(1, i+1):
            s*=j
        return s
    ds = parse(f1.__doc__)
    assert ds.short_description == "Computes i!"
    assert ds.long_description == None
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == True
    assert ds.meta[0].description == "the factorial of i"
    assert ds.meta[1].description == "this is the parameter i"

# Generated at 2022-06-23 17:14:34.639838
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:14:46.688661
# Unit test for function parse
def test_parse():
    docstring = "Args:\n    param_1: This is the first param.\n    param_2: The second param.\n\nRaises:\n    TypeError: The raised exception.\n\nReturns:\n    int: The return value.\n"
    docstring = "Args:\n    param_1: This is the first param.\n    param_2: The second param.\n\nRaises:\n    TypeError: The raised exception.\n\nReturns:\n    int: The return value.\n"


# Generated at 2022-06-23 17:14:50.114013
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    new_section = Section("Test", "test", SectionType.MULTIPLE)
    GoogleParser().add_section(new_section)

# Generated at 2022-06-23 17:15:00.217691
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse(" ") == Docstring()
    assert parse("\t") == Docstring()
    assert parse("\t\n     \r\n") == Docstring()

    expected = Docstring(
        short_description="A single sentence description",
        blank_after_short_description=True,
        long_description="A paragraph long description.",
        blank_after_long_description=False,
    )
    assert parse("A single sentence description. A paragraph long description.") == expected

    expected = Docstring(
        short_description="A single sentence description",
        blank_after_short_description=False,
        long_description="A paragraph long description.",
        blank_after_long_description=False,
    )
    assert parse("A single sentence description.\nA paragraph long description.") == expected

# Generated at 2022-06-23 17:15:07.427715
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """\
    See: https://sphinx-doc.org/domains.html#info-field-lists

    An object that encapsulates parameters to be passed to a function.
    It can also be a global parameter list or a local parameter list.

    :param name: the name of the parameter list
    :type name: str
    :param arguments:
        the list of arguments, a list of (<name>, <description>) tuples
        or a list of (<name>, <type>, <description>) tuples
    :type arguments: list
    """

    print(GoogleParser().parse(doc))

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:15:19.975688
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    source = """
        """
    expected = Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    actual = GoogleParser().parse(source)
    assert actual == expected

    source = """This function counts up to n."""
    expected = Docstring(
        short_description="This function counts up to n.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    actual = GoogleParser().parse(source)
    assert actual == expected

    source = """This function counts up to n.

        """

# Generated at 2022-06-23 17:15:24.594389
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Hello", "hello", SectionType.MULTIPLE))
    assert "Hello" in gp.sections
    assert "hello" in gp.sections
    assert gp.sections["hello"] == Section("Hello", "hello", SectionType.MULTIPLE)


# Generated at 2022-06-23 17:15:26.993037
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    my_section = Section("About", "about", SectionType.SINGULAR)
    parser = GoogleParser()
    parser.add_section(my_section)


# Generated at 2022-06-23 17:15:30.042364
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print("Test GoogleParser constructor")
    parser = GoogleParser()
    print(parser)



# Generated at 2022-06-23 17:15:42.159744
# Unit test for function parse
def test_parse():
    docstring = """Arguments:
        x (str): Some parameter. Defaults to "hello"
        y (int): Another parameter.
    """
    ds = parse(docstring)
    assert len(ds.meta) == 2
    assert ds.meta[0] == DocstringParam(args=["param", "x (str)"],
                                        arg_name="x",
                                        description="Some parameter.",
                                        type_name="str",
                                        is_optional=False,
                                        default="hello",
                                        )

# Generated at 2022-06-23 17:15:49.624706
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test if the function parse of class GoogleParser.
    """

# Generated at 2022-06-23 17:15:59.236173
# Unit test for function parse
def test_parse():
    docstring = """
        Short summary.

        Some long description.

        Args:
          arg_name: Description of arg_name. Defaults to None.
          arg_name2: Description of arg_name2. Defaults to None.

        Returns:
          Description of return value.
      """
    parsed = parse(docstring)
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ['returns']
    assert parsed.meta[1].args == ['param', 'arg_name']
    assert parsed.meta[2].args == ['param', 'arg_name2']

if __name__ == "__main__":
    test_parse()