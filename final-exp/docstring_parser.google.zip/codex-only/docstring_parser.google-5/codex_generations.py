

# Generated at 2022-06-23 17:06:04.337477
# Unit test for function parse
def test_parse():
    # Arrange
    from .common import Docstring, DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns
    from .common import PARAM_KEYWORDS, RAISES_KEYWORDS, RETURNS_KEYWORDS, YIELDS_KEYWORDS
    
    text = """Convert string to boolean
    Args:
        arg(str): The string to convert
    Returns:
        bool: The string converted
    """

# Generated at 2022-06-23 17:06:05.892011
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("").__dict__ == Docstring().__dict__

# Generated at 2022-06-23 17:06:11.607087
# Unit test for constructor of class Section
def test_Section():
    new_section = Section("some_title", "some_key", SectionType.SINGULAR)
    assert (new_section.title == "some_title")
    assert (new_section.key == "some_key")
    assert (new_section.type == SectionType.SINGULAR)


# Generated at 2022-06-23 17:06:20.659764
# Unit test for function parse
def test_parse():

    def func(a, b, c=3, d=4.3, e="e", f=True, g=None, h=None):
        """
        Short description.

        Description that is long.

        Args:
            a: Specification for a.
            b: Specification for b.
            c: int. Specification for c. Defaults to 3
            d: Specification for d.
            e: Specification for e.
            f: bool. Specification for f. Defaults to True
            g: Specification for g,
                and is multilined. Defaults to None
            h: Specification for h. Defaults to None,
                and is multilined.

        Returns:
            Specification for returns,
                and is multilined.
        """
        pass


# Generated at 2022-06-23 17:06:28.545685
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()

# Generated at 2022-06-23 17:06:35.875155
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    '''
    Test class GoogleParser's method add_section
    '''
    test_docstring = GoogleParser()
    # test the function of add_section
    test_docstring.add_section(Section('Test', 'test', SectionType.SINGULAR))
    assert test_docstring.sections['Test'].title == 'Test'
    assert test_docstring.sections['Test'].key == 'test'
    assert test_docstring.sections['Test'].type == SectionType.SINGULAR

# Generated at 2022-06-23 17:06:44.492262
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:06:50.385733
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # title_colon=True
    assert GoogleParser().title_colon
    assert not GoogleParser(title_colon=False).title_colon
    # sections
    assert GoogleParser().sections == GoogleParser(sections=None).sections
    assert (
        GoogleParser().sections != GoogleParser(sections=[Section("a", "b", 0)]).sections
    )


# Generated at 2022-06-23 17:07:00.440581
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = r"""This is a test.
    This is a sub test.
    This is a subsub test.

    Arguments:
        a: b
        c (int): Defaults to 2. d
        e: f
        g: h
    """

# Generated at 2022-06-23 17:07:04.203508
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser(title_colon=False)
    assert len(g.titles_re.pattern) < len(GoogleParser().titles_re.pattern)
    assert len(g.titles_re.pattern) > 0
    assert len(g.sections) == len(DEFAULT_SECTIONS)



# Generated at 2022-06-23 17:07:06.551047
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    if GoogleParser.parse(None) == True:
        raise AssertionError()

    if GoogleParser.parse('') == True:
        raise AssertionError()


# Generated at 2022-06-23 17:07:14.114106
# Unit test for constructor of class Section
def test_Section():
    # correct input
    title = "Args"
    key = "param"
    type = SectionType.MULTIPLE
    section = Section(title, key, type)
    assert section.title == title
    assert section.key == key
    assert section.type == type

    # incorrect input (no title and key)
    with pytest.raises(Exception):
        section = Section()

    # incorrect input (wrong title)
    with pytest.raises(Exception):
        section = Section("title","key","type")

    # incorrect input (wrong key)
    with pytest.raises(Exception):
        section = Section("Args","test","type")

    # incorrect input (wrong type)
    with pytest.raises(Exception):
        section = Section("Args","param","test")



# Generated at 2022-06-23 17:07:20.889577
# Unit test for function parse
def test_parse():
    local_parse = parse
    yield check_google, local_parse

    sections = [
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    p = GoogleParser(sections)
    yield check_google, p.parse



# Generated at 2022-06-23 17:07:21.974113
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()


# Generated at 2022-06-23 17:07:23.632778
# Unit test for constructor of class Section
def test_Section():
    section = Section()
    assert section.title == 0
    assert section.key == 0
    assert section.type == 0

# Generated at 2022-06-23 17:07:33.601993
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:07:35.938265
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key", SectionType.SINGULAR)
    assert section == Section(title="title", key="key", type=SectionType.SINGULAR)



# Generated at 2022-06-23 17:07:42.034090
# Unit test for constructor of class Section
def test_Section():
    print('Testing __init__ of class Section')
    section = Section(title = "Test", key = "test", type = SectionType.SINGULAR)
    assert section.title == "Test", "title is 'Test'"
    assert section.key == "test", "key is 'test'"
    assert section.type == SectionType.SINGULAR, "type is SectionType.SINGULAR"



# Generated at 2022-06-23 17:07:50.201882
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:08:01.510962
# Unit test for constructor of class Section
def test_Section():
    assert Section('Arguments', 'param', SectionType.MULTIPLE)
    assert Section('Args', 'param', SectionType.MULTIPLE)
    assert Section('Parameters', 'param', SectionType.MULTIPLE)
    assert Section('Params', 'param', SectionType.MULTIPLE)
    assert Section('Raises', 'raises', SectionType.MULTIPLE)
    assert Section('Exceptions', 'raises', SectionType.MULTIPLE)
    assert Section('Except', 'raises', SectionType.MULTIPLE)
    assert Section('Attributes', 'attribute', SectionType.MULTIPLE)
    assert Section('Example', 'examples', SectionType.SINGULAR)
    assert Section('Examples', 'examples', SectionType.SINGULAR)

# Generated at 2022-06-23 17:08:02.039207
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-23 17:08:09.975452
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:08:13.976898
# Unit test for constructor of class Section
def test_Section():
    s = Section("Test","test", SectionType.SINGULAR)
    assert s.title == "Test"
    assert s.key == "test"
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:08:17.782677
# Unit test for constructor of class Section
def test_Section():
    sect = Section("Example", "examples", SectionType.SINGULAR)
    assert sect.title == "Example"
    assert sect.key == "examples"
    assert sect.type == SectionType.SINGULAR

# Unit tests for parse

# Generated at 2022-06-23 17:08:22.783910
# Unit test for function parse
def test_parse():
    def f():
        """Short description.

        Long description.

        Args:
            foo (int): foo.
            bar: bar. Defaults to baz.

        Returns:
            description
        """

    assert parse(f.__doc__)

# Generated at 2022-06-23 17:08:34.784492
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    googleParser = GoogleParser()
    assert str(googleParser.parse("")) == "Docstring()"
    assert str(googleParser.parse("A short description")) == "Docstring(short_description='A short description')"
    assert str(googleParser.parse("A short description\n\nA long description")) == "Docstring(short_description='A short description', long_description='A long description')"
    assert str(googleParser.parse("  A short description  ")) == "Docstring(short_description='A short description')"
    assert str(googleParser.parse("  A short description  \n\n  A long description  ")) == "Docstring(short_description='A short description', long_description='A long description')"

# Generated at 2022-06-23 17:08:44.524548
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test_section_1 = Section(title="Test", key="test", type=SectionType.MULTIPLE)
    test_section_2 = Section(title="Example", key="examples", type=SectionType.SINGULAR)
    test_sections = [test_section_1, test_section_2]

    test_parser = GoogleParser(test_sections)
    assert(test_parser.sections["Test"].title == test_section_1.title)
    assert(test_parser.sections["Example"].key == test_section_2.key)

    test_parser.add_section(test_section_1)
    assert(test_parser.sections.__contains__("Test"))
    assert(test_parser.sections["Test"].title == test_section_1.title)

    # Test constructor on empty docstring


# Generated at 2022-06-23 17:08:55.815374
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:08:56.881099
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser() is not None



# Generated at 2022-06-23 17:09:06.222072
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section_ = Section("Arguments", "param", SectionType.MULTIPLE)
    # Test adding new section
    parser.add_section(section_)
    assert parser.sections["Arguments"] == section_
    # Test replacing section
    section_ = Section("Arguments", "param", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(section_)
    assert parser.sections["Arguments"] == section_
    # Test other sections have not been modified
    assert parser.sections["Returns"] == DEFAULT_SECTIO

# Generated at 2022-06-23 17:09:12.018555
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("VisibleDeprecationWarning", "VisibleDeprecationWarning",
                           SectionType.MULTIPLE))
    # Adding another section with the same key will replace the previous one
    gp.add_section(Section("VisibleDeprecationWarning", "VisibleDeprecationWarning",
                           SectionType.SINGULAR_OR_MULTIPLE))

    text = """
    Bla bla bla.

    Raises:
        VisibleDeprecationWarning: If a condition is not met.
    """

    result = gp.parse(text)
    assert result.meta[0].args == ["VisibleDeprecationWarning", "VisibleDeprecationWarning"]

# Generated at 2022-06-23 17:09:17.158459
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    This function does something.

    :Parameters:
        **param1** (object) -- parameter one
        **param2 (optional)** (:obj:`int`) -- parameter two. Defaults to 42.
        **param3** (:obj:`int`, optional) -- parameter three. Defaults to 43.
        **param3** (:obj:`int`) -- parameter three. Defaults to 44.

    :Returns:
        bool
            True if successful, False otherwise.
    '''

    parsed = GoogleParser().parse(text)
    assert(str(parsed) == text)

# Generated at 2022-06-23 17:09:22.792403
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section(title="title1", key="key1", type=0)
    parser.add_section(new_section)
    assert parser.sections["title1"] == new_section
    assert parser.sections["title1"].type == 0
    assert parser.sections["title1"].title == "title1"
    assert parser.sections["title1"].key == "key1"

# Generated at 2022-06-23 17:09:27.118207
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    print(section)
    print(section.title)
    print(section.key)
    print(section.type)
    print(type(section.title))
    print(type(section.key))
    print(type(section.type))



# Generated at 2022-06-23 17:09:31.060932
# Unit test for function parse
def test_parse():
    print(parse.__doc__)
    print(parse(parse.__doc__))

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-23 17:09:35.055053
# Unit test for constructor of class Section
def test_Section():
    title = 'title'
    key = 'key'
    type = 'type'
    section = Section(title, key, type)

    assert section.title == title
    assert section.key == key
    assert section.type == type

if __name__ == '__main__':
    print('GoogleParser')
    print(__doc__)
    print()
    print(GoogleParser.__doc__)
    print()

    sections = DEFAULT_SECTIONS
    title_colon=True
    obj = GoogleParser(sections,title_colon)
    print(obj)
    print()
    print(obj.__dict__)
    print()
    print(obj.__doc__)

    # __repr__
    print(obj.__repr__)

    # __str__

# Generated at 2022-06-23 17:09:38.040893
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp=GoogleParser()
    gp.parse('''
    Bla bla bla...
    :param: bla bla bla
    :Returns: bla bla bla
    ''')
    return 0

# Generated at 2022-06-23 17:09:42.312318
# Unit test for constructor of class Section
def test_Section():
    s = Section('title', 'key', SectionType.SINGULAR_OR_MULTIPLE)
    assert s.title == 'title'
    assert s.key == 'key'
    assert s.type == SectionType.SINGULAR_OR_MULTIPLE


# Generated at 2022-06-23 17:09:55.351733
# Unit test for function parse
def test_parse():
    test_doc_strings = [
        '''\
        Test function.

        Args:
            arg_1 (int): Test argument 1.
            arg_2 (float): Test argument 2.

        Returns:
            Test return value.
        ''',
        '''\
        Test function.

        Args:
            arg_1 (int): Test argument 1.
            arg_2 (float): Test argument 2.

        Yields:
            Test yield value.
        ''',
        '''\
        Test function.

        Args:
            arg_1 (int): Test argument 1.
            arg_2 (float): Test argument 2.

        Raises:
            Test exception.
        ''',
    ]
    func = parse(test_doc_strings[0])
    assert func.short_description == "Test function."

# Generated at 2022-06-23 17:10:05.071229
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    assert google_parser._setup.__name__ == "_setup"
    assert google_parser.titles_re.pattern == "^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields)[ \t\r\f\v]*$"

# Generated at 2022-06-23 17:10:08.038817
# Unit test for constructor of class Section
def test_Section():
    section = Section('test', 'key', SectionType.MULTIPLE)
    assert section.title == 'test'
    assert section.key == 'key'
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:10:15.078862
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''Add two numbers.

    Arguments:
        a (int): The first number.
        b (float): The second number.

    Returns:
        int: The result.

    '''
    text2 = '''Add two numbers.

    Args:
        a (int): The first number.
        b (float): The second number.

    Returns:
        int: The result.

    '''
    text3 = '''Add two numbers.

    Parameters:
        a (int): The first number.
        b (float): The second number.

    Returns:
        int: The result.

    '''

# Generated at 2022-06-23 17:10:20.310997
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:10:32.347720
# Unit test for function parse
def test_parse():
    docstr = """A one-line summary that does not use variable names or the function name.

    Several sentences providing an extended description. Refer to
    variables like `var` and `var2` and functions like `func` and
    `func2`.

    Args:
        param1 (int): Description of `param1`
        param2 (str): Description of `param2`

    Returns:
        bool: Description of return value

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """

# Generated at 2022-06-23 17:10:42.544858
# Unit test for function parse
def test_parse():
    def foo():
        """Parse the Google-style docstring into its components.

        :returns: parsed docstring

        Example:
            Examples can be given using either the ``Example`` or ``Examples``
            sections. Sections support any reStructuredText formatting, including
            literal blocks::

                $ python example_google.py

            Section breaks are created by resuming unindented text. Section breaks
            are also implicitly created anytime a new section starts.
        """

    docstring = parse(foo.__doc__)
    assert docstring.short_description == "Parse the Google-style docstring into its components."

# Generated at 2022-06-23 17:10:53.904396
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse("""\
        A short description of the foo class.

        Long description of the foo class.

        Args:
            par1: The first param.
            par2: The second param.

        Returns:
            The return value. True for success, False otherwise.
    """)
    assert docstring.short_description == "A short description of the foo class."
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param"]
    assert docstring.meta[0].description == "The first param."
    assert docstring.meta[1].args == ["param"]
    assert docstring.meta[1].description == "The second param."
    assert docstring.meta[2].args == ["returns"]

# Generated at 2022-06-23 17:11:01.906382
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_GoogleParser_parse.result = None
    def mock_build_meta(self, text, title):
        test_GoogleParser_parse.result = title
    GoogleParser.parse = GoogleParser.parse.__func__
    GoogleParser.parse.__globals__['self']._build_meta = mock_build_meta
    GoogleParser.parse.__globals__['self']._build_meta(
        GoogleParser.parse.__globals__['self'],
        inspect.cleandoc('''params:
            text: the docstring itself
            title: the title of the meta'''),
        'params')
    assert test_GoogleParser_parse.result == 'params'

# Generated at 2022-06-23 17:11:13.469420
# Unit test for constructor of class Section
def test_Section():
    title = "test title"
    key = "test key"
    type = SectionType.SINGULAR
    section = Section(title, key, type)

    assert section.title == title
    assert section.key == key
    assert section.type == type
    # check the string representation
    assert str(section) == "Section(title='{}', key='{}', type={})".format(
        title, key, type
    )
    # check the string representation of a tuple
    section_tuple = tuple(section)
    assert str(section_tuple) == "(title='{}', key='{}', type={})".format(
        title, key, type
    )


# Generated at 2022-06-23 17:11:21.821686
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
        Section("Params", "param", SectionType.MULTIPLE),
    ]
    parser = GoogleParser()
    section1 = Section("Returns", "returns", SectionType.SINGULAR)
    parser.add_section(section1)
    section2 = Section("Returns", "returns", SectionType.SINGULAR)
    parser.add_section(section2)
    section3 = Section("Returns", "returns", SectionType.SINGULAR)
    parser.add_section(section3)

# Generated at 2022-06-23 17:11:25.864094
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Method", "method", SectionType.SINGULAR)
    parser.add_section(section)
    assert parser.sections.get("Method") == section



# Generated at 2022-06-23 17:11:37.550030
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Exceptions", "exception", SectionType.MULTIPLE),
    ]
    parser = GoogleParser(sections)
    assert sections == parser.sections, 'Parser created from sections list is not correctly initialized'
    section = Section("Args", "param", SectionType.SINGULAR)
    parser.add_section(section)
    assert parser.sections["Args"] == section, 'Parser did not correctly add section'
    section = Section("Example", "example", SectionType.MULTIPLE)
    parser.add_section(section)
    assert parser.sections["Example"] == section, 'Parser did not correctly replace section'

# Generated at 2022-06-23 17:11:39.362769
# Unit test for function parse
def test_parse():
    text = """Args:
    a: (int)
    b: (int)
    Returns:
    list[int, int]:
    """
    assert (GoogleParser().parse(text) == parse(text))


# Generated at 2022-06-23 17:11:41.128474
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    this is a basic function!!
    '''
    assert parse(text) == [Docstring]
    return


# Generated at 2022-06-23 17:11:42.437211
# Unit test for constructor of class Section
def test_Section():
    assert Section is namedtuple("Section", ["title", "key", "type"])


# Generated at 2022-06-23 17:11:47.192618
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    new_section = Section("NewSection", "new", SectionType.MULTIPLE)
    gp = GoogleParser()
    gp.add_section(new_section)
    assert new_section.title in gp.sections
    assert gp.sections[new_section.title] == new_section


# Generated at 2022-06-23 17:11:58.512082
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:12:07.798933
# Unit test for function parse
def test_parse():
    """ Test the parser """

    doc = """
    Example function with types documented in Google style.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    print(doc)
    print(GoogleParser().parse(doc))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:12:09.359589
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # print(GoogleParser().parse('aaa'))
    pass



# Generated at 2022-06-23 17:12:16.386582
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    short description

    long description

    Args:
      arg_name (type): description
      arg_name (type): description
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == 'short description'
    assert docstring.long_description == 'long description'
    assert len(docstring.meta) == 2
    assert docstring.meta[0].arg_name == 'arg_name'
    assert docstring.meta[0].type_name == 'type'
    assert docstring.meta[0].args == ['param', 'arg_name']
    assert docstring.meta[0].description == 'description'
    assert docstring.meta[0].is_optional is None
    assert docstring.meta[0].default is None

# Generated at 2022-06-23 17:12:19.387552
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print("test_GoogleParser")
    p = GoogleParser()
    assert p.parse('This is a test')


# Generated at 2022-06-23 17:12:28.602599
# Unit test for function parse
def test_parse():
    raw_docstring = '''Arguments:
      arg1 (int, optional): The first value. Defaults to 1.
      arg2 (str, optional): The second value. Defaults to '2'.

    Raises:
      ValueError: If arg1 is equal to arg2.

    Attributes:
      attr1 (int): Description of `attr1`.
      attr2 (:obj:`str`): Description of `attr2`.

    Examples:
        >>> parse(None)
        (None, None, None)
        >>> parse('A simple string')
        ('A simple string', None, None)
        >>> parse('A string with an long description.\n\nAnd it is a good one.')
        ('A string with an long description.', 'And it is a good one.', None)
    '''
    expect_doc

# Generated at 2022-06-23 17:12:31.309479
# Unit test for constructor of class Section
def test_Section():
    # Normal case
    s = Section("test", "name", 2)
    assert ("test", "name", 2) == s
    assert s.title == "test"
    assert s.key == "name"
    assert s.type == 2

    # Error case
    try:
        Section("test", "name", 3)
    except Exception as exception:
        pass
    else:
        assert False


# Generated at 2022-06-23 17:12:36.504232
# Unit test for constructor of class Section
def test_Section():
    section = Section("Example", "examples", SectionType.SINGULAR_OR_MULTIPLE)
    assert section.title == "Example"
    assert section.key == "examples"
    assert section.type == SectionType.SINGULAR_OR_MULTIPLE
    assert section.title == "Example"
    assert section.key == "examples"
    assert section.type == SectionType.SINGULAR_OR_MULTIPLE

# Generated at 2022-06-23 17:12:48.315187
# Unit test for function parse
def test_parse():
    """Test GooglesParser parse method."""

    text = """
    Summary line.

    Extended description.

    Args:
        a: arg a
        b: arg b
        c: arg c

    Returns:
        return value
    """
    obj = parse(text)
    assert obj.short_description == "Summary line."
    assert obj.blank_after_short_description is False
    assert obj.long_description is None
    assert obj.blank_after_long_description is None
    assert len(obj.meta) == 2
    assert obj.meta[0].args == ["Args", "a: arg a\nb: arg b\nc: arg c"]
    assert obj.meta[0].description is None
    assert obj.meta[1].args == ["Returns", "return value"]

# Generated at 2022-06-23 17:12:59.550987
# Unit test for function parse
def test_parse():
    doc = parse("""
    Summarize the class. bla bla bla

    Bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla

    :param str x: Longish description for x

    :param int y: Longish description for y

    :Example:

    >>> a = 5
    >>> b = 6
    >>> res = a * b
    >>> assert res == 30
    """)

    assert "Summarize the class. bla bla bla" == doc.short_description
    assert doc.blank_after_short_description is False

# Generated at 2022-06-23 17:13:08.517721
# Unit test for constructor of class Section
def test_Section():
    
    sec1 = Section("Attributes", "attribute", SectionType.MULTIPLE)
    assert sec1.title == "Attributes"
    assert sec1.key == "attribute"
    assert sec1.type == SectionType.MULTIPLE

    sec2 = Section("Example", "examples", SectionType.SINGULAR)
    assert sec2.title == "Example"
    assert sec2.key == "examples"
    assert sec2.type == SectionType.SINGULAR

    sec3 = Section("Args", "param", SectionType.MULTIPLE)
    assert sec3.title == "Args"
    assert sec3.key == "param"
    assert sec3.type == SectionType.MULTIPLE    


# Generated at 2022-06-23 17:13:13.721966
# Unit test for constructor of class Section
def test_Section():
    test_title = "title"
    test_key = "key"
    test_type = 1

    print("Testing constructor of class Section...")
    assert Section(test_title, test_key, test_type).title == test_title
    assert Section(test_title, test_key, test_type).key == test_key
    assert Section(test_title, test_key, test_type).type == test_type


if __name__ == "__main__":
    test_Section()

# Generated at 2022-06-23 17:13:24.579132
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

# Generated at 2022-06-23 17:13:25.819253
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert gp.sections == DEFAULT_SECTIONS

# Generated at 2022-06-23 17:13:37.601540
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = """\
This function does something.

Blah blah blah.

Args:
    x (int): blah blah blah.
    y (int): blah blah blah.

Example:
    Some example.

Returns:
    int: the result.

Raises:
    ValueError: if x is not positive.

Raises:
    ImportError: if x is not positive.
"""
    p = GoogleParser()

# Generated at 2022-06-23 17:13:50.549288
# Unit test for function parse
def test_parse():
    def test_function():
        """Test function.

        Parameters:
            foo: test foo (str)
            bar: test bar (int). Defaults to 1.

        Raises:
            TestError: test
            AnotherError: another test

        Returns: something (str).
        """

    doc = parse(inspect.getdoc(test_function))
    assert doc.short_description == "Test function."
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "foo"]
    assert doc.meta[0].description == "test foo (str)"
    assert doc.meta[0].arg_name == "foo"

# Generated at 2022-06-23 17:13:52.002571
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()



# Generated at 2022-06-23 17:14:01.960039
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Testcase 1
    # Input: ""
    # Expected output:
    # Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    assert GoogleParser().parse("") == Docstring()

    # Testcase 2
    # Input: "\n\n\n"
    # Expected output:
    # Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    assert GoogleParser().parse("\n\n\n") == Docstring()

    # Testcase 3
    # Input: "  "
    # Expected output:
    # Docstring(short_description=None, blank_after_short_description=False

# Generated at 2022-06-23 17:14:11.398651
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    '''
    Test the method add_section
    '''

# Generated at 2022-06-23 17:14:14.440931
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = DEFAULT_SECTIONS
    goog_parser = GoogleParser(sections)
    assert goog_parser.title_colon == True



# Generated at 2022-06-23 17:14:26.850209
# Unit test for function parse
def test_parse():
    class Example(object):
        """Blah.

        This is a very long description to test indentation.

        Arguments:
            arg1 (int, optional): this is arg1
            arg2 (str): blah blah blah
            arg3 (bool): this has a default value of True
            arg4 (int): this has a default value of 42
            arg5 (int): this has a default value of -42
            arg6 (int, optional): this has a default value of 0
            arg7 (int, optional): this has a default value of float('inf')
            arg8 (int, optional): this has a default value of float('-inf')

        Returns:
            None

        Raises:
            ValueError: If something wrong happens.

        Examples:
            The following is an example::

                >>> print('hello')
                hello
        """



# Generated at 2022-06-23 17:14:39.011600
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for correct parsing of multiple meta elements
    text = """Summary line.
   
    Extended description.
    
    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
        
    Returns:
       str: Description of return value.
    """
    
    result = GoogleParser().parse(text)
    assert result.short_description == "Summary line."
    assert result.long_description == "Extended description."
    assert isinstance(result.meta[0], DocstringParam)
    assert result.meta[0].arg_name == "arg1"
    assert isinstance(result.meta[1], DocstringParam)
    assert result.meta[1].arg_name == "arg2"
    assert isinstance(result.meta[2], DocstringReturns)
    
    


# Generated at 2022-06-23 17:14:49.049404
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("   ") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert (
        GoogleParser().parse("This is the docstring.")
        == Docstring(
            short_description="This is the docstring.",
            blank_after_long_description=True,
        )
    )
    assert (
        GoogleParser().parse("This is the docstring.\n\n")
        == Docstring(
            short_description="This is the docstring.",
            blank_after_long_description=True,
        )
    )

# Generated at 2022-06-23 17:14:59.537752
# Unit test for function parse

# Generated at 2022-06-23 17:15:08.088453
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
        A short description.
    
        A long description.
    
        Args:
          arg1: text
          arg2: text
    
        Returns:
          text
    """
    parser = GoogleParser()
    parser.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Arg", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Parameters", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Params", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Raises", "raises", SectionType.MULTIPLE))


# Generated at 2022-06-23 17:15:16.898488
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
    ]
    google_parser = GoogleParser(sections)
    assert (
        google_parser.titles_re.pattern
        == "^(Args)|(Example)(:)[ \t\r\f\v]*$"
    )

    sections = [
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
    ]
    google_parser = GoogleParser(sections, False)
    assert google_parser.titles_re.pattern == "^(Args)|(Example)[ \t\r\f\v]*$"



# Generated at 2022-06-23 17:15:20.306929
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    s = Section("TEST", "test", SectionType.SINGULAR)
    p.add_section(s)
    assert p.sections["TEST"] == s

# Generated at 2022-06-23 17:15:24.468067
# Unit test for constructor of class Section
def test_Section():
    title = "title"
    key = "key"
    section_type = 1
    section = Section(title, key, section_type)

    assert section.title == title
    assert section.key == key
    assert section.type == section_type


test_Section()


# Generated at 2022-06-23 17:15:31.736655
# Unit test for function parse
def test_parse():
    res = parse("""
        This is a short description.
    
        This is a long description.
        It's indented after the first line.
    
        Examples:
          First example.
    
            Code example, indented.
    
          Second Example.
    
            More code, indented.
    
        Args:
          arg1:
              First arg. More arg details.
          arg2:
              Second arg. More arg details.
        Returns:
          None
        Raises:
          IOError: An error occurred accessing the bigtable.Table object.
    """)

    assert res.short_description == "This is a short description."

# Generated at 2022-06-23 17:15:43.340660
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Entity:
        def foo(self, a:int, b:str ='bar', *args, **kwargs):
            """Examples:
            foo(1, "bar", {"spam": 1, "eggs": 2}, stuff=["thing"], what={"ever": "bro"})

            :param a: an int
            :params args: other args
            :param kwargs: other keywords
            :param b: a string (Default: 'bar').

            :returns: a tuple of args and kwargs; first el is the int, second is the string
            """
            ret = (a, b) + args, kwargs
            return ret

    text = Entity.foo.__doc__
    docstring = GoogleParser().parse(text)
    assert docstring.blank_after_short_description == False
    assert docstring

# Generated at 2022-06-23 17:15:57.038909
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    instance = GoogleParser()
    def test_method():
        pass
    assert GoogleParser.parse(instance, "")
    assert GoogleParser.parse(instance, test_method.__doc__)
    assert GoogleParser.parse(instance, "This is a docstring")
    assert GoogleParser.parse(instance, "  This is a docstring")
    assert GoogleParser.parse(instance, "    This is a docstring")
    assert GoogleParser.parse(instance, "This is a docstring.\n")
    assert GoogleParser.parse(instance, "This is a docstring.\n\n")
    assert GoogleParser.parse(instance, "This is a docstring.\n\nThis is the long description.")
    assert GoogleParser.parse(instance, "This is a docstring.\n\nThis is the long description.\n")
