

# Generated at 2022-06-23 17:06:06.262923
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:06:16.809405
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test method parse of class GoogleParser"""
    text = """
        Short description.

        Long description.

        Args:
            arg1: First argument
            arg2: Second argument
            arg3: Third argument
            arg4: Fourth argument

        Returns:
            Returns something.

        Examples:
            Some examples
    """
    docstring = GoogleParser().parse(text=text)
    print(docstring.short_description)
    print(docstring.blank_after_short_description)
    print(docstring.long_description)
    print(docstring.blank_after_long_description)
    print(docstring.meta)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:06:17.997258
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-23 17:06:22.286419
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:06:27.358148
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_str = '''
    test of Google-style docstring parsing.
    '''
    parser = GoogleParser()
    doc = parser.parse(doc_str)
    if doc.short_description != 'test of Google-style docstring parsing.':
        raise TestFail('parser.parse()')


# Generated at 2022-06-23 17:06:35.536186
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    docstring = "This is a docstring"
    parser = GoogleParser()
    section1 = Section("Section1", "Section1", SectionType.MULTIPLE)
    section2 = Section("Section2", "Section2", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(section1)
    parser.add_section(section2)
    assert parser.sections["Section1"] == section1
    assert parser.sections["Section2"] == section2
    assert parser.parse(docstring) == GoogleParser().parse(docstring)

# Generated at 2022-06-23 17:06:40.289775
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test add and replace a section
    parser = GoogleParser()
    parser.add_section(Section("Params", "param", SectionType.MULTIPLE))
    assert parser.sections["Params"].title == "Params"
    parser.add_section(Section("Params", "param", SectionType.SINGULAR))
    assert parser.sections["Params"].type == SectionType.SINGULAR

# Generated at 2022-06-23 17:06:52.792688
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def x():
        """
        This is test for method parse of class GoogleParser.


        Args:
            arg1 (str): string arg
            arg2 (str): string arg

        Returns:
            int: return number
        """
        pass

    x_docstring = parse(x.__doc__)
    print(x_docstring)

    assert type(x_docstring) == Docstring
    assert type(x_docstring.short_description) == str
    assert type(x_docstring.long_description) == str
    assert type(x_docstring.blank_after_short_description) == bool
    assert type(x_docstring.blank_after_long_description) == bool
    assert type(x_docstring.meta) == list
    assert len(x_docstring.meta) == 3
   

# Generated at 2022-06-23 17:06:57.753978
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GOOGLEPARSER = GoogleParser()
    GOOGLEPARSER.add_section(Section("Summary", "summary", SectionType.MULTIPLE))
    assert GOOGLEPARSER.sections["Summary"] == Section("Summary", "summary", SectionType.MULTIPLE)



# Generated at 2022-06-23 17:07:06.934305
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    #Add section with title "Args"
    p.add_section(Section("Args","args",SectionType.MULTIPLE))
    #Add section with title "Arguments"
    p.add_section(Section("Arguments","arguments",SectionType.MULTIPLE))
    #Add section with title "Params"
    p.add_section(Section("Params","params",SectionType.MULTIPLE))
    #Add section with title "Parameters"
    p.add_section(Section("Parameters","parameters",SectionType.MULTIPLE))
    #Add section with title "Raises"
    p.add_section(Section("Raises","raises",SectionType.MULTIPLE))
    #Add section with title "Exceptions"

# Generated at 2022-06-23 17:07:08.111671
# Unit test for constructor of class Section
def test_Section():
    assert len(Section.__slots__) == 3
    assert Section.__doc__ == "A docstring section."



# Generated at 2022-06-23 17:07:08.990428
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser() is not None

# Generated at 2022-06-23 17:07:10.833054
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()
    assert GoogleParser(title_colon=False)
    assert GoogleParser(title_colon=True)



# Generated at 2022-06-23 17:07:22.084233
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test init()
    parser = GoogleParser()
    assert parser.title_colon is True

# Generated at 2022-06-23 17:07:24.127103
# Unit test for constructor of class Section
def test_Section():
    print("test_Section")
    s = Section("name", "type", "key")
    print(s)



# Generated at 2022-06-23 17:07:28.336398
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Test", "test", SectionType.MULTIPLE))
    doc = parser.parse("Test:\n  param\n  ret\n")
    assert len(doc.meta) == 2
    assert doc.meta[0].arg_name == "param"
    assert doc.meta[1].arg_name == "ret"

# Generated at 2022-06-23 17:07:36.744421
# Unit test for function parse
def test_parse():
    """Docstring class."""
    docstring = parse(
        """Hello world.
             :param input: the input
             :param output: the output
             :returns: Description of return value
             :raises Exception: Description of exception.
             :param input2: the input
             :param output2: the output
           """
    )
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta)
    assert docstring.short_description == 'Hello world.'
    assert docstring.long_description == 'the input the output Description of return value Description of exception. the input the output'

# Generated at 2022-06-23 17:07:40.404101
# Unit test for constructor of class Section
def test_Section():
    s = Section("title", "key", 0)
    assert s.title == "title"
    assert s.key == "key"
    assert s.type == 0
    assert s is not None and s is not False


# Generated at 2022-06-23 17:07:49.077759
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''Solve linear least-squares problem.

Given m m-by-n matrices `A` and `B`, solves the least-squares problem::

    minimize norm(dot(A, x) - B)

This problem has a unique solution if `A` has full column rank.

:param A: m-by-n matrix
:param B: m-by-r matrix
:returns: n-by-r matrix
:raises LinAlgError: If `A` does not have full column rank
'''
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == 'Solve linear least-squares problem.'

# Generated at 2022-06-23 17:08:00.779207
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:08:09.326070
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print("\n##### Unit test for GoogleParser ####")
    print("\n## Test 1 ##")
    print("Test for constructor of class GoogleParser")
    google_parser = GoogleParser()

# Generated at 2022-06-23 17:08:11.060303
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert(GoogleParser())


# Generated at 2022-06-23 17:08:15.432282
# Unit test for function parse
def test_parse():

    def func(param1, param2=None):
        """
        func docstring
        :param param1: param1 description
        :param param2: param2 description
        """
        pass

    print(parse(func.__doc__))
    print("\n")

# Generated at 2022-06-23 17:08:28.545331
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """Example function with types documented in the docstring.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.
        param3 (bool, optional): The third parameter. Defaults to True.

    Returns:
        int: The return value. True for success, False otherwise.
    """
    result = parser.parse(docstring)
    assert result.short_description == "Example function with types documented in the docstring."
    assert result.long_description is None
    assert len(result.meta) == 3
    assert result.meta[0].args[1] == "param1 (int)"
    assert result.meta[0].description == "The first parameter."
    assert result.meta[1].args[1] == "param2 (str)"
   

# Generated at 2022-06-23 17:08:35.382009
# Unit test for constructor of class Section
def test_Section():
    # Section("Arguments", "param", SectionType.MULTIPLE),
    assert Section("Arguments", "param", SectionType.MULTIPLE).title == "Arguments"
    assert Section("Arguments", "param", SectionType.MULTIPLE).key == "param"
    assert Section("Arguments", "param", SectionType.MULTIPLE).type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:08:44.826883
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from fuzzywuzzy import fuzz
    
    1/0
    assert bool(fuzz.ratio("this is a test", "this is a test!"))
    assert fuzz.ratio("this is a test", "this is a test!") == 100
    assert fuzz.partial_ratio("this is a test", "this is a test!") == 100
    assert fuzz.token_sort_ratio("fuzzy wuzzy was a bear", "wuzzy fuzzy was a bear") == 100
    assert fuzz.token_set_ratio("fuzzy was a bear", "fuzzy fuzzy was a bear") == 100
    
    def parse(text: str) -> Docstring:
        """Parse the Google-style docstring into its components.
        
        :returns: parsed docstring
        """

# Generated at 2022-06-23 17:08:51.140767
# Unit test for constructor of class Section
def test_Section():
    # Test case 1
    # The expected result is that the code is executed without any exceptions
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    GoogleParser(sections)
    # Test case 2
    # The expected result is that the code is executed without any exceptions
    GoogleParser(title_colon= False)


# Generated at 2022-06-23 17:08:58.151582
# Unit test for constructor of class Section
def test_Section():
    # Test with valid input
    name = "Arguments"
    key = "param"
    type = SectionType.MULTIPLE
    section = Section(name, key, type)
    assert section.title == name
    assert section.key == key
    assert section.type == type

    # Test with invalid input
    try:
        section = Section(None, key, type)
    except Exception as e:
        assert type(e) == AssertionError

    try:
        section = Section(name, None, type)
    except Exception as e:
        assert type(e) == AssertionError

    try:
        section = Section(name, key, None)
    except Exception as e:
        assert type(e) == AssertionError


# Generated at 2022-06-23 17:09:05.327500
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Example function with types documented in the docstring.

    Args:
       param1 (int): The first parameter.
       param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.
        """

    parsed = GoogleParser().parse(docstring)
    print(parsed)
    assert(len(parsed.meta) == 3) # there are 3 sections in the doc-string
    _, _, returns = parsed.meta

    assert(returns.args == ['returns', 'bool'])

# Generated at 2022-06-23 17:09:14.219072
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:09:19.635019
# Unit test for constructor of class Section
def test_Section():
    SEC = Section('Arguments', 'param', SectionType.MULTIPLE)
    assert SEC.title == 'Arguments'
    assert SEC.key == 'param'
    assert SEC.type == SectionType.MULTIPLE

if __name__ == "__main__":
    test_Section()

# Generated at 2022-06-23 17:09:28.055386
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert(len(GoogleParser().sections) == 14)

    # This is a new GoogleParser object to test so the default values are set
    # in the init function
    gp = GoogleParser(title_colon=False)
    assert(len(gp.sections) == 14)
    assert(gp.title_colon == False)

    # Now test adding a section to the GoogleParser object
    new_section = Section('Blah', 'blah', SectionType.SINGULAR)
    gp.add_section(new_section)
    assert(len(gp.sections) == 15)
    assert(len(gp.sections['Blah']) == 3)
    assert(gp.sections['Blah'] == new_section)



# Generated at 2022-06-23 17:09:31.603345
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """Test the constructor of class GoogleParser"""
    try:
        parser = GoogleParser()
    except Exception:
        assert False, "Unexpected Exception"
    return True



# Generated at 2022-06-23 17:09:41.361816
# Unit test for function parse
def test_parse():
    parser = GoogleParser(title_colon=True)
    ret = parser.parse("""\
title: short

long
""")
    assert ret.short_description == "title"
    assert ret.blank_after_short_description
    assert ret.long_description == "long"
    assert ret.blank_after_long_description
    assert not ret.meta

    ret = parser.parse("title:\n")
    assert ret.short_description == "title"
    assert not ret.long_description
    assert not ret.meta
    ret = parser.parse("title: short\n")
    assert ret.short_description == "title"
    assert not ret.long_description
    assert not ret.meta

    ret = parser.parse("""\
title: short
long
""")

# Generated at 2022-06-23 17:09:43.017355
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser()
    assert p
    # TODO: Complete this test


# Generated at 2022-06-23 17:09:56.093339
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #testcase 1
    text = """Defined in tensorflow/python/ops/resource_variable_ops.py.
Args:
  create: Python bool indicating whether to create the resource.
    If create is False and the resource does not exist, raise
    a ResourceExhaustedError.
"""

# Generated at 2022-06-23 17:10:03.673775
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    text = """
    Parameters
    ----------
    x : int
        Describe x here.
        Multi-line descriptions work fine too, using triple-double quotes.

        If this sounds complicated, it is!
    y : int
        Describe y here.
    """

    docstring = GoogleParser().parse(text)

    print(docstring.short_description)
    # None

    print(docstring.long_description)
    # None

    for meta in docstring.meta:
        print("\n")
        print("arguments: {}".format(meta.args))
        print("description: {}".format(meta.description))


# Generated at 2022-06-23 17:10:08.701214
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    docstring = """
        This is a sample function.

        Args:
            a (int): The first parameter.
            b (float, optional): The second parameter. Defaults to 10.

        Returns:
            bool: The return value. True for success, False otherwise.
        """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a sample function."



# Generated at 2022-06-23 17:10:09.546386
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser



# Generated at 2022-06-23 17:10:11.220344
# Unit test for function parse
def test_parse():
    from .test_docstring_parser import test
    test(parse)

# Generated at 2022-06-23 17:10:12.563498
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().title_colon == True


# Generated at 2022-06-23 17:10:23.003488
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    local_GoogleParser = GoogleParser()  # This line is the only difference from the original parse.py
    assert(local_GoogleParser.sections['Arguments'] == Section('Arguments', 'param', 0))
    assert(local_GoogleParser.sections['Returns'] == Section('Returns', 'returns', 2))
    assert(local_GoogleParser.sections['Raises'] == Section('Raises', 'raises', 0))
    assert(local_GoogleParser.title_colon == True)

    my_sections = [
            Section('Args', 'param', 2),
            Section('Returns', 'returns', 2)
        ]
    local_GoogleParser = GoogleParser(sections = my_sections)
    assert(local_GoogleParser.sections['Args'] == Section('Args', 'param', 2))

# Generated at 2022-06-23 17:10:24.076228
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert type(GoogleParser()) == GoogleParser

# Generated at 2022-06-23 17:10:31.516280
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    docstring=GoogleParser(sections=None,title_colon=True)
    docstring.add_section(Section("See Also", "see", SectionType.SINGULAR))
    return docstring

if __name__ == "__main__":
    print ("Unit test for method add_section of class GoogleParser")
    print (test_GoogleParser_add_section().sections)

# Generated at 2022-06-23 17:10:35.755530
# Unit test for constructor of class Section
def test_Section():
    section = Section(title = 'title', key = 'key', type = SectionType.SINGULAR)
    assert section.title == 'title'
    assert section.key == 'key'
    assert section.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:10:38.766814
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Test", "test", SectionType.MULTIPLE))
    assert '"Test"' in parser.titles_re.pattern


# Generated at 2022-06-23 17:10:51.908714
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    from .common import Section
    from .google import GoogleParser
    section1 = Section('section1', 'section1', 0)
    section2 = Section('section2', 'section2', 0)
    section3 = Section('section3', 'section3', 0)
    parser1 = GoogleParser()
    parser2 = GoogleParser()
    parser2.add_section(section1)
    parser1.add_section(section1)
    parser1.add_section(section2)
    assert parser1.sections['section1'] == parser2.sections['section1']
    assert parser1.sections['section2'] != parser2.sections['section2']
    assert 'section3' not in parser1.sections
    assert 'section3' not in parser2.sections

    # Pre-defined section

# Generated at 2022-06-23 17:11:01.241461
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:11:03.673209
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert DEFAULT_SECTIONS == GoogleParser().sections



# Generated at 2022-06-23 17:11:15.822977
# Unit test for constructor of class Section
def test_Section():
    # Create some Section objects
    section1 = Section(title="title1", key="key1", type=SectionType.SINGULAR)
    section2 = Section(title="title2", key="key2", type=SectionType.MULTIPLE)
    section3 = Section(title="title3", key="key3", type=3)

    assert section1.title == "title1"
    assert section1.key == "key1"
    assert section1.type == SectionType.SINGULAR
    assert str(section1) == "Section(title='title1', key='key1', type=<SectionType.SINGULAR: 0>)"
    assert repr(section1) == "Section(title='title1', key='key1', type=<SectionType.SINGULAR: 0>)"


# Generated at 2022-06-23 17:11:20.300303
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    Tests the add_section method of the GoogleParser class
    """
    parser = GoogleParser()
    new_section = Section("The new section", "new_section", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(new_section)
    assert parser.sections["The new section"] == new_section


# Generated at 2022-06-23 17:11:26.971697
# Unit test for function parse
def test_parse():
    def func():
        """Function docstring.

        Args:
            arg1 (str): argument 1
            arg2 (int): argument 2
            *args: variable length arguments
            **kwargs: arbitrary keyword arguments

        Examples:
            >>> func(1, 2)
            3
            >>> func(1, 2, 3)
            6
            >>> func(1, 2, 3, 4)
            10

        Returns:
            str: something

        Raises:
            ValueError: if something is wrong
        """

    docstring = parse(func.__doc__)
    assert docstring.short_description == "Function docstring."
    assert docstring.long_description == ""
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False


# Generated at 2022-06-23 17:11:29.095597
# Unit test for constructor of class Section
def test_Section():
    abcd = Section("title","key",0)
    assert abcd.title == "title"

# Generated at 2022-06-23 17:11:32.971468
# Unit test for constructor of class Section
def test_Section():
    assert Section("section1", "key1", SectionType.SINGULAR) == \
            Section(title="section1", key="key1", type=0)
    return True


# Generated at 2022-06-23 17:11:43.309838
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    docstring = """
    This is the summary line.

    Args:
        arg_0: The first argument.
        arg_1 (str): The second argument.

    Kwargs:
        kwarg_0 (bool): The first keyword-only argument (defaults to True).

    Example:
        Examples can be given using either the ``Example`` or ``Examples``
        sections. Sections support any reStructuredText formatting, including
        literal blocks::

            $ python example_google.py
    """


# Generated at 2022-06-23 17:11:55.664246
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    doc = GoogleParser()

# Generated at 2022-06-23 17:12:08.548135
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse(None) == Docstring()
    assert GoogleParser().parse('') == Docstring()

# Generated at 2022-06-23 17:12:16.066152
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert len(parser.sections) == 12
    assert parser.title_colon
    assert (
        isinstance(parser.titles_re, type(re.compile("")))
        and parser.titles_re.flags == re.M
    )

    # If arguments are not specified, default titles are used
    parser = GoogleParser([])
    assert len(parser.sections) == 12
    assert parser.title_colon
    assert (
        isinstance(parser.titles_re, type(re.compile("")))
        and parser.titles_re.flags == re.M
    )

    # If arguments are specified, they are used

# Generated at 2022-06-23 17:12:26.735059
# Unit test for function parse
def test_parse():
    desc = parse("""
    This is a summary.

    This is a description.

    Args:
        name: The function name.
        code: The function code.
        args: The arguments.
    """
    )
    assert desc.short_description == "This is a summary."
    assert desc.blank_after_short_description
    assert desc.long_description == "This is a description."
    assert desc.blank_after_long_description
    assert desc.meta[0].key == "param"
    assert desc.meta[0].args == ["param", "name"]
    assert desc.meta[0].description == "The function name."
    assert desc.meta[1].key == "param"
    assert desc.meta[1].args == ["param", "code"]

# Generated at 2022-06-23 17:12:30.019405
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE

# Generated at 2022-06-23 17:12:38.720073
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Tested function
    from utix._util.parser import GoogleParser
    parse = GoogleParser().parse
    # Suppose we have a docstring like this
    docstring = \
"""Summary line.
Parameters
----------
arg1 : int
    Description of `arg1`.
arg2 : str
    Description of `arg2`.
Returns
-------
int
    Description of return value.
Other Parameters
----------------
arg3 : list of ints
    Description of `arg3`.
"""
    parse(docstring)
    # The above docstring will be parsed into a Docstring instance,
    # which has the following attributes and their corresponding values

# Generated at 2022-06-23 17:12:49.558057
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:12:53.886029
# Unit test for constructor of class Section
def test_Section():
    title = "title"
    key = "key"
    section = Section(title, key, SectionType.SINGULAR)
    assert section.title == title
    assert section.key == key
    assert section.type == SectionType.SINGULAR

# Generated at 2022-06-23 17:13:02.595908
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Args:
    df (DataFrame): input DataFrame
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == ""
    assert docstring.long_description == ""
    assert docstring.meta[0].args == ['param', 'df (DataFrame)']
    assert docstring.meta[0].arg_name == 'df'
    assert docstring.meta[0].description == "input DataFrame"
    assert docstring.meta[0].type_name == 'DataFrame'
    assert docstring.meta[0].is_optional == False
    assert docstring.meta[0].default == None
    assert docstring.meta[0].is_attribute == False
    assert docstring.meta[0].is_generator == False

# Generated at 2022-06-23 17:13:08.284728
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser(None, False)
    parser = GoogleParser(DEFAULT_SECTIONS, True)

    parser = GoogleParser()
    assert parser.sections["Example"] == Section("Example", "examples", SectionType.SINGULAR)
    assert parser.sections["Raises"] == Section("Raises", "raises", SectionType.MULTIPLE)



# Generated at 2022-06-23 17:13:11.164648
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key", SectionType.MULTIPLE)
    assert section.title == "title"
    assert section.key == "key"
    assert section.type == SectionType.MULTIPLE



# Generated at 2022-06-23 17:13:14.554067
# Unit test for constructor of class Section
def test_Section():
    section = Section("Example", "example", SectionType.SINGULAR)
    if (section.title != "Example") or (section.key != "example") or (section.type != SectionType.SINGULAR):
        raise Exception('test_Section() failed')

# Generated at 2022-06-23 17:13:25.487749
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = ''
    ret = Docstring()
    assert GoogleParser().parse(text) == ret

    text = 'summary\n    description'
    ret = Docstring(
        short_description='summary',
        long_description='description',
        meta=[],
        blank_after_long_description=True,
        blank_after_short_description=False
    )
    assert GoogleParser().parse(text) == ret

    # title without colon
    text = 'summary\n    description\nArguments:\n    - arg_name: arg desc\n'

# Generated at 2022-06-23 17:13:26.994294
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()._setup() == None

# Generated at 2022-06-23 17:13:33.200250
# Unit test for function parse
def test_parse():
    assert(parse("")==Docstring())
    assert(parse("Test")==Docstring(short_description='Test'))
    assert(parse("\n".join(["","Test",""]))==Docstring(short_description='Test'))
    assert(parse("\n".join(["","","","Test","",""]))==Docstring(short_description='Test'))
    assert(parse("\n".join(["", "Test", "Long descr","",""]))==Docstring(short_description='Test', long_description='Long descr', blank_after_short_description=True, blank_after_long_description=False))

# Generated at 2022-06-23 17:13:34.433474
# Unit test for constructor of class Section
def test_Section():
    pass


# Generated at 2022-06-23 17:13:43.333256
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    This function does something.

    This is a longer explanation of this function.  Note that there
    aren't any specifics in here.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        description of what is returned
    Raises:
        KeyError: Raises an exception.
    """

# Generated at 2022-06-23 17:13:54.916207
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    
    def f(x, y = None):
        """Parsing a docstring
        
        Parameters
        ----------
        x : type
            Description of parameter `x`.
        y : type, optional
            Description of parameter `y`.

        """
        return x
    google_parser = GoogleParser()
    docstring = google_parser.parse(f.__doc__)
    assert docstring.short_description == "Parsing a docstring"
    assert docstring.long_description == "Parameters\n----------\nx : type\n    Description of parameter `x`.\ny : type, optional\n    Description of parameter `y`."
    assert len(docstring.meta) == 2
    meta_1, meta_2 = docstring.meta 
    assert meta_1.args[0] == "param"

# Generated at 2022-06-23 17:13:56.800902
# Unit test for function parse
def test_parse(): 
    doc = parse.__doc__
    str(parse(doc))



# Generated at 2022-06-23 17:14:02.438987
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    global test_GoogleParser_parse_code
    parser = GoogleParser()
    value = parser.parse(test_GoogleParser_parse_code)
    print(value)

test_GoogleParser_parse_code="""
    This is a simple function.

    Args:
      animal (str): The animal to describe.
      age (int): The age of the animal.

    Returns:
      str: A description of the animal.
    """

# Generated at 2022-06-23 17:14:12.350696
# Unit test for function parse
def test_parse():
    """Test parser."""
    from .common import Docstring, DocstringParam

    def test_func(a, b, *args, c=None, d=1, e=2, **kwargs):
        """Test function

        :param a: A test parameter.
        :type a: int
        :param b: Another test parameter.
        :raises: Exception
        :rtype: int
        """

    doc = parse(inspect.getdoc(test_func))
    assert doc.short_description == "Test function"
    assert doc.long_description == (
        ":param a: A test parameter.\n"
        ":type a: int\n"
        ":param b: Another test parameter.\n"
        ":raises: Exception\n"
        ":rtype: int"
    )


# Generated at 2022-06-23 17:14:16.153819
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.sections is not None
    assert parser.sections['Arguments'] is not None
    assert isinstance(parser.sections['Arguments'].type, SectionType)


# Generated at 2022-06-23 17:14:24.820772
# Unit test for function parse
def test_parse():
    def foo():
        """
        Some description

        :param x: argument description
        """

    assert parse(foo.__doc__) == Docstring(
        short_description="Some description",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        meta=[
            DocstringMeta(
                args=["param", "x"],
                description="argument description",
            )
        ],
    )


# Generated at 2022-06-23 17:14:26.216705
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """Unit test for constructor of class GoogleParser"""
    GoogleParser()


# Generated at 2022-06-23 17:14:32.324299
# Unit test for constructor of class Section
def test_Section():
    # Making a google style
    print('Testing constructor of class Section()')

    # Making a google style
    test_obj = Section("arguments","param",SectionType.MULTIPLE)

    # Asserting that the title is the same
    assert test_obj.title == "arguments"

    # Asserting that the key is the same
    assert test_obj.key == "param"

    # Asserting that the type is the same
    assert test_obj.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:14:38.961240
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    file1 = open("Google_method_docstring.txt", "r")
    google_method_docstring = file1.read()
    file2 = open("Google_class_docstring.txt", "r")
    google_class_docstring = file2.read()
    docstring = parse(google_method_docstring)
    print(docstring)


# Generated at 2022-06-23 17:14:49.021475
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    docstring = """
    Protocol to represent heterogeneous arrays of data.

    Parameters
    ----------
    x :
        Some description.

    y :
        Some description.

    *args
        Some description.

    **kwargs
        Some description.

    Examples
    --------
    >>> f(1, 2)
    3
    """

    docstring_parser = GoogleParser()
    parsed_docstring = docstring_parser.parse(docstring)
    print(parsed_docstring.short_description)
    print(parsed_docstring.long_description)
    print(parsed_docstring.meta[0].description)
    print(parsed_docstring.meta[0].args)
    print(parsed_docstring.meta[1].description)

# Generated at 2022-06-23 17:14:55.933152
# Unit test for function parse
def test_parse():
    doc = """
        example module.

        :param foo: foo
        :param bar: bar

        Example:

            >>> import example
            >>> example.add(2, 3)
            5
            >>> example.sub(5, 3)
            2
    """
    docstring = parse(doc)
    print(docstring.short_description)
    print(docstring.long_description)
    for meta in docstring.meta:
        print(meta)



# Generated at 2022-06-23 17:14:59.085178
# Unit test for constructor of class Section
def test_Section():
    section = Section("Title", "key", SectionType.MULTIPLE)
    assert section.title == "Title"
    assert section.key == "key"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:15:07.856686
# Unit test for function parse

# Generated at 2022-06-23 17:15:08.623721
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-23 17:15:18.287066
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .google_parser import GoogleParser
    from .common import Docstring
    from .common import DocstringParam
    from .common import DocstringRaises
    from .common import DocstringReturns

    text = """
    Short summary.

    Longer description.
    """
    expected = Docstring(short_description = "Short summary.",
                         long_description = "Longer description.",
                         blank_after_short_description = False,
                         blank_after_long_description = True,
                         meta = [])
    actual = GoogleParser().parse(text)
    assert expected == actual

    text = """
    Short summary.

    Longer description.

    :param param param1: this is a short description
        of a long argument.
    """

# Generated at 2022-06-23 17:15:20.525026
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Below", "below", SectionType.MULTIPLE))
    print(gp.sections)

# Generated at 2022-06-23 17:15:25.102643
# Unit test for constructor of class Section
def test_Section():
    section = Section("Returns", "returns", SectionType.MULTIPLE)
    assert section.title == "Returns"
    assert section.key == "returns"
    assert section.type == SectionType.MULTIPLE
# Test whether the title, key and type are reassigned correctly or not when
# the method add_section is called

# Generated at 2022-06-23 17:15:31.002143
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    p.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    try:
        p.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    except TypeError:
        print("add_section: duplicate")
    print("add_section: end")


# Generated at 2022-06-23 17:15:42.870858
# Unit test for function parse
def test_parse():
    text = """\
    Short description.

    Long description.

    Args:
        a (b): c. Defaults to 1.
        d (e): f. Defaults to 2.

    Kwargs:
        g (h): i. Defaults to 3.
        j (k, optional): l.

    Yields:
        m: n.

    Example:
        o: p. Defaults to 4.

    Raises:
        q: r.
    """
    doc = parse(text)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 7
    assert doc.meta[0].args == ["param", "a (b)"]
    assert doc.meta[0].description == "c. Defaults to 1."

# Generated at 2022-06-23 17:15:56.388774
# Unit test for method parse of class GoogleParser