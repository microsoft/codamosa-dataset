

# Generated at 2022-06-23 17:05:58.369201
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse('load_dataset(filename)\n\
        Load a Pickle file from the local, or HTTP or FTP server.\n\
        Args:\n\
            filename (str): File to load.\n\
        """')
    assert docstring.short_description == "Load a Pickle file from the local, or HTTP or FTP server."



# Generated at 2022-06-23 17:06:04.956765
# Unit test for function parse
def test_parse():
    docstring = """
    Function definition.

    Args:
        some_arg: some_arg.

    Returns:
        returns.

    Examples:
        example.
    
    """
    expected = Docstring(
        short_description="Function definition.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[
            DocstringParam('param','some_arg','some_arg','',False),
            DocstringReturns('returns','returns',None,False),
            DocstringMeta('examples','example')
        ]
    )
    
    assert expected == parse(docstring)

# Generated at 2022-06-23 17:06:16.847528
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test parameters
    TYPE_INT = "int"
    """Type of int."""
    TYPE_BOOL = "bool"
    """Type of bool."""
    TYPE_ARRAY_INT = "list[int]"
    """Type of list[int]."""
    TYPE_ARRAY_BOOL = "list[bool]"
    """Type of list[bool]."""
    DOCSTRING_RETURNS_TYPE_INT = "The function returns an int"
    """Description for return value for function with return type int"""
    DOCSTRING_RETURNS_TYPE_BOOL = "The function returns a bool"
    """Description for return value for function with return type bool"""
    DOCSTRING_RETURNS_TYPE_ARRAY_INT = "The function returns a list[int]"

# Generated at 2022-06-23 17:06:29.392895
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
        This is a short description.
        
        This is a long description. This is a long description. This is a long description. 
        This is a long description. This is a long description. This is a long description.
        
        Args:
            header (str): This is the argument description.
            header2 (str): This is the second argument description.
            
        Returns:
            This is the return description.
    """
    parsed = parse(text)

    assert parsed.short_description == "This is a short description."
    assert parsed.long_description == "This is a long description. This is a long description. This is a long description. This is a long description. This is a long description. This is a long description."
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long

# Generated at 2022-06-23 17:06:35.741328
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = '''
        This function prints a nice Hello message
        Such a fun thing to do!

        Args:
            name (str): Name of person to say hello to.
            count (int, optional): Number of times to say hello.

        Returns:
            A string containing the hello message.
    '''
    print(parser.parse(docstring))

# Generated at 2022-06-23 17:06:43.738474
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test parse method of class GoogleParser"""
    text = """
    """
    assert parse(text).short_description == None
    assert parse(text).long_description == None
    assert parse(text).blank_after_short_description == False
    assert parse(text).blank_after_long_description == False
    assert parse(text).meta == []

    text = """\
    """
    assert parse(text).short_description == None
    assert parse(text).long_description == None
    assert parse(text).blank_after_short_description == False
    assert parse(text).blank_after_long_description == False
    assert parse(text).meta == []

    text = ""
    assert parse(text).short_description == None
    assert parse(text).long_description == None
    assert parse(text).blank_after_

# Generated at 2022-06-23 17:06:49.991279
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE
    assert section.title == section[0]
    assert section.key == section[1]
    assert section.type == section[2]


# Generated at 2022-06-23 17:06:53.175411
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:07:02.679972
# Unit test for constructor of class Section
def test_Section():
    assert (Section("Return", "returns", SectionType.MULTIPLE) ==
            Section("Return", "returns", SectionType.MULTIPLE))
    assert (Section("Return", "returns", SectionType.MULTIPLE) !=
            Section("Return", "returns", SectionType.SINGULAR))
    assert (Section("Return", "returns", SectionType.MULTIPLE) !=
            Section("Return", "returns", SectionType.SINGULAR_OR_MULTIPLE))
    assert (Section("Return", "returns", SectionType.MULTIPLE) !=
            Section("Returns", "returns", SectionType.MULTIPLE))
    assert (Section("Return", "returns", SectionType.MULTIPLE) !=
            Section("Return", "return", SectionType.MULTIPLE))


# Generated at 2022-06-23 17:07:11.316475
# Unit test for constructor of class Section
def test_Section():
    Section1 = Section("Arguments", "param", SectionType.MULTIPLE)
    assert ("Arguments" == Section1.title)
    assert ("param" == Section1.key)
    assert (SectionType.MULTIPLE == Section1.type)
    Section2 = Section("Example", "examples", SectionType.SINGULAR)
    assert ("Example" == Section2.title)
    assert ("examples" == Section2.key)
    assert (SectionType.SINGULAR == Section2.type)
    Section3 = Section("Args", "param", SectionType.MULTIPLE)
    assert ("Args" == Section3.title)
    assert ("param" == Section3.key)
    assert (SectionType.MULTIPLE == Section3.type)

# Generated at 2022-06-23 17:07:22.645754
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import DocstringParam, DocstringRaises, DocstringReturns, DocstringMeta
    # Default parser
    docstring = """Calculates the squared-error.
        Args:
            error (float): The difference between the predicted value and the actual label
        Returns:
            The squared-error
        """

# Generated at 2022-06-23 17:07:25.970515
# Unit test for constructor of class Section
def test_Section():
    section = Section("Raises", "raises", SectionType.MULTIPLE)
    assert section.title == "Raises"
    assert section.key == "raises"
    assert section.type == SectionType.MULTIPLE

# Unit tests for constructor of class GoogleParser

# Generated at 2022-06-23 17:07:35.802204
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
    Public method to use the GoogleParser to parse a docstring.

    Args:
        text (String): docstring.
    Returns:
        :obj:`Docstring`: parsed docstring.
    """
    g = GoogleParser()
    sec = Section("arg", "Args", SectionType.MULTIPLE)
    g.add_section(sec)
    parsed = g.parse(text)
    assert len(parsed.meta) == 1
    assert isinstance(parsed.meta[0], DocstringParam)
    assert parsed.meta[0].arg_name == "text"
    assert parsed.meta[0].type_name == "String"
    assert parsed.meta[0].is_optional is None
    assert parsed.meta[0].default is None
    assert parsed.meta[0].description

# Generated at 2022-06-23 17:07:40.639208
# Unit test for function parse
def test_parse():
    parser = GoogleParser()

    text = """
        Short description.

        Long description.

        Args:
            arg1 (str): argument 1. Defaults to None.
            arg2 (str): argument 2. Defaults to None.

        Returns (int):
            return value

        Raises:
            ValueError: if error
    """
    d = parser.parse(text)
    assert d.short_description == "Short description."
    assert d.long_description == "Long description."
    assert d.blank_after_short_description
    assert not d.blank_after_long_description
    assert d.meta[0].args == ("param", "arg1 (str): argument 1. Defaults to None.")
    assert d.meta[0].arg_name == "arg1"
    assert d.meta[0].type_name

# Generated at 2022-06-23 17:07:44.566963
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = DEFAULT_SECTIONS
    parser = GoogleParser(sections)
    title = 'Titolo'
    key = 'chiave'
    type = SectionType.SINGULAR
    section = Section(title, key, type)
    parser.add_section(section)
    assert parser.sections[title].title == title
    assert parser.sections[title].key == key
    assert parser.sections[title].type == type

# Generated at 2022-06-23 17:07:48.430122
# Unit test for function parse
def test_parse():
    text = """Summary line.
                                          Extended description.

    Args:
        arg1(str): The first argument.
        arg2(int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        ValueError: The error to raise.
    """
    print(parse(text))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:07:51.748076
# Unit test for constructor of class Section
def test_Section():
    section = Section('Arguments', 'param', SectionType.MULTIPLE)
    print(section.title)
    print(section.key)
    print(section.type)


# Generated at 2022-06-23 17:07:57.006023
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = "Parameters:\n\
            \n\
            p1: first parameter\n\
            \n\
            p2: second parameter"
    section = Section("Parameters", "param", SectionType.MULTIPLE)
    p = GoogleParser()
    p.add_section(section)
    assert p.parse(text) == parse(text)



# Generated at 2022-06-23 17:08:01.768515
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print("\n---------- testing constructor of class GoogleParser -----------")
    print(GoogleParser())
    print(GoogleParser(None))
    print(GoogleParser(DEFAULT_SECTIONS))
    print(GoogleParser(title_colon=False))


# Generated at 2022-06-23 17:08:07.835619
# Unit test for function parse
def test_parse():
    """Unit test for the function parse."""
    # Simple test
    text = """
    Args:
        a: first arg
        b: second arg
    Returns:
        None.
    """
    assert isinstance(parse(text), Docstring)

    # Simple test without required fields
    text = """
    Args:
        a: first arg

    Returns:
        None.
    """
    assert isinstance(parse(text), Docstring)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:08:18.211357
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    # Constructor of class GoogleParser

# Generated at 2022-06-23 17:08:30.930220
# Unit test for function parse
def test_parse():
    text = '''
        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.

        Returns:
            int: The return value.
    '''

# Generated at 2022-06-23 17:08:42.408711
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("    ") == Docstring()
    assert GoogleParser().parse("First line.") == Docstring(
        short_description="First line.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert GoogleParser().parse("First line.\n") == Docstring(
        short_description="First line.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-23 17:08:54.569536
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(""" 
    Parses the Google-style docstring into its components.
    
    Args:
        text (str): The docstring to parse
    
    Returns:
        The parsed docstring.
    """)

    assert(docstring.short_description == "Parses the Google-style docstring into its components.")
    assert(docstring.blank_after_short_description)
    assert(docstring.long_description == """Args:
        text (str): The docstring to parse
    
    Returns:
        The parsed docstring.""")
    assert(docstring.blank_after_long_description)
    assert(len(docstring.meta) == 2)
    assert(docstring.meta[0].args == ['param', 'text (str)'])

# Generated at 2022-06-23 17:08:58.151518
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    doc = GoogleParser()
    new_section = Section("Tests", "test", SectionType.SINGULAR)
    doc.add_section(new_section)
    assert doc.sections["Tests"] is new_section

# Generated at 2022-06-23 17:09:09.114609
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    add_section = GoogleParser()
    # Test that add_section works correctly for sections
    # that are recognized by deafult
    for section in DEFAULT_SECTIONS:
        assert add_section.sections[section.title] == section
    # Test that add_section works correctly for newly added sections
    new_sections = (
        Section("New Section", "new_section", SectionType.MULTIPLE),
        Section("New Section", "new_section", SectionType.SINGULAR),
        Section("New Section", "new_section", SectionType.SINGULAR_OR_MULTIPLE))
    for section in new_sections:
        add_section.add_section(section)
        assert add_section.sections[section.title] == section

# Generated at 2022-06-23 17:09:22.099890
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""

    def _parse(s: str) -> Docstring:
        return GoogleParser().parse(s)

    assert _parse("    Short description.\n    ") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    assert _parse("    Short description.\n    Long description.") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        long_description="Long description.",
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-23 17:09:23.130107
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parse(text="Hello world")



# Generated at 2022-06-23 17:09:34.744560
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Testing docstring
    text = '''
This is the short summary.

Does this method add two numbers?

Args:
  first: The first number to add.
  second: The second number to add.

Returns:
  The sum of first and second.

Raises:
  Error: If first is an invalid value.
'''

    parsed = GoogleParser().parse(text)
    assert parsed.short_description == 'This is the short summary.'
    assert parsed.long_description == 'Does this method add two numbers?'
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == True
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args[0] == 'param'

# Generated at 2022-06-23 17:09:43.192436
# Unit test for function parse
def test_parse():

    docstring = GoogleParser().parse('''
        A sample docstring

        Args:
            arg0: some argument
            arg1 (int): a named argument
            arg2 (Optional[int]): an optional argument
            arg3 (
                int
            ): another formatted optional argument

        Returns:
            int

        Yields:
            int
    ''')

    assert docstring.short_description == 'A sample docstring'
    assert docstring.long_description is None
    assert len(docstring.meta) == 4
    for arg in docstring.meta:
        assert arg.description is not None
        assert arg.args[0] in {'param', 'returns', 'yields'}


# Generated at 2022-06-23 17:09:46.115091
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    docstring = GoogleParser()
    assert docstring is not None


# Generated at 2022-06-23 17:09:57.130084
# Unit test for function parse
def test_parse():
    text = """Summary line.

    Description. Extends over
    multiple lines.

    Args:
        x: first param
          with a long description
        y: second param

    Returns:
        First return value.
        Second return value.

    """
    doc = parse(text)
    assert doc.short_description == "Summary line."
    assert doc.long_description == """Description. Extends over
multiple lines."""
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[1].arg_name == "y"
    assert isinstance(doc.meta[2], DocstringReturns)

# Generated at 2022-06-23 17:10:01.805945
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser(
        sections=[Section("Arguments", "param", SectionType.MULTIPLE)]
    )
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    docstring = parser.parse(
        """A docstring.

        Args:
        arg1: arg description
        arg2: arg description

        """
    )
    print(docstring)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:10:06.558885
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    assert(g.parse("") == Docstring())
    assert(g.parse("Google-style docstring parsing.") == Docstring(
        short_description='Google-style docstring parsing.',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    ))
    assert(g.parse("""\
        Google-style docstring parsing.

        Detailed description of what this module does.
    """) == Docstring(
        short_description='Google-style docstring parsing.',
        long_description='Detailed description of what this module does.',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[]
    ))

# Generated at 2022-06-23 17:10:17.796441
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    assert p.parse("") == Docstring()
    assert p.parse("\n") == Docstring()
    assert p.parse("what") == Docstring(
        short_description='what',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert p.parse("what\n") == Docstring(
        short_description='what',
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-23 17:10:30.699707
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:10:33.103624
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    print(parser.sections)


# Generated at 2022-06-23 17:10:37.761248
# Unit test for constructor of class Section
def test_Section():
    section = Section(title = 'title', key='key', type=SectionType.SINGULAR)
    assert(section.title == 'title')
    assert(section.key == 'key')
    assert(section.type == SectionType.SINGULAR)


# Generated at 2022-06-23 17:10:39.367564
# Unit test for function parse
def test_parse():
    """Test the parse function."""
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-23 17:10:51.222082
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # The section to be added will be:
    # - title: "Test"
    # - key: "test"
    # - type: SINGULAR

    new_section = Section("Test", "test", SectionType.SINGULAR)

    # Create a default GoogleParser
    parser = GoogleParser()
    parser.add_section(new_section)

    # Check if the parser has a new section
    assert new_section.title in parser.sections
    assert new_section.key in parser.sections
    assert new_section.type in parser.sections

    # Check that the GoogleParser has been updated
    new_title = "Test:"
    assert new_title in parser.titles_re.pattern


# Generated at 2022-06-23 17:10:54.532466
# Unit test for constructor of class Section
def test_Section():
    section = Section("Test1", "test1", SectionType.SINGULAR)
    assert section.title == "Test1"
    assert section.key == "test1"
    assert section.type == SectionType.SINGULAR



# Generated at 2022-06-23 17:11:03.528576
# Unit test for function parse
def test_parse():
    with open("test_parse.py") as f:
        code = f.read()
    code_lines = code.split("\n")
    # Note that the closing quotes are not included.
    doc_str_lines = code_lines[3:16]
    doc_str = "\n".join(doc_str_lines)
    # Verify that it is the same as the docstring in the code.
    assert doc_str == """
    A simple example implementation of a controller for a simulated 2-link arm.

    The controller is a PD controller with feedforward from an estimated state
    of the arm.

    :param env: An instance of the Arm environment.
    :param dt: The controller time-step.
    :returns: The updated control values for the arm.
    """
    # Do the actual test

# Generated at 2022-06-23 17:11:15.668745
# Unit test for function parse
def test_parse():
    assert parse("""\
    Returns the fractional part of the number.

    :param x: The number in question.
    :return: The fractional part of the number
    :rtype: float
    """) == Docstring(
        short_description="Returns the fractional part of the number.",
        long_description="The fractional part of the number.",
        meta=[
            DocstringParam(
                args=["param", "x"],
                description="The number in question.",
                arg_name="x",
                type_name=None,
                is_optional=False,
                default=None,
            ),
            DocstringReturns(
                args=["return"],
                description="The fractional part of the number",
                type_name="float",
                is_generator=False,
            ),
        ],
    )

# Generated at 2022-06-23 17:11:25.971193
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("Foo", "foo", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Bar", "bar", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Baz", "baz", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    parser = GoogleParser(sections)
    assert parser.sections["Foo"] == Section("Foo", "foo", SectionType.SINGULAR_OR_MULTIPLE)
    assert parser.sections["Bar"] == Section("Bar", "bar", SectionType.SINGULAR_OR_MULTIPLE)
    assert parser.sections["Baz"] == Section("Baz", "baz", SectionType.SINGULAR_OR_MULTIPLE)
    assert parser.sections["Args"] == None
   

# Generated at 2022-06-23 17:11:38.079229
# Unit test for function parse
def test_parse():
    def a():
        """A function.

        This function is a function.
        More lines.

        Args:
            a (int, optional): An int.
            b (str): A str.

        Returns:
            bool: The return value. True for success, False otherwise.

        Raises:
            Exception: When something bad happens.

        Attributes:
            attribute: Some attribute.

        """

    doc = parse(inspect.getdoc(a))
    assert doc.long_description == "This function is a function.\nMore lines."
    assert doc.meta[0].arg_name == "a"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].is_optional is True
    assert doc.meta[0].default == "An int."

# Generated at 2022-06-23 17:11:46.332662
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:11:58.149704
# Unit test for function parse
def test_parse():
    text = '''
        """Return the number of days in month.

        Arguments:
            year (int): The year to get the days for.
            month (int): The month to get the days for.

        Returns:
            int: The number of days in the given month of the given year.

        Example:
            >>> calendar.monthrange(2016, 11)[1]
            30
        """
        '''
    docstring = parse(text)
    assert docstring.short_description == 'Return the number of days in month.'
    assert docstring.meta[0].args == ('param', 'Arguments')
    assert docstring.meta[0].arg_name == 'year'
    assert docstring.meta[0].type_name == 'int'

# Generated at 2022-06-23 17:12:10.946066
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
This describes a class.

Args:
    name1 (int): The first parameter
    name2 (str): The second parameter. Defaults to "foo".
"""
    sections = [
        Section('Args', 'param', SectionType.MULTIPLE),
    ]
    result = GoogleParser(sections, title_colon=True).parse(text)
    assert result.short_description == 'This describes a class.'
    assert result.long_description is None
    assert len(result.meta) == 2

    assert result.meta[0].args == ['param', 'name1 (int)']
    assert result.meta[0].description == 'The first parameter'
    assert result.meta[0].arg_name == 'name1'
    assert result.meta[0].type_name == 'int'

# Generated at 2022-06-23 17:12:13.116743
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert(isinstance(GoogleParser(), GoogleParser))

# Generated at 2022-06-23 17:12:19.560202
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser(title_colon=True)
    docstring = """
    Parse the Google-style docstring into its components.
    Returns:
        parsed docstring
    """
    result = gp.parse(docstring)
    assert result.short_description == 'Parse the Google-style docstring into its components.'
    assert result.long_description == 'Returns: parsed docstring'

# Generated at 2022-06-23 17:12:28.139004
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """\
        an instance of :class:`~pandas.DataFrame`.

        Returns
        -------
        self: Returns a copy of the object with the same uid and some
        of the metadata Variables and metadata removed.
        """
    result = parser.parse(docstring)

# Generated at 2022-06-23 17:12:35.984186
# Unit test for function parse
def test_parse():
    docstring = """Summary line.
Extended description of function.

Args:
    param1: Description of `param1`.
    param2: Description of `param2`
        which spans multiple lines.
    *args: Variable length argument list.
    **kwargs: Arbitrary keyword arguments.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.

Returns:
    bool: True if successful, False otherwise.

"""
    print(parse(docstring))


# Generated at 2022-06-23 17:12:47.890975
# Unit test for function parse
def test_parse():
    docstring = parse(r"""
    This is a google docstring.

    Some more detailed explanation.

    Args:
        arg0 (int): some arg.
        arg1 (str): another arg.
            With some explanation. Defaults to "spam".
        arg2 ([str]): optional arg.
        arg3 (str, optional): optional arg with "optional" explicitly there.
        arg4 (str?)?: optional arg with "optional" explicitly there.
        arg5 (str?)?: optional arg with "optional" explicitly there.
    Returns:
        a (int): some number.
        b (str): some string.
    Raises:
        ValueError: for bad values
        OSError: for bad files.
    """)
    assert docstring.short_description == "This is a google docstring."

# Generated at 2022-06-23 17:12:57.623532
# Unit test for constructor of class Section
def test_Section():
    assert Section("Title", "title", SectionType.SINGULAR) == Section("Title", "title", SectionType.SINGULAR)
    assert Section("Title1", "title1", SectionType.SINGULAR_OR_MULTIPLE) != Section("Title1", "title1", SectionType.MULTIPLE)
    assert Section("Title", "title", SectionType.MULTIPLE) != Section("Title", "title", SectionType.MULTIPLE)
    assert Section("Title1", "title1", SectionType.MULTIPLE) != Section("Title2", "title2", SectionType.MULTIPLE)



# Generated at 2022-06-23 17:13:08.187196
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:13:20.455676
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with empty string
    text = ""
    assert GoogleParser().parse(text) == Docstring()

    # Test with simple string
    text = "Example description."
    result = GoogleParser().parse(text)
    assert result == Docstring(
        short_description="Example description.",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    # Test with multiline string
    text = """Example description.

Example description."""
    result = GoogleParser().parse(text)

# Generated at 2022-06-23 17:13:23.813952
# Unit test for constructor of class Section
def test_Section():
    section = Section("Title", "key", SectionType.SINGULAR)
    assert section.title == "Title"
    assert section.key == "key"
    assert section.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:13:27.893853
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    g.add_section(Section("Test", "test", SectionType.SINGULAR))
    assert "Test" in g.sections



# Generated at 2022-06-23 17:13:31.288114
# Unit test for constructor of class Section
def test_Section():
    s = Section("name","value",SectionType.SINGULAR)
    assert s.title == "name"
    assert s.key == "value"
    assert s.type == SectionType.SINGULAR



# Generated at 2022-06-23 17:13:37.750525
# Unit test for constructor of class Section
def test_Section():
    assert Section("Attributes", "attribute", SectionType.MULTIPLE)
    assert Section("Example", "examples", SectionType.SINGULAR)
    assert Section("Examples", "examples", SectionType.SINGULAR)
    assert Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE)


# Generated at 2022-06-23 17:13:50.549662
# Unit test for function parse
def test_parse():
    docstr = """Class summary line.

    The summary line can have multiple sentences. The body of the
    class consists of indented paragraphs. The first non-indented line
    marks the end of the summary section (place a blank line before it).
    Parameters:
        foo (str): Description of `foo`.
        bar (str): Description of `bar`.
    """
    parsed = parse(docstr)
    assert parsed.short_description == "Class summary line."
    assert parsed.long_description == """The summary line can have multiple sentences. The body of the
    class consists of indented paragraphs. The first non-indented line
    marks the end of the summary section (place a blank line before it)."""

# Generated at 2022-06-23 17:14:01.047238
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser()
    assert g.sections is not None
    assert g.title_colon is not None

    # Test Sections
    assert isinstance(g.sections["Arguments"], Section)
    assert SectionType.MULTIPLE == g.sections["Arguments"].type
    assert g.sections["Arguments"].key == "param"
    assert g.sections["Arguments"].title == "Arguments"
    assert isinstance(g.sections["Raises"], Section)
    assert SectionType.MULTIPLE == g.sections["Raises"].type
    assert g.sections["Raises"].key == "raises"
    assert g.sections["Raises"].title == "Raises"
    assert isinstance(g.sections["Exceptions"], Section)

# Generated at 2022-06-23 17:14:10.753378
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = inspect.cleandoc(
    """
    Short description.

    Long description

    Arguments:
        my_arg (str): description of my arg. Defaults to 'default'.
        my_arg2 (str): description of my arg2. Defaults to 'default'.

    Raises:
        AssertionError: if something fails
    """
    )

    docstring = GoogleParser().parse(docstr)
    assert docstring.short_description == 'Short description.'
    assert docstring.long_description == 'Long description'
    assert len(docstring.meta) == 2
    assert docstring.meta[0].key == 'param'
    assert docstring.meta[0].description == 'description of my arg.'
    assert docstring.meta[0].type_name == 'str'

# Generated at 2022-06-23 17:14:14.226047
# Unit test for constructor of class Section
def test_Section():
    s = Section(title="title1", key="key1", type=1)
    assert s.title == "title1"
    assert s.key == "key1"
    assert s.type == 1


# Generated at 2022-06-23 17:14:26.765643
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    # default
    assert parser.parse('"""\nHello world!\n"""') ==  Docstring(
        short_description='Hello world!',
        meta=[],
        long_description=None,
    )


    # Test Types
    # test section type SINGULAR

# Generated at 2022-06-23 17:14:34.846565
# Unit test for function parse
def test_parse():
    docstring = '''Single line description.

    Args:
        arg1 (str): Description. Defaults to None.
        arg2 (int, optional): Description.
        arguments: Description that has a colon.
        arguments (optional): Description that has a colon.

    Returns:
        int: Description.
    '''
    result = parse(docstring)
    assert(result.short_description == 'Single line description.')
    assert(result.long_description is None)
    assert(result.blank_after_short_description)
    assert(result.blank_after_long_description == False)
    assert(len(result.meta) == 4)

# Generated at 2022-06-23 17:14:42.322401
# Unit test for constructor of class Section
def test_Section():
    sec_1 = Section("Arguments", "param", SectionType.MULTIPLE)
    sec_2 = Section("Args", "param", SectionType.MULTIPLE)
    sec_3 = Section("Parameters", "param", SectionType.MULTIPLE)
    sec_4 = Section("Params", "param", SectionType.MULTIPLE)
    sec_5 = Section("Raises", "raises", SectionType.MULTIPLE)
    sec_6 = Section("Exceptions", "raises", SectionType.MULTIPLE)
    sec_7 = Section("Except", "raises", SectionType.MULTIPLE)
    sec_8 = Section("Attributes", "attribute", SectionType.MULTIPLE)
    sec_9 = Section("Example", "examples", SectionType.SINGULAR)
    sec_

# Generated at 2022-06-23 17:14:45.914189
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("MySection", "mysection", SectionType.SINGULAR_OR_MULTIPLE))

    text = """\
    Test title
    MySection:
        Test title content
    """
    docstring = parser.parse(text)

    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == 'Test title'
    assert docstring.meta[1].description == 'Test title content'


# Generated at 2022-06-23 17:14:57.764667
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Attributes", "attribute", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Examples", "examples", SectionType.SINGULAR),
    ]
    parser = GoogleParser(sections)
    assert parser.sections['Arguments'].title == 'Arguments'
    assert parser.sections['Args'].title == 'Args'
    assert parser.sections['Attributes'].title == 'Attributes'
    assert parser.sections['Example'].title == 'Example'
    assert parser.sections['Examples'].title == 'Examples'
    assert parser.sections['Arguments'].key == 'param'
    assert parser

# Generated at 2022-06-23 17:14:58.584768
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from . import doctest
    doctest.testmod(GoogleParser, "GoogleParser.parse")

# Generated at 2022-06-23 17:15:05.274453
# Unit test for function parse
def test_parse():
    doc = """This is the short description.
    This line is part of the same paragraph as the previous line,
    but is preceded by an empty line.

    This is a new paragraph, indented with a continuation line.
    Args:
        arg1: The first argument.
        arg2 (int): The second argument.
        arg3:
            The third argument.
        arg4:
            The first line of the third argument.
            The second line of the third argument
            and it is still the same paragraph.
        arg5:
            The first line of the third argument.
            The second line of the third argument
            and it is still the same paragraph.
            This is a new paragraph, indented with a continuation line.


    Returns:
        This is a description of what is returned.
        This is a description of what is returned.
    """

# Generated at 2022-06-23 17:15:17.378602
# Unit test for function parse
def test_parse():
    """Test parse function."""
    doc1 = """
    Short description.

    This is a long description.
    It also has two paragraphs.

    Args:
        arg1: Desc1
        arg2: Desc2

    Raises:
        Exc1
    """


# Generated at 2022-06-23 17:15:27.288325
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def student_func():
        """Fetch a single page and report the URL and contents.

        :param url: the URL to fetch, as a string
        :param data: key-value pairs of data to submit
        :type data: dict
        :param maxlength: maximum number of bytes to accept.
                         If the page is longer, an Exception
                         is raised.
        :raises IOError: if the URL does not exist
        :raises ValueError: if the data submitted is invalid
        :returns: a tuple of the URL and the contents
        :returns: a tuple of the URL and the contents
        :returns: a tuple of the URL and the contents
        :returns: a tuple of the URL and the contents
        """
        return 'test', 'test'

# Generated at 2022-06-23 17:15:40.711369
# Unit test for constructor of class Section
def test_Section():
    # Constructor of Section
    test_case_1 = Section("Arguments", "param", SectionType.MULTIPLE).__str__()
    assert test_case_1 == "Section(title='Arguments', key='param', type=<SectionType.MULTIPLE: 1>)"

    # Constructor of Section
    test_case_2 = Section("Arguments", "param", SectionType.SINGULAR).__str__()
    assert test_case_2 == "Section(title='Arguments', key='param', type=<SectionType.SINGULAR: 0>)"

    # Constructor of Section
    test_case_3 = Section("Arguments", "param", SectionType.SINGULAR_OR_MULTIPLE).__str__()

# Generated at 2022-06-23 17:15:44.167349
# Unit test for constructor of class Section
def test_Section():
    _s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert _s.title == "Arguments"
    assert _s.key == "param"
    assert _s.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:15:49.638134
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Sanity check for method parse of class GoogleParser
    parser = GoogleParser()
    sections = parser.sections
    print(sections)
    assert any([section.title == "Raises" for section in sections.values()])


# Generated at 2022-06-23 17:15:54.696626
# Unit test for method add_section of class GoogleParser