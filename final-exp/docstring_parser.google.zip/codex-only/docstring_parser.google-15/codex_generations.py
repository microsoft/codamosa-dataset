

# Generated at 2022-06-23 17:06:00.181388
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Test", "test", SectionType.MULTIPLE))
    text = "Test:\n  x: rien\n  y: rien\n  z: rien\n"
    assert parser.parse(text) == Docstring(
        short_description=None,
        long_description=None,
        meta=[
            DocstringMeta(args=["test", "x"], description="rien"),
            DocstringMeta(args=["test", "y"], description="rien"),
            DocstringMeta(args=["test", "z"], description="rien"),
        ],
    )


# Generated at 2022-06-23 17:06:05.021945
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = DEFAULT_SECTIONS
    sections_with_key = dict()
    for element in sections:
        sections_with_key[element.key] = element
    parser = GoogleParser()
    section = Section("A", "a", SectionType.MULTIPLE)
    assert parser.sections != sections_with_key
    parser.add_section(section)
    assert parser.sections == sections_with_key
    assert parser.sections["A"] == section

# Generated at 2022-06-23 17:06:16.923444
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = '''
    Google style parser.

    This docstring is parsed by the GoogleParser class.
    Arguments can be specified like this:

    Args:
        name (str, optional): The names of the people. Defaults to 'John Doe'.

    Returns (str): The greeting.
    '''
    result = parser.parse(docstring)
    assert result is not None
    assert result.short_description == 'Google style parser.'
    assert result.long_description == 'This docstring is parsed by the GoogleParser class.'
    assert result.meta[0].args[0] == 'param'
    assert result.meta[0].arg_name == 'name'
    assert result.meta[0].type_name == 'str'
    assert result.meta[0].is_optional == True
   

# Generated at 2022-06-23 17:06:21.178562
# Unit test for function parse
def test_parse():
    examples = [
        """Multi-line
        docstring.

        First paragraph.

        Second paragraph.
        """,
        """Single-line docstring."""
    ]
    return examples
    

# Generated at 2022-06-23 17:06:26.710256
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [Section("Section", "section", SectionType.SINGULAR)]
    sections_parser = GoogleParser(sections)

    sections = [Section("Section", "test", SectionType.SINGULAR)]
    sections_parser.add_section(Section("Section", "test", SectionType.SINGULAR))
    assert sections_parser.sections == sections

# Generated at 2022-06-23 17:06:28.210391
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser(title_colon=False)
    assert gp


# Generated at 2022-06-23 17:06:30.498915
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.sections == DEFAULT_SECTIONS
    assert parser.title_colon == True    
    


# Generated at 2022-06-23 17:06:40.650045
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.sections

    # Add a new section Example
    section = Section("Example", "examples", SectionType.SINGULAR)
    parser.add_section(section)
    assert parser.sections
    assert parser.sections["Example"] is section

    # Test to add a new section Arguments
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    parser.add_section(section)
    assert parser.sections
    assert parser.sections["Arguments"] is section

    # Test to add a new section Returns
    section = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(section)
    assert parser.sections
    assert parser.sections["Returns"] is section



# Generated at 2022-06-23 17:06:43.824547
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = []
    sections.append(Section("NewTitle", "new", SectionType.MULTIPLE))
    p = GoogleParser(sections)
    p.add_section(Section("NewTitle", "new", SectionType.SINGULAR))
    assert p.sections["NewTitle"].type == SectionType.SINGULAR


# Generated at 2022-06-23 17:06:55.640630
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # test for adding a new section title
    print("\n" + "Unit test for add_section:")
    test_GoogleParser = GoogleParser()
    print("Test case 1: Add a new section title:")
    new_section = Section("New_Title", "new_title", SectionType.MULTIPLE)
    test_GoogleParser.add_section(new_section)
    print("After adding new_title, the sections are " + str(test_GoogleParser.sections))
    # test for replacing an existing section title
    print("Test case 2: Replace existing section title:")
    new_section = Section("Example", "new_title", SectionType.MULTIPLE)
    test_GoogleParser.add_section(new_section)

# Generated at 2022-06-23 17:07:05.599770
# Unit test for constructor of class Section

# Generated at 2022-06-23 17:07:13.513608
# Unit test for function parse
def test_parse():
    assert parse("") == parse("\n") == Docstring()

    s = "test"
    assert parse(s) == Docstring(
        short_description=s, blank_after_short_description=True
    )

    s = "test\n\nlonger"
    assert parse(s) == Docstring(
        short_description="test",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="longer",
    )

    assert parse("Args:    \n    arg: desc") == Docstring(
        short_description=None,
        meta=[DocstringMeta(["Args", "arg"], description="desc")],
    )


# Generated at 2022-06-23 17:07:24.268038
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstr = Docstring()

    docstr.short_description = "Test parse method of the GoogleParser class."
    docstr.long_description = "Testing the parser of the GoogleParser class on a more complicated docstring."
    docstr.blank_after_short_description = False
    docstr.blank_after_long_description = False

    doc = DocstringMeta(args=["examples", "test_parse"], description="test_parse(test: str) -> bool")
    docstr.meta.append(doc)

    doc = DocstringMeta(args=["returns", "bool"], description="True if test passes, False otherwise.")
    docstr.meta.append(doc)

    doc = DocstringMeta(args=["raises", "TypeError"], description="Raised if test does not pass")
    docstr

# Generated at 2022-06-23 17:07:35.149630
# Unit test for function parse
def test_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """Summary line.

    Extended description.

    Parameters:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`

    Returns:
        bool: True if successful, False otherwise.
        """
    )
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description."
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args[1] == "arg1 (int)"
    assert (
        docstring.meta[0].description
        == "Description of `arg1`.\n\n    Extended description."
    )
    assert docstring.meta[1].args[1] == "arg2 (str)"

# Generated at 2022-06-23 17:07:42.693102
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_str = '''
    Arguments:
        param1 [type]: The first param.
        param2 [type]:
            The second param.
    '''
    d = parse(doc_str)
    assert d.short_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is True
    assert d.long_description is None

    assert len(d.meta) == 2
    assert d.meta[0].__class__.__name__ == 'DocstringParam'
    assert d.meta[0].description == 'The first param.'
    assert d.meta[0].arg_name == 'param1'
    assert d.meta[0].type_name == 'type'
    assert d.meta[0].is_optional is None

# Generated at 2022-06-23 17:07:43.125902
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()

# Generated at 2022-06-23 17:07:53.996216
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Unit test for method parse of class GoogleParser
    """
    result = GoogleParser().parse(
        """
        Retrieve a list of available organizations
        List all organizations that the authenticated user belongs to.

        :param str Accept: (optional)
            The content type of the response: application/json or application/xml.
            Default is application/json.
        :param str Accept-Language: (optional)
            The language of the response.
        :rtype: Organizations
        """
    )
    assert result.short_description == "Retrieve a list of available organizations"
    assert result.long_description == """List all organizations that the authenticated user belongs to."""
    assert result.meta[0].key == "param"
    assert result.meta[0].args[0] == "Accept"
    assert result.meta[0].is_optional

# Generated at 2022-06-23 17:08:01.676649
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
Single line summary.

Longer description.

Args:
  a: int, required. An int.
  b: int, optional. A second int.
    Defaults to 3.

Raises:
  TypeError: if types are wrong.

Returns:
  sum of the two ints.

Example:
  >>> print(sum(1, 2))
  4
'''
    assert text == str(GoogleParser().parse(text))

# Generated at 2022-06-23 17:08:05.270243
# Unit test for constructor of class Section
def test_Section():

    s = Section("a", "b", 2)
    assert(s.title == "a")
    assert(s.key == "b")
    assert(s.type == 2)



# Generated at 2022-06-23 17:08:16.626755
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser."""
    assert GoogleParser().parse(None) == Docstring()
    assert GoogleParser().parse("") == Docstring()
    # test title_colon=False
    docstring = GoogleParser(title_colon=False).parse(
        '\n    Params:\n      param1: a parameter\n      param2: another parameter\n'
    )
    assert len(docstring.meta) == 2
    assert docstring.meta[0] == DocstringParam(
        args=["Params", "param1"],
        description="a parameter",
        arg_name="param1",
        type_name=None,
        is_optional=None,
        default=None,
    )

# Generated at 2022-06-23 17:08:29.906031
# Unit test for function parse
def test_parse():
    docstring = """A one-line summary that does not use variable names or the
        function name.
    
    Args:
      param1: The first parameter.
      param2: The second parameter.
    
    Returns:
      This is a description of what is returned.
      
    Raises:
      KeyError: Raises an exception.
    """
    doc = parse(docstring)
    assert doc.short_description == "A one-line summary that does not use variable names or the\n        function name."
    print(doc.meta)
    assert doc.meta[0].description == "The first parameter."
    assert doc.meta[1].description == "The second parameter."
    assert doc.meta[2].description == "This is a description of what is returned."

# Generated at 2022-06-23 17:08:30.618495
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-23 17:08:33.824975
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    new_section = Section("Author", "author", SectionType.SINGULAR)
    # Should not throw exception
    GoogleParser().add_section(new_section)


# Generated at 2022-06-23 17:08:41.628086
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test adding new section."""
    parser = GoogleParser()
    section = Section("Notes", "notes", SectionType.SINGULAR)
    parser.add_section(section)

    docstring = """
        This is a multi-line short description
        of my function.

        Notes
        -----
        This is a more detailed description.
    """

    parsed = parser.parse(docstring)
    assert parsed.meta[0].args == ["notes"]
    assert parsed.meta[0].description == "This is a more detailed description."

# Generated at 2022-06-23 17:08:44.675895
# Unit test for constructor of class Section
def test_Section():
    section = Section("A", "B", 0)
    assert section.title == "A"
    assert section.key == "B"
    assert section.type == 0

# Generated at 2022-06-23 17:08:55.908648
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    gp.add_section(Section("Args", "param", SectionType.MULTIPLE))
    gp.add_section(Section("Parameters", "param", SectionType.MULTIPLE))
    gp.add_section(Section("Params", "param", SectionType.MULTIPLE))
    gp.add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    gp.add_section(Section("Exceptions", "raises", SectionType.MULTIPLE))
    gp.add_section(Section("Except", "raises", SectionType.MULTIPLE))
    gp.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))
   

# Generated at 2022-06-23 17:09:08.284517
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().title_colon == True

# Generated at 2022-06-23 17:09:13.583887
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

# Generated at 2022-06-23 17:09:25.193508
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Create an section object
    # Give it a title "New Title", a keyword "new_key" and a type "SINGULAR"
    section_to_add = Section("New Title", "new_key", SectionType.SINGULAR)

    # Initialize the GoogleParser object
    google_parser_object = GoogleParser()

    # Add the new section to the GoogleParser object
    google_parser_object.add_section(section_to_add)

    # Check if the new section has been really added
    assert "New Title" in google_parser_object.sections

    # Check if the new section has the right key
    assert google_parser_object.sections["New Title"].key == "new_key"

    # Check if the new section has the right type
    assert google_parser_object.sections["New Title"].type == SectionType

# Generated at 2022-06-23 17:09:37.418704
# Unit test for function parse
def test_parse():
    docstring = parse('''
    This is a short description.
    This is a long description.

    Args:
        arg1: The first argument.
        arg2 (int, optional): The second argument. Defaults to 1.
        arg3:
            The third argument.
            Tis a more
            complex description.
            It also continues

            here.
        arg4:
            The fourty argument.
            It has two
            lines.

        arg5 (str, optional):
            The fifth argument.
            No description because it doesn't have a
            defaults to.

    Returns:
        this is a return value
    ''')

    assert docstring.short_description == 'This is a short description.'
    assert docstring.blank_after_short_description

# Generated at 2022-06-23 17:09:44.765887
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    c = GoogleParser()
    assert c.title_colon == True

# Generated at 2022-06-23 17:09:51.141407
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    test_parser = GoogleParser()
    test_Section = Section("Section", "Sections", SectionType.SINGULAR_OR_MULTIPLE)
    test_parser.add_section(test_Section)
    assert test_parser.sections["Section"] == test_Section
    assert test_parser.sections["Sections"] == test_Section


# Generated at 2022-06-23 17:10:00.551488
# Unit test for function parse
def test_parse():
    doc_string = """Summary line.

    Extended description of function.
    Characterize the function's interface, especially input parameters and
    return value.

    Args:
        text: Non-empty string
        sentences: A list of strings
        is_parsed: Boolean flag

    Returns:
        :obj:`tuple` of :obj:`list` of :obj:`str`: List of sentence-tokenized
        input strings.
        """
    docstring = parse(doc_string)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == (
        "Extended description of function. Characterize the function's "
        "interface, especially input parameters and return value.\n"
    )
    assert docstring.meta[0].args == ("param", "text")
    assert docstring

# Generated at 2022-06-23 17:10:06.360423
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    expected_sections = 16
    d = GoogleParser()
    d.add_section(Section("Test", "test", SectionType.SINGULAR))
    assert len(d.sections) == expected_sections
    for section in d.sections:
        if d.sections[section].type == SectionType.SINGULAR:
            assert d.sections[section].title == "Test"
            assert d.sections[section].key == "test"
            break

# Generated at 2022-06-23 17:10:09.269153
# Unit test for constructor of class Section
def test_Section():
    s = Section("Example", "Example", SectionType.SINGULAR)
    assert s.title == "Example"
    assert s.key == "Example"
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:10:20.749097
# Unit test for function parse
def test_parse():
    def func(a, b, c=None):
        """Summary line.
        
        Extended description of function.
        
        Args:
            a: Description of arg1
            b: Description of arg2
        
        Returns:
            Description of return value.
        """
        pass

    parser = GoogleParser()
    ret = parser.parse(func.__doc__)
    assert ret.short_description == "Summary line."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert ret.long_description == "Extended description of function."
    assert ret.meta[0].key == "param"
    assert ret.meta[0].args == ["Args", "a"]
    assert ret.meta[0].description == "Description of arg1"
    assert ret

# Generated at 2022-06-23 17:10:21.852542
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser()



# Generated at 2022-06-23 17:10:33.235507
# Unit test for function parse
def test_parse():

    text = """
        Argument names are not part of the specification.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.

        Keyword Arguments:
            kwarg1 (int): The first keyword argument.
            kwarg2 (str): The second keyword argument.

        Returns:
            bool: The return value. True for success, False otherwise.

        Raises:
            AttributeError: The ``Raises`` section is a list of all exceptions
                that are relevant to the interface.
            ValueError: If `param2` is equal to `param1`.

        """

    parsed = parse(text)
    print(parsed)
    print(type(parsed))


# Generated at 2022-06-23 17:10:37.516409
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section_1 = Section("Description", "description", SectionType.SINGULAR)
    new_parser = GoogleParser()
    new_parser.add_section(section_1)
    assert new_parser.sections == {'Description': section_1}

# Generated at 2022-06-23 17:10:45.261096
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """Return a new array of shape and type of input.

    Parameters
    ----------
    x: array_like
      Input data

    Returns
    -------
    out: ndarray
      Array of `x`'s shape and type.

    See Also
    --------
    zeros_like
    """    
    docstring = parser.parse(text)
    assert docstring.short_description == 'Return a new array of shape and type of input.'
    assert docstring.blank_after_short_description == False

# Generated at 2022-06-23 17:10:52.803674
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test1 = GoogleParser(title_colon=True)
    test2 = GoogleParser(title_colon=False)
    t1 = test1.titles_re
    t2 = test2.titles_re
    s1 = t1.search('Args')
    s2 = t2.search(':Args')
    s3 = t2.search('Args')
    s4 = t1.search('Args:')
    print(s1)
    print(s2)
    print(s3)
    print(s4)

# Generated at 2022-06-23 17:10:57.332126
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Author:", "author", SectionType.SINGULAR))
    docstring = parser.parse(
        """
    This function does nothing.

    Author:
        protonstorm
    """
    )
    assert docstring.meta[0].args == ["author", "protonstorm"]

# Generated at 2022-06-23 17:11:02.381249
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test the method parse of class GoogleParse.
    """
    test_docstring='Test Parse\nParse a Google style docstring\nParams\n    text(str): The input docstring\n    kwargs(dict): Other parser arguments\nReturns\n    Docstring: The parsed docstring'
    assert parse(test_docstring).short_description=='Test Parse'
    assert len(parse(test_docstring).meta)==2

# Generated at 2022-06-23 17:11:14.743319
# Unit test for function parse
def test_parse():
    import re
    from .common import (
        Docstring,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
        DocstringMeta,
    )
    

    # All sections are optional
    # The long description may be indented the same as the first line of the short description
    # Titles do not need to be text until the first line
    # A blank line is required between the description and the first argument

    docstring = """
        """
    assert parse(docstring) == Docstring()

    docstring = '''
        Short description.
        Long description.
        '''
    assert parse(docstring) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
    )


# Generated at 2022-06-23 17:11:16.189155
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser([]).parse("") == ""


# Generated at 2022-06-23 17:11:20.707750
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Test", "test", SectionType.MULTIPLE)
    parser.add_section(section)
    assert section in parser.sections.values()
    assert parser.sections["Test"] == section
    assert parser.sections["test"] == section
    assert "{}:".format(section.title) in parser.titles_re.pattern


# Generated at 2022-06-23 17:11:24.398917
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Tag", "key", SectionType.SINGULAR)
    parser.add_section(section)
    assert parser.sections["Tag"] == section


# Generated at 2022-06-23 17:11:28.145547
# Unit test for constructor of class Section
def test_Section():
    test_section = Section("Test Section", "test_section", 0)
    assert test_section.title == "Test Section"
    assert test_section.key == "test_section"
    assert test_section.type == 0


# Generated at 2022-06-23 17:11:37.121822
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser(title_colon = False)
    assert(gp.title_colon == False)
    assert(gp.sections["Args"] == Section('Args', 'param', 1))
    assert(gp.sections["Returns"] == Section('Returns', 'returns', 2))
    gp = GoogleParser(title_colon = True)
    assert(gp.title_colon == True)
    assert(gp.sections["Args"] == Section('Args', 'param', 1))
    assert(gp.sections["Returns"] == Section('Returns', 'returns', 2))


# Generated at 2022-06-23 17:11:38.185319
# Unit test for constructor of class Section
def test_Section():
    # Todo
    pass

# Generated at 2022-06-23 17:11:39.220805
# Unit test for function parse

# Generated at 2022-06-23 17:11:43.973268
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Custom", "custom", SectionType.SINGULAR))
    assert gp.sections["Custom"] == Section("Custom", "custom", SectionType.SINGULAR)
    assert gp.sections["Custom"].title == "Custom"
    assert gp.sections["Custom"].key == "custom"
    assert gp.sections["Custom"].type == SectionType.SINGULAR

# Generated at 2022-06-23 17:11:47.746114
# Unit test for constructor of class Section
def test_Section():
    section = Section("my_title", "my_key", SectionType.SINGULAR)
    assert section == ("my_title", "my_key", SectionType.SINGULAR)



# Generated at 2022-06-23 17:11:58.784924
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """
        Run with new parameters.

        Args:
            model: A model object.
            X: A matrix of features.
            Y: A matrix of labels.
            epochs: Int, the number of epochs to train.
            optimizer: A subclass of `tf.train.Optimizer`.
            learning_rate: Float, the learning rate to pass to the optimizer.

        Returns:
            A dict of metric results keyed by name.
        """
    )

# Generated at 2022-06-23 17:12:09.830162
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    class MyGoogleParser(GoogleParser):
        def __init__(self, sections: T.Optional[T.List[Section]] = None, title_colon=True):
            super().__init__(sections, title_colon)

    m = MyGoogleParser()
    m.add_section(Section("MySection", "mysection", SectionType.SINGULAR))
    test = r"""\
    MySection:

        One.
    """
    expected = r"""\
    MySection:

        One.
    """
    to_check = m.parse(test)
    print(to_check)
    assert expected == str(to_check)


# Generated at 2022-06-23 17:12:12.915332
# Unit test for constructor of class Section
def test_Section():
    s = Section("Args", "param", SectionType.MULTIPLE)
    assert s.title == "Args"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE



# Generated at 2022-06-23 17:12:16.762444
# Unit test for constructor of class Section
def test_Section():
    test = Section("Arguments", "param", SectionType.MULTIPLE)
    assert test.title == "Arguments"
    assert test.key == "param"
    assert test.type == SectionType.MULTIPLE

# Generated at 2022-06-23 17:12:21.281562
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section('Args','param',SectionType.MULTIPLE))
    assert 'Args' in gp.sections
    assert gp.sections['Args'] == Section('Args','param',SectionType.MULTIPLE)


# Generated at 2022-06-23 17:12:24.552523
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE
    

# Generated at 2022-06-23 17:12:31.261893
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import docstring_parser

    for section in DEFAULT_SECTIONS:
        if docstring_parser.google.parse('''
        :{}:

            foo
        '''.format(section.title)) != docstring_parser.google.parse('''
        :{}:

            foo:
        '''.format(section.title)):
            print(section)


# Generated at 2022-06-23 17:12:39.207192
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    # testing initialization
    assert gp.sections == {s.title: s for s in DEFAULT_SECTIONS}
    assert gp.title_colon == True
    assert gp.titles_re == re.compile(
        "^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields):[ \t\r\f\v]*$",
        flags=re.M,
    )
    gp2 = GoogleParser([Section("Test", "test", SectionType.SINGULAR)])

# Generated at 2022-06-23 17:12:42.129343
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('''    Test text.

    TEST text.''') == \
           Docstring(short_description='Test text.',
                     long_description='TEST text.',
                     meta=[])



# Generated at 2022-06-23 17:12:47.576318
# Unit test for constructor of class Section
def test_Section():
    section_1 = Section("Examples", "examples", SectionType.SINGULAR)
    section_2 = Section("Arguments", "param", SectionType.MULTIPLE)
    section_3 = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert(section_1.title == "Examples")
    assert(section_1.key == "examples")
    assert(section_1.type == SectionType.SINGULAR)
    assert(section_2.title == "Arguments")
    assert(section_2.key == "param")
    assert(section_2.type == SectionType.MULTIPLE)
    assert(section_3.title == "Returns")
    assert(section_3.key == "returns")

# Generated at 2022-06-23 17:12:58.954922
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # setup
    docs = """Params
    ----------
    a : int
        First thing.
    b : str
        Second thing.

    Returns
    -------
    str
        the answer.
    """
    p = GoogleParser()
    # test
    parsed_docs = p.parse(docs)
    assert parsed_docs.short_description == None
    assert parsed_docs.long_description == None
    assert parsed_docs.blank_after_short_description == False
    assert parsed_docs.blank_after_long_description == False
    assert len(parsed_docs.meta) == 3
    assert parsed_docs.meta[0].description == 'First thing.'
    assert parsed_docs.meta[0].arg_name == 'a'
    assert parsed_docs.meta[0].type_name == 'int'


# Generated at 2022-06-23 17:13:08.819548
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:13:11.617114
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key", SectionType.MULTIPLE)
    assert section.title == "title"
    assert section.key == "key"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:13:22.986003
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # SectionType.SINGULAR
    # SectionType.MULTIPLE
    # SectionType.SINGULAR_OR_MULTIPLE
    title_colon = True

# Generated at 2022-06-23 17:13:30.462454
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Method add_section must be able to add a section
    parser = GoogleParser()
    parser.add_section(Section("New Section", "new_section", SectionType.SINGULAR))
    assert "New Section" in parser.sections
    assert parser.sections["New Section"] == Section(
        "New Section", "new_section", SectionType.SINGULAR
    )
    # Method add_section must be able to replace a section
    parser = GoogleParser()
    parser.add_section(Section("Example", "example", SectionType.MULTIPLE))
    assert "Example" in parser.sections
    assert parser.sections["Example"] == Section(
        "Example", "example", SectionType.MULTIPLE
    )


# Generated at 2022-06-23 17:13:41.044443
# Unit test for function parse

# Generated at 2022-06-23 17:13:48.588465
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Test", "test", SectionType.MULTIPLE))
    text = """
        """
    docstring = gp.parse(text)
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:13:59.636824
# Unit test for constructor of class Section
def test_Section():
    l1 = list()
    l2 = list()
    l3 = list()

    title = "Arguments"
    key = "param"
    type1 = 0
    type2 = 1
    type3 = 2

    data1 = [title, key, type1]
    data2 = [title, key, type2]
    data3 = [title, key, type3]

    l1.append(Section(data1[0], data1[1], data1[2]))
    l2.append(Section(data2[0], data2[1], data2[2]))
    l3.append(Section(data3[0], data3[1], data3[2]))

    assert l1 == [Section(title="Arguments", key="param", type=0)]

# Generated at 2022-06-23 17:14:03.757358
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    s = Section("SINGLE", "single", SectionType.SINGULAR)
    g.add_section(s)
    assert g.titles_re.match('single')
    g.add_section(s)


# Generated at 2022-06-23 17:14:12.544822
# Unit test for function parse

# Generated at 2022-06-23 17:14:20.819743
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Positive test
    sections = [Section(title="Arguments", key="param", type="MULTIPLE")]
    GoogleParser(sections=sections)
    # Negative test
    sections = [Section(title="Arguments", key="param", type="MULTIPLE"), Section(title="Arguments", key="param", type="MULTIPLE")]
    try:
        GoogleParser(sections=sections)
        assert False
    except:
        assert True

# Unit test _build_meta

# Generated at 2022-06-23 17:14:30.521255
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""

    parser = GoogleParser()

    docstring = parser.parse('''Test Google style docstring.
    :param param1: The first parameter.
    :type param1: str
    :param param2: The second parameter.
    :type param2: int
    :returns: int -- the return value.
    :raises keyError: raises an exception.
    ''')

    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ['param', 'param1: The first parameter.']
    assert docstring.meta[0].arg_name == 'param1'
    assert docstring.meta[0].type_name == 'str'
    assert docstring.meta[1].args == ['param', 'param2: The second parameter.']


# Generated at 2022-06-23 17:14:32.593990
# Unit test for function parse

# Generated at 2022-06-23 17:14:37.884669
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    d1 = GoogleParser()
    d2 = GoogleParser(title_colon=False)
    d3 = GoogleParser(title_colon=True)
    assert d1.title_colon == d2.title_colon == d3.title_colon


# Generated at 2022-06-23 17:14:43.435160
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    new_section = Section(title="Test", key="test", type=SectionType.SINGULAR)
    p.add_section(new_section)
    assert "Test" in p.sections
    assert p.sections["Test"] == new_section


# Generated at 2022-06-23 17:14:50.666107
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import (
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
    )
    from .constructor import function_with_google_docstring as f
    from .constructor import function_with_google_docstring_nested as f_nested
    from .constructor import function_with_google_docstring_second as f2
    from .constructor import function_with_google_docstring_yield as fy
    from .constructor import function_with_google_docstring_extra_blankline
    from .constructor import function_with_google_docstring_no_long_description
    from .constructor import function_with_google_docstring_unicode as func_uni
    from .constructor import function_with_google_docstring_no_short_description

# Generated at 2022-06-23 17:15:00.226722
# Unit test for function parse
def test_parse():
    def func():
        """Short description.

        Examples::

            >>> a
            'a'

        Args:
            arg1 (int): Description of arg1
            arg2 (tuple): Description of arg2
            arg3 (int, optional): Description of arg3
            arg4 (int) -> int: Description of arg4

        Returns:
            int or str: Description of return value.

        Raises:
            NameError: Description of exception.

        """
        return None


# Generated at 2022-06-23 17:15:08.360944
# Unit test for constructor of class Section
def test_Section():
    sections = [Section(title = "test", key = "test", type = SectionType.MULTIPLE)]
    sections.append(Section(title = "test2", key = "test2", type = SectionType.MULTIPLE))
    sections.append(Section(title = "test3", key = "test3", type = SectionType.SINGULAR))
    sections.append(Section(title = "test4", key = "test4", type = SectionType.SINGULAR_OR_MULTIPLE))
    sections.append(Section(title = "test5", key = "test5", type = SectionType.MULTIPLE))
    sections.append(Section(title = "test6", key = "test6", type = SectionType.MULTIPLE))
    assert sections == sections
    

# Generated at 2022-06-23 17:15:12.166648
# Unit test for constructor of class Section
def test_Section():
    section = Section("Hello", "param", SectionType.SINGULAR)
    assert section.title == "Hello"
    assert section.key == "param"
    assert section.type == 0


# Generated at 2022-06-23 17:15:14.764967
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GoogleParser.add_section(self, Section("IMOOC", "imooc", SectionType.MULTIPLE))

# Generated at 2022-06-23 17:15:25.072956
# Unit test for function parse
def test_parse():
    docstring = parse("""
        Module level docstring

        Multiple paragraphs

        Arguments:
            foo: foo_arg_desc
            bar (str): bar_arg_desc. Defaults to 'bar'.

        Returns:
            str: This is the return value.
    """)

    assert docstring.short_description == "Module level docstring"
    assert docstring.long_description == "Multiple paragraphs"
    assert (
        docstring.meta[0]
        == DocstringMeta(
            args=["examples"], description="Module level docstring"
        )
    )
    assert (
        docstring.meta[1]
        == DocstringMeta(
            args=["examples"], description="Multiple paragraphs"
        )
    )

# Generated at 2022-06-23 17:15:30.495356
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    test_GoogleParser = GoogleParser()

    new_section = Section("Note", "note", SectionType.MULTIPLE)
    test_GoogleParser.add_section(new_section)

    assert new_section.title in test_GoogleParser.sections
    assert test_GoogleParser.sections[new_section.title] == new_section


# Generated at 2022-06-23 17:15:35.606096
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    with pytest.raises(AssertionError):
        GoogleParser(title_colon='str')
    with pytest.raises(AssertionError):
        GoogleParser(sections=[])
    assert GoogleParser().sections == DEFAULT_SECTIONS
    assert GoogleParser().title_colon is True

# Generated at 2022-06-23 17:15:36.994245
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()


# Generated at 2022-06-23 17:15:46.593371
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
    This is a docstring.

    ARGS:
        a: this is a
        b: this is b

    """
    )
    print(docstring)
    #assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    meta_a = docstring.meta[0]
    assert meta_a.args == ["param", "a"]
    assert meta_a.description == "this is a"
    assert meta_a.arg_name == "a"
    assert meta_a.type_name == None
    assert meta_a.is_optional == None
    assert meta

# Generated at 2022-06-23 17:15:57.529598
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE),
                Section("Raises", "raises", SectionType.MULTIPLE)]

    s = GoogleParser(sections)
    s.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))
    sections = [Section("Arguments", "param", SectionType.MULTIPLE),
                Section("Raises", "raises", SectionType.MULTIPLE),
                Section("Attributes", "attribute", SectionType.MULTIPLE)]
    assert s.sections == {section.title: section for section in sections}
