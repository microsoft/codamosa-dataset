

# Generated at 2022-06-23 17:06:01.855355
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    # Description
    assert parse("\nShort\n") == Docstring(
        short_description="Short",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("\nShort\n\n") == Docstring(
        short_description="Short",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("\nShort\n\n\n") == Docstring(
        short_description="Short",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-23 17:06:07.229794
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    parser_2 = GoogleParser(title_colon=False)
    assert parser.title_colon == title_colon
    assert parser.sections == DEFAULT_SECTIONS
    assert parser.titles_re != parser_2.titles_re



# Generated at 2022-06-23 17:06:18.424490
# Unit test for function parse
def test_parse():
    text = \
'''This is a class docstring.

    :param arg1: This is the first argument.
    :param arg2: This one is the second argument.
    :param arg3: This is the third argument
    :param arg4: This is the fourth argument
    :param arg5: This is the fifth argument
    :param arg6: This is the sixth argument
    :rtype: This is the return type
    :returns: This is a description of the return value
    :raises keyError: raises an exception
    :raises AssertionError: raises another exception
    :returns: this is the return type
    :example:
    >>> This is an example.
    >>> This is another example.
    '''
    print(parse(text))

if __name__ == '__main__':
    test_parse

# Generated at 2022-06-23 17:06:26.844340
# Unit test for function parse
def test_parse():
    text = """Summary line here.
    Extended description here.
    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.
    Returns:
        bool: Description of return value.
    """
    assert parse(text).short_description == "Summary line here."
    assert parse(text).long_description == "Extended description here."
    assert isinstance(parse(text).meta[0], DocstringParam)
    assert parse(text).meta[0].arg_name == "arg1"
    assert parse(text).meta[0].type_name == "int"
    assert parse(text).meta[0].description == "Description of arg1"

# Generated at 2022-06-23 17:06:30.792018
# Unit test for constructor of class Section
def test_Section():
    s = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert s.title == "Returns"
    assert s.key == "returns"
    assert s.type == SectionType.SINGULAR_OR_MULTIPLE

# Generated at 2022-06-23 17:06:40.874151
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:06:47.445061
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = r'''\
        """
        Short description.

        Long description.

        Args:
            arg1(str): Description of arg1. Defaults to None.
            arg2(int): Description of arg2. Defaults to None.

        Returns:
            str: Description of return value.

        Raises:
            ValueError: Description of exception.

        Examples:
            Examples can be given using either the ``Example`` or ``Examples``
            sections. Sections support any reStructuredText formatting, including
            literal blocks::

                $ python example_google.py
        """

        '''
    def test_parse_doc(parser, text, expect):
        actual = parser.parse(text)

# Generated at 2022-06-23 17:06:57.659636
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Test description
    Parameters
    ----------
    param1 : DataFrame
        param1 description
    param2 : DataFrame
        param2 description
    param3 : DataFrame
        param3 description
    """
    googleParser = GoogleParser()
    parsed_docstring = googleParser.parse(docstring)
    assert parsed_docstring.meta[0].args == ['param1', 'param1 : DataFrame']
    assert parsed_docstring.meta[1].args == ['param2', 'param2 : DataFrame']
    assert parsed_docstring.meta[2].args == ['param3', 'param3 : DataFrame']
    assert parsed_docstring.meta[0].description == "param1 description"
    assert parsed_docstring.meta[1].description == "param2 description"

# Generated at 2022-06-23 17:07:06.874722
# Unit test for function parse
def test_parse():
    # In case of failing the unit test, debug and test this function first.
    # Then work on the class.
    parser = GoogleParser()
    docstring = parser.parse(
        """
            This is a description.

            This is a long description.

            Args:
                param1: This is a parameter.
                param2: This is a parameter.

            Returns:
                This is a return value.

            Raises:
                KeyError: Raises an exception.
        """
    )
    assert docstring.short_description == "This is a description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_long_description == True
    assert docstring.blank_after_short_description == True
    assert len(docstring.meta) == 4
    param1 = doc

# Generated at 2022-06-23 17:07:14.297329
# Unit test for function parse
def test_parse():
    # Test case 1
    test_str1 = """Calculate the value of pi using the Srinivasa Ramanujan method
    :returns: The value of pi
    """
    docstring = parse(test_str1)
    assert docstring.short_description == "Calculate the value of pi using the Srinivasa Ramanujan method"
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ['returns', ': The value of pi']
    assert docstring.meta[0].description == None

    # Test case 2

# Generated at 2022-06-23 17:07:24.418668
# Unit test for function parse
def test_parse():
    """Test function parse."""
    import os
    import sys
    import textwrap
    from .common import SectionType

    test_dir = os.path.dirname(sys.modules[__name__].__file__)
    examples_file = os.path.join(test_dir, "google-examples.txt")
    with open(examples_file) as f:
        test_cases = f.read().split("\n\n")
    for c in test_cases:
        c_parts = c.split("\n\n", 1)
        if len(c_parts) < 2:
            continue
        text, expect_text = c_parts
        parser = GoogleParser()
        expect = eval(expect_text)
        actual = parser.parse(textwrap.dedent(text))
        assert actual == expect

# Generated at 2022-06-23 17:07:27.453037
# Unit test for function parse
def test_parse():
    from .tests import test_google_parser
    test_google_parser(parse)


if __name__ == "__main__":
    print(parse("""
    my function.

    :type arg: str
    :rtype: int
    :raises ValueError: if value is wrong, then arg is wrong too.

    """))

# Generated at 2022-06-23 17:07:36.331377
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = "'''" + '''
    Parse the Google-style docstring into its components.

    :param text: The text of the docstring.
    :type text: str
    :return: parsed docstring
    ''' + "'''"

# Generated at 2022-06-23 17:07:39.250945
# Unit test for constructor of class Section
def test_Section():
    section = Section("Section", "key", SectionType.SINGULAR)
    assert(section.title == "Section")
    assert(section.key == "key")
    assert(section.type == SectionType.SINGULAR)


# Generated at 2022-06-23 17:07:40.619593
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    example_docstring = """
    Example:
        >>> import torch
        >>> hl = HLoss()

        
    """
    docstring = GoogleParser().parse(example_docstring)

# Generated at 2022-06-23 17:07:43.887338
# Unit test for constructor of class Section
def test_Section():
    test_section = Section(
        title="Arguments",
        key="param",
        type=SectionType.MULTIPLE,
    )
    assert test_section.title == "Arguments"
    assert test_section.key == "param"
    assert test_section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:07:45.951155
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Test", "test", SectionType.SINGULAR))
    assert (parser.sections["Test"] == Section("Test", "test", SectionType.SINGULAR))


# Generated at 2022-06-23 17:07:58.910092
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:08:00.994861
# Unit test for function parse
def test_parse():
    from . import default_parser
    print(parse.__doc__ == default_parser.parse.__doc__)

# Generated at 2022-06-23 17:08:03.558130
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert(GoogleParser(title_colon=True))
    assert(GoogleParser(title_colon=False))


# Generated at 2022-06-23 17:08:10.871490
# Unit test for constructor of class Section
def test_Section():
    assert(Section("Arguments", "param", SectionType.MULTIPLE))
    assert(Section("Args", "param", SectionType.MULTIPLE))
    assert(Section("Parameters", "param", SectionType.MULTIPLE))
    assert(Section("Params", "param", SectionType.MULTIPLE))
    assert(Section("Raises", "raises", SectionType.MULTIPLE))
    assert(Section("Exceptions", "raises", SectionType.MULTIPLE))
    assert(Section("Except", "raises", SectionType.MULTIPLE))
    assert(Section("Attributes", "attribute", SectionType.MULTIPLE))
    assert(Section("Example", "examples", SectionType.SINGULAR))
    assert(Section("Examples", "examples", SectionType.SINGULAR))

# Generated at 2022-06-23 17:08:19.458095
# Unit test for function parse
def test_parse():
    assert parse("""
    a

    b
    c
    d
    """) == Docstring(
        short_description="a",
        blank_after_short_description=True,
        long_description="b\nc\nd",
        blank_after_long_description=False,
        meta=[]
    )

    assert parse("""
    a
    """) == Docstring(
        short_description="a",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[]
    )


# Generated at 2022-06-23 17:08:25.522632
# Unit test for function parse

# Generated at 2022-06-23 17:08:29.627181
# Unit test for constructor of class Section
def test_Section():
    title = 'title'
    key = 'key'
    type = 'type'
    s = Section(title, key, type)
    assert s.title == title
    assert s.key == key
    assert s.type == type


# Generated at 2022-06-23 17:08:40.193628
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    my_section1 = Section("Custom", "custom", SectionType.MULTIPLE)
    my_section2 = Section("Custom", "custom", SectionType.SINGULAR_OR_MULTIPLE)
    my_section3 = Section("Custom", "custom", SectionType.SINGULAR)

    parser = GoogleParser()
    parser.add_section(my_section1)
    parser.add_section(my_section2)
    parser.add_section(my_section3)
    sections = parser.sections.values()

    assert sections[-3] == my_section1
    assert sections[-2] == my_section2
    assert sections[-1] == my_section3


# Generated at 2022-06-23 17:08:43.486888
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    doc = GoogleParser()
    section = Section("New Section", "new_section", SectionType.SINGULAR)
    doc.add_section(section)
    assert section.title in doc.sections
    assert len(doc.sections) == len(DEFAULT_SECTIONS) + 1

# Generated at 2022-06-23 17:08:55.318458
# Unit test for constructor of class Section
def test_Section():
    """
    test constructor of class Section
    :return: None
    """
    # ex1: no argument is given
    try:
        s = Section()
        raise Exception
    except TypeError:
        pass
    # ex2: no argument is given
    try:
        s = Section(title="Title")
        raise Exception
    except TypeError:
        pass
    # ex3: no argument is given
    try:
        s = Section(title="Title", key="A")
        raise Exception
    except TypeError:
        pass
    # ex4: no argument is given
    try:
        s = Section(title="Title", key="A", type="B")
        raise Exception
    except TypeError:
        pass
    # ex5: argument is given

# Generated at 2022-06-23 17:08:56.733842
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GoogleParser.add_section(Section("Summary", "summary", SectionType.SINGULAR))

# Generated at 2022-06-23 17:09:08.284607
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Initialize a Parser
    parser = GoogleParser()
    # The default sections
    default_sections = [
    Section("Example", "examples", SectionType.SINGULAR),
    Section("Examples", "examples", SectionType.SINGULAR)
    ]
    # The new section to add
    new_section = Section("Test", "test", SectionType.SINGULAR)
    # Check the sections before adding a new section
    assert parser.sections == {section.title:section for section in default_sections}
    # Add a new section
    parser.add_section(new_section)
    # Check if the new section is added
    assert parser.sections == {section.title:section for section in default_sections + [new_section]}



# Generated at 2022-06-23 17:09:15.320894
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(TypeError):
        Section()
    assert Section("title", "key", SectionType.MULTIPLE).title == "title"
    assert Section("title", "key", SectionType.MULTIPLE).key == "key"
    assert Section("title", "key", SectionType.MULTIPLE).type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:09:26.320517
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:09:33.469455
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("BadSection","badsection", SectionType.MULTIPLE))
    title_colon = gp.title_colon
    sections = gp.sections
    titles_re = gp.titles_re
    assert title_colon == True
    assert titles_re != DEFAULT_SECTIONS
    assert sections != DEFAULT_SECTIONS

# Generated at 2022-06-23 17:09:42.522513
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    '''
    Test for add_section method
    :return:
    '''
    g_parser = GoogleParser()

    # Test for adding one section
    my_section = Section("my section", "my_section", SectionType.SINGULAR)
    g_parser.add_section(my_section)
    assert g_parser.sections['my section'] == my_section

    # Test for adding more sections
    my_section = Section("my section", "my_section", SectionType.SINGULAR)
    another_section = Section("another section", "another_section", SectionType.SINGULAR)
    g_parser.add_section(my_section)
    g_parser.add_section(another_section)
    assert g_parser.sections['my section'] == my_section

# Generated at 2022-06-23 17:09:55.589160
# Unit test for constructor of class Section
def test_Section():
    sec1 = Section('a','b',SectionType.SINGULAR);
    if sec1.title == 'a' and sec1.key== 'b' and sec1.type == SectionType.SINGULAR:
        print('Test1: succeed')
    else:
        print('Test1: failed')
    sec2 = Section('c','d',SectionType.MULTIPLE);
    if sec2.title == 'c' and sec2.key== 'd' and sec2.type == SectionType.MULTIPLE:
        print('Test2: succeed')
    else:
        print('Test2: failed')
    sec3 = Section('e','f',SectionType.SINGULAR_OR_MULTIPLE);

# Generated at 2022-06-23 17:10:05.331123
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    def func1():
        """Simple docstring.

        Args:
            arg: description

        Returns:
            description

        """

    func1_doc = parser.parse(func1.__doc__)
    # print(func1_doc)

    def func2(arg):
        """Simple docstring with type.

        Args:
            arg (int): description

        Returns:
            int: description

        """

    func2_doc = parser.parse(func2.__doc__)
    # print(func2_doc)

    def func3():
        """Simple docstring with optional.

        Args:
            arg (T.Optional[int]=None): description

        Returns:
            T.Optional[int]: description

        """


# Generated at 2022-06-23 17:10:13.147130
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    docstring = parser.parse("""
        Google-style docstring parsing.

        This module provides a function for parsing Google-style docstrings.
        The module can be used as a command-line utility or as a library.

        Parameters
        ----------
        text : str
            The docstring to parse.
        use_ast : bool
            Use the abstract syntax tree to find an initial guess of the
            function name and signature.

        Returns
        -------
        tuple(str, list[str], str)
            The parsed docstring with its summary, parameters and body.
        """)
    assert docstring.short_description == 'Google-style docstring parsing.'

# Generated at 2022-06-23 17:10:18.851604
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    sectionWithTitleColon = Section(title="TestSection", key="test", type=SectionType.MULTIPLE)
    parser = GoogleParser(sections=[sectionWithTitleColon], title_colon=True)
    docstring = parser.parse("TestSection:\n    Description of TestSection\n")
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert len(docstring.meta) == 1
    assert isinstance(docstring.meta[0], DocstringMeta)
    assert docstring.meta[0].description == "Description of TestSection"
    
    docstring = parser.parse("TestSection:\n    Test: Description of Test\n")
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert len(docstring.meta) == 1


# Generated at 2022-06-23 17:10:31.480345
# Unit test for function parse
def test_parse():
    assert parse("Simple no special keywords")
    assert parse("Simple no special keywords \n\n")
    docstr = parse("Short description. \n \n Long description. \n\n")
    assert docstr.short_description == "Short description."
    assert docstr.long_description == "Long description."
    assert docstr.blank_after_short_description
    assert docstr.blank_after_long_description

    docstr = parse("Short description. \nLong description. \n\n")
    assert docstr.short_description == "Short description."
    assert docstr.long_description == "Long description."
    assert not docstr.blank_after_short_description
    assert docstr.blank_after_long_description

    docstr = parse(
        """Short description.

        Long description.
        """
    )


# Generated at 2022-06-23 17:10:42.043697
# Unit test for function parse
def test_parse():
    text = """One line summary

    Extended description.

    Args:
        arg1(str): description 1. Defaults to 'value1'.
        arg2: description 2. Defaults to 'value2'.

    Raises:
        ValueError: If arg1 < 0

    Returns:
        bool: Description of return value.
    """
    docstring = parse(text)
    assert docstring.short_description == "One line summary"
    assert docstring.long_description == "Extended description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == "str"
   

# Generated at 2022-06-23 17:10:45.991335
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Unit test for method add_section of class GoogleParser"""
    parser = GoogleParser()
    test_section = Section("Args", "param", SectionType.MULTIPLE)
    parser.add_section(test_section)
    assert parser.sections["Args"].key == test_section.key
    assert parser.sections["Args"].title == test_section.title
    assert parser.sections["Args"].type == test_section.type
    return True


# Generated at 2022-06-23 17:10:55.653061
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleParser = GoogleParser(DEFAULT_SECTIONS, True)

# Generated at 2022-06-23 17:11:06.117054
# Unit test for function parse
def test_parse():
    assert inspect.cleandoc("") == parse("").description

    assert inspect.cleandoc("short") == parse("short").description
    assert inspect.cleandoc("short") == parse("short\n").description
    assert not parse("short\n").long_description

    assert inspect.cleandoc("short\n\nlong") == parse("short\n\nlong").description
    assert inspect.cleandoc("short\n\nlong") == parse("short\n\nlong\n").description

    assert (
        inspect.cleandoc("short\n\nlong\n\n")
        == parse("short\n\nlong\n\n").description
    )
    assert parse("short\n\nlong\n").long_description


# Generated at 2022-06-23 17:11:18.406253
# Unit test for constructor of class Section
def test_Section():
    #constructor only takes 3 arguments
    assert Section("Title", "Key", SectionType.MULTIPLE) is not None
    assert Section("Title", "Key", SectionType.SINGULAR) is not None
    assert Section("Title", "Key", SectionType.SINGULAR_OR_MULTIPLE) is not None
    assert Section("Title", "Param", SectionType.SINGULAR) == Section("Title", "Param", SectionType.SINGULAR)
    assert Section("Title", "Param", SectionType.SINGULAR) != Section("Title", "Param", SectionType.SINGULAR_OR_MULTIPLE)
    assert Section("Title", "Param", SectionType.SINGULAR) != Section("Title", "Key", SectionType.SINGULAR)

# Generated at 2022-06-23 17:11:21.265825
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE
    return

# Generated at 2022-06-23 17:11:26.907590
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser([])
    gp.add_section(Section("Return","return",SectionType.SINGULAR_OR_MULTIPLE))
    print(gp.sections)
    assert gp.sections == {"Return": Section("Return", "return", SectionType.SINGULAR_OR_MULTIPLE)}


# Generated at 2022-06-23 17:11:38.977292
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

    Extended description.

    Args:
      name: The name to use.
      state: Current state to be in.

    Returns:
      True if you can read this.

    Raises:
      ValueError: If `name` is empty.

    """
    ret = parse(docstring)
    assert ret.short_description == "Summary line."
    assert ret.long_description == "Extended description."
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    assert len(ret.meta) == 3
    assert ret.meta[0].description == "The name to use."
    assert ret.meta[0].type_name == "name"
    assert ret.meta[0].arg_name == "name"

# Generated at 2022-06-23 17:11:41.905643
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE

# Generated at 2022-06-23 17:11:53.930603
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test method parse of class GoogleParser."""
    test_dict = {
        "text": "Test the method parse of class GoogleParser",
        "short_description": "Test method parse of class GoogleParser",
        "long_description": None,
        "meta": [],
        "blank_after_short_description": None,
        "blank_after_long_description": None,
    }
    expected_docstring = Docstring(**test_dict)
    google_docstring = GoogleParser().parse(test_dict["text"])
    assert expected_docstring == google_docstring
    test_dict["text"] = "Test the method parse of class GoogleParser\nwith a long description"
    test_dict["long_description"] = test_dict["text"].split("\n")[1]

# Generated at 2022-06-23 17:11:57.376133
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE)
    ]
    parser = GoogleParser(sections)
    assert parser.sections == {'Arguments': Section('Arguments', 'param', SectionType.MULTIPLE)}

# Generated at 2022-06-23 17:12:10.284790
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test for adding a new section
    docstring = '''\
        """
        Arguments:
            a (int): first number
            b (int): second number
        """'''
    parser = GoogleParser()
    parser.add_section(Section("Multiply", "multiply", SectionType.MULTIPLE))
    doc = parser.parse(docstring)
    assert doc.meta[-1].args[0] == "multiply"
    assert doc.meta[-1].args[1] == "a (int): first number"
    assert doc.meta[-1].args[2] == "b (int): second number"
    assert doc.meta[-1].description == None
    assert doc.meta[-1].arg_name == None
    assert doc.meta[-1].type_name == None

# Generated at 2022-06-23 17:12:14.451345
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    splittedText = 'first line\n\nSecond Line'
    p = GoogleParser(sections=[])
    _ = p.parse(splittedText)
    assert len(_.meta) == 2


# Generated at 2022-06-23 17:12:19.616854
# Unit test for constructor of class Section
def test_Section():
    title = "title"
    key = "key"
    type = SectionType.SINGULAR
    section = Section(title, key, type)
    assert section.title == title
    assert section.key == key
    assert section.type == type


# Generated at 2022-06-23 17:12:28.190415
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    # Test 1: no text
    ret = g.parse("")
    expected = Docstring()
    print(ret)
    assert ret == expected

    # Test 2: simple description
    ret = g.parse("This is a description of it")
    expected = Docstring(
        short_description="This is a description of it",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )
    print(ret)
    assert ret == expected

    # Test 3: simple description with empty lines
    ret = g.parse("This is a better\n"
                  "\n"
                  "description of it!")

# Generated at 2022-06-23 17:12:29.035509
# Unit test for function parse
def test_parse():
    parse()

# Generated at 2022-06-23 17:12:34.715344
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    Adds section to object.
    """
    parser = GoogleParser()
    parser.add_section(Section("A", "b", SectionType.SINGULAR))
    parser.add_section(Section("B", "c", SectionType.MULTIPLE))
    parser.add_section(Section("C", "d", SectionType.SINGULAR_OR_MULTIPLE))



# Generated at 2022-06-23 17:12:46.948477
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
    ]

    a = GoogleParser()
    assert sections[0] in a.sections.values()
    assert sections[1] in a.sections.values()

    b = GoogleParser(sections=sections)
    assert sections[0] in b.sections.values()
    assert sections[1] in b.sections.values()

    b.add_section(Section("Args", "param", SectionType.MULTIPLE))
    assert sections[0] in b.sections.values()
    assert sections[1] in b.sections.values()

    c = GoogleParser(sections=sections)

# Generated at 2022-06-23 17:12:58.516507
# Unit test for function parse
def test_parse():
    src = """
    This is a long description.
    It contains multiple lines.
    And possibly an extra blank line.

    Args:
        arg1: argument 1
        arg2: argument 2
        arg3: argument 3

    Returns:
        rtype1: return value 1
        rtype2: return value 2
    """


# Generated at 2022-06-23 17:13:08.871066
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        param1:
            Some description for param1.
        param2 (SomeClassName):
            Some description for param2.

    Returns:
        Some description of the return value.
    """
    d = parse(text)
    assert d.short_description == "This is a short description."
    assert d.blank_after_short_description is True
    assert d.long_description == "This is a long description."
    assert d.blank_after_long_description is True
    assert len(d.meta) == 2
    assert isinstance(d.meta[0], DocstringParam)
    assert d.meta[0].arg_name == "param1"

# Generated at 2022-06-23 17:13:16.093756
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class G:
        """
        In the first argument, you need to indicate the path to the directory with
        the username.
        Args:
            path (str): The path to the directory with the username.
        Attributes:
            user_info (dict): The user's info.
        Returns:
            list: A list of user info.
        """
        def __init__(self, path):
            self.path = path

    doc = parse(inspect.getdoc(G))

    # print(doc.long_description)
    # print(doc.meta[0])
    # print(doc.meta[0].args)
    # print(doc.meta[0].description)
    # print(doc.meta[0].type_name)
    # print(doc.meta[0].is_optional)
    # print(doc

# Generated at 2022-06-23 17:13:25.703623
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docs = """
        This is a short description.

        This is an indented short description.

        This is a long description.

        This is an indented long description.

        Args:
            arg1 (str): The first argument.
            arg2 (str): The second argument.

        Returns:
            str: Description of return value.

        Yields:
            str: Description of yielded value.

        Raises:
            ValueError: The first exception type raised.
            ValueError: The second exception type raised.
    """
    parser = GoogleParser()
    parsed = parser.parse(docs)
    assert parsed.short_description == 'This is a short description.'
    assert parsed.long_description == 'This is a long description.'
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_

# Generated at 2022-06-23 17:13:37.505869
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Unit test for method parse of class GoogleParser
    # test of empty docstring
    assert GoogleParser().parse("") == Docstring()
    # test of docstring starting with a new line
    assert GoogleParser().parse("\n") == Docstring()

    # test of docstring starting with intended description
    assert GoogleParser().parse("short description") == Docstring(short_description="short description")

    # test of docstring starting with multiple intended description
    assert GoogleParser().parse("short description\nwith\nmultiple\nlines") == Docstring(short_description="short description\nwith\nmultiple\nlines")

    # test of docstring starting with short description which ends with new line
    assert GoogleParser().parse("short description\n") == Docstring(short_description="short description")

    # test of docstring starting with short description which ends with new

# Generated at 2022-06-23 17:13:44.959741
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    #Test1:
    test1_parser = GoogleParser()
    assert set(test1_parser.sections) == set(DEFAULT_SECTIONS)
    assert test1_parser.title_colon == True
    #Test2:
    test2_sections = [Section("Arguments", "param", SectionType.MULTIPLE),
                      Section("Args", "param", SectionType.MULTIPLE)]
    test2_parser = GoogleParser(test2_sections)
    assert set(test2_parser.sections) == set(test2_sections)
    assert test2_parser.title_colon == True
    #Test3:
    test3_parser = GoogleParser(title_colon=False)
    assert set(test3_parser.sections) == set(DEFAULT_SECTIONS)
    assert test3_parser

# Generated at 2022-06-23 17:13:52.329151
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GoogleParser().add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    GoogleParser().add_section(Section("()", "raises", SectionType.MULTIPLE))
    GoogleParser().add_section(Section("()", "raises", SectionType.SINGULAR_OR_MULTIPLE))
    try:
        GoogleParser().add_section(Section("()", "()", SectionType.SINGULAR))
        assert False
    except:
        assert True

# Generated at 2022-06-23 17:14:02.186293
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    class MySection(IntEnum):
        CLASSES = 0
        CLASS = 1

# Generated at 2022-06-23 17:14:11.542246
# Unit test for constructor of class Section
def test_Section():
    section1 = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section1.title == "Arguments"
    assert section1.key == "param"
    assert section1.type == 0
    section2 = Section("Args", "param", SectionType.MULTIPLE)
    assert section2.key == "param"
    assert section2.type == 0
    section3 = Section("Parameters", "param", SectionType.MULTIPLE)
    assert section3.key == "param"
    assert section3.type == 0
    section4 = Section("Params", "param", SectionType.MULTIPLE)
    assert section4.key == "param"
    assert section4.type == 0
    section5 = Section("Raises", "raises", SectionType.MULTIPLE)
    assert section

# Generated at 2022-06-23 17:14:24.576716
# Unit test for function parse
def test_parse():
    docstring = """Parses Google-style docstrings.
    Args:
        text (str): text of the docstring.

    Returns:
        Docstring: parsed docstring.

    Example::

        def foo(x):
            \"\"\"Does some very important stuff.

            Args:
                x (int): importance level.

            Returns:
                str: it's very important.

            \"\"\"
            if x > 42:
                return "life, the universe, and everything"
            return "nothing"

    Example:
        >>> foo(1)
        'nothing'
        >>> foo(42)
        'nothing'
        >>> foo(43)
        'life, the universe, and everything'
    """
    parsed = GoogleParser().parse(docstring)

# Generated at 2022-06-23 17:14:33.449677
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print("Testing constructor of class GoogleParser")
    print("Constructors with no params")
    assert GoogleParser().sections==DEFAULT_SECTIONS
    print("Constructors with 2 params: sections and title_colon")
    test_list = [Section("Arguments", "param", SectionType.MULTIPLE),
                 Section("Raises", "raises", SectionType.MULTIPLE),
                 Section("Example", "examples", SectionType.SINGULAR),
                 Section("Example", "examples", SectionType.SINGULAR)]

# Generated at 2022-06-23 17:14:38.395464
# Unit test for function parse
def test_parse():
    assert parse(
        'Hello world.\n\nArgs:\n  a: first parameter\n  b: second parameter'
    ) == parse(
        'Hello world.\n\nArgs:\n    a: first parameter\n    b: second parameter'
    )



# Generated at 2022-06-23 17:14:40.973482
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GoogleParser.add_section('Author','author')
    assert GoogleParser.add_section('Author','author') == DocstringMeta(args=[section.key, before], description=desc)


# Generated at 2022-06-23 17:14:49.805744
# Unit test for function parse
def test_parse():
    def f():
        """Summary line.

        Extended description of function.

        Args:
            x: int
                Description of x.
            y:
                Description of y.

        Returns:
            Description of return value.
        """
        pass

    def f_no_summary():
        """

        Extended description of function.

        Args:
            x: int
                Description of x.
            y:
                Description of y.

        Returns:
            Description of return value.
        """
        pass

    def f_no_description():
        """Summary line.

        Args:
            x: int
                Description of x.
            y:
                Description of y.

        Returns:
            Description of return value.
        """
        pass


# Generated at 2022-06-23 17:15:00.022486
# Unit test for function parse
def test_parse():
    text = '''The in-order traversal of this tree.
    :returns: list of keys in tree.
    '''
    text2 = '''hello
    :returns: list of keys in tree.
    '''
    doc = parse(text)
    assert doc.short_description == "The in-order traversal of this tree."
    assert doc.long_description == None
    assert doc.meta[0].description == "list of keys in tree."
    assert doc.meta[0].args[0] == 'returns'
    assert doc.meta[0].args[1] == 'list of keys in tree.'
    doc2 = parse(text2)
    assert doc2.short_description == "hello"
    assert doc2.long_description == None
    assert doc2.meta[0].description == None
   

# Generated at 2022-06-23 17:15:02.321016
# Unit test for constructor of class Section
def test_Section():
    s=Section('Arguments','param',0)
    assert s.title=='Arguments'
    assert s.key=='param'
    assert s.type==0


# Generated at 2022-06-23 17:15:09.827344
# Unit test for function parse
def test_parse():
    s = '''
    A Google-style docstring example.

    Attributes:
        attr1 (str): Docstring for attribute 1.
        attr2 (Optional[int]): Docstring for attribute 2.

    Keyword Args:
        kwarg1 (Tuple[int, int, int]): Docstring for a keyword argument.
        kwarg2 (str): Another keyword argument name.

    Args:
        arg1 (str): Docstring for a normal argument.
        arg2 (Union[str, bytes]): Another argument name.

    Raises:
        ValueError: The documentation for what errors this function raises.

    Returns:
        bool: The documentation for the return value.
    '''

    rs = parse(s)
    print(rs)


test_parse()

# Generated at 2022-06-23 17:15:11.770624
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    assert obj



# Generated at 2022-06-23 17:15:23.416582
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test method parse of class GoogleParser"""
    parser = GoogleParser()
    docstring = parser.parse('''
            Summary line.
            Extended description.
            
            Args:
                param1: (type): description
                param2 (type): description
        
            Args:
                param3 (type): description
            
            Attribute:
                attr_1 (type): description
                attr_2 (type): description
                
            Returns:
                type: description
                
            Yields:
                type: description

            Raises:
                ValueError: description
        ''')

# Generated at 2022-06-23 17:15:31.230656
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Example usage::
        >>> import inspect
        >>> from pydocstring import googleparser
        >>>
        >>> def testfunc():
        ...     '''Returns the sum of *a* and *b*.
        ...
        ...     Args:
        ...         a (int): First operand.
        ...         b (int): Second operand.
        ...
        ...     Returns:
        ...         int: The sum of *a* and *b*.
        ...     '''
        ...     return a + b
        >>>
        >>> gp = googleparser.GoogleParser()
        >>> result = gp.parse(inspect.getdoc(testfunc))
    """

# Generated at 2022-06-23 17:15:43.000032
# Unit test for function parse
def test_parse():
    docstring = """ Bla bla
    
    
     :param str address: IPV4 address like 192.168.1.1
     :param str attribute: (Optional) attribute of address.
    """
    result = parse(docstring)
    assert result.short_description == "Bla bla"
    assert result.meta[0] == DocstringParam(
        description='IPV4 address like 192.168.1.1',
        arg_name='address',
        type_name='str',
        is_optional=False,
        default=None,
        args=[
            'param', 'str address',
        ],
    )

# Generated at 2022-06-23 17:15:56.559155
# Unit test for function parse
def test_parse():
    text = """
    This is a test function

    Args:
        arg1 (str): test arg1.
        arg2 (int): test arg2. Defaults to 10.

    Kwargs:
        kwarg1 (str): test kwarg1.
        kwarg2 (float): test kwarg2. Defaults to 12.5.

    Example:
        an example

    Raises:
        AttributeError: When failing
        ValueError: When failing
    """
    p = parse(text)
    # Description
    print(p.short_description)
    print(p.long_description)
    print(p.blank_after_short_description)
    # Parameters