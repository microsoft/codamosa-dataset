

# Generated at 2022-06-23 17:06:02.322185
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    '''
    Test method parse of class GoogleParser
    '''
    text = '''\
    Find files.

    This text can be long. It can also be empty.

    Args:
        path (str): file path.
        pattern (str): regex pattern.

    Returns:
        List[str]: list of matching files.
    '''
    GP = GoogleParser()
    docstring = GP.parse(text)
    assert docstring.short_description == 'Find files.'
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == 'This text can be long. It can also be empty.'
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['returns', 'str']
    assert docstring.meta[0].arg

# Generated at 2022-06-23 17:06:06.691491
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    google_parser.add_section(Section("See Also", "see_also", 0))
    assert (google_parser.sections) != (Section("See Also", "see_also", 0))


# Generated at 2022-06-23 17:06:14.073508
# Unit test for constructor of class Section
def test_Section():
    # print("----------------> Unit test for constructor of class Section <----------------")
    title = "Raises"
    key = "raises"
    type = SectionType.MULTIPLE
    section = Section(title, key, type)
    print("section =", section)
    # => section = Section(title='Raises', key='raises', type=<SectionType.MULTIPLE: 1>)


# Generated at 2022-06-23 17:06:15.406605
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 17:06:21.900993
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    test_parser = GoogleParser()
    test_section = Section("New Section", "new_sec", SectionType.SINGULAR)
    test_parser.add_section(test_section)
    if(test_section not in test_parser.sections):
        print("Failed to add section")

if __name__ == "__main__":
    test_GoogleParser_add_section()

# Generated at 2022-06-23 17:06:28.667262
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = "To be, or not to be, that is the question. Whether tis nobler in the mind to suffer the slings and arrows of outrageous fortune."
    parser = GoogleParser()
    parser.add_section(Section("Or not", "or_not", 0))
    docstring = parser.parse(text)
    assert docstring.short_description == text
    assert len(docstring.meta) == 1
    assert docstring.meta[0].description == text

# Generated at 2022-06-23 17:06:39.194962
# Unit test for function parse
def test_parse():
    assert parse("").short_description == None
    assert parse("\n").short_description == None
    assert parse("\n\n").short_description == None
    assert parse("a").short_description == "a"
    assert parse("a\n").short_description == "a"
    assert parse("a\n\n").short_description == "a"
    assert parse("\na").short_description == None
    assert parse("\na\n").short_description == "a"
    assert parse("\na\n\n").short_description == "a"

    assert parse("a\nb").long_description == "b"
    assert parse("a\nb\n").long_description == "b"
    assert parse("a\nb\n\n").long_description == "b"

# Generated at 2022-06-23 17:06:46.359260
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.title_colon
    parser = GoogleParser(title_colon=False)
    assert not parser.title_colon

# Generated at 2022-06-23 17:06:57.541670
# Unit test for function parse
def test_parse():
    assert(parse("") == Docstring())
    assert(parse("\n") == Docstring())
    assert(parse("Foo\n") == Docstring(short_description="Foo"))
    assert(parse("Foo\n\n") == Docstring(short_description="Foo"))
    assert(parse("Foo.\n") == Docstring(short_description="Foo."))
    assert(parse("Foo.\n\n") == Docstring(short_description="Foo."))
    assert(parse("Foo\n Bar\n") == Docstring(short_description="Foo", long_description="Bar", blank_after_short_description=True, blank_after_long_description=False))

# Generated at 2022-06-23 17:07:00.176458
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    x = parse.__annotations__
    assert x['text'] == str
    assert x['return'] == Docstring
    

# Generated at 2022-06-23 17:07:08.081602
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_text = """
    ArrayStack is a stack class based on an array

    Attributes:
        stack_data: The stack data for the class.
        top_index: The index of the top of the stack.

    Examples:

        >>> s = ArrayStack()
        >>> len(s)
        0
        >>> s.push(2)
        >>> s.push(3)
        >>> len(s)
        2
        >>> s.pop()
        3
        >>> s.pop()
        2
        >>> len(s)
        0

    Raises:
        ValueError: If the stack is empty and a user tries to pop or peak it.
    """

    p = GoogleParser()
    doc = p.parse(google_text)
    assert doc.short_description == "ArrayStack is a stack class based on an array"


# Generated at 2022-06-23 17:07:09.601132
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    #initialize GoogleParser
    gp = GoogleParser(sections = None, title_colon = True)


# Generated at 2022-06-23 17:07:13.926904
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(Exception) as error:
        test_section = Section('hello', 'world', 3)     
    assert "IntEnum member must be a valid enumeration" in str(error.value)
    test_section = Section('hello', 'world', SectionType.MULTIPLE)
    assert test_section.title == 'hello'
    assert test_section.key == 'world'
    assert test_section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:07:17.406000
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    myStr = '''
    Python Program to check if a string is palindrome or not
    '''

    print(GoogleParser().parse(myStr))


test_GoogleParser()

# Generated at 2022-06-23 17:07:26.087062
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    # Create a new GoogleParser instance, initialize the list of all
    # the sections
    parser = GoogleParser()
    parser_sections = DEFAULT_SECTIONS

    # Create a new section
    new_section = Section("New", "new", SectionType.MULTIPLE)
    
    # Add the new section
    parser.add_section(new_section)
    new_sections = parser.sections
    new_titles_re = parser.titles_re

    # Initialize the list of all the acceptable sections
    acceptable_sections = parser_sections + [new_section]
    acceptable_sections_titles = []
    for acceptable_section in acceptable_sections:
        acceptable_sections_titles.append(acceptable_section.title)

    # Check if the new sections contain the new section

# Generated at 2022-06-23 17:07:29.854829
# Unit test for constructor of class Section
def test_Section():
    section = Section("Test", "test", "test_type")
    assert section.title == 'Test'
    assert section.key == 'test'
    assert section.type == 'test_type'


# Generated at 2022-06-23 17:07:40.182627
# Unit test for function parse
def test_parse():
    text = \
"""
Overview.

Args:
a (int): Description of argument a.
b (str): Description of argument b.

Raises:
ValueError: Description of error.

Returns:
Description of return value.
"""
    docstring = parse(text)
    assert docstring
    assert docstring.short_description == "Overview."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].keyword == 'param'
    assert docstring.meta[0].args == 'a', 'a (int)'
    assert docstring.meta[0].description == 'Description of argument a.'

# Generated at 2022-06-23 17:07:47.094479
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Add section
    title = "Attributes"
    key = "attribute"
    type = SectionType.MULTIPLE
    section = Section(title, key, type)
    gp = GoogleParser()
    gp.add_section(section)
    assert section in gp.sections.values()

    # Try to add section with existing title
    second_key = "second_attribute"
    section_duplicate = Section(title, second_key, type)
    gp.add_section(section_duplicate)
    assert section_duplicate not in gp.sections.values()



# Generated at 2022-06-23 17:07:50.050625
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser(title_colon=True)
    assert parser.titles_re is not None
    parser.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))
    parser = GoogleParser(title_colon=False)
    assert parser.titles_re is not None
    parser.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))


# Generated at 2022-06-23 17:07:55.963595
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Test", "test_key", SectionType.MULTIPLE)
    parser.add_section(section)
    assert parser.sections != DEFAULT_SECTIONS
    assert parser.sections["Test"] == section
    assert parser.sections["Test"] != DEFAULT_SECTIONS["Test"]


# Generated at 2022-06-23 17:08:06.637058
# Unit test for constructor of class Section
def test_Section():
    s_param = Section("Parameters", "param", SectionType.MULTIPLE)
    assert s_param.title == "Parameters"
    assert s_param.key == "param"
    assert s_param.type == SectionType.MULTIPLE

    s_returns = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert s_returns.title == "Returns"
    assert s_returns.key == "returns"
    assert s_returns.type == SectionType.SINGULAR_OR_MULTIPLE

    s_examples = Section("Examples", "examples", SectionType.SINGULAR)
    assert s_examples.title == "Examples"
    assert s_examples.key == "examples"
    assert s_examples.type == Section

# Generated at 2022-06-23 17:08:17.053888
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text = "Args:  \n    param1: The first parameter. Defaults to :\n    \n"
    sections = [Section("Args", "param", SectionType.MULTIPLE)]
    GoogleParser(sections=sections).parse(text)

    text = "Args:  \n    param1: The first parameter. Defaults to :\n    \n"
    sections = [Section("Args", "param", SectionType.MULTIPLE)]
    GoogleParser(sections=sections, title_colon=False).parse(text)

    text = "Args:\n    param1: The first parameter. Defaults to :\n    \n"
    GoogleParser(title_colon=False).parse(text)


# Generated at 2022-06-23 17:08:30.340470
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("asdf") == Docstring(short_description='asdf')
    assert GoogleParser().parse("asdf\n\ndefg") == Docstring(short_description='asdf', long_description='defg')
    assert GoogleParser().parse("asdf\ndefg") == Docstring(short_description='asdf', long_description='defg')
    assert GoogleParser().parse("asdf\n:qwer\nzxcv") == Docstring(short_description='asdf', long_description='zxcv')
    assert GoogleParser().parse("asdf\n:qwer\nzxcv\nqq") == Docstring(short_description='asdf', long_description='zxcv\nqq')
    assert GoogleParser().parse("asdf\n:qwer\nzxcv\n\nqq")

# Generated at 2022-06-23 17:08:37.398132
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("section", "section", SectionType.MULTIPLE))
    assert parser.sections["section"] == Section("section", "section", SectionType.MULTIPLE)
    parser.add_section(Section("section", "section", SectionType.SINGULAR))
    assert parser.sections["section"] == Section("section", "section", SectionType.SINGULAR)


# Generated at 2022-06-23 17:08:45.539041
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    docstr = """
    Test for parse method of class GoogleParser
    :param title_colon:
        require colon after section title.
    :type title_colon: bool
    :return: Section
    :rtype: Section
    """

    parser = GoogleParser()

# Generated at 2022-06-23 17:08:50.073056
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''Example 1
    Example 2'''

    parser = GoogleParser().parse(docstring)
    assert parser.short_description == 'Example 1'
    assert parser.long_description == 'Example 2'


# Generated at 2022-06-23 17:08:50.667568
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser is not None

# Generated at 2022-06-23 17:09:02.072474
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gparser = GoogleParser(sections=[])
    gparser.add_section(Section("Test1", "test1", SectionType.MULTIPLE))
    gparser.add_section(Section("Test2", "test2", SectionType.SINGULAR))
    gparser.add_section(Section("Test3", "test3", SectionType.SINGULAR_OR_MULTIPLE))
    test_sec = gparser.sections
    assert test_sec["Test1"].key == "test1"
    assert test_sec["Test2"].key == "test2"
    assert test_sec["Test3"].key == "test3"
    assert test_sec["Test1"].type == SectionType.MULTIPLE
    assert test_sec["Test2"].type == SectionType.SINGULAR
    assert test_sec

# Generated at 2022-06-23 17:09:06.448827
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key", SectionType.MULTIPLE)
    assert section.title == "title"
    assert section.key == "key"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:09:14.797905
# Unit test for function parse

# Generated at 2022-06-23 17:09:15.955606
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()


# Generated at 2022-06-23 17:09:26.744579
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # pylint: disable=R0914,R0915
    def _test_GoogleParser_parse(expected, text):
        docstring = GoogleParser().parse(text)
        assert docstring.short_description == expected.short_description
        assert docstring.long_description == expected.long_description
        assert docstring.blank_after_short_description == expected.blank_after_short_description
        assert docstring.blank_after_long_description == expected.blank_after_long_description
        assert len(docstring.meta) == len(expected.meta)
        for actual, expected in zip(docstring.meta, expected.meta):
            assert actual == expected


# Generated at 2022-06-23 17:09:34.792844
# Unit test for function parse
def test_parse():
    def f(a: int, b: int=3) -> T.Tuple[int, int]:
        """Computes the sum of two integers.

        Args:
            a: The first argument.
            b: The second argument.

        Returns:
            (a+b, a*b)
        """
        pass
    assert GoogleParser().parse(f.__doc__) == parse(f.__doc__)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:09:37.803701
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("TITLE", "key", SectionType.MULTIPLE)]
    parser = GoogleParser(sections)
    assert parser.sections == {"TITLE": sections[0]}



# Generated at 2022-06-23 17:09:40.353095
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.sections == {s.title: s for s in DEFAULT_SECTIONS}
    assert parser.title_colon == True



# Generated at 2022-06-23 17:09:45.136098
# Unit test for constructor of class Section
def test_Section():
    # Section(title, key, type)
    # title: 部分的标题
    # key：部分的密钥
    # type: 部分的类型
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    print(s)

if __name__ == "__main__":
    test_Section()


'''
Section(title='Arguments', key='param', type=<SectionType.MULTIPLE: 1>)
'''

# Generated at 2022-06-23 17:09:56.920035
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-23 17:10:06.194461
# Unit test for function parse
def test_parse():
    text = '''\
    Short summary.

    Long multiline description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        AttributeError, KeyError
    '''


# Generated at 2022-06-23 17:10:09.618199
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    docs = inspect.getdoc(GoogleParser)
    assert docs == """\
        Google-style docstring parser.

        :param sections: Recognized sections or None to defaults.
        :param title_colon: require colon after section title.
        """


# Generated at 2022-06-23 17:10:20.894958
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    section_0 = Section("section_0", "section_0", SectionType.SINGULAR)
    section_1 = Section("section_1", "section_1", SectionType.MULTIPLE)
    section_2 = Section("section_2", "section_2", SectionType.SINGULAR_OR_MULTIPLE)
    google_parser.add_section(section_0)
    google_parser.add_section(section_1)
    google_parser.add_section(section_2)
    assert(google_parser.titles_re == re.compile("^(section_(0|1|2))[ \t\r\f\v]*$", flags=re.M))

# Generated at 2022-06-23 17:10:29.991870
# Unit test for function parse
def test_parse():
    from doctring_parser.google import parse as gparse
    text = '''
    Parses the Google-style docstring into its components.

    :returns: parsed docstring
    '''
    docstring = gparse(text)
    assert docstring.short_description == 'Parses the Google-style docstring into its components.'
    assert docstring.long_description is None
    assert docstring.blank_after_long_description is None
    assert docstring.blank_after_short_description is True
    assert len(docstring.meta) == 1


# Generated at 2022-06-23 17:10:38.669008
# Unit test for function parse
def test_parse():
    """Test for function parse."""
    doc = """Example function with types documented in the docstring.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    parsed = parse(doc)
    assert parsed.short_description == "Example function with types documented in the docstring."
    assert parsed.long_description is None
    assert parsed.meta[0].args == ['returns', 'bool']
    assert parsed.meta[0].arg_name is None
    assert parsed.meta[0].type_name == 'bool'
    assert parsed.meta[0].description == 'The return value. True for success, False otherwise.'

# Generated at 2022-06-23 17:10:46.956718
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().sections == GoogleParser([]).sections == {
        s.title: s for s in DEFAULT_SECTIONS
    }
    assert GoogleParser([Section("Test1", "test1", SectionType.SINGULAR)]).sections == {
        s.title: s for s in [Section("Test1", "test1", SectionType.SINGULAR)]
    }



# Generated at 2022-06-23 17:10:55.671897
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE
    
    # Test if the default SectionType is valid
    s = Section("Arguments", "param")
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE
    # The default SectionType should be MULTIPLE
    # The following will cause an error
    # s = Section("Arguments", "param", SectionType.SINGULAR)


# Generated at 2022-06-23 17:10:56.679516
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert isinstance(GoogleParser(), GoogleParser)

# Generated at 2022-06-23 17:11:02.447316
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE
    assert str(s) == "Section(title='Arguments', key='param', type=<SectionType.MULTIPLE: 1>)"
    assert repr(s) == "Section(title='Arguments', key='param', type=<SectionType.MULTIPLE: 1>)"


# Generated at 2022-06-23 17:11:03.860983
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """Unit test for constructor of class GoogleParser"""
    parser = GoogleParser()
    assert parser.sections == {s.title: s for s in DEFAULT_SECTIONS}
    assert parser.title_colon == True


# Generated at 2022-06-23 17:11:16.014174
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:11:17.160556
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()


# Generated at 2022-06-23 17:11:19.728460
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key_word", "type")
    assert (section.title == "title")
    assert (section.key == "key_word")
    assert (section.type == "type")

# Generated at 2022-06-23 17:11:25.218732
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    for doc in test_docstrings_Google:
        assert GoogleParser().parse(doc) == docstring.parse(doc)

for doc, obj in zip(test_docstrings_Google, test_docstrings_Google_objects):
    assert GoogleParser().parse(doc) == obj
    assert GoogleParser().parse(doc) == docstring.parse(doc)


# Generated at 2022-06-23 17:11:30.661058
# Unit test for constructor of class Section
def test_Section():
    """Testing the constructor of class Section."""
    title = 'a'
    key = 'b'
    type_section = SectionType.MULTIPLE
    section = Section(title, key, type_section)
    assert section.title == title
    assert section.key == key
    assert section.type == type_section


# Generated at 2022-06-23 17:11:31.830166
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser


# Generated at 2022-06-23 17:11:42.806841
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Sections
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Attributes", "attribute", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]

    # constructor
    g1 = GoogleParser()
    g2 = GoogleParser(sections)
    g3 = GoogleParser(sections, True)
    g4 = GoogleParser(sections, False)

# Generated at 2022-06-23 17:11:48.411924
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    GoogleParser().parse("""
    This is a test.
    
    :param x: This is x.
    :type x: int
    :param y: This is y.
    :type y: str
    :returns: x + y
    :rtype: str
    
    Here is more test text.
    """)


# Generated at 2022-06-23 17:11:59.034645
# Unit test for function parse
def test_parse():
    docstring = inspect.cleandoc(
        """
    Short description.

    Long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        The return value. True for success, False otherwise.
    Raises:
        SomeCustomError: Some custom error.

    """
    )
    print(docstring)
    doc = parse(docstring)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.meta)
    assert len(doc.meta) == 3
    print(doc.meta[0])
    assert "arg1" in doc.meta[0].description
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].description == "The first argument."
   

# Generated at 2022-06-23 17:12:11.584959
# Unit test for function parse

# Generated at 2022-06-23 17:12:23.933798
# Unit test for constructor of class Section
def test_Section():
    section_type_long = 'MULTIPLE'
    section_type_short = 'M'

    section = Section(
        "Arguments", "param", 'MULTIPLE')
    assert section.title=='Arguments'
    assert section.key=='param'
    assert isinstance(section.type, SectionType)
    assert section.type.name==section_type_long
    assert section.type.value==1

    section = Section(
        "Arguments", "param", 'M')
    assert section.title=='Arguments'
    assert section.key=='param'
    assert isinstance(section.type, SectionType)
    assert section.type.name==section_type_long
    assert section.type.value==1

    section = Section(
        "Arguments", "param", 'SINGULAR')

# Generated at 2022-06-23 17:12:35.226601
# Unit test for function parse
def test_parse():
    docstring = """Summary line.

    Extended description of function.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value

    """
    result = parse(docstring)
    assert isinstance(result.meta, list)
    assert isinstance(result.meta[0], DocstringParam)
    assert isinstance(result.meta[1], DocstringParam)
    assert(result.meta[0].arg_name=='arg1')
    assert(result.meta[1].arg_name=='arg2')
    assert(result.meta[0].type_name=='int')
    assert(result.meta[1].type_name=='str')
    assert isinstance(result.meta[2], DocstringReturns)

# Generated at 2022-06-23 17:12:38.149777
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GOOGLE_PARSER = GoogleParser()
    assert isinstance(GOOGLE_PARSER, GoogleParser)


# Generated at 2022-06-23 17:12:49.153296
# Unit test for function parse
def test_parse():
    docstring = '''
    This is a long description
    that is longer than the
    short description.

    Args:
        param1: The first parameter.
        param2: The second parameter. Defaults to None.
        param3: The third parameter.
    '''


# Generated at 2022-06-23 17:12:59.715955
# Unit test for constructor of class Section
def test_Section():
    a = Section("name1", "key1", SectionType.SINGULAR)
    print(a)
    a = Section("name1", "key1", SectionType.SINGULAR_OR_MULTIPLE)
    print(a)
    a = Section("name1", "key1", SectionType.MULTIPLE)
    print(a)
    a = Section(name="name1", key="key2", type=SectionType.SINGULAR_OR_MULTIPLE)
    print(a)
    a = Section(name="name2", key="key2", type=SectionType.MULTIPLE)
    print(a)
    a = Section(name="name3", key="key3", type=SectionType.SINGULAR)
    print(a)

# Generated at 2022-06-23 17:13:09.240616
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('Example document.') == Docstring(short_description='Example document.\n')
    assert GoogleParser().parse('Example document.\n') == Docstring(short_description='Example document.')
    assert GoogleParser().parse('Example document.\n\n') == Docstring(short_description='Example document.')
    assert GoogleParser().parse('Example document.\n\nThis is a long description.') == Docstring(short_description='Example document.', long_description='This is a long description.', blank_after_long_description=False, blank_after_short_description=True)

# Generated at 2022-06-23 17:13:16.329311
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().sections == DEFAULT_SECTIONS

# Generated at 2022-06-23 17:13:24.154636
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser=GoogleParser()
    # Test to add a new section
    parser.add_section(Section("Section1","param",SectionType.MULTIPLE))
    # Test to replace an old section
    parser.add_section(Section("Args","param",SectionType.SINGULAR))
    # Test to replace an old section with a new one with same title
    parser.add_section(Section("Args","param",SectionType.MULTIPLE))
    assert(parser.sections["Section1"] == Section("Section1","param",SectionType.MULTIPLE))
    assert(parser.sections["Args"] == Section("Args","param",SectionType.MULTIPLE))

# Generated at 2022-06-23 17:13:36.044192
# Unit test for function parse
def test_parse():
    # Test Google-style parsing
    text = """
    Short desc
    Long desc

    Args:
        a: first arg
        b: second arg

    Returns:
        add(a, b)

    Raises:
        None.
    """
    result = parse(text)
    assert result.short_description == "Short desc"
    assert result.long_description == "Long desc"
    assert result.meta[0].arg_name == "a"
    assert result.meta[1].arg_name == "b"
    assert result.meta[2].description == "add(a, b)"
    assert result.meta[3].description == "None."


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:13:38.740161
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(TypeError):
        Section()
    assert Section('test1','test2','test3') == ('test1','test2','test3')


# Generated at 2022-06-23 17:13:51.497018
# Unit test for function parse
def test_parse():
    docstring = '''
        Test Docstring.

        Args:
            param1 (str): Description of param1
            param2 (bool): Description of param2
            param3 (:obj:`module.ClassName`): Description of param3

        Returns:
            bool: Description of return value
    '''
    d = parse(docstring)
    assert d.short_description == "Test Docstring."
    assert d.meta[0] == DocstringParam(
        args=["param", "param1 (str)"],
        description="Description of param1",
        arg_name="param1",
        type_name="str",
        is_optional=False,
        default=None,
    )

# Generated at 2022-06-23 17:13:55.530567
# Unit test for constructor of class Section
def test_Section():
    section = Section("Titulo", "key", "SINGULAR_OR_MULTIPLE")
    assert section.title == "Titulo"
    assert section.key == "key"
    assert section.type == "SINGULAR_OR_MULTIPLE"


# Generated at 2022-06-23 17:14:06.661509
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test add_section method of GoogleParser class."""
    text = """
    @interface
    Adds a new header to the header list.
    :param header: The new header.
    :param value: The new header's value.
    """
    doc = GoogleParser().parse(text)
    doc.meta[0].arg_name == "header"
    doc.meta[0].type_name == "str"
    doc.meta[0].is_optional == None
    assert doc.meta[0].description == "The new header."
    doc.meta[1].arg_name == "value"
    doc.meta[1].type_name == "str"
    doc.meta[1].is_optional == None
    assert doc.meta[1].description == "The new header's value."

    gp = GoogleParser()
    gp

# Generated at 2022-06-23 17:14:10.321287
# Unit test for constructor of class Section
def test_Section():
    title = "Arguments"
    key = "param"
    type1 = SectionType.MULTIPLE
    section1 = Section(title, key, type1)

    assert section1.title == title
    assert section1.key == key
    assert section1.type == type1


# Generated at 2022-06-23 17:14:22.998117
# Unit test for function parse
def test_parse():
    """Test parse function

    :return:
    """
    doc = """A short summary.

    A long summary.

    Args:
        a: Description of parameter a
        b: Description of parameter b

    Returns:
        description of return value

    Raises:
        exception one
        exception two
    """
    res_doc = parse(doc)
    assert res_doc.short_description == "A short summary."
    assert res_doc.long_description == "A long summary."
    assert len(res_doc.meta) == 3
    assert isinstance(res_doc.meta[0], DocstringParam)
    assert isinstance(res_doc.meta[1], DocstringReturns)
    assert isinstance(res_doc.meta[2], DocstringRaises)

# Generated at 2022-06-23 17:14:31.382133
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('\t') == Docstring()
    assert GoogleParser().parse('  \t') == Docstring()
    assert GoogleParser().parse('eol\n') == Docstring()
    assert GoogleParser().parse('\n') == Docstring()
    assert GoogleParser().parse('  \n') == Docstring()
    assert GoogleParser().parse('  \n  ') == Docstring()
    assert GoogleParser().parse('\n\n') == Docstring()
    assert GoogleParser().parse('  \n\n') == Docstring()
    assert GoogleParser().parse('  \n\n  ') == Docstring()
    assert GoogleParser().parse('  \n\n  \n\n') == Docstring()

# Generated at 2022-06-23 17:14:38.165424
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("K1", 1, 0), Section("K2", 2, 1)]
    parser = GoogleParser(sections, False)
    assert len(parser.sections) == 2
    assert parser.sections["K1"] == sections[0]
    assert parser.sections["K2"] == sections[1]
    assert parser.title_colon == False



# Generated at 2022-06-23 17:14:44.621783
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # given
    parser = GoogleParser()
    section = Section("Section", "key", "SectionType.SINGULAR")
    # when
    parser.add_section(section)
    # then
    assert parser.sections["Section"] == section
    assert parser._titles_re.pattern == "^(Section)[ \t\r\f\v]*$"

# Generated at 2022-06-23 17:14:55.529503
# Unit test for function parse
def test_parse():
    text = """
        Top level docs.

        This function does someting.

        Args:
            a: An integer of the size of the universe.
                Defaults to 42.
            b: So called "bar" with a strange name.
                Should be a float.
                Also defaults to 42.

        Returns:
            The answer and everything else.
            If you are alive, this would be an error.

        Raises:
            ValueError: if you've done some wrong.

        Examples:
            This is an example for you. Go for it!
    """
    print(parse(text))

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-23 17:15:03.577576
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Success
    assert GoogleParser().parse("""
        This is the summary line.

        This is the description.

        Args:
          This is the first argument.
          This is the second argument.
        """) == Docstring(
        short_description='This is the summary line.',
        long_description='This is the description.',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=['param'],
                description='This is the first argument.'
            ),
            DocstringMeta(
                args=['param'],
                description='This is the second argument.'
            )
        ]
    )

    # Success

# Generated at 2022-06-23 17:15:06.693461
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section = Section("Added Section", "addsec", SectionType.SINGULAR)
    parser = GoogleParser(sections=[section])
    section = Section("Changed Section", "changesec", SectionType.MULTIPLE)
    parser.add_section(section)
    return parser



# Generated at 2022-06-23 17:15:13.580990
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [Section('Custom Section Title', 'custom', SectionType.SINGULAR)]
    parser = GoogleParser(title_colon=True)
    parser.add_section(sections[0])
    assert sections[0].title in parser.sections
    assert sections[0].key in parser.sections
    assert sections[0].type in parser.sections


# Generated at 2022-06-23 17:15:24.678926
# Unit test for function parse
def test_parse():
    from .numpy_style import NumpyParser

    def test_parse(parser, text): 

        res = parser(text)
        print(res)
        res2 = parse(text)
        print(res2)

    text = """\
    Args:
        a: int.
        b: int. a+b

    returns:
        int. c 
    """
    test_parse(NumpyParser, text)
    print()

    text = """\
    Args:
        a: int.
        b: int. a+b

    Returns:
        int. c
    """
    test_parse(NumpyParser, text)
    print()

    text = """\
    Parameters
        a: int.
        b: int. a+b

    Returns:
        int. c
    """


# Generated at 2022-06-23 17:15:31.853340
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    text = """\
    First line of docstring.

    Second line of docstring.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    parsed = parse(text)
    assert parsed.short_description == "First line of docstring."
    assert parsed.long_description == "Second line of docstring."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 1
    assert parsed.meta[0].args == ["param", "arg1"]
    assert parsed.meta[0].description == "The first argument."
    assert parsed.meta[0].arg_name == "arg1"
    assert parsed.meta[0].type_name is None


# Generated at 2022-06-23 17:15:36.432783
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    x = GoogleParser()
    new_section = Section("New Section", "new", SectionType.SINGULAR_OR_MULTIPLE)
    x.add_section(new_section)
    assert x.titles_re.search("New Section").group(1) == "New Section"

# Generated at 2022-06-23 17:15:41.791223
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleParser = GoogleParser()
    assert googleParser.title_colon == True
    assert googleParser.titles_re is not None
    assert googleParser.sections is not None
    assert len(googleParser.sections.keys()) == 12
    assert "Args" in googleParser.sections
    assert "Returns" in googleParser.sections


# Generated at 2022-06-23 17:15:55.099503
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    class CustomGoogleParser(GoogleParser):
        def __init__(self):
            super().__init__()

        def _setup(self):
            if self.title_colon:
                colon = ":"
            else:
                colon = ""
            self.titles_re = re.compile(
                "^("
                + "|".join("(%s)" % t for t in self.sections)
                + ")"
                + colon
                + "[ \t\r\f\v]*$",
                flags=re.M,
            )
