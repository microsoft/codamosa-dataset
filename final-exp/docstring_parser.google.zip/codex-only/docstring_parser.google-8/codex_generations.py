

# Generated at 2022-06-23 17:06:07.881574
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #method parse return value test
    docstring_object = GoogleParser().parse("Author: Naoto MOTOHASHI")
    assert docstring_object.short_description == 'Author'
    assert docstring_object.long_description == 'Naoto MOTOHASHI'

    # short description has blank line test
    docstring_object = GoogleParser().parse("""Author: Naoto MOTOHASHI
    """)
    assert docstring_object.short_description == 'Author'
    assert docstring_object.long_description == 'Naoto MOTOHASHI'

    # short_descripion and long_description have blank line test
    docstring_object = GoogleParser().parse("""Author: Naoto MOTOHASHI

    """)
    assert docstring_object.short_description == 'Author'
    assert docstring_object.long_description

# Generated at 2022-06-23 17:06:18.852520
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("Attributes", "attribute", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Examples", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    gparser = GoogleParser(sections)
    gparser.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    docstring = "Returns:\n    str: The string 'boo'."
    doc = gparser.parse(docstring)
    assert doc.returns.type_name == "str"

# Generated at 2022-06-23 17:06:30.646386
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Parse the Google-style docstring into its components.

               :param text: docstring text
               :param sections: sections to parse or None for all
               :param title_colon: require colon after section title
               :returns: parsed docstring
           """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "Parse the Google-style docstring into its components."
    assert docstring.long_description == ":param text: docstring text\n:param sections: sections to parse or None for all\n:param title_colon: require colon after section title\n:returns: parsed docstring"
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "text"]

# Generated at 2022-06-23 17:06:38.152729
# Unit test for function parse
def test_parse():
    # Modify the docstring to indicate that it is a sphinx extension.
    doc = """Test function.
    
    :param a: test a
    :type a: int
    :param b: test b
    :type b: int
    :example: this is an example
    :returns: a + b
    :rtype: int
    :raises ValueError: If a or b are negative numbers
    """

    result = parse(doc)
    print(result)


# Run the unit test for function parse
test_parse()

# Generated at 2022-06-23 17:06:45.522352
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Tests the method add_section of class GoogleParser."""
    custom_sections = [
        Section("Enthalpies", "enthalpies", SectionType.MULTIPLE),
        Section("Enthalpy", "enthalpy", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    parser = GoogleParser(custom_sections, title_colon=False)
    parser.add_section(Section("Entropies", "entropies", SectionType.MULTIPLE))
    assert len(parser.sections) == 3
    assert parser.titles_re == re.compile(
        "^("
        + "|".join("(%s)" % t for t in parser.sections)
        + ")"
        + "([ \t\r\f\v]*$)"
    )
    # Checking

# Generated at 2022-06-23 17:06:57.037954
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    docstr = """Single line docstring.

    This is a longer description of what the function does.

    Args:
        arg1 (str): Description of arg1. Defaults to None.
        arg2 (int): Description of arg2.

    Parameters:
        arg3 (T.List[T.Tuple[str]]): Description of arg3.

    Returns:
        arg4 (T.List[T.List[Tuple[str]]]): Description of arg4.
        arg5 (T.List[T.List[Tuple[str]]]): Description of arg5.

    Raises:
        ValueError: Something is wrong.
        TypeError: Wrong type.
        IndexError: Index is wrong.

    """
    result = GoogleParser().parse(docstr)
    assert result.short_description == 'Single line docstring.'


# Generated at 2022-06-23 17:07:00.490972
# Unit test for function parse
def test_parse():
    """Unit test for function parse()."""
    import doctest

    return doctest.testmod(verbose=True)[0]


if __name__ == "__main__":
    print(test_parse())

# Generated at 2022-06-23 17:07:06.657769
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parsed_sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]

    googleParser = GoogleParser(sections = parsed_sections)
    for parsed_section in parsed_sections:
        assert(googleParser.sections.get(parsed_section.title) == parsed_section)


# Generated at 2022-06-23 17:07:07.758379
# Unit test for constructor of class Section
def test_Section():
    sct = Section("Example", "examples", SectionType.SINGULAR)
    print(sct)



# Generated at 2022-06-23 17:07:19.788090
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    docstring = """\
    Test module

    Parameters
    ----------
    param1: description of parameter 1. Defaults to 0.
    param2: description of parameter 2. Defaults to 1.

    Raises
    ------
    ArithmeticError
        If param2 is zero.

    Examples
    --------
    >>> test_GoogleParser_add_section()
    """
    doc = GoogleParser(DEFAULT_SECTIONS).parse(docstring)
    assert doc.short_description == "Test module"

# Generated at 2022-06-23 17:07:29.167843
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('Description') == Docstring(short_description='Description')
    assert GoogleParser().parse('Description\nMore\n') == Docstring(short_description='Description',long_description='More')
    assert GoogleParser().parse('Description\n\nMore\n\n') == Docstring(short_description='Description',long_description='More',blank_after_short_description=True, blank_after_long_description=True)

    assert GoogleParser().parse('Args:\n  arg1: Arg1') == Docstring(short_description=None, meta=[DocstringParam(arg_name='arg1', description='Arg1', args=['param', 'arg1'])])

# Generated at 2022-06-23 17:07:37.096444
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    google_parser = GoogleParser()
    assert google_parser.parse(
        '''
    Class for parameters of the derivative of the Rosenbrock function

    :ivar a: multiplier for second term of Rosenbrock f
    :ivar b: multiplier for first term of Rosenbrock f
    '''
    ) == Docstring(
        short_description="Class for parameters of the derivative of the Rosenbrock function",
        meta=[
            DocstringMeta(
                args=["param", "a"],
                description="multiplier for second term of Rosenbrock f",
            ),
            DocstringMeta(
                args=["param", "b"],
                description="multiplier for first term of Rosenbrock f",
            ),
        ],
    )


# Generated at 2022-06-23 17:07:45.601904
# Unit test for function parse
def test_parse():
    def foo():
        """Returns a value.

        Arguments:
            bar (int): bar

        Returns:
            int: the value

        Raises:
            IndexError: If bar is negative.
        """
        pass

    doc = parse(foo.__doc__)
    assert doc.short_description == "Returns a value."
    assert doc.long_description == ""
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert len(doc.meta) == 3
    assert doc.meta[0].type_name == "int"
    assert doc.meta[1].is_generator is False
    assert doc.meta[2].is_exception
    return doc

# Generated at 2022-06-23 17:07:58.481808
# Unit test for function parse
def test_parse():
    text = """Google-style docstring parsing.

    Args:
        arg1: A positional argument.
        arg2 (int): An optional argument.
        arg3, arg4 (str): A tuple.
        arg5, arg6 (int, optional): A tuple with a default.

    Returns:
        int: The return value. True for success, False otherwise.
        str: Show how to specify multiple returns.
    """

    docstr = parse(text)
    assert docstr.short_description == "Google-style docstring parsing"
    assert docstr.blank_after_short_description
    assert docstr.long_description == None
    assert docstr.blank_after_long_description
    assert len(docstr.meta) == 5

    meta0 = docstr.meta[0]

# Generated at 2022-06-23 17:08:07.947360
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # GoogleParser.parse(<docstring>) -> Docstring
    # this unit test checks that the docstring <docstring> gets parsed correctly into the
    # Docstring object returned by GoogleParser.parse(<docstring>)
    docstring = inspect.cleandoc("""
    Google-style docstrings.

    This function does nothing.

    This is the first line of a paragraph in the long description.
    The next line is part of the same paragraph;
    the line after it is empty, and the next two lines are another paragraph.

    :param message:
        Explanation about the parameter
    :returns:
        None
    :raises ValueError:
        If `message` is empty.
    """)

# Generated at 2022-06-23 17:08:17.730186
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is the short description
    And this is the long description

    Some text.
    More text.
    Even more text.

    Parameters
    ----------
    p1 : str
        The first parameter.

    p2 : int
        The second parameter

    Raises
    ------
    ValueError
        Invalid value

    """
    parser = GoogleParser()
    doc = parser.parse(docstring)
    print(doc.meta)
    print(doc.long_description)
    print(doc.short_description)
    print(doc.meta[0].args)
    print(doc.meta[0].description)


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:08:23.668832
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    gp.add_section(Section("a","a",0))
    assert gp.titles_re.search("a:") is not None
    gp = GoogleParser(title_colon=False)
    assert gp.titles_re.search("a:") is None

# Generated at 2022-06-23 17:08:35.921646
# Unit test for constructor of class Section
def test_Section():
    #     def __init__(
    #         self, title: str, key: str, type: SectionType
    #     ):
    # Should pass
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    print("Successfully instantiate Section 'Arguments' with \
        title=Arguments key=param and type=SectionType.MULTIPLE")
    print("Title: " + section.title)
    print("Key: " + section.key)
    print("Type: " + str(section.type))

    # Should not pass because the type is not in the enum
    try:
        Section("Arguments", "param", 2)
    except Exception as e:
        print(e)
    print("Successfully detect the error when instantiating Section 'Arguments'\
        with type=2")



# Generated at 2022-06-23 17:08:43.211868
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("This is short desc\nThis is long desc\n") == Docstring(
        short_description="This is short desc",
        blank_after_short_description=True,
        long_description="This is long desc",
        blank_after_long_description=False,
        meta=[],
    )
    # Test one line long desc
    assert parse("This is short desc\nThis is long desc") == Docstring(
        short_description="This is short desc",
        blank_after_short_description=True,
        long_description="This is long desc",
        blank_after_long_description=False,
        meta=[],
    )
    # Test long desc with two empty lines

# Generated at 2022-06-23 17:08:48.896481
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    skip = False
    if not skip:
        sections = DEFAULT_SECTIONS
        title_colon = True
        gp = GoogleParser(sections, title_colon)
        assert sections == gp.sections
        assert title_colon == gp.title_colon



# Generated at 2022-06-23 17:08:56.332989
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Compute sum of a and b.

    Examples:
    >>> a = 1
    >>> b = 2
    >>> a + b
    3
    Returns:
    int: sum of a and b
    """

    parsed = GoogleParser().parse(text)
    assert parsed.long_description == "Examples:\n>>> a = 1\n>>> b = 2\n>>> a + b\n3"
    assert parsed.short_description == "Compute sum of a and b."
    assert parsed.meta[0].description == "sum of a and b"
    assert parsed.meta[0].type_name == "int"


# Generated at 2022-06-23 17:09:08.707339
# Unit test for function parse
def test_parse():
    def test_parse():
        def f():
            """spam
            This is a test.
            :param int x: This is a x.
            :param str y: This is a y.
            :type n: int
            :raises ValueError: This is a ValueError.
            :raises TypeError: This is a TypeError.
            :returns: This is a return value.
            :rtype: float
            """
            print("hello world")
        d = parse(f.__doc__)
        assert d.short_description == "spam"
        assert d.long_description == "This is a test."
        assert d.blank_after_short_description is True
        assert d.blank_after_long_description is False
        assert len(d.meta) == 5


# Generated at 2022-06-23 17:09:22.052546
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Base class for plugins that extract information from source trees.

    This plugin extracts the following information from source trees:\n
        * Paths to source files
        * Paths to test files
        * Methods/functions defined in source files
        * Classes defined in source files
        * Paths to dependencies of source files (imports)
        * Paths to items imported by files in source files

    """

# Generated at 2022-06-23 17:09:24.914809
# Unit test for constructor of class Section
def test_Section():
    assert Section('Parameters', 'param', SectionType.MULTIPLE) == (
        'Parameters', 'param', SectionType.MULTIPLE
    )

# Generated at 2022-06-23 17:09:27.296806
# Unit test for constructor of class Section
def test_Section():
    test = Section("Arguments", "param", 0)
    assert test.title == "Arguments"
    assert test.key == "param"
    assert test.type == 0


# Generated at 2022-06-23 17:09:38.980619
# Unit test for function parse
def test_parse():
    a = """
        This is the first line of the first paragraph
    """
    assert parse(a) == Docstring(short_description='This is the first line of the first paragraph')

    b = """
        This is the first line of the first paragraph
        \n
        This is the second paragraph
    """
    assert parse(b) == Docstring(
        short_description='This is the first line of the first paragraph',
        blank_after_short_description='\n',
        blank_after_long_description=False,
        long_description='This is the second paragraph'
    )

    c = """
        :param int param1: First parameter
        :param str param2: Second parameter
    """

# Generated at 2022-06-23 17:09:45.712912
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Section are the headers for docstring
    section_types = ["Args", "Arguments", "Parameters", "Return", "Raise", "Yield", "Yields", "Except", "Exceptions",
                     "Attributes", "Returns", "Example", "Examples"]
    parser = GoogleParser(sections=section_types)

# Generated at 2022-06-23 17:09:57.170602
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest
    # Test 1: No text
    assert GoogleParser().parse(None) == parse(None)
    # Test 2: One section, singular
    assert GoogleParser().parse('A docstring\n') == parse('A docstring\n')
    # Test 2: One section, multiple
    assert GoogleParser().parse('Args:\n    foo\n') == parse('Args:\n    foo\n')
    # Test 3: One section, multiple with description
    assert GoogleParser().parse('Args:\n    foo:\n        description\n') == parse('Args:\n    foo:\n        description\n')
    # Test 4: One section, singular and multiple
    assert GoogleParser().parse('Returns:\n    foo\n') == parse('Returns:\n    foo\n')
    # Test 5: Multiple sections, singular and multiple
    assert Google

# Generated at 2022-06-23 17:10:01.220787
# Unit test for function parse
def test_parse():
    from . import google

# Generated at 2022-06-23 17:10:02.485309
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass

# Generated at 2022-06-23 17:10:06.345683
# Unit test for constructor of class Section
def test_Section():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    assert sections[0].title == "Arguments"
    assert sections[0].key == "param"
    assert sections[0].type == SectionType.MULTIPLE
    assert sections[0]._asdict() == {'title': "Arguments", 'key': "param", 'type': 0}

# Generated at 2022-06-23 17:10:08.913906
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key", SectionType.MULTIPLE)
    print(section[0])
    print(section[1])
    print(section[2])


# Generated at 2022-06-23 17:10:20.513293
# Unit test for function parse
def test_parse():
    """Test that parsing works correctly."""

    assert parse("") == Docstring()

    # One line short description
    short_desc = "Short description."
    assert parse(short_desc) == Docstring(
        short_description=short_desc, blank_after_short_description=False
    )

    # One line short description followed by new line
    short_desc = "Short description."
    assert parse(short_desc + "\n") == Docstring(
        short_description=short_desc, blank_after_short_description=True
    )

    # Two line short description
    short_desc_1 = "Short description."
    short_desc_2 = "even shorter."

# Generated at 2022-06-23 17:10:22.901695
# Unit test for constructor of class Section
def test_Section():
    s = Section("Example", "examples", SectionType.SINGULAR)
    assert s.title == "Example"
    assert s.key == "examples"
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:10:33.660331
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # test1
    # When sections is None
    test1 = GoogleParser()

# Generated at 2022-06-23 17:10:37.187889
# Unit test for constructor of class Section
def test_Section():
    section = Section("Example", "example", 1)
    assert(section.title == "Example")
    assert(section.key == "example")
    assert(section.type == 1)

# Generated at 2022-06-23 17:10:45.076371
# Unit test for function parse
def test_parse():
    msg = 'This is a test'
    assert parse(msg).short_description == msg
    assert parse(msg).long_description is None
    assert not parse(msg).meta
    assert parse(msg).blank_after_long_description
    assert parse(msg).blank_after_short_description

    msg = 'This is a test\n  with more \n    text'
    assert parse(msg).long_description == msg
    assert not parse(msg).short_description
    assert not parse(msg).meta
    assert parse(msg).blank_after_long_description
    assert parse(msg).blank_after_short_description

    msg = 'This is a test:\n  with more \n    text'
    assert parse(msg).long_description == 'with more \n    text'

# Generated at 2022-06-23 17:10:55.821767
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-23 17:11:00.932815
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    docstring = (
        """
        Test function.

        Args:
            arg1: test argument 1
            arg2: test argument 2

        Raises:
            TestException

        Returns:
            Test return value
        """
    )
    result = g.parse(docstring)
    assert result.short_description == "Test function."
    assert len(result.meta) == 4


# Generated at 2022-06-23 17:11:05.897939
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.titles_re.pattern == r"^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields)[ \t\r\f\v]*$"

# Generated at 2022-06-23 17:11:15.771422
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()

    gp.add_section(Section("Section1", "sect", SectionType.SINGULAR))
    gp.add_section(Section("Section2", "sect", SectionType.MULTIPLE))
    gp.add_section(Section("Section3", "sect", SectionType.MULTIPLE))

    assert gp.sections == {
        "Section1": Section("Section1", "sect", SectionType.SINGULAR),
        "Section2": Section("Section2", "sect", SectionType.MULTIPLE),
        "Section3": Section("Section3", "sect", SectionType.MULTIPLE),
    }


# Generated at 2022-06-23 17:11:26.068587
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser(title_colon=False)

# Generated at 2022-06-23 17:11:30.612644
# Unit test for constructor of class Section
def test_Section():
    sect = Section(title="Arguments", key="param", type=SectionType.MULTIPLE)
    assert sect.title == "Arguments"
    assert sect.key == "param"
    assert sect.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:11:41.918007
# Unit test for function parse
def test_parse():
    text = """
    Args:
        param1 (str): The first parameter.
        param2 (str): The second parameter.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Raises:
        KeyError: Raises an exception.

    """
    docstring = parse(text)
    print(docstring)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 6
    assert str(docstring.meta[0]) == "param1 (str): The first parameter."
    assert str(docstring.meta[1]) == "param2 (str): The second parameter."

# Generated at 2022-06-23 17:11:43.164591
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser()
    assert isinstance(g, GoogleParser)



# Generated at 2022-06-23 17:11:55.513339
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    assert gp.parse("") == Docstring(), "GoogleParser parsed an empty line"
    assert gp.parse("\n") == Docstring(), "GoogleParser parsed a newline"
    assert gp.parse("\n\n") == Docstring(), "GoogleParser parsed two newline"
    assert gp.parse("\n\n\n") == Docstring(), "GoogleParser parsed three newline"
    assert gp.parse("\ntest\n\n") == Docstring(
        short_description="test",
        long_description="",
        blank_after_short_description=True,
        blank_after_long_description=True,
    ), "GoogleParser parsed a docstring with one line"


# Generated at 2022-06-23 17:12:08.386529
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments","a",SectionType.MULTIPLE)
    # Test Section Type
    assert s.title == "Arguments"
    assert s.key == "a"
    assert s.type == SectionType.MULTIPLE

testSection = Section("Arguments", "a",SectionType.MULTIPLE)
testSection2 = Section("Args", "b",SectionType.MULTIPLE)
testSection3 = Section("Parameters", "c",SectionType.MULTIPLE)
testSection4 = Section("Params", "d",SectionType.MULTIPLE)
testSection5 = Section("Raises", "e",SectionType.MULTIPLE)
testSection6 = Section("Exceptions", "f",SectionType.MULTIPLE)

# Generated at 2022-06-23 17:12:13.112325
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    print("This is for test method add_section of class GoogleParser")
    parser = GoogleParser()
    parser.add_section(Section("Sections","test", SectionType.SINGULAR))
    sections = parser.sections.keys()
    assert "Sections" in sections
    assert "test" in sections
    assert "Example" in sections


# Generated at 2022-06-23 17:12:18.637384
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section = Section("Example", "example", SectionType.SINGULAR)
    parser = GoogleParser()
    parser.add_section(section)
    assert (
        parser.sections == DEFAULT_SECTIONS + [section]
    ), "GoogleParser.add_section() is not working"



# Generated at 2022-06-23 17:12:27.672898
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test 1
    parser = GoogleParser()
    section = Section(title = "See Also", key = "see_also", type = SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(section)
    # Test 2
    parser = GoogleParser()
    section = Section(title = "See Also", key = "see_also", type = SectionType.SINGULAR)
    parser.add_section(section)
    # Test 3
    parser = GoogleParser()
    section = Section(title = "See Also", key = "see_also", type = SectionType.MULTIPLE)
    parser.add_section(section)
    # Test 4
    parser = GoogleParser()
    section = Section(title = "Arguments", key = "see_also", type = SectionType.MULTIPLE)


# Generated at 2022-06-23 17:12:30.891101
# Unit test for constructor of class Section
def test_Section():
    section = Section("title","key",0)
    assert isinstance(section.title, str)
    assert section.key == "key"
    assert isinstance(section.type, int)

# Generated at 2022-06-23 17:12:34.157049
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Params","param",SectionType.MULTIPLE)
    assert sec.title == "Params"
    assert sec.key == "param"
    assert sec.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:12:38.589961
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    t = Section("Test", "test", SectionType.MULTIPLE)
    p.add_section(t)
    assert p.sections[t.title] == t



# Generated at 2022-06-23 17:12:42.707097
# Unit test for constructor of class Section
def test_Section():
    section = Section("Args", "param", SectionType.MULTIPLE)
    assert section.title == "Args"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-23 17:12:51.645849
# Unit test for function parse
def test_parse():
    docstring = """
    A short summary.

    A longer description which can span multiple lines.

    Args:
        param1 (int): Description of `param1`
        param2 (:obj:`str`, optional): Description of `param2`

    Returns:
        bool: Description of return value
    """


# Generated at 2022-06-23 17:12:58.694626
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Examples", "examples", SectionType.SINGULAR),
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    gp = GoogleParser(sections=sections, title_colon=False)
    gp._setup()
    assert gp.titles_re.pattern == "^(Examples|Arguments|Returns)[ \t\r\f\v]*$"



# Generated at 2022-06-23 17:13:02.262491
# Unit test for constructor of class Section
def test_Section():
    section = Section("a", "b", 0)
    assert section.title == "a"
    assert section.key == "b"
    assert section.type == 0


# Generated at 2022-06-23 17:13:10.740116
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  test_text = """
  Parameters:
      param1: Parameter 1.
      param2 (str): Parameter 2.
      param3 (str, optional): Parameter 3. Default value: 'param3 value'.
      param4 (str): Parameter 4.
        Multiline description.
  Returns:
      List of dictionaries containing API call result as per description
      above and metadata.
      [{"result": "test_result", "metadata": "test_metadata"}]
  """

# Generated at 2022-06-23 17:13:12.287104
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser(title_colon=False)


# Generated at 2022-06-23 17:13:16.963299
# Unit test for constructor of class Section
def test_Section():
    print("Test Section")
    temp = Section("Examples", "examples", 1)
    print(temp.title)
    print(temp.key)
    print(temp.type)
    print(temp)
    print()


# Generated at 2022-06-23 17:13:19.158599
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g_parser = GoogleParser()
    print(g_parser.sections)
    section = Section("MySection", "my_sect", SectionType.MULTIPLE)
    g_parser.add_section(section)
    print(g_parser.sections)
    return True

# Generated at 2022-06-23 17:13:29.356591
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    #
    # Doctest: short description
    #
    docstring = 'Short description'
    doc = parser.parse(docstring)
    assert doc.short_description == 'Short description'
    assert len(doc.meta) == 0

    #
    # Doctest: long description
    #
    docstring = 'Short description\n\nLong description'
    doc = parser.parse(docstring)
    assert doc.short_description == 'Short description'
    assert len(doc.meta) == 0
    assert doc.long_description == 'Long description'
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    #
    # Doctest: empty description
    #
    docstring = ''
    doc = parser.parse(docstring)

# Generated at 2022-06-23 17:13:40.284399
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring, DocstringMeta, DocstringParam
    from .common import DocstringRaises, DocstringReturns
    #case 1
    parser = GoogleParser()
    text = """
    Docstring
    ---------
    Add two numbers together.
    """
    assert parser.parse(text) == Docstring(
        short_description="Add two numbers together.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[]
    )
    #case 2
    parser = GoogleParser()
    text = """
    Docstring
    ---------
    Add two numbers together.
    Returns
    -------
    The sum.
    """

# Generated at 2022-06-23 17:13:51.947071
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test: no error 
    parser = GoogleParser()
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Args1", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Args2", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Args3", "param", SectionType.MULTIPLE))

    # Test: Param ValueError
    parser = GoogleParser()
    try:
        parser.add_section(Section("Args", "param", "multipart"))
        assert False
    except ValueError:
        assert True

test_GoogleParser_add_section()



# Generated at 2022-06-23 17:13:53.164563
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()


# Generated at 2022-06-23 17:14:05.366151
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()

# Generated at 2022-06-23 17:14:13.530658
# Unit test for function parse
def test_parse():
    """A unit test for function parse"""
    from .common import PARAM_KEYWORDS, RAISES_KEYWORDS, RETURNS_KEYWORDS
    from .common import DocstringParam, DocstringRaises, DocstringReturns
    from .common import Docstring

    text = """Single line short description

    Long description.

    Args:
      name: The name of the object.
      other_arg: Another argument.

    Args:
      age: The age of the object.
    """
    actual = parse(text)

    ret = Docstring()
    ret.short_description = "Single line short description"
    ret.blank_after_short_description = True
    ret.long_description = "Long description."
    ret.blank_after_long_description = False

# Generated at 2022-06-23 17:14:19.537373
# Unit test for function parse
def test_parse():
    def foo():
        """Short docstring.
        Longer docstring.

        Raises:
            ValueError: something bad
        """
        pass

    docstring = parse(foo.__doc__)

    assert docstring.short_description == "Short docstring."
    assert docstring.long_description == "Longer docstring."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert isinstance(docstring.meta[0], DocstringRaises)
    assert docstring.meta[0].arg_name == "ValueError"
    assert docstring.meta[0].description == "something bad"
    assert docstring.meta[0].type_name is None



# Generated at 2022-06-23 17:14:29.885915
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    docstring = """
        Short description.

        Long description.

        Args:
            arg1 (str): Description of arg1.
            arg2 (str): Description of arg2.

        Returns:
            str: Description of return value.
            str: Description of another return value."""
    google_parser = GoogleParser()
    docstring_obj = google_parser.parse(docstring)
    assert docstring_obj.short_description == "Short description."
    assert docstring_obj.long_description == "Long description."
    assert docstring_obj.meta[0].description == "Description of return value."
    assert docstring_obj.meta[1].description == "Description of another return value."
    assert docstring_obj.meta[0].args[0] == "returns"
   

# Generated at 2022-06-23 17:14:32.795072
# Unit test for function parse
def test_parse():
    text = """Summary line.

    Extended description of function.

    No args.

    Raises:
        ValueError: If `param1` is equal to `param2`.

    Returns:
        int: The return value.
    """

    parse(text)

# Generated at 2022-06-23 17:14:45.818696
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstring = google_parser.parse('''google_parser:
    Parse the Google-style docstring into its components.

    Returns:
        Returns parsed docstring
    ''')

    #test short description
    assert docstring.short_description == 'google_parser'

    #test long description
    assert docstring.long_description == 'Parse the Google-style docstring into its components.\n'

    #test blank_after_short_description
    assert docstring.blank_after_short_description == True

    #test blank_after_long_description
    assert docstring.blank_after_long_description == False

    #test meta
    assert len(docstring.meta) == 1
    assert isinstance(docstring.meta[0], DocstringReturns)

# Generated at 2022-06-23 17:14:54.549451
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = '''A short summary.
    
    A long description.

    Args:
        arg1: description 1
        arg2: description 2

    Yields:
        description 3
    '''
    docstring = GoogleParser().parse(doc)
    print(docstring.short_description)
    print(docstring.long_description)
    for meta in docstring.meta:
        print(meta.key, meta.description)


if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-23 17:15:01.673113
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("SOMETHING", "something", SectionType.SINGULAR))
    docstring = """SOMETHING:
        for some_value in example.

    SOMETHING: ..........
        for some_value in example.
        Yes"""
    result = parser.parse(docstring)
    assert result.meta[0].args == ['something']
    assert result.meta[0].description == 'for some_value in example.'
    assert result.meta[1].args == ['something', '..........']
    assert result.meta[1].description == 'for some_value in example.\nYes'

# Generated at 2022-06-23 17:15:12.282688
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-23 17:15:19.808966
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) == Section("Arguments", "param", SectionType.MULTIPLE)
    assert Section("Arguments", "param", SectionType.MULTIPLE) != Section("Argumen", "param", SectionType.MULTIPLE)
    assert Section("Arguments", "param", SectionType.MULTIPLE) != Section("Arguments", "para", SectionType.MULTIPLE)
    return True


# Generated at 2022-06-23 17:15:23.382142
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    new_section = Section("Test", "test", SectionType.SINGULAR)
    google_parser.add_section(new_section)
    assert google_parser.sections["Test"] == new_section

# Generated at 2022-06-23 17:15:31.203214
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
        Suateam is an awesome team
        
        Args:
            name (str): The name of member
            num (int): The number of member
        
        Raises:
            ValueError: if name cannot be found
        
        Returns:
            Suateam: The suateam which is found by name
    """
    parser = GoogleParser()
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    result = parser.parse(text)

    assert result.short_description == "Suateam is an awesome team"
    assert not result.blank_after_short_description
    assert result.long_description == None
    assert result.blank_after_long_description

# Generated at 2022-06-23 17:15:34.755957
# Unit test for constructor of class Section
def test_Section():
    sec = Section("title", "key", SectionType.SINGULAR)
    assert sec.title == "title" and sec.key == "key" and sec.type == SectionType.SINGULAR


# Generated at 2022-06-23 17:15:45.442674
# Unit test for function parse
def test_parse():
    #from .common import Docstring
    from . import google_parser

    class TestCase(namedtuple("TestCase", ["text", "result"])):
        pass


# Generated at 2022-06-23 17:15:58.837070
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring, DocstringMeta, DocstringRaises

    text = """
        This is a function.

        Parameters
        ----------
        arg1 : str
            Description of arg1.
        arg2 : str
            Description of arg2.

        Raises
        ------
        ValueError
            If something goes wrong.
        """

    ds = GoogleParser().parse(text)
