

# Generated at 2022-06-21 11:44:57.482632
# Unit test for function parse
def test_parse():
    google_str = """
            Example Google-style docstring.

            This is the summary line.

            It is a multi-line summary.

            Args:
                module_path: Path to module.

                module_name: Name of module.

            Returns:
                A variable with None value.
            """
    assert (parse(google_str).short_description == 'Example Google-style docstring.')
    assert (parse(google_str).long_description == 'This is the summary line.\n\nIt is a multi-line summary.')
    assert (parse(google_str).blank_after_short_description == True)
    assert (parse(google_str).blank_after_long_description == True)
    assert (
        parse(google_str).meta[0].description == 'Path to module.'
    )

# Generated at 2022-06-21 11:45:02.349940
# Unit test for function parse
def test_parse():
    assert(parse("") == Docstring())
    assert(parse("Hello, world") == Docstring(short_description="Hello, world"))
    assert(parse("Hello, world\ngoodbye") == Docstring(short_description="Hello, world", long_description="goodbye"))
    assert(parse("Hello, world\n\ngoodbye") == Docstring(short_description="Hello, world", long_description="goodbye"))
    assert(parse("Hello, world\ngoodbye\n\n") == Docstring(short_description="Hello, world", long_description="goodbye"))
    assert(parse("Hello, world\n\ngoodbye\n\n") == Docstring(short_description="Hello, world", long_description="goodbye"))

# Generated at 2022-06-21 11:45:14.294177
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ds = """Summary line.

Description: extended summary

long

params:
    param1: The first parameter.
    param2: The second parameter.
Yields:
    Yields the results.
    Yields more results.
Raises:
    ValueError: An exception.
    TypeError: An exception.
"""

# Generated at 2022-06-21 11:45:22.666254
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    from .common import DocstringMeta, DocstringRaises, DocstringReturns
    from .common import SectionType
    from .common import RAISES_KEYWORDS, RETURNS_KEYWORDS
    new_section = Section("Tests", "test", SectionType.MULTIPLE)
    test_docstring = GoogleParser().add_section(new_section)
    # test_docstring.parse('Tests:\n  test1: test1_description\n  test2: test2_description')
    assert test_docstring.parse('Tests:\n  test1: test1_description\n  test2: test2_description').meta == [DocstringMeta(args=['test', 'test1'], description='test1_description'), DocstringMeta(args=['test', 'test2'], description='test2_description')]


# Generated at 2022-06-21 11:45:28.130693
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #assert parse("foo\nbar\n\nbaz") == Docstring(short_description="foo",
    #             long_description="bar", meta=[])
    #assert parse("\nfoo\nbar\n\nbaz") == Docstring(short_description="foo",
    #             long_description="bar", meta=[],
    #             blank_after_short_description=True)
    assert 1 == 1

# Generated at 2022-06-21 11:45:38.668132
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p=GoogleParser()
    #test get a section
    assert isinstance(p.sections["Examples"],Section)
    #test get all sections
    assert isinstance(p.sections, dict)
    #test get the regex
    assert isinstance(p.titles_re,re.Pattern)
    #test add_section
    p.add_section(Section("Args","param",SectionType.MULTIPLE))
    assert isinstance(p.sections["Args"],Section)
    assert isinstance(p.sections, dict)
    #add_section again
    old_len=len(p.sections)
    p.add_section(Section("Args","param",SectionType.MULTIPLE))
    new_len=len(p.sections)
    assert new_len==old_len


#unit test for _build_meta


# Generated at 2022-06-21 11:45:44.263494
# Unit test for constructor of class Section

# Generated at 2022-06-21 11:45:44.985234
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser()


# Generated at 2022-06-21 11:45:57.183023
# Unit test for function parse

# Generated at 2022-06-21 11:46:03.422248
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().title_colon
    assert GoogleParser(title_colon=False).title_colon
    assert not GoogleParser(title_colon=True).title_colon

    with pytest.raises(TypeError):
        GoogleParser(sections="invalid")
    with pytest.raises(ValueError):
        GoogleParser(title_colon="invalid")

# Generated at 2022-06-21 11:46:22.433330
# Unit test for function parse
def test_parse():
    text = """
        Test function

        :param appname: The name of the app.
        :param libs: Libraries to link against.
        :type libs: list
        :param verbose: Print verbose messages.
        :raises RuntimeError: when a negative number is provided
        :returns: dict of file names
    """
    doc = parse(text)
    print(doc)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:46:23.808992
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleParser = GoogleParser()


# Generated at 2022-06-21 11:46:24.373645
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-21 11:46:32.171227
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    doc = GoogleParser()
    doc.add_section(Section("Takes", "param", SectionType.MULTIPLE))
    doc.add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    doc.add_section(Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE))
    assert doc.parse("""
    :param iterable: The iterable to be sorted.
    :param key: Optional key function by which the iterable is sorted.
    :raises TypeError: The object is not iterable.
    :return: An new sorted list from the items in iterable.
    """)

# Generated at 2022-06-21 11:46:38.734894
# Unit test for constructor of class Section
def test_Section():
    sec1 = Section("Title1", "key1", SectionType.SINGULAR)
    assert sec1.title == "Title1"
    assert sec1.key == "key1"
    assert sec1.type == SectionType.SINGULAR

    sec2 = Section("Title2", "key2", SectionType.MULTIPLE)
    assert sec2.title == "Title2"
    assert sec2.key == "key2"
    assert sec2.type == SectionType.MULTIPLE

    sec3 = Section("Title3", "key3", SectionType.SINGULAR_OR_MULTIPLE)
    assert sec3.title == "Title3"
    assert sec3.key == "key3"
    assert sec3.type == SectionType.SINGULAR_OR_MULTIPLE


# Generated at 2022-06-21 11:46:42.515192
# Unit test for constructor of class Section
def test_Section():
    title = "title123"
    key = "key123"
    type = SectionType.MULTIPLE

    # Correct attributes
    s = Section(title, key, type)
    assert s.title == title
    assert s.key == key
    assert s.type == type



# Generated at 2022-06-21 11:46:55.439324
# Unit test for function parse
def test_parse():
    def f():
        """
        Short summary.

        Longer description.

        Args:
            arg1: Description of arg1.
            arg2 (int): Description of arg2.
            arg3 (int, optional): Description of arg3. Defaults to 100.

        Returns:
            Description of return value.
            Return type is str.
        """
        pass

    docstring = parse(f.__doc__)
    assert docstring.short_description == "Short summary."
    assert docstring.long_description == "Longer description."
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3

    # Parameters
    p1 = docstring.meta[0]

# Generated at 2022-06-21 11:46:57.336835
# Unit test for constructor of class Section
def test_Section():
    new_section = Section("Title", "title", SectionType.SINGULAR)
    assert(new_section.title == "Title")
    assert(new_section.key == "title")
    assert(new_section.type == SectionType.SINGULAR)


# Generated at 2022-06-21 11:47:04.196636
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("derpy", "derp", 0)
    new_parser = parser.add_section(section)

    assert len(new_parser.sections) == 13
    assert new_parser.sections["derpy"].title == "derpy"
    assert new_parser.sections["derpy"].key == "derp"
    assert new_parser.sections["derpy"].type == 0



# Generated at 2022-06-21 11:47:12.008241
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section_undertest = Section("test", "test", SectionType.SINGULAR)
    # If we add a section, we can parse it
    my_parser = GoogleParser()
    my_parser.add_section(section_undertest)
    my_docstring = my_parser.parse("test:\n  This is a test")
    assert hasattr(my_docstring, "test")
    # But not if we don't
    my_parser = GoogleParser()
    my_docstring = my_parser.parse("test:\n  This is a test")
    assert not hasattr(my_docstring, "test")


# Generated at 2022-06-21 11:47:33.330086
# Unit test for constructor of class Section
def test_Section():
    Section_default = Section("section_title", "section_key", SectionType.SINGULAR)
    assert Section_default.title == "section_title"
    assert Section_default.key == "section_key"
    assert Section_default.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:47:41.223375
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:47:51.357567
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = DEFAULT_SECTIONS
    text = """
    Hello World

    Args:
        a: it is a

    Attributes:
        b: it is b

    Example:
        This is example
    """
    assert len(GoogleParser(sections).sections) == len(sections)
    assert len(GoogleParser(sections, title_colon=False).sections) == len(sections)

    # Section 对象
    new_section = Section("hello", "world", SectionType.MULTIPLE)
    # GoogleParser 对象
    parser = GoogleParser(sections, title_colon=False)
    assert parser.title_colon == False
    assert len(parser.sections) == len(sections)
    assert new_section.title not in parser.sections

    # GoogleParser 对

# Generated at 2022-06-21 11:47:56.104639
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser(title_colon=False).parse("Hello\n") == Docstring(
        short_description="Hello",
        long_description=None,
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )



# Generated at 2022-06-21 11:47:59.769424
# Unit test for constructor of class Section
def test_Section():
    s = Section("a", "b", SectionType.MULTIPLE)
    assert s.title == "a"
    assert s.key == "b"
    assert s.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:48:07.556656
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""Just a test for method parse of class GoogleParser""")

    assert docstring.short_description == "Just a test for method parse of class GoogleParser"
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == None
    assert docstring.blank_after_short_description == None

    assert len(docstring.meta) == 0


# Generated at 2022-06-21 11:48:16.832662
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:48:26.496111
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring
    from .google import GoogleParser
    
    text = """
        Args:
            x: The number x.

            y: The number y.

        Returns:
            The sum of x and y.

        Raises:
            TypeError: If x or y are not integers.
    """
    gp = GoogleParser()
    parsed = gp.parse(text)

# Generated at 2022-06-21 11:48:34.535924
# Unit test for function parse
def test_parse():
    docstring = """This is a description.

    Here is more description, even more, and even more.

    Args:
      foo (:obj:`int`): Parameter documentation. Defaults to 3.
      bar (:obj:`str`): Parameter documentation. Defaults to :obj:`None`.

    Returns:
      obj: Return value documentation.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "This is a description."
    assert parsed.blank_after_short_description == True
    assert parsed.long_description == "Here is more description, even more, and even more."
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].key == "params"
    assert parsed.meta[0].arg_name == "foo"

# Generated at 2022-06-21 11:48:42.078013
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    
    section = Section("Test Section", "test", SectionType.MULTIPLE)
    parser.add_section(section)
    assert len(parser.sections) == len(DEFAULT_SECTIONS) + 1
    assert parser.sections == { section.title: section, **{s.title: s for s in DEFAULT_SECTIONS} }

    parser = GoogleParser()
    
    section = Section("Test Section", "test", SectionType.SINGULAR)
    parser.add_section(section)
    assert len(parser.sections) == len(DEFAULT_SECTIONS) + 1
    assert parser.sections == { section.title: section, **{s.title: s for s in DEFAULT_SECTIONS} }

    parser = GoogleParser()
    

# Generated at 2022-06-21 11:49:05.571601
# Unit test for function parse
def test_parse():
    def foo():
        """Test function for docstring parsing.

        This function does nothing.

        :param arg1: the first argument (Not meaningful)
        :param arg2: the second argument. This is the description
        of the second argument.
        :type arg2: int
        :returns: this function does not return anything.

        Examples
        -------
        >>> foo(1, 2)
        >>> foo(3, 4)

        Notes
        -----
        Once upon a time, there was a bar.

        """
        pass

    d = parse(foo.__doc__)
    assert d.short_description == "Test function for docstring parsing."

# Generated at 2022-06-21 11:49:10.833606
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert gp.title_colon is True
    assert len(gp.sections) is len(DEFAULT_SECTIONS)
    assert set(gp.sections.keys()) == set(DEFAULT_SECTIONS)

# Unit test of function add_section

# Generated at 2022-06-21 11:49:14.728875
# Unit test for constructor of class Section
def test_Section():
    section = Section("Title", "key", SectionType.SINGULAR)
    assert section.title == "Title"
    assert section.key == "key"
    assert section.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:49:25.831083
# Unit test for function parse
def test_parse():
    assert parse("ABC") == Docstring(
        short_description="ABC",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("ABC\n\nLong text.") == Docstring(
        short_description="ABC",
        long_description="Long text.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("ABC\nLong text.") == Docstring(
        short_description="ABC",
        long_description="Long text.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-21 11:49:34.111459
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # TEST 1
    # Check if default sections are included
    parser1 = GoogleParser()
    assert len(parser1.sections) == len(DEFAULT_SECTIONS)
    assert set(parser1.sections.keys()) == set(
        section.title for section in DEFAULT_SECTIONS
    )
    # TEST 2
    # Check if custom sections are included

# Generated at 2022-06-21 11:49:45.901999
# Unit test for function parse
def test_parse():
    docstring = '''
    Parameters
    ----------
    a : {array-like}, shape (n, n)
        Array to be decomposed.
    ainv : {None, array-like}, optional
        Array to store the inverse of `a`. If supplied, must have the same shape as `a`.
    Returns
    -------
    p, L, U : {ndarray, matrix}, shape (n, n)
        The decomposition.
    Examples
    --------
    >>> A = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    >>> P, L, U = lu(A)
    >>> P
    >>> L
    >>> U
    '''
    res = parse(docstring)
    print(res)

# Generated at 2022-06-21 11:49:51.727782
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Test", "test", SectionType.MULTIPLE))

    assert(gp.sections['Test'].title == "Test")
    assert(gp.sections['Test'].key == "test")
    assert(gp.sections['Test'].type == SectionType.MULTIPLE)

# Generated at 2022-06-21 11:49:55.669353
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:50:03.092355
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

    # Test adding new section
    test_section = Section("Test", "test", 0)
    parser.add_section(test_section)
    assert parser.sections["Test"] == test_section

    # Test adding existing section
    test_section2 = Section("Test", "test2", 1)
    parser.add_section(test_section2)
    assert parser.sections["Test"] == test_section2


# Generated at 2022-06-21 11:50:13.005245
# Unit test for function parse
def test_parse():
    
    # No docstring
    parser = GoogleParser()
    assert parser.parse("") == Docstring()

    # Description only
    assert parser.parse('"A docstring"') == Docstring(
        short_description="A docstring", long_description=None, meta=[]
    )

    # Description with blank line
    assert parser.parse('"A docstring"\n\n') == Docstring(
        short_description="A docstring", long_description=None, meta=[]
    )

    # Description with blank after short

# Generated at 2022-06-21 11:50:59.851229
# Unit test for function parse
def test_parse():
    text = \
    """
    This is a test function.

    Args:
        a (float): First argument
        b (float): Second argument

    Returns:
        float: The sum.

    Raises:
        ValueError: If a is zero.

    Examples:
        >>> test_parse(3, 4)
        7

    """
    expected = \
    """
    This is a test function.

    Args:
        a (float): First argument
        b (float): Second argument

    Returns:
        float: The sum.

    Raises:
        ValueError: If a is zero.

    Examples:
        >>> test_parse(3, 4)
        7

    """
    docstring = parse(text)
    assert expected == repr(docstring)

# Generated at 2022-06-21 11:51:02.985617
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert isinstance(parser, GoogleParser)
    assert len(parser.sections) == 14
    #assert parser.title_colon == True
    #assert parser.titles_re == re.compile(...)



# Generated at 2022-06-21 11:51:10.062800
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(DEFAULT_SECTIONS[0])
    assert parser.sections[DEFAULT_SECTIONS[0].title] == DEFAULT_SECTIONS[0]
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    assert parser.sections[DEFAULT_SECTIONS[0].title] == DEFAULT_SECTIONS[0]

# Generated at 2022-06-21 11:51:20.068296
# Unit test for function parse
def test_parse():
    test_doc_string = """
        Minimal example of a google style docstring.

        Args:
            param1: The first parameter.
            param2: The second parameter.

        Returns:
            True if successful, False otherwise.

        Raises:
            AttributeError, KeyError
    """
    docstring = parse(test_doc_string)
    assert docstring.short_description == "Minimal example of a google style docstring."
    assert docstring.long_description == "The second parameter."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    section = docstring.meta[0]
    assert section.args[0] == "param"
    assert section.args[1] == "param1: The first parameter."
    assert section.description

# Generated at 2022-06-21 11:51:23.885645
# Unit test for function parse
def test_parse():
    doc = """\
    This is a docstring.

    Some more information.

    Args:
        x:    a number
        y ([int]):    a number

    Returns:
        x:    a number
    """
    print(parse(doc))



# Generated at 2022-06-21 11:51:33.131674
# Unit test for function parse
def test_parse():
    desc = """
    This is a docstring.

    Args:
        arg1 (int): Description of arg1. Defaults to 0.
        arg2 (float, optional): Description of arg2. Defaults to 1.
        arg3 (bool): Description of arg3. Defaults to False.

    Returns:
        object: Description of return.
    """

# Generated at 2022-06-21 11:51:36.438436
# Unit test for constructor of class Section
def test_Section():
    test_section = SectionType('SINGULAR')
    assert test_section == 0
    assert test_section.name == 'SINGULAR'
    assert test_section.value == 0


# Generated at 2022-06-21 11:51:48.539668
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test_GoogleParser_parse_internal(text, short_description, long_description, meta, expected):
        def test_GoogleParser_parse_internal_internal(expected_short_description, expected_long_description, expected_meta, expected_parameters):
            print("short_description     : " + str(expected_short_description))
            print("long_description      : " + str(expected_long_description))
            print("meta                  : " + str(expected_meta))
            print("parameters            : " + str(expected_parameters))
            assert expected_short_description == actual_short_description
            assert expected_long_description == actual_long_description
            assert expected_meta == actual_meta
            assert expected_parameters == actual_parameters

        actual = GoogleParser().parse(text)

# Generated at 2022-06-21 11:51:50.409002
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googlestyle = GoogleParser()
    assert isinstance(googlestyle.sections, dict)


# Generated at 2022-06-21 11:51:53.438267
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    test_section = Section("Current Section:", "current_section", SectionType.SINGULAR)

    parser = GoogleParser()
    parser.add_section(test_section)

    assert parser.sections["Current Section:"] == test_section


# Generated at 2022-06-21 11:52:25.566327
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    custom_sections = [
        Section("JSON", "json", SectionType.MULTIPLE),
        Section("TEST", "test", SectionType.SINGULAR_OR_MULTIPLE),
        Section("OTHER", "other", SectionType.SINGULAR),
    ]
    sections = DEFAULT_SECTIONS + custom_sections
    parser = GoogleParser(sections)
    parser.add_section(Section("Replace", "replace", SectionType.SINGULAR_OR_MULTIPLE))
    sections = sections[:-1] + [Section("Replace", "replace", SectionType.SINGULAR_OR_MULTIPLE)]
    assert parser.sections == {s.title: s for s in sections}

# Generated at 2022-06-21 11:52:32.634923
# Unit test for function parse
def test_parse():
    str = '''
    This is short description.

    This is long description. It can have multiple lines.

    Arguments:
        xxx(int): xxx

    Returns:
        xxx(int): xxx
    '''

    d = parse(str)
    print(d)


if __name__ == "__main__":
    test_parse()
    print('finish')

# Generated at 2022-06-21 11:52:41.346332
# Unit test for function parse
def test_parse():
    '''Docstring for function parse.

    :param arg1: The first argument.
    :type arg1: str
    :param arg2: The second argument. (default: True)
    :type arg2: bool
    :param arg3: The third argument.
    :type arg3: int
    :param arg4: The forth argument.
    :type arg4: None
    :returns:  str -- the return value

    '''
    ret = parse(test_parse.__doc__)
    print(ret)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:52:50.823845
# Unit test for function parse
def test_parse():
    docstring = """
    This is a sample text.

    This is a long sample text.
    This is the second line of long sample text

    Args:
        arg1 (int, optional): The first parameter. Defaults to 42.

            Some details about the first parameter.

        arg2 (str): The second parameter.
    """

# Generated at 2022-06-21 11:52:59.714147
# Unit test for function parse
def test_parse():
    def f():
        """
        Short description.

        Long description.
        """

    doc = parse(inspect.getdoc(f))
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."

    def g():
        """Short description."""

    doc = parse(inspect.getdoc(g))
    assert doc.short_description == "Short description."

    def h():
        """
        Short description.

        :type x: int
        """

    doc = parse(inspect.getdoc(h))
    assert doc.short_description == "Short description."
    assert doc.meta[0].arg_name == "x"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].description is None
    assert doc.meta

# Generated at 2022-06-21 11:53:10.877778
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import unittest

    # GoogleParser.parse
    class TestGoogleParser_parse(unittest.TestCase):
        def test_empty(self):
            self.assertEqual(GoogleParser().parse(""), Docstring())

        def test_empty_with_indent(self):
            self.assertEqual(GoogleParser().parse("  "), Docstring())

        def test_single_line(self):
            self.assertEqual(
                GoogleParser().parse("Hello world!"),
                Docstring(
                    short_description="Hello world!",
                    blank_after_short_description=True,
                ),
            )


# Generated at 2022-06-21 11:53:23.969021
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gParser = GoogleParser()
    if "self" in gParser.sections.values():
        print('GoogleParser.parse: self is a section')
        return False
    if "short_description" in gParser.sections.values():
        print('GoogleParser.parse: short_description is a section')
        return False
    if "long_description" in gParser.sections.values():
        print('GoogleParser.parse: long_description is a section')
        return False
    if not "Arguments" in gParser.sections.values():
        print('GoogleParser.parse: Arguments is not in sections')
        return False
    if not "Args" in gParser.sections.values():
        print('GoogleParser.parse: Args is not in sections')
        return False

# Generated at 2022-06-21 11:53:28.257479
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Example function with types documented in the docstring.

    :param int foo: The first parameter.
    :param bar: The second parameter.
    :param bool baz: The third parameter.
    :raises ValueError: If `foo` is negative.
    """
    assert len(GoogleParser().parse(text).meta) == 4


# Generated at 2022-06-21 11:53:35.803542
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = "A short desc\n\n"
    docstr += "A longer desc\n"
    docstr += "with multiple lines.\n\n"
    docstr += "Args:\n"
    docstr += "  arg1: Name of the first argument.\n"
    docstr += "  arg2 (int): Desc of the second arg. Defaults to 42.\n"
    docstr += "  arg3 (str, optional): Desc of the second arg.\n"
    docstr += "\n"
    docstr += "Raises:\n"
    docstr += "  ZeroDivisionError: If the second arg is zero.\n"
    docstr += "  AttributeError: If the arg3 is None.\n"

    doc = parse(docstr)


# Generated at 2022-06-21 11:53:48.145943
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse('''
        Single line description.

        Long description:

            - list item

        Args:
            arg1 (int): description param.
            arg2 (int): description param.

        Raises:
            ValueError: If something wrong.
    ''') == Docstring(
        short_description='Single line description.',
        blank_after_short_description=False,
        long_description='- list item',
        blank_after_long_description=True,
        meta=[
            DocstringMeta(args=['arg2'], description='description param.'),
            DocstringMeta(args=['raises'], description='ValueError: If something wrong.'),
            DocstringMeta(args=['arg1'], description='description param.'),
        ],
    )
    assert parser

# Generated at 2022-06-21 11:54:11.184518
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    doc = GoogleParser()
    assert doc.title_colon == True
    assert doc.sections["Args"] == Section("Args", "param", SectionType.MULTIPLE)
    assert doc.sections["Example"] == Section("Example", "examples", SectionType.SINGULAR)
    assert doc.sections["Params"] == Section("Params", "param", SectionType.MULTIPLE)



# Generated at 2022-06-21 11:54:18.502760
# Unit test for function parse
def test_parse():
    #from pprint import pprint
    #from ipdb import set_trace
    #set_trace()
    docstring = """A short description of the function.

    In multiparagraphs.
    In multiparagraphs.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.
    """
    parsed = parse(docstring)
    assert parsed.short_description == "A short description of the function."
    assert parsed.long_description == """In multiparagraphs.
    In multiparagraphs."""
    assert parsed.meta[0].args == ['returns']
    assert parsed.meta[1].args == ['param', 'arg1 (int)']

# Generated at 2022-06-21 11:54:29.963855
# Unit test for function parse
def test_parse():
    # Example from https://google.github.io/styleguide/pyguide.html
    text = """Summarize the function.

    A few sentences providing an extended description. Refer to
    variables using back-ticks, e.g. `var`.

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    doc = parse(text)
    assert doc.short_description == "Summarize the function."
    assert doc.blank_after_short_description == True