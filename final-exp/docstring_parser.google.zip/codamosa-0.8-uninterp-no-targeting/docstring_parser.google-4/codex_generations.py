

# Generated at 2022-06-21 11:45:14.291015
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    normal_doc_str = """
        This is a test for parse()
        Args:
            a (int): input a
            b (int): input b
        
        Returns:
            int: a+b
        
        Raises:
            ValueError: when a+b>10
        
        Examples:
            here are some examples
    """
    doc_str_2 = """
        Args:
            a (int): input a
            b (int): input b
        Returns:
            int: a+b
        Raises:
            ValueError: when a+b>10
        Examples:
            here are some examples
    """
    doc_str_3 = """
        Here are some examples
    """


# Generated at 2022-06-21 11:45:18.289468
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('Get the response from S3') == Docstring(short_description='Get the response from S3')

    assert parse('''Get the response from S3
        :param bucket: Bucket name
        :param key: Object key
        ''') == Docstring(short_description='Get the response from S3', meta=[DocstringParam('param', 'bucket: Bucket name', 'bucket', None, False, None), DocstringParam('param', 'key: Object key', 'key', None, False, None)])


# Generated at 2022-06-21 11:45:25.090263
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse(
        inspect.cleandoc(
            """
Description
"""
        )
    ) == Docstring(
        short_description="Description",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert GoogleParser().parse(
        inspect.cleandoc(
            """
Description
----------
"""
        )
    ) == Docstring(
        short_description="Description",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

# Generated at 2022-06-21 11:45:26.802459
# Unit test for function parse
def test_parse():
    print(parse.__doc__)

# Main for test
if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:45:34.145700
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = "Short description.\n    Long description.\n"
    docstring = parser.parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description



# Generated at 2022-06-21 11:45:44.093309
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleParser = GoogleParser(DEFAULT_SECTIONS)
    assert googleParser.titles_re.pattern == "(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields)[ \t\r\f\v]*$"
    assert googleParser.title_colon == True

# Generated at 2022-06-21 11:45:57.030614
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    try:
        #Test case: 
        #with title_colon = False
        google_parser = GoogleParser(title_colon = False)
        #with sections is not None
        sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
        google_parser2 = GoogleParser(sections=sections) 
        #with sections is None
        google_parser3 = GoogleParser()
        #with title_colon = False and sections is not None
        google_parser4 = GoogleParser(sections=sections,title_colon=False)
        #with title_colon = False and sections is None
        google_parser5 = GoogleParser(title_colon=False)
    except:
        print("Unable to create class GoogleParser")
# unit test for method parse() of class GoogleParser

# Generated at 2022-06-21 11:45:58.593267
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    # Act
    # Assert
    assert True

# Generated at 2022-06-21 11:46:11.468921
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    google_parser.add_section(Section("Parameters", "param", SectionType.MULTIPLE))
    google_parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    google_parser.add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    google_parser.add_section(Section("Exceptions", "raises", SectionType.MULTIPLE))
    google_parser.add_section(Section("Except", "raises", SectionType.MULTIPLE))
    google_parser.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))
    google_parser.add_section(Section("Example", "examples", SectionType.SINGULAR))

# Generated at 2022-06-21 11:46:22.583292
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d1 = """
    Google-style docstring parsing.

    :param text: docstring text
    :return: parsed docstring
    """
    d2 = parse(d1)
    assert d2.short_description == 'Google-style docstring parsing.'
    assert d2.long_description == ':param text: docstring text\n:return: parsed docstring'
    assert len(d2.meta) == 2
    assert d2.meta[0].args == ['param', 'text']
    assert d2.meta[0].description == "docstring text"
    assert d2.meta[1].args == ['return']
    assert d2.meta[1].description == "parsed docstring"

    d3 = """
    Google-style docstring parsing.

    :param only_one:
    """
    d

# Generated at 2022-06-21 11:46:37.612306
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    n = GoogleParser()
    # 1
    s = Section("Section", "section", SectionType.SINGULAR)
    n.add_section(s)
    # 2
    s = Section("Section", "section", SectionType.MULTIPLE)
    n.add_section(s)
    # 3
    s = Section("Section", "section", SectionType.SINGULAR_OR_MULTIPLE)
    n.add_section(s)

# Generated at 2022-06-21 11:46:45.575498
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-21 11:46:58.727505
# Unit test for function parse
def test_parse():
    """
    Unit test for function parse().
    """

# Generated at 2022-06-21 11:46:59.874469
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    pass


# Generated at 2022-06-21 11:47:05.368746
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = r'''
        Does something.

        Args:
            a: An int.
            b: A str.
            c: A float, optional.

        Raises:
            ValueError: If something bad happens.

        Returns:
            str: A formatted string.
        '''
    assert GoogleParser().parse(doc)

# Generated at 2022-06-21 11:47:13.836981
# Unit test for function parse
def test_parse():
    # Set up required test result
    expected = Docstring()
    expected.short_description = "This is the short description."
    expected.long_description = "This is the long description\nand two lines"
    expected.blank_after_short_description = False
    expected.blank_after_long_description = True

# Generated at 2022-06-21 11:47:20.543527
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test that GoogleParser class can be used to add new docstring sections."""
    
    google_parser = GoogleParser()
    google_parser.add_section(Section("Additional", "additional", SectionType.MULTIPLE))
    google_parser.add_section(Section("More Info", "additional", SectionType.SINGULAR))
    assert(True)

# Generated at 2022-06-21 11:47:32.568363
# Unit test for constructor of class Section

# Generated at 2022-06-21 11:47:35.364913
# Unit test for constructor of class Section
def test_Section():
    section = Section("Raises", "raises", 2)
    assert (section.title == "Raises")
    assert (section.key == "raises")
    assert (section.type == 2)


# Generated at 2022-06-21 11:47:39.751657
# Unit test for constructor of class Section
def test_Section():
    title = "Arguments"
    key = "param"
    t = SectionType.MULTIPLE
    sec = Section(title, key, t)
    assert sec.title == title
    assert sec.key == key
    assert sec.type == t

# Generated at 2022-06-21 11:47:57.831917
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    def test_no_description():
        text = ""
        docstring = GoogleParser().parse(text)
        assert docstring.short_description == None
        assert docstring.long_description == None
        assert len(docstring.meta) == 0

    def test_no_parameter():
        text = "This is a short description" + "\n\n"
        text += "This is a long description"
        docstring = GoogleParser().parse(text)
        assert docstring.short_description == "This is a short description"
        assert docstring.long_description == "This is a long description"
        assert len(docstring.meta) == 0

    def test_no_long_description():
        text = "This is a short description" + "\n\n"
        text += "Args:" + "\n"

# Generated at 2022-06-21 11:48:02.898453
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    googleParser = GoogleParser(title_colon=False)
    googleParser.add_section(Section("Section1", "param", SectionType.MULTIPLE))
    assert googleParser.sections == {'Section1': Section("Section1", "param", SectionType.MULTIPLE)}


# Generated at 2022-06-21 11:48:14.554818
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:48:25.124851
# Unit test for function parse
def test_parse():
    ret = parse("""  A short summary

    A longer description.

    Args:
        arg1 (str): Description of arg1
        arg2 (:obj:`int`, optional): Description of arg2

    Returns:
        None
    """)

    assert ret.short_description == "A short summary"
    assert not ret.blank_after_short_description
    assert ret.long_description == "A longer description."
    assert ret.blank_after_long_description
    assert len(ret.meta) == 2

    ret = parse(
        """
        A short summary
        Args:
            arg1 (str): Description of arg1
        Args:
            arg2 (:obj:`int`, optional): Description of arg2
        """
    )

    assert ret.short_description == "A short summary"

# Generated at 2022-06-21 11:48:27.646119
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser(sections=[Section("Example", "example", SectionType.SINGULAR)])
    assert isinstance(gp, GoogleParser)



# Generated at 2022-06-21 11:48:35.405084
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import epydoc.docstringparser as o
    text = """
        Class for parsing Google-style docstrings.

        Long description.

        Args:
            arg1 (int): The first argument.
            arg2 (str, optional): The second argument. Defaults to something.
            arg3 (bool): True means something, False means something else.

        Returns:
            int: return value

        Raises:
            AttributeError

        Examples:
            Examples should be written in doctest format, and should illustrate
            how to use the function.

            >>> a = 1
            >>> b = 2
            >>> c = a + b
            >>> c
            3
            >>> sum(a, b)
            5
    """

# Generated at 2022-06-21 11:48:38.369700
# Unit test for constructor of class Section
def test_Section():
    section = Section("title", "key", SectionType.MULTIPLE)
    assert section.title == "title"
    assert section.key == "key"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:48:46.018244
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # test for a variable without docstring
    # variable without docstring
    variable_without_docstring = 5
    # variable without docstring
    variable_with_docstring = "Hello world"
    variable_with_docstring.__doc__ = 'Google Style Docstring.\nDescription:\n\nArgs:\n    param1: The first parameter.\n    param2: The second parameter.\n\nReturns:\n    True if successful, False otherwise.\n    '
    GoogleParser().parse(variable_with_docstring.__doc__)

# Generated at 2022-06-21 11:48:56.808459
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("a") == Docstring(
        short_description="a", blank_after_short_description=True
    )
    assert parse("a\nb") == Docstring(
        short_description="a",
        blank_after_short_description=True,
        long_description="b",
        blank_after_long_description=False,
    )
    assert parse("a\n\nb") == Docstring(
        short_description="a",
        blank_after_short_description=True,
        long_description="b",
        blank_after_long_description=False,
    )

# Generated at 2022-06-21 11:49:02.668447
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:49:15.931367
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test when sections are None
    sections = None
    title_colon = True
    parser = GoogleParser(sections, title_colon)

# Generated at 2022-06-21 11:49:20.102718
# Unit test for constructor of class Section
def test_Section():
    s = Section('title', 'key', SectionType.SINGULAR)
    assert s.title == 'title'
    assert s.key == 'key'
    assert s.type == SectionType.SINGULAR

# Unit tests for method _setup of class GoogleParser

# Generated at 2022-06-21 11:49:29.425130
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is just a simple docstring.

    This is the long description. Notice that it ends on the same line as
    the paragraph above.

    :param name: the name to use
    :type name: str
    :param state: current state to be in, default is 0
    :type state: int
    :param kwargs: optional keyword arguments

    :raises: ValueError
    :returns: One or more values
    """

    parsed = parse(docstring)
    assert parsed.short_description == "This is just a simple docstring."
    assert parsed.long_description == "This is the long description. Notice that it ends on the same line as the paragraph above."

# Generated at 2022-06-21 11:49:33.557534
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser(title_colon=False)
    section = Section("Args", "param", SectionType.MULTIPLE)
    parser.add_section(section)
    assert parser.sections["Args"] == section


# Generated at 2022-06-21 11:49:46.257001
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    def test_no_sections():
        """Test when there is no sections."""
        gp = GoogleParser(sections=None)
        assert gp.sections == DEFAULT_SECTIONS

    def test_some_sections():
        """Test when there is some sections."""
        sections = [Section("A", "a", SectionType.MULTIPLE)]
        gp = GoogleParser(sections=sections)
        assert gp.sections == {"A": sections[0]}

    def test_all_sections():
        """Test when there is all sections."""
        sections = [
            Section("A", "a", SectionType.SINGULAR),
            Section("B", "b", SectionType.SINGULAR_OR_MULTIPLE),
            Section("C", "c", SectionType.MULTIPLE),
        ]

# Generated at 2022-06-21 11:49:56.318625
# Unit test for function parse
def test_parse():
    _text = '''\
    Sums two numbers.

    Args:
      x: An int.
      y: An int.

    Returns:
      The sum of x and y.

    Raises:
      ValueError: if x and y are both zero.

    Example:
      x = 1
      y = 2
      assert(3 == add(x, y))
      # Todo(your id here): Explain why this is correct.
    '''
    _ds = parse(_text)
    assert _ds.short_description == 'Sums two numbers.'
    assert _ds.long_description == 'The sum of x and y.'
    assert len(_ds.meta) == 4
    _x, _y, _return, _raise = _ds.meta

# Generated at 2022-06-21 11:50:08.732655
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # creating GoogleParser object
    _doc = GoogleParser()

    _doc.add_section(
        Section("Argument", "Argument", SectionType.MULTIPLE)
    )
    _doc.add_section(
        Section("Argu", "Argu", SectionType.MULTIPLE)
    )
    _doc.add_section(
        Section("Param", "Param", SectionType.MULTIPLE)
    )
    _doc.add_section(
        Section("Raise", "Raise", SectionType.MULTIPLE)
    )
    _doc.add_section(
        Section("Example", "Example", SectionType.SINGULAR)
    )
    _doc.add_section(
        Section("Examples", "Examples", SectionType.SINGULAR)
    )
    _doc.add_

# Generated at 2022-06-21 11:50:19.272107
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test to add a new section that contains only one line.
    assert parse('Method to return a list of tags.\n\nTags: list of tags.\n') == Docstring(
        short_description='Method to return a list of tags.',
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(args=['Tags'], description='list of tags.')])
    # Test to add a new section that contains more than one line.

# Generated at 2022-06-21 11:50:29.489608
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # test that adding a Section overwrites an existing one which has the same title
    # initial setup
    google = GoogleParser()
    section_titles = [section.title for section in DEFAULT_SECTIONS]
    # add an extra section with an existing title
    extra_section = Section("Attributes", "something_else", SectionType.SINGULAR)
    google.add_section(extra_section)
    # check that the overwritten section was removed
    new_section_titles = [section.title for section in google.sections.values()]
    assert extra_section.title in new_section_titles
    assert extra_section.title not in section_titles

# Generated at 2022-06-21 11:50:34.792043
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # No default sections
    GoogleParser(sections=[])
    # No default sections with different title_colon
    GoogleParser(sections=[],title_colon=False)
    # No default sections with different section
    GoogleParser(sections=[Section("Params", "param", SectionType.MULTIPLE)])


# Generated at 2022-06-21 11:50:54.733813
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:50:58.772397
# Unit test for constructor of class Section
def test_Section():
    name = "Test"
    key = "test"
    type = SectionType.SINGULAR
    section = Section(name, key, type)
    assert section.title == name
    assert section.key == key
    assert section.type == type



# Generated at 2022-06-21 11:51:07.029131
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    def test_add_singular_section():
        google_parser = GoogleParser()
        unique_section = Section("Unique", "unique",SectionType.SINGULAR)
        google_parser.add_section(unique_section)

        assert(len(google_parser.sections) == len(DEFAULT_SECTIONS)+1)
    
    def test_replace_singular_section():
        google_parser = GoogleParser()
        unique_section = Section("Unique", "unique",SectionType.SINGULAR)
        replace_section = Section("Example", "unique",SectionType.SINGULAR)
        google_parser.add_section(unique_section)
        google_parser.add_section(replace_section)

        assert(len(google_parser.sections) == len(DEFAULT_SECTIONS)+1)
    

# Generated at 2022-06-21 11:51:10.703602
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    try:
        GoogleParser()
    except Exception as e:
        assert type(e) == Exception, "Unexpected error!"
        print("Exception occurred: ", e)


# Generated at 2022-06-21 11:51:18.664469
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    print("\n------------------ testing add_section of GoogleParser ---------------------")
    text = 'Test function to handle google docstring : Author: V. Ganesh:\n'
    # Default section
    print("\n------------------ Default sections ---------------------")
    print(GoogleParser().parse(text))
    # Added section
    print("\n------------------ Added sections ---------------------")
    sec = Section('Author', 'author', SectionType.SINGULAR)
    gp = GoogleParser()
    gp.add_section(sec)
    print(gp.parse(text))


# Generated at 2022-06-21 11:51:24.847129
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    Test GoogleParser.add_section()
    :return:
    """
    section = Section("Test", "test", SectionType.SINGULAR)
    parser = GoogleParser()
    parser.add_section(section)
    assert parser.sections["Test"] == section
    assert parser.sections["Test"].title == "Test"
    assert parser.sections["Test"].key == "test"
    assert parser.sections["Test"].type == SectionType.SINGULAR


# Generated at 2022-06-21 11:51:28.606836
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g_parser = GoogleParser()
    custom_section = Section("Key", "key", SectionType.MULTIPLE)
    g_parser.add_section(custom_section)
    assert g_parser.sections["Key"] == custom_section
    assert len(g_parser.sections) == 16


# Generated at 2022-06-21 11:51:31.187383
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print("Testing: class GoogleParser")
    assert GoogleParser() != None
    assert GoogleParser(sections = None, title_colon = True) != None
    print("Passed!");


# Generated at 2022-06-21 11:51:43.198053
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
    Params:
        *param a1: blabla
        *param b1: blabla

    Raises:
        ValueError: 
            If the *code* is invalid.

        TypeError: 
            If the *code* is a string.
    """

    docstring = """This is the short description.

    This is the long description.

    Params:
        a1 (int): blabla
        b1 (float): blabla

    Raises:
        ValueError: If the code is invalid.
        TypeError: If the code is a string.
    """


# Generated at 2022-06-21 11:51:53.662564
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # test constructor
    a = GoogleParser()
    b = GoogleParser(DEFAULT_SECTIONS)
    c = GoogleParser(title_colon=True)
    d = GoogleParser(DEFAULT_SECTIONS,title_colon=True)
    e = GoogleParser(DEFAULT_SECTIONS,title_colon=False)
    assert type(a) == type(b) == type(c) == type(d) == type(e) == GoogleParser

# Generated at 2022-06-21 11:52:31.200687
# Unit test for function parse
def test_parse():
    from .samples.google import docstring as google
    from .samples.google import parsed_docstring as parsed_google
    assert(parse(google) == parsed_google)


# Generated at 2022-06-21 11:52:32.512377
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()


# Generated at 2022-06-21 11:52:40.538872
# Unit test for constructor of class Section
def test_Section():
    from unittest import TestCase

    class SectionTest(TestCase):
        def test_constructor(self):
            title = 'Parameter'
            key = 'param'
            section_type = SectionType.SINGULAR
            section = Section(title, key, section_type)
            self.assertEqual(section.title, title)
            self.assertEqual(section.key, key)
            self.assertEqual(section.type, section_type)
    
    test = SectionTest()
    test.test_constructor()


# Generated at 2022-06-21 11:52:47.763664
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert(GoogleParser())
    assert(GoogleParser(title_colon=True))
    assert(GoogleParser(title_colon=False))

    assert(GoogleParser(sections=DEFAULT_SECTIONS))
    assert(GoogleParser(sections=DEFAULT_SECTIONS, title_colon=True))
    assert(GoogleParser(sections=DEFAULT_SECTIONS, title_colon=False))

    # TODO: Section as namedtuple with default values, so that title is mandatory
    # assert(GoogleParser(sections=[Section(title="test")]))


# Generated at 2022-06-21 11:52:53.979605
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    # Initialize GoogleParser object
    gp = GoogleParser()
    assert gp is not None

    # Create a Section object to be added to GoogleParser object
    sec = Section("Test", "test", SectionType.MULTIPLE)
    assert sec is not None

    # Add the created section to GoogleParser object
    gp.add_section(sec)
    assert sec.title in gp.sections.keys()

    # Check that the title added is valid and matches the title of the Section object
    assert sec.title == gp.sections[sec.title].title

test_GoogleParser_add_section()

# Generated at 2022-06-21 11:53:04.261179
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = parse('  Example usage::\n\n    >>> import numpy as np\n    >>> MeanNormalizer().fit(X)\n    >>> MeanNormalizer().transform(X)')
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is None
    assert docstring.blank_after_long_description is None
    assert isinstance(docstring.meta, list)
    assert isinstance(docstring.meta[0], DocstringMeta)
    assert docstring.meta[0].args == ['examples']
    assert docstring.meta[0].description == 'Example usage:\n\n>>> import numpy as np\n>>> MeanNormalizer().fit(X)\n>>> MeanNormalizer().transform(X)'


# Generated at 2022-06-21 11:53:06.388601
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GoogleParser().add_section(Section("test", "test", SectionType.SINGULAR_OR_MULTIPLE))

# Generated at 2022-06-21 11:53:08.310897
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test if the output is a Docstring
    assert isinstance(GoogleParser().parse(""), Docstring)


# Generated at 2022-06-21 11:53:09.726057
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    G = GoogleParser()
    print('Setup completed')
    return True



# Generated at 2022-06-21 11:53:11.973362
# Unit test for constructor of class Section
def test_Section():
    test_section = Section("param", "param", SectionType.MULTIPLE)
    assert test_section == ("param", "param", 0)


# Generated at 2022-06-21 11:54:30.737028
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Single section text.
    '''
    pa = GoogleParser()
    res = pa.parse(text)
    assert len(res.meta) == 1
    assert res.meta[0].description == "Single section text."

    text = '''
    Single section text.

    Longer
    multi-line text.

    Longer
    multi-line text.
    '''
    pa = GoogleParser()
    res = pa.parse(text)
    assert len(res.meta) == 1
    assert res.meta[0].description == "Single section text."
    assert res.long_description is not None
    assert res.long_description == "Longer\n    multi-line text.\n\n    Longer\n    multi-line text.\n"

# Generated at 2022-06-21 11:54:36.201970
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("Arguments", "param", SectionType.SINGULAR)]

    gp = GoogleParser(sections, False)

    assert gp.sections == {'Arguments': Section('Arguments', 'param', SectionType.SINGULAR)}
    assert gp.title_colon == False
