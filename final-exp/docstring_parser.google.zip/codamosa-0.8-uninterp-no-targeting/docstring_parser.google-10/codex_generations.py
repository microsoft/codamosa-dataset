

# Generated at 2022-06-21 11:44:54.786515
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    print(parser.sections)


# Generated at 2022-06-21 11:44:57.041525
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser1 = GoogleParser()
    assert isinstance(parser1, GoogleParser)

    parser2 = GoogleParser(title_colon=False)
    assert isinstance(parser2, GoogleParser)
    assert parser2.title_colon == False
    
    

# Generated at 2022-06-21 11:45:01.533014
# Unit test for function parse
def test_parse():
    text = '''
    Test Function

    Arguments:
        a (str): The first parameter.
        b (str): The second parameter.

    Raises:
        ValueError: Raised if the parameters are not valid.
        
    Returns:
        str: The computed value.
    '''
    parsed = parse(text)
    assert isinstance(parsed, Docstring)
    assert parsed.short_description == "Test Function"
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert parsed.long_description is None
    assert len(parsed.meta) == 4

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:45:13.203391
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Tit", "key", SectionType.MULTIPLE))
    assert parser._build_multi_meta(parser.sections["Tit"], "Tit", "Tit") == \
        DocstringMeta(args=["key", "Tit"], description="Tit")
    parser.add_section(Section("Tit", "key", SectionType.SINGULAR))
    assert parser._build_single_meta(parser.sections["Tit"], "Tit") == \
        DocstringMeta(args=["key"], description="Tit")
    parser.add_section(Section("Tit", "key", SectionType.SINGULAR_OR_MULTIPLE))
    assert parser._build_single_meta(parser.sections["Tit"], "Tit") == \
        Docstring

# Generated at 2022-06-21 11:45:16.514628
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    ds = Docstring()
    ds_test = gp.parse(ds)
    assert isinstance(ds_test, Docstring)


# Generated at 2022-06-21 11:45:19.081176
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Robots", "Robot", SectionType.MULTIPLE)
    parser.add_section(section)
    assert parser.sections["Robots"] == section

# Generated at 2022-06-21 11:45:25.565618
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    str1 = """\
    A module-level docstring that describes
    a module.
    """

    str2_1 = """\
    A module-level docstring that describes
    a module.

    A second paragraph that describes
    a module.
    """

    str2_2 = """\

    A module-level docstring that describes
    a module.

    A second paragraph that describes
    a module.
    """

    str2_3 = """\

    A module-level docstring that describes
    a module.

    A second paragraph that describes
    a module.
    """


# Generated at 2022-06-21 11:45:33.143236
# Unit test for function parse
def test_parse():
    text = """
    Short description.

    Long
    description.

    Description can be over multiple lines.

    Args:
        arg1 (str): Description of arg1. Defaults to "".
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring = parse(text)
    print(docstring)
    print(docstring.short_description)
    print(docstring.long_description)
    for param in docstring.get_params():
        print(param.arg_name)
        print(param.type)
        print(param.default)
        print(param.description)
    for returns in docstring.get_returns():
        print(returns.type)
        print(returns.description)

# Generated at 2022-06-21 11:45:43.832759
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    g = inspect.cleandoc("""
        Args:
            arg1: The first argument.
            arg2: The second argument.
        Returns:
            The return value. True for success, False otherwise.
    """)
    docstring = parser.parse(g)
    assert len(docstring.meta) == 2
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == None
    assert docstring.meta[0].is_optional == None
    assert docstring.meta[1].arg_name == "arg2"
    assert docstring.meta[1].type_name == None
    assert docstring.meta[1].is_optional == None
   

# Generated at 2022-06-21 11:45:56.946136
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # TODO: Add more tests.
    # This function is not used in this project.

    def test_func1(arg1: int, arg2: float, arg3: str) -> float:
        """Test function.

        Args:
            arg1 (int): some number.
            arg2 (float): some other number.
            arg3 (str): some string.

        Returns:
            float: some number.

        Examples:
            >>> print(test_func1(123, 456.789, "abc"))
            798.789
        """

        return arg1 + arg2

    # Init GoogleParser.
    parser = GoogleParser()
    # Parse docstring.
    doc = parser.parse(test_func1.__doc__)
    # Check docstring.
    assert isinstance(doc, Docstring)


# Generated at 2022-06-21 11:46:05.167186
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser()
    assert g.sections
    assert g.title_colon
    g = GoogleParser(None, False)
    assert g.sections
    assert not g.title_colon


# Generated at 2022-06-21 11:46:17.813717
# Unit test for function parse
def test_parse():
    s = GoogleParser().parse("""
    This is the short description.

    This is the long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.

    Raises:
        ValueError: thrown if something is bad.
    """)
    assert s.short_description == "This is the short description."
    assert s.long_description == "This is the long description."
    assert len(s.meta) == 1
    assert isinstance(s.meta[0], DocstringRaises)
    assert len(s.meta[0].args) == 3
    assert s.meta[0].args[0] == "raises"
    assert s.meta[0].args[1] == "ValueError"

# Generated at 2022-06-21 11:46:26.561422
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    my_parser = GoogleParser()
    my_parser.add_section(Section("Test", "test", SectionType.SINGULAR))
    my_parser.add_section(Section("Test", "test", SectionType.MULTIPLE))
    my_parser.add_section(Section("Test", "test", SectionType.SINGULAR_OR_MULTIPLE))
    with pytest.raises(ParseError):
        my_parser.add_section(Section("Test", "test", int(0)))


# Generated at 2022-06-21 11:46:30.795701
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    check_sections = ['Attributions', 'Attributes']
    new_section = Section("Attributions", "attribute", SectionType.MULTIPLE)
    parser = GoogleParser()
    parser.add_section(new_section)
    sections_title = {s.title for s in parser.sections}
    print(sections_title)
    assert sections_title == set(check_sections)

# Generated at 2022-06-21 11:46:36.368365
# Unit test for function parse
def test_parse():
    text = """Converts an array of one type to an array of another type.

    Args:
        source (1-D array): The array to be converted.
        dest_dtype: The desired type of the output.
        default (optional): The value to use if it is impossible to do the conversion.
            If not given, a ValueError will be raised in that case.

    Returns:
        A tuple containing the converted array, and a boolean mask.
    """
    doc = parse(text)
    return doc


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:46:44.236817
# Unit test for function parse
def test_parse():
    from pprint import pprint
    parser=GoogleParser()
    text='''
    A function sum
    :param a: ...
    :param b: ...
    :returns: c
    '''
    res=parser.parse(text)
    print('short_description: ',res.short_description)
    print('long_description: ', res.long_description)
    print('blank_after_short_description',res.blank_after_short_description)
    print('blank_after_long_description',res.blank_after_long_description)
    print('meta:')
    pprint(res.meta)

if __name__=='__main__':
    test_parse()

# Generated at 2022-06-21 11:46:52.470880
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    print(google_parser)
    print(google_parser.sections)
    print(google_parser.title_colon)
    for section in google_parser.sections:
        print(google_parser.sections.get(section).title)
        print(google_parser.sections.get(section).key)
        print(google_parser.sections.get(section).type)
    print(google_parser.titles_re)


# Generated at 2022-06-21 11:46:57.496031
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test_satisfy_equal_expectation test case internal function for method parse of class GoogleParser
    def test_satisfy_equal_expectation(expectation, docstring):
        ret = GoogleParser().parse(docstring)
        assert ret == expectation, "Parse error: got {}, expected {}".format(ret, expectation)
        return True
    # test_not_satisfy_equal_expectation test case internal function for method parse of class GoogleParser
    def test_not_satisfy_equal_expectation(expectation, docstring):
        ret = GoogleParser().parse(docstring)
        assert ret != expectation, "Parse error: got {}, expected {}".format(ret, expectation)
        return True
    # test_satisfy_not_equal_expectation test case internal function for method

# Generated at 2022-06-21 11:47:02.049444
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Unit test input data
    function_docstring = """
        A short summary of the function.

           This is where an extended description would go if there were one.

        Args:
           param1: The first parameter.
           param2: The second parameter.
           *args: Variable length argument list.
           **kwargs: Arbitrary keyword arguments.

        Returns:
           bool: The return value. True for success, False otherwise.

        Raises:
           AttributeError: The ``Raises`` section is a list of all exceptions
               that are relevant to the interface.
           ValueError: If `param2` is equal to `param1`.
    """

# Generated at 2022-06-21 11:47:12.083108
# Unit test for function parse
def test_parse():
    """Tests the function parse"""
    text_to_test = """example of docstring

Args:
    arg1 (int): the first argument.
    arg2 (str): the second argument.
    arg3 (list, optional): Defaults to []. the third argument.
    arg4 (list of int, optional): Defaults to []. the fourth argument.

Returns:
    bool: the return value. True for success, False otherwise.

    additional info

Raises:
    ValueError: If `arg2` is equal to `arg1`.

Attributes:
    attr1 (str): the first atribute.
    attr2 (str): the second attribute.
"""

    lines = text_to_test.splitlines()[1:]  # skip first line
    parse_res = parse(text_to_test)

# Generated at 2022-06-21 11:47:29.372385
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Docstring for parse

    :param arg1: first arg
    :param arg2: second arg
    :returns: return value

    This is a longer description.
    This is a longer description.
    This is a longer description.
    '''

    ret = parse(text)
    assert ret.short_description == 'Docstring for parse'
    assert ret.long_description == 'This is a longer description.\nThis is a longer description.\nThis is a longer description.'
    assert ret.blank_after_long_description
    assert not ret.blank_after_short_description

    assert len(ret.meta) == 2
    assert ret.meta[0].args == ('param', 'arg1')
    assert ret.meta[0].description == 'first arg'
    assert ret.meta[0].arg

# Generated at 2022-06-21 11:47:33.118842
# Unit test for constructor of class Section
def test_Section():
    s = Section('title1','title1',SectionType.SINGULAR)
    assert s.title == 'title1'
    assert s.key == 'title1'
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:47:45.208774
# Unit test for function parse

# Generated at 2022-06-21 11:47:57.743334
# Unit test for function parse
def test_parse():
    docstring = parse_google_docstring("""
    This is a short description.

    This is a long description. Only shown when
    the docstring is long enough.

    Parameters
    ----------
    arg_1 : str
        First argument.
    arg_2 : int
        Second argument.

    Returns
    -------
    None
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description. Only shown when the docstring is long enough."
    assert len(docstring.meta) == 2
    param1 = docstring.meta[0]
    assert param1.title == "Parameters"
    assert param1.args == ["param", "arg_1"]
    assert param1.description == "First argument."
    assert param1.arg_

# Generated at 2022-06-21 11:48:01.505058
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp=GoogleParser()
    gp.add_section(Section("Foo", "foo", SectionType.MULTIPLE))
    assert ('Foo', Section) in gp.sections.items()


# Generated at 2022-06-21 11:48:13.240239
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    TEST_SECTIONS = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Attributes", "attribute", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Examples", "examples", SectionType.SINGULAR),
    ]
    parser = GoogleParser(sections=TEST_SECTIONS)
    assert parser.sections.keys() == {
        "Arguments", "Args", "Attributes", "Example", "Examples"
    }
    new_section = Section("Argumetss", "param", SectionType.MULTIPLE)
    parser.add_section(new_section)

# Generated at 2022-06-21 11:48:14.985547
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()



# Generated at 2022-06-21 11:48:25.414641
# Unit test for function parse
def test_parse():
    text = """Short summary.

This is a really really really really really really really really really
really really really really really really really really really really really
really really really really really really really really really really really
really really really really really really really really really really really
really really really really really really really really really really really
really really really really really really really really really really really
really really really really really really really really really really really
really really really really really really really really really really really
really really really really really really really really long description.

Args:
    param0 (str): Description for param0.
    param1 (str): Description for param1. Defaults to "default".

Raises:
    KeyError: If something bad happens.
    ValueError: If something bad happens.
"""

# Generated at 2022-06-21 11:48:28.991585
# Unit test for constructor of class Section
def test_Section():
    section = Section("Example", "example", SectionType.SINGULAR_OR_MULTIPLE)
    assert section.title == "Example"
    assert section.key == "example"
    assert section.type == SectionType.SINGULAR_OR_MULTIPLE


# Generated at 2022-06-21 11:48:37.055090
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Title", "title", SectionType.SINGULAR),
        Section("Args", "args", SectionType.MULTIPLE),
    ]

    # Test constructor of class GoogleParser without params
    gp1 = GoogleParser()
    sections1 = gp1.sections
    assert sections1[sections[0].title] == sections[0]
    assert sections1[sections[1].title] == sections[1]
    assert gp1.title_colon == True

    # Test constructor of class GoogleParser with params
    gp2 = GoogleParser(sections, False)
    sections2 = gp2.sections
    assert sections2[sections[0].title] == sections[0]
    assert sections2[sections[1].title] == sections[1]
    assert gp2.title_colon == False



# Generated at 2022-06-21 11:48:52.668194
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    ## Test __init__
    # Test: input: section = DEFAULT_SECTION
    # Expected: a GoogleParser object with corresponding title, key and type

    gp = GoogleParser()
    for section in DEFAULT_SECTIONS:
        assert gp.sections[section.title].title == section.title
        assert gp.sections[section.title].key == section.key
        assert gp.sections[section.title].type == section.type

    # Test: input: section = None
    # Expected: a GoogleParser object with corresponding title, key and type

    gp = GoogleParser(sections = None)
    for section in DEFAULT_SECTIONS:
        assert gp.sections[section.title].title == section.title
        assert gp.sections[section.title].key == section.key

# Generated at 2022-06-21 11:49:03.051448
# Unit test for function parse
def test_parse():
    docstring = """
    Here is a function that does very little.

    Args:
        arg1 (int): The first arg.
        arg2 (str, optional): The second arg.

    Returns:
        None

    Example:
        >>> assert func(0, 'a') is None

    Raises:
        TypeError: if arg1 is not int
    """

# Generated at 2022-06-21 11:49:15.044577
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Tests for parse method of class GoogleParser
    # Test 1
    ds = Docstring()
    ds.long_description = (
        "This is a long description of a function which appears in the\n"
        "sections of the docstring below.\n"
    )
    ds.short_description = "This is a short description."
    ds.blank_after_short_description = False
    ds.blank_after_long_description = True

# Generated at 2022-06-21 11:49:26.212761
# Unit test for function parse
def test_parse():  # pragma: no cover
    f = parse
    f2 = GoogleParser().parse
    # noinspection PyUnresolvedReferences
    f3 = GoogleParser(title_colon=True).parse

    assert f("") == f2("")
    assert f("") == f3("")
    assert f("\"\"\"\"\"\"") == f2("")
    assert f("\"\"\"\"\"\"") == f3("")

    assert f("x") == f2("x")
    assert f("x") == f3("x")
    assert f("\"\"\"x\"\"\"") == f2("x")
    assert f("\"\"\"x\"\"\"") == f3("x")

    assert f("x\ny") == f2("x\ny")

# Generated at 2022-06-21 11:49:34.086852
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """This is an example of Google-style docstring.

    Args:
        arg1 (str): Desc of arg1.
        arg2 (str): Desc of arg2. Defaults to "".
        arg3 (str): Desc of arg3.
        arg4 (str, optional): Desc of arg4.
        arg5 (str, optional): Desc of arg5.

    Returns:
        str: Desc of return value.

    Raises:
        ValueError: If arg3 is not a str.

    """
    assert GoogleParser().parse(docstring).short_description == \
        'This is an example of Google-style docstring.'
    print("test_GoogleParser_parse pass!")

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-21 11:49:46.963938
# Unit test for function parse
def test_parse():
    class A:
        def __init__(self):
            pass

    def f(x: int, y = None) -> int:
        """ Short summary.

        Long summary

        More long summary.

        Args:
            x (int): This is x. Defaults to 0.
            y: This is y. Defaults to 1.

        Returns:
            int: This is the return value.

        Raises:
            ValueError: If `x` is too large.
        """
        pass

    def g(x: int) -> T.Iterator[int]:
        """ Short summary.

        Args:
            x (int): This is x.

        Yields:
            int: The next number.
        """
        pass


# Generated at 2022-06-21 11:49:54.157174
# Unit test for function parse
def test_parse():
    google_parser = GoogleParser()
    text = '''
    Return an int array length 3 containing the first 3 digits of pi, {3, 1, 4}.

    :rtype: List[int]
    '''
    result = google_parser.parse(text)
    assert result.short_description == ' Return an int array length 3 containing the first 3 digits of pi, {3, 1, 4}'
    assert len(result.meta) == 1
    assert isinstance(result.meta[0], DocstringParam)

# Generated at 2022-06-21 11:49:57.965754
# Unit test for constructor of class Section
def test_Section():
    sec = Section("title", "key", SectionType.MULTIPLE)
    assert sec.title == "title"
    assert sec.key == "key"
    assert sec.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:50:03.423828
# Unit test for constructor of class Section
def test_Section():
    print("Test Section:")
    section = Section("Arguments","param",SectionType.MULTIPLE)
    print("\ttitle:",section.title,"\tkey:",section.key,"\ttype:",section.type)
    return


# Generated at 2022-06-21 11:50:05.036790
# Unit test for constructor of class Section
def test_Section():
    a = Section('Arguments', 'param', SectionType.MULTIPLE)
    assert a.title == 'Arguments'
    assert a.key == 'param'
    assert a.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:50:11.566527
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    text = """Tytul
    Opis
    Parametry:
      a: cos
        cos
      b: cos2
        cos2"""
    GoogleParser().parse(text)



# Generated at 2022-06-21 11:50:19.369203
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [Section("New", "new", SectionType.MULTIPLE)]
    d = GoogleParser(sections)
    assert d.sections == {'New': Section('New', 'new', SectionType.MULTIPLE)}
    d.add_section([Section('Age', 'age', SectionType.SINGULAR_OR_MULTIPLE)])
    assert d.sections == {'Age': Section('Age', 'age', SectionType.SINGULAR_OR_MULTIPLE)}


# Generated at 2022-06-21 11:50:31.775045
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    test_title_colon = True

# Generated at 2022-06-21 11:50:40.755003
# Unit test for function parse
def test_parse():
    def test_function():
        """
        Short summary.

        Long summary.

        Args:
            foo (int): An integer.
            bar (float): A float.
            baz (bool): A boolean.

        Returns:
            int: The sum of foo and bar.

        Raises:
            ValueError: Indicates invalid parameter values.

        Examples:
            >>> test_function(1, 2, True)
            3
        """
        return 1 + 2

    print(parse(test_function.__doc__))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:50:44.795591
# Unit test for constructor of class Section
def test_Section():
    """Test the Section class constructor"""
    section = Section("Raises", "raises", 2)
    assert section.title == 'Raises'
    assert section.key == 'raises'
    assert section.type == 2
    

# Generated at 2022-06-21 11:50:52.570282
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Test", "test", SectionType.SINGULAR))
    title_re = re.compile("^(Test):[ \t\r\f\v]*$", flags=re.M)
    assert parser.titles_re.pattern == title_re.pattern
    assert parser.sections["Test"].key == "test"


# Generated at 2022-06-21 11:51:02.985919
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser()

# Generated at 2022-06-21 11:51:16.033964
# Unit test for function parse
def test_parse():
    class Dummy:
        """This is a normal class.

        :param param1: this is a first param
        :param param2: this is a second param
        :param param3: this is a third param
        :type param2: int, optional
        :type param3: int
        :raises KeyError: raises an exception
        :raises OSError: raises an exception
        :returns: None
        :rtype: int
        """

    docstr = parse(Dummy.__doc__)
    assert docstr.short_description == "This is a normal class."

# Generated at 2022-06-21 11:51:26.128667
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """ """
        """Summary line.
 
        Description of method.

        Args:
            arg1: Description of arg1
            arg2: Description of arg2
     
        Returns:
            Description of return value.
        """
    )
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Description of method."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-21 11:51:34.858197
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Attention", "attention", SectionType.SINGULAR_OR_MULTIPLE))

# Generated at 2022-06-21 11:51:49.106411
# Unit test for function parse
def test_parse():
    assert parse('''
    Short
    ''') == Docstring(
        short_description="Short",
        blank_after_short_description=True,
        metadata=[]
    )
    assert parse('''
    Short
    Long
    ''') == Docstring(
        short_description="Short",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="Long",
        metadata=[]
    )
    assert parse('''
    Short
    Long
    ''') == Docstring(
        short_description="Short",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description="Long",
        metadata=[]
    )

# Generated at 2022-06-21 11:51:50.166002
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert 1==1


# Generated at 2022-06-21 11:51:57.339409
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr='''Single line summary.
    
    Parameters
    ----------
    a : float, int
        The first parameter.
    b : str
        The second parameter.
    
    Returns
    -------
    None
        A meaningless return value.
    
    '''
    google_parser = GoogleParser()
    result = google_parser.parse(docstr)
    assert result.short_description == 'Single line summary.'
    assert result.long_description.strip() == 'Parameters\n----------\na : float, int\n    The first parameter.\nb : str\n    The second parameter.\n\nReturns\n-------\nNone\n    A meaningless return value.'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True

# Generated at 2022-06-21 11:52:07.785943
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-21 11:52:16.613679
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test case: add new Section
    parser = GoogleParser()
    new_section = Section("A", "a", SectionType.MULTIPLE)
    parser.add_section(new_section)
    assert parser.sections["A"] == new_section
    # Test case: replace existing Section
    new_section = Section("Example", "example", SectionType.SINGULAR)
    parser.add_section(new_section)
    assert parser.sections["Example"] == new_section



# Generated at 2022-06-21 11:52:26.756068
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Constructor test
    g = GoogleParser()
    assert g.sections["Arguments"] == Section("Arguments", "param", SectionType.MULTIPLE)
    assert g.sections["Returns"] == Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert g.title_colon == True
    g = GoogleParser(title_colon=True)
    assert g.sections["Arguments"] == Section("Arguments", "param", SectionType.MULTIPLE)
    assert g.sections["Returns"] == Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert g.title_colon == True
    g = GoogleParser(title_colon=False)

# Generated at 2022-06-21 11:52:39.408553
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    This is a simple example.

    This is a multiline description.
    Hello World!
    Hello World again!

    Args:
        param1: This is a first parameter.
        param2 (tuple): This is a second parameter.
        param3: This is a third parameter.
            This is an optional description.

    Returns:
        string: This is a description of what is returned.
    '''
    ds = GoogleParser().parse(docstring)
    assert ds.short_description == 'This is a simple example.'
    assert ds.long_description == 'This is a multiline description.\nHello World!\nHello World again!'
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == False
    assert d

# Generated at 2022-06-21 11:52:45.174434
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    desc = """
    Some description.
    """

    #Add section
    new_section = Section("New", "new", SectionType.SINGULAR)
    gp = GoogleParser()
    gp.add_section(new_section)
    docstr = gp.parse(desc)
    assert "new" in docstr.meta.keys()
    assert docstr.meta.get("new")[0].description == desc.strip()+"\n"

# Generated at 2022-06-21 11:52:53.860672
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-21 11:53:00.072291
# Unit test for function parse
def test_parse():
    text = '''
    Short description.

    Long description

    :param str arg1: This is a parameter.
    :param str arg2: This is a keyword parameter.
    :returns: This is a return value.
    :raises AttributeError: This is an exception.
    '''

    d = parse(text)
    assert d.short_description == "Short description."
    assert d.long_description == "Long description"
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert len(d.meta) == 3

    param = d.meta[0]
    assert param.args == ["param", "arg1"]
    assert isinstance(param, DocstringParam)
    assert param.arg_name == "arg1"

# Generated at 2022-06-21 11:53:09.445137
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    # test title
    assert(section.title == "Arguments")
    # test key
    assert(section.key == "param")
    # test type
    assert(section.type == SectionType.MULTIPLE)


# Generated at 2022-06-21 11:53:21.770503
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Single-line docstring.
    :returns: x
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert_equals(docstring.short_description, "Single-line docstring.")
    assert_equals(docstring.long_description, None)
    assert_equals(docstring.blank_after_short_description, True)
    assert_equals(docstring.blank_after_long_description, False)
    assert_equals(len(docstring.meta), 1)
    assert_equals(docstring.meta[0].args, ['returns', 'x'])
    assert_equals(docstring.meta[0].type, DocstringMeta.RETURNS)

# Generated at 2022-06-21 11:53:30.865533
# Unit test for function parse
def test_parse():
    """Test the Google-style docstring parser"""

    doc = """short summary

    Long description

    Args:
        arg1 (str): The first argument.
        arg2 (int, optional): The second argument. Defaults to 10.

    Returns:
        str: The return value.
    """

    obj = parse(doc)
    assert obj.short_description == "short summary"
    assert "Long description" in obj.long_description
    assert len(obj.meta) == 2
    assert obj.meta[0].description == "The first argument."
    assert obj.meta[0].arg_name == "arg1"
    assert obj.meta[0].type_name == "str"
    assert obj.meta[0].default is None
    assert obj.meta[1].description == "The second argument. Defaults to 10."


# Generated at 2022-06-21 11:53:40.710263
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Simple example
    doc = '''
    Simple example.
    Args:
        arg: arg.
        arg2: arg.
    '''

    #  Expected output(Doctring)
    #  Docstring(short_description='Simple example.',
    #            blank_after_short_description=False,
    #            long_description=None,
    #            blank_after_long_description=False,
    #            meta=[DocstringParam(args=['param', 'arg'],
    #                                 description='arg.',
    #                                 arg_name='arg',
    #                                 type_name=None,
    #                                 is_optional=None,
    #                                 default=None),
    #                  DocstringParam(args=['param', 'arg2'],
    #                                 description='arg

# Generated at 2022-06-21 11:53:50.985436
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert isinstance(GoogleParser(), GoogleParser)
    assert GoogleParser().title_colon == True
    assert len(GoogleParser().sections) == len(DEFAULT_SECTIONS)
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
        Section("Params", "param", SectionType.MULTIPLE),
    ]
    assert len(GoogleParser(sections).sections) == len(sections)
    assert GoogleParser(title_colon=False).title_colon == False



# Generated at 2022-06-21 11:54:01.247086
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    desc_str = "This is a test function\n\nwith a long description"
    param_str = ":param first_param: description of first param\n:param second_param: description of second param"
    returns_str = ":return: description of return value"
    example_str = ":Example:\n    There is no example\n"
    doc_str = desc_str + "\n" + param_str + "\n" + returns_str + "\n" + example_str
    doc_dict = parse(doc_str)
    assert(doc_dict.short_description == "This is a test function")
    assert(doc_dict.blank_after_short_description == False)
    assert(doc_dict.long_description == "with a long description")

# Generated at 2022-06-21 11:54:10.582472
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [Section("Section1", "section1", SectionType.MULTIPLE)]
    parser = GoogleParser(sections)
    section_new = Section("Section2", "section2", SectionType.MULTIPLE)
    parser.add_section(section_new)
    section_modified = Section("Section1", "section1", SectionType.SINGULAR)
    parser.add_section(section_modified)
    sections_ = {
        'Section1': section_modified,
        'Section2': section_new
    }
    assert parser.sections == sections_


# Generated at 2022-06-21 11:54:21.712111
# Unit test for function parse
def test_parse():
    text1 = """This is the short description.
This is the long description.
It can even be multiple lines long.

Args:
    arg1 (str): Description of arg1.
    arg2 (int): Description of arg2.
    arg3 (Optional[str]): Description of arg3.

Returns:
    str: Description of return value.

Raises:
    ArithmeticError: If n == 0.
"""


# Generated at 2022-06-21 11:54:23.303182
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert len(GoogleParser().parse(None)) == 0



# Generated at 2022-06-21 11:54:32.754909
# Unit test for function parse
def test_parse():
    text = """One-line summary.

    This is a bare-bones docstring with no parameters.
    """
    doc = parse(text)
    assert doc.short_description == "One-line summary."
    assert doc.long_description == "This is a bare-bones docstring with no parameters."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert not doc.meta

    text = """One-line summary.

    This is a bare-bones docstring with no parameters.

    Arguments:
        aaa: aaaaa
            aaaaa aaaaa aaaa
            aaaaa
        bbb: bbbbbb
        ccc: cccccccc
    """
    doc = parse(text)
    assert doc.short_description == "One-line summary."
    assert doc