

# Generated at 2022-06-21 11:45:15.139486
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(TypeError):
        Section()
    with pytest.raises(TypeError):
        Section("title")
    with pytest.raises(TypeError):
        Section("title", "key")
    with pytest.raises(TypeError):
        Section("title", "key", SectionType.MULTIPLE)

    # assert Section("title", "key", SectionType.MULTIPLE)

    assert str(Section("title", "key", SectionType.MULTIPLE)) == "Section(title='title', key='key', type=<SectionType.MULTIPLE: 1>)"



# Generated at 2022-06-21 11:45:23.057640
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:45:31.127334
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    def func1():
        """
        Args:
            arg1 (str): This is arg1's description.

            arg2 (int): This is arg2's description.
            Defaults to 1.

            arg3 (int, optional): This is arg3's description.
            Defaults to 2.

        Returns:
            str: This is return's description.

        Yields:
            str: This is yield's description.

        Raises:
            ValueError: This is ValueError's description.

            KeyError: This is KeyError's description.
        """
        pass


# Generated at 2022-06-21 11:45:40.909523
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .open_api_spec import OpenApiSpec
    from .schemas import Schema
    from .open_api_spec import OpenApiParameter
    from .open_api_spec import OpenApiPath
    from .open_api_spec import OpenApiResponse
    from .open_api_spec import OpenApiSecurity
    from .open_api_spec import OpenApiSecurityRequirement
    from .open_api_spec import OpenApiSecurityScheme
    from .open_api_spec import OpenApiTag
    from .open_api_spec import OpenApiExample

    class A:
        def __init__(self):
            self.r = None


# Generated at 2022-06-21 11:45:42.653421
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True, globs=globals())

# Generated at 2022-06-21 11:45:47.482796
# Unit test for function parse
def test_parse():
    d = docstring_parser.parse(
        """
    A simple example function.
    :param str param1: The first parameter.
    :returns: 
        Returns True if successful, False otherwise
    """
    )
    print(d.short_description)



# Generated at 2022-06-21 11:45:53.685791
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser([Section("Test", "test", SectionType.MULTIPLE)])
    assert parser.sections["Test"].title == "Test"
    assert parser.sections["Test"].key == "test"
    assert parser.sections["Test"].type == 1
    

# Generated at 2022-06-21 11:46:00.984895
# Unit test for function parse
def test_parse():
    text="""
        One line summary.

        Extended description.
        the next line is indented.

        Args:
            arg1 (int): Description of arg1
            arg2 (str): Description of arg2
        """

    def validate_docstring(ds: Docstring):
        assert ds.short_description == 'One line summary.'
        assert ds.long_description == 'Extended description.\nthe next line is indented.'
        assert ds.meta[0].args == ['param', 'arg1']
        assert ds.meta[0].description == 'Description of arg1'
        assert ds.meta[0].arg_name == 'arg1'
        assert ds.meta[0].type_name == 'int'
        assert ds.meta[1].args == ['param', 'arg2']
       

# Generated at 2022-06-21 11:46:13.376392
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test parsing of a Google-style docstring."""
    
    test_google_docstring = """This is a short description.
    
    This is a long description. It contains multiple lines. This is the third line.
    
    Args:
        a (str, optional): Parameter a. Defaults to "a".
        b (str, optional): Parameter b. Defaults to "b".
        c (str, optional): Parameter c. Defaults to "c".
        d (str, optional): Parameter d. Defaults to "d".
    
    Raises:
        TypeError: iff abc.
    
    Returns:
        SimpleType: Return type.
    """

# Generated at 2022-06-21 11:46:19.018326
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    test_section = Section("TEST", "test", SectionType.MULTIPLE)
    parser.add_section(test_section)

    assert parser.sections[test_section.title] == test_section
    assert parser.sections[test_section.title] == test_section


# Generated at 2022-06-21 11:46:42.671282
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.title_colon == True

# Generated at 2022-06-21 11:46:55.678681
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test for case 1:
    # If a section is added and then it is removed it means that the method add_section properly
    # added a section.
    testparser = GoogleParser()
    testparser.add_section(Section("Example", "examples", SectionType.SINGULAR))
    testparser.sections.pop("Example")
    assert not testparser.sections

    # Test for case 2:
    # If the function parse returns the expected result it means that the method add_section
    # properly added a section.
    testparser = GoogleParser()
    testparser.add_section(Section("Example", "examples", SectionType.SINGULAR))
    text = """Example

        Test example"""
    testdocstring = testparser.parse(text)
    assert testdocstring.examples == "Test example"


# Generated at 2022-06-21 11:47:00.406011
# Unit test for function parse
def test_parse():
    text = '''\
    """Single line description.

    This is the long description of this method.

    Attributes:
        a_string: A string that can contain spaces and punctuation
            but no newlines.
        a_list_of_strings: A list of strings where each string can
            contain spaces and punctuation but no newlines. The list
            may not be empty.
    """
    '''
    expected_parsed = """
    a_string: str
        A string that can contain spaces and punctuation
    a_list_of_strings: list of str
        A list of strings where each string can contain
        spaces and punctuation but no newlines. The list
        may not be empty.
    """
    parsed = parse(text)
    print(parsed.short_description)

# Generated at 2022-06-21 11:47:11.035500
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sample_sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
        Section("Params", "param", SectionType.MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
    ]
    parser = GoogleParser(sections = sample_sections)
    expected = OrderedDict()
    for t in sample_sections:
        expected[t.title] = t
    assert parser.sections == expected

# Generated at 2022-06-21 11:47:22.599806
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    #Construcor with no paramaters
    sections = None
    title_colon = True
    gp = GoogleParser(sections, title_colon)

    assert(all(t in gp.titles_re.pattern for t in DEFAULT_SECTIONS))

    #Construcor with no paramaters
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE)]
    title_colon = True
    gp = GoogleParser(sections, title_colon)

    assert(gp.titles_re.pattern == "^(Arguments|Raises):[ \t\r\f\v]*$")


# Generated at 2022-06-21 11:47:34.298732
# Unit test for function parse
def test_parse():
    text = '''
    This is a standard Google-style docstring.

    It extends over multiple lines.

    Args:
        param1: The first parameter.
        param2: The second parameter.
    Returns:
        A value.
    '''

    result = parse(text)
    print(result)
    assert result.short_description == 'This is a standard Google-style docstring.'
    assert result.long_description == 'It extends over multiple lines.'
    assert len(result.meta) == 2
    assert result.meta[0].args == ['param1', 'param2']
    assert result.meta[0].arg_name == 'param1'
    assert result.meta[0].type_name is None
    assert result.meta[0].is_optional is None
    assert result.meta[0].default is None


# Generated at 2022-06-21 11:47:40.056279
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    doc_string = """Description of the function
    Arguments:
        param1: The first parameter.
        param2: The second parameter.
    Returns:
        True if successful, False otherwise.
    """
    parser = GoogleParser()
    parser.add_section(Section("Examples", "examples", SectionType.SINGULAR))
    result = parser.parse(doc_string)
    assert result.meta[-1].args == ["examples"]
    assert result.meta[-1].description is None

# Unit tests for method parse of class GoogleParser

# Generated at 2022-06-21 11:47:46.098862
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test that the constructor works when you pass in no arguments
    GoogleParser()
    # Test that the constructor works when you pass in sections
    sections = [Section("Title", "key", SectionType.MULTIPLE)]
    GoogleParser(sections)
    # Test that the constructor works when you pass in both sections and title_colon
    GoogleParser(sections, True)



# Generated at 2022-06-21 11:47:56.298840
# Unit test for function parse
def test_parse():
    docstring = '''
        Parse the Google-style docstring into its components.

        :returns: parsed docstring
        '''
    expected = {'short_description': 'Parse the Google-style docstring into its components.',
                'long_description': ":returns: parsed docstring",
                'blank_after_short_description': False,
                'blank_after_long_description': False,
                'meta': [DocstringMeta(description=":returns: parsed docstring",
                                       args=["returns"])]
                }
    assert parse(docstring) == expected

# Unit tests for class GoogleParser
# Add a section

# Generated at 2022-06-21 11:47:56.834243
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    pass

# Generated at 2022-06-21 11:48:16.974986
# Unit test for function parse

# Generated at 2022-06-21 11:48:26.594558
# Unit test for function parse
def test_parse():
    text = """
        This is the short description.

        This is the long description.

        Args:
            first_arg (str): First arg.
            second_arg (str, optional): Second arg. Defaults to None.

        Returns:
            long_description (str): First arg.
            short_description (str, optional): Second arg. Defaults to None.

        """
    ds = parse(text)

    assert ds.short_description == "This is the short description."
    assert ds.blank_after_short_description == True
    assert ds.long_description == "This is the long description."
    assert ds.blank_after_long_description == True

    assert len(ds.meta) == 2
    assert ds.meta[0].args == ['param', 'first_arg']
    assert ds

# Generated at 2022-06-21 11:48:34.606191
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    input_text_1 = """
    Google-style docstring parsing.

    Args:
        text: Text to parse.

    Args:
        text: Text to parse.

    Arguments:
        text: Text to parse.

    Parameters:
        text: Text to parse.
    """

    input_text_2 = """
    Google-style docstring parsing.

    Returns:
        Parsed docstring.

    Returns:
        Parsed docstring.

    Return:
        Parsed docstring.

    Return:
        Parsed docstring.
    """

    parser_1 = GoogleParser()
    parser_2 = GoogleParser()

    section_1 = Section("Return", "Returns", SectionType.SINGULAR_OR_MULTIPLE)

# Generated at 2022-06-21 11:48:42.137507
# Unit test for function parse
def test_parse():
    """Function parse() test
    """
    result = parse('This is a docstring.\n\n      This is a long description.\n\n    Args: @param param: This is a parameter. @type param: int. Defaults to None.\n      @param param2: This is a second parameter. @type param2: :obj:`int`\n      @returns: This is a return value.\n      @rtype: int\n      @raises KeyError: Raises an exception')

# Generated at 2022-06-21 11:48:49.211092
# Unit test for constructor of class Section
def test_Section():
    # create a section
    s = Section("Example", "examples", SectionType.SINGULAR)
    assert s.title == "Example"
    assert s.key == "examples"
    assert s.type == SectionType.SINGULAR
    # compare 2 sections
    s1 = Section("Example", "examples", SectionType.SINGULAR)
    s2 = Section("Example", "examples", SectionType.SINGULAR)
    assert s1 == s2


# Generated at 2022-06-21 11:48:52.579770
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser(title_colon=False)
    section = Section("Args", "param", SectionType.MULTIPLE)
    parser.add_section(section)
    assert parser.sections["Args"] == section



# Generated at 2022-06-21 11:49:02.969438
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test method parse() of GoogleParser."""
    if __name__ == "__main__":
        p = GoogleParser()
        d = p.parse("""
            Parse the Google-style docstring into its components.

            :returns: parsed docstring
            """)
        assert str(d) == 'Parse the Google-style docstring into its components.\n\n:returns: parsed docstring\n'
        assert len(d.meta) == 1
        assert d.meta[0].args == ['returns']
        assert str(d.meta[0]) == ':returns: parsed docstring'


# Generated at 2022-06-21 11:49:14.940600
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:49:26.098306
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Dummy(object):
        """Short description.

        Long description for Dummy class.

        Args:
            arg1 (int): Description of arg1. Defaults to 0.
            arg2 (optional, str): Description of arg2. Defaults to None.

        Returns:
            str: Description of return value.

        Raises:
            ValueError: Description of when exception is raised.

        """

        def __init__(self, arg1=0, arg2=None):
            pass

        def do(self, value: float) -> None:
            pass

    docstring = parse(Dummy.__doc__)
    print("Short description:", docstring.short_description)
    print("Long description:", docstring.long_description)

# Generated at 2022-06-21 11:49:28.776970
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_to_parse = 'test_docstring'
    assert parse(docstring_to_parse) == GoogleParser().parse(docstring_to_parse)


# Generated at 2022-06-21 11:49:44.350718
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # set up test data
    text = '''
        This section describes what the function does.

        The first line is brief explanation, which may be completed with
        a longer one. For instance to discuss about its algorithms,
        implementation techniques, etc.

        Args:
            param1(str): Description of `param1`
            param2(:obj:`int`, optional): Description of `param2`
            param3: Description of `param3`
                Defaults to True.

        Returns:
            bool: Description of return value

        Raises:
            AttributeError, KeyError

        '''
    res = parse(text)
    assert res.short_description == 'This section describes what the function does.'

# Generated at 2022-06-21 11:49:55.679463
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    
    
    
    
    
    
    
    
    
    
    
     
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    
    
    
    
    
    
    
    
    
    
    """

    parser = GoogleParser()

# Generated at 2022-06-21 11:49:57.015116
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser is not None


# Generated at 2022-06-21 11:50:09.375278
# Unit test for function parse
def test_parse():
    doc = """
    Find barcodes in a sequence read.

    This function takes a sequence read and tries to find barcodes within it.

    :param str read: The read to search within.
    :param str before: The sequence preceding the barcode.
    :param str after: The sequence following the barcode.
    :returns: The barcode, or None if there is no barcode.
    :raises TypeError: if any of the inputs are lists.
    """
    docstring = parse(doc)
    assert docstring.short_description == 'Find barcodes in a sequence read.'
    assert docstring.long_description == (
        'This function takes a sequence read and tries to find '
        'barcodes within it.'
    )
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after

# Generated at 2022-06-21 11:50:11.693373
# Unit test for constructor of class Section
def test_Section():
    expected = Section("title", "key", "type")
    actual = Section("title", "key", "type")
    assert(expected == actual)


# Generated at 2022-06-21 11:50:23.958664
# Unit test for function parse
def test_parse():
    s = """A short summary.

    This section is blank and should be omitted.

    A long
    description.  It can be multiple paragraphs.
    """

    parsed = parse(s)
    assert parsed.short_description == "A short summary."
    assert parsed.long_description == "A long description. It can be multiple paragraphs."

    s = """A short summary.

    A long
    description.  It can be multiple paragraphs.
    """
    parsed = parse(s)
    assert parsed.short_description == "A short summary."
    assert parsed.long_description == "A long description. It can be multiple paragraphs."

    s = """A short summary.


    A long
    description.  It can be multiple paragraphs.

    """
    parsed = parse(s)
    assert parsed.short_description == "A short summary."


# Generated at 2022-06-21 11:50:27.613276
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert str(GoogleParser().parse('Hello and test_GoogleParser_parse!\n\nA\nB\nC\n').short_description) == 'Hello and test_GoogleParser_parse!'

# Generated at 2022-06-21 11:50:39.704139
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-21 11:50:42.202505
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    assert google_parser.sections is not None
    assert google_parser.title_colon is True
    assert google_parser._setup() is None

# Generated at 2022-06-21 11:50:55.235996
# Unit test for constructor of class Section
def test_Section():
    test_section_1 = Section(title="Args", key="param", type=SectionType.MULTIPLE)
    assert test_section_1.title == "Args"
    assert test_section_1.key == "param"
    assert test_section_1.type == SectionType.MULTIPLE

    test_section_2 = Section(title="Example", key="example", type=SectionType.SINGULAR)
    assert test_section_2.title == "Example"
    assert test_section_2.key == "example"
    assert test_section_2.type == SectionType.SINGULAR

    test_section_3 = Section(title="Raises", key="raises", type=SectionType.MULTIPLE)
    assert test_section_3.title == "Raises"

# Generated at 2022-06-21 11:51:03.279554
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE).title == "Arguments"
    assert Section("Arguments", "param", SectionType.MULTIPLE).key == "param"
    assert Section("Arguments", "param", SectionType.MULTIPLE).type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:51:16.331532
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse("""\
        Args:
            arg_with_type (int): description
            arg_with_no_type: description
            arg_with_default (int, optional): description. Defaults to 42.
        Returns:
            bool: returns true
        """)
    # docstring = GoogleParser().parse("""\
    #     Params:
    #         param_with_type (int): description
    #         param_with_no_type: description
    #         param_with_default (int): description. Defaults to 42.
    #     Returns:
    #         bool: returns true
    #     """)
    print(docstring)
    assert not docstring.short_description
    assert not docstring.blank_after_short_description
    assert not docstring.long_description
   

# Generated at 2022-06-21 11:51:26.377857
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    def test_method(docstring: str, expected: str):
        actual = GoogleParser().parse(docstring)
        assert actual == eval(expected)

    test_method(
        docstring=  """
        Parse the Google-style docstring into its components.

        :returns: parsed docstring
        """,
        expected=  """
        GoogleParser().parse(
            text= """
"""
Parse the Google-style docstring into its components.

:returns: parsed docstring
"""
,
        )

# Generated at 2022-06-21 11:51:35.028308
# Unit test for function parse
def test_parse():
    text = r""" NAME
    An extended summary line.

    DESCRIPTION
        An extended description of the module with paragraphs indicated by
        lines containing a single '.'.  Note:  Indent your description
        with spaces.

        * The first paragraph.
        * The second paragraph.

    KEYWORDS
        First paragraph of description.
        Second paragraph of description.
        The third paragraph.

    RETURNS
        A string giving the current setting of the attribute.

    NOTES
        This is a note.

    EXAMPLES
        Here is an example.

    SEE ALSO
        set, reset.

    AUTHOR(S)
        Name, Age, Date.

    MODIFICATIONS
        Name, Age, Date.
    """
    print(parse(text))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:51:47.278449
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test basic GoogleParser with default sections
    text = """
    This is a short description.

    This is a long description.
    
    Args:
        this (is): a typed argument.
        this (also): a description.
        
        It can contain
        several lines.
        
        It can also have a colon at start of the lines.
    
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'this (is): a typed argument']
   

# Generated at 2022-06-21 11:51:50.499786
# Unit test for constructor of class Section
def test_Section():
    sect = Section("Title", "key", 0) # This should be a valid Section
    assert sect.title == "Title"
    assert sect.key == "key"
    assert sect.type == 0
    try:
        sect.type = 1 # This should throw an error since type is an IntEnum
    except AttributeError:
        pass


# Generated at 2022-06-21 11:52:02.117487
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    def parse(text):
        parser = GoogleParser()
        return parser.parse(text)
    # Test adding section that is not only uppercase
    _ = parse("""
    Section
    ------
    """)
    assert not hasattr(_, "Section")
    parser = GoogleParser()
    parser.add_section(Section("Section", "section", SectionType.SINGULAR_OR_MULTIPLE))
    _ = parse("""
    Section
    ------
    """)
    assert hasattr(_, "section")
    # Test adding section that is not defined in DEFAULT_SECTIONS
    _ = parse("""
    Section2
    ------
    """)
    assert not hasattr(_, "Section2")
    parser = GoogleParser()

# Generated at 2022-06-21 11:52:08.221313
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()

    # Assert that the new section is added correctly,
    # and the section type is recast correctly
    newSection = p.add_section(Section("NewSection", "new_section", SectionType.SINGULAR))
    assert p.sections["NewSection"] == Section("NewSection", "new_section", SectionType.SINGULAR)

    #Assert that the new section is added correctly,
    # and the section type is recast correctly
    newSection = p.add_section(Section("NewSection", "new_section", SectionType.MULTIPLE))
    assert p.sections["NewSection"] == Section("NewSection", "new_section", SectionType.MULTIPLE)

    #Assert that the new section is added correctly,
    # and the section type is recast correctly

# Generated at 2022-06-21 11:52:11.988312
# Unit test for constructor of class Section
def test_Section():
    newSection = Section("Examples", "examples", SectionType.SINGULAR)
    assert newSection.title == "Examples"
    assert newSection.key == "examples"
    assert newSection.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:52:16.408895
# Unit test for function parse
def test_parse():
    """Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """
    return "Unit test for function parse"


# Generated at 2022-06-21 11:52:28.876517
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google = GoogleParser()
    g_sections = google.sections
    if g_sections == None:
        print("the sections that google parser recognized is None")
    else:
        print("the sections that google parser recognized is not None")
    g_title_colon = google.title_colon
    if g_title_colon == None:
        print("the title_colon of google parser is None")
    else:
        print("the title_colon of google parser is not None")
    if g_title_colon == True:
        print("the title_colon of google parser is True")
    else:
        print("the title_colon of google parser is not True")
    if g_title_colon != True:
        print("the title_colon of google parser is not True")
    else:
        print

# Generated at 2022-06-21 11:52:40.809629
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:52:50.333350
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:52:58.063153
# Unit test for function parse
def test_parse():
    # Setup text to parse
    text = """
    This is a test.

    This is a long test.

    Args:
        arg1 (str): The first string.
        arg2 (int): The second number.
    """
    # Parse and check result
    doc = parse(text)
    assert doc.short_description == "This is a test."
    assert doc.long_description == "This is a long test."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "The first string."
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type

# Generated at 2022-06-21 11:53:09.205914
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # First we test for the section `test`
    # We use a `GoogleParser()` object to add it
    parser = GoogleParser()
    parser.add_section(Section("test", "test", SectionType.SINGULAR))
    # We retrive the regex used to find the titles and we check it
    regex = parser.titles_re
    assert re.search(regex, "test:") is not None

    # Then we test to replace the section `test`
    # We use a `GoogleParser()` object to add it
    new_parser = GoogleParser()
    new_parser.add_section(Section("test", "test", SectionType.SINGULAR))
    new_parser.add_section(Section("test", "test_mod", SectionType.SINGULAR_OR_MULTIPLE))
    # We retrive

# Generated at 2022-06-21 11:53:21.372085
# Unit test for function parse
def test_parse():
    text = """
    A short summary of the function's purpose.

    This summary may be used as the short description in the function's
    signature in automatically generated material such as the docstring for
    the pyi file.

    Example:

        Examples can be given using either the ``Example`` or ``Examples``
        sections. Sections support any reStructuredText formatting, including
        literal blocks::

            $ python example_google.py

    Parameters
    ----------
    param1 : int, optional
        The first parameter.
    param2 : str
        The second parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.

    """

# Generated at 2022-06-21 11:53:27.689392
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    assert "Args" in p.sections.keys()
    assert "Arguments" in p.sections.keys()
    s = Section("ARG", "arg", SectionType.MULTIPLE)
    p.add_section(s)
    assert "ARG" in p.sections.keys()
    assert "arg" in p.sections.keys()
    assert "Args" not in p.sections.keys()
    assert "Arguments" not in p.sections.keys()


# Generated at 2022-06-21 11:53:36.188914
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('') == Docstring()
    assert parse('\n') == Docstring()
    assert parse(' ') == Docstring()
    example_docstring = """Description of example.

        Args:
            arg1 (int): Description of arg1.
            arg2 (str): Description of arg2.
            arg3: Description of arg3.
            arg4: Description of arg4.

        Raises:
            ValueError: Description of exception.
            TypeError: Description of exception.

        Examples:
            Examples should be written in doctest format, and should illustrate how
            to use the function/class.

            >>> print([i for i in example_generator(4)])
            [0, 1, 2, 3]

        """
    example_parsed = parse(example_docstring)
    assert example_parsed

# Generated at 2022-06-21 11:53:48.586741
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert list(GoogleParser().sections.keys()) == [
        "Example",
        "Examples",
        "Except",
        "Exception",
        "Exceptions",
        "Args",
        "Arguments",
        "Attributes",
        "Params",
        "Parameters",
        "Raises",
        "Returns",
        "Yields",
    ]
    assert list(GoogleParser(title_colon=False).sections.keys()) == [
        "Example",
        "Examples",
        "Except",
        "Exception",
        "Exceptions",
        "Args",
        "Arguments",
        "Attributes",
        "Params",
        "Parameters",
        "Raises",
        "Returns",
        "Yields",
    ]

# Generated at 2022-06-21 11:53:53.820007
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections_prior_add = DEFAULT_SECTIONS
    parser = GoogleParser()
    assert parser.sections == sections_prior_add
    test_section = Section("THISISATEST", "param", SectionType.SINGULAR)
    parser.add_section(test_section)
    sections_post_add = parser.sections
    sections_post_add.append(test_section)
    assert parser.sections == sections_post_add


# Generated at 2022-06-21 11:54:11.243103
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test_1: Test add_section function of class GoogleParser
    # Given
    # a GoogleParser object
    # a new section
    # When
    # add_section method is called
    # Then
    # object of GoogleParser has a section
    sections = [Section("Section", "test", SectionType.SINGULAR)]
    test_GoogleParser = GoogleParser(sections)
    assert "Section" in test_GoogleParser.sections

    # Test_2: Test add_section function of class GoogleParser
    # Given
    # a GoogleParser object
    # a new section
    # When
    # add_section method is called
    # Then
    # object of GoogleParser has a section
    sections = [Section("Section", "test", SectionType.SINGULAR)]
    test_GoogleParser = GoogleParser(sections)
    section_A

# Generated at 2022-06-21 11:54:14.417329
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    p.add_section(Section(title="foo", key="foo", type=0))
    assert p.sections["foo"] == Section(title="foo", key="foo", type=0)


# Generated at 2022-06-21 11:54:16.273149
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    a = GoogleParser()
    assert a

# Generated at 2022-06-21 11:54:26.826491
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    doc_text = '''\
-A document for a function or method.

    :param param1: this is a first param
    :param param2: this is a second param
    :returns: description of return
    :raises keyError: raises an exception
    '''
    doc = GoogleParser().parse(doc_text)

    # Test short description
    assert doc.short_description == '-A document for a function or method.'

    # Test blank after short description
    assert doc.blank_after_short_description == False

    # Test blank after long description
    assert doc.blank_after_long_description == False

    # Test long description
    assert doc.long_description == 'this is a first param'

    return doc

# Generated at 2022-06-21 11:54:29.349787
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser(sections = [Section("Example", "examples", 0)])
    assert len(parser.titles_re.findall('Example')) == 1

# Generated at 2022-06-21 11:54:33.922158
# Unit test for function parse
def test_parse():
    text = """\
    Short description.

    Long description.

    Args:
        arg1 (str): Some parameter. Defaults to None.

    Example:
        Usage::

            obj = MyClass(arg1=10, arg2=20)

            obj.my_method(arg1=10, arg2=20)

    Returns:
        the result

    Yields:
        the result
    """
    print(parse(text))


if __name__ == "__main__":
    test_parse()