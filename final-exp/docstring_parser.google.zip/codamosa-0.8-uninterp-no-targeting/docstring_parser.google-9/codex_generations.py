

# Generated at 2022-06-21 11:45:07.558480
# Unit test for constructor of class Section
def test_Section():
    my_section = Section("Attribute", "attribute", SectionType.MULTIPLE)
    assert my_section.title == "Attribute"
    assert my_section.key == "attribute"
    assert my_section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:45:12.916600
# Unit test for constructor of class Section
def test_Section():
    section = Section(title = "TESTTESTTEST", key = "TESTTESTTEST", type = SectionType.MULTIPLE)
    assert section.title == "TESTTESTTEST"
    assert section.key == "TESTTESTTEST"
    assert section.type == SectionType.MULTIPLE
    return


# Generated at 2022-06-21 11:45:22.405166
# Unit test for function parse
def test_parse():
    long_doc = """This is a long description.
    
    And a second paragraph.
    
    """

    def test_docstring(text, **kwargs):
        """Helper function for testing parse.
        
        :param text: The text to put in the docstring.
        :param kwargs: Keyword arguments to pass to assertEqual.
        :returns: The parsed docstring.
        """
        d = Docstring(**kwargs)
        result = parse(text)
        assertEqual(d, result)
        return result

    # Test the basic structure with short and long descriptions
    test_docstring(
        """Short description.
        """ + long_doc,
        long_description=long_doc.strip()
    )

    # Test indent

# Generated at 2022-06-21 11:45:28.172359
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """
    This is an example docstring explanation.

    Args:
        param1: The first parameter.
        param2: The second parameter.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.
        file (str): This is a str. Defaults to None.
    """
    )

    assert docstring.long_description == "This is an example docstring explanation."
    assert docstring.short_description == "This is an example docstring explanation."

# Generated at 2022-06-21 11:45:30.273566
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    title_colon=True
    sections = DEFAULT_SECTIONS
    GoogleParser(sections,title_colon)



# Generated at 2022-06-21 11:45:31.057182
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    pass



# Generated at 2022-06-21 11:45:35.229899
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert (GoogleParser().titles_re.pattern ==
            "^("
            + "|".join("(%s)" % t for t in DEFAULT_SECTIONS)
            + ")"
            + ":"
            + "[ \t\r\f\v]*$")


# Generated at 2022-06-21 11:45:45.723162
# Unit test for function parse
def test_parse():
    def my_func(v1: int, v2: T.List[int] = None, v3: int = 3) -> None:
        """
        Describe the function a bit. This is sometimes called the "summary
        line" of the documentation string.

        Parameters
        ----------
        v1: int
            A required argument.
        v2:
            An optional argument.
        v3: int
            Another required argument.
        Returns
        -------
        None
        """
        pass

    doc = parse(inspect.getdoc(my_func))

    assert doc.short_description == "Describe the function a bit."
    assert doc.long_description == (
        "This is sometimes called the \"summary line\" of "
        "the documentation string."
    )
    assert doc.blank_after_short_description
   

# Generated at 2022-06-21 11:45:51.124353
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser_instance = GoogleParser()
    test_section = Section("Test", "test", SectionType.SINGULAR)
    google_parser_instance.add_section(test_section)
    assert test_section in google_parser_instance.sections.values()


# Generated at 2022-06-21 11:45:59.542065
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    #Test case 1: sections is None and title_colon is True
    p1 = GoogleParser()

# Generated at 2022-06-21 11:46:13.179953
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Parser for Google-style docstrings.

    Doctring looks like::

      Short description.

      Extended description.

      Args:
        arg1: First argument.
        arg2: Second argument.

      Returns:
        Boolean.

      Raises:
        ValueError: if something bad happened.
    """
    parsed = GoogleParser().parse(text)
    assert parsed.short_description == "Parser for Google-style docstrings."
    assert len(parsed.meta) == 4
    assert isinstance(parsed.meta[1], DocstringReturns)
    assert isinstance(parsed.meta[2], DocstringRaises)

# Generated at 2022-06-21 11:46:23.572865
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''\
        def foo(arg):
            '''
    parser = GoogleParser()
    ret = parser.parse(text)
    assert ret.short_description == 'def foo(arg):'
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == False
    assert ret.long_description == None

    text = '''\
        def foo(arg):
            """
            This is a description

            """
            '''
    parser = GoogleParser()
    ret = parser.parse(text)
    assert ret.short_description == 'def foo(arg):'
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == False
    assert ret.long_description == None


# Generated at 2022-06-21 11:46:32.674306
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import RETURNS, RETURNS_TYPE, RETURNS_TYPE_OPTIONAL, \
        RETURNS_AND_YIELDS, RETURNS_AND_YIELDS_OPTIONAL, RETURNS_OR_RAISES, \
        RETURNS_OR_RAISES_OPTIONAL, RETURNS_AND_RAISES, RETURNS_AND_RAISES_OPTIONAL,\
        EXAMPLE, EXAMPLE_OPTIONAL, EXAMPLES, EXAMPLES_OPTIONAL, PARAM, PARAM_OPTIONAL, \
        PARAMS, PARAMS_OPTIONAL, RAISES, RAISES_OPTIONAL, ATTRIBUTE, ATTRIBUTE_OPTIONAL, \
        EXCEPT, EXCEPT_OPTIONAL, ARGUM

# Generated at 2022-06-21 11:46:42.631212
# Unit test for function parse
def test_parse():
    assert parse(__doc__).short_description == "Google-style docstring parsing."
    docstring = "Test\n\nCollection:\n    First item\n    Second item\n"
    assert parse(docstring).meta[0].description == "First item"
    assert parse(docstring).meta[1].description == "Second item"
    docstring = "Test\n\nExample:\n    Collection:\n        First item\n        Second item\n"
    assert parse(docstring).meta[0].description == "First item"
    docstring = "Test\n\nExample:\n    Collection:\nFirst item\nSecond item\n"
    assert parse(docstring).meta[0].description == "Collection:\nFirst item\nSecond item"

# Generated at 2022-06-21 11:46:55.608399
# Unit test for function parse
def test_parse():
    s = """Split address into parts.

    Addresses are split into local and domain parts.

    Example:
        >>> import email.utils
        >>> email.utils.parseaddr('a@b.com')
        ('a', 'b.com')
        >>> email.utils.parseaddr('"a"@b.com')
        ('a', 'b.com')
        >>> email.utils.parseaddr('"a" <a@b.com>')
        ('a', 'b.com')
        >>> email.utils.parseaddr('"a (1)" <a@b.com>')
        ('a (1)', 'b.com')
        >>> email.utils.parseaddr('<a@b.com>')
        ('', 'b.com')

    """
    d = parse(s)
    print(d)
   

# Generated at 2022-06-21 11:46:59.473717
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    s = Section("New Section", "new_section", SectionType.MULTIPLE)
    g.add_section(s)
    assert g.sections["New Section"] == s


# Generated at 2022-06-21 11:47:06.307246
# Unit test for constructor of class Section
def test_Section():
    # Test 1
    assert Section("Title", "key", SectionType.SINGULAR) == Section("Title", "key", 0)

    # Test 2
    assert Section("Title", "key", SectionType.MULTIPLE) == Section("Title", "key", 1)

    # Test 3
    assert Section("Title", "key", SectionType.SINGULAR_OR_MULTIPLE) == Section("Title", "key", 2)



# Generated at 2022-06-21 11:47:14.299582
# Unit test for function parse
def test_parse():
    """Test the parse() function."""
    with pytest.raises(ParseError):
        parse("")

    assert parse("Hi") == Docstring("Hi", None, None, False, False)

    text = """
        Hi.

        Long description.

        """
    assert parse(text) == Docstring("Hi.", None, "Long description.", True, False)

    assert (
        parse("Hi.\nLong description.\n")
        == Docstring("Hi.", None, "Long description.", False, False)
    )

    text = """
        Hi.

        Long description.

        Arguments:
          foo (str): Foo bar.

          baz (bool): Baz bar.
        """

# Generated at 2022-06-21 11:47:27.353869
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    # Default values for class GoogleParser
    assert gp.sections == {s.title: s for s in DEFAULT_SECTIONS}
    assert gp.title_colon == True

    # If take no parameter, then all other attributes should be the same as
    # the default values.
    assert gp.titles_re.pattern == "^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields):[ \t\r\f\v]*$"

    # if input title_colon = False, titles_re should be different
    gp = GoogleParser(title_colon = False)

# Generated at 2022-06-21 11:47:37.734462
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("Hello\n") == Docstring(
        short_description="Hello"
    )
    assert parse("Hello\n\nHi\nHola") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        long_description="Hi\nHola",
        blank_after_long_description=False,
    )
    assert parse("Hello\n\nHi\nHola\n") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        long_description="Hi\nHola",
        blank_after_long_description=True,
    )

# Generated at 2022-06-21 11:47:52.931915
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = inspect.getdoc(GoogleParser)
    assert doc
    #print(doc)
    import string
    google_doc = string.Template(doc).substitute(name='str', returns='str', raises='str', title='str', key='str', type='str')
    #print(google_doc)
    doc2 = Parse.parse(google_doc)
    #print(dir(doc2))
    #print(doc2.short_description)
    #print(doc2.long_description)
    #print(doc2.meta)
    #print(doc2.meta.args)
    #print(doc2.meta.description)
    #print(doc2.meta.arg_name)
    #print(doc2.meta.type_name)
    #print(doc2.meta.is_optional)

# Generated at 2022-06-21 11:48:01.549154
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:48:13.280906
# Unit test for function parse
def test_parse():
    """Test the docstring parsing function.

    :returns: True if the test succeeds
    :rtype: bool
    """

    def test_func(text, expected_meta):
        """
        Test the parser on a given text and compare the result.

        :param text: The text of the docstring to parse.
        :param expected_meta: The expected parsed docstring.
        :return: True if the test succeeds
        :rtype: bool
        """
        p = GoogleParser()
        # noinspection PyProtectedMember
        actual = p._build_meta(text, "Example")

        if actual != expected_meta:
            print(
                "Meta mismatch for %s, got %s but expected %s."
                % (text, actual, expected_meta)
            )
            return False


# Generated at 2022-06-21 11:48:19.525434
# Unit test for constructor of class Section
def test_Section():
    section1 = Section("type", "key", 1)
    section2 = Section("param", "param", 1)
    sections = [section1, section2]
    # Test for constructor of class Section
    try:
        GoogleParser(sections)
    except KeyError:
        pass
    except Exception:
        raise


# Generated at 2022-06-21 11:48:28.113970
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("One-line description") == Docstring(
        short_description="One-line description"
    )
    assert parse("One-line description\n") == Docstring(
        short_description="One-line description", blank_after_short_description=True
    )
    assert parse("One-line description\n\n") == Docstring(
        short_description="One-line description", blank_after_short_description=True
    )

    assert parse("One-line description\nLong description") == Docstring(
        short_description="One-line description",
        blank_after_short_description=True,
        long_description="Long description",
    )

# Generated at 2022-06-21 11:48:35.833688
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:48:46.981678
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""
    test_docstring = dedent("""\
    Single-line description.

    Long description.

    Examples:
        Examples section.
        Could be multiple paragraphs.

    Args:
        Positional args.
        `arg1` (str): Argument description.

    Returns:
        Return value.

    Raises:
        Exception
        AttributeError
        ValueError
    """)
    parser = GoogleParser()
    parser_result = parser.parse(test_docstring)
    assert parser_result.short_description == "Single-line description."
    assert parser_result.long_description == "Long description."
    assert parser_result.blank_after_short_description == True
    assert parser_result.blank_after_long_description == False

# Generated at 2022-06-21 11:48:57.820602
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleparser = GoogleParser()
    assert googleparser.sections == {s.title:s for s in DEFAULT_SECTIONS}
    assert googleparser.title_colon == True

    sections2 = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
    ]
    googleparser2 = GoogleParser(sections2)
    assert googleparser2.sections == {s.title:s for s in sections2}
    assert googleparser2.title_colon == True


# Generated at 2022-06-21 11:49:02.803791
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]

    # constructor without sections
    p = GoogleParser()
    assert p.title_colon
    assert p.sections == {section.title: section for section in DEFAULT_SECTIONS}

    # constructor with sections
    p = GoogleParser(sections)
    assert p.sections == {section.title: section for section in sections}



# Generated at 2022-06-21 11:49:05.662628
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Arguments", "param", SectionType.MULTIPLE)
    assert sec.title == "Arguments"
    assert sec.key == "param"
    assert sec.type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:49:21.701267
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print(GoogleParser().sections.__class__)
#Unit test for method of class GoogleParser

# Generated at 2022-06-21 11:49:30.303614
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    check = GoogleParser()
    check.add_section(Section("A", "param", SectionType.MULTIPLE))
    check.add_section(Section("B", "param", SectionType.MULTIPLE))
    check.add_section(Section("C", "param", SectionType.MULTIPLE))
    assert check.sections["A"] == Section("A", "param", SectionType.MULTIPLE)
    assert check.sections["B"] == Section("B", "param", SectionType.MULTIPLE)
    assert check.sections["C"] == Section("C", "param", SectionType.MULTIPLE)


# Generated at 2022-06-21 11:49:37.704561
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section('Name', 'name', SectionType.SINGULAR))
    text = (
        "Name:\n"
        "\n"
        "    test_function\n"
    )
    assert gp.parse(text).meta[0].arg_name == 'name'
    assert gp.parse(text).meta[0].description == 'test_function'



# Generated at 2022-06-21 11:49:38.745183
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """returns:
        - parsed docstring
    """
    assert 2+2 == 4



# Generated at 2022-06-21 11:49:42.506561
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    f = open("demo.txt", "r")
    text = f.read()
    f.close()

    docstring = parse(text)

    print(docstring)

test_GoogleParser_parse()

# Generated at 2022-06-21 11:49:50.797472
# Unit test for function parse
def test_parse():
    text='''
    This is the doc string for a test function.
    
    Here is a long description for the test function.
    
    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Raises:
        ValueError: If any argument is None.
    
    Returns:
        The return value. True for success, False otherwise.
    '''
    print(parse(text))


# Generated at 2022-06-21 11:49:54.014034
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:49:57.860810
# Unit test for function parse
def test_parse():
    text = """The function inspects the kwargs and returns the appropriate class based on kwargs"""
    ret = parse(text)
    print(ret)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:50:08.617535
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    :rtype: dict
    """
    gd = GoogleParser().parse(text)
    assert gd.short_description == "Parse the Google-style docstring into its components."
    assert gd.long_description is None
    assert gd.blank_after_short_description == False
    assert gd.blank_after_long_description == False

    assert type(gd.meta[0]) == DocstringReturns
    assert gd.meta[0].description == "parsed docstring"
    assert gd.meta[0].type_name == None

# Generated at 2022-06-21 11:50:15.813800
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    assert(google_parser.title_colon == True)

# Generated at 2022-06-21 11:50:28.805935
# Unit test for constructor of class Section
def test_Section():
    s = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    # s is not None
    assert s is not None
    # test class attributes
    assert s.title == "Returns"
    assert s.key == "returns"
    assert s.type == SectionType.SINGULAR_OR_MULTIPLE


# Generated at 2022-06-21 11:50:40.439413
# Unit test for function parse
def test_parse():
    teststr = """\
Blah blah blah.

Args:
    arg1 (int): blah blah.
    arg2 (:obj:`str`, optional): blah. Defaults to 'blah'.
    arg3 (str): blah [blah].

Returns:
    int: Returns 5.

Raises:
    ValueError: If `arg2` is equal to `arg1`.

"""
    teststr2 = """\
Blah blah blah.

Args:
    arg1 (int): blah blah.

Returns:
    int: Returns 5.

Raises:
    ValueError: If `arg2` is equal to `arg1`.

"""
    d = parse(teststr)
    print(d)
    assert len(d.meta) == 5

# Generated at 2022-06-21 11:50:53.496720
# Unit test for function parse
def test_parse():
    assert parse("""\
    Short description.
    """) == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    assert parse("""\
    Short description.

    Long description.
    """) == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
        meta=[],
    )


# Generated at 2022-06-21 11:50:55.233227
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    assert (
        g.sections["Args"] == Section("Args", "param", SectionType.MULTIPLE)
    )

# Generated at 2022-06-21 11:51:02.789513
# Unit test for function parse
def test_parse():
    parser = GoogleParser([
        Section("Args", "arg", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
        Section("Returns", "return", SectionType.SINGULAR),
    ])
    docstring = """
    Short summary.

    Long description.

    Args:
      arg1(int): First arg.
      arg2(str): Second arg.

    Parameters:
      param1(int): First param.
      param2(str): Second param.

    Returns:
      int: Some number.
    """
    parsed = parser.parse(docstring)
    assert parsed.short_description == "Short summary."
    assert parsed.long_description == "Long description."
    assert parsed.blank_after_short_description
    assert not parsed.blank_after_long_

# Generated at 2022-06-21 11:51:15.771939
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """
    replace_non_breaking_space(self, text)
    Replace non-breaking spaces by normal spaces.

    :param text:
        The text to be processed.
    :type text: str
    :returns: The processed text.
    :rtype: str

    """

# Generated at 2022-06-21 11:51:18.219338
# Unit test for constructor of class Section
def test_Section():
    assert Section("Example", "examples", SectionType.SINGULAR)
    # __new__(Section,...)
    # __init__(Section,...)


# Generated at 2022-06-21 11:51:28.038321
# Unit test for function parse
def test_parse():
    doc_string = """
    This function prints out the docstring of a function.

    This can be used to easily test parse functions.

    :param text: docstring
    :type text: str
    :param indent: indent of the docstring
    :type indent: int
    :returns: parsed docstring
    """
    parsed_doc_string = parse(doc_string)
    assert parsed_doc_string.short_description == "This function prints out the docstring of a function."
    assert parsed_doc_string.long_description == "This can be used to easily test parse functions."
    assert parsed_doc_string.blank_after_long_description == True
    assert parsed_doc_string.blank_after_short_description == False
    assert parsed_doc_string.meta[0].description == "param text: docstring"
   

# Generated at 2022-06-21 11:51:35.512222
# Unit test for constructor of class Section
def test_Section():
    """Test the constructor of class Section."""

    a = Section("Arguments", "param", SectionType.MULTIPLE)
    assert a.title == "Arguments"
    assert a.key == "param"
    assert a.type == SectionType.MULTIPLE

    b = Section("Raises", "raises", SectionType.MULTIPLE)
    assert b.title == "Raises"
    assert b.key == "raises"
    assert b.type == SectionType.MULTIPLE

    c = Section("Example", "example", SectionType.SINGULAR)
    assert c.title == "Example"
    assert c.key == "example"
    assert c.type == SectionType.SINGULAR



# Generated at 2022-06-21 11:51:39.725427
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    goog_parser = GoogleParser()
    assert goog_parser.title_colon == True
    assert 'Args' in goog_parser.sections
    assert 'Returns' in goog_parser.sections


# Generated at 2022-06-21 11:51:49.803301
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section('Bob', 'Bob', 3))
    assert gp.sections['Bob'].title == 'Bob'


# Generated at 2022-06-21 11:51:57.145126
# Unit test for function parse
def test_parse():
    class Foo:
        """Short description

        Long description
        """

    foo = Foo()
    docstring = parse(inspect.getdoc(foo))
    print(docstring)
    assert docstring.short_description == "Short description"
    assert docstring.long_description == "Long description"
    assert docstring.meta == []

    class Foo:
        """Short description

        Long description

        Args:
            arg_one (str): The first argument.
            arg_two (int): The second argument.
        """

    foo = Foo()
    docstring = parse(inspect.getdoc(foo))
    print(docstring)
    assert docstring.short_description == "Short description"
    assert docstring.long_description == "Long description"
    assert len(docstring.meta) == 2
    assert doc

# Generated at 2022-06-21 11:52:07.670320
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    if __name__ == '__main__':
        with open("test.py", "r") as file:
            docstr = file.read()
            parsed = GoogleParser().parse(docstr)
            print(parsed)
            print("\n")
            print("Short description:", parsed.short_description)
            print("Long description:", parsed.long_description)
            print("Blank after short description:", parsed.blank_after_short_description)
            print("Blank after long description:", parsed.blank_after_long_description)
            for meta in parsed.meta:
                print("\nMeta data:")
                print("Args:", meta.args)
                print("Description:", meta.description)

# Generated at 2022-06-21 11:52:20.906227
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("A short description.") == Docstring(
        short_description="A short description.",
        blank_after_short_description=False
    )
    assert parse("\nA short description.") == Docstring(
        short_description="A short description.",
        blank_after_short_description=True
    )
    assert parse("A short description.\n") == Docstring(
        short_description="A short description.",
        blank_after_short_description=True
    )
    assert parse(
        """A short description.

        A long description.

        """
    ) == Docstring(
        short_description="A short description.",
        long_description="A long description.",
        blank_after_long_description=True,
        blank_after_short_description=True
    )

# Generated at 2022-06-21 11:52:25.252099
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Parse the Google-style docstring into its components.

    :param text: docstring
    :returns: parsed docstring
    :rtype: `MyDocstring`
    :raises ValueError: if something bad happens
    '''
    assert isinstance(GoogleParser().parse(text), Docstring)


# Generated at 2022-06-21 11:52:31.601028
# Unit test for function parse
def test_parse():
    docstring = """A docstring.

    Args:
        arg1: arg1 description. Defaults to None.
        arg2: arg2 description.
        arg3: arg3 description.
    """
    docstring = parse(docstring)
    assert docstring.short_description == 'A docstring.'
    assert len(docstring.meta) == 3


# Generated at 2022-06-21 11:52:43.143883
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-21 11:52:52.092679
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser([Section("MySection", "mysection", SectionType.SINGULAR)])
    assert str(g.sections["MySection"]) == "Section(title='MySection', key='mysection', type=<SectionType.SINGULAR: 0>)"
    g = GoogleParser([Section("MySection", "mysection", SectionType.MULTIPLE)])
    assert str(g.sections["MySection"]) == "Section(title='MySection', key='mysection', type=<SectionType.MULTIPLE: 1>)"
    g = GoogleParser([Section("MySection", "mysection", SectionType.SINGULAR_OR_MULTIPLE)])

# Generated at 2022-06-21 11:53:00.240302
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def foo():
        """This is a docstring.

        :param int x: The x-coordinate.
        :param int y: The y-coordinate.
        :return: The sum of x and y.
        """
        return 1

    result = GoogleParser().parse(foo.__doc__)
    assert result.meta[0].arg_name == "x"
    assert result.meta[0].description == "The x-coordinate."
    assert result.meta[1].arg_name == "y"
    assert result.meta[1].description == "The y-coordinate."
    assert result.meta[2].description == "The sum of x and y."

# Build a class to run unit tests.

# Generated at 2022-06-21 11:53:11.167873
# Unit test for function parse
def test_parse():
    from . import common

    val = """This function does something.

Args:
    arg1 (int): The first argument.
    arg2 (:obj:`list` of :obj:`str`): The second argument.
    arg3 (:obj:`str`, optional): The third argument.
        Defaults to "foo".

Returns:
    bool: The return value. True for success, False otherwise.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.

"""

#     print(val)

    #print(parse(val))

    ret = parse(val)
    assert ret.short_description == "This function does something."
    assert ret.long_description == ""

# Generated at 2022-06-21 11:53:29.129846
# Unit test for constructor of class Section
def test_Section():
    print(Section("Arguments", "param", SectionType.MULTIPLE))
    print(Section("Args", "param", SectionType.MULTIPLE))
    print(Section("Parameters", "param", SectionType.MULTIPLE))
    print(Section("Params", "param", SectionType.MULTIPLE))
    print(Section("Raises", "raises", SectionType.MULTIPLE))
    print(Section("Exceptions", "raises", SectionType.MULTIPLE))
    print(Section("Except", "raises", SectionType.MULTIPLE))
    print(Section("Attributes", "attribute", SectionType.MULTIPLE))
    print(Section("Example", "examples", SectionType.SINGULAR))
    print(Section("Examples", "examples", SectionType.SINGULAR))
    print

# Generated at 2022-06-21 11:53:36.459973
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """
    Test GoogleParser class constructor
    """
    GP = GoogleParser()

# Generated at 2022-06-21 11:53:48.928520
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Returns the index of the first item in seq that
    returns true for pred, or -1 if none does."""
    assert GoogleParser().parse(docstring).long_description == docstring

    docstring = """
    :param str a: Test string to check.
    :param str b: Another string to check.
    :returns: True if strings match, else False.
    """
    parser = GoogleParser()
    assert parser.parse(docstring).meta[0].arg_name == 'a'
    assert parser.parse(docstring).meta[0].description == 'Test string to check.'

    docstring = """
    :param str a: Test string to check.
    :param str b: Another string to check.
    :returns: True if strings match, else False.
    """
    parser = GoogleParser()


# Generated at 2022-06-21 11:53:49.561733
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    g = GoogleParser()




# Generated at 2022-06-21 11:53:51.933011
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) == Section("Arguments", "param", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:53:55.452454
# Unit test for constructor of class Section
def test_Section():
    section = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert section.title == "Returns"
    assert section.key == "returns"
    assert section.type == SectionType.SINGULAR_OR_MULTIPLE

# Generated at 2022-06-21 11:54:07.061971
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Paragraph","paragraph",SectionType.SINGULAR)
    parser.add_section(section)
    section = Section("Paragraphs","paragraphs",SectionType.MULTIPLE)
    parser.add_section(section)
    section = Section("Paragraph-as-Singular-or-Multiple","paragraph_s_m",
                      SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(section)

# Generated at 2022-06-21 11:54:16.639583
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test a section without colon in title
    new_section = Section("Title", "key", SectionType.SINGULAR)
    parser = GoogleParser(title_colon=False)
    parser.add_section(new_section)
    assert new_section.title in parser.sections
    assert parser.sections[new_section.title] == new_section

    # Test a section with colon in title
    new_section = Section("Section:", "key", SectionType.SINGULAR)
    parser = GoogleParser(title_colon=True)
    parser.add_section(new_section)
    assert new_section.title in parser.sections
    assert parser.sections[new_section.title] == new_section

    # Test replacing a section
    new_section = Section("Section", "key", SectionType.SINGULAR)
   

# Generated at 2022-06-21 11:54:28.362220
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    title_colon = True
    parser = GoogleParser(sections, title_colon)
    assert parser.sections == {"Arguments": Section("Arguments", "param", SectionType.MULTIPLE)}
    assert parser.title_colon == True
    assert parser._build_meta("text", "title") == DocstringMeta(args=['title', 'text'], description='')
    assert parser._build_single_meta(Section("Returns", "returns", SectionType.SINGULAR), "text") == DocstringReturns(args=['returns'], type_name=None, description='text', is_generator=False)

# Generated at 2022-06-21 11:54:35.228266
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Instanciate a GoogleParser object
    parser = GoogleParser()

    docstring = """
    Short one line summary.

    More detailed summary which may include multiple paragraphs.
    """
    
    ret_parse = parser.parse(docstring)
    assert ret_parse.short_description == "Short one line summary."
    assert ret_parse.long_description == """
    More detailed summary which may include multiple paragraphs.
    """.strip()
    assert ret_parse.blank_after_short_description
    assert ret_parse.blank_after_long_description
    
    docstring = """
    Short one line summary.

    More detailed summary which may include multiple paragraphs.
    """

    ret_parse = parser.parse(docstring)
    assert ret_parse.short_description == "Short one line summary."