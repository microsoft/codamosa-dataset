

# Generated at 2022-06-21 11:45:26.680391
# Unit test for function parse
def test_parse():
    doc = parse.__doc__
    # parse(text: str) -> Docstring:
    #     """Parse the Google-style docstring into its components.
    #
    #     :returns: parsed docstring
    #     """
    result = parse(doc)
    assert result.short_description == 'Parse the Google-style docstring into its components.'
    assert result.long_description == '\n:returns: parsed docstring'
    assert result.blank_after_short_description and result.blank_after_long_description
    assert len(result.meta) == 0
    # parse(text: str) -> Docstring:
    #     """Parse the Google-style docstring into its components.
    #     :returns: parsed docstring
    #     """
    result = parse(doc)

# Generated at 2022-06-21 11:45:31.320259
# Unit test for constructor of class Section
def test_Section():
    # class Section is defined as a named tuple
    # 'title' is the title of the section
    # 'key' is the keyword for the section
    # 'type' is the type of the section
    section = Section(title='test_title', key='test_key', type=1)
    assert section.title == 'test_title'
    assert section.key == 'test_key'
    assert section.type == 1


# Generated at 2022-06-21 11:45:34.499891
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Example", "examples", SectionType.SINGULAR)
    parser.add_section(section)
    assert parser.sections["Example"] == section


# Generated at 2022-06-21 11:45:45.130403
# Unit test for constructor of class Section
def test_Section():
    line = "Args: argname (type), optional."
    assert GOOGLE_TYPED_ARG_REGEX.match(line).group(1) == "argname"
    assert GOOGLE_TYPED_ARG_REGEX.match(line).group(2) == "type,"
    assert GOOGLE_ARG_DESC_REGEX.match(line).group(1) == "optional."
    # assert GoogleParser.parse("Args: argname (type), optional.\n\tDefault to 1.")
    # assert GoogleParser.parse("Raises: A (Exception) if a > 2\n")

    assert Section("Args", "param", SectionType.MULTIPLE) == Section("Args", "param", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:45:52.788743
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("New", "new", SectionType.SINGULAR)
    assert parser.parse("New:\n\n    description") is None
    assert parser.sections[section.title] != section
    parser.add_section(section)
    assert parser.sections[section.title] == section
    assert "new" in parser.parse("New:\n\n    description")

# Generated at 2022-06-21 11:46:00.576793
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
    Parameters
    ----------
    fname : str
        Name of the file.
    file : file object, optional
        File object to save or read.

    Returns
    -------
    Numpy array.

    Raises
    ------
    ValueError
        If `fname` or `file` are not provided.

    """
    parser = GoogleParser()
    parser.add_section(
        Section("Raises", "raises", SectionType.MULTIPLE)
    )
    docstring = parser.parse(text)
    assert docstring.meta[0].key == "param"
    assert docstring.meta[1].key == "param"
    assert docstring.meta[2].key == "returns"
    assert docstring.meta[3].key == "raises"



# Generated at 2022-06-21 11:46:02.015583
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert isinstance(GoogleParser(), GoogleParser)

# Generated at 2022-06-21 11:46:12.477982
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    instance = GoogleParser()
    instance.add_section(Section("MyTitle", "mykey", SectionType.SINGULAR))
    assert instance.sections['MyTitle'].title == 'MyTitle'
    assert instance.sections['MyTitle'].key == 'mykey'
    assert instance.sections['MyTitle'].type == SectionType.SINGULAR
    instance.add_section(Section("MyTitle", "mykey", SectionType.SINGULAR))
    assert instance.sections['MyTitle'].title == 'MyTitle'
    assert instance.sections['MyTitle'].key == 'mykey'
    assert instance.sections['MyTitle'].type == SectionType.SINGULAR


# Generated at 2022-06-21 11:46:23.145032
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:46:25.624961
# Unit test for constructor of class Section
def test_Section():
    s = Section('title', 'key', SectionType.SINGULAR)
    assert s.title == 'title'
    assert s.key == 'key'
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:47:22.955674
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse("""\
        This is description

        Args:
            arg1 (str): Argument description
            arg2 (str, optional): Argument description.

        Returns:
            This part is returned

        Raises:
            ValueError: ValueError description
            KeyError: KeyError description

        Attributes:
            attr1 (str): Attribute description
            attr2 (str, optional): Attribute description.

        Examples:
            Example description
    """)
    assert docstring.short_description == "This is description"
    assert docstring.long_description == ""
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].key == 'param'
    assert docstring.meta[0].args[0]

# Generated at 2022-06-21 11:47:28.272093
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    objGoogleParser = GoogleParser()
    strText = "ABCD\nEFGH"
    objDocstring = objGoogleParser.parse(strText)
    if objDocstring.short_description == strText:
        print("test_GoogleParser::PASS")
    else:
        print("test_GoogleParser::FAIL")

test_GoogleParser()

# Generated at 2022-06-21 11:47:38.524541
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_docstr = "Test:\n\n    Test."
    defaultParser = GoogleParser()
    parsed_docstr = defaultParser.parse(google_docstr)
    print(parsed_docstr.short_description)
    assert parsed_docstr.short_description == "Test:"

    new_section = Section("Test", "examples", SectionType.SINGULAR)
    defaultParser.add_section(new_section)
    parsed_docstr = defaultParser.parse(google_docstr)
    print(parsed_docstr.short_description)
    assert parsed_docstr.short_description == None

    del defaultParser
    defaultParser = GoogleParser()
    parsed_docstr = defaultParser.parse(google_docstr)
    print(parsed_docstr.short_description)
    assert parsed_

# Generated at 2022-06-21 11:47:47.840754
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    d = GoogleParser()
    d.add_section(Section("Example1", "example1", SectionType.SINGULAR))
    d.add_section(Section("Example1_1", "example1_1", SectionType.SINGULAR))
    assert "Example1" in d.sections
    assert "Example1_1" in d.sections
    assert d.sections["Example1"] == Section("Example1", "example1", SectionType.SINGULAR)
    assert d.sections["Example1_1"] == Section("Example1_1", "example1_1", SectionType.SINGULAR)


# Generated at 2022-06-21 11:47:59.074137
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    default_sections = DEFAULT_SECTIONS
    assert len(default_sections) == 16
    parser = GoogleParser()
    assert parser.sections == {s.title: s for s in default_sections}

    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    parser = GoogleParser(sections=sections)
    assert parser.sections == {s.title: s for s in sections}


# Generated at 2022-06-21 11:48:11.852952
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()

    doc = """
        Short summary.

        Longer summary.

        Args:
            arg1:  The first argument.
            arg2:  The first argument.
            arg2:  The second argument.

        Return:
            The return value.

        Raises:
            Exception1:  The first exception.
            Exception2:  The second exception.
        """

    # Parse the document
    docstring = GoogleParser().parse(doc)

    assert docstring.short_description == "Short summary."
    assert docstring.long_description == "Longer summary."

    assert len(docstring.meta) == 5

    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "arg1"

# Generated at 2022-06-21 11:48:22.703828
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_docstring = '''\
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    '''

    docstring = GoogleParser().parse(test_docstring)

    assert docstring.short_description == 'Parse the Google-style docstring into its components.'
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False

    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ('returns', ':returns: parsed docstring')
    assert docstring.meta[0].description == 'parsed docstring'

# Generated at 2022-06-21 11:48:25.371739
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
Example:
    some code
    some more code
"""
    docstring = GoogleParser().parse(text)
    assert docstring.meta[0].args == ['example', 'Example']


# Generated at 2022-06-21 11:48:27.566388
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert str(GoogleParser()) == "[title:section interface]@<GoogleParser object at 0x000001FA7D1CA6D8>"



# Generated at 2022-06-21 11:48:29.154380
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text = """AA
    BB
    CC
    """
    parser = GoogleParser()
    assert parser is not None

# Generated at 2022-06-21 11:48:42.954776
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(TypeError):
        #missing one arguement
        section_1 = Section("Arguments", "param")


# Generated at 2022-06-21 11:48:53.944272
# Unit test for function parse
def test_parse():
    # The first line should be a short summary.
    # Blank lines may be used before and after the summary.
    # The summary must start with an uppercase letter and end with a period.
    docstr = """Returns the sum of a and b.
        Raises:
            TypeError: if a or b are not numbers.
    """

    parsed = parse(docstr)
    assert parsed.long_description is None
    assert parsed.short_description == "Returns the sum of a and b."
    assert len(parsed.meta) == 1
    assert parsed.meta[0].description.startswith("if a or b are not numbers")

    # Additional paragraphs can be separated by a blank line.
    docstr = """Returns the sum of a and b.

        The result is always an integer.
    """


# Generated at 2022-06-21 11:48:56.698836
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:49:00.977501
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(TypeError):
        Section(["title", "key", "type"])
    with pytest.raises(ValueError):
        Section("title", "key", "type")
    with pytest.raises(ValueError):
        Section("title", "key", "section")


# Generated at 2022-06-21 11:49:03.505578
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    g.parse("")
    s = Section("My Section", "my_section", SectionType.SINGULAR)
    g.add_section(s)


# Generated at 2022-06-21 11:49:15.679550
# Unit test for function parse
def test_parse():
    d = "Args:\n foo: first argument\n bar: second argument"
    ds = parse(d)
    assert ds.meta[0].arg_name == 'foo'
    assert ds.meta[1].arg_name == 'bar'
    d = "Args:\n foo: first argument\n  bar: second argument"
    ds = parse(d)
    assert ds.meta[0].arg_name == 'foo'
    assert ds.meta[1].arg_name == 'bar'
    d = "Args:\n foo: first argument\n\nbar: second argument"
    ds = parse(d)
    assert ds.meta[0].arg_name == 'foo'
    assert ds.meta[1].arg_name == 'bar'

# Generated at 2022-06-21 11:49:17.708518
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert gp.titles_re
    assert gp.sections


# Generated at 2022-06-21 11:49:21.474282
# Unit test for constructor of class Section
def test_Section():
    obj = Section("Arguments", "param", SectionType.MULTIPLE)
    assert obj.title == "Arguments"
    assert obj.key == "param"
    assert obj.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:49:31.737810
# Unit test for constructor of class Section
def test_Section():
	sections = [
		Section("Attr1", "attr1", 0),
		Section("Attr2", "attr2", 1),
		Section("Attr3", "attr3", 2),
	]
	assert(sections[0].title == "Attr1")
	assert(sections[0].key == "attr1")
	assert(sections[0].type == SectionType.SINGULAR)

	assert(sections[1].title == "Attr2")
	assert(sections[1].key == "attr2")
	assert(sections[1].type == SectionType.MULTIPLE)

	assert(sections[2].title == "Attr3")
	assert(sections[2].key == "attr3")
	assert(sections[2].type == SectionType.SINGULAR_OR_MULTIPLE)



# Generated at 2022-06-21 11:49:39.760500
# Unit test for function parse
def test_parse():
    # print(parse.__doc__)
    s = """\
    Short description.

    Long description.

    Args:
        required (int): The required arg.
        asdf (str): The optional arg, defaults to 'asdf'.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: If `choice` is not 'A', 'B', or 'C'.

    """
    # print(parse(s))
    assert True==True

# test_parse()

# Generated at 2022-06-21 11:50:10.162215
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    orig_text = """This function does some math.

Args:
    arg1: The first argument.
    arg2: The second argument.

Returns:
    The result of the addition.

Raises:
    ValueError: If x is bigger than y.
    TypeError: If x or y are not numbers.
"""
    test_text = """This function does some math.

Args:
    arg1: The first argument.
    arg2: The second argument.

Returns:
    The result of the addition.

Raises:
    ValueError: If x is bigger than y.
    TypeError: If x or y are not numbers.
"""
    assert orig_text == obj.parse(orig_text).text
    assert orig_text == test_text

# Generated at 2022-06-21 11:50:21.750438
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
    Parameters:
    -----------
    param1 : float
        This is param1
    param2 : float
        This is param2
    """
    sec1 = Section("Parameters", "param", SectionType.MULTIPLE)
    sec2 = Section("Params", "param", SectionType.MULTIPLE)
    gp = GoogleParser()

    gp.add_section(sec1)
    res = gp.parse(text)
    assert len(res.meta) == 2
    assert res.meta[0].args == ['param', 'param1 : float']
    assert res.meta[1].args == ['param', 'param2 : float']
    assert res.meta[0].description == 'This is param1'
    assert res.meta[1].description == 'This is param2'


# Generated at 2022-06-21 11:50:34.560647
# Unit test for function parse

# Generated at 2022-06-21 11:50:43.928266
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Example1:
        """Short description.

        Long description
        """

        def foo(self):
            """Short description.

            Long description
            """
            pass


# Generated at 2022-06-21 11:50:50.340118
# Unit test for constructor of class Section
def test_Section():
    if __name__ == "__main__":
        section = Section(title = "Parameters", key = "params", type = SectionType.SINGULAR_OR_MULTIPLE)
        print(section)
        print(section.title)
        print(section.key)
        print(section.type)


# Generated at 2022-06-21 11:50:52.938574
# Unit test for constructor of class Section
def test_Section():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    GoogleParser(sections)


# Generated at 2022-06-21 11:51:01.296241
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    docstring = parse('"""Hello world."""')
    assert docstring.short_description == "Hello world."
    assert len(docstring.meta) == 0

    docstring = parse('"""Doing nothing.\n\nNothing at all.\n\n"""')
    assert docstring.short_description == "Doing nothing."
    assert docstring.long_description == "Nothing at all."
    assert docstring.blank_after_short_description and docstring.blank_after_long_description

    docstring = parse('"""Doing nothing.\nNothing at all.\n\n"""')
    assert docstring.short_description == "Doing nothing."
    assert docstring.long_description == "Nothing at all."

# Generated at 2022-06-21 11:51:15.023417
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:51:24.940068
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_str = '''One line summary.

    Extended summary.

    Attributes:
        arg1 (int): Description of `arg1`
        arg2 (int): Description of `arg2`

    Example::
        example
    '''

    parser = GoogleParser()
    parsed_doc_str = parser.parse(doc_str)

    assert parsed_doc_str.short_description == 'One line summary.'
    assert parsed_doc_str.long_description == 'Extended summary.'
    assert parsed_doc_str.meta[0].description == 'Description of `arg1`'
    assert parsed_doc_str.meta[0].arg_name == 'arg1'
    assert parsed_doc_str.meta[0].type_name == 'int'

# Generated at 2022-06-21 11:51:28.008496
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Example", "examples", SectionType.SINGULAR)
    assert sec.title == "Example"
    assert sec.key == "examples"
    assert sec.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:51:49.346197
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("One line.\n") == Docstring(short_description="One line.")
    assert parse("One line.\n\n") == Docstring(
        short_description="One line.", blank_after_short_description=True
    )
    assert parse("One line.\n\n   \n") == Docstring(
        short_description="One line.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )


# Generated at 2022-06-21 11:51:56.940021
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("string") == Docstring(
        short_description="string",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("string\n") == Docstring(
        short_description="string",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parse("string\n\n") == Docstring(
        short_description="string",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
        meta=[],
    )

# Generated at 2022-06-21 11:52:07.509793
# Unit test for constructor of class Section
def test_Section():
    from .common import Section
    assert Section("Arguments", "param", 0) == Section("Arguments", "param", 0)
    assert Section("Arguments", "param", 0) != Section("Args", "param", 0)
    assert Section("Arguments","param", 0).__doc__ == "A docstring section."
    assert Section("Arguments","param", 0)._asdict() ==  OrderedDict(
        [('title', 'Arguments'), ('key', 'param'), ('type', 0)])
    assert Section("Arguments", "param", 0).__dict__ == OrderedDict(
        [('title', 'Arguments'), ('key', 'param'), ('type', 0)])
    assert Section("Arguments", "param", 0)._replace(title="Args") == Section("Args", "param", 0)

# Generated at 2022-06-21 11:52:11.297179
# Unit test for constructor of class Section
def test_Section():
    section = Section("adad", "dssss", SectionType.MULTIPLE)
    assert section.title == "adad"
    assert section.key == "dssss"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:52:17.449969
# Unit test for constructor of class Section
def test_Section():

    title = "Parameters"
    key = "param"
    type = SectionType.MULTIPLE

    section = Section(title, key, type)

    assert section.title == title
    assert section.key == key
    assert section.type == type



# Generated at 2022-06-21 11:52:27.121766
# Unit test for function parse

# Generated at 2022-06-21 11:52:39.775568
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    desc = 'This is a description'
    example = 'This is an example'
    args = 'arg1 (str): This is an argument'
    returns = 'str: This is what is returned'
    raises = 'KeyError: This is what is raised'
    warnings = 'This is a warning'

    text = f"{desc}\n\n{args}\n\n{example}\n\n{returns}\n\n{raises}\n\n{warnings}\n\n"
    ret = GoogleParser().parse(text)

    assert ret.short_description == desc
    assert ret.long_description == example
    assert ret.meta[0].args == ['param', 'arg1 (str): This is an argument']
    assert ret.meta[1].args == ['examples', 'This is an example']

# Generated at 2022-06-21 11:52:40.976385
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert len(GoogleParser().sections) == len(DEFAULT_SECTIONS)


# Generated at 2022-06-21 11:52:45.316389
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = '''
    
    
    Args:
        x: a string

    Parameters:
        x (int): an integer

    Returns:
        (str,int): a tuple of a string and an integer
        
        '''
    p = GoogleParser()
    p.parse(d)



# Generated at 2022-06-21 11:52:54.001026
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    d_parser = GoogleParser()
    # Adding a section to default sections
    d_parser.add_section(Section("Author", "author", SectionType.SINGULAR))
    assert d_parser.sections["Author"].title == "Author"
    assert d_parser.sections["Author"].key == "author"
    assert d_parser.sections["Author"].type == SectionType.SINGULAR
    # Replacing a section in default sections
    d_parser.add_section(Section("Args", "arg", SectionType.SINGULAR))
    assert d_parser.sections["Args"].title == "Args"
    assert d_parser.sections["Args"].key == "arg"
    assert d_parser.sections["Args"].type == SectionType.SINGULAR



# Generated at 2022-06-21 11:53:05.085934
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    if __name__ == '__main__':
        import doctest
        doctest.testmod(verbose=True)

# Generated at 2022-06-21 11:53:13.898742
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit tests for parsing of Google docstrings."""

# Generated at 2022-06-21 11:53:16.941555
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()
    assert GoogleParser(title_colon=False)
    assert GoogleParser(sections=[])


# Generated at 2022-06-21 11:53:21.937768
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

    section = Section("Note", "note", SectionType.MULTIPLE)
    parser.add_section(section)

    assert section.title in parser.sections
    assert section == parser.sections[section.title]


# Generated at 2022-06-21 11:53:30.983934
# Unit test for constructor of class Section
def test_Section():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    print(sections)
    sections = [Section("Arguments", "param", SectionType.SINGULAR)]
    print(sections)
    sections = [Section("Arguments", "param", SectionType.SINGULAR_OR_MULTIPLE)]
    print(sections)
    sections = [Section("Args", "param", SectionType.MULTIPLE)]
    print(sections)
    sections = [Section("Args", "param", SectionType.SINGULAR)]
    print(sections)
    sections = [Section("Args", "param", SectionType.SINGULAR_OR_MULTIPLE)]
    print(sections)
    sections = [Section("Parameters", "param", SectionType.MULTIPLE)]
    print(sections)

# Generated at 2022-06-21 11:53:40.926008
# Unit test for function parse
def test_parse():
    from .common import (
        GoogleParser,
        Docstring,
        DocstringMeta,
        DocstringParam,
        DocstringReturns,
        DocstringRaises,
    )
    import doctest

    class Stub:
        """\
        Stub of a class for doctests.

        Attributes:
            title (str): a title.
        """
        title: str
        """A title."""

    assert [
        s
        for s in parse("""\
            Short description.

            Long description.
            Spanning multiple lines.
        """).meta
    ] == [DocstringMeta(args=[], description=None)]

# Generated at 2022-06-21 11:53:52.485675
# Unit test for function parse
def test_parse():
    docstring = """\
Summaries longer than one line should be underlined with =
Args:
    arg1 (str, optional): Description of `arg1`. Defaults to "Hello".
    arg2 (str): Description of `arg2`.
Raises:
    ValueError: Description of `ValueError`.
    TypeError: Description of `TypeError`."""

    parsed = parse(docstring)

    assert parsed.short_description == "Summaries longer than one line should be underlined with ="
    assert len(parsed.meta) == 3
    assert parsed.meta[0].args == ["arg1", "arg1 (str, optional)"]
    assert parsed.meta[0].description == "Description of `arg1`. Defaults to \"Hello\"."

# Generated at 2022-06-21 11:53:56.943702
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text = '''
    """Google-style docstring parsing."""
    '''

    sections = [
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Exceptions", "raises", SectionType.MULTIPLE),
    ]
    GoogleParser(sections)
    print("constructor tested")


# Generated at 2022-06-21 11:54:09.202501
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section = Section("SectionX", "SectionX", SectionType.SINGULAR)
    GoogleParser().add_section(section)

    section2 = Section("SectionX", "SectionX", SectionType.SINGULAR_OR_MULTIPLE)
    GoogleParser().add_section(section2)

    section3 = Section("SectionX", "SectionX", SectionType.MULTIPLE)
    GoogleParser().add_section(section3)

    section4 = Section("SectionY", "SectionY", SectionType.SINGULAR)
    GoogleParser().add_section(section4)

    section5 = Section("SectionY", "SectionY", SectionType.SINGULAR_OR_MULTIPLE)
    GoogleParser().add_section(section5)

    section6 = Section("SectionY", "SectionY", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:54:11.185545
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test constructor of class GoogleParser
    gp = GoogleParser()
    assert gp != None


# Generated at 2022-06-21 11:54:30.583347
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test if __init__ fuction works fine
    assert (GoogleParser().__dict__ == 
            GoogleParser(sections = DEFAULT_SECTIONS).__dict__)   
    assert (GoogleParser(title_colon = False).__dict__ == 
            GoogleParser(sections = DEFAULT_SECTIONS, 
                         title_colon = False).__dict__)
    assert (GoogleParser(sections = [Section("Arguments", "param", 
                                              SectionType.MULTIPLE)]).__dict__ ==
            GoogleParser(sections = [Section("Arguments", "param", 
                                              SectionType.MULTIPLE)]).__dict__)
    with pytest.raises(AttributeError):
        GoogleParser(sections = [1])
   

# Generated at 2022-06-21 11:54:39.285526
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    # Test for adding a new section
    parser.add_section(Section(title="Test", key="key", type=SectionType.SINGULAR))
    assert "not in" not in str(parser.sections)
    assert "Test" in str(parser.sections)
    # Test for updating an existing section
    parser.add_section(Section(title="Test", key="key", type=SectionType.SINGULAR))
    assert parser.sections["Test"] == Section(title="Test", key="key", type=SectionType.SINGULAR), "Section failed to update."

