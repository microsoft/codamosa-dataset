

# Generated at 2022-06-21 11:45:22.493911
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    doc_parser = GoogleParser()
    if doc_parser.title_colon:
        colon = ":"
    else:
        colon = ""
    assert doc_parser.titles_re.pattern == "^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields)" + colon + "[ \t\r\f\v]*$"
    section = Section("Notes", "note", SectionType.SINGULAR)
    doc_parser.add_section(section)
    assert doc_parser.titles_re.pattern == "^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields|Notes)" + colon + "[ \t\r\f\v]*$"

# Generated at 2022-06-21 11:45:30.699704
# Unit test for function parse
def test_parse():
    text = """
        Function summary line.

        Extended description of function.

        Args:
            arg1 (int): Description of arg1
            arg2 (str): Description of arg2
        Returns:
            str: Description of return value.
        """
    assert GoogleParser().parse(text).meta[-2].args == ["arg1", "int"]
    assert GoogleParser().parse(text).meta[-2].arg_name == "arg1"
    assert GoogleParser().parse(text).meta[-2].type_name == "int"
    assert GoogleParser().parse(text).meta[-2].description == "Description of arg1"
    assert GoogleParser().parse(text).meta[-2].is_optional is None
    assert GoogleParser().parse(text).meta[-2].default is None


# Generated at 2022-06-21 11:45:36.640157
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class TestClass:
        """This is a test class.

        It tests GoogleParser.parse.
        """
        def __init__(self):
            """Inits TestClass."""

    test_object = TestClass()

    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("   ") == Docstring()
    assert GoogleParser().parse("\n  \n ") == Docstring()
    assert GoogleParser().parse("Hello World.") == Docstring(short_description="Hello World.")
    assert GoogleParser().parse("Hello World.\n") == Docstring(short_description="Hello World.")

# Generated at 2022-06-21 11:45:40.864854
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    test_parser = GoogleArgsParser()
    new_section = Section("Optional", "optional", SectionType.MULTIPLE)
    test_parser.add_section(new_section)
    assert "Optional:" in test_parser.titles_re.pattern
    assert test_parser.sections["Optional"].key == "optional"
    assert test_parser.sections["Optional"].type == SectionType.MULTIPLE



# Generated at 2022-06-21 11:45:46.010917
# Unit test for function parse
def test_parse():
    def test():
        """Return test result.
        :param table: the table to search
        :type table: str
        :param order: the column order
        :type order: int
        :param start: the start bound
        :type start: int
        :param end: the end bound
        :type end: int
        :returns: test result
        """
        return "test result"


# Generated at 2022-06-21 11:45:50.107139
# Unit test for constructor of class Section
def test_Section():
    s = Section(title="title", key="key", type="type")
    assert s.title == "title"
    assert s.key == "key"
    assert s.type == "type"

# Generated at 2022-06-21 11:45:53.889965
# Unit test for constructor of class Section
def test_Section():
    assert Section("Raises", "raises", SectionType.MULTIPLE) == \
        Section("Raises", "raises", SectionType.MULTIPLE)


# Generated at 2022-06-21 11:45:57.580164
# Unit test for constructor of class Section
def test_Section():
    s = Section("hi", "hi", SectionType.SINGULAR)
    assert s.title == "hi"
    assert s.key == "hi"
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:46:10.202142
# Unit test for function parse
def test_parse():
    text = "This is a module summary.\n\
    This describes the module in great detail.\n\
    \n\
    Attributes:\n\
        param1 (int): The first parameter.\n\
        param2 (str): The second parameter.\n\
    \n\
    Example:\n\
        This is an example.\n\
    "
    docstring = parse(text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "This is a module summary."
    assert docstring.long_description == "This describes the module in great detail."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3

# Generated at 2022-06-21 11:46:21.790773
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert (parser.sections["Raises"].title == "Raises")
    assert (parser.sections["Raises"].key == "raises")
    assert (parser.sections["Raises"].type == SectionType.MULTIPLE)
    assert (parser.sections["Arguments"].title == "Arguments")
    assert (parser.sections["Arguments"].key == "param")
    assert (parser.sections["Arguments"].type == SectionType.MULTIPLE)
    assert (parser.sections["Returns"].title == "Returns")
    assert (parser.sections["Returns"].key == "returns")
    assert (parser.sections["Returns"].type == SectionType.SINGULAR_OR_MULTIPLE)
    assert (parser.sections["Example"].title == "Example")
   

# Generated at 2022-06-21 11:46:40.447110
# Unit test for function parse
def test_parse():
    doc = parse.__doc__
    print(doc)
    _doc = GoogleParser().parse(doc)
    print(_doc.short_description)
    print(_doc.long_description)
    print(_doc.meta)
    print(_doc.meta[0].args)
    print(_doc.meta[0].description)
    print(_doc.meta[1].args)
    print(_doc.meta[1].description)
    print(_doc.meta[2].args)
    print(_doc.meta[2].description)
    print(_doc.meta[3].arg_name)
    print(_doc.meta[3].type_name)
    print(_doc.meta[3].is_optional)
    print(_doc.meta[3].default)
    print(_doc.meta[3].description)

# Generated at 2022-06-21 11:46:52.530609
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    docstring = """Summary line.

Params:
    arg1: Description of arg1.
    arg2 (str): Description of arg2. Defaults to None.

Example:
    examples goes here.

"""

# Generated at 2022-06-21 11:46:56.959404
# Unit test for constructor of class Section
def test_Section():
    s = Section('Args','param',SectionType.MULTIPLE)
    assert(s.title == 'Args')
    assert(s.key == 'param')
    assert(s.type == SectionType.MULTIPLE)


# Generated at 2022-06-21 11:47:03.119325
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test constructor
    test_sections = [
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Exceptions", "raises", SectionType.MULTIPLE),
    ]
    parser = GoogleParser(sections=test_sections)

    assert isinstance(parser, GoogleParser)
    assert parser.sections is not None
    assert len(parser.sections) == 2
    assert parser.title_colon

    assert isinstance(parser.titles_re, re.Pattern)
    assert parser.titles_re.pattern == "^(Raises|Exceptions):[ \t\r\f\v]*$"


# Generated at 2022-06-21 11:47:11.597590
# Unit test for function parse

# Generated at 2022-06-21 11:47:21.976120
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Instantiate GoogleParser with default constructor
    google_parser = GoogleParser()
    assert google_parser is not None
    assert google_parser.sections is not None
    assert len(google_parser.sections) == 13
    assert google_parser.titles_re is not None

    # Instantiate GoogleParser with customized constructor
    google_parser_customized = GoogleParser([])
    assert google_parser_customized is not None
    assert google_parser_customized.sections is not None
    assert len(google_parser_customized.sections) == 0
    assert google_parser_customized.titles_re is not None


# Generated at 2022-06-21 11:47:32.512246
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    text = '''
        This is a docstring.

        This function does something.

        :param id: ID of the object.
        :type id: int
    '''
    parsed = g.parse(text)
    assert parsed.short_description == "This is a docstring."
    assert parsed.long_description == "This function does something."
    assert len(parsed.meta) == 1
    assert type(parsed.meta[0]) == DocstringParam
    assert parsed.meta[0].description == "ID of the object."
    assert parsed.meta[0].type_name == "int"
    assert parsed.meta[0].arg_name == "id"


# Generated at 2022-06-21 11:47:36.067611
# Unit test for constructor of class Section
def test_Section():
    # test default settings
    section = Section("Args", "param", SectionType.MULTIPLE)
    assert section.title == "Args"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:47:47.885523
# Unit test for constructor of class Section
def test_Section():
    sections = DEFAULT_SECTIONS
    for s in sections:
        assert isinstance(s, Section)
        assert s.title in ('Arguments', 'Args', 'Attributes', 'Example') or s.title in ('Examples', 'Except', 'Exceptions') or s.title in ('Parameters', 'Params', 'Raises', 'Returns', 'Yields')
        assert isinstance(s.key, str)
        assert s.key in ('attribute', 'param') or s.key in ('examples', 'raises') or s.key in ('returns', 'yields')
        assert isinstance(s.type, SectionType)
        assert s.type in (SectionType.SINGULAR, SectionType.SINGULAR_OR_MULTIPLE, SectionType.MULTIPLE)


# Generated at 2022-06-21 11:47:50.039249
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) is not None


# Generated at 2022-06-21 11:48:06.000290
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) == ("Arguments", "param", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:48:09.808663
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    G = GoogleParser()
    new_section = Section("New", "new", SectionType.SINGULAR)
    G.add_section(new_section)
    assert G.sections["New"] == new_section


# Generated at 2022-06-21 11:48:12.514863
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test if we can add new sections to GoogleParser"""
    parser = GoogleParser()
    section = Section("NewArguments", "newparam", SectionType.MULTIPLE)
    parser.add_section(section)

# Generated at 2022-06-21 11:48:20.483177
# Unit test for function parse
def test_parse():
    parser = GoogleParser()
    doc = '''
    Returns the sum of a and b

    Args:
        a (int): first input
        b (int): second input

    Returns:
        a + b

    Examples:
        >>> test_parse(1, 2)
        3
    '''
    result = parser.parse(doc)
    assert len(result.meta) == 3
    print(result)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:48:28.807500
# Unit test for function parse
def test_parse():
    # simple function with only the required """"
    def myfunc():
        """Just a function"""
        pass

    assert parse(myfunc.__doc__).short_description == "Just a function"

    # function with no """" - raises an exception
    def myfunc2():
        pass

    try:
        parse(myfunc2.__doc__)
        assert False
    except ParseError:
        pass

    # function with multi-line docstring
    def myfunc3():
        """First line

        Second line
        Third line
        """
        pass

    assert parse(myfunc3.__doc__).short_description == "First line"
    assert parse(myfunc3.__doc__).long_description == "Second line\nThird line"
    assert parse(myfunc3.__doc__).blank_after_long

# Generated at 2022-06-21 11:48:36.804704
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    def add_section_works(title, key, type, expected_found):
        parser.add_section(Section(title, key, type))
        titles_re = parser.titles_re
        return any(titles_re.match(title) for title in expected_found)
    assert add_section_works("Test", "test", SectionType.SINGULAR, ["Test"])
    assert (
        add_section_works("Tests", "test", SectionType.SINGULAR, ["Test", "Tests"])
        == True
    )
    assert (
        add_section_works("Testcolon", "test", SectionType.SINGULAR, ["Test:"])
        == True
    )

# Generated at 2022-06-21 11:48:43.565159
# Unit test for function parse
def test_parse():
    """Test for function parse"""
    def test_func():
        """
        Test function.

        This is a test function.

        :param a: Test parameter a.
        :type a: int
        """

    result = parse(inspect.getdoc(test_func))
    assert result.short_description == "Test function."
    assert result.long_description == "This is a test function."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 1

    meta = result.meta[0]
    assert meta.args == ["param", "a: Test parameter a."]
    assert meta.description == "Test parameter a."
    assert meta.arg_name == "a"
    assert meta.type_name == "int"


# Generated at 2022-06-21 11:48:54.337697
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert Docstring(
        None, None, "Returns a list of the names in the given namespace", None
    ) == GoogleParser().parse(
        """
Returns a list of the names in the given namespace
"""
    )


# Generated at 2022-06-21 11:49:03.440321
# Unit test for constructor of class Section
def test_Section():
    a = Section("a", "param", SectionType.MULTIPLE)
    assert a.title == "a"
    assert a.key == "param"
    assert a.type == SectionType.MULTIPLE
    b = Section("b", "param", SectionType.SINGULAR)
    assert b.title == "b"
    assert b.key == "param"
    assert b.type == SectionType.SINGULAR
    c = Section("c", "param", SectionType.SINGULAR_OR_MULTIPLE)
    assert c.title == "c"
    assert c.key == "param"
    assert c.type == SectionType.SINGULAR_OR_MULTIPLE


# Generated at 2022-06-21 11:49:06.788190
# Unit test for constructor of class Section
def test_Section():
    Sec = Section("Arguments", "param", SectionType.MULTIPLE)
    assert Sec.title == "Arguments"
    assert Sec.key == "param"
    assert Sec.type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:49:19.791467
# Unit test for constructor of class Section
def test_Section():
    for title, key, type in DEFAULT_SECTIONS:
        section = Section(title, key, type)
        assert title == section.title
        assert key == section.key
        assert type == section.type


# Generated at 2022-06-21 11:49:30.515790
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("Hello.") == Docstring(
        short_description="Hello."
    )
    assert GoogleParser().parse("Hello.\nWorld.") == Docstring(
        short_description="Hello.",
        blank_after_short_description=False,
        long_description="World.",
        blank_after_long_description=True,
    )
    assert GoogleParser().parse("Hello.\n\nWorld.") == Docstring(
        short_description="Hello.",
        blank_after_short_description=True,
        long_description="World.",
        blank_after_long_description=True,
    )

# Generated at 2022-06-21 11:49:43.120570
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    A.

    Args:
        a:
            an a
        b:
            a b
    Returns:
        A float or an integer.
    """

    p = GoogleParser()

    ret = p.parse(text)

# Generated at 2022-06-21 11:49:46.823200
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert len(parser.sections) == len(DEFAULT_SECTIONS)
    assert parser.title_colon == True


# Generated at 2022-06-21 11:49:56.557833
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Initialize an instance of class GoogleParser
    GoogleParser_object = GoogleParser()

    # Initialize a dictionary with key-value pairs
    GoogleParser_object.sections = {
        'Parameters': Section(title='Parameters', key='param', type=SectionType.MULTIPLE),
        'Example': Section(title='Example', key='examples', type=SectionType.SINGULAR),
        'Returns': Section(title='Returns', key='returns', type=SectionType.SINGULAR_OR_MULTIPLE),
    }

    # Initialize a new section
    section_object = Section(title='Yields', key='yields', type=SectionType.SINGULAR_OR_MULTIPLE)

    # Check if the function add_section is returning the expected value

# Generated at 2022-06-21 11:50:08.982130
# Unit test for function parse
def test_parse():
    src = '''
        1
        2
        3
    '''

    # Test for numpy-style
    docstring = parse(src)
    assert docstring.short_description == "1"
    assert docstring.long_description == "2\n3"
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    # Test for Google-style
    src = '''
        A docstring for unit test.

        Args:
            arg1: argument 1. Defaults to 1.
            arg2: argument 2.
            arg3: argument 3. Defaults to 3.
            arg4: argument 4.
        '''
    docstring = parse(src)
    assert docstring.short_description == "A docstring for unit test."
    assert docstring.long

# Generated at 2022-06-21 11:50:19.618594
# Unit test for constructor of class Section
def test_Section():
    sec1 = Section("Arguments", "param", SectionType.MULTIPLE)
    assert sec1.title == "Arguments"
    assert sec1.key == "param"
    assert sec1.type == SectionType.MULTIPLE
    sec2 = Section("Args", "param", SectionType.MULTIPLE)
    assert sec2.title == "Args"
    assert sec2.key == "param"
    assert sec2.type == SectionType.MULTIPLE
    sec3 = Section("Parameters", "param", SectionType.MULTIPLE)
    assert sec3.title == "Parameters"
    assert sec3.key == "param"
    assert sec3.type == SectionType.MULTIPLE
    sec4 = Section("Params", "param", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:50:32.054927
# Unit test for function parse
def test_parse():
    # Test empty docstring
    assert parse("") == Docstring()
    # Test docstring with only short description
    assert parse("short desc") == Docstring(
        short_description="short desc",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    # Test docstring with only short description and blank lines after
    assert parse("short desc\n") == Docstring(
        short_description="short desc",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    # Test docstring with only long description

# Generated at 2022-06-21 11:50:42.854768
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''A docstring represented by Google-style.

Args:
    arg1: This is arg1.
    arg2: This is arg2.

Returns:
    This is return.

Raises:
    Exception: An error occurred.
'''
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "A docstring represented by Google-style."
    assert doc.long_description == None
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    print(len(doc.meta))
    # print(doc.meta)
    assert doc.meta[0].description == "This is arg1."
    assert doc.meta[0].args[0] == "param"

# Generated at 2022-06-21 11:50:48.961072
# Unit test for function parse
def test_parse():
    s = """Short description.

    Long description.

    Args:
        param1: The first parameter.
        param2: The second parameter.

    Returns:
        description: description
        type: int

    Raises:
        TypeError.

    """
    print(parse(s))



# Generated at 2022-06-21 11:51:00.245183
# Unit test for constructor of class Section
def test_Section():
    test_section = Section(title="title", key="key", type=SectionType.SINGULAR)
    assert isinstance(test_section, Section)
    assert test_section.title == "title"
    assert test_section.key == "key"
    assert test_section.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:51:07.826288
# Unit test for constructor of class GoogleParser
def test_GoogleParser():

    # Test with default sections
    parser = GoogleParser()
    assert parser._build_multi_meta(parser.sections["Returns"], "list[int]", "Desc") == DocstringReturns(args=['returns', 'list[int]'], description='Desc', type_name='list[int]', is_generator=False)
    assert parser._build_multi_meta(parser.sections["Params"], "n (int)", "Desc") == DocstringParam(args=['param', 'n (int)'], description='Desc', arg_name='n', type_name='int', is_optional=None, default=None)
    assert parser._build_multi_meta(parser.sections["Returns"], "", "Desc") == DocstringReturns(args=['returns', ''], description='Desc', type_name=None, is_generator=False)

# Generated at 2022-06-21 11:51:18.247523
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test if method add_section of class GoogleParser works as expected"""
    googleParser = GoogleParser()
    newSection = Section("test", "test", SectionType.MULTIPLE)
    googleParser.add_section(newSection)
    expectedKey = "test"
    expectedType = SectionType.MULTIPLE
    actualSection = googleParser.sections[expectedKey]
    assert actualSection.title == expectedKey and actualSection.type == expectedType, "expected %s and %s, got %s and %s" % (expectedKey, expectedType, actualSection.title, actualSection.type)
    assert actualSection.key == "test", "Test if the key from the newly created section is actually saved in the dict"


# Generated at 2022-06-21 11:51:19.198771
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert(parser)


# Generated at 2022-06-21 11:51:20.546739
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()
    assert(True)


# Generated at 2022-06-21 11:51:22.121133
# Unit test for function parse
def test_parse():
    import doctest
    doctest.testmod()



# Generated at 2022-06-21 11:51:30.612879
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # test default case
    parser1 = GoogleParser()
    doc_string1 = parser1.parse('"""test"""')
    assert doc_string1.get_short_description() == 'test'
    assert len(doc_string1.meta) == 0

    # test add a section
    parser2 = GoogleParser()
    parser2.add_section(Section('MySection', 'my_section', SectionType.MULTIPLE))
    assert len(parser2.sections) == len(DEFAULT_SECTIONS) + 1
    doc_string2 = parser2.parse('"""\nMySection:\n\n'
                                'MyParam1\n'
                                'MyParam2\n'
                                '"""')
    assert doc_string2.get_short_description() == ''

# Generated at 2022-06-21 11:51:33.189437
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(ValueError):
        Section("foo", "bar", 4)



# Generated at 2022-06-21 11:51:41.205394
# Unit test for function parse
def test_parse():
    """Basic test of function parse."""
    f = parse
    res = f("""
    Hello

    :param x: X
    :param y: Y
    :returns: Z
    """)
    assert res.short_description == "Hello"
    assert res.long_description is None
    assert len(res.meta) == 3
    for meta in res.meta:
        assert isinstance(meta, DocstringParam) or isinstance(
            meta, DocstringReturns
        )

# Generated at 2022-06-21 11:51:52.119896
# Unit test for function parse
def test_parse():
    text = """Summarize the testing content.

This is the long description, where the testing content is described
in detail. You can have multiple paragraphs separate by blank lines.

Args:
    arg1 (int): The first argument.
    arg2 (str, optional): The second argument. Defaults to 'world'.

Raises:
    ValueError: if stuff happens

Returns:
    list: A list
"""

# Generated at 2022-06-21 11:52:09.088765
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:52:22.307058
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "Docstring of yolo method.\n\nArgs:\n    a (int): The A parameter.\n    b (str): The B parameter.\n\nReturns:\n    str: something.\n"


# Generated at 2022-06-21 11:52:29.565518
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    p = GoogleParser(sections=sections)
    assert p.sections == {
        "Arguments": Section("Arguments", "param", SectionType.MULTIPLE),
        "Raises": Section("Raises", "raises", SectionType.MULTIPLE),
        "Example": Section("Example", "examples", SectionType.SINGULAR),
        "Returns": Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    }

# Generated at 2022-06-21 11:52:41.171740
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:52:48.042513
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert isinstance(GoogleParser(sections=DEFAULT_SECTIONS), GoogleParser)
    assert isinstance(GoogleParser(sections=[Section("Example", "examples", SectionType.SINGULAR)]), GoogleParser)
    assert isinstance(GoogleParser(sections=[Section("Parameter", "param", SectionType.MULTIPLE)]), GoogleParser)
    assert isinstance(GoogleParser(title_colon=False), GoogleParser)
    assert isinstance(GoogleParser(sections=[Section("Parameter", "param", SectionType.SINGULAR_OR_MULTIPLE)]), GoogleParser)
    assert not isinstance(GoogleParser(sections=None), GoogleParser)
    assert not isinstance(GoogleParser(sections=[1, 2, 3]), GoogleParser)
    assert not isinstance(GoogleParser(sections=""), GoogleParser)

# Generated at 2022-06-21 11:52:56.435502
# Unit test for function parse

# Generated at 2022-06-21 11:53:01.019386
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """\
    short description

    Args:
      arg1: description of arg1
      arg2(typing.List[int]): description of arg2
    """
    print(GoogleParser().parse(docstring))

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-21 11:53:05.742570
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    t0 = GoogleParser()
    assert t0.title_colon == True
    t1 = GoogleParser(title_colon=True)
    assert t1.title_colon == True
    t2 = GoogleParser(title_colon=False)
    assert t2.title_colon == False


# Generated at 2022-06-21 11:53:14.292773
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
        Short description.

        Long description. First paragraph.

        Long description. Second paragraph.

        Args:
            arg1 (str): Description of first argument.
            arg2 (int, optional): Description of second argument.
            arg3 (Optional[str]): Description of third argument.
            arg4 (bool): Description of fourth argument. Defaults to True if not
                         provided.
        Raises:
            AttributeError: Invalid value of `arg2`.
            KeyError: Invalid value of `arg3`.
        Returns:
            str: Description of returned value.
        '''

    doc = GoogleParser().parse(text)

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description. First paragraph.\n" \
                                   "Long description. Second paragraph."
    assert doc

# Generated at 2022-06-21 11:53:16.090292
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""
    pass

# Generated at 2022-06-21 11:53:32.565858
# Unit test for function parse
def test_parse():
    def f(x: int, y: int = 2) -> int:
        """Return the sum of x and y.

        Examples:
        >>> f(1, 1)
        2

        Args:
            x (int): first number to add
            y (int, optional): second number to add

        Returns:
            int: sum of x and y
        """
        return x + y

    doc = parse(inspect.getdoc(f))
    assert doc.short_description == "Return the sum of x and y."
    assert doc.long_description.strip() == """
    Examples:
    >>> f(1, 1)
    2"""
    assert doc.meta[0].args[0] == "examples"
    assert doc.meta[0].args[1] == "Examples"

# Generated at 2022-06-21 11:53:42.167856
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleparser = GoogleParser()
    assert googleparser.title_colon == True
    assert googleparser.sections.keys() == ['Raises', 'Parameters', 'Args', 'Example', 'Exceptions', 'Returns', 'Args', 'Attributes', 'Yields', 'Except']
    assert googleparser.sections['Raises'].title == 'Raises'
    assert googleparser.sections['Raises'].key == 'raises'
    assert googleparser.sections['Raises'].type == SectionType.MULTIPLE
    assert googleparser.sections['Parameters'].title == 'Parameters'
    assert googleparser.sections['Parameters'].key == 'param'
    assert googleparser.sections['Parameters'].type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:53:46.828384
# Unit test for constructor of class Section
def test_Section():
    s = Section("Example", "examples", SectionType.SINGULAR)
    assert s.title == "Example"
    assert s.key == "examples"
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:53:55.167836
# Unit test for function parse
def test_parse():
    class Cls:
        """Shows how to document a class.

        Arguments
        ---------
        cls: str
            The name of the class.
            Required.
        basis: str
            What the class is based on.
            Optional.

        Example
        -------
        >>> Cls("my_name")
        <__main__.Cls object at 0x7ff26b8d9208>
        >>> Cls("my_name", "your_name")
        <__main__.Cls object at 0x7ff26b8d9208>
        >>> Cls("your_name", "my_name")
        <__main__.Cls object at 0x7ff26b8d9208>
        """


# Generated at 2022-06-21 11:54:06.847284
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-21 11:54:09.960258
# Unit test for constructor of class Section
def test_Section():
    a = Section("test", "testkey", SectionType.MULTIPLE)
    assert a.title == "test"
    assert a.key == "testkey"
    assert a.type == SectionType.MULTIPLE
    try:
        a.type = SectionType.SINGULAR
    except Exception:
        pass
    else:
        assert False, "Should be a readonly property"


# Generated at 2022-06-21 11:54:14.991369
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("New section", "new_section", SectionType.SINGULAR))
    assert parser.titles_re.pattern == "^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields|New section):[ \t\r\f\v]*$"


# Generated at 2022-06-21 11:54:27.317951
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:54:34.668500
# Unit test for function parse
def test_parse():
    def _parse(text):
        p = GoogleParser()
        return p.parse(text)

    assert _parse("").long_description is None
    assert _parse("").blank_after_short_description is False
    assert _parse("").blank_after_long_description is False
    assert _parse("").short_description == ""
    assert _parse("\n").long_description is None
    assert _parse("\n").short_description == ""
    assert _parse("\n").blank_after_short_description is True
    assert _parse("\n").blank_after_long_description is False
    assert _parse("\n\n").long_description is None
    assert _parse("\n\n").short_description == ""
    assert _parse("\n\n").blank_after_short_description is True
    assert _