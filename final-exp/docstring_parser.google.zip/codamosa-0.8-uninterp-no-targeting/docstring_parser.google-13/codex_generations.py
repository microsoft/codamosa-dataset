

# Generated at 2022-06-21 11:45:19.285668
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    assert len(gp.sections) == 13
    section = Section("Example", "examples", SectionType.SINGULAR)
    gp.add_section(section)
    assert len(gp.sections) == 13
    section = Section("MySection", "mysection", SectionType.SINGULAR)
    gp.add_section(section)
    assert len(gp.sections) == 14


# Generated at 2022-06-21 11:45:23.537772
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Test:
        '''
        This is class docstring.

        This is first line of class docstring.
        This is second line of class docstring.
        '''

        # There is no docstring for func
        def func(self):
            pass

        def func_with_docstring(self):
            '''
            This is a function docstring.

            This is first line of function docstring.
            This is second line of function docstring.
            '''
            pass

        def func_with_docstring_and_blank_line(self):
            '''
            This is a function docstring.

            This is first line of function docstring.
            This is second line of function docstring.

            '''
            pass


# Generated at 2022-06-21 11:45:32.938343
# Unit test for function parse
def test_parse():
    # Testing section: Example
    text = """
    This is a docstring.

    Example.

    There is an example.
    """
    assert parse(text).short_description == "This is a docstring."
    assert parse(text).long_description == None
    assert parse(text).meta[0].args == ["Example"]
    assert parse(text).meta[0].description == "There is an example."

    # Testing section: Arguments, Args, Parameters, Params
    text = """
    Arguments:
        a (str): This is a docstring.
    """
    assert parse(text).meta[0].args == ["param", "a (str)"]
    assert parse(text).meta[0].description == "This is a docstring."
    assert parse(text).meta[0].arg_name == "a"

# Generated at 2022-06-21 11:45:41.129649
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()

    assert parse("test string") == Docstring(short_description="test string")

    assert parse("test\nstring") == Docstring(
        short_description="test",
        long_description="string",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    assert parse("test\n\nstring") == Docstring(
        short_description="test",
        long_description="string",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )


# Generated at 2022-06-21 11:45:54.223496
# Unit test for function parse
def test_parse():
    text = """\
        This function does something.

        This is a longer description of the function.

        Args:
            arg1: The first argument.
            arg2: The second argument.
                It can be long.
        """

    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This function does something."
    assert docstring.long_description == ("This is a longer description of the "
                                          "function.")
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ["param", "arg1: The first argument."]
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[0].type_name is None

# Generated at 2022-06-21 11:46:01.274842
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = \
"""Simple example docstring.

Args:
    arg1 (int): Description of `arg1`
    arg2 (str, optional): Description of `arg2`. Defaults to 'default'.
    arg3 (str, optional): Default value for arg3 is calculated.

Returns:
    tuple: Description of return value."""
    docstring = parse(text)
    assert docstring.short_description == "Simple example docstring."
    assert docstring.long_description  == None
    assert docstring.blank_after_short_description  == True
    assert docstring.blank_after_long_description  == False
    assert len(docstring.meta)  == 4
    assert docstring.meta[0].key == "param"
    assert docstring.meta[0].arg_name == "arg1"
    assert doc

# Generated at 2022-06-21 11:46:13.910422
# Unit test for constructor of class Section
def test_Section():
    my_section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert my_section.title == "Arguments"
    assert my_section.key == "param"
    assert my_section.type == SectionType.MULTIPLE

    my_section_1 = Section("Args", "param", SectionType.MULTIPLE)
    assert my_section_1.title == "Args"
    assert my_section_1.key == "param"
    assert my_section_1.type == SectionType.MULTIPLE

    my_section_2 = Section("Parameters", "param", SectionType.MULTIPLE)
    assert my_section_2.title == "Parameters"
    assert my_section_2.key == "param"
    assert my_section_2.type == SectionType.MULTIP

# Generated at 2022-06-21 11:46:14.507776
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    goo = GoogleParser()

# Generated at 2022-06-21 11:46:18.668204
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = DEFAULT_SECTIONS
    title_colon=True
    print("\nTest constructor function of class GoogleParser")
    # Construct a new GoogleParser class
    parser = GoogleParser(sections, title_colon)
    print(parser)


# Generated at 2022-06-21 11:46:23.898664
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test_sections = [
        Section("this is a test title", "param", SectionType.SINGULAR),
        Section("another title", "param", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    parser = GoogleParser(test_sections)
    assert test_sections == parser.sections.values()

# Generated at 2022-06-21 11:46:40.351232
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    def check(text, **kwargs):
        s = parse(text)
        for k, v in kwargs.items():
            assert getattr(s, k) == v

    check(
        '''
        Short description.

        Long description.

        Examples:
            Examples go here.

        Returns:
            None.

        Raises:
            RuntimeError
        ''',
        short_description="Short description.",
        long_description="Long description.",
        examples="Examples go here.",
        returns="None.",
        raises=["RuntimeError"],
        extra_sections=["Args", "Params", "Attributes"],
        sections_with_content=[
            "Returns",
            "Raises",
            "Examples",
            "Params",
        ],
    )


if __name__ == "__main__":
    test

# Generated at 2022-06-21 11:46:52.411250
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:46:59.053699
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """This function is used to test the class constructor"""
    sections = [Section("Raises", "raises", SectionType.MULTIPLE)]
    parser = GoogleParser(sections)
    assert len(parser.sections) == 1
    assert parser.sections["Raises"][0] == "raises"
    assert parser.sections["Raises"][1] == SectionType.MULTIPLE



# Generated at 2022-06-21 11:47:03.383716
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.sections
    assert parser.titles_re
    assert parser.title_colon
    # test add_section
    parser = GoogleParser()
    parser.add_section(Section("Allowed", "args", SectionType.MULTIPLE))
    assert parser.sections
    assert parser.sections["Allowed"]
    assert parser.sections["Allowed"].key == "args"
    assert parser.sections["Allowed"].type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:47:11.971257
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser()

# Generated at 2022-06-21 11:47:16.178539
# Unit test for constructor of class Section
def test_Section():
    t = Section("args","param", SectionType.MULTIPLE)
    assert t.title == "args"
    assert t.key == "param"
    assert t.type == SectionType.MULTIPLE



# Generated at 2022-06-21 11:47:28.505410
# Unit test for function parse
def test_parse():
    assert parse("""\
        This is a sample docstring.
        """) == Docstring(
        short_description="This is a sample docstring.",
        long_description=None,
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

    assert parse("""\
        This is a sample docstring.

        And this is a longer description.
        """) == Docstring(
        short_description="This is a sample docstring.",
        long_description="And this is a longer description.",
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=False,
    )


# Generated at 2022-06-21 11:47:38.676072
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse(): 
    # Examples
    docstring = """
    This is a very short description.

    This is a longer multi-line description. It explains in more detail what
    the method does and how it behaves under certain circumstances.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Yields:
        The yielded value. True for success, False otherwise.
    """

    assert parse(docstring).short_description == "This is a very short description."
    assert (
        parse(docstring).long_description == "This is a longer multi-line description. It explains in more detail what the method does and how it behaves under certain circumstances."
    )
    assert parse(docstring).blank_after_short_description == False

# Generated at 2022-06-21 11:47:42.264427
# Unit test for constructor of class Section
def test_Section():
    Error = False
    try:
        s = Section('Arguments', 'param', 'MULTIPLE')
    except Exception:
        Error = True
    assert not Error


# Generated at 2022-06-21 11:47:51.865137
# Unit test for constructor of class Section

# Generated at 2022-06-21 11:48:02.581242
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section = Section('Section1', 'section1', SectionType.SINGULAR)
    parser = GoogleParser()
    parser.add_section(section)
    assert parser.sections == {'Section1': section}


# Generated at 2022-06-21 11:48:13.948982
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Isolate the case where section already exists
    google = GoogleParser()
    new_section = Section("New", "new", SectionType.SINGULAR)
    google.add_section(new_section)
    new_section_2 = Section("New", "not_new", SectionType.SINGULAR_OR_MULTIPLE)
    google.add_section(new_section_2)
    assert(google.sections["New"].key == "not_new")

    # Isolate the case where section does not exist
    google = GoogleParser()
    new_section = Section("New", "new", SectionType.SINGULAR)
    google.add_section(new_section)
    assert(google.sections["New"] == Section("New", "new", SectionType.SINGULAR))

# Generated at 2022-06-21 11:48:23.162512
# Unit test for constructor of class Section
def test_Section():
    # Default parameters
    assert Section('Test', 'test', 0).title == 'Test'
    assert Section('Test', 'test', 0).key == 'test'
    assert Section('Test', 'test', 0).type == 0
    assert Section('Test', 'test', 0) == Section('Test', 'test', 0)

    # Non-default parameters
    assert Section('Test', 'test', 1).title == 'Test'
    assert Section('Test', 'test', 1).key == 'test'
    assert Section('Test', 'test', 1).type == 1
    assert Section('Test', 'test', 1) == Section('Test', 'test', 1)


# Generated at 2022-06-21 11:48:24.788087
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    assert GoogleParser().sections["NewSection"] == GoogleParser().sections["NewSection"]


# Generated at 2022-06-21 11:48:31.369280
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.sections["Args"] == Section("Args", "param", SectionType.MULTIPLE)
    assert parser.sections["Arguments"] == Section("Arguments", "param", SectionType.MULTIPLE)
    assert parser.sections["Parameters"] == Section("Parameters", "param", SectionType.MULTIPLE)
    assert parser.sections["Params"] == Section("Params", "param", SectionType.MULTIPLE)
    assert parser.sections["Raises"] == Section("Raises", "raises", SectionType.MULTIPLE)
    assert parser.sections["Exceptions"] == Section("Exceptions", "raises", SectionType.MULTIPLE)
    assert parser.sections["Except"] == Section("Except", "raises", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:48:35.670957
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser
    assert parser.sections is not None
    assert len(parser.sections) == 13

    parser = GoogleParser(title_colon=False)
    assert parser
    assert parser.sections is not None
    assert len(parser.sections) == 13

    parser = GoogleParser(sections=[])
    assert parser
    assert parser.sections is not None
    assert len(parser.sections) == 0


# Generated at 2022-06-21 11:48:38.521309
# Unit test for constructor of class Section
def test_Section():
    s = Section("Title", "key", SectionType.SINGULAR)
    assert s.title == "Title"
    assert s.key == "key"
    assert s.type == SectionType.SINGULAR



# Generated at 2022-06-21 11:48:44.596405
# Unit test for constructor of class Section
def test_Section():
    from docstring_parser.google import Section
    # test case 1
    title = "Example"
    key = "examples"
    type = SectionType.SINGULAR
    sec = Section(title, key, type)
    assert sec.title == title
    assert sec.key == key
    assert sec.type == type
    # test case 2
    title = "Parameters"
    key = "param"
    type = SectionType.MULTIPLE
    sec = Section(title, key, type)
    assert sec.title == title
    assert sec.key == key
    assert sec.type == type
    # test case 3
    title = "Raises"
    key = "raises"
    type = SectionType.MULTIPLE
    sec = Section(title, key, type)
    assert sec.title == title
   

# Generated at 2022-06-21 11:48:48.902216
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser= GoogleParser()
    assert "Arguments" in parser.sections
    assert "Returns" in parser.sections
    assert "Yields" in parser.sections
    assert "Raises" in parser.sections
    assert "Parameters" in parser.sections
    assert "Args" in parser.sections
    assert "Params" in parser.sections
    assert "Exceptions" in parser.sections
    assert "Except" in parser.sections
    assert "Attributes" in parser.sections
    assert "Example" in parser.sections
    assert "Examples" in parser.sections
    
    section = Section("Examplez", "examples", SectionType.MULTIPLE)
    parser.add_section(section)
    assert "Examplez" in parser.sections
    assert "Example" not in parser.sections
    assert "Examples" not in parser.sections


# Generated at 2022-06-21 11:48:59.670629
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("Foo", "foo", SectionType.SINGULAR)
    parser.add_section(new_section)

    print("Expected: \n", new_section.title + "\n")
    for word in parser.titles_re.split("Foo:"):
        print("Expected: \n", new_section.title)
    print("Expected: \n", new_section.title + ": ")
    print("Expected: \n", new_section.title)
    print("Expected: \n", new_section.title)

    with open("test_output/test_GoogleParser_add_section.txt", 'w') as f:
        for word in parser.titles_re.split("Foo:"):
            f.write(word)
            f

# Generated at 2022-06-21 11:49:25.355065
# Unit test for function parse
def test_parse():
    assert parse("This is a docstring.") == Docstring(
        short_description="This is a docstring."
    )
    assert parse("This is a: docstring.") == Docstring(
        short_description="This is a: docstring."
    )
    assert parse("This is a docstring.\n") == Docstring(
        short_description="This is a docstring."
    )
    assert parse("This is a docstring.\n\n") == Docstring(
        short_description="This is a docstring.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description=None,
    )

# Generated at 2022-06-21 11:49:33.856920
# Unit test for function parse
def test_parse():
    docstring = """
    Unit test for function parse.

    :param int param_int: int parameter
    :type param_int: int
    """
    doc = parse(docstring)
    assert doc.short_description == "Unit test for function parse."
    assert doc.blank_after_short_description == False
    assert doc.long_description == None
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 1

    exp_meta = [
        DocstringParam(
            args=["param", "param_int"],
            description="int parameter",
            arg_name="param_int",
            type_name="int",
            is_optional=None,
            default=None,
        )
    ]

# Generated at 2022-06-21 11:49:36.831773
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section = Section("Test", "test", SectionType.SINGULAR)
    parser = GoogleParser()
    parser.add_section(section)
    assert section in parser.sections.values()

# Generated at 2022-06-21 11:49:39.986416
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Possible and not too long."""
    doc = parse(text)
    assert(doc.short_description == 'Possible and not too long.')



# Generated at 2022-06-21 11:49:43.176433
# Unit test for constructor of class Section
def test_Section():
    assert Section("name", "key", SectionType.SINGULAR) == \
        Section._make(["name", "key", SectionType.SINGULAR])

# Generated at 2022-06-21 11:49:47.526200
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("foobar", "foobar_section", SectionType.MULTIPLE))
    assert("foobar" in gp.sections.keys())


# Generated at 2022-06-21 11:49:56.840821
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("").short_description == None
    assert parse("     ").short_description == None
    assert parse("\n").short_description == None
    assert parse("\n\n").short_description == None
    assert parse("\n\n\n").short_description == None

    # default sections
    assert parse("A short\n\nA long").short_description == "A short"
    assert parse("A short\n\nA long").long_description == "A long"
    assert parse("SMALL\n\nBIG").short_description == "SMALL"
    assert parse("SMALL\n\nBIG").long_description == "BIG"
    assert parse("short\n\n").short_description == "short"
    assert parse("short\n\n").long_description == None
    assert parse

# Generated at 2022-06-21 11:50:01.537333
# Unit test for function parse
def test_parse():
    doc_string = """\
    No summary.

    Long description.
    """
    doc = parse(doc_string)
    assert doc.short_description == 'No summary.'
    assert doc.long_description == 'Long description.'



# Generated at 2022-06-21 11:50:09.423231
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    name = "GoogleParser"
    main_args = sections, True
    main_kwargs = {}
    GoogleParser(*main_args, **main_kwargs)
    assert globals()[name]
    globals()[name].__init__(*main_args, **main_kwargs)
    try:
        globals()[name].__init__()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 11:50:20.591037
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:50:41.409216
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Check parse method
    text = '''
    test_GoogleParser_parse

    :param text: docstring element text
    :param title: title of section containing element
    :return:
    '''
    parser = GoogleParser()
    result = parser.parse(text)
    assert result.short_description == 'test_GoogleParser_parse'
    assert result.long_description == None
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 2
    assert result.meta[0].__class__.__name__ == 'DocstringParam'
    assert result.meta[0].description == 'docstring element text'
    assert result.meta[0].arg_name == 'text'
    assert result.meta[0].type_name

# Generated at 2022-06-21 11:50:48.905685
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Create a GoogleParser with default sections
    parser = GoogleParser()
    # Add a random section
    parser.add_section(Section("Need", "need", SectionType.SINGULAR))
    # Verify that the section is added
    assert "Need" in parser.sections
    # Verify that the section is updated
    assert parser.sections["Need"] == Section("Need", "need", SectionType.SINGULAR)


# Generated at 2022-06-21 11:50:56.511371
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    class A:
        def __init__(self):
            self.google_parser = GoogleParser()
        def add_section(self, section: Section):
            self.google_parser.add_section(section)
            return self.google_parser.sections[section.title]

    a = A()
    a.add_section(Section("Test", "test", SectionType.SINGULAR))
    assert a.add_section(Section("Test", "test", SectionType.MULTIPLE)) == a.add_section(Section("Test", "test", SectionType.MULTIPLE))


# Generated at 2022-06-21 11:51:03.531441
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("Test", "test", SectionType.SINGULAR),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    google_parser = GoogleParser(sections)
    section = Section("Test", "test", SectionType.SINGULAR)
    google_parser.add_section(section)

# Generated at 2022-06-21 11:51:16.550026
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test GoogleParser._parse method"""
    inst = GoogleParser()
    
    # Test case: empty docstring
    res = inst.parse('')
    assert res == Docstring()

    # Test case: no meta
    res = inst.parse('Short description.')
    assert res == Docstring(
        short_description='Short description.',
    )

    # Test case: meta: return, singular
    res = inst.parse('Returns: Short description.')
    assert res == Docstring(
        short_description=None,
        meta=[DocstringMeta(
            args=['returns'],
            description='Short description.',
        )],
    )

    # Test case: meta: return, multiple
    res = inst.parse('Returns: something: Short description.')

# Generated at 2022-06-21 11:51:26.644739
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    text = """
    """
    # Act
    result = GoogleParser().parse(text)
    # Assert
    assert result.long_description == None
    assert result.short_description == None
    assert result.meta == []
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False

    # Arrange
    text = """The shortest distance between two points is a good straight line.

"""
    # Act
    result = GoogleParser().parse(text)
    # Assert
    assert result.long_description == None
    assert result.short_description == "The shortest distance between two points is a good straight line."
    assert result.meta == []
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description

# Generated at 2022-06-21 11:51:30.988944
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Arrange
    parser = GoogleParser()

    section_member = Section("Members", "member", 2)
    expected_sections = DEFAULT_SECTIONS + [section_member]

    # Act
    parser.add_section(section_member)

    # Assert
    assert sorted(parser.sections) == sorted([s.title for s in expected_sections])


# Generated at 2022-06-21 11:51:43.198349
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Initialize a parser without any section
    gp = GoogleParser()

    # Add few sections to the parser
    section1 = Section("Test", "test", SectionType.SINGULAR)
    gp.add_section(section1)
    section2 = Section("Test_Multiple", "test_multiple", SectionType.MULTIPLE)
    gp.add_section(section2)
    section3 = Section("Test_SINGULAR_OR_MULTIPLE", "test_or_multiple", SectionType.SINGULAR_OR_MULTIPLE)
    gp.add_section(section3)

    # Check the titles_re of the parser
    expected_regex = "^(Test|Test_Multiple|Test_SINGULAR_OR_MULTIPLE)[ \t\r\f\v]*$"

# Generated at 2022-06-21 11:51:50.507201
# Unit test for function parse
def test_parse():
    text = """
        Parse the Google-style docstring into its components.

        :param text: docstring to parse
        :returns: parsed docstring
        """
    parser = GoogleParser()
    doc = parser.parse(text)
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ["returns"]
    assert doc.meta[0].description == "parsed docstring"

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 11:51:57.503939
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    empty = Docstring()
    assert GoogleParser().parse(None) == empty
    assert GoogleParser().parse('') == empty
    assert GoogleParser().parse('\n') == empty
    assert GoogleParser().parse('\n\n') == empty
    assert GoogleParser().parse('\n \n') == empty

    short = Docstring(short_description='foo')
    assert GoogleParser().parse('foo') == short
    assert GoogleParser().parse('foo   ') == short
    assert GoogleParser().parse('foo\n') == short
    assert GoogleParser().parse('foo\n\n') == short
    assert GoogleParser().parse('foo\n\n\n') == short
    assert GoogleParser().parse('foo\n\n\n\n') == short

# Generated at 2022-06-21 11:52:26.534449
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    docParser = GoogleParser()
    # Test __init__()
    assert isinstance(docParser, GoogleParser)
    # Test add_section()
    docParser.add_section(Section("s", "k", 1))
    assert "s" in docParser.sections
    # Test parse()
    text = "Tests for parse.\n\nArgs:\n    a (int): int.\n    b (str): str."
    assert isinstance(docParser.parse(text), Docstring)
    # Test _build_meta()
    assert isinstance(docParser._build_meta(":k.", "k"), DocstringMeta)
    # Test _build_single_meta()
    assert isinstance(docParser._build_single_meta(Section("s", "k", 0), "."), DocstringMeta)
    # Test _build

# Generated at 2022-06-21 11:52:39.174443
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.sections["Arguments"] == Section("Arguments", "param", SectionType.MULTIPLE)
    assert parser.sections["Args"] == Section("Args", "param", SectionType.MULTIPLE)
    assert parser.sections["Parameters"] == Section("Parameters", "param", SectionType.MULTIPLE)
    assert parser.sections["Params"] == Section("Params", "param", SectionType.MULTIPLE)
    assert parser.sections["Raises"] == Section("Raises", "raises", SectionType.MULTIPLE)
    assert parser.sections["Exceptions"] == Section("Exceptions", "raises", SectionType.MULTIPLE)
    assert parser.sections["Except"] == Section("Except", "raises", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:52:42.998542
# Unit test for constructor of class Section
def test_Section():
    title = 'title'
    key = 'key'
    type = 'type'
    section = Section(title, key, type)
    assert section
    assert section.title == title
    assert section.key == key
    assert section.type == type



# Generated at 2022-06-21 11:52:49.379168
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gParser = GoogleParser()
    assert (gParser.sections.keys() ==
            {'Raises', 'Returns', 'Arguments', 'Example', 'Params', 'Attributes',
             'Args', 'Parameters', 'Except', 'Examples', 'Yields'})
    assert (gParser.titles_re.pattern ==
            '^(Raises|Returns|Arguments|Example|Params|Attributes|Args|Parameters|Except|Examples|Yields):[ \\t\\r\\f\\v]*$')


# Generated at 2022-06-21 11:52:51.888498
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section(title= "Evaluation", key= "evaluation", type="multiply")
    parser.add_section(section)
    assert parser.sections["Evaluation"] == section

# Generated at 2022-06-21 11:53:01.437291
# Unit test for constructor of class Section
def test_Section():
    def test_one(title_, key_, type_):
        sec = Section(title_, key_, type_)
        assert sec.title == title_, \
            'sec.title = {} != {} = title_'.format(sec.title, title_)
        assert sec.key == key_, \
            'sec.key = {} != {} = key_'.format(sec.key, key_)
        assert sec.type == type_, \
            'sec.type = {} != {} = type_'.format(sec.type, type_)
    test_one('Arguments', 'param', SectionType.MULTIPLE)
    # The following should fail because SectionType.MULTIPLE is an IntEnum
    # test_one('Arguments', 'param', 'SectionType.MULTIPLE')

# Generated at 2022-06-21 11:53:11.838719
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """Description

    Args:
        pos1 (int): Description of pos1
        pos2: Description of pos2
        pos3 (type): Description of pos3
        *args: Description of *args
        **kwargs: Description of **kwargs
        kwonly1 (str, optional): Description of kwonly1
        kwonly2 (str): Description of kwonly2. Defaults to None.
        kwonly3 (str, optional): Description of kwonly3 with type

    Raises:
        NameError: Description of NameError
        TypeError: Description of TypeError

    Returns:
        int: Return value description
    """

    parsed_docstring = GoogleParser().parse(doc)
    print("short description:", parsed_docstring.short_description)

# Generated at 2022-06-21 11:53:24.502479
# Unit test for function parse
def test_parse():

    # Read docstring for testing
    import os
    import load_data

    # Retrieve docstring
    path = os.path.abspath(load_data.__file__)
    file = open(path, "r")
    txt = file.read()
    file.close()

    # Parse docstring
    from .google import parse
    doc = parse(txt)

    # Check output
    assert doc.short_description == "Loads ABIDE preprocessed data"
    assert doc.long_description == (
        "Data comes from: https://osf.io/ez7gp/wiki/Home/\n"
        "More Data Info: https://www.ncbi.nlm.nih.gov/pubmed/26065734"
    )

    assert len(doc.meta) == 6
    assert doc.meta

# Generated at 2022-06-21 11:53:28.766422
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():

    # Create a new parser
    parser = GoogleParser()

    # The section will be added
    section = Section("Raises", "raises", SectionType.MULTIPLE)
    parser.add_section(section)

    # Testing the adding of the section
    assert parser.sections['Raises'] == Section("Raises", "raises", SectionType.MULTIPLE)


# Generated at 2022-06-21 11:53:36.170691
# Unit test for function parse
def test_parse():
    """Unit test for function parse."""
    assert GoogleParser().parse("") == Docstring()
    doc = GoogleParser().parse("This is a docstring.")
    assert doc.short_description == "This is a docstring."
    assert doc.long_description is None
    assert doc.meta == []
    doc = GoogleParser().parse("This is a docstring.\nThis is more.")
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == "This is more."
    assert doc.meta == []

    # Arguments
    doc = GoogleParser().parse("This is a docstring.\n\nArgs:\n  x: int")
    assert doc.short_description == "This is a docstring."
    assert doc.long_description is None

# Generated at 2022-06-21 11:54:13.137810
# Unit test for function parse
def test_parse():
    # Google example
    text = '''
    Args:
        param1: The first parameter.
        param2: The second parameter.

    Returns:
        True if successful, False otherwise.

    '''
    docstring = parse(text)
    assert len(docstring.meta) == 2
    param1, returns = docstring.meta
    assert param1.args == ['param', 'param1']
    assert param1.description == 'The first parameter.'
    assert param1.arg_name == 'param1'
    assert returns.args == ['returns']
    assert returns.description == 'True if successful, False otherwise.'

    # Section title replacement

# Generated at 2022-06-21 11:54:14.450270
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()


# Generated at 2022-06-21 11:54:23.469949
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    """test GoogleParser constructor"""
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    google_parser = GoogleParser(sections)
    assert google_parser.sections == {'Arguments': Section(title='Arguments', key='param', type=SectionType.MULTIPLE)}
    assert google_parser.title_colon == True
    assert google_parser.titles_re == re.compile('^(Arguments):[ \t\r\f\v]*$', flags=re.M)


# Generated at 2022-06-21 11:54:28.999042
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser(title_colon=True)
    new_section = Section("Tests", "Tests", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(new_section)
    assert parser._setup() == re.compile(
        "^(Tests):[ \t\r\f\v]*$", flags=re.MULTILINE
    )