

# Generated at 2022-06-21 11:45:18.089216
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Assert GoogleParser object is returned from constructor
    google_parser = GoogleParser()
    assert type(google_parser) == GoogleParser

    # Assert section titles are a subset of the titles that were used to created the
    # GoogleParser object.
    parser_section_titles = google_parser.sections.keys()
    assert set(parser_section_titles).issubset(DEFAULT_SECTIONS)
    return


# Generated at 2022-06-21 11:45:19.650410
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert_GoogleParser = GoogleParser()
    assert assert_GoogleParser
    # pass


# Generated at 2022-06-21 11:45:21.682201
# Unit test for constructor of class Section
def test_Section():
    SECTION = Section("title", "key", true)
    assert SECTION.title == "title"
    assert SECTION.key == "key"
    assert SECTION.type == true

# Generated at 2022-06-21 11:45:24.088620
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    googleParser = GoogleParser()
    googleParser.parse(
            """Random docstring"""
    )
    assert(1 == 1)

# Generated at 2022-06-21 11:45:33.665517
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # testing all return types
    print("testing all return types")
    docstring_text = """Short summary.

    Longer description.

    Args:
      param1: The first parameter.
      param2: The second parameter.
    Yields:
      True if successful, False otherwise.
    Returns:
      Returns True if successful, False otherwise.
    Raises:
      ValueError: When things go wrong.
    """

    # parse docstring text
    result = parse(docstring_text)

    # assert all
    assert result.meta[0].get_text() == "Short summary."
    assert result.meta[1].get_text() == "Longer description."
    assert result.meta[2].get_text() == "The first parameter."

# Generated at 2022-06-21 11:45:43.888766
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
	
	def test_function(arg1, arg2):

		"""
		Summary line. 
		This is a longer description. 
		Extended periods can be used to separate groups of words. 
		The blank line above separates the summary from the rest of the 
		description, so it does not appear in the docstring. 

		This is a description of param1. 
		:param arg1: arg1 description 
		:type arg1: type1
		:param arg2: arg2 description 
		:type arg2: type2

		:returns: description of the return value 
		:rtype: the return type
		"""
		pass


	d = parse(inspect.getdoc(test_function))
	print(d.short_description)
	

# Generated at 2022-06-21 11:45:48.139252
# Unit test for constructor of class Section
def test_Section():
    assert len(Section._fields) == 3
    assert Section._fields[0] == 'title'
    assert Section._fields[1] == 'key'
    assert Section._fields[2] == 'type'


# Generated at 2022-06-21 11:45:56.477917
# Unit test for function parse
def test_parse():
    docstring = """
    Adds all the items inside the given iterables.

    Examples:
        >>> a = set([1, 2, 3])
        >>> a.update([1, 2, 4])
        >>> a
        {1, 2, 3, 4}
        >>> b = set([1, 2, 3])
        >>> b.update({1, 4})
        >>> b
        {1, 2, 3, 4}
    """
    # print(parse(docstring))


# Generated at 2022-06-21 11:46:09.291213
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    for i,o in TEST_CASES:
        try:
            res = parse(i)
        except Exception as e:
            assert False, str(e)
        assert res == o


# Generated at 2022-06-21 11:46:12.364386
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("test", "test", SectionType.SINGULAR_OR_MULTIPLE))


# Generated at 2022-06-21 11:46:34.367596
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
        Parse the Google-style docstring into its components.
        
        :returns: parsed docstring
        """)
    assert docstring.short_description == "Parse the Google-style docstring into its components."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.long_description == ":returns: parsed docstring"
    assert docstring.meta[0].args[0] == 'returns'
    assert docstring.meta[0].args[1] == ':returns'
    assert isinstance(docstring.meta[0], DocstringReturns)
    assert docstring.meta[0].description == 'parsed docstring'
    assert docstring.meta

# Generated at 2022-06-21 11:46:37.884799
# Unit test for constructor of class Section
def test_Section():
    section = Section(title="Args",key="param",type=SectionType.MULTIPLE)
    assert section.title == "Args"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:46:39.014783
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert_equal(GoogleParser().sections, DEFAULT_SECTIONS)


# Generated at 2022-06-21 11:46:50.060787
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-21 11:47:03.054340
# Unit test for function parse
def test_parse():
    s = r'''Short description.

Long description.

Args:
    arg1 (int): Argument 1.
    arg2 (str): Argument 2.

Returns:
    bool: Does it return?
'''
    d = parse(s)
    # Test short_description
    assert d.short_description == 'Short description'
    # Test blank_after_short_description
    assert d.blank_after_short_description == True
    # Test long_description
    assert d.long_description == 'Long description.'
    # Test blank_after_long_description
    assert d.blank_after_long_description == False
    # Test meta
    # Test arg1
    arg1 = d.meta[0]
    assert arg1.title == 'Args'
    assert arg1.key == 'param'
    assert arg

# Generated at 2022-06-21 11:47:04.145203
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser()
    print(p)

# Generated at 2022-06-21 11:47:13.228977
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Single line summary.
    
    Extended description.
    """
    Docstring= GoogleParser().parse(docstring)
    # assert Docstring.short_description == 'Single line summary.'
    # assert Docstring.long_description == 'Extended description.'
    # assert Docstring.blank_after_short_description
    # assert Docstring.blank_after_long_description
    # assert not Docstring.meta
    #
    # docstring = 'Single line summary.\n'
    # Docstring= GoogleParser().parse(docstring)
    # assert Docstring.short_description == 'Single line summary.'
    # assert not Docstring.long_description
    # assert Docstring.blank_after_short_description
    # assert Docstring.blank_after_long_description
    # assert not Docstring.meta



# Generated at 2022-06-21 11:47:26.466076
# Unit test for constructor of class Section
def test_Section():

    # Case 1
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE

    # Case 2
    s = Section("Args", "param", SectionType.MULTIPLE)
    assert s.title == "Args"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE

    # Case 3
    s = Section("Parameters", "param", SectionType.MULTIPLE)
    assert s.title == "Parameters"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE

    # Case 4

# Generated at 2022-06-21 11:47:36.997759
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Create instance of class GoogleParser
    google_parser = GoogleParser()
    # Get the sections of the class
    sections = google_parser.sections
    # Test if the sections include a section which is added before
    assert sections['Todo'] is None
    # Create a new section
    section_todo = Section("Todo", "todo", SectionType.SINGULAR)
    # Add the section to the google_parser
    google_parser.add_section(section_todo)
    # Get the sections of the class
    sections = google_parser.sections
    # Test if the sections include a section which is added before
    assert sections['Todo'] is not None
    # Test if the title of the section is equal to the title of added section
    assert sections['Todo'].title == section_todo.title
    # Test if the

# Generated at 2022-06-21 11:47:48.764345
# Unit test for constructor of class Section
def test_Section():
    sec_1 = Section("Arguments", "param", SectionType.MULTIPLE)
    sec_2 = Section("Args", "param", SectionType.MULTIPLE)
    sec_3 = Section("Parameters", "param", SectionType.MULTIPLE)
    sec_4 = Section("Params", "param", SectionType.MULTIPLE)
    sec_5 = Section("Raises", "raises", SectionType.MULTIPLE)
    sec_6 = Section("Exceptions", "raises", SectionType.MULTIPLE)
    sec_7 = Section("Except", "raises", SectionType.MULTIPLE)
    sec_8 = Section("Attributes", "attribute", SectionType.MULTIPLE)
    sec_9 = Section("Example", "examples", SectionType.SINGULAR)
    sec_

# Generated at 2022-06-21 11:48:01.604116
# Unit test for constructor of class Section

# Generated at 2022-06-21 11:48:13.321439
# Unit test for function parse
def test_parse():
    assert parse("").short_description is None
    assert parse("").long_description is None
    assert parse("").blank_after_short_description is False
    assert parse("").blank_after_long_description is False

    assert parse("A").short_description == "A"
    assert parse("A").long_description is None
    assert parse("A").blank_after_short_description is False
    assert parse("A").blank_after_long_description is False

    assert parse("A\n").short_description == "A"
    assert parse("A\n").long_description is None
    assert parse("A\n").blank_after_short_description is True
    assert parse("A\n").blank_after_long_description is False

    assert parse("A\n\n").short_description == "A"

# Generated at 2022-06-21 11:48:21.147978
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = DEFAULT_SECTIONS
    title_colon = True
    gparser = GoogleParser(DEFAULT_SECTIONS, title_colon)
    assert (sections == gparser.sections)
    assert (title_colon == gparser.title_colon)


    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    gparser = GoogleParser(sections)
    assert (sections == gparser.sections)
    assert (True == gparser.title_colon)

    sections = [Section("Raises", "raises", SectionType.MULTIPLE)]
    gparser = GoogleParser(sections)
    assert (sections == gparser.sections)
    assert (True == gparser.title_colon)

    sections = [Section("Example", "examples", SectionType.SINGULAR)]

# Generated at 2022-06-21 11:48:25.289243
# Unit test for constructor of class Section
def test_Section():
    # title = line 1
    # key = type of line 2
    # type = type of line 3
    section = Section("title", "key", SectionType.SINGULAR)
    assert section.title == "title"
    assert section.key == "key"
    assert section.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:48:27.485595
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) == Section("Arguments", "param", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:48:35.270201
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Foo:
        """Short desc

        Long desc

        No blank line after long desc

        Args:
          a: a
          b (int): b
            Another line of b
          c: c. Defaults to 0.

        Returns:
          A description of return value

        Raises:
          ValueError: ValueError

        Attributes:
          hello: hello
          world: world
        """

    doc = parse(Foo.__doc__)
    assert doc.short_description == "Short desc"
    assert doc.long_description == "Long desc"
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert len(doc.meta) == 7
    assert doc.meta[0].args == ["param", "a"]

# Generated at 2022-06-21 11:48:42.673894
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:48:53.648939
# Unit test for function parse
def test_parse():
    docstring = """
    Example Google-style docstring.

    This text is long description. It may contain multiple paragraphs separated by empty lines.
    Lorem Ipsum is simply dummy text of the printing and typesetting industry.

    :param param1: The first parameter.
    :type param1: string
    :param param2: The second parameter.
    :type param2: bool, optional
    :return: This is a description of what is returned.
    :rtype: int
    :raises keyError: raises an exception
    :raises ImportError: if something cannot be imported

    """
    result = parse(docstring)
    print(result)
    assert(result.short_description == "Example Google-style docstring.")

# Generated at 2022-06-21 11:48:59.381382
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser([Section("Foo", "foo", SectionType.MULTIPLE)])
    assert(parser.sections["Foo"].type == SectionType.MULTIPLE)
    parser.add_section(Section("Foo", "foo", SectionType.SINGULAR))
    assert(parser.sections["Foo"].type == SectionType.SINGULAR)

# Generated at 2022-06-21 11:49:07.064193
# Unit test for function parse
def test_parse():
    # Setup
    docstring = """Summary line.

Description

Attributes:
    attr1 (str): Description of `attr1`.
    attr2 (:obj:`int`, optional): Description of `attr2`, defaults to 42.

Args:
    param1 (:obj:`int`): Description of `param1`.
    param2: Description of `param2` (default 42).

Returns:
    :obj:`str`: Description of returned object.

Examples:
    Examples should be written in doctest format, and should illustrate how
    to use the function/class.
    >>> x = 42
"""

# Generated at 2022-06-21 11:49:12.851113
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser()
    assert p


# Generated at 2022-06-21 11:49:17.198851
# Unit test for function parse
def test_parse():
    text = """
    short description.

    long
    description.

    Arguments:

      first_name (str): the first name.
      age (int, optional): the age. Defaults to 42.

    Returns:

      dict: dictionary of things.
    """
    ret = parse(text)

# Generated at 2022-06-21 11:49:21.046444
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    parser = GoogleParser(sections=sections)
    # test default value of title_colon
    assert parser.title_colon == True
    # test for all the sections
    for s in sections:
        assert s in parser.sections.values()


# Generated at 2022-06-21 11:49:22.178031
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()



# Generated at 2022-06-21 11:49:23.859965
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().sections == GoogleParser().sections
    

# Generated at 2022-06-21 11:49:33.080104
# Unit test for constructor of class Section
def test_Section():
    with pytest.raises(ValueError):
        Section('title', 'key', 'type')
    with pytest.raises(ValueError):
        Section('title', 'key', -1)
    with pytest.raises(ValueError):
        Section('title', 'key', 3)

    assert Section('title', 'key', SectionType.MULTIPLE) == \
    Section('title', 'key', SectionType.MULTIPLE)
    assert Section('title1', 'key', SectionType.MULTIPLE) != \
    Section('title2', 'key', SectionType.MULTIPLE)
    assert Section('title', 'key1', SectionType.MULTIPLE) != \
    Section('title', 'key2', SectionType.MULTIPLE)

# Generated at 2022-06-21 11:49:36.722456
# Unit test for constructor of class Section
def test_Section():
    sections = DEFAULT_SECTIONS
    for s in sections:
        assert s.title == s.title
        assert s.key == s.key
        assert s.type == s.type


# Generated at 2022-06-21 11:49:50.079984
# Unit test for function parse
def test_parse():
    class A:
        def f(self, *, a, b, c=None, **kwargs):
            """This is description.

            Args:
                a: arg0
                b: arg1
                c: arg2 (optional)
                d: arg3, required

            Raises:
                ValueError: When some bad thing.

            Returns:
                bool: the return value
            """
            pass

    doc = parse(A.f.__doc__)
    print(doc)
    assert doc.short_description == "This is description."

# Generated at 2022-06-21 11:49:52.710778
# Unit test for constructor of class Section
def test_Section():
    section = Section("Título", "param", SectionType.MULTIPLE)
    assert section.title == "Título"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:49:56.306927
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print('Start unit test for GoogleParser')
    p = GoogleParser()
    print(p)
    for i, s in enumerate(p.sections):
        print('    ', i, s.title)


# Generated at 2022-06-21 11:50:05.758344
# Unit test for constructor of class Section
def test_Section():
    section = Section("Bienvenue", "param", SectionType.SINGULAR_OR_MULTIPLE)
    assert "Bienvenue" in section
    assert section.title == "Bienvenue"
    assert section.key == "param"
    assert section.type == 2


# Generated at 2022-06-21 11:50:13.466042
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    def f():
        """Short
        Long

        Raises:
            ValueError: If x is not a number.
        """
        pass
    import inspect
    doc = inspect.getdoc(f)
    p = parse(doc)
    assert p.short_description == "Short"
    assert p.long_description == "Long"
    assert isinstance(p.meta[0], DocstringRaises)
    assert p.meta[0].args == ['raises', 'ValueError: If x is not a number.']
    assert p.meta[0].description == "If x is not a number."
    assert p.meta[0].type_name == 'ValueError'

# Generated at 2022-06-21 11:50:22.610469
# Unit test for constructor of class Section
def test_Section():
    sectionName = Section("Test", "test", SectionType.SINGULAR)
    if sectionName.title != "Test":
        print("Test Failed: " + "sectionName.title does not equal Test")
        return
    if sectionName.key != "test":
        print("Test Failed: " + "sectionName.key does not equal test")
        return
    if sectionName.type != SectionType.SINGULAR:
        print("Test Failed: " + "sectionName.type does not equal SINGULAR")
        return
    print("Test Succeeded")



# Generated at 2022-06-21 11:50:30.441403
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test normal add section
    parser = GoogleParser()
    Section1 = Section("NewSection", "new", SectionType.SINGULAR)
    parser.add_section(Section1)
    assert(parser.sections.get("NewSection") == Section1)
    # Test replace section
    Section2 = Section("Example", "new", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(Section2)
    assert(parser.sections.get("Example") == Section2)


# Generated at 2022-06-21 11:50:36.904091
# Unit test for constructor of class Section
def test_Section():
    title = 'title'
    key = 'key'
    type = 'single'
    section = Section(title, key, type)
    title_test = section.title
    key_test = section.key
    type_test = section.type
    assert title == title_test
    assert key == key_test
    assert type == type_test


# Generated at 2022-06-21 11:50:44.332057
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    g.add_section(Section("new_section_title", "new_section_key", "Singular"))
    assert g.title_colon
    g.add_section(Section("new_section_title", "new_section_key", "Singular"))
    assert g.titles_re == re.compile(
        "^(Raises|Exceptions|Except|new_section_title):[ \t\r\f\v]*$", flags=re.M
    )
    assert g.sections["new_section_title"] == Section(
        "new_section_title", "new_section_key", "Singular"
    )



# Generated at 2022-06-21 11:50:56.669899
# Unit test for constructor of class Section
def test_Section():
    section = Section("param", "param", SectionType.SINGULAR)
    assert (section.title == "param")
    assert (section.key == "param")
    assert (section.type == SectionType.SINGULAR)

    section = Section("attribute", "attribute", SectionType.MULTIPLE)
    assert (section.title == "attribute")
    assert (section.key == "attribute")
    assert (section.type == SectionType.MULTIPLE)

    section = Section("returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert (section.title == "returns")
    assert (section.key == "returns")
    assert (section.type == SectionType.SINGULAR_OR_MULTIPLE)


# Generated at 2022-06-21 11:50:58.685244
# Unit test for constructor of class Section
def test_Section():
    try:
        title = Section("foo", "bar", 1)
    except Exception:
        title = None
    assert title


# Generated at 2022-06-21 11:51:04.967219
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """This is the short description.
    
    And this is the long description for this function.
    
    Args:
        arg1: The first argument.
        arg2: The second argument.
        
    Returns:
        The return value. True for success, False otherwise.
    """
    result = GoogleParser().parse(docstring)
    print(result.short_description)
    print(result.long_description)
    print(result.meta[0].description)
    print(result.meta[1].description)

# Generated at 2022-06-21 11:51:10.361201
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Single line short description

One-line long description.

    :returns: the answer
    :rtype: int
    """
    parser = GoogleParser()
    result_dict = parser.parse(text)
    assert len(result_dict) == 3


# Generated at 2022-06-21 11:51:24.161965
# Unit test for function parse
def test_parse():
    # Regular one
    d = parse("""\
        Short one line summary.

        Extended description.

        Args:
            arg_one: The first argument.
            arg_two: The second argument.
        Yields:
            The yielded value.
            With description.
        Raises:
            Exception: The exception description.
        """)
    # Simple one
    e = parse("""\
        Short one line summary.
        """)
    # With multiple returns and optional parameters.

# Generated at 2022-06-21 11:51:33.400893
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Only run this if you have pytest installed
    try:
        import pytest
    except ImportError:
        return
    # This is a test function which we can reference below
    def f(a, b=2):
        """Description
        Args:
            a (int): first integer
            b (int): second integer. Defaults to 2
        Returns:
            int: a + b
        """
        pass

    # Our actual test

# Generated at 2022-06-21 11:51:45.311327
# Unit test for function parse
def test_parse():
    """Test parsing of docstrings."""
    docstring = """A simple docstring.
    :param foo: Int like how many foos
    :type foo: int
    :param bar: Float like how many bars
    :type bar: float
    :return: Total foos plus bars
    :rtype: float
    """
    ds = parse(docstring)
    assert ds.short_description == "A simple docstring."
    assert ds.meta[0].description == "Int like how many foos"
    assert ds.meta[0].type_name == "int"
    assert ds.meta[0].arg_name == "foo"
    assert ds.meta[1].description == "Float like how many bars"
    assert ds.meta[1].type_name == "float"

# Generated at 2022-06-21 11:51:54.857033
# Unit test for function parse
def test_parse():
    text1 = """
Short description

Long description.

Raises:
    AttributeError: An error occurred.
"""
    res = parse(text1)
    assert len(res.meta) == 1
    assert res.meta[0].description == "An error occurred."
    assert res.meta[0].args == ["raises", "AttributeError"]
    assert isinstance(res.meta[0], DocstringRaises)

    text2 = """
Short description

Long description.

Raises:
    AttributeError: An error occurred.
        More details.
    TypeError: Another error occurred.
        More details.
"""
    res = parse(text2)
    assert len(res.meta) == 2
    assert res.meta[0].description == "An error occurred.\nMore details."
    assert res.meta

# Generated at 2022-06-21 11:52:06.159462
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # set up object
    parser = GoogleParser()
    # set up text
    text = '''
    Short description

    Long description

    Attributes
        attr1 (List[int]): Description of attr1
        attr2 (List[int]): Description of attr2

    Raises
        Exception: Description of exception

    Parameters
        a (int): Description of a
        b (int): Description of b
'''
    # exercise parse
    result = parser.parse(text)
    # verify
    assert result.short_description == "Short description"
    assert result.long_description == "Long description"
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 3

# Generated at 2022-06-21 11:52:18.486932
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()

# Generated at 2022-06-21 11:52:27.768453
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Create a new section
    section = Section("Author", "author", SectionType.SINGULAR)

    # Create a new parser, add the new section and parse a docstring
    text = "Google style docstring\n\nAuthor: Thomas\n"
    parser = GoogleParser()
    parser.add_section(section)
    doc = parser.parse(text)

    # Check the parsed docstring
    assert len(doc.meta) == 1
    assert doc.meta[0].key == "author"
    assert doc.meta[0].args == ["author", "Thomas"]
    assert doc.meta[0].description == None

    # Create a new section and add it to the parser
    section = Section("Author", "author", SectionType.SINGULAR)

    # Create a new parser, add the new section and parse a docstring
   

# Generated at 2022-06-21 11:52:34.942529
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    parser = GoogleParser()
    parser.add_section(section)
    assert parser.sections["Arguments"] == Section("Arguments", "param", SectionType.MULTIPLE)
    #Test to add an existing section of the same title
    parser.add_section(section)


# Generated at 2022-06-21 11:52:35.600256
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-21 11:52:45.923205
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = GoogleParser().parse("""This is a test
    another line
    def test\n\n""")
    assert d.short_description == "This is a test another line"
    assert d.long_description == "def test"
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == True

    d = GoogleParser().parse("""This is a test
        Another test
        def test\n\n""")
    assert d.short_description == "This is a test Another test"
    assert d.long_description == "def test"
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == True


# Generated at 2022-06-21 11:52:55.594520
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Add", "add", SectionType.SINGULAR))
    parser.add_section(Section("Show", "show", SectionType.SINGULAR_OR_MULTIPLE))
    assert parser.sections["Add"] == Section("Add", "add", SectionType.SINGULAR)
    assert parser.sections["Show"] == Section("Show", "show", SectionType.SINGULAR_OR_MULTIPLE)


# Generated at 2022-06-21 11:53:00.240307
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    title_colon = True
    sections = DEFAULT_SECTIONS
    parser = GoogleParser(sections, title_colon)
    parser.add_section(Section("To", "to", SectionType.SINGULAR))
    sections.append(Section("To", "to", SectionType.SINGULAR))
    assert sections == parser.sections


# Generated at 2022-06-21 11:53:07.752588
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    new_section = Section("test", "test", SectionType.MULTIPLE)
    p.add_section(new_section)
    new_section.title == "test"
    new_section.key == "test"
    new_section.type == SectionType.MULTIPLE
    assert new_section.title == "test"
    assert new_section.key == "test"
    assert new_section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:53:08.813814
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()



# Generated at 2022-06-21 11:53:12.133286
# Unit test for function parse
def test_parse():
    doc = """
    Calculate the square of a number.
    :param x: number to square
    :type x: int
    :rtype: int
    :raises TypeError: if x is not an integer
    """
    print(parse(doc))



# Generated at 2022-06-21 11:53:24.689297
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:53:33.185947
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()

# Generated at 2022-06-21 11:53:37.810753
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    from .common import DocstringAttribute

    gp = GoogleParser()
    gp.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))

    doc = gp.parse("""
    Attributes:
        attribute1: The first.
    """)

    assert doc.meta == [
        DocstringAttribute(args=["attribute", "attribute1"], description="The first.")
    ]

# Generated at 2022-06-21 11:53:42.886138
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Titletest","paramtest", SectionType.SINGULAR)
    assert parser.sections.get("Titletest") == None
    parser.add_section(section)
    assert parser.sections.get("Titletest") == section


# Generated at 2022-06-21 11:53:52.805134
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    This methods tests the add_section function
    """
    # initialize a default Google parser object 
    g = GoogleParser()
    # add a section to the google parser
    g.add_section(Section("Input", "input", SectionType.SINGULAR))
    # create and parse a google docstring
    d = g.parse("""Input: test""")
    # verify that the parsed docstring has a correct input section
    assert d.meta[0].args[0] == "input"
    assert d.meta[0].description == "test"
    # printing the google parser object
    g.__repr__()
    # printing the parsed docstring object
    d.__repr__()


# Generated at 2022-06-21 11:54:10.942672
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    s = Section("Attributes", "attribute", SectionType.MULTIPLE)
    parser.add_section(s)
    assert s in parser.sections.values()
    new_s = Section("Attributes", "attr", SectionType.MULTIPLE)
    parser.add_section(new_s)
    assert new_s in parser.sections.values()
    assert s not in parser.sections.values()
    assert parser.sections["Attributes"] == new_s

# Generated at 2022-06-21 11:54:14.248540
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parsed = Docstring()
    parser = GoogleParser()
    assert parser.sections is not None
    assert parser.titles_re is not None
    assert parser.title_colon is True
    assert parsed == parser.parse("")
    return



# Generated at 2022-06-21 11:54:26.830257
# Unit test for function parse
def test_parse():
    def foo(a, b, c=3, *, d=4, e=5, f="6", **kwargs):
        '''a b c.
        :param a: a
        :type a: int
        :param b: b
        :param d: d
        :param e: z
        :param f: y
        :param g: g
        :param h: h
        :param c: c
        :type c: int
        :param kwargs: kwargs
        :return:
        '''
        pass


# Generated at 2022-06-21 11:54:33.865808
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """ """
    doc = inspect.cleandoc("""\
    This is a sample docstring.
    This continues the description.
    This is the second line.

    This is the third line.

    Args:
        arg1: This is DocstringParam object.
        arg2: This is DocstringParam object, too.
        arg3: This is also DocstringParam object.

    Example:
        code-block:: python

        >>> print("hello world")
        hello world

    Returns:
        This is the DocstringReturns object.
        This is the second line.
    """)
    print("==================")
    print(doc)
    print("==================")
    print(GoogleParser().parse(doc))