

# Generated at 2022-06-21 11:44:57.850858
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    assert google_parser.parse("") == Docstring()
    assert google_parser.parse("Hello") == Docstring(
        short_description="Hello",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )
    assert google_parser.parse("Hello\n\n") == Docstring(
        short_description="Hello",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )

# Generated at 2022-06-21 11:45:07.842001
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # initialize parser
    parser = GoogleParser(title_colon=False)
    parser.add_section(Section("Test", "test", SectionType.SINGULAR))
    # create docstring
    docstring = """
        :test: something
    """
    # test
    assert parser.sections["Test"] == Section("Test", "test", SectionType.SINGULAR)
    assert parser.parse(docstring) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=["test"],
                description="something",
            ),
        ],
    )


# Generated at 2022-06-21 11:45:18.836773
# Unit test for constructor of class GoogleParser
def test_GoogleParser():

    # Test for default settings

    gp = GoogleParser()
    assert gp.title_colon
    assert 'Returns' in gp.sections
    assert gp.sections['Returns'].title == 'Returns'
    assert gp.sections['Returns'].key == 'returns'
    assert gp.sections['Returns'].type == SectionType.SINGULAR_OR_MULTIPLE

    # Test for accepted Sections

# Generated at 2022-06-21 11:45:25.408014
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  parameter = "text"
  text1 = "a, b"
  text2 = "c, .."
  text3 = "?d, e"
  text4 = "f, *"
  text5 = "g, **"
  result1 = {'args': ['param', text1], 'description': None, 'arg_name': text1.split(", ")[0], 'type_name': text1.split(", ")[1], 'is_optional': False, 'default': None}
  result2 = {'args': ['param', text2], 'description': None, 'arg_name': text2.split(", ")[0], 'type_name': text2.split(", ")[1], 'is_optional': True, 'default': None}

# Generated at 2022-06-21 11:45:28.549457
# Unit test for constructor of class Section
def test_Section():
    sect = Section("Args", "param", SectionType.MULTIPLE)
    assert sect.title == "Args"
    assert sect.key == "param"
    assert sect.type == SectionType.MULTIPLE
    return sect



# Generated at 2022-06-21 11:45:34.794202
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    def test_section(section_name, section_key, section_type):
        _section = Section(section_name, section_key, section_type)
        gparser = GoogleParser()
        gparser.add_section(_section)
        assert gparser.sections[section_name] == _section
        assert gparser.sections[section_name].title == section_name
        assert gparser.sections[section_name].key == section_key
        assert gparser.sections[section_name].type == section_type
    test_section('TESTNAME','TESTKEY',0)
    test_section('TESTNAME','TESTKEY',1)
    test_section('TESTNAME','TESTKEY',2)


# Generated at 2022-06-21 11:45:38.709176
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert(s.title == "Arguments")
    assert(s.key == "param")
    assert(s.type == SectionType.MULTIPLE)

# Generated at 2022-06-21 11:45:40.975885
# Unit test for constructor of class Section
def test_Section():
    section = Section(title="t", key="k", type="type")
    assert section.title == "t"
    assert section.key == "k"
    assert section.type == "type"

# Generated at 2022-06-21 11:45:48.741361
# Unit test for function parse
def test_parse():
    text = ''' One line summary.

    Longer description. Can have multiple paragraphs.
    List:
    - item 1
    - item 2
    - item 3

    Can have examples
    >>> a = 5
    >>> print(a)
    5
    '''

    docstring = parse(text)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:45:54.938924
# Unit test for function parse
def test_parse():
    """Simple test of function parse."""

    docstring = parse.__doc__
    doc = GoogleParser().parse(docstring)
    print(doc.short_description)
    print([x.description for x in doc.meta])
    print([x.type_name for x in doc.meta])
    print(doc.long_description)



# Generated at 2022-06-21 11:46:59.000799
# Unit test for constructor of class Section
def test_Section():

	s1 = Section("Args", "param", 2)
	s2 = Section("Example", "examples", 0)
	s3 = Section("Returns", "returns", 1)

	assert(s1.title == "Args")
	assert(s2.title == "Example")
	assert(s3.title == "Returns")

	assert(s1.key == "param")
	assert(s2.key == "examples")
	assert(s3.key == "returns")

	assert(s1.type == 2)
	assert(s2.type == 0)
	assert(s3.type == 1)


# Generated at 2022-06-21 11:47:02.774411
# Unit test for constructor of class Section
def test_Section():
    section= Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:47:10.949270
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    parser = GoogleParser()
    parser.sections = sections
    assert parser.sections == sections

    section = Section("Args", "param", SectionType.MULTIPLE)
    # Test adding a new section
    parser.add_section(section)
    assert parser.sections == {'Arguments': sections[0], 'Args': section}

    section = Section("Args", "param", SectionType.SINGULAR)
    # Test replace a section
    parser.add_section(section)
    assert parser.sections == {'Arguments': sections[0], 'Args': section}

# Generated at 2022-06-21 11:47:23.477841
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gparser = GoogleParser()

# Generated at 2022-06-21 11:47:30.792957
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    lst = [Section("Example", "example", SectionType.SINGULAR), Section("Arguments", "arg", SectionType.MULTIPLE)]
    gp = GoogleParser(lst)
    assert gp.sections['Example'].key == 'example'
    assert gp.sections['Arguments'].key == 'arg'
    assert gp.sections['Example'].type == 0
    assert gp.sections['Arguments'].title == "Arguments"


# Generated at 2022-06-21 11:47:39.932262
# Unit test for function parse
def test_parse():
    docstr = """
    Short description.

    Long description.

    Args:
        arg_name: Argument description.

    Raises:
        ExceptionName: Description.

    Example:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

    Returns:
        Description of return values.

    """
    doc = parse(docstr)
    # ShortDescription should be "Short description."
    assert doc.short_description == "Short description."
    # LongDescription should be "Long description."
    assert doc.long_description == "Long description."
    # BlankAfterShortDescription should be true
    assert doc.blank_after_short_description == True
    # BlankAfterLongDescription should be false
    assert doc.blank_after_long_description == False
    # Metadata should be a list of DocstringParam

# Generated at 2022-06-21 11:47:44.198767
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:47:48.105923
# Unit test for constructor of class Section
def test_Section():
    sec = Section(title='Voltage', key='V', type=SectionType.MULTIPLE)
    assert sec.title == 'Voltage'
    assert sec.key == 'V'
    assert sec.type == SectionType.MULTIPLE
    return sec


# Generated at 2022-06-21 11:47:58.610264
# Unit test for function parse
def test_parse():
    doc = """Summary line.

    Description longer than one line. Description after empty line.

    Args:
        param1: The first parameter.
        param2: The second parameter.

    Returns:
        True if successful, False otherwise.

    """
    p = parse(doc)
    assert(p.short_description == "Summary line.")
    assert(p.long_description == """Description longer than one line. Description after empty line.""")
    for param in p.meta:
        if type(param) is DocstringParam:
            assert(param.arg_name == "param1" or param.arg_name == "param2")
        if type(param) is DocstringReturns:
            assert(param.type_name == "bool")


# Generated at 2022-06-21 11:48:06.796317
# Unit test for constructor of class Section
def test_Section():
    s = Section('Returns', 'returns', SectionType.SINGULAR_OR_MULTIPLE)
    
    test = s.title == 'Returns' and s.key == 'returns' and s.type == SectionType.SINGULAR_OR_MULTIPLE
    if test:
        print("Successfully test constructor of class Section")
    else:
        print("Failed test constructor of class Section")


# Generated at 2022-06-21 11:48:29.806894
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Arguments", "param", SectionType.MULTIPLE)
    assert sec.title is "Arguments" and sec.key is "param" and sec.type is SectionType.MULTIPLE

    sec = Section("Args", "param", SectionType.MULTIPLE)
    assert sec.title is "Args" and sec.key is "param" and sec.type is SectionType.MULTIPLE

    sec = Section("Parameters", "param", SectionType.MULTIPLE)
    assert sec.title is "Parameters" and sec.key is "param" and sec.type is SectionType.MULTIPLE

    sec = Section("Params", "param", SectionType.MULTIPLE)
    assert sec.title is "Params" and sec.key is "param" and sec.type is SectionType.MULTIPLE

# Generated at 2022-06-21 11:48:33.593215
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """Append a new item with value x to the end of the array.
        Return None."""
    d = GoogleParser().parse(doc)
    assert d.short_description == 'Append a new item with value x to the end of the array.'
    assert d.long_description == 'Return None.'


# Generated at 2022-06-21 11:48:36.347662
# Unit test for constructor of class Section
def test_Section():
    section = Section("Title", "key", SectionType.MULTIPLE)
    assert section.title == "Title"
    assert section.key == "key"
    assert section.type == SectionType.MULTIPLE



# Generated at 2022-06-21 11:48:47.574229
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:48:58.466070
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    _docstring = """Single line docstring."""
    expected_result = Docstring(
        short_description="Single line docstring.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert parser.parse(_docstring) == expected_result

    _docstring = """
        Multiline docstring.

        And another sentence.
        """
    expected_result = Docstring(
        short_description="Multiline docstring.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="And another sentence.",
        meta=[],
    )
    assert parser.parse(_docstring) == expected_result

    _docstring

# Generated at 2022-06-21 11:48:58.847511
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    pass

# Generated at 2022-06-21 11:49:06.736080
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:49:18.753572
# Unit test for function parse
def test_parse():
    """Test function parse"""
    doc_string_1 = """
    This is the short summary of my function.

    Here is the long description of my function. It can go on
    for more than one paragraph.

    Parameters
    ----------
    a : int
        First parameter. Defaults to 1.
    b : int
        Second parameter.

    Returns
    -------
    None
        No return value.
    """
    doc_string_2 = """
    This is the short summary of my function.

    Here is the long description of my function. It can go on
    for more than one paragraph.

    Args
    ----
    a : int
        First parameter. Defaults to 1.
    b : int
        Second parameter.

    Returns
    -------
    None
        No return value.
    """
    doc_string_3

# Generated at 2022-06-21 11:49:29.697186
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test method add_section of class GoogleParser."""

    new_section = Section("Section", "section", SectionType.MULTIPLE)
    parser = GoogleParser()
    #
    # with title_colon = True
    #
    parser.title_colon = True
    # Add a new section
    parser.add_section(new_section)
    # Get titles_re
    titles_re = parser.titles_re
    # Check pattern
    pattern = titles_re.pattern
    # Check titles (or)
    title_or_sections = pattern[2:-17]
    title_sections = title_or_sections.split("|")
    # Check titles (and)
    titles = []
    expected_titles = []

# Generated at 2022-06-21 11:49:36.167594
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("New-section", "new", SectionType.SINGULAR)
    parser.sections["New-section"] = new_section
    assert parser.sections.get("New-section") == new_section
    assert not parser.sections.get("Not-existing-section")

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 11:49:52.463449
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert sec.title == "Returns"
    assert sec.key == "returns"
    assert sec.type == SectionType.SINGULAR_OR_MULTIPLE


# Generated at 2022-06-21 11:50:05.233473
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a google-style docstring.

    This is a long description
    which spans multiple lines
    and ends with a blank line.

    Args:
        a (str): The first parameter.
        b (int, optional): The second parameter. Defaults to 1.
        c (float): The third parameter.

    Returns:
        str: Return value of this function.

    Raises:
        RuntimeError: If something bad happens.
    """
    docstring_dict = parse(docstring)
    assert docstring_dict.short_description == "This is a google-style docstring."
    assert docstring_dict.long_description == "This is a long description\nwhich spans multiple lines\nand ends with a blank line."
    assert docstring_dict.blank_after_long_description == True

# Generated at 2022-06-21 11:50:14.071629
# Unit test for function parse
def test_parse():
    text = """
    This is a short description.
    
    
    
    This is a long description.
    It goes on for a while.
    Spanning multiple
    lines
    
    
    
    Args:
        arg1: This is arg1
        arg2: This is arg2
        
    Returns:
        This is a return value
    """
    # parse
    docstring = parse(text)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta)

    # parse another
    text = """
    This is a short description.

    Args:
        arg1: This is arg1
        arg2 (int): This is arg2 and it has a type
    """
    docstring = parse(text)

# Generated at 2022-06-21 11:50:21.170407
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE
    assert s == Section("Arguments", "param", SectionType.MULTIPLE)
    assert s != Section("Arguments", "param", SectionType.SINGULAR)
test_Section()


# Generated at 2022-06-21 11:50:23.009619
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert isinstance(GoogleParser(), GoogleParser)



# Generated at 2022-06-21 11:50:27.556658
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert(s.title == "Arguments")
    assert(s.key == "param")
    assert(s.type == SectionType.MULTIPLE)


# Generated at 2022-06-21 11:50:39.655589
# Unit test for function parse
def test_parse():
    def my_function(a, b, c="foo"):
        """Short description.

        Long description (with indentation).

        Args:
            a (int): The first parameter.
            b (str): The second parameter.
            
        Returns:
            int: The return value. Defaults to False.
            int, str: The return value.

        Raises:
            ValueError: If `a` is negative.

        """
        return a + b

    res = parse(my_function.__doc__)
    assert len(res.meta) == 4
    assert res.short_description == "Short description."
    assert res.long_description == "Long description (with indentation)."

    assert isinstance(res.meta[0], DocstringParam)

# Generated at 2022-06-21 11:50:52.350393
# Unit test for function parse
def test_parse():
    def _test_parse(text, expected):
        assert GoogleParser().parse(text) == expected

    _test_parse("", Docstring())

    # test docstring with only short description
    _test_parse(
        "Short Description",
        Docstring(
            short_description="Short Description",
            blank_after_short_description=False,
            blank_after_long_description=False,
            long_description=None,
            meta=[],
        ),
    )

    # test docstring with short description and long description

# Generated at 2022-06-21 11:50:56.043081
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Title", "Key", SectionType.SINGULAR)
    assert sec.title == "Title"
    assert sec.key == "Key"
    assert sec.type == SectionType.SINGULAR

# Testing the method GoogleParser.add_section

# Generated at 2022-06-21 11:51:00.080001
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test if parse raises ParseError on empty string and returns a Docstring
    with pytest.raises(ParseError) as exc_info:
        GoogleParser().parse("")
    assert isinstance(exc_info.value.args[0], Docstring)

    # Test if parse raises ParseError when missing element in Google-style docstring
    with pytest.raises(ParseError):
        GoogleParser().parse("""
    Test if parse raises ParseError when missing element in Google-style docstring
    """)

    # Test if parse raises ParseError when invalid element in Google-style docstring
    with pytest.raises(ParseError):
        parse("""
    Raises:
    Test if parse raises ParseError when invalid element in Google-style docstring
    """)


# Generated at 2022-06-21 11:51:12.548095
# Unit test for constructor of class Section
def test_Section():
    my_section = Section("Title", "key", SectionType.SINGULAR)
    assert(my_section.title == "Title")
    assert(my_section.key == "key")
    assert(my_section.type == SectionType.SINGULAR)


# Generated at 2022-06-21 11:51:21.266475
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    doc = '''
    This is the short description.

    This is the much longer description. So we can do all kinds of things.

    Args:
        arg1 (str): The first argument.
        arg2 (str, optional): The second argument, defaults to "default."
        arg3 (bool, optional): The third argument, defaults to False.
        arg4 (str): The fourth argument.

    Attributes:
        attr1 (str): The first attribute.
        attr2 (str, optional): The second attribute, defaults to "default."
        attr3 (bool, optional): The third argument, defaults to False.
        attr4 (str): The fourth attribute.

    Raises:
        ExceptionA: If something happens.
        ExceptionB: If something else happens.

    Returns:
        int: The return value.
        '''


# Generated at 2022-06-21 11:51:27.090145
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = '''
        Summarize the function here.

        Args:
          arg1: A type of arg1.
          arg2: A type of arg2.

        Raises:
          AError: An error occurred.''

    '''
    gp = GoogleParser()
    # Add a new section
    gp.add_section(Section("Test", "test", SectionType.MULTIPLE))
    # Test new section
    gp.parse(text)   


# Generated at 2022-06-21 11:51:28.522357
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    import pytest
    assert GoogleParser().title_colon == True



# Generated at 2022-06-21 11:51:34.750457
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("A single line summary")
    result_str = str(docstring)
    expected_str = "[DocstringMeta(args=['A', 'single', 'line', 'summary'], description=None, arg_name=None, type_name=None, is_optional=None, default=None)]"
    if result_str != expected_str:
        print("Error in GoogleParser.parse, expected:", expected_str)
        print("But it returned:", result_str)

# tests for class Docstring

# Generated at 2022-06-21 11:51:39.419164
# Unit test for constructor of class Section
def test_Section():
    section = Section("Args", "param", SectionType.MULTIPLE)

    assert section.title == "Args"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:51:50.571211
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    docstring = """
        Single.

        Multi
        line
        description.
        """
    expected = Docstring(
        short_description="Single.",
        blank_after_short_description=True,
        long_description="Multi\nline\ndescription.",
        blank_after_long_description=True,
    )
    assert parse(docstring) == expected

    docstring = """
        Single.

        Multi
        line
        description.

        Args:
            arg1: description.
            arg2: description. Defaults to something.
        """

# Generated at 2022-06-21 11:51:57.525168
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = ('This is a test. With a long line.\n\n'
           'A long description.\n\n'
           'Args: a: a string\n'
           '    with a long line.\n'
           '    And indented.\n'
           '    This should not be a new section.\n'
           'Returns:\n'
           '    A string.\n'
           'Raises:\n'
           '    TypeError: if passed a non-string.\n'
           '    ValueError: if passed a negative string.\n')
    docstring = parse(doc)
    assert docstring.short_description == 'This is a test. With a long line.'

# Generated at 2022-06-21 11:52:03.421663
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Param", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Functions", "function", SectionType.MULTIPLE))
    assert parser.sections["Param"].type == SectionType.MULTIPLE
    assert parser.sections["Functions"].type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:52:08.946822
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE
    s = Section("Args", "param", SectionType.MULTIPLE)
    assert s.title == "Args"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE
    s = Section("Parameters", "param", SectionType.MULTIPLE)
    assert s.title == "Parameters"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE
    s = Section("Params", "param", SectionType.MULTIPLE)
    assert s.title == "Params"

# Generated at 2022-06-21 11:52:26.882261
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`.
    arg2 : str
        Description of `arg2`.

    Returns
    -------
    int
        Description of return value.
    """

    google_parser = GoogleParser()

    parsed_docstring = google_parser.parse(docstring)

    assert parsed_docstring.short_description == "Summary line."
    assert parsed_docstring.long_description == "Extended description."
    assert parsed_docstring.blank_after_short_description
    assert parsed_docstring.blank_after_long_description
    assert parsed_docstring.meta[0].description == "Description of `arg1`."
    assert parsed_docstring.meta[0].arg_name == "arg1"
   

# Generated at 2022-06-21 11:52:39.547914
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:52:44.860152
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test of GoogleParser add_section method."""
    text = \
        """
    Test of method add_section of class GoogleParser.

    :param text: docstring element text
    :param title: title of section containing element
    :return:
    """

    # Create parser
    parser = GoogleParser()

    # Create custom section
    title = "Test"
    section = Section(title, "param", SectionType.SINGULAR)

    # Add custom section to parser
    parser.add_section(section)

    # Call parse method of parser
    result = parser.parse(text)

    # Check if new element was added
    assert any([i.args[0] == title for i in result.meta])

# Generated at 2022-06-21 11:52:53.687088
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # create GoogleParser and get its attributes
    g = GoogleParser()
    sections = g.sections

    # check length of sections
    assert len(sections) == 13

    # check section with title "Arguments"
    sec_args = sections['Arguments']
    assert sec_args.title == 'Arguments'
    assert sec_args.key == 'param'
    assert sec_args.type == 1

    # check section with title "Args"
    sec_args = sections['Args']
    assert sec_args.title == 'Args'
    assert sec_args.key == 'param'
    assert sec_args.type == 1

    # check section with title "Parameters"
    sec_args = sections['Parameters']
    assert sec_args.title == 'Parameters'
    assert sec_args.key == 'param'
    assert sec_

# Generated at 2022-06-21 11:52:56.945179
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    document = "This is the first line \n    This is the second line \n    This is the third line \n    This is the fourth line"
    result = "This is the first line\nThis is the second line\nThis is the third line\nThis is the fourth line"
    assert parse(document) == result


# Generated at 2022-06-21 11:52:58.218206
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
	# TODO
	assert True

# Generated at 2022-06-21 11:53:09.399375
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = Section("Arguments", "param", SectionType.MULTIPLE)

    # Set sections
    g = GoogleParser(sections)
    assert g.sections == {"Arguments": sections}

    # Don't set sections
    g = GoogleParser()

# Generated at 2022-06-21 11:53:14.691102
# Unit test for constructor of class Section
def test_Section():
    # First assert is for the constructor without arguments
    sectionA = Section(title = "title", key="key", type="type")
    assert sectionA.title == "title"
    assert sectionA.key == "key"
    assert sectionA.type == "type"
    # Second assert is for the constructor with arguments
    sectionB = Section(title = "title2", key="key2", type="type2")
    assert sectionB.title == "title2"
    assert sectionB.key == "key2"
    assert sectionB.type == "type2"


# Generated at 2022-06-21 11:53:26.742560
# Unit test for function parse
def test_parse():
    text = '''\
    Args:
        aaa (str) : aaa.
        bbb (List[str]): bbb.
        ccc (tuple[int]): ccc. Defaults to (1, 2, 3).
        ddd: ddd.
    Returns:
        tuple[int, str]: tuple of int and string.

    '''
    res = parse(text)
    assert len(res.meta) == 5
    assert text == str(res)
    assert res.meta[0].arg_name == 'aaa'
    assert res.meta[0].type_name == 'str'
    assert res.meta[0].description == 'aaa.'
    assert res.meta[1].arg_name == 'bbb'
    assert res.meta[1].type_name == 'List[str]'


# Generated at 2022-06-21 11:53:32.853539
# Unit test for constructor of class Section
def test_Section():
    section = Section(title="Method", key="method", type=SectionType.MULTIPLE)
    assert section == Section("Method", "method", SectionType.MULTIPLE)
    assert section != Section("Methods", "method", SectionType.MULTIPLE)
    assert section != Section("Method", "methods", SectionType.MULTIPLE)
    assert section != Section("Method", "method", SectionType.SINGULAR)

    # try to change the value of a component of section
    with pytest.raises(AttributeError):
        section.title = "Methods"


# Generated at 2022-06-21 11:54:14.111836
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-21 11:54:19.048190
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = list(DEFAULT_SECTIONS)
    sections.append(Section("Alias", "alias", SectionType.MULTIPLE))
    google = GoogleParser(sections=sections)
    assert google.sections["Alias"] == Section("Alias", "alias", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:54:30.401217
# Unit test for function parse
def test_parse():
    result = parse(
        """\
        A sample docstring.
        """
    )
    assert result.short_description == "A sample docstring."

    result = parse(
        """\
        A sample docstring.
        More here.
        """
    )
    assert result.long_description == "More here."

    result = parse(
        """\
        A sample docstring.

        More here.
        """
    )
    assert result.blank_after_short_description is True
    assert result.long_description == "More here."

    result = parse(
        """\
        A sample docstring.

        More here.
        And more.
        """
    )
    assert result.blank_after_long_description is False
    assert result.long_description == "More here.\nAnd more."



# Generated at 2022-06-21 11:54:41.279961
# Unit test for function parse
def test_parse():
    def f(x: int) -> int:
        """This is a function with parameters and return.

        :param x: a parameter with a type annotation
        :return: the value of x
        """
        return x
    assert parse(f.__doc__).short_description == "This is a function with parameters and return."
    assert parse(f.__doc__).long_description is None
    assert parse(f.__doc__).blank_after_short_description is False
    assert parse(f.__doc__).blank_after_long_description is False
    assert parse(f.__doc__).meta[0] == DocstringParam(args=["param", "x"], description="a parameter with a type annotation", arg_name="x", type_name="int", is_optional=None, default=None)