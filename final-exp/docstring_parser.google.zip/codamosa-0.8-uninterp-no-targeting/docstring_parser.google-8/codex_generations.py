

# Generated at 2022-06-21 11:45:06.274643
# Unit test for constructor of class Section
def test_Section():
    section = Section("Argument","param",SectionType.MULTIPLE)
    assert section.title == "Argument"
    assert section.key =="param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:45:11.209768
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert (
        GoogleParser().parse("This is a docstring.")
        == Docstring(
            short_description="This is a docstring.",
            long_description=None,
            meta=list(),
            blank_after_short_description=False,
            blank_after_long_description=False,
        )
    )


# Generated at 2022-06-21 11:45:21.299589
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print('Unit test for constructor of class GoogleParser')
    print('--------------------')
    print('Test 1:')
    print('Input: sections is None')
    print('Output: ', GoogleParser().sections == DEFAULT_SECTIONS)
    print('--------------------')
    print('Test 2:')
    print('Input: sections is DEFAULT_SECTIONS')
    print('Output: ', GoogleParser(DEFAULT_SECTIONS).sections == DEFAULT_SECTIONS)
    print('--------------------')
    print('Test 3:')
    print('Input: sections is DEFAULT_SECTIONS and title_colon is False')
    print('Output: ')
    print(GoogleParser(DEFAULT_SECTIONS, False).sections)
    print('--------------------')
    print('Test 4:')

# Generated at 2022-06-21 11:45:22.343408
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
	parser = GoogleParser(title_colon=True)


# Generated at 2022-06-21 11:45:32.061965
# Unit test for constructor of class Section
def test_Section():
    assert Section(title='Arguments', key='param', type=0) == DEFAULT_SECTIONS[0]
    assert Section(title='Args', key='param', type=0) == DEFAULT_SECTIONS[1]
    assert Section(title='Parameters', key='param', type=0) == DEFAULT_SECTIONS[2]
    assert Section(title='Params', key='param', type=0) == DEFAULT_SECTIONS[3]
    assert Section(title='Raises', key='raises', type=0) == DEFAULT_SECTIONS[4]
    assert Section(title='Exceptions', key='raises', type=0) == DEFAULT_SECTIONS[5]
    assert Section(title='Except', key='raises', type=0) == DEFAULT_SECTIONS[6]
    assert Section

# Generated at 2022-06-21 11:45:36.132538
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section(
            title = "Parameters",
            key = "param",
            type = SectionType.MULTIPLE
    )
    parser.add_section(new_section)
    assert(parser.sections["Parameters"] == new_section)


# Generated at 2022-06-21 11:45:43.324548
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test = GoogleParser()
    assert test.titles_re.pattern == "^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields):[ \t\r\f\v]*$"
    assert test.title_colon == True

# Generated at 2022-06-21 11:45:56.568426
# Unit test for function parse
def test_parse():
    text = """\
        Short Description

        Long Description

        Args:
            a: Aaa
            bbb (tuple of ints): Bbb
            c (Type): Ccc

        Raises:
            ValueError: On invalid input.

        Returns:
            int: The answer.
        """
    doc = parse(text)
    assert doc.short_description == "Short Description"
    assert doc.long_description == "Long Description"
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "a: Aaa"]
    assert doc.meta[1].args == ["param", "bbb (tuple of ints): Bbb"]
    assert doc.meta[2].args == ["raises", "ValueError: On invalid input."]
    assert doc.meta[3].args

# Generated at 2022-06-21 11:46:09.401629
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("test", "test", SectionType.SINGULAR))
    assert gp.sections["test"].title == "test"
    assert gp.sections["test"].key == "test"
    assert gp.sections["test"].type == SectionType.SINGULAR
    gp.add_section(Section("test", "test", SectionType.SINGULAR_OR_MULTIPLE))
    assert gp.sections["test"].title == "test"
    assert gp.sections["test"].key == "test"
    assert gp.sections["test"].type == SectionType.SINGULAR_OR_MULTIPLE
    gp.add_section(Section("test", "test", SectionType.MULTIPLE))
    assert gp.sections["test"].title == "test"


# Generated at 2022-06-21 11:46:11.037704
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert hasattr(gp, 'sections') == True
    assert hasattr(gp, 'title_colon') == True
    assert hasattr(gp, 'titles_re') == True


# Generated at 2022-06-21 11:46:20.558466
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    new_section = Section("Attribute", "attribute", SectionType.MULTIPLE)
    gp.add_section(new_section)
    assert gp.sections[new_section.title] == new_section

# Generated at 2022-06-21 11:46:23.076862
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    p.add_section(Section("Test", "test", SectionType.SINGULAR))
    assert p.sections["Test"] == Section("Test", "test", SectionType.SINGULAR)

# Generated at 2022-06-21 11:46:32.293549
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:46:35.233208
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    googleParser = GoogleParser()
    section = Section('Tests', 'test', SectionType.MULTIPLE)
    googleParser.add_section(section)
    assert section.title in googleParser.sections

# Generated at 2022-06-21 11:46:42.826640
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    obj = GoogleParser()
    
    new_section1 = Section("NewSection1", "new_section_1", SectionType.MULTIPLE)
    obj.add_section(new_section1)
    assert new_section1 in obj.sections.values()
    assert "NewSection1" in obj.sections.keys()

    new_section2 = Section("NewSection2", "new_section_2", SectionType.SINGULAR)
    obj.add_section(new_section2)
    assert new_section2 in obj.sections.values()
    assert "NewSection2" in obj.sections.keys()

# Generated at 2022-06-21 11:46:55.959472
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("FOO!").short_description == "FOO!"

    assert parser.parse("FOO!\n\nBAR!").long_description == "BAR!"
    assert parser.parse("FOO!\nBAR!").long_description == "BAR!"

    assert parser.parse("FOO!\n\nBAR!").blank_after_short_description
    assert not parser.parse("FOO!\nBAR!").blank_after_short_description
    assert parser.parse("FOO!\n\nBAR!").blank_after_long_description
    assert not parser.parse("FOO!\nBAR!").blank_after_long_description


# Generated at 2022-06-21 11:47:03.006220
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    desc = "this is a test"

# Generated at 2022-06-21 11:47:11.380046
# Unit test for function parse
def test_parse():
    assert parse("") == Docstring()
    assert parse("  ") == Docstring()
    assert parse("  \n") == Docstring()
    assert parse("  \n\n") == Docstring()
    assert parse("\n") == Docstring(
        short_description="",
        blank_after_short_description=None,
        blank_after_long_description=None,
        long_description="",
        meta=[],
    )
    assert parse("  \n\n  ") == Docstring(
        short_description="",
        blank_after_short_description=None,
        blank_after_long_description=None,
        long_description="",
        meta=[],
    )

# Generated at 2022-06-21 11:47:13.742384
# Unit test for constructor of class Section
def test_Section():
    s = Section("Example", "examples", SectionType.SINGULAR)
    assert(s.title == "Example")
    asse

# Generated at 2022-06-21 11:47:26.872070
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = parse(
        """
    My function.

    Short description.

    Long description.

    Args:
        x: first arg
        y: second arg
        z: third arg

    Example:
        >>> x = 1
        >>> y = 2
        >>> x + y
        3
    """
    )

    assert docstring.short_description == "My function."
    assert docstring.long_description == "Long description."
    assert docstring.meta[0].args == ["examples"]
    assert docstring.meta[0].description == ">>> x = 1\n>>> y = 2\n>>> x + y\n3"
    assert docstring.meta[1].args == ["param", "x"]
    assert docstring.meta[1].description == "first arg"


# Generated at 2022-06-21 11:47:34.344900
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) == Section("Arguments","param",SectionType.MULTIPLE)


# Generated at 2022-06-21 11:47:46.729677
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        Summary line.

        This is a longer description of the method.  It goes on for
        multiple lines.

        Args:
            arg1 (int): Description of arg1
            arg2 (str, optional): Description of arg2
            arg3: Description of arg3
        Returns:
           Some value.
           Another value.

        Examples:
           Examples should be written in doctest format, and should illustrate how
           to use the function.

           >>> a = [1, 2, 3]
           >>> print([x + 3 for x in a])
           [4, 5, 6]
           >>> print("a\nb")
           a
           b
        """
    d = GoogleParser().parse(text)
    print(d)

# Generated at 2022-06-21 11:47:58.450409
# Unit test for function parse
def test_parse():
    ds = """\
    Sum two numbers

    This is the long description. It may have multiple
    paragraphs in it.

    Args:
        a: first number
        b: second number

    Returns:
        sum of a and b
    """

    result = parse(ds)
    assert not result.blank_after_long_description
    assert not result.blank_after_short_description
    assert len(result.meta) == 2

    assert result.short_description == "Sum two numbers"
    assert result.long_description == (
        "This is the long description. It may have multiple\n"
        "paragraphs in it."
    )
    assert result.meta[0].description == ""
    assert result.meta[0].args == ("param", "a: first number")

# Generated at 2022-06-21 11:48:08.826294
# Unit test for constructor of class Section
def test_Section():
    Section_1 = Section("Arguments", "param", SectionType.MULTIPLE)
    Section_2 = Section("Raises", "raises", SectionType.MULTIPLE)
    assert Section_1.title=="Arguments"
    assert Section_1.key=="param"
    assert Section_1.type==SectionType.MULTIPLE
    assert Section_2.title=="Raises"
    assert Section_2.key=="raises"
    assert Section_2.type==SectionType.MULTIPLE
    assert Section_1!=Section_2


# Generated at 2022-06-21 11:48:12.161512
# Unit test for constructor of class Section
def test_Section():
    newSection = Section("title", "key", SectionType.MULTIPLE)
    assert newSection.title == "title"
    assert newSection.key == "key"
    assert newSection.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:48:22.413827
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test_sections = [Section("Args", "param", SectionType.MULTIPLE), 
                     Section("Attributes", "attribute", SectionType.MULTIPLE), 
                     Section("Example", "examples", SectionType.SINGULAR), 
                     Section("Examples", "examples", SectionType.SINGULAR), 
                     Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE), 
                     Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE)]
    assert GoogleParser(test_sections)
    assert GoogleParser(test_sections, title_colon=False)


# Generated at 2022-06-21 11:48:30.046963
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Examples", "examples", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    gp = GoogleParser(sections=sections)
    assert gp.sections == {'Arguments': Section(title='Arguments', key='param', type=2), 'Examples': Section(title='Examples', key='examples', type=2)}
    assert gp.title_colon == True
    gp = GoogleParser()

# Generated at 2022-06-21 11:48:30.597809
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()

# Generated at 2022-06-21 11:48:39.099621
# Unit test for function parse
def test_parse():
    def test_func_docstring():
        """
        This is the short description.

        This is the long description.

        Args:
            arg1: An argument.

        Returns:
            Something important.

        Yields:
            Something important.
        """
        pass

    docstring = parse(test_func_docstring.__doc__)


# Generated at 2022-06-21 11:48:50.189661
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    def fc(s: str) -> Section:
        return Section(s, "", 0)

# Generated at 2022-06-21 11:49:04.459422
# Unit test for function parse
def test_parse():
    """Test docstring parsing"""
    def f():
        """Short description.

        Long description.

        Args:
            arg1(str, optional): First arg.
            arg2(int): Second arg.

        Returns:
            int: The return value.

        Raises:
            ValueError: if something wrong.
        """

    ds = parse(f.__doc__)
    assert ds.short_description == "Short description."
    assert ds.long_description == "Long description."
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is True
    assert len(ds.meta) == 3
    assert ds.meta[0].title == "Args"

# Generated at 2022-06-21 11:49:10.594281
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    with_sections = GoogleParser(sections=[Section("Sections", "section", SectionType.SINGULAR)])
    with_sections.add_section(Section("Sections", "section", SectionType.SINGULAR))
    assert with_sections.sections["Sections"] == Section("Sections", "section", SectionType.SINGULAR)

# Generated at 2022-06-21 11:49:17.797666
# Unit test for constructor of class Section
def test_Section():
    """Unit test for constructor of class Section."""
    section1 = Section("Example", "Example", "Example")

    # Test type of variables in the tuple
    assert isinstance(section1.title, str)
    assert isinstance(section1.key, str)
    assert isinstance(section1.type, str)

    # Test value of the tuple
    assert section1.title == "Example"
    assert section1.key == "Example"
    assert section1.type == "Example"



# Generated at 2022-06-21 11:49:28.942312
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    p.add_section(Section("TEST", "test", SectionType.MULTIPLE))
    assert p.parse("TEST\nparam: test: test\n") == Docstring(
        meta=[
            DocstringMeta(args=["test", "param"], description="test"),
            DocstringParam(
                args=["test", "test: test"],
                description="",
                arg_name="test",
                type_name="test",
                is_optional=None,
                default=None,
            ),
        ]
    )

    p.add_section(Section("TEST", "test", SectionType.SINGULAR))

# Generated at 2022-06-21 11:49:40.949940
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
        Section("Params", "param", SectionType.MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    section = Section("Arg", "param", SectionType.MULTIPLE)
    gp = GoogleParser(sections)
    gp.add_section(section)
    assert gp.sections["Arg"] == section

# Generated at 2022-06-21 11:49:49.834567
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("BAR", "bar", SectionType.SINGULAR))
    docstr = parser.parse(
        "Foo.\n\n"
        "Bar:\n"
        "    Zaz.\n"
    )
    assert docstr.short_description == "Foo."
    meta = docstr.meta[0]
    assert meta.description == "Zaz."
    assert meta.args == ["bar"]


# Generated at 2022-06-21 11:49:57.726759
# Unit test for function parse
def test_parse():
    d_test = """
Args:
    p1 (str): first parameter
    p2 (int, optional): second parameter. Defaults to 5
    p3 (str [str]): third parameter
    p4 (str): last parameter

Returns:
    bool: success or failure
    """

    def f_test(p1, p2=5, p3=None, *args, **kwargs):
        """
        Function to test Google docstring parsing.

        :param p1: first parameter
        :type p1: str
        :param p2: second parameter
        :type p2: int
        :param p3: third parameter
        :type p3: list of str
        :param p4: last parameter
        :type p4: str
        :return: success or failure
        :rtype: bool
        """
       

# Generated at 2022-06-21 11:50:10.031027
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:50:13.037629
# Unit test for constructor of class Section
def test_Section():
    sections = [Section("Arguments", "param", SectionType.MULTIPLE),
                Section("Examples", "examples", SectionType.SINGULAR)]
    assert sections == DEFAULT_SECTIONS


# Generated at 2022-06-21 11:50:19.369792
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser(sections = [Section("Titre", "", SectionType.MULTIPLE)])
    gp.add_section(Section("Titre", "", SectionType.MULTIPLE))
    assert(len(gp.sections) == 1)
    gp.add_section(Section("Titre2", "", SectionType.SINGULAR))
    assert(len(gp.sections) == 2)

# Generated at 2022-06-21 11:50:42.972358
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().sections['Arguments'] == Section("Arguments", "param",
                                                             SectionType.MULTIPLE)
    assert GoogleParser().sections['Raises'] == Section("Raises", "raises",
                                                         SectionType.MULTIPLE)
    assert GoogleParser().sections['Returns'].title == "Returns"
    assert GoogleParser().sections['Returns'].key == "returns"
    assert GoogleParser().sections['Returns'].type == 2
    assert GoogleParser().sections['Example'] == Section("Example", "examples",
                                                          SectionType.SINGULAR)
    assert GoogleParser().sections['Examples'] == Section("Examples", "examples",
                                                           SectionType.SINGULAR)

# Generated at 2022-06-21 11:50:55.958712
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""
    parser = GoogleParser()

    # test doc string with short/long descriptions and sections (args, returns)
    text = """
    Args:
    """
    docstr = parser.parse(text)
    assert docstr.short_description is None
    assert docstr.long_description is None
    assert len(docstr.meta) == 0

    text = """
    Args:
    Returns:
    """
    docstr = parser.parse(text)
    assert docstr.short_description is None
    assert docstr.long_description is None
    assert len(docstr.meta) == 0

    text = """
    Args:
    Returns:
      normal_returns (list): List of normal returns.
    """
    docstr = parser.parse(text)

# Generated at 2022-06-21 11:51:05.399867
# Unit test for function parse
def test_parse():
    ds = """
    Short desc.

    Long desc.

    Args:
        arg (str):
            Argument.

    Params:
        param (str, optional):
            Parameter
            Defaults to "foo".

    Returns:
        int

    Raises:
        ValueError
    """
    parsed = parse(ds)
    assert parsed.short_description == "Short desc."
    assert parsed.blank_after_short_description
    assert parsed.long_description == "Long desc."
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 4
    assert parsed.meta[0].args == ("param", "arg (str)")
    assert parsed.meta[0].description == "Argument."

# Generated at 2022-06-21 11:51:17.952720
# Unit test for constructor of class Section
def test_Section():
   a = Section("Arguments", "param", SectionType.MULTIPLE)
   b = Section("Args", "param", SectionType.MULTIPLE)
   c = Section("Parameters", "param", SectionType.MULTIPLE)
   d = Section("Params", "param", SectionType.MULTIPLE)
   e = Section("Raises", "raises", SectionType.MULTIPLE)
   f = Section("Exceptions", "raises", SectionType.MULTIPLE)
   g = Section("Except", "raises", SectionType.MULTIPLE)
   h = Section("Attributes", "attribute", SectionType.MULTIPLE)
   i = Section("Example", "examples", SectionType.SINGULAR)
   j = Section("Examples", "examples", SectionType.SINGULAR)
   k

# Generated at 2022-06-21 11:51:27.845928
# Unit test for function parse
def test_parse():
    google_parser=GoogleParser()
    doc_string=""""\
    Args:
        string (str, optional): The string to split. Defaults to ''.
        num_or_size_splits (int, optional): Number of pieces to split the
            string into, or number of bytes between splits. Defaults to None.
        maxsplit (int, optional): The maximum number of splits. Defaults to -1.
    Returns:
        A list of splits.
        """
    # Expected output

# Generated at 2022-06-21 11:51:30.737717
# Unit test for constructor of class Section
def test_Section():
    my_section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert my_section.title == "Arguments"
    assert my_section.key == "param"
    assert my_section.type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:51:43.081563
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:51:53.516913
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

    section = Section("Arguments", "params", SectionType.MULTIPLE)
    parser.add_section(section)
    assert len(parser.sections) == 14
    assert parser.sections["Arguments"] == section
    assert parser.titles_re.match("Arguments:")

    section = Section("Implements", "implements", SectionType.SINGULAR)
    parser.add_section(section)
    assert len(parser.sections) == 15
    assert parser.sections["Implements"] == section
    assert parser.titles_re.match("Implements:")

    section = Section("Implements", "implements1", SectionType.SINGULAR)
    parser.add_section(section)
    assert len(parser.sections) == 15

# Generated at 2022-06-21 11:51:55.594339
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    print(google_parser)


# Generated at 2022-06-21 11:52:04.576553
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    parser.add_section(Section("Additional", "additional", SectionType.MULTIPLE))
    assert parser.sections["Arguments"] == Section("Arguments", "param", SectionType.MULTIPLE)
    assert parser.sections["Additional"] == Section("Additional", "additional", SectionType.MULTIPLE)
    assert parser.sections["Args"] == Section("Args", "param", SectionType.MULTIPLE)
    assert len(parser.sections) == 6

# Generated at 2022-06-21 11:52:12.564789
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser()


# Generated at 2022-06-21 11:52:25.297280
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()

    gp.add_section(Section('Arguments', 'param', SectionType.MULTIPLE))
    assert (gp.sections['Arguments'] == Section('Arguments', 'param', SectionType.MULTIPLE)), "Fail add new section"

    gp.add_section(Section('Args', 'param', SectionType.MULTIPLE))
    assert (gp.sections['Args'] == Section('Args', 'param', SectionType.MULTIPLE)), "Fail add new section"

    gp.add_section(Section('Parameters', 'param', SectionType.MULTIPLE))
    assert (gp.sections['Parameters'] == Section('Parameters', 'param', SectionType.MULTIPLE)), "Fail add new section"

    gp.add_section(Section('Params', 'param', SectionType.MULTIPLE))


# Generated at 2022-06-21 11:52:38.017265
# Unit test for constructor of class Section
def test_Section():
    extractor = GoogleParser()

# Generated at 2022-06-21 11:52:48.038717
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    print("Testing GoogleParser_add_section...", end="", flush=True)
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
        Section("Params", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Example", "Example", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]


# Generated at 2022-06-21 11:52:56.435817
# Unit test for function parse
def test_parse():
    parser = GoogleParser()
    test_docstring1 = """
    Testing function.

    This is a test function.

    Args:
        x (int): the variable.
        y (int): the variable.

    Raises:
        ValueError: If any parameter is negative.
        TypeError: If any parameter is not integer.

    Returns:
        The sum of x and y.

    """
    docstring = parser.parse(test_docstring1)
    assert type(docstring.short_description) is str
    assert type(docstring.long_description) is str
    # assume that the metadata will have 2 params here and 2 raises
    assert len(docstring.meta) == 4

    for index, element in enumerate(docstring.meta):
        index_set = set([0,1])

# Generated at 2022-06-21 11:53:07.807510
# Unit test for constructor of class Section
def test_Section():
    s = Section("title", "key", SectionType.SINGULAR)
    assert s.title == 'title'
    assert s.key == 'key'
    assert s.type == SectionType.SINGULAR
    print(s)


if __name__ == "__main__":
    test_Section()
    print("*" * 40)
    print("Testing GoogleParser...")
    parser = GoogleParser()
    text = """Summary line.

    Extended description of function.

    Args:
        param1: Description of param1
        param2: Description of param2

    Returns:
        Description of return value
    """
    doc = parser.parse(text)
    assert doc.short_description == "Summary line."
    assert doc.long_description == "Extended description of function."
    assert doc.blank_after_short

# Generated at 2022-06-21 11:53:18.668216
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    x = GoogleParser().parse('''
    Short description

    Long description (optional)

    Returns:
        Returns something
    ''')
    assert x.short_description == 'Short description'
    assert x.long_description == 'Long description (optional)'
    assert x.blank_after_short_description
    assert x.blank_after_long_description
    assert len(x.meta) == 1
    assert isinstance(x.meta[0], DocstringReturns)
    assert x.meta[0].arg_name == 'returns'
    assert x.meta[0].type_name == 'Returns something'

    x = GoogleParser().parse('''Short description''')
    assert x.short_description == 'Short description'
    assert x.long_description is None
    assert not x.blank_after_short_description


# Generated at 2022-06-21 11:53:28.780440
# Unit test for function parse
def test_parse():
    google_docstring = """\
    Parameters
    ----------
    arg1 : int
        Description of arg1
    arg2 : str
        Description of arg2
    arg3 : None, optional
        Description of arg3
    arg4 : int, optional
        Description of arg4. Defaults to 42.
    arg5 : List[int], optional
        Description of arg5
    arg6 : dict, keyword only, optional
        Description of arg6

    Returns
    -------
    None
        Description of return value

    Raises
    ------
    ValueError
        If something is wrong

    Yields
    ------
    : int
        Description of yielded value
    """
    docstring = parse(google_docstring)
    assert docstring.short_description is None
    assert docstring.long_description is None

# Generated at 2022-06-21 11:53:37.631808
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test case for function parse in class GoogleParser."""
    print('Test case for function parse in class GoogleParser.')
    docstring = """
        Args:
            arg1: a string
            arg2: a string

        Returns:
            a string
    """
    _docstring = parse(docstring)
    assert _docstring.short_description == None
    assert _docstring.blank_after_short_description == False
    assert _docstring.blank_after_long_description == False
    assert _docstring.long_description == None
    assert len(_docstring.meta) == 2
    assert _docstring.meta[0].args == ['param', 'arg1: a string']
    assert _docstring.meta[0].description == 'a string'

# Generated at 2022-06-21 11:53:50.011858
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # initial from GoogleParser
    google_parser = GoogleParser()

    #check methods and attributes of class Docstring
    assert hasattr(Docstring, '__init__')
    assert hasattr(Docstring, '__str__')
    assert hasattr(Docstring, '__repr__')
    assert hasattr(Docstring, 'short_description')
    assert hasattr(Docstring, 'long_description')
    assert hasattr(Docstring, 'blank_after_short_description')
    assert hasattr(Docstring, 'blank_after_long_description')
    assert hasattr(Docstring, 'meta')
    assert hasattr(Docstring, 'returns')
    #check methods and attributes of class GoogleParser
    assert hasattr(GoogleParser, '__init__')
    assert hasattr(GoogleParser, '__eq__')
   

# Generated at 2022-06-21 11:53:58.421221
# Unit test for constructor of class Section
def test_Section():
    s = Section("foo", "bar", "baz")
    assert s.title == "foo"
    assert s.key == "bar"
    assert s.type == "baz"


# Generated at 2022-06-21 11:54:10.577257
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    pattern_list_before = list(GoogleParser().sections)
    count_before = len(GoogleParser().sections)
    assert not count_before == 0, "The default pattern list is empty"
    test_section = Section("Test","test",SectionType.SINGULAR)
    with GoogleParser() as test_parser:
        test_parser.add_section(test_section)
    pattern_list_after = list(GoogleParser().sections)
    count_after = len(GoogleParser().sections)
    assert not count_after == count_before,"The default pattern list is not changed"
    assert "Test" in pattern_list_before, "The default pattern list does not contain 'Test'"
    assert "Test" in pattern_list_after, "The default pattern list does not contain 'Test'"

# Generated at 2022-06-21 11:54:13.230438
# Unit test for constructor of class Section
def test_Section():
    fields = ['title', 'key', 'type']
    test_section = Section(title='Yields', key='yields', type=2,
                           verbose=True, rename=False)
    assert test_section.title == 'Yields', 'Failed to create a section'

# Generated at 2022-06-21 11:54:25.866650
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Create a new section
    section_1 = Section("Test", "test", SectionType.SINGULAR)

    # Add this section to the parser
    parser = GoogleParser()
    parser.add_section(section_1)

    # Parse a new docstring using the added section
    doc = parser.parse("Test: This is a test docstring")
    meta = doc.meta[0]
    assert meta.args == ["test"]
    assert meta.description == "This is a test docstring"

    # Create a new section
    section_2 = Section("Test", "test", SectionType.MULTIPLE)

    # Add this section to the parser
    parser = GoogleParser()
    parser.add_section(section_2)

    # Parse a new docstring using the added section

# Generated at 2022-06-21 11:54:29.492752
# Unit test for constructor of class Section
def test_Section():
    sec = Section("Arguments", "param", SectionType.MULTIPLE)
    assert sec.title == 'Arguments'
    assert sec.key == 'param'
    assert sec.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:54:35.861743
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''One line summary.
    
    Long multi-line summary.
    
    Some more text.
    
    Args:
      arg1: The first argument.
      arg2 (str): The second argument.
    
    Keyword Arguments:
      keyword1: Keyword argument 1.
      keyword2 (bool): Keyword argument 2.
    
    Returns:
      Some return value.
    
    Raises:
      KeyError: Raises an exception.
    '''
    result = parse(text)
    assert result.short_description == 'One line summary.'
    assert result.long_description == 'Long multi-line summary.\n\nSome more text.'
    assert result.blank_after_short_description is True
    assert result.blank_after_long_description is True