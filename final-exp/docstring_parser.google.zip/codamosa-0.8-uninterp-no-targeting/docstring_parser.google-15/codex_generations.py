

# Generated at 2022-06-21 11:45:21.193604
# Unit test for function parse
def test_parse(): # pragma: no cover
    from .markdown import MarkdownParser
    docs = """
    One line summary.

    Longer description.

    Args:
        arg1: First argument.
        arg2: Second argument.

    Returns:
        A string.
    """
    parsed = parse(docs)
    assert parsed.short_description == 'One line summary.'
    assert parsed.long_description == 'Longer description.'
    assert parsed.meta[0].args == ['param', 'arg1']
    assert parsed.meta[1].args == ['param', 'arg2']
    assert parsed.meta[2].args == ['returns']
    assert parsed.meta[2].description == 'A string.'
    assert not parsed.blank_after_long_description
    assert not parsed.blank_after_short_description


# Generated at 2022-06-21 11:45:27.366204
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test1 = GoogleParser()
    test2 = GoogleParser([
        Section("Example", "examples", SectionType.SINGULAR),
        Section("Examples", "examples", SectionType.SINGULAR),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ])


# Generated at 2022-06-21 11:45:36.464962
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = 'This is short description.\n'
    docstring += 'Example: This is code example.\n'
    docstring += 'Attributes:\n'
    docstring += '  x:This is an attribute.\n'
    docstring += '  y:This is an attribute.\n'
    docstring += 'Return: This is return value.\n\n'
    docstring += 'This is long deccription.\n'

    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert doc.short_description == 'This is short description.'
    assert doc.long_description == 'This is long deccription.'
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3

# Generated at 2022-06-21 11:45:42.572776
# Unit test for function parse
def test_parse():
    docstring = """A short description.

A longer description.

Args:
    arg1: A description.
    arg2: Another description.

Returns:
    A description.

Raises:
    ExceptionName: Description.
    ExceptionName: Description.
"""
    parsed_docstring = parse(docstring)
    assert parsed_docstring.short_description == "A short description."
    assert parsed_docstring.long_description == "A longer description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False
    assert len(parsed_docstring.meta) == 4
    assert parsed_docstring.meta[0].meta_name == "param"

# Generated at 2022-06-21 11:45:53.366519
# Unit test for function parse
def test_parse():
    def f(x):
        """
        A sample docstring.

        Args:
            x: an int.

        Returns:
            None.
        """
        pass


# Generated at 2022-06-21 11:45:59.307343
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test adding a new section
    parser = GoogleParser()
    new_section = Section("Foo", "foo", SectionType.SINGULAR)
    parser.add_section(new_section)
    assert(parser.sections["Foo"] == new_section)

    # Test adding a new section with the same name as one that already exists
    new_section_2 = Section("Foo", "foo_2", SectionType.SINGULAR)
    parser.add_section(new_section_2)
    assert(parser.sections["Foo"] == new_section_2)

# Generated at 2022-06-21 11:46:03.675048
# Unit test for constructor of class Section
def test_Section():
    # Test __init__ works correctly
    s = Section('title', 'key', 'type')
    assert s.title == 'title'
    assert s.key == 'key'
    assert s.type == 'type'



# Generated at 2022-06-21 11:46:14.786531
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Add normal section
    section = Section("Sections", "sections", SectionType.SINGULAR_OR_MULTIPLE)
    parser = GoogleParser(title_colon=True)
    assert parser.sections.get("Sections") == None
    parser.add_section(section)
    assert parser.sections.get("Sections") == section

    # Add section which title is also in default sections
    section = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert parser.sections.get("Returns") != None
    parser.add_section(section)
    assert parser.sections.get("Returns") == section

# Generated at 2022-06-21 11:46:24.241445
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('') == Docstring()
    assert parse(
        'Class for parsing Google-style docstrings.\n\nArgs:\n    text: docstring to parse'
    ) == Docstring(
        short_description='Class for parsing Google-style docstrings.',
        meta=[
            DocstringMeta(
                description='docstring to parse',
                args=['param', 'text'],
            )
        ],
    )

# Generated at 2022-06-21 11:46:32.934336
# Unit test for constructor of class Section
def test_Section():
    sec1 = Section("Arguments", "param", SectionType.MULTIPLE)
    sec2 = Section("Args", "param", SectionType.MULTIPLE)
    sec3 = Section("Parameters", "param", SectionType.MULTIPLE)
    assert(sec1.title == "Arguments")
    assert(sec1.key == "param")
    assert(sec1.type == SectionType.MULTIPLE)
    assert(sec2.title == "Args")
    assert(sec2.key == "param")
    assert(sec2.type == SectionType.MULTIPLE)
    assert(sec3.title == "Parameters")
    assert(sec3.key == "param")
    assert(sec3.type == SectionType.MULTIPLE)


# Generated at 2022-06-21 11:46:55.960039
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    new_section = [Section("New", "section", SectionType.SINGULAR)]
    test = GoogleParser(new_section)

    sections = test.sections
    assert sections == {'New': Section(title='New', key='section', type=0)}

    test.add_section(Section("New 2", "section", SectionType.MULTIPLE))
    assert sections == {'New': Section(title='New', key='section', type=0), 'New 2': Section(title='New 2', key='section', type=1)}



# Generated at 2022-06-21 11:47:05.836512
# Unit test for function parse
def test_parse():
    doc = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """
    gs = parse(doc)

    assert gs.short_description == "Parse the Google-style docstring into its components."
    assert gs.blank_after_short_description == True
    assert gs.blank_after_long_description == True
    assert gs.long_description == ":returns: parsed docstring"
    assert gs.meta[0].args == ["returns"]
    assert gs.meta[0].description == "parsed docstring"


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:47:15.482107
# Unit test for function parse
def test_parse():
    parser = GoogleParser()
    assert parser.parse(None) == Docstring()

    assert parser.parse("Single line") == Docstring(
        short_description="Single line",
    )

    assert parser.parse("Single line\n") == Docstring(
        short_description="Single line",
        blank_after_short_description=True,
    )

    assert parser.parse("Single line\n\nLong description") == Docstring(
        short_description="Single line",
        long_description="Long description",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )


# Generated at 2022-06-21 11:47:21.074698
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    with open("../../docstring_test_files/docstring_google.py") as f:
        doc = f.read()
        result = GoogleParser().parse(doc)
        assert result
        assert result.short_description == 'docstring_google module.'
        print(f"Done docstring_google module test.")

# Generated at 2022-06-21 11:47:21.867367
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()

# Generated at 2022-06-21 11:47:25.665415
# Unit test for constructor of class Section
def test_Section():
    section = Section("Example", "examples", 0)
    assert section.title == "Example"
    assert section.key == "examples"
    assert section.type == 0


# Generated at 2022-06-21 11:47:29.568488
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.sections == DEFAULT_SECTIONS
    assert parser.title_colon is True

    parser = GoogleParser(title_colon=False)
    assert parser.title_colon is False


# Generated at 2022-06-21 11:47:39.194348
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Attributes", "attribute", SectionType.MULTIPLE),
    ]
    parser = GoogleParser(sections)
    assert parser.sections == {
        "Arguments": Section("Arguments", "param", SectionType.MULTIPLE),
        "Args": Section("Args", "param", SectionType.MULTIPLE),
        "Attributes": Section("Attributes", "attribute", SectionType.MULTIPLE),
    }
    assert parser.title_colon == True

# Generated at 2022-06-21 11:47:50.157621
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    
    #define a new section
    newSection = Section("New", "new", 1)
    
    #create the instance of GoogleParser class
    parser = GoogleParser(None, True)
    #definition of the default sections

# Generated at 2022-06-21 11:47:51.398810
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    pass

# Generated at 2022-06-21 11:48:00.854995
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
        Parse the Google-style docstring into its components.

        :returns: parsed docstring
        """
    print(GoogleParser().parse(doc))


# Generated at 2022-06-21 11:48:02.795031
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # if 4 test cases failed, then the class is not created successfully
    assert GoogleParser() is not None


# Generated at 2022-06-21 11:48:14.469343
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser.title_colon == True

# Generated at 2022-06-21 11:48:18.690388
# Unit test for constructor of class Section
def test_Section():
    title = "TEST"
    key = "TEST"
    type = "TEST"
    test = Section(title, key, type)
    assert (test.title == title, test.key == key, test.type == type)


# Generated at 2022-06-21 11:48:24.243632
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    new_section = Section("Test", "test", SectionType.MULTIPLE)
    parser.add_section(Section("Test", "test", SectionType.MULTIPLE))
    parser.titles_re = re.compile("^(Test):[ \t\r\f\v]*$", flags=re.M)
    assert parser.parse("Test:")
    assert parser.sections['Test'] == new_section

# Generated at 2022-06-21 11:48:25.038701
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().sections == DEFAULT_SECTIONS



# Generated at 2022-06-21 11:48:31.992604
# Unit test for constructor of class Section
def test_Section():
    # Initialization
    test_section = Section("test_title", "test_key", "test_type")
    # test attribute title
    assert test_section.title == "test_title", "test_section.title is wrong!"
    # test attribute key
    assert test_section.key == "test_key", "test_section.key is wrong!"
    # test attribute type
    assert test_section.type == "test_type", "test_section.type is wrong!"
    # test_section.title = random_title
    # test_section.key = random_key
    # test_section.type = random_type


# Generated at 2022-06-21 11:48:39.915273
# Unit test for function parse
def test_parse():
    p = GoogleParser()

# Generated at 2022-06-21 11:48:48.449667
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().sections == DEFAULT_SECTIONS
    assert (
        GoogleParser(title_colon=False).sections[
            "Arguments"
        ].title
        == "Arguments"
    )
    assert GoogleParser().sections == DEFAULT_SECTIONS
    assert (
        GoogleParser(title_colon=False).sections[
            "Arguments"
        ].title
        == "Arguments"
    )
    assert (
        GoogleParser().sections[
            "Arguments"
        ].title
        == "Arguments"
    )



# Generated at 2022-06-21 11:48:59.284162
# Unit test for function parse
def test_parse():
    """Unit test for function parse

    This function is used to test whether the function parse works correctly.
    """
    test_docstring_before = '''
    Parse the Google-style docstring into its components.

    :param text: docstring
    :returns: parsed docstring

    :Example:
        >>> test_parse()
        Parse the Google-style docstring into its components.

        :param text: docstring
        :returns: parsed docstring
    '''

# Generated at 2022-06-21 11:49:22.847987
# Unit test for function parse
def test_parse():
    text_1 = """
    example(a, b)
    This is an example function.

    Args:
        a (int)
        b (str): test

    Raises:
        TypeError
        ValueError

    Returns:
        None: If successful, returns None.

    Examples:
        >>> example(2, "testing")
        >>> example("danger", 1)
        """

    text_2 = """
    example_2(a, b)
    This is an example function.

    Args:
        a (int)
        b (str): test

    Parameters:
        c (float)


    Returns:
        None: If successful, returns None.

    Examples:
        >>> example(2, "testing")
        >>> example("danger", 1)
        """
    

# Generated at 2022-06-21 11:49:26.816991
# Unit test for function parse
def test_parse():
    from .reST import ReSTParser

    # Test description
    text = inspect.cleandoc("""
    Simple description.

    Long description.

    Args:
        a: parameter a
    """)
    expected = ReSTParser(title_colon=False).parse(text)
    assert parse(text) == expected

    # Test param
    text = inspect.cleandoc("""
    Simple description.

    Args:
        a: parameter a
    """)
    expected = ReSTParser(title_colon=False).parse(text)
    assert parse(text) == expected

    # Test returns
    text = inspect.cleandoc("""
    Simple description.

    Returns:
        returns
    """)
    expected = ReSTParser(title_colon=False).parse(text)

# Generated at 2022-06-21 11:49:38.628819
# Unit test for function parse
def test_parse():

    def test(text, expected):
        doc = parse(text)
        assert str(doc) == expected

    # TODO: test this
    # test(
    #     '''one line section:
    #     test('''


# Generated at 2022-06-21 11:49:43.280797
# Unit test for constructor of class Section
def test_Section():
    title = "title"
    key = "key"
    type = 1
    section = Section(title, key, type)
    assert(section.title == title)
    assert(section.key == key)
    assert(section.type == type)


# Generated at 2022-06-21 11:49:54.964825
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()

    p.add_section(Section("Asdf:", "keyword", SectionType.SINGULAR))
    test_text = "Asdf: test"
    parse_result = p.parse(test_text)
    assert(parse_result.meta[0].keyword == "keyword")
    assert(parse_result.meta[0].description == "test")

    p.add_section(Section("Asdf:", "keyword2", SectionType.SINGULAR))
    parse_result = p.parse(test_text)
    assert(parse_result.meta[0].keyword == "keyword2")
    assert(parse_result.meta[0].description == "test")

    # test default sections
    assert(parse(test_text).meta[0].keyword == "examples")
   

# Generated at 2022-06-21 11:50:07.449372
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text = "Arguments: bla"
    sections = [Section("Arguments", "param", SectionType.MULTIPLE)]
    google_parser = GoogleParser(sections)
    assert (google_parser.title_colon) == True
    assert (google_parser.sections) == {'Arguments':Section(title='Arguments',key='param',type=SectionType.MULTIPLE)}
    assert (google_parser.titles_re.search(text).group(1)) == "Arguments"
    assert (google_parser.titles_re.search(text).group()) == "Arguments:"
    assert (google_parser.sections[google_parser.titles_re.search(text).group(1)]) == Section(title='Arguments',key='param',type=SectionType.MULTIPLE)

# Generated at 2022-06-21 11:50:10.763069
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser != None
    assert parser.sections != None
    assert parser.title_colon == True
    assert parser._setup() != {}
    print("test_GoogleParser passed successfully.")    
    

# Generated at 2022-06-21 11:50:20.910137
# Unit test for constructor of class Section
def test_Section():
    # Test the constructor of class Section
    # Test 1
    try:
        Section(None, "returns", SectionType.SINGULAR)
    except Exception:
        print("Test 1 failed")
    else:
        print("Test 1 passed")

    # Test 2
    try:
        Section("Args", None, SectionType.SINGULAR)
    except Exception:
        print("Test 2 failed")
    else:
        print("Test 2 passed")

    # Test 3
    try:
        Section("Args", "returns", None)
    except Exception:
        print("Test 3 failed")
    else:
        print("Test 3 passed")


# Generated at 2022-06-21 11:50:23.711929
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse.__doc__ == """Parse the Google-style docstring into its components.

:returns: parsed docstring
"""

# Generated at 2022-06-21 11:50:27.833444
# Unit test for constructor of class Section
def test_Section():
    s = Section(title="title", key="key", type=SectionType.MULTIPLE)
    assert s.title == "title"
    assert s.key == "key"
    assert s.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:50:58.081107
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser = GoogleParser()
    section = Section("Foo", "foo", SectionType.MULTIPLE)
    google_parser.add_section(section)
    assert google_parser._build_meta("a b c", "Foo") == DocstringMeta(args=['foo', 'a b c'], description='a b c')

# Generated at 2022-06-21 11:51:00.506692
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().sections is not None
    assert len(GoogleParser().sections) == len(DEFAULT_SECTIONS)


# Generated at 2022-06-21 11:51:02.548778
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().title_colon
    assert not GoogleParser(title_colon=False).title_colon


# Generated at 2022-06-21 11:51:12.144400
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sec = Section("Test", "test", SectionType.SINGULAR)
    gp = GoogleParser()
    gp.add_section(sec)

    assert "Test" in gp.sections
    assert "test" in gp.sections
    assert SectionType.SINGULAR in gp.sections

    sec = Section("Test", "test", SectionType.MULTIPLE)
    gp.add_section(sec)

    assert "Test" in gp.sections
    assert "test" in gp.sections
    assert SectionType.MULTIPLE in gp.sections


# Generated at 2022-06-21 11:51:21.093659
# Unit test for method add_section of class GoogleParser

# Generated at 2022-06-21 11:51:29.905750
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    text = inspect.cleandoc("""Greets the user.

Example::

    hello("Bob")
    'Hello, Bob!'

:param name: The person to greet.
:type name: str.

:returns: Greeting as str.
:raises ValueError: If name is not a str.

""")

# Generated at 2022-06-21 11:51:32.927048
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert DEFAULT_SECTIONS == GoogleParser().sections
    sections = [Section("Arguments", "param", SectionType.MULTIPLE),]
    assert sections == GoogleParser(sections).sections



# Generated at 2022-06-21 11:51:40.081866
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # GIVEN
    idocstring = """
    Args:
    title: section title
    text: section text
    """
    # WHEN
    docstring = GoogleParser().parse(idocstring)
    # THEN
    assert docstring.meta[0].description == 'section text'
    assert docstring.meta[0].args[0] == 'param'
    assert docstring.meta[0].args[1] == 'title'

# Generated at 2022-06-21 11:51:51.137235
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Unit test for method add_section of class GoogleParser."""
    sections = [
        Section("Arg", "param", SectionType.MULTIPLE),
        Section("Examples", "examples", SectionType.SINGULAR),
    ]
    parser = GoogleParser(sections)
    assert parser.sections["Arg"].title == "Arg"
    assert parser.sections["Arg"].key == "param"
    assert parser.sections["Arg"].type == SectionType.MULTIPLE
    assert parser.sections["Examples"].title == "Examples"
    assert parser.sections["Examples"].key == "examples"
    assert parser.sections["Examples"].type == SectionType.SINGULAR
    assert parser.sections["Arguments"] is None
    assert parser.sections["Args"] is None
    assert parser.sections["Parameters"] is None


# Generated at 2022-06-21 11:51:57.773519
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('Test docstring.') == Docstring(short_description='Test docstring.',
                                                                 blank_after_short_description=False,
                                                                 long_description='',
                                                                 blank_after_long_description=False)
    assert GoogleParser().parse('Test docstring.\n') == Docstring(short_description='Test docstring.',
                                                                   blank_after_short_description=True,
                                                                   long_description='',
                                                                   blank_after_long_description=False)

# Generated at 2022-06-21 11:52:54.058687
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Attributes:
        bar:
            doc. This is bar
    """
    parser = GoogleParser()
    expected = Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(args=['attribute', 'bar'], description='This is bar'),
        ],
    )
    assert expected == parser.parse(docstring)

# Generated at 2022-06-21 11:52:55.554070
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert(type(gp) == GoogleParser)



# Generated at 2022-06-21 11:52:59.260677
# Unit test for constructor of class Section
def test_Section():
    title = 'Parameters'
    key = 'param'
    type = SectionType.SINGULAR_OR_MULTIPLE
    section = Section(title, key, type)
    assert (section.title == title and section.key == key and section.type == type)


# Generated at 2022-06-21 11:53:01.677381
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert len(GoogleParser().sections) == len(DEFAULT_SECTIONS)


# Generated at 2022-06-21 11:53:11.941709
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Parse docstring according to Google style guide
    parser = GoogleParser()
    parser.add_section(Section("Added", "added", SectionType.MULTIPLE))
    parser.add_section(Section("Deleted", "deleted", SectionType.MULTIPLE))
    docstring = parser.parse("""One line summary.

    Detailed description.

    Added:
        bob: bob bob bob.
        alice: alice alice alice.
    Deleted:
        bob: bob bob bob.
        alice: alice alice alice.
    """)

    # Check results
    assert len(docstring.meta) == 4
    assert docstring.meta[0] == DocstringMeta(args=["added", "bob"], description="bob bob bob.")
    assert docstring.meta[1] == Doc

# Generated at 2022-06-21 11:53:15.248861
# Unit test for constructor of class Section
def test_Section():
    section=Section("title", "key", SectionType.MULTIPLE)
    assert section.title=="title"
    assert section.key=="key"
    assert section.type==SectionType.MULTIPLE

# Generated at 2022-06-21 11:53:27.118735
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    sample_docstring = 'This is the very simple sample docstring for sample.py which demonstrates the usage of GoogleParser.\n\nArgs:\n    a (int): this is the first argument.\n        It has a long description. And this is the second line.\n        And third line of the desc?!\n        Defaults to 100.\n    b (str): this is the second argument.\n    c (str): this is the third argument.\n\nReturns:\n    int: the result of the multiplication.\n\nRaises:\n    ValueError: if the arguments are invalid,\n    TypeError: if the arguments are of wrong type.\n\nExample:\n    >>> print(sample(a=1, b=2, c=3))\n    6\n'

# Generated at 2022-06-21 11:53:29.487292
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert not GoogleParser().title_colon
    assert GoogleParser().title_colon == True
    assert len(GoogleParser().sections) == len(DEFAULT_SECTIONS)


# Generated at 2022-06-21 11:53:34.193721
# Unit test for constructor of class Section
def test_Section():
    s_repr = 'Section(title="Args", key="param", type=1)'
    s = Section("Args", "param", SectionType.MULTIPLE)
    assert((s_repr == repr(s)) and (s.title == "Args") and (s.key == "param") and (s.type == 1))
    assert(s.title == "Args")
    assert(s.key == "param")
    assert(s.type == 1)

# Generated at 2022-06-21 11:53:38.515164
# Unit test for constructor of class Section
def test_Section():
    # A default instance of Section should be created when the following
    # attributes are given
    title = "Arguments"
    key = "param"
    type = SectionType.MULTIPLE
    section = Section(title, key, type)
    assert section.title == title
    assert section.key == key
    assert section.type == type
