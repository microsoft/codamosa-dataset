

# Generated at 2022-06-21 11:45:22.375327
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Initialize the GoogleParser object
    p = GoogleParser()
    # Create a sample Section
    s = Section("Sample", "sample", SectionType.MULTIPLE)
    # Add the section
    p.add_section(s)
    # Make sure the added section is correct
    assert p.sections["Sample"] == s
    t = p.parse("Sample:\n    - one: two\n    - three: four\n")
    assert (
        t.meta[0].args
        == ["sample", "- one: two\n    - three: four"]
    )
    # Add a new section
    p.add_section(s)
    # Overwrite, add a new section
    assert p.sections["Sample"] == s
    # Make sure the added section is correct

# Generated at 2022-06-21 11:45:30.593321
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse(
        """test_GoogleParser_parse(self):
        Unit test for method parse of class GoogleParser
"""
    ) == Docstring()

    assert GoogleParser().parse(
        """test_GoogleParser_parse(self):

        Unit test for method parse of class GoogleParser
"""
    ) == Docstring(
        short_description="test_GoogleParser_parse(self):",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Unit test for method parse of class GoogleParser",
        meta=[],
    )


# Generated at 2022-06-21 11:45:39.515850
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()

# Generated at 2022-06-21 11:45:45.417112
# Unit test for constructor of class Section
def test_Section():
    from unittest import TestCase, mock
    from enum import IntEnum
    from enum import Enum
    from typing import List
    from typing import Optional
    from typing import Tuple
    from typing import Union


    class SectionType(IntEnum):
        """Types of sections."""

        SINGULAR = 0
        """For sections like examples."""

        MULTIPLE = 1
        """For sections like params."""

        SINGULAR_OR_MULTIPLE = 2
        """For sections like returns or yields."""

    class Section(namedtuple("SectionBase", "title key type")):
        """A docstring section."""
        # Tests for this class have not been implemented.
        pass

    Section.__module__ = "test_Section"


# Generated at 2022-06-21 11:45:53.888816
# Unit test for function parse
def test_parse():
    from .common import print_docstring

    text = """This is the short description for this function.

    This is the long description for this function.

    Args:
        param1: This is the first parameter.
        param2: This is a second parameter.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    """

    result = parse(text)
    print_docstring(result)



# Generated at 2022-06-21 11:45:56.345057
# Unit test for constructor of class Section
def test_Section():
    sections = DEFAULT_SECTIONS

    for i in range(len(sections)):
        assert sections[i].title == DEFAULT_SECTIONS[i].title
    

# Generated at 2022-06-21 11:45:56.913019
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert True

# Generated at 2022-06-21 11:46:07.287865
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    doc = """Summarize the DocstringParse here.
    Params:
        arg1 (int): Description of arg1
        arg2 (optional, str): Description of arg2. Defaults to None.
    Returns:
        int. Description of return value.
    """

    # Act
    sut = GoogleParser().parse(doc)

    # Assert
    assert len(sut.meta) == 3
    assert isinstance(sut.meta[0], DocstringParam)
    assert isinstance(sut.meta[1], DocstringParam)
    assert isinstance(sut.meta[2], DocstringReturns)

# Generated at 2022-06-21 11:46:19.553964
# Unit test for function parse
def test_parse():
    docstring = parse("""
    This is a test for function parse.

    Args:
        arg1: The first argument
        arg2 (int): The second argument
        arg3 (str, optional): The third argument. Defaults to None.

    Returns:
        int. The return value.
        """)
    assert docstring.short_description == "This is a test for function parse."
    assert docstring.blank_after_short_description
    assert docstring.long_description is None
    assert docstring.blank_after_long_description

    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument"
    assert docstring.meta[1].args == ["param", "arg2"]
   

# Generated at 2022-06-21 11:46:30.139216
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:46:40.587499
# Unit test for constructor of class Section
def test_Section():
    assert Section("Parameters", "param", SectionType.MULTIPLE).title == "Parameters"
    assert Section("Parameters", "param", SectionType.MULTIPLE).key == "param"
    assert Section("Parameters", "param", SectionType.MULTIPLE).type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:46:44.924062
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text = ":param: Table name"
    G1 = GoogleParser(title_colon=False)
    G2 = GoogleParser(title_colon=True)
    assert G1.parse(text) == G2.parse(text)
    assert G1.parse(text).meta == G2.parse(text).meta

# Generated at 2022-06-21 11:46:47.391132
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    t = Section("t", "t", 0)
    g.add_section(t)


# Generated at 2022-06-21 11:46:56.904746
# Unit test for constructor of class Section
def test_Section():
    desc_1 = {'title': 'Params', 'key': 'param', 'type': 1}
    desc_2 = {'title': 'Raises', 'key': 'raises', 'type': 1}
    obj_1 = Section(title = 'Params', key = 'param', type = 1)
    obj_2 = Section(title = 'Raises', key = 'raises', type = 1)
    assert(obj_1.__dict__ == desc_1)
    assert(obj_2.__dict__ == desc_2)


# Generated at 2022-06-21 11:47:01.324594
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Test", "test", SectionType.MULTIPLE))
    assert 'Test' in parser.sections
    assert parser.sections['Test'] == Section("Test", "test", SectionType.MULTIPLE)


# Generated at 2022-06-21 11:47:07.428504
# Unit test for constructor of class Section
def test_Section():
    SectionType.SINGULAR = 0
    SectionType.MULTIPLE = 1
    SectionType.SINGULAR_OR_MULTIPLE = 2
    sec = Section("Arguments", "param", SectionType.MULTIPLE)
    assert sec.title == "Arguments"
    assert sec.key == "param"
    assert sec.type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:47:09.181899
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser is not None
    google_parser=GoogleParser()
    assert google_parser is not None


# Generated at 2022-06-21 11:47:21.503997
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""
    docstring = GoogleParser().parse(
        """
    A function with types documented in the docstring.

    `PEP 484`_ type annotations are supported. If attribute, parameter, and
    return types are annotated according to `PEP 484`_, they do not need to be
    included in the docstring:

    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    .. _PEP 484:
        https://www.python.org/dev/peps/pep-0484/

    """
    )
    assert docstring.short_description == "A function with types documented in the docstring."
    assert docstring.long_description.startsw

# Generated at 2022-06-21 11:47:33.434060
# Unit test for function parse
def test_parse():
    docstring = """
    This is the summary line.

    This is the extended description.  It helps to explain the purpose
    of the function, and put it into context.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
        arg3 (list): Description of arg3
        arg4 (bool, optional): Description of arg4. Defaults to False.
        arg5 (:obj:`os.PathLike`, optional):
            Description of arg5. Defaults to None.
        *args: Description of *args
        **kwargs: Description of **kwargs

    Returns:
        dict: Description of return value

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """

    ds = parse(docstring)
    print(ds)


# Generated at 2022-06-21 11:47:34.250834
# Unit test for constructor of class Section
def test_Section():
    return



# Generated at 2022-06-21 11:47:48.588911
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    #Default Sections
    parser = GoogleParser()
    parser.sections == { section.title: section for section in DEFAULT_SECTIONS}
    # One new section and the old one is removed
    section = Section("Test","test",SectionType.SINGULAR)
    parser.add_section(section)
    parser.sections == { section.title: section for section in DEFAULT_SECTIONS + [section]}
    # Two new sections, the old ones are removed
    section2 = Section("Test2","test2",SectionType.SINGULAR)
    parser.add_section(section2)
    parser.sections == { section.title: section for section in DEFAULT_SECTIONS + [section,section2]}

# Generated at 2022-06-21 11:47:59.525472
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    '''
    Description:
    ------------
    This function tests the method add_section of the class GoogleParser. 
    
    '''
    
    # Create a GoogleParser class
    gp = GoogleParser()
    
    # Add two new sections
    gp.add_section(Section('ALGORITHM', 'algorithm', SectionType.SINGULAR_OR_MULTIPLE))
    gp.add_section(Section('REFERENCE', 'reference', SectionType.SINGULAR))
    
    # Check that the two new sections were added
    assert gp.sections.keys() == {'ALGORITHM', 'REFERENCE', 'Examples', 'Args', 'Arguments', 'Attributes', 'Raises', 'Parameters', 'Except', 'Exceptions', 'Params', 'Returns', 'Yields'}

    # Check that

# Generated at 2022-06-21 11:48:11.987071
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()

# Generated at 2022-06-21 11:48:23.853611
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_text1 = """\
    This is a summary of the class.
    
    This is the long description of the class.
    
    Args:
        argument1 (argument1_type): The description of argument1.
    """
    docstring_text2 = docstring_text1 + """\
        argument2 (argument2_type): The description of argument2.
    """
    docstring_text3 = """\
    This is a summary of the class.
    
    This is the long description of the class.
    
    Args:
        argument1 (argument1_type): The description of argument1.
            This is a continuation of the description of argument1.
    """

# Generated at 2022-06-21 11:48:30.829902
# Unit test for function parse

# Generated at 2022-06-21 11:48:38.713393
# Unit test for function parse
def test_parse():
    DOCSTRING = """
        This function does something amazing.

        This is the long description. It can contain
        multiple paragraphs and any other useful information
        about the function.

        The short description is the first paragraph and
        it should be concise, generally no longer than about 50
        characters.

        Args:
            arg1 (str): The first argument.
            arg2 (str, optional):  The second argument.
                Defaults to None.
            arg3 (str):
                The third argument.

        Returns:
            str: Some return value.
    """
    PARSED_DOCSTRING = parse(DOCSTRING)
    assert PARSED_DOCSTRING.short_description == "This function does something amazing."

# Generated at 2022-06-21 11:48:49.843910
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))
    with open(dir_path+'/test_GoogleParser_parse.txt') as f:
        content = f.read()

# Generated at 2022-06-21 11:49:00.580998
# Unit test for function parse
def test_parse():
    docstring = """Basic example.

    :param int bar: bar
    :param foo: foo
    """

    doc = parse(docstring)

    assert doc.short_description == "Basic example."
    assert doc.long_description is None
    assert doc.blank_after_long_description is False
    assert doc.blank_after_short_description is True

    assert doc.meta[0].args == ['param', 'int bar']
    assert doc.meta[0].arg_name == 'bar'
    assert doc.meta[0].type_name == 'int'
    assert doc.meta[0].is_optional is False

    assert doc.meta[1].args == ['param', 'foo']
    assert doc.meta[1].arg_name is None
    assert doc.meta[1].type_name is None
    assert doc

# Generated at 2022-06-21 11:49:04.951921
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser(title_colon=True)
    print("\n-------- Parser --------\n")
    print()
    for section in parser.sections:
        print("section: ", section)
    print("title_colon: ", parser.title_colon)
    print("titles_re: ", parser.titles_re)


# Generated at 2022-06-21 11:49:10.503702
# Unit test for constructor of class Section
def test_Section():
    assert Section("Parameters", "param", SectionType.MULTIPLE).title == "Parameters"
    assert Section("Args", "param", SectionType.MULTIPLE).key == "param"
    assert Section("Example", "examples", SectionType.SINGULAR).type == SectionType.SINGULAR



# Generated at 2022-06-21 11:49:21.701142
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = GoogleParser().parse("""\
    Author:
        Alex
    """)
    assert doc.short_description == 'Author'
    assert doc.long_description is None
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is False
    assert doc.meta[0].key == 'author'
    assert doc.meta[0].args[0] == 'author'
    assert doc.meta[0].args[1] == ''
    assert doc.meta[0].description == 'Alex'

# Generated at 2022-06-21 11:49:25.521294
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    p = GoogleParser()
    p.add_section(Section("Hello", "greetings", SectionType.SINGULAR))
    assert p.sections.get("Hello") == Section("Hello", "greetings", SectionType.SINGULAR)


# Generated at 2022-06-21 11:49:33.936153
# Unit test for constructor of class Section
def test_Section():
    print("Testing Section()...", end="")
    sample_section = Section("Title", "key", SectionType.MULTIPLE)

    assert sample_section.title == "Title"
    assert sample_section.key == "key"
    assert sample_section.type == SectionType.MULTIPLE

    sample_section = Section("Title", "key", SectionType.SINGULAR)
    assert sample_section.title == "Title"
    assert sample_section.key == "key"
    assert sample_section.type == SectionType.SINGULAR

    sample_section = Section("Title", "key", SectionType.SINGULAR_OR_MULTIPLE)
    assert sample_section.title == "Title"
    assert sample_section.key == "key"
    assert sample_section.type == SectionType.SINGULAR_OR

# Generated at 2022-06-21 11:49:46.193195
# Unit test for constructor of class Section
def test_Section():
    # Testes
    testes = [
        Section("Key", "value", SectionType.SINGULAR),
        Section("Key", "value", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Key", "value", SectionType.MULTIPLE),
    ]
    # Resultados esperados
    results = [
        ("Key", "value", SectionType.SINGULAR),
        ("Key", "value", SectionType.SINGULAR_OR_MULTIPLE),
        ("Key", "value", SectionType.MULTIPLE),
    ]
    # Verifica se os resultados esperados e os resultados obtidos batem
    if testes != results:
        raise Exception("Teste falhou!")


# Generated at 2022-06-21 11:49:56.287950
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Test with default DEFAULT_SECTIONS
    gParser = GoogleParser()
    assert len(gParser.sections) == len(DEFAULT_SECTIONS)

    # Test with empty list as input
    gParser = GoogleParser([])
    assert len(gParser.sections) == 0

    # Test with input for title_colon==True
    gParser = GoogleParser(title_colon=True)
    assert len(gParser.sections) == len(DEFAULT_SECTIONS)
    gParser.add_section(Section("NewSection", "new", SectionType.MULTIPLE))
    assert len(gParser.sections) == len(DEFAULT_SECTIONS) + 1

    # Test with input for title_colon==False
    gParser = GoogleParser(title_colon=False)

# Generated at 2022-06-21 11:49:59.045343
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    assert google_parser.sections is not None
    assert google_parser.title_colon is not None



# Generated at 2022-06-21 11:50:08.418564
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("section1", "section1", SectionType.SINGULAR),
        Section("section2", "section2", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    section = [
        Section("section3", "section3", SectionType.MULTIPLE),
    ]
    parser = GoogleParser(sections=sections)
    parser.add_section(section[0])
    assert(parser.sections == {
        'section1': sections[0],
        'section2': sections[1],
        'section3': section[0],
    })


# Generated at 2022-06-21 11:50:15.341989
# Unit test for function parse
def test_parse():
    """Test function parse."""
    doc = r"""
    This is the short description.

    This is the long description.
    It can be multiple lines.

    This is the first section.
    It is intended to have indented code blocks::

        # This is a code block
        print("hello")

    This is the second section.
    """
    parts = parse(doc)

    assert parts.short_description == "This is the short description."
    assert parts.long_description == (
        'This is the long description.\nIt can be multiple lines.'
    )
    assert parts.blank_after_short_description is True
    assert parts.blank_after_long_description is True


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:50:19.552976
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section = Section("Test Arguments", "test_param", SectionType.MULTIPLE)
    parser = GoogleParser()
    parser.add_section(section)
    assert section in parser.sections.values()


# Generated at 2022-06-21 11:50:30.538127
# Unit test for constructor of class Section
def test_Section():
    test_obj1 = Section("Test_Title", "test_key", SectionType.SINGULAR)
    assert test_obj1.title == "Test_Title", "Should be the same title"
    assert test_obj1.key == "test_key", "Should be the same key"
    assert test_obj1.type == SectionType.SINGULAR, "Should be the same type"
    assert test_obj1[0] == "Test_Title",  "Should be the same title"
    assert test_obj1[1] == "test_key", "Should be the same key"
    assert test_obj1[2] == SectionType.SINGULAR, "Should be the same type"
    

# Generated at 2022-06-21 11:50:57.863279
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    My Class

    Attributes:
        var1: the first variable
        var2: the second variable

    Examples:
        >>> object1 = MyClass(var1, var2)
    """
    doc = GoogleParser().parse(docstring)

    assert doc.short_description == "My Class"
    assert isinstance(doc.meta[0], DocstringMeta)
    assert doc.meta[0].args == ["attribute", "var1"]
    assert doc.meta[0].description == "the first variable"
    assert isinstance(doc.meta[1], DocstringMeta)
    assert doc.meta[1].args == ["attribute", "var2"]
    assert doc.meta[1].description == "the second variable"
    assert isinstance(doc.meta[2], DocstringMeta)

# Generated at 2022-06-21 11:51:00.644356
# Unit test for constructor of class Section
def test_Section():
    Section_test = Section(title="Arguments",key="param",type=SectionType.MULTIPLE)
    print(Section_test)



# Generated at 2022-06-21 11:51:02.287563
# Unit test for constructor of class Section
def test_Section():
    assert Section("arguments", "param", SectionType.MULTIPLE)
    

# Generated at 2022-06-21 11:51:08.237629
# Unit test for constructor of class Section
def test_Section():
    # Test for constructor of class Section
    title = "Arguments"
    key = "param"
    type = SectionType.MULTIPLE
    test_section = Section(title, key, type)
    assert test_section.title == title
    assert test_section.key == key
    assert test_section.type == type


# Generated at 2022-06-21 11:51:17.481935
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section1 = Section("Test 1", "test1", SectionType.SINGULAR)
    parser.add_section(section1)
    section2 = Section("Test 2", "test2", SectionType.SINGULAR_OR_MULTIPLE)
    parser.add_section(section2)
    section3 = Section("Test 3", "test3", SectionType.MULTIPLE)
    parser.add_section(section3)
    assert parser.sections == {'Test 1': section1, 'Test 2': section2, 'Test 3': section3}


# Generated at 2022-06-21 11:51:27.500944
# Unit test for function parse
def test_parse():
    # test for short description only
    text = '''This is short description.'''
    result = parse(text)
    assert result.short_description == 'This is short description.'
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert result.long_description is None
    assert len(result.meta) == 0

    # test for description with multiple lines
    text = '''This is short description.\n    This is long description.'''
    result = parse(text)
    assert result.short_description == 'This is short description.'
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert result.long_description == 'This is long description.'
    assert len(result.meta) == 0

   

# Generated at 2022-06-21 11:51:29.544079
# Unit test for constructor of class Section
def test_Section():
    # noinspection PyTypeChecker
    assert Section("Title", "key", SectionType.SINGULAR)



# Generated at 2022-06-21 11:51:33.259962
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test parsing of the class GoogleParser
    """
    parse("""
        Short description of the module.

        Long description of the module.

        Args:
            arg1: Name of arg1.

        Returns:
            Returned value.
        """)


# Generated at 2022-06-21 11:51:45.161415
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    input_string = """
        Args:
            x (int): some integer
            y (float, optional): some float. Defaults to 1.0.
            z (str, optional)
        Returns:
            None
    """

# Generated at 2022-06-21 11:51:52.535888
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
    def method(
        self,
        arg1: the first argument,
        arg2: the second argument (optional, defaults to 0)
    ) -> None
    """
    parser = GoogleParser(sections=[
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Parameters", "param", SectionType.MULTIPLE),
    ])
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    parser.parse(text)


# Generated at 2022-06-21 11:52:08.901267
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    @GoogleParser.parse
    def returns_a_docstring():
        """Short description.

        The first line is short description. The rest is long
        description.

        Args:
            arg1 (str): The first argument.
            arg2 (int, optional): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.

        """
        pass
    assert returns_a_docstring.short_description == "Short description."
    assert returns_a_docstring.long_description == "The first line is short description. The rest is long description."
    assert returns_a_docstring.blank_after_short_description == False
    assert returns_a_docstring.blank_after_long_description == False
    assert len(returns_a_docstring.meta) == 3
    assert returns_

# Generated at 2022-06-21 11:52:22.129771
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    Creates a GoogleParser object and adds a Section
    """

# Generated at 2022-06-21 11:52:29.484468
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("Short") == Docstring(short_description="Short")
    assert (
        parse("Short\n\nLong")
        == Docstring(
            short_description="Short",
            blank_after_short_description=True,
            long_description="Long",
            blank_after_long_description=True,
        )
    )
    assert (
        parse("Short\n\nLong\n\nMore")
        == Docstring(
            short_description="Short",
            blank_after_short_description=True,
            long_description="Long\n\nMore",
            blank_after_long_description=False,
        )
    )

# Generated at 2022-06-21 11:52:41.127471
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    empty_docstring = ""
    empty_docstring_ret = Docstring()
    assert empty_docstring_ret == GoogleParser().parse(empty_docstring)

    short_docstring = "This is a short description."
    short_docstring_ret = Docstring()
    short_docstring_ret.short_description = "This is a short description."
    assert short_docstring_ret == GoogleParser().parse(short_docstring)

    long_empty_docstring = "\n\n"
    long_empty_docstring_ret = Docstring()
    long_empty_docstring_ret.long_description = ""
    long_empty_docstring_ret.blank_after_short_description = True
    long_empty_docstring_ret.blank_after_long_description = True
    assert long_empty_docstring_

# Generated at 2022-06-21 11:52:42.311783
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    if parser is None:
        assert False
    else:
        assert True


# Generated at 2022-06-21 11:52:51.732718
# Unit test for function parse

# Generated at 2022-06-21 11:53:01.210761
# Unit test for function parse

# Generated at 2022-06-21 11:53:11.732079
# Unit test for function parse

# Generated at 2022-06-21 11:53:17.964885
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
        This is a test method.

        Args:
          arg1: Argument 1
          arg2: Argument 2
    """

    docstring = parse(text)

    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[1].arg_name == 'arg2'

# Generated at 2022-06-21 11:53:28.280411
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == parse("")


# assert GoogleParser().parse("A short desc.") == parse("A short desc.")
# assert GoogleParser().parse("A short desc.\n") == parse("A short desc.\n")
# assert GoogleParser().parse("A short desc.\n\n") == parse("A short desc.\n\n")
# assert GoogleParser().parse("A short desc.\n\nA long desc.\n") == parse("A short desc.\n\nA long desc.\n")
# assert GoogleParser().parse("A short desc.\n\nA long desc.\n\n") == parse("A short desc.\n\nA long desc.\n\n")
# assert GoogleParser().parse("A short desc.\n\n\nA long desc.\n\n")

# Generated at 2022-06-21 11:53:41.260530
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    googleParser_1 = GoogleParser()
    if 'Layers' in googleParser_1.sections:
        assert ('Layers' in googleParser_1.sections) & ('Args' in googleParser_1.sections) & ('Raises' in googleParser_1.sections)
    else:
        assert True


# Generated at 2022-06-21 11:53:52.692415
# Unit test for function parse
def test_parse():
    assert(isinstance(parse("Docstring without fields."), Docstring))
    assert(isinstance(parse("Docstring without fields.\n   "), Docstring))
    assert(isinstance(parse("Docstring without fields.\n  \n"), Docstring))
    assert(isinstance(parse("Docstring without fields.\n\n"), Docstring))
    
    assert(isinstance(parse("Examples:\n	Example\n"), Docstring))
    assert(isinstance(parse("Args:\n	arg_name"), Docstring))
    assert(isinstance(parse("Args:\n	arg_name\n"), Docstring))
    assert(isinstance(parse("Args:\n	arg_name - description"), Docstring))
    assert(isinstance(parse("Args:\n	arg_name - description\n"), Docstring))

# Generated at 2022-06-21 11:54:04.214720
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring, DocstringParam
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("    ") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse(" ") == Docstring()
    assert GoogleParser().parse("\n\n\n  \n\n") == Docstring()
    assert GoogleParser().parse("This is a test.") == Docstring(
        short_description="This is a test.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
    )

# Generated at 2022-06-21 11:54:05.712440
# Unit test for constructor of class Section
def test_Section():
    assert Section("Parameters", "param", SectionType.MULTIPLE)


# Generated at 2022-06-21 11:54:15.856366
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    # Empty docstring
    assert parser.parse("") == Docstring()

    # Short description only
    short_text = "Hello, world"
    short_docstring = Docsting(
        short_description=short_text, long_description=None, meta=[]
    )
    assert parser.parse(short_text) == short_docstring

    # Short and long descriptions
    # Test with and without blank lines after the short description.
    long_text = "Hello, world!\n\nThis is a long description."
    long_docstring = Docstring(
        short_description=short_text,
        blank_after_short_description=False,
        long_description=long_text.strip("\n"),
        meta=[],
    )

# Generated at 2022-06-21 11:54:24.169984
# Unit test for function parse
def test_parse():
    docstring = r"""Summary line.
    Extended description

    @param arg1: Description
    @param arg2: Description
    @param arg3: Description
        Description continued
    @param arg4: Description
    @return: Description
    @raises ValueError: Description
    @raises NotImplementedError: Description
    """
    # result = parse(docstring)
    # docstring_result = str(result)
    # print(docstring_result)


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:54:27.902002
# Unit test for function parse
def test_parse():
    text = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """

    result = parse(text)
    print(result)

if __name__ == '__main__':
    test_parse()

# Generated at 2022-06-21 11:54:31.089820
# Unit test for constructor of class Section
def test_Section():
    s = Section('Arguments', 'param', SectionType.MULTIPLE)
    assert s.title == 'Arguments'
    assert s.key == 'param'
    assert s.type == SectionType.MULTIPLE
