

# Generated at 2022-06-21 11:45:29.667233
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    with open('GoogleParser.py', 'r') as docstring:
        parser = GoogleParser()

    doc = parser.parse(docstring.read())
    assert doc.short_description == "GoogleParser"
    attributes = doc.meta[-4:]
    assert attributes[0].arg_name == "sections"
    assert attributes[1].arg_name == "title_colon"
    assert attributes[2].arg_name == "titles_re"
    assert attributes[3].arg_name == "self"
    assert isinstance(attributes[0], DocstringParam)



# Generated at 2022-06-21 11:45:36.518937
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Converts an object to a double or returns a default.

    Args:
      input: a `double` or `string` Tensor.
      default: a `double`; default value if the object cannot be converted to
        a `double`.
      name: A name for the operation (optional).

    Returns:
      A `double` Tensor.
    """
    print(GoogleParser().parse(text))


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-21 11:45:46.823550
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = [
        Section("BlaBla", "blabla", SectionType.SINGULAR_OR_MULTIPLE),
        Section("BlaBlaBla", "blablabla", SectionType.SINGULAR),
        Section("BlaBlaBlaBla", "blablablabla", SectionType.MULTIPLE),
        Section("BlaBlaBlaBlaBla", "blablablablabla", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    g = GoogleParser()
    for section in sections:
        g.add_section(section)
    assert(g.sections["BlaBla"].key == sections[0].key)
    assert(g.sections["BlaBlaBla"].key == sections[1].key)

# Generated at 2022-06-21 11:45:58.257192
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
    This is a multi-line descriptive docstring.
    This is long description.
    Args:
        arg_1: The first argument.
        arg_2: The second argument.
    Returns:
        int -- The return value: 0 for success, 1 otherwise.
    Raises:
        AttributeError -- The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
        ValueError -- If `param2` is equal to `param1`.
    """
    x = GoogleParser()
    print(x.parse(text=text))
    parser = GoogleParser()
    param = Section("Attribute", "attribute", SectionType.MULTIPLE)
    parser.add_section(section=param)
    print(parser.parse(text=text))

# Generated at 2022-06-21 11:46:11.131151
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # One-line description
    text = "Return the integer value of a digit or None."
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "Return the integer value of a digit or None."
    assert docstring.long_description == None

    # One-line description with spaces before and after
    text = """
    Return the integer value of a digit or None.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "Return the integer value of a digit or None."
    assert docstring.long_description == None

    # One-line description with spaces before and after, ending with spaces
    text = """
    Return the integer value of a digit or None.
    
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_

# Generated at 2022-06-21 11:46:22.352808
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def f(x: int, y: int = 0, z: int = 0) -> int:
        """Summary line.

        Extended description of method.

        Args:
            x: int
            y: int
            z: int

        Returns:
            int: Description after return colon.

        Raises:
            KeyError: Raises an exception.
            OtherError: Another exception.

        """

    ret = parse(inspect.cleandoc(f.__doc__))
    assert ret.meta[0].args == ["returns", "int"]
    assert ret.meta[0].arg_name == "int"
    assert ret.meta[0].type_name == "int"
    assert ret.meta[0].is_optional is False
    assert ret.meta[0].default is None

# Generated at 2022-06-21 11:46:31.974631
# Unit test for function parse
def test_parse():
    text = """
        Short description.

        Long description.

        Args:
            arg1: type1. Desc 1.
            arg2: type2. Desc 2.

        Returns:
            desc.

        Raises:
            Exception: desc.

        Yields:
            desc.
    """

    doc = parse(text)

    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_long_description is True
    assert doc.blank_after_short_description is False

    assert doc.meta[0].args == ["arg1"]
    assert doc.meta[0].description == "type1. Desc 1."
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name is None

# Generated at 2022-06-21 11:46:38.633826
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_text = """
        Parse the Google-style docstring into its components.

        :returns: parsed docstring

        Args:
            text: Text of docstring

        Returns:
            Parsed docstring
    """
    ret = parse(test_text)
    assert ret.short_description == "Parse the Google-style docstring into its components."
    assert ret.long_description == ":returns: parsed docstring"
    assert len(ret.meta) == 2 and isinstance(ret.meta[0], DocstringParam) and isinstance(ret.meta[1], DocstringReturns)


# Generated at 2022-06-21 11:46:39.556782
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    pass


# Generated at 2022-06-21 11:46:46.574189
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser(title_colon=True)
    assert "example" in parser.titles_re.pattern.lower()
    assert "yields:" in parser.titles_re.pattern.lower()
    assert "returns:" in parser.titles_re.pattern.lower()
    assert "args:" in parser.titles_re.pattern.lower()
    assert "args:" in parser.titles_re.pattern.lower()
    assert "arguments:" in parser.titles_re.pattern.lower()
    assert "args:" in parser.titles_re.pattern.lower()
    assert "parameters:" in parser.titles_re.pattern.lower()
    assert "params:" in parser.titles_re.pattern.lower()
    assert "raises:" in parser.titles_re.pattern.lower()

# Generated at 2022-06-21 11:47:10.205288
# Unit test for function parse
def test_parse():
    doc = inspect.cleandoc(
        """
    This is a short description.

    This is a long description.

    Attributes:
        attr1: Description of `attr1`

    """
    )
    docstring = parse(doc)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert len(docstring.meta) == 1
    assert docstring.meta[0] == DocstringMeta(
        args=["attribute", "attr1"], description="Description of `attr1`"
    )



# Generated at 2022-06-21 11:47:22.432815
# Unit test for function parse
def test_parse():
    text = """My short description
    My long description

    Args:
        a (int): An integer.
        b (str): A string.
        c (list, optional): A list. Defaults to [].

    Returns:
        str: My returns.

    Raises:
        ValueError: An exception.
    """

    # Parse the google-style docstring
    docstring = parse(text)

    # Check whether imported correctly

# Generated at 2022-06-21 11:47:34.161603
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("1") == Docstring(short_description="1", long_description=None)
    content = parser.parse("1\n2")
    assert content == Docstring(short_description="1", long_description="2")
    assert content.short_description == "1"
    assert content.long_description == "2"
    assert content.blank_after_short_description == False
    assert content.blank_after_long_description == False
    content = parser.parse("1\n  2")
    assert content == Docstring(short_description="1", long_description="2")
    assert content.short_description == "1"
    assert content.long_description == "2"

# Generated at 2022-06-21 11:47:46.668877
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser(title_colon=True)
    text = '''
        This is a description of a function.

        Params:
            a: First argument.
            b: Second argument. Also accepts 3 and 8.

        Returns:
            The average of the two arguments.

        Raises:
            TypeError: if either argument is not a number.
    '''

    doc = parser.parse(text)
    assert doc.short_description == "This is a description of a function."

# Generated at 2022-06-21 11:47:57.744336
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
This is an example of Google-style docstrings.

Args:
    param1: The first parameter.
    param2: The second parameter.
Returns:
    True if successful, False otherwise.
'''
    doc = parse(docstring)
    docstring_2 = '''
""" This is an example of Google-style docstrings.

Args:
    param1: The first parameter.
    param2: The second parameter.
Returns:
    True if successful, False otherwise.
"""
'''
    doc_2 = parse(docstring_2)
    return (docstring == docstring_2) & (doc.short_description == doc_2.short_description) & (doc_2.long_description == doc.long_description)

# Generated at 2022-06-21 11:48:10.646236
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    type_1 = GoogleParser()
    # print(type(type_1)) # <class '__main__.GoogleParser'>
    # print(type_1.sections)
    # {'Args': Section(title='Args', key='param', type=1),
    #  'Arguments': Section(title='Arguments', key='param', type=1),
    #  'Attributes': Section(title='Attributes', key='attribute', type=1),
    #  'Example': Section(title='Example', key='examples', type=0),
    #  'Examples': Section(title='Examples', key='examples', type=0),
    #  'Parameters': Section(title='Parameters', key='param', type=1),
    #  'Params': Section(title='Params', key='param', type=1),
    #  '

# Generated at 2022-06-21 11:48:22.228638
# Unit test for function parse
def test_parse():
    doc = """
    This function returns the square value of the input number

    Args:
        x: int or float

    Returns:
        int or float
    """

# Generated at 2022-06-21 11:48:25.610984
# Unit test for constructor of class Section
def test_Section():
    assert Section("a", "b", SectionType.SINGULAR_OR_MULTIPLE)
    assert Section("a", "b", SectionType.SINGULAR)
    assert Section("a", "b", SectionType.MULTIPLE)


# Generated at 2022-06-21 11:48:33.912400
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Test GoogleParser on a sample string
    googleparser_obj = GoogleParser()
    docstring_obj = googleparser_obj.parse(
        """
        Main function

        Args:
            a_param (str): a parameter.

        Return:
            int: a number.
        """
    )
    assert docstring_obj.short_description == "Main function"
    assert docstring_obj.meta[0].description == "a parameter."
    assert docstring_obj.meta[1].description == "a number."

    # Test GoogleParser on the same sample string, but with a colon after the "Args"
    googleparser_obj = GoogleParser(title_colon=False)

# Generated at 2022-06-21 11:48:41.599061
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class A:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    import inspect
    import types
    import numpy as np
    import datetime as dt
    import omegaconf as oc

    doc = """
    """
    for i in range(1):
        fname = "foo" + str(i)
        f = A(*[1,2,3],**{'n':1})
        if i == 0:
            f = lambda x: np.mean(x)
            doc = """
            Function to calculate the mean value. 
            
            Args:
                x: A numpy array.

            Returns:
                The mean value.
            """
        

# Generated at 2022-06-21 11:48:55.417158
# Unit test for function parse
def test_parse():
    docstring = """
    Short description.

    Long description.
    Over multiple lines if needed.

    Args:
        what: what arg
    """
    d = parse(docstring)
    assert d.short_description == 'Short description.'
    assert d.long_description == 'Long description.\nOver multiple lines if needed.'
    assert d.blank_after_short_description
    assert not d.blank_after_long_description
    assert len(d.meta) == 1
    m = d.meta[0]
    assert m.description == 'what'
    assert m.args == ["param", "what: what arg"]
    assert m.arg_name == "what"



# Generated at 2022-06-21 11:49:04.907632
# Unit test for constructor of class GoogleParser

# Generated at 2022-06-21 11:49:06.312506
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser is not None


# Generated at 2022-06-21 11:49:11.764213
# Unit test for constructor of class Section
def test_Section():
    x = Section("test", "test", SectionType.SINGULAR_OR_MULTIPLE)
    assert x.title == "test"
    assert x.key == "test"
    assert x.type == SectionType.SINGULAR_OR_MULTIPLE


# Generated at 2022-06-21 11:49:15.722629
# Unit test for constructor of class Section
def test_Section():
    sec1 = Section("Arguments", "param", SectionType.MULTIPLE)
    assert sec1.title == "Arguments"
    assert sec1.key == "param"
    assert sec1.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:49:27.020383
# Unit test for function parse
def test_parse():
    """Test google style parser."""
    doc = """Takes two numbers and adds them.

    Args:
      num1 (int): First number to add.
      num2 (int): Second number to add.

    Returns:
      int: The sum of num1 and num2.
    """
    result = parse(doc)
    assert len(result.meta) == 2
    assert any(isinstance(m, DocstringParam) for m in result.meta)
    assert any(isinstance(m, DocstringReturns) for m in result.meta)


# Generated at 2022-06-21 11:49:27.623549
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # ADD YOUR CODE HERE
    pass


# Generated at 2022-06-21 11:49:40.503378
# Unit test for function parse
def test_parse():
    test_text = """
    This is the short description.

    This is the long description.

    This is a long description continued on a new line.

    Returns:
        Return a value.

    Raises:
        ValueError: if something bad happens.

    """
    result = parse(test_text)
    assert result.short_description == 'This is the short description.'
    assert result.long_description == 'This is the long description.\n\nThis is a long description continued on a new line.'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 2
    assert type(result.meta[0]) == DocstringReturns
    assert result.meta[0].description == 'Return a value.'

# Generated at 2022-06-21 11:49:53.045850
# Unit test for function parse
def test_parse():
    assert parse("""
    Hello,

    I'm function tests.
    
    Ok?
    """) == Docstring(
        short_description="Hello,",
        blank_after_short_description=True,
        long_description="I'm function tests.\n\nOk?",
        blank_after_long_description=True,
    )


# Generated at 2022-06-21 11:49:54.904609
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    a = GoogleParser()
    assert type(a) == GoogleParser
    

# Generated at 2022-06-21 11:50:05.009370
# Unit test for constructor of class Section
def test_Section():
    sec = Section(title='Arguments', key='param', type=0)
    assert sec.title == 'Arguments'
    assert sec.key == 'param'
    assert sec.type == 0 # type == SectionType.SINGULAR

# Generated at 2022-06-21 11:50:11.147772
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    assert GoogleParser(title_colon=True)
    assert GoogleParser(title_colon=False)
    Sections = [Section("Name", "Names", SectionType.MULTIPLE)]
    parser1 = GoogleParser(Sections, title_colon=True)
    parser2 = GoogleParser(Sections, title_colon=False)
    assert parser1 and parser2
    assert parser1.titles_re
    assert parser2.titles_re


# Generated at 2022-06-21 11:50:17.105159
# Unit test for function parse
def test_parse():
    def foo():
        """This is the brief description.
        -
        This is the long description.

        Parameters
        ----------
        x : int
            This is the first argument.

        y : float?
            This argument is optional.

        Returns
        -------
        int
            The return value.
        """

    assert parse(foo.__doc__).short_description == "This is the brief description."
    assert parse(foo.__doc__).long_description == "This is the long description."
    assert parse(foo.__doc__).blank_after_short_description
    assert parse(foo.__doc__).blank_after_long_description

    assert str(parse(foo.__doc__)) == foo.__doc__

    assert len(parse(foo.__doc__).meta) == 3

# Generated at 2022-06-21 11:50:29.608944
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    import sys
    import os
    import time
    path = os.getcwd()
    if path.find("src") < 0:
        path += "/src/"
    else:
        path += "/"

    # Insert src and test path to python path
    sys.path.append(path)
    from sklearn.linear_model import LinearRegression
    from sklearn.preprocessing import PolynomialFeatures
    from sklearn.pipeline import make_pipeline

    # parse the doc string of sklearn.pipeline
    f = make_pipeline
    doc = parse(f.__doc__)
    # print(doc.short_description)
    # print(doc.long_description)
    # print('Description:', doc.short_description, doc.long_description)
    # print('Meta:')
   

# Generated at 2022-06-21 11:50:39.749520
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = '''\
        def test():
            """This is a test.
        
            This is
            the long description.
            Yields:
                a: the first yield
                b: the second yield
        
            Examples:
                >>> test()
            """
    '''

    parser = GoogleParser()

    # Parse the docstring
    ret = parser.parse(text)

    # Add a new section
    parser.add_section(
        Section(
            title="Preconditions",
            key="precondition",
            type=SectionType.SINGULAR,
        )
    )

    # Parse the docstring again
    ret = parser.parse(text)

# Generated at 2022-06-21 11:50:48.127806
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    sections = [
        Section("Attributes", "attribute", SectionType.MULTIPLE),
    ]
    googleParser1 = GoogleParser(sections)
    sections = [
        Section("Attributes", "attribute", SectionType.MULTIPLE),
        Section("Arguments", "param", SectionType.MULTIPLE),
    ]
    googleParser2 = GoogleParser(sections)
    assert(len(googleParser1.sections) == 1)
    assert(len(googleParser2.sections) == 2)

# Generated at 2022-06-21 11:50:54.882156
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Create a new parser with default sections
    parser = GoogleParser()

    # Add a new section
    section = Section("Added_Section", "added", SectionType.MULTIPLE)
    parser.add_section(section)

    # Check if section is successfully added
    if section not in list(parser.sections.values()):
        print("Fail: Section not added successfully!")
    else:
        print("Successfully Add Section.")


# Generated at 2022-06-21 11:51:04.677575
# Unit test for function parse
def test_parse():
    before = """The coolest function.
    This is the greatest function of all.

    :param hater: a hater of cool
    :type hater: bool
    :returns: True if you are cool, False otherwise
    :rtype: bool

    :raises UncoolError: if you are uncool.

    Examples
    --------
    >>> is_cool()
    True
    """
    after = parse(before)
    assert after.short_description == "The coolest function."
    assert after.long_description == "This is the greatest function of all."
    assert after.blank_after_short_description == False
    assert after.blank_after_long_description == True
    assert len(after.meta) == 1
    assert after.meta[0].args == ['param', 'hater']

# Generated at 2022-06-21 11:51:10.532258
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    assert "Attributes" in parser.sections
    assert "Attrs" not in parser.sections

    parser.add_section(Section("Attrs", "attrs", SectionType.SINGULAR))
    assert "Attributes" in parser.sections
    assert "Attrs" in parser.sections


# Generated at 2022-06-21 11:51:13.116636
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse(None) == Docstring()


# Generated at 2022-06-21 11:51:24.619268
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:51:33.866683
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert(section.title == "Arguments")
    assert(section.key == "param")
    assert(section.type == SectionType.MULTIPLE)

    s = Section("Args", "param", SectionType.MULTIPLE)
    assert(s.title == "Args")
    assert(s.key == "param")
    assert(s.type == SectionType.MULTIPLE)

    s = Section("Parameters", "param", SectionType.MULTIPLE)
    assert(s.title == "Parameters")
    assert(s.key == "param")
    assert(s.type == SectionType.MULTIPLE)

    s = Section("Params", "param", SectionType.MULTIPLE)

# Generated at 2022-06-21 11:51:41.156753
# Unit test for function parse
def test_parse():
    usage = """\
    Convert an integer number to a binary string. The result is a valid Python
    expression. If x is not a Python int object, it has to define an __index__()
    method that returns an integer.
    
    Parameters:
      x (int): The number to convert.
    Example:
    """
    output = parse(usage)
    print(output)

if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:51:44.822302
# Unit test for constructor of class Section
def test_Section():
    s = Section("Raises", "raises", SectionType.MULTIPLE)
    assert s.title == "Raises"
    assert s.key == "raises"
    assert s.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:51:47.540794
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    """
    expected = Docstring()

    parsed = GoogleParser().parse(text)
    assert parsed == expected


# Generated at 2022-06-21 11:51:55.943907
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = inspect.cleandoc(r"""
    Test parse() method of GoogleParser
    
    Description.
    
    Arguments:
      argument1: test argument1
    Returns:
      (list): list of strings
    
    """)
    res = GoogleParser().parse(doc)
    exp = inspect.cleandoc(r"""
    Test parse() method of GoogleParser
    
    Description.
    """)
    assert res.short_description == exp
    assert res.long_description == None
    assert res.blank_after_short_description == True
    assert res.blank_after_long_description == False
    assert len(res.meta) == 2
    assert res.meta[0].args == ['param', 'argument1']
    assert res.meta[0].arg_name == 'argument1'
    assert res

# Generated at 2022-06-21 11:51:57.518233
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    assert isinstance(gp, GoogleParser)


# Generated at 2022-06-21 11:52:07.894013
# Unit test for function parse

# Generated at 2022-06-21 11:52:20.807861
# Unit test for function parse
def test_parse():
    """Test GoogleParser.parse()."""
    text = """This is a function.

    Args:
       arg1: The first argument.
       arg2: The second argument.

    Returns:
       A result.
    """

    result = parse(text)
    assert result.short_description == "This is a function."
    assert result.meta[0].key == "param"
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[1].key == "param"
    assert result.meta[1].args == ['param', 'arg2']
    assert result.meta[2].key == "returns"
    assert result.meta[2].args == ['returns']
    assert result.meta[2].description == "A result."


# Generated at 2022-06-21 11:52:25.167525
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """Test method add_section of class GoogleParser"""
    gp = GoogleParser()
    gp.add_section(Section("Test", "test", SectionType.SINGULAR_OR_MULTIPLE))
    assert gp.sections["Test"] == Section("Test", "test", SectionType.SINGULAR_OR_MULTIPLE)

# Generated at 2022-06-21 11:52:48.783353
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser(DEFAULT_SECTIONS)
    # Adding a new section with the same title as a default one
    # should replace it
    parser.add_section(Section("Example", "examples", SectionType.SINGULAR))
    assert parser.sections["Example"].key == "examples"
    assert parser.sections["Example"].type == SectionType.SINGULAR
    # Adding a new section with a title different from all defaults
    # should append it to the parser's sections
    parser.add_section(Section("Stuff", "stuff", SectionType.SINGULAR))
    assert parser.sections["Stuff"].key == "stuff"
    assert parser.sections["Stuff"].type == SectionType.SINGULAR

# Generated at 2022-06-21 11:52:57.123700
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test_function(a, b, c=3, d=4, e=5):
        """Short summary.

        Longer description.

        Args:
            a (str): A string.
            b (str): Another string,
                which goes over two lines.
            c (int): A third string, with optional type.
            d (int, optional): An optional one.
            e (c, optional): A third optional one,
                with a type that does not parse.
        """
        pass

    ds = GoogleParser().parse(test_function.__doc__)
    assert ds.short_description == "Short summary."
    assert ds.long_description == "Longer description."
    assert ds.blank_after_short_description == True
    assert ds.blank_after_long_description == True
   

# Generated at 2022-06-21 11:53:08.562780
# Unit test for function parse
def test_parse():
    """Unit test for class GoogleParser."""
    d = """One line summary.

    Longer, possibly multi-line description.
    """
    doc = parse(d)
    assert doc.short_description == "One line summary."
    assert (
        doc.long_description
        == "Longer, possibly multi-line description.\n"
    )

    d = """Summary which spans multiple lines.

        One liner long description.

        Raises:
            TypeError: None is not an integer

        Returns:
            int: the sum of a and b

        """
    doc = parse(d)
    assert (
        doc.long_description
        == "One liner long description.\n"
    )
    assert doc.short_description == "Summary which spans multiple lines."
    assert len(doc.meta) == 3

# Generated at 2022-06-21 11:53:20.196863
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    docstring = """
        This function does amazing things.

        Args:
            arg1: description
            arg2: description

        Returns:
            description

        Raises:
            TypeError: if arg1 is None, arg2 is None
    """

# Generated at 2022-06-21 11:53:29.862310
# Unit test for function parse
def test_parse():
    """Test basic parsing of a docstring"""
    mystr = '''
    This is a docstring
    for testing that contains
    some information about this function.

    Parameters:
        foo(int): My parameter description.
        bar(str): Description for bar.
        baz(list): Description for baz.

    Returns:
        None

    Example:
        >>> name = "foo"
        >>> val  = 11
        >>> print(f"{name}={val}")
        foo=11

    '''
    meta = parse(mystr)
    assert len(meta.meta) == 2
    assert meta.meta[1].args == ['example']
    assert "foo=11" in meta.meta[1].description
    assert meta.meta[0].args == ["returns"]

# Generated at 2022-06-21 11:53:32.450925
# Unit test for constructor of class Section
def test_Section():
    sections = Section("Arguments", "param", SectionType.MULTIPLE)
    assert sections.title == "Arguments"
    assert sections.key == "param"
    assert sections.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:53:38.685436
# Unit test for function parse
def test_parse():
    """Unit test for function parse"""

    # Test google style signature
    def test_google_style_with_args(a, b: int, *, c: str = "string") -> str:
        """
        Test google style signature.

        Args:
            a: argument a.
            b: argument b.
            *: vararg.
            c: argument c.
        Returns:
            A return value.

        """
        pass

    docstring = parse(test_google_style_with_args.__doc__)
    assert docstring.short_description == "Test google style signature"
    assert docstring.long_description == ""
    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == "argument a."
    assert docstring.meta[1].description == "A return value."



# Generated at 2022-06-21 11:53:43.009492
# Unit test for constructor of class Section
def test_Section():
    sec = Section("A", "a", SectionType.MULTIPLE)
    assert sec.title == "A"
    assert sec.key == "a"
    assert sec.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:53:53.643417
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def dummy(a: int, b: str="foobar"):
        """Test if the parser works.

        Args:
            a (int): First argument of int type.
            b (str, optional): Default is foobar.

        Raises:
            ValueError: Whatever.

        Returns:
            str: Some string.
        """
        pass

    docstring = GoogleParser().parse(inspect.getdoc(dummy))
    assert docstring.short_description == "Test if the parser works."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].description == "First argument of int type."
    assert docstring.meta

# Generated at 2022-06-21 11:54:05.257897
# Unit test for function parse
def test_parse():
    docstring = """
    This is the short description.

    A long description here.

    Example:
        Here our example

    Returns:
        int: description
        float (): description
        :param name: description

    Raises:
        Value error: description

    Args:
        name (str): description. Defaults to None.
        value (int, optional): description. Defaults to 0.

        Other (str): description
        value (int, optional): description. Defaults to 0.

    Returns:
        int: A positive integer.
        :return: A positive integer.
        :return name: A positive integer.
        :return name (str): A positive integer.
    """


# Generated at 2022-06-21 11:54:30.654418
# Unit test for function parse
def test_parse():
    docstring = """Short description.

    Long description.

    Args:
        arg1 (int): Some argument.
        arg2 (int): Some argument.
    """
    doc = parse(docstring)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1 (int)"]
    assert doc.meta[1].args == ["param", "arg2 (int)"]


if __name__ == "__main__":
    def foo(a, b):
        """Short description.

        Long description.

        Args:
            a (int): Some argument.
            b (int): Some argument.
        """

    test_parse()