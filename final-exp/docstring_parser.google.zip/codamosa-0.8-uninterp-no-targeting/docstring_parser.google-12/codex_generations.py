

# Generated at 2022-06-21 11:44:55.376411
# Unit test for function parse
def test_parse():
    text = \
    """
        Single-line docstring.

        Detailed description.
        Parameters
        ----------
        arg1:
            Description of arg1.
        arg2: str
            Description of arg2.
        Returns
        -------
        str
            Description of return value.
    """
    ret = parse(text)
    assert ret.short_description == "Single-line docstring."
    assert ret.long_description == "Detailed description."
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    assert len(ret.meta) == 3
    assert ret.meta[0].title == "param"
    assert ret.meta[0].args == ["param", "arg1"]
    assert ret.meta[0].description == "Description of arg1."
    assert ret.meta

# Generated at 2022-06-21 11:44:57.400847
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    gp.add_section(Section("Test", "param", SectionType.MULTIPLE))
    assert gp.sections == DEFAULT_SECTIONS + [Section("Test", "param", SectionType.MULTIPLE)]

# Generated at 2022-06-21 11:45:02.138453
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """
    This is a test method.

    Params:
        test_method: the test method.
    """
    g = GoogleParser()
    g.add_section(Section("Params", "param", SectionType.MULTIPLE))
    result = g.parse(text)
    assert len(result.meta) == 1
    assert result.meta[0].args == ['param', 'test_method: the test method.']
    assert result.meta[0].arg_name == 'test_method'
    assert result.meta[0].type_name == 'the test method.'
    assert result.meta[0].description is None
    assert result.meta[0].is_optional is None
    assert result.meta[0].default is None
    

# Generated at 2022-06-21 11:45:07.944603
# Unit test for function parse
def test_parse():
    print(parse("""
        Return the sum of two numbers.

        Args:
            a (int): the first number.
            b (int): the second number.

        Returns:
            int: the total.

        Example:
            >>> add(2, 3)
            5
        """))


if __name__ == "__main__":
    test_parse()

# Generated at 2022-06-21 11:45:18.918838
# Unit test for function parse
def test_parse():
    # Test docstring with all contents
    docstring = """The quick brown fox jumps over the lazy dog.

    This is the long description. The quick brown fox jumps over the lazy dog.

    Args:
        arg1: The first parameter.
        arg2: The second parameter. Defaults to "foo".

    Returns:
        True if the fox jumped, False otherwise.

    Example:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

        >>> print([i for i in example_generator(4)])
        [0, 1, 2, 3]
    """

    # Test docstring without long description

# Generated at 2022-06-21 11:45:25.063332
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # test initialization
    gp1 = GoogleParser()
    if not gp1:
        raise RuntimeError("GoogleParser is incorrectly initialized")
    # test add_section
    gp1.add_section(Section("Returns", "returns", 1))
    section_list = gp1.sections
    if "Returns" not in section_list:
        raise RuntimeError("The section is not successfully added")
    # test _setup
    gp1._setup()
    # test parse when text is "test_text"
    test_text = "test_text"
    gp1.parse(test_text)
    if gp1.parse(test_text).short_description != "test_text":
        raise RuntimeError("The text is incorrectly parsed")
    # test parse otherwise

# Generated at 2022-06-21 11:45:34.452927
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Keyword", "keyword", SectionType.SINGULAR_OR_MULTIPLE))
    parser.add_section(Section("Key", "key", SectionType.MULTIPLE))
    docstring = parser.parse(
        textwrap.dedent(
            """
            This is a short description

            This is a long description

            Runs test suite

            Keyword:
                Keyword:
                    This is a singular section

                Key:
                    Key:
                        This is a multi-line specification
                        which continues on the next line.

                Key:
                    This is another multi-line specification
                    which continues on the next line.
            """
        )
    )
    assert docstring.short_description == "This is a short description"
    assert docstring.long_description

# Generated at 2022-06-21 11:45:35.872810
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser() is not None

# Generated at 2022-06-21 11:45:37.064706
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().parse("") == Docstring()



# Generated at 2022-06-21 11:45:39.438840
# Unit test for function parse
def test_parse():
    def parse(text: str) -> Docstring:
        """Parse the Google-style docstring into its components.

        :returns: parsed docstring
        """
        return GoogleParser().parse(text)



# Generated at 2022-06-21 11:45:57.393697
# Unit test for function parse
def test_parse():
    text = """Summary line.

        Extended description of function.

        Args:
            arg1: Description of arg1
            arg2: Description of arg2
            *args: Description of *args
            **kwargs: Description of *kwargs
            arg3 (int): Description of arg3
            arg4 (bool, optional): Description of arg4

        Returns:
            Description of return value

        Raises:
            Exception1: Description of exception1
            MyException2: Description of exception2
    """
    ret = parse(text)
    desc = "Summary line.\n\nExtended description of function."
    assert ret.short_description == "Summary line."
    assert ret.blank_after_short_description == True
    assert ret.long_description == desc
    assert ret.blank_after_long_description == False
    assert len

# Generated at 2022-06-21 11:46:03.032556
# Unit test for constructor of class Section
def test_Section():
    title = "Attribute"
    key = "attribute"
    section_type = SectionType.MULTIPLE
    t = Section(title, key, section_type)
    assert t.key == "attribute"
    assert t.type == SectionType.MULTIPLE
    assert t.title == "Attribute"


# Generated at 2022-06-21 11:46:15.969330
# Unit test for function parse
def test_parse():
    doc = parse("""\
    Test.

    Args:
        a: a is any.
        b: b is anything.

    Returns:
       y: y is a bool.
       m: m is an int.

    Raises:
        Exception: Because.
    """)


# Generated at 2022-06-21 11:46:19.552581
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    section = Section("Section Title", "Section Key", SectionType.SINGULAR)

    # Test adding new section
    parser.add_section(section)
    assert parser.sections["Section Title"] == section


# Generated at 2022-06-21 11:46:30.172107
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  text= "Parse Google-style docstrings into docstring components."
  # Create object of class GoogleParser
  obj= GoogleParser()
  # Get parsed docstring by calling method parse of class GoogleParser
  parsed_docstring = obj.parse(text)
  # Assert that the Short_description of parsed docstring is equal to text
  assert parsed_docstring.short_description==text
  # Assert that there is no Long_description
  assert parsed_docstring.long_description==None
  # Assert that there is no Blank_after_short_description
  assert parsed_docstring.blank_after_short_description==None
  # Assert that there is no Blank_after_long_description
  assert parsed_docstring.blank_after_long_description==None
  # Assert that parsed_docstring has no Meta
  assert parsed

# Generated at 2022-06-21 11:46:32.748081
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section.title == "Arguments"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:46:42.677865
# Unit test for function parse
def test_parse():
    import pytest

    def test_func1(arg1: str, arg2: str = "foobar") -> bool:
        """Short desc.

        Long desc.

        Args:
            arg1: first arg.
            arg2: second arg. Defaults to "foobar".

        Returns:
            A boolean.
            True if I'm right, False if I'm not.
        """
        return True

    res = parse(inspect.getdoc(test_func1))
    assert len(res) == 2
    assert len(res.meta) == 3
    short_desc, longer_desc = res.meta[0:2]
    returns = res.meta[2]
    assert short_desc.args == ("short desc",)
    assert short_desc.description is None
    assert len(longer_desc) == 1

# Generated at 2022-06-21 11:46:48.642407
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    
    # Check one section
    doc = parse("""\
        short description
         
        long description
        
        Parameters:
            param1: First parameter
                with further explanation:
                - bullet point 1
                - bullet point 2
        """)
    print(doc)
    
    

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-21 11:46:49.880888
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()


# Generated at 2022-06-21 11:47:02.887279
# Unit test for function parse
def test_parse():
    """Basic test for function parse"""
    # Given
    text = """\
    Parse the Google-style docstring into its components.

    :param input: docstring text
    :returns: parsed docstring

    - aaa
      bbb
    """
    # When
    result = parse(text)
    # Then
    assert result.short_description == "Parse the Google-style docstring into its components."
    assert result.long_description == "- aaa\n  bbb"
    assert result.blank_after_short_description
    assert result.meta[0].args == ("param", "input")
    assert result.meta[1].args == ("returns",)
    assert len(result.meta) == 2

    # When
    result = parse("")
    # Then
    assert result.short_description is None

# Generated at 2022-06-21 11:47:08.857246
# Unit test for constructor of class Section
def test_Section():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section == Docstring()


# Generated at 2022-06-21 11:47:10.738821
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    test_obj = GoogleParser(sections=[])
    assert test_obj != None


# Generated at 2022-06-21 11:47:14.698327
# Unit test for constructor of class Section
def test_Section():
    title = 'Arguments'
    key = 'param'
    type = SectionType.MULTIPLE
    section = Section(title, key, type)

    assert title == section.title
    assert key == section.key
    assert type == section.type


# Generated at 2022-06-21 11:47:27.756211
# Unit test for constructor of class Section

# Generated at 2022-06-21 11:47:32.143140
# Unit test for constructor of class Section
def test_Section():
    # Section(title, key, type)
    s = Section("Examples", "examples", SectionType.SINGULAR)
    assert s.title == "Examples"
    assert s.key == "examples"
    assert s.type == SectionType.SINGULAR


# Generated at 2022-06-21 11:47:42.902484
# Unit test for function parse
def test_parse():
    func = parse
    text = inspect.getdoc(func)
    assert text == func.__doc__
    func_name = func.__name__
    func_obj = func

    gdoc = parse(text)
    assert gdoc.short_description == "Parse the Google-style docstring into " \
                                     "its components."
    assert gdoc.long_description == ":returns: parsed docstring"
    assert gdoc.blank_after_short_description is True
    assert gdoc.blank_after_long_description is True
    assert len(gdoc.meta) == 1
    meta = gdoc.meta[0]
    assert meta.args == [RETURNS_KEYWORDS[0], "parsed docstring"]
    assert meta.description == "parsed docstring"
    assert meta.type_

# Generated at 2022-06-21 11:47:52.055512
# Unit test for function parse
def test_parse():
    s = """Short docstring.

    Longer part.

    Returns:
      Returns something
    """
    assert parse(s) == Docstring(
        short_description="Short docstring.",
        blank_after_short_description=True,
        long_description="Longer part.",
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=["returns"], description="Returns something"
            )
        ],
    )
    s = '''Short docstring.

Longer part.

Returns:
  Returns: something
'''

# Generated at 2022-06-21 11:47:59.890498
# Unit test for constructor of class Section
def test_Section():
    # Corner case: an element with empty title
    section_empty = Section("", "param", SectionType.MULTIPLE)
    assert section_empty.title == ""
    assert section_empty.key == "param"
    assert section_empty.type == SectionType.MULTIPLE
    # Normal case: a section with a non-empty title
    section_nonempty = Section("Parameters", "param", SectionType.MULTIPLE)
    assert section_nonempty.title == "Parameters"
    assert section_nonempty.key == "param"
    assert section_nonempty.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:48:12.030226
# Unit test for function parse
def test_parse():
    def foo(a: int, b: str = "bar") -> str:
        """\
        Foo function.

        Examples
        --------

        >>> print(foo(1, 'bar') + 'x')
        bazx

        >>> print(foo(1, 'baz') + 'x')
        bax

        Parameters
        ----------
        a: int
            Baz parameter.
        b: str, optional
            Bar parameter. Defaults to 'bar'.

        Returns
        -------
        str
            Foo return value.
        """

        if b == "bar":
            return "baz"
        return "bax"

    ds = parse(inspect.getdoc(foo))
    assert ds.short_description == "Foo function."

# Generated at 2022-06-21 11:48:16.050167
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section('section title', 'section_key', 0))
    assert parser.sections['section title'] is not None



# Generated at 2022-06-21 11:48:30.905192
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        This is my docstring module.

        Args:
            arg1 (str): Description of arg1
                long line
                long line
            arg2 (int): Description of arg2
                long line
                long line
            arg3 (bool): Description of arg3
                long line
                long line

        Returns:
            str: result of doing something
        """

    p = GoogleParser()

    d = p.parse(text)
    print("meta", d.meta)
    for m in d.meta:
        print("args", m.args)
        print("description", m.description)
        if isinstance(m, DocstringParam):
            print("arg_name", m.arg_name)
            print("type_name", m.type_name)

# Generated at 2022-06-21 11:48:39.362120
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Arrange, Act, Assert.

    :param a: first parameter
    :param b: second parameter
    :returns: the result
    :raises keyError: raises an exception
    """

# Generated at 2022-06-21 11:48:40.716441
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert parser


# Generated at 2022-06-21 11:48:51.899260
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    One line summary.

    More detailed description.

    Args:
        arg1(str): description of arg1
        arg2(str): description of arg2

    Returns:
        description of return value
    '''
    res = GoogleParser().parse(docstring)
    assert res.short_description == 'One line summary.'
    assert res.blank_after_short_description
    assert res.long_description == 'More detailed description.'
    assert res.blank_after_long_description
    assert(len(res.meta) == 4)


if __name__ == "__main__":
    import sys
    import logging

    logging.basicConfig(level=logging.DEBUG)
    # Parse a file
    ds = GoogleParser().parse(open(sys.argv[1]).read())


# Generated at 2022-06-21 11:48:54.889943
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE

# Generated at 2022-06-21 11:48:57.186241
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    title_colon = True
    parser = GoogleParser(title_colon = title_colon)

# Generated at 2022-06-21 11:49:00.624334
# Unit test for constructor of class Section
def test_Section():
    a = Section("Arguments", "param", SectionType.MULTIPLE)
    assert a.title == "Arguments"
    assert a.key == "param"
    assert a.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:49:11.869217
# Unit test for function parse

# Generated at 2022-06-21 11:49:12.946991
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    return parser

# Generated at 2022-06-21 11:49:22.227759
# Unit test for function parse
def test_parse():
    """
    Test that the parse function returns the right Docstring obj
    """
    expected = Docstring(
        short_description = 'the short description',
        blank_after_short_description = False,
        blank_after_long_description = False,
        long_description = 'the long description',
        meta = [
            DocstringMeta(
                args = ['Args'],
                description = 'the description'
            )
        ]
    )
    test_str = '''
    the short description

    the long description

    Args:
      the description
    '''

    actual = parse(test_str)

    assert actual == expected


# Generated at 2022-06-21 11:49:42.836046
# Unit test for constructor of class Section
def test_Section():
    my_section = Section(title = 'Test', key = 'test', type = 1)
    assert isinstance(my_section, namedtuple)
    assert my_section.title == 'Test'
    assert my_section.key == 'test'
    assert my_section.type == 1
    

# Generated at 2022-06-21 11:49:54.678581
# Unit test for function parse
def test_parse():
    do_parse_test(
        """
        Short description.

        Long description.

        Args:
            param1: The first parameter.
            param2: The second parameter.

        Returns:
            Something.
        """,
        """
        Short description.

        Long description.

        Args:
            param1: The first parameter.
            param2: The second parameter.

        Returns:
            Something.
        """,
        """
        Short description.
        """,
        """
        Short description.

        Long description.
        """,
        """
        Args:
            param1: The first parameter.
            param2: The second parameter.
        """,
        """
        Returns:
            Something.
        """,
    )

# Generated at 2022-06-21 11:50:07.141730
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    # assert google_parser.parse('') == {}
    # assert google_parser.parse('hello\nworld.') == {
    #     'desc': 'hello\nworld.', 'title': None}
    # assert google_parser.parse('Example:') == {}
    # assert google_parser.parse('Example:\n  hello\nworld.') == {
    #     'desc': 'hello\nworld.', 'title': 'Example'}
    # assert google_parser.parse('Example:\n\n  hello\nworld.') == {
    #     'desc': 'hello\nworld.', 'title': 'Example'}
    # assert google_parser.parse('Example:\n\n  hello\nworld.\n') == {
    #     'desc': 'hello\n

# Generated at 2022-06-21 11:50:15.105563
# Unit test for function parse
def test_parse():
    text1 = """
        Parses the Google-style docstring into its components.
        """
    assert parse(text1) == Docstring(
        short_description="Parses the Google-style docstring into its components."
    )

    text2 = """
        Parses the Google-style docstring into its components.

        This method will return a Docstring object, which contains all
        the information in a docstring.
        """
    assert parse(text2) == Docstring(
        short_description="Parses the Google-style docstring into its components.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description="This method will return a Docstring object, which contains all the information in a docstring.",
    )


# Generated at 2022-06-21 11:50:27.670176
# Unit test for function parse

# Generated at 2022-06-21 11:50:32.204674
# Unit test for constructor of class Section
def test_Section():
    first = Section('Arguments', 'param', SectionType.MULTIPLE)
    second = Section('Args', 'param', SectionType.MULTIPLE)
    third = Section('Parameters', 'param', SectionType.MULTIPLE)
    fourth = Section('Params', 'param', SectionType.MULTIPLE)
    fifth = Section('Raises', 'raises', SectionType.MULTIPLE)
    sixth = Section('Exceptions', 'raises', SectionType.MULTIPLE)
    seventh = Section('Except', 'raises', SectionType.MULTIPLE)
    eighth = Section('Attributes', 'attribute', SectionType.MULTIPLE)
    ninth = Section('Example', 'examples', SectionType.SINGULAR)
    tenth = Section('Examples', 'examples', SectionType.SINGULAR)
    ele

# Generated at 2022-06-21 11:50:42.891838
# Unit test for function parse
def test_parse():
    text = """\
    This is a test function.

    This is a test function that takes a string and returns a string.

    Arguments:
        param1 (str): The first parameter.
        param2 (int): The second parameter.

    Returns:
        str: The return value.

    """
    doc = parse(text)
    print(doc)
    print('doc.short_description: ', doc.short_description)
    print('doc.long_description: ', doc.long_description)
    print('doc.blank_after_short_description: ', doc.blank_after_short_description)
    print('doc.blank_after_long_description: ', doc.blank_after_long_description)
    print('doc.meta: ')
    for meta in doc.meta:
        print(meta.type_name)


# Generated at 2022-06-21 11:50:55.862926
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-21 11:51:03.241851
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # Exception
    try:
        GoogleParser(title_colon=False).add_section(Section("Another", "key", SectionType.SINGULAR))
    except:
        assert False
    try:
        GoogleParser(title_colon=True).add_section(Section("Another", "key", SectionType.SINGULAR))
    except:
        assert False
    # Use default
    parser1 = GoogleParser(title_colon=False)
    # Add a section
    parser2 = GoogleParser(title_colon=False)
    parser2.add_section(Section("Another", "key", SectionType.SINGULAR))
    # Replace a section
    parser3 = GoogleParser(title_colon=False)
    parser3.add_section(Section("Example", "examples", SectionType.SINGULAR))
    #

# Generated at 2022-06-21 11:51:04.757791
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    p = GoogleParser()
    assert p is not None


# Generated at 2022-06-21 11:52:02.861104
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("hello") == Docstring("hello", "", "", "", True, False)
    assert parse("hello\nworld") == Docstring("hello", "world", "", "", True, False)
    assert parse("hello\nworld\n") == Docstring("hello", "world", "", "", True, True)


# Generated at 2022-06-21 11:52:05.989620
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    test_section = Section("Test", "test", SectionType.MULTIPLE)
    test_parser = GoogleParser()
    test_parser.add_section(test_section)
    assert test_section.title in test_parser.sections

# Generated at 2022-06-21 11:52:12.329499
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert parse("A short description") == Docstring(
        "A short description", None, False, False, []
    )

    assert parse("A short description\n\nA long description") == Docstring(
        "A short description",
        "A long description",
        True,
        False,
        [],
    )

    assert parse("A short description\n\nA long description.\n") == Docstring(
        "A short description",
        "A long description.",
        True,
        True,
        [],
    )


# Generated at 2022-06-21 11:52:21.684227
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    title = "test"
    title_non_existent = "test_non_existent"
    section = Section("test", "foo", 0)
    section_original = DEFAULT_SECTIONS[0]

    parser = GoogleParser()
    assert section_original is parser.sections[title]
    assert title_non_existent not in parser.sections

    parser.add_section(section)
    assert section is parser.sections[title]
    assert title_non_existent not in parser.sections



# Generated at 2022-06-21 11:52:32.808245
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    text = """This is a sample function.

    :param foo: first argument is foo.
    :type foo: int

    :param bar: second argument is bar.
    :type bar: str

    :returns: sum of arguments.
    :rtype: int

    :Example:

    >>> sum(1, 2)
    3
    """
    parser = GoogleParser()
    parser.add_section(Section("Example", "example", SectionType.SINGULAR))
    doc = parser.parse(text)
    assert len(doc.meta) == 3
    assert doc.meta[0].short_name == "example"
    assert doc.meta[0].args == ["example"]
    assert doc.meta[0].description == "This is a sample function."

# Generated at 2022-06-21 11:52:44.076294
# Unit test for constructor of class Section
def test_Section():
    test1 = Section(title = "test", key = 1, type = "test")
    assert(test1.title == "test")
    assert(test1.key == 1)
    assert(test1.type == "test")
    test2 = Section(title = "test", key = 1)
    assert(test2.title == "test")
    assert(test2.key == 1)
    assert(test2.type == None)
    test3 = Section(title = "test")
    assert(test3.title == "test")
    assert(test3.key == None)
    assert(test3.type == None)
    test4 = Section()
    assert(test4.title == None)
    assert(test4.key == None)
    assert(test4.type == None)



# Generated at 2022-06-21 11:52:52.911115
# Unit test for function parse

# Generated at 2022-06-21 11:52:59.553885
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Case 1: Empty string
    text = ''
    p = GoogleParser().parse(text)
    expected_p = ''
    assert repr(p) == repr(expected_p)
    # Case 2: Good string

# Generated at 2022-06-21 11:53:10.696550
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser().title_colon
    assert not GoogleParser(title_colon=False).title_colon
    assert GoogleParser([Section("Example", "examples", SectionType.SINGULAR)])
    assert GoogleParser([Section("Example", "examples", "SINGULAR")])
    assert GoogleParser([Section("Example", "examples", 0)])
    assert GoogleParser([Section("Example", "examples", -1)])
    assert GoogleParser([Section("Example", "examples", 3)])
    assert GoogleParser([Section("Example", "examples", SectionType.SINGULAR)])
    assert GoogleParser([Section("Example", "examples", SectionType.MULTIPLE)])
    assert GoogleParser([Section("Example", "examples", SectionType.SINGULAR_OR_MULTIPLE)])
    assert Google

# Generated at 2022-06-21 11:53:23.694278
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case data
    testcase1 = r"""
    This is a test docstring.

    :param a: parameter
    :returns: return
    """
    
    testcase2 = r"""
    This is a test docstring.

    :param a: parameter
    :returns: return
    :raises Exception: raises
    :yields: yields
    :yields: yields2
    """

# Generated at 2022-06-21 11:54:29.471771
# Unit test for function parse
def test_parse():
    doc = """This is a unit test of the parse function.
    It is used to check whether the generator works as expected.

    Args:
        arg1: This is the first argument.
        arg2 (int): This is the second argument.

    Examples:
        Examples can be given using either the ``Example`` or ``Examples``
        sections. Sections support any reStructuredText formatting, including
        literal blocks::

            #>>> print('hello')
            hello

        Sections support any reStructuredText formatting, including literal blocks::

            #>>> print('hello')
            hello

    Raises:
        ValueError: If `invalid_value` is supplied.

    Returns:
        int: The return value.
    """
    print(parse(doc))


if __name__ == "__main__":
    test_parse()