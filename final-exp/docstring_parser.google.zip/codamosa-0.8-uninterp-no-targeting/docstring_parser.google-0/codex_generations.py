

# Generated at 2022-06-21 11:45:06.366743
# Unit test for constructor of class Section
def test_Section():
    section = Section("Test", "some_key", 0)
    assert section.title == "Test"
    assert section.key == "some_key"
    assert section.type == 0


# Generated at 2022-06-21 11:45:17.635253
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    old_sections = parser.sections.copy()
    old_title = 'Some title'
    new_title = 'Some new title'
    parser.add_section(Section(old_title, 'Some key', SectionType.MULTIPLE))

    assert parser.sections.__len__() == old_sections.__len__() + 1
    assert parser.sections.__contains__(old_title) is True
    assert parser.sections.__contains__(new_title) is True

    parser.add_section(Section(old_title, 'Some key', SectionType.MULTIPLE))

    assert parser.sections.__len__() == old_sections.__len__() + 1
    assert parser.sections.__contains__(old_title) is True
    assert parser.sections.__contains

# Generated at 2022-06-21 11:45:19.245956
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    s = GoogleParser(sections = DEFAULT_SECTIONS)
    assert(s)


# Generated at 2022-06-21 11:45:21.040688
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    parser = GoogleParser()
    assert len(parser.sections) == 14
    assert parser.title_colon == True


# Generated at 2022-06-21 11:45:31.847052
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ds = """First line.
    Second line.
    Third line.

    Arguments:
        arg1: First argument.
        arg2: Second argument.

    Examples:
        >>> a = 1
        >>> b = 2

    Returns:
        int: The sum of the two arguments.

    Raises:
        TypeError: If the arguments are not of type int.
    """
    parsed = GoogleParser().parse(ds)
    assert parsed.short_description == "First line."
    assert parsed.long_description == "Second line.\nThird line."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 5
    assert len(parsed.meta) == len(ds.split("\n\n"))

# Generated at 2022-06-21 11:45:34.661861
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    g = GoogleParser()
    g.add_section(Section("Arg", "args", SectionType.MULTIPLE))
    assert "Arg" in g.sections


# Generated at 2022-06-21 11:45:40.104605
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Title: test parse method of class GoogleParser
    Args:
        arg_1(str): arg_1 is str type
        arg_2(int): arg_2 is int type
        arg_3(int): arg_3 is int type
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == 'test parse method of class GoogleParser'


# Generated at 2022-06-21 11:45:41.852763
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc = parser.parse('google')
    assert (doc.short_description == 'google')

# Generated at 2022-06-21 11:45:53.684937
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = (
        "This function does something.\n\n"
        "    :param x: The first parameter.\n"
        "    :param y: The second parameter.\n\n"
        "    :returns: Something.\n"
        "    :rtype: int\n"
    )
    result = parser.parse(docstring)
    expected = ("This function does something.",
                {
                    ("param", "x: The first parameter."),
                    ("param", "y: The second parameter."),
                    ("returns", "Something."),
                    ("rtype", "int")
                }
               )
    assert result == expected


# Generated at 2022-06-21 11:45:57.904342
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections = GoogleParser().sections
    assert sections['Arguments'].key == 'param'
    sections.add_section(Section("Params", "param", SectionType.MULTIPLE))
    assert sections['Arguments'].key == 'param'
    assert sections['Params'].key == 'param'

# Generated at 2022-06-21 11:46:07.393205
# Unit test for constructor of class Section
def test_Section():
    section = Section("Test", "test", SectionType.MULTIPLE)
    assert section.title == "Test"
    assert section.key == "test"
    assert section.type == 1
    assert not section.__doc__
    section.__doc__ = "Test"
    assert section.__doc__


# Generated at 2022-06-21 11:46:19.652161
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    for title, arguments in [
        ("Params", ["param", "argName: argType", "Argument description."]),
        ("Args", ["param", "argName: argType", "Argument description."]),
        ("Parameters", ["param", "argName: argType", "Argument description."]),
        (
            "Example",
            ["examples", "Example description."],
        ),
        ("Examples", ["examples", "Example description."]),
        ("Returns", ["returns", "returnType", "Return description."]),
        ("Raises", ["raises", "ExceptionName", "Exception description."]),
    ]:
        print("Test for title: ", title)
        print("Arguments: ", arguments)
        parser = GoogleParser()

# Generated at 2022-06-21 11:46:22.000607
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    googleparser = GoogleParser()
    return googleparser.sections


# Generated at 2022-06-21 11:46:30.448591
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    # Test good section
    parser.add_section(Section("TestTitle", "testkey", SectionType.SINGULAR))
    # Test the section's name is the same as before added
    assert "TestTitle" in parser.sections.keys()
    # Test bad section (wrong key)
    try:
        parser.add_section(Section("TestTitleWrongKey", "testkeyWrongKey", SectionType.SINGULAR))
    except AssertionError:
        assert True
    # Test bad section (wrong type)
    try:
        parser.add_section(Section("TestTitleWrongType", "testkey", "String"))
    except AssertionError:
        assert True


# Generated at 2022-06-21 11:46:33.554357
# Unit test for constructor of class Section
def test_Section():
    sect = Section('Attributes', 'attribute', SectionType.MULTIPLE)
    assert isinstance(sect, Section), "Constructor of class Section failed"


# Generated at 2022-06-21 11:46:42.375732
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import json
    from .common import RecursiveJSONEncoder

    with open('tests/test_data/google_docstring_test_input', 'r') as f:
        google_docstring = f.read()

    with open('tests/test_data/google_docstring_test_output', 'r') as f:
        expected_output = json.loads(f.read())

    output = parse(google_docstring)
    assert(json.dumps(output, cls=RecursiveJSONEncoder, sort_keys=True, indent=4) == json.dumps(expected_output, cls=RecursiveJSONEncoder, sort_keys=True, indent=4))

# test the function parse

# Generated at 2022-06-21 11:46:49.683119
# Unit test for constructor of class Section
def test_Section():
    S = Section("Arguments", "param", SectionType.SINGULAR_OR_MULTIPLE)
    assert S[0] == "Arguments"
    assert S[1] == "param"
    assert S[2] == SectionType.SINGULAR_OR_MULTIPLE
    assert str(S) == "Section(title='Arguments', key='param', type=<SectionType.SINGULAR_OR_MULTIPLE: 2>)"


# Generated at 2022-06-21 11:47:02.718589
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    # --- Test with non-default constructor parameters ---
    # Given a list of sections with a non-default type
    sections = [Section("Arguments", "param", SectionType.SINGULAR)]
    # When GoogleParser is constructed
    parser = GoogleParser(sections=sections)
    # Then the list of sections should be equal to the given list of sections
    assert parser.sections == {title: section for title, section in sections}
    # And title_colon should be True
    assert parser.title_colon

    # --- Test with default constructor parameters ---
    # When GoogleParser is constructed
    parser = GoogleParser()
    # Then the list of sections should be the default list of sections
    assert parser.sections == {
        title: section for title, section in DEFAULT_SECTIONS
    }
    # And title_colon should be True
   

# Generated at 2022-06-21 11:47:07.968082
# Unit test for constructor of class Section
def test_Section():
    with open('test_constructor.txt', 'r') as f:
        text = f.read()
        for item in re.findall(r'(\w+):\s*(.*)', text):
            print(item)
            assert Section(item[0], item[1], SectionType.MULTIPLE)
            print('comparsion success')


# Generated at 2022-06-21 11:47:14.959198
# Unit test for function parse
def test_parse():
    s = "DESCRIPTION\n    DESCRIPTION PART 2\n    DESCRIPTION PART 3"
    d = parse(s)
    assert d.short_description == "DESCRIPTION"
    assert d.long_description == "DESCRIPTION PART 2\nDESCRIPTION PART 3"
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == True

    s = "DESCRIPTION\n\n    DESCRIPTION PART 2\n    DESCRIPTION PART 3"
    d = parse(s)
    assert d.short_description == "DESCRIPTION"
    assert d.long_description == "DESCRIPTION PART 2\nDESCRIPTION PART 3"
    assert d.blank_after_short_description == True
    assert d.blank_after_long_description == True


# Generated at 2022-06-21 11:47:35.170524
# Unit test for constructor of class Section
def test_Section():
    s = Section("Arguments", "param", SectionType.MULTIPLE)
    assert s.title == "Arguments"
    assert s.key == "param"
    assert s.type == SectionType.MULTIPLE

    s = Section("Example", "examples", SectionType.SINGULAR)
    assert s.title == "Example"
    assert s.key == "examples"
    assert s.type == SectionType.SINGULAR

    s = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    assert s.title == "Returns"
    assert s.key == "returns"
    assert s.type == SectionType.SINGULAR_OR_MULTIPLE



# Generated at 2022-06-21 11:47:36.661323
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
  p = GoogleParser()
  return p


# Generated at 2022-06-21 11:47:38.609986
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    gp = GoogleParser()
    gp = GoogleParser(title_colon=False)


# Generated at 2022-06-21 11:47:49.971622
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()

# Generated at 2022-06-21 11:47:53.352597
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print("Test creating an instance of GoogleParser class")
    gparser = GoogleParser()
    print(gparser)

if __name__ == "__main__":
    test_GoogleParser()

# Generated at 2022-06-21 11:47:56.299734
# Unit test for constructor of class Section
def test_Section():
    assert Section("Arguments", "param", SectionType.MULTIPLE) == ("Arguments", "param", SectionType.MULTIPLE)


# Generated at 2022-06-21 11:48:00.359554
# Unit test for constructor of class Section
def test_Section():
    section = Section("Parameters", "param", SectionType.MULTIPLE)
    assert section.title == "Parameters"
    assert section.key == "param"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:48:12.374324
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Args:
  path: Path to the file to load.
  bucket: Name of bucket where the file is located.
  file_name: Name of file.

Returns:
  A list of the key and value pair in the json file.

Raises:
  ValueError: If the path is not valid.
"""

# Generated at 2022-06-21 11:48:23.984866
# Unit test for function parse
def test_parse():
    text = '''
    Short description
    Long description

    Keyword arguments:
    arg1 -- description
    arg2 (str) -- description with type
    '''
    docstring = parse(text)
    print(docstring)
    return docstring

docstring = test_parse()

# Short description
print(docstring.short_description)
# Long description
print(docstring.long_description)
# Blank after short description?
print(docstring.blank_after_short_description)
# Blank after long description?
print(docstring.blank_after_long_description)
# Meta
print(docstring.meta)

# Short description
print(docstring.meta[0].short_description)
# Arguments
print(docstring.meta[0].args)
# Arg name

# Generated at 2022-06-21 11:48:29.465251
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    assert len(gp.sections) == len(DEFAULT_SECTIONS)
    assert gp.sections == {s.title: s for s in DEFAULT_SECTIONS}
    other_section = Section("TheNewSection", "newsection", SectionType.SINGULAR)
    gp.add_section(other_section)
    assert len(gp.sections) == len(DEFAULT_SECTIONS) + 1
    assert gp.sections["TheNewSection"] == other_section


# Generated at 2022-06-21 11:48:55.195289
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doctxt = """
    This is a test docstring


    Params:
        arg1: The first argument to the function
        arg2: The second argument to the function
        arg3 (str): The third argument to the function
               with a long description on a line after the first
               one.

    Returns:
        int: whatever.

    Raises:
        InvalidArgument: Should raise an exception if not valid.
    """
    res = parse(doctxt)
    assert res.short_description == "This is a test docstring"
    assert res.long_description == ""
    assert len(res.meta) == 4
    assert res.meta[0].args[0] == "param"
    assert res.meta[0].args[1] == "arg1"

# Generated at 2022-06-21 11:48:59.135683
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    section = Section("Test", "Test", SectionType.MULTIPLE)
    googleParser = GoogleParser()
    googleParser.add_section(section)
    assert len(googleParser.sections) == len(DEFAULT_SECTIONS) + 1

# Generated at 2022-06-21 11:49:04.941113
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    parser.add_section(Section("Arg", "arg", SectionType.MULTIPLE))
    assert parser.sections["Arg"] == Section("Arg", "arg", SectionType.MULTIPLE)
    assert "arg" in parser.sections
    # Assert that there is no side-effect on DEFAULT_SECTIONS
    parser.add_section(Section("Args", "param", SectionType.MULTIPLE))
    assert "args" in parser.sections
    assert "Args" not in parser.sections


# Generated at 2022-06-21 11:49:14.562280
# Unit test for constructor of class Section
def test_Section():
    assert Section("title", "key", SectionType.SINGULAR) == namedtuple("SectionBase", "title key type")("title", "key", SectionType.SINGULAR)
    assert Section("title", "key", SectionType.MULTIPLE) == namedtuple("SectionBase", "title key type")("title", "key", SectionType.MULTIPLE)
    assert Section("title", "key", SectionType.SINGULAR_OR_MULTIPLE) == namedtuple("SectionBase", "title key type")("title", "key", SectionType.SINGULAR_OR_MULTIPLE)

# Generated at 2022-06-21 11:49:25.726568
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # 1. Arrange
    text = '''bla bla
    Args:
        first (int): bla bla.
        second (bool): test.
    '''
    # 2. Act
    docstring = GoogleParser().parse(text)
    # 3. Assert
    assert docstring.short_description == 'bla bla'
    assert docstring.meta[0].args[0] == DocstringParam.key
    assert docstring.meta[0].args[1] == 'first (int)'
    assert docstring.meta[0].arg_name == 'first'
    assert docstring.meta[0].type_name == 'int'
    assert docstring.meta[0].description == 'bla bla.'
    assert docstring.meta[0].is_optional == False
    
    assert docstring

# Generated at 2022-06-21 11:49:34.065786
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    Parse the Google-style docstring into its components.

    :returns: parsed docstring

    """
    assert parse(text).short_description == "Parse the Google-style docstring into its components."
    assert parse(text).blank_after_short_description == True
    assert parse(text).long_description == ""
    assert parse(text).blank_after_long_description == True
    assert parse(text).meta == [DocstringMeta(args=['returns', ''], description="parsed docstring")]

# Generated at 2022-06-21 11:49:38.209322
# Unit test for constructor of class Section
def test_Section():
    section = Section("test title", "test key", SectionType.SINGULAR)
    assert section.title == "test title"
    assert section.key == "test key"
    assert section.type == SectionType.SINGULAR



# Generated at 2022-06-21 11:49:51.287574
# Unit test for function parse
def test_parse():
    parser = GoogleParser()
    f = """
    Short description.

    Long description.

    Args:
      a: description
      b: description

    Returns:
      description

    Raises:
      ValueError: description

    Attributes:
      e: description
      f: description

    Example
      >>> a
      1

    Examples
      >>> a
      1

    """

    docstring = parser.parse(f)

    assert docstring.meta[0].key == "args"
    assert docstring.meta[0].args[0] == "args"
    assert docstring.meta[0].args[1] == "a: description\nb: description"
    assert docstring.meta[0].description == """Args:
      a: description
      b: description"""


# Generated at 2022-06-21 11:49:55.669359
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser()
    # Add a section
    section = Section("Keywords", "keywords", SectionType.MULTIPLE)
    parser.add_section(section)
    # Check if added section is really in self.sections
    assert parser.sections["Keywords"] == section

# Generated at 2022-06-21 11:50:07.961079
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    text1="""
GoogleParser(sections=None, title_colon=True)

Setup sections.

:param sections: Recognized sections or None to defaults.
:param title_colon: require colon after section title.
"""
    text2="""
parse(text)

Parse the Google-style docstring into its components.

:returns: parsed docstring
"""
    sections1 = [
        Section("Parameters", "param", SectionType.MULTIPLE),
        Section("Params", "param", SectionType.MULTIPLE),
    ]
    sections2 = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Params", "param", SectionType.MULTIPLE),
    ]

# Generated at 2022-06-21 11:50:22.194417
# Unit test for constructor of class Section
def test_Section():
    section = Section(title = "Returns", key = "returns", type = SectionType.SINGULAR_OR_MULTIPLE)
    assert section.title == "Returns"
    assert section.key == "returns"
    assert section.type == SectionType.SINGULAR_OR_MULTIPLE


# Generated at 2022-06-21 11:50:23.354437
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    GoogleParser()
    assert True


# Generated at 2022-06-21 11:50:26.557250
# Unit test for constructor of class Section
def test_Section():
    parsed = Section("Title", "key", SectionType.SINGULAR)
    expected = ("Title", "key", SectionType.SINGULAR)
    assert parsed == expected


# Generated at 2022-06-21 11:50:34.792291
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Define a "new" section title, key and type
    new_section = Section('Notes', 'notes', SectionType.SINGULAR)
    # Define a text with the above section
    text: str = "This is a text.\n\nNotes: \n    A note.\n"
    # Add the section
    p: GoogleParser = GoogleParser()
    p.add_section(new_section)
    # Parse the text (this will crash if the section is not recognized)
    p.parse(text)

# Generated at 2022-06-21 11:50:44.038696
# Unit test for function parse
def test_parse():
    result = parse("""
        This is a test.

        Args:
            param (int): This is a parameter.
            param2 (list): Some other parameter.
            param3 (str, optional): A parameter that is optional.
            param4 (str?, optional): Another parameter that is optional. Defaults to "default".

        Raises:
            ValueError: if something bad happens.

        Returns:
            int: The answer.
        """)

# Generated at 2022-06-21 11:50:56.894838
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def dummy():
        """
        Google-style docstring

        :param foo: A\nB\nC\nD
        :param bar: x\ny\nz\n
        :param baz: a\nb\nc\n
        :foo: E\nF\nG\n
        :bar: a\nb\nc\n
        :baz: a\nb\nc\n
        \n
        """
        pass

    result = parse(inspect.getdoc(dummy))

# Generated at 2022-06-21 11:51:03.744627
# Unit test for function parse
def test_parse():
    assert (GoogleParser().parse(
    """\
    Short description.

    Long description.

    Parameters:
        param1 (int): Parameter 1. Defaults to 0.
        param2 (int): Parameter 2.

    Returns:
        str: Return value.

    Raises:
        ValueError: An exception.

    Examples:
        Some examples.

        >>> example()
        123
    """
    ))

# Generated at 2022-06-21 11:51:11.908588
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    google_parser = GoogleParser()
    assert google_parser.sections == {s.title: s for s in DEFAULT_SECTIONS}
    assert google_parser.title_colon == True
    assert google_parser._setup() == None
    assert google_parser.titles_re.pattern == "^(Arguments|Args|Parameters|Params|Raises|Exceptions|Except|Attributes|Example|Examples|Returns|Yields):[ \t\r\f\v]*$"

# Generated at 2022-06-21 11:51:18.248081
# Unit test for constructor of class Section
def test_Section():
    print("\nUnit test for constructor of class Section")
    title = 'Arguments'
    key = 'param'
    type = SectionType.MULTIPLE
    Section1 = Section(title, key, type)
    # print(Section1)
    assert Section1.title == 'Arguments'
    assert Section1.key == 'param'
    assert Section1.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:51:25.321500
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    A simple, multiline docstring.

    Keyword arguments:
        arg1 -- The first argument [string]
        arg2 -- The second argument [float]

    Returns:
        value -- Some aggregated value [int]
    """

    parsed = GoogleParser().parse(text)
    assert (
        parsed.short_description == "A simple, multiline docstring."
    ), "short description doesn't match."
    assert (
        parsed.long_description == ""
    ), "long description doesn't match."
    assert (
        parsed.blank_after_short_description == False
    ), "blank_after_short_description doesn't match."
    assert (
        parsed.blank_after_long_description == False
    ), "blank_after_long_description doesn't match."


# Generated at 2022-06-21 11:51:45.677769
# Unit test for constructor of class Section
def test_Section():
    # empty default
    s = Section(title='', key='', type=SectionType.SINGULAR)
    assert s.title == ''
    assert s.key == ''
    assert s.type == SectionType.SINGULAR
    # exist title
    s = Section(title='Example', key='examples', type=SectionType.SINGULAR)
    assert s.title == 'Example'
    assert s.key == 'examples'
    assert s.type == SectionType.SINGULAR
    s = Section(title='Example', key='examples', type=SectionType.SINGULAR_OR_MULTIPLE)
    assert s.title == 'Example'
    assert s.key == 'examples'
    assert s.type == SectionType.SINGULAR_OR_MULTIPLE

# Generated at 2022-06-21 11:51:52.615741
# Unit test for function parse
def test_parse():
    from .merge import merge_docstrings
    from .numpy import parse as numpy_parse

    def test_function():
        """
        This is a test function.

        Args:
            a (str): this is an arg
            b (str): this is another arg
            c (str): this is yet another arg

        Returns:
            str: this is the return value
        """
        return "Hello, world!"

    merge_docstrings([GoogleParser(), numpy_parse], None, test_function)

# Generated at 2022-06-21 11:51:56.987212
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    print("Testing constructor of class GoogleParser")
    sections = [Section("Raises", "raises", SectionType.MULTIPLE)]
    gp = GoogleParser(sections=sections)
    assert gp["Raises"] == sections[0]


# Generated at 2022-06-21 11:51:58.797575
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = GoogleParser().parse("""
    """
    )

# Generated at 2022-06-21 11:52:08.608690
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    title_colon = True
    sections = Section("Arguments", "param", SectionType.MULTIPLE)
    sections1 = Section("Args", "param", SectionType.MULTIPLE)
    sections2 = Section("Parameters", "param", SectionType.MULTIPLE)
    sections3 = Section("Params", "param", SectionType.MULTIPLE)
    sections2 = Section("Raises", "raises", SectionType.MULTIPLE)
    sections3 = Section("Exceptions", "raises", SectionType.MULTIPLE)
    sections4 = Section("Except", "raises", SectionType.MULTIPLE)
    sections5 = Section("Attributes", "attribute", SectionType.MULTIPLE)
    sections6 = Section("Example", "examples", SectionType.SINGULAR)
    sections7 = Section

# Generated at 2022-06-21 11:52:18.594550
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # Setup parser
    parser = GoogleParser()

    # Add new section
    parser.add_section(
        Section("Returns:", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    )

    # Assert new section is added and old section is overwritten
    assert len(parser.sections) == 1
    assert parser.sections["Returns:"].title == "Returns:"
    assert parser.sections["Returns:"].key == "returns"
    assert parser.sections["Returns:"].type == SectionType.SINGULAR_OR_MULTIPLE


# Generated at 2022-06-21 11:52:21.321474
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    assert GoogleParser()
    assert GoogleParser(title_colon=True)
    assert not GoogleParser(title_colon=False)


# Generated at 2022-06-21 11:52:24.621558
# Unit test for constructor of class Section
def test_Section():
    section = Section("Raises", "raises", SectionType.MULTIPLE)
    assert section.title == "Raises"
    assert section.key == "raises"
    assert section.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:52:37.384962
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GoogleParser_ = GoogleParser()
    # Test with sections

# Generated at 2022-06-21 11:52:47.515748
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    string_test_1 = """Summary line.

    Extended description of method.

    Args:
        param1: The first parameter.
        param2: The first parameter.
    Returns:
        The return value. True for success, False otherwise.
    """
    string_test_2 = """Summary line.

    Extended description of method.

    Arguments:
        param1: The first parameter.
        param2: The first parameter.
    Returns:
        The return value. True for success, False otherwise.
    """
    string_test_3 = """Summary line.

    Extended description of method.

    Parameters:
        param1 (str): The first parameter.
        param2 (str): The first parameter.
    Returns:
        The return value. True for success, False otherwise.
    """

# Generated at 2022-06-21 11:53:09.205931
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    docstring = GoogleParser()
    current_sections_number = len(docstring.sections)
    new_section = Section("Any title","param",SectionType.SINGULAR_OR_MULTIPLE)
    docstring.add_section(new_section)
    new_sections_number = len(docstring.sections)
    assert current_sections_number + 1 == new_sections_number 


# Generated at 2022-06-21 11:53:13.324107
# Unit test for constructor of class GoogleParser
def test_GoogleParser():
    try:
        googleParser = GoogleParser([1, 2, 3])
    except TypeError as e:
        print(e)
    try:
        googleParser1 = GoogleParser([Section(10, 20, 30)])
    except TypeError as e:
        print(e)


# Generated at 2022-06-21 11:53:22.050819
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    parser = GoogleParser(title_colon=True)
    assert list(parser.sections.keys()) == DEFAULT_SECTIONS
    parser.add_section(Section("Test", "test", SectionType.MULTIPLE))
    assert list(parser.sections.keys()) == DEFAULT_SECTIONS + ["Test"]
    parser.add_section(Section("Test", "test", SectionType.MULTIPLE))
    assert list(parser.sections.keys()) == DEFAULT_SECTIONS + ["Test"]

# Generated at 2022-06-21 11:53:31.056220
# Unit test for function parse
def test_parse():
    import pytest

    text = """
    Parse the text.

    :param arg1: param1 description
    :param arg2: param2 description

    :raises KeyError: raises description
    :return: return description
    """

    doc = parse(text)

    assert doc.short_description == "Parse the text."
    assert doc.long_description == None
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True

    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == 'param1 description'
    assert doc.meta[0].arg_name == 'arg1'
    assert doc.meta[0].type_name == None
    assert doc.meta[0].is_optional == None

# Generated at 2022-06-21 11:53:34.384110
# Unit test for constructor of class Section
def test_Section():
    title = "Arguments"
    key = "param"
    type = "SectionType.MULTIPLE"
    section = Section(title, key, type)
    assert section.title == title
    assert section.key == key
    assert section.type == type


# Generated at 2022-06-21 11:53:36.777584
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    GoogleParser2 = GoogleParser(sections=[])
    Section2 = Section("NewSection", "new", SectionType.SINGULAR)
    GoogleParser2.add_section(Section2)
    assert (GoogleParser2.sections["NewSection"] == Section2)



# Generated at 2022-06-21 11:53:49.215556
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring
    from .google import parse
    from .numpy import NumpyParser
    from .sphinx import SphinxParser
    from .napoleon import NapoleonParser

    # Test for empty string
    res = GoogleParser().parse("")
    assert isinstance(res, Docstring)
    assert not res.short_description
    assert not res.long_description
    assert not res.meta

    # Test for empty docstring
    res = GoogleParser().parse("\n\n")
    assert isinstance(res, Docstring)
    assert not res.short_description
    assert not res.long_description
    assert not res.meta


    # Test for short description
    res = GoogleParser().parse("Test")
    assert isinstance(res, Docstring)

# Generated at 2022-06-21 11:53:52.650755
# Unit test for constructor of class Section
def test_Section():
    section_test_1 = Section("Arguments", "param", SectionType.MULTIPLE)
    assert section_test_1.title == "Arguments" and section_test_1.key == "param" and section_test_1.type == SectionType.MULTIPLE


# Generated at 2022-06-21 11:54:04.164941
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-21 11:54:14.854928
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    """
    Tests for the method add_section of class GoogleParser
    """
    # Unittest for the method add_section and parse of class GoogleParser
    # The method add_section is tested with the method parse
    # The tests are divided in two parts: correct and incorrect
    #
    # In the correct part the following situations are tested:
    #   - Add one section
    #   - Add more section
    #   - Add a section which already exists
    #   - Add a section without colon after title
    #
    # In the incorrect part the following situations are tested:
    #   - Add a section with wrong title
    #   - Add a section with wrong type

    # Correct
    # Add one section
    func = GoogleParser()
    # Setting up
    sectionExpected = Section("single", "single", SectionType.SINGULAR)