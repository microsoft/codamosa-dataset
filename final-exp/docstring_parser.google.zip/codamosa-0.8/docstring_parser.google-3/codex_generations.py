

# Generated at 2022-06-11 21:16:07.148598
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import numpy as np
    # Test with a docstring of the numpy package

# Generated at 2022-06-11 21:16:13.287451
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of GoogleParser class."""
    text = """
            This function does something.

            Args:
                arg1: The first argument.
                arg2: The second argument.

            Returns:
                The return value. True for success, False otherwise.
            """
    result = GoogleParser().parse(text)
    print(result)



# Generated at 2022-06-11 21:16:19.291113
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    @docstring_google
    def foo():
        """Method foo.

        Arguments:
            arg1 (str): The first argument.
            arg2 (str, optional): The second argument. Defaults to 'b'.

        Returns:
            str: The return value.

        Raises:
            AttributeError: The exception description.
        """

        pass

    assert foo.__doc__ == """Method foo.

Arguments:
    arg1 (str): The first argument.
    arg2 (str, optional): The second argument. Defaults to 'b'.

Returns:
    str: The return value.

Raises:
    AttributeError: The exception description."""

    docstring = parse(foo.__doc__)
    assert isinstance(docstring, Docstring)

# Generated at 2022-06-11 21:16:30.135464
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Creates a new cluster.

    Args:
        project_id: The Google Developers Console [project ID or project
            number](https://support.google.com/cloud/answer/6158840).
        zone: The name of the Google Compute Engine
            [zone](https://cloud.google.com/compute/docs/zones#available) in which the cluster
            resides.
        cluster: A dict object representing the cluster attributes. For a list of supported fields,
            refer to the CLUSTER_ATTRIBUTES dict.
        
        
        test
    """
    print(GoogleParser().parse(text))



# Generated at 2022-06-11 21:16:43.437571
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Single-line summary.

    Long description.

    Args:
        arg1 (str): This is the first argument.
        arg2 (int): This is the second argument. Default is 42.

    Returns:
        str: This is the return value.
    """
    sections = [
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    gp = GoogleParser(sections)
    result = gp.parse(docstring)
    assert type(result) == Docstring
    assert result.short_description == "Single-line summary."
    assert result.long_description == (
        "Long description."
    )
    assert result.blank_after_short_description == True

# Generated at 2022-06-11 21:16:56.153765
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    # Test for empty docstring
    assert parser.parse('') == Docstring()
    # Test for short and long description parser
    assert parser.parse('This is short description') == Docstring(
        short_description='This is short description',
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parser.parse(
        'This is short description\n\nThis is long description'
    ) == Docstring(
        short_description='This is short description',
        long_description='This is long description',
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    # Test for meta parser

# Generated at 2022-06-11 21:17:05.022119
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:17:05.824590
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()


# Generated at 2022-06-11 21:17:15.031999
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Docstring is None
    docstring = GoogleParser().parse(None)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert not docstring.meta

    # Docstring is empty
    docstring = GoogleParser().parse("")
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert not docstring.meta

    # Docstring has only short description
    docstring = GoogleParser().parse("short description")
    assert docstring.short_description == "short description"
    assert docstring.long_description is None

# Generated at 2022-06-11 21:17:21.542977
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = \
    """
    This is a google style docstring.

    :param arg1: The first argument.
    :type arg1: str
    :param arg2: The second argument.
    :type arg2: int, optional
    :returns: Description of return value.
    :rtype: bool
    """
    cfg = GoogleParser()
    res = cfg.parse(text)
    # print(res)
    assert res.short_description == "This is a google style docstring."
    assert res.long_description == None
    # print(res.meta)
    assert len(res.meta) == 4
    res = cfg.parse(text)
    # print(res)
    assert res.short_description == "This is a google style docstring."
    assert res.long_description == None


# Generated at 2022-06-11 21:17:41.534030
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""    One-line summary\n    extended description\n    Parameters\n    ----------\n    x : int\n        description of x.\n\n        >>> print(x)\n    """)
    print(docstring)
    parser = GoogleParser(title_colon=False)
    docstring = parser.parse("""    One-line summary\n    extended description\n    Parameters\n    ----------\n    x : int\n        description of x.\n\n        >>> print(x)\n    """)
    print(docstring)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:17:53.761178
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """Small test function.

    Args:
        a (str): first argument.
        b (str): second argument.

    Returns:
        str: join of both strings.
    """

    docstring = parser.parse(text)
    assert docstring.short_description == "Small test function."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False

# Generated at 2022-06-11 21:17:56.970538
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_string = """
    Compute the gravity vector.
    See also
    --------
    compute_gravity_potential
    """

    assert GoogleParser().parse(doc_string)



# Generated at 2022-06-11 21:18:06.427762
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''\
    Test for the parse method of class GoogleParser.

    This method tests all methods of class GoogleParser.

    Arguments:
        text (str): Google-style docstring with multiple sections.

    Returns:
        Docstring: parsed docstring
    '''
    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert doc.short_description == "Test for the parse method of class GoogleParser."
    assert doc.long_description == '''\
    This method tests all methods of class GoogleParser.
    '''
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert isinstance(doc.meta[0], DocstringParam)

# Generated at 2022-06-11 21:18:18.383004
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    # def parse(self, text: str) -> Docstring:
    def check(text, docstring):
        print("text", text)
        print("docstring", docstring)
        _docstring = parser.parse(text)
        assert _docstring == docstring
        print()

    # blank
    check("", Docstring())
    check(" ", Docstring())
    check("\t", Docstring())
    check("\n", Docstring())

    # short_description
    check("x", Docstring(short_description="x"))
    check(" x", Docstring(short_description="x"))
    check("x ", Docstring(short_description="x"))
    check("\tx", Docstring(short_description="x"))
    check("\nx", Docstring(short_description="x"))

# Generated at 2022-06-11 21:18:29.406084
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing method parse of class GoogleParser")

    text = """
        Short description.
        
        Long description.
            line 1
            line 2

        Args:
            arg1 (int): Arg 1 description.
            arg2 (str): Arg 2 description.
    """
    docstring = GoogleParser().parse(text)
    print(docstring)
    # print(docstring.short_description)
    # print(docstring.long_description)
    # print(docstring.meta)
    # print(docstring.blank_after_short_description)
    # print(docstring.blank_after_long_description)
    # print(docstring.meta[0].description)
    # print(docstring.meta[0].arg_name)
    # print(docstring.meta[0].type_name)
   

# Generated at 2022-06-11 21:18:39.504824
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    t=parse(u"""
    """
    )
    assert t.short_description == None
    assert t.long_description == None
    assert t.blank_after_long_description == False
    assert t.blank_after_short_description == False

    t=parse(u"""
    """
    )
    assert t.short_description == None
    assert t.long_description == None
    assert t.blank_after_long_description == False
    assert t.blank_after_short_description == False

    t=parse(u"""
    """
    )
    assert t.short_description == None
    assert t.long_description == None
    assert t.blank_after_long_description == True
    assert t.blank_after_short_description == True

    t=parse(u"""
    """
    )

# Generated at 2022-06-11 21:18:48.331222
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    def get_docstring():
        """
        Constroi o dicionário de dados para o produto com
        as informações de nome, sku, descrição e quantidade.

        :params nome: nome do produto.
        :params descricao: descrição do produto.
        :params quantidade: quantidade do produto.
        :param sku: Código do produto.

        :returns: retorna o dicionário de dados do produto.
        """
        return ''

    parsed = GoogleParser().parse(get_docstring.__doc__)


# Generated at 2022-06-11 21:18:51.823848
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    docstr = """def example_function(first_param, second_param):

     """
    # TODO: Write tests here



# Generated at 2022-06-11 21:19:00.502658
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Run the test
    from .examples import google_docstrings
    for module in google_docstrings:
        for key, value in module.__dict__.items():
            if inspect.isclass(value) and hasattr(value, "__doc__"):
                g = parse(value.__doc__)
                print("Class:%s\n" % key)
                print("short_description:%s\n" % g.short_description)
                print("long_description:%s\n" % g.long_description)
                print("blank_after_short_description:%s\n" % g.blank_after_short_description)
                print("blank_after_long_description:%s\n" % g.blank_after_long_description)

# Generated at 2022-06-11 21:19:09.857979
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    This is a method to parse Google-style docstring into its components.

    Args:
        text (str): google-style docstring
    
    Returns:
        parsed docstring
    """
    gp = GoogleParser()
    ret = gp.parse(text)
    assert (ret.short_description == "This is a method to parse Google-style docstring into its components.")
    assert (ret.blank_after_short_description == True)
    assert (ret.blank_after_long_description == False)
    assert (ret.long_description == None)
    assert (len(ret.meta) == 1)
    assert (isinstance(ret.meta[0], DocstringParam))
    assert (ret.meta[0].args == ['param', 'text (str)'])

# Generated at 2022-06-11 21:19:17.046478
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:19:29.780465
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = ""
    print("docstring: ", d)
    parsed_docstring = parse(d)
    print("parsed_docstring: ", parsed_docstring)
    assert parsed_docstring.short_description == ""
    assert parsed_docstring.long_description == None
    assert len(parsed_docstring.meta) == 0
    d = """
    """
    print("docstring: ", d)
    parsed_docstring = parse(d)
    print("parsed_docstring: ", parsed_docstring)
    assert parsed_docstring.short_description == ""
    assert parsed_docstring.long_description == None
    assert len(parsed_docstring.meta) == 0
    d = """
    This is a function.
    """
    print("docstring: ", d)
   

# Generated at 2022-06-11 21:19:35.435177
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #.
    docstring = textwrap.dedent('''\
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    ''')

    tested_obj = GoogleParser()
    ret = tested_obj.parse(docstring)

    assert ret.short_description == "Parse the Google-style docstring into its components."


# Generated at 2022-06-11 21:19:47.068404
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    def function():
        """Convenience function for unittesting docstring parsing.

        Dummy function for unittesting docstring parsing. Returns
        the docstring of itself as a string, formatted according to
        the Google Style Python docstring.

        Args:
            param1: The first parameter.
            param2: The second parameter.
                Defaults to None.

        Returns:
            bool: The return value. True for success, False otherwise.

        """
        return True

    # Create parser, parse to get Docstring, check properties
    parser = GoogleParser()
    docstring = parser.parse(function.__doc__)

    assert docstring.short_description == "Convenience function for unittesting docstring parsing."

# Generated at 2022-06-11 21:19:55.455890
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_string = """Test function
    :param arg1: The first argument.
    :param arg2: The second argument.
    :type arg2: str
    :param arg3: The third argument.
    :type arg3: :class:`~.Module`
    :return: The return type.
    :rtype: str
    :raises TypeError: if something goes wrong.
    :raises ValueError: if something else goes wrong.
    """

    google_parser = GoogleParser()
    result = google_parser.parse(test_string)

    assert(result.short_description == "Test function")
    assert(result.long_description == None)
    assert(result.blank_after_short_description == True)
    assert(result.blank_after_long_description == False)

# Generated at 2022-06-11 21:20:03.802183
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_docstring_1 = '''
    Sum values of the `column` with the `value`.

    This is a long description.

    :param int column: The column.
    :param int value: The value.
    :return: The result.
    :rtype: int
    '''

    actual_output = GoogleParser().parse(test_docstring_1)

# Generated at 2022-06-11 21:20:12.535497
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse("""\
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """)
    print(docstring)
    assert docstring.short_description == "Parse the Google-style docstring into its components."
    assert docstring.long_description == "returns: parsed docstring"
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ["returns"]
    assert docstring.meta[0].description == "parsed docstring"


# Generated at 2022-06-11 21:20:22.738790
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse(
        """
        Get a list of topology table entries by a given condition.

        The condition could be ``device_id``, ``topology_type`` and ``topology_feature``.

        Args:
            input (str): The input to calculate the length of.

        Returns:
            int: The length of.

        Example:
            >>> hello = "hello world"
            >>> len(hello)
            12

        Raises:
            ValueError: The input was not valid.
        """
    )

    assert docstring.short_description == "Get a list of topology table entries by a given condition."
    assert docstring.long_description == "The condition could be ``device_id``, ``topology_type`` and ``topology_feature``."

# Generated at 2022-06-11 21:20:35.540618
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring, DocstringParam, DocstringRaises, DocstringReturns
    from .google import GoogleParser
    from .meta import Meta


    ###############################
    # Positive tests
    ###############################

    # text=No docstring, returns empty docstring
    ret = Docstring()
    ret = GoogleParser().parse(text='')
    assert ret == Docstring()

    # text=1 line docstring, returns docstring with that line in short description
    ret = Docstring()
    ret.short_description='This function squares a number'
    ret2 = GoogleParser().parse(text='This function squares a number')
    assert ret == ret2

    # text=short_description and long description, returns docstring with that line in short description and correct long description
    ret = Docstring()
    ret.short_

# Generated at 2022-06-11 21:20:53.211282
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """\
        Args:
            arg1: The first argument.
            arg2 (int): The second argument. Optional.
            arg3 (str, optional): The third argument. Defaults to "hello".
            arg4 (bool, optional): The fifth argument. Defaults to False.
            arg5 (T.Tuple[str, int]):
                The sixth argument.
        """
    )

# Generated at 2022-06-11 21:21:03.478617
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    A function that generates a list.

    Args:
        num_elem (int): number of elements.
        elem_value (float): value of each element.
        list_name (str): name of the list.

    Returns:
        a list named after list_name of float values
    """

    docstring_dict = parse(docstring)
    assert isinstance(docstring_dict, Docstring)
    assert docstring_dict.short_description == "A function that generates a list."
    assert docstring_dict.long_description is None
    assert docstring_dict.blank_after_short_description == False
    assert docstring_dict.blank_after_long_description == False

    meta = docstring_dict.meta
    assert len(meta) == 3

# Generated at 2022-06-11 21:21:12.675403
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:21:23.509281
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import DocstringParam, DocstringRaises, DocstringReturns

    docstring = """A test paragraph.

And another one.

Args:
  yes: This is a yes.
  no: This is a no.

Returns:
  A description of the return value.
  """
    doc = GoogleParser().parse(docstring)
    assert str(doc) == docstring

    ret = doc.returns
    if not isinstance(ret, DocstringReturns):
        raise Exception("Expected a DocstringReturns instance.")
    assert ret.arg_name is None
    assert ret.type_name == "A description of the return value."

    params = sorted(doc.params, key=lambda p: p.arg_name)

# Generated at 2022-06-11 21:21:36.093816
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_docstring = """
    Greeting.

    Args:
    name (str): The name of the person to greet.
    """

    google_docstring_with_default = """
    Greeting.

    Args:
    name (str): The name of the person to greet. Defaults to 'world'.
    """

    google_docstring_with_returns = """
    Greeting.

    Returns:
    str: Greeting string.
    """

    assert GoogleParser().parse(google_docstring).short_description == 'Greeting.'
    assert GoogleParser().parse(google_docstring).long_description == None
    assert GoogleParser().parse(google_docstring).blank_after_short_description == True

# Generated at 2022-06-11 21:21:45.211504
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Test GoogleParser.parse.

Args:
    arg1: Arg1 description
    arg2 (str): Arg2 description
    arg3 (str): Arg3 description with os.linesep
    arg4 (str, optional): Arg4 description. Defaults to None.
    arg5 (str, optional): Arg5 description with multi-line text. Defaults to None.
Raises:
    TypeError
        Description for exception
Returns:
    str: Description for return value
Example:
    >>> print("Example")
    Example
    """
    result = GoogleParser().parse(docstring)
    assert result.short_description == "Test GoogleParser.parse."

# Generated at 2022-06-11 21:21:54.191484
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = textwrap.dedent(
        """\
    A summary line.

    A longer description.

    Args:
        param1: A
        param2 (int): B

    Returns:
        The return value. True for success, False otherwise.
    """
    )
    parsed = GoogleParser().parse(text)


# Generated at 2022-06-11 21:22:06.497105
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    with open("test.md") as input:
        text = input.read()
        output = GoogleParser().parse(text)

# Generated at 2022-06-11 21:22:19.110655
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:22:30.711584
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring, DocstringParam, DocstringReturns
    from .google import GoogleParser


# Generated at 2022-06-11 21:22:47.192399
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test parse method of class GoogleParser
    test_code = '''\
        
        """
        Test docstring.
        
        :param str module: The module name.
        :param bool param2: The second parameter.
        :keyword str kwonly: This keyword arg is required.
        :keyword int kwonly2: This keyword arg is not required.
        :raises ImportError: The exception type to raise.
        :raises ValueError: Another type of exception to raise.
        :returns: True if verbose, False otherwise.
        :returns: None if not verbose.
        """
        
        def func():
            pass
        
        '''

    for module in (inspect, inspect2):
        print(module.__name__)
        ds = GoogleParser().parse(test_code)


# Generated at 2022-06-11 21:22:57.567797
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Description for the function.
    Args:
        name (str): The name of the person.
        age (int): The age of the person.
        is_tall (bool): Whether or not the person is tall.
        family (List[Person]): The family of the person.
    """
    ds = parse(text)
    assert(len(ds.meta) == 4)
    assert(ds.meta[0].description == "The name of the person.")
    assert(ds.meta[1].description == "The age of the person.")
    assert(ds.meta[2].description == "Whether or not the person is tall.")
    assert(ds.meta[3].description == "The family of the person.")

# Generated at 2022-06-11 21:23:07.732970
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    SG = GoogleParser()
    text_1 = '''
            This is a docstring.
            
            Args:
                arg_x: a number, the abc.
            '''
    text_2 = '''
            This is a docstring.
            
            Args:
                arg_x (int): a number, the abc.
            '''
    text_3 = '''
            This is a docstring.
            
            Args:
                arg_x (int, optional): a number, the abc.
            '''
    text_4 = '''
            This is a docstring.
            
            Args:
                arg_x (int?)
            '''
    text_5 = '''
            This is a docstring.
            
            Args:
                arg_x
            '''

# Generated at 2022-06-11 21:23:18.941121
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('') == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
        )

    assert parse('Short description') == Docstring(
        short_description='Short description',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
        )

    assert parse('Short description\nLong description') == Docstring(
        short_description='Short description',
        long_description='Long description',
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
        )

    assert parse('Short description\n\nLong description')

# Generated at 2022-06-11 21:23:30.357568
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    parser = GoogleParser()
    d = parser.parse(
        """
    Compute the integral of f by Gaussian quadrature.

    The integral of f(x) = exp(-x) from x = 0 to infinity.

    Parameters
    ----------
    n: int
        Order of quadrature.
    
    Returns
    -------
    estimated integral
        Integral of f(x) from 0 to infinity.
    """
    )

    assert d.short_description == "Compute the integral of f by Gaussian quadrature."
    assert d.blank_after_short_description
    assert d.long_description == "The integral of f(x) = exp(-x) from x = 0 to infinity."
    assert d.blank_after_long_description
    assert d.meta[0].key == "param"
    assert d

# Generated at 2022-06-11 21:23:41.965810
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''\
    A short summary.

    A long description.

    Args:
        arg1: Description of arg1.
        arg2: Description of arg2.

    Returns:
        A description of what is returned.
    '''

# Generated at 2022-06-11 21:23:50.958001
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # 1
    text = "This function does something.\n\nArgs:\n  arg1: An argument.\n  arg2: Another argument.\n    This argument has a description over multiple lines.\n\nReturns:\n  This is a description of what is returned.\n  Here is another line of it.\n\nRaises:\n  KeyError: Raises an exception.\n  OtherError: Raises another exception."
    ans = GoogleParser().parse(text)
    assert len(ans.meta) == 4
    assert ans.meta[0].args == ['param', 'arg1']
    assert ans.meta[0].description == 'An argument.'
    assert ans.meta[1].args == ['param', 'arg2']

# Generated at 2022-06-11 21:23:58.182387
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    result = parser.parse(
        """Returns a world

        This is a long description.
        This is a long description.
        This is a long description.
        This is a long description.
        This is a long description.

        :param name: The name of the world.
        :type name: str
        :param universe: The universe the world exists in.
        :type universe: Universe
        :returns: returns a world
        :rtype: World
        """
    )
    print(result)



# Generated at 2022-06-11 21:23:59.853181
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test case for GoogleParser.parse method using doctest."""
    import doctest
    doctest.testmod(verbose=True)
    return True


# Generated at 2022-06-11 21:24:09.205293
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    parsed_docstring = parser.parse('''\
    This is the description.
    ''')
    assert parsed_docstring.short_description == 'This is the description.'
    assert parsed_docstring.long_description is None

    parsed_docstring = parser.parse('''\
    This is the description.

    This is the long description.
    ''')
    assert parsed_docstring.short_description == 'This is the description.'
    assert parsed_docstring.long_description == 'This is the long description.'

    parsed_docstring = parser.parse('''\
    This is the description.

    This is the long description.

    Args:
      test (TestType): Test description.

    Returns:
      TestType: Test description.

    ''')

    assert parsed

# Generated at 2022-06-11 21:24:21.604579
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest
    from .common import Docstring, DocstringMeta
    # Setup
    googledocstring = '''This is a summary.

    This is a long, multi-line description.
    It can have many lines.

    Args:
        a: This is an argument.

        b(str): This is another argument.

        c(str, optional): This is a third argument.
            Some more description of c. Defaults to True.

    Returns:
        A thing.
    '''

# Generated at 2022-06-11 21:24:34.726407
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    docstring = """This is a docstring example.

Args:
    arg_name (str): description...
    arg_name2 (str): description...
    arg_name3 (str): description...

Returns:
    str: return description...
"""
    result = parser.parse(docstring)
    print(result)
    assert result.meta[0].args == ['returns', 'str: return description...']
    assert result.meta[0].description == 'return description...'
    assert result.meta[0].type_name == 'str'
    assert result.meta[1].args == ['param', 'arg_name(str): description...']
    assert result.meta[1].description == 'description...'
    assert result.meta[1].arg_name == 'arg_name'

# Generated at 2022-06-11 21:24:40.670001
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse('This is a docstring.\n')
    print(docstring.meta)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.blank_after_short_description)
    print(docstring.blank_after_long_description)

test_GoogleParser_parse()

# Generated at 2022-06-11 21:24:49.613789
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #x = "Google-style docstring parsing."
    s = "SINGULAR"
    m = "MULTIPLE"
    sm = "SINGULAR_OR_MULTIPLE"

# Generated at 2022-06-11 21:24:51.227484
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    a = GoogleParser("test.py")
    assert True # TODO: implement your test here


# Generated at 2022-06-11 21:25:01.934871
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    Hello world.

    Arguments:
        arg1 (int): arg1.
        arg2 (int): arg2.

    Returns:
        int: max of arg1, arg2.
    """


# Generated at 2022-06-11 21:25:10.598680
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """Computes the tan of x element-wise.

Args:
  x: A Tensor or SparseTensor. Must be one of the following types:
    `float32`, `float64`, `int32`, `complex64`, `complex128`.

Returns:
  A Tensor of the same shape as x.
"""
    docstring = GoogleParser().parse(doc)
    assert docstring.meta[0].description == "Computes the tan of x element-wise."
    assert docstring.meta[0].args == ["description"]
    assert docstring.meta[1].description == "x: A Tensor or SparseTensor. Must be one of the following types: `float32`, `float64`, `int32`, `complex64`, `complex128`."

# Generated at 2022-06-11 21:25:21.286711
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc1 = """Convert from Celsius to Fahrenheit.

    :param celsius: The temperature in Celsius.
    :type celsius: float
    :returns: The temperature in Fahrenheit.
    :rtype: float
    """
    doc2 = """Convert from Celsius to Fahrenheit.

    :param celsius: The temperature in Celsius.
    :type celsius: float
    :returns: The temperature in Fahrenheit.
    :rtype: float
    :raises: ValueError
    """

# Generated at 2022-06-11 21:25:29.865043
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    txt = """
    Alias for field number 4
    """

    p = GoogleParser()
    doc = p.parse(txt)
    print(doc.meta)
    print(doc.short_description)
    print(doc.long_description)

    txt = """
    function description

    :param arg1: the first argument
    :type arg1: int, optional
    :param arg2: the second argument
    :type arg2: str

    :returns: description of return value
    :rtype: bool
    """

    p = GoogleParser()
    doc = p.parse(txt)
    print(doc.meta)
    print(doc.short_description)
    print(doc.long_description)


# Generated at 2022-06-11 21:25:39.848469
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''One line summary.

    Longer description.

    Args:
        arg1 (str): The first argument.
        arg2 (numpy.random.random_state): The second argument.

    Returns:
        numpy.Array: The return value.
    '''
    docstring_v2 = '''One line summary.

    Longer description.

    Args:
        arg1 (str): The first argument.
        arg2 (numpy.random.random_state): The second argument.

    Returns:
        numpy.Array: The return value.

    Raises:
        AttributeError: The raised error.
    '''