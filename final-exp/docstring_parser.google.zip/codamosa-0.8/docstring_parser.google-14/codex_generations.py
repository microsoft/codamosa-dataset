

# Generated at 2022-06-11 21:15:59.768639
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("\n") == Docstring()
    assert parser.parse("\n    ") == Docstring()

    an_example = \
        DocstringMeta(args=['examples'], description='a example')
    an_parameter = DocstringParam(args=['param', 'a'],
                                  description='a parameter',
                                  arg_name='a',
                                  type_name=None,
                                  is_optional=None,
                                  default=None)
    an_returns = DocstringReturns(args=['returns', 'a'],
                                  description='a return',
                                  type_name='a',
                                  is_generator=False)

# Generated at 2022-06-11 21:16:08.069793
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest, inspect
    from .common import Docstring

    def run_test(sig_str, exp_str, exp_returns_str, parser):
        exp = eval(exp_str)
        exp_returns = eval(exp_returns_str)
        sig = eval(sig_str)
        parsed = GoogleParser(parser).parse(sig)
        assert parsed == exp, \
            '\n' + str(parsed) + '\n' + exp_str + '\n' + sig_str

    def check(
        sig, exp, exp_returns, parser=None
    ):
        if sig == None:
            return
        if not parser:
            run_test(repr(sig), exp, exp_returns, parser)

# Generated at 2022-06-11 21:16:17.196368
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:16:25.615837
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gParser = GoogleParser()
    docstring = gParser.parse(
        """
    This function is used to print a message.

    Parameters
    ----------
    msg : str
        The message that needs to be printed.
    msg1 : str
        The message that needs to be printed again.
    return : int
        The length of the message.

    """
    )
    print(docstring.__repr__())



# Generated at 2022-06-11 21:16:33.542253
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:16:45.766265
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("Hello World") == Docstring(
        short_description="Hello World", long_description=None, meta=[]
    )

    assert GoogleParser().parse("Hello World\n") == Docstring(
        short_description="Hello World",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    assert GoogleParser().parse("Hello World\n\nSomething") == Docstring(
        short_description="Hello World",
        long_description="Something",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-11 21:16:57.837590
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
A one-line summary that does not use variable names or the
function name.

Several sentences providing an extended description. Refer to
variables like `var1` and `var2`, and show `function_name`
how to do the job for a typical case.

Args:
    param1: The first parameter.
    param2: The second parameter.
    *args: Variable length argument list.
    **kwargs: Arbitrary keyword arguments.

Returns:
    bool: The return value. True for success, False otherwise.

"""

    result = GoogleParser().parse(text)

# Generated at 2022-06-11 21:17:06.369258
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    '''
    A function to test the method parse from class GoogleParser
    '''
    # Declaration of a docstring
    docstring = '''
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    '''
    # Implementation of the test
    parser = GoogleParser()
    docstring = parser.parse(docstring)
    # We check if we obtain the expected output
    assert docstring.short_description == 'Parse the Google-style docstring into its components.'
    assert docstring.long_description == 'returns: parsed docstring'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta == [DocstringMeta(args=['returns'], description='parsed docstring')]

# Generated at 2022-06-11 21:17:10.684902
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    :param arg: arg
    :type arg: arg
    """
    ret = GoogleParser().parse(text)
    assert ret.short_description is None
    assert ret.long_description is None

# Generated at 2022-06-11 21:17:23.110316
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse("""Example function with types documented in the docstring.
    
    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.
    """)
    assert docstring.meta[0].key == 'param'
    assert docstring.meta[0].args[1] == 'param1 (int)'
    assert docstring.meta[0].description == """The first parameter."""
    assert docstring.meta[1].args[1] == 'param2 (str)'
    assert docstring.meta[1].description == """The second parameter."""
    assert docstring.meta[2].args[0] == 'returns'
    assert docstring.meta[2].type_name == ''

# Generated at 2022-06-11 21:17:39.161502
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test1():
        global text
        text = '''Summary line.

Description:
    Long description.
'''
        global result
        result = GoogleParser().parse(text)
        return result

    print(test1())

test_GoogleParser_parse()

# Generated at 2022-06-11 21:17:50.361778
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  # Test case 1
  doc = """This is an example of Google style.

Args:
    param1: This is the first param.
    param2: This is a second param.

Returns:
    This is a description of what is returned.

Raises:
    KeyError: Raises an exception.
"""
  docstring = GoogleParser().parse(doc)
  print(docstring)
  # for elem in docstring.meta:
  #   print(elem)
  param1 = docstring.meta[0]
  print(param1)
  print(param1._type_name)
  print(type(param1))
  print(type(docstring))
  param2 = docstring.meta[1]
  print(type(param2))
  returns = docstring.meta[2]
  print

# Generated at 2022-06-11 21:18:02.698759
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a docstring
    """
    assert GoogleParser().parse(docstring) == Docstring(
        short_description="This is a docstring",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    docstring = """
    This is a docstring
    This is the long description
    """
    assert GoogleParser().parse(docstring) == Docstring(
        short_description="This is a docstring",
        long_description="This is the long description",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )

    docstring = """
    This is a docstring
    This is the long description
    """

# Generated at 2022-06-11 21:18:13.711556
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser(sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Exceptions", "raises", SectionType.MULTIPLE),
        Section("Except", "raises", SectionType.MULTIPLE),
        Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR)
    ])


# Generated at 2022-06-11 21:18:26.275200
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
    Test Google-style docstring parser.
    [This](http://www.example.com) is a link.

    :param x: A parameter.
    :param y: A second parameter.
    :type y: int
    :raises TypeError: If something bad happens.
    :return: None
    :rtype: None
    """
    res = GoogleParser().parse(doc)
    assert res.short_description == "Test Google-style docstring parser."
    assert res.long_description == """
        [This](http://www.example.com) is a link.
        """
    assert res.blank_after_long_description is True
    assert len(res.meta) == 4
    assert isinstance(res.meta[0], DocstringParam)

# Generated at 2022-06-11 21:18:37.174932
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import (
        Docstring,
        DocstringMeta,
        DocstringParam,
        DocstringRaises,
        DocstringReturns,
        ParseError,
    )
    from .google import SectionType, parse
    text = """\
    Single line description
    Long description

    Returns:
        int: The answer.
    """
    assert parse(text) == Docstring(
        short_description="Single line description",
        long_description="Long description",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[
            DocstringReturns(
                args=[
                    "returns",
                ],
                description="The answer.",
                type_name="int",
                is_generator=False,
            ),
        ],
    )

# Generated at 2022-06-11 21:18:43.079270
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def add(a, b):
        """Adds numbers.

        Adds two numbers and returns their sum.

        Args:
            a: first number
            b: second number

        Returns:
            sum of two numbers

        Examples:
            >>> add(1, 2)
            3
        """

    doc = parse(add.__doc__)
    print(doc.short_description)
    assert doc.short_description == "Adds numbers."


# Generated at 2022-06-11 21:18:50.762277
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Declaration of variables and lists
    examples = []
    examples.append('"""Test.\n\n    Examples:\n        >>> import foo\n        >>> foo.bar()\n    """')
    examples.append('"""Test.\n\n    Examples:\n        >>> import foo\n        >>> foo.bar()\n        >>> foo.bar()\n    """')
    examples.append('"""Test.\n\n    Example:\n        >>> import foo\n        >>> foo.bar()\n    """')
    examples.append('"""Test.\n\n    Examples:\n        >>> import foo\n        >>> foo.bar()\n        >>> foo.bar()\n    \n    Examples\n    --------\n    Another example\n    """'),

# Generated at 2022-06-11 21:18:59.893836
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:19:01.020537
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass


# Generated at 2022-06-11 21:19:10.310991
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """A short summary of the class.

    A longer description of the class.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value

    Raises:
        ValueError: if int(arg2) == 0
        TypeError: if type(arg2) is not str
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "A short summary of the class."
    assert doc.long_description == "A longer description of the class."
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is True
    assert doc.meta[0].args == ["param", "arg1 (int)"]
    assert doc.meta[0].arg_

# Generated at 2022-06-11 21:19:17.198229
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class A:
        """Class A

        Example:
            >>> print(A())

        Args:
            param1: description of param1
        Params:
            param2: description of param2
        Attributes:
            attribute1: description of attribute1
        Parameters:
            param3: description of param3
        """

        def __init__(self, param1, param2, param3=0, attribute1=0):
            pass

        def foo():
            """Foo docstring

            Example:
                >>> print(foo())

            Args:
                param1: description of param1
            Args:
                param2: description of param2
            Attributes:
                attribute1: description of attribute1
            Parameters:
                param3: description of param3
            """
            pass


# Generated at 2022-06-11 21:19:29.931391
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    section1 = Section("Arguments", "param", SectionType.MULTIPLE)
    section2 = Section("Raises", "raises", SectionType.MULTIPLE)
    section3 = Section("Exceptions", "raises", SectionType.MULTIPLE)
    section4 = Section("Example", "examples", SectionType.SINGULAR)
    section5 = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    section6 = Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE)
    google_parser1 = GoogleParser(
        sections=[section1, section2, section3, section4, section5, section6]
    )
    google_parser2 = GoogleParser()


# Generated at 2022-06-11 21:19:38.586667
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    text = '''

    Returns a dictionary containing:
      'decision_function': sparse matrix (n_samples, n_classes)
      'probabilities': sparse matrix (n_samples, n_classes)
      'confidences': array (n_samples,)

    '''
    r = p.parse(text)
    assert r.short_description == 'Returns a dictionary containing:'
    assert r.long_description.strip() == (
        "'decision_function': sparse matrix (n_samples, n_classes)\n"
        "'probabilities': sparse matrix (n_samples, n_classes)\n"
        "'confidences': array (n_samples,)")


# Generated at 2022-06-11 21:19:50.889581
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.titles_re.search('Arguments:')
    assert parser.titles_re.search('Args:')
    assert parser.titles_re.search('Parameters:')
    assert parser.titles_re.search('Params:')
    assert parser.titles_re.search('Raises:')
    assert parser.titles_re.search('Example:')
    assert parser.titles_re.search('Examples:')
    assert parser.titles_re.search('Returns:')
    assert parser.titles_re.search('Yields:')
    assert parser.parse('Hello') == Docstring(short_description='Hello')

# Generated at 2022-06-11 21:19:56.757076
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("Test:") == Docstring(short_description="Test")
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse(" Returns:") == Docstring(meta=[DocstringReturns(args=['returns'], description=None, type_name=None, is_generator=False)])


# Generated at 2022-06-11 21:20:02.559825
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_text_1 = '''
    Parse the Google-style docstring into its components.

    :param text: text: str
    :returns: parsed docstring

    '''
    p = GoogleParser()
    res = p.parse(docstring_text_1)
    print(res.short_description)
    print(res.long_description)
    print(res.blank_after_short_description)
    print(res.blank_after_long_description)
    print(len(res.meta))


# Generated at 2022-06-11 21:20:14.290150
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring
    from .common import DocstringMeta
    from .common import DocstringParam
    from .common import DocstringRaises
    from .common import DocstringReturns
    from .common import ParseError

    print("Testing function parse of class GoogleParser")

    p = GoogleParser()

    # Empty Docstring
    d0 = p.parse("")
    assert not d0
    assert d0.short_description == None
    assert d0.meta == []

    d0_0 = p.parse("\n")
    assert not d0_0
    assert d0_0.short_description == None
    assert d0_0.meta == []

    d0_1 = p.parse("\n\n")
    assert not d0_1
    assert d0_1.short_description == None
   

# Generated at 2022-06-11 21:20:18.768165
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("Hi, this is a docstring.") == Docstring(
        short_description = "Hi, this is a docstring.",
        meta = [],
        blank_after_short_description =   True,
        long_description = ""
    )


# Generated at 2022-06-11 21:20:25.930478
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''Return the first argument.

Parameters
----------
x: int, optional
    The argument to return.
Returns
-------
    The first argument.
'''

# Generated at 2022-06-11 21:20:41.149022
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from pprint import pformat
    text = """\
    My test docstring.

    Args:
        arg1 (:obj:`int`): this is an int arg.
        arg2 (:obj:`int`, optional): this is an optional int arg. Defaults to 1.

    Returns:
        int

    Raises:
       ValueError: If something goes wrong.

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function/class.
        >>> print([i for i in example_generator(4)])
        [0, 1, 2, 3]

    .. note::
        There are no doctest blocks in this example
    """
    p = GoogleParser()
    d = p.parse(text)
    print(pformat(d))


# Generated at 2022-06-11 21:20:53.741598
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    class TestClass:
        """This is the full docstring of the class
        which has a short description and a long description.
        """

    def test_function():
        """This is the full docstring of the function.

        It has a short description, a long description and contains the
        following sections:

        Args:
            arg1 (str): this is the description of arg1, which is a string. Defaults to 'arg1'.
            arg2 (int): this is the description of arg2, which is an integer.

        Returns:
            int: this is the description of the return value.

        Raises:
            ValueError: if arg1 is arg2
        """


# Generated at 2022-06-11 21:21:00.509786
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Teardown of the parser per test
    def teardown_parser():
        return GoogleParser()

    # Teardown of the docstring per test
    def teardown_docstring():
        return Docstring()


# Generated at 2022-06-11 21:21:01.516970
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #TODO: add unit test
    pass

# Generated at 2022-06-11 21:21:11.429233
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # A string representing the content of a Google-style docstring,
    # dedented by n_spaces spaces
    doc_string = """
    Short description.

    Long description.

    Args:
        arg1 (type): Description of arg1.
        arg2: Description of arg2.
        arg3, optional: Description of arg3. Defaults to 1.
        arg4 (type)?, optional: Description of arg4.
    
    Returns:
        description
    """
    n_spaces = 4
    doc_string = doc_string[n_spaces:]

    # First test: with title_colon set to True, the title of a section
    # must be followed by a colon. The docstring above is correctly
    # formatted, so we expect no error to be raised
    GoogleParser(title_colon=True).parse

# Generated at 2022-06-11 21:21:22.750310
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "This is a short description.\n\n" + \
        "This is a long description.\n" + \
        "It spans multiple lines.\n" + \
        "Arguments:\n" + \
        "    arg1: This is argument 1.\n" + \
        "    arg2 (int, optional): This is argument 2. Defaults to 2.\n" + \
        "Returns:\n" + \
        "    int: Result of add.\n" + \
        "Raises:\n" + \
        "    IOError\n" + \
        "    OSError\n"

    ret = GoogleParser().parse(text)
    assert ret.short_description == "This is a short description."
    assert ret.long_description == "This is a long description.\n"

# Generated at 2022-06-11 21:21:35.475473
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ds = '''\
    """
    Split a pathname into components (the opposite of os.path.join) in a
    platform-neutral way.

    Args:
      path: A pathname

    Returns:
      A list of the components in the path.

    Raises:
      ValueError: if the path is empty.

    Example:
        >>> split_path('/foo/bar')
        ['foo', 'bar']
        >>> split_path('/foo/bar/')
        ['foo', 'bar']

    """
    '''

# Generated at 2022-06-11 21:21:44.747594
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-11 21:21:53.895675
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    code = """\
    A short summary.

    A longer description with a blank line between it and the short
    summary.

    Args:
        arg1 (str): Description of arg1.
        arg2 (list): List of ints.

    Returns:
        str: The return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    doc = GoogleParser().parse(code)
    expected_return_type = "str"
    expected_return_description = "The return value."
    assert doc.short_description == "A short summary."
    assert doc.long_description == "A longer description with a blank line between it and the short\n    summary."


# Generated at 2022-06-11 21:22:06.237356
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ds = parse(
        """
        Summarize the function in one sentence.

        Describe the function more in detail.

        Args:
            arg1 (str): The first argument.
            arg2 (str): The second argument.
                It can go on for a long time, in which case you need to start
                the description on the second line.

        Examples:
            The following is an example of usage::

                >>> print(foo(1, 2))

        Returns:
            str: Returned value.

        Raises:
            ValueError: If something fails.
            NotImplementedError: If something else fails.
            AttributeError: If this fails.
        """
    )
    assert ds.short_description == "Summarize the function in one sentence."

# Generated at 2022-06-11 21:22:21.800307
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Override
    args = ['ars', 'kwargs']

# Generated at 2022-06-11 21:22:31.962877
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """A function which calculates the sum of two numbers.

:param x: first number
:param y: second number
:rtype: int

:return: the sum of x and y

:raises ValueError: if x is less than zero.

:exception ValueError: if x is greater than 10.
"""
    p = GoogleParser()
    d = p.parse(doc)
    assert d.short_description == "A function which calculates the sum of two numbers."
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False

# Generated at 2022-06-11 21:22:43.865129
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test if parsing works correctly"""
    text = """
    This method returns the class of the object

    Args:
        obj: The object, of which the class is returned.

    Returns:
        The class of the object

    """
    assert parse(text).short_description == "This method returns the class of the object"
    assert parse(text).long_description == "This method returns the class of the object\n"
    assert parse(text).blank_after_short_description is True
    assert parse(text).blank_after_long_description is True
    assert parse(text).meta[0].args == ["param", "obj"]
    assert parse(text).meta[0].description == "The object, of which the class is returned."
    assert parse(text).meta[1].args == ["returns", "The class of the object"]

# Generated at 2022-06-11 21:22:52.053627
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:23:00.596410
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pprint

    def func_test(text, expected_results):
        p = GoogleParser()
        ds = p.parse(text)

        if ds.short_description != expected_results['short_description']:
            print('short_description mismatch')
            pprint.pprint(ds.short_description)
            pprint.pprint(expected_results['short_description'])
        if ds.blank_after_short_description != expected_results['blank_after_short_description']:
            print('blank_after_short_description mismatch')
            pprint.pprint(ds.blank_after_short_description)
            pprint.pprint(expected_results['blank_after_short_description'])

# Generated at 2022-06-11 21:23:10.919015
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    parse_func = lambda text: parser.parse(text)

    text = """Single line docstring.

    :param a:
    :returns:
    """
    docstring = parse_func(text)
    assert docstring.short_description == "Single line docstring."
    assert docstring.long_description == ""
    assert docstring.meta[0].args == ['param', 'a']
    assert docstring.meta[1].args == ['returns']

    text = """Single line docstring.

    Args:
        a:
    Returns:
    """
    docstring = parse_func(text)
    assert docstring.short_description == "Single line docstring."
    assert docstring.long_description == ""

# Generated at 2022-06-11 21:23:20.161924
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    ret = p.parse("""\
        This is the short description.
        This is the long description.

        Parameters
            arg1 (str): What is arg1.
            arg2 (:obj:`int`, optional): What is arg2. Default is 5.
    """)

    assert ret.short_description == "This is the short description."
    assert ret.blank_after_short_description == False
    assert ret.long_description == "This is the long description."
    assert ret.blank_after_long_description == True

    assert len(ret.meta) == 3
    assert ret.meta[0].args == ["param", "arg1"]
    assert ret.meta[0].description == "What is arg1."
    assert ret.meta[0].arg_name == "arg1"

# Generated at 2022-06-11 21:23:25.123011
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_string = """Signature:
    parse(text)
    """
    try:
        doc = GoogleParser().parse(doc_string)
    except Exception as e:
        print(e)
    

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:23:33.691773
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''Short description.

    Long description.

    Args:
        arg_name (type): Description.
    '''

    docstring = GoogleParser().parse(text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == 'Short description.'
    assert docstring.long_description == 'Long description.'
    assert docstring.blank_after_short_description == True

    assert len(docstring.meta) == 1
    assert docstring.meta[0].args == ['param', 'arg_name (type)']
    assert isinstance(docstring.meta[0], DocstringParam)

    docstring = GoogleParser(title_colon=False).parse(text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == 'Short description.'

# Generated at 2022-06-11 21:23:43.842478
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-11 21:23:54.196218
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    # quick tests for multiple single section
    text = """
        Short description.
        Longer description with newlines.
        [params]
        A: int
        B: str: Optional
        C: bool=True
        [returns]
        A value of D.
        [example]
        print('blah')
    """
    parser.parse(text)
    # Remove whitespace
    text = "".join(text.split())
    parser.parse(text)

# Generated at 2022-06-11 21:24:01.260387
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """This is a summary

This is an extended summary

Parameters
----------
x: int
    this is a parameter.
y: float

Returns
-------
int
    This is a return.
"""
    result = parse(text)
    assert result.short_description == "This is a summary"
    assert "extended summary" in result.long_description
    assert result.meta[0].description == "this is a parameter."
    assert result.meta[1].description == "This is a return."


# Generated at 2022-06-11 21:24:14.236446
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  import example.foo
  import example.module
  import example.bar
  import example.module2
  import example.submodule
  import example.subsubmodule

  settings = GoogleParser(title_colon=False)
  docstring = settings.parse(example.foo.__doc__)
  assert docstring.short_description == "Foo"
  assert docstring.long_description == "Class Foo"
  assert not docstring.blank_after_short_description
  assert not docstring.blank_after_long_description

  description = """
  Name: f
  Types: function, int
  """
  docstring = settings.parse(description)
  assert not docstring.short_description
  assert not docstring.long_description
  assert docstring.blank_after_short_description
  assert docstring.blank_after

# Generated at 2022-06-11 21:24:22.476471
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def example_func(a, b, c=1.0, d=[], e=(), f={}, g=None, h=True):
        """
        Examples:
            >>> example_func(1, 2, c=1.5, d=[], e=(), f={}, g=None, h=False)

        Arguments:
            a: first
            b: second

        Returns:
            result

        Raises:
            ValueError: if something is wrong

        """
        pass

    expected = """Examples:
            >>> example_func(1, 2, c=1.5, d=[], e=(), f={}, g=None, h=False)

Arguments:
    a: first
    b: second

Returns:
    result

Raises:
    ValueError: if something is wrong

"""
    expected

# Generated at 2022-06-11 21:24:35.025568
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        Single line description.

        Long description.
        And another line.
        And third.

        Args:
            arg1 (str): First arg description.
            arg2 (str): Second arg description.

        Returns:
            Tuple[int, str, int]:
            First value is the number of species, second the name of
            the library, third the number of unique species.
        """
    google_parser = GoogleParser()
    docstring = google_parser.parse(text)
    assert docstring.short_description == "Single line description."
    assert docstring.long_description == "Long description.\nAnd another line.\nAnd third."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta)

# Generated at 2022-06-11 21:24:46.589220
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Summary line here.\nDescription Here
        \n    with spaces    \n    and spaces
        \n  Args:\n    head1 (type1): Description of the first param\n    head2 (type2): Description of the second param\n    head3 (type3): Description of the third param\n  Returns:\n    Description of the return value here."""
    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert len(doc.meta) == 4
    assert isinstance(doc.meta[3], DocstringReturns)
    assert doc.meta[3].args == ['returns', 'Description of the return value here']
    assert doc.meta[3].description == None
    assert doc.meta[3].type_name == None

# Generated at 2022-06-11 21:24:53.163416
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    b = GoogleParser()
    docstring = '''\
    One line summary.

    Longer description.

    Args:
         a: int
    """
    '''
    assert b.parse(docstring).short_description == "One line summary."
    assert b.parse(docstring).long_description == "Longer description."
    assert b.parse(docstring).meta[0].title == "Args"
    assert b.parse(docstring).meta[0].args[1] == "a"


# Generated at 2022-06-11 21:25:03.433117
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:25:11.748786
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""

    # Test for empty docstring
    expected = Docstring()
    assert(GoogleParser().parse("") == expected)
    
    # Test for docstring without any section
    text = "A description of the unit test"
    expected = Docstring(short_description=text)
    assert(GoogleParser().parse(text) == expected)

    # Test for docstring with a single line
    text = "A section:\n\nThe test description."
    expected = Docstring(
        short_description=None,
        long_description="The test description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    expected.meta.append(DocstringMeta("section", "a section"))

# Generated at 2022-06-11 21:25:12.633806
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # TODO: complete test
    pass

# Generated at 2022-06-11 21:25:27.073639
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    assert(isinstance(google_parser, GoogleParser))
    docstring = google_parser.parse("Some short descr\n\nSome long descr")
    assert(docstring.short_description == "Some short descr")
    assert(docstring.blank_after_short_description == True)
    assert(docstring.blank_after_long_description == True)
    assert(docstring.long_description == "Some long descr")
    docstring = google_parser.parse("Some short descr\nSome short descr\nSome long descr")
    assert(docstring.short_description == "Some short descr")
    assert(docstring.blank_after_short_description == True)
    assert(docstring.blank_after_long_description == True)

# Generated at 2022-06-11 21:25:29.192863
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse(): # TODO
    pass



# Generated at 2022-06-11 21:25:32.465234
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert (GoogleParser().parse(None) == \
        Docstring(short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False))


# Generated at 2022-06-11 21:25:38.699738
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gdoc = """A year is a 4-digit number, such as 2016.
    
    Args:
    year: The year to convert.
    
    Returns:
    int: The number of seconds since January 1 of the given year.
    
    Raises:
    ValueError: If year is negative or greater than 9999.
    """
    res = GoogleParser().parse(gdoc)
    print(res)
    
    