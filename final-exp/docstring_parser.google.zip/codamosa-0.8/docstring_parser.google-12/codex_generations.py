

# Generated at 2022-06-11 21:16:05.973895
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:16:16.432224
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""
    parser = GoogleParser()
    D = parser.parse
    assert D(None) == Docstring()
    assert D("") == Docstring()
    assert D("\n") == Docstring()
    assert D("A\n\nB") == Docstring(
        short_description="A",
        long_description="B",
        blank_after_short_description=True,
    )
    assert D("A\n\n\nB\n\n") == Docstring(
        short_description="A",
        long_description="B",
        blank_after_short_description=True,
    )

# Generated at 2022-06-11 21:16:29.479458
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    docstring = "Hello world!"
    doc = parser.parse(docstring)
    assert doc.short_description == "Hello world!"
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 0

    docstring = "    Hello world!"
    doc = parser.parse(docstring)
    assert doc.short_description == "Hello world!"
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 0

    docstring = "Hello\nworld!"
    doc = parser.parse(docstring)
    assert doc.short

# Generated at 2022-06-11 21:16:32.018543
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
        Parse the Google-style docstring into its components.
        :returns: parsed docstring
        """
    result = parse(docstring)
    print(result)



# Generated at 2022-06-11 21:16:44.973778
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "This is the docstring summary.\n\nThis is the docstring description.\n\nArgs:\n    name (str, optional): The name for this parameter.\n    value (str): The description for the value.\n\nYields:\n    str: The description for the yield value.\n\nRaises:\n    Error: The description for the Error exception.\n"
    d = GoogleParser().parse(docstring)
    assert d.short_description == "This is the docstring summary."
    assert d.long_description == "This is the docstring description."
    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is True
    assert len(d.meta) == 5

# Generated at 2022-06-11 21:16:57.465272
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = GoogleParser().parse("""some text""")
    assert text.short_description == "some text"

    text = GoogleParser().parse("""
some text
    """)
    assert text.short_description == "some text"
    assert text.long_description == ""

    text = GoogleParser().parse("""
some text
    and longer

    """)
    assert text.short_description == "some text"
    assert text.long_description == "and longer"
    assert text.blank_after_short_description
    assert text.blank_after_long_description

    text = GoogleParser().parse("""
some text

    and longer

    """)
    assert text.short_description == "some text"
    assert text.long_description == "and longer"
    assert text.blank_after_short_description

# Generated at 2022-06-11 21:17:07.432521
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Handle a get request for all users
    Args:
        request: http request
    Returns:
        response to http request
    """

    doc = GoogleParser().parse(text)

    assert len(doc.meta) == 2
    assert doc.meta[0].description=="Handle a get request for all users"
    assert doc.meta[0].key=="description"
    assert doc.meta[1].description=="response to http request"
    assert doc.meta[1].key=="returns"
    assert doc.meta[1].type_name=="response"


# Generated at 2022-06-11 21:17:16.024893
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Tests for `GoogleParser.parse()`."""
    parser = GoogleParser()

# Generated at 2022-06-11 21:17:27.106385
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:17:38.609492
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    global __test
    __test = True
    assert parse('test') == None
    assert parse('test\n') == None
    assert parse('test\n\n') == None
    assert parse('test\ntest\n') == None

    decon = "Deconvolution and inversion in the time domain.\n"
    arg = "Parameters\n"
    before = "-----------\n"
    data_desc = "\tdata : ndarray\n\t\tArray of observed data.\n"
    dt_desc = "\tdt : float\n\t\tSampling interval in sec.\n"
    sx_desc = "\tsx : ndarray\n\t\tSource x-component vector.\n"

# Generated at 2022-06-11 21:17:57.105641
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test_GoogleParser_parse
    """
    Test that the GoogleParser can parse a Google Python style
    docstring correctly.
    """
    class Test:
        """Test class that has a Google style docstring.

        Args:
            param1 (str): The first parameter.
            param2 (str): The second parameter.

        Attributes:
            attr1 (str): The first attribute.
            attr2 (str): The second attribute.

        Examples:
            Examples should be written in doctest format, and
            should illustrate how to use the function/class.
            >>>
        """


# Generated at 2022-06-11 21:18:02.835464
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    This is a description.

    Args:
        arg1 (int): Description of arg1. Defaults to None.
        arg2 (str, optional): Description of arg2. Defaults to ''.

    Returns:
        list: Description of return value.
    '''
    parser = GoogleParser()
    doc = parser.parse(docstring)

    print(doc.short_description)
    print(doc.long_description)
    print(doc.meta[0].description)
    if doc.meta[0].is_generator:
        print(doc.meta[0].returns_type)
        print(doc.meta[0].is_generator)
    print(doc.meta[0].args)
    print(doc.meta[1].description)

# Generated at 2022-06-11 21:18:13.911363
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    with pytest.raises(ParseError):
        GoogleParser().parse("abc def:")
        GoogleParser().parse("abc def: \n")
        GoogleParser().parse("abc def: \n aaa\n")

    docstring = Docstring(
        short_description="Short description",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[
            DocstringMeta(
                args=["Args", "a: 3"],
                description="Description of the argument",
                arg_name="a",
                type_name=None,
                is_optional=None,
                default="3",
            )
        ],
    )

# Generated at 2022-06-11 21:18:26.472885
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Test with empty string
    assert GoogleParser().parse("") == Docstring()
    
    docstring = """
    Short single line summary.

    More detailed description which can be several lines.

    Args:
      arg1: The first argument.
      arg2: The second argument.

    Raises:
      ValueError: In case of invalid argument values.
      TypeError: In case of invalid argument types.
    """
    parsed = GoogleParser().parse(docstring)

# Generated at 2022-06-11 21:18:37.381737
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import DocstringReturns
    text = \
"""
    This function does something useful.

    It accepts three arguments, two of which aren't used.

    :param x: An unused argument.
    :param y: Another unused argument.
    :param z: A used argument.
    :type z: bool
    :return: Something useful.
"""
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This function does something useful."
    assert docstring.long_description == textwrap.dedent(text).strip()
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert type(docstring.meta[0]) == DocstringParam

# Generated at 2022-06-11 21:18:38.091414
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass

# Generated at 2022-06-11 21:18:44.605223
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Parse the Google-style docstring into its components.

    :param text: Google-style docstring
    :param sections: sections
    :returns: parsed docstring
    """
    docstring = GoogleParser().parse(text)
    assert len(docstring.meta) == 3
    assert docstring.meta[0].description == "Parse the Google-style docstring into its components."
    assert len(docstring.meta[1].description) == 0
    assert len(docstring.meta[2].description) == 0

# Generated at 2022-06-11 21:18:51.705644
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("     test docstring") == \
        Docstring(
            short_description="test docstring",
            long_description=None, 
            meta=[]
        )
    assert parse("     test docstring\n") == \
        Docstring(
            short_description="test docstring",
            long_description=None, 
            meta=[]
        )
    assert parse("     test docstring\n\n") == \
        Docstring(
            short_description="test docstring",
            long_description=None, 
            meta=[]
        )
    assert parse("     test docstring\n     ") == \
        Docstring(
            short_description="test docstring",
            long_description=None, 
            meta=[]
        )

# Generated at 2022-06-11 21:19:00.409903
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("GoogleParser.parse()")
    source = inspect.getsource(GoogleParser)

    # (tested_method_name, unittest_name, unittest_docstring)

# Generated at 2022-06-11 21:19:11.732832
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_docstring = """
    This is a test.

    Args:
        arg1: Parameter description
        arg2: Parameter description

    Raises:
        ValueError: If `bar` is empty.
    """
    result = GoogleParser().parse(test_docstring)

# Generated at 2022-06-11 21:19:28.811527
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_obj = GoogleParser()
    text = '''This function has a weird function signature, that is not really
    Pythonic, but it is what it is.
    '''
    # Test for when text is None
    result = test_obj.parse(None)
    assert result == Docstring(), "Expected result is {}".format(Docstring())
    
    # Test for when text is not None
    result = test_obj.parse(text)
    expected_result = Docstring(
        short_description='This function has a weird function signature, that is not really Pythonic, but it is what it is.',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description= None,
        meta= []
    )

# Generated at 2022-06-11 21:19:38.487146
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    docstring = """\
    This function solves a system of linear equations.
    Parameters
    ----------
    A : (M, M) array_like
        A square matrix.
    b : (M,) array_like
        Right-hand side vector.
    Returns
    -------
    x : (M,) ndarray
        The solution to the system A x = b.  Returned shape matches the
        shape of b.
    Raises
    ------
    LinAlgError
        If A is singular.
    """
    #a = GoogleParser()
    #print(a.parse(docstring))
    return 
    
    
    
    
    
#doc="""
#:param arg1: The first parameter.
#:param arg2: The second parameter.
#:returns: The return value.
#:raises

# Generated at 2022-06-11 21:19:50.801803
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    sample_text = "This is a sample comment\n" + \
        ":param param1: this is a \n" + \
        "param1\n" + \
        "\n" + \
        ":param param2: this is a \n" + \
        "param2\n" + \
        "\n" + \
        ":returns: this is a return\n" + \
        ":raises keyError: raises an exception\n"
    gp = GoogleParser()
    docstring = gp.parse(sample_text)

    assert docstring.short_description == "This is a sample comment"
    assert docstring.long_description == "this is a param1\nparam2"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description

# Generated at 2022-06-11 21:20:00.622845
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
returns: Return a function which is the same as func, except that it accepts
    a different number of arguments. func is called with the
    same arguments as partial.func(...partial.args, *args, **kwargs), where
    args is either a list or a tuple of positional arguments and kwargs is a
    dictionary of keyword arguments.
"""
    assert GoogleParser().parse(text).meta[0].description == "Return a function which is the same as func, except that it accepts a different number of arguments. func is called with the same arguments as partial.func(...partial.args, *args, **kwargs), where args is either a list or a tuple of positional arguments and kwargs is a dictionary of keyword arguments."

# Generated at 2022-06-11 21:20:12.079096
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    document = """
    This class describes an environment that can be used with an RL
    algorithm.

    An environment is a class that represents the task or problem
    to be solved. It exposes an interface that allows an agent
    to interact with it in order to learn how to perform the task
    optimally.

    Args:
        env(`Environment`): A gym environment.

    """

    obj = GoogleParser()

    docstring_obj = obj.parse(document)

    assert docstring_obj.long_description == """An environment is a class that represents the task or problem
to be solved. It exposes an interface that allows an agent
to interact with it in order to learn how to perform the task
optimally."""

    assert docstring_obj.meta[0].args == ['param', 'env']


# Generated at 2022-06-11 21:20:22.385861
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:20:35.122540
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:20:43.245594
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_text = """\
    Counts the number of overlapping occurrences of sub in string.

    If start or end is non-negative, the corresponding offset is used as
    the beginning or end of the sub string. If omitted or None,
    defaults to the end of the string for end and the beginning of the
    string for start.
    """

    docstring = GoogleParser().parse(test_text)
    assert docstring.short_description == "Counts the number of overlapping occurrences of sub in string."
    assert docstring.long_description == (
        "If start or end is non-negative, the corresponding offset is used as\n"
        "the beginning or end of the sub string. If omitted or None,\n"
        "defaults to the end of the string for end and the beginning of the\n"
        "string for start."
    )

# Generated at 2022-06-11 21:20:55.735456
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser."""
    parser = GoogleParser()
    docstring = parser.parse("""
    Short description.

        Long description.

    Parameters
    ----------
    a : int
        Desc of a.
    b : str, optional
        Desc of b. Defaults to x.
    c : int, optional
        Desc of c. Defaults to y.

    Yields
    ------
    str
        Foo.

    Example
    -------
    >>> foo(2, 4)
    6
    """)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    for m in docstring.meta:
        if m.args[0] == "param":
            assert m.arg_name == "a"

# Generated at 2022-06-11 21:21:07.084740
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test_parse1():
        docstring = """Example function with types documented in the docstring.

        Args:
            param1 (int): The first parameter.
            param2 (str): The second parameter.

        Returns:
            bool: The return value. True for success, False otherwise.

        """
        docStringObj = GoogleParser().parse(docstring)
        assert len(docStringObj.meta) == 2
        assert docStringObj.short_description == 'Example function with types documented in the docstring.'
        assert docStringObj.long_description == None
        #print(docStringObj.meta)
        assert type(docStringObj.meta[0]) == DocstringParam
        assert docStringObj.meta[0].args == ['param1 (int):', 'The first parameter.']
        assert docStringObj.meta[0].arg

# Generated at 2022-06-11 21:21:26.265553
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create a docstring to be parsed by parse()
    text = """
    This is a text to be parsed. It consists of
    multiple lines of text.
    """
    assert (text == parse(text).short_description)
    # Add a long description to the docstring
    text = """
    This is a text to be parsed. It consists of
    multiple lines of text.
    """.strip()
    assert (text == parse(text).long_description)
    # Add an arg section to the docstring
    text = """
    This is a text to be parsed. It consists of
    multiple lines of text.

    Args:
        arg1 (str): This is the first argument.
        arg2 (int, optional): This is the second argument.
    """.strip()
    assert (text == parse(text).short_description)

# Generated at 2022-06-11 21:21:33.431796
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """This function does something.

    Args:
      param1: The first parameter.
      param2: The second parameter.

    Returns:
      A value.
    """
    doc_string = parser.parse(text)
    print(doc_string)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:21:43.756792
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Unit test of GoogleParser.parse
    """
    parser = GoogleParser()
    docstr = """Google-style docstring parsing.

    :param text: docstring text to parse
    :param param2: another parameter
    :param param3: yet another parameter
    :param param4: and yet another parameter
    :return: parsed docstring
    :example:
        >>> from merlin.common.google_docstring_parser import parse
        >>> text = 'Test Google-style docstring parsing.'
        >>> parse(text)
        {'short_description': 'Test Google-style docstring parsing.', 'long_description': None,
        'blank_after_long_description': False, 'blank_after_short_description': False, 'meta': []}
    """
    ret = parser.parse(docstr)


# Generated at 2022-06-11 21:21:51.972572
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    description = "Sample function."
    param_name = "n"
    param_type = "int"
    param_desc = "A positive integer"
    param_default = "10"
    return_type = "None"
    return_desc = "Nothing"
    docstring = """{0}

Keyword arguments:

{1}({2}) -- {3} (default {4})
Returns: ({5}) -- {6}
""".format(
        description, param_name, param_type, param_desc, param_default, return_type, return_desc
    )

    parser = GoogleParser()
    parsed = parser.parse(docstring)
    assert parsed.short_description == description
    assert parsed.blank_after_short_description
    assert parsed.long_description is None
    assert parsed.blank_after_

# Generated at 2022-06-11 21:22:03.922298
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Method tests
    class TestClass:
        def test_method(
            self,
            param1: "Parameter 1",
            param2: "Parameter 2",
            param3: "Parameter 3",
            param4: "Parameter 4, optional",
            param5: "Parameter 5?",
        ) -> "return annotation":
            """Test method for GoogleParser.parse.

            :param param1: First parameter
            :param param2: Second parameter
            :type param2: str
            :param param3: Third parameter
            :param param4: Fourth parameter
            :type param4: str
            :param param5: Fifth parameter
            :type param5: str
            :returns: return value
            :raises: error

            """
            pass
    docstring = inspect.getdoc(TestClass.test_method)
    assert docstring

# Generated at 2022-06-11 21:22:11.571866
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Command line interface.

    Args:
        line: The line of command.
        arg: This is arg.

    Returns:
        The complete line converted to sys.argv format.

    Raises:
        ValueError: Never.
    """

# Generated at 2022-06-11 21:22:22.915112
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    *Parses* a *Google-style* docstring into its components.


    :returns: parsed docstring
    """
    # Parse docstring
    parser = GoogleParser()
    parsed = parser.parse(text)

    assert isinstance(parsed.short_description, str)
    assert isinstance(parsed.long_description, str)
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 1
    assert isinstance(parsed.meta[0], DocstringMeta)
    assert parsed.meta[0].description == "parsed docstring"
    assert parsed.meta[0].args[0] == "returns"



# Generated at 2022-06-11 21:22:27.522667
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # setup
    d = Docstring()
    text = "The short description.\n\nThe long description.\nSome more text."
    # assert
    assert GoogleParser().parse(text) == d
    # teardown

# Generated at 2022-06-11 21:22:34.037700
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:22:46.104271
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:23:17.556354
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
	google_parser = GoogleParser()
	assert google_parser.parse("")
	assert google_parser.parse("this is a docstring\n")
	assert google_parser.parse("""\
    		Parses a Google-style docstring into its components.
    		
    		Args:
    			text (str): The docstring to parse.
    		
    		Returns:
    			Docstring: The parsed docstring.
    	""")


# Generated at 2022-06-11 21:23:29.011547
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print(GoogleParser())
    print(GoogleParser().parse('''\
    Short summary.

    Long summary

    Arguments:
        a (int): the first param
        b (str): the second param

    Returns:
        int: the return value
    '''))
    print(GoogleParser().parse('''\
    Arguments:
        a (int): the first param
            with a long description
        b (str): the second param
    '''))
    print(GoogleParser().parse('''\
    Arguments:
        a (int): the first param
            with a long description

        b (str): the second param
    '''))

# Generated at 2022-06-11 21:23:35.110388
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = (
        "This is a summary\n"
        "\n"
        "This is the long description\n"
        "\n"
        "Args:\n"
        "  arg_1: Parameter\n"
        "  arg_2 (str, optional): Optional parameter\n"
        "    Defaults to None.\n"
        "\n"
        "Returns:\n"
        "  A value.\n"
        "\n"
        "Raises:\n"
        "  ValueError: An error occurred.\n"
    )
    doc = parse(text)
    assert doc.short_description == "This is a summary"
    assert doc.blank_after_short_description
    assert doc.long_description == "This is the long description"
    assert doc.blank_after_long_description

# Generated at 2022-06-11 21:23:44.546401
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """This is a description of the function.

Args:
    arg1 (str): Description of argument arg1.
    arg2 (str): Description of argument arg2.

Returns:
    str: Description of what is returned.
    """

    ret = parse(doc)
    assert len(ret.meta) == 2
    assert ret.meta[0].args[0] in PARAM_KEYWORDS
    assert ret.meta[0].args[1] == "arg1 (str)"
    assert ret.meta[0].description == "Description of argument arg1."
    assert ret.meta[1].args[0] in PARAM_KEYWORDS
    assert ret.meta[1].args[1] == "arg2 (str)"
    assert ret.meta[1].description == "Description of argument arg2."

# Generated at 2022-06-11 21:23:54.059334
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """Short description.

Long description.

Args:
    arg1 (int): Description of arg1.
    arg2 (str): Description of arg2.
        Defaults to 'hello'. Defaults to 'hello'.
"""
    parsed = parser.parse(text)

# Generated at 2022-06-11 21:24:03.357580
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.
    
    This is a long description.
    
    Arguments:
        param1 (int): The first parameter.
        param2 (str): The second parameter.
        param3 (list): The third parameter.
    
    Returns:
        int: The return value.
        str: The return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description=='This is a short description.'
    assert docstring.long_description=='This is a long description.'
    assert docstring.meta[0].description=='The first parameter.'
    assert docstring.meta[1].description=='The second parameter.'
    assert docstring.meta[2].description=='The third parameter.'

# Generated at 2022-06-11 21:24:15.949395
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert (GoogleParser(title_colon=True).parse("") ==
            Docstring())

    assert (GoogleParser(title_colon=True).parse("""\
    The first line is the short description.
    The next few lines until the first blank line is the
    long description.
    """) ==
            Docstring(
                short_description='The first line is the short description.',
                long_description='The next few lines until the first blank line is the\nlong description.',
                blank_after_short_description=False,
                blank_after_long_description=False))


# Generated at 2022-06-11 21:24:19.930723
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Args:
      param1: The first parameter.
      param2: The second parameter.
    """
    result = GoogleParser().parse(text)
    assert result
    assert result.meta
    assert len(result.meta) == 2
    assert result.short_description is None
    assert result.long_description is None



# Generated at 2022-06-11 21:24:33.676017
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from pprint import pprint
    from .common import PrettyStringIO

    def test(s, parsed):
        stream = PrettyStringIO()
        pprint(parsed, stream=stream)
        assert (
            GoogleParser().parse(s) == parsed
        ), "Parsing failed: {!r}: {}".format(s, stream.getvalue())

    # Empty strings
    test("", Docstring())
    test("\n", Docstring())
    test("\r\n", Docstring())
    test("\r\n\r\n", Docstring())

    # Simple descriptions
    test("a", Docstring(short_description="a", blank_after_short_description=False))
    test("a\n", Docstring(short_description="a", blank_after_short_description=True))

# Generated at 2022-06-11 21:24:46.003142
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''param1 (type): Description.
    param2: Description continuing.

    Raises: RuntimeError

    Returns:
        result

    '''
    docstring = GoogleParser().parse(text)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].key == "param"
    assert docstring.meta[0].args == ['param', 'param1 (type)']
    assert docstring.meta[0].description == 'Description.'
    assert docstring.meta[1].key == "param"

# Generated at 2022-06-11 21:25:13.430820
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("\nRunning unit test for method parse of class GoogleParser")
    g_parser = GoogleParser()
    test_DocString_1 = """
    Process a dataset in a batch.
    Args:
        dataset (Dataset): The dataset to process.
        batch_size (int): The batch size. Defaults to 32.
        shuffle (bool): Whether to shuffle data at each epoch. Defaults to True.
        num_workers (int): The number of processes to use. Defaults to 4.
    """

# Generated at 2022-06-11 21:25:20.603894
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    res = g.parse("Some text. \n\n    No indent. \n  \n  * Indent.\n  * More indents.\n\nExamples:\n  * Indent to match.\n  * More examples.\n\nReturns:\n  Some return.\n  \n")
    assert(res.long_description == "No indent. * Indent. More indents.")
    assert(res.short_description == 'Some text.')
    return


# Generated at 2022-06-11 21:25:29.467376
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:25:39.546876
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = '''Short description.

Long description.

Parameters
----------
a : int
    A integer.
b : bool
    A bool.
c : str, optional
    A string. Defaults to 'abc'.
    One more line.

Returns
-------
str
    A string.
'''
    ds = GoogleParser().parse(doc)
    assert ds.short_description == 'Short description.'
    assert ds.long_description == 'Long description.'
    assert len(ds.meta) == 4
    assert ds.meta[0].args == ['param', 'a : int']
    assert ds.meta[0].description == 'A integer.'
    assert ds.meta[1].args == ['param', 'b : bool']
    assert ds.meta[1].description == 'A bool.'
   