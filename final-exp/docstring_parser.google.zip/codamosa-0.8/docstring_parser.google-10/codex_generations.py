

# Generated at 2022-06-11 21:16:15.858193
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """This is the summary
    line.

    This is the description area. It is
    a multiline docstring that can easily be
    accessed using the
    .__doc__ attribute.

    This is the description area. It is used to describe
    the tests and how to use them.

    This is the description area. It is used to describe
    the tests and how to use them.

    Parameters:
        func: The function to be tested.
            Defaults to None.
        args: The arguments for the function.
        kwargs: The keyword arguments for the function.

    Returns:
        int: The return code.

    Raises:
        Exception: An exception is raised.
    """
    docstring = GoogleParser().parse(doc)

# Generated at 2022-06-11 21:16:28.619680
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:16:30.612604
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    _ = GoogleParser().parse
    _.__doc__ = GoogleParser.parse.__doc__
    yield _

# Generated at 2022-06-11 21:16:43.810084
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
        Summary line.

        Extended description.

        Attributes:
            attr1 (str): Attribute 1.
            attr2 (str): Attribute 2.

        Args:
            arg1 (str): Argument 1.
            arg2 (str): Argument 2.

        Raises:
            ImportError: If a module cannot be found.
            ValueError: If a built-in operation or function receives an argument that
                has the right type but an inappropriate value.

        Returns:
            bool: The return value. True for success, False otherwise.
        '''
    docstring = GoogleParser().parse(text)
    assert len(docstring.meta) == 9
    assert isinstance(docstring.meta[0], DocstringMeta)
    assert isinstance(docstring.meta[1], DocstringMeta)
    assert isinstance

# Generated at 2022-06-11 21:16:56.240450
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:17:01.453702
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    x = inspect.cleandoc("""
    This is a class of python.
    
    Arguments:
        a (str): the name of the first parameter
        b (int): the name of the second parameter
    Returns:
        this is the return of the function
        a: 1
        b: 2
    """)
    metas = GoogleParser().parse(x)
    print(metas)

# Generated at 2022-06-11 21:17:13.144996
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = '''
    :param arg1: This is the first argument
    :type arg1: int or float
    :param arg2: This is the second argument
    :type arg2: str, optional
    :param arg3: This is the third argument
    :type arg3: float, optional. Defaults to None.
    :raises KeyError: Raises a KeyError
    :raises TypeError: Raises a TypeError
    :raises RuntimeError: Raises a RuntimeError
    :returns: This returns something
    :rtype: int or str
    :yields: This yields something
    :ytype: float
    '''
    ans = GoogleParser().parse(doc)

# Generated at 2022-06-11 21:17:19.298865
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    This is the short description
    
    This is the long description
    
    This is a title:
    '''
    result = GoogleParser().parse(text)
    print(result)
    print(result.short_description)
    print(result.long_description)
    # print(result.meta)
if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:17:30.824992
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    raise ParseError('Can\'t infer indent from "    "')

# Generated at 2022-06-11 21:17:40.689304
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def f(a, b):
        """Test parser.

        :returns: a+b

        :param a: First number.
        :param b: Second number.

        :param c: Third number.

        :raises: TypeError
        """

    data = parse(inspect.getdoc(f))
    assert data.short_description == "Test parser."
    assert data.long_description == "    :returns: a+b"
    assert data.blank_after_short_description
    assert data.blank_after_long_description
    assert len(data.meta) == 4
    assert data.meta[0].args[0] == "param"
    assert data.meta[0].arg_name == "a"
    assert data.meta[0].description == "First number."

# Generated at 2022-06-11 21:17:57.816311
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring1 = """Shows that even if the number of lines in the short description is less than 5,\
        the number of the blank lines is still 1.\n\n    Args:\n        x: a number.\n\n
        Returns:\n        a number.\n\n        """
    docstring2 = """Shows that if the number of lines in the short description is more than 5, but less\
    than 10, the number of blank lines will be 1 anyway.\n\n        Args:\n            x: a number.\n\n
        Returns:\n            a number.\n\n        """

# Generated at 2022-06-11 21:18:06.715146
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a function.

    Parameters
    ----------
    x : int
        The first param.
    y : float
        The second param.
    Returns
    -------
    int
        The return type.
    """

    parser = GoogleParser()
    #Invoke the method to test

# Generated at 2022-06-11 21:18:18.646218
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with no parameter
    docstring = GoogleParser().parse('''This is a simple program
    I did it just to test the parse method of GoogleParser class
    ''')
    assert (docstring.short_description == None)
    assert (docstring.long_description == None)
    assert (docstring.blank_after_short_description == False)
    assert (docstring.blank_after_long_description == False)

    # Test with a short description
    docstring = GoogleParser().parse('''This is a simple program''')
    assert (docstring.short_description == 'This is a simple program')
    assert (docstring.long_description == None)
    assert (docstring.blank_after_short_description == False)
    assert (docstring.blank_after_long_description == False)

    # Test

# Generated at 2022-06-11 21:18:29.616002
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser(title_colon=True).parse("") == Docstring()
    assert GoogleParser(title_colon=False).parse("") == Docstring()

    text1 = """
        Short description.

        Long description.

        Args:
            name: str
                Parameter name.
            value: bool
                Parameter value.

        Returns:
            int
                return value.
        """


# Generated at 2022-06-11 21:18:39.674671
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test case 1
    passed = True
    try:
        GoogleParser().parse("")
    except ParseError:
        passed = False
    assert passed

    # test case 2
    passed = True
    try:
        parse("")
    except ParseError:
        passed = False
    assert passed

    # test case 3
    passed = True
    try:
        parse("\n")
    except ParseError:
        passed = False
    assert passed

    # test case 4
    passed = True
    try:
        parse(" ")
    except ParseError:
        passed = False
    assert passed

    # test case 5
    passed = True

# Generated at 2022-06-11 21:18:42.785166
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = """
    Examples
    --------
    >>> 2 + 2
    4
    """
    assert GoogleParser().parse(docstr).long_description == ">>> 2 + 2\n4"

# Generated at 2022-06-11 21:18:50.561873
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('''
    Test function.

    Args:
        param1 (str): The first parameter.
    ''').meta == [
        DocstringParam(
            args=['param', 'param1 (str)'],
            arg_name='param1',
            type_name='str',
            description='The first parameter.',
            default=None,
            is_optional=False
        )
    ]

# Generated at 2022-06-11 21:18:59.769478
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    result = GoogleParser().parse(
    """This is a short description.
    This is a long description.

    Args:
      first_arg: the first argument
      second_arg: the second argument
        This is a longer description.

    Returns:
      This is a description of what is returned.

    Raises:
      An error when something bad happens.
        Details about the bad thing that happened.

    """
    )
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert type(result.meta) == list
    assert result.meta[0].args == ['param', 'first_arg']

# Generated at 2022-06-11 21:19:11.269849
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring
    from .common import DocstringParam
    from .common import DocstringRaises
    from .common import DocstringReturns
    from .common import DocstringMeta

    global test_GoogleParser_parse

    docstring = """\
    First line.

    Second line.

    Arguments:
        x (int): The x coordinate
        y (int): The y coordinate
        z (str, optional): The z coordinate

        """
    google_parser = GoogleParser()
    r = google_parser.parse(docstring)
    assert r.short_description == "First line."
    assert r.long_description == "Second line."
    assert r.blank_after_long_description == False
    assert r.blank_after_short_description == False

# Generated at 2022-06-11 21:19:21.216726
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:19:36.048831
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse(None) == Docstring()

    # Parse description only
    doc = parser.parse("Short description.")
    assert doc.short_description == "Short description."
    assert doc.blank_after_short_description == False
    assert doc.long_description is None
    assert doc.blank_after_long_description == False

    # Parse multi-line description
    doc = parser.parse(
        """Short description.
        Long description.
        """
    )
    assert doc.short_description == "Short description."
    assert doc.blank_after_short_description == True
    assert doc.long_description == "Long description."
    assert doc.blank_after_long_description == True

    # Parse description with trailing whitespace


# Generated at 2022-06-11 21:19:48.097388
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_input = """Parses Google-style docstrings into its components.

Returns a :class:`.Docstring` instance containing the
components of the docstring.

Args:
    text: the docstring text to parse, required.

Raises:
    ValueError: if `text` is empty.

Example:
    >>> from docstring_parser import parse
    >>> parse('Tests GoogleParser.\\n\\nArgs:\\n    text: the docstring text to parse, required.')
    Docstring([
        DocstringMeta(args=['Example'], description='Tests GoogleParser.'),
        DocstringParam(args=['Args', 'text'], arg_name='text', description='the docstring text to parse, required.', type_name=None, is_optional=None, default=None),
        ])
"""


# Generated at 2022-06-11 21:19:55.777745
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Docstring Text
    Description.
    Description two.
    Description three.
    Description four.
    Description Five.
    Description Six.
    Description Seven.


    Example
    -------
    >>> x = 1
    >>> x += 1

    Arguments
    ---------
    first_thing: int or None
        The first thing not the 2nd thing

    Raise
    -----
    ValueError:
        In case there is an exception

    Returns
    -------
    y: int
        The value of y
    """

# Generated at 2022-06-11 21:20:03.929232
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("Example:")
    assert parse("Example:") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=['examples'], description=None)])
    assert parse("    Example:") == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=['examples'], description=None)])
    assert parse("Arguments:")

# Generated at 2022-06-11 21:20:15.353150
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:20:24.682776
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Args:
        param1: The first parameter.
        param2: The second parameter.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.
    """
    g = GoogleParser()
    assert g.parse(text).short_description is None
    assert g.parse(text).long_description is None
    assert g.parse(text).meta[0].description == "The first parameter."
    assert g.parse(text).meta[0].type_name is None
    assert g.parse(text).meta[0].arg_name == "param1"
    assert g.parse(text).meta[1].description == "The second parameter."
    assert g.parse(text).meta[1].type_name is None
    assert g.parse(text).meta[1].arg_name

# Generated at 2022-06-11 21:20:38.071805
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_docstring = """
    One line description.

    More detailed description. Those can span
    multiple lines.

    Args:
        arg1 (int): Description of `arg1`
        arg2 (str): Description of `arg2`. Defaults to "abc".

    Returns:
        int: Description of return value

    Raises:
        TypeError: When `arg2` is invalid.

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

        >>> a = [1, 2, 3]
        >>> print([x + 3 for x in a])
        [4, 5, 6]
    """
    test_result = GoogleParser().parse(test_docstring)

# Generated at 2022-06-11 21:20:48.696575
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:20:58.356493
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        One line summary
        Longer description

        Args:
            arg1 (int): Description of arg1
            arg2 (str): Description of arg2

        Returns:
            str: Description of return value
        """

    doc = parse(text)
    assert doc.short_description == 'One line summary'
    assert doc.long_description == 'Longer description'
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2

    assert doc.meta[0].args == ('param', 'arg1 (int)')
    assert doc.meta[0].type_name == 'int'
    assert doc.meta[0].arg_name == 'arg1'
    assert doc.meta[0].description == 'Description of arg1'

# Generated at 2022-06-11 21:21:09.178102
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    parser = GoogleParser()

    # Test Cases

    # test case 1: OK
    text1 = """
        Google-style docstring parsing.

        :returns: parsed docstring
    """
    parsed_docstring1 = parser.parse(text1)
    assert parsed_docstring1.short_description == "Google-style docstring parsing.", "Short description error"
    assert parsed_docstring1.long_description == None, "Long description error"
    assert parsed_docstring1.blank_after_short_description == False, "Blank after short description error"
    assert parsed_docstring1.blank_after_long_description == True, "Blank after long description error"
    assert parsed_docstring1.meta[0].description == "parsed docstring", "Meta error"

    # test case 2: OK
    text2

# Generated at 2022-06-11 21:21:24.229171
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    '''
    unit test for parse in GoogleParser class from google.py
    
    Parameters
    ----------
    text
        text in google style docstring
    Return
    ------
    Docstring object
    '''
    # test cases
    # text = '''
    #     This function does something.
    
    #     Args:
    #         param1: The first parameter.
    #         param2: The second parameter. Defaults to None.
    #             This is a long description.
    
    #     Returns:
    #         bool: The return value. True for success, False otherwise.
    #     '''
    # text = '''
    #     This function does something.
    
    #     Args:
    #         param1: The first parameter.
    #         param2: The second parameter. Defaults

# Generated at 2022-06-11 21:21:25.232926
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert True

# Generated at 2022-06-11 21:21:38.269305
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Summary line here.

    Extended description here.

    Args:
        arg1 (str): Description of arg1
        arg2: Description of arg2
        arg3 (int, optional): Description of arg3 (default is 0).
        arg4 (bool, optional): Description of arg4 (default is False).

    Returns:
        bool: Description of return value.
        None: Description of "None" return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
        Exception: This can be anything that inherits from Exception.

    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    #  test attribute short_description

# Generated at 2022-06-11 21:21:45.403226
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = parse("""\
    The constructor for the class.

    :param foo: The value of foo
    :type foo: int
    :param bar: The value of bar
    :type bar: str
    :param baz: The value of baz
    :type baz: str
    :raises ValueError: if something bad happens

    :returns: Nothing
    :rtype: None
    """,)

    assert doc.short_description == "The constructor for the class."
    assert doc.long_description == "The constructor for the class."
    assert doc.meta[0].description == 'The value of foo'
    assert len(doc.meta) == 5


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:21:54.318897
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Case 1: The input string is empty
    docstring = ""

    ret_docstring = GoogleParser().parse(docstring)

    # The output should be an object of class Docstring
    assert(isinstance(ret_docstring, Docstring))

    # The output should have short_description, long_description set to None
    assert(ret_docstring.short_description is None)
    assert(ret_docstring.long_description is None)
    assert(not ret_docstring.blank_after_short_description)
    assert(not ret_docstring.blank_after_long_description)
    assert(not ret_docstring.meta)

    # Case 2: The input string is only one line
    docstring = "One line doc string"

    ret_docstring = GoogleParser().parse(docstring)

    # The output should

# Generated at 2022-06-11 21:21:58.487263
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
	Arguments = 1
	Args = 2
	Parameters = 3
	Params = 4
	Raises = 5
	Exceptions = 6
	Except = 7
	Attributes = 8
	Example = 9
	Examples = 10
	Returns = 11
	Yields = 12
	
	def function(self, a, b=1, c=1, d=1, e=1, f=1, g=1, h=1, i=1, j=1, k=1, l=1, m=1, n=1, o=1, p=1, q=1, r=1, s=1, t=1, u=1, v=1, w=1, x=1, y=1, z=1):
		"""This is a docstring """


# Generated at 2022-06-11 21:22:08.885577
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        This is a short description.
    
        This is a long description.
    
        Args:
            param1: The first parameter.
            param2: The second parameter.
        
        Returns:
            The return value. True for success, False otherwise.
            The return value. True for success, False otherwise.
        
        Raises:
            KeyError: Raises an exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.long_description == "This is a long description."
    assert docstring.short_description == "This is a short description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    docstring_param = docstring.meta[0]

    assert docstring_param.description

# Generated at 2022-06-11 21:22:20.982415
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
    Docstring
    =========

    Args:
        arg1 (int) : first arg

    Return:
        int: a number
    """
    docstring = GoogleParser().parse(doc)
    assert docstring.short_description == 'Docstring'

    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == "first arg"
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == "int"
    assert docstring.meta[1].description == "a number"
    assert docstring.meta[1].type_name == "int"

    doc = """
    Docstring
    =========

    Attributes:
        arg1 (int): first arg
    """

# Generated at 2022-06-11 21:22:31.404145
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse('') == Docstring()


# Generated at 2022-06-11 21:22:43.439007
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text0 = None
    python_docstring0 = inspect.cleandoc(text0)
    Googledocstring0 = GoogleParser().parse(python_docstring0)
    assert Googledocstring0.meta == []
    assert Googledocstring0.short_description == None
    assert Googledocstring0.long_description == None
    assert Googledocstring0.blank_after_short_description == False
    assert Googledocstring0.blank_after_long_description == False

    text1 = ""
    python_docstring1 = inspect.cleandoc(text1)
    Googledocstring1 = GoogleParser().parse(python_docstring1)
    assert Googledocstring1.meta == []
    assert Googledocstring1.short_description == None
    assert Goog

# Generated at 2022-06-11 21:22:51.386417
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser() 
    text = 'Arguments:\n    \n    \n\n    '
    print(parser.parse(text).__dict__)

# test_GoogleParser_parse()

# Generated at 2022-06-11 21:23:00.387104
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "docstring"
    expected = Docstring()
    expected.short_description = "docstring"
    parser = GoogleParser()
    assert parser.parse(docstring) == expected

    docstring = "docstring\n\nlong description"
    expected = Docstring()
    expected.short_description = "docstring"
    expected.long_description = "long description"
    expected.blank_after_short_description = True
    expected.blank_after_long_description = True
    assert parser.parse(docstring) == expected

    docstring = "Args:\n    arg1: should be an int\n"
    expected = Docstring()
    expected.short_description = "docstring"
    expected.long_description = "long description"
    expected.blank_after_short_description = True
    expected.blank

# Generated at 2022-06-11 21:23:10.767142
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = """
    Parse the Google-style docstring into its components.

    This method parses a Google-style docstring into its components.

    Parameters
    ----------
    text : str
        The docstring to parse.

    Returns
    -------
    docstring : Docstring
        The parsed docstring.

    Raises
    ------
    ParseError
        If the docstring is malformed.
    """
    result = parse(d)
    assert len(result.meta) == 3
    assert result.short_description == "Parse the Google-style docstring into its components."
    assert result.long_description == "This method parses a Google-style docstring into its components."
    assert result.meta[0].description == "The docstring to parse."
    assert result.meta[1].description == "The parsed docstring."

# Generated at 2022-06-11 21:23:19.693786
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = inspect.cleandoc("""\
        Single argument.

        Args:
          arg: argument description
        """)

    docstring = GoogleParser().parse(doc)

    # Check attributes
    assert docstring.short_description == 'Single argument.'
    assert docstring.long_description is None
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    # Check elements
    assert docstring.meta[0].key == "param"
    assert docstring.meta[0].description == "argument description"
    assert docstring.meta[0].arg_name == "arg"

    # Check stringification
    assert str(docstring.meta[0]) == 'arg: argument description'



# Generated at 2022-06-11 21:23:30.759099
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    Summary line.

    Extended description.

    Args:
      arg1: Description of arg1
      arg2: Description of arg2

    Returns:
      Description of return value.

    Raises:
      IOError: An error occurred accessing the bigtable.Table object.
    """
    google_ds = GoogleParser().parse(text)
    assert google_ds.short_description == "Summary line."
    assert google_ds.long_description == "Extended description."
    assert len(google_ds.meta) == 3
    assert isinstance(google_ds.meta[0], DocstringParam)
    assert isinstance(google_ds.meta[1], DocstringReturns)
    assert isinstance(google_ds.meta[2], DocstringRaises)



# Generated at 2022-06-11 21:23:42.342994
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test function parse
    def parse(text):
        return GoogleParser().parse(text)

    # Test method parse

    assert(
        repr(parse('Test function.\n\n')) ==
        repr(
            inspect.cleandoc(
                '''
                Test function.
                '''
            )
        )
    )

    assert(
        repr(parse('Test function.\n\nArguments:\n  arg1 (str): description\n')) ==
        repr(
            inspect.cleandoc(
                '''
                Test function.

                Arguments:
                  arg1 (str): description
                '''
            )
        )
    )


# Generated at 2022-06-11 21:23:53.468789
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Simple Google-style docstring.

    Short description.

    Long description.

    Args:
        param1 (str): The first parameter.
        param2 (str, optional): The second parameter. Default: None.

    Raises:
        ValueError: if something bad happens.

    Returns:
        str: The return value.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == 'Simple Google-style docstring.'
    assert doc.long_description == 'Long description.'
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    
    assert len(doc.meta) == 4
    assert isinstance(doc.meta[0], DocstringParam)
    assert isinstance(doc.meta[1], DocstringRaises)

# Generated at 2022-06-11 21:24:02.973571
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser."""
    test_content = '''
    Single line summary.

    Extended description.

    Attributes:
        arg1 (int): The arg1.
        arg2 (str): The arg2.
        arg3 (bool, optional): The arg3 (default True).

    Returns:
        str: The return value.

    Raises:
        AttributeError: The exception description.
        TypeError: The exception description.

    Examples:
        Examples should be written in doctest format, and
        should illustrate how to use the function/class.
        >>>
    '''
    parser = GoogleParser()
    docstring = parser.parse(test_content)
    print(docstring)
    return docstring

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:24:15.763254
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    from .common import Docstring

    assert GoogleParser().parse('') == Docstring()

    # Check description only
    assert GoogleParser().parse('Description only') == Docstring(
        short_description='Description only',
        blank_after_short_description=False,
    )

    assert GoogleParser().parse('\nDescription only') == Docstring(
        short_description='Description only',
        blank_after_short_description=True,
    )

    # Check short and long descriptions
    assert GoogleParser().parse('Short description\n\nLong description') == Docstring(
        short_description='Short description',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description='Long description',
    )


# Generated at 2022-06-11 21:24:23.121504
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Converts this number to a Python :class:`int` object.

    Arguments:
        int: an integer number

    Return
        int: a Python number

    Raises:
        TypeError: if object is not a number or of an appropriate type

    """

# Generated at 2022-06-11 21:24:36.766836
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:24:47.438836
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert isinstance(parser, GoogleParser)

    text = """
    Single-line docstring
    """
    ret = parser.parse(text)
    assert isinstance(ret, Docstring)
    assert not ret.meta
    assert ret.short_description == "Single-line docstring"
    assert not ret.long_description

    text = """
    Single-line docstring with whitespace.
    """
    ret = parser.parse(text)
    assert isinstance(ret, Docstring)
    assert not ret.meta
    assert ret.short_description == "Single-line docstring with whitespace."
    assert not ret.long_description

    text = """
    Single-line docstring
    with whitespace.
    """
    ret = parser.parse(text)

# Generated at 2022-06-11 21:24:57.817234
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    description = """\
    This is a description.
    
    This is a long description.
    
    Example:
    
      This is an example.
    
    Example:
    
      This is another example.
    """
    desc_text = '\n    This is a description.\n    This is a long description.\n'
    doc = {
        'Args': '\n      This is an example.\n    ',
        'Args2': '\n      This is another example.\n    ',
        'Attributes': '\n      This is an attribute.\n    ',
    }
    assert parse(description).short_description == 'This is a description.'
    assert parse(description).long_description == 'This is a long description.'

# Generated at 2022-06-11 21:25:08.350085
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Testing method parse of class GoogleParser"""

# Generated at 2022-06-11 21:25:18.252173
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = '''
        This is a short description.

        This is a long description. This is a continued line.
            This is a continued again.

        Args:
            first_arg: Description of first arg.
            second_arg: Description of second arg.

        Returns:
            Description of return value.
    '''

# Generated at 2022-06-11 21:25:28.178624
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = '''
        This is the short description.

        This is the long description.  It is separated from the short
        description by a blank line.

        Args:
            param1: Description of `param1`.
            param2: Description of `param2`.
            param3: Description of `param3`.

        Raises:
            AttributeError, KeyError

        Returns:
            Description of return value.
        '''
    d = parser.parse(text)
    print(d)
#   import pdb; pdb.set_trace()

# Generated at 2022-06-11 21:25:39.114759
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Three ways to write docstring - first form
    docstring = '''
    This method does something.

    Args:
        param1 (str): The first parameter.
        param2 (Optional[str]): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``AttributeError`` exception.
        ValueError: The ``ValueError`` exception.
    '''
    # three ways to write docstrings - second form