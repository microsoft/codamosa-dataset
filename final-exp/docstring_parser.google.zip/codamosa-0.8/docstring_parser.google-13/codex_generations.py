

# Generated at 2022-06-11 21:16:17.301806
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:16:30.381005
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import numpy as np
    from .common import DocstringParam, DocstringReturns, DocstringRaises

    dp = DocstringParam
    dr = DocstringReturns
    da = DocstringRaises

# Generated at 2022-06-11 21:16:43.689074
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = GoogleParser().parse

    # test basic cases
    assert doc("") == Docstring()
    assert doc("a") == Docstring(short_description="a")
    assert doc("a\n\nb") == Docstring(
        short_description="a\nb", blank_after_long_description=True
    )
    assert doc("a\nb") == Docstring(short_description="a", long_description="b")
    assert doc("a\n\nb") == Docstring(
        short_description="a",
        blank_after_short_description=True,
        long_description="b",
        blank_after_long_description=True,
    )

    # test arguments

# Generated at 2022-06-11 21:16:56.156117
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """
    Hello world!

    Args:
        arg1: The first argument.
        arg2: The second argument.

        Args:
            arg3: The third argument.
            arg4: The fourth argument.
    """

# Generated at 2022-06-11 21:16:56.846994
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass



# Generated at 2022-06-11 21:17:10.181798
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """\
        Module summary line.

        Module description.

        Args:
        name (str): function name. Defaults to "World".

        Returns:
        str: A message.
        """
    parsed = parse(docstring)
    assert parsed.short_description == "Module summary line."
    assert parsed.long_description == "Module description."
    assert len(parsed.meta) == 1
    _meta = parsed.meta[0]
    assert _meta.args == ["param", "name (str)"]
    assert _meta.description == "function name. Defaults to \"World\"."
    arg_name, type_name = _meta.arg_name, _meta.type_name
    assert arg_name == "name"
    assert type_name == "str"
    assert _meta.is_optional

# Generated at 2022-06-11 21:17:22.652759
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr="""Arithmetic functions.

    The following operations are supported.  Operands must be any numeric
    type.  Addition, subtraction, multiplication and (true) division yield
    the sum, difference, product or quotient.  Exponentiation is supported
    for integer exponents via the pow() function.
    """
    p = GoogleParser()
    doc = p.parse(docstr)
    assert docstr == str(doc)

# Generated at 2022-06-11 21:17:34.525933
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("Test") == Docstring(short_description="Test")
    assert parse("Test\n") == Docstring(short_description="Test")
    assert parse("Test\n\n") == Docstring(short_description="Test")
    assert parse("Test\n\nArguments:") == Docstring(
        short_description="Test", meta=[DocstringMeta(args=("Arguments",), description=None)]
    )
    assert parse("Test\n\nArgs:") == Docstring(
        short_description="Test", meta=[DocstringMeta(args=("Args",), description=None)]
    )

# Generated at 2022-06-11 21:17:42.266079
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:17:54.614399
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    """
    Test method parse of class GoogleParser
    
    1. Testing the description of the module with all the sections described
    2. Testing the description of the method with no sections (no params, no raises , no returns and no yields)
    3. Testing the description of the method with one or more sections having no argument
    4. Testing the description of the methods with one or more sections having one or more arguments

    """

    p=GoogleParser()


    #1. Testing the description of the module with all the sections described

    docstring = '''Some text here.
    Args:
    arg1:
    arg2:

    Returns:
    result: integer -- the sum of the three inputs

    Raises:
    AttributeError
    '''

    assert p.parse(docstring).short_description == 'Some text here.'

# Generated at 2022-06-11 21:18:33.010776
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    class Test:

        @parse
        def doc1(self) -> str:
            """Test docstring.

            Arguments:
                id: UUID of the entry.
                name (optional): Name of the entity.
                address: The address.
                excluded: Should not be used.

            Returns:
                Some text.
            """

        @parse
        def doc2(self) -> str:
            """Test docstring.

            Parameters:
                id (int): A unique identifier.
                    Missing docstring comment.
                name (optional) (str): The name. It should not have a colon at
                    the end.
                    For more info see the :any:`function` documentation.

            Returns:
                Some text.
            """


# Generated at 2022-06-11 21:18:41.849068
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def f():
        """Short description.
        Long description.

        Args:
            arg1: (str, optional) arg1 description. Defaults to "arg1 default".
            arg2 (str): arg2 description.

        Returns:
            str: returns description.
        Yields
            int: yields description.
        """
        pass


# Generated at 2022-06-11 21:18:49.841646
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:18:58.726528
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .example_google import DESCR, DESCR_2
    DESCR = (
        "Calculate the greatest common divisor of a and b.\n\n"

        + DESCR[DESCR.index("Args:"):]
    )
    doc = GoogleParser().parse(DESCR)
    print(doc)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.meta)
    doc = GoogleParser().parse(DESCR_2)
    print(doc)
    print(doc.short_description)
    print(doc.long_description)
    print(doc.meta)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:19:09.878632
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Short description.

    Long description.

    Args:
        x: First param.
        y: Second param.

    Kwargs:
        z: Third param.

    Returns:
        Some value.
    """
    r = GoogleParser().parse(text)
    assert r.short_description == 'Short description.'
    assert r.blank_after_short_description == False
    assert r.long_description == 'Long description.'
    assert r.blank_after_long_description == True
    assert len(r.meta) == 2

    assert r.meta[0].args == ['param', 'x: First param.']
    assert r.meta[0].arg_name == 'x'
    assert r.meta[0].description == 'First param.'
    assert r.meta[0].type_name == None

# Generated at 2022-06-11 21:19:17.046597
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test method parse of class GoogleParser"""
    from .common import DocstringParam
    from .common import DocstringReturns
    from .common import DocstringRaises
    from .common import Docstring
    from .common import DocstringMeta

# Generated at 2022-06-11 21:19:29.780988
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
        Short summary.

            Long description.

        Arguments:
            arg1: A positional argument.
            arg2 (str): A keyword argument. Defaults to "arg2".
            arg3: A positional argument with the same name as the class.

        Returns:
            One or more values.
        '''
    result = GoogleParser().parse(text)

# Generated at 2022-06-11 21:19:34.423816
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google = GoogleParser()
    docstring = google.parse("""\
        Google-style docstring parsing.
        
        :returns: parsed docstring
        """
        )
    return docstring.long_description == 'parsed docstring'


# Generated at 2022-06-11 21:19:40.584889
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ds = Docstring()
    ds.short_description = \
"""
    Short desc.
    """
    ds.blank_after_short_description = False
    ds.blank_after_long_description = False
    ds.long_description = \
"""Long desc on two lines.
    """

    # Add elements from each chunk
    ds.meta.append(
        DocstringParam(
            args=["param", "param xy (str)"],
            description="\n        Long desc.\n        ",
            arg_name="xy",
            type_name="str",
            is_optional=False,
            default=None,
        )
    )

# Generated at 2022-06-11 21:19:52.295290
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse(
        """Examples::
            >>> foo = 'bar'
        """
    )
    assert docstring.short_description == "Examples:"
    assert docstring.long_description == ">>> foo = 'bar'"
    assert len(docstring.meta) == 1

    docstring = GoogleParser().parse(
        """Examples:
        >>> foo = 'bar'
        """
    )
    assert docstring.short_description == "Examples:"
    assert docstring.long_description == ">>> foo = 'bar'"
    assert len(docstring.meta) == 1

    docstring = GoogleParser().parse(
        """Examples:\n
        >>> foo = 'bar'
        """
    )
    assert docstring.short_description == "Examples:"

# Generated at 2022-06-11 21:20:04.324092
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    docstring = '''Args:
  x (int): The first paramter.
  y (int): The second parameter.
'''

    doc = GoogleParser().parse(docstring)
    assert isinstance(doc.meta, list)
    assert doc.meta[0].args == ['param', 'x (int)']

    docstring = '''Args:
  x: The first paramter.
  y: The second parameter.
'''

    doc = GoogleParser().parse(docstring)
    assert isinstance(doc.meta, list)
    assert doc.meta[0].args == ['param', 'x']

    docstring = '''Args:
  x: The first paramter.
  y: The second parameter.

Returns:
  int: The return value.
'''

    doc = GoogleParser().parse(docstring)

# Generated at 2022-06-11 21:20:14.989119
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def func(a: int=0, b: int=1, *args, c: int=0, d: int=0, **kwargs) -> int:
        """Test function for Google docstring parsing.

        :param a: test parameter a.
        :param b: test parameter b. Defaults to 1.
        :param c: test parameter c.
        :param d: test parameter d. Defaults to 0.
        :raises: StandardError

        :Example:

        >>> func(1, 2)
        """
        return a + b + c + d

    print(func.__doc__)
    print(GoogleParser().parse(func.__doc__))

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:20:24.463088
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = "Description string.\
        \n\
        \nMore description string.\
        \n    \
        \nMore description string.\
        \n\
        \nReturns\
        \nstring or None, something or None.\
        \n    \
        \nRaises\
        \nSomeException, SomeException.\
        \n    \
    "
    r = parse(d)
    assert r.short_description == "Description string."
    assert r.long_description == "More description string.\n    \nMore description string."
    assert r.blank_after_short_description == True
    assert r.blank_after_long_description == False
    assert r.meta[0].description == "string or None, something or None."

# Generated at 2022-06-11 21:20:37.853674
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "one\n\ntwo\n  three\n\nParameters:\n  first: one\n    two\n  second: three\n\nReturns:\n  Return one\n  two\n"

# Generated at 2022-06-11 21:20:44.434404
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "    Test whether all elements evaluate to True (or if the iterable \
is empty).\n    \n    This is equivalent to::\n\n        def all(iterable):\n            for element in iterable:\n                if not element:\n                    return False\n            return True\n\n    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "Test whether all elements evaluate to True (or if the iterable is empty)."
    assert docstring.long_description == "This is equivalent to::\n\n    def all(iterable):\n        for element in iterable:\n            if not element:\n                return False\n        return True"
    assert len(docstring.meta) == 0

# Generated at 2022-06-11 21:20:56.372431
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = " This is a multiline description. \n\n" + \
                " :param param: A description of 'param'. \n" + \
                " :type param: str\n" + \
                " :param param: A description of 'param'. \n" + \
                " :type param: int\n" + \
                " :rtype: str\n" + \
                " :raises error: An error occurs\n" + \
                " :returns: A description.\n" + \
                " :examples: This is a multiline example.\n" + \
                " :yields: A description of yielded values.\n"
    parser = GoogleParser()
    docstring = parser.parse(docstring)


# Generated at 2022-06-11 21:21:07.705941
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Parsing top level docstring of module `google`
    test_module = __import__("google")
    parser = GoogleParser()
    result = parser.parse(test_module.__doc__)
    assert result.short_description == "`google` - Simple, lightweight, efficient Python client for Google APIs."
    assert result.blank_after_short_description

# Generated at 2022-06-11 21:21:15.036053
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """This is my docstring.

Args:
    a: first argument.
    b: second argument. Defaults to True.

    c: third argument.

    d: fourth argument. Defaults to None.

Raises:
    ValueError: when a is invalid.
    ValueError: when b is invalid.
    ValueError: when c is invalid.
    ValueError: when d is invalid.

Returns:
    list: The list of results
"""
    meta = GoogleParser().parse(text).meta
    assert isinstance(meta[0], DocstringMeta)
    assert meta[0].args == []
    assert meta[0].description == """This is my docstring."""

    assert isinstance(meta[1], DocstringParam)
    assert meta[1].args == ["param", "a"]

# Generated at 2022-06-11 21:21:23.981448
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Short description.

    Long description.

    Returns:
        str: Some return value.
    """
    p = GoogleParser()
    d = p.parse(docstring)

    assert d.short_description == 'Short description.'
    assert d.blank_after_short_description
    assert d.long_description == 'Long description.'
    assert d.blank_after_long_description
    assert d.meta[0].description == 'Some return value.'
    assert d.meta[0].args[0] == 'returns'
    assert d.meta[0].type_name == 'str'



# Generated at 2022-06-11 21:21:37.115152
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Parse an empty docstring
    docstring = GoogleParser().parse("")
    assert docstring == Docstring()

    # Parse a minimal
    docstring = GoogleParser().parse("short description")
    assert docstring.short_description == "short description"
    assert docstring.long_description == None

    # Parse long description
    docstring = GoogleParser().parse("Short description\n\nLong description.")
    assert docstring.short_description == "Short description"
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_long_description == False

    docstring = GoogleParser().parse("Short description\nLong description.")
    assert docstring.short_description == "Short description"
    assert docstring.blank_after_short

# Generated at 2022-06-11 21:21:51.771308
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    >>> text = '''One-line summary.
    ...
    ... Extended description.
    ...
    ... Args:
    ...     arg_1: Something about the arg_1.
    ...     arg_2: Something about the arg_2.
    ...
    ... Returns:
    ...     Something about the return value.
    ... '''
    >>> p = GoogleParser()
    >>> print(p.parse(text))
    One-line summary.
     
    Extended description.
     
    args: arg_1
        Something about the arg_1.
     
    args: arg_2
        Something about the arg_2.
     
    returns:
        Something about the return value.
    <BLANKLINE>
    """



# Generated at 2022-06-11 21:22:03.677887
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test for method GoogleParser.parse
    """

    def check(text, expected):
        docstring = parse(text)
        assert docstring.short_description == expected
        print("docstring", docstring.__dict__)

    #testing short description
    check("Short description.", "Short description.")
    check("Short description.\nLine two.", "Short description.")
    check("Short description.\n\nLong description.", "Short description.")
    check("Short description.\n\n  Long description.", "Short description.")
    check("Short description.\n\n\nLong description.", "Short description.")
    check("Short description.\n\n  Long description.", "Short description.")
    check("Short description.\n\n\n  Long description.", "Short description.")

# Generated at 2022-06-11 21:22:11.453581
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    inspect.cleandoc('')
    GoogleParser()
    docstring = '''
        """Short description.

        Long description.

        Args:
          x: first argument

        Returns:
          Nothing

        Raises:
          ValueError: if x is zero
        """
    '''
    parsed_docstring = GoogleParser().parse(docstring)

# Generated at 2022-06-11 21:22:23.314881
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from pprint import pprint
    
    class A:
        """
        Args:
            arg1 (int): The first argument.
            arg2 (int): The second argument.

        Attributes:
            attr1 (int): The first attribute.
            attr2 (int): The second attribute.
        
        Raises:
            ValueError: If something is wrong.
            
        Returns:
            None
        """
        pass

    class B:
        """
        arg1 (str): The first argument.
        arg2 (str): The second argument.

        attr1 (str): The first attribute.
        attr2 (str): The second attribute.

        raises ValueError: If something is wrong.
        returns None
        """
        pass


# Generated at 2022-06-11 21:22:26.378634
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print(parse.__doc__)


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:22:33.600502
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    docstr = """
    See Also
    --------
    str : equivalent method for str

    Returns
    -------
    bool
        boolean

    Raises
    ------
    ValueError
        If this is specified,
        then the exception is raised.

    Notes
    -----
    This is a note.

    Examples
    --------
    This is an example.

    """

    doc_obj = GoogleParser().parse(docstr)
    assert doc_obj.short_description == 'See Also'
    assert doc_obj.long_description == 'equivalent method for str'
    assert doc_obj.blank_after_short_description == True
    assert doc_obj.blank_after_long_description == True

    assert doc_obj.meta[0].args == ['returns', 'bool']

# Generated at 2022-06-11 21:22:45.703183
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:22:52.639528
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Unit test of method parse of class GoogleParser.
    """
    parser = GoogleParser()
    # Initialize docstring
    docstring = '''
    Computes the sum of all element along axis.

    Args:
        axis (int): The axis that is collapsed.
        skipna (bool): If True, missing values are skipped.

    Returns:
        numpy.ndarray: A new array with the sum of elements.
    '''
    # Parse docstring
    parsed_docstring = parser.parse(docstring)
    # Check results
    assert parsed_docstring.short_description == "Computes the sum of all element along axis"
    assert parsed_docstring.blank_after_short_description == False
    assert parsed_docstring.long_description == None
    assert parsed_docstring.blank_after_long

# Generated at 2022-06-11 21:22:59.728732
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """This is a Google-style docstring.

Args:
    param1: The first parameter.
    param2: The second parameter.
        Defaults to 2.

Returns:
    None

Raises:
    ValueError:
        If `param2` is equal to `param1`.
"""
    doc_google = GoogleParser().parse(docstring)
    print("Short description:", doc_google.short_description)
    print("Long description:", doc_google.long_description)
    for meta in doc_google.meta:
        print(meta.args, meta.description)
    return doc_google



# Generated at 2022-06-11 21:23:02.909101
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def func():
        """Does something.

        Raises:
            ValueError: If something malicious happens.

        Yields:
            str: The next thing that happens.

        """
        return
    print(GoogleParser().parse(func.__doc__))

# Generated at 2022-06-11 21:23:19.150116
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ret = parse("")
    assert isinstance(ret, Docstring)
    assert ret.short_description == None
    assert ret.long_description == None
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert isinstance(ret.meta, list)
    assert len(ret.meta) == 0

    ret = parse("Short description.")
    assert ret.short_description == "Short description."
    assert ret.long_description == None
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert isinstance(ret.meta, list)
    assert len(ret.meta) == 0

    ret = parse("Short description.\nLong description.")
    assert ret.short_description == "Short description."


# Generated at 2022-06-11 21:23:30.439190
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create a GoogleParser object
    parser = GoogleParser()
    # Test case where text is None
    res = parser.parse(None)
    assert res.short_description is None, "test_GoogleParser_parse: TypeError"
    assert res.long_description is None, "test_GoogleParser_parse: TypeError"
    assert res.meta == [], "test_GoogleParser_parse: TypeError"
    assert res.blank_after_short_description == False, "test_GoogleParser_parse: TypeError"
    assert res.blank_after_long_description == False, "test_GoogleParser_parse: TypeError"
    # Test case where text is an empty string
    res = parser.parse("")
    assert res.short_description is None, "test_GoogleParser_parse: TypeError"
    assert res.long_description

# Generated at 2022-06-11 21:23:42.094361
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert (GoogleParser().parse('') == Docstring())                        # case where docstring is ''
    text = '''  
    This is for testing purposes.
    '''
    assert (GoogleParser().parse(text) == Docstring(short_description='This is for testing purposes.',
                                                    blank_after_short_description=True,
                                                    blank_after_long_description=True,
                                                    long_description=None,
                                                    meta=[]))                                            # where only short_desc is given
    text = '''  
    This is for testing purposes.
    
    This is the long description part.
    '''

# Generated at 2022-06-11 21:23:53.307342
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    s = inspect.cleandoc('''
        """Docstring.

        Parameters:
            a: integer
            b: integer

        Returns:
            integer: sum of a and b.
            0 if a or b is none.

        Raise:
            ValueError: if a and b are not integers.
        """''')
    result = GoogleParser().parse(s)

    assert result.short_description.startswith("Docstring")
    assert result.short_description.endswith(".")

    assert result.long_description is None
    assert result.blank_after_short_description is False

    assert len(result.meta) == 3

    assert len(result.meta[0].args) == 2
    assert result.meta[0].args[0] == "param"

# Generated at 2022-06-11 21:23:58.778910
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text ="""
            Parses the Google-style docstring into its components.

            Example:

            Args:
              text (str): The docstring to parse.

            Returns:
              Docstring: The parsed result.

            Raises:
              ParseError: if some error happened.

            """
    print(parse(text))

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:24:07.339067
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = "Sentence [1].\n\nSentence [2] line1\nline2.\n\n"
    short_description = "Sentence"
    long_description = "Sentence [1] line1\nline2."
    ret = GoogleParser().parse(doc)
    assert ret.short_description == short_description, "Short description failed"
    assert ret.long_description == long_description, "Long description failed"


# Generated at 2022-06-11 21:24:18.449568
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for method parse of class GoogleParser"""
    print("Testing method parse of class GoogleParser ...")
    gdp = GoogleParser()
    # Example from https://github.com/google/styleguide/blob/gh-pages/pyguide.md#38-comments-and-docstrings
    example_docstring = """Summary line for function.
    
    Extended description of function.
    
    Args:
        param1 (str): Description of param1
        param2 (:obj:`int`, optional): Description of param2
    
    Returns:
        bool: Return description
    """
    parsed_docstring = gdp.parse(example_docstring)
    assert parsed_docstring.short_description == "Summary line for function."
    assert parsed_docstring.long_description == "Extended description of function."
    #

# Generated at 2022-06-11 21:24:32.366828
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Tests for method parse of class GoogleParser
    """
    parser = GoogleParser()
    text = (
        "Get the index of the reference sequence, given the name.\n"
        "\n"
        "Args:\n"
        "  name (str): The name of the reference sequence.\n"
        "\n"
        "Returns:\n"
        "  int: Index of the sequence.\n"
        "\n"
        "Raises:\n"
        "  ValueError: If the sequence name is missing.\n"
    )
    # (
    #     {
    #         'short_description': 'Get the index of the reference sequence, given the name.',
    #         'long_description': '',
    #         'blank_after_short_description': True,
    #         'blank_after

# Generated at 2022-06-11 21:24:38.663583
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert (GoogleParser().parse("Hello World")) == Docstring(short_description='Hello World')
    assert (GoogleParser().parse("""Hello World
This is the long description
    """)) == Docstring(short_description='Hello World', blank_after_short_description=True, blank_after_long_description=False, long_description='This is the long description')
    assert (GoogleParser().parse("""Hello World

This is the long description
    """)) == Docstring(short_description='Hello World', blank_after_short_description=True, blank_after_long_description=True, long_description='This is the long description')

# Generated at 2022-06-11 21:24:48.462920
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for method parse of class GoogleParser."""
    text = """
    A function that does something.

    Parameters
    ----------
    arg1: int
        Description of arg1. Defaults to 0.
    arg2: bool, optional
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """

    docstring = GoogleParser().parse(text)

    assert docstring.description == text
    assert not docstring.params
    assert not docstring.returns
    assert not docstring.yields
    assert not docstring.exceptions
    assert docstring.meta
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].default == "0"
    assert docstring.meta[1].description == "Description of arg2."

# Generated at 2022-06-11 21:25:03.970293
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    '''
    Test doctstrings
    '''
    docstr = '''Test of method parse
    This is a test method
    Args:
        x : integer
        y : integer
    Returns:
        x + y or 0 if an error occurs
    '''
    docstr_parsed = GoogleParser().parse(docstr)
    assert docstr_parsed.short_description == 'Test of method parse'
    assert docstr_parsed.long_description == 'This is a test method'
    assert docstr_parsed.meta[0].args[1] == 'x : integer'
    assert docstr_parsed.meta[0].description == ''
    assert docstr_parsed.meta[1].args[1] == 'y : integer'

# Generated at 2022-06-11 21:25:09.914397
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_docstring = '''A very simple Google-style docstring.

    Extended description of function.

    Args:
      param1: The first parameter.
      param2: The second parameter.
      *args: Variable length argument list.
      **kwargs: Arbitrary keyword arguments.

    Returns:
      True if successful, False otherwise.

    Raises:
      AttributeError, KeyError

    '''
    parser = GoogleParser()
    ds = parser.parse(test_docstring)
    print(ds)


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:25:20.479068
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Parses Google-style docstring.

    Example:
        >>> text = \"\"\"
        ...    Parses Google-style docstring.
        ...
        ...        Args:
        ...            text (str): text to be parsed
        ...        Returns:
        ...            Docstring: parsed docstring
        ...    \"\"\"
        >>> docstring = GoogleParser().parse(text)
        >>> print(docstring)
        <BLANKLINE>
        <BLANKLINE>

    :returns: parsed docstring
    """
    result = GoogleParser().parse(text)
    assert result.short_description == "Parses Google-style docstring."
    assert result.blank_after_short_description == False

# Generated at 2022-06-11 21:25:29.385581
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test function
    def f():
        '''
        This is a Google-style docstring.

        Args:
            filename (str): Name of the file.
            module (str): Name of the module.

        Returns:
        list: A list of lines.

        Raises:
            NameError
        '''
    # parse
    d = parse(f.__doc__)
    print(d.long_description)
    print(d.short_description)
    for e in d.meta:
        print(e.description)
    assert len(d.meta) == 5
    assert d.short_description == "This is a Google-style docstring."
    assert d.blank_after_long_description
    assert d.blank_after_short_description
    print('test ok')

# call test function
test

# Generated at 2022-06-11 21:25:39.517484
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test docstring with everything
    docstring = """
    A short summary.

    A long description.

    Args:
        arg1 (str): Description of `arg1`.
        arg2 (int): Description of `arg2`.

    Raises:
        ValueError: Error description.

    Yields:
        str: A string.

    Examples:
        >>> print(3)
        3
    """
    google_parser = GoogleParser()
    docstring = google_parser.parse(docstring)
    assert len(docstring.meta) == 5
    # Args
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "Description of `arg1`."
    assert docstring.meta[0].arg_name == "arg1"