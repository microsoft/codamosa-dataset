

# Generated at 2022-06-11 21:16:19.825438
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import DocstringParam, DocstringRaises, DocstringReturns

    method_google_parser_parse_google_parser_google_parser = GoogleParser()
    method_google_parser_parse_text = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring

    Raises:
        RuntimeError: if argument `text` cannot be parsed.
    """

# Generated at 2022-06-11 21:16:31.688742
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Args:
        text (str): The text.
        indent (int): The indent.
    Returns:
        Docstring.
    '''
    ret = GoogleParser().parse(text)
    assert ret.short_description == None
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert ret.long_description == None
    assert ret.meta[0].args == ['param', 'text (str)']
    assert ret.meta[0].description == 'The text.'
    assert ret.meta[0].arg_name == 'text'
    assert ret.meta[0].type_name == 'str'
    assert ret.meta[0].is_optional == False
    assert ret.meta[0].default == None
    assert ret.meta

# Generated at 2022-06-11 21:16:44.759861
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # tested method
    from docstring_parser import GoogleParser
    # dependency function
    from docstring_parser import DocstringParam

# Generated at 2022-06-11 21:16:57.252551
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .google import GoogleParser
    gp = GoogleParser()
    s = '''
    def func_name(spam: str = 'eggs', eggs: int = 42) -> str:
        '''
    result = gp.parse(s)
    assert result
    assert result.short_description is None
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert len(result.meta) == 2
    assert isinstance(result.meta[0], DocstringParam)
    assert isinstance(result.meta[1], DocstringReturns)
    param = result.meta[0]
    assert param.args == ['param', 'spam']
    assert param.description is None
    assert param.arg_name == 'spam'

# Generated at 2022-06-11 21:17:10.510164
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:17:22.976523
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    data = """
    Test multi-line options by emphasizing
    readability and simplicity.

    :param str name: The name of the person.
    :param optional int age: The age of the person.
         Defaults to 28.
    :param list favorites:
         A list of the person's favorite things.
         Defaults to an empty list.
    :returns: True if OK, False otherwise.

    Examples:
        >>> parse('hello world')
        True
    """
    doc = parser.parse(data)
    assert doc.short_description == 'Test multi-line options by emphasizing\nreadability and simplicity.'
    assert doc.blank_after_short_description == True

# Generated at 2022-06-11 21:17:34.901230
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for empty string
    docstring = parse("")
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    # Test for short description only
    docstring = parse("short description")
    assert docstring.short_description == "short description"
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    # Test for multiline short description
    docstring = parse("short description\n  more text")
    assert docstring.short_description == "short description more text"


# Generated at 2022-06-11 21:17:39.786629
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'this is a example'
    gp = GoogleParser()
    docstring = gp.parse(text)
    assert docstring.short_description == 'this is a example'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == None
    assert docstring.blank_after_long_description == None
    assert len(docstring.meta) == 0


# Generated at 2022-06-11 21:17:50.718233
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    readme = """
    This is an example docstring.

    This is a longer description.

    Args:
        arg_a: Description of arg_a.
        arg_b: Description of arg_b.
        arg_c (str): Description of arg_c.
        arg_d (int): Description of arg_d.
        arg_e (str, optional): Description of arg_e. Defaults to None.
        arg_f (str, optional): Description of arg_f. Defaults to 'whatever'.
        arg_g (DataType): Description of arg_g. Defaults to DataType(...).

    Returns:
        str: Description of return value.

    Raises:
        TypeError: Description of exception.
    """
    docstring_parsed = parse(readme)

# Generated at 2022-06-11 21:18:02.987161
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    text = inspect.cleandoc(
        """\
        Short description
        
        Long description
        
        Args:
            arg1: arg1 description.
            arg2: arg2 description.
            
        Returns:
            return description.
        """
    )

# Generated at 2022-06-11 21:18:13.681664
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def _test_parse(text, short_description, long_description):
        # Return true if doc equals Docstring()
        parsed = parse(text)
        assert parsed.short_description == short_description
        assert parsed.long_description == long_description

    def test_infer_indent():
        with raises(ParseError) as err:
            parse('\n  Indent must be determined by the first non-empty line')
        assert str(
            err.value
        ) == 'Can\'t infer indent from "  Indent must be determined by the first non-empty line"'

    # TODO: The following unit tests failed:
    # 1.  _test_parse('\n  This is the first line.\n  This is the second line.', '', 'This is the first line.\nThis is the second line.')

# Generated at 2022-06-11 21:18:26.238369
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    assert gp.parse("this is docstring") == Docstring(
        short_description="this is docstring",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert gp.parse("this is docstring\n") == Docstring(
        short_description="this is docstring",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:18:37.134296
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "This function does something.\n\n"
    docstring += "Args:\n"
    docstring += "    arg1 (str): argument1.\n"
    docstring += "    arg2 (str): argument2.\n"
    docstring += "    arg3 (str): argument3.\n\n"
    docstring += "Raises:\n"
    docstring += "    Exception: Exception\n"
    docstring += "    Exception1: Exception1\n\n"
    docstring += "Returns:\n"
    docstring += "    (str): Returns something.\n\n"
    docstring += "Example:\n"
    docstring += "    do something\n"

# Generated at 2022-06-11 21:18:46.584502
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # pylint: disable=W0122
    from .common import Docstring, DocstringMeta
    from .google.parser import GoogleParser
    doc = GoogleParser().parse("")
    assert doc == Docstring()
    doc = GoogleParser().parse('"\n')
    assert doc == Docstring(short_description=None, long_description=None, meta=[])
    doc = GoogleParser().parse('"Short\n')
    assert doc == Docstring(short_description="Short", long_description=None, meta=[])
    doc = GoogleParser().parse('"Short\nLong')
    assert doc == Docstring(short_description="Short", long_description="Long", meta=[])
    doc = GoogleParser().parse('"Short\nLong"')

# Generated at 2022-06-11 21:18:52.841991
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:19:01.042294
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create a docstring for test
    docstring = """This is a docstring example.

Args:
    number_of_times (int): How many times to repeat.
        Negative numbers not allowed.
    string_to_repeat (str): What to repeat.
    repeat_type (str): Whether to repeat the string or to repeat
        the characters in the string.
    repeat_type: Whether to repeat the string or to repeat
        the characters in the string.
    
    repeat_type (str): Whether to repeat the string or to repeat
        the characters in the string.
    repeat_type: Whether to repeat the string or to repeat
        the characters in the string.

Returns:
    str: The repeated string.
"""
    # Create a parser and parse the docstring
    parser = GoogleParser()
    doc_parsed = parser.parse

# Generated at 2022-06-11 21:19:12.296489
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Sample of Google-style docstring
    text = '''\
    A short summary

    A little longer description

    Args:
        arg_name: A description of arg_name
        other_arg: A description of other_arg
            with multiple lines

    Raises:
        ValueError: Description of the error

    Returns:
        int: Description of return.'''

    # Parse docstring
    parser = GoogleParser()
    docstring = parser.parse(text)

    # Print short description
    print(docstring.short_description)

    # Print long description
    print(docstring.long_description)

    # Iterate over all parts of the docstring
    for meta in docstring:
        # Print key, type_name and description for the current part
        print(meta.args)

# Generated at 2022-06-11 21:19:23.690021
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Parameters
    ----------
    text: string
        The text of the docstring.

    Returns
    -------
    string
        The text of the docstring.
    """
    parser = GoogleParser()
    print(parser)
    parsed_docstring = parser.parse(docstring)
    print(parsed_docstring)
    print(parsed_docstring.meta) # list of DocstringMeta
    print(parsed_docstring.short_description)
    print(parsed_docstring.long_description)
    meta_list = parser.parse(docstring).meta
    print(meta_list)
    for meta in meta_list:
        if isinstance(meta, DocstringParam):
            print(meta)
            print(meta.arg_name)

# Generated at 2022-06-11 21:19:32.608255
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = GoogleParser()
    # SINGULAR_OR_MULTIPLE with singular variant
    assert docstr.parse("""
        Returns
        -------
        energy : float, optional
            The energy of the system.

        (units: energy)
        """) == Docstring(
            short_description=None,
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[
                DocstringReturns(
                    args=['returns'],
                    description='The energy of the system.',
                    type_name=None,
                    is_generator=False
                )
            ]
        )
    # SINGULAR_OR_MULTIPLE with singular variant, no space after title

# Generated at 2022-06-11 21:19:39.880421
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from typing import List, Dict
    # Test the function with specific test case
    import sys
    import pytest
    from io import StringIO
    input_para1 = """Summary line.

Extended description of function.

Args:
    arg1: Description of arg1
    arg2: Description of arg2

Returns:
    Description of return value.
"""

# Generated at 2022-06-11 21:19:56.011424
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    This function is used to test method parse of class GoogleParser
    """

    # Test case 1: The docstring contains no meta data
    GoogleParser.parse('This is the first line of the docstring \n \
        This is the second line of the docstring')

    # Test case 2: The docstring contains meta data that
    # should be parsed as an attribute
    GoogleParser.parse('Attributes: \n \
        attr1: The first attribute \n \
        attr2: The second attribute')

    # Test case 3: The docstring contains meta data that
    # should be parsed as an example
    GoogleParser.parse('Example: \n \
        print("Hello")')

    # Test case 4: The docstring contains meta data that
    # should be parsed as a parameter

# Generated at 2022-06-11 21:20:04.002548
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def f(x : str = "default") -> str:
        """Short description.

        Long description with examples...

            >>> print(f)
            <function test_GoogleParser_parse.<locals>.f at 0x000001D5FB5E5D90>
            >>> f(1)
            '1'
            >>> f('a')
            'a'

        :param x: first parameter
        :type x: str
        :param y: second parameter
        :type y: int
        :returns: string of parameter
        :raises: RuntimeError
        """
        return str(x)

    doc = parse(f.__doc__)
    assert doc.short_description == "Short description."

# Generated at 2022-06-11 21:20:15.437863
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Function signature: def parse(self, text: str) -> Docstring
    doc = GoogleParser().parse('\n    Google-style docstring parsing.\n')
    assert doc.short_description == 'Google-style docstring parsing.'

    doc = GoogleParser().parse('\n    Google-style docstring parsing.\n')
    assert doc.short_description == 'Google-style docstring parsing.'
    assert doc.long_description is None

    doc = GoogleParser().parse('\n    Google-style docstring parsing.\n\n')
    assert doc.short_description == 'Google-style docstring parsing.'
    assert doc.long_description is None

    doc = GoogleParser().parse('\n    Google-style docstring parsing.\n    \n')
    assert doc.short_description == 'Google-style docstring parsing.'


# Generated at 2022-06-11 21:20:24.736284
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test multi-line docstring with empty first line
    text = '\nA multi-line docstring.'
    expected = Docstring(
        short_description='',
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description='A multi-line docstring.',
        meta=[],
    )
    actual = GoogleParser().parse(text)
    assert expected == actual

    # Test single-line docstring which is the first line of a multi-line docstring
    text = '''\
A single-line docstring.
A multi-line docstring.
'''

# Generated at 2022-06-11 21:20:38.122373
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    GOOGLE_EXAMPLE = """
    Parameters
    ----------
    mode : str
        Mode of the image. One of {'RGB', 'YCbCr', 'L'}.
        Defaults to 'L'.
    """
    assert GoogleParser().parse(GOOGLE_EXAMPLE).meta[0].description == "Mode of the image. One of {'RGB', 'YCbCr', 'L'}."
    assert isinstance(GoogleParser().parse(GOOGLE_EXAMPLE).meta[0], DocstringParam) is True
    assert GoogleParser().parse(GOOGLE_EXAMPLE).meta[0].arg_name == "mode"
    assert GoogleParser().parse(GOOGLE_EXAMPLE).meta[0].type_name == "str"

# Generated at 2022-06-11 21:20:48.993161
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def success(text: str):
        """Test a successful parse."""
        assert text == str(GoogleParser().parse(text))

    def failure(text: str):
        """Test that a parse fails."""
        try:
            GoogleParser().parse(text)
        except ParseError:
            pass
        else:
            assert False, "Expected failure."

    # Test corner cases
    assert "" == str(GoogleParser().parse(""))

    # Test including examples

# Generated at 2022-06-11 21:20:58.443694
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''one line description
    multi
    line
    description

    Args:
        arg1: Description of arg1.
        arg2 (str): Description of arg2. Defaults to "default".
        arg3: Multi line
            description.
            Defaults to [1, 2, 3].

    Returns:
        result (bool): True if successful, False otherwise.
    '''

#     print(docstring)
    parsed = GoogleParser().parse(docstring)
#     print(parsed)
    assert parsed.short_description == "one line description"
    assert parsed.blank_after_short_description is True
    assert parsed.long_description == '''
    multi
    line
    description
    '''.strip()
    assert parsed.blank_after_long_description is False

# Generated at 2022-06-11 21:21:09.264402
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Method to test the parse method of class GoogleParser.
    """
    # Parsing the test data

# Generated at 2022-06-11 21:21:15.825138
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test examples
    assert parse("") == Docstring()
    assert parse(None) == Docstring()
    assert parse("Hello world") == Docstring(
        short_description="Hello world", blank_after_short_description=False
    )
    assert parse("Hello world\n") == Docstring(
        short_description="Hello world", blank_after_short_description=True
    )
    assert parse("\nHello world") == Docstring(
        short_description="Hello world", blank_after_short_description=False
    )
    assert parse("\nHello world\n") == Docstring(
        short_description="Hello world", blank_after_short_description=True
    )

# Generated at 2022-06-11 21:21:18.200498
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert isinstance(parse(""), Docstring)


# Generated at 2022-06-11 21:21:39.599084
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = inspect.cleandoc("""\
    Program for quick testing.
    
    Parameters:
        arg1 (str): First argument name. Defaults to "default arg1".
        arg2 (int): Second argument name. Defaults to 0.
        arg3 (str): Third argument name.
    """)
    docstring = GoogleParser().parse(doc)
    assert docstring.short_description == "Program for quick testing."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert isinstance(docstring.meta[0], DocstringParam)
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_

# Generated at 2022-06-11 21:21:50.651716
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:22:02.788794
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert isinstance(GoogleParser().parse(""), Docstring)
    # noinspection PyTypeChecker
    assert GoogleParser().parse("") == Docstring()
    # noinspection PyTypeChecker
    assert GoogleParser().parse("   ") == Docstring()
    assert isinstance(GoogleParser().parse("foo"), Docstring)
    # noinspection PyTypeChecker
    assert GoogleParser().parse("foo") == Docstring(
        short_description="foo",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert isinstance(GoogleParser().parse("foo."), Docstring)
    # noinspection PyTypeChecker

# Generated at 2022-06-11 21:22:05.046872
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse(None) is None
    assert GoogleParser().parse('') == ''

# test of function parse

# Generated at 2022-06-11 21:22:11.970606
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("test") == Docstring(short_description="test", blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    assert GoogleParser().parse("test\n\n") == Docstring(short_description="test", blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    assert GoogleParser().parse("test\n\n\n") == Docstring(short_description="test", blank_after_short_description=True, long_description=None, blank_after_long_description=False, meta=[])

# Generated at 2022-06-11 21:22:23.517898
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text1 = '''
    Create a class that have the following attributes and methods.
    
    Parameters
    ----------
    x : int
        A positive integer number. If zero, user should be warned.

    y : float
        A float number. If zero, user should be warned.

    Returns
    -------
    None
    
    Examples
    --------
    >>> prueba = GoogleParser()
    >>> prueba.parse(text1)
    >>> assert(prueba.x = x)
    >>> assert(prueba.y = y)
    >>> assert(prueba.parse(text1))
    '''
    doc = parse(text1)
    assert(doc.short_description == 'Create a class that have the following attributes and methods')

# Generated at 2022-06-11 21:22:32.820622
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # valid docstring with short description,
    #                   long description,
    #                   parameters description,
    #                   returns description
    #                   code examples,
    #                   raises description
    #                   yields description
    td_docstring = """
    This is a valid docstring.
    This is a long valid docstring.
    Arguments:
        arg1: A string parameter.
    Arguments:
        arg2: An integer parameter. Defaults to 1.
    Returns:
        A valid return.
    Yields:
        A valid yield.
    Raises:
        ValueError: if parameter arg2 is invalid.
    Example:
        >>> print(True)
        True
    Examples:
        >>> print(1)
        1
        >>> print(2)
        2
    """

    # True docstring
    td_doc

# Generated at 2022-06-11 21:22:44.422292
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = ""
    assert GoogleParser().parse(docstring).short_description is None
    assert GoogleParser().parse(docstring).long_description is None

    docstring = """
        Short description.

        Extended description.

        Parameters
        ----------
        arg1 : str
            Description of arg1.
        arg2, arg3 : list of str
            Description of arg2, arg3.

        Returns
        -------
        str
            Description of return value.

        Examples
        --------
        >>> doctest_google_parse("text")
        'text'

        >>> doctest_google_parse("text")
        'text'

        >>> doctest_google_parse("text")
        'text'


        """
    assert GoogleParser().parse(docstring).short_description == "Short description."

# Generated at 2022-06-11 21:22:50.802912
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    dstring = gp.parse("""Test docstring.
Args:
    asd: Description of first parameter.
        Multi-line parameter
        description.
    param: Description of second parameter.
        Another multi-line parameter
        description.
    aaa: Description of third parameter.
Raises:
    ValueError: First exception.
    IndexError: Second exception.
Returns:
    Description
        of return value.
Returns:
    Description
        of return value.
Yields:
    Description of yielded
        value.
""")
    print(dstring)

# Generated at 2022-06-11 21:23:00.112322
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Set up class instance
    p = GoogleParser()

    # Check correct output

# Generated at 2022-06-11 21:23:19.992709
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
Sums a + b.

Args:
    a (int): first number to sum.
    b (int): second number to sum.

Returns:
    int: sum of a + b
    """
    parser = GoogleParser()
    doc = parser.parse(text)
    assert doc.short_description == "Sums a + b."
    assert doc.long_description is None
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ['returns', 'int']
    assert doc.meta[0].description == 'sum of a + b'
    assert isinstance(doc.meta[0], DocstringReturns)
    assert doc.meta[0].is_generator == False
    assert doc.meta[0].type_name == 'int'

# Generated at 2022-06-11 21:23:31.262133
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .numpy_parser import NumpyParser

    class Test:
        """Test docstring.

        This is a test.

        Params:
            a: a
            b (int): b

        Returns:
            None
        """

        def __init__(self, a, b):
            self.a = a
            self.b = b

    a = Test(1, 2)

    docstrings = (
        GoogleParser().parse(inspect.getdoc(a)),
        NumpyParser().parse(inspect.getdoc(a)),
    )
    # docstrings = [NumpyParser().parse(inspect.getdoc(a))]

    assert docstrings[0].short_description == "Test docstring."
    assert docstrings[0].long_description == "This is a test."

# Generated at 2022-06-11 21:23:42.858501
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    The test function for Google parser.
    """
    print("""
    test_GoogleParser_parse
    """)

    print("""
    # test for function parse
    """)
    parser = GoogleParser()

# Generated at 2022-06-11 21:23:53.605526
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test Google docstring parsing."""


# Generated at 2022-06-11 21:24:00.731840
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Successfully parses non-empty docstring for which all sections
    # are optional and only short description is present
    class ClassWithNoDocstringMeta:
        """Short description only."""
    parser = GoogleParser()
    ret = parser.parse(ClassWithNoDocstringMeta.__doc__)
    assert ret.meta == []
    assert ret.short_description == "Short description only."
    assert ret.long_description == None
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == False

    # Successfully parses non-empty docstring for which all sections
    # are optional and both short and long descriptions are present
    class ClassWithDocstring:
        """Short description.

        Long description."""
    parser = GoogleParser()

# Generated at 2022-06-11 21:24:03.988984
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # parse is tested through doctest style testing in docstring.py
    pass


# Generated at 2022-06-11 21:24:16.172824
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('''\
    Short summary.

    Long description.
    ''') == Docstring(
        [],
        'Short summary.',
        True,
        'Long description.',
        True,
    )


# Generated at 2022-06-11 21:24:22.957691
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:24:28.909403
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_string = """This is a test
    for:
        :param param1: this is the first param
        :param param2: this is the second param
        :returns:
        :raises keyError: raises an exception
    """
    google_parser = GoogleParser()
    assert google_parser.parse(doc_string)

# Generated at 2022-06-11 21:24:37.664655
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:25:05.597682
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = GoogleParser()
    text = """\
        This function does something.

        Args:
            a (:obj:`int`): First argument.
            b (:obj:`str`): Second argument.
        """
    r = d.parse(text)
    assert r.docstring == text
    assert r.short_description == "This function does something."
    assert r.blank_after_short_description
    assert r.long_description == ""
    assert r.blank_after_long_description
    assert len(r.meta) == 2
    assert isinstance(r.meta[0], DocstringParam)
    assert r.meta[0].description == "First argument."
    assert r.meta[0].type_name == "int"
    assert r.meta[0].arg_name == "a"
   

# Generated at 2022-06-11 21:25:13.717866
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    function1(x,y,z)

    Perform some calculation.

    Parameters:
      x: The x value.
      y: The y value.
      z: The z value.

    Returns:
      Value of the calculation.
    """
    ds = GoogleParser().parse(docstring)
    assert ds.short_description == "function1(x,y,z)"
    assert ds.long_description == "Perform some calculation."
    assert ds.meta[0].args == ["param", "x: The x value."]
    assert ds.meta[0].description == "The x value."
    assert ds.meta[1].args == ["param", "y: The y value."]
    assert ds.meta[1].description == "The y value."

# Generated at 2022-06-11 21:25:24.826573
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """:param int len: The length of the list.
:param callable f: The callback.
:rtype: list
:return: A list of the results.

This is a long description.

:param int g: just a param

This is also a long description.

:returns: None

This is a short description.

The ``something`` variable is used to create :see: reference.
"""
    # Parse docstring
    ret = parser.parse(text)
    print(ret)
    assert ret.short_description == ""
    assert ret.long_description is None
    assert len(ret.meta) == 1
    assert ret.meta[0].args[0] == "returns"
    assert ret.meta[0].args[1] is None
    assert ret

# Generated at 2022-06-11 21:25:26.992615
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    parser.parse("")
    parser.parse("    Args:")
    parser.parse("    Args: \n")


# Generated at 2022-06-11 21:25:38.553974
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import re

    doc = '''
    Args:
        a: 1
        b: 2
        c: 3
    Returns:
        (a,b,c)
    '''

    ret = parse(doc)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.meta
    for m in ret.meta:
        assert type(m) is DocstringParam
        m = m.as_dict()
        assert type(m) is dict
        assert re.match(r'^[abc]$', m['arg_name'])
        assert m['description'] is None
        assert m['type_name'] is None
        assert m['default'] is None
