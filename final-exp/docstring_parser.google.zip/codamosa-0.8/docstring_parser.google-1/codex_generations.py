

# Generated at 2022-06-11 21:16:10.084479
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
        This is a long description.
        Returns:
            Docstring: The parsed docstring.
    """
    assert GoogleParser().parse(docstring).long_description == "This is a long description."

# Generated at 2022-06-11 21:16:17.864249
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """d:i.
    A Google-Style.

    Args:
        dump (str): File for the dumps.
        limit (int): Maximum argument of the sum.

    Returns:
        str: Sum of the arguments raised at each non-negative integer
        power less than ``limit``.

    Raises:
        LimitExceeded: If ``limit`` is negative.

    Examples:
        >>> example('a')
        'a'
    """

    parser = GoogleParser()
    docstrings = parser.parse(docstring)

    assert (
        docstrings.short_description
        == "d:i. A Google-Style."
    )

# Generated at 2022-06-11 21:16:28.075831
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse('') == Docstring()
    assert parser.parse('simple string') == Docstring(short_description='simple string')
    assert parser.parse('simple\nstring') == Docstring(short_description='simple', long_description='string', blank_after_long_description=True, blank_after_short_description=True)
    assert parser.parse('simple\n \nstring') == Docstring(short_description='simple', long_description='string', blank_after_long_description=True, blank_after_short_description=True)

# Generated at 2022-06-11 21:16:34.576368
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = "An example docstring."
    doc = parser.parse(text)
    assert (doc.short_description == "An example docstring.")
    assert (doc.long_description is None)
    assert (doc.blank_after_short_description == False)
    assert (doc.blank_after_long_description == False)
    assert (len(doc.meta) == 0)
    text = "An example docstring.\n"
    doc = parser.parse(text)
    assert (doc.short_description == "An example docstring.")
    assert (doc.long_description is None)
    assert (doc.blank_after_short_description == True)
    assert (doc.blank_after_long_description == False)
    assert (len(doc.meta) == 0)

# Generated at 2022-06-11 21:16:44.547778
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert ValueError == type(GoogleParser().parse(""))
    assert 'Expected paramenter name.' == str(GoogleParser().parse("a = 1"))
    assert 'Can\'t infer indent from "a = 1"' == str(GoogleParser().parse("Args:\na = 1"))
    assert 'No specification for "Args": "Args:"' == str(GoogleParser().parse("Args:\n"))
    assert 'No specification for "Args": "Args:\n"' == str(GoogleParser().parse("Args:\n\n"))
    assert ValueError == type(GoogleParser().parse("Args:\n    a = 1"))


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:16:57.073721
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc = '''Description of the function.

    Args:
        arg1: Description of arg1.
        arg2: Description of arg2.

    Returns:
        Description of the return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    '''
    result = parser.parse(doc)
    assert result.short_description == 'Description of the function.'
    assert result.long_description == 'Description of arg1.\n    arg2.\n    '
    assert result.blank_after_long_description == False
    assert result.blank_after_short_description == True
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[0].arg_name == 'arg1'
    assert result.meta

# Generated at 2022-06-11 21:17:10.374286
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    D = """
    """
    D1 = GoogleParser().parse(D)
    assert D1.short_description == None
    assert D1.long_description == None
    assert D1.blank_after_short_description == False
    assert D1.blank_after_long_description == False
    assert len(D1.meta) == 0

    D = """
    short description
    """
    D1 = GoogleParser().parse(D)
    assert D1.short_description == "short description"
    assert D1.long_description == None
    assert D1.blank_after_short_description == False
    assert D1.blank_after_long_description == False
    assert len(D1.meta) == 0

    D = """
    short description

    long description
    """
    D1 = GoogleParser().parse

# Generated at 2022-06-11 21:17:22.888420
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstring = google_parser.parse("""\
    A docstring for a function or method.

    Parameters
    ----------
    a : int
        A parameter.

    Returns
    -------
    int
        Something.
    """)
    assert docstring.short_description == "A docstring for a function or method."
    assert docstring.long_description == None
    assert docstring.meta[0].args == ['parameters', 'a : int']
    assert docstring.meta[0].arg_name == 'a'
    assert docstring.meta[0].type_name == 'int'
    assert docstring.meta[0].description == 'A parameter.'
    assert docstring.meta[1].args == ['returns', 'int']
    assert docstring.meta[1].type_

# Generated at 2022-06-11 21:17:34.802425
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Function to test method parse of class GoogleParser."""
    doc = """
    A function to compute the square of a number.

    Args:
        x: the number to be squared.

    Returns:
        Return the square of x.
    """
    assert GoogleParser().parse(doc).meta[0] == DocstringParam(
        args=["param", "x"],
        description="the number to be squared.",
        arg_name="x",
        type_name=None,
        is_optional=None,
        default=None
    )
    assert GoogleParser().parse(doc).meta[1] == DocstringReturns(
        args=["returns", "the square of x."],
        description="Return the square of x.",
        type_name="the square of x.",
        is_generator=False
    )
   

# Generated at 2022-06-11 21:17:42.390166
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test several options for line indentation
    def test_indent(text, indent, short_desc, long_desc):
        doc = GoogleParser().parse(text)
        assert doc.indent == indent
        assert doc.short_description == short_desc
        assert doc.long_description == long_desc

    test_indent("", "", None, None)
    test_indent("\n", "", None, None)
    test_indent("\n\n", "", None, None)
    test_indent("Test\n", None, "Test", None)
    test_indent("  Test\n", "  ", "Test", None)
    test_indent("    Test\n", "    ", "Test", None)
    test_indent("Test\n\n", None, "Test", None)

# Generated at 2022-06-11 21:18:00.473520
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test empty
    assert {} == GoogleParser().parse("")

    # Test simple
    assert {
        "short_description": "Foo",
        "meta": [
            DocstringMeta(
                args=["Examples", "foo"],
                description=">>> foo()\n42",
            )
        ],
    } == GoogleParser().parse(
        """Foo

Examples:
>>> foo()
42
"""
    )

    # Test short description and long description
    assert {
        "short_description": "Foo",
        "long_description": "Bar\nBaz",
        "blank_after_short_description": False,
        "blank_after_long_description": False,
        "meta": [],
    } == GoogleParser().parse(
        """Foo
Bar
Baz"""
    )

   

# Generated at 2022-06-11 21:18:08.128221
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("foo") == Docstring(
        short_description="foo",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    assert GoogleParser().parse("foo\nbar") == Docstring(
        short_description="foo",
        long_description="bar",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-11 21:18:19.926040
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Check parse method for GoogleParser class"""
    # Simple docstring
    simple_docstring = """
        This is a simple and short docstring.
        """
    docstring = GoogleParser().parse(simple_docstring)
    assert docstring.short_description == "This is a simple and short docstring."
    assert docstring.long_description is None

    # Simple docstring with long description
    simple_docstring = """
        This is a simple docstring.
        And this is the long description.
        """
    docstring = GoogleParser().parse(simple_docstring)
    assert docstring.short_description == "This is a simple docstring."
    assert docstring.long_description == "And this is the long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

# Generated at 2022-06-11 21:18:30.386531
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:18:40.128102
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''Example
    --------
    this is a example
    
    Attributes
    ----------
    attr1: str, optional. Defaults to "default".
        this is a attribute
    attr2: int, optional. Defaults to 5.
    '''
    d = Docstring()
    d.short_description = "Example"
    d.blank_after_short_description = False
    d.long_description = "this is a example"
    d.blank_after_long_description = True
    d.meta.append(DocstringMeta(["examples"], "this is a example"))
    d.meta.append(DocstringParam(["attribute", "attr1: str"], "this is a attribute", "attr1", "str"))

# Generated at 2022-06-11 21:18:48.696965
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test with only description
    text = """
        Short description.

        Long description.
        """
    result = GoogleParser().parse(text)
    print(result.__dict__.items())
    assert result.short_description == "Short description."
    assert result.blank_after_short_description and \
        result.blank_after_long_description and \
        not result.long_description
    assert not result.params
    assert not result.returns
    assert not result.raises
    assert not result.attributes
    assert not result.examples

    # test with only examples
    text = """
        Examples:

        >>> print("hello world")
        hello world
        """
    result = GoogleParser().parse(text)
    assert result.short_description is None
    assert not result.params

# Generated at 2022-06-11 21:18:58.267614
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = "Bla bla bla.\n\nArgs:\n  arg1: Description of arg1.\n  arg2: Description of arg2."
    assert parser.parse(docstring) == Docstring(
        short_description="Bla bla bla.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["arg1"], description="Description of arg1.", indent=4
            ),
            DocstringMeta(
                args=["arg2"], description="Description of arg2.", indent=4
            ),
        ],
    )

# Generated at 2022-06-11 21:19:01.018064
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
    Examples
    --------
    This is an example
    """)
    assert docstring.meta[0].description == 'This is an example'

# Generated at 2022-06-11 21:19:12.259251
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Given a Google-style docstring
    text = """Parses a Google-style docstring into components.

Short description.

Long description.

Args:
    text (str):
        The docstring to parse.

Returns:
    A parsed docstring.

Raises:
    ParseError: On failure.
"""
    # When the method parse is called
    docstring = GoogleParser().parse(text)
    # Then the correct Docstring is returned
    assert docstring.short_description == "Parses a Google-style docstring into components."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False

    assert len(docstring.meta) == 3

# Generated at 2022-06-11 21:19:23.638780
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    doc = """
    Test the GoogleParser class parse method.

    :param param: description
    :raises: Any exception
    :returns: nothing
    """
    docstring = google_parser.parse(doc)
    assert docstring.short_description == "Test the GoogleParser class parse method."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == None
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "param: description"]
    assert docstring.meta[0].description == "description"
    assert docstring.meta[0].arg_name == "param"

# Generated at 2022-06-11 21:19:37.592692
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstring = google_parser.parse("""
        Function docstring.

        Args:
            first_arg: An int
            second_arg: An optional int, default is 42.
        Returns:
            A string.
        Raises:
            ValueError: A random value error.
    """)
    assert len(docstring.meta) == 4
    assert docstring.short_description == "Function docstring."
    assert docstring.long_description == None


# Generated at 2022-06-11 21:19:49.660382
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test GoogleParser.parse()."""
    p = GoogleParser()
    text = r"""
    This is the short description.

    This is the long description.

    Args:
        param1: The first parameter.
        param2: The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    ret = p.parse(text)

# Generated at 2022-06-11 21:20:01.262771
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:20:06.637504
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
    This method returns some stuff
    :params name: param-name
    """
    assert GoogleParser().parse(doc) == Docstring(
        short_description="This method returns some stuff",
        meta=[
            DocstringMeta(
                args=["param", "name"],
                description="param-name",
                arg_name="name",
            ),
        ],
    )

# Generated at 2022-06-11 21:20:18.553242
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("Test") == Docstring("Test")
    assert GoogleParser().parse("Test\nfoo") == Docstring("Test", "foo")
    assert GoogleParser().parse("Test\n\nfoo") == Docstring("Test", "\nfoo")
    assert GoogleParser().parse("Test\n\nfoo\n") == Docstring("Test", "\nfoo\n")

    doc = GoogleParser().parse("Test\nArgs:\nfoo")
    assert doc.short_description == "Test"
    assert doc.long_description is None
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.meta[0] == DocstringMeta("param", "foo")


# Generated at 2022-06-11 21:20:25.828208
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    title_colon=True
    
    sections = [Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)]
    
    googleParser = GoogleParser(sections, title_colon)

    doc = googleParser.parse("Returns:\n    The number of arguments entered by user.")

    assert doc.short_description is None
    
    assert doc.long_description is None
    
    assert doc.blank_after_short_description is None
    
    assert doc.blank_after_long_description is None
    
    assert len(doc.meta) == 1
    
    meta = doc.meta[0]
    
    assert meta.args[0] == "returns"
    
    assert meta.description == "The number of arguments entered by user."
    
    
    # Test section 'Returns'

# Generated at 2022-06-11 21:20:38.501163
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Start with a one-line summary ending with a period.
        
        Follow the summary with a blank line and an indented
        description of the object's calling conventions. Optionally
        include a list of the parameters with their types, purpose, and
        default values:
        
        :param name: str, optional
            A name for the object being described. Defaults to None.
            The name is used to compute a unique id for the object.
        :param location: tuple of float, optional
            The (x, y) coordinates of the object. Defaults to (0, 0).
        """
    output = GoogleParser().parse(text)
    assert output.short_description == "Start with a one-line summary ending with a period."

# Generated at 2022-06-11 21:20:49.738889
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Unit test for method parse of class GoogleParser
    # Tests taken from https://github.com/takluyver/sphinx-jsonschema/blob/master/sphinx_jsonschema/google.py
    from .numpydoc import parse as numpydoc_parse
    from .common import OrderedDict

    cases = OrderedDict()

# Generated at 2022-06-11 21:20:55.659554
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Case 1: google docstring without section
    docStr = GoogleParser().parse("This is the function docstring")
    assert str(docStr) == """\
This is the function docstring

"""

    # Case 2: google docstring with multiple sections
    docStr = GoogleParser().parse("""\
This is the function docstring

This is the long description

This is the example:
    This is the example

This is the raises:
    Exception

This is the returns:
    This is the returns

This is the parameters:
    arg1: This is the arg1
    arg2:
    arg3:
        This is the arg3
        This is the arg3
""")


# Generated at 2022-06-11 21:21:06.999994
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = parse("""\
A really simple example of docstring parsing using the new google format.

Args:
    fruit: A nice and juicy apple or pear for example.
    color: The color of the fruit.

Returns:
    A tasty and colorful fruit.
""")
    assert docstring.short_description == "A really simple example of docstring parsing using the new google format."
    assert docstring.long_description == None
    assert len(docstring.meta) == 3
    assert docstring.meta[0].description == ""
    assert docstring.meta[0].args == ['Args', '']
    assert docstring.meta[1].description == "A nice and juicy apple or pear for example."
    assert docstring.meta[1].args == ['Args', '    fruit:']

# Generated at 2022-06-11 21:21:25.364083
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def sample_func(a, b=2, *args, **kwargs):
        """Sample func for testing google_parser.

        Args:
            a: param 1
            b: param 2, defaults to 2
            *args: variable length argument list
            **kwargs: arbitrary keyword arguments

        Returns:
            sample value

        Raises:
            ValueError:

            if invalid parameter is specified.

            TypeError:

            if invalid parameter type is specified.
        """
        pass

    docstring = GoogleParser().parse(inspect.getdoc(sample_func))

    assert docstring.short_description is not None
    assert len(docstring.short_description) > 0

    assert docstring.long_description is not None
    assert len(docstring.long_description) > 0

    assert len(docstring.meta) == len

# Generated at 2022-06-11 21:21:38.790173
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = Docstring()
    parser = GoogleParser()
    assert str(parser.parse(doc.__doc__))==str(doc)


# Generated at 2022-06-11 21:21:46.767663
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
        Test Google-Style Docstring.

        Long description.

        Args:
            arg1: the first argument.
            arg2: the second argument. Defaults to 'ABC'.
            arg3 (str): the third argument.

        Returns:
            int. the return value.

        Raises:
            ValueError: if any argument is invalid.

        Examples:
            >>> GoogleParser().parse('test')
            True

            >>> GoogleParser().parse('test')
            False
    """
    # Expected Result
    short_description = "Test Google-Style Docstring."
    long_description = \
        "Long description.\n\n" + "Returns\n" + "-------\n" + "int. the return value."

# Generated at 2022-06-11 21:21:54.652118
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:22:06.797179
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """The constructor.

        The constructor.

        Args:
            width: The width of the rectangle.
            height: The height of the rectangle.
        """

    ds = GoogleParser().parse(doc)
    assert len(ds.meta) == 2
    meta = ds.meta[0]
    assert meta.args == ["param", "width: The width of the rectangle."]
    assert meta.arg_name == "width"
    assert meta.type_name == None
    assert meta.is_optional == None
    assert meta.default == None
    assert meta.description == "The width of the rectangle."
    meta = ds.meta[1]
    assert meta.args == ["param", "height: The height of the rectangle."]
    assert meta.arg_name == "height"
    assert meta.type_name

# Generated at 2022-06-11 21:22:18.435991
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Short summary.
    
    Long description.
    
    Args:
        arg1 (str): Description.
        
        arg2 (str): Description.
        
    Returns:
        str: Description.
    """
    doc = parse(text)
    assert doc
    assert doc.short_description == 'Short summary.'
    assert doc.long_description == 'Long description.'
    assert len(doc.meta) == 3
    assert 'arg1' in doc.meta[0].args
    assert 'arg2' in doc.meta[1].args
    assert 'return' in doc.meta[2].args


if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:22:25.986376
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # test_parse_no_section
    text = """\
        First sentence.

        Second sentence.

        Long
        long
        long.
        """
    docstring = Docstring()
    docstring.short_description = 'First sentence.'
    docstring.long_description = 'Second sentence.\n\nLong\nlong\nlong.'
    docstring.blank_after_short_description = True
    docstring.blank_after_long_description = True
    assert GoogleParser().parse(text) == docstring

    # test_parse_with_section

# Generated at 2022-06-11 21:22:34.375984
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("Foo") == Docstring(short_description="Foo",long_description=None,\
                                            blank_after_short_description=False,blank_after_long_description=False,\
                                            meta=[])
    assert parser.parse("Foo\n") == Docstring(short_description="Foo",long_description=None,\
                                              blank_after_short_description=True,blank_after_long_description=False,\
                                              meta=[])

# Generated at 2022-06-11 21:22:46.532404
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert(Docstring(
        short_description = None,
        blank_after_short_description = False,
        long_description = 'A fully specified (field_name, value, ...) record.',
        blank_after_long_description = True,
        meta = [DocstringParam(
            args=['Args', 'field_name (str): Field name'],
            description='Field name',
            arg_name='field_name',
            type_name='str',
            is_optional=False,
            default=None)]
        ) == GoogleParser().parse(
        'A fully specified (field_name, value, ...) record.\n'
        '\n'
        'Args:\n'
        '    field_name (str): Field name\n'
        '\n'
    ))

# Generated at 2022-06-11 21:22:58.084427
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Set up
    text = """Summary line.
    Extended description.

    Args:
        arg1 (str): Description of arg1
        arg2 (int, optional): Description of arg2

    Returns:
        bool: Description of return value

    Raises:
        AttributeError: The text raised due to an attribute error.
        ValueError: The text raised due to a value error.

    """
    parser = GoogleParser()

# Generated at 2022-06-11 21:23:14.383467
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''\
        A function with a long description.

        A function with a long description.
        A function with a long description.
        A function with a long description.
        A function with a long description.
        A function with a long description.
        A function with a long description.
        A function with a long description.
        A function with a long description.
        A function with a long description.
        :param x: A parameter.
        :param y: A parameter.
        :type y: int
        :return: A function.
        :rtype: string
        :raises ValueError: Hej.
        :raises TypeError: Hej.
        '''

# Generated at 2022-06-11 21:23:21.665921
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_docstring = """\
    The first line is brief description.

    The second line is a more detailed description.
    You may use several lines.

    Args:
        arg1 (str): Description of arg1
        arg2 (:obj:`int`, optional): Description of arg2

    Returns:
        bool: Description of return value

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    .. _Google Python Style Guide:
       http://google.github.io/styleguide/pyguide.html

    """
    result = GoogleParser().parse(test_docstring)
    assert result.short_description == "The first line is brief description."
    assert result.long_

# Generated at 2022-06-11 21:23:32.003923
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import unittest
    class TestGoogleParser(unittest.TestCase):
        def setUp(self):
            self.GoogleParser = GoogleParser()

        def test_parse(self):
            d1 = """Parse the Google-style docstring into its components.
        :returns: parsed docstring
        """
            expected1 = Docstring(
                meta = [
                    DocstringMeta(args=['returns'], description='parsed docstring')
                ],
                short_description = 'Parse the Google-style docstring into its components.',
                blank_after_short_description = False,
                blank_after_long_description = True,
                long_description = None,
            )
            self.assertEqual(expected1,self.GoogleParser.parse(d1))


# Generated at 2022-06-11 21:23:43.402038
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    dummy_text = """
    This is a short description

    And the long description.

    Args:
        arg1(int): parameter description
        arg2(str): another description
        arg3 (bool): and another description

    Returns:
        int: and the return description

    Raises:
        KeyError: if something bad happens

    Example:
        >>> blah blah blah

    .. note::
        This is a note.
    """
    docstring = GoogleParser().parse(dummy_text)

    # assert docstring.short_description == "This is a short description"
    # assert docstring.long_description == "And the long description."
    # assert docstring.blank_after_short_description is True
    # assert docstring.blank_after_long_description is False


# Generated at 2022-06-11 21:23:51.624199
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    s = """
    The docstring for this function.

    Long description of this function.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """

    # Act
    result = GoogleParser().parse(s)

    # Assert
    assert result.short_description == "The docstring for this function."
    assert result.long_description == "Long description of this function."
    assert len(result.meta) == 2

    assert result.meta[0].key == "param"
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[0].description == 'arg1: The first argument.'

    assert result.meta[1].key == "param"


# Generated at 2022-06-11 21:23:53.887552
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Testing for method parse of class GoogleParser"""
    GoogleParser_instance = GoogleParser()
    assert 1 == 1


# Generated at 2022-06-11 21:24:03.257578
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docs = """
    mydocumentation
    :param test: some description
    :param other: some description here
    :return: some description
    :raises: some description
    :raises: some description
    """
    ret = GoogleParser().parse(docs)

    assert ret.short_description is not None
    assert ret.short_description == "mydocumentation"

    assert ret.long_description is None

    assert ret.blank_after_short_description is not None
    assert ret.blank_after_short_description == False

    assert ret.blank_after_long_description is not None
    assert ret.blank_after_long_description == False

    assert len(ret.meta) == 5
    assert ret.meta[0].args == ['param', 'test: some description']


# Generated at 2022-06-11 21:24:15.904067
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_to_test = \
        """
test_docstring_parse: Test parse a Google style docstring into its components.

Args:
    text: The text of the docstring

Returns:
    docstring components.
        """
    output = ("test_docstring_parse: Test parse a Google style docstring",
              "into its components.\n\nArgs:\n    text: The text of the",
              "docstring\n\nReturns:\n    docstring components.\n        ")

    parser = GoogleParser()
    docstring = parser.parse(docstring_to_test)
    assert docstring.short_description == output[0]
    assert docstring.long_description == output[1]
    assert docstring.meta[0].description == output[2]



# Generated at 2022-06-11 21:24:20.876220
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    GoogleParser().parse("""
        One-line description.
        Long description. It can
        span multiple lines.

        Args:
            arg1 (int): Description of arg1
            arg2 (str, optional): Description of arg2. Defaults to "asdf".
            arg3 (List[int]): Description of arg3

        Raises:
            ValueError: When arg1 is negative.
            TypeError: When arg2 has some bad type.

        Returns:
            str: Asdf.
        """)

# Generated at 2022-06-11 21:24:27.264892
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .meta import get_meta
    from .common import get_docstring

    dokstring = get_docstring("../tests/dokstrings/google.py")
    for meta in get_meta(dokstring):
        print(meta)



# Generated at 2022-06-11 21:24:46.988381
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-11 21:24:57.364824
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    s = '''Test docstring
    :param str name: Name to be used.
    :param int id: Id of the user.
    :return: a description and a value
    :rtype: str
    '''
    parser = GoogleParser()

# Generated at 2022-06-11 21:25:07.856313
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-11 21:25:14.175084
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""

# Generated at 2022-06-11 21:25:25.223716
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """A test for python docstring.

:param foo: A foo.
:type foo: int

:param bar: A bar.
:type bar: str
:raises ValueError: if no foo
:raises TypeError: if bar is not a str
"""
    docstring = GoogleParser().parse(text)

    assert docstring.short_description == "A test for python docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

    assert len(docstring.meta) == 3

    assert docstring.meta[0].description == "A foo."
    assert docstring.meta[0].type_name == "int"
    assert isinstance(docstring.meta[0], DocstringParam)

# Generated at 2022-06-11 21:25:32.312710
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Solve a quadratic equation.

    This is a more elaborate description.

    Args:
        a (float): The quadratic coefficient.
        b (float): The linear coefficient.
        c (int): The constant coefficient.

    Returns:
        float: The larger root of the equation if it has any.

    Raises:
        ValueError: If the equation has no roots.

    Examples:
        >>> solve_quad(1, 0, -4)
        2.0
    """


# Generated at 2022-06-11 21:25:41.939191
# Unit test for method parse of class GoogleParser