

# Generated at 2022-06-11 21:15:59.789637
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
    ]
    text = """One line summary.

Longer description.

Multi-line.

Arguments:
    arg_1 (:class:`int`): The first argument.
    arg_2 (:class:`str`): The second argument. Defaults to 'No value'.

Raises:
    Not_In_Range: If input value is out of range.
    ValueError: Raised if something else went wrong.
"""
    gp = GoogleParser(sections=sections)
    ret = gp.parse(text)
    assert ret.short_description == "One line summary."

# Generated at 2022-06-11 21:16:04.196054
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """Example Google-style docstring:

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    """
    docstring = GoogleParser().parse(doc)
    print(docstring)
    

# Generated at 2022-06-11 21:16:14.709155
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Create a new empty Params object.

    Returns
    -------
    params : Params
        The created parameter object.
    '''
    gp = GoogleParser()
    assert isinstance(gp, GoogleParser)
    doc = gp.parse(text)
    assert type(doc) == Docstring
    assert doc.short_description == 'Create a new empty Params object.'
    assert type(doc.meta) == list
    assert len(doc.meta) == 1
    assert type(doc.meta[0]) == DocstringMeta
    assert doc.meta[0].args == ['returns']
    assert doc.meta[0].description == 'The created parameter object.'

# Generated at 2022-06-11 21:16:26.233755
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def func(a, b):
        """
        Short description.

        Long description.

        Args:
            a: first argument
            b: second argument

        Returns:
            return description
        """
        return None

    Document = GoogleParser().parse(func.__doc__)
    #print(Document)
    assert Document.short_description == "Short description."
    assert Document.long_description == "Long description."
    assert Document.blank_after_short_description == True
    assert Document.blank_after_long_description == False

    assert len(Document.meta) == 1
    assert Document.meta[0].description == "return description"



# Generated at 2022-06-11 21:16:33.799156
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def foo():
        """Print a message.

        Parameters
        ----------
        message : str, optional
            The message to be printed.

        Returns
        -------
        None

        Raises
        ------
        TypeError
            If message is not a string

        Examples
        --------
        >>> foo('Hello World')
        Hello World
        """
        pass

    foo_docstring = inspect.getdoc(foo)

    foo_parsed_docstring = parse(foo_docstring)

    assert foo_parsed_docstring.short_description == "Print a message."
    assert foo_parsed_docstring.blank_after_short_description == True
    assert foo_parsed_docstring.blank_after_long_description == True

# Generated at 2022-06-11 21:16:47.060022
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docs = open("tests/test_GoogleParser_parse.txt","r")
    docs = docs.read()
    line = docs.split("\n\n")
    for i in range(len(line)):
        line[i] = line[i][1:].split("\n")
        line[i][1] = line[i][1].split("\t")
        
    for i in range(len(line)):
        text = line[i][0][1:]
        docstring = GoogleParser().parse(text)
        assert docstring.short_description == line[i][1][1]
        assert docstring.long_description == line[i][1][2]
        assert docstring.blank_after_short_description == (line[i][1][3] == "True")
        assert docstring.blank_

# Generated at 2022-06-11 21:16:59.592814
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Dummy:
        """This is a dummy class.

        This is the long description for the dummy class.

        Attributes:
            attr1 (str): This is the first attribute.
            attr2 (int): This is the second attribute.

        Args:
            par1: This is the first parameter.
            par2: This is the second parameter.

        Examples:
            >>> print(dummy)
            <__main__.Dummy instance at 0x7f283cdf5420>

        Raises:
            TypeError: If the type of the argument is wrong.

        Returns:
            str: Returned string.
        """
        def __init__(self, par1, par2):
            """Constructor."""
            pass


# Generated at 2022-06-11 21:17:02.648037
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    parse_str = "Test for class GoogleParser"
    assert parser.parse(parse_str)
    print("Test for method parse of class GoogleParser is passed")


# Generated at 2022-06-11 21:17:13.768317
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()

# Generated at 2022-06-11 21:17:23.328925
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test the method parse of class GoogleParser."""
    docstring = """
    Some text to be ignored as comment in the source code.
    Args:
        arg1 (str): arg1 description.
        arg2 (int): arg2 description. Defaults to 12.
    """
    gparser = GoogleParser()
    doc_struct = gparser.parse(docstring)
    print(doc_struct)
    print(doc_struct.long_description)
    print(doc_struct.short_description)
    for meta in doc_struct.meta:
        print(meta)
        print(meta.description)
        print(meta.args)
        print(meta.arg_name)

# Generated at 2022-06-11 21:17:40.813425
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Multi-line
                   Google-style docstring.

                   Args:
                     param1: The first parameter.
                     param2: The second parameter. Defaults to None.
                   Returns:
                     Description of return value
                     and type.
                   Raises:
                     An exception.

                   A single line can be used, too.
                """
    g = GoogleParser()
    result = g.parse(docstring)
    assert result.short_description == "Multi-line Google-style docstring."
    assert result.blank_after_short_description is False
    assert result.long_description == None
    assert result.blank_after_long_description is True
    assert result.meta[0].args[0] == 'param'
    assert result.meta[0].args[1] == 'param1: The first parameter.'
   

# Generated at 2022-06-11 21:17:49.009530
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    docstring

    Args:
        parameter_1 (int): description of parameter_1.
        parameter_2 (str): description of parameter_2.

    Returns:
        description of return value.
    '''
    docstring_returns = GoogleParser().parse(docstring)
    print(docstring_returns.short_description)
    for docstring_param in docstring_returns.meta:
        if isinstance(docstring_param, DocstringParam):
            print(docstring_param.arg_name)


# Generated at 2022-06-11 21:17:57.036287
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    GoogleParser().parse('''
    This is the first line of the docstring.
    This is the second line of the docstring.
    This is the third line of the docstring.
    :param arg1: description of arg1
    :type arg1: str
    :param arg2: description of arg2
    :type arg2: str
    :param arg3: description of arg3
    :type arg3: str
    :returns: description of return value
    :rtype: int
    ''')

# Generated at 2022-06-11 21:17:58.213311
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest
    from .common import Docstring, DocstringMeta, DocstringParam
    # TODO: implement and automate test if possible


# Generated at 2022-06-11 21:18:01.458360
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    New in version 0.0.1.
    """
    assert GoogleParser().parse(text).short_description == 'New in version 0.0.1.'


# Generated at 2022-06-11 21:18:07.347939
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
A Google-style docstring parser.

:param foo: the foo param
:type foo: str
"""
    p = parse(text)
    expected = Docstring(
        short_description="A Google-style docstring parser."
    )
    expected.meta.append(
        DocstringParam(
            args=["param", "foo"],
            description="the foo param",
            arg_name="foo",
            type_name="str",
            is_optional=None,
            default=None,
        )
    )
    assert p.short_description == expected.short_description
    assert p.meta == expected.meta

# Generated at 2022-06-11 21:18:19.224335
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Docstring des funktions, die mit GoogleParser.parse(text) getestet wird
    def test_funktion(a, b, c):
        """docstring

        :param a:
        :type a: int
        :param b:
        :type b: int
        :param c:
        :type c: int
        :return:
        :rtype: int
        """
        return a * b * c

    doc = inspect.getdoc(test_funktion)

# Generated at 2022-06-11 21:18:29.977736
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Testing the method GoogleParser.parse
    # The instance below is an GoogleParser instantiated using the default parameters
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("desc") == Docstring(
        short_description="desc", long_description=None, meta=[]
    )
    assert parser.parse("desc\n\nmore desc") == Docstring(
        short_description="desc",
        long_description="more desc",
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parser.parse("desc\nmore desc") == Docstring(
        short_description="desc",
        long_description="more desc",
        meta=[],
    )

# Generated at 2022-06-11 21:18:39.854627
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """Args:
        arg1: description
        arg2: description"""
    d = parser.parse(docstring)
    assert d.short_description is None
    assert d.long_description is None
    assert len(d.meta) == 2
    assert d.meta[0].args[0] == "args"
    assert d.meta[0].args[1] == "arg1"
    assert d.meta[0].description == "description"
    assert d.meta[0].arg_name == "arg1"
    assert d.meta[0].type_name is None
    assert d.meta[0].default is None
    assert d.meta[0].is_optional is None
    assert d.meta[1].args[1] == "arg2"
    assert d.meta

# Generated at 2022-06-11 21:18:48.552196
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Args:
  arg1 (int): Description
    of arg1
  arg2 (str, optional): Description of arg2.
    Defaults to "b".
  arg3: Description of arg3.
  arg4: Other description
        of arg4.

Returns:
  int: Description of return value.

Raises:
  ValueError: If arg1 is equal to arg2.
  TypeError: If arg3 is not of type int.

Examples:
  >>> parse_google_docstring("Args: ...")
  Docstring(...)
"""
    doc = GoogleParser().parse(text)
    #
    assert len(doc.meta) == 8
    #
    assert doc.meta[0].args == ["param", "arg1 (int)"]

# Generated at 2022-06-11 21:19:00.908355
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Tests for one empty (None) argument
    assert GoogleParser().parse(None) == Docstring()

    # Tests for one empty ('') argument
    assert GoogleParser().parse('') == Docstring()

    # Tests for one empty argument with multiple lines
    assert GoogleParser().parse('\n\n') == Docstring()

    # Tests for docstring without details
    assert GoogleParser().parse('first line.\n') == Docstring(
        description='first line.')

    # Tests for docstring with details
    assert GoogleParser().parse('first line.\n    more details.\n') == Docstring(
        description='first line.', details='    more details.\n')

    # Tests for docstring with tags (keywords)
    assert GoogleParser().parse('first line.\n    :type name: str\n') == Doc

# Generated at 2022-06-11 21:19:12.181134
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Google style docstrings.

    The following are code examples::

        # Example 1
        # Example 2

    Args:
        arg1 (int): The first argument. Defaults to 2.
        arg2 (str): The second argument. Defaults to 'abc'.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    result = GoogleParser().parse(text)
    # print("-----------------")
    # print("short_description =", result.short_description)
    # print("long_description =", result.long_description)
    # print("blank_after_short_description =", result.blank_after_short_description)
    # print("blank_after_long_description =", result.blank_after_long_description)
    # print("-----------------")

# Generated at 2022-06-11 21:19:23.588888
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring
    from datetime import date
    google = GoogleParser()
    ds = google.parse("""This is a short description.

    This is a long description. It contains several sentences.
    More sentences.

    Args:
      arg1 (int): Description of arg1. Defaults to 10.
      arg2 (str): Description of arg2.

    Returns:
      tuple: Tuple of two items.
      The first one is int, the second one is str.
    """)

# Generated at 2022-06-11 21:19:32.544798
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        Google-style docstring.

        :param x: X argument
        :type x: str
        :returns: Yields
        :rtype: list
        :raises: ValueError
    """
    result = GoogleParser().parse(text)

# Generated at 2022-06-11 21:19:39.857652
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    text = '''
        This docstring contains information about the "bob" function.

        Args:
            arg1 (int): This is the first argument to the function.
            arg2 (str, optional): This is the second argument to the function.
                This is actually a long description, so it needs to span
                multiple lines, because a good description should really
                explain how the function works.
        Returns:
            bool: This specifies if the function did something useful or not.
    '''
    result = google_parser.parse(text)
    print(result)

    #assert result.arg1.args == "int"
    #assert result.arg2.description == "This is the second argument to the function. This is actually a long description, so it needs to span multiple lines, because a good description should really explain

# Generated at 2022-06-11 21:19:51.717813
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = GoogleParser().parse("""\
        Short description.

        Longer description.

        Args:
            arg1 (Optional[int]): arg1. Defaults to 0.
            arg2 (int): arg2. Defaults to 1.

        Raises:
            NotImplementedError: Raises NotImplementedError.

        Returns:
            int: The return value.
    """)
    assert isinstance(doc, Docstring)

    assert doc.short_description == "Short description."
    assert doc.long_description == "Longer description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert len(doc.meta) == 3

    meta = doc.meta[0]
    assert isinstance(meta, DocstringParam)
    assert meta.arg_name

# Generated at 2022-06-11 21:20:02.278577
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''  A Google-style docstring.

    :param str arg1: The first argument.
    :param str arg2: The second argument.
    :raises ValueError: Raises Exception
    :return: None
    '''

    parsed = parse(docstring)

    assert parsed.short_description == "A Google-style docstring."

    assert parsed.meta[1].args[0] == 'param'
    assert parsed.meta[1].args[1] == 'arg1'
    assert parsed.meta[1].arg_name == 'arg1'
    assert parsed.meta[1].type_name == 'str'
    assert parsed.meta[1].is_optional == False
    assert parsed.meta[1].description == 'The first argument.'
    assert parsed.meta[1].default is None

    assert parsed

# Generated at 2022-06-11 21:20:14.001393
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for empty text
    text = ""
    ret = parse(text)
    assert ret.short_description == None
    assert ret.long_description == None
    
    # Test for only short description
    text = "Short description."
    ret = parse(text)
    assert ret.short_description == "Short description."
    
    # Test for short description and long description
    text = "Short description.\n    Long description."
    ret = parse(text)
    assert ret.short_description == "Short description."
    assert ret.long_description == "Long description."
    assert ret.blank_after_short_description == True

    text = "Short description.\n\n    Long description."
    ret = parse(text)
    assert ret.short_description == "Short description."

# Generated at 2022-06-11 21:20:22.972158
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Write a function to compute the list of the first n fibonacci numbers
    This function should use recursion for it's implementation
    Args:
        n (int): nth element in fibonacci series
    Returns:
        list: list of elements in fibonacci series
    """
    parsed_docstring = GoogleParser().parse(docstring)
    print(parsed_docstring.long_description)
    print(parsed_docstring.short_description)
    print(parsed_docstring.meta[0])
    print(parsed_docstring.meta[1])
    print(parsed_docstring.meta[2])
    print("Success")



# Generated at 2022-06-11 21:20:24.926042
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse(None) is not None
    assert parse(" ") is not None
    assert parse("  ") == parse("  ")



# Generated at 2022-06-11 21:20:42.461184
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("test_GoogleParser_parse ... ", end="")
    # one-line docstring
    assert GoogleParser().parse("one-line docstring").short_description == "one-line docstring"
    assert GoogleParser().parse("one-line docstring").long_description == None
    assert GoogleParser().parse("one-line docstring").blank_after_short_description == False
    assert GoogleParser().parse("one-line docstring").blank_after_long_description == False
    assert GoogleParser().parse("one-line docstring").meta == []

    # multi-line docstring with examples as sections

# Generated at 2022-06-11 21:20:55.241107
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Foo:
        def add(self, a: int, b: int) -> int:
            "Add a and b.\n\n:type a: int\n:type b: int\n:rtype int:\n"
            return a + b

        def add_with_doc(self, a: int, b: int) -> T.Union[int, str]:
            """
            Add a and b.

            Parameters
            ----------
            a
                First number.
            b
                Second number.

            Returns
            -------
            int
                Sum of a and b.
            """
            return a + b

    d = parse(Foo.add.__doc__)
    assert d.short_description == "Add a and b."

# Generated at 2022-06-11 21:21:06.594904
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """The most important attributes.

Examples:
    >>> a.attr1
    1
    >>> a.attr2
    2

Attributes:
    attr1: Description of attribute 1.
    attr2: Description of attribute 2.
"""
    p = parse(doc)
    assert p.short_description == "The most important attributes."
    assert p.long_description == """Examples:
>>> a.attr1
1
>>> a.attr2
2

Attributes:
    attr1: Description of attribute 1.
    attr2: Description of attribute 2."""

# Generated at 2022-06-11 21:21:11.962151
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    s = "Configure a system to perform a VASP calculation.\n\n\nArgs:\n    structure: The input structure\n    specification: The calculation parameters\n    name: A name to associate with the calculation\n\nRaises:\n    ValueError: If something is wrong.\n\nReturns the generated CalcJob node.\n"
    p = GoogleParser()
    print(p)

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:21:23.113832
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_GoogleParser_parse_1()
    test_GoogleParser_parse_2()
    test_GoogleParser_parse_3()
    test_GoogleParser_parse_4()
    test_GoogleParser_parse_5()
    test_GoogleParser_parse_6()
    test_GoogleParser_parse_7()
    test_GoogleParser_parse_8()
    test_GoogleParser_parse_9()
    test_GoogleParser_parse_10()
    test_GoogleParser_parse_11()
    test_GoogleParser_parse_12()
    test_GoogleParser_parse_13()
    test_GoogleParser_parse_14()
    test_GoogleParser_parse_15()
    test_GoogleParser_parse_16()
    test_GoogleParser_parse_17()
    test_GoogleParser_parse_18()
   

# Generated at 2022-06-11 21:21:35.726137
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """    Docstring of module to be parsed.

    :param int a: first param a
    :param int b: second param b
    :return: a+b"""

    docstring = parse(text)

    assert docstring.short_description == 'Docstring of module to be parsed.'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-11 21:21:45.015128
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
Args:
    arg1 (int): The first argument.
    arg2 (str): The second argument.

Raises:
    TypeError: if `arg2` is not a string.
    ValueError: if `arg2` is not "yes".

Returns:
    bool: The return value. True for success, False otherwise.
    '''

# Generated at 2022-06-11 21:21:54.061229
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """This is a general description of this module.

Args:
  arg1 (a): The first argument.
  arg2 (b): The second argument.
  arg3 (c): The third argument.

Returns:
  The return value.
"""
    result = GoogleParser().parse(text)
    assert result.short_description == "This is a general description of this module."
    assert result.long_description == None
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0]['description'] == "The first argument."
    assert result.meta[0].kwargs == {'arg_name': 'arg1', 'type_name': 'a', 'is_optional': False}

# Generated at 2022-06-11 21:22:06.435893
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:22:19.026767
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("abc\n") == Docstring(
        short_description="abc", blank_after_short_description=True
    )
    assert parse("abc\n\ndef") == Docstring(
        short_description="abc",
        blank_after_short_description=True,
        long_description="def",
    )
    assert parse("abc\n\n  def") == Docstring(
        short_description="abc",
        blank_after_short_description=True,
        long_description="def",
    )

# Generated at 2022-06-11 21:22:31.904587
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    if __name__ != "__main__":
        from . import doctest_google_parser  # type: ignore

        g = GoogleParser()
        g.sections = doctest_google_parser.SECTIONS
        g._setup()
        for test_docstring, test_result_dict in doctest_google_parser.SAMPLES:
            result = g.parse(test_docstring)
            assert test_result_dict == result.__dict__  # type: ignore

# Generated at 2022-06-11 21:22:43.820542
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """A short summary.

    Then, an optional longer description.

    Parameters:
        a: info
        b: more info
        c:
            more
        d (optional): even more

    Returns:
        a return value

    Raises:
        AError

    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "A short summary."
    assert ret.long_description == "Then, an optional longer description."
    assert ret.meta[0].arg_name == "a"
    assert ret.meta[0].description == "info"
    assert ret.meta[1].arg_name == "b"
    assert ret.meta[1].description == "more info"
    assert ret.meta[2].arg_name == "c"

# Generated at 2022-06-11 21:22:46.104657
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Code to test
    google_parser = GoogleParser()
    return google_parser.parse(text)


# Generated at 2022-06-11 21:22:52.791223
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc1 = '''This is the short description of the method.

    This is the long description of the function which spans
    multiple lines.
    '''
    doc2 = '''This is the short description of the method.

    This is the long description of the function which spans
    multiple lines.

    Examples:
        This is an example of how to use the method::
            # doctest: +SKIP
            foo()
    '''

# Generated at 2022-06-11 21:23:00.888756
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
    Name
        menu_generator
    Arguments
        args: A sequence of iterables, it can be list or tuple.
              Defaults to (1,2,3,4,5).
    Returns
        A tuple of iterables.
    Raises
        ValueError: If args is None.
    Examples
        >>> x = [[1,2],[3,4]]
        >>> x
        >>> [[1,2],[3,4]]
        >>> list(zip(*x))
        >>> [(1,3),(2,4)]
    """

    parser = GoogleParser()
    docstring = parser.parse(doc)
    assert docstring.long_description == "A sequence of iterables, it can be list or tuple.\n\nDefaults to (1,2,3,4,5)."

# Generated at 2022-06-11 21:23:11.121834
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "Short description.\n\nLong description."
    assert GoogleParser().parse(docstring) == Docstring(
        short_description="Short description.",
        blank_after_short_description=False,
        long_description="Long description.",
        blank_after_long_description=False,
        meta=[],
    )

    docstring = "Short description.\n\n\nLong description."
    assert GoogleParser().parse(docstring) == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        long_description="Long description.",
        blank_after_long_description=False,
        meta=[],
    )

    docstring = "Short description.\n\nLong description.\n\n"

# Generated at 2022-06-11 21:23:20.189412
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test of a simple docstring
    text = """
        Short description.

        Long description.

        Args:
            arg1 (int): Description of arg1.
            arg2 (str): Description of arg2. Defaults to None.

        Returns:
            bool: Description of return value.

        Raises:
            AttributeError: The reason.
    """

# Generated at 2022-06-11 21:23:31.402356
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  text = '''
Test docstring.

Args:
    param1 (str): Test parameter.
    param2 (str): Test parameter. Defaults to 'test'.

Returns:
    Test return value.
  '''

  assert str(GoogleParser().parse(text)) == '''short_description: Test docstring.
long_description: None
blank_after_short_description: True
blank_after_long_description: False
meta: [<Parameter: arg0 param0 arg1 param1 arg_name param1 type_name str description Test parameter.>, <Parameter: arg0 param0 arg1 param2 arg_name param2 type_name str description Test parameter. Defaults to 'test'. default 'test'>, <Returns: arg0 returns arg1 Test return value. type_name Test return value.>]'''


# Generated at 2022-06-11 21:23:34.966600
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    try:
        GoogleParser().parse("")
    except ParseError as e:
        assert "No specification for" in str(e)

# Generated at 2022-06-11 21:23:43.124420
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Parse the Google-style docstring into its components.

    :param title_colon: require colon after section title.
    :type title_colon: bool
    :param sections: Recognized sections or None to defaults.
    :type sections: T.Optional[T.List[Section]]
    :returns: parsed docstring
    :rtype: Docstring
    :raises ParseError: on errors
    :yields: section
    """
    print(GoogleParser().parse(docstring))


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:24:01.841164
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('A docstring.') == Docstring(
        short_description='A docstring.',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )
    assert GoogleParser().parse('A docstring.\n\nA long desc.') == Docstring(
        short_description='A docstring.',
        long_description='A long desc.',
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[]
    )

# Generated at 2022-06-11 21:24:14.824329
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-11 21:24:22.459510
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()

    doc_contents = '''\
    This is an example of a google style docstring with more than
    one line.

    Args:
        param1 (str): The first parameter.
        param2 (:obj:`int`, optional): The second parameter.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.
    '''

# Generated at 2022-06-11 21:24:35.027219
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Test GoogleParser.parse")
    docstring_parser = GoogleParser()

# Generated at 2022-06-11 21:24:46.589486
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    s = "Summary line.\n\nDescription, will be indented.\n\n    Line with indent.\n\nArgs:\n    a (int): the first argument, will be indented\n        with description following on the next line,\n        indented further.\n    b:\n        the second argument,\n        will also be indented, but description\n        will be on the same line.\n    c:\n        the third argument\n    d? (str): the fourth argument. Optional.\n\nReturns:\n    returns something.\n\nRaises:\n    ValueError: If something wrong.\n\n    TypeError: If something wrong.\n"
    print(parse(s))
    print(GoogleParser().parse(s))
    print(parse(s).long_description)

# Generated at 2022-06-11 21:24:56.830904
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """Short summary.

    This function does nothing.
    It returns None.

    Args:
        param1 (int): Description of param1.
        param2 (:obj:`float`, optional): Description of param2. Default: 0.0.
    Returns:
        None
    """
    parsed = parser.parse(docstring)
    # short_description
    assert parsed.short_description == "Short summary."
    # long_description
    assert parsed.long_description == "This function does nothing.\nIt returns None."
    # blank_after_short_description
    assert parsed.blank_after_short_description == True

    # meta
    assert len(parsed.meta) == 2
    # meta[0]
    assert parsed.meta[0].__class__.__name

# Generated at 2022-06-11 21:25:06.817343
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = inspect.cleandoc("""\
        This is what a google style docstring looks like.

        Args:
            arg1 (:obj:`int`): The first thing to be passed.
            arg2 (:obj:`str`, optional): The second thing to be passed.
                                        Defaults to "".
            arg3 (:obj:`list`): A list.
                - 4 spaces for sub items
        Raises:
            ValueError: If things aren't good.

        Returns:
            :obj:`str`: Some important value.

        Example:
            >>> print(len('wow'))
            3
    """)
    print(docstring)
    result = GoogleParser().parse(docstring)
    print(result)

# Generated at 2022-06-11 21:25:13.941660
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  obj = GoogleParser()
  text = ""
  ret = obj.parse(text)
  assert ret.short_description == None
  assert ret.blank_after_short_description == False
  assert ret.blank_after_long_description == False
  assert ret.long_description == None
  
  text = "Return a list of the numbers in the string s.\n\n   >>> extract_numbers(['Hello', '1', '2'])\n   [1, 2]"
  ret = obj.parse(text)
  assert ret.short_description == 'Return a list of the numbers in the string s.'
  assert ret.blank_after_short_description == True
  assert ret.blank_after_long_description == True

# Generated at 2022-06-11 21:25:15.153991
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #TODO
    pass

# Generated at 2022-06-11 21:25:25.913179
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  assert GoogleParser().parse(__doc__) == Docstring(
    short_description="Google-style docstring parsing.",
    blank_after_short_description=True,
    blank_after_long_description=True,
    long_description="""Parses a Google-style docstring into its components.

:returns: parsed docstring
""".strip(),
    meta=[
      DocstringMeta(
        args=["Yields"],
        description="A Google-style docstring into its components.",
      ),
      DocstringMeta(
        args=["Parameters", "text"],
        description="The text of the docstring.",
      ),
      DocstringMeta(
        args=["Raises", "ParseError"],
        description="If the docstring is not valid.",
      ),
    ],
  )