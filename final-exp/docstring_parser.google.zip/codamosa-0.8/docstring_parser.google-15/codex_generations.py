

# Generated at 2022-06-11 21:16:08.752241
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text1 = """Docstring for a method.

    Args:
        a: int - parameter a

    Returns:
        int - the result
    """
    text2 = """Docstring for a method.

    Args:
        a: int - parameter a
    Other:
        b: int - parameter b

    Returns:
        int - the result
    """
    text3 = """Docstring for a method.

    Args:
        a: int - parameter a

    Returns:
        int - the result
        bool - the truth value
    """

# Generated at 2022-06-11 21:16:17.430321
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()

    assert GoogleParser().parse("short\n\nlong") == Docstring(
        short_description="short",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="long",
    )


# Generated at 2022-06-11 21:16:30.500152
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("\n\nRunning test_GoogleParser_parse")
    docstring = """This is a module.

Args:
    arg1: the first argument
        Here the first argument is described.

        This is a second line.
    arg2 (int): the second argument
        A longer description of the second argument. Defaults to None.
    arg3 (int): the third argument. Defaults to 42.

Returns:
    int: the answer to the question
    """

    print("\n\nTesting {}".format(docstring))
    parsed = parse(docstring)
    print(parsed)

    assert parsed.short_description == "This is a module."

# Generated at 2022-06-11 21:16:43.809831
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    
    # Construct input
    text = "First line.\n\nSecond line.\n\n:param arg1: first argument.\n:param arg2: second argument.\n\nLast line."

    # Execute the function being tested
    result = GoogleParser().parse(text)

    # Verify the result
    assert result.short_description == "First line."
    assert result.long_description == "Second line."
    assert result.blank_after_short_description == True
    assert len(result.meta) == 2
    assert result.meta[0].args == ["param", "arg1"]
    assert result.meta[0].description == "first argument."
    assert result.meta[1].args == ["param", "arg2"]
    assert result.meta[1].description == "second argument."
    

# Unit

# Generated at 2022-06-11 21:16:48.579047
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    ###############
    # Expected output
    ###############

    expected_output = Docstring(
        short_description="""
        Parse the Google-style docstring into its components.
        """
    )

# print(GoogleParser().parse.__doc__)



# Generated at 2022-06-11 21:16:56.929193
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class X:
        """an example:
        a
        b

        Args:
          x: a parameter. Defaults to 0.
          y: another parameter. Defaults to 1
        Raises:
          ValueError: always.
        Returns:
          None
        """

    docstring = parse(X.__doc__)
    assert docstring.short_description == "an example"
    assert docstring.long_description == "a\nb"
    assert len(docstring.meta) == 4

# Generated at 2022-06-11 21:17:06.018562
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    # the docstring to parse
    docstring = '''
        :param x: the value to perform action on
        '''
    parser = GoogleParser()
    parser.add_section(Section("Test", "test", SectionType.SINGULAR))
    parsed_docstring = parser.parse(docstring)
    assert len(parsed_docstring.meta) == 1
    assert parsed_docstring.meta[0].args == ['param', 'x']
    assert parsed_docstring.meta[0].description == 'the value to perform action on'

# Generated at 2022-06-11 21:17:14.291689
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    sections: T.Optional[T.List[Section]] = None
    parser = GoogleParser(sections)
    section_add = Section("Test", "test", SectionType.SINGULAR)
    parser.add_section(section_add)
    section_replace = Section("Args", "param", SectionType.SINGULAR)
    parser.add_section(section_replace)
    assert parser.sections["Test"] == section_add
    assert parser.sections["Args"] == section_replace
    sections = DEFAULT_SECTIONS + [section_replace]
    parser = GoogleParser(sections)
    assert parser.sections["Test"] == section_add
    assert parser.sections["Args"] == section_replace

# Generated at 2022-06-11 21:17:21.097996
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def setup():
        # make sure that the unit tests are being run from the project root
        import os
        assert os.path.abspath(os.path.curdir).split(os.sep)[-1] == "autodocstring"

        # change present working directory to testing directory
        import sys
        import os
        abspath = os.path.abspath(__file__)
        dname = os.path.dirname(abspath)
        os.chdir(dname)

        # add project root to path to we can import the tested module
        import sys
        sys.path.insert(0, dname + os.sep + "..")

    def teardown():
        # remove project root from path
        import sys
        sys.path.pop(0)

        # change back to project root


# Generated at 2022-06-11 21:17:33.011769
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    gp = GoogleParser()
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    before_dict = gp.sections.copy()
    gp.add_section(section)
    assert(gp.title_colon)
    after_dict = gp.sections
    before = set(before_dict.keys())
    after = set(after_dict.keys())
    keys_added = after - before
    keys_removed = before - after
    assert(len(keys_added)==0)
    assert("Arguments" in after)
    assert("Args" not in after)
    assert("Arguments" in after)
    assert("Parameters" in after)
    assert("Params" in after)
    assert("Raises" in after)
    assert("Exceptions" in after)

# Generated at 2022-06-11 21:18:00.523320
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    testString = "Replace the item at index with x.\n\nRaises:\nIndexError: if index is out of range\nTypeError: if x is of an inappropriate type for this container\n"

# Generated at 2022-06-11 21:18:08.177061
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest
    from .common import DocstringParam

    def test_parse(text, expected):
        assert GoogleParser().parse(text).meta == expected

    test_parse("a short description\n\n", [])
    test_parse("a short description\n\nand a long one\n", [])
    test_parse("a short description\n\nand\na long one\n", [])
    test_parse("a short description\n\n   and a long one\n", [])
    test_parse("a short description\n   \nand a long one\n", [])

    meta = [DocstringParam(args=["param", "x"],
                           description="A positional argument.",
                           arg_name="x", type_name=None, is_optional=None, default=None)]
    test_

# Generated at 2022-06-11 21:18:19.971317
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    example = """
    Example of google docstring
    short description
    long description

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Raises:
        KeyError: Raises an exception.

    Returns:
        True if successful, False otherwise.

    """
    # case 1

# Generated at 2022-06-11 21:18:30.414506
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:18:40.116088
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = inspect.cleandoc(
        """Function returns
        the number of times foo is in the string.

        Args:
            a: description of a
            b: description of b
        
        Raises:
            TypeError if a is not str.

        Returns:
            int: number of foos.
    
        Examples:
            >>> foo_count("i love foo bar")
            2
            >>> foo_count("foo")
            1
        """
    )
    result = parse(text=text)
    assert isinstance(result, Docstring)
    assert len(result.meta) == 4
    assert isinstance(result.meta[0], DocstringParam)
    assert isinstance(result.meta[1], DocstringRaises)
    assert isinstance(result.meta[2], DocstringReturns)

# Generated at 2022-06-11 21:18:48.697342
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # 1. doctest normal
    text = """
    Sums two numbers.

    :param a: The first number.
    :type a: int
    :param b: The second number.
    :type b: int
    :returns: The sum of two numbers.
    :rtype: int
    """
    text = inspect.cleandoc(text)
    g = GoogleParser()
    ret = Docstring()
    ret.short_description = 'Sums two numbers.'
    ret.blank_after_short_description = False
    ret.blank_after_long_description = True
    ret.long_description = None
    ret.meta = []

# Generated at 2022-06-11 21:18:50.674932
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert(True)

# Generated at 2022-06-11 21:18:59.863207
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = '''
    some text
    ----------------
    some text

    Parameters
    ----------
    arg1 : float
        arg1 description
    arg2 : float
        arg2 description
    arg3 (float):
    '''
    parser = GoogleParser()
    parsed = parser.parse(doc)
    assert parsed.short_description == 'some text', 'Short description is not parsed correctly'
    assert parsed.long_description == 'some text', 'Long description is not parsed correctly'
    assert parsed.blank_after_short_description == True, 'Blank_after_short_description is not parsed correctly'
    assert parsed.blank_after_long_description == True, 'Blank_after_long_description is not parsed correctly'
    assert len(parsed.meta) == 3, 'Meta is not parsed correctly'
    assert isinstance

# Generated at 2022-06-11 21:19:05.137305
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    Parse Google-style docstrings into a Docstring.

    :param text: docstring
    :return: parsed docstring
    '''
    p = GoogleParser()
    print(p.parse(docstring))

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:19:14.640465
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  google_parser = GoogleParser()
  assert google_parser.titles_re == re.compile(
      '^((?P<Arguments>Arguments)|(?P<Args>Args)|(?P<Parameters>Parameters)|(?P<Params>Params)|(?P<Raises>Raises)|(?P<Exceptions>Exceptions)|(?P<Except>Except)|(?P<Attributes>Attributes)|(?P<Example>Example)|(?P<Examples>Examples)|(?P<Returns>Returns)|(?P<Yields>Yields)):[ \t\r\f\v]*$',
      flags=re.M
  )


# Generated at 2022-06-11 21:19:31.743257
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from pprint import pprint
    from inspect import getdoc
    google_parser = GoogleParser()
    def test_func(world: None, universe: None) -> str:
        """This is a test function docstring.

        Args:
            world: the name of the world
            universe: the name of the universe

        Returns:
            test_func: The name of the test function.

        """
        return 'test_func'

    print("test_func.__doc__: {}".format(test_func.__doc__))
    pprint(google_parser.parse(getdoc(test_func)))

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:19:39.509270
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = "Compute the factorial of a number.\n\n    Args:\n        n (int): The number to compute the factorial of.\n\n    Returns:\n        int: The computed factorial.\n\n    Examples:\n        >>> fact(5)\n        120\n    "

    # TODO: Multi-line arguments and descriptions
    # '''
    # Compute the factorial of a number.
    #
    # Args:
    #     n (int): The number to
    #         compute the factorial of.
    #
    # Returns:
    #     int: The computed
    #         factorial.
    #
    # Examples:
    #     >>> fact(5)
    #     120
    # '''
    doc_results = parse(doc)

# Generated at 2022-06-11 21:19:51.396099
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Find the minimum number of coins required to make n cents.

    You can use standard American denominations, that is, 1¢, 5¢, 10¢, and
    25¢.

    For example, given n = 16, return 3 since we can make it with a 10¢, a
    5¢, and a 1¢.

    Arguments:
        n (int): the amount to make with coins

    Returns:
        int: the minimum number of coins

    Raises:
        ValueError: if n is negative
    """
    doc = parse(text)


# Generated at 2022-06-11 21:20:02.046938
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        This is a summary.

        This is a longer description.
        See also http://example.com.

        Args:
            arg1: The first argument.
            arg2: The second argument.
            arg3 (int): The third argument. Defaults to 1.
            arg4 (str, optional): The fourth argument. Defaults to 'default'.

        Returns:
            int: The return value.
        """
    docstring = GoogleParser().parse(text)
    docstring_items = [docstring.short_description, docstring.long_description, docstring.meta[0].description, docstring.meta[1].description, docstring.meta[0].type_name, docstring.meta[1].type_name, docstring.meta[0].default, docstring.meta[1].default]
    expected_items

# Generated at 2022-06-11 21:20:13.779130
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def function():
        """The function's docstring.

        Some text.

        Args:
            arg1 (str): The first argument.

        Returns: int

        Raises:
            TypeError: if an error occurs

        Example:
            foo
            bar
        """

        pass

    docstring = parse(function.__doc__)
    assert (
        docstring.short_description == "The function's docstring."
    ), "Short Description"
    assert docstring.long_description is None, "Long Description"
    assert docstring.blank_after_short_description, "Blank after short description"
    assert not docstring.blank_after_long_description, "Blank after long description"

    meta = docstring.meta
    assert len(meta) == 3, "Length of meta list"
    assert meta[0]

# Generated at 2022-06-11 21:20:23.667417
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
        Returns the text input after performing a simple regex based
        subsititution.

        Args:
            text (str): The text to perform subsitution on.
            subsitutions (dict): A dictionary of subsitutions where the
                keys are the regex strings to match and the values are the
                strings that should be substituted in.
        Returns:
            str: The text after subsitutions have been performed.
    '''
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "Returns the text input after performing a simple regex based subsititution."

# Generated at 2022-06-11 21:20:37.029479
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test 1
    parser = GoogleParser()
    assert parser.parse("") == Docstring()

    # test 2
    parser = GoogleParser()
    assert parser.parse(
        "The first line is the short description.\n"
        "The rest of the lines until the first empty one\n"
        "make up the long description.\n\n"
        "The text after the second empty line is extra and\n"
        "should be ignored."
    ) == Docstring(
        short_description="The first line is the short description.",
        long_description="The rest of the lines until the first empty one\n"
        "make up the long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    # test 3

# Generated at 2022-06-11 21:20:44.053455
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def func(x:int, y:str = "Hello") -> str:
        """
        This is a really long description of this function.
        Should this line be long?
        Arguments:
            x (int): Description of first argument
            y (str, optional): Description of second argument.
                Defaults to "Hello".
        Returns:
            str: Description of the return value
        Raises:
            ValueError: Description of ValueError exception and that
                it is propagated up.
        """
        pass

# Generated at 2022-06-11 21:20:56.189276
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert (
        parser.parse("short description\n\nlong\ndescription\n")
        == Docstring(
            short_description="short description",
            blank_after_short_description=False,
            blank_after_long_description=False,
            long_description="long\ndescription",
            meta=[],
        )
    )
    assert (
        parser.parse("short description\n\nlong\ndescription")
        == Docstring(
            short_description="short description",
            blank_after_short_description=False,
            blank_after_long_description=False,
            long_description="long\ndescription",
            meta=[],
        )
    )

# Generated at 2022-06-11 21:20:58.479305
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()



# Generated at 2022-06-11 21:21:15.093905
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""

    def _test(google_docstring, python_docstring):
        assert GoogleParser().parse(google_docstring).__dict__ == python_docstring.__dict__

    _test(
        "Does nothing.\n",
        Docstring(
            short_description="Does nothing.",
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        ),
    )
    _test(
        "Does nothing.\n\n",
        Docstring(
            short_description="Does nothing.",
            long_description=None,
            blank_after_short_description=True,
            blank_after_long_description=False,
            meta=[],
        ),
    )
   

# Generated at 2022-06-11 21:21:24.896894
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = """
    Parameters:
        a (str): First variable
        b (int): Second variable
    """
    res = GoogleParser().parse(docstr)
    assert len(res.meta) == 2
    assert res.meta[0].args == ['param', 'a (str)']
    assert res.meta[0].arg_name == 'a'
    assert res.meta[0].type_name == 'str'
    assert res.meta[0].description == 'First variable'
    assert res.meta[1].args == ['param', 'b (int)']
    assert res.meta[1].arg_name == 'b'
    assert res.meta[1].type_name == 'int'
    assert res.meta[1].description == 'Second variable'

# Generated at 2022-06-11 21:21:30.393985
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse(text)

if __name__ == "__main__":
    # check unit test
    test_GoogleParser_parse()
    # print docstring
    print(docstring)

# Generated at 2022-06-11 21:21:40.648099
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:21:47.562697
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = """This function does something.

Args:
    param1: The first parameter.
    param2: The second parameter.

Returns:
    bool: The return value. True for success, False otherwise.
"""

    def main(text: str) -> None:
        print("INPUT:")
        print(text)
        print("\nOUTPUT:")
        print(GoogleParser().parse(text))

    main(docstr)

# Generated at 2022-06-11 21:21:54.918045
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Parse the Google-style docstring into its components.
    :returns: parsed docstring
    """
    short_description = "Parse the Google-style docstring into its components."
    long_description = ":returns: parsed docstring"
    returned_type = "str"
    returned_description = "parsed docstring"
    returned_element = Docstring(
        short_description = short_description,
        long_description = long_description,
        blank_after_short_description = False,
        blank_after_long_description = False,
        meta = [DocstringReturns(
            description = returned_description,
            type_name = returned_type,
            args = ["returns", returned_type],
            is_generator = False
        )],
    )
    assert returned_element

# Generated at 2022-06-11 21:21:59.595655
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    text = ("A\n"
            "  B\n"
            "    C\n"
            "D\n"
            "E\n"
            "F\n")
    print(gp.parse(text))


# Generated at 2022-06-11 21:22:09.622404
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text=""":param name:
    :param age:"""
    GoogleParser().parse(text)
    text=""":param name: str
    name of the person
    :param age: int
    age of the person"""
    GoogleParser().parse(text)
    text=""":param name: str
    name of the person
    :param age: int
    age of the person
    :returns: the person
    :rtype: class 'Person'"""
    GoogleParser().parse(text)
    text=""":param name: str
    name of the person
    :param age: int
    age of the person
    :returns: the person
    :rtype: class
        'Person'"""
    GoogleParser().parse(text)

# Generated at 2022-06-11 21:22:21.157533
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("""
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """) == Docstring(
        short_description="Parse the Google-style docstring into its components.",
        long_description="parsed docstring",
        meta=[
            DocstringReturns(
                args=["returns", None],
                description=None,
                type_name=None,
                is_generator=False,
            )
        ],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )


# Generated at 2022-06-11 21:22:31.522950
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = GoogleParser().parse("""
    Short description of function.

    Description of funcion.

    Args: arg1: Description of arg1
          arg2 (str): Description of arg2.

    Returns: Description of return value.

    Raises: ExceptionOne: Description of ExceptionOne
            ExceptionTwo: Description of ExceptionTwo
    """)
    assert doc.short_description == "Short description of function."
    assert doc.long_description == "Description of funcion."
    assert len(doc.meta) == 5
    assert doc.meta[0].args[0] == "examples"
    assert doc.meta[0].args[1] == None
    assert doc.meta[0].description == None
    assert doc.meta[1].args[0] == "param"

# Generated at 2022-06-11 21:22:58.684355
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    One line summary
    """
    expected = Docstring(short_description="One line summary", long_description=None)
    actual = parse(docstring)
    assert actual == expected

    docstring = """
    One line summary

    longer description
    """
    expected = Docstring(short_description="One line summary", long_description="longer description", blank_after_short_description=True, blank_after_long_description=False)
    actual = parse(docstring)
    assert actual == expected

    docstring = """
    One line summary
    longer description
    """
    expected = Docstring(short_description="One line summary", long_description="longer description", blank_after_short_description=False, blank_after_long_description=False)
    actual = parse(docstring)
    assert actual

# Generated at 2022-06-11 21:23:09.361438
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser."""
    gp = GoogleParser()

# Generated at 2022-06-11 21:23:19.693593
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("Test.") == Docstring(short_description="Test.")
    assert parse("Test.\n") == Docstring(short_description="Test.")
    assert parse("Test.\n  ") == Docstring(short_description="Test.")
    assert parse("Test.\n\n") == Docstring(short_description="Test.")
    assert parse("Test.\n\n  ") == Docstring(short_description="Test.")
    assert (
        parse("Test.\n\nTest.\n") == Docstring(
            short_description="Test.", long_description="Test."
        )
    )

# Generated at 2022-06-11 21:23:31.079171
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import (
        DocstringReturns,
        DocstringParam
    )
    text = """
        module description.

        Attributes:
            x: an attribute.
            y: another attribute.
        """

    expected_return = Docstring()
    expected_return.short_description = 'module description.'
    expected_return.meta.append(
        DocstringParam(
            args=['attribute', 'x: an attribute.'],
            arg_name='x', type_name=None,
            is_optional=None, default=None,
            description='an attribute.'
        )
    )

# Generated at 2022-06-11 21:23:42.701211
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('"""'+'\n'
    '    Docstring for a function.'+'\n'
    '"""'+'\n') == Docstring(
        short_description='Docstring for a function.',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

# Generated at 2022-06-11 21:23:53.571333
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:24:03.066479
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test the method parse of class GoogleParser
    """
    # test for nonexisting docstring
    test_string = ""
    assert(GoogleParser().parse(test_string) == Docstring())

    # test for short_description
    test_string = "hello world"
    result = GoogleParser().parse(test_string)
    assert(result.short_description == "hello world")
    # test if preserve newline
    test_string = "\nhello world"
    assert(GoogleParser().parse(test_string).short_description == "hello world")

    # test for arguments
    test_string = """
        hello world

        Args:
            arg1 (int): number of foos.
            arg2 (str): path of bar.
    """
    result = GoogleParser().parse(test_string)

# Generated at 2022-06-11 21:24:15.813241
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for empty docstring
    assert GoogleParser().parse('') == Docstring()

    # Test for docstring with only a short description
    text = 'Calculate the sum of a and b'
    assert GoogleParser().parse(text) == Docstring(
        short_description = text,
        blank_after_short_description = True,
        blank_after_long_description = True,
        long_description = None,
        meta = []
    )

    # Test for docstring with only a short description with a colon in it
    text = 'Call: Calculate the sum of a and b'

# Generated at 2022-06-11 21:24:22.806103
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ds = """Parses arguments for a function.
    This function takes a list of arguments and resolves any kind of
    nested parameter.

    Args:
        string (str): String to parse.

    Raises:
        ValueError: If the string is invalid.

    Returns:
        str: The parsed string.
    """
    gp = GoogleParser()
    ret = gp.parse(ds)
    assert ret.short_description == 'Parses arguments for a function.'
    assert ret.long_description == 'This function takes a list of arguments and resolves any kind of\nnested parameter.'
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert isinstance(ret.meta[0], DocstringParam)
    DocstringParam(ret.meta[0])

# Generated at 2022-06-11 21:24:35.118741
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing method parse of class GoogleParser...")

# Generated at 2022-06-11 21:25:03.544059
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class TestClass:

        def __init__(self, test_val: T.Optional[int]):
            self.test_val = 0

        def __repr__(self):
            return "TestClass(test_val={})".format(self.test_val)

        def test_method(self, param1: int, param2: T.Optional[int] = 3) -> int:
            """This is a test method.

            Params:
                param1: the first parameter.
                param2: the second parameter.

            Returns:
                an integer.
            """

            return param1 + param2

    test_method = TestClass(0).test_method
    assert("test_method" == inspect.getdoc(test_method).split("\n")[0])

# Generated at 2022-06-11 21:25:11.866941
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = '''Short description.

Long description.

Args:
     x (int): description. Defaults to 42.
     y (bool): description. Defaults to True.

Returns:
    (int): the value of x.
    '''

# Generated at 2022-06-11 21:25:13.697325
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    for s in globals().keys():
        if s.startswith("test"):
            globals()[s]()


# Generated at 2022-06-11 21:25:24.827239
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """Example Google-style docstring.

This module demonstrates documentation as specified by the `Google Python Style Guide`_.

Args:
    parameter1(int): The first parameter.
    parameter2(str): The second parameter.
    Requiere(bool): Whether the parameter is required.
        Defaults to True.

Raises:
    AttributeError: The ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.

Returns:
    bool: The return value. True for success, False otherwise.

"""
    docstring = parser.parse(text)
    print(docstring.short_description)
    print(docstring.long_description)

# Generated at 2022-06-11 21:25:32.064942
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:25:36.209677
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    Google-style docstring

    :param a: integer to add
    :type a: int
    :param b: integer to add
    :type b: int
    :return: integer a + b
    :rtype: int
    :raises ValueError: If a or b is not an integer.
    """

    docstring = GoogleParser().parse(text)
    if docstring:
        print("Docstring.short_description = " + docstring.short_description)
        print("Docstring.long_description = " + docstring.long_description)
        for meta in docstring.meta:
            print(meta)
    else:
        print("Failed to parse")


# Generated at 2022-06-11 21:25:41.715066
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Docstring with args in the format

    :param arg1: description of arg1
    :type arg1: int
    :param arg2: description of arg2
    :type arg2: str, optional
    :param arg3: description of arg3
    :type arg3: str, optional. Defaults to 'foo'.

    :Example:
        Example code for this function
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "Docstring with args in the format"
    assert len(docstring.meta) == 4
    assert docstring.meta[0].description == "description of arg1"
    assert docstring.meta[0].type_name == "int"
    assert docstring.meta[0].is_optional == False
    assert doc