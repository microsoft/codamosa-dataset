

# Generated at 2022-06-11 21:16:06.043098
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''  A docstring for the test.

  Attributes:
    attr1 (int, optional): Description for attr1. Defaults to 56
    attr2 (str, optional): Description for attr2. Defaults to "abc"
    attr3 (float, optional): Description for attr3. Defaults to 56.0
    attr4 (bool, optional): Description for attr4. Defaults to None'''

    parser = GoogleParser()
    result = parser.parse(docstring)

    short_description = 'A docstring for the test.'
    long_description = None
    blank_after_short_description = True
    blank_after_long_description = True

    print('\n====================')
    print('Testing parse function')
    print('Result: ', result)
    print('Expected:')

# Generated at 2022-06-11 21:16:13.097416
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:16:19.644108
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    to_test = [
        """
        This is the first line of the docstring part.

        This is the second line of the docstring part.

        Args:
            a: an attribute
            b (:class:`int`): an optional attribute
            kwargs: Optional keyword arguments.

        Example:
            Examples can be given using either the ``Example`` or ``Examples``
            sections. Sections support any reStructuredText formatting, including
            literal blocks::

                $ python example_google.py

        Examples can be given using either the ``Example`` or ``Examples``
        sections. Sections support any reStructuredText formatting, including
        literal blocks::

            $ python example_google.py

        Yields:
            The return value. True for success, False otherwise.
        """
    ]


# Generated at 2022-06-11 21:16:31.658485
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_1 = """This is the first line of docstring.

This is the second line.
"""

    text_2 = """This is the first line of docstring.

This is the second line.

Args:
    param1: This is the first parameter.
    param2: This is a second parameter.

Returns:
    This is a return value.
"""

    text_3 = """This is the first line of docstring.

This is the second line.

Parameters:
    param1: The first parameter.
    param2: The second parameter.

Returns:
    The return value.
"""


# Generated at 2022-06-11 21:16:44.725093
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Single line summary.

Single line description.

Args:
  foo (str): An argument. Defaults to "foo".
  bar (int): An argument. Defaults to "bar".

Returns:
  None
"""
    docstring_single = """Summary

Args:
  bar: An argument. Defaults to "bar".

Returns:
  None
"""

# Generated at 2022-06-11 21:16:53.971448
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    string = "Attributes:\n"\
        "    attr1 (int): Description for attr1\n"\
        "    attr2 (float): Description for attr2\n"\
        "    attr3 (list): Description for attr3\n"\
        "    attr4 (tuple): Description for attr4\n"\
        "    attr5 (dict): Description for attr5\n"
    assert GoogleParser().parse(string).meta[0].description == 'Description for attr1'



# Generated at 2022-06-11 21:17:03.088825
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Test parse method of GoogleParser class.

    Arguments
    ---------
    julia : str
        Julia's file path. 
    xml : str
        XML-conversion's file path.

    Example
    -------
    Here is an example.

    >>> from docs_from_models.__main__ import main
    >>> main()

    Returns
    -------
    bool
        If the test is successful.
    """
    doc = parse(docstring)

# Generated at 2022-06-11 21:17:13.918940
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("""\
        foo:
            Foo-Bar.
        """) == Docstring(
        short_description="",
        long_description="foo: Foo-Bar.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=["foo"], description="Foo-Bar.")]
    )

# Generated at 2022-06-11 21:17:25.193825
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Google-style docstring.

    This is the first line of the docstring which is the short
    description.

    This is the second line of the docstring which is the long
    description.

    Note that the first line is empty and that the third line is blank.

    Args:
        a: The first parameter.
        b: Optional second parameter that defaults to 2.
        c: A list of parameters.
    Returns:
        Some value.
    Raises:
        SomeError: Always.
    """

    doc = GoogleParser().parse(text)

    assert doc.short_description == "Google-style docstring."
    assert doc.long_description == "This is the second line of the docstring "
    "which is the long\ndescription."
    assert doc.blank_after_short_description
    assert doc

# Generated at 2022-06-11 21:17:37.150743
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''test

    Arguments:
        arg1(str):
            First arg.
        arg2(int):
            Second arg.
            Second line.

    Returns:
        Ret.
        Ret.
    '''

    ret = GoogleParser().parse(docstring)
    assert ret.short_description == "test"
    assert ret.blank_after_short_description is True
    assert ret.blank_after_long_description is False
    assert ret.long_description is None
    assert isinstance(ret.meta[0], DocstringParam)
    assert ret.meta[0].arg_name == "arg1"
    assert ret.meta[0].description == "First arg."
    assert ret.meta[0].type_name == "str"
    assert isinstance(ret.meta[1], DocstringParam)

# Generated at 2022-06-11 21:17:50.421043
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    result = parser.parse("""Parameter specification using function annotations.

Args:
    arg0 (int): a positional argument.
    arg1 (str): a keyword argument. Defaults to None.
    *args: a list of positional arguments.
    **kwargs: a dictionary of keyword arguments.

Returns:
    None
""")
    assert result.short_description == 'Parameter specification using function annotations.'

# Generated at 2022-06-11 21:17:59.307439
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    section = Section("Arguments", "param", SectionType.MULTIPLE)
    parser = GoogleParser(title_colon=False)
    parser.add_section(section)
    text = '''
    Short description.

    Long description.

    Arguments:
        param_name (str): Description. Defaults to "some_value".

    Returns:
        str: Description.
    '''
    assert len(parser.parse(text).meta) == 2

# Generated at 2022-06-11 21:18:07.176621
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Arguments:
        name (str): Name of a given person.
    """
    assert GoogleParser().parse(docstring) == Docstring(short_description=None, blank_after_short_description=None, long_description=None, blank_after_long_description=None, meta=[DocstringParam(args=['param', 'name (str): Name of a given person.'], description='Name of a given person.', arg_name='name', type_name='str', is_optional=None, default=None)])
    docstring = """
    Returns:
        int: Age of a given person.
    """

# Generated at 2022-06-11 21:18:19.042430
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing method parse of class GoogleParser")
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()

    s = parse("Short description.")
    assert s.short_description == "Short description."
    assert s.blank_after_short_description == False
    assert s.long_description == None
    assert s.blank_after_long_description == True
    assert len(s.meta) == 0

    s = parse("\nShort description.")
    assert s.short_description == "Short description."
    assert s.blank_after_short_description == True

# Generated at 2022-06-11 21:18:29.850258
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('\n') == Docstring(
        short_description='', long_description='', blank_after_short_description=True, blank_after_long_description=True)
    assert GoogleParser().parse('\n\n') == Docstring(
        short_description='', long_description='', blank_after_short_description=True, blank_after_long_description=True)
    assert GoogleParser().parse('\n\n\n') == Docstring(
        short_description='', long_description='', blank_after_short_description=True, blank_after_long_description=True)

# Generated at 2022-06-11 21:18:39.796200
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:18:40.696904
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass

# Generated at 2022-06-11 21:18:48.911199
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Unit test for method parse of class GoogleParser
    from .common import assert_docstring

    assert_docstring(
        parse("Short summary.\n\nLong summary.\n"),
        Docstring(
            short_description="Short summary.",
            long_description="Long summary.",
            blank_after_short_description=True,
            blank_after_long_description=False,
            meta=[],
        ),
    )
    assert_docstring(
        parse("Short summary\nlong summary.\n"),
        Docstring(
            short_description="Short summary",
            long_description="long summary.",
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        ),
    )

# Generated at 2022-06-11 21:18:59.198409
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("").__dict__ == Docstring().__dict__
    assert parse(" ").__dict__ == Docstring().__dict__
    assert parse("\n").__dict__ == Docstring().__dict__
    assert parse("\n\n").__dict__ == Docstring().__dict__
    assert parse("\n\n\n").__dict__ == Docstring().__dict__
    assert parse("\n\n\n\n").__dict__ == Docstring().__dict__

    assert parse("test").__dict__ == {
        'short_description': 'test',
        'long_description': None,
        'blank_after_short_description': False,
        'blank_after_long_description': False,
        'meta': []
    }


# Generated at 2022-06-11 21:19:10.659573
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # check text with return and yield
    text_return = '''Summary line.

    Extended description of function.

    Parameters
    ----------
    param1 : int
        Description of param1

    Returns
    -------
    bool
        Description of return value

    Yields
    ------
    int
        Description of yielded value

    '''
    assert GoogleParser().parse(text_return).meta[0].description == "Description of param1"
    assert GoogleParser().parse(text_return).meta[1].description == "Description of return value"
    assert GoogleParser().parse(text_return).meta[2].description == "Description of yielded value"

    # check text with raise and attribute

# Generated at 2022-06-11 21:19:28.022665
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring_1 = ""
    docstring_2 = "Hello"
    docstring_3 = "    Hello"
    docstring_4 = "    Hello. This is a well documented function.\n"
    docstring_5 = "    Hello. This is a well documented function.\n    "
    docstring_6 = "    Hello. This is a well documented function.\n\n"
    docstring_7 = "    Hello. This is a well documented function.\n\n\n"
    docstring_8 = "    Hello. This is a well documented function.\n\n\n    "
    docstring_9 = "    Hello. This is a well documented function.\n\n\n    Extra"

# Generated at 2022-06-11 21:19:38.080466
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:19:50.394051
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test parsing Google docstring
    test_docstring = """
    Order function (or sort function) used by this module when sorting.

    :param object: object to compare
    :param object: other object to compare

    :returns:
        -1 if object < other, 0 if object == other, +1 if object > other
    """
    parsed_docstring = GoogleParser().parse(test_docstring)
    assert parsed_docstring is not None
    assert parsed_docstring.short_description == "Order function (or sort function) used by this module when sorting."
    assert parsed_docstring.long_description == None
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False

# Generated at 2022-06-11 21:20:01.418353
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    text = "Testing."
    assert p.parse(text) == Docstring(
        short_description=text,
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    text = """
    Short description.

    Long description.
    """
    assert p.parse(text) == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="Long description.",
        meta=[],
    )

    text = """
    Short description.
    
    Long description.
    """

# Generated at 2022-06-11 21:20:13.084410
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''Summary line.

Description of the method.
Args:
    choice:
        name: choice (Type: int(default: 0))
        description: choose the numbers
    number:
        name: number
        description: an odd number
Returns:
    description of return value
'''
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.meta[0].args == ['returns', 'description of return value']
    assert docstring.meta[1].args == ['param', 'choice']
    assert docstring.meta[1].description == 'name: choice (Type: int(default: 0))\n        description: choose the numbers'
    assert docstring.meta[2].description == 'name: number\n        description: an odd number'


# Generated at 2022-06-11 21:20:23.154548
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Parsing basic docstring
    text = """
    This is a docstring! It is awesome.

    Long description.

    Parameters
    ----------
    arg1 : str
        Argument 1.
    arg2 : int
        Argument 2.

    Returns
    -------
    str
        The result.

    Raises
    ------
    ValueError
        If nothing works.
    """
    d = parse(text)
    assert d.short_description == "This is a docstring! It is awesome."
    assert d.long_description == (
        "Long description.\n"
    )
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert len(d.meta) == 4
    assert isinstance(d.meta[0], DocstringParam)
    assert d.meta

# Generated at 2022-06-11 21:20:36.152455
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .examples import GOOGLE_1

    docstring = parse(GOOGLE_1)
    assert docstring.short_description == "Foobar."
    assert docstring.long_description == "Longer description which\nspans multiple lines."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    assert len(docstring.meta) == 9

    assert docstring.meta[0].args == [
        "args",
        "foo (int): The foo argument.",
    ]
    assert docstring.meta[0].description == "An optional argument, with a very long description that spans multiple lines."

    assert docstring.meta[1].args == ["returns", "int"]

# Generated at 2022-06-11 21:20:43.173616
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = inspect.cleandoc(
        """
    Short description.

    Long description.

    Args:
        pattern (str): Pattern to match.
        text (str): Text to search.
    """
    )

    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.meta[0].args == ["param", "pattern (str)"]
    assert docstring.meta[0].description == "Pattern to match."
    assert docstring.meta[1].args == ["param", "text (str)"]
    assert docstring.meta[1].description == "Text to search."


# Generated at 2022-06-11 21:20:55.695080
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    test_string = """
    This is the short description.
    This is the long description.

    This is another short description.
    This is another long description.


    Args:
        x: int
        y: str
            This is an argument description.

    Kwargs:
        z: List[str]
            This is another argument description.

    Returns:
        int This is the return description.

    Raises:
        Exception: This is the exception description.
    """

    result = parser.parse(test_string)
    assert (result.short_description == "This is the short description.")
    assert (result.long_description == "This is the long description.\n\nThis is another short description.\nThis is another long description.")
    assert len(result.meta) == 4

# Generated at 2022-06-11 21:21:07.041062
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    text1 = """
    >>> obj = MyClass()
    >>> obj.dummy_method()
    True
    """
    # Expect
    docstring = Docstring()
    docstring.short_description = ">>> obj = MyClass()"
    docstring.blank_after_short_description = True
    docstring.long_description = ">>> obj.dummy_method()\nTrue"
    docstring.blank_after_long_description = True

    # Do
    gp = GoogleParser()
    assert gp.parse(text1) == docstring

    # Expect
    docstring.meta.append(DocstringReturns(
        args=['returns'],
        description='True',
        type_name=None,
        is_generator=False
    ))

    # Do

# Generated at 2022-06-11 21:21:23.789410
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    source = """Summary line.

    Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
    """

# Generated at 2022-06-11 21:21:36.647843
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test(s, text, title, desc_chunk, meta_chunk, single, spli):
        text = inspect.cleandoc(text)
        match = re.search(title, text)
        if match:
            desc_chunk = text[: match.start()]
            meta_chunk = text[match.start() :]
        else:
            desc_chunk = text
            meta_chunk = ""
        indent_match = re.search(r"^\s+", meta_chunk)
        if not indent_match:
            raise ParseError('Can\'t infer indent from "{}"'.format(meta_chunk))
        indent = indent_match.group()
        chunks = OrderedDict()
        chunks[title] = meta_chunk[start:end].strip("\n")
       

# Generated at 2022-06-11 21:21:45.292484
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test empty string
    text = ""
    ds = GoogleParser().parse(text)
    assert ds.meta == list()
    assert ds.short_description is None
    assert ds.blank_after_short_description is None
    assert ds.long_description is None
    assert ds.blank_after_long_description is None

    # test single line description
    text = "This is a one line description."
    ds = GoogleParser().parse(text)
    assert ds.meta == list()
    assert ds.short_description == text
    assert ds.blank_after_short_description is False
    assert ds.long_description is None
    assert ds.blank_after_long_description is None

    # test single line description with following line break

# Generated at 2022-06-11 21:21:52.845277
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Define a test text
    text = """Single-line docstring
    
    This is a longer description of the single-line docstring. It covers
    multiple lines, with blanks lines separating each part.
    """
    # Test parsing this text and compare to expected result
    result = GoogleParser().parse(text)
    expected = Docstring(short_description="Single-line docstring", long_description="This is a longer description of the single-line docstring. It covers\nmultiple lines, with blanks lines separating each part.", blank_after_short_description=True, blank_after_long_description=True)
    assert result == expected

# Generated at 2022-06-11 21:22:04.894257
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  # Test if the returned values are correct
  text = '''
  A short summary.

  This is a long description.

  Raises:
    ValueError: If `x` is empty.
    TypeError:  If `x` is not a list.
    UnboundLocalError:  If `x` is not defined

  Returns:
    The return value. True for success, False otherwise.

  Examples:

  >>> square([1, 2, 3])
  [1, 4, 9]
  '''
  output = parse(text)
  assert output.short_description == 'A short summary'
  assert output.long_description == 'This is a long description.'
  assert output.meta[0].description == 'The return value. True for success, False otherwise.'

# Generated at 2022-06-11 21:22:11.951751
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    return_val = GoogleParser().parse("""
        Test.

        Parameters
        ----------
        param1 : str
            The first parameter.
        param2 : int, optional
            The second parameter.

        Returns
        -------
        bool
            True if successful, False otherwise.

        Raises
        ------
        AttributeError
            The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError
            If `param2` is equal to `param1`.

        Examples
        --------
        >>> test(42)
        True
    """)
    assert return_val.short_description is "Test."
    for i, meta in enumerate(return_val.meta):
        if meta.args[0] == "param":
            assert meta.args[1] == "param1 : str"


# Generated at 2022-06-11 21:22:23.491367
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    result = GoogleParser().parse("This is a test")
    assert result.short_description == 'This is a test'
    assert result.meta == []
    assert result.long_description == None

    text = "This is a test\nlong description"
    result = GoogleParser().parse(text)
    assert result.short_description == 'This is a test'
    assert result.meta == []
    assert result.long_description == 'long description'
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True

    text = "This is a test\n\nlong description"
    result = GoogleParser().parse(text)
    assert result.short_description == 'This is a test'
    assert result.meta == []
    assert result.long_description == 'long description'


# Generated at 2022-06-11 21:22:32.822168
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Testing for empty docstring
    assert parse("") == Docstring()
    assert parse("\n    ") == Docstring()
    assert parse("\n    \n    ") == Docstring()

    # Testing for non-empty docstring with no sections
    docstring=Docstring()
    docstring.short_description="Short description"
    docstring.blank_after_short_description=False
    docstring.long_description=None
    docstring.blank_after_long_description=False
    docstring.meta=[]
    assert parse("Short description")==docstring

    # Testing for non-empty docstring with no sections
    docstring=Docstring()
    docstring.short_description="Short description"
    docstring.blank_after_short_description=True
    docstring.long_description="Long description"
   

# Generated at 2022-06-11 21:22:44.469952
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("text") == Docstring(
        short_description="text",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=None,
        meta=[],
    )
    assert parse("a\nb") == Docstring(
        short_description="a",
        blank_after_short_description=True,
        long_description="b",
        blank_after_long_description=None,
        meta=[],
    )
    assert parse("a\n\nb") == Docstring(
        short_description="a",
        blank_after_short_description=True,
        long_description="b",
        blank_after_long_description=None,
        meta=[],
    )

# Generated at 2022-06-11 21:22:52.288113
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Case 1
    text = """
        This is a docstring
        with a short and
        a long part.

        Args:
            a: The first argument
            b: The second argument
                over multiple lines

        Returns:
            Something without a type

        Raises:
            ValueError: If something
                        is wrong
    """
    result = GoogleParser().parse(text)
    assert result.short_description == "This is a docstring with a short and a long part."
    assert result.long_description == "a long part."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert result.meta[0].description == "The first argument"
    assert result.meta[1].description == "The second argument over multiple lines"

# Generated at 2022-06-11 21:23:07.579562
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse(
        """
        A short description of the object.

        A longer description of the object.

        Args:

            arg1 (str): Description of `arg1`.
            arg2 (List[int]): Description of `arg2`.
            arg3 (bool): Description of `arg3`. Default to True.

        Returns:

            bool: Description of return value.

        Raises:

            AttributeError: The ``Raises`` section is a list of all exceptions
                that are relevant to the interface.
        """
    )

    assert docstring.short_description == 'A short description of the object.'
    assert docstring.long_description == 'A longer description of the object.'
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False



# Generated at 2022-06-11 21:23:14.776407
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:23:21.760280
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("Function description") == Docstring(
        short_description="Function description",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=True,
        meta=[],
    )

    assert parse("Function description.  Function description.") == Docstring(
        short_description="Function description.  Function description.",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-11 21:23:32.000313
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    # Test parsing a Google-style docstring

# Generated at 2022-06-11 21:23:43.400874
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("A short summary\n") == Docstring(
        short_description="A short summary",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=list(),
    )
    assert parse(
        "A short summary\n\n"
        "A longer description spanning multiple lines.\n"
    ) == Docstring(
        short_description="A short summary",
        long_description="A longer description spanning multiple lines.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=list(),
    )
    assert parse(
        "A short summary\n"
        "A longer description spanning multiple lines.\n"
    ) == Doc

# Generated at 2022-06-11 21:23:53.744616
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:24:03.178649
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    text = """
        Args:
            foo: The first parameter.
            bar: The second parameter. Defaults to 'bar'.
            baz: The third parameter.
        Returns:
            Nothing at all.
        """

    # Act
    docstring = GoogleParser().parse(text)

    # Assert
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 3

    assert docstring.meta[0].__class__ is DocstringParam
    assert docstring.meta[0].args == ['param', 'foo']
    assert docstring.meta[0].description == 'The first parameter.'
    assert doc

# Generated at 2022-06-11 21:24:14.305231
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = '''
    This is a short description.

    Thiis is a longer description.

    Parameters:
        name:
            Description of a parameter.
        name2(str):
            Description of a parameter with type.
    '''

    dp = GoogleParser()
    r1 = dp.parse(d)
    assert r1.short_description == "This is a short description."
    assert r1.long_description == "Thiis is a longer description."
    assert len(r1.meta) == 2
    assert r1.meta[0].description == "Description of a parameter."
    assert r1.meta[1].description == "Description of a parameter with type."



# Generated at 2022-06-11 21:24:21.977688
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import os

    filename = os.path.abspath(__file__)
    dirname = os.path.dirname(filename)

    f = open(dirname+"/test_GoogleParser_parse.txt","r")
    text = f.read()
    f.close()

    parse_result = parse(text)
    print(parse_result.meta[0].args)
    print(parse_result.meta[0].description)
    print(parse_result.meta[0].is_optional)
    print(parse_result.meta[0].arg_name)
    print(parse_result.meta[0].default)
    print(parse_result.meta[0].type_name)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:24:34.862998
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .google import parse

    assert parse('This is a function.') == Docstring(short_description='This is a function.')
    assert (
        parse('This is a function.\n\nWith a long description.') == Docstring(
            short_description='This is a function.',
            long_description='With a long description.',
            blank_after_short_description=True,
            blank_after_long_description=False,
        )
    )
    assert (
        parse('This is a function.\n\nWith a long description.\n') == Docstring(
            short_description='This is a function.',
            long_description='With a long description.',
            blank_after_short_description=True,
            blank_after_long_description=True,
        )
    )

# Generated at 2022-06-11 21:24:47.093876
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    description = "Given a string, return the first non-repeating character in it.\n"
    long_description = """\
        Examples:

            s = "leetcode"
            return "l".
            s = "loveleetcode",
            return "v".
            Note: You may assume the string contain only lowercase letters."""

    p = GoogleParser()
    ds = p.parse(description+long_description)
    assert ds.short_description == description
    assert ds.long_description == long_description

# Generated at 2022-06-11 21:24:50.493794
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Ensure that the function for the GoogleParser class is working correctly
    # and the different components of the docstring are being extracted
    # correctly.
    # This is NOT for testing docstrings in code.
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 21:25:01.105247
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Methods for handling text data.

    Attributes:
        punctuation (string): The string of all punctuation.
        punctuation_no_periods (string): A version of punctuation with periods removed.
        stopwords (list): A list of words that are stopwords.

    Args:
        text (str): The text to remove from the string.
        remove_stopwords (bool, optional): If True, remove uni-
            gram stopwords. Defaults to False.

    Raises:
        ValueError: If the input text is empty or None.

    Returns:
        ndarray: The modified text.

    """
    parser = GoogleParser()
    func = GoogleParser.parse
    docstring = parser.parse(text)
    key1 = docstring.meta[0].args[0]
    key2 = doc

# Generated at 2022-06-11 21:25:09.959979
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pdb
    parser = GoogleParser()
    docstring = parser.parse.__doc__
    parsed = parser.parse(docstring)
    assert parsed.short_description == 'Parse the Google-style docstring into its components.'
    assert parsed.long_description == ':returns: parsed docstring'
    assert len(parsed.meta) == 0
    return parsed


if __name__ == "__main__":
    from sphinxcontrib.napoleon import GoogleDocstring
    import sys
    docstring = "\n".join(sys.argv[1:])
    parsed = GoogleDocstring(docstring)
    print(repr(GoogleDocstring(docstring)))

# Generated at 2022-06-11 21:25:20.478968
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Jupyter Notebook to test method parse of class GoogleParser"""
    from importnb import Notebook
    with Notebook():
        from .parser.google import parse as parse_google

        from .parser.numpy import parse as parse_numpy
        from .parser.numpy_napoleon import parse as parse_numpy_napoleon

        from .parser.sphinx import parse as parse_sphinx
        from .parser.sphinx_autodoc import parse as parse_sphinx_autodoc
        from .parser.sphinx_napoleon import parse as parse_sphinx_napoleon


# Generated at 2022-06-11 21:25:29.386663
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def func_for_test():
        """
        test_GoogleParser_parse: parse docstring and get its components

        Args:
            arg1 (str): this is arg1
            arg2 (int): this is arg2

        Returns:
            int: this is a return

        Raises:
            KeyError: raises an exception
        """
        return 0

    docstring = GoogleParser().parse(func_for_test.__doc__)

    assert docstring.short_description == 'test_GoogleParser_parse: parse docstring and get its components'

    assert docstring.long_description == (
        'test_GoogleParser_parse: parse docstring and get its components'
    )

    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

    meta = docstring.meta



# Generated at 2022-06-11 21:25:39.515611
# Unit test for method parse of class GoogleParser