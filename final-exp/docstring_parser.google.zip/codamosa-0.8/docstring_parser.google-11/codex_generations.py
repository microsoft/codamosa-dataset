

# Generated at 2022-06-11 21:16:06.147237
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "This function does something amazing.\n\nArgs:\n  param1: The first parameter.\n  param2: The second parameter."
    doc = GoogleParser().parse(text)
    print(doc.meta)
    print(doc.short_description)
    print(doc.long_description)


# Generated at 2022-06-11 21:16:11.326415
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse(".") == Docstring(
        short_description=".",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse(
        """
    A short description of the function.

    And then a long one.

        """
    ) == Docstring(
        short_description="A short description of the function.",
        blank_after_short_description=True,
        long_description="And then a long one.",
        blank_after_long_description=False,
    )



# Generated at 2022-06-11 21:16:18.357431
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
The ``write`` method

:param filename: Name for the file
:type filename: str
:param text: Text to write
:type text: str
:param encoding: Encoding to use
:type encoding: str
:raises IOError: If writing fails
'''
    ret = GoogleParser().parse(docstring)
    assert ret.short_description == "The ``write`` method"
    assert not ret.long_description
    assert ret.meta[0].__class__ is DocstringParam
    assert ret.meta[1].__class__ is DocstringParam
    assert ret.meta[2].__class__ is DocstringParam
    assert ret.meta[3].__class__ is DocstringRaises
    assert len(ret.meta) == 4


# Generated at 2022-06-11 21:16:31.174201
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    comment = """
    Parse the Google-style docstring into its components.

    This inherits from the Docstring class and provides some helpers
    to make it easier to parse Google-style docstrings.

    :param text: docstring text or None
    :returns: parsed docstring
    """
    result = GoogleParser().parse(comment)
    expected_result = Docstring(
        long_description=None,
        short_description='Parse the Google-style docstring into its components.',
        blank_after_short_description=False,
        blank_after_long_description=None,
        meta=[
            DocstringMeta(
                args=[
                    'Args',
                    'text'
                ],
                description='docstring text or None')
        ])
    assert result == expected_result, (result, expected_result)



# Generated at 2022-06-11 21:16:44.370181
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Summaries should be written in the imperative mood and should not
    explicitly depend on the function's name or describe its return type. Do
    write "Compute the heuristic value of a game state" instead of "This
    function computes the heuristic value of a game state", or "Return the
    heuristic value of a game state" instead of "The heuristic value of a game
    state is returned by this function."
    """
    text = inspect.cleandoc(text)
    parts = text.split("\n", 1)
    short_description = parts[0]
    assert short_description == "Summaries should be written in the imperative mood and should not"
    long_desc_chunk = parts[1]

# Generated at 2022-06-11 21:16:56.878891
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    txt = """This is a summary for class A.

This is the extended summary for Class A.

Attributes:
    attr1: A string attribute.

Raises:
    A1Error: If x > 10
"""
    print(parser.parse(txt))
    txt = """This is a summary for class A.

This is the extended summary for Class A.

Attributes:
    attr1 (str): A string attribute.

Raises:
    A1Error: If x > 10
"""
    print(parser.parse(txt))

# Generated at 2022-06-11 21:17:10.231375
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """\
        Short description.

        Long description.

        Args:
            arg1 (str): The first argument.
            arg2 (int, optional): The second argument. Defaults to 42.
        Raises:
            AttributeError: The ``Raises`` section is a list of all exceptions
                that are relevant to the interface.
        """
    docstring = GoogleParser().parse(docstring)
    assert type(docstring) == Docstring
    assert type(docstring.meta[0]) == DocstringParam
    assert docstring.meta[0].description == "The first argument."
    assert type(docstring.meta[1]) == DocstringParam
    assert docstring.meta[1].description == "The second argument. Defaults to 42."
    assert type(docstring.meta[2]) == DocstringRaises
   

# Generated at 2022-06-11 21:17:19.057896
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''This is my class.
    It is full of awesomeness.
    Args:
        arg1: an integer
        arg2: a string
    Raises:
        ValueError
    '''
    print("Starting test_GoogleParser_parse...")
    parser = GoogleParser()
    ret = parser.parse(docstring)
    # print(ret.meta)
    print("Finished test_GoogleParser_parse")

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:17:20.830949
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 21:17:26.686941
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Summary line.
    Extended description of function.
    Parameters
    ----------
    param1 : int
        Parameter 1.
    param2 : str
        Parameter 2.
    Returns
    -------
    int
        The return code.
    """
    GoogleParser().parse(docstring)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:17:57.036539
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def _test(text, short, long_desc, meta):
        p = GoogleParser()
        d = p.parse(text)
        msg = "text = {!r}".format(text)
        assert d.short_description == short, msg
        assert d.long_description == long_desc, msg
        assert d.meta == meta, msg
        assert len(d.meta) == len(meta), msg

    # Test long desc
    long = "Blah blah blah."
    _test(long, None, long, [])

    # Test short desc
    _test("Short.", "Short.", None, [])

    # Test short desc, long desc
    _test("Short.\n\nLong.", "Short.", "Long.", [])

    # Test short desc, blank, long desc

# Generated at 2022-06-11 21:18:02.734261
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:18:11.231704
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """ Test for method parse of class GoogleParser.

    GoogleParser().parse() must be equivalent to the function parse()
    """
    docstring = """
        This is a regular method.

        Args:
            lst (iterable): a list of lists.
            n (int): to be returned.

        Returns:
            n (int): n.

        Raises:
            ZeroDivisionError: n can not be zero.
            TypeError: lst must be a list of lists.
    """
    p = GoogleParser()
    assert p.parse(docstring) == parse(docstring)


# Generated at 2022-06-11 21:18:22.531210
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is the short description.
    This is the long description.

    Arguments:
    arg1: Description of arg1. Defaults to 42.
    arg2 (Optional[int]): Description of arg2. Defaults to 43.

    Returns:
    bool: Description of return value.
    """
    d = GoogleParser().parse(text)
    assert d.short_description == "This is the short description."
    assert d.meta[0].description == "This is the long description."
    assert d.meta[1].description == "Description of arg1. Defaults to 42."
    assert d.meta[1].arg_name == "arg1"
    assert d.meta[2].description == "Description of arg2. Defaults to 43."
    assert d.meta[2].arg_name == "arg2"

# Generated at 2022-06-11 21:18:31.020153
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """One-line description.
    Args:
        x: Desc.
       y: Desc.
        z (str): Desc.
    Returns:
        Description of return value.
    Raises:
        ValueError: Description of raised error.
        Exception: Description.
    """
    docstring = GoogleParser().parse(docstring)

    docstring_str = str(docstring)
    assert docstring_str == """
    Args:
        x: Desc.
        y: Desc.
        z (str): Desc.
    Raises:
        ValueError: Description of raised error.
        Exception: Description.
    Returns:
        Description of return value.
    """, docstring_str



# Generated at 2022-06-11 21:18:40.380230
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    gp = GoogleParser()

# Generated at 2022-06-11 21:18:48.762169
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """ Test of method 'parse' of class GoogleParser.
    """
    parser = GoogleParser()

    # Test when the docstring is not empty
    docstring = "This function does blabla.\nDescription of the function\n\nArgs: \narg1 (int): first arg\narg2 (int): second arg"
    result = parser.parse(docstring)

# Generated at 2022-06-11 21:18:54.047119
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("    ") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("Hello, world.") == Docstring(
        short_description="Hello, world.", blank_after_short_description=False
    )
    assert parse("Hello, world.\n") == Docstring(
        short_description="Hello, world.", blank_after_short_description=True
    )
    assert parse("Hello, world.\n\n") == Docstring(
        short_description="Hello, world.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

# Generated at 2022-06-11 21:19:01.504695
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    Insert an item at a given position.
    Raises:
        IndexError: if the index is out of range.
    """

    ds = GoogleParser().parse(text)

    assert ds.short_description == "Insert an item at a given position."
    assert ds.long_description is None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False

    assert len(ds.meta) == 1

    assert ds.meta[0].args == ['raises']
    assert ds.meta[0].description == "IndexError: if the index is out of range."

# Generated at 2022-06-11 21:19:12.699076
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("      ") == Docstring()
    assert parse("\t\t\t\t") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\t \n\t \n\t \n\t") == Docstring()
    assert parse("\t \nabcd\t \n\t") == Docstring(
        short_description="abcd",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
    )

# Generated at 2022-06-11 21:19:30.368875
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('foo') == \
        Docstring(None, None, 'foo', False, False)

    docstring = """

Sample docstring.

Args:
    arg1 (int): The first argument.

    arg2 (str): The second argument:

        - 2a
        - 2b

Returns:
    bool: The return value. True for success, False otherwise.

"""

# Generated at 2022-06-11 21:19:36.725162
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_string = '''A simple test string'''
    data = GoogleParser().parse(doc_string)
    short_description = data.short_description
    blank_after_short_description = data.blank_after_short_description
    blank_after_long_description = data.blank_after_long_description
    long_description = data.long_description
    return short_description,blank_after_short_description,blank_after_long_description,long_description

# Generated at 2022-06-11 21:19:48.820195
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse("""
        This is a short description of the module.
        
        Long description is
        also possible.
        And if you need some functionality,
        you can call it.
        
        This is an example:
            x = 5
            y = 7
            print(x+y)
        
        Parameters
        ----------
        aa : int
                This is aa.
        
        bb : int
                This is bb.
        
        Returns
        -------
        int
            sum of a and b
        
        Raises
        ------
        TypeError
            if a or b are not int
        
        Notes
        -----
        This is a note.
        """)
    assert docstring.short_description == "This is a short description of the module."
    assert docstring.long

# Generated at 2022-06-11 21:19:52.555285
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Short description.

    Extended description.
    """
    doc = parse(docstring)
    print(doc.long_description)
    assert doc.short_description == 'Short description.'
    assert doc.long_description == 'Extended description.'


# Generated at 2022-06-11 21:19:56.935293
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse(): 
    # TODO: Add some unit test cases
    # assert GoogleParser().parse(str) == expected
    assert 0


if "__main__" == __name__:
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:20:04.389005
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def f():
        """Short description.

        Long description.

        Args:
            arg1 (int, optional): Description of `arg1`
            arg2 (str): Description of `arg2`

        Returns:
            bool: Description of return value

        Raises:
            ValueError: The first argument of `f()` must be
            `first_arg`.
        """
        pass

    doc = GoogleParser().parse(f.__doc__)
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert isinstance(doc.meta[0], DocstringParam)
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-11 21:20:15.740208
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser."""
    from .common import Docstring, DocstringParam, DocstringReturns
    from .common import DocstringRaises, DocstringAttribute
    from .common import DocstringExamples
    from .google_parser import GoogleParser
    # test if the parsing is successful
    docstring = inspect.cleandoc('''\
    Foo function.
    Args:
        a: int.
        b: list.
    Returns:
        dict.
    ''')
    parser = GoogleParser()

# Generated at 2022-06-11 21:20:24.905877
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:20:38.200875
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    A short summary of the function.

    Description of the function.

    Args:
        a: Argument a.
        b: Argument b.

        Returns:
            A value.
        '''
    assert(GoogleParser().parse(text).short_description == 'A short summary of the function.')
    assert(GoogleParser().parse(text).long_description == 'Description of the function.')
    assert(GoogleParser().parse(text).meta[0].args == ['param', 'a:'])
    assert(GoogleParser().parse(text).meta[0].description == 'Argument a.')
    assert(GoogleParser().parse(text).meta[1].args == ['param', 'b:'])
    assert(GoogleParser().parse(text).meta[1].description == 'Argument b.')

# Generated at 2022-06-11 21:20:46.154872
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """This is a description.
    This is still a description.
    This is yet a description."""
    docstring_parsed = GoogleParser().parse(docstring)
    
    assert docstring_parsed.short_description == "This is a description."
    assert docstring_parsed.long_description == "This is still a description.\nThis is yet a description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == False
    assert docstring_parsed.meta == []

# Generated at 2022-06-11 21:20:59.252651
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_object = GoogleParser().parse('''
    A simple test of GoogleParser.

    Google-style docstring parsing.
    
    Args:
        arg1 (int): The first parameter.
        arg2 (int): The second parameter.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list
            of all exceptions raised.
        ValueError: If `param2` is equal to `param1`.
    ''')
    assert(docstring_object.short_description == "A simple test of GoogleParser.")
    assert(docstring_object.blank_after_short_description == False)
    assert(docstring_object.long_description == "Google-style docstring parsing.")

# Generated at 2022-06-11 21:21:10.150311
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""
    parser = GoogleParser()
    assert parser
    docstring_text = """\
            Another one-line description

            And another paragraph that says some more things.

            Args:
                arg1 (int): The first argument.
                arg2 (str): The second argument.

            Returns:
                str: The return value. Return type is optional.

            Raises:
                AttributeError: The ``Raises`` section is a list of all exceptions
                    that are relevant to the interface.
                ValueError: If `param2` is equal to `param1`.
        """
    docstring = parser.parse(docstring_text)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "Another one-line description"

# Generated at 2022-06-11 21:21:22.079977
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Summary line.

    Extended description.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`.
    arg2 : str
        Description of `arg2`.

    Returns
    -------
    int
        Description of return value.
    """
    doc = GoogleParser[str].parse(docstring)
    assert(doc.short_description == "Summary line.")
    assert(doc.long_description == "Extended description.")
    assert(doc.meta[0].args == ["Parameters"])
    assert(doc.meta[0].type_name == "int")
    assert(doc.meta[0].arg_name == "arg1")
    assert(doc.meta[0].description == "Description of `arg1`.")
    assert(doc.meta[1].type_name == "str")


# Generated at 2022-06-11 21:21:32.346374
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    func = parse
    assert func.__name__ == "parse"
    assert func.__doc__ == parse.__doc__
    assert func.__annotations__ == {}
    assert isinstance(func(None), Docstring)
    assert parse.__name__ == "parse"
    assert (
        parse.__doc__
        == """Parse the Google-style docstring into its components.

    :returns: parsed docstring"""
    )
    assert parse.__annotations__ == {
        "text": str,
        "return": "Docstring",
    }


# Generated at 2022-06-11 21:21:42.155885
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Short description.

    Long description.

    Args:
        foo (str): First parameter.
        bar (str): Second parameter.

    Example:
        This is an example::

            example code

    Returns:
        int: The return value.
    """

    ds = parse(docstring)
    assert ds.short_description == "Short description."
    assert ds.long_description == "Long description."
    assert ds.blank_after_long_description
    assert ds.blank_after_short_description

    assert len(ds.meta) == 3
    assert ds.meta[0][0] == "param"
    assert ds.meta[0].arg_name == "foo"
    assert ds.meta[0].description == "First parameter."
    assert ds.meta

# Generated at 2022-06-11 21:21:52.294978
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    text = '''short description

long description

Args:
    name (str): Name of the person.

Returns:
    bool: The return value. True for success, False otherwise.

Raises:
    ValueError: If `name` is empty.

'''

    # Execute
    result = GoogleParser().parse(text)

    # Assert
    assert result.short_description == "short description"
    assert result.long_description == "long description"
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 3
    assert result.meta[0].description == "Name of the person."
    assert result.meta[0].args == ["param", "name (str)"]
    assert result.meta

# Generated at 2022-06-11 21:22:04.228531
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = '''Args:
        param1: The first parameter.
        param2: The second parameter.
        Returns:
            bool: The return value. True for success, False otherwise.
        '''
    r = parser.parse(text)
    assert r.short_description == None
    assert r.long_description == None
    assert r.blank_after_short_description == False
    assert r.blank_after_long_description == False
    assert len(r.meta) == 3
    assert r.meta[0].args == ['param', 'param1']
    assert r.meta[0].type == 'param'
    assert r.meta[0].key == 'param1'
    assert r.meta[0].description == 'The first parameter.'

# Generated at 2022-06-11 21:22:11.730947
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Short description
    assert (
        GoogleParser().parse("Short description.") == parse("Short description.")
    )

    # Remove leading blank lines
    assert GoogleParser().parse("\n\nShort description.") == parse(
        "Short description."
    )

    # Remove tailing blank lines
    assert GoogleParser().parse("Short description.\n\n") == parse(
        "Short description."
    )

    # Join consecutive empty lines in docstring to single empty line
    assert GoogleParser().parse("Short description.\n\n\n") == parse(
        "Short description."
    )

    # Handle blank short description
    assert GoogleParser().parse("\nLong description.") == parse("Long description.")

    # Handle short and long descriptions

# Generated at 2022-06-11 21:22:23.466686
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
      
    docstring = '''Single line description.
    
    Extended description with some *markup*.
    
    There can be blank lines in between.
    
    Attributes:
        arg1 (bool): Description for arg1
        arg2 (str): Description for arg2
        arg3 (Optional[str]): Description for arg3
    '''

    res = GoogleParser().parse(docstring)
    assert res.short_description == 'Single line description.'
    assert res.long_description == 'Extended description with some *markup*.'
    assert res.blank_after_short_description == True
    assert res.blank_after_long_description == False

    sections = res.sections
    # assert sections[0].key == 'returns'
    # assert sections[0].title == 'Returns'
    # assert sections[0].type

# Generated at 2022-06-11 21:22:32.796931
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == parse.__annotations__["return"]
    assert parse("ds") == parse.__annotations__["return"]

    assert parse(
    """Example

    Examples can be given using either the ``Example`` or ``Examples``
    sections. Sections support any reStructuredText formatting, including
    literal blocks::

        $ python my_script.py
"""
    ) == parse.__annotations__["return"]

    assert parse(
    """Arguments:
    param1 (int): The first parameter.
    param2 (str): The second parameter.
    """
    ) == parse.__annotations__["return"]

    assert parse(
    """Args:
    param1 (int): The first parameter.
    param2 (str): The second parameter.
    """
    ) == parse.__annotations__["return"]

   

# Generated at 2022-06-11 21:22:47.996082
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse('''Single line description.

    Long description
    ''')
    # Test short description
    assert docstring.short_description == "Single line description."
    # Test long description
    assert docstring.long_description == "Long description"
    # Test meta description
    assert docstring.meta == []
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    docstring = GoogleParser().parse('''Single line description.

    Long description
    Parameters
    ----------
    arg1 : str
        Description of arg1
    arg2 : float
        Description of arg2
    ''')
    # Test short description
    assert docstring.short_description == "Single line description."
    # Test long description

# Generated at 2022-06-11 21:22:58.909124
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc = parser.parse("")
    print("Passed empty string")
    print("desc:", doc.short_description)
    print("meta:", doc.meta)

    doc = parser.parse("This is an example")
    print("Passed simple string")
    print("desc:", doc.short_description)
    print("meta:", doc.meta)

    doc = parser.parse("This is an example\n\nWith more text")
    print("Passed string with extra text")
    print("desc:", doc.short_description)
    print("meta:", doc.meta)
    print("long desc:", doc.long_description)
    print("blank after long desc:", doc.blank_after_long_description)

# Generated at 2022-06-11 21:23:09.462700
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    lines = ["""
            Returns the area of a square with the length of one side.

            Arguments:
                size (int): The length of one side of the square.

            Returns:
                The area of the square.
            """]
    lines_str = ''.join(lines)
    docstring = GoogleParser().parse(lines_str)
    assert docstring.short_description == 'Returns the area of a square with the length of one side.'
    assert docstring.long_description == 'Arguments:\n    size (int): The length of one side of the square.\n\nReturns:\n    The area of the square.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-11 21:23:19.783370
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test_func(arg1, arg2='hello'):
        """Test function.

        Args:
            arg1: arg1
            arg2: arg2
        """
        pass

    sig = inspect.signature(test_func)
    doc = inspect.getdoc(test_func)
    ds = parse(doc)
    # print(ds.short_description)
    # print(ds.long_description)
    # print(ds.meta)

    assert ds.short_description == "Test function."
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert len(ds.meta) == 2
    assert isinstance(ds.meta[0], DocstringParam)
    assert ds

# Generated at 2022-06-11 21:23:31.156465
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    A simple docstring.

    Args:
        arg1 (int): The first message.
        arg2 (str, optional): The second message. Defaults to 0.

    Returns:
        list: A list containing the first message.

    Raises:
        ValueError: The message is empty.
    """
    result = parse(text)
    assert type(result) == Docstring
    assert len(result.meta) == 4


# Generated at 2022-06-11 21:23:42.780104
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Parameters
    ----------
    in_channels : int
        Number of channels in the input image.
    out_channels : int
        Number of channels produced by the convolution.
    '''
    res = GoogleParser().parse(text)

# Generated at 2022-06-11 21:23:53.606675
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Tests for line with multiple parameters
    print(GoogleParser().parse("""
    Params:
        a: a
        b: b
    """))
    print(GoogleParser().parse("""
    Params:
    a: a
    b: b
    """))
    print(GoogleParser().parse("""
    Params:
    a (a): a
    b (b): b
    """))
    print(GoogleParser().parse("""
    Params:
    a (a): (a)
    b (b): (b)
    """))
    print(GoogleParser().parse("""
    Params:
    a (a): a. Defaults to a.
    b (b): b. Defaults to b.
    """))

# Generated at 2022-06-11 21:24:03.094973
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for GoogleParser.parse."""
    parser = GoogleParser()

    docstring = '''
        A nice function.

        Args:
            a: a useful param.
            b: yet another param.
        '''
    print("docstring:\n", docstring)
    doc = parser.parse(docstring)
    print("Docstring:\n", doc)

    docstring2 = '''
        Args:
            a: a useful param.
            b: yet another param.
        '''
    print("docstring:\n", docstring2)
    doc2 = parser.parse(docstring2)
    print("Docstring:\n", doc2)


# Generated at 2022-06-11 21:24:15.813406
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # input
    text = '''\
    Args:
        arg1 (str): first arg. Defaults to "test".
        arg2 (int): second arg.
        arg3: third arg.
    Returns:
        str: a string.
    Raises:
        SomeError: If some error occurs.
    '''
    # expected output
    expected_short_desc = None
    expected_blank_after_short_desc = False
    expected_blank_after_long_desc = False
    expected_long_desc = None

# Generated at 2022-06-11 21:24:22.200606
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a description.
    It has a first line.
    And a third.

    Args:
       first_arg (int): The first argument.
       second_arg (str): The second argument. Defaults to 'doh'.
       third_arg (bool): The third argument. Defaults to False.

    Raises:
        RuntimeError:
            If something goes wrong.

    Returns:
        int: The return code.

    """

    docstring = GoogleParser().parse(text)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:24:35.993479
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    result = parse('''
    Short summary.
    
    Long summary.
    
    Args:
        arg1: the first
        arg2: the second
    
    Returns:
        str: the result
    ''')
    params = [p for p in result.meta if isinstance(p, DocstringParam)]
    assert len(params) == 2
    assert params[0].description == 'the first'
    assert params[0].arg_name == 'arg1'
    assert params[1].description == 'the second'
    assert params[1].arg_name == 'arg2'
    returns = [r for r in result.meta if isinstance(r, DocstringReturns)]
    assert len(returns) == 1
    assert returns[0].description == 'the result'
    assert returns[0].type_name

# Generated at 2022-06-11 21:24:47.200625
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with no content
    assert parse('') == Docstring()

    # Test properly working parsing
    text = '''short description

    long description
    still long description

    Args:
        arg1 (str): first argument
        arg2: second argument
        arg3 (int): third argument

    Returns:
        (int): return value

    Raises:
        IOError: when file not found
    '''

# Generated at 2022-06-11 21:24:49.838814
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    a = GoogleParser().parse(' \n\n        hello world\n        hi world')
    assert a.short_description == 'hello world'
    assert a.meta[0].description == 'hi world'

# Generated at 2022-06-11 21:25:00.417815
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for GoogleParser with title_colon = True
    text = '''
    The quick brown fox jumps over the lazy dog.
    :param param_1: A parameter
    :param param_2: A parameter
    :type param_2: Optional[str]
    :returns: description of return, return type is returned
    '''
    res = parse(text)
    assert len(res.meta) == 3
    assert isinstance(res.meta[0], DocstringMeta)
    assert isinstance(res.meta[1], DocstringParam)
    assert isinstance(res.meta[2], DocstringReturns)
    assert res.meta[1].arg_name == 'param_1'
    assert res.meta[1].type_name == None
    assert res.meta[1].is_optional == False

# Generated at 2022-06-11 21:25:09.031239
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = '''
    Description of function

    Args:
        arg1: Expect arg 1
        arg2: Expect arg 2. Defaults to "value"
        arg3: Expect arg 3 (optional)

    Yields:
        thing: str

    Raises:
        ValueError: If this
        KeyError: If that

    Returns:
        thing: str
        thing: str
    '''
    docstring = parser.parse(text)
    assert docstring.short_description == 'Description of function'

# Generated at 2022-06-11 21:25:19.492386
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is the short description.

    This is the long description.

    Args:
        arg1 (int): The first arg. Defaults to 1.
        arg2 (str): The second arg.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The error description.
    """

# Generated at 2022-06-11 21:25:28.819866
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    This is some text
    used to test.

    Args:
        arg1: This is the first argument.
        arg2: This is another argument.

    Raises:
        AnError: If something bad happened.
    """
    result = GoogleParser().parse(text)

# Generated at 2022-06-11 21:25:39.184940
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = \
"""
One-line summary of the method.

Description of the method:
    - Some more detailed.
    - Other.

Args:
    arg_name (type): argument description. Defaults to 'default'.
    arg_name: argument description.
    ...
    arg_name (type): argument description.

Returns:
    int: a positive integer.
"""
    parsed_docstring = parser.parse(docstring)
    assert(len(parsed_docstring.meta) == 2)
    assert(parsed_docstring.short_description == "One-line summary of the method.")
    assert(parsed_docstring.long_description == \
"""Description of the method:
    - Some more detailed.
    - Other.""")

# Generated at 2022-06-11 21:25:47.685417
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    parser = GoogleParser()

    # Test of a docstring with little information but no invalid info
    test_docstring_1 = '''
    This is a test.
    '''

    test_docstring_1_parsed = Docstring(
        short_description = 'This is a test.',
        blank_after_short_description = True,
        long_description = None,
        blank_after_long_description = None,
        meta = [],
    )

    assert parser.parse(test_docstring_1) == test_docstring_1_parsed

    # Test of a docstring with more information but no invalid info
    test_docstring_2 = '''
    This is a test.
    It is a very long test.
    This is the end of the test.
    '''

    test_doc