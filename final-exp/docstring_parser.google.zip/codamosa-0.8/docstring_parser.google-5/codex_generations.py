

# Generated at 2022-06-11 21:16:01.856961
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring
    print(GoogleParser().parse('Docstring.\nArgs:\n    a, b (int): some int numbers.\n    c=1 (int): some int number.'))


# Generated at 2022-06-11 21:16:09.318429
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    text = """Short summary.
    \n
    Still part of the short summary.
    """
    docstring: Docstring = google_parser.parse(text)
    assert docstring.short_description == "Short summary."
    assert docstring.blank_after_short_description == True
    assert docstring.long_description == "Still part of the short summary."
    assert docstring.blank_after_long_description == True
    assert docstring.meta == []
    text = """Short summary.
    \n
    Still part of the short summary.

    """
    docstring = google_parser.parse(text)
    assert docstring.short_description == "Short summary."
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-11 21:16:17.725389
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    my_GoogleParser = GoogleParser()
    my_GoogleParser.add_section(Section("Unit", "string", SectionType.SINGULAR))
    assert(my_GoogleParser.parse("") == Docstring())
    assert(my_GoogleParser.parse("a") == Docstring(short_description='a'))
    assert(my_GoogleParser.parse("\na") == Docstring(
        short_description='',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description='a',
    ))
    assert(my_GoogleParser.parse("a\n") == Docstring(
        short_description='a',
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description='',
    ))

# Generated at 2022-06-11 21:16:30.762894
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("Example:") == Docstring(
        short_description=None,
        long_description=None,
        meta=[DocstringMeta(args=['example'], description=None)],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parser.parse("Example: \nx") == Docstring(
        short_description=None,
        long_description=None,
        meta=[DocstringMeta(args=['example'], description='x')],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

# Generated at 2022-06-11 21:16:43.659195
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p1 = GoogleParser()
    text_in = """
This function has many arguments, and only some of them are optional:
:param a:
:param b: This one is optional, and default to 3.
:param c (int): This one also optional, defaulting to 4.
:param d (str, optional): Likewise. Defaults to "5".
:param e?:   Same thing, but with a trailing question mark.
:param f (float=6.0): Same thing, but the equal sign is used instead.
:param g: This one is required.
"""
    doc = p1.parse(text_in)
    assert len(doc.meta) == 7
    for param in doc.meta:
        assert isinstance(param, DocstringParam)



# Generated at 2022-06-11 21:16:53.101588
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Parse the Google-style docstring into its components.
    :returns: parsed docstring
    """
    res = GoogleParser().parse(text)
    assert isinstance(res, Docstring)
    assert res.short_description == "Parse the Google-style docstring into its components."
    assert res.long_description == None
    assert res.blank_after_short_description == True
    assert res.blank_after_long_description == True
    assert res.meta[0].description.strip() == "parsed docstring"


# Generated at 2022-06-11 21:17:01.330663
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test docstring with no content
    assert GoogleParser().parse('') == Docstring()
    # Test docstring with no sub-section
    doc = 'This is a demo.'
    assert GoogleParser().parse(doc) == Docstring(
        short_description='This is a demo.')
    # Test docstring with a sub-section
    doc = '''This is a demo.

    Argument:
        x: This is a integer.'''
    assert GoogleParser().parse(doc) == Docstring(
        short_description='This is a demo.', long_description='Argument: x: This is a integer.', meta=[DocstringMeta(args=['param', 'x'], arg_name=None, description='This is a integer.', is_optional=None, type_name=None)])
    # Test docstring with a sub-section

# Generated at 2022-06-11 21:17:13.083665
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse('') == Docstring()

    assert parser.parse('Google style of documentation') == Docstring(
        short_description='Google style of documentation',
        blank_after_short_description=True,
    )

    assert parser.parse('Google style of documentation\n') == Docstring(
        short_description='Google style of documentation',
        blank_after_short_description=True,
    )

    assert parser.parse('Google style of documentation\n\n') == Docstring(
        short_description='Google style of documentation',
        blank_after_short_description=True,
        blank_after_long_description=False,
    )


# Generated at 2022-06-11 21:17:24.517531
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    '''Tests parse method of GoogleParser class'''
    print("Testing GoogleParser_parse")
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("  ") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("   \n   \n") == Docstring()
    assert GoogleParser().parse("docs") == Docstring(short_description="docs")
    # GoogleParser().parse("docs\n\n    desc")
    # assert GoogleParser().parse("docs\n   \n   desc") == Docstring(short_description="docs")
    # assert GoogleParser().parse("docs\n\n\n\ndesc") == Docstring(short_description="docs")

# Generated at 2022-06-11 21:17:36.540072
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-11 21:18:00.924815
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse('''
Description of the function.

Args:
    param1: The first parameter.
    param2: The second parameter.

Returns:
    bool: The return value. True for success, False otherwise.

''')
    assert docstring.short_description == 'Description of the function.'
    assert docstring.long_description == '\n    bool: The return value. True for success, False otherwise.'
    assert len(docstring.meta) == 2
    assert docstring.meta[0].__class__.__name__ == 'DocstringMeta'
    assert docstring.meta[0].args == ['param', 'param1: The first parameter.']
    assert docstring.meta[0].description == 'The first parameter.'
    assert docstring.meta[1].__class

# Generated at 2022-06-11 21:18:08.622796
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    psr = GoogleParser()
    assert psr.parse("") == Docstring()
    assert psr.parse("Hello, world!") == Docstring(
        short_description="Hello, world!"
    )
    assert psr.parse("Hello, world!\n") == Docstring(
        short_description="Hello, world!"
    )
    assert psr.parse("Hello, world!\n\n") == Docstring(
        short_description="Hello, world!",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-11 21:18:10.912104
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    func = GoogleParser().parse
    print(func.__name__)
    assert func



# Generated at 2022-06-11 21:18:22.259588
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # 测试正常 api_doc
    test_docstring = '''The full description of the API.

        This may contain multiple paragraphs.
        This second line is indented.

        Args:
            arg1 (Optional[int]): The first parameter.
               Defaults to None.
            arg2 (int): The second parameter.

        Raises:
            Exception: The exception to be raised.
        '''
    test_res = GoogleParser().parse(test_docstring)

    # 测试不带 Args 的 api_doc
    test_docstring2 = '''The full description of the API.

            This may contain multiple paragraphs.
            This second line is indented.

            Raises:
                Exception: The exception to be raised.
            '''
    test_res2 = Google

# Generated at 2022-06-11 21:18:31.283013
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class Temp:
        """temp class."""
        def f(
            self,
            a: int = 1,
            b: int = 2,
            c: int = 3,
            d: int = 4
        ) -> T.Tuple[int]:
            """Single section example.

            Example:
                something

            Returns:
                somthing
            """

        def g(self, a: T.List[int]) -> T.List[int]:
            """Multiple section example.

            Args:
                a (typing.List[int]): something.

            Example:
                something

            Returns:
                somthing

            """

    ret = GoogleParser().parse(Temp.f.__doc__)
    assert ret.short_description == "Single section example."



# Generated at 2022-06-11 21:18:40.473426
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("test") == Docstring(short_description="test")
    assert parse("test\n") == Docstring(short_description="test")
    assert parse("   test") == Docstring(short_description="test")
    assert parse("   test\n   ") == Docstring(short_description="test")
    assert parse("  test\n test") == Docstring(
        short_description="test", long_description="test"
    )
    assert parse("  test\n test\n") == Docstring(
        short_description="test", long_description="test"
    )
    assert parse(
        """
    test
    """
    ) == Docstring(short_description="test")

# Generated at 2022-06-11 21:18:48.822569
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .numpy import parse_numpy

    def parse_numpy(text):
        return np_parser.parse(text)

    np_parser = GoogleParser(title_colon=False)
    for section in DEFAULT_SECTIONS:
        if section.title != "Params":
            np_parser.add_section(section)
    np_parser.add_section(Section("Parameters", "params", SectionType.MULTIPLE))

    doc = """\
        First line.

        Second line.

        Examples
        --------
        >>> example()

        Returns
        -------
        float
            Return value.
        """
    assert parse(doc) == parse_numpy(doc)


# Generated at 2022-06-11 21:18:57.988411
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-11 21:19:06.946273
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    This is a GoogleParser_parse method of Documentator class.
    '''
    ret = GoogleParser().parse(text)
    assert ret.short_description == text.strip()
    assert ret.long_description == None
    assert ret.blank_after_long_description == False
    assert ret.blank_after_short_description == False
    assert ret.meta == []
    assert ret.__dict__ == {'short_description': text.strip(), 'long_description': None, 'blank_after_long_description': False, 'blank_after_short_description': False, 'meta': []}


# Generated at 2022-06-11 21:19:15.655996
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Tests parse method of class GoogleParser"""

    text = """
        Bla bla

        Bla bla bla

        Arguments:
            a (int): a parameter.
            b (int): b param.
            c (int): c param. Default to 2.
        """

    parser = GoogleParser()
    parser.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    docstring = parser.parse(text)

    assert docstring.short_description == "Bla bla"
    assert docstring.long_description == "Bla bla bla"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

    assert len(docstring.meta) == 3

# Generated at 2022-06-11 21:19:31.796676
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Summary line.

Extended description.

Attributes:
  attr1 (str): Description of `attr1`.
  attr2 (int, optional): Description of `attr2`. Defaults to 1.
  attr3 (:obj:`list` of :obj:`int`): Description of `attr3`. Defaults to list(range(10)).
  attr4: Description of `attr4`.

Args:
  arg1 (str): Description of `arg1`.
  arg2 (int): Description of `arg2`.

Raises:
  AttributeError: The ``Raises`` section is a list of all exceptions
    that are relevant to the interface.
  ValueError: If `param2` is equal to `param1`.

"""
    docstring = parse(text)
    #print(docstring)


# Generated at 2022-06-11 21:19:37.070207
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        Args:
            field_name (str): The name of the field.
            alias (str, optional): An alias for this field.
            type_name (str): The type.
            desc (str): Description of the field.

        Returns:
            str: The name of the field.
        """
    print(GoogleParser().parse(text))


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:19:49.115559
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text1 = '''
    Short description

    Long description.
    '''

    assert GoogleParser().parse(text1) == Docstring(
        short_description="Short description",
        blank_after_short_description=True,
        long_description="Long description.",
        blank_after_long_description=False,
        meta=[]
    )

    text2 = '''
    Short description

    Examples
    --------
    >>> a = 1
    >>> b = 2
    '''


# Generated at 2022-06-11 21:19:55.255250
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test if the method parse is working correctly
    # ================================Input======================================
    # Input the docstring of a function
    docstring = '''Retrieve user playlists

    :Returns:
        A list of user playlists.

    :Example:
        >>> get_user_playlists(user_name='Tom')
        [
            <Playlist 'Good songs'>,
            <Playlist 'Bad songs'>
        ]
    '''
    # ================================Output=====================================
    # Output the parsed docstring
    print(GoogleParser().parse(docstring))

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:20:03.558868
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing GoogleParser.parse()")

    # Simple docstring with single line description
    docstring = GoogleParser().parse("""Test method.
    :param x: this is a param
    :return: this is a return
    """)
    assert docstring.short_description == "Test method."
    assert docstring.long_description is None
    assert docstring.meta[0].args[0] == "param"
    assert docstring.meta[0].args[1] == "x"
    assert docstring.meta[0].description == "this is a param"
    assert docstring.meta[1].args[0] == "return"
    assert docstring.meta[1].description == "this is a return"

    print("Success!")


# Generated at 2022-06-11 21:20:15.031810
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = parse("Args: \n  arg1: Description of arg1\n  arg2: Description of arg2\n")
    assert len(docstring.meta) == 1
    assert docstring.meta[0].key == 'param'
    assert list(docstring.meta[0].args) == ['param', 'arg1']
    assert docstring.meta[0].description == 'Description of arg1'
    assert docstring.meta[0].type_name is None
    assert docstring.meta[0].is_optional is None
    assert docstring.meta[0].default is None
    assert docstring.meta[1].key == 'param'
    assert list(docstring.meta[1].args) == ['param', 'arg2']
    assert docstring.meta[1].description == 'Description of arg2'

# Generated at 2022-06-11 21:20:24.491576
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = inspect.cleandoc(r"""
        This is a short description
       
        This is a long description
       
        Args:
            arg1: The first argument.
            arg2: The second argument.
        Returns:
            The return value.
        
        Raises:
            IndexError: Thrown if an index error is detected.
            KeyError: Thrown if a key error is detected.
        
        Examples:
       
        >>> my_func(42)
        (13, 'hello')
        """)
    doc = parse(text)
    assert doc.short_description == "This is a short description"
    assert doc.long_description == "This is a long description"
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description

# Generated at 2022-06-11 21:20:37.900212
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """One line description.

    Long description.

    Args:
        arg1: Description of arg1.
        arg2: Description of arg2.

    Returns:
        Description of return value.

    Raises:
        ValueError: If a value error occurred.
    """
    result = parse(text)

# Generated at 2022-06-11 21:20:44.455293
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:20:56.372239
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:21:11.057114
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    txt = """
        Bla bla.
        """
    
    txt = """
        Bla bla.

        Parameters
        ----------
        arg1 : str
            Bla bla.
        arg2 : int
            Bla bla.

        Returns
        -------
        int
            Bla bla.
        """

    txt = """
    Bla bla.

    Arguments
    ---------
    arg1 : str
        Bla bla.
    arg2 : int
        Bla bla.

    Raises
    ------
    Exception
        Bla bla.

    Yields
    ------
    int
        Bla bla.
    """

    txt = """
        """

    txt = """
        Bla bla.

        """


# Generated at 2022-06-11 21:21:22.401111
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test GoogleParser.parse method."""
    g = GoogleParser()
    s = g.parse("this is a docstring.")
    assert s.short_description == "this is a docstring."
    assert s.long_description is None
    assert not s.meta

    # Test iterable metadata
    s = g.parse("""This is an example docstring.

Args:
    iterable (Iterable): Some iterable.
    name (str): Some string.

Returns:
    str: Some string.
""")

    a = s.meta[0]
    assert a.args == ("param", "iterable (Iterable)")
    assert a.description == "Some iterable."
    assert a.arg_name == "iterable"
    assert a.type_name == "Iterable"
    assert a.is_

# Generated at 2022-06-11 21:21:35.144784
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    def assert_parse( text: str, expected: Docstring) -> None:
        actual = parse(text)
        assert actual == expected


# Generated at 2022-06-11 21:21:45.167614
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    model = GoogleParser()
    assert(type(model) is GoogleParser)

    model = model.parse("\nThis method has to do things.\n")
    assert(type(model) is Docstring)
    assert(model.short_description == "This method has to do things.")
    assert(model.long_description == None)
    assert(model.blank_after_short_description == True)
    assert(model.blank_after_long_description == False)
    assert(model.meta == [])

    model = model.parse("\nThis method has to do things.\n\n")
    assert(type(model) is Docstring)
    assert(model.short_description == "This method has to do things.")
    assert(model.long_description == None)

# Generated at 2022-06-11 21:21:54.191078
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('') == Docstring()
    assert parse('t') == Docstring(short_description='t')
    assert parse('t\nd') == Docstring(short_description='t', long_description='d')
    assert parse('t\n d') == Docstring(short_description='t', long_description='d')
    assert parse('t\n\nd') == Docstring(short_description='t', long_description='d', blank_after_short_description=True, blank_after_long_description=True)
    assert parse('t\n \nd') == Docstring(short_description='t', long_description='d', blank_after_short_description=True, blank_after_long_description=False)
    #assert parse('t\n\n\nd') == Docstring(short_description='t', long_description

# Generated at 2022-06-11 21:22:06.484696
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('''
        Single-line description.
        :param a: A parameter.
        ''') == Docstring(
        description='Single-line description.',
        meta=[DocstringParam(
            args=["param", "a: A parameter."],
            arg_name='a',
            description='A parameter.',
            is_optional=None,
            default=None,
            type_name=None,
            )])


# Generated at 2022-06-11 21:22:19.110017
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    def parse_and_check(s, desc, exp_short, exp_long, exp_meta):
        exp_short = exp_short or ""
        exp_long = exp_long or ""
        doc = GoogleParser(title_colon=True).parse(s)
        assert doc.desc == desc, "Desc not correct"
        assert doc.short_description == exp_short or "", (
            "Short description not correct"
        )
        assert doc.long_description == exp_long or "", (
            "Long description not correct"
        )
        assert doc.meta == exp_meta or [], "Meta not correct"



# Generated at 2022-06-11 21:22:30.711883
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Google-style parser test"""
    # define docstring with section titles
    docstring = """
    This is a test docstring.
    This is the long description.

    Args:
        first_arg (str): this is the first argument
                    blah blah blah. Defaults to None.
        second_arg (int): the second argument is a number.

    Returns:
        bool: True if successful, False otherwise.
    """

    # build GoogleParser object
    parser = GoogleParser()

    # parse the docstring
    parsed_docstring = parser.parse(docstring)

    # define expected docstring

# Generated at 2022-06-11 21:22:36.187471
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """This function does some fancy stuff.

Args:
  arg_name: argument description.
  arg_name (int): argument description.

Returns:
  int. The return value.
"""
    result = GoogleParser().parse(docstring)
    print(result.short_description)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:22:47.983330
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    Given a non-empty array of integers, every element appears twice except for one. Find that single one.
    # Runtime: 40 ms, faster than 45.61% of Python3 online submissions for Single Number.
    # Memory Usage: 14.7 MB, less than 5.59% of Python3 online submissions for Single Number.
    '''
    google_docstring = parse(text)
    assert google_docstring.short_description == 'Given a non-empty array of integers, every element appears twice except for one. Find that single one.'
    assert google_docstring.long_description is None
    assert google_docstring.blank_after_short_description is True
    assert google_docstring.blank_after_long_description is False
    assert len(google_docstring.meta) == 2

# Generated at 2022-06-11 21:22:56.913148
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '"""Retrieve object by its ID.\n    Args:\n        id (str): Object ID.\n    Returns:\n        dict:\n            Object.\n    """\n'
    test_instance = GoogleParser()
    assert test_instance.parse(text)


# Generated at 2022-06-11 21:23:07.618930
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from docstring_parser import Parser
    from docstring_parser.common import Docstring
    assert GoogleParser().parse('In [1]:') == Docstring()
    assert GoogleParser().parse('In[1]:') == Docstring()
    assert GoogleParser().parse('In [1] :') == Docstring()
    assert GoogleParser().parse('In[1] :') == Docstring()
    assert GoogleParser().parse('In [1]:') == Docstring()
    assert GoogleParser().parse('In[1]:') == Docstring()
    assert GoogleParser().parse('In [1]: ') == Docstring()
    assert GoogleParser().parse('In[1]: ') == Docstring()
    assert GoogleParser().parse('In [1] : ') == Docstring()
    assert GoogleParser().parse('In[1] : ') == Docstring()

# Generated at 2022-06-11 21:23:14.797947
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # testing an empty docstring
    text = ""
    assert GoogleParser().parse(text) == Docstring()

    # testing an docstring with only a short description
    text = """Lorem ipsum dolor sit amet, consectetur adipiscing elit."""
    expected = Docstring(short_description="Lorem ipsum dolor sit amet, consectetur adipiscing elit.")
    assert GoogleParser().parse(text) == expected

    # testing an docstring with a short description and a long description

# Generated at 2022-06-11 21:23:21.782132
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #given
    text = """
    some text :)
    Args:
        a: "hello"
        b: helloween :)
    Exceptions:
        b:
            some text
    Returns:
        str
    """
    parser = GoogleParser()

    #when
    results = parser.parse(text)

    #then
    # TODO create proper test
    assert results.short_description is None
    assert results.long_description == "some text :)"
    assert len(results.meta) == 3
    assert results.meta[0].description == "\"hello\""
    assert results.meta[0].type_name == "str"
    assert results.meta[0].is_optional == None
    assert results.meta[0].arg_name == "a"
    assert results.meta[0].default == None


# Generated at 2022-06-11 21:23:23.113711
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    _test_GoogleParser_parse()



# Generated at 2022-06-11 21:23:29.483586
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """test method parse of class GoogleParser"""
    test_text = """
        This is text
        """
    test_result = GoogleParser().parse(test_text)
    assert test_result
    assert test_result.short_description == "This is text"
    assert test_result.long_description == ""
    assert test_result.blank_after_short_description == False
    assert test_result.blank_after_long_description == True

# Generated at 2022-06-11 21:23:35.318194
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring,DocstringMeta,DocstringParam,DocstringRaises,DocstringReturns

    class A:
        "Short description"
    d = parse(A.__doc__)
    assert isinstance(d, Docstring)
    assert d.short_description == "Short description"
    assert len(d.meta) == 0

    class A:
        """\
        Short description
        Long description

        Attributes:
            a: int
            b: int
        """
    d = parse(A.__doc__)
    assert isinstance(d, Docstring)
    assert d.short_description == "Short description"
    assert d.long_description == "Long description"
    assert len(d.meta) == 1
    assert isinstance(d.meta[0], DocstringMeta)

# Generated at 2022-06-11 21:23:44.576306
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:23:54.143202
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class A:
        """
        A function.

        Args:
            arg1: the first arg
            arg2 (str, optional): the second arg

        Raises:
            TypeError: if an arg is not a str.

        Returns:
            None
        """
        pass

    docstring = parse(A.__doc__)

    assert len(docstring) == 2
    assert docstring[0].short_description == "A function."
    assert docstring[1].arg_name == "arg1"
    assert docstring[1].type_name is None
    assert docstring[1].is_optional is None
    assert docstring[1].default is None
    assert docstring[1].description == "the first arg"
    assert docstring[2].arg_name == "arg2"

# Generated at 2022-06-11 21:24:03.407239
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from textwrap import dedent
    docstring = \
        """
        Single line description.

        This is the second line of description.

        Args:
            arg1 (str): first argument
            arg2 (int, optional): second argument
            arg3 [str]: third argument

        Raises:
            ValueError: If something bad happens.

        Yields:
            int: count until 5.
        """

    parser = GoogleParser()
    ret = parser.parse(docstring)

    assert ret.short_description == "Single line description."
    assert ret.long_description == dedent(
        """
        This is the second line of description.
        """
    )
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description

    assert len(ret.meta) == 4


# Generated at 2022-06-11 21:24:19.793613
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    desc = 'Parses the Google-style docstring into its components.'
    text = """
        This is a test docstring

        This is the long description

        Args:
            argument (int): The first argument.
            another (str): The second argument.

        Returns:
            bool: True if successful, else False.

        Raises:
            AttributeError: The ``Raises`` section is a list of all exceptions
                that are relevant to the interface.
            ValueError: If the parameters are out of range, and that sort of thing.
    """

    # Testing the string
    assert(desc in text)

    # Testing the class initialization
    gp = GoogleParser()

    # Testing the method add_section
    c = Section("Arguments", "param", SectionType.MULTIPLE)
    gp.add_section(c)


# Generated at 2022-06-11 21:24:33.393907
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser
    parsed = parser.parse("""\
    Asserts that `expression` is truthy (a boolean).

    Args:
      expression: The bool expression to test.
      message: Optional string to display if the check fails.

    Raises:
      AssertionError: The check failed.
    """)
    assert parsed
    assert isinstance(parsed, Docstring)
    assert parsed.short_description == "Asserts that `expression` is truthy (a boolean)."
    assert parsed.long_description == "Args:\n  expression: The bool expression to test.\n  message: Optional string to display if the check fails.\n\nRaises:\n  AssertionError: The check failed."
    assert len(parsed.meta) == 2

# Generated at 2022-06-11 21:24:45.709178
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is the example function.

    It does this important thing.

    Args:
        arg1 (str): First argument.
        arg2 (int): Second argument.

        It has this important purpose.
        This is the second line of its description.

    Returns:
        bool: Example return value.

    Raises:
        ValueError: If something is not right.

    Attributes:
        attr (int): Example attribute.

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

        >>> print([i for i in example_generator(4)])
        [0, 1, 2, 3]
    """

    de = Docstring()
    de.short_description = "This is the example function."

    de.blank_after_short_description = True

# Generated at 2022-06-11 21:24:55.704236
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """The docstring for a class, function or method.

    Args:
        arg1 (int): The first parameter.
        arg2 (str): The second parameter.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.
    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
    """

# Generated at 2022-06-11 21:25:05.438599
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    # If a docstring starts with a space character, it should be considered as a short description
    docstring = parser.parse("  This is short description")
    assert docstring.short_description == "This is short description"
    # If a docstring starts with a non-space character, it should be considered as an ordinary line
    docstring = parser.parse("  This is ordinary line")
    assert docstring.short_description == None
    assert docstring.long_description == "This is ordinary line"
    # If a docstring has a section, the section's title should be capitalized
    docstring = parser.parse("  This is a docstring.\n\nThis is a section:")
    assert docstring.short_description == "This is a docstring."

# Generated at 2022-06-11 21:25:13.601247
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ds = Docstring()
    assert(GoogleParser().parse('') == ds)
    ds = Docstring()
    ds.short_description = 'This is a short description'
    assert(GoogleParser().parse('This is a short description') == ds)
    ds = Docstring()
    ds.short_description = 'This is a short description'
    ds.blank_after_short_description = True
    ds.long_description = 'This is a long description'
    assert(GoogleParser().parse('This is a short description\n\nThis is a long description') == ds)
    ds = Docstring()
    ds.short_description = 'This is a short description'
    ds.blank_after_short_description = True
    ds.blank_after_long_description = True

# Generated at 2022-06-11 21:25:19.925710
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Simple example function with types documented in the docstring.

Args:
    param1 (int): The first parameter.
    param2 (str): The second parameter.

Returns:
    bool: The return value. True for success, False otherwise.

"""
    meta = GoogleParser().parse(docstring)
    print(meta)


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:25:29.155280
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:25:39.347147
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    res = parse('"""Short description.\n\nLong description.\n\nArgs:\n  arg1: description of arg1\n  arg2: description of arg2\n\nRaises:\n  ValueError: if arg1 is wrong\n  IOError: if arg2 is wrong\n"""')
    assert res
    res = parse('"""Lorem ipsum\n\nParams:\n  foo: Lorem.\n  bar: Lorem ipsum.\n\nRaises:\n  FooException: Lorem ipsum.\n  BarException: Lorem ipsum.\n"""')
    assert res