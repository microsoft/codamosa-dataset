

# Generated at 2022-06-11 21:16:16.931502
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("TESTING BEGINS")
    text = r"""\
    """
    doc = GoogleParser().parse(text=text)
    assert doc.short_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.long_description == None
    assert doc.meta == []
    print("TESTING FOR A GIVEN DOCSTRING PASSED")


# Generated at 2022-06-11 21:16:30.007271
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Parameterized testing is supported in nose with the
    :class:`nose.tools.parameterized` decorator and
    :func:`nose.tools.make_decorator`.

    :param test_cases: an iterable collection of test case input.
    :type test_cases: iterable
    :param params: an optional mapping of test parameter names to their
                   values. If provided, `test_cases` must be a collection
                   of test parameter names. The test parameter names
                   must be strings. The test parameter values may be
                   anything that may be used as a test function call
                   arguments.

    """
    ret = GoogleParser().parse(docstring)
    print(ret.meta)
    print(ret.short_description)
    print(ret.long_description)

# Generated at 2022-06-11 21:16:37.592189
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """This is a sample of docstring which will be parsed.
    Arguments:
       this_is_arg1: This is argument1. Default to 1.
       this_is_arg2: This is argument2. Default to 2.

    Returns:
       success: whether success or not

    Raises:
       TypeError: if is wrong type
    """
    ret = GoogleParser().parse(text)
    print(ret)
    assert ret

# Generated at 2022-06-11 21:16:48.077612
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Define docstring
    text = """\
        Short description.

        Long description.

        Arguments:
            arg1 (str): The first argument.
            arg2 (str, optional): The second argument.
              Defaults to "2".

        Returns:
            bool: The return value. True for success, False otherwise.
        """
    # Parse docstring
    doc = GoogleParser().parse(text)

    # Test parsing
    assert doc.short_description == "Short description."
    assert doc.long_description == "Long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert len(doc.meta) == 2

    assert doc.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-11 21:17:00.277500
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        Testing GoogleParser's method parse.

        This is a long description.
        This is line 2 of long description.

        Parameters:
            arg1 (bool): The first argument.
                Defaults to False.
            arg2 (str): The second argument.
                This is a long description of arg2.

        Returns:
            int: Return value.

        Raises:
            AttributeError: The ``Raises`` section is a list of all exceptions
                that are relevant to the interface.
            ValueError: If `param2` is equal to `param1`.
    """
    result = GoogleParser().parse(text)

    assert result.short_description == "Testing GoogleParser's method parse."
    assert result.long_description == """\
This is a long description.
This is line 2 of long description."""
    assert result

# Generated at 2022-06-11 21:17:07.103889
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    text = '''
        Google style docstring for the function square.

        Args:
            x: The number to square.

        Returns:
            The squared number.

        Raises:
            TypeError: If x is not a number.
    '''
    d = g.parse(text)
    for param in d.meta:
        print(param)


# Generated at 2022-06-11 21:17:10.243470
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test for method parse of class GoogleParser
    
    """
    assert len(GoogleParser().parse('').meta)==0



# Generated at 2022-06-11 21:17:22.738368
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = \
"""
This is a good docstring for a function.

Args:
    a (int): number of a.
    b (int, optional): number of b.

Return:
    int: sum of a and b.
"""
    ret = GoogleParser().parse(text)

    assert ret.short_description == "This is a good docstring for a function."
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    assert ret.long_description == "Args:\n\t\ta (int): number of a.\n\t\tb (int, optional): number of b.\n\nReturn:\n\t\tint: sum of a and b."

    # 1 element in meta array
    assert len(ret.meta) == 1

# Generated at 2022-06-11 21:17:34.627352
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:17:42.302196
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("hello") == Docstring(
        short_description="hello", long_description=None, meta=[]
    )
    assert parse("hello\n\nworld") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )
    assert parse("hello\n\nworld\n") == Docstring(
        short_description="hello",
        long_description="world",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:18:01.282494
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = inspect.cleandoc("""
        docstring.

        Arguments:
            foo:
                The first argument.
            bar:
                The second argument.

        Raises:
            Exception1
                When something bad happens.
            Exception2
                When something even worse happens.
        """)

# Generated at 2022-06-11 21:18:08.841628
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""
    def sum(a, b):
        """Returns sum of arguments.

        :param a: the first operand
        :param b: the second operand
        :type b: int
        :returns: the sum of arguments
        :raises: ValueError on non-int input
        """
        if not isinstance(a, int) or not isinstance(b, int):
            raise ValueError("Arguments must be integers")
        return a + b

    def factorial(n: int) -> int:
        """Calculate factorial of n.

        :param n: the number to calculate factorial
        :returns: the factorial of n
        :raises: ValueError if n is negative
        """

# Generated at 2022-06-11 21:18:20.542160
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Args:
        test (str): some test value.

    Returns:
        bool: Some value.
    """
    doc = GoogleParser().parse(docstring)
    assert(str(doc) == "[Docstring([Meta(args=['param', 'test'], description='some test value.')], [Meta(args=['returns'], description='Some value.')], 'some test value.', None, False, False)]")
    docstring = """
    Args:
        test (str): some test value.

    Returns:
        bool: Some value.

    Raises:
        ValueError: If something.
    """
    doc = GoogleParser().parse(docstring)

# Generated at 2022-06-11 21:18:30.711575
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse('')
    assert docstring == Docstring(None, None, False, False, None, [])
    docstring = parser.parse('a')
    assert docstring == Docstring('a', None, False, False, None, [])
    docstring = parser.parse('a\n\nb')
    assert docstring == Docstring('a', 'b', True, False, None, [])
    docstring = parser.parse('a\n b')
    assert docstring == Docstring('a', 'b', False, False, None, [])
    docstring = parser.parse('a\n\nb\nc')
    assert docstring == Docstring('a', 'b\nc', True, False, None, [])

# Generated at 2022-06-11 21:18:40.224501
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert inspect.cleandoc(
        parse.__doc__
    ) == """Parse the Google-style docstring into its components.

:returns: parsed docstring"""

    assert inspect.cleandoc(
        GoogleParser.parse.__doc__
    ) == """Parse the Google-style docstring into its components.

:returns: parsed docstring"""

    assert inspect.cleandoc(
        'Example of a simple one-line docstring.'
    ) == 'Example of a simple one-line docstring.'

    assert inspect.cleandoc(
        'Example of a simple one-line docstring.\n'
    ) == 'Example of a simple one-line docstring.'


# Generated at 2022-06-11 21:18:48.739542
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest
    from .common import DocstringParam, DocstringMeta, DocstringReturns, DocstringRaises
    import inspect
    import re

    # setup GoogleParser

# Generated at 2022-06-11 21:18:59.162427
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """This is a module docstring.

This is an example:
    print('hello world')

Args:
    name: The name to use in the greeting.
    age: Age of the person who will be greeted.

Returns:
    The greeting string.

Raises:
    AttributeError: The ``greeting`` attribute is not set.
    KeyError: The person requested is not present in this room.
"""


# Generated at 2022-06-11 21:19:10.617514
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:19:17.367526
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
        This is the description of my class.
        Arguments:
            arg1 (optional): This is the first argument.
            arg2: This is the second argument.
        Raises:
            ValueError: if the first argument is None
        '''

# Generated at 2022-06-11 21:19:30.077824
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing parse...", end="")
    parser = GoogleParser()
    docstring = parser.parse("""\
        Test docstring.

        Test description.

        Args:
            arg1 (str): Test arg1.
            arg2 (str): Test arg2.

        Attributes:
            attr1 (str): Test attr1.
            attr2 (str): Test attr2.

            attr3: Test attr3.
                With a longer description.
            attr4: Test attr4.
                With a longer description.

        Returns:
            object: Test return.

        Raises:
            AttributeError: Test exception.
        """)
    assert docstring.short_description == "Test docstring."
    assert docstring.blank_after_short_description is False
    assert docstring.long_

# Generated at 2022-06-11 21:19:46.599718
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    a = "test"
    output = obj.parse(a)
    assert type(output) == Docstring
    # Test fields
    assert output.short_description == "test"
    assert output.long_description == None
    assert output.blank_after_short_description == False
    assert output.blank_after_long_description == False
    assert output.meta == []

    a = "test\n\n"
    output = obj.parse(a)
    assert type(output) == Docstring
    # Test fields
    assert output.short_description == "test"
    assert output.long_description == None
    assert output.blank_after_short_description == True
    assert output.blank_after_long_description == False
    assert output.meta == []


# Generated at 2022-06-11 21:19:55.235029
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    input = '''
        This is the short description with a link to
        `some code <https://www.example.com>`_.

        This is the long description with a link to :class:`some.Module`.
        It can span multiple lines.

        This is a paragraph in the long description.

        This is a second paragraph in the long description.
    '''

    actual = GoogleParser().parse(input)


# Generated at 2022-06-11 21:20:03.776618
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
    This is a long-ish description.

    Line 2 of the long-ish description.

    Args:
      arg1: Description of arg1.
      arg2: Description of arg2.

    Returns:
      Description of return value.

    Raises:
      ValueError: If `arg2` is equal to `arg1`.

    Attributes:

    """
    parser = GoogleParser()
    docstring = parser.parse(doc)
    assert docstring.short_description == "This is a long-ish description."
    assert docstring.blank_after_short_description
    assert docstring.long_description == (
        "Line 2 of the long-ish description."
    )
    assert not docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta

# Generated at 2022-06-11 21:20:15.268999
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Testcase 1
    text = """
    Hello world.

    :param kwarg1: This is a keyword arg.

    :param kwarg2: This is a keyword arg
    with a long description and extra indentation
    """
    result = GoogleParser().parse(text=text)
    assert result.short_description == "Hello world."
    assert result.long_description == None
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0].args == ['kwarg1']
    assert result.meta[0].description == "This is a keyword arg."
    assert result.meta[0].keyword == 'param'
    assert result.meta[0].arg_name == 'kwarg1'
    assert result.meta[0].type_

# Generated at 2022-06-11 21:20:24.634261
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("short\n\nlong\n\nparam: bla\n\nreturns") == Docstring(
        short_description="short",
        long_description="long",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["param", "bla"],
                description=None,
            ),
            DocstringReturns(
                args=["returns"],
                description=None,
                type_name=None,
                is_generator=False,
            ),
        ],
    )

# Generated at 2022-06-11 21:20:30.620142
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse.__doc__
    assert type(docstring) is str
    docstring = parser.parse(docstring)
    assert type(docstring) is Docstring
    assert docstring.short_description == 'Parse the Google-style docstring into its components.'


# Generated at 2022-06-11 21:20:41.320904
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing method parse of class GoogleParser")
    obj = GoogleParser()
    text = "hmm this is some text!"
    res = obj.parse(text)
    assert res.short_description == "hmm this is some text!"

    # testing when long_description is present
    text = "hmm this is some text!\nThis is the long description!\n"
    res = obj.parse(text)
    assert res.short_description == "hmm this is some text!"
    assert res.long_description == "This is the long description!"

    # testing when long_description is not present
    text = "hmm this is some text!"
    res = obj.parse(text)
    assert res.short_description == "hmm this is some text!"
    assert res.long_description == None

    # testing when bl

# Generated at 2022-06-11 21:20:53.867346
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .numpyparser import NumpyParser
    from . import parse
    import pytest

    def test(source: str, expected: str) -> None:
        """Test the parser."""
        try:
            actual = parse(source, parser=NumpyParser).to_google()
            assert actual == expected
        except Exception as e:
            print(source)
            raise e

    test(
        "", ":returns MyClass: some description with no dot\n"
    )
    test(
        "", ":returns MyClass: some description with no dot\n"
    )

# Generated at 2022-06-11 21:21:00.581608
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    sections = [
        Section("Arguments", "param", SectionType.MULTIPLE),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    parser = GoogleParser(sections)
    docstring = parser.parse("""
    Docstring summary line

    Docstring long description
    """
    )
    # Check attributes of docstring
    assert docstring.short_description=="Docstring summary line"
    assert docstring.long_description=="Docstring long description"
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False


# Generated at 2022-06-11 21:21:10.748672
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import unittest

    class TestGoogleParserParse(unittest.TestCase):

        def setUp(self):
            self.parser = GoogleParser()

        def test_with_no_text(self):
            raw = ""
            self.assertEqual(self.parser.parse(raw), Docstring())

        def test_with_text_and_no_title(self):
            raw = "This is the short description\n"
            "This is the long description."
            doc = self.parser.parse(raw)
            self.assertEqual(doc.short_description, "This is the short description")
            self.assertEqual(
                doc.long_description, "This is the long description."
            )
            self.assertEqual(doc.blank_after_short_description, True)
            self.assertE

# Generated at 2022-06-11 21:21:25.338182
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:21:38.749151
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def func(a, b=1, c=3):
        doc = """Single line summary.

        Extended description.

        Args:
            a: description of first argument
            b: description of second argument
            c: description of third argument

        Returns:
            description of return value

        Raises:
            ZeroDivisionError if invalid inputs.
        """
        pass

    doc = GoogleParser().parse(func.__doc__)
    assert isinstance(doc, Docstring)
    assert doc.short_description == "Single line summary."
    assert doc.long_description == "Extended description."
    assert doc.blank_after_short_description is True
    assert doc.blank_after_long_description is True

# Generated at 2022-06-11 21:21:46.716967
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest
    def get_docstring_meta(docstring, klass):
        return [meta for meta in docstring.meta if isinstance(meta, klass)]

    g_parser = GoogleParser()

    def test_returns_type(text, expected_type_name):
        docstring = g_parser.parse(text)
        returns = get_docstring_meta(docstring, DocstringReturns)
        assert len(returns) == 1
        actual_type, = returns[0].type_name.split()
        assert actual_type == expected_type_name

    def test_returns_description(text):
        docstring = g_parser.parse(text)
        returns = get_docstring_meta(docstring, DocstringReturns)
        assert len(returns) == 1
        assert returns[0].description

# Generated at 2022-06-11 21:21:54.628770
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    with open("../../tests/data/GoogleParser.parse.txt", "r") as myfile:
        data=myfile.readlines()

    for i in range(len(data)):
        data[i] = data[i].replace("\n", "")

    gs = GoogleParser()
    ds = Docstring()

    ds = gs.parse(data[0])

# Generated at 2022-06-11 21:22:06.752347
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """ Test the method parse of class GoogleParser """
    parser = GoogleParser()
    example_google_docstring ='''
    This is a docstring example.
    Args:
        arg0: This is the first argument.
        arg1 (int): This is the second argument.
        arg2 (str, optional): This is the third argument.
    Raises:
        ValueError: If `arg2` is equal to `arg0`.
        TypeError: This error can be raised from anywhere.
    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    DocstringElement = namedtuple('DocstringElement', ['args', 'description', 'type_name', 'arg_name', 'is_optional', 'default', 'is_generator'])

# Generated at 2022-06-11 21:22:10.106374
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    string = """Google-style docstring parsing."""
    print("test_GoogleParser_parse:", GoogleParser(title_colon=True).parse(string))


# Generated at 2022-06-11 21:22:17.064244
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    a = GoogleParser()
    a.parse('''
    Chunk a document into sentences.
    :param text: a string
    :type text: str or unicode
    :returns: a list of sentences
    :rtype: list(str)
    >>> test_GoogleParser_parse()
    ''')

test_GoogleParser_parse()


# Generated at 2022-06-11 21:22:28.866241
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    # single line docstring
    d = g.parse("""\nThis is a sample module.\n""")
    assert d == Docstring(
        long_description=None,
        short_description="This is a sample module.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    # Two-line docstring with a blank line between short and long descriptions.
    d = g.parse("""\nThis is a sample module.\n\nFunctions:\n""")
    assert d == Docstring(
        long_description=None,
        short_description="This is a sample module.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:22:39.111215
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:22:50.319314
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method GoogleParser.parse
    from .pytest_util import assert_match

    def assert_parse(string, expected, expect_error=None):
        try:
            actual = parse(string)
            if expect_error:
                assert False, 'Expected error: {}'.format(expect_error)
        except e as ParseError:
            if not expect_error:
                print(e)
            assert_match(e.message, expect_error)
        else:
            assert_match(actual, expected)
    assert_parse('description', [
        'short_description', 'description',
        'blank_after_short_description', 'False',
        'blank_after_long_description', 'True',
        'meta', [],
    ])

# Generated at 2022-06-11 21:23:09.992450
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def function_definition():
        """First line.

        Additional explanation.

        Arguments:
          arg1(str): This is the first argument.
          arg2(int): This is the second argument.
          arg3(bool, optional): This argument is optional.
                                Defaults to False.

        Returns:
          bool: Return true if option is True

        Raises:
          ValueError: If option is not True or False.
        """


# Generated at 2022-06-11 21:23:18.494220
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = '''
    Add a to b.
    
    Params:
        a (int): An integer.
        b (int, optional): Another integer. Defaults to 0.
    
    Returns:
        The sum of the integers.
    '''
    exp = '''
    Add a to b.
    
    Params:
        a (int): An integer.
        b (int): Another integer.
    
    Returns:
        The sum of the integers.
    '''
    docstring = GoogleParser().parse(doc)
    assert (str(docstring)) == exp



# Generated at 2022-06-11 21:23:29.987047
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''\
        This is a method docstring.

        Example:
            This is an example.
            This is the second line of the example.
        
        Attributes:
            attr1 (str): Description of `attr1`
            attr2 (str): Description of `attr2`
        '''
    
    parsed = GoogleParser().parse(docstring)
    assert parsed.short_description == 'This is a method docstring.'
    assert parsed.long_description == 'This is an example.\nThis is the second line of the example.'
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long_description == True
    assert len(parsed.meta) == 2
    assert parsed.meta[0].args == ['example']

# Generated at 2022-06-11 21:23:41.852754
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    txt = """
    Hello, Docstring!

    This is a test.

    Args:
        arg1: an example argument
        arg2: another example argument
        arg3 (str): this one has a type
        arg4 (optional): this one is optional
        arg5 (str, optional): this one is optional with a type

    Returns:
        str: A string with a default value of 'success'.
        int: A number with a default value of 0.

    Yields:
        str: A string with a default value of 'success'.
        int: A number with a default value of 0.

    Raises:
        Exception: If something goes wrong.

    Example:
        Prints 'Hello, World!'

        >>> print("Hello, World!")
    """
    result = GoogleParser().parse(txt)

# Generated at 2022-06-11 21:23:46.952693
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """A test.
    :returns: Something else.
    """
    assert GoogleParser().parse(docstring).long_description == "A test."
    return


__all__ = ["GoogleParser", "parse"]

# Generated at 2022-06-11 21:23:56.156716
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    gp = GoogleParser()

# Generated at 2022-06-11 21:24:04.273003
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Use this method to test GoogleParser.parse()
    from pytodo.parsers.google import parse
    doc = parse("""\
        This is a short description.

        This is a long description.

        Args:
            arg1 (bool): The first argument.
            arg2 (int): The second argument
                and its description. Defaults to 3.
        """)
    print("Returned doc:", doc)
    # make sure the parse is according to the input
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ["param"]

# Generated at 2022-06-11 21:24:07.975853
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .testdata import test_strings

    for text, expected_result in test_strings.items():
        parser = GoogleParser()
        actual_result = parser.parse(text)
        assert actual_result == expected_result

# Generated at 2022-06-11 21:24:18.783034
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # returns: short description, long description, meta
    ret = Docstring()
    ret.short_description = "My short description"
    ret.long_description = "My long description"
    ret.meta = [DocstringMeta(args=['attribute'], description='test')]

    # test empty string
    assert (GoogleParser().parse("") == Docstring())

    # test with only description
    test_description = "A short description\nA long description"
    assert (GoogleParser().parse(test_description) == Docstring(short_description="A short description", long_description="A long description"))

    # test with only one element
    test_one_element = "A short description\nA long description\nArgs:\n    arg1 (int): A long description of arg1"

# Generated at 2022-06-11 21:24:32.756495
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    CustomSection = Section("Custom", "custom", SectionType.SINGULAR)
    return_section = Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE)
    parser = GoogleParser([CustomSection, return_section], title_colon=True)

    # Google style docstring
    s = """\
    Simple function.

    This will do this and that.

    Parameters
    ----------
    param: str
        The parameter description.

    Returns
    -------
    int
        The return value.

    Examples
    --------
    >>> func()
    1
    """
    res = parser.parse(s)
    assert res.short_description == "Simple function."
    assert res.long_description == "This will do this and that."

# Generated at 2022-06-11 21:24:50.553589
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser

    Returns:
        None
    """
    gp = GoogleParser()
    one_line_text = 'This function takes a, b, as input and returns a+b as output'
    parsed_docstring = gp.parse(one_line_text)
    expected_docstring = Docstring(
        short_description=one_line_text, long_description=None, meta=[]
    )
    assert parsed_docstring == expected_docstring

    multi_line_text = """
    This is a multi-line input.
    This function takes a, b, as input and returns a+b as output
    """
    parsed_docstring = gp.parse(multi_line_text)

# Generated at 2022-06-11 21:25:01.105711
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def foo(x, y):
        """Summary line.

        Extended description of function.

        Parameters
        ----------
        x : int
            Description of `x`
        y : float
            Description of `y`

        Returns
        -------
        str
            Description of return value

        """
        return None


    parser = GoogleParser()
    docstring = parser.parse(foo.__doc__)
    assert docstring.short_description == "Summary line."
    assert docstring.long_description == "Extended description of function."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "x"]

# Generated at 2022-06-11 21:25:11.011786
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    doc1 = """
    A short summary.

    A longer description with some additional details,
    including blank lines.

    Args:
        some_arg (int): a variable

        another_arg (str): some constant

    Returns:
        int: some result
    """

    doc2 = """
    A short summary.

    A longer description with some additional details,
    including blank lines.

    Parameters:
        some_arg (int): a variable

        another_arg (str): some constant

    Returns:
        int: some result

    Raises:
        ValueError: description
    """


# Generated at 2022-06-11 21:25:21.587281
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import os
    import tempfile

    d1 = """Multiline docstring.
    Would be parsed by GoogleParser.

    Section without title.

    Parameters
    ----------
    v : int
        The velocity in m/s.
    t : float
        Time in seconds.
    """

    d2 = """Multiline docstring.
    Would be parsed by GoogleParser.

    Parameters
    ----------
    v : int
        The velocity in m/s.

    t : float
        Time in seconds.
    """

    d3 = """Multiline docstring.
    Would be parsed by GoogleParser.

    Parameters
    ----------
    v : int
        The velocity in m/s.
        Defaults to 3

    t : float
        Time in seconds.
    """


# Generated at 2022-06-11 21:25:30.032151
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''My first line.

Attributes:
    attr1 (str, optional): My attribute.
    attr2 (:obj:`int`, optional): My other attribute. Defaults to 42.

Example:
    Some example.

Examples:
    Some example.
    Some other example.

Return:
    What is returned.

Returns:
    What is returned.

Raise:
    Some error.

Raises:
    NameError: if something bad occurs.
    ValueError: if something else bad occurs.

Yield:
    What is yielded.
    What is yielded.

Yields:
    What is yielded.
    What is yielded.
'''
    res = GoogleParser().parse(docstring)
    assert res.short_description == 'My first line.'

# Generated at 2022-06-11 21:25:39.954420
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()

    # Test case 1: no docstring
    config = parse("")
    assert not config.short_description and not config.long_description and not config.meta
    # Test case 2: docstring with no metadata
    config = parse("this is the docstring")
    assert config.short_description == "this is the docstring" and not config.long_description and not config.meta

    # Test case 3: docstring with metadata
    config = parse("Args:\n  arg1: First arg\n  arg2: Second arg. Defaults to 42.\n")
    assert config.short_description == None and config.long_description == None and len(config.meta) == 2
    assert config.meta[0].args == ['param', 'arg1'] and config.meta[0].description == 'First arg'