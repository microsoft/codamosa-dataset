

# Generated at 2022-06-11 21:15:59.997663
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # TODO: use test_case
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("  ") == Docstring()
    assert parser.parse("  abcd").short_description == "abcd"

    assert parser.parse("abcd efgh\n").short_description == "abcd efgh"
    assert parser.parse("\nabcd efgh\n").short_description == "abcd efgh"
    assert parser.parse("abcd efgh\n\n").short_description == "abcd efgh"
    assert parser.parse("\nabcd efgh\n\n").short_description == "abcd efgh"


# Generated at 2022-06-11 21:16:08.245112
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    assert str(gp.parse("")) == "{}"
    assert str(gp.parse("")) == "{}"
    assert str(gp.parse("(Optional).")) == "{'short_description': '(Optional).'}"
    assert str(
        gp.parse("(Optional).\n" + "\n" + "Longer.")
    ) == "{'blank_after_long_description': True, 'blank_after_short_description': True, 'long_description': 'Longer.', 'short_description': '(Optional).'}"
    assert str(gp.parse("**Params**: \n" + "    a\n" + "    b")) == (
        "{'meta': [{'args': ['param', 'a'], 'description': None, 'type_name': None}]}"
    )

# Generated at 2022-06-11 21:16:13.813521
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    a_str = """
    This is a method to print time and date
    :param date: date to print (str)
    :param time: time to print (str)
    :return: a formatted str describing date and time
    :raises TypeError: if date or time is not a str
    """
    a_str_parse = parse(a_str)
    assert str(a_str_parse) == a_str

# Generated at 2022-06-11 21:16:19.951340
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    google_docstring = """One line summary.

    Extended summary.
    """
    expected_docstring = Docstring(
        short_description="One line summary.",
        blank_after_short_description=True,
        long_description="Extended summary.",
        blank_after_long_description=True,
        meta=[],
    )
    result1 = GoogleParser().parse(google_docstring)
    print("test case 1: ", result1==expected_docstring)

    # Test case 2
    google_docstring = """One line summary.

    Extended summary.
    """

# Generated at 2022-06-11 21:16:31.716765
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    description = "Parse the Google-style docstring into its components."

# Generated at 2022-06-11 21:16:44.792158
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:16:57.252691
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("\n") == Docstring()
    assert parser.parse("Hello world.\n") == Docstring(
        short_description="Hello world.",
    )
    assert parser.parse("Hello world.\n\n") == Docstring(
        short_description="Hello world.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parser.parse("Hello world.\n\n\n") == Docstring(
        short_description="Hello world.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-11 21:17:10.643365
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""
    # test for docstring with multiple sections
    g = GoogleParser()
    text = """
    Single line description followed by a blank line.

    Multiple sections of meta-data.

    Attributes:
        Hello: world

    Args:
        param1: The first parameter.
        param2: The second parameter.
            Default is -1.
        param3(str): The third parameter.
            Default is 'yes'.

    Raises:
        KeyError: Raises an exception.

    Returns:
        True if successful, False otherwise.

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

        >>> print([i for i in example_gen()])
        [0, 1, 2, 3]

    """
    ds = Doc

# Generated at 2022-06-11 21:17:23.108883
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    input = ("""\
This is the short description.

This is the long description.

Args:
    arg1: The first argument.
    arg2: The second argument.

Returns:
    The return value. True for success, False otherwise.
""")

# Generated at 2022-06-11 21:17:26.970724
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = parse.__doc__
    import pprint
    pprint.pprint(GoogleParser().parse(docstring).__dict__)


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:17:55.417842
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Summary line.

    Extended description.
    
    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function/class. 
        >>>
        
    Arguments:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    """

    class test():
        """Summary line.

        Extended description.
    
        Examples:
            Examples should be written in doctest format, and should illustrate how
            to use the function/class. 
            >>>
        
        Arguments:
            arg1 (int): Description of arg1
            arg2 (str): Description of arg2

        Returns:
            str: Description of return value

        """
        def func(self):
            pass

    #print(inspect.cleandoc(inspect.getdoc

# Generated at 2022-06-11 21:18:05.317418
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """
    Short summary.

    Long summary.

    Args:
        arg1 (int): Description of arg1
            With second line.

        arg2 (str): Description of arg2

        arg3 (Optional[int]): Description of arg3. Defaults to 10.

    Returns:
        Tuple[int, str, bool]: Description of return
    """

    # print(text)
    docstring = parser.parse(text)
    print(docstring)
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.blank_after_short_description)
    print(docstring.blank_after_long_description)
    print(docstring.meta)


# Generated at 2022-06-11 21:18:17.655705
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("testing method parse of class GoogleParser...")
    parser = GoogleParser()

# Generated at 2022-06-11 21:18:28.860348
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "Summary line.\n\nDescription. Description continues here.\n\n"
    text += "   Args:\n"
    text += "       arg1 (int): Description of `arg1`.\n"
    text += "       arg2 (str): Description of `arg2`."
    text += "           The description continues here.\n"
    text += "       *args: Variable length argument list.\n"
    text += "       **kwargs: Arbitrary keyword arguments.\n"
    text += "   Returns:\n"
    text += "        bool.\n"
    text += "   Raises:\n"
    text += "        AttributeError, KeyError\n"
    text += "   Examples:\n"
    text += "       Examples should be written in doctest format, and"

# Generated at 2022-06-11 21:18:39.076614
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-11 21:18:41.166188
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    try:
        GoogleParser().parse("")
    except ParseError:
        pass  # expected



# Generated at 2022-06-11 21:18:49.206579
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
    Return a new array of given shape and type, without
    initializing entries.

    Parameters
    ----------
    shape : int or tuple of int
        Shape of the empty array, e.g., ``(2, 3)`` or ``2``.
    dtype : data-type, optional
        Desired output data-type for the array, e.g, ``numpy.int8``.
        Default is ``numpy.float64``.

    Returns
    -------
    out : ndarray
        Array of uninitialized (arbitrary) data of the given shape,
        dtype, and order.  Object arrays will be initialized to None.
    """

    result = parse(doc)

    assert result.short_description == "Return a new array of given shape and type, without initializing entries."
    assert result.blank_after

# Generated at 2022-06-11 21:18:59.232774
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:19:10.702087
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    def get_docstring(text: str) -> str:
        """Returns docstring from text.

        :param text: text possibly containing a docstring
        :returns: docstring or None
        """
        lines = [line.strip(" ") for line in text.split("\n")]

        def is_docstring(text: str) -> bool:
            return text.startswith('"""' or text.startswith("'''"))

        ret = []
        if lines and is_docstring(lines[0]):
            lines.pop(0)
            while lines and not is_docstring(lines[0]):
                ret.append(lines.pop(0))
        if lines and is_docstring(lines[0]):
            lines.pop(0)
        return "\n".join(ret) or None

   

# Generated at 2022-06-11 21:19:17.412158
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    code = """
    Larger function with multiple parameters, some with type

    :param param1: The first parameter.
    :type param1: int
    :param param2: The second parameter.
    :type param2: int
    :returns: Description of return value.
    :rtype: int
    :raises TypeError: if isinstance(x, str)
    :raises KeyError: if type(x) == dict
    """


# Generated at 2022-06-11 21:19:27.526025
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for method parse of class GoogleParser"""
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:19:28.850705
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Running unit test for method parse of class GoogleParser")


# Generated at 2022-06-11 21:19:38.502513
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("string") == Docstring(
        short_description="string", blank_after_short_description=False,
        blank_after_long_description=False, long_description=None, meta=[]
    )
    assert GoogleParser().parse("string\na\nb\nc") == Docstring(
        short_description="string", blank_after_short_description=False,
        blank_after_long_description=True, long_description="a\nb\nc", meta=[]
    )

# Generated at 2022-06-11 21:19:41.829689
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_text_01 = '''
    This is the first line.
    It is on the second line.

    This is the third line.
    '''

    GoogleParser().parse(test_text_01)

# Generated at 2022-06-11 21:19:53.179504
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Set to 1 if this function is being tested.
    TEST_THIS_FUNCTION = 0

    if TEST_THIS_FUNCTION == 1:
        # Dummy test case
        stub = GoogleParser()
        print(GoogleParser.__doc__)
        print(stub.parse.__doc__)

        # For each test case,
        for case in [{'input':"The function that should be tested",
                      'expected':"The expected output corresponding to test1", 'reason':"Because test1 has these conditions"}]:
            # Get inputs
            input0 = case['input']
            expected = case['expected']
            reason = case['reason']

            # Perform test
            stub.parse(input0)
            actual = "The actual output"

            # Print results
            print("--------------")

# Generated at 2022-06-11 21:20:03.156640
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('test') == parse('''test''')
    assert parse('''
test
''') == parse('''test''')
    assert parse('''
test
''') == parse('test')
    assert parse('''
test
''') == parse('''
test''')
    assert parse('''
test
''') == parse('''
test
''')
    assert parse('''
test
''') == parse('''
test

''')
    assert parse('''
test
''') != parse('''
tests
''')
    assert parse('''
test
''') == parse('''
    test
''')
    assert parse('''
test
''') == parse('''
    test
    ''')
    assert parse('''
test
''')

# Generated at 2022-06-11 21:20:14.246906
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    elem = GoogleParser()
    docstring = '''
    Args:
        arg1: The first argument.
        arg2: The second argument.
    '''
    result = elem.parse(docstring)
    expected = Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(args=[
                'param',
                'arg1',
                'The first argument.'
            ], description='The first argument.'),
            DocstringMeta(args=[
                'param',
                'arg2',
                'The second argument.'
            ], description='The second argument.')
        ]
    )
    assert result == expected

# Generated at 2022-06-11 21:20:23.962491
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "Short summary.\n\nLonger description.\n\nAttributes:\n    attr1 (int): Description.\n    attr2 (float) \n    attr3: Description.\n    attr4 (int, optional): Description. Defaults to 2.\n    attr5 (\n        int, \n        optional,\n    ): Description. Defaults to 2.\n\nRaises:\n    ValueError: Description.\n    SyntaxError: Description.\n"
    docstring = parse(docstring)
    assert docstring.short_description == "Short summary."
    assert docstring.long_description == "Longer description."
    assert docstring.meta[0].description == "Description."
    assert docstring.meta[0].arg_name == "attr1"
    assert docstring

# Generated at 2022-06-11 21:20:32.148019
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """A function to test GoogleParser().parse()"""
    text = """Calculate the distance between two numbers.

    :param number: The first number.
    :param other: The second number.
    
    :returns: The distance between two numbers.
    """

    print(parse(text))
    print(parse(text).meta[0])
    print(parse(text).meta[1])
    print(parse(text).meta[2])


# Generated at 2022-06-11 21:20:39.199548
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for method parse of class GoogleParser"""
    parser = GoogleParser()

    # setup
    docstring = '''Single line
    ...
    Hello World!
    '''

    # assert
    docstring = parser.parse(docstring)
    assert docstring.short_description == 'Single line'
    assert docstring.long_description == 'Hello World!'
    assert docstring.blank_after_long_description
    assert docstring.blank_after_short_description



# Generated at 2022-06-11 21:20:56.539113
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
        google-style docstring for test
        :param arg1: argument1
        :param arg2 : argument2
        :param arg3: argument3
        :return: nothing
        """
    parser = GoogleParser()
    result = parser.parse(doc)
    assert result.short_description == "google-style docstring for test"
    assert len(result.meta) == 4
    assert result.meta[0].args[0] == "param"
    assert result.meta[0].args[1] == "arg1"
    assert result.meta[1].args[0] == "param"
    assert result.meta[1].args[1] == "arg2"
    assert result.meta[2].args[0] == "param"

# Generated at 2022-06-11 21:21:07.448955
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("""
    This is a short description.

    This is a long description.

    Arguments:
        x: X

    Examples:
        foo = 1
    """) == Docstring(
        short_description="This is a short description.",
        long_description="This is a long description.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=["param", "x: X"],
                description=None,
                arg_name="x",
                type_name=None,
                is_optional=None,
                default=None,
            ),
            DocstringMeta(args=["examples", None], description="foo = 1"),
        ],
    )


# Generated at 2022-06-11 21:21:14.897835
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:21:24.980515
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    string_1 = """Short description.

    Longer description.

    Args:
        arg1: First argument.
        arg2: Second argument.

    Returns:
        The return value. True for success, False otherwise.
        """
    string_2 = """Short description.

    Longer description.

    args:
        arg1: First argument.
        arg2: Second argument.

    returns:
        The return value. True for success, False otherwise.
        """
    string_3 = """Short description.

    Longer description.

    Args:
        arg1: First argument.
        arg2: Second argument.
        arg3: Third argument.

    Returns:
        The return value. True for success, False otherwise.
        """

# Generated at 2022-06-11 21:21:37.949033
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    _text = """
        This is the summary line for a first method.
        file: name of the input file
        :param x: param1
        :param y: param2
        :returns: The return value. True for success, False otherwise.
        :raises KeyError: When a key error
        """
    docstring = GoogleParser().parse(_text)
    docstring.short_description == "This is the summary line for a first method."
    docstring.long_description == None
    docstring.blank_after_short_description == True
    docstring.blank_after_long_description == False

# Generated at 2022-06-11 21:21:40.930452
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc_string = parser.parse("\n")
    doc_string = parser.parse("\n\n")
    pass

# End unit test for method parse of class GoogleParser


# Generated at 2022-06-11 21:21:51.699658
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    
    text = inspect.cleandoc(
    """
    """
    )
    assert parse(text) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    text = inspect.cleandoc(
    """
    short description
    """
    )
    assert parse(text) == Docstring(
        short_description='short description',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

    text = inspect.cleandoc(
    """
    short description
    long description
    """
    )
    assert parse(text) == Docstring

# Generated at 2022-06-11 21:22:03.570691
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Parse the Google-style docstring into its components.

    :returns: parsed docstring"""
    docstring = GoogleParser().parse(text)

    assert docstring.short_description == "Parse the Google-style docstring into its components."
    assert docstring.blank_after_short_description == False
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == True

    assert docstring.meta[0].args[0] == "returns"
    assert docstring.meta[0].args[1] == "parsed docstring"
    assert docstring.meta[0].description == "parsed docstring"
    assert docstring.meta[0].is_generator == False
    assert docstring.meta[0].is_optional == None

# Generated at 2022-06-11 21:22:11.404914
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for method GoogleParser().parse"""
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("Function description") == Docstring(
        short_description="Function description",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    assert GoogleParser().parse("Function description\n") == Docstring(
        short_description="Function description",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-11 21:22:23.315735
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    Summary line.

    Extended description.

    Parameters:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
        arg3 (float): Description of arg3
            Defaults to 10.
        arg4 (bool, optional): Description of arg4
        arg5 (int): Description of arg5 with
            two lines and a list:
            * list 1
            * list 2

    Returns:
        int: Description of return value.
    """

    expected_title = "Summary line."
    expected_descriptions = ("Extended description.", )
    expected_params = (
        "arg1",
        "arg2",
        "arg3",
        "arg4",
        "arg5",
        "arg6",
    )

# Generated at 2022-06-11 21:22:38.630800
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    test_docstring_1 = """Short description.

    Long description.

    Parameters
    ----------
    arg1: str
        Description of arg1

    arg2: int, optional
        Desription of arg2
    """

# Generated at 2022-06-11 21:22:44.509703
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    gParser = GoogleParser()
    gParser.parse('''

        Add two numbers.

        Args:
            a: first number to be added
            b: second number to be added

        Returns:
            Sum of the two numbers.
    ''')

import unittest


# Generated at 2022-06-11 21:22:52.288942
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc = parser.parse("this is a test.")
    assert doc.short_description == "this is a test."
    assert doc.long_description is None
    assert len(doc.meta) == 0
    
    doc = parser.parse("this is a test.\n   \n   \n   \nlong desc.")
    assert doc.short_description == "this is a test."
    assert doc.long_description == "long desc."
    assert doc.meta == []
    
    doc = parser.parse("this is a test.\n\n\nlong desc.")
    assert doc.short_description == "this is a test."
    assert doc.long_description == "long desc."
    assert doc.meta == []
    

# Generated at 2022-06-11 21:23:00.745375
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    #Input: 
    # text = '''
    #   This is the first line of docstring
    #   This is the second line of docstring
    #   This is the third line of docstring
    #   '''
    # Expected output: 
    # Docstring(short_description='This is the first line of docstring', long_description='This is the second line of docstring\nThis is the third line of docstring', blank_after_short_description=False, blank_after_long_description=True, meta=[])

    text = '''
      This is the first line of docstring
      This is the second line of docstring
      This is the third line of docstring
      '''

# Generated at 2022-06-11 21:23:01.814186
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("\n") == Docstring()

# Generated at 2022-06-11 21:23:11.627417
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:23:20.396493
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def foo():
        """
        First line is brief description.

        The rest of the description starts here and continues
        on this line for a while.

        The description continues on
        :py:attr:`some.attr`

        :param foo: description
        :type foo: int
        :param bar: description
        :param baz: description

        :returns: description
        :rtype: str
        """
        return


# Generated at 2022-06-11 21:23:31.544465
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = '''blah blah blah

Args:
    arg1: Description of arg1.
    arg2: Description of arg2.

blah blah blah

Raises:
    AttributeError
    IOError

blah blah blah

Returns:
    Description of return value.
    '''
    docstring = parser.parse(text)
    assert docstring is not None
    assert docstring.short_description == 'blah blah blah'
    assert docstring.long_description == 'blah blah blah'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta is not None
    assert len(docstring.meta) == 4

# Generated at 2022-06-11 21:23:43.273046
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test parse method."""

    text = """\
        Short Description.
        
        Long Description ...
        
        Args:
            *args: Arbitrary variable length argument list.
            **kwargs: Arbitrary keyword arguments.
            arg1 (str): Description of arg1.
            arg2 (Optional[str]): Description of arg2. Defaults to None.
            arg3 (bool): Description of arg3.. Defaults to False.
            
        Returns:
            str: Description of return value.
            tuple(bool, list(str)): Description of another return value.
            
        Yields:
            str: Description of yielded value.
            Tuple[bool, List[str]]: Description of another yielded value.
    """

# Generated at 2022-06-11 21:23:45.927333
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    string = """
    """
    parser = GoogleParser()
    assert parser.parse(string) == Docstring()



# Generated at 2022-06-11 21:24:01.299523
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text1 = '''
        Single line docstring

        Args:
            foo (int): The foo value.
            bar (str, optional): The bar value. Defaults to 'bar'.
            baz (bool, optional): The baz value. Defaults to True.

        Returns:
            int: The foo value.

        Examples:
            >>> foo(1, 2, 3)
            6
            >>> foo('a', 'b', 'c')
            'abc'
        '''
    parser = GoogleParser()
    docstring = parser.parse(text1)
    assert docstring.short_description == 'Single line docstring'
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-11 21:24:02.133022
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:24:15.006173
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    
    docstring = """Google-style docstring parsing.
Parameters
----------
x : int
    The first number to add.
y : int
    The second number to add.
    
Returns
-------
float
    The sum of x and y.
"""
    
    docstring_obj = GoogleParser().parse(docstring)
    assert(docstring_obj.short_description == 'Google-style docstring parsing.')
    assert(docstring_obj.long_description == None)
    assert(docstring_obj.blank_after_short_description == True)
    assert(docstring_obj.blank_after_long_description == False)
    assert(docstring_obj.meta[0].args == ['param', 'x : int'])
    assert(docstring_obj.meta[0].arg_name == 'x')
   

# Generated at 2022-06-11 21:24:23.099051
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert_that(parse('This is a string with no metadata'),
        all_of(has_property('short_description', 'This is a string with no metadata'),
        has_property('long_description', None)))

    assert_that(parse('This is a string with no metadata\n\n\n'),
        all_of(has_property('short_description', 'This is a string with no metadata'),
        has_property('long_description', None),
        has_property('blank_after_short_description', True),
        has_property('blank_after_long_description', True)))


# Generated at 2022-06-11 21:24:35.147984
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()

    assert GoogleParser().parse("My module.\n\nMy desc.") == Docstring(
        short_description="My module.",
        long_description="My desc.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[]
    )

    assert GoogleParser().parse("My module.\nMy desc.") == Docstring(
        short_description="My module.",
        long_description="My desc.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-11 21:24:46.667035
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Google-style docstring parsing.

    :param text: the text to be parsed

    :returns: parsed docstring
    """
    text = inspect.cleandoc(text)
    ret = GoogleParser().parse(text)
    assert ret.short_description == "Google-style docstring parsing."
    assert ret.long_description == "the text to be parsed"
    assert ret.meta[0].args == ["param", "text"]
    assert ret.meta[1].args == ["returns"]
    short_dec = ret.short_description
    long_dec = ret.long_description
    return_doc = ""
    for i in ret.meta:
        if i.args == ["returns"]:
            return_doc = i.description
    assert return_doc == "parsed docstring"
   

# Generated at 2022-06-11 21:24:53.722442
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    :param a: Param a
    :param b: Param b
    :raises exc: Raises exc
    :return: Return
    '''
    google_parser = GoogleParser()
    result = google_parser.parse(docstring)
    assert len(result.meta) == 4
    assert result.meta[1] == DocstringParam(args=['param', 'b: Param b'], arg_name='b',
                                            description='Param b',
                                            type_name=None, is_optional=None, default=None)

# Generated at 2022-06-11 21:25:03.759747
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # should parse correctly a docstring following the google pattern

    text = '''
        Name

        Args:
            value1 (str): The string value of the parameter
            value2 (str): The string value of the parameter

        Returns:
            A parsed docstring.
    '''

    parsed_docstring = GoogleParser().parse(text)

    # checking if the parsed_docstring is a Docstring
    isinstance(parsed_docstring, Docstring)

    # checking the short description
    parsed_docstring.short_description == "Name"

    # checking the long description
    parsed_docstring.long_description == "Args:\n    value1 (str): The string value of the parameter\n    value2 (str): The string value of the parameter\n\nReturns:\n    A parsed docstring."

    # checking if there was

# Generated at 2022-06-11 21:25:12.097882
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("Short\nLong\n") == Docstring(
        short_description="Short",
        long_description="Long",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("Short\n\nLong\n") == Docstring(
        short_description="Short",
        long_description="Long",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert parse("Short\n\nLong\n\n") == Docstring(
        short_description="Short",
        long_description="Long",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-11 21:25:20.098007
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "First line.\n\nDescription.\n\nArgs:\n    arg1: description1. Default to default value.\n    arg2: description2. Defaults to default value."
    args_list = ['arg1: description1. Default to default value.', 'arg2: description2. Defaults to default value.']
    docstring_obj = parse(docstring)
    ldesc = docstring_obj.long_description
    args = docstring_obj.meta[0].args
    assert ldesc is not None
    assert ldesc == 'Description.'
    assert args_list == args

# Generated at 2022-06-11 21:25:27.337887
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    A test function.
    """
    ret = parse(text)
    exp = """
    A test function.
    """
    assert ret == exp



# Generated at 2022-06-11 21:25:38.773654
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def f():
        """This function is not very useful but it serves as an example.

        Short description of what this function does.

        Long description of what this function does. And let's make it even
        longer, until it reaches multiple lines.

        Args:
            mandatory (str, list[str], tuple(str)): A mandatory positional
                argument with a somewhat complicated type.
            opt_no_default (int): An optional argument with no default value.
            opt_default (float): An optional argument with a default value.
                Defaults to 42.0.

        Returns:
            Optional[int]: Something useful
        """
        pass

    ret = parse(f.__doc__)
    assert ret.short_description == "This function is not very useful but it serves as an example."