

# Generated at 2022-06-11 21:16:16.870754
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
    assert type(GoogleParser().parse('Some docstring')) == Docstring
   

# Generated at 2022-06-11 21:16:29.962813
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-11 21:16:43.223098
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    from .common import Docstring
    from .google import parse


# Generated at 2022-06-11 21:16:56.062824
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()

    ret = parse(
        """\
        This is a docstring.
        Arguments:
            x: The x coordinate.
        """
    )
    assert ret == Docstring(
        short_description="This is a docstring.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=["param", "x"],
                description="The x coordinate.",
                arg_name="x",
                type_name=None,
                is_optional=None,
                default=None,
            )
        ],
    )


# Generated at 2022-06-11 21:17:04.978761
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = ''' \
        Compute the parity of a value.
        Args:
            x: the value for which to compute the parity
            y: a second value
        Returns:
            the parity of the input
        '''


# Generated at 2022-06-11 21:17:14.470488
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring =  \
    """Compute x and y outputs for a given x value.
        
        **Note**: This is a sample docstring with Google style

        This method is a wrapper for `scipy.interpolate.interp1d` class. If a
        :class:`~scipy.interpolate.interp1d` class is given, then the function
        evaluates the linear spline for the given values.
        If vector of values is given, then the vector items are taken as x
        coordinates and the function returns the corresponding y coordinates.

        Parameters
        ----------
        x : ndarray, shape (n,)
            x-coordinates of the interpolated values.

        Returns
        -------
        y : ndarray, shape (n,)
            Interpolated values, same shape as x.
        """
    expected

# Generated at 2022-06-11 21:17:21.206858
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "This is a test.\n\nArgs:\n    param1: The first parameter.\n    param2: The second parameter. Defaults to None.\n\nReturns:\n    The return type is a string.\n\nRaises:\n    ValueError: If `param2` is equal to `param1`."
    doc = parse(text)
    assert doc.short_description == "This is a test."
    assert doc.long_description == None
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 5
    # Arguments
    assert doc.meta[0].args[0] == 'param'
    assert doc.meta[0].args[1] == 'param1: The first parameter.'
    assert doc

# Generated at 2022-06-11 21:17:33.107105
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "Description\n\n" +\
            "Some long description\n\n" +\
            "Notes\n\n" +\
            "    Note 1.\n" +\
            "    Note 2.\n\n" +\
            "Args:\n" +\
            "    a (str): Param a.\n" +\
            "        Param a description.\n" +\
            "    b (str, optional): Param b. Defaults to None.\n" +\
            "        Param b description.\n\n" +\
            "Returns:\n" +\
            "    str\n" +\
            "        Description of returns.\n"
    res = GoogleParser().parse(text)

    assert res.short_description == "Description"
    assert res.blank_after

# Generated at 2022-06-11 21:17:35.001715
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        """
    assert GoogleParser().parse(text) == Docstring()



# Generated at 2022-06-11 21:17:42.475017
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test for Google-style docstring parsing.
    
    :param type_name: this is the type name
    :type type_name: str
    :param value: this is the value of type_name
    :type value: str
    :param is_optional: if True, type_name is required
    :type is_optional: bool
    :param default: if not provided, type_name is required
    :type default: str
    """

    docstring = GoogleParser().parse(text)
    print(docstring)
    assert docstring.short_description == "This is a test for Google-style docstring parsing."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-11 21:18:15.126195
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc_str = parser.parse(
        """
        Summary line.

        Extended description.

        Args:
            arg1 (int): Description of arg1
            arg2 (str, optional): Description of arg2. Defaults to None.
        """
    )
    assert doc_str.short_description == "Summary line."
    assert doc_str.long_description == "Extended description."
    assert doc_str.meta is not None
    assert len(doc_str.meta) == 2
    assert doc_str.meta[0].arg_name == "arg1"
    assert doc_str.meta[0].type_name == "int"
    assert doc_str.meta[1].arg_name == "arg2"
    assert doc_str.meta[1].type_name == "str"

# Generated at 2022-06-11 21:18:25.101844
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''Calculate the GCD
    \n
    The greatest common divisor is the largest integer that divides
    both x and y without leaving a remainder.
    \n
    Args:
        x: The first number.
        y: The second number.
    \n
    Returns:
        The GCD of x and y

    Examples:
        >>> gcd(12, 4)
        4
        >>> gcd(15, 10)
        5
        >>> gcd(5, 5)
        5
    '''
    print(GoogleParser().parse(text))


# Generated at 2022-06-11 21:18:33.062476
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    s = """Summary line.

    Extended description.

    Args:
      arg1 (int): Description of `arg1`
      arg2 (str): Description of `arg2`.

    Returns:
      bool: Description of return value.

    Raises:
      AttributeError, KeyError
    """
    ds = parse(s)


# Generated at 2022-06-11 21:18:41.893306
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("hello") == Docstring(short_description='hello')
    assert parse("hello\nworld") == Docstring(short_description='hello', long_description='world')
    assert parse("hello\n\nworld") == Docstring(short_description='hello', blank_after_short_description=True, long_description='world')
    assert parse("hello\n\nworld\n\n") == Docstring(short_description='hello', blank_after_short_description=True, blank_after_long_description=True, long_description='world')
    assert parse("Args:\n    hello") == Docstring(short_description=None, meta=[DocstringParam(args=['param', 'hello'], arg_name='hello', description=None, is_optional=None, default=None, type_name=None)])
    assert parse

# Generated at 2022-06-11 21:18:43.120437
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()



# Generated at 2022-06-11 21:18:50.788799
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_str_0 = """This is a summary of the example.

This is a more detailed description of the example.

Args:
    arg1 (str): Description of arg1. Defaults to 'hello'.
    arg2 (int): Description of arg2. Defaults to 123.

Returns:
    (bool): Whether the example was successful.

Raises:
    ValueError: If the example is unsuccessful.
"""
    # TODO: Add test for class Docstring
    # TODO: Add test for class DocstringMeta
    # TODO: Add test for class DocstringParam
    # TODO: Add test for class DocstringRaises
    test_docstring = parse(test_str_0)
    assert test_docstring.short_description == 'This is a summary of the example.'
    assert test_docstring.long_description

# Generated at 2022-06-11 21:18:59.932764
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import dsfoo_google.module2 as module2
    import dsfoo_google.module4 as module4
    method1 = module2.class1.method1
    method2 = module4.class1.method2
    method3 = module4.class1.method3
    method4 = module4.class1.method4
    method5 = module4.class1.method5
    method6 = module4.class1.method6
    method7 = module4.class1.method7
    method8 = module4.class1.method8
    method9 = module4.class1.method9
    method10 = module4.class1.method10
    method11 = module4.class1.method11
    method12 = module4.class1.method12
    method13 = module4.class1.method13
    method

# Generated at 2022-06-11 21:19:01.021376
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:19:12.297374
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:19:23.691509
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    doc = """This is a long description.

This is a long description.

Args:
    a (str): The first parameter.
    b (str): The second parameter.
    c (str): The third parameter.

Example:
    Examples can be given using either the ``Example`` or ``Examples``
    sections. Sections support any reStructuredText formatting, including
    literal blocks::

        $ python example_google.py

Returns:
    str: Description of return value.
"""
    parsed = GoogleParser().parse(doc)
    assert parsed.short_description == "This is a long description."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description is True
    assert parsed.blank_after_long_description is False

# Generated at 2022-06-11 21:19:37.874163
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_str = '''
        MyClass
        =======

        This is a docstring.

        Arguments:
            arg1 (str): Argument 1.

            arg2 (int): Argument 2.

        Example:
            Examples can be given using either the ``Example`` or ``Examples``
            sections. Sections support any reStructuredText formatting,
            including literal blocks::

                $ python example_google.py

        Examples:
            >>> def test():
            ...     str = "Penguin"
            ...     int = 42
            ...     return str, int
            >>> test()
            ('Penguin', 42)
    '''
    p = GoogleParser()
    ret = p.parse(test_str)
    assert ret.short_description == "MyClass"
    assert ret.long_description == "This is a docstring."


# Generated at 2022-06-11 21:19:50.246998
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = 'Single line docstring.'

    docstring_parts = parser.parse(docstring)

    assert isinstance(docstring_parts, Docstring)
    assert docstring_parts.short_description == docstring
    assert docstring_parts.long_description is None
    assert docstring_parts.blank_after_short_description is None
    assert docstring_parts.blank_after_long_description is None
    assert len(docstring_parts.meta) == 0

    docstring = 'Multiline\n    docstring'

    docstring_parts = parser.parse(docstring)

    assert isinstance(docstring_parts, Docstring)
    assert docstring_parts.short_description == 'Multiline'
    assert docstring_parts.long_description == 'docstring'

# Generated at 2022-06-11 21:20:01.345306
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Divide the array elements into four equal parts while maintaining the original order.

    Parameters:
        x:
            Input array to split
        n:
            Number of equal parts to split the input array

    Returns:
        A four-element array containing four equal length sub-arrays
    """


# Generated at 2022-06-11 21:20:12.986656
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert (
        str(
            GoogleParser().parse(
                """Function that returns a string.

        Args:
            times: Number of times to repeat
            word: String to repeatedly return

        Returns:
            A string. Repeats the word argument the number of times specified
                by the times argument.

        Raises:
            ValueError: If times is negative or word is an empty string.
        """
            )
        )
        == """short_description: Function that returns a string.
blank_after_short_description: False
blank_after_long_description: False
long_description: None
meta: [<DocstringParam: param:times>
, <DocstringParam: param:word>
, <DocstringReturns: returns:None>
]"""
    )

# Generated at 2022-06-11 21:20:23.118867
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test_GoogleParser_parse:
    text = '''Parses a Google-style docstring.

:param text: The docstring to parse.
:returns: Parsed docstring.
'''

    ret = GoogleParser().parse(text)
    assert ret.short_description == 'Parses a Google-style docstring.'
    assert len(ret.meta) == 2
    assert str(ret.meta[0]) == ':param text: The docstring to parse.'
    assert str(ret.meta[1]) == ':returns: Parsed docstring.'
    assert ret.long_description == ''

    # test_GoogleParser_parse_blank_lines:

# Generated at 2022-06-11 21:20:33.732774
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from pytator.google_docstring import GoogleParser
    text = '''
        This is a description for this function.

        Attributes:
                attribute1 (object): Description for the attribute.
                attribute2 (string, optional): Description for optional attr.
        '''
    gp = GoogleParser()
    docstring = gp.parse(text)
    assert docstring.short_description == 'This is a description for this function.'
    assert len(docstring.meta) == 2
    assert docstring.meta[1].arg_name == 'attribute2'
    assert docstring.meta[1].is_optional == True


# Generated at 2022-06-11 21:20:42.727126
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:20:55.408388
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    good = """\
    Description.
    
    Description of the method.
    
    Arguments:
        arg1: The first argument.
        arg2: The second argument. Defaults to 2.
         
    Raises:
        TypeError: If arg1 is invalid.
    
    Returns:
        The return value. True for success, False otherwise.
    
    """
    bad = """\
    Description.
    
    Description of the method.
    
    Arguments:
        arg1: The first argument.
        arg2: The second argument. Defaults to 2.
         
    Raises:
        TypeError: If arg1 is invalid.
    
    Returns:
        The return value. True for success, False otherwise.
        """
    assert GoogleParser().parse(good) is not None
    assert GoogleParser().parse

# Generated at 2022-06-11 21:21:06.776687
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """ Given a string in Google-style docstring format, returns a Docstring """

    # Long description, short description and metadata with filler
    long_description = "This is a long description.\n"
    short_description = "This is a short description.\n"
    filler = '\n\n'
    metadata = "Args:\n    arg1: description\n    arg2: description\n\n"
    docstring = short_description + long_description + filler + metadata

    # Test that a GoogleParser instantiated with no arguments
    # returns a Docstring, with the correct short and long
    # descriptions, and metadata

    parser = GoogleParser()
    docstring_result = parser.parse(docstring)

    s_desc = docstring_result.short_description
    l_desc = docstring_result.long_description
    meta

# Generated at 2022-06-11 21:21:14.516547
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()

# Generated at 2022-06-11 21:21:22.836785
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse.__doc__ == parse.__doc__
    googleparser = GoogleParser()
    assert googleparser.parse("This is a test.") == Docstring(
        meta=None,
        short_description="This is a test.",
        long_description=None,
        blank_after_short_description=None,
        blank_after_long_description=None,
    )
    assert googleparser.parse("This is a test.\n\nAnd this is another part.") == Docstring(
        meta=None,
        short_description="This is a test.",
        long_description="And this is another part.",
        blank_after_short_description=True,
        blank_after_long_description=None,
    )

# Generated at 2022-06-11 21:21:35.512302
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("").short_description == None
    assert GoogleParser().parse("hello").short_description == "hello"
    assert GoogleParser().parse("hello\n").short_description == "hello"
    assert GoogleParser().parse("hello\n").long_description == None
    assert GoogleParser().parse("hello\nworld").short_description == "hello"
    assert GoogleParser().parse("hello\nworld").long_description == "world"
    assert GoogleParser().parse("hello\n\nworld").short_description == "hello"
    assert GoogleParser().parse("hello\n\nworld").long_description == "world"
    assert GoogleParser().parse("hello\n\nworld").blank_after_short_description
    assert GoogleParser().parse("hello\n\nworld").blank_after_long_description
    assert GoogleParser

# Generated at 2022-06-11 21:21:44.784467
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test Cases from google style
    example_str = ['Args:',
                   '  a: first argument',
                   '  b: second argument',
                   '  c: third argument',
                   '',
                   'Returns:',
                   '  boolean indicating success or failure',
                   '']
    example_str = '\n'.join(example_str)
    assert 'a' in [p.arg_name for p in parse(example_str).meta if isinstance(p, DocstringParam)], 'Failed Test Case 1: python docstring'
    example_str = ['Returns:',
                   '    bool:',
                   '      Return boolean indicating success or failure.',
                   '']
    example_str = '\n'.join(example_str)

# Generated at 2022-06-11 21:21:53.923096
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """This is a docstring.

    Args:
        a (str): this is a.
        b (str, optional): this is b. Defaults to None.
        c (str):
            this is c.
            it spans two lines.
        d (str):
            this is d.
            it spans two lines.
            third line.
        e (str, optional):
            this is e.
            it spans two lines.
            third line. Defaults to None.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a docstring."
    assert doc.blank_after_short_description == True
    assert doc.long_description == None
    assert doc.blank_after_long_description == False

# Generated at 2022-06-11 21:22:06.236226
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # default section
    assert GoogleParser().parse(
        """
    :param arg: something
    :returns: something
    """
    ) == Docstring(
        short_description=None,
        long_description=None,
        meta=[
            DocstringParam(
                args=["param", "arg"],
                description="something",
                arg_name="arg",
                type_name=None,
                is_optional=None,
                default=None,
            ),
            DocstringReturns(
                args=["returns", "something"],
                description=None,
                type_name="something",
                is_generator=False,
            ),
        ],
    )

# Generated at 2022-06-11 21:22:18.716398
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("Simple one line") == Docstring("Simple one line")
    assert GoogleParser().parse("Simple one line\n\n") == Docstring("Simple one line")
    assert GoogleParser().parse("Simple one line\nWith long description") == Docstring("Simple one line", "With long description")
    assert GoogleParser().parse("Simple one line\n\nWith long description") == Docstring("Simple one line", "With long description")
    assert GoogleParser().parse("Simple one line\n\nWith long description\n") == Docstring("Simple one line", "With long description")
    assert GoogleParser().parse("Simple one line\n\nWith long description\n\n") == Docstring("Simple one line", "With long description")


# Generated at 2022-06-11 21:22:30.464639
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
Test_googleDocstring.

Args:
    arg1: This is the first pos arg.
    arg2: This is the second pos arg.
    arg3: This is the first keyword arg.
    arg4: This is the second keyword arg.

Raises:
    AttributeError, KeyError.
    arg_err: arg1 is greater than arg2.

Returns:
    This is a description of what is returned.
    :returns:  This is what is returned.
    :return:  This is what is returned.

"""
    ds = GoogleParser().parse(doc)

    assert ds.short_description == 'Test_googleDocstring'
    assert ds.long_description == None
    assert ds.blank_after_long_description == True
    assert ds.blank_after_

# Generated at 2022-06-11 21:22:41.802523
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
        Args:
            real (float): Represents the real part. Defaults to 0.
            imag (float or int): Represents the imaginary part. Defaults to 0.
        """
    docstring = GoogleParser().parse(doc)
    assert docstring.short_description == ""
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == None
    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == "Represents the real part."
    assert docstring.meta[0].args == [
        'param',
        'real (float)'
    ]
    assert docstring.meta[0].arg_name == 'real'
    assert docstring.meta[0].type

# Generated at 2022-06-11 21:22:51.239217
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:23:00.306257
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    A simple calculator class.

    Attributes
    ----------
    a : int
        Untyped number.
    b : int or str
        Typed number.
    x : int
        Another number.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "A simple calculator class."
    assert len(doc.meta) == 3
    assert doc.meta[0] == DocstringMeta(args=['attribute', 'a'], description='Untyped number.')
    assert doc.meta[1] == DocstringMeta(args=['attribute', 'b'], description='Typed number.')
    assert doc.meta[2] == DocstringMeta(args=['attribute', 'x'], description='Another number.')

# Generated at 2022-06-11 21:23:15.467494
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    document = """
    Summary line.

    Extended description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        dict: Description of return value
    """

    g = GoogleParser()
    d = g.parse(document)

    print(d.as_rst())


# Generated at 2022-06-11 21:23:26.650994
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:23:34.017284
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        Some short description.

        Some long description.

        Example::

            Something to be shown in doctest way.

        Arguments (type):

            :arg x: the first argument.
        Raises (type):

            :raises ValueError: if x is negative
        Returns (type):

            :returns: the factorial of x.
    """

    result = GoogleParser().parse(text)

    # result
    assert result.short_description == "Some short description."
    assert not result.blank_after_short_description
    assert result.long_description == "Some long description."
    assert result.blank_after_long_description

    assert len(result.meta) == 3
    assert result.meta[0].args == ["example"]

# Generated at 2022-06-11 21:23:42.003456
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""Foo bar.

    Args:
        arg1: Foo. Defaults to bar.
        arg2 (str): Bar.

    Returns:
        the_answer (int): 42.
    """)
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring.short_description, str)
    assert isinstance(docstring.long_description, str)
    assert isinstance(docstring.returns, DocstringReturns)
    assert isinstance(docstring.meta, list)
    for m in docstring.meta:
        assert isinstance(m, DocstringMeta)

# Generated at 2022-06-11 21:23:49.169805
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = '''
    """A docstring."""
    '''
    doc = GoogleParser().parse(docstr)

    assert doc.short_description == "A docstring."
    #assert doc.long_description == None
    #assert doc.meta == []
    #assert doc.blank_after_short_description == False
    #assert doc.blank_after_long_description == False


# Generated at 2022-06-11 21:23:57.294680
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def single_example():
        """
        Short description.

        Long description.

        Args:
            arg_name (int):
                Parameter description. Defaults to 10.

        Returns:
            int: description
        """
        pass


# Generated at 2022-06-11 21:24:04.762213
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("    ") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\\n") == Docstring()
    assert GoogleParser().parse("\t") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("Testing  \nTesting") == Docstring("Testing  \nTesting")
    assert GoogleParser().parse("Testing  \n\nTesting") == Docstring("Testing  \n\nTesting")
    assert GoogleParser().parse("Testing  \n\n\nTesting") == Docstring("Testing  \n\n\nTesting")

# Generated at 2022-06-11 21:24:16.615166
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create object of GoogleParser class
    obj = GoogleParser()
    # Create docstring
    t1 = """
    A short summary of the method. This can be up to
    120 characters long.

    Otherwise, it should just be a short summary,
    as in "Opens the file."

    Args:
      arg1: The first argument.
      arg2: The second argument.

    Returns:
      This is a description of what is returned.
      This can span multiple lines.
    """

# Generated at 2022-06-11 21:24:29.002242
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test method parse of class GoogleParser
    """
    docstring = """
    Test method parse of class GoogleParser
    :rtype: Docstring
    :returns: parsed docstring
    """
    g = GoogleParser()
    ds = g.parse(docstring)
    # print("\n")
    # print(dir(ds))
    # print("\n")
    # print(dir(ds.meta[0]))
    print("\n")
    print("long_description:" + str(ds.long_description))
    print("\n")
    print("short_description:" + str(ds.short_description))
    print("\n")
    print("meta:" + str(ds.meta))
    print("\n")

# Generated at 2022-06-11 21:24:37.689846
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test parse method of class GoogleParser
    # Parameters
    # ----------
    # text : str
    #   Text of docstring
    parser = GoogleParser()
    assert parser is not None
    # Case with empty string
    str0 = '""'
    assert parser.parse(str0) is not None
    assert parser.parse(str0).short_description is None
    assert parser.parse(str0).blank_after_short_description is False
    assert parser.parse(str0).short_description is None
    assert parser.parse(str0).long_description is None
    assert parser.parse(str0).blank_after_long_description is False
    # Case with valid docstring

# Generated at 2022-06-11 21:25:03.831422
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    markdown = "Short description\n\nLong description\n\nArgs:\n  param: Parameter description."
    expected = Docstring()
    expected.short_description = "Short description"
    expected.long_description = "Long description"
    expected.blank_after_short_description = True
    expected.blank_after_long_description = False
    expected.meta.append(DocstringParam(
        args=["parameter", "param"],
        arg_name="param",
        description="Parameter description.",
        type_name=None,
        is_optional=None,
        default=None
    ))
    assert parse(markdown) == expected

# Generated at 2022-06-11 21:25:12.136908
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """ test for method parse of class GoogleParser
    """
    text="""Parses a docstring into its components.

    :parameters:
        text : str
            The docstring to parse.

    :returns: parsed numpydoc.docscrape.Docstring namedtuple.
    """
    doc=GoogleParser().parse(text)
    assert doc.short_description=="Parses a docstring into its components."
    assert doc.long_description==":parameters:\n    text : str\n        The docstring to parse.\n\n:returns: parsed numpydoc.docscrape.Docstring namedtuple."
    assert len(doc.meta)==2
    assert doc.meta[0].description==":parameters:"

# Generated at 2022-06-11 21:25:23.200142
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    ds = parser.parse("""
    Short description
    
    Long description
    
    :param param1: Description for param1
    :type param1:
    :param param2: Description for param2. Defaults to None.
    :type param2: str
    
    :returns: Description for return
    :rtype: None
    """)
    assert isinstance(ds, Docstring)
    assert ds.short_description == "Short description"
    assert ds.long_description == "Long description"
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == True
    assert isinstance(ds.meta[0], DocstringParam)
    assert ds.meta[0].args[0] == "param"

# Generated at 2022-06-11 21:25:32.423884
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from . import __file__ as this_file
    from inspect import cleandoc

    # finds the docstring of the module GoogleParser
    with open(this_file, "r") as source:
        for line in source:
            if (line.startswith("class GoogleParser") or line.startswith(
                    "class _Section")):
                break
        else:
            raise ValueError("Could not find docstring")
        docstring = []
        for line in source:
            if line.startswith("    """):
                docstring.append(line.strip())
                break
        for line in source:
            if line.startswith("    """):
                break
            docstring.append(line.strip())

    docstring = "\n".join(docstring)
    # insert newlines

# Generated at 2022-06-11 21:25:42.045577
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    text = '''Short description.

Long description of method.

Args:
    NN_samples:
        The number of samples to draw.

    NN_samples_1:
        The number of samples to draw.

    NN_samples_2:
        The number of samples to draw. Default to value.

    NN_samples_3:
        The number of samples to draw.

    NN_samples_4:
        The number of samples to draw.

Returns:
    Return: Return.
'''

    g = GoogleParser()
    s = g.parse(text)
    assert s.short_description == "Short description."
    assert s.blank_after_short_description == True
    assert s.long_description == "Long description of method."
    assert s.blank_after_long_