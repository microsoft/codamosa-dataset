

# Generated at 2022-06-11 21:16:17.224700
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()


# Generated at 2022-06-11 21:16:30.300327
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
    Prints a greeting.

    Args:
        greeting (str): The word to use in the greeting.
        punctuation (str, optional): Some punctuation. Defaults to "!".

    """
    parsed = parser.parse(docstring)
    assert parsed.short_description == "Prints a greeting."
    assert parsed.long_description == None
    assert parsed.blank_after_short_description == True
    assert parsed.blank_after_long_description == False
    assert parsed.meta[0].args[0] == "Args"
    assert parsed.meta[0].args[1] == "greeting (str)"
    assert parsed.meta[0].arg_name == "greeting"
    assert parsed.meta[0].type_name == "str"
    assert parsed

# Generated at 2022-06-11 21:16:43.606560
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def f():
        """
        hello world

        :param a: a is an int
        :raises ValueError: if a is not 7
        :returns: 8 if a is 7
        """
        pass

    # noinspection PyProtectedMember
    p = GoogleParser()._parse_body(
        inspect.cleandoc(inspect.getdoc(f))
    )
    assert p.short_description == "hello world"
    assert len(p.meta) == 2
    assert p.meta[0].args == ("param", "a")
    assert p.meta[0].description == "a is an int"
    assert p.meta[0].arg_name == "a"
    assert p.meta[0].type_name is None
    assert p.meta[0].is_optional is None

# Generated at 2022-06-11 21:16:56.153637
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
	assert GoogleParser().parse("""
			
					""") == Docstring()
	assert GoogleParser().parse("""
			"""
					) == Docstring()
	assert GoogleParser().parse("""
					
			""") == Docstring()
	assert GoogleParser().parse("""
					
			""") == GoogleParser().parse("""
					
			""")
	assert not GoogleParser().parse("""
			""").blank_after_short_description
	assert GoogleParser().parse("""
			""").blank_after_long_description
	assert not GoogleParser().parse("""
			""").long_description

# Generated at 2022-06-11 21:17:09.073571
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:17:14.465133
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert (inspect.cleandoc(text) == GoogleParser().parse(text).short_description)
    assert (inspect.cleandoc(text) == GoogleParser().parse(text).long_description)


# Generated at 2022-06-11 21:17:21.207021
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    global Docstring

    class Docstring2:

        def __init__(self):
            
            self.short_description = None
            self.long_description = None
            self.blank_after_short_description = False
            self.blank_after_long_description = False
            self.meta = []

        def __eq__(self, other):

            if self.short_description != other.short_description:
                return False
            if self.long_description != other.long_description:
                return False
            if self.blank_after_short_description != other.blank_after_short_description:
                return False
            if self.blank_after_long_description != other.blank_after_long_description:
                return False
            if self.meta != other.meta:
                return False
            return True


# Generated at 2022-06-11 21:17:33.108736
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test parsing Google-styled docstrings
    """
    import sys
    if sys.version_info < (3, 6):
      return
    from unittest import TestCase, main
    from .test_common import collect_examples

    examples = collect_examples("google")


# Generated at 2022-06-11 21:17:41.182111
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc_str = """    A doc string.

    This is a long description.


    Returns:
        Returns a string.
    """
    parsed = parser.parse(doc_str)
    assert parsed.short_description == "A doc string."
    assert parsed.long_description == "This is a long description."
    assert parsed.blank_after_short_description
    assert parsed.blank_after_long_description
    assert len(parsed.meta) == 1
    returns = parsed.meta[0]
    assert isinstance(returns, DocstringReturns)
    assert returns.description == "Returns a string."


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-11 21:17:53.267910
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ans = parse("""
    short description

    long description

    Args:
        x (int): x
        y (int): y

    Returns:
        Tuple[int, int]: Two numbers.
    """)
    assert ans.short_description == 'short description'
    assert ans.long_description == 'long description'
    assert ans.blank_after_short_description == True
    assert ans.blank_after_long_description == False
    assert len(ans.meta)==2
    assert ans.meta[0].args[0]=='param'
    assert ans.meta[0].args[1]=='x (int)'
    assert ans.meta[0].description=='x'
    assert ans.meta[0].arg_name=='x'

# Generated at 2022-06-11 21:18:12.261697
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('\n') == Docstring()
    assert GoogleParser().parse('\n\n') == Docstring()
    assert GoogleParser().parse('\n\n\n') == Docstring()
    #
    s = 'short description'
    assert GoogleParser().parse(s) == Docstring(short_description=s, long_description=None)
    s = 'short description\n'
    assert GoogleParser().parse(s) == Docstring(short_description=s.strip(), long_description=None)
    s = 'short description\n\n'
    assert GoogleParser().parse(s) == Docstring(short_description=s.strip(), long_description=None)
    s = 'short description\n\n\n'

# Generated at 2022-06-11 21:18:17.864199
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Calculate the sum of two numbers.

Args:
    x: The first number.
    y: The second number.

Returns:
    The sum of x and y.
"""

    print(GoogleParser().parse(text))

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:18:29.012839
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse('''
    This is a module docstring.
    
    Args:
        arg1: The first argument.
        arg2: The first argument.
    
    Kwargs:
        kwarg1: The first keyword argument.
        kwarg2 (int): The second keyword argument.
        
    Attributes:
        attr1: The first attribute.
        attr2 (:obj:`int`): The second attribute.
    
    Returns:
        The return value. True for success, False otherwise.
    
    Raises:
        Exception1: The first exception type for which this function throws.
        Exception2: The second exception type for which this function throws.
    
    Useless:
        What? This section is not useful!
    ''')

# Generated at 2022-06-11 21:18:39.182882
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "Function to test Google parser.\n\n    This function will return 5 and do nothing else.\n    \n    Args\n    ----\n    arg1 (int): First arg.\n    arg2 (int): Second arg.\n    arg3 (int): Third arg.\n    \n    Returns\n    -------\n    float: float of arguments.\n    \n    Raises\n    ------\n    Exception\n        blah blah blah\n    AttributeError\n        blah blah blah\n    \n    Examples\n    --------\n    >>> test_GoogleParser_parse()\n    5\n    "
    ret = GoogleParser().parse(text)

    assert ret.short_description == "Function to test Google parser."

# Generated at 2022-06-11 21:18:41.266021
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert 1 == 1


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:18:49.264160
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:18:49.914642
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass

# Generated at 2022-06-11 21:18:57.488134
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    GoogleParser().parse("""\
A one-line summary that does not use variable names or the
function name.

Several sentences providing an extended description. Refer to
variables like `var_name` and :any:`Module.class_name`.

Parameters
----------
var_name : array_like
    Description of `var_name`.
long_var_name : {'C', 'F'}, optional
    Description of `long_var_name`, defaults to 'C'.
Examples
--------
These are written in doctest format, and should illustrate how to
use the function.
>>> a=2
>>> print(a)
2
""")

# Generated at 2022-06-11 21:19:06.466235
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Valid docstring
    text = """\
        Long description.

        Args:
            arg1: First line.
                Second line.
                Third line.
                Default to 1.
            arg2: Desc. Defaults to 2.
            arg3 (str): Desc.
            arg4:
                1. First element.
                2. Second element.
            arg5:
                * 1. First element.
                * 2. Second element.

        Attributes:
            attr1: Desc.

        Returns:
            Desc

        Yields:
            Desc
        """

    print(GoogleParser().parse(text))


# Generated at 2022-06-11 21:19:15.189328
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert(GoogleParser().parse("Test").short_description == "Test")
    assert(GoogleParser().parse("Test\nTest\n").short_description == "Test")
    assert(GoogleParser().parse("Test\nTest\n").long_description == "Test")
    assert(GoogleParser().parse("Test\n\nTest\n").long_description == "Test")
    assert(GoogleParser().parse("Test\nTest\n").blank_after_long_description == True)
    assert(GoogleParser().parse("Test\nTest\n").blank_after_short_description == True)
    assert(GoogleParser().parse("Test\nTest").blank_after_short_description == False)
    assert(GoogleParser().parse("Test").meta == None)



# Generated at 2022-06-11 21:19:32.738774
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert type(GoogleParser().parse("""
        Short summary.
    
        Long description.
    
        Args:
            arg1: Description of :attr:`arg1`.
            arg2 (str): Description of arg2.
        Kwargs:
            kwarg1: Description of :attr:`kwarg1`.
            kwarg2 (str): Description of kwargs2.
    
        Attributes:
            attribute1: Description of :attr:`attribute1`.
            attribute2 (str): Description of attribute2.
    
        Returns:
            Description of return value.
        
        Example:
            Examples should be written in doctest format, and should illustrate how
            to use the function.
    
            >>> a = [1, 2, 3]
        """)) is Docstring


# Generated at 2022-06-11 21:19:39.920784
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Tests for functionality of the GoogleParser parse method.
    """

    assert GoogleParser().parse(text) == Docstring(short_description='Tests for functionality of the GoogleParser parse method.',
                                                   long_description=None,
                                                   meta=[],
                                                   blank_after_short_description=True,
                                                   blank_after_long_description=False)

    # Test with simple default section
    text = """
    Tests for functionality of the GoogleParser parse method.

    Some longer description of what it does.

    Examples:
        Simple example
    """


# Generated at 2022-06-11 21:19:51.797772
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gP = GoogleParser()
    assert gP.parse("") == Docstring()
    assert gP.parse("\n") == Docstring()
    assert gP.parse("  \n   \n\n") == Docstring()
    assert gP.parse("Hello world!") == Docstring(
        short_description="Hello world!", blank_after_short_description=False, blank_after_long_description=True
    )
    assert gP.parse("Hello world! :sup:") == Docstring(
        short_description="Hello world! :sup:", blank_after_short_description=False, blank_after_long_description=True
    )

# Generated at 2022-06-11 21:19:53.661308
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """test_GoogleParser.py is the testing file"""
    assert(True)


# Generated at 2022-06-11 21:20:03.443165
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    doc-string for test
    Args:
        arg1: the first argument
        arg2: the second argument

    Returns:
        the doc-string return value
        '''
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == 'doc-string for test'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'the first argument'
    assert docstring.meta[0].arg_name == 'arg1'

# Generated at 2022-06-11 21:20:11.771130
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = parse(__doc__)
    print(docstr.short_description)
    print(docstr.long_description)
    for meta in docstr.meta:
        print(meta)
        if isinstance(meta, DocstringReturns):
            print(meta.is_generator)
        if isinstance(meta, DocstringParam):
            print(meta.arg_name, meta.type_name, meta.is_optional, meta.default)

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:20:21.856380
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_string = """This is a test for function parse of GoogleParser.

Arguments:
    text (str): the string to be parsed.
    start (int, optional): the start index of the string.
    end (int, optional): the end index of the string.

Returns:
    Docstring: parsed docstring

Raises:
    ParseError: if there are some errors during parsing.

Example:
    >>> text = "parse me, please!"
    >>> obj = GoogleParser()
    >>> ds = obj.parse(text)
    >>> ds.short_description
    'parse me, please!'
"""
    ds = parse(test_string)
    print(ds)


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-11 21:20:34.130658
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """This function does nothing.

Args:
    arg1: The first argument.
    arg2 (int): The second argument.

Keyword Args:
    karg1: The first keyword-only argument.
    karg2: The second keyword-only argument.

Raises:
    ValueError: if arg2 < 0.

Returns:
    None

"""
    got = parser.parse(text)

# Generated at 2022-06-11 21:20:38.415983
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = \
    """
    Returns and yields
    This function does a lot.

    Example:
        Here's an example.

    Returns:
        An int.
    """
    result = GoogleParser().parse(docstring)
    print(result)
    assert False

# Generated at 2022-06-11 21:20:49.500325
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:21:00.649117
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def docstring():
        """Google-style docstring.

        This function does something.

        Args:
            param1 (int): The first parameter.
            param2 (str): The second parameter. Defaults to 'water'.

        Returns:
            bool: The return value. True for success, False otherwise.

        Raises:
            AttributeError: The ``Raises`` section is a list of all exceptions
                that are relevant to the interface.
            ValueError: If `param2` is equal to `param1`.

        """
        pass

# Generated at 2022-06-11 21:21:10.825978
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .parse_common import assert_equal

    docstring = """
        Args:
            username (str): Username for login
            password (str, optional): Password for login. Defaults to "default"

        Returns:
            bool: True if successful, False otherwise
        """


# Generated at 2022-06-11 21:21:22.161667
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest
    from textwrap import dedent

    def check(text, expected):
        google_parser = GoogleParser()

        actual_docstring = google_parser.parse(text)
        actual = actual_docstring.__dict__
        assert actual == expected

    # Test for docstring without title
    test_docstring = dedent(
        '''
        This is a docstring without title.
        '''
    )
    test_expected = {
        'short_description': 'This is a docstring without title.',
        'blank_after_short_description': True,
        'blank_after_long_description': True,
        'long_description': None,
        'meta': []
    }
    check(test_docstring, test_expected)
    
    
    # Test for docstring with return
   

# Generated at 2022-06-11 21:21:34.947330
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # 1. Standard case
    docstring = GoogleParser().parse("""Title:
        Short desc.
        
        Long desc.

        Params:
            x: first param.
            y: second param.
        """)
    assert 'Title' in [m.args[0] for m in docstring.meta]
    assert len(docstring.meta) == 1
    assert docstring.short_description == "Short desc."
    assert docstring.long_description == "Long desc."

    # 2. Only short description
    docstring = GoogleParser().parse("""Title:

        Short desc.

        Params:
            x: first param.
            y: second param.
        """)
    assert 'Title' in [m.args[0] for m in docstring.meta]
    assert len(docstring.meta) == 1

# Generated at 2022-06-11 21:21:44.987031
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:21:48.878578
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        :param text: docstring element text
        :param title: title of section containing element
        :return:
        """
    assert GoogleParser().parse(text) is not None

# Generated at 2022-06-11 21:22:00.005936
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    res = parser.parse('This is a method')
    assert res.short_description == 'This is a method'
    assert res.long_description == None
    assert res.meta == []
    assert res.blank_after_long_description == False
    assert res.blank_after_short_description == False

    res = parser.parse('This is a method.\n\nAnd this is more description.')
    assert res.short_description == 'This is a method.'
    assert res.long_description == 'And this is more description.'
    assert res.meta == []
    assert res.blank_after_long_description == False
    assert res.blank_after_short_description == True

    res = parser.parse('This is a method.\n\nAnd this is more description.\n\n')

# Generated at 2022-06-11 21:22:09.872539
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Tests for short description
    docstring = GoogleParser().parse("First sentence.")
    assert docstring.short_description == "First sentence."
    assert docstring.long_description is None
    assert len(docstring.meta) == 0
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    # Long description
    docstring = GoogleParser().parse(
        "First sentence.\n\nSecond paragraph.\n\nThird paragraph."
    )
    assert docstring.short_description == "First sentence."
    assert docstring.long_description == "Second paragraph.\n\nThird paragraph."
    assert len(docstring.meta) == 0
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    # Multi

# Generated at 2022-06-11 21:22:21.289886
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """ Test of method parse of class GoogleParser """

    parser = GoogleParser()


# Generated at 2022-06-11 21:22:31.641588
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
        This is the short description.

        This is the long description.
        The long description is indented.
    """)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description.\nThe long description is indented."
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

    docstring = parser.parse("""
        This is the short description.

        This is the long description.
        The long description is indented.


    """)
    assert docstring.short_description == "This is the short description."

# Generated at 2022-06-11 21:22:50.774319
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def method_with_docstring(a, b):
        """
        this is short description

        this is long description
        which is wrapped to two lines.

        Args:
            a: this is a
            b: this is b

        Returns:
            int: the sum of a, b
        """
        return a + b

    def method_with_multiple_returns(a, b):
        """
        this is short description

        this is long description
        which is wrapped to two lines.

        Args:
            a: this is a
            b: this is b

        Returns:
            (int, int): tuple of a, b and sum of a, b
        """
        return a, b, a + b

    def method_with_no_docstring(a, b):
        return a + b


# Generated at 2022-06-11 21:23:00.054711
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-11 21:23:10.543490
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''Summarize the function.
    :param arg1: The first argument.
    :param arg2: The second argument.
    :returns: The return value.
    :raises Exception: Because it can.
    '''
    parser = GoogleParser()
    parsed_docstring = parser.parse(text)
    assert parsed_docstring.short_description == 'Summarize the function.'
    assert parsed_docstring.long_description == None
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False
    assert parsed_docstring.meta[0].args == ['param', 'arg1']
    assert parsed_docstring.meta[1].args == ['param', 'arg2']
    assert parsed_docstring.meta[2].args

# Generated at 2022-06-11 21:23:20.134785
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text='''A function with docstring.

    Parameters
    ----------
    p1 : int
        description of p1.
    p2 : str
        description of p2.

    Returns
    -------
    str
        description of return.

    Raises
    ------
    RuntimeError
        always.
    '''
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == 'A function with docstring.'
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 3
    assert len(docstring.meta[0].args) == 2
    assert len(docstring.meta[1].args) == 2

# Generated at 2022-06-11 21:23:31.369100
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is the short description.

    This is the long description.  It can have multiple lines.

    Args:

      arg1: Description of arg1.
      
      arg2: Description of arg2.

    Returns:
      A description of returns.

    Raises:
      Exception: Description of the exception.  Can have multiple
          lines.

    """
    d = GoogleParser().parse(text)
    assert d.long_description == """
    This is the long description.  It can have multiple lines.""".strip()

    assert d.short_description == "This is the short description."

    assert d.meta[0].args[0] == "param"
    assert d.meta[0].args[1] == "arg1"
    assert d.meta[0].description == "Description of arg1."

   

# Generated at 2022-06-11 21:23:43.204080
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest
    text = """\
    The shortest summary.

    The first paragraph in an extensive summary: some text which
    explains everything.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Example:
        Examples can be given using either the ``Example`` or ``Examples``
        sections. Sections support any reStructuredText formatting, including
        literal blocks::

            #>>> print 'hello'
            hello

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function/class.

        >>> print foobar(2000)
        1001
    """
    result = GoogleParser().parse(text)
    assert result.short_description == "The shortest summary."

# Generated at 2022-06-11 21:23:53.674663
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''Test
    test2
    test3
'''
    result = GoogleParser().parse(docstring)
    assert result.short_description == 'Test'
    assert result.blank_after_short_description == True
    assert result.long_description == 'test2\ntest3'
    assert result.blank_after_long_description == False

docstring = '''This function does something.

    Arguments:
        arg1 (str): First argument.
        arg2 (str): Second argument.
            Also has indented description
'''
result = GoogleParser().parse(docstring)
assert result.short_description == 'This function does something.'
assert result.long_description == '\n'
assert result.blank_after_short_description == False
assert result.blank_after_long_description == False

# Generated at 2022-06-11 21:24:03.127488
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    A sample docstring.
    Here's the long description.

    Args:

      arg1(str): A string argument.
      arg2(str, optional): A default argument.

    Returns:

      (str): A string example.

    Raises:

      ValueError: An exception.
    """
    doc = parse(text)
    assert doc.short_description == "A sample docstring."
    assert doc.long_description == "Here's the long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert doc.meta[0].args == ["returns", "str"]
    assert doc.meta[0].description == "A string example."
    assert doc.meta[0].arg_name == "str"

# Generated at 2022-06-11 21:24:15.814704
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    This is the unit test for method GoogleParser.parse
    """
    docstring_0 = "This is a short description.\n\nThis is a long description.\nIt spans several lines."

# Generated at 2022-06-11 21:24:23.122845
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "Say Hello, world."

    docstring_with_section = """Say Hello, world.
    
    Args:
        name: name of the person
    """

    docstring_with_sections = """Say Hello, world.
    
    Args:
        name: name of the person
    Return:
        The greeting string
    """

    docstring_with_joined_sections = """Say Hello, world.
    
    Args:
        name: name of the person
    Return:
        The greeting string with reformated docstring
    Yields:
        Whatever
    """

    docstring_with_multiple_args = """Say Hello, world.
    
    Args:
        name: name of the person
        others: other people
    Return:
        The greeting string
    """

    docstring_with

# Generated at 2022-06-11 21:24:38.455333
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Define class for doctests.
    class Example:
        """This is an example.
        """
        pass

    a = GoogleParser()
    assert a.parse(Example.__doc__) == Docstring(
        meta=[
            DocstringMeta(
                args=["example"], description="This is an example.",
            ),
        ],
        short_description="This is an example.",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
    )

    # def __init__(self, data, size: int, *, block: int = 0, offset: int = 0):
    b = GoogleParser()

# Generated at 2022-06-11 21:24:48.466169
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test_func():        
        doc = """
        Args:
        y_pred (torch.Tensor): Predicted target value.
        y_true (torch.Tensor): True target value.

        Returns:
        torch.Tensor: Mean of squared errors.
        """
        #doc = """
        #Args:
        #    |  y_pred (torch.Tensor): Predicted target value.
        #    |  y_true (torch.Tensor): True target value.
        #
        #Returns:
        #    |  torch.Tensor: Mean of squared errors.
        #"""
        return GoogleParser().parse(doc)
    Name = "test_GoogleParser_parse"
    func = test_func

# Generated at 2022-06-11 21:24:57.102410
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print(GoogleParser().parse(
        """This is a test docstring.

        Args:
            arg1: Something
                more.

            arg2 (str): Something else.

            arg3 (str, optional): Something more.
                Default: "else".
                Also more.

            arg4 (str?): Optional flags.

            arg5 (str): Required flags.

        Raises:
            AttributeError: If something fails.

        Returns:
            str: Result of the work.

        Yields:
            int: 2.

            float: 3.14

            str: "Hello"
        """
    ))


# Generated at 2022-06-11 21:25:07.368628
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstring = google_parser.parse("""\
        This is the short description.
        This is the long description.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.
        Returns:
            str: The return value.
        Raises:
            AttributeError: The ``AttributeError`` exception.
        Examples:
            Examples should be written in doctest format, and should illustrate how
            to use the function.
    """)
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description is True

# Generated at 2022-06-11 21:25:14.066243
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import os.path
    tests_dir = os.path.dirname(os.path.abspath(__file__))
    filepath = os.path.join(tests_dir, "test_GoogleParser_parse.txt")
    with open(filepath, "r", encoding="utf8") as f:
        text = f.read()
    ret = GoogleParser().parse(text)
    # print(ret.short_description)
    # print(ret.blank_after_short_description)
    # print(ret.long_description)
    # print(ret.blank_after_long_description)
    # for meta in ret.meta:
    #     print(meta.args)
    #     print(meta.description)
    assert ret.short_description == "This is short description."
    assert ret.blank_after_

# Generated at 2022-06-11 21:25:25.143400
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("Hello world!\n") == Docstring(
        short_description="Hello world!",
        blank_after_short_description=True,
        blank_after_long_description=None,
        long_description=None,
        meta=[],
    )
    assert parse("Hello world!\n\nMore stuff\n") == Docstring(
        short_description="Hello world!",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="More stuff",
        meta=[],
    )

# Generated at 2022-06-11 21:25:32.284707
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test encoding to JSON
    google_parser = GoogleParser()

# Generated at 2022-06-11 21:25:39.149042
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    desc = "Parse the Google-style docstring into its components."
    p = GoogleParser()
    text = """
        Parse the Google-style docstring into its components.

        :returns: parsed docstring
        """
    result = p.parse(text)
    expected = Docstring()
    expected.short_description = desc
    expected.long_description = desc
    expected.blank_after_short_description = True
    expected.blank_after_long_description = True
    assert result == expected