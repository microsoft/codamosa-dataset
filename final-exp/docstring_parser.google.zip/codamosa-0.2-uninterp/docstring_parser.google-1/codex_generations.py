

# Generated at 2022-06-17 18:06:42.397157
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:06:54.136313
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert GoogleParser().parse("Short description.") == Docstring(
        short_description="Short description."
    )

    # Test for docstring with only long description
    assert GoogleParser().parse("\nLong description.") == Docstring(
        long_description="Long description."
    )

    # Test for docstring with short and long description
    assert GoogleParser().parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        long_description="Long description.",
    )

    # Test for docstring with short and long description and blank line

# Generated at 2022-06-17 18:07:04.055197
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (bool): The third argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `foo`.
    """
    parser = GoogleParser()
    result = parser.parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 4

# Generated at 2022-06-17 18:07:15.644741
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.
    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    parsed_docstring = GoogleParser().parse(docstring)
    assert parsed_docstring.short_description == "This is a test docstring."
    assert parsed_docstring.long_description == "This is the long description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == True
    assert parsed_docstring.meta[0].args[0] == "param"

# Generated at 2022-06-17 18:07:27.716206
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:07:33.655064
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
   

# Generated at 2022-06-17 18:07:44.948305
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:07:54.183804
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first argument is invalid.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']

# Generated at 2022-06-17 18:08:04.556884
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test for GoogleParser.parse.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.

    Returns:
        This is a return.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test for GoogleParser.parse."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "This is arg1."
    assert docstring.meta

# Generated at 2022-06-17 18:08:12.358950
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value.
    '''
    docstring_parsed = GoogleParser().parse(docstring)
    assert docstring_parsed.short_description == 'This is a short description.'
    assert docstring_parsed.long_description == 'This is a long description.'
    assert docstring_parsed.meta[0].args == ['param', 'arg1']
    assert docstring_parsed.meta[0].description == 'The first argument.'
    assert docstring_parsed.meta[1].args == ['param', 'arg2']

# Generated at 2022-06-17 18:08:39.765835
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a docstring.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].type_name == None
    assert doc

# Generated at 2022-06-17 18:08:53.824877
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1 (int)']
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:09:05.504448
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:09:13.073677
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "This is a short description.\n\nThis is a long description.\n\nArgs:\n  arg1 (str): Description of arg1.\n  arg2 (int): Description of arg2.\n\nReturns:\n  str: Description of return value.\n\nRaises:\n  ValueError: Description of raised exception."
    docstring_obj = GoogleParser().parse(docstring)
    assert docstring_obj.short_description == "This is a short description."
    assert docstring_obj.long_description == "This is a long description."
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == True
    assert docstring_obj.meta[0].args == ['param', 'arg1 (str)']
    assert doc

# Generated at 2022-06-17 18:09:24.939721
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
        Short description.

        Long description.

        Args:
            arg1: The first argument.
            arg2: The second argument.
        Returns:
            The return value.
        Raises:
            KeyError: Raises an exception.
        """)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:09:33.299298
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case of test case
    # Input data for unit test
    text = '''
    This is a test docstring.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    '''
    # Expected output of unit test

# Generated at 2022-06-17 18:09:40.666928
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test docstring.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.

    Returns:
        This is a return.
    """
    result = GoogleParser().parse(text)
    assert result.short_description == "This is a test docstring."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert result.meta[0].args == ["param", "arg1"]
    assert result.meta[0].description == "This is arg1."
    assert result.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:09:53.347999
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:10:03.462952
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "This is a short description."
    assert ret.long_description == "This is a long description."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ["param", "arg1"]
    assert ret.meta[0].description == "The first argument."
    assert ret.meta[1].args == ["returns"]

# Generated at 2022-06-17 18:10:16.799435
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:10:30.061075
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
        arg3 (str): The third argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `baz`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:10:37.780690
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.
        arg3 (str): This is arg3.
        arg4 (str): This is arg4.

    Returns:
        str: This is a return value.

    Raises:
        ValueError: This is raised if something bad happens.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 4

# Generated at 2022-06-17 18:10:47.375277
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta

# Generated at 2022-06-17 18:10:57.727745
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[1].args == ['param', 'arg2']

# Generated at 2022-06-17 18:11:09.413857
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]
    assert docstring

# Generated at 2022-06-17 18:11:21.288147
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is a return value.

    Raises:
        ValueError: This is a ValueError.
    """
    docstring_parsed = GoogleParser().parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == True

# Generated at 2022-06-17 18:11:32.814659
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a docstring.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring_obj = GoogleParser().parse(docstring)
    assert docstring_obj.short_description == "This is a docstring."
    assert docstring_obj.long_description == "The return value. True for success, False otherwise."
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == False
    assert docstring_obj.meta[0].args == ["param", "arg1"]
    assert docstring_obj.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:11:39.235355
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[1].args == ['param', 'arg2']
    assert doc.meta[1].description

# Generated at 2022-06-17 18:11:47.793772
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: If something goes wrong.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:12:00.249326
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.
        arg3 (str): This is arg3.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `arg2` is equal to `arg3`.

    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args

# Generated at 2022-06-17 18:12:12.927034
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): Description of arg1.
        arg2 (str): Description of arg2.

    Returns:
        int: Description of return value.

    Raises:
        ValueError: If something bad happens.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (int)"]

# Generated at 2022-06-17 18:12:21.422184
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test function.

    This is the long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (str): The third argument.
        arg4 (str): The fourth argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `foo`.
    """
    result = GoogleParser().parse(docstring)
    assert result.short_description == "This is a test function."
    assert result.long_description == "This is the long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert result.meta[0].args == ['param', 'arg1 (int)']


# Generated at 2022-06-17 18:12:31.635716
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a test."
    assert doc.long_description is None
    assert doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1 (int)"]
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "int"
    assert doc.meta[0].is_optional is False
   

# Generated at 2022-06-17 18:12:37.191148
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring_obj = GoogleParser().parse(docstring)
    assert docstring_obj.short_description == "This is a short description."
    assert docstring_obj.long_description == "This is a long description."
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == True
    assert docstring_obj.meta[0].args == ['param', 'arg1: The first argument.']
    assert docstring_obj.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:12:44.293648
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (bool): The third argument.

    Returns:
        int: The return value.

    Raises:
        ValueError: If `bar` is equal to `baz`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == "The return value."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (int)"]
    assert docstring

# Generated at 2022-06-17 18:12:52.662827
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert GoogleParser().parse("Short description.") == Docstring(
        short_description="Short description."
    )

    # Test for docstring with short and long description
    assert GoogleParser().parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
    )

    # Test for docstring with short, long and meta description

# Generated at 2022-06-17 18:12:58.858589
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.

    Returns:
        bool: This is a return.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "This is arg1."
    assert docstring.meta[0].arg_name == "arg1"
   

# Generated at 2022-06-17 18:13:04.285739
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:13:12.872731
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a test function."
    assert doc.long_description == "The first argument.\nThe second argument."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1 (int)']
    assert doc.meta[0].description == 'The first argument.'
    assert doc.meta[0].arg_name == 'arg1'

# Generated at 2022-06-17 18:13:20.704478
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case 1:
    # Input:
    # text = ""
    # Expected output:
    # Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    # Actual output:
    # Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    text = ""
    assert GoogleParser().parse(text) == Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])

    # Test for method parse of class GoogleParser
    # Failure case 2:
    # Input

# Generated at 2022-06-17 18:13:33.577822
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        This is a short description.

        This is a long description.

        Args:
            arg1: The first argument.
            arg2: The second argument.

        Returns:
            The return value. True for success, False otherwise.
        """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:13:44.076948
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (bool, optional): The third argument. Defaults to True.

    Returns:
        str: The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1 (int)']
    assert doc.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:13:54.821190
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.
        arg3 (str): Description of arg3. Defaults to "foo".

    Returns:
        str: Description of return value.
    """

    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:14:04.786885
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:14:15.166039
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `bar` is equal to `baz`.

    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
   

# Generated at 2022-06-17 18:14:26.006353
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (str): The third argument.
    """

# Generated at 2022-06-17 18:14:36.335272
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
        arg3 (str): The third argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:14:45.135105
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
    Returns:
        This is a return value.
    """
    docstring = parser.parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:14:55.957052
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
   

# Generated at 2022-06-17 18:15:04.585602
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:15:20.078443
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == "The ``Raises`` section is a list of all exceptions\nthat are relevant to the interface.\nIf `param2` is equal to `param1`."
    assert docstring.blank_after_short_description

# Generated at 2022-06-17 18:15:32.250113
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:15:38.673809
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a function.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:15:45.817080
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first argument is invalid.
        TypeError: The second argument is invalid.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']

# Generated at 2022-06-17 18:15:54.283814
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:16:00.805474
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1 (str)"]
    assert doc.meta[0].arg_

# Generated at 2022-06-17 18:16:08.412786
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Setup
    text = """
    This is a function.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value.
    """
    # Exercise
    ret = GoogleParser().parse(text)
    # Verify
    assert ret.short_description == "This is a function."
    assert ret.long_description == "This is the long description."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ["param", "arg1"]
    assert ret.meta[0].description == "The first argument."
    assert ret.meta

# Generated at 2022-06-17 18:16:15.019387
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = '''
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
    '''