

# Generated at 2022-06-17 18:06:53.349733
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args[0] == "param"

# Generated at 2022-06-17 18:07:03.870009
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:07:10.014042
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        a: This is a.
        b: This is b.

    Returns:
        This is a return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'a']
    assert docstring.meta[0].description == 'This is a.'
    assert docstring.meta[1].args == ['returns', 'This is a return value.']

# Generated at 2022-06-17 18:07:18.416567
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (list): The third argument.

    Returns:
        str: The return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc

# Generated at 2022-06-17 18:07:30.514309
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:07:41.606046
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "Parse the Google-style docstring into its components."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['returns']
    assert docstring.meta[0].description == 'parsed docstring'
    assert docstring.meta[0].arg_name == None
    assert docstring.meta[0].type_name == None
    assert docstring.meta[0].is_optional == None
    assert docstring.meta[0].default == None

# Generated at 2022-06-17 18:07:54.608474
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:08:04.884413
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1: The first argument."]
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:08:12.187754
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta

# Generated at 2022-06-17 18:08:23.601215
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """

# Generated at 2022-06-17 18:08:39.670451
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Setup
    text = """
    This is the short description.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value.
    """

# Generated at 2022-06-17 18:08:53.820924
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case of test case
    # Input data for unit test
    text = """
    This is a test docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.
    """
    # Perform the test
    result = GoogleParser().parse(text)
    # Verify the result
    assert result.short_description == "This is a test docstring."
    assert result.long_description == None
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0].args == ['param', 'arg1 (str)']
    assert result.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:09:00.254151
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].description

# Generated at 2022-06-17 18:09:10.987338
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
    """

# Generated at 2022-06-17 18:09:23.213104
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """

# Generated at 2022-06-17 18:09:32.135491
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:09:41.758312
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.
        arg3 (bool): Description of arg3. Defaults to False.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: Description of exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:09:53.479899
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:10:03.571467
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:10:16.799733
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:10:29.911611
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test with simple docstring
    docstring = GoogleParser().parse("""
    Short description.

    Long description.
    """)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert not docstring.meta

    # Test with docstring with no short description
    docstring = GoogleParser().parse("""
    Long description.
    """)
    assert docstring.short_description is None
    assert docstring.long_description == "Long description."
    assert not docstring.blank_after_short_description
    assert docstring.blank_after_long_description


# Generated at 2022-06-17 18:10:37.587197
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `foo`.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']

# Generated at 2022-06-17 18:10:47.211747
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `foo`.
    """

# Generated at 2022-06-17 18:10:57.671111
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `bar` is equal to `baz`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:11:09.415671
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (str): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: Description of exception.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ["param", "arg1 (str)"]
    assert doc.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:11:21.287703
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): Description of arg1.
        arg2 (str): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1 (int)"]
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:11:32.814635
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[0].arg_name == "arg1"


# Generated at 2022-06-17 18:11:37.920335
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case 1
    # Input
    text = "This is a test docstring"
    # Expected output
    expected_output = Docstring(
        short_description="This is a test docstring",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    # Actual output
    actual_output = GoogleParser().parse(text)
    # Unit test
    assert actual_output == expected_output
    # Success case 1
    # Input
    text = "This is a test docstring\n\nThis is a long description"
    # Expected output

# Generated at 2022-06-17 18:11:47.073154
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:11:54.777113
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
        This is a short description.

        This is a long description.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.
        """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (int)"]
    assert docstring.meta[0].description == "The first argument."
   

# Generated at 2022-06-17 18:12:09.118060
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:12:19.960634
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
        arg3: This is arg3.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    """

# Generated at 2022-06-17 18:12:31.537459
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str, optional): This is arg2. Defaults to None.
        arg3 (str): This is arg3.

    Returns:
        str: This is return.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:12:37.075363
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']

# Generated at 2022-06-17 18:12:44.231795
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is the first argument.
        arg2 (int): This is the second argument.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.

    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:12:55.886351
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("Hello") == Docstring(
        short_description="Hello",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert GoogleParser().parse("Hello\nWorld") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="World",
        meta=[],
    )

# Generated at 2022-06-17 18:13:02.378646
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:13:11.636867
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:13:17.406610
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first argument is invalid.
        TypeError: The second argument is invalid.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:13:28.861185
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:13:42.716357
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        bool: Description of return value.

    Raises:
        ValueError: Description of exception.
    """
    docstring_parsed = parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == True

# Generated at 2022-06-17 18:13:54.207836
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert GoogleParser().parse("Short description.") == Docstring(
        short_description="Short description."
    )

    # Test for docstring with short and long description
    assert GoogleParser().parse(
        "Short description.\n\nLong description."
    ) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Test for docstring with short and long description and blank line

# Generated at 2022-06-17 18:14:00.686239
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:14:11.626747
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        int: This is a return value.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1 (int)"]
    assert doc.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:14:16.295531
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
        arg4: The fourth argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 2

# Generated at 2022-06-17 18:14:27.090856
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (list): The third argument.

    Returns:
        str: The return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-17 18:14:36.928000
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:14:45.741974
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.

    Returns:
        str: This is the return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "This is arg1."
    assert docstring

# Generated at 2022-06-17 18:14:56.164451
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    This is a long description.
    It can span multiple lines.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
        arg4: The fourth argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == "This is a long description.\nIt can span multiple lines."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:15:00.826687
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[1].args == ['param', 'arg2']
    assert docstring.meta[1].description == 'The second argument.'


# Generated at 2022-06-17 18:15:15.099541
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].type_name == 'str'


# Generated at 2022-06-17 18:15:23.482604
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:15:32.816901
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[1].args == ["param", "arg2"]
    assert doc.meta[1].description == "The second argument."


# Generated at 2022-06-17 18:15:43.351369
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
        arg3: This is arg3.

    Returns:
        This is a return description.

    Raises:
        ValueError: If something bad happens.
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1']


# Generated at 2022-06-17 18:15:55.947883
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1: The first argument."]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta

# Generated at 2022-06-17 18:16:05.540831
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Setup
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    # Exercise
    ret = GoogleParser().parse(text)
    # Verify
    assert ret.short_description == "This is a short description."
    assert ret.long_description == "This is a long description."
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ["param", "arg1"]
    assert ret.meta[0].description == "The first argument."


# Generated at 2022-06-17 18:16:15.398375
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "The first argument."