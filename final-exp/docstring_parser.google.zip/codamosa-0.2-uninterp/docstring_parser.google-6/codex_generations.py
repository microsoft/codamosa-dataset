

# Generated at 2022-06-17 18:06:47.901017
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:06:54.063707
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:07:04.019080
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (str): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:07:15.645254
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
        Short description.

        Long description.

        Args:
            arg1: The first argument.
            arg2: The second argument.
        Returns:
            The return value. True for success, False otherwise.
        Raises:
            KeyError: Raises an exception.
        """)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:07:27.716325
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:07:33.654775
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
    """
    parser = GoogleParser()
    result = parser.parse(docstring)
    assert result.short_description == "This is a test."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 3

# Generated at 2022-06-17 18:07:44.948408
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:07:50.873344
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.
        arg3 (str): This is arg3.
    """
    docstring_parsed = GoogleParser().parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == False
    assert docstring_parsed.meta[0].args == ['param', 'arg1 (str)']
    assert docstring_parsed.meta

# Generated at 2022-06-17 18:08:02.852482
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

# Generated at 2022-06-17 18:08:08.429834
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[1].args == ["param", "arg2"]
    assert doc.meta[1].description == "The second argument."



# Generated at 2022-06-17 18:08:23.782153
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    text = """
    This is a test.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "The ``Raises`` section is a list of all exceptions\nthat are relevant to the interface.\nIf `param2` is equal to `param1`."
    assert docstring.blank_after_

# Generated at 2022-06-17 18:08:31.155801
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (list): The third argument.
        arg4 (dict): The fourth argument.
        arg5 (bool): The fifth argument. Defaults to True.

    Returns:
        str: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:08:36.871539
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:08:47.325974
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[1].args == ["param", "arg2"]
    assert doc.meta[1].description == "The second argument."

#

# Generated at 2022-06-17 18:08:57.106983
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].arg_name == 'arg1'

# Generated at 2022-06-17 18:09:08.897129
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (bool): The third argument. Defaults to False.
        arg4 (int): The fourth argument.

    Returns:
        int: The return value.
    """
    docstring_obj = parse(docstring)
    assert docstring_obj.short_description == "This is a test docstring."
    assert docstring_obj.long_description == "This is the long description."
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == True
    assert len(docstring_obj.meta) == 4
    assert docstring_obj.meta

# Generated at 2022-06-17 18:09:21.509323
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """

# Generated at 2022-06-17 18:09:31.553255
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.
        arg3 (str): Description of arg3. Defaults to "foo".

    Returns:
        int: Description of return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:09:39.111925
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    A short summary.

    A long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "A short summary."
    assert docstring.long_description == "A long description."
    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].description == "The second argument."


# Generated at 2022-06-17 18:09:44.431872
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[1].args

# Generated at 2022-06-17 18:10:01.545390
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        The return value. True for success, False otherwise.
    """
    docstring_parsed = GoogleParser().parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == True
    assert docstring_parsed.meta[0].args == ["param", "arg1"]
    assert docstring_parsed.meta[0].description

# Generated at 2022-06-17 18:10:15.258118
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
    This is a docstring.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
        arg3: This is arg3.

    Returns:
        This is a return.

    Raises:
        ValueError: If something wrong.

    """
    result = parser.parse(docstring)
    assert result.short_description == "This is a docstring."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[0].description == 'This is arg1.'
   

# Generated at 2022-06-17 18:10:25.360114
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:10:36.879978
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test.

    Args:
        a: a
        b: b

    Returns:
        c: c
    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "This is a test."
    assert ret.long_description == None
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ['param', 'a: a\n        b: b']
    assert ret.meta[0].description == None
    assert ret.meta[0].arg_name == 'a'
    assert ret.meta[0].type_name == 'a'
    assert ret.meta[0].is_

# Generated at 2022-06-17 18:10:46.721227
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1 (int)']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].type_name == 'int'


# Generated at 2022-06-17 18:10:57.490261
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == 'Description of arg1.'

# Generated at 2022-06-17 18:11:09.327206
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description


# Generated at 2022-06-17 18:11:21.287238
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring_result = GoogleParser().parse(docstring)
    assert docstring_result.short_description == "This is a short description."
    assert docstring_result.long_description == "This is a long description."
    assert docstring_result.blank_after_short_description == True
    assert docstring_result.blank_

# Generated at 2022-06-17 18:11:32.814688
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:11:43.090035
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:11:55.365668
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:12:07.382369
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:12:18.723916
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
        arg3 (str): The third argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `arg2` is equal to `arg3`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args

# Generated at 2022-06-17 18:12:30.653371
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        The return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:12:40.636743
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta

# Generated at 2022-06-17 18:12:48.475801
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """
        This is a short description.

        This is a long description.

        Args:
            arg1: The first argument.
            arg2: The second argument.
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:12:59.600739
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """

# Generated at 2022-06-17 18:13:09.594229
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:13:18.253230
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:13:29.504180
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("\n") == Docstring()
    assert parser.parse("\n\n") == Docstring()
    assert parser.parse("\n\n\n") == Docstring()
    assert parser.parse("\n\n\n\n") == Docstring()
    assert parser.parse("\n\n\n\n\n") == Docstring()
    assert parser.parse("\n\n\n\n\n\n") == Docstring()
    assert parser.parse("\n\n\n\n\n\n\n") == Docstring()
    assert parser.parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:13:45.030218
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.
    """

# Generated at 2022-06-17 18:13:55.220192
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:14:01.201471
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `foo`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:14:12.478429
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first argument is invalid.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']
   

# Generated at 2022-06-17 18:14:19.815057
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:14:30.848275
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (bool): The third argument.

    Returns:
        int: The return value.
    """
    docstring_object = GoogleParser().parse(docstring)
    assert docstring_object.short_description == "This is a short description."
    assert docstring_object.long_description == "This is a long description."
    assert docstring_object.blank_after_short_description == True
    assert docstring_object.blank_after_long_description == False
    assert docstring_object.meta[0].args == ["param", "arg1 (int)"]

# Generated at 2022-06-17 18:14:39.949524
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.
        arg3 (str): This is arg3.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If something bad happens.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4
    assert docstring.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:14:54.305455
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first argument is invalid.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
   

# Generated at 2022-06-17 18:15:03.540031
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description

# Generated at 2022-06-17 18:15:08.788180
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test with short description only
    assert GoogleParser().parse("Short description.") == Docstring(
        short_description="Short description."
    )

    # Test with short and long description
    assert GoogleParser().parse(
        """
        Short description.

        Long description.
        """
    ) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Test with short and long description with extra blank lines

# Generated at 2022-06-17 18:15:24.133070
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
        This is a short description.

        This is a long description.

        Args:
            arg1: This is arg1.
            arg2: This is arg2.
            arg3: This is arg3.

        Returns:
            This is a description of what is returned.

        Raises:
            KeyError: Raises an exception.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:15:34.197340
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    parser = GoogleParser()
    docstring = parser.parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_

# Generated at 2022-06-17 18:15:43.541780
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first argument is invalid.
    """
    result = GoogleParser().parse(text)
    assert result.short_description == "This is a test."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 3
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[0].description == 'The first argument.'
    assert result.meta

# Generated at 2022-06-17 18:15:55.984117
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[0].arg_name

# Generated at 2022-06-17 18:16:05.541317
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Args:
        a (int): a
        b (int): b
    Returns:
        int: a + b
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == ""
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'a (int)']
    assert docstring.meta[0].description == 'a'
    assert docstring.meta[0].arg_name == 'a'
    assert docstring.meta[0].type_name == 'int'
    assert docstring.meta[0].is_optional == False


# Generated at 2022-06-17 18:16:15.397983
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.

    Returns:
        str: This is a return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].arg_name == "arg1"