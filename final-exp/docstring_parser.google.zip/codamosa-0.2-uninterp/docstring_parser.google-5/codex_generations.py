

# Generated at 2022-06-17 18:06:32.715593
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test method parse of class GoogleParser
    """
    # Test case 1
    text = """
    This is a test docstring.

    :param arg1: The first argument.
    :type arg1: str
    :param arg2: The second argument.
    :type arg2: int, optional
    :returns: Description of return value.
    :rtype: bool
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1']
   

# Generated at 2022-06-17 18:06:41.062194
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Input arguments:
    #   text:
    #       type: str
    #       doc:
    # Output:
    #   return:
    #       type: Docstring
    #       doc:
    # Test data:
    text = '''
    This is a test function.

    This is a long description.

    Args:
        arg1: This is the first argument.
        arg2: This is the second argument.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    '''
    # Expected output:

# Generated at 2022-06-17 18:06:53.655042
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:06:57.602383
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a docstring.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value.
    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "This is a docstring."
    assert ret.long_description == "This is a long description."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ['param', 'arg1: The first argument.']
    assert ret.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:07:06.042960
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
   

# Generated at 2022-06-17 18:07:16.244084
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (bool): The third argument.

    Returns:
        str: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "The return value. True for success, False otherwise."
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1 (int)"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2 (str)"]


# Generated at 2022-06-17 18:07:28.574221
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # This is a test for method parse of class GoogleParser
    # Input arguments:
    #   text:
    #       This is a test for method parse of class GoogleParser
    # Expected output:
    #   Docstring(short_description='This is a test for method parse of class GoogleParser', long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    text = "This is a test for method parse of class GoogleParser"
    assert GoogleParser().parse(text) == Docstring(short_description='This is a test for method parse of class GoogleParser', long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])


# Generated at 2022-06-17 18:07:39.804017
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
        This is a short description.

        This is a long description.

        Args:
            arg1 (str): Description of arg1.
            arg2 (int): Description of arg2.
            arg3 (str): Description of arg3.

        Returns:
            str: Description of return value.

        Raises:
            ValueError: Description of exception.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:07:54.004989
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: If arg1 is empty.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "Description of arg1."
   

# Generated at 2022-06-17 18:08:04.440016
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[1].args == ['param', 'arg2']

# Generated at 2022-06-17 18:08:26.586401
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (str): Description of arg2.

    Returns:
        str: Description of return value.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:08:37.560345
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `bar` is not equal to `foo`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']

# Generated at 2022-06-17 18:08:47.877492
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: Description of exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:08:55.746564
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]
    assert doc

# Generated at 2022-06-17 18:09:07.916600
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """
        This is a short description.

        This is a long description.

        Args:
            arg1 (str): The first argument.
            arg2 (str): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.

        Raises:
            AttributeError: The ``AttributeError`` exception.
            ValueError: The ``ValueError`` exception.
    """
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:09:20.453833
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
        arg3: This is arg3.

    Returns:
        This is a return description.

    Raises:
        ValueError: This is a ValueError description.
        KeyError: This is a KeyError description.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 5

# Generated at 2022-06-17 18:09:30.810521
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.
        arg3 (str, optional): This is arg3. Defaults to 'default'.
        arg4 (str): This is arg4.
        arg5 (str, optional): This is arg5. Defaults to 'default'.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `arg2` is equal to `arg3`.
    """
    result = GoogleParser().parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True

# Generated at 2022-06-17 18:09:40.952043
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:09:48.683526
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is a return.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:10:00.370531
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        int: Description of return value.

    Raises:
        ValueError: Description of exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "Description of arg1."
    assert doc

# Generated at 2022-06-17 18:10:09.584752
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:10:20.613599
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (str): The third argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `baz`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:10:29.495892
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    """
    docstring_obj = parser.parse(docstring)
    assert docstring_obj.short_description == "This is a short description."
    assert docstring_obj.long_description == "This is a long description."
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == False
    assert len(docstring_obj.meta) == 3
    assert docstring_obj.meta[0].args

# Generated at 2022-06-17 18:10:39.181627
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    A short summary.

    A longer description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: If arg1 is empty.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "A short summary."
    assert docstring.long_description == "A longer description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "Description of arg1."
   

# Generated at 2022-06-17 18:10:48.391309
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    docstring = '''
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
    '''

# Generated at 2022-06-17 18:10:58.059553
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
    This is a docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    """
    doc = parser.parse(docstring)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == "Args:\n    arg1 (int): The first argument.\n    arg2 (str): The second argument."
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[1].description == "The second argument."
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[1].arg_name == "arg2"
    assert doc.meta[0].type_name == "int"

# Generated at 2022-06-17 18:11:09.655928
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.

    Returns:
        str: This is the return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:11:21.583386
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta

# Generated at 2022-06-17 18:11:33.081240
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]
    assert docstring.meta[1].description == "The second argument."



# Generated at 2022-06-17 18:11:38.223117
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """
    result = GoogleParser().parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0].args == ['param', 'arg1 (str)']
    assert result.meta[0].description == 'Description of arg1.'
    assert result.meta[0].arg_name == 'arg1'
    assert result.meta

# Generated at 2022-06-17 18:11:56.001810
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
        arg4: The fourth argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description

# Generated at 2022-06-17 18:12:07.722952
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Parameters
    ----------
    arg1 : int
        Description of arg1.
    arg2 : str
        Description of arg2.

    Returns
    -------
    int
        Description of return value.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1 : int"]
    assert docstring.meta[0].description == "Description of arg1."

# Generated at 2022-06-17 18:12:19.075573
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
        arg3 (bool): The third argument. Defaults to False.

    Returns:
        str: The return value.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == None
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1 (str)"]
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[0].arg_name

# Generated at 2022-06-17 18:12:24.707435
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:12:33.212535
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:12:41.877255
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:12:45.094533
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # This method is not tested because it is not used in the code
    pass


# Generated at 2022-06-17 18:12:56.424895
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: Description of exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:13:02.725507
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    This is a longer description of the function.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
        arg3 (:obj:`int`, optional): The third argument. Defaults to None.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == "This is a longer description of the function."


# Generated at 2022-06-17 18:13:11.889561
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case of test case
    # Input data for unit test
    text = '''
    This is a test docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    # Expected output of unit test

# Generated at 2022-06-17 18:13:28.819250
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (Optional[int]): The third argument.
        arg4 (int): The fourth argument. Defaults to 4.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `foo`.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 5

# Generated at 2022-06-17 18:13:35.208776
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[1].args == ['param', 'arg2']

# Generated at 2022-06-17 18:13:45.215494
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: Description of exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:13:55.338278
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:14:05.657599
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a function.

    This is the long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a function."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1 (int)']
    assert docstring.meta[0].description == "The first argument."
    assert docstring

# Generated at 2022-06-17 18:14:15.736070
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case of test case
    # Input data for this test case
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: The exception description.
    """
    # Expected output of this test case

# Generated at 2022-06-17 18:14:26.303792
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case:
    # If the docstring is empty, it should return an empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Success case:
    # If the docstring is not empty, it should return a docstring with the
    # correct attributes
    docstring = GoogleParser().parse(
        """
        This is a short description.

        This is a long description.

        Args:
            arg1: This is the first argument.
            arg2: This is the second argument.

        Returns:
            This is the return value.
        """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
   

# Generated at 2022-06-17 18:14:36.633770
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:14:45.365802
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

# Generated at 2022-06-17 18:14:56.036494
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:15:11.705464
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is the return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "This is arg1."
    assert docstring

# Generated at 2022-06-17 18:15:21.325498
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].type_

# Generated at 2022-06-17 18:15:32.655797
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "This is a test function."
    assert ret.long_description is None
    assert ret.blank_after_short_description is True
    assert ret.blank_after_long_description is False
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ['param', 'arg1']
    assert ret.meta[0].description == 'The first argument.'
    assert ret.meta[0].arg_name == 'arg1'
    assert ret.meta[0].type_name is None
    assert ret.meta[0].is_optional is None

# Generated at 2022-06-17 18:15:38.924358
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with no docstring
    assert GoogleParser().parse("") == Docstring()

    # Test with docstring with no meta
    docstring = GoogleParser().parse("""
    This is a short description.

    This is a long description.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert not docstring.meta

    # Test with docstring with meta
    docstring = GoogleParser().parse("""
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
    """)
    assert docstring

# Generated at 2022-06-17 18:15:45.936329
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a summary.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a summary."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:15:54.388653
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["returns"]

# Generated at 2022-06-17 18:16:00.883423
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is return.

    Raises:
        ValueError: This is exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "This is arg1."
    assert docstring

# Generated at 2022-06-17 18:16:08.458050
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.
        arg3 (str): This is arg3.
    """
    doc = parser.parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ['param', 'arg1 (str)']
    assert doc.meta[0].description == "This is arg1."

# Generated at 2022-06-17 18:16:17.674694
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.

    Returns:
        This is a return value.
    '''
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == 'This is a short description.'
    assert docstring.long_description == 'This is a long description.'
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'This is arg1.'