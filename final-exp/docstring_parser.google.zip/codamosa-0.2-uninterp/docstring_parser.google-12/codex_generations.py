

# Generated at 2022-06-17 18:06:54.028198
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    text = """\
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[0].arg_name

# Generated at 2022-06-17 18:07:03.982773
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:07:15.646360
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (int)']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[0].arg_name == 'arg1'

# Generated at 2022-06-17 18:07:27.715484
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for method parse of class GoogleParser"""
    # Test for method parse of class GoogleParser
    # Input arguments for method parse
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    # Output arguments for method parse

# Generated at 2022-06-17 18:07:38.863783
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]
    assert docstring

# Generated at 2022-06-17 18:07:47.970070
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:07:56.922333
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
        Short description.

        Long description.

        Args:
            arg1: The first argument.
            arg2: The second argument.
        Returns:
            The return value. True for success, False otherwise.
        """)
    assert docstring.short_description == "Short description."
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["returns"]
    assert docstring.meta

# Generated at 2022-06-17 18:08:06.774970
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1 (str)"]
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:08:14.829156
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.
    """
    docstring_obj = GoogleParser().parse(docstring)
    assert docstring_obj.short_description == "This is a test docstring."
    assert docstring_obj.long_description == None
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == False
    assert docstring_obj.meta[0].args == ['param', 'arg1 (str)']
    assert docstring_obj.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:08:25.966725
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
        arg3 (str, optional): The third argument. Defaults to 'third'.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `arg2` is equal to `arg3`.
    """
    result = parse(docstring)
    assert result.short_description == "This is a test docstring."
    assert result.long_description == "This is the long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 4

# Generated at 2022-06-17 18:08:40.273619
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:08:53.922078
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value. True for success, False otherwise.
    """

# Generated at 2022-06-17 18:09:00.298049
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:09:11.048835
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a docstring.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
        arg3: This is arg3.

    Returns:
        This is a return.

    Raises:
        This is a raise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description

# Generated at 2022-06-17 18:09:23.272343
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `foo`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == 'The first argument.'
   

# Generated at 2022-06-17 18:09:32.176019
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """

# Generated at 2022-06-17 18:09:41.792602
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    parsed_docstring = GoogleParser().parse(docstring)
    assert parsed_docstring.short_description == "This is a short description."
    assert parsed_docstring.long_description == "This is a long description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == True
    assert parsed_docstring.meta[0].args == ['param', 'arg1']
    assert parsed_docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:09:53.504322
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (int)"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta

# Generated at 2022-06-17 18:10:03.570765
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (bool): The third argument.

    Returns:
        str: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1 (int)']
    assert docstring.meta[0].description == 'The first argument.'
   

# Generated at 2022-06-17 18:10:16.800194
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.
        arg3 (str): This is arg3.
        arg4 (int): This is arg4.

    Returns:
        str: This is the return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 5

# Generated at 2022-06-17 18:10:29.942518
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    parsed_docstring = GoogleParser().parse(docstring)
    assert parsed_docstring.short_description == "This is a test docstring."
    assert parsed_docstring.long_description == None
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:10:33.944276
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
        arg4: The fourth argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:10:40.768101
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "The return value. True for success, False otherwise."
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ['param', 'arg2']
    assert docstring.meta[1].description == "The second argument."
    assert docstring.meta[2].args == ['returns']

# Generated at 2022-06-17 18:10:54.942398
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
        arg4: The fourth argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:11:06.512566
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case of test case
    # Input data for this test case
    text = """
    This is a test docstring.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
    """
    # Expected output of this test case

# Generated at 2022-06-17 18:11:11.173994
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring_parsed = GoogleParser().parse(docstring)
    assert docstring_parsed.short_description == 'This is a short description.'
    assert docstring_parsed.long_description == 'This is a long description.'
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == False
    assert docstring_parsed.meta[0].args == ['param', 'arg1 (str)']
    assert docstring_

# Generated at 2022-06-17 18:11:22.110192
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test with simple docstring
    docstring = GoogleParser().parse("""
    This is a simple docstring.
    """)
    assert docstring.short_description == "This is a simple docstring."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    # Test with simple docstring with blank line after short description
    docstring = GoogleParser().parse("""
    This is a simple docstring.

    """)
    assert docstring.short_description == "This is a simple docstring."
    assert docstring.long_description is None
    assert docstring.blank_after_short_

# Generated at 2022-06-17 18:11:33.372049
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:11:43.859116
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1 (str)"]
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[0].type_name == "str"

# Generated at 2022-06-17 18:11:56.653867
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str, optional): This is arg2. Defaults to None.

    Returns:
        str: This is a return.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "This is arg1."
    assert docstring.meta[0].arg_name

# Generated at 2022-06-17 18:12:09.765446
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a docstring.
    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a docstring."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["Args", "arg1: The first argument.\narg2: The second argument."]
    assert doc.meta[0].description == None

# Generated at 2022-06-17 18:12:20.283187
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test with docstring with only short description
    assert GoogleParser().parse("Short description.") == Docstring(
        short_description="Short description."
    )

    # Test with docstring with short description and long description
    assert GoogleParser().parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
    )

    # Test with docstring with short description, long description and meta

# Generated at 2022-06-17 18:12:25.411892
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    This is the long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-17 18:12:33.662378
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """
        Test function.

        Args:
            arg1: The first argument.
            arg2: The second argument.
        """
    )
    assert docstring.short_description == "Test function."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]
    assert docstring.meta[1].description == "The second argument."


# Generated at 2022-06-17 18:12:42.245592
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:12:50.759727
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int, optional): This is arg2. Defaults to 10.

    Returns:
        str: This is a description of what is returned.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:13:00.227977
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring_obj = GoogleParser().parse(docstring)
    assert docstring_obj.short_description == "This is a short description."
    assert docstring_obj.long_description == "This is a long description."
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == False
    assert len(docstring_obj.meta) == 3
    assert docstring_obj.meta[0].args == ['param', 'arg1 (str)']

# Generated at 2022-06-17 18:13:10.249319
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring_parsed = GoogleParser().parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed

# Generated at 2022-06-17 18:13:18.766482
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first argument is invalid.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']

# Generated at 2022-06-17 18:13:29.870291
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ['param', 'arg2']
    assert docstring

# Generated at 2022-06-17 18:13:43.419282
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """

# Generated at 2022-06-17 18:13:54.305559
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    text = """
    This is a test.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    """

# Generated at 2022-06-17 18:14:04.045955
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Setup
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    # Exercise
    ret = GoogleParser().parse(text)
    # Verify
    assert ret.short_description == "This is a short description."
    assert ret.long_description == "This is a long description."
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ["param", "arg1: The first argument."]

# Generated at 2022-06-17 18:14:14.616897
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """

    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1"]
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[1].args == ["param", "arg2"]
    assert doc

# Generated at 2022-06-17 18:14:25.427530
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:14:35.824027
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    parser = GoogleParser()
    result = parser.parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 2
    assert result.meta[0].args == ["param", "arg1: The first argument."]
    assert result.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:14:40.278749
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:14:54.367583
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    docstring_meta = GoogleParser().parse(docstring)
    assert docstring_meta.short_description == "This is a short description."
    assert docstring_meta.long_description == "This is a long description."
    assert docstring_meta.blank_after_short_description == True
    assert docstring_meta.blank_

# Generated at 2022-06-17 18:15:03.566647
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case 1:
    # Input:
    #   text = ""
    # Expected output:
    #   Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    # Observed output:
    #   Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    text = ""
    expected_output = Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])
    observed_output = GoogleParser().parse(text)
    assert expected_output == observed_output

# Generated at 2022-06-17 18:15:15.198162
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "Parse the Google-style docstring into its components."
    assert ret.long_description == None
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 1
    assert ret.meta[0].args == ['returns']
    assert ret.meta[0].description == 'parsed docstring'

    # Test case 2
    text = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring

    """
    ret = GoogleParser().parse(text)

# Generated at 2022-06-17 18:15:25.148002
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (None): The third argument.

    Returns:
        str: The return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

# Generated at 2022-06-17 18:15:34.735868
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    This is a test.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value.
    '''
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == 'This is a test.'
    assert docstring.long_description == 'The return value.'
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[1].args == ['param', 'arg2']
    assert docstring.meta[1].description == 'The second argument.'
    assert docstring.meta[2].args == ['returns']
    assert docstring.meta[2].description == 'The return value.'



# Generated at 2022-06-17 18:15:43.911832
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.
        arg3: This is arg3.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    """
    docstring_obj = parse(docstring)
    assert docstring_obj.short_description == "This is a short description."
    assert docstring_obj.long_description == "This is a long description."
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == True
    assert len(docstring_obj.meta) == 4

# Generated at 2022-06-17 18:15:56.020646
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test docstring.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_

# Generated at 2022-06-17 18:16:05.543181
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == 'Description of arg1.'

# Generated at 2022-06-17 18:16:15.397923
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_