

# Generated at 2022-06-17 18:06:41.217312
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (int)']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:06:53.684030
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (list): The third argument.
        arg4 (dict): The fourth argument.
        arg5 (bool): The fifth argument.
        arg6 (tuple): The sixth argument.
        arg7 (set): The seventh argument.
        arg8 (float): The eighth argument.
        arg9 (complex): The ninth argument.
        arg10 (object): The tenth argument.

    Returns:
        int: The return value. True for success, False otherwise.
    """
    parser = GoogleParser()
    result = parser.parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long

# Generated at 2022-06-17 18:06:58.887011
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description
    assert doc.blank_after_long_description
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1 (int)"]
    assert doc.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:07:03.942944
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:07:10.068660
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring
    from .common import DocstringMeta
    from .common import DocstringParam
    from .common import DocstringRaises
    from .common import DocstringReturns
    from .common import ParseError
    from .common import SectionType
    from .common import Section
    from .common import YIELDS_KEYWORDS
    from .common import PARAM_KEYWORDS
    from .common import RAISES_KEYWORDS
    from .common import RETURNS_KEYWORDS
    from .common import DEFAULT_SECTIONS
    from .common import GOOGLE_TYPED_ARG_REGEX
    from .common import GOOGLE_ARG_DESC_REGEX
    from .common import MULTIPLE_PATTERN
    from .common import inspect
    from .common import re

# Generated at 2022-06-17 18:07:17.068748
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["returns"]

# Generated at 2022-06-17 18:07:29.534811
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:07:33.850711
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    This is a short description.

    This is a long description.

    Args:
        arg1: This is arg1.
        arg2: This is arg2.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    '''
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == 'This is a short description.'
    assert doc.long_description == 'This is a long description.'
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert doc.meta[0].args == ['param', 'arg1']
    assert doc.meta[0].description == 'This is arg1.'

# Generated at 2022-06-17 18:07:37.545773
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a docstring.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == "This is a long description."
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]
    assert docstring.meta[1].description == "The second argument."


# Generated at 2022-06-17 18:07:47.426449
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: Description of exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:08:03.834633
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ['param', 'arg1: The first argument.']
    assert doc.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:08:11.260259
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True


# Generated at 2022-06-17 18:08:22.691149
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:08:30.460889
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:08:39.796445
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Google-style docstring parsing.

    :param sections: Recognized sections or None to defaults.
    :param title_colon: require colon after section title.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "Google-style docstring parsing."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'sections']
    assert docstring.meta[0].description == "Recognized sections or None to defaults."
    assert docstring.meta[1].args == ['param', 'title_colon']
    assert docstring.meta[1].description == "require colon after section title."

#

# Generated at 2022-06-17 18:08:53.820736
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("A short description.") == Docstring(
        short_description="A short description."
    )
    assert parse("A short description.\n") == Docstring(
        short_description="A short description.",
        blank_after_short_description=True,
    )
    assert parse("A short description.\n\n") == Docstring(
        short_description="A short description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert parse("A short description.\n\nA long description.") == Docstring(
        short_description="A short description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        long_description="A long description.",
    )

# Generated at 2022-06-17 18:09:00.231518
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
        OtherError: Raises a different exception.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 4
    assert doc.meta[0].args == ["param", "arg1"]

# Generated at 2022-06-17 18:09:10.987360
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    This is a test function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    '''
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == 'This is a test function.'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (int)']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:09:23.212969
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    result = GoogleParser().parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[0].description == 'The first argument.'
    assert result.meta[0].arg_name == 'arg1'
    assert result.meta[0].type_name

# Generated at 2022-06-17 18:09:32.135795
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (list): The third argument.

    Returns:
        str: The return value.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len

# Generated at 2022-06-17 18:09:44.158120
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with empty string
    assert GoogleParser().parse("") == Docstring()

    # Test with no section
    text = "This is a description."
    assert GoogleParser().parse(text) == Docstring(
        short_description="This is a description.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    # Test with one section
    text = """This is a description.

Args:
    arg1: This is arg1.
"""

# Generated at 2022-06-17 18:09:51.029510
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
        This is a short description.

        This is a long description.

        Args:
            arg1: The first argument.
            arg2: The second argument.

        Returns:
            The return value.

        Raises:
            KeyError: Raises an exception.
        """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta

# Generated at 2022-06-17 18:10:01.913383
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        This is a test function.

        Args:
            arg1 (int): The first argument.
            arg2 (str): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.
        """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (int)']
    assert docstring.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:10:15.651306
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (str): The third argument.
    '''
    parser = GoogleParser()
    result = parser.parse(docstring)
    assert result.short_description == 'This is a short description.'
    assert result.long_description == 'This is a long description.'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 3
    assert result.meta[0].args == ['param', 'arg1 (int)']
    assert result.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:10:25.756530
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a docstring.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If `bar` is equal to `baz`.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (str)']

# Generated at 2022-06-17 18:10:37.302469
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:10:46.969081
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:10:57.585295
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
        arg3 (str): The third argument.

    Returns:
        str: The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta

# Generated at 2022-06-17 18:11:09.415159
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case 1:
    # docstring is None
    # Expected output:
    # Docstring()
    assert GoogleParser().parse(None) == Docstring()

    # Failure case 2:
    # docstring is empty
    # Expected output:
    # Docstring()
    assert GoogleParser().parse("") == Docstring()

    # Failure case 3:
    # docstring is not empty but does not have sections
    # Expected output:
    # Docstring(short_description='short description', long_description='long description')
    assert GoogleParser().parse("short description\n\nlong description") == Docstring(
        short_description="short description", long_description="long description"
    )

    # Failure case 4:
    # docstring has sections but no description
    # Ex

# Generated at 2022-06-17 18:11:21.353542
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test with short description only
    assert GoogleParser().parse("Short description.") == Docstring(
        short_description="Short description."
    )

    # Test with short description and long description
    assert GoogleParser().parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
    )

    # Test with short description, long description and meta

# Generated at 2022-06-17 18:11:36.066819
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test for docstring with short description only
    assert GoogleParser().parse("A short description.") == Docstring(
        short_description="A short description."
    )

    # Test for docstring with short description and long description
    assert GoogleParser().parse("A short description.\n\nA long description.") == Docstring(
        short_description="A short description.",
        long_description="A long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Test for docstring with short description and long description

# Generated at 2022-06-17 18:11:45.512536
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:11:58.636483
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `baz`.
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (str)']

# Generated at 2022-06-17 18:12:08.878548
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: Description of exception.
    """
    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:12:19.925741
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:12:31.464345
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a function.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a function."
    assert doc.long_description == "The ``Raises`` section is a list of all exceptions\nthat are relevant to the interface."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False

# Generated at 2022-06-17 18:12:40.784859
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ['param', 'arg2']
    assert docstring.meta

# Generated at 2022-06-17 18:12:48.780867
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:12:59.728138
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1 (str)"]
    assert doc.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:13:09.759885
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
    """
    parser = GoogleParser()
    result = parser.parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[0].description == "The first argument."
    assert result.meta[1].args == ['param', 'arg2']

# Generated at 2022-06-17 18:13:30.243427
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first exception type.
        KeyError: The second exception type.
    """
    parsed_docstring = parser.parse(docstring)
    assert parsed_docstring.short_description == "This is a short description."
    assert parsed_docstring.long_description == "This is a long description."
    assert parsed_docstring.blank_after_short_description == True
    assert parsed_docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:13:40.434419
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert len(doc.meta) == 2
    assert doc.meta[0].description == "The first argument."
    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[1].description == "The second argument."
    assert doc.meta[1].arg_name == "arg2"


# Generated at 2022-06-17 18:13:53.858724
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[0].arg_name == "arg1"
   

# Generated at 2022-06-17 18:14:00.498255
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Failure case of test case
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    # Instantiate GoogleParser
    parser = GoogleParser()
    # Call method parse of GoogleParser
    result = parser.parse(text)
    # Check result
    assert result.short_description == "This is a test function."
    assert result.long_description == None
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta[0].args == ['param', 'arg1']
    assert result.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:14:11.458385
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("Hello") == Docstring(
        short_description="Hello",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert GoogleParser().parse("Hello\n") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert GoogleParser().parse("Hello\n\n") == Docstring(
        short_description="Hello",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-17 18:14:19.375022
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]

# Generated at 2022-06-17 18:14:30.481477
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test function.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.
    """

# Generated at 2022-06-17 18:14:39.691300
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    result = parser.parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 2
    assert result.meta[0].args == ['param', 'arg1: The first argument.']
    assert result.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:14:54.136523
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.
    """

# Generated at 2022-06-17 18:15:03.391614
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a docstring.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """

# Generated at 2022-06-17 18:15:22.603156
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:15:33.133543
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.

    Returns:
        bool: This is a return value.

    Raises:
        ValueError: This is a ValueError.
    """

# Generated at 2022-06-17 18:15:43.387556
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is the short description.

    This is the long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is the short description."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:15:48.608476
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:15:54.144798
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test with short description only
    assert GoogleParser().parse("Short description.") == Docstring(
        short_description="Short description."
    )

    # Test with short description and long description
    assert GoogleParser().parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    # Test with short description, long description and examples

# Generated at 2022-06-17 18:16:04.026656
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.

    Returns:
        bool: This is the return value.
    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "This is a test docstring."
    assert ret.long_description == "This is the long description."
    assert len(ret.meta) == 2
    assert ret.meta[0].args == ["param", "arg1 (str)"]
    assert ret.meta[0].description == "This is arg1."
    assert ret.meta[0].arg_name == "arg1"
    assert ret.meta[0].type_name == "str"
    assert ret.meta

# Generated at 2022-06-17 18:16:14.618056
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is return value.

    Raises:
        ValueError: This is raised when value is invalid.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1 (str)"]