

# Generated at 2022-06-17 18:06:45.786907
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test function.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']

# Generated at 2022-06-17 18:06:52.890220
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """

# Generated at 2022-06-17 18:07:03.787660
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for empty docstring
    assert GoogleParser().parse("") == Docstring()

    # Test for docstring with only short description
    assert GoogleParser().parse("Short description.") == Docstring(
        short_description="Short description."
    )

    # Test for docstring with short and long description
    assert GoogleParser().parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description.",
    )

    # Test for docstring with short and long description

# Generated at 2022-06-17 18:07:09.987766
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a test.

    Args:
        arg1 (str): This is a test.
        arg2 (str): This is a test.
        arg3 (str): This is a test.

    Returns:
        str: This is a test.
    """
    result = GoogleParser().parse(text)
    assert result.short_description == "This is a test."
    assert result.long_description == "This is a test.\nThis is a test."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert result.meta[0].args == ['param', 'arg1 (str)']
    assert result.meta[0].description == "This is a test."
    assert result.meta[0].arg

# Generated at 2022-06-17 18:07:18.385709
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (str): Description of arg2.
        arg3 (str): Description of arg3.

    Returns:
        str: Description of return value.
    """
    docstring_parsed = GoogleParser().parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == True

# Generated at 2022-06-17 18:07:30.514007
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        bool: Description of return value.
    """
    parser = GoogleParser()
    result = parser.parse(docstring)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == True
    assert len(result.meta) == 3
    assert result.meta[0].description == "Description of arg1."
    assert result.meta[0].arg_name == "arg1"
    assert result.meta[0].type

# Generated at 2022-06-17 18:07:41.605807
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.
        arg3 (str): This is arg3.

    Returns:
        str: This is return.

    Raises:
        ValueError: This is exception.
    """

# Generated at 2022-06-17 18:07:54.575601
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """

# Generated at 2022-06-17 18:08:04.848803
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (list): The third argument.

    Returns:
        str: The return value.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ["param", "arg1 (int)"]
    assert doc.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:08:12.157266
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1: The first argument.']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta

# Generated at 2022-06-17 18:08:28.797164
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[0].arg_name == 'arg1'
    assert doc

# Generated at 2022-06-17 18:08:38.969673
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        AttributeError, KeyError
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
   

# Generated at 2022-06-17 18:08:48.613305
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    '''
    parser = GoogleParser()

# Generated at 2022-06-17 18:08:56.461052
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].type_name == None

# Generated at 2022-06-17 18:09:08.606473
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
    This is a test.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "The return value. True for success, False otherwise."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:09:21.213310
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta[0].description == "The first argument."
    assert docstring.meta[1].args == ["param", "arg2"]
    assert docstring

# Generated at 2022-06-17 18:09:31.348512
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    Returns:
        The return value. True for success, False otherwise.
    """)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ["param", "arg1: The first argument."]
    assert docstring.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:09:41.164589
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = '''
    This is a function.

    Args:
        arg1: The first argument.
        arg2: The second argument.
    '''
    docstring = parser.parse(text)
    assert docstring.short_description == 'This is a function.'
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[1].args == ['param', 'arg2']
    assert docstring.meta[1].description == 'The second argument.'


# Generated at 2022-06-17 18:09:48.875445
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
        arg3 (str): The third argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `arg2` is equal to `arg3`.
    """


# Generated at 2022-06-17 18:10:00.498186
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.

    Raises:
        ValueError: The first argument is invalid.
        TypeError: The second argument is invalid.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test docstring."
    assert docstring.long_description == "This is the long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta[0].args == ['param', 'arg1']

# Generated at 2022-06-17 18:10:17.279238
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
    """
    docstring_obj = GoogleParser().parse(docstring)
    assert docstring_obj.short_description == "This is a test docstring."
    assert docstring_obj.long_description == None
    assert docstring_obj.blank_after_short_description == True
    assert docstring_obj.blank_after_long_description == False
    assert docstring_obj.meta[0].args == ['param', 'arg1 (int)']
    assert docstring_obj.meta[0].description == 'The first argument.'
    assert docstring_obj.meta[0].arg_name == 'arg1'

# Generated at 2022-06-17 18:10:27.260695
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('\n') == Docstring()
    assert GoogleParser().parse('\n\n') == Docstring()
    assert GoogleParser().parse('\n\n\n') == Docstring()
    assert GoogleParser().parse('\n\n\n\n') == Docstring()
    assert GoogleParser().parse('\n\n\n\n\n') == Docstring()
    assert GoogleParser().parse('\n\n\n\n\n\n') == Docstring()
    assert GoogleParser().parse('\n\n\n\n\n\n\n') == Docstring()
    assert GoogleParser().parse('\n\n\n\n\n\n\n\n') == Docstring()

# Generated at 2022-06-17 18:10:33.646076
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:10:40.709276
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    docstring = """
    This is a docstring.

    Args:
        a: a
        b: b
        c: c

    Returns:
        returns
    """
    result = GoogleParser().parse(docstring)
    assert result.short_description == "This is a docstring."
    assert result.long_description == "Args:\n    a: a\n    b: b\n    c: c\n\nReturns:\n    returns"
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert len(result.meta) == 2
    assert result.meta[0].args == ['param', 'a']
    assert result.meta[0].description == 'a'

# Generated at 2022-06-17 18:10:54.950286
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("\n") == Docstring()
    assert parse("\n\n") == Docstring()
    assert parse("\n\n\n") == Docstring()
    assert parse("\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n") == Docstring()
    assert parse("\n\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:11:06.511467
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-17 18:11:11.211542
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:11:22.140510
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = '''
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    '''
    ret = GoogleParser().parse(text)
    assert ret.short_description == 'This is a test function.'
    assert ret.long_description == 'The return value. True for success, False otherwise.'
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert len(ret.meta) == 3
    assert ret.meta[0].args == ['param', 'arg1']
    assert ret.meta[0].description == 'The first argument.'

# Generated at 2022-06-17 18:11:33.411188
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ["param", "arg1 (str)"]
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_name == "str"
    assert doc

# Generated at 2022-06-17 18:11:43.860374
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ['param', 'arg1 (int)']
    assert doc.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:12:06.977264
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        str: The return value.
    """

# Generated at 2022-06-17 18:12:18.272209
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    parser = GoogleParser()
    docstring = parser.parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_

# Generated at 2022-06-17 18:12:30.044717
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `foo`.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ['param', 'arg1 (str)']

# Generated at 2022-06-17 18:12:36.779946
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a test docstring.

    This is the long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a test docstring."
    assert doc.long_description == "This is the long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 2
    assert doc.meta[0].args == ['param', 'arg1 (str)']
    assert doc.meta[0].description == "The first argument."

# Generated at 2022-06-17 18:12:44.090804
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[1].args

# Generated at 2022-06-17 18:12:55.815703
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short

# Generated at 2022-06-17 18:13:07.051262
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Input arguments:
    #   text: str
    # Output arguments:
    #   Docstring
    #
    # Test 1
    text = '''
    This is a test function.

    :param a: a parameter
    :type a: int
    :param b: another parameter
    :type b: float
    :returns: a + b
    :rtype: float
    '''

# Generated at 2022-06-17 18:13:14.402493
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    text = """
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "Parse the Google-style docstring into its components."
    assert ret.long_description == None
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert len(ret.meta) == 1
    assert ret.meta[0].args == ['returns']
    assert ret.meta[0].description == 'parsed docstring'

    # Test 2

# Generated at 2022-06-17 18:13:21.113559
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.

    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."

# Generated at 2022-06-17 18:13:31.460984
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a function.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        AttributeError: The ``Raises`` section is a list of all exceptions
            that are relevant to the interface.
        ValueError: If `param2` is equal to `param1`.
    """
    doc = GoogleParser().parse(text)
    assert doc.short_description == "This is a function."
    assert doc.long_description == "The ``Raises`` section is a list of all exceptions\nthat are relevant to the interface."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == True

# Generated at 2022-06-17 18:13:55.334374
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test function.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a test function."
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 3
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first argument.'
    assert docstring.meta[1].args == ['param', 'arg2']
    assert docstring.meta

# Generated at 2022-06-17 18:14:01.276668
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    text = """
    This is a test function.

    Args:
        arg1 (str): The first argument.
        arg2 (int, optional): The second argument. Defaults to 10.

    Returns:
        bool: The return value. True for success, False otherwise.

    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "This is a test function."
    assert ret.long_description == "Args:\n    arg1 (str): The first argument.\n    arg2 (int, optional): The second argument. Defaults to 10.\n\nReturns:\n    bool: The return value. True for success, False otherwise."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True

# Generated at 2022-06-17 18:14:12.520729
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.

    Returns:
        The return value. True for success, False otherwise.
    """
    docstring_parsed = GoogleParser().parse(docstring)
    assert docstring_parsed.short_description == "This is a short description."
    assert docstring_parsed.long_description == "This is a long description."
    assert docstring_parsed.blank_after_short_description == True
    assert docstring_parsed.blank_after_long_description == True
    assert docstring_parsed.meta[0].args == ['param', 'arg1: The first argument.']

# Generated at 2022-06-17 18:14:19.840904
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1: The first argument.
        arg2: The second argument.
        arg3: The third argument.

    Returns:
        This is a description of what is returned.

    Raises:
        KeyError: Raises an exception.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1"]
    assert docstring.meta

# Generated at 2022-06-17 18:14:30.895823
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (int): The first argument.
        arg2 (str): The second argument.
        arg3 (list): The third argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `arg2` is equal to `arg1`.
    """
    doc = GoogleParser().parse(docstring)
    assert doc.short_description == "This is a short description."
    assert doc.long_description == "This is a long description."
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3

# Generated at 2022-06-17 18:14:39.979157
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta[0].args == ['param', 'arg1 (str)']
    assert docstring.meta[0].description == "Description of arg1."
    assert docstring.meta[0].arg_name == "arg1"

# Generated at 2022-06-17 18:14:54.273519
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    This is a test docstring.

    This is a long description.

    Args:
        arg1 (str): The first argument.
        arg2 (int): The second argument.
        arg3 (bool): The third argument.

    Returns:
        str: The return value.
    '''

# Generated at 2022-06-17 18:15:03.510064
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        str: Description of return value.

    Raises:
        ValueError: If arg1 is empty.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ['param', 'arg1 (str)']

# Generated at 2022-06-17 18:15:15.147816
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a docstring.

    This is a long description.

    Args:
        arg1 (str): Description of arg1.
        arg2 (int): Description of arg2.

    Returns:
        int: Description of return value.

    Raises:
        ValueError: If something bad happens.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a docstring."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description
    assert docstring.blank_after_long_description
    assert len(docstring.meta) == 4
    assert docstring.meta[0].args == ["param", "arg1 (str)"]

# Generated at 2022-06-17 18:15:23.512262
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a test.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (str): This is arg2.

    Returns:
        str: This is a return.
    """
    ret = GoogleParser().parse(text)
    assert ret.short_description == "This is a test."
    assert ret.long_description == "This is a long description."
    assert len(ret.meta) == 3
    assert ret.meta[0].args == ["param", "arg1 (str)"]
    assert ret.meta[0].description == "This is arg1."
    assert ret.meta[1].args == ["param", "arg2 (str)"]
    assert ret.meta[1].description == "This is arg2."
    assert ret.meta

# Generated at 2022-06-17 18:15:45.226339
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.
        arg3 (str, optional): This is arg3.

    Returns:
        str: This is the return value.

    Raises:
        ValueError: If something bad happens.
    """
    docstring = GoogleParser().parse(text)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert len(docstring.meta) == 4

# Generated at 2022-06-17 18:15:56.622747
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n") == Docstring()
    assert GoogleParser().parse("\n\n\n\n\n\n\n\n") == Docstring()

# Generated at 2022-06-17 18:16:06.303584
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a short description.

    This is a long description.

    Args:
        arg1 (str): This is arg1.
        arg2 (int): This is arg2.
        arg3 (str, optional): This is arg3.
        arg4 (str, optional): This is arg4. Defaults to 'default'.

    Returns:
        str: This is return.

    Raises:
        ValueError: This is exception.
    """
    docstring = GoogleParser().parse(docstring)
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-17 18:16:16.021493
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """
    This is a docstring.

    Args:
        arg1 (str): The first argument.
        arg2 (str): The second argument.

    Returns:
        str: The return value.

    Raises:
        ValueError: If `bar` is equal to `baz`.
    """