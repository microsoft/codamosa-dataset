

# Generated at 2022-06-25 16:23:37.166481
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert True
    #assert False
    #assert False


# Generated at 2022-06-25 16:23:43.932894
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """First line of the docstring example.

    Parameters
    ----------
    arg1 : int
        Description of `arg1` (with typos).
    arg2 : str
        Description of `arg2`.

    Returns
    -------
    int
        Description of return value.

    See Also
    --------
    otherfunc : description of `otherfunc`
    thirdfunc, fourthfunc, fifthfunc
        Description of these functions.

    Examples
    --------
    Examples should be written in doctest format, and should illustrate how
    to use the function.

    >>> a = [1, 2, 3]
    >>> print([x + 3 for x in a])
    [4, 5, 6]

    """

    parser = GoogleParser()

    docstring = parser.parse(text)

# Generated at 2022-06-25 16:23:47.665098
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    parser.parse("""\
Work out the sum of the squares of the digits of a number.

Examples:

  >>> from brownie.test import given
  >>> from hypothesis import strategies as st
  >>> from . import fixture

  >>> @given(st.integers())
  ... def test_sum_of_squares_of_digits(n):
  ...     assert n == fixture(n)
  ...     assert n == 500

"""
                 )


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:23:59.976507
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    docstring_0 = parser_0.parse("foo")
    assert docstring_0.short_description == "foo"
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []
    assert docstring_0.signature is None

    # Given a docstring with a blank after the short description
    parser_1 = GoogleParser()
    docstring_1 = parser_1.parse("foo\n\nbar")
    assert docstring_1.short_description == "foo"
    assert docstring_1.long_description == "bar"
    assert docstring_1.blank_after_short_description is True


# Generated at 2022-06-25 16:24:11.389055
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser(title_colon=True)
    doc = """
        A test docstring.

        Arguments:
            arg1 (str): first arg
        """
    parsed = g.parse(doc)
    assert parsed.short_description == "A test docstring."
    assert parsed.blank_after_short_description == False
    assert parsed.blank_after_long_description == False
    assert parsed.long_description == None
    assert len(parsed.meta) == 1
    assert parsed.meta[0].args == ['param', 'arg1 (str)']
    assert parsed.meta[0].description == 'first arg'
    assert isinstance(parsed.meta[0], DocstringParam)
    assert parsed.meta[0].arg_name == 'arg1'
    assert parsed.meta[0].type

# Generated at 2022-06-25 16:24:21.171750
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser(title_colon=True)
    docstring_text_0 = "parses google style docstrings into its components"
    docstring_text_1 = """
    parses google style docstrings into its components
    
    """
    docstring_text_2 = """\
    parses google style docstrings into its components
    
    Arguments:
        text (str): text to parse
    
    Returns:
        Docstring: parsed docstring
        """
    docstring_text_3 = """\
    parses google style docstrings into its components
    
    Args:
        text (str): text to parse
    
    Returns:
        Docstring: parsed docstring\
    """

# Generated at 2022-06-25 16:24:23.929742
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_data = inspect.getsource(GoogleParser) + inspect.getsource(Section)
    assert len(parse(test_data).meta) == 5, "Test parser does not work"

# Generated at 2022-06-25 16:24:24.797436
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("A class")


# Generated at 2022-06-25 16:24:37.937454
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    docstring = """
        Computes the ``A*B``.

        Description line 1.
        Description line 2.

        Args:
            a: Description of ``a``.
            b: Description of ``b``.

        Returns:
            Numpy array:
                Description of return value.

        Raises:
            ValueError: If ``a < 0``.

        .. note::
            This is a note.
    """

    ret = parser.parse(docstring)

    posts = []
    for meta in ret.meta:
        posts.append(meta)

    # Solution

# Generated at 2022-06-25 16:24:51.169120
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Docstring for parse() method of class GoogleParser
    :returns: parsed docstring
    """
    # Setup
    parser = GoogleParser()

    # Exercise
    doc = parser.parse(text)

    # Verify
    assert doc.long_description == None
    assert doc.short_description == "Docstring for parse() method of class GoogleParser"
    assert doc.blank_after_long_description == False
    assert doc.blank_after_short_description == False
    assert isinstance(doc.meta, list)
    assert len(doc.meta) == 1
    assert doc.meta[0].args == ['returns', ':returns:']
    assert isinstance(doc.meta[0], DocstringReturns)
    assert doc.meta[0].description == "parsed docstring"

# Generated at 2022-06-25 16:24:58.405702
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:25:06.317505
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)
    str_1 = ' Parameters\n----------\nparam1 : array_like\n    first param\nparam2 : array_like\n    second param\nReturns\n-------\nout : int\n    the result'
    docstring_1 = parse(str_1)



# Generated at 2022-06-25 16:25:11.043595
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Assign arguments
    str_0 = 'x|D,~">LWbkU9>p'
    # Call method
    expected = parse(str_0)
    # Assert result
    assert str_0 == expected.short_description



# Generated at 2022-06-25 16:25:19.004059
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = GoogleParser().parse(str_0)


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:25:20.697986
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert False



# Generated at 2022-06-25 16:25:22.123185
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = GoogleParser().parse('')


# Generated at 2022-06-25 16:25:33.531862
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = ''
    docstring_0 = GoogleParser().parse(str_0)
    str_1 = '    """A docstring to test."""'
    docstring_1 = GoogleParser().parse(str_1)
    str_2 = '    """A docstring to test.\n\n    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n    '
    docstring_2 = GoogleParser().parse(str_2)

# Generated at 2022-06-25 16:25:36.585524
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_obj = GoogleParser()
    # Test case 0
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parser_obj.parse(str_0)



# Generated at 2022-06-25 16:25:39.348266
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:25:50.322021
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()
    docstring = parse("""\
        Creates a new :class:`Client` instance.

        Args:
            host (str): The server to connect to.
            port (int, optional): The port to connect to.
            user (str, optional): The username to auth with.
            password (str, optional): The password to use.

        Returns:
            Client: A new instance of :class:`Client`.
        """)
    assert docstring.short_description == "Creates a new :class:`Client` instance."
    assert docstring.blank_after_short_description

# Generated at 2022-06-25 16:25:58.223014
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    try:
        str_0 = 'x|D,~">LWbkU9>p'
        docstring_0 = GoogleParser().parse(str_0)

        return 'Success'
    except:
        return 'Failed'


# Generated at 2022-06-25 16:25:59.297518
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # TODO
    pass

# Generated at 2022-06-25 16:26:02.442750
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:26:14.182522
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 1
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = GoogleParser().parse(str_0)
    str_1 = 'x|D,~">LWbkU9>p'
    assert docstring_0.short_description == str_1
    str_2 = None
    assert docstring_0.long_description == str_2
    bool_0 = False
    assert docstring_0.blank_after_short_description == bool_0
    bool_1 = False
    assert docstring_0.blank_after_long_description == bool_1
    int_0 = 0
    assert len(docstring_0.meta) == int_0

    # Test 2

# Generated at 2022-06-25 16:26:14.794932
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert False


# Generated at 2022-06-25 16:26:23.154131
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_1 = 'Qh>s8H!_Mzw$)Z#'
    docstring_1 = parse(str_1)
    assert docstring_1.long_description == None
    assert docstring_1.short_description == None
    assert docstring_1.blank_after_short_description == None
    assert docstring_1.blank_after_long_description == None
    assert len(docstring_1.meta) == 0

# Unit test

# Generated at 2022-06-25 16:26:27.318598
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = '>w}0Q0I.q\nqQj9XgZ[\n\n'
    parser_0 = GoogleParser()
    docstring_0 = parser_0.parse(str_0)


# Generated at 2022-06-25 16:26:31.278264
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Create an instance of GoogleParser
    google_parser = GoogleParser()

    # Test case 0
    test_case_0()


# Generated at 2022-06-25 16:26:32.399623
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()

# Generated at 2022-06-25 16:26:44.252704
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)
    str_1 = '#[XG,I]v0'
    docstring_1 = parse(str_1)
    str_2 = 'DyQ1XRU'
    docstring_2 = parse(str_2)
    str_3 = 'JU'
    docstring_3 = parse(str_3)
    str_4 = 'M'
    docstring_4 = parse(str_4)
    str_5 = '#v'
    docstring_5 = parse(str_5)
    str_6 = 'PzV'
    docstring_6 = parse(str_6)
    str_7 = 'PEjD'
    docstring

# Generated at 2022-06-25 16:27:05.795377
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

# Test with pytest
if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:27:10.003701
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    u"""Test if parse(str_0) doesn't fail"""
    docstring_0 = test_case_0()


# Generated at 2022-06-25 16:27:19.458494
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    class_str = """
    Class description.
    """
    class_meta = parser.parse(class_str).meta[0]
    assert class_meta.args == ['class']
    assert class_meta.description == 'Class description.'

    function_str = """
    Function description.

    Parameters
    ----------
    param1 : int
        Description of param1.

    param2 : float
        Description of param2.

    Examples
    --------
    Example text.

    Returns
    -------
    None.

    """
    assert parser.parse(function_str).long_description == 'Function description.'
    assert parser.parse(function_str).meta[0].arg_name == 'param1'
    assert parser.parse(function_str).meta[0].description == 'Description of param1.'


# Generated at 2022-06-25 16:27:21.671752
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:27:34.539716
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:27:37.164378
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = '6qo:vJ8G'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:27:44.571478
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_1 = 'Following namespace prefix are supported:\n'
    str_1 += '\n'
    str_1 += '* `xsd` == http://www.w3.org/2001/XMLSchema\n'
    str_1 += '* `xsi` == http://www.w3.org/2001/XMLSchema-instance\n'
    str_1 += '* `soap` == http://schemas.xmlsoap.org/soap/envelope/\n'
    str_1 += '* `soap-enc` == http://schemas.xmlsoap.org/soap/encoding/\n'
    str_1 += '* `soap-env` == http://schemas.xmlsoap.org/soap/envelope/\n'
    str

# Generated at 2022-06-25 16:27:54.514032
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse('') == Docstring()
    assert parse('a') == Docstring(
        short_description='a',
        blank_after_short_description=True,
        long_description=None
    )
    assert parse('a\n\nb') == Docstring(
        short_description='a',
        blank_after_short_description=True,
        long_description='b',
        blank_after_long_description=True
    )
    assert parse('  a') == Docstring(short_description='a')
    assert parse('a\n  b') == Docstring(
            short_description='a',
            long_description='b',
    )
    assert parse('\n a') == Docstring(short_description='a')

# Generated at 2022-06-25 16:28:06.513600
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = '\n    Process data with: \n    \n    Example:: \n    \n        from test.package import *\n        test.package.print_err("Hello World")\n        \n    \n    \n    * Print Error message to the console\n    * Print the file name where it is called from\n    * Print a line number in the file where it is called from\n    \n    \n    Args:\n        \n        str (str): An error message to display\n    \n    \n    Returns:\n        \n        int: 0 on success, None if not called correctly\n    \n    \n'

# Generated at 2022-06-25 16:28:14.545605
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 1
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 0

    # Test case 2
    str_0 = 'D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

    assert docstring_0.short_description == 'D'
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False


# Generated at 2022-06-25 16:28:38.931027
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Variables
    text_0 = 'w|pT`bv#t{B@/"'
    text_1 = '=v@q3pLZg4Y4|~'
    text_2 = 'E!_/rB1X<-#*?"'
    text_3 = 'b!N6]P3ScU3:6U'
    text_4 = '1gUCx%Zo*PfYmQ'
    text_5 = 'y0^ymTv~gWZVd|'
    text_6 = 'vOU%"WyV8Ys]w%'
    text_7 = '4C?|#Ri9QF>dvj'
    text_8 = '&q3_^F0$a-@EZ6'
    text_

# Generated at 2022-06-25 16:28:42.758513
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    at_least_one_passed = False
    try:
        test_case_0()
        at_least_one_passed = True
    except:
        pass

    assert at_least_one_passed


# Generated at 2022-06-25 16:28:47.140302
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)
    str_1 = 'x|D,~">LWbkU9>p'
    docstring_1 = parse(str_1)


# Generated at 2022-06-25 16:28:48.684124
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)



# Generated at 2022-06-25 16:29:00.307420
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_1 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_1)
    str_2 = 'x|D,~">LWbkU9>p'
    docstring_1 = parse(str_2)
    str_3 = 'x|D,~">LWbkU9>p'
    docstring_2 = parse(str_3)
    str_4 = 'x|D,~">LWbkU9>p'
    docstring_3 = parse(str_4)
    str_5 = 'x|D,~">LWbkU9>p'
    docstring_4 = parse(str_5)
    str_6 = 'x|D,~">LWbkU9>p'
    doc

# Generated at 2022-06-25 16:29:06.303140
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:29:18.443383
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = '    """Wraps a method so that it can be invoked asynchronously.\n\n      The wrapped method returns a future indicating the outcome of the call.\n\n      Args:\n        fn: A bound method to wrap.\n\n      Returns:\n        A function taking the same arguments as the original method and\n        returning a Future.\n      """\n  '
    str_1 = '    """\n\n      Wraps a method so that it can be invoked asynchronously.\n\n      The wrapped method returns a future indicating the outcome of the call.\n\n      Args:\n        fn: A bound method to wrap.\n\n      Returns:\n        A function taking the same arguments as the original method and\n        returning a Future.\n      """\n  '

# Generated at 2022-06-25 16:29:24.355882
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Create instance of class GoogleParser
    google_parser_0 = GoogleParser()

    # Create a string of docstring
    str_0 = 'x|D,~">LWbkU9>p'

    # Call the method parse of class GoogleParser
    # with str_0 as input
    docstring_0 = google_parser_0.parse(str_0)

    # Assert that __str__ of docstring_0 is equal to
    # 'x|D,~">LWbkU9>p'
    assert str(docstring_0) == 'x|D,~">LWbkU9>p'

# Generated at 2022-06-25 16:29:36.185872
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'decompress_request(self, request):\n    Decompress a gzipped request. The following headers\n    are added to the request:\n\n    - ``X-Zappa-Throw-Errors``: If the response is not valid gzip, an exception is raised by the WSGI\n      server (``gunicorn``) and this error message is returned to the client.\n    - ``Content-Length``: The original size of the compressed body. This can be used by the client to\n      determine if the response is valid gzip.\n'
    docstring_0 = parse(str_0)
    assert not docstring_0.short_description
    assert not docstring_0.long_description
    assert docstring_0.blank_after_short_description
    assert docstring_0.blank_after

# Generated at 2022-06-25 16:29:39.904531
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:29:58.832694
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print('Testing GoogleParser.parse')
    test_case_0()


if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:01.175948
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:14.516015
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:30:17.462975
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:30:18.470099
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert 1==2

# Generated at 2022-06-25 16:30:21.356477
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parser.parse(str_0)
    assert isinstance(docstring_0, Docstring)



# Generated at 2022-06-25 16:30:24.170928
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:30:29.410446
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str = 'x|D,~">LWbkU9>p'
    googleParser = GoogleParser()
    docstring = googleParser.parse(str)
    assert docstring.short_description == 'x|D,~">LWbkU9>p'
    assert docstring.long_description == None


# Generated at 2022-06-25 16:30:35.720099
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parser_0.parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 0
    # assert docstring_0.meta[0].description is None



# Generated at 2022-06-25 16:30:38.382971
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:31:14.500341
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()

# Generated at 2022-06-25 16:31:16.969367
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:31:19.792607
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:31:23.583951
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import parse
    case_0 = 'x|D,~">LWbkU9>p'

    expected_0 = Docstring(
        short_description=None,
        long_description=None,
        meta=[],
    )
    actual_0 = parse(case_0)
    assert actual_0 == expected_0

# Generated at 2022-06-25 16:31:29.968136
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == str_0
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert bool(docstring_0.meta) == False

# Testing class GoogleParser for method add_section

# Generated at 2022-06-25 16:31:36.047414
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:31:37.424212
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()

# Script to test class GoogleParser

# Generated at 2022-06-25 16:31:49.131248
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    case_0 = '\n    x|D,~">LWbkU9>p\n\n'
    result_0 = GoogleParser().parse(case_0)
    assert result_0.short_description is None
    assert result_0.long_description is None
    assert result_0.blank_after_short_description is None
    assert result_0.blank_after_long_description is None
    assert len(result_0.meta) == 0

# Generated at 2022-06-25 16:31:58.261006
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = ''
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.meta == []
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    str_1 = 'Mh#0X\x0bHc%P'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Mh#0X\x0bHc%P'
    assert docstring_1.long_description == None
    assert docstring_1.meta == []
    assert docstring_1.blank_after_short_description == False
    assert docstring_1

# Generated at 2022-06-25 16:32:01.713950
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'x|D,~">LWbkU9>p'
    docstring_0 = parse(str_0)

