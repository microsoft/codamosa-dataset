

# Generated at 2022-06-25 16:23:54.523090
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    s = """Summarize what this function/method does.
        Explain the parameters and types of the returned value.
        Note that the function/method documentation should go before the
        implementation in the source file.
        """

    g = GoogleParser()
    docstring = g.parse(s)

    assert docstring.short_description == "Summarize what this function/method does."
    assert docstring.long_description == """
        Explain the parameters and types of the returned value.
        Note that the function/method documentation should go before the
        implementation in the source file.
        """
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False

# Generated at 2022-06-25 16:24:04.824034
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = """This is a simple function:

    return x
    """
    google_parser_0 = GoogleParser()
    result_0 = google_parser_0.parse(text_0)
    assert str(result_0) == "This is a simple function"
    assert result_0.short_description == "This is a simple function"
    assert result_0.long_description == None
    assert not result_0.blank_after_short_description
    assert result_0.blank_after_long_description
    assert len(result_0.meta) == 0

    text_1 = """This is a simple function
    """
    google_parser_1 = GoogleParser()
    result_1 = google_parser_1.parse(text_1)
    assert str(result_1) == "This is a simple function"


# Generated at 2022-06-25 16:24:14.509700
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Check that valid input is processed correctly
    assert parse("test") == Docstring(
        short_description='test',
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    # Check that invalid input is processed correctly
    assert parse(4) == Docstring()

    # Check that valid input is processed correctly
    assert parse("test") == Docstring(
        short_description='test',
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    # Check that invalid input is processed correctly
    assert parse(4) == Docstring()

    # Check that valid input is processed correctly
    assert parse("test") == Docstring

# Generated at 2022-06-25 16:24:25.253854
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    for section_type in SectionType:
        for num_sections in range(5):
            title_colon = random.choice([True, False])
            sections = DEFAULT_SECTIONS[random.randint(0, len(DEFAULT_SECTIONS))]
            docstringClass = GoogleParser(sections, title_colon)
            text = '\n'.join([generate_docstring_string() for i in range(num_sections)])
            parsedDocstring = parse(text)
            
            # check that parsed docstring is a Docstring instance
            assert isinstance(parsedDocstring, Docstring)

            # test that parsedDocstring.short_description is of type str
            assert isinstance(parsedDocstring.short_description, str)
            
            # test that parsedDocstring.long_description is of type str

# Generated at 2022-06-25 16:24:37.770946
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    desc = """Summary line.

    Extended description of function.

    Parameters
    ----------
    arg1 : int
        Description of `arg1`
    arg2 : str
        Description of `arg2`

    Returns
    -------
    int
        Description of return value

    """
    doc = GoogleParser().parse(desc)

    assert doc.short_description == "Summary line."
    assert doc.long_description == "Extended description of function."

    assert doc.blank_after_short_description
    assert doc.blank_after_long_description

    assert doc.meta[0].arg_name == "arg1"
    assert doc.meta[1].arg_name == "arg2"
    assert doc.meta[2].type_name == "int"

# Generated at 2022-06-25 16:24:51.170300
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    A method decorator that takes a key word argument and a value, e.g.

    @cache(timeout=10)

    If the decorated method is called with a matching keyword argument,
    its return value is returned from the cache.  Otherwise the function
    is called like normal and the return value is inserted into the cache
    under the specified name.

    The timeout parameter is optional and specifies how many seconds the
    result should remain in the cache.
    """
    gparser = GoogleParser()
    docstring = gparser.parse(text)
    assert docstring.short_description == 'A method decorator that takes a key word argument and a value, e.g.'
    assert docstring.short_description == 'A method decorator that takes a key word argument and a value, e.g.'

# Generated at 2022-06-25 16:24:51.818294
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    pass

# Generated at 2022-06-25 16:25:02.791859
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''\
    Execute a query that will return a result set.
    This should only be used for queries that return a result set, i.e.
    SELECT, SHOW, DESCRIBE, EXPLAIN. Do not run INSERT/UPDATE/DELETE
    queries with this.
    """
    '''
    parser = GoogleParser()
    result = parser.parse(text)
    assert result.short_description == 'Execute a query that will return a result set.'
    assert result.blank_after_short_description == False
    assert result.long_description == 'This should only be used for queries that return a result set, i.e.\nSELECT, SHOW, DESCRIBE, EXPLAIN. Do not run INSERT/UPDATE/DELETE\nqueries with this.'
    assert result.blank_after_long

# Generated at 2022-06-25 16:25:11.979166
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    myGoogleParser = GoogleParser();
    result = myGoogleParser.parse("This is a test docstring");
    assert(result.short_description == "This is a test docstring");
    assert(result.long_description == None);
    assert(result.blank_after_short_description == False);
    assert(result.blank_after_long_description == True);
    assert(len(result.meta) == 0);


# Generated at 2022-06-25 16:25:26.104060
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case with a docstring containing both a short and long description, returns section,
    # and example section
    google_test_docstring = '''
    This is the short description.

    This is the long description. It can hold multiple lines.

        >>> print("example")
        42

    :returns: the answer
    '''
    google_test_docstring_parser = parse(google_test_docstring)
    assert google_test_docstring_parser.short_description == 'This is the short description.'
    assert google_test_docstring_parser.long_description == 'This is the long description. It can hold multiple lines.'
    assert google_test_docstring_parser.blank_after_short_description is True
    assert google_test_docstring_parser.blank_after_long_description is False

    # Test case

# Generated at 2022-06-25 16:25:45.781077
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    docstring = """Google-style docstring parsing.
    """
    expected_output = Docstring(
        short_description="Google-style docstring parsing.",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        sections={},
        meta=[],
    )
    actual_output = google_parser_0.parse(docstring)

    assert expected_output == actual_output

# Generated at 2022-06-25 16:25:53.425614
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse("This is docstring - 1") == Docstring(
        short_description="This is docstring - 1"
    )
    assert google_parser_0.parse("This is docstring - 2") == Docstring(
        short_description="This is docstring - 2"
    )
    assert google_parser_0.parse("This is docstring - 3") == Docstring(
        short_description="This is docstring - 3"
    )
    assert google_parser_0.parse("This is docstring - 4") == Docstring(
        short_description="This is docstring - 4"
    )

# Generated at 2022-06-25 16:26:01.193897
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    with open("test_cases/test_case_0.txt", "r") as file_object:
        lines = file_object.readlines()
        s = ""
        for line in lines:
            s += line
        docstring_0 = google_parser_0.parse(s)
    assert docstring_0 is not None

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:26:13.006708
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:26:20.688806
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse(
        'This is a sample docstring.\nIt is indented properly\n    '
    ) == Docstring(
        short_description='This is a sample docstring.',
        long_description='It is indented properly',
        blank_after_long_description=True,
        blank_after_short_description=False,
        meta=[],
    )
    assert google_parser_0.parse('just a short description') == Docstring(
        short_description='just a short description',
        long_description=None,
        blank_after_long_description=False,
        blank_after_short_description=False,
        meta=[],
    )

# Generated at 2022-06-25 16:26:31.026373
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("\n\nTesting method parse of class GoogleParser:")
    docstring_0 = "test_docstring"
    google_parser_0 = GoogleParser()

# Generated at 2022-06-25 16:26:43.033899
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    docstring_1 = google_parser_1.parse("")
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is None
    assert docstring_1.blank_after_long_description is None
    assert not docstring_1.meta
    docstring_1 = google_parser_1.parse("  \n")
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is None
    assert docstring_1.blank_after_long_description is None
    assert not docstring_1.meta
    docstring_1 = google_parser_1.parse

# Generated at 2022-06-25 16:26:47.864435
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse(str())
    # Assertions


# Generated at 2022-06-25 16:26:58.113406
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Test case 0: test GoogleParser.parse() with a no_description docstring
    # Example:
    #   def func0():
    #     """
    #     Raises:
    #         KeyError: If key is not found.
    #     """
    #
    #     pass
    no_description_docstring = \
"""
Raises:
    KeyError: If key is not found.
"""
    google_parser_0 = GoogleParser()
    result_0 = google_parser_0.parse(no_description_docstring)

# Generated at 2022-06-25 16:27:01.081885
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "Test docstring"
    google_parser_0.parse(text_0)
    return



# Generated at 2022-06-25 16:27:29.201766
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "  str\n   int  ?\n"
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description ==  None
    assert docstring_0.long_description ==  None
    assert docstring_0.blank_after_short_description ==  False
    assert docstring_0.blank_after_long_description ==  False
    assert docstring_0.meta[0].args ==  ['param', '  str\n']
    assert docstring_0.meta[0].arg_name ==  'str'
    assert docstring_0.meta[0].description ==  None
    assert docstring_0.meta[0].type_name ==  None

# Generated at 2022-06-25 16:27:41.372883
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()

# Generated at 2022-06-25 16:27:43.143517
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()

# Generated at 2022-06-25 16:27:50.749027
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    docstring_0 = "short desc\n\nlong desc"
    docstring_1 = google_parser_0.parse(docstring_0)

    assert docstring_1.short_description == "short desc"
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.long_description == "long desc"
    assert docstring_1.blank_after_long_description == True
    assert docstring_1.meta == []

# Generated at 2022-06-25 16:27:53.588623
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    t = "TODO(pyera)"
    r = GoogleParser().parse(t)
    assert r.short_description == "TODO(pyera)"


# Generated at 2022-06-25 16:27:55.244308
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Missing section Should raise ParseError
    google_parser_1 = GoogleParser()
    assert google_parser_1.parse("") == "{}"


# Generated at 2022-06-25 16:28:07.468178
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    T.assertEqual(
        google_parser_0.parse("Raises:\n    ValueError: If this or that"),
        Docstring(
            short_description=None,
            meta=[
                DocstringRaises(
                    args=['raises', 'ValueError'],
                    description="If this or that",
                    type_name="ValueError",
                )
            ],
        ),
    )

# Generated at 2022-06-25 16:28:19.788273
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:28:32.685714
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser = GoogleParser()

    assert google_parser.parse("test") == Docstring(
        short_description="test",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

    assert google_parser.parse("test\n") == Docstring(
        short_description="test",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )


# Generated at 2022-06-25 16:28:42.904356
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    print("Running GoogleParser parse() test case #0...")
    test_case_0()
    print("GoogleParser parse() test case #0 passed!")
    print("Running GoogleParser parse() test case #1...")
    test_case_1()
    print("GoogleParser parse() test case #1 passed!")
    print("Running GoogleParser parse() test case #2...")
    test_case_2()
    print("GoogleParser parse() test case #2 passed!")
    print("Running GoogleParser parse() test case #3...")
    test_case_3()
    print("GoogleParser parse() test case #3 passed!")
    print("Running GoogleParser parse() test case #4...")
    test_case_4()

# Generated at 2022-06-25 16:29:02.842196
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = "  Blah\n  bleh.\n\nblah.\n    blah bleh blah.\n\n  blah blah blah:\n    blah blah blah.\n\nblah bleh blah:\n  blah blah blah.\n\n"

    ret = google_parser_0.parse(text)
    assert ret.short_description == "Blah bleh."
    assert ret.long_description == "blah.\nblah bleh blah."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False
    assert ret.meta[0].args == ["blah blah blah"]
    assert ret.meta[0].description == "blah blah blah."

# Generated at 2022-06-25 16:29:06.209578
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    test_0 = "The :class:`~xyz.abc` is a good thing."
    result = google_parser_0.parse(test_0)

# Generated at 2022-06-25 16:29:13.479939
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_str = """Parses the docstring.

    Sections supported:
    - parameters
    - type parameters
    - raises
    - returns
    - examples

    :param text: docstring to parse
    :raises DocstringParserError: if the docstring is badly formatted

    """
    # Actual call to method
    out = google_parser_0.parse(text_str)

    # Show the results
    print(out)



# Generated at 2022-06-25 16:29:23.424536
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    meta = google_parser.parse('Converts an image array to a callable.\n')
    assert (meta.short_description == 'Converts an image array to a callable.')
    assert (meta.long_description == None)
    assert (meta.blank_after_short_description == False)
    assert (meta.blank_after_long_description == False)
    assert (len(meta.meta) == 0)

    meta = google_parser.parse(
        'Converts an image array to a callable.\n\n')
    assert (meta.short_description == 'Converts an image array to a callable.')
    assert (meta.long_description == None)
    assert (meta.blank_after_short_description == True)

# Generated at 2022-06-25 16:29:25.404327
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    # Test
    assert google_parser_0.parse("") is not None

# Generated at 2022-06-25 16:29:37.478000
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_1 = GoogleParser()
    google_parser_2 = GoogleParser()
    google_parser_3 = GoogleParser()
    google_parser_4 = GoogleParser()
    google_parser_5 = GoogleParser()
    google_parser_6 = GoogleParser()
    google_parser_7 = GoogleParser()
    google_parser_8 = GoogleParser()
    google_parser_9 = GoogleParser()
    google_parser_10 = GoogleParser()
    google_parser_11 = GoogleParser()
    google_parser_12 = GoogleParser()
    google_parser_13 = GoogleParser()
    google_parser_14 = GoogleParser()
    google_parser_15 = GoogleParser()
    google_parser_16 = GoogleParser()
    google_parser_17 = GoogleParser()
   

# Generated at 2022-06-25 16:29:50.248849
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()

    # Check input docstring_0
    docstring_0 = """Google-style docstring parsing."""
    docstring_0_out = google_parser.parse(docstring_0)
    docstring_0_expected = Docstring()
    docstring_0_expected.short_description = "Google-style docstring parsing."
    docstring_0_expected.long_description = ""
    assert docstring_0_expected == docstring_0_out

    # Check input docstring_1
    docstring_1 = """Google-style docstring parsing.

    :param sections: Recognized sections or None to defaults.
    :param title_colon: require colon after section title.
    :returns: parsed docstring"""
    docstring_1_out = google_parser.parse(docstring_1)

# Generated at 2022-06-25 16:29:53.976100
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    outstr = "Short description.\n"
    google_parser_1.parse(outstr)
    print("Test case passed successfully.")


# Generated at 2022-06-25 16:30:02.146574
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    assert google_parser.parse("") == Docstring()
    assert google_parser.parse("One line.") == Docstring(
        short_description="One line.", long_description=None,
    )
    assert google_parser.parse("One line.\n\n") == Docstring(
        short_description="One line.", long_description=None,
    )
    assert google_parser.parse("One line.\n\n\n") == Docstring(
        short_description="One line.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

# Generated at 2022-06-25 16:30:15.805803
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Test cases
    text_0 = None
    text_1 = ""
    text_2 = "Testing\n        Adds two numbers together.\n\n        Args:\n            a (int): The first param.\n            b (int): The second param.\n\n        Returns:\n            The sum.\n        "
    text_3 = "Testing\n        Adds two numbers together.\n\n        Args:\n            a (int): The first param.\n            b (int): The second param.\n\n        Returns:\n            The sum.\n        "

# Generated at 2022-06-25 16:30:48.395404
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_parse_0 = google_parser_0.parse("short\n\nlong\n\n")
    assert google_parser_parse_0.short_description == "short"
    assert google_parser_parse_0.blank_after_short_description == True
    assert google_parser_parse_0.blank_after_long_description == True
    assert google_parser_parse_0.long_description == "long"
    assert google_parser_parse_0.meta == []
    google_parser_parse_1 = google_parser_0.parse("short\n\nlong\n\nParams:\n\n")
    assert google_parser_parse_1.short_description == "short"
    assert google_parser_parse_1.blank_after_short_

# Generated at 2022-06-25 16:30:52.517238
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    source = '''
    Example docstring.

    This is another line.
    '''
    google_parser_1 = GoogleParser()
    print("Docstring parsed: ")
    print(google_parser_1.parse(source))

# Generated at 2022-06-25 16:30:56.636139
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()


# Generated at 2022-06-25 16:31:04.193124
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = '''
    Short description.
    Long description.
    '''
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == 'Short description.'
    assert docstring_0.long_description == 'Long description.'
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True


# Generated at 2022-06-25 16:31:10.492738
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'A function\n'
    text += '\n'
    text += 'Args:\n'
    text += '    x (int, optional): A number.\n'
    text += '    y (float, optional): Another number. Defaults to 2.5.\n'
    text += '    z (str): A string.\n'
    text += '\n'
    text += 'Returns:\n'
    text += '    tuple: A tuple of results.\n'
    text += '\n'
    text += 'Raises:\n'
    text += '    AnotherError: Some error.\n'
    text += '    AnotherError: Some error.\n'
    text += '\n'
    text += 'Example:\n'
    text += '    >>> print(x)\n'
    text

# Generated at 2022-06-25 16:31:23.107840
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Init GoogleParser and assign docstring
    google_parser_0 = GoogleParser()

# Generated at 2022-06-25 16:31:32.828053
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    """
    def parse(self, text: str) -> Docstring:
        """

# Generated at 2022-06-25 16:31:44.627241
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser."""
    # testing for normal case with arguments

    text = """
    Parse the Google-style docstring into its components.
    :param text: docstring to parse
    :returns: parsed docstring
    """
    google_parser_0 = GoogleParser()
    result = google_parser_0.parse(text)
    assert result is not None
    assert result.meta is not None
    assert len(result.meta) == 3
    assert result.meta[0].description is not None
    assert result.meta[0].description == "Parse the Google-style docstring into its components."
    assert result.meta[1].is_optional is not None
    assert result.meta[1].is_optional == False
    assert result.meta[1].arg_name is not None

# Generated at 2022-06-25 16:31:52.201340
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()

    # Call method parse of google_parser_1
    docstring_2 = google_parser_1.parse("")

    assert docstring_2.short_description == None
    assert docstring_2.long_description == None
    assert docstring_2.blank_after_short_description == False



# Generated at 2022-06-25 16:31:58.746310
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "This is the title\n(Optional) args: an int.\n:param a: (Optional) an int\n:param b: a str. Defaults to 'default'.\n:returns: True if greater than 0.\n:raises ValueError: if less than 0."
    res = parse(text)
    assert res.short_description == "This is the title"
    assert res.long_description == "(Optional) args: an int."
    assert res.blank_after_long_description
    assert not res.blank_after_short_description
    assert len(res.meta) == 4
    assert res.meta[0].args == ['param', 'a']
    assert res.meta[0].description == ""
    assert res.meta[0].arg_name == "a"

# Generated at 2022-06-25 16:32:52.669623
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse("""
    Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """) == Docstring(
        short_description="Parse the Google-style docstring into its components.",
        long_description=(
            "parsed docstring"
        ),
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringReturns(
                args=["returns", "parsed docstring"],
                description="parsed docstring",
                type_name="parsed docstring",
                is_generator=False,
            )
        ],
    )




# Generated at 2022-06-25 16:32:56.155083
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    func0 = google_parser.parse
    param_0 = 'Args:          param1: The first parameter.\n'
    func0(param_0)


# Generated at 2022-06-25 16:33:02.175949
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #
    # A method to parse Google-style docstrings into a Docstring object.
    #
    # """Parses Google-style docstrings.
    #
    # Docstrings should have the general form:
    #
    #     Short summary.
    #
    #     Extended description.
    #
    #     Args:
    #       arg1: Description of arg1.
    #       arg2: Description of arg2.
    #     Returns:
    #       Description of return value.
    # """
    google_parser_0 = GoogleParser()

# Generated at 2022-06-25 16:33:11.619869
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    # Call method
    result = google_parser_0.parse('The short description.\n\nThe long description.\n\nArgs:\n    arg1 (str): the first argument.\n    arg2 (optional, str): the second argument, defaults to "foo".\n\nReturns:\n    int: the return value.\n')

    # Check types
    assert isinstance(result, Docstring, 'GoogleParser.parse does not return Docstring object')

    # Check content of Docstring
    assert result.short_description == 'The short description.'
    assert result.long_description == 'The long description.'
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True

    assert len(result.meta) == 2
    meta_