

# Generated at 2022-06-25 16:23:49.362278
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj_0 = GoogleParser(DEFAULT_SECTIONS, True)
    str_arg_0 = '''Returns:\n    An array\n    of stuff.'''
    Docstring_ret_0 = obj_0.parse(str_arg_0)
    assert(str(type(Docstring_ret_0)) == "<class 'darglint.google_docstring.Docstring'>")
    assert(Docstring_ret_0.short_description is None)
    assert(Docstring_ret_0.long_description is None)
    assert(len(Docstring_ret_0.meta) == 1)
    assert(str(type(Docstring_ret_0.meta[0])) == "<class 'darglint.google_docstring.DocstringReturns'>")

# Generated at 2022-06-25 16:23:57.365210
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse("foo")
    assert docstring_0
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []

# Generated at 2022-06-25 16:24:10.719736
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import doctest
    from .google import GoogleParser
    from .google import Docstring, DocstringMeta, DocstringParam, DocstringReturns, DocstringRaises
    doctest.run_docstring_examples(GoogleParser.parse, globals(),
                                   name="GoogleParser.parse")
    #pylint: disable=too-many-locals

# Generated at 2022-06-25 16:24:11.930848
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser: GoogleParser = GoogleParser()

    assert google_parser.parse("") == Docstring()



# Generated at 2022-06-25 16:24:15.620674
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    google_parser = GoogleParser()
    text = "Here is a test."

    # Exercise
    ret = google_parser.parse(text)

    # Verify
    assert ret.short_description == "Here is a test."
    assert ret.long_description == None
    assert ret.blank_after_short_description == False
    assert ret.blank_after_long_description == True
    assert len(ret.meta) == 0


# Generated at 2022-06-25 16:24:25.888787
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Verify with no text
    result = GoogleParser().parse("")
    assert result.long_description is None
    assert result.short_description is None
    assert result.meta == []
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    # Verify with description
    result = GoogleParser().parse(
        "This is the short description.\n\nThis is the long description."
    )
    assert result.long_description == "This is the long description."
    assert result.short_description == "This is the short description."
    assert result.meta == []
    assert result.blank_after_short_description is True
    assert result.blank_after_long_description is False
    # Verify with meta

# Generated at 2022-06-25 16:24:39.117852
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    parsed_docstring = GoogleParser().parse("")
    expected_docstring = Docstring()
    assert parsed_docstring == expected_docstring
    assert parsed_docstring.meta == []
    assert parsed_docstring.short_description == None
    assert parsed_docstring.long_description == None
    assert parsed_docstring.blank_after_short_description == False
    assert parsed_docstring.blank_after_long_description == False
    # Test case 1

# Generated at 2022-06-25 16:24:47.775913
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:25:00.497197
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    section_type_0 = SectionType.SINGULAR
    section_type_1 = SectionType.MULTIPLE
    section_type_2 = SectionType.SINGULAR_OR_MULTIPLE
    section_0 = Section("Args", "param", section_type_1)
    section_1 = Section("Returns", "returns", section_type_2)
    test_case_0 = GoogleParser([section_0, section_1])
    text = """Prints the numbers from 1 to n.

    Args:
        n: The upper limit of numbers to print.
        verbosity: level of verbosity.

    Returns:
        int: The nmber n."""

# Generated at 2022-06-25 16:25:09.524201
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser != None
    docstring = parser.parse("""
        Unit test for method parse of class GoogleParser

        :returns: parsed docstring
    """)
    assert docstring != None
    assert docstring.short_description == "Unit test for method parse of class GoogleParser"
    assert len(docstring.meta) == 1
    assert docstring.meta[0].description == "parsed docstring"
    assert docstring.meta[0].args == ['returns', ':returns: parsed docstring']
    assert docstring.meta[0].is_returns == True


# Generated at 2022-06-25 16:25:30.288842
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Tests only a few cases because none have quite the same
    # formatting, and the purpose of this class is to parse
    # the other classes' docstrings, which are tested elsewhere
    parser_0 = GoogleParser()
    parser_1 = GoogleParser()
    parser_2 = GoogleParser()
    parser_3 = GoogleParser()

    doc_0 = parser_0.parse("A short description.\n\nA long description.")
    assert doc_0.short_description == "A short description."
    assert doc_0.long_description == "A long description."
    assert doc_0.blank_after_short_description
    assert doc_0.blank_after_long_description

    doc_1 = parser_1.parse("A short description.\n\nA long description.")

# Generated at 2022-06-25 16:25:31.885049
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """"""
    ret = GoogleParser().parse(text)
    return ret


# Generated at 2022-06-25 16:25:39.656850
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    section_type_0 = SectionType.SINGULAR
    assert section_type_0 == 0
    section_type_1 = SectionType.MULTIPLE
    assert section_type_1 == 1
    section_type_2 = SectionType.SINGULAR_OR_MULTIPLE
    assert section_type_2 == 2
    section_0 = Section("example", "example", section_type_0)
    section_1 = Section("return", "return", section_type_2)
    section_2 = Section("param", "param", section_type_1)
    section_3 = Section("yields", "yields", section_type_2)
    section_4 = Section("examples", "example", section_type_0)
    section_5 = Section("Returns", "return", section_type_2)


# Generated at 2022-06-25 16:25:44.860643
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "A short summary.\n\nAnd a long one\nspanning\nmultiple lines."
    result = GoogleParser().parse(text)
    returns = None
    expected = Docstring(raises=None, returns=returns, meta=None)
    assert result == expected


# Generated at 2022-06-25 16:25:50.072169
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """
    A simple test docstring.

    For testing only.
    """
    assert parser.parse(text) == Docstring(
        short_description="A simple test docstring.",
        blank_after_short_description=True,
        long_description="For testing only.",
        blank_after_long_description=False,
        meta=[],
    )



# Generated at 2022-06-25 16:25:56.040568
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    w_func =  inspect.getfullargspec(test_case_0)
    docstring = inspect.getdoc(test_case_0)
    p_result = parser.parse(docstring)
    assert p_result.short_description == 'Unit test for method parse of class GoogleParser'

    parser = GoogleParser(title_colon=False)
    w_func =  inspect.getfullargspec(test_case_0)
    docstring = inspect.getdoc(test_case_0)
    p_result = parser.parse(docstring)
    assert p_result.short_description == 'Unit test for method parse of class GoogleParser'

# Generated at 2022-06-25 16:26:07.918963
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """
        Arguments:
            param1 (int): Description of first param.
            param2 (str, optional): Description of second param.
            param3 (int, str, optional): Description of third param.
        """
    docstring_meta = parser.parse(docstring)
    assert len(docstring_meta.meta) == 1
    assert docstring_meta.meta[0].key == "param"
    assert len(docstring_meta.meta[0].children) == 3
    assert docstring_meta.meta[0].children[0].args == ["param", "param1 (int)"]
    assert docstring_meta.meta[0].children[1].args == [
        "param",
        "param2 (str, optional)",
    ]
    assert docstring_meta.meta

# Generated at 2022-06-25 16:26:17.959974
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    title_colon_0 = True
    sections_0 = None
    text_0 = "Foobar\n"
    ret_0 = Docstring()
    ret_0.short_description = "Foobar"
    assert GoogleParser(sections_0, title_colon_0).parse(text_0) == ret_0
    title_colon_1 = True
    sections_1 = None
    text_1 = "Foobar\n\n"
    ret_1 = Docstring()
    ret_1.short_description = "Foobar"
    ret_1.blank_after_short_description = True
    assert GoogleParser(sections_1, title_colon_1).parse(text_1) == ret_1
    title_colon_2 = True
    sections_2 = None
    text_

# Generated at 2022-06-25 16:26:23.214379
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = ":return: The full filename."

    # Case 0: section_type == SectionType.SINGULAR
    try:
        parser.parse(text)
    except ParseError as error:
        assert False, error



# Generated at 2022-06-25 16:26:28.785930
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # This test case tries to run the class GoogleParser which is in parser.py
    # The method parse is the one we test and as a result,
    # it will return the definition of the class. 
    assert GoogleParser().parse.__doc__ == "Parse the Google-style docstring into its components."

# Unit test of method test_case_0 of class GoogleParser

# Generated at 2022-06-25 16:26:47.695884
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-25 16:26:53.184963
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gParser_0 = GoogleParser()
    str_0 = ""
    result = gParser_0.parse(str_0)
    exp_result = Docstring(blank_after_long_description=None, blank_after_short_description=None, long_description=None, meta=[], short_description=None)
    if result != exp_result:
        raise Exception()


# Generated at 2022-06-25 16:27:01.287634
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gparser = GoogleParser()

# Generated at 2022-06-25 16:27:08.832764
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_text = """
    Set the parameters of this estimator.

    Args:
        X: matrix-like, shape (n_samples, n_features)
            Training vector, where n_samples is the number of samples and
            n_features is the number of features.
    """

    sections = [
        Section("Args", "param", SectionType.MULTIPLE),
        Section("Example", "examples", SectionType.SINGULAR),
    ]
    parser = GoogleParser(sections)
    doc = parser.parse(doc_text)
    print(doc)



# Generated at 2022-06-25 16:27:18.389146
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "Description\n\n  Arguments: arg1 (type1): Description\n    arg2 (type2): Description\n    arg3 (type3): Description\n\n  Returns: type4\n"
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == "Description"
    assert docstring_0.long_description == ""
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is False

# Generated at 2022-06-25 16:27:29.379143
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:27:41.506461
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for condition for if not text:
    assert GoogleParser().parse(text = "") == Docstring()

    # Test for condition for if len(parts) > 1:
    assert GoogleParser().parse(text = "hello\nworld") == Docstring(
        short_description = "hello",
        long_description = "world",
        blank_after_short_description = False,
        blank_after_long_description = False)

    # Test for condition for if len(parts) > 1:
    assert GoogleParser().parse(text = "hello\n world") == Docstring(
        short_description = "hello",
        long_description = "world",
        blank_after_short_description = True,
        blank_after_long_description = False)

    # Test for condition for if len(parts) > 1:
    assert Google

# Generated at 2022-06-25 16:27:50.930975
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    string = """One-line summary that does not use variable names or the function name.

    Longer description that may include math using a LaTeX-style syntax.
    """
    obj = GoogleParser()
    actual = obj.parse(string)
    assert actual.short_description == 'One-line summary that does not use variable names or the function name.'
    assert actual.blank_after_short_description == True
    assert actual.long_description == 'Longer description that may include math using a LaTeX-style syntax.'
    assert actual.blank_after_long_description == False
    assert actual.meta == []


# Generated at 2022-06-25 16:28:01.011779
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    expected_docstring_0 = Docstring(
        short_description="compute something",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    expected_docstring_1 = Docstring(
        short_description="compute something",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )
    expected_docstring_2 = Docstring(
        short_description="compute something",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-25 16:28:11.952243
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    text_0 = "sample"
    docstring_0 = parser_0.parse(text_0)
    assert docstring_0.short_description == text_0
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == None
    assert docstring_0.meta == []

    # Test for docstring that is just short description and meta
    text_1 = "sample\n\nMeta:\n\n    - A: 10\n    - B: 20"
    docstring_1 = parser_0.parse(text_1)
    assert docstring_1.short_description == "sample"
    assert docstring_1.long_description == None

# Generated at 2022-06-25 16:28:27.044666
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("No formatting here") == Docstring(
      short_description='No formatting here'
    )
    assert parser.parse("No formatting here\nAnother line\n") == Docstring(
      short_description='No formatting here\nAnother line',
      blank_after_short_description=False,
      long_description=None,
      blank_after_long_description=False
    )
    assert parser.parse("No formatting here\n\nAnother line") == Docstring(
      short_description='No formatting here',
      blank_after_short_description=True,
      long_description='Another line',
      blank_after_long_description=False
    )

    assert parser.parse("Args:\n    foo: bar") == Docstring

# Generated at 2022-06-25 16:28:31.360337
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test function parse of class GoogleParser
    """
    section_type_0 = SectionType.SINGULAR
    text_0 = 'Parses Google-style docstrings.'
    ret_0 = GoogleParser().parse(text_0)
    assert ret_0.short_description == 'Parses Google-style docstrings.'


# Generated at 2022-06-25 16:28:42.048516
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:28:52.738104
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()

    # Test for cases of various number of sections
    for num_sections in range(0, 4):
        section_tuples = []
        for i in range(num_sections):
            section_tuples.append((f"Section{i}", f"key{i}", SectionType.MULTIPLE))
        sections = [Section(*t) for t in section_tuples]

        # Test for cases of various number of elements in each section
        for j in range(0, 3):
            gp = GoogleParser(sections)
            docstring = ""
            for i in range(num_sections):
                if docstring:
                    docstring += "\n\n"
                docstring += f"Section{i}:"

# Generated at 2022-06-25 16:28:55.578610
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = None
    google_parser = GoogleParser()
    assert google_parser.parse(text) == Docstring()


# Generated at 2022-06-25 16:29:03.684681
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:29:16.725466
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Setup
    x = GoogleParser()
    # Testing parser's handling of Google-style docstrings
    y = x.parse(
        """Single-line description.
        
        Long description.
        
        Args:
          arg1 (str): Description of `arg1`.
          arg2 (:class:`ClassName`): Description of `arg2`.
        
        Returns:
          str: Description of return value.
        
        Raises:
          ValueError: Description of raised exception.
        
        """
    )

# Generated at 2022-06-25 16:29:21.499547
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = ""
    result = GoogleParser().parse(text_0)
    assert result


# Generated at 2022-06-25 16:29:31.752288
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import pytest
    import random

    def get_random_int():
        return random.randrange(-2147483648, 2147483647)

    def get_random_float():
        return random.randrange(-1e+308, 1e+308)

    def get_random_byte_array():
        return bytearray(random.randrange(0, 256) for _ in range(random.randrange(0, 1024)))

    class MyClass(GoogleParser):
        pass

    my_class = MyClass()

    # Valid argument
    text = "test"
    expected_outcome = Docstring()
    actual_outcome = my_class.parse(text)
    assert actual_outcome == expected_outcome

    # Invalid argument
    # text = None
    # expected_outcome = Docstring()


# Generated at 2022-06-25 16:29:44.084539
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    title_colon = False
    parser = GoogleParser(title_colon=title_colon)

    class C0:
        pass

    class C1:
        def f0():
            pass

    class C2:
        def f0():
            """
            Simple.
            """

    class C3:
        def f0():
            """
            Simple with short description and long description.

            This is the long description.
            """

    class C4:
        def f0():
            """
            Simple with short description and long description
            and blank line.

            This is the long description.
            """

    class C5:
        def f0():
            """
            Simple with blank line at the end.

            This is the long description.

            """


# Generated at 2022-06-25 16:29:59.189856
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse(
        """Returns the aaa."""
    ) == Docstring(
        short_description="",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=[], description="Returns the aaa.")],
    )
    assert parse(
        """Returns the aaa.

        """
    ) == Docstring(
        short_description="",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=[], description="Returns the aaa.")],
    )

# Generated at 2022-06-25 16:30:12.674981
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()
    test_text = '''\
    Summaries of Google-style docstrings:

    - *Single-line paragraphs* should be separated by a
      blank line. Otherwise, the function's or class's
      purpose won't be captured when users look at help
      in the interpreter.
    - Some *multi-line paragraphs* may need to be indented
      to make things line up correctly.
    '''
    google_parser = GoogleParser()
    docstring_0 = google_parser.parse(test_text)
    assert docstring_0.short_description == "Summaries of Google-style docstrings:"
    assert docstring_0.blank_after_short_description

# Generated at 2022-06-25 16:30:23.745840
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print('Unit test for method parse of class GoogleParser')

    example_0 = """
    This is a short description.

    This is a long description. It should be indented with the same indent as this
    first line of the long description. The blank line separating the
    short and long description should be kept.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
        arg3 (Optional[int]): Description of arg3
    """

    expected_return_0 = Docstring()

    expected_return_0.short_description = "This is a short description."


# Generated at 2022-06-25 16:30:31.251617
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    gd = gp.parse(
        """The ``parse`` method of the ``GoogleParser`` class.

The ``parse`` method takes a string containing the docstring to be parsed.
After parsing, it returns a Docstring instance with the parsed components.

:returns: The Docstring instance.
"""
    )
    assert len(gd.meta) == 1
    ret = gd.meta[0]
    assert isinstance(ret, DocstringReturns)
    assert ret.type_name == "The Docstring instance"



# Generated at 2022-06-25 16:30:36.088039
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test = "Short description.\n\nLong description.\n\nArgs:\n    a: First argument\n    b: Second argument.\n    c: Third argument.\n\nReturns:\n    Nothing.\n\nRaises:\n    Exception: When things go wrong.\n\nExamples:\n    >>> print(100)\n    100"
    docstring = parse(test)
    print(docstring)

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:44.567343
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    gp0 = GoogleParser()
    d0 = gp0.parse('  Args:\n\n      a: description of A')
    assert d0.short_description is None
    assert d0.long_description is None
    assert d0.blank_after_short_description is False
    assert d0.blank_after_long_description is False
    assert len(d0.meta) == 1
    assert type(d0.meta[0]) == DocstringParam
    assert d0.meta[0].description == "description of A"
    assert d0.meta[0].is_optional is None
    assert d0.meta[0].arg_name == "a"
    assert d0.meta[0].default is None
    assert d0.meta[0].type_name is None

    # Test case

# Generated at 2022-06-25 16:30:57.616792
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    result = parse("")
    assert result.short_description is None
    assert result.long_description is None
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 0

    result = parse("Test.")
    assert result.short_description == "Test."
    assert result.long_description is None
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 0

    result = parse("Test.\n")
    assert result.short_description == "Test."
    assert result.long_description is None
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    assert len(result.meta) == 0

    result = parse

# Generated at 2022-06-25 16:31:08.649638
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:31:17.013880
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser
    # Test case 0
    text_0 = "One line short description\n\nOne line long description\n"
    ret_0 = GoogleParser().parse(text_0)
    assert ret_0.short_description == "One line short description"
    assert ret_0.long_description == "One line long description"
    assert len(ret_0.meta) == 0


# Generated at 2022-06-25 16:31:25.632372
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Testing for failure
    # Case 1
    # Check for correct exception
    # Case 1.a
    with pytest.raises(ParseError):
        GoogleParser().parse(None)
    # Case 1.b
    with pytest.raises(ParseError):
        GoogleParser().parse("")
    # Case 1.c
    with pytest.raises(ParseError):
        GoogleParser().parse(" ")
    # Case 1.d
    with pytest.raises(ParseError):
        GoogleParser().parse("a")
    # Case 1.e
    with pytest.raises(ParseError):
        GoogleParser().parse("Example:")


# Generated at 2022-06-25 16:31:41.109645
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test for GoogleParser.parse() for docstring with title and type section
    text_1 = "This is a Google style docstring.\nSection type: Single"
    assert parse(text_1) == Docstring(
        long_description="Section type: Single",
        short_description="This is a Google style docstring.",
        meta=[
            DocstringMeta(args=["Section type"], description="Single")
        ],
    )

    # test for GoogleParser.parse() for docstring with title, type section and
    # indentation
    text_2 = (
        "This is a Google style docstring.\n"
        "Section type:\n"
        "    Indented Single"
    )

# Generated at 2022-06-25 16:31:46.040814
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "My awesome function.\n\nArgs: name: the name of the function\n\nReturns:\n    the result of the function"
    GoogleParser().parse(text)

    text = "The __init__.\n\nParameters:\n    name: the name of the function\n\nReturns:\n    the result of the function"
    GoogleParser().parse(text)

# Generated at 2022-06-25 16:31:56.792727
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    args_g00 = DocstringParam(['param', "p1"], "p1 desc", arg_name="p1", type_name=None, is_optional=None, default=None)
    args_g01 = DocstringParam(['param', "p2"], "p2 desc", arg_name="p2", type_name=None, is_optional=None, default=None)
    args_g02 = DocstringReturns(['returns', "None"], "None", type_name=None, is_generator=False)
    GoogleParser_g00 = GoogleParser()
    docstring = "test test2\n\ntest3\n\nArgs:\n    p1: p1 desc\n    p2: p2 desc\n\nReturns:\n    None\n"
    docstring_g01 = GoogleParser_g00

# Generated at 2022-06-25 16:32:09.245301
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test #1
    print("Test #1: ", end="")
    parser = GoogleParser()
    text_1 = (
        "This is a description.\n"
        "\n"
        "Args:\n"
        "  arg1 (str): The first arg.\n"
        "\n"
        "Returns:\n"
        "  Description of the return value.\n"
        "  str.\n"
        "\n"
        "Raises:\n"
        "  ValueError: If `arg1` is blank.\n"
    )
    res_1 = parser.parse(text_1)
    assert res_1.short_description == "This is a description."
    assert res_1.blank_after_short_description

# Generated at 2022-06-25 16:32:16.857646
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """A short summary.

    A long description.

    Arguments:
        arg1:
          Longer description of arg1.
        arg2 (int):
          Longer description of arg2.

    Returns:
        bool: The return value. True for success, False otherwise.

    Raises:
        KeyError: The key was not found.
    """

    result = parser.parse(docstring)

# Generated at 2022-06-25 16:32:26.596326
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser([Section("Example", "examples", section_type_0)])
    result = parser.parse(
        "A simple example\n    >>> print(hello)\n    \"world\"\n"
    )
    assert result.short_description == "A simple example"
    assert (
        result.long_description
        == '\n    >>> print(hello)\n    "world"'
    )
    assert result.meta == [
        DocstringMeta(
            args=["examples"],
            description=None,
        )
    ]


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:32:37.715505
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """Descriptor of this class.

        For other documentation, see class documentation.

        Attributes:
            attr_0 (:obj:`int`): the first attribute.
        """
    )

    assert docstring.short_description == "Descriptor of this class."
    assert docstring.long_description == "For other documentation, see class documentation."
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert len(docstring.meta) == 1
    assert docstring.meta[0].args[0] == "attribute"
    assert docstring.meta[0].args[1] == "attr_0 :obj:`int`"

# Generated at 2022-06-25 16:32:43.270199
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    text = "This is a short description. It is\na long description."
    p = GoogleParser()
    # Exercise
    result = p.parse(text)
    # Verify
    assert(result.short_description == 'This is a short description.')
    assert(result.long_description == 'It is a long description.')
    assert(result.blank_after_short_description == False)
    assert(result.blank_after_long_description == False)
    assert(result.meta == [])


# Generated at 2022-06-25 16:32:50.082011
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse(" ") == Docstring()
    assert parser.parse("""
This is the first line.

This is the second line.
        """) == Docstring("This is the first line.", "This is the second line.")
    assert parser.parse("""This is the first line.

This is the second line.""") == Docstring("This is the first line.", "This is the second line.")
    assert parser.parse("""
This is the first line.

This is the second line.
        """) == Docstring("This is the first line.", "This is the second line.")

# Generated at 2022-06-25 16:32:58.066936
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    actual = GoogleParser().parse('Summary.\n\nArgs:\n  df: DataFrame\n')
    expected = Docstring(
        short_description='Summary',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=['param', 'df: DataFrame'],
                description=None,
                arg_name='df',
                type_name='DataFrame',
                is_optional=False,
                default=None,
            ),
        ],
    )
    assert actual == expected
