

# Generated at 2022-06-25 16:23:48.779326
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "short description\n\nlong description\n\nArgs:\n  arg: text\n\nReturns:\n  Some return value\n"
    gp = GoogleParser()
    ds = gp.parse(text)
    print("Result:")
    print("ds.short_description:", ds.short_description)
    print("ds.blank_after_short_description:", ds.blank_after_short_description)
    print("ds.long_description:", ds.long_description)
    print("ds.blank_after_long_description:", ds.blank_after_long_description)

    for meta in ds.meta:
        print("ds.meta.args:", meta.args)
        for arg in meta.args:
            print("meta.args[arg]:", arg)
       

# Generated at 2022-06-25 16:24:01.026535
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    d = parser.parse("test docstring\n")
    assert d.short_description == "test docstring"

    d = parser.parse("test docstring")
    assert d.short_description == "test docstring"

    d = parser.parse("long description\n\n")
    assert d.short_description is None
    assert d.long_description == "long description"

    d = parser.parse("long description\n")
    assert d.short_description is None
    assert d.long_description == "long description"

    d = parser.parse("short desc\n\nlong desc\n\n")
    assert d.short_description == "short desc"
    assert d.long_description == "long desc"


# Generated at 2022-06-25 16:24:02.238333
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert True

# Generated at 2022-06-25 16:24:09.506182
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = \
"""Short summary.

Long summary.

Args:
    a: First thing.
    b: Second thing.

Returns:
    Something.

Raise:
    SomeException

Example:
    Example usage.
"""
    g = GoogleParser()
    d = g.parse(doc)
    assert d.short_description == "Short summary."
    assert d.long_description == "Long summary."
    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is False
    assert len(d.meta) == 4

# Generated at 2022-06-25 16:24:15.698892
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("Example") == Docstring(
        short_description=None,
        blank_after_short_description=None,
        long_description=None,
        blank_after_long_description=None,
        meta=[DocstringMeta(args=['examples', 'Example'], description='\n')],
    )

    assert parse("""
    Example
    -------
    """) == Docstring(
        short_description=None,
        blank_after_short_description=None,
        long_description=None,
        blank_after_long_description=None,
        meta=[DocstringMeta(args=['examples', 'Example'], description='\n')],
    )


# Generated at 2022-06-25 16:24:25.968892
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "This is a long description.\n\nThis is a second paragraph of the long description.\n\n:param request: The request object.\n:type request: ``HttpRequest``\n:param user: A User instance.\n:type user: ``django.contrib.auth.models.User``\n:returns: This is a description of what is returned.\n:rtype: ``HttpResponse`` or ``HttpRedirectResponse``\n:raises: This is a description of the exception."
    parser = GoogleParser()

# Generated at 2022-06-25 16:24:38.383578
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create the parser
    parser = GoogleParser()
    # Create the docstring
    docstring = """
    This is a long description.

    This is the first section.
    This is the second section.

    This is the final section."""
    # Parse the docstring
    docstring = parser.parse(docstring)
    # Inspect the docstring
    assert docstring.short_description == "This is a long description."
    assert docstring.long_description == "This is the first section.\nThis is the second section."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.meta == ['This is the final section.']


# Generated at 2022-06-25 16:24:44.070312
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    value_0 = parser.parse("")
    assert (
        value_0
        == Docstring(
            short_description=None,
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        )
    )
    value_1 = parser.parse("yields: str\n\nYields a string.")

# Generated at 2022-06-25 16:24:54.264937
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    for section_type_0 in SectionType:
        section_0 = Section("Arguments", "param", section_type_0)
        parser_0 = GoogleParser(sections=[section_0])
        text_0 = ''
        ds_0 = parser_0.parse(text_0)
        assert ds_0.short_description is None
        assert ds_0.long_description is None
        assert ds_0.blank_after_short_description is None
        assert ds_0.blank_after_long_description is None
        assert len(ds_0.meta) == 0

    for section_type_0 in SectionType:
        section_0 = Section("Arguments", "param", section_type_0)
        parser_0 = GoogleParser(sections=[section_0])

# Generated at 2022-06-25 16:24:55.782436
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()


# Generated at 2022-06-25 16:25:06.156235
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = Docstring()
    docstring_1 = google_parser_0.parse("")
    assert docstring_0 == docstring_1


# Generated at 2022-06-25 16:25:12.958100
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = ""
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description is None
    assert len(docstring_0.long_description) == 0
    assert len(docstring_0.meta) == 0
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.blank_after_short_description is False


# Generated at 2022-06-25 16:25:26.131081
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str = """Takes a dictionary, that is supposed to be a tabular. It can contain an arbitrary number of columns, but each row must have the same number of entries.

It then converts the dict into an Xarray Dataset, making the keys the column names of the dataset and the values the column data.

Each column must be an iterable (e.g. a tuple, a list, an iterator or a generator) with the same number of entries.

Assigning the resulting dataset to a variable and calling just that variable will print the dataset in a tabular form.

This is a very simple function, but it has a lot of flexibility and usefulness.

Args:
    data: The dictionary to be converted into an Xarray Dataset.

Returns:
    An Xarray Dataset.
"""
    parser = GoogleParser()

# Generated at 2022-06-25 16:25:36.621945
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text1 = '''
        Short summary

        Longer description

        Args:
            arg1 (str): Description of arg1
            arg2 (str): Description of arg2

        Returns:
            dict: Description of return value

        Raises:
            NameError: Description of exception
    '''

    docstr1 = google_parser_0.parse(text1)
    assert docstr1.short_description == 'Short summary'
    assert docstr1.long_description == 'Longer description'
    assert docstr1.meta[0].arg_name == 'arg1'
    assert docstr1.meta[0].type_name == 'str'
    assert docstr1.meta[0].description == 'Description of arg1'
    assert docstr1.meta[1].arg_name == 'arg2'
    assert docstr

# Generated at 2022-06-25 16:25:41.824728
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = inspect.cleandoc("""\
    Returns a new string object containing a copy of str.

    :param str:
        The string from which a new ``str`` object is to be built.
    :param encoding:
        The encoding of str.
        Default is ``'utf-8'``.
    :param errors:
        The error handling scheme to use for the handling of decoding errors.
        The default is ``'strict'``.
    :returns:
        If ``encoding`` or ``errors`` is given, the return value is a
        ``bytes`` object; otherwise, it is a ``str`` object.
    :raises TypeError:
        If you provide a third argument.
    """)
    result = google_parser_0.parse(text)
    assert result == doc

# Generated at 2022-06-25 16:25:44.833667
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    string_0 = """
    This is a summary
    """
    qtbot.addWidget(google_parser_0)
    with qtbot.waitExposed(google_parser_0):
        google_parser_0.parse(string_0)


if __name__ == "__main__":
    import sys

    sys.exit(unittest.main())

# Generated at 2022-06-25 16:25:52.761549
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()

    text_0 = """summary line

extended description

Args:
    arg1 (int): description of arg1
"""

    ds_0 = google_parser_1.parse(text_0)
    ds_0 = Docstring(
        short_description="summary line",
        long_description="extended description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=["Arguments", "arg1 (int)"],
                description="description of arg1",
                arg_name="arg1",
                type_name="int",
                is_optional=False,
                default=None,
            )
        ],
    )

# Generated at 2022-06-25 16:26:05.335767
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    short_desc = "My short description."
    long_desc = "My long description."
    yield_desc = "My yields description."
    param_desc = "My param description."
    raise_desc = "My raises description."
    returns_desc = "My returns description."
    single_returns_desc = "My returns description."
    single_yields_desc = "My yields description."
    non_standard_section_desc = "My nonstandard description."
    non_standard_section_desc_2 = "My nonstandard description 2."

# Generated at 2022-06-25 16:26:06.348398
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert(True)


# Generated at 2022-06-25 16:26:11.441694
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_0 = "docstrings.GoogleParser"
    docstring_0 = google_parser_0.parse(str_0)
    assert docstring_0.short_description == "docstrings.GoogleParser"
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:26:26.123998
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    text = ""
    docstring = google_parser.parse(text)
    docstring = google_parser.parse(text)
    docstring = google_parser.parse(text)
    docstring = google_parser.parse(text)
    docstring = google_parser.parse(text)
    docstring = google_parser.parse(text)
    docstring = google_parser.parse(text)
    docstring = google_parser.parse(text)
    docstring = google_parser.parse(text)

# Generated at 2022-06-25 16:26:39.486504
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from docstring_parser.common import Docstring, DocstringMeta, DocstringParam, \
        DocstringReturns, DocstringRaises

    google_parser_0 = GoogleParser()

    text_0 = ""
    actual = google_parser_0.parse(text_0)
    expected = Docstring()
    assert actual == expected

    text_1 = "Parse the Google-style docstring into its components."
    actual = google_parser_0.parse(text_1)
    expected = Docstring(
        short_description="Parse the Google-style docstring into its components.",
    )
    assert actual == expected

    text_2 = "Parse the Google-style docstring into its components.\n\n" \
        ":returns: parsed docstring"
    actual = google_parser_0.parse(text_2)

# Generated at 2022-06-25 16:26:45.688411
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:26:55.820942
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:27:00.730097
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    expected_1 = Docstring(
        short_description='blah blah.',
        long_description='long desc',
        meta=[],
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    text = """\
blah blah.

long desc

Returns:
    blah blah
"""
    actual = google_parser_1.parse(text)
    assert actual == expected_1

# Generated at 2022-06-25 16:27:10.512402
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    docstring_1 = google_parser_1.parse("\n")
    assert docstring_1.short_description == ""
    assert docstring_1.long_description == ""
    docstring_2 = google_parser_1.parse("")
    assert docstring_2.short_description == ""
    assert docstring_2.long_description == ""
    google_parser_2 = GoogleParser()
    docstring_3 = google_parser_2.parse(
        "Convert a number to a string.\n\nArgs:\n    x: the number to convert\n"
    )
    assert docstring_3.short_description == "Convert a number to a string."
    assert docstring_3.long_description == ""
    assert docstring_3.blank_after_

# Generated at 2022-06-25 16:27:14.527386
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = ""
    result = GoogleParser().parse(text)
    assert result.short_description == None
    assert result.blank_after_short_description == None
    assert result.long_description == None
    assert result.blank_after_long_description == None
    assert result.meta == []


# Generated at 2022-06-25 16:27:27.211156
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """First line of the docstring.

    Second line of the docstring.

    :param arg: description for arg
    :type arg: type for arg
    :returns: description for return
    :rtype: type for return

    Last line of docstring."""
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == "First line of the docstring."
    assert docstring_0.long_description == "Second line of the docstring.\n      Last line of docstring."
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 3
    meta_0

# Generated at 2022-06-25 16:27:39.981892
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    docstring_1 = google_parser_1.parse("")
    assert docstring_1 == Docstring()
    docstring_1 = google_parser_1.parse("docstring without section")
    assert docstring_1 == Docstring(short_description="docstring without section")
    docstring_1 = google_parser_1.parse("docstring without section\n that spans two lines")
    assert docstring_1 == Docstring(
        short_description="docstring without section",
        long_description="that spans two lines",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    docstring_1 = google_parser_1.parse(
        "docstring without section\n that spans two lines\n"
    )
   

# Generated at 2022-06-25 16:27:49.998759
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # Test case 0
    text = "  This is my docstring.\n\n  And it has a long description.\n\nA paragraph.\n\nA second paragraph.\n"
    docstring = google_parser_0.parse(text)
    assert docstring.short_description == "This is my docstring."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.long_description == "And it has a long description.\n\nA paragraph.\n\nA second paragraph."


# Generated at 2022-06-25 16:27:56.850131
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    text = "foo"
    docstring = google_parser.parse(text)
    assert docstring.short_description == "foo"



# Generated at 2022-06-25 16:28:09.022909
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    text = """
    Short description.

    Long description.

    Args:
        p1 (str, optional): Description of `p1`
        p2: Description of `p2`
        p3 (str): Description of `p3`
        p4 (str, optional): 
            Multi-line description of `p4`.
            Defaults to None.
        p5 (bool, optional): Multi-line description of `p5`.

    Returns:
        bool: Description of return value.

    Raises:
        ValueError: If `p2` is empty.

        KeyError: For all other errors.

    """
    ret = google_parser_0.parse(text)
    assert isinstance(ret, Docstring)
    assert ret.short_description == "Short description."
   

# Generated at 2022-06-25 16:28:20.680554
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = ""
    Docstring_0 = google_parser_0.parse(text_0)
    text_0 = "What happens if the docstring is empty?"
    Docstring_1 = google_parser_0.parse(text_0)
    text_0 = "What happens if the docstring is empty?"
    Docstring_2 = google_parser_0.parse(text_0)
    text_0 = "What happens if the docstring is empty?"
    Docstring_3 = google_parser_0.parse(text_0)
    text_0 = "What happens if the docstring is empty?"
    Docstring_4 = google_parser_0.parse(text_0)
    text_0 = "What happens if the docstring is empty?\n\n"
   

# Generated at 2022-06-25 16:28:33.091355
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test with good docstring
    google_parser_0 = GoogleParser()
    good_example_docstring = """
    This is a test docstring
    
    Args:
        arg1 (float): this is arg1
        arg2 (str): this is arg2
    
    Yields:
        int, float: two output values
    """
    docstring = google_parser_0.parse(good_example_docstring)
    assert docstring.short_description == "This is a test docstring"
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == 1
    assert docstring.blank_after_long_description == 0
    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == "this is arg1"
    assert docstring

# Generated at 2022-06-25 16:28:43.099982
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    string = """Compute the sum of a list of variables.

Usage::

    with tf.Session() as sess:
        result = sess.run(tf.add_n([output1, output2, output3]))

Args:
    inputs: A list of Tensor objects, each with same shape and type.
    name: A name for the operation (optional).

Returns:
    A Tensor of same shape and type as the elements of `inputs`.
"""
    doc_0 = GoogleParser().parse(string)
    assert doc_0.short_description == "Compute the sum of a list of variables."

# Generated at 2022-06-25 16:28:50.366757
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # Call parse
    ret = google_parser_0.parse("")
    # Assert that ret.short_description = None
    assert (ret.short_description == None)
    # Assert that ret.long_description = None
    assert (ret.long_description == None)
    # Assert that ret.meta == []
    assert (ret.meta == [])
    # Call parse
    ret = google_parser_0.parse("Get an iterator from an iterable.\n\n    Create an iterator from obj.\n    ")
    # Assert that ret.short_description == 'Get an iterator from an iterable.'
    assert (ret.short_description == 'Get an iterator from an iterable.')
    # Assert that ret.long_description == 'Create an iterator from obj

# Generated at 2022-06-25 16:29:01.539437
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    arg_0 = """
        Parses Google-style docstrings.

        Args:
            text: str

        Returns:
            returns a `GoogleDocstring`
        """
    ret_0 = google_parser_0.parse("""
        Parses Google-style docstrings.

        Args:
            text: str

        Returns:
            returns a `GoogleDocstring`
        """)
    assert inspect.cleandoc("""
        Parses Google-style docstrings.

        Args:
            text: str

        Returns:
            returns a `GoogleDocstring`
        """) == arg_0

# Generated at 2022-06-25 16:29:07.424963
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = 'def foo(variable_0):\n    "A summary.\n\n    A more detailed description.\n\n    Args:\n      variable_0 (str): Description of variable_0.\n    "\n    pass\n\n'
    assert expect == google_parser_0.parse(text_0)

# Generated at 2022-06-25 16:29:19.266147
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:29:20.809859
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # Insert your test code here
    assert 1 == 0


# Generated at 2022-06-25 16:29:37.307716
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """\
    Parses Google-style docstrings.
    """
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == text_0
    text_1 = """\
    Parses Google-style docstrings.

    Returns
    -------
    docstring : Docstring
        Parsed docstring.
    """
    docstring_1 = google_parser_0.parse(text_1)
    assert docstring_1.short_description == "Parses Google-style docstrings."
    assert docstring_1.long_description == None
    assert docstring_1.meta[0].description == "Parsed docstring."

# Generated at 2022-06-25 16:29:44.630731
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    print(google_parser_1.parse("""
    Google-style docstring.

    Args:
        param1: The first parameter.
        param2: The second parameter. Defaults to "empty".

    Returns:
        bool: The return value. True for success, False otherwise.
    """))


if __name__ == "__main__":
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:29:58.046668
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test case 0
    text_0 = """The ``.reg`` file is an INI formatted file consisting of:

- config_version: a section describing the version of the config file
- files: a section describing the files to be managed
- sources: a section describing the sources of information to be used by the tool
- options: a section describing any options
"""
    docstring_0 = parse(text_0)
    assert docstring_0.short_description == "The ``.reg`` file is an INI formatted file consisting of:"
    assert docstring_0.long_description == """
- config_version: a section describing the version of the config file
- files: a section describing the files to be managed
- sources: a section describing the sources of information to be used by the tool
- options: a section describing any options
"""

# Generated at 2022-06-25 16:30:11.594632
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstring = google_parser.parse(
        """
    The doctest for sample_package.module_without_init.

    It has the following format:

    Args:
          arg1(str): This is the first argument.

              It has a long description that spans multiple lines.
              Indented lines must be indented from the same point as the first
              long description line.

    """
    )
    assert docstring.short_description == 'The doctest for sample_package.module_without_init.'
    assert docstring.long_description == "It has the following format:"
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert len(docstring.meta) == 1

# Generated at 2022-06-25 16:30:17.263847
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a Google-style docstring.
    
    It is indented with four spaces.
    
    """
    expected = """
This is a Google-style docstring.

It is indented with four spaces.

"""
    actual = GoogleParser().parse(text)
    assert actual.long_description == expected



# Generated at 2022-06-25 16:30:26.055540
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    text_0 = "Docstring for class Foo.\n\n\nArgs:\n  param1: The first parameter.\n  param2: The second parameter. Defaults to 'foo'.\n  param3 (int): Parameter without description.\n\n"
    method_0 = google_parser_1.parse(text_0)
    assert method_0 is not None


# Generated at 2022-06-25 16:30:35.638259
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = 'A docstring.'
    assert google_parser_0.parse(text) == Docstring(short_description='A docstring.', long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])

    google_parser_1 = GoogleParser()
    text = 'A docstring.\n\nA multiline description.'
    assert google_parser_1.parse(text) == Docstring(short_description='A docstring.', long_description='A multiline description.', blank_after_short_description=True, blank_after_long_description=True, meta=[])

    google_parser_2 = GoogleParser()
    text = 'A docstring.\n\nA multiline description.\n\n'

# Generated at 2022-06-25 16:30:44.389149
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_1 = GoogleParser()
    google_parser_2 = GoogleParser()
    google_parser_3 = GoogleParser()
    google_parser_4 = GoogleParser()
    google_parser_5 = GoogleParser()
    google_parser_6 = GoogleParser()
    google_parser_7 = GoogleParser()
    google_parser_8 = GoogleParser()
    google_parser_9 = GoogleParser()
    google_parser_10 = GoogleParser()
    google_parser_11 = GoogleParser()
    google_parser_12 = GoogleParser()
    google_parser_13 = GoogleParser()
    google_parser_14 = GoogleParser()
    google_parser_15 = GoogleParser()
    google_parser_16 = GoogleParser()
    google_parser_17 = GoogleParser()
   

# Generated at 2022-06-25 16:30:57.617225
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:31:08.890471
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    assert google_parser.parse('')
    assert google_parser.parse('doc')
    assert google_parser.parse('long doc')
    assert google_parser.parse('long doc\nsecond line')
    assert google_parser.parse('long doc\n\nhello')
    assert google_parser.parse('long doc\n\nhello\n')
    assert google_parser.parse('long doc\n\nhello\nworld')
    assert google_parser.parse('long doc\n\nhello\nworld\n')
    assert google_parser.parse('long doc\n\nhello\nworld\n\n')

    assert google_parser.parse('long doc\n\nhello\nworld\n\nArgs:')

# Generated at 2022-06-25 16:31:15.331179
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.parse()


# Generated at 2022-06-25 16:31:25.501114
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup a mocked docstring
    docstring = """
    :param a: b
    :type a: str
    
    :param a: b
    :type a: str
    """
    google_parser = GoogleParser()
    # Parse the docstring
    parsed = google_parser.parse(docstring)
    assert(parsed.meta[0].args == ['param', 'a: b'])
    assert(parsed.meta[0].arg_name == 'a')
    assert(parsed.meta[0].type_name == 'str')
    assert(parsed.meta[1].args == ['type', 'a: str'])
    assert(parsed.meta[1].description == "a")
    

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:31:33.481268
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = 'This is a docstring.'
    ret = google_parser_0.parse(text_0)
    assert ret.short_description == 'This is a docstring.'

    text_1 = """Solve the equation "a * x = b" for x.

:param a: the first parameter
:param b: the second parameter"""
    ret = google_parser_0.parse(text_1)
    assert len(ret.meta) == 2
    assert ret.meta[0].description == 'the first parameter'
    assert ret.meta[1].description == 'the second parameter'

    text_2 = "Partition the input in two sections.\n\nArgs: a: the first param\nb: the second param"

# Generated at 2022-06-25 16:31:37.425048
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = ""
    Docstring_0 = google_parser_0.parse(text_0)
    return Docstring_0



# Generated at 2022-06-25 16:31:49.130328
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()

# Generated at 2022-06-25 16:31:53.163948
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for method parse in class GoogleParser
    """

    # Setup
    google_parser_0 = GoogleParser()
    text_0 = ""

    # Invocation
    ret_0 = google_parser_0.parse(text_0)

    # Check
    assert ret_0 is not None



# Generated at 2022-06-25 16:32:04.892893
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    r_0 = google_parser_0.parse("")
    assert (
        repr(r_0)
        == "Docstring(short_description=None, long_description=None, blank_after_short_description=None, blank_after_long_description=None, meta=[])"
    )
    r_1 = google_parser_0.parse("doc")
    assert (
        repr(r_1)
        == "Docstring(short_description='doc', long_description=None, blank_after_short_description=None, blank_after_long_description=None, meta=[])"
    )

# Generated at 2022-06-25 16:32:13.855311
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = ""
    docstring = google_parser_0.parse(text)
    assert docstring == Docstring()

    text = "\"\"\"\nShort summary.\n\nLong summary.\n\"\"\""
    docstring = google_parser_0.parse(text)
    assert docstring == Docstring(
        short_description="Short summary.",
        blank_after_short_description=True,
        long_description="Long summary.",
        blank_after_long_description=False,
    )

    text = "\"\"\"\nShort summary.\n\nLong summary.\n\n\"\"\""
    docstring = google_parser_0.parse(text)

# Generated at 2022-06-25 16:32:14.863485
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert 1 == 1


test_case_0()
test_GoogleParser_parse()

# Generated at 2022-06-25 16:32:26.891454
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Test case 0
    google_parser_0 = GoogleParser()
    ds_0 = Docstring()
    ds_0.short_description = 'Echo back its arguments.'
    ds_0.blank_after_short_description = True
    ds_0.meta = [DocstringParam(args=['param', 'arg'], description='The string to echo.', arg_name='arg', type_name=None, is_optional=None, default=None)]
    ds_0.meta.append(DocstringReturns(args=['returns', 'str'], description='The echoed string.', type_name='str', is_generator=False))

# Generated at 2022-06-25 16:32:43.132856
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    try:
        docstring_0 = google_parser_0.parse()
    except TypeError:
        pass
    google_parser_1 = GoogleParser()
    try:
        docstring_1 = google_parser_1.parse('string')
    except TypeError:
        pass
    google_parser_2 = GoogleParser()
    try:
        docstring_2 = google_parser_2.parse('')
    except TypeError:
        pass
    google_parser_3 = GoogleParser()
    try:
        docstring_3 = google_parser_3.parse('')
    except TypeError:
        pass
    google_parser_4 = GoogleParser()

# Generated at 2022-06-25 16:32:49.933100
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

# Generated at 2022-06-25 16:32:56.646545
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

# Generated at 2022-06-25 16:32:59.739502
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    text_0 = '    '
    test_0 = GoogleParser().parse(text_0)
