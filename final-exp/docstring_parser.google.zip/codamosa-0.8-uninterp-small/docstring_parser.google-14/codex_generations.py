

# Generated at 2022-06-25 16:23:26.626221
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_0 = "Dummy method."
    docstring_0 = google_parser_0.parse(str_0)
    assert docstring_0.short_description == str_0
    assert not docstring_0.meta


# Generated at 2022-06-25 16:23:28.029987
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Assert: not implemented
    pass


# Generated at 2022-06-25 16:23:37.794538
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    assert (
        google_parser_0.parse(
            """
    """
        )
        == Docstring(
            meta=[],
            blank_after_long_description=None,
            blank_after_short_description=None,
            long_description=None,
            short_description=None,
        )
    )

    assert (
        google_parser_0.parse(
            """Very short description
    """
        )
        == Docstring(
            meta=[],
            blank_after_long_description=None,
            blank_after_short_description=None,
            long_description=None,
            short_description="Very short description",
        )
    )


# Generated at 2022-06-25 16:23:44.449633
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    ret_0 = google_parser_0.parse('\n    This is the short  description.\n\n    This is the long description.\n\n    Args:\n        foo (str): This is the first parameter.\n        bar (str): This is a second parameter.\n    ')
    assert ret_0.short_description == 'This is the short  description.'
    assert ret_0.long_description == 'This is the long description.'
    assert ret_0.blank_after_short_description == True
    assert ret_0.blank_after_long_description == True

# Generated at 2022-06-25 16:23:54.286817
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    first = ("""
    Parse the Google-style docstring into its components.
    :returns: parsed docstring
    """)
    second = ("""
    Parameters
    ----------
        text: str
            The string to parse.
    """)
    third = ("""
    Return
    ------
        parsed docstring
    """)
    fourth = ("""
        """ + first + """
        """ + second + """
        """ + third + """
        """)
    expected = Docstring()
    expected.short_description = "Parse the Google-style docstring into its components."
    expected.long_description = ":returns: parsed docstring"

# Generated at 2022-06-25 16:23:57.703859
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass
    assert 1 == 1
    # assert 1 == 2
    # assert 1 == 3


# Generated at 2022-06-25 16:24:04.119748
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "Example of google style.\n\nThis is a second paragraph.\n\nArgs:\n    arg1 (int): Description of arg1\n        with a second line.\n    arg2 (str): Description of arg2.\n\nReturns:\n    str: Description of return value."
    try:
        google_parser_0.parse(text_0)
    except Exception as e:
        print(type(e))
        print(e.args)
        print(e)
        assert False


# Generated at 2022-06-25 16:24:13.839526
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:24:20.385521
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    arg_0 = ''
    # Call method parse of class GoogleParser with arg_0
    ret = google_parser_0.parse(arg_0)
    # Verify the result
    assert ret == {
        'long_description': None,
        'blank_after_short_description': False,
        'short_description': None,
        'blank_after_long_description': False,
        'meta': []
    }

# Generated at 2022-06-25 16:24:24.522798
# Unit test for method add_section of class GoogleParser
def test_GoogleParser_add_section():
    google_parser_1 = GoogleParser()
    section_0 = Section(title="Parameters", key="param", type=SectionType.MULTIPLE)
    google_parser_1.add_section(section=section_0)


# Generated at 2022-06-25 16:24:41.220833
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "Test docstring"
    docstring_0 = google_parser_0.parse(text_0)
    expected_0 = None
    got_0 = docstring_0.short_description
    assert (
        got_0 == expected_0
    ), "expected: {}, got: {}".format(expected_0, got_0)
    docstring_0 = google_parser_0.parse(text_0)
    expected_0 = None
    got_0 = docstring_0.long_description
    assert (
        got_0 == expected_0
    ), "expected: {}, got: {}".format(expected_0, got_0)
    docstring_0 = google_parser_0.parse(text_0)
    expected_0 = None
   

# Generated at 2022-06-25 16:24:51.765873
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.title_colon = True

# Generated at 2022-06-25 16:25:02.754525
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    txt = """\
    Short description

    Long description

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        int: Description of return value

    Raises:
        ValueError: Description of exception
    """

    doc = Docstring()
    doc.short_description = "Short description"
    doc.long_description = "Long description"
    doc.blank_after_short_description = True
    doc.blank_after_long_description = False

# Generated at 2022-06-25 16:25:11.214380
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    global google_parser_0
    with open('test_cases/cases/test_case_0.txt', 'r') as f:
        text = f.read()
        text = text.rstrip()
        google_parser_0.parse(text)

if __name__ == "__main__":
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:25:13.382518
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = "A docstring."
    docstring_0 = google_parser_0.parse(text)


# Generated at 2022-06-25 16:25:20.067230
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """This is a short description.

This is a long description.


Args:
    a: is this
    b: is that
    c: is it
"""
    expected_docstring = Docstring()
    expected_docstring.short_description = "This is a short description."
    expected_docstring.long_description = "This is a long description."
    expected_docstring.blank_after_short_description = True
    expected_docstring.blank_after_long_description = True
    expected_docstring.meta = [
        DocstringMeta(args=["param", "a"], description="is this"),
        DocstringMeta(args=["param", "b"], description="is that"),
        DocstringMeta(args=["param", "c"], description="is it"),
    ]
    google_parser = GoogleParser()

# Generated at 2022-06-25 16:25:22.185113
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    r"""
    test_GoogleParser_parse
    """
    google_parser_1 = GoogleParser()
    source_0 = 'Banana is a fruit'
    output_0 = google_parser_1.parse(source_0)
    assert output_0.short_description == source_0


# Generated at 2022-06-25 16:25:33.531052
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_arg_0 = """"""
    docstring_22 = google_parser_0.parse(str_arg_0)
    assert docstring_22 == Docstring()
    str_arg_1 = """"""
    docstring_23 = google_parser_0.parse(str_arg_1)
    assert docstring_23 == Docstring()
    str_arg_2 = """  """
    docstring_24 = google_parser_0.parse(str_arg_2)
    assert docstring_24 == Docstring()
    str_arg_3 = """\n"""
    docstring_25 = google_parser_0.parse(str_arg_3)
    assert docstring_25 == Docstring()
    str_arg_4 = """
"""
    docstring_26

# Generated at 2022-06-25 16:25:40.448209
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = test_case_0()

    docstring_0 = Docstring()
    assert google_parser_0.parse('\n    Chunk description\n    ') == docstring_0
    assert google_parser_0.parse('\n    Chunk description\n    ') == docstring_0
    assert google_parser_0.parse('\n    Chunk description\n    ') == docstring_0
    assert google_parser_0.parse('\n    Chunk description\n    ') == docstring_0
    assert google_parser_0.parse('\n    Chunk description\n    ') == docstring_0
    assert google_parser_0.parse('\n    Chunk description\n    ') == docstring_0

# Generated at 2022-06-25 16:25:41.603315
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()


# Generated at 2022-06-25 16:26:02.889464
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """This function does something.
    :type foo: float
    :type bar: str
    :param qux: Stuff.
    :returns: Something else.
    """

# Generated at 2022-06-25 16:26:14.627819
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = """
    The base class for all built-in exceptions. It is a subclass of
    Exception. All exceptions should subclass Exception directly or
    indirectly.

    The associated value is accessible through the ``args`` attribute or
    by accessing the exception instance as an indexable sequence.
    """
    docstring_0 = google_parser_0.parse(text)

TESTS = [
    test_case_0,
    test_GoogleParser_parse,
]

if __name__ == "__main__":
    print("Running Python-style doctring parser tests...")
    print("")

# Generated at 2022-06-25 16:26:27.655034
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = ''
    assert google_parser_0.parse(text) == Docstring()
    google_parser_1 = GoogleParser()

# Generated at 2022-06-25 16:26:28.832705
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # TODO: change this to a proper test case
    assert True



# Generated at 2022-06-25 16:26:39.939245
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = u'Print a poem by a named poet (default is Langston Hughes).\n\n    :param poet: a declared poet, defaults to Langston Hughes\n    :type poet: string\n    :param poem: a declared poem of the declared poet, defaults to "Dream"\n    :type poem: string\n    :param indent: indentation for the poem, defaults to 4 spaces\n    :type indent: string\n    :returns: the poet and poem printed\n\n'
    ret_0 = google_parser_0.parse(text_0)

    assert ret_0.short_description == u'Print a poem by a named poet (default is Langston Hughes).'
    assert ret_0.long_description is None
    assert ret_0.blank_after_short_

# Generated at 2022-06-25 16:26:40.760255
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ret_0 = parse("")


# Generated at 2022-06-25 16:26:43.722608
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    google_parser.parse("Some text")

# Generated at 2022-06-25 16:26:48.997250
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    param_0 = parse(str())
    assert isinstance(param_0, Docstring)
    assert param_0.short_description == None
    assert param_0.long_description == None

# Generated at 2022-06-25 16:26:58.156725
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "text"
    docstring_0 = google_parser_0.parse(text_0)
    docstring_1 = Docstring()
    assert docstring_0 == docstring_1

    text_1 = "text\n text"
    docstring_2 = google_parser_0.parse(text_1)
    docstring_3 = Docstring()
    docstring_3.short_description = "text"
    docstring_3.long_description = "text"
    assert docstring_2 == docstring_3

    text_2 = "text\n \n text"
    docstring_4 = google_parser_0.parse(text_2)
    docstring_5 = Docstring()
    docstring_5.short_description = "text"


# Generated at 2022-06-25 16:27:08.994671
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    ret_1 = google_parser_1.parse()
    assert isinstance(ret_1, Docstring)
    google_parser_2 = GoogleParser()
    ret_2 = google_parser_2.parse('')
    assert isinstance(ret_2, Docstring)
    google_parser_3 = GoogleParser()
    ret_3 = google_parser_3.parse('This is a short test,\n\nthis is a long one.')
    assert isinstance(ret_3, Docstring)
    assert ret_3.short_description == 'This is a short test'
    assert ret_3.long_description == 'this is a long one.'
    assert ret_3.blank_after_short_description == True

# Generated at 2022-06-25 16:27:29.154158
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse(
        """Summary line.

        Extended description of function.

        Args:
          arg1: The first argument.
          arg2: The second argument.

        Returns:
          Description of return value.
        """
    )

# Generated at 2022-06-25 16:27:37.510164
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr_str = """
    A test function with Google style docstring.

    Parameters
    ----------
    param1 : str
        The first parameter.
    param2 : Optional[str]
        The second parameter.
    """
    google_parser = GoogleParser()
    docstring = google_parser.parse(docstr_str)
    print(docstring)

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:27:42.289143
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert(True)


if __name__ == '__main__':
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:27:45.208115
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # TODO: fix the test
    expected = """
    Test the GoogleParser.parse method
    :returns: None
    """
    assert False # can't test until the source is actually implemented

# Generated at 2022-06-25 16:27:54.870119
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    def docstring_0(text):
        return google_parser_0.parse(text)

    assert docstring_0("") == Docstring()
    assert docstring_0("foo") == Docstring(
        "foo",
        None,
        None,
        False,
        False,
    )
    assert docstring_0("Return foo\n") == Docstring(
        "Return foo",
        None,
        None,
        False,
        False,
    )
    assert docstring_0("foo\n\nbar") == Docstring(
        "foo",
        None,
        "bar",
        True,
        False,
    )

# Generated at 2022-06-25 16:28:04.691578
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = 'Test function.\n\n\tExample::\n\n\t\tpython setup.py\n'
    doc_string_one = GoogleParser().parse(docstring)
    assert doc_string_one.short_description == "Test function."
    assert doc_string_one.blank_after_short_description == False
    assert doc_string_one.long_description == None
    assert all(title.args == ['Examples'] for title in doc_string_one)
    assert doc_string_one.meta[0].description == 'Example::\n\n\t\tpython setup.py'


# Generated at 2022-06-25 16:28:10.398851
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0: Docstring = google_parser_0.parse(
        "This function does something.\n\n    Args:\n        a: first arg\n        b: second arg\n\n    Returns:\n        c\n"
    )

    assert docstring_0.short_description == "This function does something."
    assert docstring_0.long_description is None


# Generated at 2022-06-25 16:28:20.333371
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "    """
    results_0 = google_parser_0.parse(text_0)
    assert results_0.short_description is None
    assert results_0.long_description is None
    assert results_0.blank_after_short_description is None
    assert results_0.blank_after_long_description is None
    assert results_0.meta == []


# Generated at 2022-06-25 16:28:24.353662
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test case for method parse of class GoogleParser."""
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse('') == Docstring()


# Generated at 2022-06-25 16:28:37.881247
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.parse(r"""
        A long-winded multi-paragraph description of the function.
        
        Args:
        
            :param b: list of books
            :type a: Book
        
            :param c: list of values
            :type a: int
        
        Returns: 
        
            Returned book.
            Return type: int
        
        Raises:
        
            - TypeError
        
        Examples:
        
            >>> Function(book, [])
            [1, 2]
            
            >>> Function(book, [1, 2])
            Error
        """)  # noqa: W293



# Generated at 2022-06-25 16:29:02.726613
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    text_0 = "Hello world."
    docstring_0 = google_parser_0.parse(text_0)

    text_1 = "Hello world.\n"
    docstring_1 = google_parser_0.parse(text_1)

    text_2 = "Hello world.\n\n"
    docstring_2 = google_parser_0.parse(text_2)

    text_3 = "Hello world.\n\nKeyword arguments:\nx -- an integer."
    docstring_3 = google_parser_0.parse(text_3)

    text_4 = "Hello world.\n\nKeyword arguments:\ny (int) -- an integer."
    docstring_4 = google_parser_0.parse(text_4)


# Generated at 2022-06-25 16:29:09.488301
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = parse(
        """Calculate the position of a given time for a body in a solar system.

The position will be returned in the J2000 coordinate system.

Args:
  body: String name of the body to calculate positions for.
  start_time: The starting time for the search.
  end_time: The ending time for the search.

Raises:
  ValueError: An invalid body was specified.

Returns:
  A dictionary of position values for the specified body and
  time range.

"""
    )
    assert len(docstring_0.meta) == 2



# Generated at 2022-06-25 16:29:20.690998
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # Test of positive case
    docstring_0 = inspect.cleandoc(
        """
    Tests.

    Some raising exceptions.
    """
    )
    docstring_1 = google_parser_0.parse(docstring_0)
    assert isinstance(docstring_1, Docstring)
    assert isinstance(docstring_1.meta, T.List)
    assert docstring_1.short_description == "Tests."
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is None
    assert docstring_1.meta == []
    # Test of positive case

# Generated at 2022-06-25 16:29:31.060476
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse("")
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.meta == []
    # Test case 1
    test_str_1 = """One-line description.

    Long description."""
    google_parser_1 = GoogleParser()
    docstring_1 = google_parser_1.parse(test_str_1)
    assert docstring_1.short_description == "One-line description."
    assert docstring_1.long_description == "Long description."
    assert docstring_1.meta == []
    # Test case 2

# Generated at 2022-06-25 16:29:43.464859
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = """Example of google style.

    Args:
        param1: The first parameter.
        param2: The second parameter. Defaults to None.
            Split-line style is also supported.

    Returns:
        bool: The return value. True for success, False otherwise.
    """
    s = """Google-style docstrings are identical to NumPy docstrings (in fact,
    a Google-style docstring is a valid NumPy docstring), except that
    Google-style docstrings do not permit anything to precede the
    initial blockquote. In other words, Google-style docstrings are not
    allowed to be one-line docstrings.  
    """
    assert inspect.cleandoc(s)
    d = parse(docstring)
    print(d.short_description)
    print(d.long_description)
    print

# Generated at 2022-06-25 16:29:57.388069
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    example_0 = GoogleParser()

    str_0 = '''
    Parse the Google-style docstring into its components.

    :returns: parsed docstring

    :raises ParseError: on invalid Google-style docstring
    '''
    ret_0 = google_parser_0.parse(str_0)
    assert type(ret_0) is Docstring
    assert ret_0.short_description is None
    assert ret_0.long_description is None
    assert ret_0.blank_after_short_description is False
    assert ret_0.blank_after_long_description is True
    assert len(ret_0.meta) == 1
    assert type(ret_0.meta[0]) is DocstringRaises
    assert ret_0.meta[0].args == ["raises", "ParseError"]


# Generated at 2022-06-25 16:30:00.927590
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    self = GoogleParser()

    # Set up mock objects & set return values
    text = "Bla"

    # Call method under test
    #    ret = self.parse(text)


# Generated at 2022-06-25 16:30:14.264651
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_1 = google_parser_0.parse("""\
    """
)
    assert repr(docstring_1) == "Docstring(description=None, short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False, meta=[])"
    assert docstring_1.description == None
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []

# Generated at 2022-06-25 16:30:24.844987
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:30:28.523760
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    # Case 0:
    docstring_0 = inspect.getdoc(test_case_0)
    assert docstring_0[:18] == 'Google-style docstring'

# Generated at 2022-06-25 16:30:46.938561
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    if len(inspect.getargspec(google_parser_0.parse).args) == 1:
        text_0 = ""
        assert google_parser_0.parse(text_0) == Docstring(), "Return value of method parse of class GoogleParser is not equal to expected value"

if __name__ == "__main__":
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:55.455848
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Parse the Google-style docstring into its components.

    :returns: parsed docstring
    """

    # Set up test case data
    test_case_0.google_parser_0 = GoogleParser()

    # Perform the test
    try:
        assert google_parser_0.parse("") == Docstring(
            '',
            None,
            False,
            False,
            '',
            [],
            [],
        ), "Test case 0 failed"
    except:
        raise
    else:
        print("Test case 0 passed")


# Generated at 2022-06-25 16:31:02.337470
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser = GoogleParser()
    docstring = google_parser.parse("""This is a short description.

        This is a long description.

        Args:
            a (str): Description of a.
            b (str): Description of b.

        Returns:
            str: Description of returns.

        Raises:
            RuntimeError: Description of RuntimeError.
        """)

    print(docstring.meta)
    assert docstring.meta[0].type == "returns"
    assert docstring.meta[0].args == ["returns", "str"]
    assert docstring.meta[0].is_iterator is False
    assert docstring.meta[0].type_name == "str"

    assert docstring.meta[1].type == "raises"

# Generated at 2022-06-25 16:31:14.717307
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
        Args:
            a: A required parameter.
            b (int, optional): A defaulted parameter.
            c: A required parameter.
    """

# Generated at 2022-06-25 16:31:24.797057
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:31:29.189393
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for non-empty string (parses the Google-style docstring into its components.)
    # assert_equal(expected, GoogleParser.parse(self, text))
    raise NotImplementedError()

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 16:31:38.864282
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = """
        :param:
    """
    assert GoogleParser().parse(text_0) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=["param"], description=None)],
    )
    text_1 = """
        Parameters:
            arg:
    """
    assert GoogleParser().parse(text_1) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[DocstringMeta(args=["param", "arg"], description=None)],
    )

# Generated at 2022-06-25 16:31:46.507443
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.add_section(Section("description", "description", SectionType.SINGULAR))
    google_parser_0.add_section(Section("Attributes", "attribute", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Args", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE))
    google_parser_0.add_section(Section("Parameters", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Except", "raises", SectionType.MULTIPLE))

# Generated at 2022-06-25 16:31:55.929528
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # Parse the Google-style docstring into its components.
    text = '''
        Google style docstring.

        Takes the trained classifier, which should be of type
        ``sklearn.linear_model.logistic.LogisticRegression``, and the input
        vector, ``X``.

        :param clf: classifcation model
        :type clf: sklearn.linear_model.logistic.LogisticRegression
        :param X: input vector
        :type X: array-like
        :return: classification decision
        :rtype: array-like

        .. note::
            It would be good to explain how this decision is made

        """'''
    ret = google_parser_0.parse(text)

# Generated at 2022-06-25 16:32:08.612339
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_0 = inspect.cleandoc("test_parse")
    docstring_0 = google_parser_0.parse(str_0)
    assert docstring_0.__class__ == Docstring
    assert docstring_0.short_description == "test_parse"
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == None
    assert docstring_0.meta == []
    assert docstring_0.__class__ == Docstring
    str_0 = inspect.cleandoc("test_parse\n\nmore")
    docstring_0 = google_parser_0.parse(str_0)
    assert docstring_0.__class__

# Generated at 2022-06-25 16:32:25.315690
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.parse("Foo method.\n")


if __name__ == "__main__":

    print(test_case_0())

    print(test_GoogleParser_parse())

# Generated at 2022-06-25 16:32:34.987328
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Args", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Parameters", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Params", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(
        Section("Raises", "raises", SectionType.MULTIPLE)
    )
    google_parser_0.add_section(
        Section("Exceptions", "raises", SectionType.MULTIPLE)
    )
    google_parser_0.add_section

# Generated at 2022-06-25 16:32:43.066132
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_cases = []

    # test_0
    google_parser_0 = GoogleParser()
    text_0 = """
    Do some useful thing.

    :param int foo: An integer.
    :param str bar: A string.
    :type bar: str
    :return: A string.
    """

# Generated at 2022-06-25 16:32:49.873449
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    google_parser_0 = GoogleParser()
    text_0 = """Raises
    ------
    NotImplementedError
        How do I get no space between the title and the colons?
    """
    expected_0 = Docstring(
        short_description="",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[
            DocstringRaises(
                args=["Description", "raises", "NotImplementedError"],
                description="How do I get no space between the title and the colons?",
                type_name="NotImplementedError",
            )
        ],
    )
    actual_0 = google_parser_0.parse(text_0)

# Generated at 2022-06-25 16:32:59.164129
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """\
Summary line. In one line.

Extended description.

Attributes:
    x (int): The x coordinate.
Raises:
    ValueError: If there is no y coordinate.
    ValueError: If there is no x coordinate.
Returns:
    int: The x coordinate.
"""

# Generated at 2022-06-25 16:33:05.835068
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    string_0 = "Return a string.\n\nArgs:\n    a: integer\n    b: integer\n\nReturns:\n    sum:\n        integer sum\n"
    docstring_0 = google_parser_0.parse(string_0)
