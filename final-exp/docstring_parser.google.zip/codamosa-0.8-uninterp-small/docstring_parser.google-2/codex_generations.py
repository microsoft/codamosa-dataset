

# Generated at 2022-06-25 16:23:42.906131
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    test_0 = Docstring()
    output_0 = parser.parse('"""This docstring has no args or returns."""')
    assert output_0 == test_0


# Generated at 2022-06-25 16:23:44.650315
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Code
    GoogleParser_parse_0 = GoogleParser()
    GoogleParser_parse_0.parse('')


# Generated at 2022-06-25 16:23:54.572682
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    gprsr = GoogleParser()

    docstring = """
    Parse the Google-style docstring into its components.
    """
    component = gprsr.parse(docstring)

    # Test case 1
    assert component.short_description == "Parse the Google-style docstring into its components."
    assert component.long_description is None
    assert component.meta == []
    assert component._is_empty() == False
    assert component._is_empty(False, False) == True
    assert component.blank_after_short_description == False
    assert component.blank_after_long_description == False

    # Test case 2
    docstring = """
    Parse the Google-style docstring into its components.
    :returns: parsed docstring
    """
    component = gprsr.parse(docstring)

    assert component

# Generated at 2022-06-25 16:24:04.849691
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_obj = GoogleParser()
    assert google_parser_obj.parse("") == Docstring()
    assert google_parser_obj.parse("Single line.") == Docstring(
        short_description="Single line.",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert google_parser_obj.parse("Single line\n") == Docstring(
        short_description="Single line",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert google_parser_obj.parse("\n") == Docstring(
        short_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    assert google_parser_obj.parse

# Generated at 2022-06-25 16:24:07.838521
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    message = "This is an error message"
    try:
        raise ParseError(message)
    except ParseError as e:
        assert str(e) == message



# Generated at 2022-06-25 16:24:14.203158
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def check_parse(docstring, should):
        parser = GoogleParser()
        result = parser.parse(docstring)

        assert result == should

    # Simple docstring
    check_parse(
        """
        Short description.

        Long description.
        """,
        Docstring(
            description="Short description.",
            short_description="Short description.",
            long_description="Long description.",
            blank_after_short_description=True,
            blank_after_long_description=False,
            meta=[],
        ),
    )

    # Simple docstring, but with line breaks

# Generated at 2022-06-25 16:24:25.065123
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    # Test case 0
    text = """
        :param value: test
        :returns: test
        """
    assert parser.parse(text) == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[
            DocstringParam(
                args=["param", "value"],
                description="test",
                arg_name="value",
                type_name=None,
                default=None,
                is_optional=None,
            ),
            DocstringReturns(
                args=["returns", "test"],
                description="test",
                type_name="test",
                is_generator=False,
            ),
        ],
    )

    # Test

# Generated at 2022-06-25 16:24:38.220488
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create object
    parser = GoogleParser()

    # Access attribute sections
    section_01 = parser.sections
    print(section_01)
    print(type(section_01))

    # Access attribute titles_re
    section_02 = parser.titles_re
    print(section_02)
    print(type(section_02))
    section_02_1 = parser.titles_re.pattern
    print(section_02_1)
    print(type(section_02_1))
    section_02_2 = parser.titles_re.flags
    print(section_02_2)
    print(type(section_02_2))
    section_02_3 = parser.titles_re.groups
    print(section_02_3)
    print(type(section_02_3))
    section

# Generated at 2022-06-25 16:24:51.204889
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = "A short description.\n\n"
    meta_list = parser.parse(text).meta
    assert meta_list == []
    text = "A short description.\n\nReturns: None\n\n"
    meta_list = parser.parse(text).meta
    assert len(meta_list) == 1
    text = (
        "A short description.\n\nReturns:\n    The long description.\n\n"
    )
    meta = parser.parse(text).meta[0]
    assert meta.description == "The long description."
    text = (
        "A short description.\n\nReturns:\n    x -- The long description.\n\n"
    )
    meta = parser.parse(text).meta[0]

# Generated at 2022-06-25 16:25:02.379613
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = parse("")
    docstring_1 = parse("""This is a test docstring.""")
    docstring_2 = parse("""This is a test docstring.

And here is a long description. Usually it has some
further information.

Parameters
----------
name : str
    The name of the person.
age : float
    The age of the person.

Returns
-------
person : Person
    The Person instance.""")
    docstring_3 = parse("""This is a test docstring.

And here is a long description. Usually it has some
further information.

Raises
------
TypeError
    When something unexpected happens.""")

# Generated at 2022-06-25 16:25:19.231992
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test method parse of class GoogleParser."""
    print("Testing GoogleParser.parse")
    test_parser = GoogleParser()
    param_types = []
    test_parser.sections = {'param': Section('param', 'param', SectionType.MULTIPLE)}
    test_case_0 = test_parser.parse("test")
    assert test_case_0.short_description == "test"
    assert test_case_0.long_description is None
    assert test_case_0.blank_after_short_description is False
    assert test_case_0.blank_after_long_description is False
    assert test_case_0.meta == []
    test_case_1 = test_parser.parse("test :param test: test\n test")
    assert test_case_1.short_description == "test"


# Generated at 2022-06-25 16:25:30.540354
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = "The quick brown fox jumps over the lazy dog."
    desc_0 = parse(text_0)
    assert desc_0.short_description == text_0
    assert desc_0.long_description is None

    text_0 = "The quick brown fox jumps over the lazy dog. Another line."
    desc_0 = parse(text_0)
    assert desc_0.short_description == "The quick brown fox jumps over the lazy dog."
    assert desc_0.long_description == "Another line."

    text_0 = "The quick brown fox\n jumps over the lazy dog.\n Another line."
    desc_0 = parse(text_0)
    assert desc_0.short_description == "The quick brown fox"
    assert desc_0.long_description == "jumps over the lazy dog. Another line."



# Generated at 2022-06-25 16:25:38.753551
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = "Return True if all elements of the iterable are true (or if the iterable is empty)."
    parsed_docstring = parser.parse(docstring)
    assert parsed_docstring.short_description == "Return True if all elements of the iterable are true (or if the iterable is empty)."
    assert parsed_docstring.long_description == None
    assert parsed_docstring.blank_after_short_description == None
    assert parsed_docstring.blank_after_long_description == None
    assert parsed_docstring.meta == []

    docstring = "Return True if all elements of the iterable are true (or if the iterable is empty).\n"
    parsed_docstring = parser.parse(docstring)

# Generated at 2022-06-25 16:25:44.257306
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ds = """Python style.
    :param a: description of a
    """
    parser = GoogleParser()
    res = parser.parse(ds)
    assert res.short_description == "Python style."
    assert res.long_description is None
    assert len(res.meta) == 1
    assert res.meta[0].description == "description of a"
    assert res.meta[0].arg_name == "a"
    assert res.meta[0].type_name is None
    assert res.meta[0].default is None
    assert res.meta[0].is_optional is False
    assert res.meta[0].is_generator is False


# Generated at 2022-06-25 16:25:45.992987
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert False, "Todo: implement"

# Generated at 2022-06-25 16:25:53.515532
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'Short description.\n\nLong description.\n\nArgs:\n  arg1: arg1\n    type: str\n    desc: desc1\n  arg2: arg2\n    type: int, optional\n    desc: desc2\n  arg3: arg3\n    type: bool, optional\n    desc: desc3\n\nReturns:\n  (str, int): return desc\n'
    parser = GoogleParser()
    parsed_text = parser.parse(text)
    actual = parsed_text.meta[0].args

# Generated at 2022-06-25 16:26:05.867291
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    _GoogleParser = GoogleParser(sections=DEFAULT_SECTIONS)
    assert _GoogleParser.parse("") == Docstring()
    assert _GoogleParser.parse("\n") == Docstring()
    assert _GoogleParser.parse("\n\n") == Docstring()
    assert _GoogleParser.parse("a") == Docstring(short_description="a",
                                                          blank_after_short_description=False)
    assert _GoogleParser.parse("\n\na") == Docstring(short_description="a",
                                                               blank_after_short_description=False)
    assert _GoogleParser.parse("\n\n\na") == Docstring(short_description="a",
                                                                blank_after_short_description=False)
    assert _GoogleParser.parse("a\n\n") == Docstring

# Generated at 2022-06-25 16:26:08.869063
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
# Uncomment to enable test case
    text = None
    rslt = gp.parse(text)


if __name__ == "__main__":
    pass

# Generated at 2022-06-25 16:26:18.610424
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "Short description\n\nLonger description."
    test0 = GoogleParser().parse(text)
    assert test0.short_description == "Short description"
    assert test0.long_description == "Longer description."
    assert not test0.blank_after_long_description
    assert not test0.blank_after_short_description

    text = "Short description\n\n\n\nLonger description."
    test1 = GoogleParser().parse(text)
    assert test1.short_description == "Short description"
    assert test1.blank_after_short_description
    assert test1.long_description == "Longer description."
    assert test1.blank_after_long_description

    text = "Short description\n\n\n\nLonger description.\n\n\n"
    test2

# Generated at 2022-06-25 16:26:30.074670
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc_1 = inspect.cleandoc(
        """\
    This is a short description.

    This is a long description.

    This is an example section.

    This is a returns section:

        int: The return value.
    """
    )
    doc_2 = inspect.cleandoc(
        """\
    This is a short description.

    This is a long description.

    This is an example section.

    This is a returns section:

        The return value.
    """
    )
    doc_3 = inspect.cleandoc(
        """\
    This is  a short description   .
    This is a long 
    description.
    This  is  an example section.

    This is a returns 
    section:
        The return value.
    """
    )


# Generated at 2022-06-25 16:26:48.510331
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """Docstring for function test_GoogleParser_parse.\n\nArgs:\n  iterable (Iterable[int]): Something that can be iterated over.\n\nYields:\n  int: The next value in the iteration.\n\n"""
    ret_0 = google_parser_0.parse(text_0)
    assert str(ret_0.short_description) == "Docstring for function test_GoogleParser_parse."
    assert ret_0.blank_after_short_description == True
    assert str(ret_0.long_description) == ""
    assert ret_0.blank_after_long_description == False
    assert len(ret_0.meta) == 3

# Generated at 2022-06-25 16:26:53.448412
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    # Test arg 'text' with a mock instance of the type 'str'

    # Test arg 'text' with a mock instance of the type 'None'
    text = None
    expected = Docstring()
    actual_value = google_parser.parse(text)
    assert actual_value == expected


# Generated at 2022-06-25 16:26:54.391707
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert 0 == 0



# Generated at 2022-06-25 16:26:59.813711
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()

    # Test keyword args
    docstring = inspect.cleandoc("""\
        This method is not intended to be called directly but only by the
        deque iterator. Raises a RuntimeError if this method is called.

        Keyword args:
            blah blah blah

        Returns:
            blah blah blah

        Example:
            blah blah blah
        """)
    google_parser_1.parse(docstring)



# Generated at 2022-06-25 16:27:10.042267
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = 'This class is used to represent a book.   A book has a title and a price.'
    text_1 = """
        This class is used to represent a book.   A book has a title and a price.

        Example:

            book = Book('Harry Potter', 23.30)
            print(book.title)
            book.price = 24.00
            print(book.price)

        :param title: The title of the book.
        :type title: str
        :param price: The price of the book.
        :type price: float
        :returns: A new :class:`Book` object.
        :rtype: :class:`Book`

        .. note::

           This is an example of a note.

        .. seealso:: :class:`BookStore`
        """

# Generated at 2022-06-25 16:27:19.447828
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test cases
    # Case 1
    docstring = """
    Get some info.
    
    Returns:
        None
    """
    expected_short_description = "Get some info."
    expected_long_description = None
    expected_blank_after_short_description = False
    expected_blank_after_long_description = False
    expected_meta = [
        DocstringMeta(
            args=['returns'],
            description="None",
        )
    ]
    parsed = GoogleParser().parse(docstring)
    actual_short_description = parsed.short_description
    actual_long_description = parsed.long_description
    actual_blank_after_short_description = parsed.blank_after_short_description
    actual_blank_after_long_description = parsed.blank_after_long_description
    actual_

# Generated at 2022-06-25 16:27:24.887190
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:27:38.302126
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create a GoogleParser
    google_parser_1 = GoogleParser()
    # Set up test parameters
    text_1 = '''
    Args:
        name_1: The name of a file.
        name_2: The name of a file.
    '''

# Generated at 2022-06-25 16:27:51.444230
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def do_test(text, title_colon, sections, expected):
        google_parser = GoogleParser(sections, title_colon=title_colon)
        ret = google_parser.parse(text)
        assert ret == expected

    text = """Summarize the function here.
    Args:
        param_1 (str): The first parameter.
        param_2 (str): The second parameter.
    Raises:
        AttributeError: the error description.
    Returns:
        str: The return value.
    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.
    >>> print([i for i in example_generator(4)])
    [0, 1, 2, 3]
    """
    title_colon = True

# Generated at 2022-06-25 16:27:53.222164
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.parse("")


# Generated at 2022-06-25 16:27:57.208765
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert 1 == 1

# Generated at 2022-06-25 16:28:09.233874
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    case_0 = "Parses Google-style docstrings and returns a Docstring namedtuple.\r\n\r\n:return: parsed docstring\r\n"
    case_0_expected = Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["return"], description="parsed docstring"
            )
        ],
    )
    case_1 = "An implementation of the Google docstring format.\r\n\r\n:return: parsed docstring\r\n\r\n"

# Generated at 2022-06-25 16:28:18.948341
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    doctstring_0 = google_parser_0.parse("")
    doctstring_1 = google_parser_0.parse("    Not short description.")
    doctstring_2 = google_parser_0.parse("""\
    Not short description.
    Not long description.""")
    doctstring_3 = google_parser_0.parse("""\
    Not short description.

    Not long description.""")

if __name__ == "__main__":
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:28:32.293121
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    text = """ Method documentation

    :param arg1: The first value.
    :param arg2: The first value.
    :returns: Describe the return value

    """
    docstring = google_parser.parse(text)
    assert docstring.short_description ==  "Method documentation"
    assert docstring.long_description == None
    assert docstring.meta[0].args == ['param', 'arg1']
    assert docstring.meta[0].description == 'The first value.'
    assert docstring.meta[0].arg_name == 'arg1'
    assert docstring.meta[0].type_name == None
    assert docstring.meta[0].is_optional == None
    assert docstring.meta[0].default == None

# Generated at 2022-06-25 16:28:36.316643
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("\nTesting GoogleParser.parse")
    test_text = "A method that returns an integer"
    assert GoogleParser().parse(test_text).short_description == test_text


# Generated at 2022-06-25 16:28:48.344628
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test inputs and expected results
    google_parser_1 = GoogleParser()
    text_1 = """
    This is a function.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    bool
        The return value. True for success, False otherwise.

    :raises: NotImplementedError
    """
    expected_1 = """
    This is a function.

    Parameters
    ----------
    arg1 : int
        The first argument.
    arg2 : str
        The second argument.

    Returns
    -------
    bool
        The return value. True for success, False otherwise.

    :raises: NotImplementedError
    """
    # Perform the test

# Generated at 2022-06-25 16:28:59.987237
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    title_colon_0 = True
    sections_0 = None
    google_parser_0 = GoogleParser(sections=sections_0, title_colon=title_colon_0)

# Generated at 2022-06-25 16:29:10.751274
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = inspect.cleandoc(
        """
        Short description.

        Long description.

        Args:
            arg1 (str): Description of `arg1`.
            arg2: Description of `arg2`.
        Returns:
            str: Description of return value.
        """
    )
    docstring_1 = google_parser_0.parse(docstring_0)
    assert docstring_1.short_description == "Short description."
    assert docstring_1.long_description == "Long description."
    assert docstring_1.meta[0].description == "Description of `arg1`."
    assert docstring_1.meta[1].description == "Description of `arg2`."

# Generated at 2022-06-25 16:29:13.347855
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_parse = GoogleParser()
    result_parse = google_parser_parse.parse("")
    assert len(result_parse) > 0


# Generated at 2022-06-25 16:29:23.337827
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    docstring_0 = google_parser_1.parse("")
    print('Should be "":', docstring_0.short_description == "")
    print('Should be None:', docstring_0.long_description is None)
    print('Should be None:', docstring_0.meta == [])
    print("\n")
    docstring_1 = google_parser_1.parse("")
    print('Should be "":', docstring_1.short_description == "")
    print("\n")
    print('Should be None:', docstring_1.long_description is None)
    print("\n")
    print('Should be None:', docstring_1.meta == [])
    print("\n")

# Generated at 2022-06-25 16:29:39.581728
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    assert google_parser_0.parse("") == Docstring()
    assert google_parser_0.parse("a") == Docstring(
        short_description="a",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )
    assert google_parser_0.parse("a\n") == Docstring(
        short_description="a",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

# Generated at 2022-06-25 16:29:43.757870
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = Docstring()
    assert google_parser_0.parse('Bla bla bla\n\nArgs:\n  arg1 (int):\n    bla bla bla\n') == docstring_0

# Generated at 2022-06-25 16:29:48.878513
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    assert(google_parser.parse("Returns the sum of the values for the requested axis."))
    assert(google_parser.parse(""))

# Generated at 2022-06-25 16:29:59.575474
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    docstring_1 = GoogleParser.parse(google_parser_1, """
        Test docstring.

        Args:
        arg1 (str): Test arg1.

        Kwargs:
        kwarg1 (str, optional): Test kwarg1. Defaults to "foo".
        kwarg2 (bool): Test kwarg2.
    """)
    assert [
        docstring_1.short_description,
        docstring_1.long_description,
        docstring_1.blank_after_short_description,
        docstring_1.blank_after_long_description
    ] == ['Test docstring.', None, True, False]
    assert docstring_1.meta[0].args == ['param', 'arg1 (str)']
    assert docstring_

# Generated at 2022-06-25 16:30:07.892223
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = """
            Args:
              param1: The first parameter.
            Args:
              param1: The first parameter.
            """
    expected = '''
               Args:
                 param1: The first parameter.
               Args:
                 param1: The first parameter.
            '''
    actual = google_parser_0.parse(text)
    assert (expected, actual) == (expected, actual)



# Generated at 2022-06-25 16:30:19.777642
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("") == Docstring()
    assert parse("Expected paramenter name.") == Docstring()
    assert parse("Can't infer indent from \"\"") == Docstring()
    assert parse("No specification for \"title\": \"\"") == Docstring()
    assert parse("( )") == Docstring()
    assert parse("(") == Docstring()
    assert parse(")") == Docstring()
    assert parse("( )") == Docstring()
    assert parse("(") == Docstring()
    assert parse(")") == Docstring()
    assert parse("(param)") == Docstring()
    assert parse("(param,)") == Docstring()
    assert parse("(param, )") == Docstring()
    assert parse("(param, )") == Docstring()
    assert parse("(param, )") == Docstring()

# Generated at 2022-06-25 16:30:31.294879
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    google_parser = GoogleParser(
        sections=[
            Section("Args", "param", SectionType.MULTIPLE),
            Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
        ],
        title_colon=True,
    )

    # Case #0
    docstring = google_parser.parse(
        """
    Compute the sum of a list of numbers.

    Args:
        numbers (list of int): A list of integers.

    Returns:
        int: The sum of the numbers.
    """
    )
    assert docstring.short_description == "Compute the sum of a list of numbers."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description
    assert not docstring.blank_after_long

# Generated at 2022-06-25 16:30:42.004778
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:30:49.777807
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()

    assert google_parser.parse("") == Docstring()

    assert google_parser.parse("None") == Docstring(
        short_description="None"
    )

    assert google_parser.parse("None\n") == Docstring(
        short_description="None"
    )

    assert google_parser.parse("\nNone\n\n") == Docstring(
        short_description="None"
    )

    assert google_parser.parse("\n\nNone\n\n") == Docstring(
        short_description="None"
    )

    assert google_parser.parse("\n \nNone\n\n") == Docstring(
        short_description="None"
    )


# Generated at 2022-06-25 16:30:59.687832
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()
    text_0 = """
    Compute the XYZ representation.

    See Also
    --------
    transformations.euler_from_quat : Euler angles from `quaternion`
    quaternions.quat_from_euler : `quaternion` from Euler angles
    """
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == "Compute the XYZ representation."
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.long_description == """\
See Also
--------
transformations.euler_from_quat : Euler angles from `quaternion`
quaternions.quat_from_euler : `quaternion` from Euler angles"""

# Generated at 2022-06-25 16:31:09.076801
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Setup method call
    docstring = ""

    # Call method
    google_parser = GoogleParser()
    google_docstring = google_parser.parse(docstring)

    # Check Call
    assert google_docstring.blank_after_short_description == False
    assert google_docstring.blank_after_long_description == True
    assert google_docstring.short_description == None
    assert google_docstring.long_description == None
    assert google_docstring.meta == []


# Generated at 2022-06-25 16:31:22.061263
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    code = "Hello, world!\n\nThis is a test."
    ret_val = google_parser_0.parse(code)
    assert ret_val.short_description == "Hello, world!"
    assert ret_val.long_description == "This is a test."
    assert ret_val.blank_after_short_description == True
    assert ret_val.blank_after_long_description == False
    assert len(ret_val.meta) == 0

    code = "Hello, world!\n\nThis is a test.\n\nArgs:\n    first: First string.\n    second (str or None): Second string.  Defaults to None."
    ret_val = google_parser_0.parse(code)

# Generated at 2022-06-25 16:31:23.865745
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()

    return_value_1 = google_parser_0.parse(text='')
    assert return_value_1 == None


# Generated at 2022-06-25 16:31:29.929074
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_arg_0 = """Does something amazing.

Args:
    param1: The first parameter.
    param2: The second parameter.
    *args: Variable length argument list.
    **kwargs: Arbitrary keyword arguments.

Returns:
    True if verbose.

Raises:
    AttributeError, KeyError
"""
    google_parser_0.parse(str_arg_0)


# Generated at 2022-06-25 16:31:41.171172
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

# Generated at 2022-06-25 16:31:44.741568
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse("\n")
    docstring_1 = google_parser_0.parse("\n")

    assert docstring_0.__eq__(docstring_1)


# Generated at 2022-06-25 16:31:52.314126
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse('') == Docstring(short_description=None, long_description=None, meta=[])


if __name__ == "__main__":
    google_parser_0 = GoogleParser()
    print(google_parser_0.sections.keys())

# Generated at 2022-06-25 16:32:04.866073
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse("Example:\n    >>> some_example()\n")
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.meta[0].args == ["examples", "Example:"]
    assert docstring_0.meta[0].description == ">>> some_example()"

    # Test case 1
    google_parser_1 = GoogleParser()
    docstring_1 = google_parser_1.parse(
        "Example:\n    >>> some_example()\n\nExample:\n    >>> some_example()\n"
    )
    assert docstring_1.short_description == None
    assert docstring_1.long_description

# Generated at 2022-06-25 16:32:13.613892
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    # Read in the file containing test case data
    myFile = open('tests/google_parser/google_parser_parse_test_data.txt')
    lines = myFile.readlines()
    myFile.close()
    # The first line contains number of test cases
    test_cases = int(lines[0])
    for i in range(test_cases):
        # Extract the test case data
        text = lines[3*i+1].strip()
        # Extract the expected results
        expected_docstring = lines[3*i+2].strip()
        expected_meta = lines[3*i+3].strip()
        # Use the algorithm under test to find the docstring
        actual_docstring = google_parser.parse(text)
        print(actual_docstring)
        # Check the

# Generated at 2022-06-25 16:32:21.098920
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Set up test parameters
    google_parser = GoogleParser()
    text = "This is a docstring."

    # Expected outcome
    expected_docstring = Docstring()
    expected_docstring.short_description = "This is a docstring."

    # Perform test
    actual_docstring = google_parser.parse(text)

    assert actual_docstring == expected_docstring

# Generated at 2022-06-25 16:32:35.174067
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_2 = GoogleParser()
    docstr = """Calculate the volume of a pyramid.
        Arguments:
            length (int): The length of the pyramid.
            width (int): The width of the pyramid.
            height (int): The height of the pyramid.
        Returns:
            int: The volume of the pyramid.
        """
    result = google_parser_2.parse(docstr)
    assert result.short_description == "Calculate the volume of a pyramid."
    assert result.long_description == """Arguments:
            length (int): The length of the pyramid.
            width (int): The width of the pyramid.
            height (int): The height of the pyramid.
        Returns:
            int: The volume of the pyramid."""
    assert result.blank_after_short_description == True
    assert result

# Generated at 2022-06-25 16:32:39.308094
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = ''
    ret = google_parser_0.parse(text)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert ret.meta == []


# Generated at 2022-06-25 16:32:45.546812
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    docstring_0 = parse("Test Docstring\n")
    assert docstring_0.short_description == "Test Docstring"
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []

    docstring_1 = parse("Test Docstring\n\nThis is a long description.\n")
    assert docstring_1.short_description == "Test Docstring"
    assert docstring_1.long_description == "This is a long description."
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert doc

# Generated at 2022-06-25 16:32:55.700557
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()
    assert google_parser_0.parse("") == Docstring()
    google_parser_1 = GoogleParser()
    assert google_parser_1.parse("") == Docstring()
    google_parser_2 = GoogleParser()
    assert google_parser_2.parse("") == Docstring()
    google_parser_3 = GoogleParser()
    assert google_parser_3.parse("") == Docstring()
    google_parser_4 = GoogleParser()
    assert google_parser_4.parse("") == Docstring()
    google_parser_5 = GoogleParser()
    assert google_parser_5.parse("") == Docstring()



# Generated at 2022-06-25 16:33:05.834677
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = """This is a test function.

The first line of the docstring is brief explanation, which may be completed
with a longer one.

Examples
--------
Examples should be written in doctest format, and should illustrate how
to use the function.

>>> a=[1,2,3]
>>> print([x + 3 for x in a])
[4, 5, 6]

"""
    doc = parse(docstring_0)
    assert doc.short_description == "This is a test function."
    assert doc.long_description is not None
    print(doc.long_description)
    return doc

