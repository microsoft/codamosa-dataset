

# Generated at 2022-06-25 16:23:53.610732
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    #
    text_0 = """
    This is a method that does a lot of things.

    This is the long description, which provides a more detailed explanation
    of the function.

    The function __does__ a few things, including:

    1.  Doing some stuff.
    2.  Doing some other stuff.
    3.  Doing a third thing.

    Parameter w is a good parameter.
    Parameter x is a bad parameter, and it defaults to 10.
    Parameter y is an optional parameter.
    Parameters a, b, c are all bad parameters.

    Raises:
        ValueError: The `x` parameter is bad.

    Returns:
        None.

    """
    ret_0 = google_parser_0.parse(text_0)



# Generated at 2022-06-25 16:24:04.348100
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test case for method parse of class GoogleParser."""
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse("") == Docstring()
    assert google_parser_0.parse("None\n") == Docstring(short_description="None")
    assert google_parser_0.parse("None\n\n") == Docstring(
        short_description="None", blank_after_short_description=True
    )
    assert google_parser_0.parse("None\n\n\n") == Docstring(
        short_description="None",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    assert google_parser_0.parse("Short only.\n") == Docstring(
        short_description="Short only."
    )
   

# Generated at 2022-06-25 16:24:13.456889
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'This is the first line of the docstring.\n    The second line\n    is indented.\n\n    That is the end of the description.\n\n    Parameters\n    ----------\n    arg1 : str\n        Description of arg1. Defaults to "foo".\n    arg2 : List[str]\n        Description of arg2. Defaults to None.\n\n    Returns\n    -------\n    bool\n        Description of return value.\n\n    Examples\n    --------\n\n    >>> func(1)\n    True'
    google_parser_0 = GoogleParser()
    assert isinstance(google_parser_0.parse(text), Docstring)


# Generated at 2022-06-25 16:24:21.290565
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    subject_0 = google_parser_0.parse("Parse the Google-style docstring into its components.")
    assert subject_0.short_description == "Parse the Google-style docstring into its components." and subject_0.long_description is None and subject_0.blank_after_short_description is True and subject_0.blank_after_long_description is True and not subject_0.meta


if __name__ == "__main__":
    import pytest
    pytest.main(str(__file__).replace(".pyc", ".py"))

# Generated at 2022-06-25 16:24:26.965429
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse("""
        '''This is a multiline function docstring.

        Args:
            arg1: An important argument.
            arg2: Another important argument.

        Returns:
            And its returned value.
        '''
    """)
    assert docstring_0.short_description == 'This is a multiline function docstring.'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 3
    assert docstring_0.meta[0].__class__.__name__=='DocstringParam'

# Generated at 2022-06-25 16:24:39.736875
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    test method - parse

    Returns:
       (test description, error if any)
    """
    google_parser_0 = GoogleParser()
    text_0 = "test doc string"
    result_0 = google_parser_0.parse(text_0)
    expected_0 = {'short_description': 'test doc string', 'long_description': None, 'blank_after_short_description': False, 'blank_after_long_description': True, 'meta': []}
    if not result_0 == expected_0:
        return "parse - Expected: {}, Found: {}".format(expected_0, result_0)
    text_1 = """
    doc with no meta

    This is just a rambling description.
    """
    result_1 = google_parser_0.parse(text_1)
   

# Generated at 2022-06-25 16:24:42.883378
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test Case 0
    google_parser_0 = GoogleParser()
    text = ""
    assert google_parser_0.parse(text) == Docstring()


# Generated at 2022-06-25 16:24:46.358831
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    docstring_2 = google_parser_1.parse("")
    assert docstring_2.short_description == None


# Generated at 2022-06-25 16:24:56.937435
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = '\n    Short summary.\n\n    Optional more detailed summary.\n    '

    assert google_parser_0.parse(text) == Docstring(
        short_description='Short summary.',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description='Optional more detailed summary.',
        meta=[],
    )


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-25 16:25:09.978628
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    # Test 1: input = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla scelerisque euismod dui, quis gravida erat feugiat vel. Nulla et velit mauris.\n\nExample:\n    >>> lorem_ipsum()\n\nNunc aliquet, nisi eget congue venenatis, risus magna gravida felis, quis luctus lectus purus vel enim. Donec aliquam consequat felis, quis mattis dui porta at.\n\nArgs:\n    param1 (int): The first parameter.\n    param2 (str): The second parameter. Defaults to \"foo\".\n\nKeyword Args:\n    param3

# Generated at 2022-06-25 16:25:33.632781
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    def parse(text): return google_parser.parse(text)

    s = """
    This is a short description.

    This is the long description.
    """

    assert parse(s).short_description == "This is a short description."
    assert parse(s).long_description == "This is the long description."

    s = """
    This is a short description.

    This is the long description.
    """

    d = parse(s)
    assert d.short_description == "This is a short description."
    assert d.long_description == "This is the long description."

    s = """This is a short description."""

    d = parse(s)
    assert d.short_description == "This is a short description."
    assert d.long_description is None

    s = parse

# Generated at 2022-06-25 16:25:37.946700
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = ""
    docstring = google_parser_0.parse(text)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 0


# Generated at 2022-06-25 16:25:43.736966
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = inspect.cleandoc(
        """
        Short description.

        Long description.

        Args:
            arg1 (str): The first argument.
            arg2 (int): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.
        """
    )
    doc = inspect.cleandoc(
        """
        Short description.

        Long description.

        Args:
            arg1 (str): The first argument.
            arg2 (int): The second argument.

        Returns:
            bool: The return value. True for success, False otherwise.
        """
    )
    assert doc == GoogleParser().parse(text).to_google()

# Generated at 2022-06-25 16:25:52.437612
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "Manually create a Markdown table. Use this if you need more control over the output than provided by the other table methods. You can also use this to create a table from scratch (without reading a file or data). This method does not escape characters, so make sure do that yourself if necessary. The table will be created using the data provided and will have default styling.\n\n    :param data: A list of lists containing the table data. Each row must have the same number of items.\n    :param headers: A list containing the headers for the table.\n    :returns: A string containing a Markdown table.\n    "
    docstring_0 = google_parser_0.parse(text_0)
    str_0 = str(docstring_0)

# Generated at 2022-06-25 16:25:58.776803
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    text = '''    This is a short description.

    This is long description which has a
    second line.'''
    google_parser_0 = GoogleParser()

    # Act
    result = google_parser_0.parse(text)

    # Assert
    assert result.long_description == 'This is long description which has a\nsecond line.'


# Generated at 2022-06-25 16:26:10.548138
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_0 = "Args:"
    docstring_0 = google_parser_0.parse(str_0)
    str_1 = "Type:"
    docstring_1 = google_parser_0.parse(str_1)
    str_2 = "Raises:"
    docstring_2 = google_parser_0.parse(str_2)
    str_3 = "Returns:"
    docstring_3 = google_parser_0.parse(str_3)
    str_4 = "Yields:"
    docstring_4 = google_parser_0.parse(str_4)
    str_5 = "Raises:"
    docstring_5 = google_parser_0.parse(str_5)
    str_6 = "Raises:"

# Generated at 2022-06-25 16:26:22.185804
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Ensure that an empty string returns an empty docstring.
    assert GoogleParser().parse("") == Docstring()

    # Ensure that we can parse all section types.
    test = """
    Top level description.

    Long description.

    Parameters:
        param: parameter description
        param (TYPE): parameter description with type

    Returns:
        return description
        return (TYPE) return description with type

    Raises:
        Exception: exception description
        Exception (TYPE): exception description with type

    Yields:
        Type: yield description
        Type (TYPE): yield description with type

    Examples:
        Code example

    Attributes:
        attr1: attribute description
        attr1 (TYPE): attribute description with type
    """
    test = inspect.cleandoc(test)
    result = GoogleParser().parse(test)
    assert result.short

# Generated at 2022-06-25 16:26:33.009492
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_1 = GoogleParser()
    google_parser_2 = GoogleParser()
    google_parser_3 = GoogleParser()
    google_parser_4 = GoogleParser()
    google_parser_5 = GoogleParser()
    google_parser_6 = GoogleParser()
    google_parser_7 = GoogleParser()
    google_parser_8 = GoogleParser()
    google_parser_9 = GoogleParser()
    google_parser_10 = GoogleParser()
    google_parser_11 = GoogleParser()
    google_parser_12 = GoogleParser()

    google_parser_0.parse("Parse the Google-style docstring into its components.\n\n    :returns: parsed docstring\n    ")

# Generated at 2022-06-25 16:26:44.282592
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    s = """
    A short description.

    A long description.

    Parameters
    ----------
    param1 : int
        The first parameter.
    param2 : str
        The second parameter.
    param3 : list of ints
        The third parameter.

    Returns
    -------
    str
        The return value.

    Raises
    ------
    AttributeError
        The Raisin

    Yields
    ------
    int
        The yield value.
    """

# Generated at 2022-06-25 16:26:55.204875
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    google_parser_0 = GoogleParser()

    # Invoke method

# Generated at 2022-06-25 16:27:06.235755
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """sdfsadf

    with optional:
        :param int count: The number of things. Defaults to 10.
        :returns: The list of things.
        :raises ValueError: If count is negative.
    """
    google_parser_0.parse(text_0)

if __name__ == "__main__":
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:27:13.802963
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    google_parser_1 = GoogleParser()

    s = 'foo'
    # Act
    docstring = google_parser_1.parse(s)

    # Assert
    assert docstring.short_description == 'foo'
    assert docstring.long_description is None
    assert docstring.meta == []
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False



# Generated at 2022-06-25 16:27:21.564552
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse('') == Docstring(
        long_description=None,
        short_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert google_parser_0.parse('Returns a list of the first n numbers.') == Docstring(
        long_description=None,
        short_description='Returns a list of the first n numbers.',
        meta=[DocstringMeta(
            args=["returns"],
            description='Returns a list of the first n numbers.',
        )],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )


# Generated at 2022-06-25 16:27:34.436122
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    docstring = inspect.cleandoc("""
        This is a longer description of this function.

        Parameters
        ----------
        arg1 : int
            The first argument.

        Returns
        -------
        bool
            The return value. True for success, False otherwise.
        """)
    docstring_2 = google_parser_1.parse(docstring)
    assert docstring_2.short_description == "This is a longer description of this function."
    assert docstring_2.blank_after_short_description
    assert docstring_2.long_description == "The return value. True for success, False otherwise."
    assert not docstring_2.blank_after_long_description
    assert docstring_2.meta[0].args == ["param", "arg1 : int"]

# Generated at 2022-06-25 16:27:37.062079
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'Function with basic documentation.'
    docstring = parse(text)
    assert docstring.short_description == text


# Generated at 2022-06-25 16:27:44.528417
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 0:
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse("")
    try:
        google_parser_0.parse("")
    except ParseError:
        pass

# Test 1:
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse("""
    This is a docstring.

    This is a longer description.

    Blah blah blah.
    
    Arguments:
        a (str): This is a.
        b (str): This is b.
    
    Returns:
        str: returns a str
        """)

# Generated at 2022-06-25 16:27:54.485541
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_parse_0 = GoogleParser().parse("This function makes a plot of a 3D function")
    google_parser_parse_1 = GoogleParser().parse("This function makes a plot of a 3D function\n\nIt uses matplotlib.pyplot.plot to plot the function\n")
    google_parser_parse_2 = GoogleParser().parse("This function makes a plot of a 3D function\n\nIt uses matplotlib.pyplot.plot to plot the function\n\nThere is also a flag for plotting the function.\n")

# Generated at 2022-06-25 16:27:58.945565
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test parse method of class GoogleParser."""
    google_parser_0 = GoogleParser()
    parser_0 = google_parser_0.parse
    test_case_0()
    test_case_1 = parser_0
    test_case_2 = parser_0
    test_case_3 = parser_0



# Generated at 2022-06-25 16:28:10.725384
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Description of method that is being tested.
    """
    google_parser_1 = GoogleParser()

# Generated at 2022-06-25 16:28:21.808806
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # google_parser_0.parse has type <class 'method'>
    docstring_0 = parse("Parse the Google-style docstring into its components.")
    # docstring_0.short_description == "Parse the Google-style docstring into its components."
    # docstring_0.blank_after_short_description == False
    # docstring_0.long_description == None
    # docstring_0.blank_after_long_description == False
    # docstring_0.meta == []


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:28:40.950199
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()

    # Test case for method parse of class GoogleParser
    text_0 = '''
    Test for method parse of class GoogleParser.

    This method will test the class GoogleParser and its parse method.

    Args:
        text_0 (str): Test case for method parse of class GoogleParser.

    Returns:
        None: Test case for method parse of class GoogleParser.

    '''

# Generated at 2022-06-25 16:28:51.464599
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = """
    This is just a normal comment.

    This is another normal comment.

    :param arg1: The first argument.
    :param arg2: The second argument. Defaults to 42.
    :returns: The sum of the arguments.
    :raises Exception: When the sum is too big.
    """

# Generated at 2022-06-25 16:29:01.812030
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert isinstance(google_parser_0.parse('foo'), Docstring)
    assert isinstance(google_parser_0.parse('foo'), Docstring)
    assert isinstance(google_parser_0.parse('foo'), Docstring)
    assert isinstance(google_parser_0.parse('foo'), Docstring)
    assert isinstance(google_parser_0.parse('foo'), Docstring)
    assert isinstance(google_parser_0.parse('foo'), Docstring)
    assert isinstance(google_parser_0.parse('foo'), Docstring)
    assert isinstance(google_parser_0.parse('foo'), Docstring)
    assert isinstance(google_parser_0.parse('foo'), Docstring)

# Generated at 2022-06-25 16:29:06.833805
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.parse(text="")
    google_parser_0.parse(text="Compute the sum of two numbers.\n\n")


# Generated at 2022-06-25 16:29:18.834350
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_0 = "DOCSTRING"
    Docstring_0 = google_parser_0.parse(str_0)
    str_1 = "DOCSTRING"
    Docstring_1 = google_parser_0.parse(str_1)
    str_2 = ""
    Docstring_2 = google_parser_0.parse(str_2)
    str_3 = ""
    Docstring_3 = google_parser_0.parse(str_3)
    str_4 = ""
    Docstring_4 = google_parser_0.parse(str_4)

# Generated at 2022-06-25 16:29:25.584551
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test RST docstring parsing.
    """
    # Tests of a docstring with only a short description
    # Test of a docstring with two or more title
    google_parser_2 = GoogleParser()
    docstring_3 = "Split dict into dict of dicts."
    docstring_3 += "\n\n"
    docstring_3 += "\x08"
    assert google_parser_2.parse(docstring_3) == Docstring(
        short_description="Split dict into dict of dicts.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=None,
        meta=[DocstringMeta(
            args=[],
            description="Split dict into dict of dicts.",
        )],
    )


# Generated at 2022-06-25 16:29:26.952522
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()


# Generated at 2022-06-25 16:29:28.557246
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    google_parser.parse('')

# Generated at 2022-06-25 16:29:31.797511
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()

    text_0 = "Parses a Google-style docstring into its components."

    ret = google_parser_0.parse(
        text_0
    )




# Generated at 2022-06-25 16:29:38.026224
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = "Hello\n"
    google_parser_0 = GoogleParser()
    Docstring_0 = google_parser_0.parse(text_0)
    assert Docstring_0.short_description == "Hello"
    assert not Docstring_0.long_description
    

# Generated at 2022-06-25 16:29:57.397788
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0_ret = google_parser_0.parse("")
    assert isinstance(google_parser_0_ret, Docstring)
    assert google_parser_0_ret.short_description is None
    assert google_parser_0_ret.long_description is None
    assert google_parser_0_ret.blank_after_short_description is False
    assert google_parser_0_ret.blank_after_long_description is False
    assert google_parser_0_ret.meta == []

# Generated at 2022-06-25 16:30:03.760775
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = ""
    returned_0 = google_parser_0.parse(text_0)
    assert returned_0 == Docstring(meta=[],
                                   short_description=None,
                                   long_description=None,
                                   blank_after_short_description=False,
                                   blank_after_long_description=False)


# Generated at 2022-06-25 16:30:17.368198
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Input
    text = """
    This is a function.

    Args:
        one (int): A number.
        two (str): A string.

    Example:
        Examples can be given using either the ``Example`` or ``Examples``
        sections. Sections support any reStructuredText formatting, including
        literal blocks::

            $ hello_world
            Hello World!
    """

    google_parser_0 = GoogleParser()
    result = google_parser_0.parse(text)

    assert result.short_description == "This is a function."
    assert result.blank_after_short_description == True

# Generated at 2022-06-25 16:30:23.914259
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = ""
    docstring_1 = Docstring()
    assert google_parser_0.parse(docstring_0) == docstring_1

    google_parser_1 = GoogleParser()
    docstring_2 = "This is short description."
    docstring_3 = Docstring()
    docstring_3.short_description = "This is short description."
    assert google_parser_1.parse(docstring_2) == docstring_3


# Generated at 2022-06-25 16:30:26.969105
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Local variable declarations
    text = ""
    # Method invocation
    ret = GoogleParser().parse(text)
    # Assertions
    assert isinstance(ret, object)


# Generated at 2022-06-25 16:30:36.162137
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # Parse case 0: with: title colon
    text_0 = """
     title1:
       aaaa
       bbbb
       cccc
       dddd
     title2:
       aaaa
       bbbb
       cccc
       dddd
    """
    ret_0 = google_parser_0.parse(text_0)
    assert ret_0.short_description is None
    assert ret_0.long_description is None
    assert ret_0.blank_after_short_description is False
    assert ret_0.blank_after_long_description is False
    assert len(ret_0.meta) == 0
    assert ret_0.empty is False
    # Parse case 1: without: title colon

# Generated at 2022-06-25 16:30:44.587075
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup test data
    text_0_0 = """This is a sample docstring.

    This is the long description. This uses the
    cleandoc function.
    """
    text_0_1 = """This is a sample docstring.

    This is the long description. This uses the
    cleandoc function.
    """
    text_0_2 = """This is a sample docstring.

    This is the long description. This uses the
    cleandoc function.
    """
    text_1_0 = """This is a sample docstring.

    This is the long description. This uses the
    cleandoc function.

    Arguments:
        arg1 (int): Description of `arg1`
        arg2 (str, optional): Description of `arg2`

    Returns:
        int: Description of return value
    """


# Generated at 2022-06-25 16:30:52.561733
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "Docstring to be parsed."
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == "Docstring to be parsed."


if __name__ == "__main__":
    import sys

    sys.exit(pytest.main(args=sys.argv))

# Generated at 2022-06-25 16:31:01.050844
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test = """Finds pythagorean triples.

A pythagorean triple is a set of three natural numbers, a < b < c,
for which a**2 + b**2 = c**2

Examples:
    3**2 + 4**2 == 5**2
    6**2 + 8**2 == 10**2
    7**2 + 24**2 == 25**2

Args:
    limit (int): The limit for the largest component.

Returns:
    List of tuples (a, b, c) for which a**2 + b**2 == c**2
    and a < b < c <= limit.

Raises:
    ValueError: if limit < 3
"""
    docstr = google_parser_0.parse(test)

# Generated at 2022-06-25 16:31:09.102615
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:31:26.720673
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = ""
    docstring_0 = google_parser_0.parse(text_0)
    text_1 = "Method short description.\n\nMethod long description."
    docstring_1 = google_parser_0.parse(text_1)
    text_2 = "Method short description.\n\nMethod long description.\n\n"
    docstring_2 = google_parser_0.parse(text_2)
    text_3 = "Method short description.\n\n\nMethod long description."
    docstring_3 = google_parser_0.parse(text_3)
    text_4 = "Method short description.\n\nMethod long description.\n\nArguments:\n    arg1 -- argument long description."

# Generated at 2022-06-25 16:31:38.650903
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Fixture
    google_parser_0 = GoogleParser()
    google_parser_0._setup()
    text_0 = "Brief description.\n\nLong description.\n\nArgs:\n  arg1: An argument.\n  arg2 (int, optional): Another argument.\n\nReturns:\n  A value."

# Generated at 2022-06-25 16:31:44.800934
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Unit test for method parse of class GoogleParser"""
    google_parser = GoogleParser()
    docstring = inspect.cleandoc("""
    Sums two numbers.

    Example::

        >>> sum(1, 2)
        3

    :param x: First number.
    :param y: Second number.
    :returns: Sum.
    """)
    result = google_parser.parse(docstring)
    print(result)



# Generated at 2022-06-25 16:31:50.196008
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = "something something\n something something\n"
    ret_0 = Docstring()
    ret_0.short_description = 'something something'
    ret_1 = parse(text_0)
    assert ret_0 == ret_1

# Generated at 2022-06-25 16:31:58.306420
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Test case 0
    google_parser_0 = GoogleParser()
    text_0 = ""
    ret_0 = google_parser_0.parse(text_0)
    assert ret_0.short_description is None
    assert ret_0.long_description is None
    assert ret_0.blank_after_short_description is False
    assert ret_0.blank_after_long_description is False
    assert ret_0.meta == []

    # Test case 1
    google_parser_1 = GoogleParser()
    text_1 = """
            Short description.

            Long description.
            """
    ret_1 = google_parser_1.parse(text_1)
    assert ret_1.short_description == "Short description."
    assert ret_1.long_description == "Long description."

# Generated at 2022-06-25 16:31:59.139967
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing parse of GoogleParser")


# Generated at 2022-06-25 16:32:01.879073
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()


# Generated at 2022-06-25 16:32:12.549358
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = Docstring()
    docstring_0.short_description = 'Test case for module.'
    docstring_0.blank_after_short_description = False
    docstring_0.blank_after_long_description = True
    docstring_0.long_description = 'Test case for module.'
    docstring_0.meta = [
        DocstringMeta(args=['param', 'value'],
                      description='Argument to test.'),
        DocstringMeta(args=['returns'],
                      description='True if all tests passed.')
    ]
    docstring_1 = google_parser_0.parse('''\
Test case for module.

:param value: Argument to test.
:returns: True if all tests passed.''')
    assert doc

# Generated at 2022-06-25 16:32:25.092284
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.add_section(Section("", "", SectionType.SINGULAR))
    google_parser_0.add_section(Section("", "", SectionType.SINGULAR))
    google_parser_0.add_section(Section("", "", SectionType.SINGULAR))
    google_parser_0.add_section(Section("", "", SectionType.SINGULAR))
    google_parser_0.add_section(Section("", "", SectionType.SINGULAR))
    google_parser_0.add_section(Section("", "", SectionType.SINGULAR_OR_MULTIPLE))
    google_parser_0.add_section(Section("", "", SectionType.SINGULAR_OR_MULTIPLE))
    google_parser_0

# Generated at 2022-06-25 16:32:29.520412
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "This is a sentence."
    ret_val_1 = google_parser_0.parse(text_0)


# Generated at 2022-06-25 16:32:44.972728
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Test against:
    def test_case(a, b, c=4, d=5, e=6, f=7, g=8, h=9, i=None, j=True, k=False, l=False, m=None):
        """

# Generated at 2022-06-25 16:32:56.561666
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_1 = GoogleParser()
    text_1 = """\
    This is a short description.

    This is a longer description.

    This is a very long description.

    Args:
      arg1: This is a first argument.
      arg2: This is a second argument.

    Returns:
      Returns a value.

    Raises:
      RuntimeError: Always raises this error.
    """
    ret = google_parser_1.parse(text_1)
    assert ret.short_description == "This is a short description."
    assert ret.long_description == """\
This is a longer description.

This is a very long description."""
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    assert ret.meta
    assert len(ret.meta) == 3

# Generated at 2022-06-25 16:32:59.020310
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test failure of method parse when invoked with wrong parameter
    with pytest.raises(Exception) as e:
        google_parser = GoogleParser()
        assert google_parser.parse('this is not a docstring')
