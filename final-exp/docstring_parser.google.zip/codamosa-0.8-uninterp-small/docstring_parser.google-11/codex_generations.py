

# Generated at 2022-06-25 16:23:37.917220
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = """
        This is a long description.

        This is the second sentence of the long description.

        Args:
            arg_one: The first argument.
            arg_two: The second argument.
                This is the second line of the second argument's description.
                This is the third line of the second argument's description.
            arg_three: The third argument.
            arg_four: The fourth argument.
                This is the second line of the fourth argument's description.

        Returns:
            True if successful, False otherwise.
            This is the second line of the return description.
    """
    ret = google_parser_0.parse(text)
    assert ret.short_description == "This is a long description."


# Generated at 2022-06-25 16:23:41.165206
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'See example'
    google_parser_0 = GoogleParser()
    ret = google_parser_0.parse(text)
    assert ret.short_description == 'See example'
    assert ret.long_description is None
    assert len(ret.meta) == 0


# Generated at 2022-06-25 16:23:49.475882
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # Test 1
    arg0 = 'Test docstring.'
    ret0 = google_parser_0.parse(arg0)
    assert ret0.short_description == 'Test docstring.'
    assert ret0.blank_after_short_description is False
    assert ret0.long_description is None
    assert ret0.blank_after_long_description is None
    assert ret0.meta == []
    # Test 2
    arg0 = 'Test docstring.\n\nTest longer description.    '
    ret0 = google_parser_0.parse(arg0)
    assert ret0.short_description == 'Test docstring.'
    assert ret0.blank_after_short_description is True
    assert ret0.long_description == 'Test longer description.'
    assert ret0.blank

# Generated at 2022-06-25 16:23:59.257253
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """Short summary.

    Longer description.

    Args:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2

    Returns:
        bool: Description of return value
    """

    google_parser_0 = GoogleParser()
    ret = google_parser_0.parse(doc)
    print(ret.short_description)
    print(ret.long_description)
    print(ret.blank_after_short_description)
    print(ret.blank_after_long_description)
    print(ret.meta)


# Generated at 2022-06-25 16:24:09.241521
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Test for method parse of class GoogleParser")
    google_parser_0 = GoogleParser()
    # Print to console
    docst = google_parser_0.parse("""
        This is a multi-line summary.
        This is a second line in the summary.

        And this is the extended description. It can have
        multiple paragraphs.

        Args:
            arg1: This is an argument.
            arg2: This is another argument.

        Returns:
            This is the return value.
        """)

# Generated at 2022-06-25 16:24:15.457570
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstring = "Description of the function.\n\n    Examples:\n        An example.\n\n    Returns:\n        The return value.\n"
    actual = google_parser.parse(docstring)

# Generated at 2022-06-25 16:24:24.797240
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    google_parser_1.parse(
        """First line of the docstring.

The first line is brief explanation, which may be completed with
a longer one. For instance to discuss about its methods. The only
methods are:

do_turn
    Does something.

do_reset
    Resets something.

Args:
    param1: description
    param2: description

Returns:
    description

Raises:
    AttributeError: the ``Raises`` section is a list of all exceptions
        that are relevant to the interface.
    ValueError: If `param2` is equal to `param1`.
"""
    )



# Generated at 2022-06-25 16:24:34.508851
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    text_1 = "This is a test."
    docstring_1 = google_parser_1.parse(text_1)
    assert docstring_1.short_description == "This is a test."
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_long_description == False
    assert len(docstring_1.meta) == 0


# Generated at 2022-06-25 16:24:41.539961
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = """Returns parsed docstring."""
    docstring = google_parser_0.parse(text)
    # assert docstring.short_description == "Returns parsed docstring."


# Generated at 2022-06-25 16:24:51.937271
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """
A short summary of the module.

    A longer description with lots of extra information.
    This module is used to compare and contrast
    different approaches of how to do this.

    Arguments:
        arg1 (int): Description of arg1
        arg2 (str): Description of arg2
            Defaults to "default".

    Returns:
        float: Description of return value

    Raises:
        ValueError: Description
    """
    actual_docstring_0 = google_parser_0.parse(text_0)

# Generated at 2022-06-25 16:25:13.163745
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_1 = google_parser_0.parse('')
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert len(docstring_1.meta) == 0
    docstring_2 = google_parser_0.parse('')
    assert docstring_2.short_description is None
    assert docstring_2.long_description is None
    assert docstring_2.blank_after_short_description is False
    assert docstring_2.blank_after_long_description is False
    assert len(docstring_2.meta) == 0

# Generated at 2022-06-25 16:25:13.795172
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass

# Generated at 2022-06-25 16:25:24.637685
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    text = "Return x + y."
    result = google_parser_0.parse(text)
    if result.short_description != "Return x + y.":
        raise RuntimeError("incorrect short description")
    if result.long_description != None:
        raise RuntimeError("incorrect long description")
    if result.meta:
        raise RuntimeError("incorrect meta")
    if result.blank_after_long_description:
        raise RuntimeError("incorrect blank after long description")
    if result.blank_after_short_description:
        raise RuntimeError("incorrect blank after short description")



# Generated at 2022-06-25 16:25:34.888791
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    with open("pydocstyle/tests/data/google/test_docstrings.txt") as file_in:
        lines = file_in.read().splitlines()
        for line in lines:
            (input_text, expected_text) = line.split("||")
            input_text = input_text.strip()
            expected_text = expected_text.strip()
            if input_text == "":
                break
            print("Input: " + input_text)
            print("Expected: " + expected_text)
            result = google_parser_1.parse(input_text)
            print("Result: " + str(result))
            try:
                assert  str(result) == expected_text
            except AssertionError:
                print("AssertionError")


# Generated at 2022-06-25 16:25:48.864762
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()


# Generated at 2022-06-25 16:26:02.748385
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = ""
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.meta == []
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False

    text_1 = "Description text\n"
    docstring_1 = google_parser_0.parse(text_1)
    assert docstring_1.meta == []
    assert docstring_1.short_description == "Description text"
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert doc

# Generated at 2022-06-25 16:26:14.525461
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # Parse sample docstring
    docstring_1 = GoogleParser.parse(google_parser_0, "'''Docstring for test function.\nWith a plan text description with a new line.\n\nExample:\n    >>> test_function(42)\n    42\n\nArgs:\n    testing: Test value to work with that contains a default value.\n        Defaults to None.\n\nReturns:\n    int: An integer.\n'''")  # noqa: E501
    assert docstring_1.short_description == "Docstring for test function."
    assert docstring_1.header == ""
    assert docstring_1.long_description == "With a plan text description with a new line."
    assert docstring_1.blank_after_short_description
   

# Generated at 2022-06-25 16:26:18.707042
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = "Parse the Google-style docstring into its components."
    docstring_1 = google_parser_0.parse(docstring_0)


# Generated at 2022-06-25 16:26:21.816238
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()

    assert(google_parser_1.parse("") == Docstring())




# Generated at 2022-06-25 16:26:32.957530
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for parse."""
    text_0 = ""
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0
    text_1 = "A function."
    google_parser_1 = GoogleParser()
    docstring_1 = google_parser_1.parse(text_1)
    assert docstring_1.short_description == "A function."
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_

# Generated at 2022-06-25 16:26:44.916269
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # First test case
    google_parser_0 = GoogleParser()

    google_parser_0.add_section(
            Section("Arguments", "param", SectionType.MULTIPLE)
            )

    actual = google_parser_0.parse("""
        Converts object to string and appends to the log.

        :param object: object to be appended.
        :type object: object
        """)
    assert actual.short_description == "Converts object to string and appends " \
                                      "to the log."
    assert actual.long_description is None
    assert actual.blank_after_short_description is False
    assert actual.blank_after_long_description is False
    assert len(actual.meta) == 1
    assert actual.meta[0].args == ["param", "object"]
    assert actual.meta

# Generated at 2022-06-25 16:26:48.654292
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj_GoogleParser = GoogleParser()
    obj_Docstring = Docstring()
    assert GoogleParser.parse(obj_GoogleParser, '') == obj_Docstring


# Generated at 2022-06-25 16:26:59.663233
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring = google_parser_0.parse("""
    Test method.

    Some long description.

    Args:
        arg1: Some description.
        arg2: Some description. Defaults to True.
        arg3: Some description.
            Defaults to some long description of all the things.

    Raises:
        ValueError: If something bad happens.
        Exception: If something else bad happens.

    Exceptions:
        ValueError: If something bad happens.
        Exception: If something else bad happens.

    Return:
        Something.

    Yields:
        Something.
    """)
    # Check for docstring.short_description
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring.short_description, str)
    assert docstring.short

# Generated at 2022-06-25 16:27:09.936204
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "    First line.\n    Second line.\n    Third line.\n"
    assert_equal(
        google_parser_0.parse(text_0),
        Docstring(
            short_description="First line.",
            blank_after_short_description=True,
            long_description="Second line.\nThird line.",
            blank_after_long_description=True,
            meta=[],
        ),
    )
    text_1 = (
        "    First line.\n    Second line.\n\n"
        "    Third line.\n    Fourth line.\n"
    )

# Generated at 2022-06-25 16:27:11.664225
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_5 = GoogleParser()


# Generated at 2022-06-25 16:27:16.315217
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse("This is a class docstring.")
    assert docstring_0.short_description == "This is a class docstring."


if __name__ == "__main__":
    import sys

    sys.exit(int(bool(test_case_0())))

# Generated at 2022-06-25 16:27:23.644865
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    google_parser_0 = GoogleParser()
    text_1 = """This is a module docstring.

    This is a longer description.
    """
    # Act
    result = google_parser_0.parse(text_1)

    # Assert
    assert result.short_description == "This is a module docstring."
    assert result.long_description == "This is a longer description."



# Generated at 2022-06-25 16:27:31.828286
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = """
    The endpoint allows to add a new employee.

    Attributes:
        id: The id of employee.
    Returns:
        Returns a employee.
    """
    doc = google_parser_0.parse(text)
    assert doc.short_description == "The endpoint allows to add a new employee."
    assert len(doc.meta) == 3


if __name__ == "__main__":
    test_GoogleParser_parse()
    print("Test Finished")

# Generated at 2022-06-25 16:27:35.699335
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = str()
    ret = google_parser_0.parse(text_0)


# Generated at 2022-06-25 16:27:43.936207
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    # Setup parameters
    text_0 = 'Short summary.\n\n===================================================================================================================\n\nLong summary.\n\nArgs:\n  arg1: A parameter named arg1.\n\nAttributes:\n  attr1: An attribute named attr1.\n  attr2: An attribute named attr2.\n\n===================================================================================================================\n\nReturns:\n  A string.\n\nRaises:\n  ValueError: if the value is invalid.\n\n===================================================================================================================\n\nExamples:\n  >>> print("Hello world!")\n  Hello world!\n\n'

    # Call the method
    t_0 = google_parser_0.parse(text_0)

    # Test assertions
    assert t_0.short_description

# Generated at 2022-06-25 16:27:52.402679
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()



# Generated at 2022-06-25 16:27:54.218414
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse("\n") == "\n"


# Generated at 2022-06-25 16:28:06.036368
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """
    This is a test.
    """
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == "This is a test."
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert not docstring_0.meta
    text_1 = """
    This is a test.
    Another line.
    """
    docstring_1 = google_parser_0.parse(text_1)
    assert docstring_1.short_description == "This is a test."
    assert docstring_1.long_description == "Another line."

# Generated at 2022-06-25 16:28:10.026897
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    tests = [GoogleParser()]
    for google_parser_0 in tests:

        # Invocation
        ret = google_parser_0.parse('Test.\n\n  Args:\n      param1: test')

        # Output verification

        # Cleanup - none necessary



# Generated at 2022-06-25 16:28:20.705496
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:28:33.092786
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:28:43.101239
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("Short description") == Docstring(
        short_description='Short description',
    )

    assert parse("Short description\n") == Docstring(
        short_description='Short description',
        blank_after_short_description=True,
    )

    assert parse("Short description\n\n") == Docstring(
        short_description='Short description',
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

    assert parse("Short description\n\nLong description") == Docstring(
        short_description='Short description',
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description='Long description',
        meta=[],
    )

    assert parse("Short description\n\nLong description\n") == Doc

# Generated at 2022-06-25 16:28:50.366768
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring: Docstring
    # newlines in the docstring
    docstring = google_parser_0.parse("docstring")
    assert docstring.short_description == "docstring"
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.long_description == None
    docstring = google_parser_0.parse("docstring\n")
    assert docstring.short_description == "docstring"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == False
    assert docstring.long_description == None
    docstring = google_parser_0.parse("docstring\n\n")
    assert docstring.short_description

# Generated at 2022-06-25 16:28:57.939114
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = 'Adds a member to a resource (or removes, if the member is already a part of it).'
    docstring = google_parser_0.parse(text_0)
    assert docstring.short_description == text_0
    assert docstring.blank_after_short_description is False
    assert docstring.long_description == ''
    assert docstring.blank_after_long_description is True

# Generated at 2022-06-25 16:29:07.794568
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    raw_docstring = ["""\
        Args:
            foo (str): Description. Defaults to None.
            bar (Optional[float]): Description. Defaults to 2.0.
            baz (:obj:`bool`): Description.
            qux (Optional[str], optional): Qux description.

        Returns:
            str: Description.

        Raises:
            ValueError: Description.
        """]
    for text in raw_docstring:
        docstring = parser.parse(text)
        print(docstring.long_description)

test_GoogleParser_parse()


# Generated at 2022-06-25 16:29:32.027451
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()

    text_0_str_0 = "  This is an example of a Google style docstring."
    ret_0 = google_parser_0.parse(text_0_str_0)
    assert ret_0.short_description == 'This is an example of a Google style docstring.'
    assert ret_0.long_description == None
    assert ret_0.blank_after_short_description == False
    assert ret_0.blank_after_long_description == False
    assert ret_0.meta == []

    text_1_str_0 = "\nThis is the first line of the long description.\n\nThis is the second line.\nThis is the third line.\n\n"
    ret_1 = google_parser_0.parse(text_1_str_0)

# Generated at 2022-06-25 16:29:37.012552
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = Docstring()
    docstring_1 = google_parser_0.parse("")
    assert docstring_0 == docstring_1


# Generated at 2022-06-25 16:29:49.938757
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    this_source = inspect.getsource(GoogleParser)

# Generated at 2022-06-25 16:29:59.576267
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    String_1 = 'Returns true if and only if the system property named by the argument exists and is equal to the string "true".'
    String_1 = String_1.strip()
    result_1 = google_parser_1.parse(String_1)
    # print(result_1)
    print("correct!")
    assert result_1 == Docstring(
        short_description='Returns true if and only if the system property named by the argument exists and is equal to the string "true".',
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )

# Generated at 2022-06-25 16:30:12.946352
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Unit test for method parse of class GoogleParser
    """
    google_parser_0 = GoogleParser()
    google_parser_0.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Args", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Parameters", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Params", "param", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    google_parser_0.add_section(Section("Exceptions", "raises", SectionType.MULTIPLE))
    google_

# Generated at 2022-06-25 16:30:23.997478
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Testing for raise error
    try:
        expected = ParseError('No specification for "parameters"')
        doc_string = "Parameters:\n\n    :input_dimension: "
        parsed_doc_string = GoogleParser().parse(doc_string)
    except Exception as e:
        actual = e
    assert actual == expected

    # Testing for return type
    doc_string = \
"""Single line description.

Extended description.

Args:
    foo: int. foo parameter.
    bar: str. bar parameter.

Returns:
    int. Result of computation.

Raises:
    InvalidOperation: If `bar` is strange.
"""
    parsed_doc_string = GoogleParser().parse(doc_string)
    assert isinstance(parsed_doc_string, Docstring)

    # Testing for single

# Generated at 2022-06-25 16:30:26.334012
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert isinstance(google_parser_0.parse(""), Docstring)


# Generated at 2022-06-25 16:30:29.410708
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    google_parser.parse("")

test_case_0()
test_GoogleParser_parse()
print("All test passed")

# Generated at 2022-06-25 16:30:35.824375
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = """
    Args:
    param arg0: this is what arg0 is. Defaults to 'none'.
    param arg1: this is what arg1 is. Defaults to 'default'.
    param arg2: this is what arg2 is. Defaults to 'default'.
    """

    ret = google_parser_0.parse(text)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert len(ret.meta) == 1
    ret_meta_0 = ret.meta[0]
    assert isinstance(ret_meta_0, DocstringParam)

# Generated at 2022-06-25 16:30:39.982034
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 =  """
    :param x: none
    :param y: none

    :returns: nothing"""
    google_parser_0.parse(text_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:31:08.890140
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Summary line.

Extended description.

Attributes:
    attr1 (int): Description of `attr1`.
    attr2 (:obj:`str`): Description of `attr2`.

Example:
    Examples should be written in doctest format, and should illustrate how
    to use the function.

Returns:
    bool: True if successful, False otherwise.
"""

    doc = parse(text)
    assert doc.short_description == "Summary line."
    assert doc.long_description == "Extended description."
    assert len(doc.meta) == 5
    assert doc.meta[0].args == ["attribute", "attr1 (int)"]
    assert doc.meta[0].description == (
        "Description of `attr1`."
    )

# Generated at 2022-06-25 16:31:21.932816
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

# Generated at 2022-06-25 16:31:31.589411
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup the expected value
    expected_0 = Docstring()
    expected_0.long_description = 'This is an example.\n\nIt has two paragraphs.'

    # Call the method
    google_parser_0 = GoogleParser()
    actual_0 = google_parser_0.parse('This is an example.\n\nIt has two paragraphs.')

    # Check the value
    assert actual_0.long_description == expected_0.long_description

    # Setup the expected value
    expected_1 = Docstring()
    expected_1.long_description = 'This is an example.\n\nIt has two paragraphs.'

    # Call the method
    google_parser_1 = GoogleParser(title_colon=False)

# Generated at 2022-06-25 16:31:43.918534
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse('Parse the Google-style docstring into its components.') == Docstring(
        short_description='Parse the Google-style docstring into its '
                          'components.',
        long_description='',
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )

    assert google_parser_0.parse('') == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )

    assert google_parser_0.parse('Parse the Google-style docstring into its components.\n\n\n    ')

# Generated at 2022-06-25 16:31:55.942649
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    docstring_1 = ''
    docstring_1_expected = Docstring(short_description=None, long_description=None, blank_after_short_description=False, blank_after_long_description=False)
    docstring_2 = 'Hello\nworld\n!'
    docstring_2_expected = Docstring(short_description='Hello', long_description='world\n!', blank_after_short_description=False, blank_after_long_description=False)
    docstring_3 = 'Hello\n\nworld\n!'
    docstring_3_expected = Docstring(short_description='Hello', long_description='world\n!', blank_after_short_description=True, blank_after_long_description=False)

# Generated at 2022-06-25 16:32:06.769073
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    result = google_parser_0.parse("")
    assert result.short_description is None
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert result.meta == []

    text = """
    Print the current version and exit.
    """
    result = GoogleParser().parse(text)
    assert result.short_description == "Print the current version and exit."
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert result.meta == []

    text = """
    Print the current version and exit.

    -vv, --verbose

    """

# Generated at 2022-06-25 16:32:15.600339
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

# Generated at 2022-06-25 16:32:19.442976
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = "  pypi-server --port 8080\n"
    google_parser_0 = GoogleParser()
    result = google_parser_0.parse(text_0)
    assert result.short_description == "pypi-server --port 8080"


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-25 16:32:28.283472
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # str -> expected: Docstring
    tests_0 = dict()
    tests_0[""] = Docstring (
        meta=[],
        short_description=None,
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
    )
    tests_0["short only"] = Docstring (
        meta=[],
        short_description="short only",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
    )

# Generated at 2022-06-25 16:32:37.136117
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:32:47.579620
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # TODO: implement test
    raise Exception("Test not implemented")


# Generated at 2022-06-25 16:32:58.406076
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser(sections=[Section("Parameter", "param", SectionType.MULTIPLE)])
    str_0 = "foo\n\nArgs:\n   bar: bar\n"
    docstring_0 = google_parser_0.parse(str_0)
    assert len(docstring_0.meta) == 1
    str_1 = "foo\n\nArgs:\n   bar:\n"
    docstring_1 = google_parser_0.parse(str_1)
    assert len(docstring_1.meta) == 1
    str_2 = "foo\n\nArgs:\n   bar:\n\n"
    docstring_2 = google_parser_0.parse(str_2)
    assert len(docstring_2.meta) == 1