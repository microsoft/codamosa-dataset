

# Generated at 2022-06-25 16:23:37.487014
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test parse docstring with section 'Args:'
    text = """\
Summation function.

    :param a: The first addend.
    :param b: The second addend.
    :return: The summation.
    """

    # Expected result of this test case

# Generated at 2022-06-25 16:23:42.215547
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    text = """
    class Solution(object):
        def findJudge(self, N, trust):
            count = [0] * (N + 1)
            for i, j in trust:
                count[i] -= 1
                count[j] += 1
            for i in range(1, N + 1):
                if count[i] == N - 1:
                    return i
            return -1
    """
    ret = obj.parse(text)
    print(ret)

# Generated at 2022-06-25 16:23:50.511849
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    my_google_parser = GoogleParser()

    # Case 0
    """
    Arg1: Must be some text/n/nA test string.
    Arg2:

    Args:

    Params:

    Return:
        The return value.
    Returns:
    """
    test_string_0 = """
    Arg1: Must be some text/n/nA test string.
    Arg2:

    Args:

    Params:

    Return:
        The return value.
    Returns:
    """
    test_string_0_exp_docstring = Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=None,
        meta=[]
    )
    assert my_google_parser.parse

# Generated at 2022-06-25 16:24:02.817765
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text1 = "This is a test."
    formal_text1 = "This is a test.\n"
    doc1 = GoogleParser().parse(text1)
    assert doc1.__str__() == formal_text1
    text2 = (
        "Short description.\n"
        + "Without an empty line after first line.\n"
        + "\n"
        + "Long description.\n"
        + "Without an empty line after first line.\n"
    )
    formal_text2 = (
        "Short description.\n"
        + "\n"
        + "Long description.\n"
        + "\n"
    )
    doc2 = GoogleParser().parse(text2)
    assert doc2.__str__() == formal_text2

# Generated at 2022-06-25 16:24:12.889288
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        "This is a short description.\n"
        "\n"
        "This is a long description.\n"
        "\n"
        "Args:\n"
        "    one: first parameter\n"
        "    two: second parameter"
    )
    assert docstring.meta[0].args == ["param", "one: first parameter"]
    assert docstring.meta[0].arg_name == "one"
    assert docstring.meta[1].args == ["param", "two: second parameter"]
    assert docstring.meta[1].arg_name == "two"
    assert docstring.short_description == "This is a short description."
    assert docstring.blank_after_short_description

# Generated at 2022-06-25 16:24:14.376732
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    assert isinstance(obj.parse(str), Docstring)


# Generated at 2022-06-25 16:24:17.283928
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = ""
    ret = GoogleParser().parse(text)
    assert isinstance(ret, Docstring), "TypeError: GoogleParser.parse()."


# Generated at 2022-06-25 16:24:25.254211
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # just run in test mode with following command:
    # python3 -m doctest -v dparse.py
    # or run all tests like:
    # python3 -m pytest --doctest-modules
    # or
    # make test
    # check for errors in doctest inside python debugger (leftover from 
    # py.test --doctest-modules):
    # python3 -m pdb -c continue -c continue -c continue -m doctest -v dparse.py
    # or
    # python3 -m doctest -v dparse.py
    import doctest
    doctest.testmod(verbose=True)
    # 
    google_parser = GoogleParser()

# Generated at 2022-06-25 16:24:33.920841
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc_string = """This is a short description.

This is a long description. It can span multiple
lines.

Args:
    arg_0 (str): This is the first parameter.
    arg_1 (int): This is the second parameter.
    arg_2 (bool): This is the third parameter.

Returns:
    int: This is the return value.
"""
    docstring_object = parse(doc_string)

# Generated at 2022-06-25 16:24:42.037583
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    docstring = "Test\n"
    assert g.parse(docstring).short_description == "Test"

    docstring = "Test\nTest"
    assert g.parse(docstring).long_description == "Test"

    docstring = "Test\n\nTest"
    assert g.parse(docstring).short_description == "Test"
    assert g.parse(docstring).long_description == "Test"

    docstring = "Test\n\n\nTest"
    assert g.parse(docstring).short_description == "Test"
    assert g.parse(docstring).long_description == "Test"

    docstring = "Test\n  Test"
    assert g.parse(docstring).long_description == "Test"


# Generated at 2022-06-25 16:25:11.607574
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    text = "Hello world!"
    result = p.parse(text)
    assert result.short_description == text
    assert result.long_description == None
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False
    assert result.meta == []

    text = "Here is the title of the module.\n\nAnd some more text.\n\n"
    result = p.parse(text)
    assert result.short_description == 'Here is the title of the module.'
    assert result.long_description == 'And some more text.'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.meta == []


# Generated at 2022-06-25 16:25:26.052618
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test 0
    text_0 = """
Moves the selected nodes to the target node.

:param target_node: The destination node.
:param nodes: The nodes to move.
:return: True if successful
"""
    actual = GoogleParser().parse(text_0)
    expected = Docstring()
    expected._short_description = "Moves the selected nodes to the target node."
    expected.blank_after_short_description = True
    expected.blank_after_long_description = True
    expected._long_description = None
    expected.title = None
    expected.meta.append(DocstringParam(args=["param", "target_node:"], description="The destination node.", arg_name="target_node", type_name=None, is_optional=None, default=None))

# Generated at 2022-06-25 16:25:30.503915
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Initialization
    googleParser = GoogleParser()
    text = "line 0\nline 1"
    
    with pytest.raises(AttributeError) as exception_info:
        googleParser.parse(text)


# Generated at 2022-06-25 16:25:38.755217
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    input_text_0 = "/**\n*  One-line summary.\n*  \n*  Details.\n*  \n*  Args:\n*    arg1 (str): Description of arg1\n*    arg2 (int): Description of arg2\n*  \n*  Returns:\n*    Some return value\n*/"
    input_text_1 = "/**\n*  One-line summary.\n*  \n*  Details.\n*  \n*  Args:\n*    arg1 (str): Description of arg1\n*    arg2 (int): Description of arg2\n*  \n*  Returns:\n*    Some return value\n*  \n*  Yields:\n*    Some yield value\n*/"

    parser_0 = GoogleParser()

    google

# Generated at 2022-06-25 16:25:49.987598
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()
    assert parser.parse("123") == Docstring({'short_description': '123'})
    assert parser.parse("123\n\n") == Docstring({'short_description': '123'})
    assert parser.parse("123\n456") == Docstring({'short_description': '123'})
    assert parser.parse("123\n\n456") == Docstring({'short_description': '123'})
    assert parser.parse("123\n\n456\n\n") == Docstring({'short_description': '123'})
    assert parser.parse("123\n456\n\n") == Docstring({'short_description': '123', 'long_description': '456'})

# Generated at 2022-06-25 16:26:02.890369
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test for method parse of class GoogleParser"""
    sections = [
        Section("Args:", "param", SectionType.SINGULAR),
        Section("Kwargs:", "param", SectionType.SINGULAR),
        Section("Returns:", "returns", SectionType.SINGULAR),
        Section("Yields:", "yields", SectionType.SINGULAR),
        Section("Raises:", "raises", SectionType.SINGULAR),
    ]
    parser = GoogleParser(sections=sections)

    d0 = "Parse the Google-style docstring into its components.\n\n:returns: parsed docstring"

# Generated at 2022-06-25 16:26:14.627496
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
  from .common import (Docstring, DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns)
  from .common import SectionType
  from collections import OrderedDict
  section_type_0 = SectionType.SINGULAR
  section_type_1 = SectionType.MULTIPLE
  section_type_2 = SectionType.SINGULAR_OR_MULTIPLE
  sections_0 = list()
  sections_0.append(Section("Arguments", "param", section_type_1))
  sections_0.append(Section("Args", "param", section_type_1))
  sections_0.append(Section("Parameters", "param", section_type_1))
  sections_0.append(Section("Params", "param", section_type_1))

# Generated at 2022-06-25 16:26:27.653557
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test parse to make sure it works with the general case"""
    description = """
        test_case_0

        Description of GoogleParser.parse

        Args:
            arg1 (str) : first argument
            arg2 (str) : second argument

        Returns:
            None
    """
    answer = GoogleParser(sections=DEFAULT_SECTIONS).parse(description)

# Generated at 2022-06-25 16:26:34.628602
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "Parse the Google-style docstring into its components."
    obj = GoogleParser()
    ret = obj.parse(text)
    assert ret == Docstring(
        short_description = "Parse the Google-style docstring into its components.",
        long_description = None,
        blank_after_short_description = False,
        blank_after_long_description = False,
        meta = [],
        deprecated = False,
    )
    text = "Parse the Google-style docstring into its components.\n\nArgs:\n    text: docstring to parse"
    obj = GoogleParser()
    ret = obj.parse(text)

# Generated at 2022-06-25 16:26:37.671934
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = parse("")
    docstring_1 = parse("\n")


# Generated at 2022-06-25 16:26:55.026468
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    assert p.parse('Simple.') == Docstring(
        short_description='Simple.',
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
        meta=[],
    )

    p = GoogleParser()

# Generated at 2022-06-25 16:26:56.915609
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert(True)


# Generated at 2022-06-25 16:27:03.041555
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    s = GoogleParser()
    text = "This is a test\n"
    ds = s.parse(text)
    assert ds.short_description == "This is a test"
    assert ds.long_description == None
    assert ds.meta == []
    text = "This is a test\n\nThis is a long description\n"
    ds = s.parse(text)
    assert ds.short_description == "This is a test"
    assert ds.long_description == "This is a long description"
    assert ds.meta == []
    text = "This is a test\n\nThis is a long description\n\n"
    ds = s.parse(text)
    assert ds.short_description == "This is a test"

# Generated at 2022-06-25 16:27:11.374564
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ds = GoogleParser()
    s0 = """\
    This is a description

    Args:
        p1: description of p1
        p2 (int): description of p2

    Returns:
        int: description of returns.
    """
    s1 = inspect.cleandoc(s0)
    d = ds.parse(s1)
    assert d.short_description == "This is a description"
    assert d.long_description == "Args:\n    p1: description of p1\n    p2 (int): description of p2\n\nReturns:\n    int: description of returns."
    assert d.blank_after_short_description
    assert d.blank_after_long_description
    assert len(d.meta) == 3


# Generated at 2022-06-25 16:27:20.375375
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:27:23.240494
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    t = "A one line description and\none-line summary"
    text = "A one line description and one-line summary\n\n"
    assert GoogleParser().parse(text).short_description == t



# Generated at 2022-06-25 16:27:36.425257
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Setup:
    global docstring
    def docstring():
        return """One line summary.

More detailed summary which may be several lines.

Args:
    arg_0 (str): Argument 0.
    arg_1 (bool, optional): Argument 1. Defaults to False.
    arg_2 (int): Argument 2.

Returns:
    str. Result.

Raises:
    ValueError. If something bad happened.
    TypeError. If something really bad happened.

"""
    global parser
    parser = GoogleParser()

    # Execution:
    result = parser.parse(docstring())

    # Assertion:
    assert result.short_description == """One line summary."""
    assert result.long_description == """More detailed summary which may be several lines."""

# Generated at 2022-06-25 16:27:43.068888
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = Docstring()
    d.short_description = "test"
    d.long_description = \
"""This is a test.

test 2
"""
    d.meta.append(
        DocstringReturns(args=["returns"], description="1", type_name="int")
    )
    d.meta.append(
        DocstringRaises(args=["raises"], description="ValueError", type_name="int")
    )
    assert GoogleParser().parse("test\n\nThis is a test.\n\n    test 2\n\nReturns:\n    1\nRaises:\n    ValueError") == d


# Generated at 2022-06-25 16:27:53.623291
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Case 0 (normal)
    gps = GoogleParser()
    docstr = """
    This is the short description line.

    This is the long description line.

    Parameters:
        arg1 (str): The first argument.
        arg2 (int, optional): The second argument. Defaults to True.

    Returns:
        bool: The return value. True for success, False otherwise.

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

        >>> a = [1, 2, 3]
        >>> print([x + 3 for x in a])
        [4, 5, 6]
    """
    # Execute
    ds = gps.parse(docstr)
    # Verify:
    assert ds.short_description == "This is the short description line."
    assert d

# Generated at 2022-06-25 16:28:04.961911
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case #0
    docstring = """\
    Short description.

    Long description.

    Args:
        arg1 (str): Description of `arg1`. Defaults to 'arg1'
        arg2 (int): Description of `arg2`. Defaults to 42
        arg3 (:obj:`my_mod.SomeClass`): Description of `arg2`. Defaults to
            :obj:`my_mod.some_func`
    """
    parser = GoogleParser()

# Generated at 2022-06-25 16:28:23.866129
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """\
        Args:
            text: docstring element text

        Returns:
            parsed docstring

        Raises:
            ParseError: Unable to parse text.
    """
    ret_1 = google_parser_0.parse(text_0)
    assert ret_1
    assert ret_1.short_description is None
    assert ret_1.blank_after_short_description
    assert ret_1.blank_after_long_description
    assert ret_1.long_description is None
    assert len(ret_1.meta) == 3
    assert ret_1.meta[0].description == "docstring element text"
    assert ret_1.meta[1].description == "parsed docstring"
    assert ret_1.meta[2].description

# Generated at 2022-06-25 16:28:38.881051
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()

    docstring = inspect.cleandoc(u'''
        Short description.

        Long description.

        Args:
            arg1 (str): Description of arg1.
        ''')
    docstring = google_parser.parse(docstring)
    assert docstring
    assert docstring.meta
    assert len(docstring.meta) == 1
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].description == (
        "Description of arg1."
    )
    assert docstring.meta[0].type_name == "str"
    assert docstring.meta[0].key == "param"


# Generated at 2022-06-25 16:28:39.831595
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass

# Generated at 2022-06-25 16:28:49.832390
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
#
#     text_0 = '/**\n     * Args:\n     *     arg1 (str): The first parameter.\n     *     arg2 (str): The second parameter.\n     * Returns:\n     *     str: The return value.\n     */'
#     ret_0 = google_parser_0.parse(text_0)
#     assert ret_0.short_description == '*'
#     assert ret_0.long_description is None
#     assert len(ret_0.meta) == 3
#
#     text_1 = '/**\n     * Args:\n     *     arg1 (str): The first parameter.\n     * Returns:\n     *     str: The return value.\n     */'
#     ret_1 = google_parser

# Generated at 2022-06-25 16:29:01.244571
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    text = "This is a short description.\n\nThis is a long description.\n\nArgs:\n  arg1 (str): arg1 desc\n  arg2: arg2 desc\n\nReturns:\n  (int): return desc"

    # Parse the Google-style docstring into its components.
    ret = google_parser_0.parse(text)

    assert str(ret) == "This is a short description.\nThis is a long description."
    assert ret.short_description == "This is a short description."
    assert ret.long_description == "This is a long description."
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == False

# Generated at 2022-06-25 16:29:08.830583
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Define test input and expected output
    input = """\
    """
    expected_out = Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[]
    )
    # Call function under test
    actual_out = GoogleParser().parse(input)
    # Check if outputs match
    assert actual_out == expected_out, f"Expected: {expected_out}\nActual: {actual_out}"
    print("Test passed")


# Generated at 2022-06-25 16:29:20.450884
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    input_text = inspect.cleandoc("""
    This function does something.

    Long description.

    :param foo: Foo.
    :param bar: Bar.
    :returns: Returns something.
    :raises TypeError: If *foo* is not a string.
    """)


# Generated at 2022-06-25 16:29:26.383170
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstr = google_parser.parse('this is a docstring')
    assert docstr.short_description == 'this is a docstring'
    assert docstr.long_description is None
    assert docstr.blank_after_short_description is False
    assert docstr.blank_after_long_description is False
    assert len(docstr.meta) == 0

    docstr = google_parser.parse('')
    assert docstr.short_description is None
    assert docstr.long_description is None
    assert docstr.blank_after_short_description is False
    assert docstr.blank_after_long_description is False
    assert len(docstr.meta) == 0


# Generated at 2022-06-25 16:29:38.507625
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

# Generated at 2022-06-25 16:29:50.903364
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Some description.
    
    Parameters
    ----------
    param_0 : float
        A float parameter.
    param_1 : str
        A string parameter.
    param_2 : bool
        A boolean parameter.
        
    Yields
    ------
    str
        Some output.
        
    Raises
    ------
    ValueError
        If something went wrong.
    """
    google_parser_2 = GoogleParser()
    res = google_parser_2.parse(text)
    assert res.short_description == "Some description."

# Generated at 2022-06-25 16:30:00.288453
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """One line."""
    actual = GoogleParser().parse(text)
    assert "One line." == actual.short_description
    assert None is actual.long_description
    assert [] == actual.meta
    actual = GoogleParser().parse(text)
    assert isinstance(actual, Docstring)
    actual = GoogleParser().parse(text)
    assert "One line." == actual.short_description
    assert None is actual.long_description
    assert [] == actual.meta


# Generated at 2022-06-25 16:30:13.736424
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_1 = GoogleParser()

    text_0 = ""
    doc_0 = google_parser_0.parse(text_0)
    assert doc_0.short_description == None
    assert doc_0.long_description == None
    assert doc_0.blank_after_short_description == None
    assert doc_0.blank_after_long_description == None
    assert doc_0.meta == []

    # with parameter keyword
    text_1 = """\
    Apply a function (with side effects) to every node.

    :param fn: The function to apply.
    :type fn: Callable.
    """
    doc_1 = google_parser_0.parse(text_1)

# Generated at 2022-06-25 16:30:24.529237
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    case_0 = """Shows basic usage of the Drive v3 API.
    Creates a Drive v3 API service and prints the names and ids
    of the last 10 files the user has access to.
    """
    expected_0 = Docstring()
    expected_0.short_description = "Shows basic usage of the Drive v3 API."
    expected_0.blank_after_short_description = False
    expected_0.long_description = """Creates a Drive v3 API service and prints the names and ids
    of the last 10 files the user has access to."""
    expected_0.blank_after_long_description = True
    expected_0.meta = []

    passed_0 = True

# Generated at 2022-06-25 16:30:28.993759
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse("") == ""
    assert google_parser_0.parse("") == ""
    assert google_parser_0.parse("") == ""
    assert google_parser_0.parse("") == ""

# Generated at 2022-06-25 16:30:38.396257
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = """Parses Google-style docstrings.

Google style docstrings may have sections such as "Args" for
arguments, "Returns" for return values, and "Yields" for generator
functions.

Args
    text: The string to parse into an AbstractDocstring object.

Returns
    parsed_docstring: An AbstractDocstring object that represents
        parsed_docstring.

    :type: AbstractDocstring
    :rtype: AbstractDocstring

Raises
    google.gendoc.common.ParseError: If Google-style parsing fails.

    :type: ParseError
    :rtype: ParseError

"""

# Generated at 2022-06-25 16:30:41.410397
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.parse('Simple module\n')


# Generated at 2022-06-25 16:30:45.557648
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.parse("GeoJSON FeatureCollection")
    google_parser_0.parse("")
    google_parser_0.parse("GeoJSON Feature")
    google_parser_0.parse("Coordinate reference system (CRS) as defined by GeoJSON")


# Generated at 2022-06-25 16:30:57.657299
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
    """
    google_parser_0 = GoogleParser()
    ret = google_parser_0.parse(text)
    assert ret.short_description == None
    assert ret.blank_after_short_description == None
    assert ret.blank_after_long_description == None
    assert ret.long_description == None
    assert len(ret.meta) == 0

    text = """\
    """
    google_parser_1 = GoogleParser()
    ret = google_parser_1.parse(text)
    assert ret.short_description == None
    assert ret.blank_after_short_description == None
    assert ret.blank_after_long_description == None
    assert ret.long_description == None
    assert len(ret.meta) == 0

    text = """\
    """
    google_parser

# Generated at 2022-06-25 16:31:07.709550
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_0 = """Parse the Google-style docstring into its components.

:returns: parsed docstring
"""
    docstring_0 = google_parser_0.parse(str_0)
    assert docstring_0 == Docstring(
        short_description="Parse the Google-style docstring into its components.",
        blank_after_short_description=True,
        long_description="returns: parsed docstring",
        blank_after_long_description=False,
        meta=[DocstringMeta(args=['returns'], description='parsed docstring')],
    )

# Generated at 2022-06-25 16:31:16.722312
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    string_0 = '    The ``foo`` function does foo.\n\n    Parameters:\n        :foo: A string.\n\n    Returns:\n        :returns: The result.'
    docstring_0 = google_parser_0.parse(string_0)
    assert isinstance(docstring_0, Docstring)

if __name__ == "__main__":
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:31:32.358425
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    func = api_tests.test_case_0
    text = inspect.getdoc(func)
    doc = google_parser_0.parse(text)
    assert (
        doc.short_description == "Google-style docstring parsing."
    ), "Incorrect short_description"
    assert doc.blank_after_short_description, "Incorrect blank_after_short_description"
    assert (
        doc.long_description
        == """\
This is a more complex docstring.

More complex docstrings have more complex content.
"""
    ), "Incorrect long_description"
    assert doc.blank_after_long_description, "Incorrect blank_after_long_description"
    assert len(doc.meta) == 12, "Incorrect number of elements in meta"



# Generated at 2022-06-25 16:31:37.610563
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    def test():
        return google_parser_0.parse('')
    expected = Docstring(short_description=None, blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    assert includes(test, expected, print_diff=True)


# Generated at 2022-06-25 16:31:49.308052
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()
    test_case_25()

# Generated at 2022-06-25 16:31:56.629472
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    docstring = """The function

    Does something.

    .. function:: function_name(arg1: str) -> float
        :param arg1: Desc of arg1
        :returns: Desc of return value.

    Args:
        arg1 (str): Desc of arg1
        arg2 (str, optional): Desc of arg2
        arg3 (str, optional): Desc of arg3. Defaults to None.
    """

    ret = google_parser_1.parse(docstring)
    assert ret.short_description == "The function"
    assert ret.long_description == "Does something."
    assert ret.meta[0].args == ['param']
    assert ret.meta[0].description == 'Desc of arg1'
    assert ret.meta[1].args == ['return']


# Generated at 2022-06-25 16:32:09.119114
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_8 = GoogleParser()
    expected_8 = Docstring()
    actual_8 = google_parser_8.parse('\n    Do something\n    ')
    assert expected_8 == actual_8
    expected_9 = Docstring()
    actual_9 = google_parser_8.parse('      Do something')
    assert expected_9 == actual_9
    google_parser_10 = GoogleParser()
    expected_10 = Docstring()
    actual_10 = google_parser_10.parse('\n        Do something\n        ')
    assert expected_10 == actual_10
    expected_11 = Docstring()
    actual_11 = google_parser_10.parse('          Do something')
    assert expected_11 == actual_11
    google_parser_20 = GoogleParser()
    expected_20 = Doc

# Generated at 2022-06-25 16:32:16.775310
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    try:
        google_parser_0 = GoogleParser()
        assert google_parser_0.parse("text") == Docstring(
            long_description=None,
            short_description=None,
            meta=[DocstringMeta(args=["text"], description="text")],
        )
    except:
        return False
    try:
        google_parser_1 = GoogleParser()
        assert google_parser_1.parse("text\n text") == Docstring(
            long_description="text",
            short_description=None,
            meta=[DocstringMeta(args=["text\n text"], description="text\n text")],
            blank_after_long_description=False,
            blank_after_short_description=True,
        )
    except:
        return False

# Generated at 2022-06-25 16:32:21.647138
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Starting test_GoogleParser_parse")
    google_parser_1 = GoogleParser()
    text_1 = """\
    Hello world.
    """
    doc_1 = google_parser_1.parse(text_1)


# Generated at 2022-06-25 16:32:33.947363
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_text = """
    Parse a Google-style docstring into its constituent parts.

    Parameters
    ----------
    text : str
        The docstring to parse.
    """
    google_parser_1 = GoogleParser()
    docstring_1 = google_parser_1.parse(docstring_text)
    docstring_1_short_description = "Parse a Google-style docstring into its constituent parts."
    docstring_1_long_description = None
    docstring_1_blank_after_short_description = False
    docstring_1_blank_after_long_description = False
    docstring_1_meta = [
        Meta(args=['param', 'text'], arg_name='text', type_name='str', description='The docstring to parse.')
    ]

    assert docstring_1

# Generated at 2022-06-25 16:32:42.375977
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    text = """
    Short summary.

    Longer description.

    Args:
        p1 (int), optional: Description of p1. Defaults to 3.
        p2 (str): Description of p2.
        p3 (bytes): Description of p3.

    Returns:
        int: Description of return value.

    Raises:
        ValueError: If p2 < 0.
        TypeError:  If p3 is not bytes.

    Examples:
        Examples should be written in doctest format, and should illustrate how
        to use the function.

        >>> a = [1, 2, 3]
        >>> print [x + 1 for x in a]
        [2, 3, 4]
    """
    docstring = google_parser.parse(text)

    assert docstring.short_description

# Generated at 2022-06-25 16:32:48.682408
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser(
        sections=[
            Section("Not_Arguments", "param", SectionType.MULTIPLE),
            Section("Args", "param", SectionType.MULTIPLE),
            Section("Not_Raises", "raises", SectionType.MULTIPLE),
            Section("Exceptions", "raises", SectionType.MULTIPLE),
            Section("Not_Example", "examples", SectionType.SINGULAR),
            Section("Examples", "examples", SectionType.SINGULAR),
            Section("Not_Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
            Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE),
        ])