

# Generated at 2022-06-25 16:24:03.048281
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    input_0 = ""
    expected_0 = Docstring()
    if type(GoogleParser().parse(input_0)) is not Docstring:
        raise Exception("Incorrect return type")
    if GoogleParser().parse(input_0) != expected_0:
        raise Exception("Incorrect return value")
    input_1 = "\n"
    expected_1 = Docstring()
    if type(GoogleParser().parse(input_1)) is not Docstring:
        raise Exception("Incorrect return type")
    if GoogleParser().parse(input_1) != expected_1:
        raise Exception("Incorrect return value")
    input_2 = "\t"
    expected_2 = Docstring()
    if type(GoogleParser().parse(input_2)) is not Docstring:
        raise Exception("Incorrect return type")

# Generated at 2022-06-25 16:24:09.554047
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring, DocstringParam, DocstringRaises


# Generated at 2022-06-25 16:24:15.722430
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = Docstring()
    text_0.short_description = "function with type annotations"

# Generated at 2022-06-25 16:24:24.793372
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:24:37.947042
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Parameterized test case
    Foo_text_0 = "Doc string."
    Foo_text_1 = "Doc\nstring."
    Foo_text_2 = "Doc string.\n"
    Foo_text_3 = "\nDoc string.\n"
    Foo_text_4 = "\nDoc string.\n\n"
    Foo_text_5 = "\nDoc string.\n \n"
    Foo_text_6 = "\nDoc string.\n\n "
    Foo_text_7 = "Args:\n    arg1: first arg\n    arg2: second arg\n\n"
    Foo_text_8 = "Returns:\n    string\n\n"
    Foo_text_9 = "Returns:\n    string\n    other: description\n\n"
    Foo_text_

# Generated at 2022-06-25 16:24:40.062412
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docs = '''
        """
        param epsilon: Value used to initialise weights.
        """
        '''
    print(GoogleParser().parse(docs))

# Generated at 2022-06-25 16:24:51.274752
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    Arguments:
        arg1: description of arg 1 of arbitrary length.

        arg2
            description of arg 2 of arbitrary length.

    Args:
        arg3 (str): description of arg 3 of arbitrary length.
        arg4 (int):
            description of arg 4 of arbitrary length.

    Example:
        example of arbitrary length.

    Raises:
        ValueError: if value 1.
        ValueError: if value 2.
        ValueError:
            if value 3.
    """
    parser = GoogleParser(title_colon=False)
    docstring = parser.parse(text)

    assert "arg1" in docstring.params
    assert "arg2" in docstring.params
    assert "arg3" in docstring.params
    assert "arg4" in docstring.params

# Generated at 2022-06-25 16:25:02.383599
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = ''
    result_0 = GoogleParser().parse(text_0)
    assert isinstance(
        result_0,
        Docstring,
    )
    assert result_0 == Docstring()
    text_1 = '         '
    result_1 = GoogleParser().parse(text_1)
    assert isinstance(
        result_1,
        Docstring,
    )
    assert result_1 == Docstring()
    text_2 = '\n'
    result_2 = GoogleParser().parse(text_2)
    assert isinstance(
        result_2,
        Docstring,
    )
    assert result_2 == Docstring()
    text_3 = '\n\n\n'
    result_3 = GoogleParser().parse(text_3)

# Generated at 2022-06-25 16:25:11.086081
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    GoogleParser_obj = GoogleParser()
    test_str = "This is a test"
    section_0 = Section("test", "test", SectionType.MULTIPLE)

    GoogleParser_obj.add_section(section_0)
    doc_obj = GoogleParser_obj.parse(test_str)
    assert doc_obj.short_description == test_str

# Generated at 2022-06-25 16:25:19.304925
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = GoogleParser().parse(
        '''Single line.
        Multiple
        lines.

        """
        examples section.
        """

        Args:
            arg_0: arg 0
            arg_1: arg_1

        Returns:
            0.
        '''
    )
    assert docstring
    assert docstring.short_description == "Single line."
    assert docstring.long_description == "Multiple\nlines."
    assert docstring.blank_after_short_description, "short description."
    assert docstring.blank_after_long_description, "long description."
    assert len(docstring.meta) == 4

    assert docstring.meta[0].description == "examples section."
    assert docstring.meta[1].description == "arg 0"
    assert docstring.meta[1].arg_

# Generated at 2022-06-25 16:25:38.193022
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = google_parser_0.parse(str_0)
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short_description == str_0

    # Test for missing section arguments
    google_parser_1 = GoogleParser(title_colon=True)
    google_parser_1.add_section(Section('Params', 'param', SectionType.MULTIPLE))
    str_1 = 'Params:\n    param_0: A parameter\n    param_1: Another parameter'
    docstring_1 = google_parser_1.parse(str_1)
    assert isinstance(docstring_1, Docstring)
    assert docstring_1

# Generated at 2022-06-25 16:25:39.794200
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:25:50.616957
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Setup
    parser = GoogleParser()
    str_0 = """One line summary.

Longer description.

Args:
  arg1: The first arg. Defaults to 1.
  arg2: The second arg.
    Default to 2.
    Default to 3.
  arg3: yay.

Returns:
  This does something.

Raises:
  SomeError: Raises if something bad happens.
  OtherError: For some other reason.
"""
    docstring_0 = parser.parse(str_0)

    # Assertions
    assert docstring_0.short_description == "One line summary."
    assert docstring_0.long_description == 'Longer description.\n'
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after

# Generated at 2022-06-25 16:26:02.933055
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    result = GoogleParser()
    docstring_0 = result.parse('X~.@{(>vv>/b')
    result.add_section(Section("Arguments", "param", SectionType.MULTIPLE))
    result.add_section(Section("Args", "param", SectionType.MULTIPLE))
    docstring_1 = result.parse(
        "A docstring.\n\n    Example: foo\n    Example: bar\n\n"
    )
    result.add_section(Section("Raises", "raises", SectionType.MULTIPLE))
    docstring_2 = result.parse(
        "A docstring.\n\n    Example: foo\n    Example: bar\n\n"
    )

# Generated at 2022-06-25 16:26:06.928022
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    test_GoogleParser_parse.probe_statement_write("docstring_0", docstring_0)


# Generated at 2022-06-25 16:26:17.491728
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import random

    # Test with empty args.
    text = ''
    expected = Docstring()
    actual = GoogleParser().parse(text)
    assert expected == actual

    # Test with empty docstring.
    text = ''
    expected = Docstring()
    actual = GoogleParser().parse(text)
    assert expected == actual

    # Test with invalid docstring.
    text = '# Invalid docstring'
    expected = Docstring()
    actual = GoogleParser().parse(text)
    assert expected == actual

    # Test with invalid docstring short description.
    text = 'Invalid short description'
    expected = Docstring()
    actual = GoogleParser().parse(text)
    assert expected == actual

    # Test with empty docstring long description.
    text = '\n\n'

# Generated at 2022-06-25 16:26:29.573627
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:26:35.420054
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import Docstring
    from .google import GoogleParser
    # Test case from str
    GoogleParser_instance_0 = GoogleParser()
    str_0 = 'X~.@{(>vv>/b'
    Docstring_0 = Docstring()
    Docstring_0.long_description = None
    Docstring_0.short_description = 'X~.@{(>vv>/b'
    Docstring_0.blank_after_long_description = False
    Docstring_0.blank_after_short_description = True
    Docstring_0.meta = []
    Docstring_1 = GoogleParser_instance_0.parse(str_0)
    assert Docstring_0.short_description == Docstring_1.short_description
    assert Docstring_0.long_description == Docstring_1.long

# Generated at 2022-06-25 16:26:39.557277
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'X~.@{(>vv>/b'
    exp_docstring = parse(text)
    obs_docstring = GoogleParser().parse(text)

    assert exp_docstring == obs_docstring

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:26:45.733745
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    str =  '''
        This is the short description.

        This is the long description.  It consists of multiple
        lines.

        Args:
            arg: Description of a positional argument.
            arg2: Description of a positional argument.
        Kwargs:
            kwarg: Description of a keyword argument.
        '''
    docstring = parser.parse(str)
    assert docstring.short_description == 'This is the short description.'
    assert docstring.long_description == 'This is the long description.  It consists of multiple\nlines.'
    assert docstring.meta[0].args == ['param', 'arg']
    assert docstring.meta[1].args == ['param', 'arg2']
    assert docstring.meta[2].args == ['kwparam', 'kwarg']

# Generated at 2022-06-25 16:26:59.073404
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    str_test_0 = 'X~.@{(>vv>/b'
    docstring_test_0 = parser.parse(str_test_0)

    assert docstring_test_0.meta == []
    assert docstring_test_0.short_description == None
    assert docstring_test_0.long_description == None

    str_test_1 = 'Parses the Google-style docstring into its components.\n\n    :returns: parsed docstring\n    '
    docstring_test_1 = parser.parse(str_test_1)

    assert docstring_test_1.meta == []
    assert docstring_test_1.short_description == 'Parses the Google-style docstring into its components.'
    assert docstring_test_1.long_

# Generated at 2022-06-25 16:27:09.557925
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Replace the following for each method to test
    def test(self, text: str) -> Docstring:
        return parse(text)

    instance = GoogleParser()
    # Setup test cases
    str_0 = 'X~.@{(>vv>/b'
    expected_0 = test_case_0()
    str_1 = 'F:z!#7b\n[=`D9\x0e"<\x0c'
    expected_1 = test_case_0()
    str_2 = '~X.@ckFb!\x0bv#7b\n[=`D9\x0e"<\x0c'
    expected_2 = test_case_0()

# Generated at 2022-06-25 16:27:19.072341
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse("X~.@{(>vv>/b") == Docstring(
        short_description=None,
        long_description=None,
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    assert parse("b>@{(>vv>/b") == Docstring(
        short_description=None,
        long_description=None,
        meta=[],
        blank_after_short_description=False,
        blank_after_long_description=False,
    )

# Generated at 2022-06-25 16:27:29.817186
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'Example 4'
    docstring_0 = parse(str_0)

    str_1 = 'Example 3'
    docstring_1 = parse(str_1)

    str_2 = 'Example 2'
    docstring_2 = parse(str_2)

    str_3 = 'remove_bad_chars(text)'
    docstring_3 = parse(str_3)

    str_4 = 'Test case'
    docstring_4 = parse(str_4)

    str_5 = 'Test case'
    docstring_5 = parse(str_5)

    str_6 = 'Test case'
    docstring_6 = parse(str_6)

    str_7 = 'Test case'
    docstring_7 = parse(str_7)

    str_8 = 'Test case'

# Generated at 2022-06-25 16:27:41.696475
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    str_1 = 'X~.@{(>vv>/b'
    docstring_1 = parse(str_1)
    str_2 = 'X~.@{(>vv>/b'
    docstring_2 = parse(str_2)
    str_3 = 'X~.@{(>vv>/b'
    docstring_3 = parse(str_3)
    str_4 = 'X~.@{(>vv>/b'
    docstring_4 = parse(str_4)
    str_5 = 'X~.@{(>vv>/b'
    docstring_5 = parse(str_5)
    str_6 = 'X~.@{(>vv>/b'


# Generated at 2022-06-25 16:27:45.127778
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == str_0
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 0

# Generated at 2022-06-25 16:27:50.285741
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    parser_0 = GoogleParser()
    docstring_0 = parser_0.parse(str_0)

if __name__ == '__main__':
  test_case_0()
  test_GoogleParser_parse()

# Generated at 2022-06-25 16:28:00.566753
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = parse('')
    docstring_0 = parse('   ')
    docstring_0 = parse('\n    Parameters:\n         a (int): The integer\n    ')
    docstring_0 = parse('Parameters:\n    a (int): The integer\n')
    docstring_0 = parse('Raises\n    Exception: The exception\n')
    docstring_0 = parse('Raises\n    Exception\n')
    docstring_0 = parse('Arguments\n    a (int)\n')
    docstring_0 = parse('Args\n    a (int)\n')
    docstring_0 = parse('Parameters\n    a (int)\n')
    docstring_0 = parse('Params\n    a (int)\n')

# Generated at 2022-06-25 16:28:05.149125
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj_0 = GoogleParser()
    str_0 = '0=!YY#1pb:kz0w)<>'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:28:13.848665
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = parse('X~.@{(>vv>/b')
    docstring_1 = parse('X~.@{(>vv>/b\n')
    docstring_2 = parse('X~.@{(>vv>/b\n\nd\n')
    docstring_3 = parse('ab\n\ncd\n')
    docstring_4 = parse('ab\n\ncd\n\n')
    docstring_5 = parse('ab\n\ncd\n\n\n')
    docstring_6 = parse('ab\n\ncd\n\n\n\ne')
    docstring_7 = parse('ab\n\ncd\n\n\n\ne\n')

# Generated at 2022-06-25 16:28:32.367409
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    assert check_docstring(docstring_0, str_0)
    str_0 = '@$>:R<>R>(#KQ~A'
    docstring_0 = parse(str_0)
    assert check_docstring(docstring_0, str_0)
    str_0 = 'R/|R>r7&u_r'
    docstring_0 = parse(str_0)
    assert check_docstring(docstring_0, str_0)
    str_0 = 't_|rr7*xg|&w|'
    docstring_0 = parse(str_0)
    assert check_docstring(docstring_0, str_0)


# Generated at 2022-06-25 16:28:36.426161
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print('testing method GoogleParser.parse of class GoogleParser')
    docstring_0 = test_case_0()


if __name__ == '__main__':

    test_GoogleParser_parse()

# Generated at 2022-06-25 16:28:40.900940
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = GoogleParser()
    str_0 = 'X~.@{(>vv>/b'
    docstring_0.parse(str_0)



# Generated at 2022-06-25 16:28:44.651935
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    str_0 = ''
    docstring_0 = parser.parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None


# Generated at 2022-06-25 16:28:50.166051
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = parse("Returns: \n    Nothing\n")
    assert docstring.meta == [
        DocstringReturns(args=['returns'], description='\n    Nothing', type_name='returns')
    ]
    docstring = parse("Returns:\n    Nothing\n")
    assert docstring.meta == [
        DocstringReturns(args=['returns'], description='\n    Nothing', type_name='returns')
    ]


# Generated at 2022-06-25 16:29:01.508266
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Try to parse empty str
    docstring_0 = GoogleParser().parse(str())
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0

    # Try to parse multiline str
    str_1 = 'Short description\n\nLong description\n\n'
    docstring_1 = GoogleParser().parse(str_1)
    assert docstring_1.short_description == 'Short description'
    assert docstring_1.long_description == 'Long description'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank

# Generated at 2022-06-25 16:29:11.576865
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    str_0 = 'X~.@{(>vv>/b'
    str_1 = 'T(#)r'
    str_2 = 'IaG'
    str_3 = 'P+dk[@.|/'
    str_4 = 'K'

    docstring_0 = parse(str_0)
    docstring_1 = parse(str_1)
    docstring_2 = parse(str_2)
    docstring_3 = parse(str_3)
    docstring_4 = parse(str_4)

# Generated at 2022-06-25 16:29:18.161631
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    args = [
        '@vw/o)*W8y;>MCTTk',
        '[{:<S)'
    ]

    for arg in args:
        try:
            parse(arg)
        except (TypeError, ValueError) as e:
            arg_repr = repr(arg)
            print("arg {} caused exception: {}".format(arg_repr, e))
            assert False


# Generated at 2022-06-25 16:29:25.225960
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    try:
        docstring_0.meta[0]
    except IndexError:
        pass
    else:
        print('Test failed. DocstringMeta should not have had length 1.')

    str_1 = 'X~.@{(>vv>/b'
    docstring_1 = parse(str_1)
    if docstring_1.meta:
        print('Test failed. DocstringMeta should have been empty.')

    str_2 = 'X~.@{(>vv>/b'
    docstring_2 = parse(str_2)
    if docstring_2.short_description:
        print('Test failed. Short description should have been None.')

    str_3

# Generated at 2022-06-25 16:29:27.003826
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:29:49.938340
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = parse('''
    Convert an array of bytes or bytearray to an array of
    code points.

    Each byte in the source will result in either a single code point
    or in a surrogate pair depending on whether or not the byte
    represents a valid UTF-8 encoded character.

    If a byte sequence is ill-formed, the result is ill-defined.
    ''')
    assert docstring.short_description == 'Convert an array of bytes or bytearray to an array of\ncode points.'
    assert not docstring.blank_after_short_description

# Generated at 2022-06-25 16:30:00.350838
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    str_0 = "The quick brown fox jumps over the lazy dog.\n"
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "The quick brown fox jumps over the lazy dog."
    assert docstring_0.long_description is None
    assert docstring_0.meta == []
    assert docstring_0.blank_after_short_description
    assert docstring_0.blank_after_long_description

    # Test case 1
    str_1 = "The quick brown fox jumps over the lazy dog.\n\nExample:\n"
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "The quick brown fox jumps over the lazy dog."
    assert docstring_1.long_description is None
    assert len

# Generated at 2022-06-25 16:30:01.898070
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()

# Compute coverage of class GoogleParser

# Generated at 2022-06-25 16:30:14.464341
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    docstring_1 = GoogleParser().parse(str_0)
    assert docstring_0.short_description == docstring_1.short_description
    assert docstring_0.blank_after_short_description == docstring_1.blank_after_short_description
    assert docstring_0.long_description == docstring_1.long_description
    assert docstring_0.blank_after_long_description == docstring_1.blank_after_long_description
    assert docstring_0.meta == docstring_1.meta

test_GoogleParser_parse()
test_case_0()

# Generated at 2022-06-25 16:30:24.944350
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == str_0
    assert docstring_0.long_description == None
    str_1 = '|>0HFy'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == str_1
    assert docstring_1.long_description == None
    str_2 = '~r=Fq'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == str_2
    assert docstring_2.long_description == None
    str_3 = ';9XcY0m'
    docstring_3 = parse(str_3)
    assert doc

# Generated at 2022-06-25 16:30:31.676273
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    try:
        assert (docstring_0.short_description == None)
    except AssertionError as e:
        print('AssertionError raised for GoogleParser.parse test')
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:42.402626
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    assert not parse(str_0).long_description
    assert not parse(str_0).meta
    assert not parse(str_0).short_description
    str_1 = '@a]&=V7|X,1~'
    assert parse(str_1).long_description == ("""
        """ if True else None)
    assert not parse(str_1).meta
    assert parse(str_1).short_description == ('@a]&=V7|X,1~' if True else None)
    str_2 = '''\
    X,n7:^I=Q]&7|X,1~
    '''
    assert parse(str_2).long_description == ("""
        """ if True else None)

# Generated at 2022-06-25 16:30:48.818446
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)

#     assert docstring_0.short_description == 'X~.@{(>vv>/b'
#     assert docstring_0.long_description == None
#     assert docstring_0.blank_after_short_description == True
#     assert docstring_0.blank_after_long_description == False
#     assert len(docstring_0.meta) == 0

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:59.234121
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()

# 
# # Function parse_google
# def parse_google(text: str) -> Docstring:
#     """Parse the Google-style docstring into its components.
#
#     :returns: parsed docstring
#     """
#     if not text:  #pragma: no cover
#         return Docstring()
#     # Clean according to PEP-0257
#     text = inspect.cleandoc(text)
#     # Find first title and split on its position
#     match = TITLES_RE.search(text)
#     if match:
#         desc_chunk = text[:match.start()]
#         meta_chunk = text[match.start():]
#     else:
#         desc_chunk = text
#         meta_chunk = ""


# Generated at 2022-06-25 16:31:04.267355
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    str_1 = '_/V7b5/5/5V7XXI'
    docstring_1 = parse(str_1)

# Generated at 2022-06-25 16:31:21.603099
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing parse")
    parser_0 = GoogleParser()
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parser_0.parse(str_0)
    print("Test 0 Passed\n")

# Unit tests for class GoogleParser

# Generated at 2022-06-25 16:31:31.934588
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from pandas.io.formats.printing import pprint_thing
    str_0 = 'X~.@{(>vv>/b'
    expected_0 = Docstring()
    expected_0.short_description = 'X~.@{(>vv>/b'
    expected_0.long_description = None
    expected_0.blank_after_short_description = False
    expected_0.blank_after_long_description = False
    expected_0.meta = []
    docstring_0 = parse(str_0)
    actual_0 = docstring_0

# Generated at 2022-06-25 16:31:38.004317
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    with open('tests/data/google_simple.txt', 'r') as google_simple_file:
        google_simple = google_simple_file.read()
        parsed = parser.parse(google_simple)
    print(parsed)
    print(parsed.meta)

# Generated at 2022-06-25 16:31:41.065332
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None



# Generated at 2022-06-25 16:31:47.401637
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Unit test for method parse of class GoogleParser")
    # Case 0:
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    print("Test Case 0:"); print(docstring_0)


# Generated at 2022-06-25 16:31:49.771041
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:31:53.600573
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    with pytest.raises(ParseError) as excinfo:
        GoogleParser().parse(str_0)

# Generated at 2022-06-25 16:31:59.560491
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = parse('A.@{(>vv>/b')
    test_repr_0 = repr(docstring_0)
    test_repr_1 = repr(docstring_0)
    assert test_repr_0 == test_repr_1


if __name__ == "__main__":
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:32:11.452232
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # initialization
    p = GoogleParser()
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    d = Docstring()
    d.short_description = None
    d.blank_after_short_description = False
    d.blank_after_long_description = False
    d.long_description = None
    d.meta.append(DocstringMeta(args=[], description=None))
    try:
        assert d == docstring_0
    except AssertionError:
        print(str_0)
    str_1 = 'foo(bar[, baz=0]) -> None\n\nfoo() calls bar() with a default baz. '
    docstring_1 = parse(str_1)
    d = Docstring()
    d

# Generated at 2022-06-25 16:32:16.863602
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'X~.@{(>vv>/b'
    docstring_0 = parse(str_0)
    str_1 = 'X~.@{(>vv>/b'
    str_2 = 'X~.@{(>vv>/b'
    docstring_1 = parse(str_1, str_2)

# Generated at 2022-06-25 16:32:55.533229
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    googleParser_0 = GoogleParser()
    googleParser_0.parse('short\n\nlong')
    googleParser_1 = GoogleParser()
    googleParser_1.parse('short')
    googleParser_2 = GoogleParser()
    googleParser_2.parse('short\n\n\n')
    googleParser_3 = GoogleParser()
    googleParser_3.parse('\nshort')
    googleParser_4 = GoogleParser()
    googleParser_4.parse('')
    googleParser_5 = GoogleParser()
    googleParser_5.parse('short\nlong')
    googleParser_6 = GoogleParser()
    googleParser_6.parse('short\nlong\n')
    googleParser_7 = GoogleParser()
    googleParser_7.parse('short\n\nlong\n\n')
   

# Generated at 2022-06-25 16:32:57.346631
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'X~.@{(>vv>/b'
    obj = GoogleParser()
    assert(obj.parse(text) == None)

# Generated at 2022-06-25 16:33:10.418186
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    str_0 = 'X~.@{(>vv>/b'
    str_1 = '@!*k>e$9})'
    str_2 = '*Ud-3B/{7T#'
    str_3 = 'p/\a!mz'
    str_4 = '*h;<\"{UNn_'
    str_5 = '~{XQiLl0'

    str_0_expected = 'X~.@{(>vv>/b'
    str_1_expected = '@!*k>e$9})'
    str_2_expected = '*Ud-3B/{7T#'
    str_3_expected = 'p/\a!mz'