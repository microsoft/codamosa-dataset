

# Generated at 2022-06-25 16:23:52.284190
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    sections_0 = []
    parser_0 = GoogleParser(sections_0)
    doc_string_0 = parse("")
    assert doc_string_0 == Docstring(
        short_description=None,
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    doc_string_1 = parse("Test")
    assert doc_string_1 == Docstring(
        short_description="Test",
        long_description=None,
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )
    doc_string_2 = parse("Test\n\n")

# Generated at 2022-06-25 16:24:03.661297
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with empty docstring
    assert GoogleParser().parse("") == Docstring()
    # Test with short and long descriptions only
    assert GoogleParser().parse("Short description.\n\nLong description.") == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )
    # Test with empty long description
    assert GoogleParser().parse("Short description.\n") == Docstring(
        short_description="Short description.",
        long_description=None,
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    # Test with indented long description

# Generated at 2022-06-25 16:24:13.456589
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text_0 = "Summary line.\n\nLong description."
    docstring_0 = parser.parse(text_0)
    assert docstring_0.short_description == "Summary line."
    assert docstring_0.long_description == "Long description."
    assert len(docstring_0.meta) == 0

    text_1 = "One-line summary.\n\n\nAttributes:\n    attr1 (type): Description of attr1.\n    attr2 (type): Description of attr2.\n        Second line of description of attr2."
    docstring_1 = parser.parse(text_1)
    assert docstring_1.short_description == "One-line summary."
    assert docstring_1.long_description is None

# Generated at 2022-06-25 16:24:23.111630
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser(title_colon=False)

# Generated at 2022-06-25 16:24:25.563556
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docs = GoogleParser(title_colon=False)
    text = "\n"
    expected = Docstring()
    result = docs.parse(text)
    assert result == expected


# Generated at 2022-06-25 16:24:38.880525
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    
    docstring = """My function with multiple args.
    
    args:
        arg1: first arg.
        arg2: second arg.
        arg3: third arg.
    returns: returns docstring.
    
    
    """

# Generated at 2022-06-25 16:24:39.449594
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass

# Generated at 2022-06-25 16:24:47.916374
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc = parser.parse(
        r'''
    This is the example.

    Args:
      a: A str.
      b: A str.

    Returns:
      True.

    Raises:
      TypeError.
      ValueError.

    Examples:
      >>> some_module.some_func(a, b)
      True
      >>> some_module.some_func(a, c)
      False

    Attributes:
      a: A str.
      b: A str.
    '''
    )
    assert doc.short_description == "This is the example."
    assert doc.blank_after_short_description is True

# Generated at 2022-06-25 16:24:59.592598
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # GH-1096
    text = '''"""
    Documentation for a function.

    Parameters
    ----------

    length : int
        The length parameter.
    width : int
        The width parameter.

    Returns
    -------
    int
        The calculated area.
    """'''


# Generated at 2022-06-25 16:25:12.050165
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc0 = '''A simple docstring.'''
    doc1 = '''A simple docstring.

With a description.'''
    doc2 = '''A simple docstring.

With a description.

And one with a blank line.'''
    doc3 = '''A simple docstring.

With a description.

And one with a blank line.

And with a final blank line.'''
    doc4 = '''A simple docstring.'''
    doc5 = '''A simple docstring.

With a description.'''
    doc6 = '''A simple docstring.

With a description.

And one with a blank line.'''
    doc7 = '''A simple docstring.

With a description.

And one with a blank line.

And with a final blank line.'''

# Generated at 2022-06-25 16:25:30.682960
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:25:38.451442
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''
    :param arg: description
    '''
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert len(docstring.meta) == 1
    param_0 = docstring.meta[0]
    assert param_0.args == ['param', 'arg']
    assert param_0.description == 'description'
    assert param_0.arg_name == 'arg'
    assert param_0.type_name is None
    assert param_0.is_optional is None
    assert param_0.default is None


# Generated at 2022-06-25 16:25:44.345467
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test docstring of method parse of class GoogleParser
    print('Test docstring of method parse of class GoogleParser')
    print(GoogleParser.parse.__doc__)
    # Test case 0
    print('\nTest case 0')
    test_case_0()

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:25:53.272958
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring_1 = parser.parse("f(x: int) -> int\n\nDocstring\n")
    docstring_2 = parser.parse("""\
f(x)
\n\
Docstring\n""")
    docstring_3 = parser.parse("""\
f(x: int)
\n\
Docstring\n""")
    docstring_4 = parser.parse("f(x: str) -> None: Return None.")
    docstring_5 = parser.parse("""\
f(x, y)
    Return None.\n""")
    docstring_6 = parser.parse("""\
f(x, y)
    Return None.\n""")

# Generated at 2022-06-25 16:26:05.865663
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    text_0 = None
    result_0 = parser_0.parse(text_0)
    assert isinstance(result_0, Docstring)
    assert result_0.short_description is None
    assert result_0.long_description is None
    assert result_0.blank_after_short_description is None
    assert result_0.blank_after_long_description is None
    assert result_0.meta == []
    text_1 = ''
    result_1 = parser_0.parse(text_1)
    assert isinstance(result_1, Docstring)
    assert result_1.short_description is None
    assert result_1.long_description is None
    assert result_1.blank_after_short_description is None
    assert result_1.blank_after_long_

# Generated at 2022-06-25 16:26:08.857262
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for case with default args
    parser = GoogleParser()
    text = None
    docstring = parse(text)
    assert docstring == Docstring()



# Generated at 2022-06-25 16:26:18.598342
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-25 16:26:26.538148
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = "A single line, no paragraphs."
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "A single line, no paragraphs."
    assert docstring_0.long_description is None
    assert not docstring_0.blank_after_short_description
    assert not docstring_0.blank_after_long_description
    assert len(docstring_0.meta) == 0



# Generated at 2022-06-25 16:26:36.592937
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    document = """
    This is a short description.

    This is a longer description.
    """
    gs = GoogleParser()

    # Invoke method
    result = gs.parse(document)

    # Check results
    assert result.short_description == 'This is a short description.'
    assert result.long_description == 'This is a longer description.'
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True


# Generated at 2022-06-25 16:26:47.656647
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Test case when first section is open
    str_0 = """\
        The summary line for a Google-style docstring should be at most 70 \
        characters, including a colon.

        If a parameter is a class, the __init__ method in the class should be \
        used as the description.

        A blank line with no indentation separates the summary line from the \
        rest of the docstring. Radical!

        :param name: The name of the person.
        :param age: The age of the person.
        :param returns: The return value. True for success, False otherwise.
        :raises KeyError: Raises an exception.
        """
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:27:10.383261
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_1 = """
    Example function with types annotated.

    Parameters
    ----------
    param1: int
        The first parameter.
    param2: str
        The second parameter.

    Returns
    -------
    bool
        True if successful, False otherwise.

    """
    docstring_1 = parse(str_1)
    assert isinstance(docstring_1, Docstring)
    assert docstring_1.short_description == "Example function with types annotated."
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == None

# Generated at 2022-06-25 16:27:11.813267
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = test_case_0()


# Generated at 2022-06-25 16:27:20.655022
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    str_0 = 'Raises:\n    ValueError: if x < 0\n    TypeError: if x is not a number'
    expected_0 = Docstring(
        "",
        "",
        [
            DocstringRaises(
                args=["raises", "ValueError: if x < 0"],
                description="if x < 0",
                type_name="ValueError",
            ),
            DocstringRaises(
                args=["raises", "TypeError: if x is not a number"],
                description="if x is not a number",
                type_name="TypeError",
            ),
        ]
    )

    # Execution
    actual_0 = GoogleParser().parse(str_0)

    # Validation
    assert actual_0 == expected_0


# Generated at 2022-06-25 16:27:33.113654
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    str_0 = """Args:
      param1 (str): The first parameter.
      param2 (:obj:`int`, optional): The second parameter. Defaults to None.
    Returns:
      bool: The return value. True for success, False otherwise.
    """
    docstring_0 = parser.parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta[0].args == ['returns', 'bool']
    assert docstring_0.meta[0].type_name == 'bool'
    assert docstring_0.meta[0].is_

# Generated at 2022-06-25 16:27:44.180261
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = """Do one thing and do it well.

The function does one thing and does it well.

Params:
    param1 (str): parameter1. Defaults to None.
    param2 (str): parameter2. Defaults to "abc".
Returns:
    str: The return value.
Raises:
    Exception: An exception occurs."""
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Do one thing and do it well.'
    assert docstring_0.long_description == 'The function does one thing and does it well.'
    assert len(docstring_0.meta) == 4
    assert docstring_0.meta[0].args == ['param', 'param1 (str)']

# Generated at 2022-06-25 16:27:46.329941
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    actual = obj.parse(None)
    expected = None
    print("Test 0 Passed")


test_GoogleParser_parse()

# Generated at 2022-06-25 16:27:50.841016
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = None
    docstring_0 = parse(str_0)
    parser_0 = GoogleParser()
    docstring_1 = parser_0.parse(str_0)
    assert docstring_0 == docstring_1

# Generated at 2022-06-25 16:27:53.625214
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # assertEqual(expected, parse(text))
    raise NotImplementedError()


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 16:28:04.963541
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    str_0 = None
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert len(docstring_0.meta) == 0

    # Test case 1
    str_1 = """\
    Parser for Google-style docstring

    Parsing is based on the algorithm presented in PEP 257.
    """
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "Parser for Google-style docstring"
    assert docstring_1.long_description == "Parsing is based on the algorithm presented in PEP 257."
    assert len(docstring_1.meta) == 0

    # Test case 2

# Generated at 2022-06-25 16:28:13.755253
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_1 = None
    docstring_1 = GoogleParser().parse(str_1)

    str_2 = """
    Calculate the length of a line.

    The length of the line is calculated as the square root of the sum of the
    squared differences between each coordinate.

    Parameters
    ----------
        line:  Tuple[Tuple[float, float], Tuple[float, float]]
            Tuple of 2 points. Each point should be a 2-dimensional tuple of
            floats.

    Returns
    -------
        float
            Length of the line.

    Examples
    --------
    >>> line = ((0, 0), (1, 1))
    >>> distance(line)
    1.4142135623730951
    """
    docstring_2 = GoogleParser().parse(str_2)


# Generated at 2022-06-25 16:28:27.044650
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = """This is a simple test function.\n    \n    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "This is a simple test function."


    str_1 = """This is a simple test function.\n\n"""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == "This is a simple test function."


    str_2 = """This is a simple test function.\n    """
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == "This is a simple test function."


    str_3 = """ This is a simple test function.\n    \n    """
    docstring_3 = parse(str_3)
    assert docstring

# Generated at 2022-06-25 16:28:37.881991
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = None

    assert parse(str_0) == GoogleParser().parse(str_0)

# from enum import IntEnum
# from collections import namedtuple
# from typing import *
# from .common import *
# from .numpy import *
# from .google import *
# from .sphinx import *
# from .enum import *
# from .attributes import *
# from .attributes_class import *
# from .attributes_method import *
# from .attributes_property import *
# from .writer import *
# from .style import *
# from .cli import *
# from .__about__ import *
# from .__version__ import *

# Generated at 2022-06-25 16:28:48.627267
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Regression testing for method 'parse' of class 'GoogleParser'.
    """
    str_0 = "First line of description.\n\nSecond line of description.\n\nArgs:\n  arg_name: The name of the argument.\n  arg_type: The type of the argument.\n\nReturns:\n  The type of the return value.\n\nRaises:\n  ExceptionName: An exception type."
    docstring_0 = GoogleParser().parse(str_0)
    assert docstring_0.short_description == "First line of description."
    assert docstring_0.blank_after_short_description
    assert docstring_0.long_description == "Second line of description."
    assert docstring_0.blank_after_long_description
    assert docstring_0.meta[0].description

# Generated at 2022-06-25 16:29:00.229081
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_1 = None
    docstring_1 = parse(str_1)
    str_2 = """This is the first line.

This is the second line.

And the third.

Arguments:
    param1 (int): This is a param.
    param2 (str): This is another param.

Returns:
    bool: This is the return type.

"""
    docstring_2 = parse(str_2)
    _result = docstring_2
    assert isinstance(_result, Docstring)
    assert _result.short_description == "This is the first line."
    assert _result.long_description == """This is the second line.
And the third.
"""
    assert len(_result.meta) == 3
    meta_0 = _result.meta[0]

# Generated at 2022-06-25 16:29:14.613115
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test the GoogleParser parse method."""
    expected_docstring = Docstring(
        short_description="Test method.",
        blank_after_short_description=False,
        blank_after_long_description=True,
        long_description=None,
        meta=[
            DocstringParam(
                description="The method argument.",
                arg_name="arg",
                type_name=None,
                is_optional=False,
                default=None,
                args=["param", "arg"],
            )
        ],
    )
    test_docstring = parse(
        """Test method.
        Args:
            arg (:obj:`~mypackage.mymodule.MyClass`): The method argument."""
    )
    assert test_docstring == expected_docstring


# Generated at 2022-06-25 16:29:21.113027
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    # Case-0
    str_0 = None
    docstring_0 = parser.parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == None
    assert docstring_0.blank_after_long_description == None
    assert len(docstring_0.meta) == 0

# Generated at 2022-06-25 16:29:23.346407
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    str_0 = None
    docstring_0 = obj.parse(str_0)


# Generated at 2022-06-25 16:29:33.935899
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = "short description"
    docstring_0 = parse(str_0)
    str_1 = "short description\nlong description"
    docstring_1 = parse(str_1)
    str_2 = "short description\n\nlong description"
    docstring_2 = parse(str_2)
    str_3 = "short description\nlong description\n\nmore long description"
    docstring_3 = parse(str_3)
    str_4 = "short description\n\nlong description\n\nmore long description"
    docstring_4 = parse(str_4)
    str_5 = "short description\n\nlong description\n\nmore long description\n\n"
    docstring_5 = parse(str_5)

# Generated at 2022-06-25 16:29:41.386871
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = """
    Test title
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    long descr
    """
    docstring = Docstring(
        'Test title',
        '\nlong descr',
        blank_after_long_description=True,
        blank_after_short_description=True,
    )
    assert GoogleParser().parse(str_0) == docstring



# Generated at 2022-06-25 16:29:49.332448
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = '''
    Parse the Google-style docstring into its components.


    :returns: parsed docstring
    '''
    doc = GoogleParser().parse(str_0)

    assert doc.description() == str_0
    # Make sure default sections are inferred correctly
    assert "Arguments" in doc.sections()
    assert "Returns" in doc.sections()



# Generated at 2022-06-25 16:30:01.232736
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = """Summary line.

    Extended description.
    """
    docstring_0 = parse(str_0)
    str_1 = """Summary line.

    Extended description.

Args:
    param1 (int): The first parameter.
    param2 (str): The second parameter.

Returns:
    bool: The return value. True for success, False otherwise.
    """
    docstring_1 = parse(str_1)
    str_2 = """Summary line.

    Extended description.

Arguments:
    arg1 (int): The first parameter.
    arg2 (str, optional): The second parameter. Defaults to "foo".

Returns:
    bool: The return value. True for success, False otherwise.
    """
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:30:04.381653
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = None
    docstring_0 = parse(str_0)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 16:30:17.896612
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = None
    str_1 = ""
    str_2 = """
    Subprocess execution with a custom version of the Popen API.

    :param args: The sequence of program arguments or else the string to
        execute through the shell (see `run`).

    :param shell: Whether or not there should be a shell used to execute this
        command.

    :param check: Raise CalledProcessError if return code is not zero.

    :param capture_output: Capture stdout/stderr and expose the output as
        attributes on the exception when check is True.

    :param text: If capture_output is True, this is the text to be used for
        stdin.

    :param timeout: Number of seconds before the subprocess is timed out.

    :param encoding: The encoding to use if the output is captured.
    """
    docstring

# Generated at 2022-06-25 16:30:20.534163
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_1 = ""
    docstring_1 = parse(str_1)
    print(str_1)
    print(docstring_1)
    assert docstring_1 is not None


# Generated at 2022-06-25 16:30:31.842741
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # case 0
    str_0 = None
    docstring_0 = parse(str_0)

    # case 1
    str_1 = """Summary line.

    Extended description of function.
    """
    docstring_1 = parse(str_1)

    assert docstring_1.short_description == "Summary line."
    assert docstring_1.blank_after_short_description is True
    assert docstring_1.long_description == "Extended description of function."
    assert docstring_1.blank_after_long_description is True
    assert not docstring_1.meta

    # case 2
    str_2 = """Summary line.
    Extended description of function.
    """
    docstring_2 = parse(str_2)

    assert docstring_2.short_description == "Summary line."
    assert doc

# Generated at 2022-06-25 16:30:42.531690
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert parse(None) == Docstring()
    assert parse("") == Docstring()

# Generated at 2022-06-25 16:30:46.169818
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = parse("Some docstring.")
    assert docstring.short_description == "Some docstring."
    assert not docstring.long_description
    assert not docstring.meta
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description



# Generated at 2022-06-25 16:30:57.733389
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # setup
    gp = GoogleParser()
    docstring_0 = Docstring()
    docstring_1 = Docstring()
    docstring_2 = Docstring()
    docstring_3 = Docstring()
    docstring_4 = Docstring()
    docstring_5 = Docstring()
    docstring_6 = Docstring()

    # test case 0
    test_str_0 = None
    try:
        ret_str_0 = gp.parse(test_str_0)
        assert ret_str_0 == docstring_0
    except ParseError as pe:
        raise AssertionError(pe)

    # test case 1
    test_str_1 = """
    This is a description.
    """
    docstring_1.short_description = "This is a description."

# Generated at 2022-06-25 16:31:03.183109
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    string_1 = parse(
        """An example docstring for an object.
        :param arg1: The first argument.
        :type arg1: str
        :param arg2: The second argument.
        :type arg2: int, optional
        """
    )
    assert [
        meta.description == "The first argument."
        for meta in string_1.meta
        if meta.key == "param" and meta.args[1] == "arg1"
    ]
    assert [
        meta.description == "The second argument."
        for meta in string_1.meta
        if meta.key == "param" and meta.args[1] == "arg2"
    ]
    assert string_1.returns == []



# Generated at 2022-06-25 16:31:04.042654
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()



# Generated at 2022-06-25 16:31:18.535124
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = parse("")
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.meta == []
    assert docstring_0.blank_after_short_description == None
    assert docstring_0.blank_after_long_description == None
    docstring_1 = parse("a")
    assert docstring_1.short_description == "a"
    assert docstring_1.long_description == None
    assert docstring_1.meta == []
    assert docstring_1.blank_after_short_description == None
    assert docstring_1.blank_after_long_description == None
    docstring_2 = parse("a\nb")
    assert docstring_2.short_description == "a"
    assert docstring_2

# Generated at 2022-06-25 16:31:27.114399
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:31:38.673644
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test parse of None
    str_0 = None
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0
    # Test parse of empty string
    str_1 = ""
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False

# Generated at 2022-06-25 16:31:49.854349
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    GoogleParser_inst = GoogleParser()
    str_0 = None
    docstring_0 = GoogleParser_inst.parse(str_0)

    str_1 = ""
    docstring_1 = GoogleParser_inst.parse(str_1)

    str_2 = """
    Perform some operation.

    If `x` is provided, do `X`.
    If `y` is provided, do `Y`.

    Args:
        x: Optional[int]: Do `X` with `x`.
        y: Optional[int]: Do `Y` with `y`.

    Returns:
        int: The result.

    Raises:
        ValueError: If `x` and `y` are both provided.

    """
    docstring_2 = GoogleParser_inst.parse(str_2)


# Generated at 2022-06-25 16:31:54.630484
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # noinspection PyUnresolvedReferences
    test_case_0()


# Entry point for debugging
if __name__ == "__main__":
    import sys

    # Uncomment one of the following to debug specific test case

    # test_case_0()
    # test_GoogleParser_parse()

    # Run all tests
    for test in (
        test_case_0,
        test_GoogleParser_parse,
    ):
        test()

# Generated at 2022-06-25 16:31:58.890653
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Given
    parser = GoogleParser()
    str_0 = None
    # When
    docstring_0 = parser.parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:32:02.041289
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()



# Generated at 2022-06-25 16:32:09.831443
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    str_0 = """b"""

    # Act
    docstring_0 = GoogleParser().parse(str_0)

    # Assert
    assert len(docstring_0.meta) == 0
    # assert docstring_0.short_description == 'b'
    assert docstring_0.short_description is None
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.long_description is None



# Generated at 2022-06-25 16:32:12.781618
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    str_0 = None
    docstring_0 = parse(str_0)

    assert_equals(docstring_0.short_description, None)
    assert_equals(docstring_0.long_description, None)


# Generated at 2022-06-25 16:32:25.278177
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    st = '''\
        Args:
            x: A string.
            y: An integer.
        Returns:
            Nothing.
    '''
    parser = GoogleParser()
    res = parser.parse(st)
    assert isinstance(res, Docstring)

    st = '''\
        Args:
            x: A string.
            y: An integer.
        Raises:
            ValueError: The input was not valid.
        Returns:
            A tuple.
    '''
    parser = GoogleParser()
    res = parser.parse(st)
    assert isinstance(res, Docstring)

    st = '''\
        Args:
            x: A string.
            y: An integer.
        Raises:
            ValueError: The input was not valid.
    '''
    parser = Google

# Generated at 2022-06-25 16:32:33.828657
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert isinstance(test_case_0(), Docstring)

# Generated at 2022-06-25 16:32:42.292550
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    # Test docstring 0
    # Case where there is no docstring
    str_0 = None
    assert parser.parse(str_0) == Docstring()

    # Test docstring 1
    # Case where there is only a short description
    str_1 = "Short description"
    expected_1 = Docstring()
    expected_1.short_description = str_1
    assert parser.parse(str_1) == expected_1

    # Test docstring 2
    # Case where there is only a long description
    str_2 = "\n    Long description\n"
    expected_2 = Docstring()
    expected_2.long_description = "Long description"
    assert parser.parse(str_2) == expected_2

    # Test docstring 3
    # Case where there is a blank line between the

# Generated at 2022-06-25 16:32:54.838073
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    str_0 = """
    Args:
        a (int):
            a doc.
            a doc.
            a doc.
        - b (int):
            b doc.
            b doc.
    """
    docstring_0 = parser.parse(str_0)
    assert len(docstring_0.meta) == 2
    assert docstring_0.meta[0].description == 'a doc.\na doc.\na doc.'
    assert docstring_0.meta[0].arg_name == 'a'
    assert docstring_0.meta[0].type_name == 'int'
    assert docstring_0.meta[1].description == 'b doc.\nb doc.'
    assert docstring_0.meta[1].arg_name == 'b'
    assert docstring_

# Generated at 2022-06-25 16:33:01.483034
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    str_0 = """Docstring for a class.

Simple multi-line description.

Attributes:
    attr_a: Description of `attr_a`.
    attr_b (str): Description of `attr_b`.
    attr_c (:obj:`int`, optional): Description of `attr_c`, defaults to 42.
"""
    docstring_0 = parser_0.parse(str_0)

    assert docstring_0.short_description == "Docstring for a class."
    assert docstring_0.long_description == "Simple multi-line description."
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == True
    assert len(docstring_0.meta) == 3

    attr_