

# Generated at 2022-06-25 16:23:35.362954
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = """\
    Args:
      arg1 (str): path to some file.
    """
    docstring = GoogleParser().parse(text_0)
    print(docstring)

    text_1 = """\
    Arguments:
      arg1 (str): path to some file.

      arg2 (str): another path.
        This is a pretty long
        description.

    Raises:
      ValueError: if arg1 is None.

    Returns (list): some list
    """
    docstring = GoogleParser().parse(text_1)
    print(docstring)

test_GoogleParser_parse()

# Generated at 2022-06-25 16:23:42.733137
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    text_0 = """A short summary.

A longer description with multiple paragraphs.

Args:
  param: A description for a parameter.

  param: Another description for a parameter.
"""

# Generated at 2022-06-25 16:23:46.029753
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse('GoogleParser.parse:\n    \n        Google-style docstring parsing.\n    \n    :returns: parsed docstring\n    ')
    print(docstring_0.meta)


# Generated at 2022-06-25 16:23:57.923270
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser(title_colon=True)
    docstring_0 = parser.parse(
        'some function.'
        'with tests for both unix and windows line endings (CR vs CRLF).'
        '\r\n\r\nArgs:\r\n  test_unix_lineendings (bool): Test\r\n                                                  _unix_lineendings.\r\n  test_windows_lineendings (bool): Test\r\n                                    _windows_lineendings.\r\n'
        '\r\nReturns:\r\n  str: some tests\r\n'
    )

# Generated at 2022-06-25 16:24:05.701616
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = ""
    assert GoogleParser().parse(text) == Docstring()

    text = """\
            Short description.

            Long description.
            """
    assert GoogleParser().parse(text) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    text = """\
            Short description.

            Long description.

            """
    assert GoogleParser().parse(text) == Docstring(
        short_description="Short description.",
        long_description="Long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
        meta=[],
    )


# Generated at 2022-06-25 16:24:12.143328
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """
    This is a docstring.

    This is more text.
    """
    # print("GoogleParser_parse_0: ", parser.parse(text))
    result = parser.parse(text)
    assert result.short_description == "This is a docstring."
    assert result.long_description == "This is more text."
    assert result.meta == []
    assert result.blank_after_short_description
    assert result.blank_after_long_description
    text = """
    This is a docstring.

    This is more text.

    Another paragraph.
    """
    # print("GoogleParser_parse_1: ", parser.parse(text))
    result = parser.parse(text)
    assert result.short_description == "This is a docstring."

# Generated at 2022-06-25 16:24:18.270554
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = """This is a short description.
    This is a long description.
    """
    expected = Docstring(
        short_description="This is a short description.",
        long_description="This is a long description.",
        meta=list(),
        blank_after_short_description=True,
        blank_after_long_description=False,
    )
    actual = parser.parse(docstring)
    assert actual == expected



# Generated at 2022-06-25 16:24:25.670968
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gparser = GoogleParser()

# Generated at 2022-06-25 16:24:38.973175
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("") == Docstring()
    assert GoogleParser().parse("\n\n") == Docstring()
    assert (
        GoogleParser().parse("This is a test\n\n    import this\n\n")
        == Docstring(
            short_description="This is a test",
            long_description="import this",
            blank_after_short_description=False,
            blank_after_long_description=True,
            meta=[],
        )
    )

# Generated at 2022-06-25 16:24:51.242887
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = "This is a docstring."
    actual = parser.parse(text)
    assert actual == Docstring(
        short_description="This is a docstring.",
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
    )

    text = "This is a docstring.\nAnd so is this."
    actual = parser.parse(text)
    assert actual == Docstring(
        short_description="This is a docstring.",
        blank_after_short_description=False,
        long_description="And so is this.",
        blank_after_long_description=False,
    )

    text = "This is a docstring.\n\n    This is code.\n\nAnd so is this."
   

# Generated at 2022-06-25 16:25:09.979284
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    s = "This is a sample docstring.\n\n\n" \
        "Deeper description.\n" \
        "And it continues.\n\n" \
        "Args:\n" \
        "    arg1 (str): First argument.\n" \
        "    arg2 (str, optional): Second argument.\n\n" \
        "Raises:\n" \
        "    ValueError: if it fails.\n\n" \
        "Returns:\n" \
        "    str: the result.\n\n" \
        "Yields:\n" \
        "    str: the sequence.\n\n" \
        "Example:\n" \
        "    >>> print(this(is=True))\n" \
        "    None\n\n" \
       

# Generated at 2022-06-25 16:25:17.381142
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = ":param int x: The x value\n:param int y: The y value\n"
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.meta[0].args == ['param', 'x']
    assert docstring_0.meta[1].args == ['param', 'y']



# Generated at 2022-06-25 16:25:20.802985
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = make_sample_docstrings()[0]
    assert len(text) > 0
    gp = GoogleParser()
    gp.parse(text)

# Generated at 2022-06-25 16:25:31.409017
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc = parser.parse("  Test \n\n   :returns: value  \n")
    assert doc.short_description == "Test"
    assert doc.long_description == None
    assert doc.blank_after_short_description == True
    assert doc.blank_after_long_description == None
    assert doc.meta == []
    doc = parser.parse("One line.")
    assert doc.short_description == "One line."
    assert doc.long_description == None
    assert doc.blank_after_short_description == None
    assert doc.blank_after_long_description == None
    assert doc.meta == []
    doc = parser.parse("One line.\n\nMore text.\n")
    assert doc.short_description == "One line."
    assert doc.long_

# Generated at 2022-06-25 16:25:37.448870
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    input_text = ''
    input_sections = [
        Section('Returns', 'returns', section_type_0),
        Section('Raises', 'raises', section_type_0)
    ]
    input_title_colon = True
    expected_result = Docstring(short_description='', long_description=None)

    # Act
    actual_result = GoogleParser(input_sections, input_title_colon).parse(input_text)

    # Assert
    assert actual_result == expected_result


# Generated at 2022-06-25 16:25:49.087380
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    global test_case_0
    global test_case_1
    global test_case_2
    global test_case_3
    global test_case_4
    global test_case_5
    global test_case_6
    global test_case_7
    global test_case_8
    global test_case_9
    global test_case_10
    global test_case_11
    global test_case_12
    global test_case_13
    global test_case_14
    global test_case_15
    global test_case_16
    global test_case_17
    global test_case_18
    global test_case_19
    global test_case_20
    global test_case_21
    global test_case_22
    global test_case_23
    global test_case_24

# Generated at 2022-06-25 16:26:02.797583
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    a_parser = GoogleParser()
    """
    Test 0: Test single line description
    Input:  | """

# Generated at 2022-06-25 16:26:14.535126
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    #
    # Test case 0
    #
    google_parser_0 = GoogleParser()
    text_0 = "Generate a random integer between a and b\n\nArgs:\n    a: Lower limit.\n    b: Upper limit.\n\nReturns:\n    The random integer.\n    The random integer.\n\nRaises:\n    ValueError: If a is bigger than b.\n    "
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == "Generate a random integer between a and b"

# Generated at 2022-06-25 16:26:22.548346
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("************* test_GoogleParser_parse **************")
    google_parser = GoogleParser()
    docstring = google_parser.parse('"""\n    Attributes:\n        attribute_0 (int): This is attribute_1. Defaults to 0.\n        attribute_1 (dict): This is attribute_1. Defaults to {}.\n    """')
    assert len(docstring.meta) == 2
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is None
    assert docstring.blank_after_long_description is None
    assert docstring.meta[0].key == 'attribute'
    assert docstring.meta[0].args == ['attribute', 'attribute_0 (int)']

# Generated at 2022-06-25 16:26:31.036840
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    f = open("tests/docstring_test_cases/test_docstring_GoogleParser_parse.txt", "r")
    docstring_test_case = f.read()

    f = open("tests/docstring_test_cases/expected_result_docstring_GoogleParser_parse.txt", "r")
    docstring_expected_result = f.read()

    docstring = GoogleParser().parse(docstring_test_case)

    assert str(docstring) == docstring_expected_result

# Generated at 2022-06-25 16:26:39.675925
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "Hello World"
    exp_0 = Docstring(
        short_description="Hello World",
        blank_after_short_description=False,
        blank_after_long_description=False,
    )
    ret_0 = google_parser_0.parse(text_0)
    assert ret_0 == exp_0


# Generated at 2022-06-25 16:26:45.792087
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Get GoogleParser object
    google_parser_0 = GoogleParser()

    # Assert that function parse is implemented
    assert hasattr(google_parser_0, 'parse')
    # Assert that method parse is of type function
    assert(str(type(GoogleParser.parse)) == "<class 'function'>")

    # Parse the source code of method parse
    src_parse = inspect.getsource(GoogleParser.parse)
    # Convert the source code of parse to a list of lines
    src_parse = src_parse.split('\n')
    # Filter out comments and blank lines from the source
    src_parse = list(filter(lambda x : x[:2] != '# ' and x != '', src_parse))
    # Get the first line of the function parse
    src_parse_1 = src_parse[0]



# Generated at 2022-06-25 16:26:49.594783
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    meta = google_parser.parse('first line\n  second line\n    returns:\n      value')
    assert len(meta.meta) == 1
    assert isinstance(meta.meta[0], DocstringReturns)


# Generated at 2022-06-25 16:26:58.355841
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()
    text = inspect.cleandoc("""
    """
    )
    expected = Docstring({
        "short_description": None,
        "long_description": None,
        "blank_after_short_description": False,
        "blank_after_long_description": False,
        "meta": []
    }
    )
    actual = google_parser_0.parse(text)
    assert actual == expected

    google_parser_1 = GoogleParser()
    text = inspect.cleandoc("""
        """
    )

# Generated at 2022-06-25 16:27:09.151799
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    d = """One line summary.

    Longer description.

    Args:
        arg1 (int): Description of arg1.
        arg2 (str, optional): Description of arg2.
            Defaults to "foo".

    Returns:
        int: Description of return value.
    """

# Generated at 2022-06-25 16:27:12.347392
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    text_1 = " this is a test"
    docstring_1 = google_parser_1.parse(text=text_1)
    assert docstring_1 == Docstring()


# Generated at 2022-06-25 16:27:20.947155
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()

    text = '''
        This is a summary.

        This is a description.

        Parameters
        ----------
        arg_0 : int
            A description of arg_0
        arg_1 : str
            Another description of arg_1

        Returns
        -------
        tuple(str, int)
            Meaning of this tuple
    '''
    docstring_2 = google_parser_1.parse(text)

    assert docstring_2.short_description == "This is a summary."
    assert docstring_2.long_description == "This is a description."
    assert docstring_2.blank_after_long_description == True
    assert docstring_2.meta[0].args == ['param']
    assert docstring_2.meta[0].arg_name == 'arg_0'

# Generated at 2022-06-25 16:27:22.695365
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.parse("This is a short description")

# Generated at 2022-06-25 16:27:35.755496
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse(
        "Single line docstring.") == Docstring(
        "Single line docstring.", None, False, False, None
    )
    assert google_parser_0.parse(
        "Single line.\nDocstring with several lines.") == Docstring(
        "Single line.", None, True, False, "Docstring with several lines."
    )
    assert google_parser_0.parse(
        "Single line.\n") == Docstring(
        "Single line.", None, True, True, None
    )
    assert google_parser_0.parse(
        "Single line.\n\n") == Docstring(
        "Single line.", None, True, True, None
    )


# Generated at 2022-06-25 16:27:44.441665
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case data
    google_parser_0 = GoogleParser()
    text_0 = 'Parses a google-style docstring and returns its components.'

    # Call the method to test
    result = google_parser_0.parse(text_0)

    # Verify the results
    assert (result.short_description == 'Parses a google-style docstring and returns its components.')
    assert (result.blank_after_short_description == False)
    assert (result.blank_after_long_description == False)
    assert (result.long_description == None)
    assert (result.meta == [])

# Generated at 2022-06-25 16:27:53.178382
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_obj = GoogleParser()
    text = "This is the short description.\n\nThis is the long description.\n\nArgs:\narg_name (type_name): Description. Default value: None."
    ret = google_parser_obj.parse(text)
    return ret


# Generated at 2022-06-25 16:27:59.126606
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    text = 'Example of class docstring.'
    docstring = google_parser.parse(text)
    assert docstring.short_description == 'Example of class docstring.'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.return_type == None
    assert docstring.return_desc == None


# Generated at 2022-06-25 16:28:10.884766
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    P = GoogleParser()
    # case 0
    text = None
    ret = P.parse(text)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert ret.meta == []
    # case 1
    text = "  "
    ret = P.parse(text)
    assert ret.short_description is None
    assert ret.long_description is None
    assert ret.blank_after_short_description is False
    assert ret.blank_after_long_description is False
    assert ret.meta == []
    # case 2
    text = ""
    ret = P.parse(text)
    assert ret.short_description is None

# Generated at 2022-06-25 16:28:20.706317
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_cases = [
        # test_case_0
        (
           (
                """
                Calculate the square root of a number.

                Args:
                    n (int): The number to find the square root of.
                """
            ),
            {
                "short_description": "Calculate the square root of a number.",
                "long_description": None,
                "blank_after_short_description": False,
                "blank_after_long_description": False,
                "meta": [
                    DocstringParam(
                        args=["param", "n (int)"],
                        arg_name="n",
                        description="The number to find the square root of.",
                        type_name="int",
                        is_optional=False,
                        default=None,
                    )
                ],
            },
        ),
    ]

# Generated at 2022-06-25 16:28:33.091253
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    assert google_parser_1.parse('    Function for testing.\n\n    Note qwert, this is a test function.\n\n    Args:\n        arg0: arg0\n    ') == Docstring('    Function for testing.\n\n    Note qwert, this is a test function.\n\n', 'Function for testing.', 'Note qwert, this is a test function.', [DocstringParam(['arg'], 'arg0', 'arg0', None, None, True)])
    google_parser_2 = GoogleParser()

# Generated at 2022-06-25 16:28:39.636959
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    string_0 = """
        """
    Docstring_0 = google_parser_0.parse(string_0)
    string_1 = """
        A short description of the class.
    
        A longer description of the class.  Not sure
        what to write here.  Can be multiple paragraphs.
    
        Args:
            arg1: A required argument
            arg2: An optional argument
        """
    Docstring_1 = google_parser_0.parse(string_1)
    string_2 = """
        A short description of the class.
    
        A longer description of the class.  Not sure
        what to write here.  Can be multiple paragraphs.
    
        Args:
            arg1: A required argument.
            arg2: An optional argument.
        """


# Generated at 2022-06-25 16:28:42.758841
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = ' docstring '
    docstring_1 = google_parser_0.parse(text_0)
    docstring_1.short_description


# Generated at 2022-06-25 16:28:53.874411
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "Hello, world!"
    result_0 = google_parser_0.parse(text_0)
    check_0 = Docstring()
    check_0.short_description = "Hello, world!"
    check_0.blank_after_short_description = True
    check_0.long_description = None
    check_0.blank_after_long_description = False

# Generated at 2022-06-25 16:29:01.245551
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'Parse the Google-style docstring into its components.\n\n:returns: parsed docstring'
    google_parser_0 = GoogleParser()
    result = google_parser_0.parse(text)
    assert result.short_description == 'Parse the Google-style docstring into its components.'
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.long_description == ':returns: parsed docstring'
    assert len(result.meta) == 0


# Generated at 2022-06-25 16:29:07.737335
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Tests the GoogleParser.parse() method."""
    # Parameters
    text = ""
    expected = ""
    # Process
    result = GoogleParser().parse(text)
    # Verify
    assert result == expected

test_case_0()


# Generated at 2022-06-25 16:29:29.959441
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test_case(text):
        google_parser_0 = GoogleParser()
        assert isinstance(google_parser_0.parse(), Docstring), "Expected instance of type 'Docstring'"
        return Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test_case(text) == Docstring()
    assert test

# Generated at 2022-06-25 16:29:41.314749
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Setup test variables
    docstr_str_0 = 'top'
    docstr_str_1 = "one"
    docstr_str_2 = "two"
    docstr_str_3 = None
    docstr_str_4 = "four"
    docstr_str_5 = "five"
    docstr_str_6 = "six"
    docstr_str_7 = "seven"
    docstr_str_8 = "eight"
    docstr_str_9 = "nine"

    # Setup test class instances
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse(docstr_str_0)

    # Test method parse of class GoogleParser with docstring
    assert docstring_0.short_description == docstr_str_0

    # Setup test

# Generated at 2022-06-25 16:29:52.367881
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    string_0 = ''
    assert_equal(google_parser_0.parse(string_0), '""')
    string_0 = ''
    assert_equal(google_parser_0.parse(string_0), '""')
    string_0 = ''
    assert_equal(google_parser_0.parse(string_0), '""')
    string_0 = ''
    assert_equal(google_parser_0.parse(string_0), '""')
    string_0 = ''
    assert_equal(google_parser_0.parse(string_0), '""')
    string_0 = ''
    assert_equal(google_parser_0.parse(string_0), '""')
    string_0 = ''

# Generated at 2022-06-25 16:29:57.519235
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()

    docstring_0 = """
    my_function(arg1, arg2):
      """

    expected = Docstring()
    expected.short_description = "my_function(arg1, arg2)"

    assert google_parser_0.parse(docstring_0) == expected


# Generated at 2022-06-25 16:30:10.140693
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.sections = {'Raises': Section('Raises', key='raises', type=SectionType.MULTIPLE), 'Parameter': Section('Parameter', key='param', type=SectionType.MULTIPLE), 'Args': Section('Args', key='param', type=SectionType.MULTIPLE), 'Yields': Section('Yields', key='yields', type=SectionType.SINGULAR_OR_MULTIPLE), 'Exception': Section('Exception', key='raises', type=SectionType.MULTIPLE)}
    google_parser_0.title_colon = False
    try:
        google_parser_0._setup()
    except Exception as e:
        assert False


# Generated at 2022-06-25 16:30:18.139330
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser(DEFAULT_SECTIONS)
    text = '"""This is a docstring."""'
    ret = google_parser_0.parse(text)

    assert(ret.short_description == "This is a docstring.")
    assert(ret.long_description is None)
    assert(ret.blank_after_short_description is False)
    assert(ret.blank_after_long_description is True)
    assert(len(ret.meta) == 0)


# Generated at 2022-06-25 16:30:30.951665
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("test GoogleParser.parse")

    # Test different types of docstrings
    # Empty docstring
    description = ""
    docstring = GoogleParser().parse(description)
    assert not docstring.short_description
    assert not docstring.long_description
    assert not docstring.meta
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description

    # Test simple docstring
    description = """\
        This is a very simple docstring with no description of arguments.
    """
    docstring = GoogleParser().parse(description)
    assert docstring.short_description == "This is a very simple docstring with no description of arguments."
    assert not docstring.long_description
    assert not docstring.meta
    assert not docstring.blank_after_short_description

# Generated at 2022-06-25 16:30:41.490771
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    GoogleParser_0 = GoogleParser()
    text_0 = " This is a short description.\n\nThis is a long description.\n\nThis is a third description.\n\nArgs:\n    param1 (int): Param one description.\n    param2 (str): Param two description. Defaults to \"two\".\n    param3 (tuple): Param three description. Defaults to (1, 2).\n\nReturns:\n    int: Return value description.\nRaises:\n    ZeroDivisionError: Error description\n    ValueError: Error description\n"

# Generated at 2022-06-25 16:30:43.865024
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Testing the case function of parse
    google_parser_0 = GoogleParser()

    assert google_parser_0.parse("") == Docstring("")

# Generated at 2022-06-25 16:30:54.072175
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "First line.\n\nDescription::\n\n Long description.\nremainder\n"
    google_parser_0 = GoogleParser()
    ret = google_parser_0.parse(text)
    assert isinstance(ret, Docstring)
    assert ret.short_description == 'First line.'
    assert ret.blank_after_short_description
    assert ret.long_description == 'Long description.'
    assert ret.blank_after_long_description
    assert len(ret.meta) == 0


# Generated at 2022-06-25 16:31:23.107482
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # A Google-style docstring

    docstring = """
        This is a Google-style docstring.

        This is the short description.

        This is the long description.

        Args:
            arg1: The first argument.
            arg2: The second argument.

        Raises:
            Exception1: The first exception.
            Exception2: The second exception.
        """


# Generated at 2022-06-25 16:31:32.090678
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()
    #
    # Test case 0:
    # google_parser_0.parse(None)
    #
    #
    # Test case 1:
    # google_parser_1.parse()
    #
    #
    # Test case 2:
    #
    # Buffer (type: str):
    # '
    # test
    #
    # '
    #
    # Expected result (type: parse_docstrings.common.google_docstring.Docstring):
    #
    # Docstring(
    #     short_description=None,
    #     long_description=None,
    #     blank_after_short_description=None,
    #     blank_after_long_description=None,
    #     meta=None,
    # )
    #
    #

# Generated at 2022-06-25 16:31:34.024028
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert 1 == 2, "Wrong implementation"



# Generated at 2022-06-25 16:31:36.163440
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()


# Generated at 2022-06-25 16:31:40.645657
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    file_path = os.path.join(os.path.dirname(__file__), "fixtures/binary_search_tree/binary_search_tree.py")
    with open(file_path) as file:
        source = file.read()
    google_parser_0.parse(source)

# Generated at 2022-06-25 16:31:52.445330
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert google_parser_0.parse(T.cast(T.Optional[T.AnyStr], None)) == Docstring()
    assert google_parser_0.parse("") == Docstring()
    google_parser_1 = GoogleParser()
    assert google_parser_1.parse("") == Docstring()
    text_1 = "One line summary.\n\nOne line summary continued.\n\nMore details.\n"
    assert google_parser_1.parse(text_1) == Docstring(
        short_description="One line summary.",
        long_description="One line summary continued.\n\nMore details.",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[],
    )

# Generated at 2022-06-25 16:32:04.868723
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    # Should start by setting up the parser.

    # Should parse the docstring into a Docstring object.
    docstring_0 = google_parser_0.parse("")
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert not (docstring_0.blank_after_short_description)
    assert not (docstring_0.blank_after_long_description)
    assert not (docstring_0.meta)

    # Should parse the docstring into a Docstring object.
    docstring_0 = google_parser_0.parse("Here a short description.")
    assert isinstance(docstring_0, Docstring)

# Generated at 2022-06-25 16:32:11.105966
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    assert google_parser_0.parse("") == Docstring()
    assert google_parser_0.parse("\n\n") == Docstring()

    assert google_parser_0.parse("Short description.\n\n") == \
        Docstring(short_description="Short description.", long_description=None, blank_after_short_description=True, blank_after_long_description=False, meta=[])
    assert google_parser_0.parse("Short description.\n\nLong description.") == \
        Docstring(short_description="Short description.", long_description="Long description.", blank_after_short_description=True, blank_after_long_description=False, meta=[])

# Generated at 2022-06-25 16:32:13.486172
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    # test case for GoogleParser
    google_parser.parse('Smoothly parabolize virally.')



# Generated at 2022-06-25 16:32:25.774780
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = """
    Args:
        text (str): The docstring.

    Returns:
        Docstring: The parsed docstring.

    Raises:
        ParseError: If a section is not parsable.
    """
    ret = google_parser_0.parse(text)
    assert (ret.short_description is None)
    assert (ret.blank_after_short_description is False)
    assert (ret.long_description is None)
    assert (ret.blank_after_long_description is False)
    assert (DocstringMeta(
        args=['returns', 'Returns'],
        description='The parsed docstring.',
        ) in ret.meta)

# Generated at 2022-06-25 16:33:10.821331
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    global google_parser_0
    print('test_GoogleParser_parse')
    google_parser_0 = GoogleParser()
    docstring_0 = Docstring()
    docstring_1 = google_parser_0.parse('# Using Google style docstrings\n\n')
    assert docstring_1 == docstring_0
    print('test_GoogleParser_parse')
    google_parser_0 = GoogleParser()
    docstring_0 = Docstring()
    docstring_1 = google_parser_0.parse('#Using Google style docstrings')
    assert docstring_1 == docstring_0
    print('test_GoogleParser_parse')
    google_parser_0 = GoogleParser()
    docstring_0 = Docstring()