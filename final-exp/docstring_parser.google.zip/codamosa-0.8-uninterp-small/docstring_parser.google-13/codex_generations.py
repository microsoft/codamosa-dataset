

# Generated at 2022-06-25 16:24:10.679469
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    #
    #  Args:
    #    a: int.
    #    b: string.
    #    c: float.
    #  Returns:
    #    int.
    #  Raises:
    #    ValueError.
    #
    docstr = '''
  Args:
    a: int.
    b: string.
    c: float.
  Returns:
    int.
  Raises:
    ValueError.
    '''
    docstring = parser.parse(docstr)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 5
   

# Generated at 2022-06-25 16:24:16.514110
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test #0
    text = '  This is a test.\n\n' + \
           '  This is only a test.\n\n' + \
           '  Testing, testing, 1 2 3.\n' + \
           '  Testing, testing, 1 2 3,\n' + \
           '  Testing, testing, 1 2 3.\n'
    GoogleParser().parse(text)

    # Test #1
    text = '  This is a test.\n\n' + \
           '  This is only a test.\n\n' + \
           '  Testing, testing, 1 2 3.\n' + \
           '  Testing, testing, 1 2 3,\n' + \
           '  Testing, testing, 1 2 3.\n'
    GoogleParser().parse(text)



# Generated at 2022-06-25 16:24:25.173848
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Instantiate class
    googleParser = GoogleParser()
    # Set argument

# Generated at 2022-06-25 16:24:38.291553
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp_0 = GoogleParser()

    DOC_0 = None
    DOC_0_exp = Docstring()

    DOC_1 = "*No sections*"
    DOC_1_exp = Docstring(
        short_description="No sections",
        blank_after_short_description=False,
        blank_after_long_description=False,
        long_description=None,
    )

    DOC_2 = "*Short description*.\n\n" "*Long description*.\n"
    DOC_2_exp = Docstring(
        short_description="Short description",
        blank_after_short_description=True,
        blank_after_long_description=False,
        long_description="Long description",
    )

    DOC_3 = "*Short description*\n\n" "*Long description*\n"
   

# Generated at 2022-06-25 16:24:47.420066
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    actual = parser.parse(" :param str foo: Bar.\n")
    expected = Docstring([DocstringParam(['param', 'str foo'], 'Bar.', 'foo',
        'str', '', None)])
    assert actual == expected


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)  # pragma: no cover

# Generated at 2022-06-25 16:24:56.195142
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse(
        """This is a short description.

This is a long description.

Args:
    arg1 (int): This is arg1. Defaults to 1.
    arg2 (str): This is arg2.
"""
    )
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description == "This is a long description."


# Generated at 2022-06-25 16:25:09.911815
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:25:18.885217
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create instance for class GoogleParser
    google_parser = GoogleParser()

    # Test case 0: test for method parse
    docstring_text = "A test string."
    docstring_dict = {
        "short_description": "A test string.",
        "blank_after_short_description": False,
        "long_description": None,
        "blank_after_long_description": False,
        "meta": [],
    }
    returned = google_parser.parse(docstring_text)

# Generated at 2022-06-25 16:25:30.338445
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-25 16:25:33.190518
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "This is the description string."
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == "This is the description string."


# Generated at 2022-06-25 16:25:51.182575
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

# Generated at 2022-06-25 16:25:58.710664
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    """
    Short Description.

    Long Description.

    Args:
        arg1 (tuple):
            Description.

        arg2 (tuple):
            Description.
    """
    '''

    result = GoogleParser().parse(docstring)
    assert len(result.meta) == 2
    assert result.meta[0].description == "Description."
    assert result.short_description == "Short Description."
    assert result.long_description == "Long Description."

# Generated at 2022-06-25 16:26:10.499331
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_cases = []
    # test_case 0
    arguments_0 = {
        "text": """\
        Compute the number of rows and columns.

        Parameters
        ----------
        a : array_like
            input array.

        Returns
        -------
        out : tuple
            number of rows and columns.

        See Also
        --------
        size
        shape
        ndim
        ndarray.shape : Equivalent array method.

        Examples
        --------
        >>> np.matrix([[1,2],[3,4]]).shape
        (2, 2)
        """
    }
    test_cases.append(
        (arguments_0, section_type_0, )
    )
    # test_case 1

# Generated at 2022-06-25 16:26:19.485405
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:26:30.491423
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    goog = GoogleParser()
    s = " Short description. Long description.\n\n :    @param x: ...\n :    @return: ...\n"
    goog.parse(s)
    s = " Short description. Long description.\n    @param x: ...\n    @return: ...\n"
    goog.parse(s)
    s = " Short description. Long description.\n    @param x: ...\n    @return: ...\n    args: ...\n"
    goog.parse(s)
    s = " Short description. Long description.\n    @param x: ...\n    @return: ...\n    args: ...\n    @param a: ...\n"
    goog.parse(s)

# Generated at 2022-06-25 16:26:42.625370
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert str(GoogleParser().parse("")) == "Docstring(short_description=None, long_description=None, meta=[])"

# Generated at 2022-06-25 16:26:55.088784
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    global docstring_0
    global docstring_1
    global docstring_2
    global docstring_3
    global docstring_4
    global docstring_5
    global docstring_6
    global docstring_7
    global docstring_8
    global docstring_9
    global docstring_10
    global docstring_expected_0
    global docstring_expected_1
    global docstring_expected_2
    global docstring_expected_3
    global docstring_expected_4
    global docstring_expected_5
    global docstring_expected_6
    global docstring_expected_7
    docstring_0 = """"""
    docstring_1 = """Full name:
    goolge.parser.GoogleParser.parse

    Short description:

    This is a long description
    """
    doc

# Generated at 2022-06-25 16:27:07.415176
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    docstring = "Short description"
    actual = parser.parse(docstring)
    assert actual.short_description == docstring

    docstring = "Short description\n\nLong description"
    actual = parser.parse(docstring)
    assert actual.short_description == "Short description"
    assert actual.long_description == "Long description"

    docstring = "Short description\n\nLong description\n\n"
    actual = parser.parse(docstring)
    assert actual.short_description == "Short description"
    assert actual.long_description == "Long description"
    assert actual.blank_after_short_description
    assert actual.blank_after_long_description

    docstring = "Short description\n\n\nLong description"
    actual = parser.parse(docstring)
   

# Generated at 2022-06-25 16:27:11.116131
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create a GoogleParser object
    google_parser_0 = GoogleParser()

    # Call method parse of google_parser_0
    google_parser_0.parse("")


test_case_0()
test_GoogleParser_parse()

# Generated at 2022-06-25 16:27:17.952189
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """\
        Short description.

        Long description.
        """
    googleParser = GoogleParser()
    docstring = googleParser.parse(text)
    # Short description tests
    assert docstring.short_description == "Short description."
    # Long description tests
    assert docstring.long_description == "Long description."
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    # Meta tests
    meta = docstring.meta
    assert meta == []



# Generated at 2022-06-25 16:27:36.964083
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test with a .py file
    def test_case_1():
        text_0 = 'Test'
        expected_0 = Docstring(
            short_description='Test',
            long_description=None,
            blank_after_short_description=False,
            blank_after_long_description=False,
            meta=[],
        )
        actual_0 = GoogleParser().parse(text_0)
        assert expected_0 == actual_0

    def test_case_2():
        text_0 = 'Test\n\n'
        expected_0 = Docstring(
            short_description='Test',
            long_description=None,
            blank_after_short_description=True,
            blank_after_long_description=False,
            meta=[],
        )

# Generated at 2022-06-25 16:27:44.480303
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Tests for method parse of class GoogleParser
    # Setup test objects
    parser = GoogleParser()

    # Test case 0
    text = """This is the short description.

This is the long description.

Args:
    arg1 (str): The first argument.
    arg2 (int): The second argument. Defaults to 0.

Returns:
    int: The return value.
"""

# Generated at 2022-06-25 16:27:54.454450
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    # Test case 0: following is the text of the docstring of function __init__ of class GoogleParser
    text_0 = '''Setup sections.

:param sections: Recognized sections or None to defaults.
:param title_colon: require colon after section title.'''
    gp.parse(text_0)
    # Test case 1
    text_1 = "Docstring description."
    gp.parse(text_1)
    # Test case 2
    text_2 = "Docstring description.\n\nArgs:\n  arg1: Description of arg1.\n  arg2: Description of arg2."
    gp.parse(text_2)
    # Test case 3: following is the text of the docstring of function _build_meta of class GoogleParser

# Generated at 2022-06-25 16:27:57.198875
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    section_type_0 = SectionType.SINGULAR_OR_MULTIPLE
    expected = Docstring()
    actual = GoogleParser().parse("a\nb")
    assert expected == actual


# Generated at 2022-06-25 16:28:06.565795
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docString = GoogleParser()
    text = 'Example\n--------\n>>> hello withing the example\n'
    parsedStr = docString.parse(text)
    #  Check for string
    assert len(parsedStr.long_description) > 0
    #  Check for blank after short description
    assert parsedStr.blank_after_short_description  == False
    #  Check for blank after long description
    assert parsedStr.blank_after_long_description  == False
    #  Check for meta
    assert len(parsedStr.meta) == 0



# Generated at 2022-06-25 16:28:18.762778
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from . import example_docstrings

    parser = GoogleParser()
    doc = parser.parse(example_docstrings.DOCSTRING_GOOGLE)

    print(doc.short_description)
    print(doc.long_description)
    print(doc.blank_after_short_description)
    print(doc.blank_after_long_description)

    for m in doc.meta:
        print(m.args[0] + " " + m.args[1] if len(m.args) > 1 else m.args[0])
        print(m.description)
        print(m.arg_name if isinstance(m, DocstringParam) else "")
        print(m.type_name if isinstance(m, DocstringParam) else "")

# Generated at 2022-06-25 16:28:32.181215
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstring = google_parser.parse(
        """Returns some things.

what it returns in one sentence.

what it returns in more detail.

Args:
    thing: a thing
    other: another thing

Returns:
    a list containing things

Yields:
    a thing
"""
    )
    assert docstring.meta[0].args == ["returns"]
    assert docstring.meta[1].args == ["param", "thing"]
    assert docstring.meta[1].arg_name == "thing"
    assert docstring.meta[2].args == ["param", "other"]
    assert docstring.meta[2].arg_name == "other"
    assert docstring.meta[2].description == "another thing"

# Generated at 2022-06-25 16:28:34.061678
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test GoogleParser.parse"""

    import pytest
    import pydocstyle.violations as violations


# Generated at 2022-06-25 16:28:48.262232
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = \
    """
    Return attributes of a module or class

    This function takes a name, loads the module and returns a list of
    attributes.  If the name points to a class, list_attributes returns
    it a dict.  If it points to a package, it returns a list of strings
    which contains all the modules in the package except __init__.

    :param name: the module name or its path
    :param package: the package name (default None)
    :returns: array of attributes
    :raises: ImportError if the module cannot be loaded
    """
    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert doc.short_description == \
            "Return attributes of a module or class"

# Generated at 2022-06-25 16:28:59.904292
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:29:09.878229
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Init
    google_parser = GoogleParser()

    # Test Cases
# ---------------------------------------------------------------------------------

    # Test Case 0:
    parse_0 = google_parser.parse("")
    # Assertions
    assert (parse_0 == Docstring(short_description=None, long_description=None, meta=[]))
# ---------------------------------------------------------------------------------

# Generated at 2022-06-25 16:29:20.930314
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Tests for method parse of class GoogleParser"""
    parser = GoogleParser()
    docstring = parser.parse(
    '''
        Args:
            param1: The first parameter.
            param2: The second parameter. Multiple
                    lines are supported.

        Keyword Args:
            kwarg1 (str): The first keyword argument
            kwarg2 (:obj:`int`, optional): The second keyword argument.
                                           Defaults to 0.

        Returns:
            True if successful, False otherwise.

        Raises:
            AttributeError, KeyError
    '''
    )

    assert isinstance(docstring, Docstring)
    assert isinstance(docstring.short_description, str)
    assert docstring.short_description == ''
    assert isinstance(docstring.long_description, str)
   

# Generated at 2022-06-25 16:29:31.240328
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    section_type_0 = SectionType.SINGULAR_OR_MULTIPLE
    section_0 = Section("Raises", "raises", section_type_0)
    sections_0 = [section_0]
    google_parser_0 = GoogleParser(sections_0)
    string_0 = "One-line summary that doesn't need to make sense by itself."
    string_1 = "First line of explanation.  Further paragraphs of explanation\ngo here."
    string_2 = "Raises:\n    RuntimeError: if things go wrong."
    string_3 = "\n".join([string_0, string_1, string_2])
    docstring_0 = google_parser_0.parse(string_3)
    assert type(docstring_0) == Docstring

# Generated at 2022-06-25 16:29:43.650088
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test case 0
    text__0 = 'Description\n\nA description of the function.\nArguments\n\nparams: A description of params.\nReturns\n\nA description of the return value.\n'
    ret__0 = GoogleParser().parse(text__0)
    assert ret__0.short_description == 'Description'
    assert ret__0.blank_after_short_description == True
    assert ret__0.blank_after_long_description == True
    assert ret__0.long_description == 'A description of the function.'
    assert len(ret__0.meta) == 3
    docstring_meta__0 = ret__0.meta[0]
    assert docstring_meta__0.args == ['param', 'params: ']

# Generated at 2022-06-25 16:29:57.385816
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """This is a Google-style docstring.

Args:
    arg1 (str): Description of arg1. Defaults to 'a'.

Returns:
    tuple(str, int): Description of return values.
"""
    docstring = parser.parse(text)
    assert docstring.short_description == "This is a Google-style docstring."
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 2
    assert docstring.meta[0].description == "Description of arg1. Defaults to 'a'."
    assert docstring.meta[0].arg_name == "arg1"
    assert docstring.meta[0].type_

# Generated at 2022-06-25 16:30:02.090927
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """GoogleParser.parse"""
    # Set up mock
    GoogleParser.parse(text)

    # Monitor calls
    # If a call to a method that you do not expect is made, an exception will be raised.
    # A test case should only make the expected calls to the mock.


# Generated at 2022-06-25 16:30:15.753743
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = """
    Args:
        arg1 (str): This is the first argument.
        arg2 (str, optional): This is a second argument.
    """
    obj_0 = GoogleParser()

    # GoogleParser.parse requires text to be of type str
    with pytest.raises(TypeError):
        obj_0.parse(1)

    # GoogleParser.parse requires text to be not None
    with pytest.raises(TypeError):
        obj_0.parse(None)

    # GoogleParser.parse returns Docstring
    # GoogleParser.parse returns Docstring.short_description as str
    assert isinstance(
        obj_0.parse(text_0).short_description, str
    )
    # GoogleParser.parse returns Docstring.short_description is None

# Generated at 2022-06-25 16:30:19.125417
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'This is a test'
    expected = "This is a test"
    gp = GoogleParser()
    actual = gp.parse(text)
    assert actual == expected


# Generated at 2022-06-25 16:30:27.261147
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    google_parser_0 = GoogleParser(sections=[
        Section(title="Some Title", key="key", type=section_type_0),
        Section(title="First Title", key="first", type=section_type_0),
        Section(title="Second Title", key="second", type=section_type_0),
        Section(title="Third Title", key="third", type=section_type_0)], title_colon=True)
    text = 'Testing\n\nSome Title:\n\nFirst Title:\n\nSecond Title:\n\nThird Title:\n\n'
    result = google_parser_0.parse(text)
    assert isinstance(result, Docstring), "Return value from parse() is not of type Docstring"

# Generated at 2022-06-25 16:30:34.015889
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Case 1 : Test w/o using GoogleParser object
    parser = GoogleParser("Google")
    text = "Google docstring."
    assert parser.parse(text) == "Google docstring."

    # Case 2 : Test using GoogleParser object
    #parser = GoogleParser("Google")
    #text = "Google docstring."
    #assert parser.parse(text) == "Google docstring."


if __name__ == "__main__":
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:48.395952
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    text = """Example function with types documented in the docstring.
    Args:
        param1 (int): The first parameter.
        param2 (str): The second parameter.
    Returns:
        bool: The return value.
    """
    result = parser.parse(text)
    assert len(result.meta) == 3
    assert result.short_description == "Example function with types documented in the docstring."
    assert result.long_description == None
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == True
    assert result.meta[0].args == ['param', 'param1 (int)']
    assert result.meta[1].args == ['param', 'param2 (str)']
    assert result.meta[2].args == ['returns']

# Generated at 2022-06-25 16:30:50.751582
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # GoogleParser.parse: Test case 0
    test_GoogleParser_parse_0()



# Generated at 2022-06-25 16:30:52.695185
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    assert parser.parse("") == Docstring()


# Generated at 2022-06-25 16:30:57.099413
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    text = """An array is monotonic if it is either monotone increasing or monotone decreasing.
    An array A is monotone increasing if for all i <= j, A[i] <= A[j].  An array A is monotone decreasing
    if for all i <= j, A[i] >= A[j].
    Return true if and only if the given array A is monotonic."""
    test_docstring = parser_0.parse(text)

# Generated at 2022-06-25 16:31:02.569531
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Input params
    test_case_0()
    test_obj = GoogleParser()
    param_0 = "test_string"
    expected_result = Docstring()

    # perform the test
    result = test_obj.parse(param_0)

    # assert the result
    assert result == expected_result

# Generated at 2022-06-25 16:31:14.954311
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_text = '''
        """Summary.

        Args:
          arg_name (str): Description of arg. Defaults to 'default value'.

        Returns:
          bool: Description of return value.

        Raises:
          AttributeError: The ``Raises`` section is a list of all exceptions
              that are relevant to the interface.
          ValueError: If `value` is not a valid value.
        """
    '''

# Generated at 2022-06-25 16:31:16.099828
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert True  # can't write a unit test for this yet

# Generated at 2022-06-25 16:31:25.916912
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_0 = GoogleParser.parse(GoogleParser(), """
        Do something with a > b.
        This is a long description of the function. It is meant to span
        multiple lines and explain the function in detail.

        Parameters:
          a: An int.
          b: An int.
    """)

    test_1 = GoogleParser.parse(GoogleParser(), """
        Do something with a > b.
        This is a long description of the function. It is meant to span
        multiple lines and explain the function in detail.

        Args:
          a: An int.
          b: An int.
    """)


# Generated at 2022-06-25 16:31:31.294457
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test 0
    g = GoogleParser()
    docstring_0 = """\
    Example function with types documented in the docstring.

    :param arg1: The first argument.
    :type arg1: int
    :param arg2: The second argument.
    :type arg2: str
    :return: The return value.
    :rtype: bool
    """
    assert g.parse(docstring_0) is not None



# Generated at 2022-06-25 16:31:41.264199
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .numpydoc import NumpyDocstring
    from .common import DocstringParam

    s = """Single line docstring
    with some indentation.
    """
    parsed = GoogleParser().parse(s)
    # Check short description
    assert parsed.short_description == "Single line docstring"
    # Check long description
    assert parsed.long_description == "with some indentation."
    # Check if parsed docstring has no DocstringParam
    assert parsed.get_parameters() == []

    s = """Single line docstring
    with some indentation.

    Parameter a: blah blah blah
    Parameter b: blah blah blah
    """
    parsed = GoogleParser().parse(s)
    # Check short description
    assert parsed.short_description == "Single line docstring"
    # Check long description
    assert parsed.long

# Generated at 2022-06-25 16:31:52.090387
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    doc = """
    Short description.

    Long description.
    """
    p = parse(doc)
    assert p.short_description == "Short description."
    assert p.long_description == "Long description."
    assert p.blank_after_short_description is True
    assert p.blank_after_long_description is False



# Generated at 2022-06-25 16:32:04.864340
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = """Docstring header.

Long description.

Args:
    name (str): Argument description.
    age (int): Another argument,

Returns:
    dict: Return value description.

Raises:
    ValueError: If `name` is invalid.
"""
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse(text_0)
# AssertionError: 'Docstring header.\n\nLong description.\n\n' != 'Docstring header.\n\nLong description.\n'
    assert docstring_0.short_description == 'Docstring header.\n\nLong description.\n'
    assert docstring_0.blank_after_short_description == True
# AssertionError: None != False
    assert docstring_0

# Generated at 2022-06-25 16:32:08.923857
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()

    try:
        google_parser_0.parse(None)
    except TypeError:
        pass
    else:
        raise AssertionError

if __name__ == "__main__":
    import sys

    if len(sys.argv) >= 2 and sys.argv[1] == "-ut":
        import ut

        ut.main()

# Generated at 2022-06-25 16:32:16.593638
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    class_test_case = Docstring()
    class_test_case.short_description = "Test class for GoogleParser."
    func_test_case = Docstring()
    func_test_case.short_description = "Test function for GoogleParser."
    func_param_desc = "A parameter for the test function."
    func_param_type = "str"
    doc_test_case = Docstring()
    doc_test_case.short_description = "Test the document for GoogleParser."
    doc_returns_desc = "a document for GoogleParser."
    doc_returns_type = "Docstring"
    doc_param_desc = "a parameter for a method with *arg."
    doc_exception_desc = "an exception for a method with **kwargs."

# Generated at 2022-06-25 16:32:27.579633
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    ret = GoogleParser().parse("")
    assert ret.short_description is None
    assert ret.long_description is None
    assert not ret.blank_after_short_description
    assert not ret.blank_after_long_description
    assert not ret.meta
    assert ret == ret
    ret = GoogleParser().parse("Hello")
    assert ret.short_description == "Hello"
    assert ret.long_description is None
    assert not ret.blank_after_short_description
    assert not ret.blank_after_long_description
    assert not ret.meta
    assert ret == ret
    ret = GoogleParser().parse("Hello\nWorld")
    assert ret.short_description == "Hello"
    assert ret.long_description == "World"
    assert not ret.blank_after_short_description
    assert not ret.blank_

# Generated at 2022-06-25 16:32:35.692047
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Arrange
    google_parser_1 = GoogleParser()
    google_parser_1.add_section(Section("Warns", "warns", SectionType.MULTIPLE))
    google_parser_1.add_section(Section("Note", "note", SectionType.SINGULAR))


# Generated at 2022-06-25 16:32:41.125898
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    doc_0 = GoogleParser.parse(google_parser_0, "")
    assert doc_0 == Docstring(
        short_description=None,
        blank_after_short_description=False,
        long_description=None,
        blank_after_long_description=False,
        meta=[],
    )

test_function_list = [
    test_case_0,
    test_GoogleParser_parse,
]

# Generated at 2022-06-25 16:32:54.062828
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """
    This is a function.

    Arguments:
        arg1 (str): A required positional argument.

        arg2 (str, optional): An argument with a default value.
            Defaults to None.

        *args: Variable length argument list.

        **kwargs: Arbitrary keyword arguments.

    Returns:
        int: The return value.
    """

    d = GoogleParser().parse(text)

    assert d is not None
    assert d.short_description == "This is a function."
    assert d.long_description is None
    assert d.blank_after_short_description is True
    assert d.blank_after_long_description is False
    assert d.meta is not None
    assert len(d.meta) == 9

# Generated at 2022-06-25 16:32:57.685775
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = """This is a short description.

    This is a long description.
    """
    result = google_parser_0.parse(text)
    assert result.short_description == "This is a short description."
    assert result.long_description == "This is a long description."

