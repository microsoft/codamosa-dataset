

# Generated at 2022-06-25 16:23:36.086717
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_1 = 'This is short\n\nThis is long'
    docstring_1 = parse(str_1)
    assert isinstance(docstring_1.short_description, str)
    assert docstring_1.short_description == 'This is short'
    assert docstring_1.blank_after_short_description == True
    assert isinstance(docstring_1.long_description, str)
    assert docstring_1.long_description == 'This is long'
    assert docstring_1.blank_after_long_description == True

    str_2 = 'This is short\nThis is long'
    docstring_2 = parse(str_2)
    assert isinstance(docstring_2.short_description, str)
    assert docstring_2.short_description == 'This is short'
    assert doc

# Generated at 2022-06-25 16:23:43.179729
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # test case 0
    str_0 = 'Return'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Return"
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta[0].args == ['returns']
    assert docstring_0.meta[0].description is None

    # test case 1
    str_1 = 'Return::'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring

# Generated at 2022-06-25 16:23:52.447291
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'Return'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_long_description == None
    assert docstring_0.meta == [DocstringReturns(args=['return'], description=None, type_name=None, is_generator=False)]

    str_1 = 'Returns'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == None
    assert docstring_1.blank_after_short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_long_description

# Generated at 2022-06-25 16:24:03.780343
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'Return'
    str_1 = '''This is a test.
    This is another line.'''
    str_2 = 'Return: This is a test.'
    str_3 = '''Returns: This is a test.
        This is another line.'''
    str_4 = '''Return:
            This is a test.
            This is another line.'''
    str_5 = '''Return:         This is a test.
            This is another line.'''
    str_6 = '''Return
            This is a test.
            This is another line.'''
    str_7 = '''Returns
            int. This is a test.
            This is another line.'''
    str_8 = '''Returns
            int. This is a test.'''

# Generated at 2022-06-25 16:24:13.536719
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Global setup

    # Body of unit test for method parse of class GoogleParser
    str_0 = """Google-style docstrings.

Args:
    param1(str): The first parameter.
    param2(str): The second parameter.
    *args: Variable length argument list.
    **kwargs: Arbitrary keyword arguments.

Returns:
    bool: The return value. True for success, False otherwise.
    """
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == "Google-style docstrings."

# Generated at 2022-06-25 16:24:24.989339
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'Return'
    _0 = GoogleParser()
    _1 = _0.parse(str_0)
    assert _1.short_description is None
    assert _1.long_description is None
    assert len(_1.meta) == 0
    assert _1.blank_after_short_description is False
    assert _1.blank_after_long_description is False
    assert _1.blank_after_title is False
    str_2 = 'Return\n'
    _0 = GoogleParser()
    _2 = _0.parse(str_2)
    assert _2.short_description == 'Return'
    assert _2.long_description is None
    assert len(_2.meta) == 0
    assert _2.blank_after_short_description is True
    assert _2.blank_after_

# Generated at 2022-06-25 16:24:38.133246
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    str_0 = 'Return'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == [DocstringMeta(args=['returns', 'Return'], description=None)]

    # Test case 1
    str_1 = 'Return to the thing'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Return to the thing'
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert doc

# Generated at 2022-06-25 16:24:39.118397
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()

# Generated at 2022-06-25 16:24:47.801185
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'Return'
    docstring_0 = parse(str_0)
    assert isinstance(docstring_0, Docstring)
    assert docstring_0.short_description == 'Return'
    assert docstring_0.long_description is None
    assert isinstance(docstring_0.meta, list)
    assert docstring_0.meta == []
    str_1 = 'These data type names are defined\nfor the standard operators.'
    docstring_1 = parse(str_1)
    assert isinstance(docstring_1, Docstring)
    assert docstring_1.short_description == 'These data type names are defined'
    assert docstring_1.long_description == 'for the standard operators.'
    assert isinstance(docstring_1.meta, list)

# Generated at 2022-06-25 16:25:00.497910
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case 0
    str_0 = 'Return'
    docstring_0 = parse(str_0)
    expected = Docstring(short_description=None, long_description=None, meta=[DocstringMeta(args=['return'], description=None)])
    assert docstring_0 == expected
    # Test case 1
    str_1 = 'Return a value of a'
    docstring_1 = parse(str_1)
    expected = Docstring(short_description=None, long_description=None, meta=[DocstringMeta(args=['return'], description='a')])
    assert docstring_1 == expected
    # Test case 2
    str_2 = 'Return a value of a. Defaults to b.'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:25:14.207405
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass

# Generated at 2022-06-25 16:25:26.467993
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse("""\
        A short description of the class.

        A longer description of the class.

        Args:
          first_arg: the first argument.
          second_arg: the second argument.

        Returns:
          Some return value.

        Raises:
          AnException: An exception that can occur.
          AnotherException: Another exception that can occur.

        """
    ) == parse("""\
        A short description of the class.

        A longer description of the class.

        Args:
          first_arg: the first argument.
          second_arg: the second argument.

        Returns:
          Some return value.

        Raises:
          AnException: An exception that can occur.
          AnotherException: Another exception that can occur.

        """
    )


# Generated at 2022-06-25 16:25:36.806562
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = '''
    This function does something useful.

    This function is perhaps not useful.

    Args:
        a : first param
        b : second param
        c (int, optional) : third param Defaults to 5.
    Returns:
        int: added return value
    Raises:
        ValueError: if wrong value is passed in.
    '''
    parser = GoogleParser()
    doc = parser.parse(docstring)
    assert doc.short_description == 'This function does something useful.'
    assert doc.long_description == 'This function is perhaps not useful.'
    assert len(doc.meta) == 4
    assert doc.meta[0].args[0] == 'param'
    assert doc.meta[0].arg_name == 'a'
    assert doc.meta[0].description == 'first param'


# Generated at 2022-06-25 16:25:48.955872
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    doc = "Guess the current system locale.\n\n    Parameters\n    ----------\n    category: str, optional\n        Return the locale for this category, defaults to LC_ALL\n    *args, **kwargs: Any, optional\n        Additional parameters.\n    \n    Raises\n    ------\n    Exception\n        No appropriate locale could be found.\n\n    Returns\n    -------\n    system_locale: str\n        The name of the system locale.\n    "
    ret = parser.parse(doc)
    assert type(ret) == Docstring
    assert ret.short_description == "Guess the current system locale."

# Generated at 2022-06-25 16:25:58.661841
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    txt = """Simple example type.

    :param int arg1: The first parameter.
    :param int arg2: The second parameter.

    :return: Return value.
    :rtype: str
    """

    ret = GoogleParser().parse(txt)
    assert len(ret.meta) == 3
    assert isinstance(ret.meta[0], DocstringParam)
    assert isinstance(ret.meta[1], DocstringParam)
    assert isinstance(ret.meta[2], DocstringReturns)

# Generated at 2022-06-25 16:26:06.795635
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """parses Google-style docstrings.

    Example:
        >>> a = 42
        >>> a
        42
    """

    result = parse(text)

    assert result.short_description == "parses Google-style docstrings."
    assert result.blank_after_short_description == True
    assert result.blank_after_long_description == False
    assert result.long_description == "Example:\n    >>> a = 42\n    >>> a\n    42"
    assert len(result.meta) == 0


# Generated at 2022-06-25 16:26:08.155493
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    pass


# Generated at 2022-06-25 16:26:15.303036
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test for method parse of class GoogleParser. """Parse the Google-style docstring into its components. """

    # Check whether parse is callable
    parser = GoogleParser()
    assert callable(parser.parse)

    # Test case 0
    expected_docstring = Docstring(
        short_description='', long_description='', meta=[]
    )
    actual_docstring = GoogleParser().parse('')
    assert actual_docstring == expected_docstring


parser = GoogleParser()



# Generated at 2022-06-25 16:26:23.094927
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = """Builds a query string.
  The query string uses Google-style arguments as specified
  (https://github.com/google/protobuf/blob/master/src/google/protobuf/descriptor.proto#L485).

  Args:
    text: Query string value.

  Returns:
    A query string.
"""
    GoogleParser().parse(text)



# Generated at 2022-06-25 16:26:33.007241
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    from .common import DocstringParam

    text = """
    Test string
    Parameters
    ----------
    arg_0 : TestType
        Description
    arg_1 : TestType, optional
        Description. Defaults to None.
    arg_2 : TestType?
        Description. Defaults to 1.
    """
    ret = GoogleParser().parse(text)

    # Check only the first argument
    assert(ret.meta[0].args == ['param', 'arg_0'])
    assert(ret.meta[0].description == 'Description')
    assert(ret.meta[0].__class__ == DocstringParam)
    assert(ret.meta[0].arg_name == 'arg_0')
    assert(ret.meta[0].type_name == 'TestType')

# Generated at 2022-06-25 16:26:42.152800
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    google_parser_0 = GoogleParser()
    text = "Hello world!"

    # Invoke method
    result = google_parser_0.parse(text)

    assert result.short_description == "Hello world!"
    assert result.long_description == None
    assert result.blank_after_short_description == False
    assert result.blank_after_long_description == False
    assert result.meta == []

# Generated at 2022-06-25 16:26:52.531997
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    global google_parser_0
    assert google_parser_0.parse("Test parser.") == {"short_description": "Test parser.", "long_description": None, "blank_after_short_description": None, "blank_after_long_description": None, "meta": []}


google_parser_1 = GoogleParser([Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE), Section("Params", "param", SectionType.MULTIPLE)])


# Generated at 2022-06-25 16:27:06.929870
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:27:15.517644
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring = "summary\n\nThis is a simple docstring with no sections."
    docstring_0 = GoogleParser()
    result = docstring_0.parse(docstring)

    docstring_1 = Docstring()
    docstring_1.short_description = "summary"
    docstring_1.long_description = "This is a simple docstring with no sections."
    docstring_1.blank_after_short_description = True
    docstring_1.blank_after_long_description = False
    docstring_1.meta = []
    assert result == docstring_1


# Generated at 2022-06-25 16:27:22.648016
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Expecting Raises(
    #     args=['raises', 'TypeError'], description='If x is not a number.', type_name='TypeError'
    # ), Returns(
    #     args=['returns', 'int'], description='The square of x.', type_name='int'
    # )
    google_parser_1 = GoogleParser()

# Generated at 2022-06-25 16:27:28.130474
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0_parse_0 = google_parser_0.parse("This is a test")
    google_parser_0_parse_0_pop_0 = google_parser_0_parse_0.pop()
    _validate_Docstring(google_parser_0_parse_0_pop_0)


# Generated at 2022-06-25 16:27:35.413450
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    
    # Initialization
    google_parser_0 = GoogleParser()
    str_0 = 'Google-style docstring parsing.'
    str_1 = 'Google-style docstring parsing.'
    
    # Invoke method
    result = google_parser_0.parse(str_0)
    
    # Check the output
    assert str(result) == str_1


# Generated at 2022-06-25 16:27:45.340425
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser = GoogleParser()

    docstring = google_parser.parse('Hello there.')
    assert docstring.short_description == "Hello there."

    docstring = google_parser.parse('Hello there.\n')
    assert docstring.short_description == "Hello there."

    docstring = google_parser.parse('''Hello there.\n\nAnd you!''')
    assert docstring.short_description == "Hello there."
    assert docstring.blank_after_short_description
    assert docstring.long_description == "And you!"
    assert docstring.blank_after_long_description

    docstring = google_parser.parse('''Hello there.\nAnd you!''')
    assert docstring.short_description == "Hello there."
    assert not docstring.blank_after_short_description


# Generated at 2022-06-25 16:27:54.946220
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    google_parser_0 = GoogleParser()
    text_0 = '''
    short

    long

    Args:
        arg1 (bool): arg1 description.
        arg2 (str, optional): arg2 description. Defaults to "hello".
    '''

# Generated at 2022-06-25 16:28:07.101863
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:28:36.554949
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = """
        Move the paddle.

        The paddle moves to the left or right, depending on the command given.

        Args:
            command (str): The command to execute.

        """
    expected_meta = [
        DocstringMeta(
            args=["Args",'command (str): The command to execute.'],
            description='The command to execute.',
        )
    ]

    expected_ret = Docstring(
        short_description='Move the paddle.',
        long_description='The paddle moves to the left or right, depending on the command given.',
        blank_after_long_description=False,
        blank_after_short_description=True,
        meta=expected_meta,
    )

    actual_ret = google_parser_0.parse(text)
   

# Generated at 2022-06-25 16:28:46.702577
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    s = """
    Fetches numerical indices that correspond to units of text.
    The result is a list of numbers, where the
    i-th number corresponds to the i-th `Span` of the `Document`.
    """
    r = google_parser_0.parse(s)
    assert r
    assert r.short_description == "Fetches numerical indices that correspond to units of text."
    assert r.long_description == "The result is a list of numbers, where the\n" + \
                                 "i-th number corresponds to the i-th `Span` of the `Document`."



# Generated at 2022-06-25 16:28:52.617593
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    expected = Docstring()
    expected.short_description = "This is the short description."
    expected.long_description = """\
This is the long description.  It spans
multiple lines."""
    expected.blank_after_short_description = True
    expected.blank_after_long_description = False

# Generated at 2022-06-25 16:29:02.414829
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # inp: -
    # out: Docstring(short_description='', blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    docstring_0 = GoogleParser().parse('')
    # inp: short
    # out: Docstring(short_description='short', blank_after_short_description=False, long_description=None, blank_after_long_description=False, meta=[])
    docstring_1 = GoogleParser().parse('short')
    # inp: short long
    # out: Docstring(short_description='short', blank_after_short_description=True, long_description='long', blank_after_long_description=False, meta=[])
    docstring_2 = GoogleParser().parse('short\nlong')
    # inp

# Generated at 2022-06-25 16:29:14.787048
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
# Note that some of the assertions below use near equality comparison.
# An alternative to this is to use the math.isclose function as follows:
#   numpy.isclose(actual, desired, rtol=1e-07, atol=0, equal_nan=False)
    def test_GoogleParser_parse_0():
        text = """\
Test docstring.
"""
        ret_val_0 = google_parser_0.parse(text)
        assert ret_val_0.short_description == "Test docstring."
    def test_GoogleParser_parse_1():
        text = """\
Test docstring.

Test long description.
"""
        ret_val_1 = google_parser_0.parse(text)

# Generated at 2022-06-25 16:29:24.116295
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    # Test cases
    text_0 = ""
    text_1 = "Class: Google class."
    text_2 = "Google class."
    text_3 = "Class: Google class.\n\n"
    text_4 = "Class: Google class.\n\nLong description.\n\n"
    text_5 = "Arguments: \n    a: This is A.\n    b: This is B. Defaults to 2.\n\nReturns:\n    This is long description.\n\n"
    text_6 = "Args:\n    a: This is A.\n    b: This is B. Defaults to 2.\n\nReturns:\n    This is long description.\n\n"

# Generated at 2022-06-25 16:29:32.166429
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.title_colon = False
    text = "Short summary.\n\nLong summary.\n\nArgs:\n  name: Name to use.\n"
    docstring_0 = google_parser_0.parse(text)
    google_parser_0.title_colon = True
    text = "Short summary.\n\nLong summary.\n\nArgs:\n  name: Name to use.\n"
    docstring_1 = google_parser_0.parse(text)
    assert docstring_1 == docstring_0


# Generated at 2022-06-25 16:29:44.422808
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()

    text_0 = 'Do a barrel roll.'

    docstring_0 = google_parser_0.parse(text_0)

    assert isinstance(docstring_0, Docstring)

    assert docstring_0.short_description == 'Do a barrel roll.'

    assert docstring_0.long_description is None

    assert len(docstring_0.meta) == 0

    google_parser_1 = GoogleParser(title_colon=True)

    text_1 = 'Description:\n\n\tDo a barrel roll.'

    docstring_1 = google_parser_1.parse(text_1)

    assert isinstance(docstring_1, Docstring)

    assert docstring_1.short_description is None


# Generated at 2022-06-25 16:29:57.915010
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Test case 0
    input_0 = """\
This docstring is meant to be an example.

This docstring is meant to be an example.

This docstring is meant to be an example.

This docstring is meant to be an example.

:param: arg1
    arg1 description
:param arg2:
    arg2 description
:param arg3 (int, optional):
    arg3 description
:param arg4 (int):
    arg4 description
:param arg5 (int, optional):
    arg5 description
:returns:
    description of return value
:returns:
    description of return value
:rtype:
    float
:rtype:
    float
:returns arg6:
    description of return value
:returns arg7 (int, optional):
    description of return value
"""

    expected

# Generated at 2022-06-25 16:30:01.031087
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text_0 = "This is a docstring."
    result = google_parser_0.parse(text_0)


# Generated at 2022-06-25 16:30:26.287210
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()

    # Test case 1
    text_1 = "This is a short description.\n\nThis is a long description.\n\nArgs:\n  a: The a is a number. Defaults to 5.\n  b: The b is a number. Defaults to 5."
    docstring_1 = google_parser_1.parse(text_1)
    assert docstring_1.short_description == "This is a short description."
    assert docstring_1.long_description == "This is a long description."
    assert len(docstring_1.meta) == 2
    assert docstring_1.meta[0].type == "param"
    assert docstring_1.meta[0].arg_name == "a"

# Generated at 2022-06-25 16:30:35.776127
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test docstring_0
    docstring_0 = "This is the short description.\n\nThis is the\nlong description.\n\nArgs:\n  arg1 (int): The first argument.\n  arg2 (str, optional): The second argument (default: 'default').\n\nReturns:\n  Some return value."
    parsed_0 = parse(docstring_0)
    assert parsed_0.short_description == "This is the short description."
    assert parsed_0.blank_after_short_description
    assert parsed_0.long_description == "This is the\nlong description."
    assert parsed_0.blank_after_long_description
    assert parsed_0.meta[0].args == ['param']
    assert parsed_0.meta[0].arg_name == 'arg1'
    assert parsed

# Generated at 2022-06-25 16:30:39.981490
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '"""Google-style docstring parsing."""'
    google_parser = GoogleParser()
    result = google_parser.parse(text)
    assert result.short_description == 'Google-style docstring parsing.'
    assert result.long_description == None
    assert result.meta == []


# Generated at 2022-06-25 16:30:42.136020
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    google_parser_0.parse(str_arg_0)


# Generated at 2022-06-25 16:30:43.823285
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()


# Generated at 2022-06-25 16:30:57.024016
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_1 = GoogleParser()


# Generated at 2022-06-25 16:31:02.123392
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    text = '"""\n    :param a: int\n    """\n    pass\n    '
    result = google_parser_0.parse(text)
    assert len(result.meta) == 1


# Generated at 2022-06-25 16:31:14.522471
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Instantiating a new object
    google_parser_0 = GoogleParser()

    # Calling instance method 'parse' with arguments
    #
    #   >>> def sample(text):
    # ...     text = inspect.cleandoc(text)
    # ...     return text
    # ...
    # >>> sample('''
    # ... test
    # ...
    # ...   Args:
    # ...     a (int): Description of a.
    # ...     b: Description of b.
    # ...
    # ...   Returns:
    # ...     tuple(str, list[str]): Description of return value.
    # ...
    # ... ''')
    # 'test\n\n  Args:\n    a (int): Description of a.\n    b: Description of b.\n\n  Returns:\n

# Generated at 2022-06-25 16:31:24.558760
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test if method parse of class GoogleParser works as expected"""
    google_parser_0 = GoogleParser()
    google_parser_1 = GoogleParser()
    google_parser_2 = GoogleParser()
    google_parser_3 = GoogleParser()
    google_parser_4 = GoogleParser()
    google_parser_5 = GoogleParser()
    google_parser_6 = GoogleParser()
    google_parser_7 = GoogleParser()
    google_parser_8 = GoogleParser()

    # Test case for valid docstring

# Generated at 2022-06-25 16:31:28.991338
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    google_parser_0 = GoogleParser()
    text_0 = 'Test docstring short description.'
    # Exercise
    docstring_0 = google_parser_0.parse(text_0)
    # Verify
    assert docstring_0.short_description == 'Test docstring short description.'


# Generated at 2022-06-25 16:31:56.681602
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse(" ")
    if not isinstance(docstring_0, Docstring):
        raise TypeError("test case 0 failed")
    docstring_0 = google_parser_0.parse("None")
    if not isinstance(docstring_0, Docstring):
        raise TypeError("test case 1 failed")

    # disable title colon
    google_parser_1 = GoogleParser(title_colon=False)
    docstring_0 = google_parser_1.parse("Parameters:")
    if not isinstance(docstring_0, Docstring):
        raise TypeError("test case 2 failed")
    docstring_0 = google_parser_1.parse("Parameters\n----------")

# Generated at 2022-06-25 16:32:03.750481
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse("")

if __name__ in ("__main__", "reST"):
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse("")
    docstring_1 = GoogleParser().parse("")
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:32:13.570564
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test case for method parse of class GoogleParser."""
    google_parser_0 = GoogleParser()
    docstring_0 = google_parser_0.parse("")
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert len(docstring_0.meta) == 0
    docstring_1 = google_parser_0.parse("")
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False

# Generated at 2022-06-25 16:32:24.414520
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """
    Tests for parse of GoogleParser
    """
    google_parser = GoogleParser()
    # Case 0
    result_0 = google_parser.parse(
        text='Short description.\n\nLong description.'
    )
    assert (
        result_0.short_description == 'Short description.'
    ), 'Short description.'
    assert (
        result_0.long_description == 'Long description.'
    ), 'Long description.'
    assert result_0.blank_after_short_description, 'Blank after short description.'
    assert result_0.blank_after_long_description, 'Blank after long description.'


# Generated at 2022-06-25 16:32:34.684925
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    # AssertionError: Expected paramenter name.
    try:
        assert google_parser_0.parse("") == Docstring()
    except AssertionError:
        raise AssertionError(
            "Expected {} to be {}".format(
                repr(google_parser_0.parse("")), repr(Docstring())
            )
        )
    # AssertionError: Expected paramenter name.

# Generated at 2022-06-25 16:32:42.910098
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:32:48.706196
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = '''\
    Calculate the square root of a number.

    Alias for the `m.sqrt` function.

    Args:
        x: The number for which to calculate the square root.
        y: The number for which to calculate the square root.

    Returns:
        float: The square root of `x`.

    Raises:
        ValueError: if `x` is negative.
    '''

# Generated at 2022-06-25 16:32:54.150852
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:33:06.296966
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Assign
    google_parser = GoogleParser()
    text = """\
    Summary line.

    Extended description.

    Parameters:
        arg1(str): Description of `arg1`.
        arg2(str): Description of `arg2`.

    Returns:
        str: Description of `return`.
    """