

# Generated at 2022-06-25 16:23:38.310629
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Partition:
    # Text is empty
        text = "" 
        gp = GoogleParser()
        gp.parse(text)
    # Text is not empty
        text = "a"
        gp = GoogleParser()
        gp.parse(text)


# Generated at 2022-06-25 16:23:48.817693
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:23:59.437495
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert(True)


if __name__ == "__main__":
    import sys
    import os
    import pyperclip

    if len(sys.argv) > 1:
        path = sys.argv[1]
    else:
        path = pyperclip.paste()
        if not os.path.exists(path):
            path = inspect.getfile(inspect.stack()[1][0])

    if os.path.exists(path):
        with open(path, "r") as f:
            text = f.read()
    else:
        text = path

    ds = parse(text)
    print(ds)

# Generated at 2022-06-25 16:24:09.360434
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print()
    print("Method parse() of class GoogleParser")
    print("====================================")
    print("Parse a string with format according to Google-style docstring into its components.")
    print("The string is given as argument to the method.")

    print("\nCreate a parser object")
    parser = GoogleParser()

    print("\nParse a string that has a valid format and includes the following sections:")
    print("- Parameters:")
    print("  - arg1: An argument with integer type, default value 10")
    print("  - arg2: An argument with string type, with a default value \"dog\"")
    print("  - arg3: An argument with boolean type, with a default value True")
    print("- Returns: a text with format according to Google-style docstring")

# Generated at 2022-06-25 16:24:15.567880
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Use the example docstring from Google
    text = """
        Short summary.

        Longer summary.

        Args:
            param1: Description of `param1`.
            param2: Description of `param2`.
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword argument list.

        Raises:
            AttributeError: The ``Raises`` section is a list of all exceptions
                that are relevant to the interface.
            ValueError: If `param2` is equal to `param1`.

        Returns:
            True if successful, False otherwise.
        """

    parser = GoogleParser()
    docstring = parser.parse(text)

    assert docstring.short_description == "Short summary."
    assert docstring.long_description == "Longer summary."
    assert docstring.blank_after_short_description

# Generated at 2022-06-25 16:24:25.854967
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:24:39.119740
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "hello\nworld\n"
    assert GoogleParser().parse(text) == parse(text)
    text = "hello world\n"
    assert GoogleParser().parse(text) == parse(text)
    text = "hello world\n\nthis is a long description"
    assert GoogleParser().parse(text) == parse(text)
    text = "hello world\n\nthis is a long description\n\n"
    assert GoogleParser().parse(text) == parse(text)
    text = "hello world\n\nthis is a long description\n\n\n"
    assert GoogleParser().parse(text) == parse(text)
    text = "hello world\n\nthis is a long description\nwhich should be indented"
    assert GoogleParser().parse(text) == parse(text)
    text

# Generated at 2022-06-25 16:24:45.509057
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    sections_0 = DEFAULT_SECTIONS
    parser_0 = GoogleParser(sections_0)
    text_0 = "This is a test docstring.\n\nThis is the long description.\n\nArgs:\n    arg1: the first argument\n    arg2: the second argument. Defaults to None.\n\nReturns:\n    int: the return value"
    result_0 = parser_0.parse(text_0)
    assert (
        result_0.short_description == "This is a test docstring."
    ), "Expected {}, got {}".format("This is a test docstring.", result_0.short_description)

# Generated at 2022-06-25 16:24:47.852136
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    import doctest
    failures, tests = doctest.testmod(verbose=True)
    assert failures == 0



# Generated at 2022-06-25 16:25:00.535976
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "This is a docstring. \n\nWith multiline description.\n" + (
        "Args:\n    parameter (int): Description.\n"
    ) + "        Defaults to 42.\n\n" + (
        "Returns:\n    tuple: Description.\n"
    ) + "        Defaults to (42,).\n\n" + (
        "Raises:\n    KeyError: Description.\n"
    ) + "        Defaults.\n\n" + "Example:\n" + "    Use like this.\n\n" + (
        "Yields:\n    int: Description.\n"
    ) + "        Defaults to 42.\n"

# Generated at 2022-06-25 16:25:17.748644
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    docstring = parser.parse("This is a short description.")
    assert docstring.short_description == "This is a short description."
    assert docstring.long_description is None
    assert docstring.meta == []

    docstring = parser.parse("This is a short description.\n"
                             "\n"
                             "This is a long description")
    assert docstring.short_description == "This is a short description."
    assert docstring.blank_after_short_description is True
    assert docstring.blank_after_long_description is True
    assert docstring.long_description == "This is a long description"
    assert docstring.meta == []


# Generated at 2022-06-25 16:25:29.734496
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:25:38.927688
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert_equal(
        GoogleParser().parse(
            """
        Short.

        Long.

        Raises:
          ValueError if something bad happens.

        Yields:
          str: a value.
        """
        ),
        Docstring(
            short_description="Short.",
            blank_after_short_description=False,
            long_description="Long.",
            blank_after_long_description=False,
            meta=[
                DocstringRaises(
                    args=["Raises", "ValueError"],
                    description="if something bad happens.",
                    type_name="ValueError",
                ),
                DocstringReturns(
                    args=["Yields", "str"],
                    description="a value.",
                    type_name="str",
                    is_generator=True,
                ),
            ],
        ),
    )

# Generated at 2022-06-25 16:25:42.912699
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)

if __name__ == "__main__":
    test_case_0()
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:25:44.509651
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)

# Generated at 2022-06-25 16:25:46.487258
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'y'

# Generated at 2022-06-25 16:25:48.727726
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # First test case
    str_0 = 'y'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:26:02.749057
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = parse('Test method parse of class GoogleParser')
    docstring_1 = parse('Test method parse of class GoogleParser\nReturns\n    x')
    docstring_2 = parse('''
    Test method parse of class GoogleParser
    Returns
        x''')
    docstring_3 = parse('''
    Test method parse of class GoogleParser
    Returns
        x : int
            return value''')
    docstring_4 = parse('''
    Test method parse of class GoogleParser
    Returns
        x : float
            return value''')
    docstring_5 = parse('''
    Test method parse of class GoogleParser
    Returns
        x : float
            return value
        y''')

# Generated at 2022-06-25 16:26:14.477488
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_0 = 'y'
    docstring_0 = google_parser_0.parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False

    # Additional tests
    str_0 = """args:
    args"""
    docstring_0 = google_parser_0.parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False

# Unit

# Generated at 2022-06-25 16:26:17.028120
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)
    return


if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:26:38.544378
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = parse
    docstring_0 = GoogleParser.parse(parser, str_0)
    assert docstring_0.long_description is None
    assert docstring_0.short_description == 'y'
    assert len(docstring_0.meta) == 0


# Generated at 2022-06-25 16:26:40.437219
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = parse('y')
    docstring_1 = parse('y')
    docstring_2 = parse('y')

# Generated at 2022-06-25 16:26:50.154746
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 16:26:55.818924
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = "Short\n\nLong"

    docstring_0 = parse(text_0)
    assert docstring_0.short_description == "Short"
    assert docstring_0.long_description == "Long"
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is True



# Generated at 2022-06-25 16:26:57.409340
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()

if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:27:04.390647
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)
    print(docstring_0.short_description)
    print(docstring_0.is_empty)
    assert docstring_0.short_description == 'y'
    assert docstring_0.is_empty == False

    str_1 = '    y'
    docstring_1 = parse(str_1)
    print(docstring_1.short_description)
    print(docstring_1.is_empty)
    assert docstring_1.short_description == 'y'
    assert docstring_1.is_empty == False

    str_2 = 'y\n'
    docstring_2 = parse(str_2)
    print(docstring_2.short_description)

# Generated at 2022-06-25 16:27:11.834272
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Begin test_GoogleParser_parse")
    str_0 = """Draw and show a myokit.DataLog

:param datalog: The datalog to draw
:param show: Set to ``False`` to prevent showing plots
:param clear_figures: Set to ``True`` to clear existing figures
:param figure: Figure to use (will be created if ``None``)
:param axes: Axes to use (will be created if ``None``)
"""
    docstring_0 = GoogleParser().parse(str_0)
    assert docstring_0.short_description == "Draw and show a myokit.DataLog", "Return value of method parse is not correct"

# Generated at 2022-06-25 16:27:12.774766
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:27:21.178615
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'string'
    docstring_0 = parse(str_0)
    str_1 = 'string\n  string'
    docstring_1 = parse(str_1)
    str_2 = 'string\nstring'
    docstring_2 = parse(str_2)
    str_3 = 'string\nstring\n'
    docstring_3 = parse(str_3)
    str_4 = 'string\nstring\nstring\n'
    docstring_4 = parse(str_4)
    str_5 = 'string\n\nstring\nstring\n'
    docstring_5 = parse(str_5)
    str_6 = 'string\n\nstring\nstring\n\nstring\n'
    docstring_6 = parse(str_6)


# Generated at 2022-06-25 16:27:33.888796
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = '''
    Given a roman numeral, convert it to an
    integer. Input is guaranteed to be withi
    the rnage from 1 to 3999.
    '''
    docstring_0 = parse(str_0)
    str_1 = '''
    Params:
    s: [str]
    roman string
    '''
    docstring_1 = parse(str_1)


if __name__ == "__main__":
    str_0 = '''
    Given a roman numeral, convert it to an
    integer. Input is guaranteed to be withi
    the rnage from 1 to 3999.
    '''
    str_1 = '''
    Params:
    s: [str]
    roman string
    '''

# Generated at 2022-06-25 16:28:09.445995
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.long_description is None
    assert docstring_0.meta == [DocstringMeta('y', None)]
    print('Test passed!')


# Generated at 2022-06-25 16:28:10.401919
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    try:
        test_case_0()
    except Exception as e:
        print('Error when calling method parse of class GoogleParser')
        raise e

# Generated at 2022-06-25 16:28:19.537939
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    method_name = 'parse'
    # Failure case
    args_0 = ['', '', '', '', '', '', '']
    try:
        assert parser.parse(*args_0)
    except ParseError:
        # test case passed
        pass
    # Test Cases
    parser = GoogleParser()
    method_name = 'parse'
    # Test case 0
    str_0 = 'y'
    try:
        docstring_0 = parse(str_0)
        assert docstring_0
    except ParseError:
        # test case passed
        pass


# Generated at 2022-06-25 16:28:20.189999
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert True

# Generated at 2022-06-25 16:28:32.867089
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = parse('y')
    assert len(docstring_0.meta) == 0
    assert docstring_0.short_description == 'y'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False

    docstring_0 = parse('y\n\n')
    assert len(docstring_0.meta) == 0
    assert docstring_0.short_description == 'y'
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == True
    assert docstring_0.blank_after_long_description == False

    docstring_0 = parse('y\n\na')

# Generated at 2022-06-25 16:28:39.610174
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_0 = Docstring()
    str_0 = 'y'
    docstring_0.short_description = 'y'
    docstring_0.blank_after_short_description = True
    docstring_0.blank_after_long_description = False
    docstring_0.long_description = None
    docstring_0.meta = []
    assert parse(str_0) == docstring_0

# Generated at 2022-06-25 16:28:46.225279
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    str_0 = 'r'
    docstring_0 = parser_0.parse(str_0)
    str_1 = 'Returns\n  :rtype: int'
    docstring_1 = parser_0.parse(str_1)
    str_2 = 'Args:\n    param1: The first parameter.\n    param2: The second parameter.'
    docstring_2 = parser_0.parse(str_2)


# Generated at 2022-06-25 16:28:47.571445
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str = 'y'
    googleParser = GoogleParser()
    googleParser.parse(str)


# Generated at 2022-06-25 16:28:48.066412
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert True

# Generated at 2022-06-25 16:28:49.987378
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    str_0 = 'y'
    docstring_0 = google_parser.parse(str_0)
    assert docstring_0 != None
test_case_0()
test_GoogleParser_parse()

# Generated at 2022-06-25 16:29:49.900955
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # test_case_0
    str_0 = ''
    docstring_0 = parse(str_0)
    assert(len(docstring_0.params) == 0 and len(docstring_0.raises) == 0 and len(docstring_0.returns) == 0)

    # test_case_1
    str_1 = 'y\n'
    docstring_1 = parse(str_1)
    assert(len(docstring_1.params) == 0 and len(docstring_1.raises) == 0 and len(docstring_1.returns) == 0)
    assert(docstring_1.short_description == 'y')

    # test_case_2
    str_2 = '\n'
    docstring_2 = parse(str_2)

# Generated at 2022-06-25 16:29:51.209566
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()


# Generated at 2022-06-25 16:29:55.824259
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp_0 = GoogleParser()
    d_0 = parse('y')
    d_1 = gp_0.parse('y')
    assert d_0 == d_1

if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:02.965376
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # TEST-0: Non-empty string
    str_0 = 'y'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'y'
    docstring_1 = parse(' y ')
    assert docstring_1.short_description == ' y '
    docstring_2 = parse(' y\n')
    assert docstring_2.short_description == ' y'
    docstring_3 = parse(' y\n\n')
    assert docstring_3.short_description == ' y'
    assert docstring_3.blank_after_short_description == True
    docstring_4 = parse(' y\n\n\n')
    assert docstring_4.short_description == ' y'
    assert docstring_4.blank_after_short_description == True


# Generated at 2022-06-25 16:30:08.177228
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    str_0 = 'y'
    docstring_0 = parser_0.parse(str_0)
    bool_0 = docstring_0.short_description == 'y'
    assert bool_0


# Generated at 2022-06-25 16:30:10.542406
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)


# Generated at 2022-06-25 16:30:17.608953
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = """This function does something.

    Examples:

        First example:

            print(1)

        Second example:

            print(2)

    Args are for the function. They are usually optional.
    """
    docstring_0 = parse(str_0)
    print("Passed unit test for method parse of class GoogleParser")


if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:19.952744
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()
    str_0 = 'y'
    _docstring_0 = obj.parse(str_0)
    test_case_0()


# Generated at 2022-06-25 16:30:22.657644
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    str_0 = 'y'
    docstring_0 = parser.parse(str_0)



# Generated at 2022-06-25 16:30:28.525177
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_1 = '''\
    A function.

    This function is useful.

    :param x: `x`.
    :param y: `y`.
    :type x: int
    :type y: int
    :returns: result
    '''
    docstring_1 = parse(str_1)
    str_2 = '''\
    A function.

    This function is useful.

    :param x: `x`.
    :param y: `y`.
    :type x: int
    :type y: int
    :returns: result
    '''
    docstring_2 = parse(str_2)
    assert (docstring_1 == docstring_2)

# Generated at 2022-06-25 16:31:21.852249
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    instance = GoogleParser()
    str_0 = 'y'
    docstring_0 = instance.parse(str_0)
    assert docstring_0.meta == []
    assert docstring_0.short_description == 'y'
    assert docstring_0.long_description is None
    str_1 = 'y'
    docstring_1 = GoogleParser(title_colon=False).parse(str_1)
    assert docstring_1.meta == []
    assert docstring_1.short_description == 'y'
    assert docstring_1.long_description is None
    str_2 = 'y'
    docstring_2 = GoogleParser(sections=[Section("Y", "param", SectionType.MULTIPLE)]).parse(str_2)
    assert docstring_2.meta == []
    assert docstring

# Generated at 2022-06-25 16:31:23.711623
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    str_0 = """A docstring."""

    docstring_0 = parse(str_0)

    assert docstring_0.short_description == "A docstring."



# Generated at 2022-06-25 16:31:32.458630
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'y'
    assert not docstring_0.blank_after_short_description
    assert not docstring_0.blank_after_long_description
    str_1 = 'y\n'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'y'
    assert docstring_1.blank_after_short_description
    assert not docstring_1.blank_after_long_description
    str_2 = 'y\n'
    docstring_2 = parse(str_2)
    assert docstring_2.short_description == 'y'
    assert docstring_2.blank_after_short_description
    assert not docstring_

# Generated at 2022-06-25 16:31:42.195626
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)
    str_1 = ' y '
    docstring_1 = parse(str_1)
    str_2 = ' y :'
    docstring_2 = parse(str_2)
    str_3 = 'y: '
    docstring_3 = parse(str_3)
    str_4 = 'y: x'
    docstring_4 = parse(str_4)
    str_5 = 'y: x\n'
    docstring_5 = parse(str_5)
    str_6 = 'y: x\n  '
    docstring_6 = parse(str_6)
    str_7 = 'y: x\n   '
    docstring_7 = parse(str_7)

# Generated at 2022-06-25 16:31:52.662836
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """test_GoogleParser_parse(text)

    test for method parse of class GoogleParser
    """

    str_0 = 'y'
    docstring_0 = parse(str_0)

    str_1 = ':type y:\n    None'
    docstring_1 = parse(str_1)

    str_2 = ':type y:\n:param k:\n    None'
    docstring_2 = parse(str_2)

    str_3 = ':type y:y\n:param k:k\n    None'
    docstring_3 = parse(str_3)

    str_4 = 'y: Type\n    Description'
    docstring_4 = parse(str_4)

# Generated at 2022-06-25 16:31:56.035804
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()
    # TODO: add more tests


# Generated at 2022-06-25 16:31:58.113059
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()


if __name__ == '__main__':
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:32:10.346462
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = ''
    docstring_0 = GoogleParser().parse(str_0)
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []

    str_1 = '''\
    get it
    '''
    docstring_1 = GoogleParser().parse(str_1)
    assert docstring_1.short_description == 'get it'
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False

# Generated at 2022-06-25 16:32:23.058173
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = """Simple example"""
    docstring_0 = parse(str_0)
    assert docstring_0.short_description == 'Simple example'
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.long_description is None
    str_1 = 'Example with long description\n\nMore description.'
    docstring_1 = parse(str_1)
    assert docstring_1.short_description == 'Example with long description'
    assert docstring_1.long_description == 'More description.'
    assert docstring_1.blank_after_short_description == True
    assert docstring_1.blank_after_long_description == True
    str_2 = 'Example with description on same line'
    docstring_2 = parse(str_2)
    assert docstring

# Generated at 2022-06-25 16:32:29.995832
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    str_0 = 'y'
    docstring_0 = parse(str_0)
    str_1 = 'x'
    docstring_1 = parse(str_1)
    str_2 = 'Test'
    docstring_2 = parse(str_2)
    str_3 = 'Test:  Example'
    docstring_3 = parse(str_3)
    pass