

# Generated at 2022-06-25 16:24:01.483507
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Setup
    first_arg = "some  magic    string" + chr(10) + chr(10) + chr(10) + "      magic"
    text = first_arg + "      some text" + chr(10) + "      some more text"
    # Exercise
    ret = GoogleParser(title_colon=False).parse(text)
    # Verify
    assert first_arg == ret.meta[0].args[0]
    assert "some text" == ret.meta[0].description
    assert "some more text" == ret.meta[1].description
    assert "magic" == ret.meta[1].args[0]


# Generated at 2022-06-25 16:24:12.072328
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test cases
    # Case 0
    section_type_0 = SectionType.SINGULAR_OR_MULTIPLE
    title_colon_0 = True
    text_0 = """
    This is the summary line
    This is the long description

    Args:
        arg1 (int): This is the first integer
        arg2 (str): This is the second string

    Returns:
        int: This is a return integer
    """
    section_0 = Section("Args", "param", section_type_0)
    section_1 = Section("Returns", "returns", section_type_0)
    sections_0 = [section_0, section_1]
    parser_0 = GoogleParser(sections=sections_0, title_colon=title_colon_0)
    # parse()

# Generated at 2022-06-25 16:24:21.777810
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    """Test parse."""
    doc = """
    Short description.
    Long description.
    Arguments:
        arg1 (int): Description of arg1.
        arg2 (list[int]): Description of arg2.
    Returns:
        int: Description of return value.
    Raises:
        TypeError: Description of exception raised.
    """
    ret = parse(doc)
    assert ret.short_description == "Short description."
    assert ret.long_description == "Long description."
    assert ret.blank_after_short_description
    assert ret.blank_after_long_description
    args = ret.meta[0]
    assert args.args == ["param", "arg1 (int)"]
    assert args.arg_name == "arg1"
    assert args.type_name == "int"
    args = ret

# Generated at 2022-06-25 16:24:34.587774
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    text = """
        summaries are just one line

        Long descriptions
        have multiple lines and
        include indented code blocks
        """
    assert parser.parse(text) == Docstring(
        short_description="summaries are just one line",
        long_description="Long descriptions\nhave multiple lines and\ninclude indented code blocks",
        blank_after_short_description=True,
        blank_after_long_description=False,
        meta=[],
    )

    text = """
        summaries are just one line

        Long descriptions
        have multiple lines and
        include indented code blocks

        """

# Generated at 2022-06-25 16:24:47.120021
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    meta0 = DocstringMeta(args=["Example", "Example:"], description="Example doc")
    ret0 = Docstring(
        short_description="Example",
        long_description="Example",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[meta0]
    )
    assert GoogleParser().parse("Example\nExample: Example doc") == ret0

    meta0 = DocstringMeta(args=["Returns", "returns"], description="Example doc")
    ret1 = Docstring(
        short_description="Example",
        long_description="Example",
        blank_after_short_description=False,
        blank_after_long_description=False,
        meta=[meta0]
    )
    assert GoogleParser().parse("Example\nReturns: Example doc") == ret1

# Generated at 2022-06-25 16:25:00.203703
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "This is a function.\n\n:param foo: This is a description.\n:param bar: This is another description.\n:raises ValueError: This is exception description.\n:returns: description\n"
    GoogleParser_instance_0 = GoogleParser()
    ret_val_0 = GoogleParser_instance_0.parse(text)
    assert (
        ret_val_0.short_description == "This is a function."
    ), "Expected instance attribute short_description == 'This is a function.', but it did not."
    assert (
        ret_val_0.blank_after_short_description == True
    ), "Expected instance attribute blank_after_short_description == True, but it did not."

# Generated at 2022-06-25 16:25:05.863985
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # input
    text = ""

    # expected output
    ret = Docstring()

    # actual output
    gp = GoogleParser()
    actual_ret = gp.parse(text)

    # assertion
    assert ret == actual_ret, (ret, actual_ret)



# Generated at 2022-06-25 16:25:15.428447
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstring = google_parser.parse("")
    assert isinstance(docstring, Docstring)
    assert len(docstring.meta) == 0
    assert docstring.short_description is None
    assert docstring.long_description is None

    docstring = google_parser.parse("short description")
    assert isinstance(docstring, Docstring)
    assert len(docstring.meta) == 0
    assert docstring.short_description == "short description"
    assert docstring.long_description is None

    docstring = google_parser.parse("short description\n\n")
    assert isinstance(docstring, Docstring)
    assert len(docstring.meta) == 0
    assert docstring.short_description == "short description"
    assert docstring.long_description is None

    doc

# Generated at 2022-06-25 16:25:27.160066
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstr = """This is the docstring.
    Args:
        x: blah blah.
        y: blah blah.

        This is a longer explanation of y. It may include multiple lines.
        z: blah blah more blah.
    Returns:
        This is where it returns to.

    """
    doc = GoogleParser().parse(docstr)
    assert doc.short_description == "This is the docstring."
    assert doc.long_description == ""
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 3
    assert doc.meta[0].args == ['param', 'x']
    assert doc.meta[1].args == ['param', 'y']
    assert doc.meta[2].args == ['returns']
   

# Generated at 2022-06-25 16:25:36.444550
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # create GoogleParser object
    google_parser_obj = GoogleParser()
    # call method
    result_docstring = google_parser_obj.parse(
        inspect.cleandoc(
            """
        Short description.

        This is a long description.
        """
        )
    )
    # assert result
    assert result_docstring.short_description == "Short description."
    assert result_docstring.long_description == "This is a long description."
    assert result_docstring.blank_after_short_description == True
    assert result_docstring.blank_after_long_description == False
    assert len(result_docstring.meta) == 0



# Generated at 2022-06-25 16:25:52.203858
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    # Example 1
    text = inspect.cleandoc(
        """\
        Args:
            foo:
            bar:
            baz (str):

        Returns:
            None
        """
    )
    doc = parser.parse(text)
    assert isinstance(doc, Docstring)
    assert len(doc.meta) == 2
    assert doc.num_meta_elements("param") == 2
    assert doc.num_meta_elements("returns") == 1
    assert doc.meta[0] == DocstringParam(
        args=["param", "bar"],
        description=None,
        arg_name="bar",
        type_name=None,
        default=None,
        is_optional=None,
    )
    assert doc.meta[1] == DocstringReturns

# Generated at 2022-06-25 16:26:04.875339
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("")
    assert docstring.__dict__ == {
        "short_description": None,
        "long_description": None,
        "blank_after_short_description": False,
        "blank_after_long_description": False,
        "meta": [],
    }

    parser = GoogleParser()
    docstring = parser.parse("A short description\n")
    assert docstring.__dict__ == {
        "short_description": "A short description",
        "long_description": None,
        "blank_after_short_description": False,
        "blank_after_long_description": False,
        "meta": [],
    }

    parser = GoogleParser()

# Generated at 2022-06-25 16:26:15.807325
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    # Setup
    goo_parser = GoogleParser()

    doc_string = '''\
    This is a first line.

    This is a second line.

    Raises:
        ValueError: the first argument of the raise statement
        TypeError: the second argument of the raise statement
        NotImplementedError: the third argument of the raise statement

    Returns:
        None: This is a short description
              Second line of the description.
    '''

    # Exercise
    actual_docstring = goo_parser.parse(doc_string)

    # Verify

# Generated at 2022-06-25 16:26:29.039524
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    g = GoogleParser()
    docstring = g.parse(
        """
    This is a short description.

    This is a long description.
"""
    )
    assert docstring == Docstring(
        short_description="This is a short description.",
        long_description="This is a long description.",
        blank_after_short_description=True,
        blank_after_long_description=False,
    )

    docstring = g.parse(
        """
    This is a short description.

    This is a long description.

    """
    )
    assert docstring == Docstring(
        short_description="This is a short description.",
        long_description="This is a long description.",
        blank_after_short_description=True,
        blank_after_long_description=True,
    )

    docstring = g

# Generated at 2022-06-25 16:26:35.399182
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p = GoogleParser()
    d = p.parse("""
    The first line is a short description.

    The second line is a long
    description. It can have multiple lines.

    Args:
        param1: The first parameter.
        param2: The second parameter.
        *args: Variable length argument list.
        **kwargs: Arbitrary keyword arguments.

    Attributes:
        attr1: Description of attr1.

    Raises:
        Exception1: If the action could not be performed.
        Exception2: If the action could not be performed.

    Returns:
        str: The return value.
        int: The return value.

    """
    )
    assert d.short_description == "The first line is a short description."

# Generated at 2022-06-25 16:26:45.332132
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:26:55.615231
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Initialization
    # ---------------

    # Setup parser
    sections = [
        Section("Argument", "arg", SectionType.SINGULAR),
        Section("Arguments", "args", SectionType.MULTIPLE),
        Section("Example", "example", SectionType.SINGULAR),
        Section("Examples", "examples", SectionType.SINGULAR),
        Section("Raises", "raises", SectionType.MULTIPLE),
        Section("Return", "return", SectionType.SINGULAR_OR_MULTIPLE),
        Section("Returns", "returns", SectionType.SINGULAR_OR_MULTIPLE),
    ]
    parser = GoogleParser(sections)

    # Test cases
    # ----------

    # Test 0: docstring without meta
    # ------------------------------
    # Argument

# Generated at 2022-06-25 16:27:07.661918
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    sections_0 = [Section("Yields", "yields", SectionType.SINGULAR_OR_MULTIPLE)]
    test_text_0 = """Takes a url or a string and returns the domain name.

Parameters
----------
some:    Url or string.
another: Url or string.
"""

# Generated at 2022-06-25 16:27:17.774265
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    t = "The Google Style Python Docstrings."
    d = GoogleParser().parse(t)
    # Test of parsing doc string that is simply a single line string
    assert d.short_description == "The Google Style Python Docstrings."
    # Test of parsing doc string that is simply a single line string
    assert d.long_description is None
    # Test of parsing doc string that is simply a single line string
    assert d.blank_after_short_description is False
    # Test of parsing doc string that is simply a single line string
    assert d.blank_after_long_description is False
    # Test of parsing doc string that is simply a single line string
    assert len(d.meta) == 0

    t = "The Google Style Python Docstrings.\n\n"
    d = GoogleParser().parse(t)
    # Test of parsing doc string

# Generated at 2022-06-25 16:27:20.500453
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    parser.parse("""\
        This is an example of a short description.

        This is an example of a long description.

        Args:
            arg1: An example argument.
        Returns:
            An example return value.
    """)


# Generated at 2022-06-25 16:27:36.648368
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    # Test case 0
    docstring = parser.parse("""
        Some description.

        Args: param0 (type): First parameter.
                Defaults to None.
              param1 (:obj:`str`, optional): Second parameter.
              param2 (:py:class:`int`, optional): Third parameter.
        Returns: (:py:class:`str`): Some string.
    """)
    expected_docstring = Docstring()
    expected_docstring.short_description = "Some description."

# Generated at 2022-06-25 16:27:44.294199
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    def test_case_1():
        parser = GoogleParser()

# Generated at 2022-06-25 16:27:54.330406
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()
    docstring = parser.parse("""\
    Example function with types documented in the docstring.

    :param int a: The value of a
    :param str b: The value of b
    :returns: a + b
    :rtype: int
    """)
    assert len(docstring.meta) == 5
    assert docstring.meta[0].__class__ is DocstringMeta
    assert docstring.meta[0].args == ["examples"]
    assert docstring.meta[0].description == "Example function with types documented in the docstring."
    assert docstring.meta[1].__class__ is DocstringParam
    assert docstring.meta[1].args == ["param", "a: The value of a"]
    assert docstring.meta[1].description is None
    assert docstring.meta

# Generated at 2022-06-25 16:28:06.243860
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = "This is a simple test"
    text_1 = "This is an example:\n\nThis is the second line of the example."
    text_2 = "This is an example:\n\nThis is the second line of the example:\n\nThis is the third line of the example."
    text_3 = "This is an example:\n\nThis is the second line of the example:\n\nThis is the third line of the example.\n\nThis is the fourth line of the example."
    text_4 = "This is an example:\n\nThis is the second line of the example:\n\nThis is the third line of the example.\n\nThis is the fourth line of the example."

# Generated at 2022-06-25 16:28:14.430227
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text_0 = (""""""
    """    parse the Google-style docstring into its components.

    :param text: Google-style docstring
    :returns: parsed docstring
    """)
    obj_0 = GoogleParser()
    ret_0 = obj_0.parse(text_0)

# Generated at 2022-06-25 16:28:21.666570
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    #
    # Without sections
    #

    expected = Docstring(
        short_description="Short description",
        blank_after_short_description=True,
        long_description="Long description",
        meta=[
            DocstringMeta(
                args=["examples"],
                description="Example",
            )
        ],
        blank_after_long_description=True,
    )
    actual = GoogleParser().parse(
        """
        Short description

        Long description

        Examples
        --------
        Example
        """
    )

    assert expected == actual

    #
    # With sections
    #


# Generated at 2022-06-25 16:28:33.735879
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Constructor test
    try:
        GoogleParser_instance_0 = GoogleParser()
    except Exception as e:
        print(str(e))
    # Method test

# Generated at 2022-06-25 16:28:37.365721
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    str_0 = ""
    docstring_0 = google_parser_0.parse(str_0)


# Generated at 2022-06-25 16:28:48.466053
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    section_type_0 = SectionType.SINGULAR_OR_MULTIPLE
    section_type_1 = SectionType.SINGULAR_OR_MULTIPLE
    section_type_2 = SectionType.SINGULAR_OR_MULTIPLE
    section_type_3 = SectionType.SINGULAR_OR_MULTIPLE
    section_type_4 = SectionType.SINGULAR_OR_MULTIPLE
    section_type_5 = SectionType.SINGULAR_OR_MULTIPLE
    section_type_6 = SectionType.SINGULAR_OR_MULTIPLE
    # docstring: Parse the Google-style docstring into its components.
    # :returns: parsed docstring

# Generated at 2022-06-25 16:29:00.068499
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = "short description\n\nlong description\n\nParameters:\n    param:  description\n    param2:  description\n\nReturns:\n    result:  description\n\nYields:\n    yield:  description\n    yield2:  description\n\n"""
    result = GoogleParser().parse(text)
    assert result.short_description == 'short description'
    assert result.long_description == 'long description'
    assert result.blank_after_long_description is True
    assert result.blank_after_short_description is True
    assert len(result.meta) == 5
    assert result.meta[0].description == 'description'
    assert result.meta[0].keywords == ('param', 'Parameters')
    assert result.meta[0].arguments == ('Param', 'param')
   

# Generated at 2022-06-25 16:29:07.974560
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    docstring = \
    """Single-line summary.
    More detailed description.

    Returns:
      The returned value.
    """

    doc = parse(docstring)

    assert doc.short_description == "Single-line summary."
    assert doc.long_description == "More detailed description."
    assert doc.blank_after_short_description is True
    assert doc.meta[0].description == "The returned value."



# Generated at 2022-06-25 16:29:11.979612
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print("Testing method GoogleParser.parse...")
    # Arrange
    o = GoogleParser()

    # Act
    ret = o.parse('')

    # Assert
    assert [] == ret.meta


# Generated at 2022-06-25 16:29:22.416330
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    source_0 = inspect.cleandoc(
        """
    This is a short description.
    This is the long description.

    Args:
        a (int): First param.
        b: Second param.
        c (float, optional): This one is optional.

    Returns:
        str: Returns a string

    Raises:
        XyzError: An error.
    """
    )
    section_type_0 = SectionType.SINGULAR_OR_MULTIPLE
    section_type_1 = SectionType.MULTIPLE
    section_type_2 = SectionType.SINGULAR
    section_type_3 = SectionType.MULTIPLE
    section_type_4 = SectionType.SINGULAR
    section_type_5 = SectionType.MULTIPLE
    section_type_6 = SectionType

# Generated at 2022-06-25 16:29:32.653777
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Test case data
    googleParser = GoogleParser()

# Generated at 2022-06-25 16:29:44.734260
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Create test object
    obj = GoogleParser()
    # Set test variables
    text = """Simple description.
    Args:
        arg1 (int): Simple argument.
    Returns:
        A simple return.
    """
    # Test method
    assert obj.parse(text) == Docstring(
        short_description="Simple description.",
        blank_after_short_description=True,
        long_description=None,
        blank_after_long_description=False,
        meta=[
            DocstringMeta(
                args=["param"],
                description="Simple argument.",
                arg_name="arg1",
                type_name="int",
            ),
            DocstringReturns(
                args=["returns"], description="A simple return.", type_name=None
            ),
        ],
    )
    # Test method

# Generated at 2022-06-25 16:29:58.215352
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():

    docstring = """Summarize here.

        Args:
          arg1: Description of arg1
          arg2: Description of arg2
        """

    parser = GoogleParser()
    docstring = parser.parse(docstring)
    assert docstring.short_description == "Summarize here."
    assert docstring.long_description is None

    section = docstring.meta[0]
    assert section.args[1] == "arg1"
    assert section.arg_name == "arg1"
    assert section.description == "Description of arg1"
    assert section.type_name is None

    section = docstring.meta[1]
    assert section.args[1] == "arg2"
    assert section.arg_name == "arg2"
    assert section.description == "Description of arg2"

# Generated at 2022-06-25 16:30:09.272435
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    sections_0 = DEFAULT_SECTIONS
    text_0 = """\
    Example of docstring with all sections.

    Args:
        name (str): Name of function.
        args (dict): Arguments.
    Returns:
        Result.

    Raises:
        Exception.

    """
    ds = GoogleParser().parse(text_0)
    print(ds)
    #print(ds.meta)
    #print(ds.meta[-1].arg_name)
    #print(ds.meta[-1].description)

# Run the tests
if __name__ == "__main__":
    test_GoogleParser_parse()

# Generated at 2022-06-25 16:30:20.617100
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:30:31.926656
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    p0 = GoogleParser(title_colon=True)
    print(p0.parse(''))
    print(p0.parse('This actually works!\n'))
    p1 = GoogleParser(title_colon=True)
    print(p1.parse(''))
    print(p1.parse('\n'))
    print(p1.parse('\n\n'))
    print(p1.parse('\n\n\n'))
    p2 = GoogleParser(title_colon=True)
    p2.add_section(Section('foo', 'foo', SectionType.SINGULAR_OR_MULTIPLE))
    print(p2.parse('foo:\n    a\n'))
    print(p2.parse('foo:\n    a\n    b\n'))


# Generated at 2022-06-25 16:30:42.705899
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser = GoogleParser()
    docstring = google_parser.parse("")
    assert docstring.long_description == None
    assert docstring.short_description == None
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == False
    assert docstring.meta == []
    docstring = google_parser.parse("My description")
    assert docstring.long_description == None
    assert docstring.short_description == 'My description'
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == False
    assert docstring.meta == []
    docstring = google_parser.parse("My\ndescription\n")
    assert docstring.long_description == None

# Generated at 2022-06-25 16:30:53.974451
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = 'Test case for method parse of class GoogleParser'
    docstring = parse(text)
    assert docstring.short_description == 'Test case for method parse of class GoogleParser'
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert type(docstring.meta) == list
    assert len(docstring.meta) == 0

# Generated at 2022-06-25 16:30:56.809711
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    google_parser_0 = GoogleParser()
    try:
        docstring_0 = google_parser_0.parse('')
    except ParseError:
        return
    assert False



# Generated at 2022-06-25 16:31:08.304936
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    print('Testing GoogleParser.parse')

    # Test case 0
    # Create arguments
    text = "Returns a file object.\n\nReturns:\n    file:\n        File handle."
    # Execute function
    ret = GoogleParser().parse(text)
    # Test return value count
    assert len(ret.meta) == 1
    # Test return value 0 type and value
    assert isinstance(ret.meta[0], DocstringReturns)
    arg_00_0 = ret.meta[0].args[0]
    arg_01_0 = ret.meta[0].args[1]
    arg_02_0 = ret.meta[0].description
    arg_03_0 = ret.meta[0].type_name
    arg_04_0 = ret.meta[0].is_generator
    assert arg_00_

# Generated at 2022-06-25 16:31:18.536809
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    assert GoogleParser().parse('') == Docstring()
    assert GoogleParser().parse('\n') == Docstring()
    assert GoogleParser().parse('foo\n') == Docstring(short_description='foo')
    assert GoogleParser().parse('foo\n\n') == Docstring(short_description='foo')
    assert GoogleParser().parse('\nfoo\n') == Docstring(
        short_description='foo', blank_after_short_description=True
    )
    assert GoogleParser().parse('\nfoo\n\n') == Docstring(
        short_description='foo', blank_after_short_description=True
    )

# Generated at 2022-06-25 16:31:27.540700
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    docstring = parser.parse("""\
        Short.

        Long.
        """)
    assert docstring.short_description == "Short."
    assert docstring.blank_after_short_description
    assert docstring.long_description == "Long."
    assert docstring.blank_after_long_description
    assert docstring.meta == []



# Generated at 2022-06-25 16:31:28.391894
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    test_case_0()



# Generated at 2022-06-25 16:31:41.109664
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # See doc
    print(inspect.cleandoc("asd    \n\n \n  \n\n asd"))
    text = '''bla
        bla
        :param  k:
        :param k:
            Bla.
            Bla.
        :param (Optionable) k:
            Bla.

        :raises  Bla:
        :raises Bla:
            Bla.

        :returns:
        :returns (Optional) Bla:
            Bla.
        :returns (Generator[Bla, Bla, Bla]):
            Bla.
        '''
    doc = GoogleParser().parse(text)

    assert doc.short_description == "bla"
    assert doc.long_description == "bla"

# Generated at 2022-06-25 16:31:52.877584
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    text = ""
    parser = GoogleParser()
    docstring = parser.parse(text)
    assert docstring.short_description == None
    assert docstring.blank_after_short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == None
    assert len(docstring.meta) == 0
    text = "Single line docstring."
    docstring = parser.parse(text)
    assert docstring.short_description == text
    assert not docstring.blank_after_short_description
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == None
    assert len(docstring.meta) == 0
    text = "Multiline\n    docstring."
    docstring = parser.parse(text)
    assert doc

# Generated at 2022-06-25 16:32:04.864629
# Unit test for method parse of class GoogleParser

# Generated at 2022-06-25 16:32:13.817566
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    section_type_0 = SectionType.SINGULAR_OR_MULTIPLE
    section_0 = Section("Returns", "returns", section_type_0)
    google_parser_0 = GoogleParser()
    google_parser_0.add_section(section_0)
    str_0 = "def function_0(arg_0):  \n    \"\"\"  \n    :param arg_0:  \n    :type arg_0: int  \n    :rtype: int  \n    :returns: something  \n    :raises ValueError:  \n    \"\"\"  \n    pass"
    docstring_0 = google_parser_0.parse(str_0)
    print(docstring_0.meta)
    assert docstring_0.long_description == "something"



# Generated at 2022-06-25 16:32:22.082371
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    obj = GoogleParser()

    test_case_0()



# Generated at 2022-06-25 16:32:33.983998
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    gp = GoogleParser()
    d = gp.parse("")
    assert d.short_description == None, "Short description must be empty"
    assert d.long_description == None, "Long description must be empty"
    assert d.blank_after_short_description == False, "blank after short desc."
    assert d.blank_after_long_description == False, "blank after long desc."
    assert d.meta == [], "Meta must be empty"

    d = gp.parse("Short description\n\nLong description")
    assert d.short_description == "Short description", "Short desc not set"
    assert d.long_description == "Long description", "Long desc not set"
    assert d.blank_after_short_description == True, "blank after short desc."

# Generated at 2022-06-25 16:32:38.503400
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser = GoogleParser()

    # Case 0
    text_0 = "Like range(), but instead of returning a list,\nreturn an iterator, useful for looping\nover large ranges of numbers."

    ret_0 = parser.parse(text_0)

    assert ret_0.short_description == text_0


# Generated at 2022-06-25 16:32:42.545988
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    parser_0 = GoogleParser()
    #
    text_0 = "    title\ntext\nmore text\n\n"
    ret = parser_0.parse(text_0)
    assert ret.short_description == "title"
    assert ret.blank_after_short_description == True
    assert ret.blank_after_long_description == True
    assert ret.long_description == None



# Generated at 2022-06-25 16:32:48.083176
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    docstring_text_0 = ''
    sections_0 = None
    title_colon_0 = True

    # Instantiate an instance of class GoogleParser
    parser_0 = GoogleParser(sections_0, title_colon_0)
    docstring_1 = parser_0.parse(docstring_text_0)
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert len(docstring_1.meta) == 0

    docstring_text_1 = ' '
    sections_1 = None
    title_colon_1 = True

    # Instantiate an instance of class GoogleParser

# Generated at 2022-06-25 16:32:58.705857
# Unit test for method parse of class GoogleParser
def test_GoogleParser_parse():
    # Case 0
    google_parser_0 = GoogleParser()
    text_0 = "description"
    docstring_0 = google_parser_0.parse(text_0)
    assert docstring_0.short_description == text_0

    # Case 1
    google_parser_1 = GoogleParser()
    text_1 = "description\n\nlong description."
    docstring_1 = google_parser_1.parse(text_1)
    assert docstring_1.short_description == "description"

    # Case 2
    google_parser_2 = GoogleParser()
    text_2 = "description\nlong description."
    docstring_2 = google_parser_2.parse(text_2)
    assert docstring_2.short_description ==  "description"

    # Case 3
    google_parser_3