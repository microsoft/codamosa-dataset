

# Generated at 2022-06-25 22:07:37.260190
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    union_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    assert_equal(union_0, a_s_t_1)

# Generated at 2022-06-25 22:07:45.958305
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0.Module(body=[])
    module_0.Name(id='None', ctx=module_0.Load())
    module_0.Name(id='None', ctx=module_0.Load())
    module_0.Dict(keys=[], values=[])
    module_0.Dict(keys=[], values=[])
    module_0.Call(func=module_0.Name(id='_py_backwards_merge_dicts',
                                     ctx=module_0.Load()),
                  args=[module_0.List(elts=[])],
                  keywords=[])

# Generated at 2022-06-25 22:07:46.471669
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass


# Generated at 2022-06-25 22:07:55.736720
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)

    # Input: Dict(keys=[Num(n=1), Num(n=2)], values=[Num(n=1), Num(n=2)])
    # Expected output: Dict(keys=[Num(n=1), Num(n=2)], values=[Num(n=1), Num(n=2)])
    a_s_t_1.body.append(module_0.Dict(keys=[module_0.Num(n=1), module_0.Num(n=2)], values=[module_0.Num(n=1), module_0.Num(n=2)]))

# Generated at 2022-06-25 22:08:04.650783
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    return_value_0 = module_0.Dict(keys=[None], values=[])
    module_0.Dict(keys=[None], values=[]).lineno = None
    module_0.Dict(keys=[None], values=[]).col_offset = None
    module_0.Dict(keys=[None], values=[]).end_lineno = None
    module_0.Dict(keys=[None], values=[]).end_col_offset = None
    assert dict_unpacking_transformer_1.visit_Dict(module_0.Dict(keys=[None], values=[])) is return_value_0

# Unit test

# Generated at 2022-06-25 22:08:14.133811
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    x = a_s_t_0
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_0 = a_s_t_0
    stmt_list = [ast_0.Module(body=[x.Expr(value=ast_0.Dict(keys=[None, ast_0.Num(n=1), None], values=[ast_0.Dict(keys=[], values=[]), ast_0.Num(n=1), x.Name(id='dict')]))])]

# Generated at 2022-06-25 22:08:20.672669
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Dict()
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    assert_equals(dict_unpacking_transformer_0, dict_unpacking_transformer_1)

# Generated at 2022-06-25 22:08:28.375402
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    a_s_t_2 = module_0.Dict()
    ret_val_1 = dict_unpacking_transformer_1.visit_Dict(a_s_t_2)
    assert isinstance(ret_val_1, module_0.Dict)


# Generated at 2022-06-25 22:08:35.693015
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[module_0.Num(n=1)], values=[module_0.Num(n=1)])

    i_1 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    assert i_1 == module_0.Dict(keys=[module_0.Num(n=1)], values=[module_0.Num(n=1)])


# Generated at 2022-06-25 22:08:38.630735
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    assert module_0.Module==type(dict_unpacking_transformer_0.visit(module_1))


# Generated at 2022-06-25 22:08:44.875916
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert False


# Generated at 2022-06-25 22:08:53.498855
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Creating objects for testing...
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Accessing methods of created objects...
    x_var_0 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)
    # Asserting return types...
    assert isinstance(x_var_0.keys, list)
    assert isinstance(x_var_0.keys[0], module_0.expr)
    assert isinstance(x_var_0.values, list)
    assert isinstance(x_var_0.values[0], module_0.expr)

# Generated at 2022-06-25 22:09:02.585619
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_x_var_3 = dict_unpacking_transformer_1.visit_Module(module_x_var_2)
    module_x_var_4 = module_0.Module([], [module_0.ImportFrom('typed_ast', ['Name'], 0)])
    a_s_t_2 = module_0.AST()
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_2)

# Generated at 2022-06-25 22:09:06.824811
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:09:13.940754
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()

# Generated at 2022-06-25 22:09:21.496551
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:09:27.362986
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict()
    dict_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)




# Generated at 2022-06-25 22:09:31.825293
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict()
    dict_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)

# Generated at 2022-06-25 22:09:41.772236
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    one_0 = module_0.Num()
    one_0.n = 1
    one_0.lineno = 2
    one_0.col_offset = 3
    one_1 = module_0.Num()
    one_1.n = 1
    one_1.lineno = 2
    one_1.col_offset = 3
    dict_1 = module_0.Dict()
    dict_1.keys = [one_0, one_0]
    dict_1.values = [one_1, one_1]
    dict_1.lineno = 2
    dict_1.col_offset = 3
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    dict_2 = dict_unpacking_transformer_1.visit_Dict

# Generated at 2022-06-25 22:09:51.544978
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    try:
        import typed_ast.ast3 as module_0
    except ModuleNotFoundError as e:
        print('Error: ', e)
        return
    try:
        import dzetsaka.transforms.dict_unpacking as module_1
    except ModuleNotFoundError as e:
        print('Error: ', e)
        return

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = module_1.DictUnpackingTransformer(a_s_t_0)

    module_x_var_0 = module_0.Module()
    module_x_var_1 = module_0.Dict()
    module_x_var_2 = module_0.List()
    module_x_var_3 = module_0.Name()
    module_

# Generated at 2022-06-25 22:10:08.308292
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    module_x_var_1 = module_0.Body()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_x_var_1)
    dict_unpacking_transformer_0.visit_Dict(module_x_var_0)

# Generated at 2022-06-25 22:10:17.739309
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test method 'visit_Dict' of class 'DictUnpackingTransformer'."""

# Generated at 2022-06-25 22:10:25.392419
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    list_comp_0 = module_0.ListComp(elt=module_0.Name(id='y', ctx=module_0.Load()), generators=[module_0.comprehension(target=module_0.Name(id='y', ctx=module_0.Store()), iter=module_0.Name(id='x', ctx=module_0.Load()), ifs=[])])

# Generated at 2022-06-25 22:10:35.519000
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Creating instance of class DictUnpackingTransformer without parameters
    dict_unpacking_transformer_0 = DictUnpackingTransformer()

    # Creating instance of class AST with parameter 'module'
    a_s_t_0 = AST(module)

    # Creating instance of class Module with parameter '_fields' with value [(body, [Assign(targets=[_Name(id='x', ctx=Store())], value=Call(func=Name(id='dict', ctx=Load()), args=[List(elts=[], ctx=Load()), Call(func=Name(id='dict', ctx=Load()), args=[List(elts=[], ctx=Load())], keywords=[], starargs=None, kwargs=None)], keywords=[], starargs=None, kwargs=None))])]

# Generated at 2022-06-25 22:10:41.128410
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:10:45.416207
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:10:55.417661
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    d_i_c_t_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    c_o_n_s_t_0 = module_0.Constant(1)
    d_i_c_t_0.keys.append(c_o_n_s_t_0)
    a_s_t_0 = module_0.AST()
    c_o_n_s_t_1 = module_0.Constant(1)

# Generated at 2022-06-25 22:11:04.548742
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    a = None
    b = None
    c = None
    d = None
    e = None
    f = None
    g = None
    h = None
    i = None
    j = None
    k = None
    l = None
    m = None
    n = None
    o = None
    p = None
    q = None
    r = None
    s = None
    t = None
    u = None
    v

# Generated at 2022-06-25 22:11:16.029691
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    assert_equal(module_x_var_0, module_0.Module())

    a_s_t_0 = module_0.AST()
    assert_equal(a_s_t_0, module_0.AST())

    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert_equal(dict_unpacking_transformer_0.tree, module_0.AST())
    assert_equal(dict_unpacking_transformer_0._tree_changed, False)

    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert_equal(module_x_var_1, module_0.Module())
   

# Generated at 2022-06-25 22:11:24.758660
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    module_0 = ast.parse("{1: 1, **dict_a}")

    module_x_var_0 = module_0.body[0].value

    dict_unpacking_transformer_0 = DictUnpackingTransformer()

    returned_value_0 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)

    assert isinstance(returned_value_0, ast.Call)
    assert returned_value_0.func.id == '_py_backwards_merge_dicts'
    assert len(returned_value_0.args) == 1
    assert len(returned_value_0.args[0].elts) == 2
    assert isinstance(returned_value_0.args[0].elts[0], ast.Dict)
   

# Generated at 2022-06-25 22:11:53.745052
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    dict_0 = module_0.Dict()
    dict_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    # True and False are switched because the test setup is missing some
    # statements
    assert dict_unpacking_transformer_0._tree_changed == False
    assert isinstance(dict_1, module_0.Dict)
    dict_unpacking_transformer_0._tree_changed = False

    dict_2 = module_0.Dict()
    dict_2

# Generated at 2022-06-25 22:11:54.425919
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
  test_case_0()



# Generated at 2022-06-25 22:12:02.593090
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
  from _ast import Module
  module_x_var_0 = Module()
  a_s_t_0 = _ast.AST()
  dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
  module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
  assert isinstance(module_x_var_1, Module)
  assert isinstance(module_x_var_1, Module)

import bitarray
import _cffi_backend
import _collections_abc
import _csv
import _dummy_thread
import _elementtree
import _frozen_importlib
import _markupbase
import _multiprocessing
import _posixsubprocess
import _sitebuiltins

# Generated at 2022-06-25 22:12:06.370578
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:12:08.496989
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:12:11.964523
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:12:13.758578
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_0.Module()
    module_0.AST()
    DictUnpackingTransformer(module_0.AST())

# Generated at 2022-06-25 22:12:19.237702
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)

# Generated at 2022-06-25 22:12:27.583300
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_2 = dict(keys=[module_0.Constant(value=1, kind=None), module_0.Constant(value=module_0.NameConstant(value=None), kind=None)], values=[module_0.Constant(value=1, kind=None), module_0.Constant(value=2, kind=None)])
    dict_unpacking_transformer_1 = dict_unpacking_transformer_0.visit_Dict(dict_2)

# Generated at 2022-06-25 22:12:33.262309
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:12:58.178763
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Prepare test
    module_x_var_0 = ast.Module()
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = False
    ast_0 = ast.Dict(keys=[None], values=[ast.Name(id="x", ctx=ast.Load())])
    # Perform the test
    dict_unpacking_transformer_1 = dict_unpacking_transformer_0.visit_Dict(ast_0)
   

# Generated at 2022-06-25 22:13:06.859435
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:13:11.150405
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:13:16.458486
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[None], values=[])
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:13:24.910813
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict(keys=list(), values=list())
    dict_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)
    assert dict_x_var_0 is dict_x_var_1


# Generated at 2022-06-25 22:13:34.434275
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict()
    dict_x_var_0.keys = [None]
    dict_x_var_0.values = [None]
    dict_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 22:13:43.162667
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_x_var_0)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(module_x_var_0)
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_2.visit_Module(module_x_var_0)
    dict_unpacking_transformer_3 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_4 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:13:46.163299
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:13:50.074391
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:13:50.857187
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:14:34.474583
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = _ast.Module()
    a_s_t_0 = _ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = _ast.Dict()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(module_x_var_1, ast.Call)

# Generated at 2022-06-25 22:14:41.282391
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit(module_x_var_0)
    dict_0 = module_0.Dict(keys=[None], values=[None])
    call_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert True

# Generated at 2022-06-25 22:14:48.809634
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = module_0.Module()
    assert repr(module_x_var_1) == repr(module_x_var_2)
    assert module_x_var_1.ctx == module_x_var_2.ctx

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:14:56.266572
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.target == (3, 4)
    assert dict_unpacking_transformer_0.tree == a_s_t_0
    assert dict_unpacking_transformer_0._tree_changed
    assert dict_unpacking_transformer_0.visit_Module.__func__ is DictUnpackingTransformer.visit_Module.__func__
    assert dict_unpacking_transformer_0.visit_Dict.__func__ is DictUnpackingTransformer.visit_Dict.__func__


# Generated at 2022-06-25 22:14:57.723942
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_0.Module()
    module_0.AST()
    assert DictUnpackingTransformer(None)

# Generated at 2022-06-25 22:15:02.892482
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Given
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # When
    dict_0 = module_0.Dict()
    dict_x_var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    # Then
    assert type(dict_x_var_0) is module_0.Dict


# Generated at 2022-06-25 22:15:08.425898
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:15:15.879971
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    value_0 = module_0.Dict()
    value_1 = module_0.Constant()
    value_2 = module_0.Name()
    value_3 = module_0.Str()
    value_1.s = value_3
    value_0.values = [value_1]
    value_2.id = value_3
    value_0.keys = [value_2]
    assert isinstance(dict_unpacking_transformer_0.visit_Dict(value_0), module_0.Dict)

# Generated at 2022-06-25 22:15:22.384909
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = dict_unpacking_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:15:25.644901
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# test_case_0()
test_DictUnpackingTransformer()
x = DictUnpackingTransformer(None)
x.visit_Dict(None)

# Generated at 2022-06-25 22:16:55.985447
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert True == True
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == module_x_var_0

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:16:56.829384
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:16:59.693483
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = ast.Module()
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:17:03.855954
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_0 = ast.Module()
    assert isinstance(ast, module_0)
    module_x_var_0 = module_0.Module()
    a_s_t_x_var_0 = module_0.AST()
    dict_unpacking_transformer_x_var_0 = DictUnpackingTransformer(
        a_s_t_x_var_0)
    assert isinstance(dict_unpacking_transformer_x_var_0, dict_unpacking_transformer_x_var_0.__class__)


# Generated at 2022-06-25 22:17:06.707820
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:17:07.136789
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-25 22:17:11.048933
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:17:14.142342
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:17:15.842423
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    assert dict_unpacking_transformer_0 is not None

# Unit tests for method DictUnpackingTransformer.visit_Module

# Generated at 2022-06-25 22:17:17.056321
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    tree = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer(tree)

