

# Generated at 2022-06-25 22:07:38.031772
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a = module_0.AST()            # initialization expression of class AST
    dict_unpacking_transformer = DictUnpackingTransformer(a)        # initialization of class DictUnpackingTransformer
    assert isinstance(dict_unpacking_transformer, DictUnpackingTransformer), "Check if object is an instance of class DictUnpackingTransformer"
    # Check if object instance is exactly class DictUnpackingTransformer
    assert type(dict_unpacking_transformer) == DictUnpackingTransformer, "Check if object is exactly an instance of class DictUnpackingTransformer"
    # Check if object is instance of BaseNodeTransformer
    assert isinstance(dict_unpacking_transformer, BaseNodeTransformer), "Check if object is an instance of BaseNodeTransformer"
    # Check if object instance is exactly class BaseNodeTransformer

# Generated at 2022-06-25 22:07:46.705583
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Build code
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:07:51.400182
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    a_s_t_2 = module_0.Module()
    node_0 = dict_unpacking_transformer_1.visit_Module(a_s_t_2)


# Generated at 2022-06-25 22:07:55.736543
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = dict_unpacking_transformer_0.visit_Module(module_1)
    assert module_2 is module_1


# Generated at 2022-06-25 22:07:59.963947
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = module_0.Module()
    module_0 = dict_unpacking_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:08:04.532477
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module(a_s_t_0.copy_location([]))
    dict_unpacking_transformer_0.visit(module_0_0)


# Generated at 2022-06-25 22:08:13.982402
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    module_1 = module_0.Module()

# Generated at 2022-06-25 22:08:25.050274
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    dict_0 = module_0.Dict()
    module_1.body = [dict_0]
    expr_0 = module_0.Num(n=1)
    expr_1 = module_0.Num(n=2)
    dict_comp_0 = module_0.DictComp(key=expr_0, value=expr_1, generators=[])
    alias_0 = module_0.alias(name='dict', asname=None)
    import_0 = module_0.ImportFrom(module='typed_ast._ast3', names=[alias_0], level=0)
   

# Generated at 2022-06-25 22:08:28.643489
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0



# Generated at 2022-06-25 22:08:36.959774
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    from typed_ast import ast3 as ast
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet

    @snippet
    def merge_dicts():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

    module = ast.parse('''{1: 1, **{2: 2}}\n''')
    insert_at(0, module, merge_dicts.get_body())
    module_new_1 = DictUnpackingTransformer().visit_Module(module)

    assert module_new_1 is not None, "Expect function to return a value"
    assert '_py_backwards_merge_dicts' in module_new_

# Generated at 2022-06-25 22:08:45.880813
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast
    import typed_astunparse
    a_s_t_0 = ast.parse(
        """{'__key__': 'foo', **{'bar': 'biz'}}"""
    )
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    a_s_t_0 = dict_unpacking_transformer_0.visit(a_s_t_0)
    print(typed_astunparse.unparse(a_s_t_0))


# Generated at 2022-06-25 22:08:54.514462
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:09:05.587139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    # Test 1
    test_str_0 = "{1: 1, **dict_a}"
    test_str_1 = "__py_backwards_merge_dicts([{1: 1}], dict_a)"
    assert(test_str_1 == str(dict_unpacking_transformer_0.visit_Dict(module_0.parse(test_str_0))))


# Generated at 2022-06-25 22:09:08.742598
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Class()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)



# Generated at 2022-06-25 22:09:18.720236
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([module_0.Expr(module_0.Dict(keys=[], values=[]))])
    module_2 = dict_unpacking_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:09:27.646145
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    import typed_ast._ast3 as module_1
    ast_1 = module_1.Call()
    ast_2 = module_1.Dict()
    ast_3 = module_1.Str()
    ast_4 = module_1.Str()
    ast_5 = module_1.Str()
    ast_6 = module_1.Str()
    ast_7 = module_1.BinOp()
    ast_8 = module_1.Str()
    ast_9 = module_1.Str()
    ast_10 = module_1.Str()
    ast_11 = module_1.BinOp()
    ast_12 = module

# Generated at 2022-06-25 22:09:39.150617
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)

if __name__ == '__main__':
    import sys
    import subprocess
    import os
    import sys
    import pytest
    from . import module_0
    from . import module_0

    arg = sys.argv[1]

# Generated at 2022-06-25 22:09:43.009864
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Run target function
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = ast.Module()
    a_s_t_1 = DictUnpackingTransformer(module_1)
    pass



# Generated at 2022-06-25 22:09:49.403738
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)
    assert hasattr(dict_unpacking_transformer_0, 'target')
    assert hasattr(dict_unpacking_transformer_0, '_tree_changed')


# Generated at 2022-06-25 22:09:52.465718
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_1


# Generated at 2022-06-25 22:10:02.969239
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([], [module_0.Expr(module_0.BinOp(module_0.Num(1), module_0.Add(), module_0.Num(2)))], [])
    dict_unpacking_transformer_0._tree_changed = False
    module_2 = dict_unpacking_transformer_0.visit_Module(module_1)
    assert dict_unpacking_transformer_0._tree_changed is False
    assert isinstance(module_2, module_0.Module)
    assert isinstance(module_2.body[0].value, module_0.BinOp)

# Generated at 2022-06-25 22:10:09.504521
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module(
        body=[]
    )
    dict_unpacking_transformer_0.generic_visit(node=module_1)
    assert module_1 is not None


# Generated at 2022-06-25 22:10:12.926895
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:17.355542
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert DictUnpackingTransformer(AST()).visit_Dict(None) == None


import typed_ast._ast3 as module_1
import typed_ast._ast3 as module_2
import typed_ast._ast3 as module_3
import typed_ast._ast3 as module_4


# Generated at 2022-06-25 22:10:25.156115
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast
    import typed_ast.ast3 as a
    import typing
    import _ast
    # Test case 2 - a.Module(
    #   body=[
    #       a.Expr(
    #           value=a.Call(
    #               func=a.Name(
    #                   id='_py_backwards_merge_dicts',
    #                   ctx=a.Load()),
    #               args=[
    #                   a.List(
    #                       elts=[
    #                           a.Dict(
    #                               keys=[
    #                                   a.Name(
    #                                       id='a',
    #                                       ctx=a.Load()),
    #                                   a.Constant(
    #                                       value=1,
    #                                       kind=None)],
   

# Generated at 2022-06-25 22:10:30.136016
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node = module_0.Dict(keys=[1], values=[1])
    func_return_0 = dict_unpacking_transformer_0.visit_Dict(node)
    assert func_return_0 is not None


# Generated at 2022-06-25 22:10:36.326706
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Dict()
    r_1 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert isinstance(r_1, module_0.Call)


# Generated at 2022-06-25 22:10:41.593143
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    class_1 = dict_unpacking_transformer_1.__class__
    class_2 = DictUnpackingTransformer
    assert class_1 == class_2


# Generated at 2022-06-25 22:10:42.404047
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:10:43.482497
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    with pytest.raises(TypeError):
        DictUnpackingTransformer()

# Generated at 2022-06-25 22:10:52.489034
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_x_var_3 = dict_unpacking_transformer_1.visit_Module(module_x_var_2)

# Generated at 2022-06-25 22:10:57.105255
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:11:06.194782
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module([module_0.Expr(module_0.Dict([], []))])
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    module_0.Module([module_0.Expr(module_0.Dict([], []))])
    module_x_var_2 = module_0.Module([module_0.Expr(module_0.Dict([], []))])
    module_0.Module([module_0.Expr(module_0.Dict([], []))])
    module_

# Generated at 2022-06-25 22:11:09.972536
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:11:15.656463
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:11:17.409995
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

if __name__ == '__main__':
    import sys

    sys.exit(unittest.main())

# Generated at 2022-06-25 22:11:24.564288
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Imports from typed_ast
    from typed_ast import ast3 as ast
    from typing import Union
    # Content of test case
    module_x_var_0 = ast.Module()
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    # End of content of test case
    assert not dict_unpacking_transformer_0._tree_changed


# Generated at 2022-06-25 22:11:29.496432
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:11:30.258675
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()


# Generated at 2022-06-25 22:11:37.491234
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.a_s_t_0 is a_s_t_0


# Generated at 2022-06-25 22:11:51.269483
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()

    a_s_t_0 = module_0.AST()

    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Dummy test for get_body of snippet

# Generated at 2022-06-25 22:11:54.842901
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_a_s_t_0 = module_0.AST()
    test_DictUnpackingTransformer_0 = DictUnpackingTransformer(test_a_s_t_0)
    test_Dict_0 = module_0.Dict(keys=[], values=[])
    test_DictUnpackingTransformer_0.visit_Dict(test_Dict_0)

# Generated at 2022-06-25 22:11:59.206449
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)



# Generated at 2022-06-25 22:12:02.996655
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_0 = ast.parse('')
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = dict_unpacking_transformer_0.visit_Module(module_0)



# Generated at 2022-06-25 22:12:04.099066
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

# Unit tests for class DictUnpackingTransformer

# Generated at 2022-06-25 22:12:07.687691
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:12:09.376832
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

# vim: set ts=8 sw=4 sts=4 expandtab :

# Generated at 2022-06-25 22:12:15.708633
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)
    assert len(module_x_var_1.body) > 0


# Generated at 2022-06-25 22:12:25.247529
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    {1: 1, **{3: 3}}
    {1: 1, **{3: 3}, **{4: 4}}
    {1: 1, **{3: 3}, **{4: 4}, **{5: 5}}
    {1: 1, 2: 2, **{3: 3}, **{4: 4}}
    {1: 1, 2: 2, **{3: 3}, **{4: 4}, **{5: 5}}
    {1: 1, 2: 2, 3: 3, **{4: 4}}
    {1: 1, 2: 2, 3: 3, **{4: 4}, **{5: 5}}
    {1: 1, 2: 2, 3: 3, 4: 4, **{5: 5}}

# Generated at 2022-06-25 22:12:30.517068
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.Module()
    node = ast.Dict(keys=[None, None], values=[ast.Call(func=ast.Name(id='a'), args=[], keywords=[]), ast.Call(func=ast.Name(id='b'), args=[], keywords=[])])
    transformer = DictUnpackingTransformer()
    transformer.visit_Dict(node)


# Generated at 2022-06-25 22:12:48.491614
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()



# Generated at 2022-06-25 22:12:54.605584
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # ensure hasattr(dict_unpacking_transformer_0, '_tree_changed')
    test_case_0()
    assert hasattr(dict_unpacking_transformer_0, '_tree_changed')
    assert not dict_unpacking_transformer_0._tree_changed

# Generated at 2022-06-25 22:12:58.971425
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert type(module_x_var_1) is module_0.Module


# Generated at 2022-06-25 22:13:03.985660
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:13:05.377226
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:13:07.661985
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:13:12.250112
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:13:13.151546
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:13:18.698506
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_1 = module_0.Module()

    ast_1 = module_0.AST()

    dict_unpacking_transformer_1 = DictUnpackingTransformer(ast_1)

    dict_0 = module_0.Dict([], [])

    ret_val_0 = dict_unpacking_transformer_1.visit_Dict(dict_0)

    assert type(ret_val_0) == module_0.Dict

    dict_1 = module_0.Dict([None], [module_0.Name(id='a')])

    ret_val_1 = dict_unpacking_transformer_1.visit_Dict(dict_1)

    assert type(ret_val_1) == module_0.Call


# Generated at 2022-06-25 22:13:24.584775
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_1 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_1)


# Generated at 2022-06-25 22:14:03.073353
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:14:03.821767
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:14:06.755005
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:14:10.898281
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_1 = module_0.Dict()
    dict_x_var_2 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_1)

# Generated at 2022-06-25 22:14:15.647320
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:14:23.164483
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = source = '''
        print({1: 1, 2: 2, **{3: 3}})
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], {3: 3})
    '''

    def run_test(tr):
        source = source = '''
            print({1: 1, 2: 2, **{3: 3}})
        '''
        expected = '''
            _py_backwards_merge_dicts([{1: 1, 2: 2}], {3: 3})
        '''

# Generated at 2022-06-25 22:14:28.750021
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

from ..utils.tree import tree



# Generated at 2022-06-25 22:14:33.872861
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # test if class DictUnpackingTransformer was properly constructed
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = ast.Module()
    module_x_var_0 = dict_unpacking_transformer_0.visit_Module(module_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:14:39.837310
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:14:44.520407
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_0.keys = None
    dict_0.values = None
    dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:16:09.115133
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_2 = DictUnpackingTransformer(module_0.AST())


# Generated at 2022-06-25 22:16:13.679255
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    node_x_var_0 = module_0.Dict()
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0.visit_Dict(node_x_var_0)
    dict_unpacking_transformer_0._tree_changed = False

# Generated at 2022-06-25 22:16:18.083100
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:16:23.029900
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    try:
        assert False
    except AssertionError:
        print('AssertionError raised')


# Generated at 2022-06-25 22:16:27.582007
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:16:30.882209
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:16:35.479944
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:16:40.089956
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    return (module_x_var_0, module_x_var_1)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:16:45.007360
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert (dict_unpacking_transformer_0 == dict_unpacking_transformer_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert (module_x_var_1.body[0].targets[0].id == '_py_backwards_merge_dicts')


# Generated at 2022-06-25 22:16:49.086947
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_tree = module_0.parse('def f():\n    x = {1: 1, **{}, 2: 2}\n')
    test_ast = module_0.AST(test_tree)
    test_transformer = DictUnpackingTransformer(test_ast)

    assert test_transformer._tree_changed
    assert str(test_ast) == '<Module[<FunctionDef[<arguments><Assign[<Name()><Call[<Name()><List><Dict><Dict><int()><int()><int()><int()>]>]>]>]>'