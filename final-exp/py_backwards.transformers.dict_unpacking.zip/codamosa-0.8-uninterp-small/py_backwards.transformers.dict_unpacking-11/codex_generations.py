

# Generated at 2022-06-25 22:07:34.690305
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"
    # assert False, "Unimplemented"


# Generated at 2022-06-25 22:07:43.671758
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_0_1 = dict_unpacking_transformer_0.visit_Module(module_0_0)
    assert isinstance(module_0_1, module_0.Module)
    try:
        assert False
    except AssertionError:
        print('Expected:')
        print('    <Module lineno="1" col_offset="0">')
        print('        def _py_backwards_merge_dicts(dicts):')
        print('            result = {}')
        print('            for dict_ in dicts:')

# Generated at 2022-06-25 22:07:46.288325
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:07:54.240675
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    def visit_Dict_0(cls, node):
        pass
    setattr(DictUnpackingTransformer, 'visit_Dict', visit_Dict_0)
    assert_true(hasattr(DictUnpackingTransformer, 'visit_Dict'),
                'Method visit_Dict of class DictUnpackingTransformer not found')
    visit_Dict_0(dict_unpacking_transformer_0, module_0.Dict(keys=[], values=[]))


# Generated at 2022-06-25 22:08:01.505185
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0) # type: DictUnpackingTransformer
    dict_0 = module_0.Dict(keys=[None, module_0.Name(id='keys_0')],
                           values=[module_0.Num(n=1), module_0.Num(n=2)])
    dict_unpacking_transformer_0.visit_Dict(dict_0) # TypeError: visit_Dict() missing 1 required positional argument: 'node'


# Generated at 2022-06-25 22:08:08.747273
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # test for type not being list
    node_0 = module_0.Dict(keys=[module_0.Constant(value=3, kind=None)], values=[module_0.Constant(value=3, kind=None)])
    dict_unpacking_transformer_0.visit_Dict(node_0)
    dict_unpacking_transformer_0._tree_changed = True
    dict_unpacking_transformer_0.visit_Dict(node_0)

# Generated at 2022-06-25 22:08:14.127806
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[])
    dict_unpacking_transformer_0.visit(module_1)
    dict_unpacking_transformer_0.visit(module_1)

# Generated at 2022-06-25 22:08:19.634312
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[])
    module_2 = dict_unpacking_transformer_0.visit_Module(module_1)
    assert isinstance(module_2, module_0.Module)


# Generated at 2022-06-25 22:08:30.999440
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.parse("""\
x = {a: b, c: d, **{e: f, g: h, **{i: j, **{k: l}}}}""")
    module_1 = ast.parse("""\
x = _py_backwards_merge_dicts([{a: b, c: d}], {e: f, g: h, **{i: j, **{k: l}}})""")
    a_s_t_0 = module_0
    a_s_t_1 = module_1
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_0_0 = module_

# Generated at 2022-06-25 22:08:37.584489
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = module_0.Module()
    dict_unpacking_transformer_0.visit_Module(module_2)
    name_0 = module_0.Name()
    module_1.body = [name_0]
    module_2.body = [module_1]
    result_0 = dict_unpacking_transformer_0.visit_Dict(module_1)
    assert result_0 is module_1


# Generated at 2022-06-25 22:08:52.447138
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    a = module_0.Expr(value=module_0.Name(id='a', ctx=module_0.Load()))
    dict_1 = module_0.Dict(
        keys=[module_0.Num(n=1), None],
        values=[module_0.Num(n=1), a]
    )
    a_s_t_1.body[:] = [module_0.Expr(value=dict_1)]
    dict_unpacking_transformer_1.visit(a_s_t_1)


# Generated at 2022-06-25 22:09:01.686598
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[], values=[])
    dict_unpacking_transformer_0.visit_Dict(dict_0)

    dict_unpacking_transformer_0.visit_Dict(module_0.Dict(keys=[], values=[]))

    dict_unpacking_transformer_0.visit_Dict(module_0.Dict(keys=[module_0.Num(n=1)], values=[module_0.Num(n=1)]))


# Generated at 2022-06-25 22:09:11.108182
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '''{1: 1, **dict_a}'''
    transformed = '''_py_backwards_merge_dicts([{1: 1}], dict_a)'''

    transformed = ast.parse(transformed)  # type: ignore
    expected = compile(transformed, '<ast>', mode='exec')
    code_ast = compile(code, '<ast>', mode='eval')
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    visit_Dict_result = dict_unpacking_transformer_0.visit_Dict(code_ast)
    assert str(visit_Dict_result) == str(expected)


# Generated at 2022-06-25 22:09:20.430882
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_2 = a_s_t_0.Module(body=[])
    dict_unpacking_transformer_0.visit_Module(module_2)
    dict_3 = a_s_t_0.Dict(keys=[], values=[])
    dict_3 = dict_unpacking_transformer_0.visit(dict_3)

    # Verify that function visit_Dict returns a_s_t_0.Dict(keys=[], values=[])
    assert isinstance(dict_3, a_s_t_0.Dict)
    assert dict_3.keys == []
    assert dict_3.values == []



# Generated at 2022-06-25 22:09:25.547193
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.parse("if True:")
    a_s_t_2 = module_0.parse("{1: 1, **dict_a}")
    a_s_t_3 = ast.Dict(keys=[ast.Num(1), None],
                      values=[ast.Num(1),
                              ast.Name(id='dict_a', ctx=ast.Load())])
    a_s_t_4 = module_0.parse("_py_backwards_merge_dicts([{1: 1}], dict_a})")
    a_s_t_5 = module_0.parse

# Generated at 2022-06-25 22:09:29.518396
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.parse('DICT')
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0)

    dict_unpacking_transformer_0.visit_Dict(module_0)



# Generated at 2022-06-25 22:09:39.627759
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module()
    call_0 = a_s_t_0.Call()
    arguments_0 = [call_0]
    keywords_0 = []
    call_1 = a_s_t_0.Call(arguments_0, keywords_0)
    expr_0 = call_1
    ass_0 = a_s_t_0.Assign(expr_0)
    expr_1 = ass_0
    module_1.body.append(expr_1)
    module_2 = dict_unpacking_transformer_0.visit_Module(module_1)
    assert type

# Generated at 2022-06-25 22:09:49.365739
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # _py_backwards_merge_dicts([dict(kw1=1)], kw2=2)
    test_dict = module_0.Dict()
    test_dict.keys = [ module_0.Str(s = 'kw1')]
    test_dict.values = [ module_0.Num(n = '1')]
    test_call = module_0.Call()
    test_call.func = module_0.Name(id = 'dict')
    test_call.args = [test_dict]
    test_call.keywords = []
    test_call_0 = module_0.Call()
    test_call_0.func = module_0.Name(id = '_py_backwards_merge_dicts')

# Generated at 2022-06-25 22:09:58.163270
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)

    class_2 = module_0.ClassDef(name='Foo', body=[], decorator_list=[])
    dict_3 = module_0.Dict(keys=[], values=[])
    dict_4 = module_0.Dict(keys=[], values=[])
    dict_5 = module_0.Dict(keys=[], values=[])

    module_6 = module_0.Module(body=[class_2, dict_3, dict_4, dict_5])
    r_module_6 = dict_unpacking_transformer_1.visit_Module(module_6)


# Generated at 2022-06-25 22:10:02.922735
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_0 = module_0.Dict(keys=None, values=None)
    ast_1 = dict_unpacking_transformer_0.visit_Dict(ast_0)
    assert ast_1 == None


# Generated at 2022-06-25 22:10:22.865350
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    case_0_0_a_s_t_0 = module_0.AST()
    case_0_0_dict_unpacking_transformer_0 = DictUnpackingTransformer(case_0_0_a_s_t_0)
    case_0_0_module_0 = module_0.Module(body = [module_0.Assign(targets = [module_0.Name(id = 'var_0', ctx = module_0.Store())], value = module_0.Dict(keys = [module_0.Name(id = 'a', ctx = module_0.Load()), module_0.Name(id = 'b', ctx = module_0.Load())], values = [module_0.Num(n = 1), module_0.Num(n = 2)]))])
    case_

# Generated at 2022-06-25 22:10:24.494714
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:34.211849
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    # module
    module_1 = module_0.Module()

    # module.body
    body_0 = []
    module_1.body = body_0

    # expr_0
    expr_0 = module_0.Expr(value = module_0.Constant(value = 1))
    body_0.append(expr_0)

    # expr_1
    expr_1 = module_0.Expr(value = module_0.Constant(value = 1))
    body_0.append(expr_1)

    # expr_2
    # module.body[2].value
    # module.body[2].value.key


# Generated at 2022-06-25 22:10:43.984023
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()

    class B0(object):
        def visit(self, node):
            return node
    
    class B1(object):
        def visit(self, node):
            return node
    
    class B2(object):
        def visit(self, node):
            return node
    
    class B3(object):
        def visit(self, node):
            return node
    
    class B4(object):
        def visit(self, node):
            return node
    
    class B5(object):
        def visit(self, node):
            return node
    
    class B6(object):
        def visit(self, node):
            return node
    
    class B7(object):
        def visit(self, node):
            return node
    

# Generated at 2022-06-25 22:10:48.748242
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0._fields = ['a']
    node_0 = module_0.Dict(keys=[None, 'a', None], values=[])
    dict_unpacking_transformer_0.visit_Dict(node_0)


# Generated at 2022-06-25 22:10:54.667243
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(
        a_s_t_0)

    dict_0 = module_0.Dict(keys=[None], values=[None])
    mod = module_0.Module([None], None)
    mod.body = [dict_0]
    dict_unpacking_transformer_0.visit(mod)


# Generated at 2022-06-25 22:11:00.373973
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_node_0 = module_0.Dict(keys=[module_0.Num(n=1), None], values=[module_0.Num(n=1), module_0.Name(id='dict_a')])
    dict_unpacking_transformer_0.visit_Dict(ast_node_0)


# Generated at 2022-06-25 22:11:08.245877
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0.parse('''{1: 1, **dict_a}''', mode='eval')
    assert module_0.dump(dict_unpacking_transformer_0.visit(module_0.parse('''{1: 1, **dict_a}''', mode='eval'))) == 'Call(_py_backwards_merge_dicts, [List([Dict([(1, 1)], []), Call(dict, [Name(dict_a, Load())], [])], Load())], [])'


# Generated at 2022-06-25 22:11:08.745206
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    return None

# Generated at 2022-06-25 22:11:20.185056
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = str
    a_s_t_1 = module_0.AST()
    _ast_to_str_0 = a_s_t_1.to_source
    str_1 = str
    a_s_t_2 = module_0.AST()
    typed_ast_parse_0 = a_s_t_2.parse
    a_s_t_3 = module_0.AST()
    _ast_to_str_1 = a_s_t_3.to_source
    a_s_t_4 = module_0.AST()
    # DictUnpackingTransformer.visit_Dict:

# Generated at 2022-06-25 22:11:25.908636
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = test_case_0()
    foo = None


# Generated at 2022-06-25 22:11:30.504429
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.tests.typed_ast_test_gen import TypedAstTestGen
    t = TypedAstTestGen(name='DictUnpackingTransformer',
                        version='3.4')
    NEGATIVE_CASES = (t.fail('pass'),)
    POSITIVE_CASES = (t.fail('pass'),)
    t.test(NEGATIVE_CASES, POSITIVE_CASES)


# Generated at 2022-06-25 22:11:38.042435
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    case_0 = module_0.Module(body=[None])
    a_s_t_0 = module_0.AST()  # type: ignore
    instance_0 = DictUnpackingTransformer(a_s_t_0)
    module_0.Module([], type_ignores=[])
    result_0 = instance_0.visit_Module(case_0)
    pass


# Generated at 2022-06-25 22:11:42.291944
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.Module()
    a_s_t_1 = module_0.Module()
    t = DictUnpackingTransformer()
    a_s_t_0 = t.visit_Module(a_s_t_0)
    # assert a_s_t_0 == a_s_t_1


# Generated at 2022-06-25 22:11:47.775510
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
   dict_unpacking_transformer_0 = DictUnpackingTransformer()
   module_0_0 = module_0.Module([], lineno=1, col_offset=0)
   module_0_1 = module_0.Module([], lineno=1, col_offset=0)
   dict_unpacking_transformer_0.visit(module_0_1)
   assert module_0_0 == module_0_1


# Generated at 2022-06-25 22:11:48.889818
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass


# Generated at 2022-06-25 22:11:51.502328
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    my_transformer_0 = DictUnpackingTransformer()
    my_ast_0 = test_case_0()
    res = my_transformer_0.visit_Module(my_ast_0)

# Generated at 2022-06-25 22:11:53.177770
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    _args = ()
    _kwargs = {}
    return DictUnpackingTransformer(*_args, **_kwargs)


# Generated at 2022-06-25 22:11:57.313075
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Create an instance of DictUnpackingTransformer
    # Assert that DictUnpackingTransformer.generic_visit is the initial generic_visit
    assert DictUnpackingTransformer.generic_visit.__name__ == 'generic_visit'
    # Assert that DictUnpackingTransformer.target is (3, 4)
    assert DictUnpackingTransformer.target == (3, 4)


# Generated at 2022-06-25 22:11:59.206122
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    DictUnpackingTransformer().visit_Dict(a_s_t_0)
    assert True



# Generated at 2022-06-25 22:12:05.753682
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
  tree = module_0.parse("{1: 1, 2: 2, **{3: 3, 4: 4}}", mode='eval')
  DictUnpackingTransformer(tree).run()
  assert '_py_backwards_merge_dicts' in ast.dump(tree)

# Generated at 2022-06-25 22:12:14.658265
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node_var_0 = module_0.Dict()
    node_var_0.keys = [None]
    node_var_0.values = [None]
    node_var_0.ctx = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0.AST())
    node_var_1 = dict_unpacking_transformer_0.visit_Dict(node_var_0)

    assert isinstance(node_var_1, module_0.Call)
    assert node_var_1.func.id == '_py_backwards_merge_dicts'

    assert len(node_var_1.args) == 1
    assert isinstance(node_var_1.args[0], module_0.List)

# Generated at 2022-06-25 22:12:24.363676
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

if __name__ == "__main__":
    import typing
    import inspect
    import sys
    for name in dir(typing):
        item = getattr(typing, name)
        if not hasattr(item, "__module__"):
            continue
        if getattr(item, "__module__") != "typing":
            continue
        if inspect.isclass(item):
            test_func = globals().get('test_' + name)
            if test_func is None:
                print(f"creating test for {name}")
                test_func = lambda: None
                func_text = f"""def test_{name}():
    test_case_0()
"""
                exec(func_text, globals())

# Generated at 2022-06-25 22:12:28.637246
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0 is not None

# Unit testing of constructor of class DictUnpackingTransformer

# Generated at 2022-06-25 22:12:37.356873
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    module_x_var_0.body.append(module_0.Expr(value=module_0.Dict(keys=[], values=[])))
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1.body[0].value.keys == []
    assert module_x_var_1.body[0].value.values == []

module_x_var_2 = module_0.Module()

# Generated at 2022-06-25 22:12:42.984320
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0._tree_changed == False
    assert dict_unpacking_transformer_0.a_s_t == a_s_t_0
    assert dict_unpacking_transformer_0.target == (3, 4)


# Generated at 2022-06-25 22:12:52.306633
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import os
    import typed_ast.ast3
    from flake8.api import legacy as flake8
    style_guide = flake8.get_style_guide(
        select=['T000'],
        exclude=['C,E,F,W,N'],
        filename=[os.path.join(
            os.path.dirname(__file__),
            'test_DictUnpackingTransformer.py'
        )],
        show_source=True
    )
    report = style_guide.check_files()
    if report.total_errors != 0:
        from flake8.formatting import base as formatting
        report._application.formatter = formatting.Default(report._application)
        report.print_statistics()

# Generated at 2022-06-25 22:12:57.619128
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    dict_0 = module_0.Dict(keys=[None], values=[
        module_0.Dict(keys=[], values=[])
    ])
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:13:03.051265
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[None], values=[module_0.Num(n = 1)])
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:13:04.034714
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:13:14.441928
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:13:25.383844
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Setup
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[module_0.Name(id='_x'), module_0.Name(id='_y')],
values=[module_0.Num(n=1), module_0.Num(n=2)])
    # Exercise
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    # Verify
    print('module_x_var_1', module_x_var_1)
    dict_1 = module_x_var_1

# Generated at 2022-06-25 22:13:33.767233
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    dict_x_var_0 = module_0.Dict()
    dict_x_var_0.keys = [None for i in range(random.randint(1,10))]
    dict_x_var_0.values = [None for i in range(random.randint(1,10))]
    dict_unpacking_transformer_0 = DictUnpackingTransformer(dict_x_var_0)
    dict_unpacking_transformer_0.visit_Dict(module_x_var_0)

# Generated at 2022-06-25 22:13:36.296402
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    try:
        module_0.AST()
    except Exception:
        assert False

    try:
        DictUnpackingTransformer(module_0.AST())
    except Exception:
        assert False



# Generated at 2022-06-25 22:13:45.066105
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)
    assert (DictUnpackingTransformer.__module__ 
            == DictUnpackingTransformer.__module__)
    assert (DictUnpackingTransformer.__doc__ 
            == DictUnpackingTransformer.__doc__)
    assert (DictUnpackingTransformer.__qualname__ 
            == DictUnpackingTransformer.__qualname__)
    assert (DictUnpackingTransformer.__init__.__qualname__ 
            == DictUnpackingTransformer.__init__.__qualname__)



# Generated at 2022-06-25 22:13:48.737972
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:13:53.235962
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    assert(module_x_var_0 is not None)
    a_s_t_0 = module_0.AST()
    assert(a_s_t_0 is not None)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert(dict_unpacking_transformer_0 is not None)

# Generated at 2022-06-25 22:13:57.412321
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[None, None], values=[None, None])
    module_x_var_2 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:14:03.513335
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:14:10.931886
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    dict_0 = module_0.Dict(keys=[], values=[])
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    dict_2 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    dict_4 = module_0.Dict(keys=[], values=[])
    dict_3 = dict_unpacking_transformer_0.visit_Dict(dict_4)

# Generated at 2022-06-25 22:14:30.311750
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:14:34.854002
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[None], values=[])
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    print(module_x_var_1)

# Generated at 2022-06-25 22:14:35.751492
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:14:41.503161
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:14:49.293108
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # test case 1
    module_0 = ast.Module()
    d = ast.Dict(keys=[None, None, None],
                 values=[ast.Call(func=ast.Name(id='d'), args=[], keywords=[]),
                         ast.Num(n=1),
                         ast.Name(id='2')])
    module_1 = DictUnpackingTransformer().visit(module_0)
    assert module_1.body[0].value == ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(
            elts=[ast.Call(func=ast.Name(id='dict'), args=[d], keywords=[])])],
        keywords=[])

# Generated at 2022-06-25 22:14:51.674355
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_0.Module()
    module_0.AST()
    DictUnpackingTransformer()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:14:52.452702
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:14:59.992972
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module(body=[])
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == module_x_var_0
    module_x_var_0 = module_0.Module()
    assert module_x_var_0.body == []
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1.body == module_x_var_0.body

# Generated at 2022-06-25 22:15:04.609955
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:15:07.587282
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    return True or True


# Generated at 2022-06-25 22:15:47.392614
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    ast_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(ast_0)


# Generated at 2022-06-25 22:15:52.342327
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = module_0.Dict()
    module_x_var_3 = dict_unpacking_transformer_0.visit_Dict(module_x_var_2)


# Generated at 2022-06-25 22:15:56.329118
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:16:00.520411
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:16:02.865957
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:16:03.585893
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:16:06.510614
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    return


# Generated at 2022-06-25 22:16:11.628015
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

    assert 0 == len(module_x_var_0.body)
    assert 0 == module_x_var_0.type_ignores


# Generated at 2022-06-25 22:16:12.342992
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:16:16.094871
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.target == (3, 4)
