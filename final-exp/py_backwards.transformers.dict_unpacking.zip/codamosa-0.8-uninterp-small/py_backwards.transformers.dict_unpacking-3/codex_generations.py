

# Generated at 2022-06-25 22:07:31.081105
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:07:40.032755
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # test start
    a_s_t_0 = module_0.Dict(keys=[module_0.Name(id='None')], values=[module_0.Name(id='None')])
    a_s_t_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_0)
    assert a_s_t_0 is not None, "Expected not None."
    assert isinstance(a_s_t_0, module_0.Call), "Expected Call, got %s" % type(a_s_t_0)
    # test end
    # test start
    # test end

# Generated at 2022-06-25 22:07:43.125673
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Dict(None)


# Generated at 2022-06-25 22:07:50.811417
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    node_0 = a_s_t_0.parse('a = {}')
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0.fix_missing_locations(dict_unpacking_transformer_0.visit(node_0))

if __name__ == '__main__':
    import sys
    if sys.version_info < (3, 4):
        print('This test is for Python >= 3.4')
        sys.exit(0)
    test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:07:59.963257
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    temp_a_s_t_module_1 = a_s_t_1.parse('a = 1')
    temp_a_s_t_module_1.body.append(module_0.Expr(module_0.Call(module_0.Name('_py_backwards_merge_dicts', module_0.Load()), [module_0.List([]), module_0.Name('a', module_0.Load())])))
    temp_a

# Generated at 2022-06-25 22:08:07.310981
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[None], values=[module_0.Dict(keys=[], values=[])])
    a_s_t_2 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    assert isinstance(a_s_t_2, module_0.Call)

if sys.argv[-1] == "--test":
    test_case_0()
else:
    main()

# Generated at 2022-06-25 22:08:17.219098
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import _ast
    import typed_ast
    a_s_t_0 = typed_ast._ast3.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = typed_ast.ast3.Module()
    dict_1 = typed_ast.ast3.Dict(keys=[None], values=[None])
    typed_ast.ast3.fix_missing_locations(dict_1)
    call_2 = typed_ast.ast3.Call(func=dict_1, args=[], keywords=[], starargs=None, kwargs=None)
    typed_ast.ast3.fix_missing_locations(call_2)
    dict_3 = typed_ast.ast3.Dict(keys=[None], values=[call_2])

# Generated at 2022-06-25 22:08:28.469571
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0.Module(body=[], type_ignores=[])
    a_s_t_0.Module(body=[], type_ignores=[])
    module_0.Dict(keys=[], values=[])
    a_s_t_0.Dict(keys=[], values=[])
    case_0_keys = [
        None,
    ]
    case_0_values = [
        module_0.Dict(keys=[], values=[]),
    ]
    case_0_dict_0 = a_s_t_0.Dict(keys=case_0_keys, values=case_0_values)
    expected_

# Generated at 2022-06-25 22:08:35.214051
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    
    # Test data
    node_0 = a_s_t_0.parse('{True: False, None: True}', mode='eval')
    dict_unpacking_transformer_0.visit(node_0)
    assert repr(dict_unpacking_transformer_0._tree) == repr(a_s_t_0.parse('{True: False, None: True}', mode='eval'))

# Generated at 2022-06-25 22:08:41.935532
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.parse('def f():\n    {1: 1, **dict_a}\n    ')
    setattr(a_s_t_1, 'body', [module_0.parse('{1: 1, **dict_a}\n    ')])
    property_0 = getattr(module_0.parse('1'), 'n', None)
    setattr(module_0.parse('1'), 'n', property_0)
    property_1 = getattr(module_0.parse('1'), 'n', None)

# Generated at 2022-06-25 22:08:55.807883
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0_0 = module_0.Module([module_0.Dict([module_0.Num(1), module_0.Name('a', module_0.Load())], [module_0.Num(2), module_0.Name('b', module_0.Load())], [module_0.Num(3), module_0.Name('c', module_0.Load())], [module_0.Num(4), module_0.Name('d', module_0.Load())])])
    a_s_t_0_0 = module_0.AST()
    dict_unpacking_transformer_0_0 = DictUnpackingTransformer(a_s_t_0_0)

# Generated at 2022-06-25 22:09:08.578033
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-25 22:09:12.202057
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0.Module(body=[])


# Generated at 2022-06-25 22:09:18.896764
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    b_0 = module_0.Dict(keys=[None, None], values=[None, None])
    result_0 = dict_unpacking_transformer_0.visit_Dict(b_0)
    assert type(result_0) is module_0.Call


# Generated at 2022-06-25 22:09:23.677645
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[None], values=[module_0.Dict(keys=[], values=[])])
    dict_unpacking_transformer_0.visit(a_s_t_1)

# Generated at 2022-06-25 22:09:26.709343
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    import ast
    a_s_t_1 = ast.AST()
    dict_0 = a_s_t_1.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:09:33.524249
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:09:42.397802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[module_0.Num(n=1), None], values=[module_0.Num(n=1), module_0.Dict(keys=[], values=[])])
    result_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    dict_unpacking_transformer_0.visit_Name()
    dict_unpacking_transformer_0.visit_Str()
    dict_unpacking_transformer_0.visit_Bytes()
    dict_unpacking

# Generated at 2022-06-25 22:09:47.958410
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert dict_unpacking_transformer_0.tree_changed == False

# Generated at 2022-06-25 22:09:57.095230
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_0_1 = module_0.Module()

# Generated at 2022-06-25 22:10:04.235092
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer(__this_file__)
    dict_unpacking_transformer_0.visit_Dict(module_0.Dict(keys=[], values=[]))


# Generated at 2022-06-25 22:10:08.722896
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:11.284006
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_unpacking_transformer_0.visit_Dict(module_0.AST())


# Generated at 2022-06-25 22:10:20.589868
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # We need to make sure that the case when keys collection of dict AST node
    # contains at least one None value is handled properly. In this case the
    # call of _py_backwards_merge_dicts method is inserted at the location of
    # the dict node.
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[module_0.Num(n=1), None, module_0.Num(n=3)], values=[module_0.Num(n=1), module_0.Num(n=2), module_0.Num(n=3)], ctx=None)

# Generated at 2022-06-25 22:10:26.633217
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Set up
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    expr_0_0 = module_0.Name(id='a')
    expr_0_1 = module_0.Name(id='b')
    key_0_1 = module_0.Name(id='x')
    value_0_1 = module_0.Name(id='y')
    key_0_2 = None
    value_0_2 = module_0.Name(id='d')
    key_0_3 = module_0.Name(id='i')
    value_0_3 = module_0.Name(id='j')

# Generated at 2022-06-25 22:10:31.501793
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    a_s_t_2 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)


# Generated at 2022-06-25 22:10:38.753577
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[None, None], values=[None, None])
    a_s_t_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:10:46.408876
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module(body=[module_0.Dict(keys=[module_0.Constant(value=None), module_0.Constant(value=None), module_0.Constant(value=None), module_0.Constant(value=1)], values=[module_0.Dict(keys=[], values=[]), module_0.Dict(keys=[], values=[]), module_0.Dict(keys=[], values=[]), module_0.Constant(value=1)])])
    module_0_1 = dict_unpacking_transformer_0.visit(module_0_0)

# Generated at 2022-06-25 22:10:55.875248
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    a_s_t_1.keys = [module_0.Name(id='a', ctx=module_0.Load()), module_0.Num(n=1)]
    a_s_t_1.values = [module_0.Num(n=1), module_0.Name(id='a', ctx=module_0.Load())]
    a_s_t_2 = dict_unpacking_transformer_0.visit(a_s_t_1)

# Generated at 2022-06-25 22:11:02.847044
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = ast.Module((), ())
    module_1.body.append(ast.Dict([], []))
    module_1.body.append(ast.Dict([], []))
    try:
        dict_unpacking_transformer_0.visit(module_1)
        assert True
    except AssertionError as e:
        print("AssertionError raised: ", e)
        assert False


# Generated at 2022-06-25 22:11:21.428083
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0.body.append(module_0.Pass())

# Generated at 2022-06-25 22:11:30.058223
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_4 = module_0.Name()
    node_3 = module_0.Name()
    module_0.alias(module_0.Name, 'copy_location', module_0.copy_location)
    copy_location_0 = module_0.copy_location
    copy_location_0(node_3, node_4)
    module_0.alias(module_0.Name, 'lineno', module_0.lineno)
    lineno_0 = module_0.lineno
    module_0.alias(module_0.Name, 'col_offset', module_0.col_offset)
    col_offset_0 = module_

# Generated at 2022-06-25 22:11:31.147733
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_DictUnpackingTransformer_visit_Dict_0()


# Generated at 2022-06-25 22:11:43.082790
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    function_def_0 = module_0.FunctionDef(name='merge_dicts', body=[], decorator_list=[])
    module_1.body = [function_def_0]
    name_0 = module_0.Name(id='None', ctx=module_0.Load())
    dict_0 = module_0.Dict(keys=[name_0], values=[])
    call_0 = module_0.Call(func=module_0.Name(id='merge_dicts', ctx=module_0.Load()), args=[], keywords=[])
    module_2 = module

# Generated at 2022-06-25 22:11:52.255632
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    x_0 = module_0.Dict()
    result_0 = x_0
    module_0.Dict.assert_called_with(x_0)
    module_0.Dict.return_value.keys.index.assert_called_with(None)
    module_0.Dict.return_value.keys.index.return_value.__gt__.assert_called_with(0)

# Generated at 2022-06-25 22:12:00.515564
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast3_0 = module_0.Dict(keys=[1], values=[1])
    ast3_1 = dict_unpacking_transformer_0.visit_Dict(ast3_0)

    assert(isinstance(ast3_1, module_0.Dict))
    assert(ast3_1.keys == [1])
    assert(ast3_1.values == [1])
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:12:08.978920
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0)
    dict_0 = ast.Dict(elts=[], keywords=[], lineno=0, col_offset=0)
    dict_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    try:
        assert type(dict_0) == ast.Dict
        fail_0 = 0
        print(str(bool(fail_0)) + ': ' + 'lineno: ' + str(dict_0.lineno) + ', col_offset: ' + str(dict_0.col_offset))
        print('Expected: dict')
        print('Received: ' + str(type(dict_0)))
    except AssertionError:
        print

# Generated at 2022-06-25 22:12:18.140656
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    
    # Create AST object
    a_s_t_0 = module_0.AST()
    # Create _py_backwards_merge_dicts0 object
    module_0.Name('_py_backwards_merge_dicts', module_0.Load())
    # Create List object
    module_0.List(elts=[], ctx=module_0.Load())
    # Create Dict object
    module_0.Dict(keys=[], values=[])
    # Create _py_backwards_merge_dicts1 object
    module_0.Name('_py_backwards_merge_dicts', module_0.Load())
    # Create List object
    module_0.List(elts=[], ctx=module_0.Load())
    # Create Call object

# Generated at 2022-06-25 22:12:27.112316
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    graph_0 = {
        0: (1,),
        1: (2,)
    }
    node_0_0 = module_0.Dict(graph_0)
    node_1_0 = module_0.Assign(left=module_0.Name(id="module_0"), right=node_0_0)
    module_1_0 = module_0.Module(body=[node_1_0])
    node_2_0 = dict_unpacking_transformer_0.visit(module_1_0)

    assert node_2_0 == module_1_0

# Generated at 2022-06-25 22:12:36.197482
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:12:48.456107
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    # Check if there were any errors during the compilation


if __name__ == '__main__':
    test_case_0()
    # test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:12:56.931002
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:13:05.567133
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    a_s_t_0 = module_0.AST()
    module_0_0 = module_0.Module([])
    module_0_1 = dict_unpacking_transformer_0.visit_Module(module_0_0)
    dict_0_0 = module_0.Dict([], [])
    dict_0_1 = dict_unpacking_transformer_0.visit_Dict(dict_0_0)
    dict_0_2 = dict_unpacking_transformer_0.visit(dict_0_0)
    dict_0_3 = dict_unpacking_transformer_0.visit_Call(dict_0_0)
    
DictUnpackingTransformer_visit_Dict_0

# Generated at 2022-06-25 22:13:14.406393
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Call case 0.
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0.body = [module_0.Expr(value=module_0.Dict(keys=[module_0.Num(n=1), None, module_0.Num(n=3)], values=[module_0.Str(s='1'), module_0.Str(s='2'), module_0.Str(s='3')]))]
    actual_out_0 = dict_unpacking_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:13:25.049386
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    expr_0 = module_0.Name()
    expr_0.id = '_py_backwards_merge_dicts'
    expr_0.ctx = module_0.Load()
    expr_1 = module_0.Call()
    expr_1.func = expr_0
    expr_2 = module_0.List()
    expr_1.args = [expr_2]
    expr_1.keywords = []

if __name__ == '__main__':
    test_case_0()
    test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:13:31.083333
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    a_s_t_1 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(a_s_t_1)


# Generated at 2022-06-25 22:13:40.439552
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    node_0 = module_0.Module()
    module_0.Module.body
    ast_0 = module_0.Name()
    ast_0.id = 'string_0'
    ast_0.ctx = module_0.Load()
    ast_1 = module_0.Expr()
    node_0.body = [ast_1]
    ast_2 = module_0.Str()
    ast_2.s = 'string_1'
    ast_0.s = ast_2
    ast_1.value = ast_0
    assert dict_unpacking_transformer_0.visit(node_0) is node_0

# Generated at 2022-06-25 22:13:44.489788
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(elts=[], keywords=[])
    dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:13:48.738446
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module(body=[])
    try:
        dict_unpacking_transformer_0.visit_Dict(module_0_0)
    except Exception:
        raise RuntimeError('Test failed')


# Generated at 2022-06-25 22:13:56.681791
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    a_s_t_2 = module_0.AST()
    dict_1 = a_s_t_2.parse("{1: 1}")
    a_s_t_3 = module_0.AST()
    dict_2 = a_s_t_3.parse("{2: 1}")
    dict_3 = dict_2.body[0].value
    a_s_t_4 = module_0.AST()
    dict_4 = a_s_t_4.parse("{3: 1}")
    dict_5 = dict_4.body[0].value

# Generated at 2022-06-25 22:14:19.161432
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = True
    return dict_unpacking_transformer_0._tree_changed

# test_case_1
import typed_ast._ast3 as module_0
import typed_ast._ast3 as module_1

# Generated at 2022-06-25 22:14:22.830081
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # temp1_DictUnpackingTransformer_visit_Dict_0
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    # function call
    value = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:14:31.937067
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:14:37.225923
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    assert isinstance(dict_unpacking_transformer_0.visit_Dict(a_s_t_1), module_0.Dict)


# Generated at 2022-06-25 22:14:42.509996
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visitDict(dict_0)


# Generated at 2022-06-25 22:14:51.068420
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[None, 1], values=[module_0.Dict(keys=[], values=[]), module_0.Num(n=1)])
    module_0.copy_location(a_s_t_1, None)
    module_0.fix_missing_locations(a_s_t_1)
    a_s_t_2 = a_s_t_1
    assert (dict_unpacking_transformer_0.visit_Dict(a_s_t_1) == a_s_t_2)


# Generated at 2022-06-25 22:14:58.652219
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Build test AST
    module_0 = module_0.Module([module_0.Expr(module_0.Call(module_0.Name('test', module_0.Load()), [module_0.Dict(keys=[module_0.Num(1), module_0.None_()], values=[module_0.Name('1', module_0.Load()), module_0.Name('foo', module_0.Load())])], [], None, None))])

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:15:02.181843
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    a_s_t_2 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)

# Generated at 2022-06-25 22:15:11.735993
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    code_0 = None
    ast_0 = ast.parse(code_0)
    dict_unpacking_transformer_0.visit(ast_0)
    print('With preserving existing classes:')
    print(ast.dump(ast_0, include_attributes=True))
    print('Without preserving existing classes:')
    print(ast.dump(ast_0))
    code_2 = '{1: 1, **dict_a}'
    ast_2 = ast.parse(code_2)
    dict_unpacking_transformer_0.visit(ast_2)
    print('With preserving existing classes:')

# Generated at 2022-06-25 22:15:12.233812
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass

# Generated at 2022-06-25 22:15:27.641206
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Test visit_Module of class DictUnpackingTransformer"""
    s = '''
a = 1
'''
    node = ast.parse(s)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert transformer._tree_changed
    assert isinstance(result, ast.Module)
    assert len(result.body) == 2
    assert isinstance(result.body[0], ast.FunctionDef)
    assert result.body[0].name == '_py_backwards_merge_dicts'
    assert isinstance(result.body[1], ast.Assign)
    assert isinstance(result.body[1].value, ast.Num)
    assert result.body[1].targets[0].id == 'a'
    assert result.body[1].value.n

# Generated at 2022-06-25 22:15:29.360569
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:15:33.633195
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_1 = module_0.Module()
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    dict_unpacking_transformer_1.visit_Module(module_1)


# Generated at 2022-06-25 22:15:39.790002
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:15:42.439429
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ast_0 = module_0.AST()
    module_0_0 = module_0.Module()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(ast_0)
    var_0 = dict_unpacking_transformer_0.visit_Module(module_0_0)
    var_0.body.append(module_0_0)


# Generated at 2022-06-25 22:15:46.867148
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    try:
        arg_0 = module_0.AST()
        ret_0 = DictUnpackingTransformer(arg_0)
    except Exception as e:
        print(str(e))
        assert True == False


# Generated at 2022-06-25 22:15:49.374464
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Test constructor of class DictUnpackingTransformer, without parameter
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    return dict_unpacking_transformer_0


# Generated at 2022-06-25 22:15:52.077698
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = ast.Dict()
    ast_0 = ast.AST()
    dictUnpackingTransformer_0 = DictUnpackingTransformer(ast_0)
    var_0 = dictUnpackingTransformer_0.visit_Dict(dict_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:15:59.549790
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Compile array for argument of the test
    a_s_t_0 = module_0.AST()
    module_0.Module(body=[])
    array_0 = [module_0.Expr(value=module_0.Dict(keys=[], values=[]))]
    # Instantiate an instance of DictUnpackingTransformer
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Call visit_Module method of DictUnpackingTransformer class
    module_0.Module(body=[])
    var_0 = dict_unpacking_transformer_0.visit_Module(module_0.Module(body=array_0))


# Generated at 2022-06-25 22:16:02.336236
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:16:20.616402
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a})
    dict_2 = module_0.Dict(keys=[module_0.Num(n=1), module_0.Num(n=2)],
                           values=[module_0.Num(n=1), module_0.Num(n=2)])
    dict_1 = module_0.Dict(keys=[module_0.Num(n=1)],
                           values=[module_0.Num(n=1)])
    dict_0 = module_0.Dict()
    s_t_0 = module_0.Str(s='_py_backwards_merge_dicts')
    s_t_1 = module_0.Str(s='dict')
    a_s_t_

# Generated at 2022-06-25 22:16:22.912337
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Test exception raised
    with pytest.raises(TypeError, match=r".* missing 1 required positional argument: 'tree' .*"):
        DictUnpackingTransformer()


# Generated at 2022-06-25 22:16:24.997604
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:16:26.664706
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:16:30.061001
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Tests for class DictUnpackingTransformer

# Generated at 2022-06-25 22:16:33.084051
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert not hasattr(dict_unpacking_transformer_0, '_tree_changed')

test_case_0()

# Generated at 2022-06-25 22:16:36.352734
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:16:38.741672
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    ast_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(ast_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:16:39.396248
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:16:39.838991
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert True


# Generated at 2022-06-25 22:17:05.281396
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:17:09.370386
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(var_0, module_0.Dict) or var_0 is None

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:17:15.544214
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = ast.Dict()
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(var_0, ast.Call)
    assert var_0.func.id == '_py_backwards_merge_dicts'
    assert var_0.args[0].elts[0].keys == []
    assert var_0.args[0].elts[0].values == []

test_case_0()
test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:17:17.936934
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0


# Generated at 2022-06-25 22:17:21.591095
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    key_0 = list()
    value_0 = list()
    bit_or_1 = module_0.BitOr()
    dict_1 = module_0.Dict()
    dict_unpacking_transformer_0 = dict_unpacking_transformer_0.visit_Dict(dict_0, key_0, value_0, bit_or_1, dict_1)

# Generated at 2022-06-25 22:17:27.711225
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert type(dict_0) == module_0.Dict
    assert type(a_s_t_0) == module_0.AST
    assert type(dict_unpacking_transformer_0) == DictUnpackingTransformer
    assert type(var_0) == module_0.Dict
