

# Generated at 2022-06-25 22:07:36.209607
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    a_s_t_2 = module_0.Dict()
    # prepare ast
    ast_0 = a_s_t_1
    ast_1 = a_s_t_2

# Generated at 2022-06-25 22:07:43.409948
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Dict(keys=[None, ast.Num(n=1)], values=[ast.Str(s='a'), ast.Num(n=1)])
    str_0 = str(dict_unpacking_transformer_0.visit_Dict(a_s_t_1))
    assert str_0 == "_py_backwards_merge_dicts([{1: 1}], {'a': 1})"


# Generated at 2022-06-25 22:07:52.764853
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:07:57.844703
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[], values=[])
    a_s_t_2 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)


# Generated at 2022-06-25 22:08:06.382280
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Test case where kwarg unpacking is not present
    expr_0 = a_s_t_0.parse('{1: 1}').body[0]
    expr_1 = dict_unpacking_transformer_0.visit_Dict(expr_0)
    assert '{1: 1}', expr_1.to_source.strip()
    # Test case where kwarg unpacking is present
    expr_0 = a_s_t_0.parse('{1: 1, **dict_a}').body[0]
    expr_1 = dict_unpacking_transformer_0.visit_Dict(expr_0)


# Generated at 2022-06-25 22:08:11.467497
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    a_s_t_1 = module_0.Dict(keys=[],
                            values=[])

    dict_unpacking_transformer_0.visit(a_s_t_1)


# Generated at 2022-06-25 22:08:17.592637
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    d_i_c_t_0 = ast.Dict()
    d_i_c_t_0.keys.append(None)
    d_i_c_t_0.values.append(ast.NameConstant(value=None, kind=None))
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_0 = dict_unpacking_transformer_0.visit_Dict(d_i_c_t_0)

# Generated at 2022-06-25 22:08:28.858015
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_1 = module_0.Dict()
    dict_2 = module_0.Dict()
    dict_3 = module_0.Dict()
    dict_4 = module_0.Dict()
    dict_5 = module_0.Dict()
    dict_6 = module_0.Dict()
    dict_7 = module_0.Dict()
    dict_8 = module_0.Dict()
    dict_9 = module_0.Dict()
    dict_10 = module_0.Dict()
    dict_11 = module_0.Dict()


# Generated at 2022-06-25 22:08:34.042155
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    
    module_0_0 = module_0.Module()
    
    
    
    
    
    
    
    
    
    
    dict_unpacking_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:08:37.972106
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = module_0.Module([], [])
    any_0 = dict_unpacking_transformer_0.visit_Module(module_0)
    assert any_0 is not None
    assert any_0 == module_0


# Generated at 2022-06-25 22:08:52.407636
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys = [], values = [])
    dict_unpacking_transformer_0.visit_Dict(a_s_t_1)

# Generated at 2022-06-25 22:08:58.210477
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Dict(keys=[], values=[])
    expect_0 = module_0.Dict(keys=[], values=[])
    dict_unpacking_transformer_0.visit_Dict(node_0)


# Generated at 2022-06-25 22:09:04.606985
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assertequal = assertEqual

    class Module_0(module_0.Module):
        _fields = ('body',)
        def __init__(self, body, lineno=1, col_offset=0):
            assertequal(lineno, 1)
            assertequal(col_offset, 0)
            self.body = body
            assertequal(lineno, 1)
            assertequal(col_offset, 0)
        def __str__(self):
            return ""
        def __repr__(self):
            return "Module(%r, %r, %r)" % (self.body, self.lineno, self.col_offset)
        _attributes = ('lineno', 'col_offset')
        __slots__ = ('lineno', 'col_offset')

# Generated at 2022-06-25 22:09:12.886187
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # No change in case no unpacking argument is present
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Dict(keys=None, values=None)
    node_1 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert node_1 == node_0
    
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    node_2 = module_0.Dict(keys=[], values=[])

# Generated at 2022-06-25 22:09:18.146677
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = ast.parse("{}")
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    dict_unpacking_transformer_1.visit(a_s_t_1)


# Generated at 2022-06-25 22:09:27.281712
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    result = dict_unpacking_transformer_0.visit_Dict(
        ast.parse('{1: 1, **dict_a}').body[0].value)

    assert isinstance(result, ast.Call)

    assert result.func.id == '_py_backwards_merge_dicts'
    assert isinstance(result.args[0], ast.List)
    assert isinstance(result.args[0].elts[0], ast.Dict)
    assert isinstance(result.args[0].elts[1], ast.Call)

    assert result.args[0].elts[0].keys[0].n == 1

# Generated at 2022-06-25 22:09:30.696991
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)

# Generated at 2022-06-25 22:09:37.209548
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    import astor as module_1
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1.to_source(dict_unpacking_transformer_0.visit(module_1.parse('[{1: 1, **dict_a}]')))


# Generated at 2022-06-25 22:09:42.909367
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    a_s_t_1.keys = list()
    a_s_t_1.values = list()
    a_s_t_2 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)


# Generated at 2022-06-25 22:09:46.268137
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert_equals(DictUnpackingTransformer._visit_Dict(DictUnpackingTransformer_0, dict_0), dict_merge_call_0)


# Generated at 2022-06-25 22:09:53.751770
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_5 = dict_unpacking_transformer_0.visit_Module(module_1)
    module_6 = module_0.Module(body=[])
    assert module_5 == module_6


# Generated at 2022-06-25 22:09:57.974755
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    DictUnpackingTransformer.visit_Module(dict_unpacking_transformer_0, module_0_0)


# Generated at 2022-06-25 22:10:02.388329
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    test_input = """\
x = {1, 2, 3}
y = {1: 'a', 2: 'b', **z, 4: 'c'}"""
    test_output = """\
_py_backwards_merge_dicts([{  1: 'a', 2: 'b'}, {4: 'c'}], z)"""
    
    tree = ast.parse(test_input)
    DictUnpackingTransformer().visit(tree)
    result = astor.to_source(tree)
    assert result == test_output

# Generated at 2022-06-25 22:10:10.892441
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([])
    try:
        result_0 = dict_unpacking_transformer_0.visit_Module(module_1)
    except Exception as exc_0:
        module_2 = module_0.Module([])
        assert module_2 == exc_0
    else:
        module_2 = module_0.Module([])
        assert result_0 == module_2

# Generated at 2022-06-25 22:10:15.653152
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0.Module(body=[])
    dict_unpacking_transformer_0.visit_Module(module_0.Module(body=[]))


# Generated at 2022-06-25 22:10:17.780112
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

import typed_ast._ast3 as module_1

import typed_ast._ast3 as module_2


# Generated at 2022-06-25 22:10:23.366286
# Unit test for constructor of class DictUnpackingTransformer

# Generated at 2022-06-25 22:10:31.052877
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_tokens = []
    expected_tokens = ['DEF', 'NAME', 'LPAR', 'NAME', 'RPAR', 'COLON', 'NEWLINE', 'INDENT', 'RETURN', 'NAME', 'NEWLINE', 'DEDENT', 'EOF']
    test_type_ignores = []
    expected_type_ignores = []
    test_skips = []
    expected_skips = [10, 11, 12]
    test_errors = []
    expected_errors = []

# Generated at 2022-06-25 22:10:39.330746
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    body_1 = [a_s_t_1.parse('def f():\n    pass')]
    node_1 = a_s_t_1.Module(body = body_1)
    ret_1 = dict_unpacking_transformer_1.visit_Module(node_1)


# Generated at 2022-06-25 22:10:43.333820
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:10:49.203366
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:51.730502
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:52.567503
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:11:01.916237
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    # Case 0
    # Case 0.1
    a_s_t_0.parse("a = 1")
    actual_0 = a_s_t_0.body.pop()
    actual_1 = a_s_t_0.body.pop()
    actual_2 = a_s_t_0.body.pop()
    expected_0 = None
    expected_1 = ['a = 1']
    expected_2 = False
    assert actual_0 == expected_0
    assert actual_1 == expected_1
    assert actual_2 == expected_2
    actual_0 = a_s_t_0.body.pop()
   

# Generated at 2022-06-25 22:11:08.476198
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1, dunders=True)
    a_s_t_2 = module_0.AST()
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_2, dunders=False)


# Generated at 2022-06-25 22:11:16.553019
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
  a_s_t_0 = module_0.AST()
  dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
  a_s_t_1 = module_0.Dict(keys=[], values=[])
  try:
    dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
  except BaseException as e:
    raise AssertionError() from e


# Generated at 2022-06-25 22:11:23.246346
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    body_0 = module_0.Module([])
    module_1 = module_0.Module(body_0)
    dict_0 = module_0.Dict(keys=[], values=[])
    if (dict_unpacking_transformer_0.visit_Dict(dict_0) is not dict_0):
        raise RuntimeError


# Generated at 2022-06-25 22:11:26.322977
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)



# Generated at 2022-06-25 22:11:28.578066
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    dict_unpacking_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:11:38.002606
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # {1: 1, **dict_a}
    # Should transform to:
    #     _py_backwards_merge_dicts([{1: 1}], dict_a})
    dict_0 = module_0.Dict(keys=[module_0.Constant(value=1)], values=[module_0.Constant(value=1)], lineno=0, col_offset=0)
    dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:11:54.179869
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as pyast
    import typed_ast.ast3 as typedast
    a_s_t_1 = typedast.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    visitor_method_0 = dict_unpacking_transformer_1.visit_Dict
    src_0 = pyast.parse("{1: 1, **dict_a}")
    assert hasattr(src_0.body[0].value, 'keys')
    assert hasattr(src_0.body[0].value, 'values')
    res_0 = visitor_method_0(src_0.body[0].value)
    assert hasattr(res_0, 'func')
    assert hasattr(res_0, 'args')

# Generated at 2022-06-25 22:11:55.136272
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer((None,)) is not None

# Generated at 2022-06-25 22:11:58.199394
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.tree == module_0.AST()


# Generated at 2022-06-25 22:12:06.263740
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test 1
    # Test case 1
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)

# Generated at 2022-06-25 22:12:10.730038
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = module_0.Module()
    dict(**{})
    
    assert dict_unpacking_transformer_0.visit_Module(module_0) is module_0



# Generated at 2022-06-25 22:12:19.654865
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    try:
        dict_unpacking_transformer_0.visit(module_0.Name(id='_py_backwards_merge_dicts', ctx=module_0.Load()))
    except:
        dict_unpacking_transformer_0.visit(module_0.Name(id='_py_backwards_merge_dicts', ctx=module_0.Load()))
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_0)
    dict_un

# Generated at 2022-06-25 22:12:29.818996
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    
    # Test 0 (dict unpacking)

    expected_0 = _py_backwards_merge_dicts([{1: 1}], {1: 1, **{1: 1}})
    test_0 = ast.parse('{\n    1: 1,\n    **{1: 1}\n}').body[0].value
    result_0 = dict_unpacking_transformer_0.visit_Dict(test_0)
    assert result_0 is not None
    assert result_0.__dict__ == expected_0

    # Test 1 (no dict unpacking)

    expected_1 = {1: 1}
    test_

# Generated at 2022-06-25 22:12:38.079259
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_cases = (
        (dict, 3, 2, None),
        ({1: 2}, 1, 2, {3: 4}),
        ({1: 2, None: {3: 4}}, 1, 2, {3: 4, **{5: 6}}),
        ({1: 2, None: {3: 4}, **{5: 6}}, 1, 2, {3: 4, **{5: 6, **{7: 8}}}),
    )
    for case in test_cases:
        ast_0 = module_0.AST()
        dict_unpacking_transformer_0 = DictUnpackingTransformer(ast_0)
        dict_unpacking_transformer_0.visit_Dict(case[0])
    

# Generated at 2022-06-25 22:12:48.006799
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert dict_unpacking_transformer_0._tree_changed == False
    dict_unpacking_transformer_0._tree_changed = False
    dict_0.keys = [None, None, None]
    dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert dict_unpacking_transformer_0._tree_changed == False
    dict_unpacking_transformer_0._tree_changed = False

# Generated at 2022-06-25 22:12:51.286411
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    assert(isinstance(DictUnpackingTransformer(a_s_t_0), \
        typed_ast.transforms.DictUnpackingTransformer.DictUnpackingTransformer))

# Generated at 2022-06-25 22:13:13.653075
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    module_0 = module_0.Module(body=[])
    a_s_t_0 = module_0.Module(body=[])
    dict_unpacking_transformer_0._generic_visit = lambda arg_0: arg_0

    result = dict_unpacking_transformer_0.visit_Dict(a_s_t_0)

    assert result.body == []
    assert isinstance(result, module_0.Module)


# Generated at 2022-06-25 22:13:25.228696
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:13:29.784325
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 22:13:33.312694
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:13:38.169087
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    dict_unpacking_transformer_0._tree_changed = bool()
    dict_unpacking_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:13:43.052572
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([module_0.Expr(module_0.BinOp(module_0.Num(1), module_0.Add(), module_0.Num(1)))])
    dict_unpacking_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:13:51.000641
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class_0 = DictUnpackingTransformer
    method_0 = class_0.visit_Module
    isinstance_0 = isinstance
    import ast
    module_0 = ast
    class_1 = module_0.Module
    def f_0():
        module_1 = ast
        class_2 = module_1.Name
        expr_0 = class_2(
            id='_py_backwards_merge_dicts', lineno=1, col_offset=0
        )
        class_3 = module_1.List
        class_4 = module_1.List
        expr_1 = class_4(elts=[])
        a_s_t_0 = module_0.AST()

# Generated at 2022-06-25 22:13:54.456034
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Testing class constructor
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

if __name__ == '__main__':
    test_case_0()
    test_DictUnpackingTransformer()

# Generated at 2022-06-25 22:13:57.446547
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert(dict_unpacking_transformer_0 != None)


# Generated at 2022-06-25 22:14:06.517001
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree

    node = ast.Module([
        ast.Assign(
            targets=[ast.Name(id='a')],
            value=ast.Dict(keys=[ast.Num(n=1), None],
                           values=[ast.Num(n=1), ast.Name(id='b')]))
    ])

    tr = DictUnpackingTransformer(node)
    new_node = tr.visit(node)

    assert tr._tree_changed

# Generated at 2022-06-25 22:14:42.611036
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:14:43.538446
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass


# Generated at 2022-06-25 22:14:49.854774
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_0 = module_0.Dict(keys=[None], values=[])
    ast_1 = dict_unpacking_transformer_0.visit_Dict(ast_0)
    assert ast_1 == module_0.Call(args=[module_0.Dict(keys=[], values=[])], keywords=[], func=module_0.Name(id='_py_backwards_merge_dicts'))


# Generated at 2022-06-25 22:14:53.601542
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_1 = module_0.Module()
    dict_unpacking_transformer_1.visit_Module(module_1)


# Generated at 2022-06-25 22:15:00.962889
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = module_0.Call()
    call_1.func = call_0
    slice_0 = module_0.Index()
    call_1.slice = slice_0
    slice_1 = module_0.Slice()
    call_2 = module_0.Call()
    slice_1.upper = call_2
    call_1.slice = slice_1
    call_3 = module_0.Call()
    call_3.func = call_0
    slice_2 = module_0.Index()
    call_3.slice = slice_2

# Generated at 2022-06-25 22:15:06.753434
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    with pytest.raises(Exception): # visit_Module should raise the exception
        dict_unpacking_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:15:08.907532
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return

if __name__ == '__main__':
    import sys
    import __main__
    sys.modules[__main__.__name__] = __main__
    import pytest
    pytest.main()

# Generated at 2022-06-25 22:15:12.828375
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    dict_unpacking_transformer_0.visit(a_s_t_1)


# Generated at 2022-06-25 22:15:19.108574
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    some_module_0 = module_0.Module(
        body=[],
        type_ignores=[],
    )

    some_dict_0 = module_0.Dict(
        keys=[module_0.Num(n=1.0)],
        values=[module_0.Num(n=1.0)],
    )

    some_call_0 = module_0.Call(
        func=module_0.Name(id='_py_backwards_merge_dicts'),
        args=[module_0.List(elts=[module_0.Dict(keys=[module_0.Num(n=1.0)], values=[module_0.Num(n=1.0)])])],
        keywords=[],
    )


# Generated at 2022-06-25 22:15:23.696248
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = ast.Dict( )
    dict_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert type(dict_0) is ast.Dict


# Generated at 2022-06-25 22:16:08.847619
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    pass


# Generated at 2022-06-25 22:16:16.412433
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astroid
    import pylint
    module_name = 'typed_ast.transforms'
    module_info = pylint.lint.Run.get_module_file_from_name(module_name)
    module_file = module_info.name
    module = astroid.parse(module_name, module_file)
    for class_def in module.body:
        if not isinstance(class_def, astroid.ClassDef):
            continue
        if class_def.name != 'DictUnpackingTransformer':
            continue
        for method_def in class_def.body:
            if not isinstance(class_def, astroid.FunctionDef):
                continue
            if method_def.name == 'visit_Dict':
                break
    else:
        raise AssertionError()

   

# Generated at 2022-06-25 22:16:19.463217
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:16:23.740552
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module;
    a_s_t_0 = module_0.AST();
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0);
    dict_0 = module_0.Dict();
    dict_unpacking_transformer_0.visit_Module(dict_0);

test_case_0()

# Generated at 2022-06-25 22:16:27.090856
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0 is not None


# Generated at 2022-06-25 22:16:29.168418
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:16:30.125158
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_0
    DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:16:31.606669
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    try:
        test_case_0()
    except:
        print('Exception caught in test_case_0')


# Generated at 2022-06-25 22:16:39.277418
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # https://docs.python.org/3/library/typed_ast.html#typed_ast.ast3.Module
    module_0 = ast.Module([], lineno=0, col_offset=0)

    # https://docs.python.org/3/library/typed_ast.html#typed_ast.ast3.AST
    a_s_t_0 = ast.AST()

    # class DictUnpackingTransformer(BaseNodeTransformer)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    #
    # https://docs.python.org/3/library/typed_ast.html#typed_ast.ast3.Module
    module_x_var_0 = module_0
    #
    # https://docs.python.

# Generated at 2022-06-25 22:16:41.289441
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0
