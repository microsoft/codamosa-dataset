

# Generated at 2022-06-25 22:07:23.761131
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test case 1
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = ast.Dict(keys=[ast.Num(n=1), None, ast.Str(s='second')], values=[ast.Num(n=1), ast.Dict(keys=[ast.Str(s='key')], values=[ast.Str(s='value')]), ast.Str(s='value')])
    res_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:07:24.597129
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass



# Generated at 2022-06-25 22:07:29.306961
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    arg_0 = ast.Module([], [])
    var_0 = dict_unpacking_transformer_0.visit_Module(arg_0)
    print(var_0)



# Generated at 2022-06-25 22:07:37.093164
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    input_0 = ast.parse(
        "foo(a={'bar': 123, 'baz': None, **'some-dict', 'whut': 1})").body[0]
    expected_0 = ast.parse(
        "foo(a=_py_backwards_merge_dicts([{'bar': 123, 'baz': None, 'whut': 1}], 'some-dict'))"
    ).body[0]
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    result = dict_unpacking_transformer_0.visit(input_0)
    assert ast.dump(result) == ast.dump(expected_0)



# Generated at 2022-06-25 22:07:45.797217
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    import astor
    module_0 = ast.parse('{a: 1, **{}}')
    dict_unpacking_transformer_0._tree_changed = True
    dict_unpacking_transformer_0._tree_changed = True
    dict_unpacking_transformer_0._tree_changed = True
    dict_unpacking_transformer_0.generic_visit = lambda x1: x1
    dict_unpacking_transformer_0.generic_visit = lambda x1: x1
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_

# Generated at 2022-06-25 22:07:51.689322
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Line number: 541
    # Function name: visit_Dict
    # Test case number: 0
    a_s_t_0 = ast.Dict(keys=[None], values=[None])
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    result = dict_unpacking_transformer_0.visit_Dict(a_s_t_0)
    assert result is None


# Generated at 2022-06-25 22:07:59.925587
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    _py_backwards_merge_dicts = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(_py_backwards_merge_dicts)
    ast_dict_0 = Dict()
    ast_dict_0.keys = [1]
    ast_dict_0.values = [1]
    ast_dict_1 = Dict()
    ast_dict_1.keys = [None]
    ast_dict_1.values = [1]
    assert dict_unpacking_transformer_0.visit_Dict(ast_dict_0) == ast_dict_0
    assert dict_unpacking_transformer_0.visit_Dict(ast_dict_1) == ast_dict_1

# Generated at 2022-06-25 22:08:05.807631
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree_0 = ast.parse('{1: 1, 2: 2, **x}')
    expected_0 = ast.parse(
        """
        {1: 1, **_py_backwards_merge_dicts([{2: 2}], x)}
        """.strip()
    )
    dict_unpacking_transformer_0 = DictUnpackingTransformer(tree_0)
    tree_1 = dict_unpacking_transformer_0.visit_Module(tree_0)
    assert tree_1 == expected_0

# Generated at 2022-06-25 22:08:15.281030
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # A case: test when value with `None` is in middle of dict
    dict_unpacking_transformer_0 = DictUnpackingTransformer(None)
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0.visit_Module(ast.parse("{1: 1, **dict_a}"))
    dict_unpacking_transformer_0.visit_Dict(ast.Dict(keys=[None], values=[dict_a]))
    assert dict_unpacking_transformer_0._tree_changed is False
    # A case: test when value with `None` is at the end of dict
    dict_unpacking_transformer_0 = DictUnpackingTransformer(None)
    dict_unpacking_transformer_0._tree_changed = False
    dict

# Generated at 2022-06-25 22:08:26.663029
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    source_code_0 = [0]
    source_code_1 = [-1]
    source_code_2 = [0]
    source_code_3 = [0]
    source_code_4 = [0]
    source_code_5 = [0]
    source_code_6 = [0]
    source_code_7 = [0]
    source_code_8 = [0]
    source_code_9 = [0]
    source_code_10 = [0]
    source_code_11 = [0]
    source_code_12 = [0]
    source_code_13 = [0]

# Generated at 2022-06-25 22:08:32.464722
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer((3, 4)).target == (3, 4)
    assert DictUnpackingTransformer(3, 4).target == (3, 4)
    assert DictUnpackingTransformer.target == (3, 4)


# Generated at 2022-06-25 22:08:37.312402
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = dict_unpacking_transformer_0.visit_Dict(module_x_var_1)

# Generated at 2022-06-25 22:08:38.370324
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

import astunparse as module_2


# Generated at 2022-06-25 22:08:43.206904
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:08:47.238083
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)


# Generated at 2022-06-25 22:08:56.698190
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

if __name__ == '__main__':
    import sys
    if len(sys.argv) == 2 and sys.argv[-1] == '-v':
        print('test_case_0()')
        print('test_DictUnpackingTransformer_visit_Module()')
    else:
        test_case_0()
        test_DictUnpackingTransformer_visit_Module()

# Generated at 2022-06-25 22:08:59.248766
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:09:02.093006
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)



# Generated at 2022-06-25 22:09:06.674680
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert (dict_unpacking_transformer_0.target == (3, 4))


# Generated at 2022-06-25 22:09:10.709802
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = dict_unpacking_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:09:19.310130
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:09:23.830423
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)

# Generated at 2022-06-25 22:09:24.630243
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None) is not None


# Generated at 2022-06-25 22:09:27.597721
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == module_x_var_0


# Generated at 2022-06-25 22:09:34.278044
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 22:09:35.125735
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:09:39.181524
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:09:43.632459
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:09:48.694322
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)

# Generated at 2022-06-25 22:09:57.529838
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # We need an example AST
    example_ast = ast.parse("""{1: 2, **dict_b, **dict_a}""")
    # Let's transform it
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(example_ast)
    # The result should pass python compiler
    ast.fix_missing_locations(transformed)
    code = compile(transformed, "<test>", mode="exec")
    # And should have all the right names in it
    assert len(set(code.co_names)) == {'_py_backwards_merge_dicts', 'dict_a', 'dict_b'}
    code_block = code.co_consts[0]

# Generated at 2022-06-25 22:10:10.503311
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:10:14.805610
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:10:19.330115
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:10:24.139364
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = None

    # Call to visit_Dict of DictUnpackingTransformer
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(node_0)



# Generated at 2022-06-25 22:10:28.279607
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


if __name__ == '__main__':
    import pytest

    pytest.main()

# Generated at 2022-06-25 22:10:33.626620
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_2 = None
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_4 = DictUnpackingTransformer(a_s_t_1)
    module_x_var_3 = dict_unpacking_transformer_4.visit_Dict(module_x_var_2)


# Generated at 2022-06-25 22:10:39.718992
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(a_s_t_1)

# Generated at 2022-06-25 22:10:42.814919
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    result = dict_unpacking_transformer_0
    assert result is not None


# Generated at 2022-06-25 22:10:46.345188
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:10:49.456588
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(
        arg_0 = a_s_t_0,
    )

# Generated at 2022-06-25 22:11:04.299950
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pytest.skip('Needs implementation')

# Generated at 2022-06-25 22:11:07.112538
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:11:18.234341
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None


# Generated at 2022-06-25 22:11:21.478575
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:11:22.059787
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-25 22:11:26.744057
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:11:29.968034
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    str_0 = str(module_x_var_1)
    assert str_0 == None


# Generated at 2022-06-25 22:11:38.779019
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0) # Test whether the constructor returns an object of type DictUnpackingTransformer
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:11:43.235620
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)

# Generated at 2022-06-25 22:11:47.856303
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)
    pass


# Generated at 2022-06-25 22:12:19.728359
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_2 = None
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_x_var_3 = dict_unpacking_transformer_1.visit_Dict(module_x_var_2)

# Generated at 2022-06-25 22:12:23.670139
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:12:27.661318
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Test with concrete argument module_0.AST
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:12:36.731961
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    call_0 = module_0.Call(module_0.Name(id = '_py_backwards_merge_dicts'), [], [module_0.keyword(arg = 'dicts', value = module_0.List([module_0.Dict([module_0.Name(id = 'a', ctx = module_0.Load())], [module_0.Name(id = 'b', ctx = module_0.Load())], []), module_0.Name(id = 'c', ctx = module_0.Load())], [], []))], [])

# Generated at 2022-06-25 22:12:40.090177
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:12:42.907348
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    try:
        a_s_t_0 = module_0.AST()
        dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    except Exception as inst:
        assert False


# Generated at 2022-06-25 22:12:47.102370
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:12:52.149692
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)



# Generated at 2022-06-25 22:12:56.042756
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:12:57.020685
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert 1 == 1


# Generated at 2022-06-25 22:14:01.273621
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == None


# Generated at 2022-06-25 22:14:09.153220
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0._split_by_None = lambda x_var_0: None
    dict_unpacking_transformer_0._prepare_splitted = lambda x_var_0: None
    dict_unpacking_transformer_0._merge_dicts = lambda x_var_0: None
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    dict_unpacking_transformer_0.visit_Dict(module_x_var_1)

# Generated at 2022-06-25 22:14:16.867059
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = 'typed_ast._ast3'
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, module_3.BaseNodeTransformer)
    # Testing attribute is_disabled
    attr_0 = getattr(dict_unpacking_transformer_0, 'is_disabled', None)
    assert not attr_0
    # Testing attribute a
    attr_0 = getattr(dict_unpacking_transformer_0, 'a', None)
    assert isinstance(attr_0, module_0.AST)
    # Testing attribute tree_changed

# Generated at 2022-06-25 22:14:20.561604
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
  a_s_t_0 = module_0.AST()
  dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

from ..utils.visitor import flatten


# Generated at 2022-06-25 22:14:29.540732
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_2 = module_0.Str('abc')
    module_x_var_3 = module_0.List()
    module_x_var_4 = module_0.List()
    module_x_var_5 = module_0.Expr(module_x_var_4)
    module_x_var_6 = module_0.Import([module_x_var_5])
    module_x_var_7 = module_0.Name('name_0', module_0.Load())
    module_x_var_8 = module_0.Name('abc', module_0.Store())
    module_x_var_9 = module_0.Name('abc', module_0.Store())
    module_x_var_10 = module_0.Name('abc', module_0.Del())
    module

# Generated at 2022-06-25 22:14:33.151094
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Dict(module_x_var_0)

# Generated at 2022-06-25 22:14:43.574307
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = ast.Module()
    assert module_x_var_0.body == []
    assert module_x_var_0.type_ignores == []
    assert module_x_var_0.tbody == []
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1.body[0].body[0].name == 'body'
    assert module_x_var_1.body[0].body[0].ctx == ast.Store()

# Generated at 2022-06-25 22:14:50.992025
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[], values=[])
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_x_var_0 = None
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = dict_unpacking_transformer_1.visit_Module(module_x_var_1)


# Generated at 2022-06-25 22:14:56.196411
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    try:
        assert module_x_var_0 is module_x_var_1
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 22:14:59.305859
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0 is None
