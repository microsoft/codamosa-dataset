

# Generated at 2022-06-25 22:07:30.957436
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([])
    module_2 = dict_unpacking_transformer_0.visit(module_1)
    module_0.Module([])

# Generated at 2022-06-25 22:07:39.614759
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([], [module_0.Expr(module_0.Dict(keys=[module_0.Num(1)], values=[module_0.Name(id='x', ctx=module_0.Store())]))], [], [])
    print(module_1)
    print(module_0.fix_missing_locations(module_1))
    ret_val_2 = dict_unpacking_transformer_0.visit(module_0.fix_missing_locations(module_1))
    ret_val_3 = ret_val_2.body[0]
    ret_val_4 = ret

# Generated at 2022-06-25 22:07:40.246574
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert 2 == 2


# Generated at 2022-06-25 22:07:46.351755
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    test_value_00 = module_0.Module(body=list())
    test_value_01 = dict_unpacking_transformer_0.visit_Module(node=test_value_00)
    assert test_value_01 is not None
    assert test_value_01.body is not None
    assert len(test_value_01.body) == 2


# Generated at 2022-06-25 22:07:55.950496
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_1 = module_0.Module()
    a_s_t_2 = module_0.AST()
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_2)
    dict_unpacking_transformer_1.visit(module_1)
    dict_unpacking_transformer_2.visit(module_1)
    module_2 = module_0.Module()
    a_s_t_3 = module_0.AST()
    dict_unpacking_transformer_3 = DictUnpackingTransformer(a_s_t_3)
    dict_unpacking_transformer

# Generated at 2022-06-25 22:08:04.882101
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # ---------------------------------------
    # Example 1:
    # ---------------------------------------
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[], values=[])
    dict_unpacking_transformer_0.visit(a_s_t_1)
    dict_unpacking_transformer_0.finalize()

# Generated at 2022-06-25 22:08:08.862375
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0.body = [ module_0.Expr(value=module_0.Call(func=module_0.Name(id='dict', ctx=module_0.Load()), args=[module_0.Str(s='foo')], keywords=[module_0.keyword(arg='baz', value=module_0.Num(n=2))])) ]
    dict_unpacking_transformer_0.visit(a_s_t_0)
    assert dict_unpacking_transformer_0._tree_changed == False


a_s_t_0 = module_0.AST()
dict_unpacking_transformer

# Generated at 2022-06-25 22:08:18.841449
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Code:
    # {1: 1, **dict_a}

# Generated at 2022-06-25 22:08:27.125452
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict(): 
    # Init
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    # Testing if the type of "a_s_t_1" is correct
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_0.generic_visit(a_s_t_1)
    assert isinstance(a_s_t_1, module_0.AST)


# Generated at 2022-06-25 22:08:35.958977
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_1.body.append(module_0.Assign())
    module_1.body.append(module_0.Expr())
    module_1.body.append(module_0.FunctionDef())
    module_1.body.append(module_0.ClassDef())
    module_1.body.append(module_0.Return())
    module_1.body.append(module_0.Delete())
    module_1.body.append(module_0.Assign())
    module_1.body.append(module_0.Expr())

# Generated at 2022-06-25 22:08:46.342069
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:08:52.834591
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert_equal(dict_unpacking_transformer_0._tree_changed, False)
    assert_equal(dict_unpacking_transformer_0.result, None)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:08:53.654246
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    _test_case_0()

# Generated at 2022-06-25 22:09:02.696769
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    try:
        assert isinstance(var_0, (module_0.Dict, module_0.Call))
    except AssertionError as e:
        print("Assertion failed in test_DictUnpackingTransformer_visit_Dict:")
        print("    got ", var_0)
        print("    expected ", "module_0.Dict() or module_0.Call()")
        raise e

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:09:09.203699
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

if __name__ == '__main__':
    import pytest
    pytest.main(args=['test_DictUnpackingTransformer.py'])

# Generated at 2022-06-25 22:09:12.875962
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = ast.Dict()
    ast0 = ast.AST()
    transformer = DictUnpackingTransformer(ast0)
    var0 = transformer.visit_Dict(dict_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:09:20.537063
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = Dict()
    a_s_t_0 = AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    var_1 = repr('Dict(keys=[], values=[], lineno=None, col_offset=None)')
    var_2 = repr('Dict(keys=[], values=[], lineno=None, col_offset=None)')
    assert var_0 == var_1
    assert var_0 == var_2

# Generated at 2022-06-25 22:09:25.036224
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert var_0 is not None
    assert type(var_0) is module_0.Call

# Generated at 2022-06-25 22:09:25.878557
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()

import unittest


# Generated at 2022-06-25 22:09:30.755208
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Iter #0
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:09:47.434308
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Variable declarations
    module_0 = (module_0, module_0)
    arg_0 = module_0.Dict()
    a_s_t_0 = (module_0.List, module_0.Name)
    var_0 = module_0.List()
    var_1 = module_0.Name()
    var_2 = (module_0.List, module_0.Num)
    var_3 = module_0.List()
    var_4 = module_0.Num()
    var_5 = module_0.Call()
    var_6 = module_0.Call()
    var_7 = module_0.Call()
    var_8 = module_0.Call()
    var_9 = module_0.Call()
    var_10 = module_0.Dict()
    var_

# Generated at 2022-06-25 22:09:48.935506
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()

# Generated at 2022-06-25 22:09:56.155705
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert type(var_0) == module_0.Dict, 'Expected type is module_0.Dict'
    module_0.Dict(var_0)
    assert var_0.lineno == dict_0.lineno, 'Expected value is dict_0.lineno'


# Generated at 2022-06-25 22:10:00.488016
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(dict_1, module_0.Dict)


# Generated at 2022-06-25 22:10:11.784247
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

    import typed_ast._ast3 as module_1
    dict_0 = module_1.Dict(keys=[])
    a_s_t_0 = module_1.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)

    import typed_ast._

# Generated at 2022-06-25 22:10:19.171956
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert var_0 == module_0.Call(
        func=module_0.Name(
            id='_py_backwards_merge_dicts',
            ctx=module_0.Load()),
        args=[module_0.List([])],
        keywords=[])

# Generated at 2022-06-25 22:10:22.864817
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:10:28.200729
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    x = ast.parse('a["b"] = x').body[0]

    assert x.targets[0].__class__ == ast.Subscript
    assert x.targets[0].value.__class__ == ast.Name
    assert x.targets[0].value.id == 'a'
    assert x.targets[0].slice.__class__ == ast.Index
    assert x.targets[0].slice.value.__class__ == ast.Str
    assert x.targets[0].slice.value.s == 'b'


test_case_0()

# Generated at 2022-06-25 22:10:33.626951
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    if not (dict_0 == dict_unpacking_transformer_0.visit_Dict(dict_0)):
        assert False

# Generated at 2022-06-25 22:10:34.581956
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test 1,
    test_case_0()

# Generated at 2022-06-25 22:10:57.229776
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Testing with equal inputs
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

    # Testing with different inputs
    dict_1 = module_0.Dict()
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    var_1 = dict_unpacking_transformer_1.visit_Dict(dict_0)


# Generated at 2022-06-25 22:11:06.314605
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(var_0, module_0.Call)
    assert isinstance(var_0.func, module_0.Name)
    assert '_py_backwards_merge_dicts' == var_0.func.id
    assert var_0.keywords == []
    assert isinstance(var_0.args, list)
    assert len(var_0.args) == 1
    assert isinstance(var_0.args[0], module_0.List)
   

# Generated at 2022-06-25 22:11:09.246088
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:11:15.486842
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = AST()
    a_s_t_0 = AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:11:16.339260
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()

# Generated at 2022-06-25 22:11:21.722501
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(var_0, module_0.Call)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:11:27.318126
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0.AST())
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    
test_DictUnpackingTransformer_visit_Dict()
test_case_0()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 22:11:30.554332
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(var_0, module_0.Call)


# Generated at 2022-06-25 22:11:37.491512
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:11:41.111869
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:12:18.863699
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
  import typed_ast._ast3 as module_0
  from unittest.mock import MagicMock
  from unittest.mock import call
  import ast

  class DictUnpackingTransformer_0(object):
    def _split_by_None(self, pairs):
      return [
        [],
        [
          (
            module_0.Name(),
            module_0.Str()
          )
        ],
        [],
        [
          (
            module_0.Name(),
            module_0.Str()
          ),
          (
            module_0.Name(),
            module_0.Str()
          )
        ]
      ]


# Generated at 2022-06-25 22:12:24.323765
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)


import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:12:29.288077
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_2 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(var_2, module_0.Call)


# Generated at 2022-06-25 22:12:37.642031
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Create list of module_0.Dict Objects
    list_0 = [module_0.Dict() for _ in range(0, 4)]
    for dict_0 in list_0:
        # Create a_s_t_0 instance of module_0.AST
        a_s_t_0 = module_0.AST()
        # Create instance of module_0.DictUnpackingTransformer
        dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
        # Call visit_Dict method
        var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
        # Assert that var_0 is instance of module_0.Dict or module_0.Call

# Generated at 2022-06-25 22:12:47.182021
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = ast.Dict()
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(var_0, ast.Call)
    assert isinstance(var_0.func, ast.Name)
    assert var_0.func.id == '_py_backwards_merge_dicts'
    assert isinstance(var_0.args, list)
    assert len(var_0.args) == 1
    assert isinstance(var_0.args[0], ast.List)
    assert isinstance(var_0.keywords, list)

# Generated at 2022-06-25 22:12:55.934722
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    DictUnpackingTransformer._tree_changed = False
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    if DictUnpackingTransformer._tree_changed:
        print("Test failed, line 17")

    if not isinstance(var_0, module_0.Dict):
        print("Test failed, line 18, expected type is Dict, found type: %s" % (var_0,))

    dict_unpacking_transformer_0._tree_changed = False

# Generated at 2022-06-25 22:12:58.435720
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:13:02.342133
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = Dict()
    a_s_t_0 = AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:13:07.298730
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Build call arguments and call
    dict_0 = ast.Dict(keys=[], values=[])
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    var_1 = type(var_0) == ast.Call
    assert var_1

# Generated at 2022-06-25 22:13:08.237536
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert test_case_0()

# Generated at 2022-06-25 22:14:26.863981
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    try:
        assert (var_0 == None)
    except AssertionError:
        raise

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:14:31.701273
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_1 = dict_unpacking_transformer_0.visit_Dict(var_0)
    assert isinstance(var_1, module_0.Dict)


# Generated at 2022-06-25 22:14:35.020626
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.parse('')
    dict_0 = module_0.body[0]
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0.visit_Dict(dict_0), ast.Dict)

# Generated at 2022-06-25 22:14:42.818521
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import Union, Iterable, Optional, List, Tuple
    from typed_ast import ast3 as ast
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    
    
    dict_0 = dict
    a_s_t_0 = ast
    dict_unpacking_transformer_0 = DictUnpackingTransformer(dict_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:14:46.815191
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Setup
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    # Target
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:14:47.656008
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert 1==1


# Generated at 2022-06-25 22:14:50.696507
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()

### TESTING

if __name__ == '__main__':
    import sys
    import test_utils as utils
    utils.run_tests(sys.modules[__name__], sys.argv[1:])

# Generated at 2022-06-25 22:14:51.523499
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()


# Generated at 2022-06-25 22:14:55.583540
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert (var_0 == dict_0)


# Generated at 2022-06-25 22:14:58.969687
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Setup
    source = ""
    ast_0 = ast.parse(source)
    transformer = DictUnpackingTransformer(ast_0)

    # Exercise
    result = transformer.visit_Dict(ast_0.body[0])

    # Verify
    assert result == ast_0.body[0]
