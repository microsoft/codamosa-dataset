

# Generated at 2022-06-25 22:07:33.083970
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    module_1 = module_0.Module()

    node_2 = module_0.Dict()

    node_2.keys.append(1)

    value_3 = module_0.Name()
    value_3.id = 'a'

    node_2.values.append(value_3)

    module_1.body.append(node_2)

    dict_unpacking_transformer_0.visit(module_1)

# Generated at 2022-06-25 22:07:42.058113
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    
    # Collect TypeInfos with initializing of variables
    # because we need a AST with types information
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0.parse("""{1: 1, **dict_a}""")
    
    # Collect TypeInfos with clearing of variables
    # because we need a AST without types information
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    a_s_t_1.parse("""{1: 1, **dict_a}""")
    
    # Transform a_s_t_0 to a

# Generated at 2022-06-25 22:07:45.553611
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:07:50.847597
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict( 0, 0 )
    dict_unpacking_transformer_0.visit_Dict( dict_0 )
    # AssertionError: 
    # assert isinstance(result[-1], list)


# Generated at 2022-06-25 22:08:00.002240
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_2 = module_0.Dict(keys=[module_0.Num(n=1.0),
                                  None,
                                  module_0.Num(n=3.0)],
                            values=[module_0.Num(n=1.0),
                                    module_0.Name(id='a'),
                                    module_0.Name(id='b')])
    # DictUnpackingTransformer.visit_Dict.actual_result
    actual_result_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_2)
    # DictUnpackingTransformer.

# Generated at 2022-06-25 22:08:04.561428
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_ = module_0.Module()
    names = [module_0.NameConstant(value=None)] * 3
    module_.body = [module_0.Expr(value=module_0.Dict(keys=names, values=[]))]
    module_0_45 = module_0.Module()
    names_0_45 = [module_0.NameConstant(value=None)] * 3
    module_0_45.body = [module_0.Expr(value=module_0.Dict(keys=names_0_45, values=[]))]
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0_45)
    module_1 = dict_unpacking_transformer_0.visit(module_)

# Generated at 2022-06-25 22:08:10.513994
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dictionary_0 = module_0.Dict(keys=[module_0.Num(1.0), None], values=[module_0.Num(2.0), module_0.Name(id='dict', ctx=module_0.Load())])
    dict_unpacking_transformer_0.visit(dictionary_0)


# Generated at 2022-06-25 22:08:14.588811
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    node_0 = None
    result = dict_unpacking_transformer_1.visit_Dict(node_0)

# Generated at 2022-06-25 22:08:25.845887
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    funcdef_0 = module_0.FunctionDef()
    module_1.body = [funcdef_0]
    dict_0 = module_0.Dict()
    dict_1 = module_0.Dict()
    dict_2 = module_0.Dict()
    dict_3 = module_0.Dict()
    dict_4 = module_0.Dict()
    dict_5 = module_0.Dict()
    dict_6 = module_0.Dict()
    dict_7 = module_0.Dict()
    dict_8 = module_0.Dict()

# Generated at 2022-06-25 22:08:35.141890
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import _ast
    import typed_ast.ast3 as ast
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast.dump(dict_unpacking_transformer_0.visit(ast.parse('{6: 1, **d}')))
    dict_unpacking_transformer_0.visit(ast.parse('{6: 1, **d}'))
    dict_unpacking_transformer_0.visit(ast.parse('{6: 1, **d, 7: 2, **d2}'))
    dict_unpacking_transformer_0.visit(ast.parse('{6: 1, **d, 7: 2, **d2, 8: 3}'))


# Generated at 2022-06-25 22:08:46.929185
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[], values=[])
    a_s_t_2 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    try:
        assert a_s_t_2.keys == []

    except AssertionError:
        raise AssertionError('''keys''')

    try:
        assert a_s_t_2.values == []

    except AssertionError:
        raise AssertionError('''values''')


# Generated at 2022-06-25 22:08:56.639615
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.tree import parse
    from ..utils.source_code import source_code
    from .base import UnaryOperatorTransformer

    # Test with simple expression
    @source_code()
    def test_code_0():
        a = {1: 1, 2: 2, 3: 3}

    ast_node_0 = parse(test_code_0.code)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(ast_node_0)
    assert dict_unpacking_transformer_0.visit(ast_node_0).as_string() == test_code_0.code

    # Test with dict unpacking
    @source_code()
    def test_code_1():
        a = {1: 1, **{2: 2}}


# Generated at 2022-06-25 22:09:04.718316
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():

    from typed_ast import ast3 as ast
    from typed_ast import convert, dump
    import pickle

    a = ast.parse('x = {1: 1, 2: 2, **dict_a}')
    
    DictUnpackingTransformer(a).visit(a)

    print(dump(a))

    assert convert(a) == \
        "x = _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)"

# Generated at 2022-06-25 22:09:09.248312
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_node_0 = module_0.Module([], [])
    dict_unpacking_transformer_0.visit(ast_node_0)


# Generated at 2022-06-25 22:09:11.522357
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():

    # Test with arguments
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)



# Generated at 2022-06-25 22:09:20.686701
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    result = ast.parse('{1: 2, **{3: 4}}')
    DictUnpackingTransformer().visit(result)
    assert str(
        result) == "from __future__ import print_function\n{return _py_backwards_merge_dicts([{1: 2}] , {3: 4})}"
    
    result = ast.parse('{1: 2, **{3: 4}, 5: 6}')
    DictUnpackingTransformer().visit(result)
    assert str(
        result) == "from __future__ import print_function\n{return _py_backwards_merge_dicts([{1: 2} , {5: 6}] , {3: 4})}"
    

# Generated at 2022-06-25 22:09:23.002340
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    # Try if the code is valid python
    try:
        exec(dict_unpacking_transformer_0.visit_Module.__code__)
    except Exception:
        pass


# Generated at 2022-06-25 22:09:31.463236
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    child_0 = module_0.Call(
        func=module_0.Name(id='int'),
        args=[module_0.Num(n=1)],
        keywords=[])
    child_1 = module_0.Dict(keys=[], values=[])
    child_2 = module_0.Call(
        func=module_0.Name(id='int'),
        args=[module_0.Num(n=1)],
        keywords=[])
    child_3 = module_0.Name(id='value')
    child_4 = module_0.Dict(keys=[child_2], values=[child_3])
    child_5 = module_0.Call(
        func=module_0.Name(id='dict'),
        args=[child_4],
        keywords=[])
    child_6 = module_0

# Generated at 2022-06-25 22:09:36.166555
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # assert dict_unpacking_transformer_0._tree == a_s_t_0


# Generated at 2022-06-25 22:09:46.004050
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    a_s_t_2 = module_0.Call()
    a_s_t_1.keys = [a_s_t_2]
    a_s_t_3 = module_0.Name()
    a_s_t_1.values = [a_s_t_3]
    a_s_t_2.func = a_s_t_3
    a_s_t_4 = module_0.Name()
    a_s_t_2.args = [a_s_t_4]

# Generated at 2022-06-25 22:09:51.340866
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_0 = ast.Module()
    a_s_t_0 = module_0
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    return 1


# Generated at 2022-06-25 22:09:59.818156
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[])
    module_2 = dict_unpacking_transformer_0.visit(module_1)
    
    if isinstance(module_2, module_0.Module) and len(module_2.body) == 1 and isinstance(module_2.body[0], module_0.Expr) and isinstance(module_2.body[0].value, module_0.Name) and module_2.body[0].value.id == '_py_backwards_merge_dicts':
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 22:10:03.959392
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert hasattr(dict_unpacking_transformer_0, 'visit_Dict')


# Generated at 2022-06-25 22:10:09.856093
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    assert module_1 == dict_unpacking_transformer_0.visit_Module(module_1)


# Generated at 2022-06-25 22:10:19.132103
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    str_0 = 'a'
    int_0 = 10
    dict_0 = module_0.Str(str_0, int_0)
    a_s_t_2 = module_0.AST()
    str_1 = 'b'
    int_1 = 11
    dict_1 = module_0.Str(str_1, int_1)
    a_s_t_3 = module_0.AST()
    str_2 = 'c'
    int_2 = 12
    dict_2 = module_0.Str(str_2, int_2)


# Generated at 2022-06-25 22:10:26.124264
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    a_s_t_1 = module_0.Dict()
    a_s_t_1.keys = [None, None, None] # type: ignore
    a_s_t_1.values = [None, None, None] # type: ignore
    a_s_t_1.keys = [None] # type: ignore
    a_s_t_1.values = [None] # type: ignore
    a_s_t_1.keys = [None, None] # type: ignore
    a_s_t_1.values = [None, None] # type: ignore

    # Act
    result = dict_unpacking_trans

# Generated at 2022-06-25 22:10:37.106616
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1_0 = module_0.Module([])
    module_1_1 = dict_unpacking_transformer_0._visit_Module(module_1_0)
    dict_1_2 = module_0.Dict([])
    dict_1_3 = dict_unpacking_transformer_0._visit_Dict(dict_1_2)
    dict_1_4 = module_0.Dict([module_0.keyword(None, module_0.Num(1))])
    dict_1_5 = dict_unpacking_transformer_0._visit_Dict(dict_1_4)
    dict_

# Generated at 2022-06-25 22:10:42.366978
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)
    module_1.body.append(dict_0)

# Generated at 2022-06-25 22:10:43.445174
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer, type)


# Generated at 2022-06-25 22:10:45.348507
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:10:55.112941
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.parse('from math import sqrt')
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    ret_val_0 = {}
    ast.copy_location(ret_val_0, module_0)
    ast.fix_missing_locations(ret_val_0)
    dict_unpacking_transformer_0.visit(module_0)



# Generated at 2022-06-25 22:10:57.349198
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:11:06.438413
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer(None)
    a_s_t_0 = module_0.AST()
    dict_0 = module_0.Dict(keys=(), values=())
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_1.visit(dict_0)
    dict_unpacking_transformer_0.visit(dict_0)
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_3 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer

# Generated at 2022-06-25 22:11:14.058272
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_2 = module_0.Dict()
    a_s_t_1 = module_0.Expr()
    a_s_t_1.value = a_s_t_2
    a_s_t_3 = dict_unpacking_transformer_0.visit(a_s_t_1)
    


# Generated at 2022-06-25 22:11:20.390746
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    test_cases_visit_Dict_1 = [
    ]
    for test_case_visit_Dict_1 in test_cases_visit_Dict_1:
        result_1 = DictUnpackingTransformer.visit_Dict(dict_unpacking_transformer_1, test_case_visit_Dict_1)
        assert 'pass' == 'pass'

# Generated at 2022-06-25 22:11:28.133407
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Dict(keys=[1, 'foo'], values=[[], {}])
    dict_unpacking_transformer_0.visit(a_s_t_1)
    # Should return: ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'), args=[ast.List(elts=[ast.Dict(keys=[1, 'foo'], values=[[], {}])])], keywords=[])


# Generated at 2022-06-25 22:11:37.649570
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = Module([Expr(Call(Name('_py_backwards_merge_dicts', Load()), [List([Call(Name('dict', Load()), [Num(1), Num(1)], [])], Call(Name('dict', Load()), [Name('dict_a', Load())], []))], []))])
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    result = dict_unpacking_transformer_0.visit_Module(a_s_t_0)
    assert isinstance(result, Module)
    assert result.body[0].value.func.id == '_py_backwards_merge_dicts'

# Generated at 2022-06-25 22:11:40.957061
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # TODO: Implement test or remove method
    raise Exception("Not implemented")


# Generated at 2022-06-25 22:11:45.600693
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([])
    assert dict_unpacking_transformer_0.visit_Module(module_1) == module_0.Module([merge_dicts.get_body()])


# Generated at 2022-06-25 22:11:54.208621
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    # Setup

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0.copy_location(dict_unpacking_transformer_0, a_s_t_0)
    dict_unpacking_transformer_0.body = [module_0.Expr(module_0.AnnAssign(module_0.Subscript(module_0.Name('a', module_0.Store()), module_0.Index(module_0.Num(1)), module_0.Store()), module_0.Name('b', module_0.Load()), None))]

    # Test

    dict_unpacking_transformer_0.visit_Module(dict_unpacking_transformer_0)

    #

# Generated at 2022-06-25 22:12:12.382786
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0_literal_0 = module_0.Literal(value=1, context=module_0.Load())
    a_s_t_0_literal_1 = module_0.Literal(value=1, context=module_0.Load())
    a_s_t_0_dict_0 = module_0.Dict(keys=[a_s_t_0_literal_0], values=[a_s_t_0_literal_1])

# Generated at 2022-06-25 22:12:15.340765
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:12:22.097358
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = _ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_0 = _ast.Module()
    dict_unpacking_transformer_0.visit(ast_0)
    dict_unpacking_transformer_0.visit_Dict(ast_0)
    dict_unpacking_transformer_0.generic_visit(ast_0)
    

# Generated at 2022-06-25 22:12:27.387895
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_1.body = []
    try:
        module_1_0 = dict_unpacking_transformer_0.visit_Module(module_1)
    except Exception as exception_0:
        assert type(exception_0) == IndentationError


# Generated at 2022-06-25 22:12:30.473654
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Assert:
    assert (DictUnpackingTransformer is not None), \
        "Unable to create object of class DictUnpackingTransformer"
        # Assert:

# Generated at 2022-06-25 22:12:33.620276
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 22:12:40.642196
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Setup
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    dict_unpacking_transformer_0._tree_changed = False
    # Exercise
    module_0_0_0 = dict_unpacking_transformer_0.visit_Module(module_0_0)
    # Verify
    assert isinstance(module_0_0_0, module_0.Module)
    assert dict_unpacking_transformer_0._tree_changed == True

from . import bases
from . import forward_references
from . import builtin_funcs
from . import classes
from . import list_comprehensions
from . import literals


# Generated at 2022-06-25 22:12:45.221247
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    class_0 = module_0.FunctionDef()
    dict_unpacking_transformer_0.visit_Dict(class_0)


# Generated at 2022-06-25 22:12:54.334158
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0.Module()
    # TODO: this should be the next line.
    # test_case_0()
    test_case_0()
    # TODO: fix this line
    # module_0.Dict(keys=[None], values=[module_0.List(elts=[], ctx=None)])
    a_s_t_0.Module()
    a_s_t_0.Dict()
    # TODO: fix this
    # assert True, "Expected: {'a': 3}, 4,\nGot: 3, 4"
    assert True, "Expected: None,\nGot: None"



# Generated at 2022-06-25 22:12:55.444886
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None


# Generated at 2022-06-25 22:13:09.095362
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:13:13.606196
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:13:19.861627
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_x_var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:13:21.325640
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # No need for unit test
    pass

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:13:28.050035
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = module_0.Module()
    dict_s_t_0 = module_0.Dict(keys=[None, None, None, None], values=[None, None, None, None])
    dict_x_var_2 = dict_unpacking_transformer_0.visit_Dict(dict_s_t_0)
    assert dict_x_var_2 is None
    pass

# Generated at 2022-06-25 22:13:36.627688
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_var_0 = module_0.Module()

    def test_case_0():
        module_x_var_0 = module_0.Module()
        a_s_t_0 = module_0.AST()
        dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
        module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
        assert (module_x_var_0 == module_x_var_1)
    test_case_0()

# Generated at 2022-06-25 22:13:42.796288
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_x_var_0 = module_0.AST()
    dict_unpacking_transformer_x_var_0 = DictUnpackingTransformer(a_s_t_x_var_0)
    module_x_var_1 = dict_unpacking_transformer_x_var_0.visit_Module(module_x_var_0)
    assert not isinstance(module_x_var_1, module_0.Module)

# Generated at 2022-06-25 22:13:47.420333
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    ast_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(ast_0)
    dict_unpacking_transformer_0.generic_visit(module_0.Num(n=1))
    dict_unpacking_transformer_0._tree_changed = True
    dict_unpacking_transformer_0.generic_visit(module_0.Num(n=1))

# Generated at 2022-06-25 22:13:50.429874
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:13:51.206704
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:14:22.607112
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = ast.Module()
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_2 = dict_unpacking_transformer_1.visit_Module(module_x_var_0)

    dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    dict_unpacking_transformer_1.visit_Module(module_x_var_1)
   

# Generated at 2022-06-25 22:14:27.356857
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:14:32.723491
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    del dict_unpacking_transformer_0

# Partly unit test for constructor of class DictUnpackingTransformer

# Generated at 2022-06-25 22:14:38.196699
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_1 = module_0.Module()
    module_x_var_2 = module_0.Dict()
    module_x_var_0 = module_0.AST()
    module_x_var_3 = DictUnpackingTransformer(module_x_var_0)
    module_x_var_4 = module_x_var_3.visit_Dict(module_x_var_2)


# Generated at 2022-06-25 22:14:40.570455
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:14:43.434289
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:14:48.329916
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    dict_x_var_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)


# Generated at 2022-06-25 22:14:49.145330
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:14:57.173184
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    module_x_var_0.body = [module_0.Expr(module_0.Dict(keys=[None, None],
                                                       values=[module_0.Num(n=0),
                                                               module_0.Num(n=0)]))]
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = module_0.Expr(module_x_var_1.body[1])
    assert type(module_x_var_2)

# Generated at 2022-06-25 22:14:57.693481
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-25 22:15:48.246927
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:15:52.190837
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Dict
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    d_x_var_0 = ast.Dict()
    d_s_t_0 = ast.AST()
    dict_unpacking_transformer_1 = dict_unpacking_transformer_0.visit_Dict(d_x_var_0)
    assert type(dict_unpacking_transformer_1) == Dict

# Generated at 2022-06-25 22:16:00.588263
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[], values=[])
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(module_x_var_1, module_0.Call)
    assert isinstance(module_x_var_1.func, module_0.Name)
    assert isinstance(module_x_var_1.args, list)
    assert isinstance(module_x_var_1.keywords, list)



# Generated at 2022-06-25 22:16:04.594920
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:16:09.315890
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:16:13.611059
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[None, None], values=[])
    _ = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:16:21.369250
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
  module_x_var_0 = module_0.Module()
  module_x_var_1 = module_0.AST()
  module_x_var_2 = DictUnpackingTransformer(module_x_var_1)
  module_x_var_4 = None
  module_x_var_5 = None
  module_x_var_6 = None
  module_x_var_7 = None
  module_x_var_8 = None
  module_x_var_9 = None
  module_x_var_10 = module_0.List()
  module_x_var_11 = module_0.List()
  module_x_var_12 = module_0.List()
  module_x_var_13 = module_0.List()
  module_x_var_3 = module_x

# Generated at 2022-06-25 22:16:29.265472
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = typed_ast.ast3.Module()
    a_s_t_0 = typed_ast.ast3.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = typed_ast.ast3.Dict(keys=[typed_ast.ast3.Constant(value=1, kind=None), None, typed_ast.ast3.Constant(value=3, kind=None)], values=[typed_ast.ast3.Constant(value=1, kind=None), typed_ast.ast3.Constant(value=2, kind=None), typed_ast.ast3.Constant(value=3, kind=None)])

# Generated at 2022-06-25 22:16:31.465816
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0 is not None


# Generated at 2022-06-25 22:16:36.610262
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Function in test module: test_case_0
    # Function in self module: visit_Module
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)