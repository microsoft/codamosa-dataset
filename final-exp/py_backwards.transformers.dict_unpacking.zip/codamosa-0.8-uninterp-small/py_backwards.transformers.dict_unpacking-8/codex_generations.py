

# Generated at 2022-06-25 22:07:24.597430
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    expected_0 = module_0.Dict(keys=None, values=None)
    node_0 = module_0.Dict(keys=None, values=None)
    result_0 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert result_0 == expected_0

# Generated at 2022-06-25 22:07:30.049909
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = a_s_t_0.Dict(keys=[None], values=["fdsdfs"])
    dict_unpacking_transformer_1.visit_Dict(dict_0)

import typed_ast.ast3 as module_1


# Generated at 2022-06-25 22:07:37.096242
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_dict_0 = module_0.Dict()
    a_dict_0.keys = [module_0.Name(id="a"), module_0.Name(id="b")]
    a_dict_0.values = [module_0.Constant(value=1), module_0.Constant(value=2)]
    dict_unpacking_transformer_0.visit_Dict(a_dict_0)
    assert True


# Generated at 2022-06-25 22:07:43.706412
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.parse("func_0(**dict_0)")
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    return_value_1 = dict_unpacking_transformer_0.visit_Dict(a_s_t_0.body[0].value)
    assert type(return_value_1) == ast.Call
    assert return_value_1.func.id == '_py_backwards_merge_dicts'



# Generated at 2022-06-25 22:07:44.522815
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()

# Generated at 2022-06-25 22:07:50.196010
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0_0 = module_0.Dict(keys = [], values = [])
    result = dict_unpacking_transformer_0.visit_Dict(a_s_t_0_0)
    assert result == a_s_t_0_0


# Generated at 2022-06-25 22:07:59.375619
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    keys_0 = ['a', 'b', None]
    values_0 = ['1', '2', None]
    kwargs_0 = {'values':values_0, 'keys':keys_0}
    ast_Dict_0 = module_0.Dict(**kwargs_0)
    
    assert {'keys': keys_0, 'values': values_0} == ast_Dict_0.__dict__
    assert {'keys': keys_0, 'values': values_0} == ast_Dict_0.__dict__
    assert isinstance(ast_Dict_0, module_0.Dict)
    assert module

# Generated at 2022-06-25 22:08:08.025586
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    data_0 = module_0.Dict()
    module_1 = module_0.Module()
    try:
        module_0.copy_location(data_0, module_1)
    except AttributeError:
        pass
    try:
        module_0.set_context(data_0, module_1)
    except AttributeError:
        pass
    try:
        module_0.set_lineno(data_0, 1)
    except AttributeError:
        pass

    assert dict_unpacking_transformer_0.visit_Dict(data_0) is module_0.Dict()



# Generated at 2022-06-25 22:08:17.959870
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_obj_0 = DictUnpackingTransformer(a_s_t_0)
    # This test case generates the following AST:
    #
    # Name(id='a', ctx=Load())
    # Dict(keys=[Name(id='a', ctx=Load()), None], values=[Num(n=1), Name(id='a', ctx=Load())])
    # Num(n=1)
    #
    # The resulting AST is:
    #
    # Module(body=[Expr(value=Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), args=[List(elts=[Dict(keys=[Name(id='a', ctx=Load())],

# Generated at 2022-06-25 22:08:29.220576
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_ast_0 = (module_0.parse('def f():\n    return {1: 1, **a}').body[0])

    dict_unpacking_transformer_0.visit(module_ast_0)

# Generated at 2022-06-25 22:08:36.473838
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Unit test for method visit_Dict of class DictUnpackingTransformer
    def test_DictUnpackingTransformer_visit_Dict():
        a_s_t_0 = module_0.AST()
        dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:08:44.876481
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0.AST())
    a_s_t_0 = module_0.AST()
    a_s_t_0.body = [module_0.Module(body=[module_0.Expr(value=module_0.Dict(keys=[module_0.NameConstant(value=None), module_0.NameConstant(value=None)], values=[module_0.Dict(keys=[module_0.Constant(value=123, kind=None), module_0.Constant(value=123, kind=None)], values=[module_0.Constant(value=456, kind=None), module_0.Constant(value=456, kind=None)]), module_0.Constant(value=123, kind=None)]))])]
   

# Generated at 2022-06-25 22:08:49.508875
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    al = [0, 1, 2, 3, 4, 5, 6, 7]
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, a_s_t_0.NodeTransformer)


# Generated at 2022-06-25 22:08:59.101224
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = module_0.Module([ast.Expr(merge_dicts.get_body()[0])])
    module_0.body.append(ast.Expr(ast.Dict(keys=[ast.Num(1)], values=[ast.Num(1)])))
    module_0_ = module_0.body[1].value
    # Call method visit_Module of class DictUnpackingTransformer
    a_s_t_0.fix_missing_locations(module_0_)
    # Stmts: [Expr(), Expr()]
    assert type(module_0_) is module_0.Module
    module

# Generated at 2022-06-25 22:09:04.929138
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    name_0 = module_0.Name(id = "int")
    alias_0 = module_0.alias()
    alias_0.name = "int"
    alias_0.asname = None
    alias_0.module = None
    with module_0.builtins.open("/home/sho/json_0_10.json", "r") as file_0:
        a_s_t_0 = module_0.literal_eval(module_0.load(file_0))
        alias_0.qualname = a_s_t_0
    alias_0.type_comment = None
    alias_0.setPar

# Generated at 2022-06-25 22:09:08.807905
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:09:11.213740
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)
    assert issubclass(type(None), object)
    assert issubclass(type(None), type(object))


# Generated at 2022-06-25 22:09:17.493059
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    a_s_t_0 = module_0.Module(body=[])
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    assert dict_unpacking_transformer_1.visit_Module(a_s_t_0) == module_0.Module(body=[])


# Generated at 2022-06-25 22:09:20.194200
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer is not None
    assert isinstance(DictUnpackingTransformer, type)
    a_s_t_0 = module_0.AST()
    assert DictUnpackingTransformer(a_s_t_0) is not None
test_DictUnpackingTransformer()


# Generated at 2022-06-25 22:09:23.490278
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # TODO: Add more tests
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0

# Generated at 2022-06-25 22:09:31.088629
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module = module_0.Module()
    r = dict_unpacking_transformer_1.visit_Module(module)
    assert isinstance(r, (module_0.Module,))


# Generated at 2022-06-25 22:09:41.232027
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_0.keys = [None, None, None]
    dict_0.values = [module_0.Name(id='a'), module_0.Name(id='b'), module_0.Name(id='c')]
    dict_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(dict_1, module_0.Call)
    assert dict_1.func.id == '_py_backwards_merge_dicts'
    assert len(dict_1.args) == 1

# Generated at 2022-06-25 22:09:45.228080
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    print(dict_unpacking_transformer_0)
    

# Generated at 2022-06-25 22:09:54.112927
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Dict(values=[
        ast.Name(id='a', ctx=ast.Load()),
        ast.Name(id='b', ctx=ast.Load()),
        ast.Name(id='c', ctx=ast.Load())], keys=[
        ast.Num(n=1),
        ast.Num(n=2),
        ast.Num(n=3)])
    # ERROR: assert isinstance(dict_unpacking_transformer_0.visit_Dict(a_s_t_1), ast.Dict)
    # ERROR: assert not dict_unpacking_transformer_

# Generated at 2022-06-25 22:09:54.952221
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:09:56.614824
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert(DictUnpackingTransformer(module_0.AST()) is not None)


# Generated at 2022-06-25 22:10:01.641418
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.Module([module_0.Expr(value=module_0.Dict(keys=[None, module_0.Name(id='a', ctx=module_0.Load())], values=[module_0.Num(n=1), module_0.Num(n=2)]))])
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_0 = dict_unpacking_transformer_1.visit_Module(a_s_t_1)


# Generated at 2022-06-25 22:10:08.588168
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    arg_0 = module_0.Module(body=[])
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module(body=[])
    assert dict_unpacking_transformer_0.visit_Module(arg_0) == module_0_0


# Generated at 2022-06-25 22:10:17.993836
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    test_0 = module_0.Dict()
    module_2 = module_0.Module()
    test_1 = module_0.Dict()
    module_3 = module_0.Module()
    test_2 = module_0.Dict()
    module_4 = module_0.Module()
    test_3 = module_0.Dict()
    module_5 = module_0.Module()
    module_6 = module_0.Module()
    module_7 = module_0.Module()
    test_4 = module_0.Dict()
    module_8 = module_

# Generated at 2022-06-25 22:10:22.971964
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=None, values=None, ctx=None)
    a_s_t_2 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)


# Generated at 2022-06-25 22:10:35.147184
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    a_s_t_2 = module_0.Module()
    # Call visit_Module
    a_s_t_3 = dict_unpacking_transformer_1.visit_Module(a_s_t_2)


# Generated at 2022-06-25 22:10:41.437807
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    def check_func(a_s_t_0):
        dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
        dict_0 = a_s_t_0.Dict()
        module_1 = a_s_t_0.Module(body=[dict_0])
        return dict_unpacking_transformer_0.visit(module_1)

    check_func(module_0)

# Generated at 2022-06-25 22:10:48.023495
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0.AST())
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call(
        obj=module_0.Name(id='dict'), 
        args=[], 
        keywords=[], 
        starargs=None, 
        kwargs=None
    )
    dict_0 = module_0.Dict(
        keys=[], 
        values=[]
    )
    list_0 = module_0.List(
        elts=[call_0, dict_0], 
        ctx=module_0.Load()
    )

# Generated at 2022-06-25 22:10:51.573991
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

if __name__ == '__main__':
    import sys
    import nose2
    
    sys.argv.append('--verbose')
    sys.argv.append('--nocapture')
    nose2.main()

# Generated at 2022-06-25 22:10:56.490843
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    assert dict_unpacking_transformer_0.visit_Module(a_s_t_1) == a_s_t_1


# Generated at 2022-06-25 22:11:03.921802
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    begin_src_0 = '''\
{1: 1, **dict_a}
'''
    begin_src_0 = module_0.parse(begin_src_0)
    end_src_0 = dict_unpacking_transformer_0.visit(begin_src_0)
    begin_src_0 = module_0.dump(begin_src_0)
    end_src_0 = module_0.dump(end_src_0)
    pass

# Generated at 2022-06-25 22:11:06.437173
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:11:08.817932
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:11:17.409308
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.target == (3, 4)
    assert dict_unpacking_transformer_0._tree_changed is False
    assert dict_unpacking_transformer_0._tree is a_s_t_0
    assert dict_unpacking_transformer_0.ast_version is (3, 4)


# Generated at 2022-06-25 22:11:19.828686
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    ut = DictUnpackingTransformer(None)
    node = dict()

    ret_val = ut.visit_Dict(node)


# Generated at 2022-06-25 22:11:43.277692
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:11:47.855783
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0.AST())
    ast_0 = module_0.Dict(keys=[module_0.Num(n=1)], values=[module_0.Num(n=1)])
    dict_unpacking_transformer_0.visit(ast_0)

# Generated at 2022-06-25 22:11:51.382486
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.target == (3, 4)

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)



# Generated at 2022-06-25 22:11:54.526019
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    dict_unpacking_transformer_0.visit_Module(module_1)


# Generated at 2022-06-25 22:12:02.706526
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Init a class object
    a_s_t_4 = module_0.AST()
    dict_unpacking_transformer_4 = DictUnpackingTransformer(a_s_t_4)
    # Init a AST object
    a_s_t_5 = module_0.AST()
    # Create a Dict object with "keys" and "values" 
    keys_5 = []
    keys_5.append(1)
    keys_5.append(2)
    keys_5.append(3)
    values_5 = []
    values_5.append(1)
    values_5.append(2)
    values_5.append(3)
    d_i_c_t_5 = module_0.Dict(keys_5, values_5)
    # Call method visit_Dict

# Generated at 2022-06-25 22:12:11.091305
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    t_p_0_0 = module_0.Name(id='a')
    t_p_0_1 = module_0.Name(id='b')
    t_p_0_2 = module_0.Name(id='c')
    t_p_0_3 = module_0.Name(id='d')
    t_p_0_4 = module_0.Name(id='e')
    t_p_0_5 = module_0.Name(id='f')
    t_p_0_6 = module_0.Name(id='g')

# Generated at 2022-06-25 22:12:20.020526
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[module_0.Expr(value=module_0.Dict(keys=[None, module_0.Name(id='a', ctx=module_0.Load())], values=[module_0.Num(n=1), module_0.Name(id='dict_a', ctx=module_0.Load())]))])

# Generated at 2022-06-25 22:12:27.503237
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    test_case_0()
    string = '{1: 1, **dict_a}'
    dict_0 = dict_unpacking_transformer_0.parse(string)
    # var dict_0 = ast.parse(string)
    result_0 = dict_unpacking_transformer_0.visit(dict_0)


from argparse import ArgumentParser, Namespace, Action

from ..utils import get_tree



# Generated at 2022-06-25 22:12:33.142486
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_0_0.body = []
    module_0_0.type_ignores = []
    dict_unpacking_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:12:35.541124
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:12:56.008650
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    a_s_t_2 = module_0.Assign()
    a_s_t_3 = module_0.Name()
    a_s_t_4 = module_0.Name()
    a_s_t_5 = module_0.Dict()
    a_s_t_6 = module_0.Num()
    a_s_t_8 = module_0.Num()
    a_s_t_10 = module_0.Dict()
    a_s_t_11 = module_0.Name()

# Generated at 2022-06-25 22:13:04.581504
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.parse('{1: 1, **{}}', mode='eval')
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    output_0 = dict_unpacking_transformer_0.visit(module_0)
    assert output_0 == ast.parse('_py_backwards_merge_dicts([{1: 1}], {})', mode='eval')
    module_1 = ast.parse('{1: 1, 2: 2, **{3: 3}}', mode='eval')
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    output_1 = dict_unpacking_transformer_1.visit(module_1)

# Generated at 2022-06-25 22:13:09.626187
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Construct the expected result of the test

    # Get the result of the test
    from py_backwards.transformers.dict_unpacking import DictUnpackingTransformer
    ast_0 = module_0.AST()
    dictUnpackingTransformer_0 = DictUnpackingTransformer(ast_0)
    result = dict_unpacking_transformer_0.visit_Dict()


    # Compare the expected and the result
    assert result == expected_result



# Generated at 2022-06-25 22:13:15.322941
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_d_0 = module_0.Dict()
    a_t_0 = dict_unpacking_transformer_0.visit_Dict(a_d_0)

    assert isinstance(a_t_0, module_0.Dict) or isinstance(a_t_0, module_0.Call)
    assert True

# Generated at 2022-06-25 22:13:25.851180
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_1.body.append(module_0.Expr(value=module_0.Call(func=module_0.Name(id='_py_backwards_merge_dicts'), args=[module_0.List(elts=[module_0.Call(func=module_0.Name(id='dict'), args=[], keywords=[])])], keywords=[])))
    module_1.body.append(module_0.Expr(value=module_0.Name(id='_py_backwards_merge_dicts')))
    module_2 = dict_unpacking_transformer_0.vis

# Generated at 2022-06-25 22:13:27.487008
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:13:36.553777
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    a_s_t_1 = module_0.AST()
    module_1 = module_0.Module([])
    pass
    a_s_t_1._fields[0] = [module_1]

    a_s_t_2 = module_0.AST()
    module_2 = module_0.Module([])
    pass
    a_s_t_2._fields[0] = [module_2]

    a_s_t_3 = module_0.AST()
    module_3 = module_0.Module([])
    pass
    a_s_t_3._fields[0] = [module_3]



# Generated at 2022-06-25 22:13:39.656556
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:13:47.599005
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    test_str_1 = "keys=[key for key, _ in group]\nvalues=[value for _, value in group]"
    test_str_2 = "func=ast.Name(id='_py_backwards_merge_dicts')\nargs=[ast.List(elts=list(xs))]\nkeywords=[]"
    test_str_3 = "def _py_backwards_merge_dicts(dicts):\n\tresult = {}\n\tfor dict_ in dicts:\n\t\tresult.update(dict_)\n\treturn result"
    test_str_4 = "elif group:"

# Generated at 2022-06-25 22:13:55.556690
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    node_0 = module_0.Dict(keys = [None], values = [module_0.Num(n = - 5)])

    node_1 = dict_unpacking_transformer_0.visit_Dict(node_0)

    assert isinstance(node_1, module_0.Call)
    assert isinstance(node_1.func, module_0.Name)
    assert node_1.func.id == '_py_backwards_merge_dicts'
    assert isinstance(node_1.args, list)
    assert len(node_1.args) == 1

# Generated at 2022-06-25 22:14:27.932348
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:14:35.192149
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Make instance of AST.
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Arguments for __init__
    node = module_0.Module([module_0.Expr(module_0.Call(func=module_0.Name(id='dict', ctx=module_0.Load()), args=[module_0.Call(func=module_0.Name(id='dict', ctx=module_0.Load()), args=[], keywords=[])], keywords=[module_0.keyword(arg=None, value=module_0.Call(func=module_0.Name(id='dict', ctx=module_0.Load()), args=[], keywords=[]))]))])
    expect = module

# Generated at 2022-06-25 22:14:37.146818
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a = module_0.AST()
    dict_unpacking_transformer = DictUnpackingTransformer(a)


# Generated at 2022-06-25 22:14:46.506185
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    source_string_0 = '{\'a\': 1, \'b\': 2, **{\'c\': 3, \'d\': 4}}'
    source_parsed_0 = module_0.parse(source_string_0)
    source_dictionary_0 = module_0.dump(source_parsed_0)
    keys_0 = source_dictionary_0.keys()
    if 'Module' in keys_0:
        body_0 = source_dictionary_0['Module'][0]['body']
    else:
        body_0 = source_dictionary_0['Interactive'][0]['body']
   

# Generated at 2022-06-25 22:14:48.660952
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:14:52.889523
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    result_0 = dict_unpacking_transformer_0.visit_Module(module_1)
    assert result_0 == module_1


# Generated at 2022-06-25 22:14:58.138099
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer.__init__, TypedFunctionType)
    DictUnpackingTransformer.__init__.__annotations__['tree'] = module_0.AST
    DictUnpackingTransformer.__init__.__annotations__['return'] = NoneType
    DictUnpackingTransformer.__init__.__annotations__['args'] = (
        module_0.AST,
    )
    DictUnpackingTransformer.__init__.__kwdefaults__ = None
    

# Generated at 2022-06-25 22:14:59.173702
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # TODO: Implement test
    assert False


# Generated at 2022-06-25 22:15:02.690658
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0: module_0.Dict = None
    node_1: ast.Call = dict_unpacking_transformer_0.visit_Dict(node_0)



# Generated at 2022-06-25 22:15:12.218095
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module([])
    a_s_t_2 = module_0.Dict([None, None, None], [module_0.Num(1), module_0.Num(2), module_0.Num(3)])
    a_s_t_3 = module_0.Dict([module_0.Num(1)], [module_0.Num(1)])
    a_s_t_4 = module_0.Dict([module_0.Num(2)], [module_0.Num(2)])

# Generated at 2022-06-25 22:15:46.346744
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert True

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:15:50.267201
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = 2000
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)

# Generated at 2022-06-25 22:15:51.367839
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    try:
        DictUnpackingTransformer({})
    except:
        assert False
    assert True



# Generated at 2022-06-25 22:15:54.641979
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert True


# Generated at 2022-06-25 22:15:58.159872
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:16:00.586707
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:16:05.732276
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = None
    # Direct call to function
    module_x_var_0 = test_case_0()
    assert_equal(module_x_var_0, module_x_var_0)

test_DictUnpackingTransformer_visit_Module()

# Generated at 2022-06-25 22:16:13.541216
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert type(module_x_var_1) == module_0.Module

# Generated at 2022-06-25 22:16:17.117870
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:16:20.268828
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    # Constructor test 1
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)