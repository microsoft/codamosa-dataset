

# Generated at 2022-06-25 22:07:37.459639
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Input
    a_s_t_0 = module_0.AST()
    # Method call
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Expected output

# Generated at 2022-06-25 22:07:46.161248
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    a_s_t_2 = module_0.Num(1)
    a_s_t_3 = a_s_t_2
    a_s_t_4 = a_s_t_1
    a_s_t_5 = a_s_t_4.values.append(a_s_t_3)
    a_s_t_6 = a_s_t_0.Num(1)
    a_s_t_7 = a_s_t_6
    a_s_t_8 = a_s_t_4.keys

# Generated at 2022-06-25 22:07:50.485955
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_2 = module_0.Module()
    method_return_3 = dict_unpacking_transformer_1.visit_Module(module_2)


# Generated at 2022-06-25 22:07:56.949167
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast
    import typed_ast.ast3 as t_ast
    assert DictUnpackingTransformer.visit_Dict(DictUnpackingTransformer, t_ast.parse('''
d = {1: 2, 3: 4, **{5: 6, 7: 8}, 9: 10}
''').body[0].value) == t_ast.parse('''
_py_backwards_merge_dicts([{1: 2, 3: 4}, {9: 10}], {5: 6, 7: 8})
''').body[0].value


# Generated at 2022-06-25 22:08:05.807867
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typing
    import typed_ast._ast3 as module_0
    
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    
    # Test 1:
    get_source_code_tree_0 = module_0.parse("_py_backwards_merge_dicts([{1: 1}], dict_a})")
    get_target_code_tree_0 = module_0.parse('{"_py_backwards_merge_dicts": _py_backwards_merge_dicts, "dict_a": dict_a}') # type: typing.Undefined
    
    # Test 2:

# Generated at 2022-06-25 22:08:15.321505
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.parse("{1: 1, **dict_a}")
    a_s_t_0 = module_0
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    py_backwards_merge_dicts_body = merge_dicts.get_body()
    merge_dicts_body = ast.Module(body=[py_backwards_merge_dicts_body])
    assert len(module_0.body) == 1
    assert len(module_0.body[0].keys) == 2
    assert module_0.body[0].keys[0] == 1
    assert len(module_0.body[0].values[0].elts) == 0

# Generated at 2022-06-25 22:08:24.438443
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    node_0 = module_0.Dict(
        keys=[module_0.Num(n=1)],
        values=[module_0.Num(n=1)]
    )
    module_1.body.append(node_0)
    __tracebackhide__ = True
    assert dict_unpacking_transformer_0.visit(node_0) is node_0


# Generated at 2022-06-25 22:08:34.324654
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:08:41.205792
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    a_s_t_0 = ast3.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    expr_0 = ast3.Subscript(
        value=ast3.Name(id='a', ctx=ast3.Load()),
        slice=ast3.ExtSlice(dims=[
            ast3.Index(value=ast3.Num(n=0)),
            ast3.Index(value=ast3.Num(n=0)),
            ]),
        ctx=ast3.Load())

# Generated at 2022-06-25 22:08:50.578883
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0_0 = module_0.Module((), module_0.body((module_0.Expr(module_0.Dict(((module_0.Num(0), module_0.Num(1)), (None, module_0.Name('a', module_0.Load())), (module_0.Num(2), module_0.Name('b', module_0.Load()))),))),))
    a_s_t_1 = module_0.AST(filename='', type_comments=False, feature_version=34)

# Generated at 2022-06-25 22:09:16.862012
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[])

# Generated at 2022-06-25 22:09:22.599467
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    # initialize parameters with default values
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # initialize field '_tree_changed' with default value
    dict_unpacking_transformer_0._tree_changed = False
    a_dict_0 = module_0.Dict(keys=(module_0.Num(n=1), None), values=(module_0.Num(n=1), module_0.Name(id=dict_a, ctx=module_0.Load())), lineno=0, col_offset=0)
    # call function 'visit_Dict'
    a_call_0 = dict_unpacking_transformer_0.visit_Dict(a_dict_0)
   

# Generated at 2022-06-25 22:09:31.199408
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()

# Generated at 2022-06-25 22:09:37.512894
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0.parse('a')
    dict_unpacking_transformer_0.visit(a_s_t_0.body[0].value, None)
    print(a_s_t_0.body)
    assert 1 == 1

# Generated at 2022-06-25 22:09:43.221140
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Dict(keys=[], values=[])
    a_s_t_0.body.append(node_0)
    value_0 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert value_0 is node_0


# Generated at 2022-06-25 22:09:53.145294
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[None], values=[])
    a_s_t_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    try:
        assert a_s_t_0.__class__ == module_0.Call
    except AssertionError as e:
        e.__context__ = None
        raise
    try:
        assert a_s_t_0.func.__class__ == module_0.Name
    except AssertionError as e:
        e.__context__ = None
        raise

# Generated at 2022-06-25 22:09:57.404949
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = None
    dict_0 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert dict_0 is None


# Generated at 2022-06-25 22:10:01.249116
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    print("Testing visit_Dict")
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(a_s_t_1)

# Generated at 2022-06-25 22:10:11.940936
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    err = []
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    node_0 = a_s_t_0.Dict(keys=[], values=[])
    a_s_t_0.copy_location(node_0, None)
    a_s_t_0.fix_missing_locations(node_0)

    results_0 = dict_unpacking_transformer_0.visit_Dict(node_0)


# Generated at 2022-06-25 22:10:17.983061
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([], module_0.ModuleType(None))
    _ = dict_unpacking_transformer_0._visit_children(module_1)
    _ = dict_unpacking_transformer_0._visit_children(module_1)


# Generated at 2022-06-25 22:10:54.425532
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    # test case
    # with None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # iterable mock
    # items = []
    # items.append(('some_key', 'some_value'))
    # items.append((None, 'some_value'))
    # items.append(('some_key', 'some_value'))
    # items.append((None, 'some_value'))
    # items_iter_0 = iter(items)
    # dict_1 = module_0.Dict([module_0.keyword('some_key', 'key_0'), module_0.keyword(None, 'key_0'), module_0.keyword('some_key', '

# Generated at 2022-06-25 22:11:03.097697
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node = module_0.Dict()
    node.keys.append(None)
    node.keys.append(None)
    node.keys.append(None)
    node.keys.append(Module_0_0())
    node.values.append(Module_0_1())
    node.values.append(Module_0_2())
    node.values.append(Module_0_3())
    node.values.append(Module_0_4())
    module_0.DictUnpackingTransformer.visit_Dict(dict_unpacking_transformer_0, node)


# Generated at 2022-06-25 22:11:14.576935
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    a_s_t_2 = module_0.Dict()
    a_s_t_1 = a_s_t_2
    dict_unpacking_transformer_0.visit(a_s_t_1)

    if False:
        a_s_t_3 = module_0.Dict()
        a_s_t_1 = a_s_t_3
        dict_unpacking_transformer_0.visit(a_s_t_1)

    if False:
        a_s_t_4 = module_0.Dict()

# Generated at 2022-06-25 22:11:15.930262
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert 0 == (0)  # raise NotImplementedError()


# Generated at 2022-06-25 22:11:20.422357
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([])
    module_2 = dict_unpacking_transformer_0.visit(module_1)
    assert isinstance(module_2, module_0.Module)


# Generated at 2022-06-25 22:11:29.321147
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    call_0 = module_0.Call()

    call_0.lineno = 1
    call_0.col_offset = 1

    type_comment_0 = module_0.TypeComment()

    type_comment_0.lineno = 1
    type_comment_0.col_offset = 1

    expr_0 = module_0.Expr()

    expr_0.lineno = 1
    expr_0.col_offset = 1

    expr_1 = module_0.Expr()

    expr_1.lineno = 1
    expr_1.col_offset = 1

    slice_0 = module_0.Slice()

    slice

# Generated at 2022-06-25 22:11:31.970819
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0._tree_changed is True


# Generated at 2022-06-25 22:11:43.237964
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0 = module_0.Dict()
    a_s_t_0.keys = [module_0.Num(n=1)]
    a_s_t_0.values = [module_0.Num(n=1)]
    a_s_t_1 = module_0.Dict()
    a_s_t_1 = dict_unpacking_transformer_0.visit_Dict(a_s_t_0)
    assert a_s_t_1.__class__ == module_0.Dict

# Generated at 2022-06-25 22:11:52.441554
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_node_0 = module_0.Dict(keys=[None, module_0.Name(id='x')], values=[module_0.Dict(keys=[], values=[]), module_0.Num(n=1)])
    dict_result_0 = dict_unpacking_transformer_0.visit_Dict(ast_node_0)
    assert dict_result_0.values[0].keys == []
    assert dict_result_0.values[0].values == []
    assert dict_result_0.values[1].n == 1
    assert dict_result_0.values[2].keys == []
    assert dict_result

# Generated at 2022-06-25 22:12:00.623696
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Dict([], [])
    dict_unpacking_transformer_0._tree_changed = False
    union_type_0 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert (inspect.isclass(module_0.Dict) and inspect.isclass(union_type_0) and issubclass(union_type_0, module_0.Dict))
    assert (dict_unpacking_transformer_0._tree_changed == False)
    node_1 = module_0.Dict([], [], None)
    dict_unpacking_transformer_0

# Generated at 2022-06-25 22:12:30.234496
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:12:32.078377
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    obj_0 = DictUnpackingTransformer.DictUnpackingTransformer()
    obj_0.visit_Dict()


# Generated at 2022-06-25 22:12:37.850293
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    case_0_dict_0 = module_0.Dict()
    case_0_a_s_t_0 = module_0.AST()
    case_0_dict_unpacking_transformer_0 = DictUnpackingTransformer(case_0_a_s_t_0)
    case_0_var_0 = case_0_dict_unpacking_transformer_0.visit_Dict(case_0_dict_0)
    assert case_0_var_0 is None

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:12:44.211964
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

if (__name__ == '__main__'):
    test_case_0()
    test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:12:48.532778
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    try:
        test_case_0()
        print("test_DictUnpackingTransformer_visit_Dict() has passed..")
    except AssertionError as e:
        print("Test Failed", e)

if __name__ == "__main__":
    test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:12:56.998571
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    dict_1 = module_0.Dict()
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    var_1 = dict_unpacking_transformer_1.visit_Dict(dict_1)
    dict_2 = module_0.Dict()
    a_s_t_2 = module_0.AST()
    dict_unpacking_

# Generated at 2022-06-25 22:13:00.627034
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:13:04.919250
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:13:13.606368
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    snippet_0 = module_0.Constant()
    snippet_1 = module_0.Constant()
    snippet_2 = module_0.Constant()
    snippet_3 = module_0.Constant()
    snippet_4 = module_0.Constant()
    snippet_5 = module_0.Constant()
    snippet_6 = module_0.Constant()
    snippet_7 = module_0.Constant()
    snippet_8 = module_0.Constant()
    snippet_9 = module_0.Constant()
    snippet_10 = module_0.Constant()
    snippet_11 = module_0.Constant()
    snippet_12 = module_0.Constant()
    snippet_13 = module_0.Constant()
    snippet_14 = module_0.Constant()
    snippet_15

# Generated at 2022-06-25 22:13:19.578975
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    pass



# Generated at 2022-06-25 22:14:17.987504
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_1 = module_0.Dict()
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    var_1 = dict_unpacking_transformer_1.visit_Dict(dict_1)

# Generated at 2022-06-25 22:14:22.062209
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:14:26.833034
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0.AST())
    module_0.Dict()
    
    # Assert
    assert_equal(var_0.__class__, module_0.Dict)
    assert_equal(var_0.keys, [])
    assert_equal(var_0.values, [])

# Generated at 2022-06-25 22:14:34.506171
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast
    import typed_ast.ast3 as ast3
    import re
    
    def _assert_source(expected_source, actual_node):
        expected_source = expected_source.strip()
        actual_source = ast3.unparse(actual_node).strip()
        if expected_source != actual_source:
            print('Expected:', expected_source)
            print('Actual:', actual_source)
            print()
        assert expected_source == actual_source
    
    _assert_source(
        'def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result',
        merge_dicts.get_body())
    

# Generated at 2022-06-25 22:14:40.716951
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(var_0, module_0.Dict)


# Generated at 2022-06-25 22:14:44.783928
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.visit_Dict(dict_0) == dict_0

# Generated at 2022-06-25 22:14:53.068771
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    var_1 = dump(var_0)
    var_2 = len(var_1)
    assert(var_2 == 11)
    var_3 = var_1[1]
    var_4 = var_3.__class__
    var_5 = module_0.List
    var_6 = (var_4 is var_5)
    assert(var_6 == False)
    var_7 = var_1[1]
    var_8 = var_7.el

# Generated at 2022-06-25 22:14:57.479957
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert (var_0 == dict_0)

import typed_ast._ast3 as module_2


# Generated at 2022-06-25 22:15:01.551208
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
# def test_DictUnpackingTransformer_visit_Dict():


import sys


# Generated at 2022-06-25 22:15:07.373871
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert isinstance(var_0, module_0.Dict)


# Generated at 2022-06-25 22:16:06.555421
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(module_0)


# Generated at 2022-06-25 22:16:10.661615
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0._ast == a_s_t_0

if __name__ == '__main__':
    import pytest

    pytest.main(["-v", __file__])

# Generated at 2022-06-25 22:16:15.353755
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert str(var_0) == 'Dict()'

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:16:21.263377
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import functools
    try:
        dict_unpacking_transformer_0 = DictUnpackingTransformer()
        module_0 = importlib.import_module('typed_ast._ast3')
        dict_0 = module_0.Dict()
        dict_unpacking_transformer_0.visit_Dict(dict_0)
        assert func()
    except AttributeError:
        import sys
        print("Exception in user code:")
        print("-" * 60)
        traceback.print_exc(file=sys.stdout)
        print("-" * 60)
        raise


# Generated at 2022-06-25 22:16:22.010115
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass


# Generated at 2022-06-25 22:16:27.511129
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Module(module_0)

from _ast import AST
from asttokens import asttokens
from .base import BaseNodeTransformer
from .base import NodeTransformerContext

import _ast
import ast


# Generated at 2022-06-25 22:16:35.202248
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # It should accept Tree
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)

    # It should accept BaseNodeTransformer
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    node_transformer_0 = module_0.NodeTransformer()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(node_transformer_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:16:38.645986
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    with pytest.raises(TypeError):
        dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:16:39.543843
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # None
    var_0 = DictUnpackingTransformer()


# Generated at 2022-06-25 22:16:44.502543
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_0 = module_0.Dict()
    dict_1 = module_0.Dict()
    dict_2 = module_0.Dict()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = module_0.Module([], [dict_0, dict_1, dict_2])
    var_0 = dict_unpacking_transformer_0.visit_Module(module_0)

# Test for method visit_Dict of class DictUnpackingTransformer