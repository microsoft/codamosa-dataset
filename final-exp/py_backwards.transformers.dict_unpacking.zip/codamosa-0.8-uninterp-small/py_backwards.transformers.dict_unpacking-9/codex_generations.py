

# Generated at 2022-06-25 22:07:32.925344
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = ast.parse('d = {**{1: 2}, **{2: 3}}').body[0].value
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    _py_backwards_merge_dicts_1 = ast.parse(
            'def _py_backwards_merge_dicts(dicts):\n'
            '    result = {}\n'
            '    for dict_ in dicts:\n'
            '        result.update(dict_)\n'
            '    return result\n')
    insert_at(0, a_s_t_0, _py_backwards_merge_dicts_1.body)
    return a_s_t_0

# Generated at 2022-06-25 22:07:36.461782
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # test_DictUnpackingTransformer_visit_Dict
    # TODO: implement this test
    assert False  # no implementations yet


# Generated at 2022-06-25 22:07:41.429875
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = ast.Module(body=[])
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0 = ast.Module(body=[])
    assert a_s_t_0 == dict_unpacking_transformer_0.visit(a_s_t_0)


# Generated at 2022-06-25 22:07:45.372669
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    d = ast.Dict(keys=[None, ast.Constant(value=1)], values=[ast.Constant(value=1), ast.Constant(value=2)])
    result = dict_unpacking_transformer_0.visit_Dict(d)
    assert result is not None
    # Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-25 22:07:54.280356
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = ast.parse('a = {1: 1, **b}')
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0 = dict_unpacking_transformer_0.visit(a_s_t_0)
    assert a_s_t_0.body[0].value == ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'), args=[ast.List(elts=[ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)])]), ast.Name(id='b')], keywords=[])

test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:08:01.185980
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = ast.parse("class C:\n  def foo(self):\n    dict_a={}")
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = a_s_t_0
    result_0 = dict_unpacking_transformer_0.visit(node_0)
    assert isinstance(result_0, ast.AST)
    assert result_0.body[1].body[0].value.args[0].elts[0].values[0].keys[0].value is None

# Generated at 2022-06-25 22:08:10.059019
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer(None)
    dict_unpacking_transformer_0._tree_changed = True
    dict_unpacking_transformer_0._tree_changed = True

    dict_call_0 = ast.Call(posonlyargs=None,
                           args=[ast.List(elts=[], ctx=ast.Load())],
                           keywords=[])
    dict_call_0 = ast.Call(func=ast.Name(id='_py_backwards_merge_dicts',
                                         ctx=ast.Load()),
                           args=[ast.List(elts=[dict_call_0], ctx=ast.Load())],
                           keywords=[])


# Generated at 2022-06-25 22:08:19.461715
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = ast.Dict(keys=[], values=[])
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)
    assert hasattr(dict_unpacking_transformer_0, 'visit_Dict')
    assert callable(dict_unpacking_transformer_0.visit_Dict)
    dict_unpacking_transformer_0.visit_Dict(a_s_t_0)
    def expected_result():
        return ast.Dict(keys=[], values=[])
    assert dict_unpacking_transformer_0.result() == expected_result()



# Generated at 2022-06-25 22:08:30.840842
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = ast.parse('''class A:
    def __init__(self, a={1: 1, **dict_a}):
        pass''')
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.generic_visit = lambda x : x
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0.visit_Dict(ast.parse('''{1: 1, **dict_a}'''))
    assert dict_unpacking_transformer_0._tree_changed == True

# Generated at 2022-06-25 22:08:35.105667
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = None  # type: ast.Module
    a_s_t_2 = dict_unpacking_transformer_0.visit_Module(a_s_t_1)

# Generated at 2022-06-25 22:08:45.490464
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Init input
    # a_s_t_0 = None
    a_s_t_2 = ast.Dict()
    a_s_t_2.keys = [None, 1, None]
    a_s_t_2.values = [1, 1, 2]
    a_s_t_1 = ast.Dict(keys=None, values=a_s_t_2)

    # Call method
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ret_val_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)

    # Test return value
    assert isinstance(ret_val_0, ast.Call)

# Generated at 2022-06-25 22:08:46.342906
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()


# Generated at 2022-06-25 22:08:48.755263
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)



# Generated at 2022-06-25 22:08:54.550419
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Module(body=[])
    ast.fix_missing_locations(a_s_t_1)
    a_s_t_2 = dict_unpacking_transformer_0.visit(a_s_t_1)
    assert isinstance(a_s_t_2, ast.Module)



# Generated at 2022-06-25 22:09:01.878104
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    assert dict_unpacking_transformer_0._tree_changed == False



# Generated at 2022-06-25 22:09:06.874597
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = None
    try:
        module_1 = dict_unpacking_transformer_0.visit_Module(module_0)
    except Exception as inst_0:
        raise


# Generated at 2022-06-25 22:09:11.916903
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = ast.Dict(keys=[], values=[])
    dict_1 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    dict_2 = ast.Dict(keys=[], values=[])
    assert dict_1 == dict_2


# Generated at 2022-06-25 22:09:20.929653
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = ast.Module()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = ast.Module()
    r_0 = dict_unpacking_transformer_0.visit_Module(node_0)
    assert_equal(r_0.__class__, ast.Module)
    assert_equal(r_0.body[0].__class__, ast.Expr)
    assert_equal(r_0.body[0].value.__class__, ast.Call)
    assert_equal(r_0.body[0].value.func.__class__, ast.Name)
    assert_equal(r_0.body[0].value.func.id, '_py_backwards_merge_dicts')

# Generated at 2022-06-25 22:09:26.083984
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Function takes a_s_t_0 as an argument.
    # Failure message(s) unused.
    a_s_t_2 = parse('{1: 1, **dict_a}')
    # Function takes a_s_t_2 as an argument.
    # Failure message(s) unused.
    a_s_t_3 = ast.Module(body=[a_s_t_2])
    # Function takes a_s_t_3 as an argument.
    # Failure message(s) unused.
    a_s_t_4 = ast.Name(id='dict_a')
    # Function takes a_s_t_4 as an argument.


# Generated at 2022-06-25 22:09:33.381781
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = ast.Dict(keys=[None, ast.Num(n=1)], values=[a_s_t_0, a_s_t_0])
    obj_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    assert type(obj_0) == ast.Call
    assert obj_0.keywords == []
    assert type(obj_0.args[0]) == ast.List
    assert obj_0.args[0].ctx == ast.Load
    assert type(obj_0.args[0].elts[0]) == ast.Dict
    assert obj_0

# Generated at 2022-06-25 22:09:41.028932
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast.Dict([ast.Str('a'), ast.Str('b')], [ast.Str('c'), ast.Str('d')])
    # Unit test for method visit_Module of class DictUnpackingTransformer


# Generated at 2022-06-25 22:09:50.661000
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-25 22:09:56.666262
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = ast.Module([])
    module_1 = dict_unpacking_transformer_0.visit_Module(module_0)
    assert isinstance(module_1, ast.Module)
    assert module_1.body == [
        merge_dicts.get_body()  # type: ignore
    ]


# Generated at 2022-06-25 22:09:58.676105
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)



# Generated at 2022-06-25 22:10:01.592909
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Set up context
    a_s_t_0 = None

    # Invoke the function
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    # Check the results
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:10:03.611434
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Test with the default value for argument node
    dict_unpacking_transformer_0 = DictUnpackingTransformer(None)


# Generated at 2022-06-25 22:10:11.442096
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    a_s_t_0 = None
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = None
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_1)


if __name__ == '__main__':
    test_case_0()
    test_DictUnpackingTransformer()

# Generated at 2022-06-25 22:10:17.490681
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = ast.Dict(keys=[None, None, None], values=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)])
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Dict(a_s_t_0) # Should not raise any exceptions



# Generated at 2022-06-25 22:10:23.117321
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0 = ast.Module(body=[])
    dict_unpacking_transformer_0.visit(module_0)

    # Verify the fields of dict_unpacking_transformer_0
    assert dict_unpacking_transformer_0.tree_changed is True

    # Verify the fields of module_0
    assert len(module_0.body) == 1


# Generated at 2022-06-25 22:10:28.019875
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = ast.parse('x = {1: 1, **d}')  # type: ast.Module
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_1 = dict_unpacking_transformer_0.visit_Module(a_s_t_0)
    assert dict_unpacking_transformer_1.body[0].value.func.id == '_py_backwards_merge_dicts'  # type: ignore
    assert dict_unpacking_transformer_1.body[0].value.args[0].elts[0].values[0].n == 1  # type: ignore
    assert dict_unpacking_transformer_1.body[0].value.args[0].elts

# Generated at 2022-06-25 22:10:32.905587
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-25 22:10:35.426420
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    dict_unpacking_transformer_1.visit_Module


# Generated at 2022-06-25 22:10:44.900416
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()

    # {'bar': 'baz', **{'foo': 'bar', **{'f': 'b'}}}
    # ->
    # _py_backwards_merge_dicts([{'bar': 'baz'}, {'foo': 'bar'}, {'f': 'b'}])

    source_code = "{'bar': 'baz', **{'foo': 'bar', **{'f': 'b'}}}"
    expected_source_code = \
        "_py_backwards_merge_dicts([{'bar': 'baz'}, {'foo': 'bar'}, {'f': 'b'}])"
    expected_tree = ast.parse(expected_source_code)


# Generated at 2022-06-25 22:10:52.409938
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Setup
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    dict_unpacking_transformer_1._tree_changed = False
    dict_unpacking_transformer_1._visit_count = 0
    node1 = ast.parse("{1: 1, **dict_a}")
    # Exercise
    dict_unpacking_transformer_1.visit_Dict(node1)
    # Verify
    assert dict_unpacking_transformer_1._tree_changed
    assert dict_unpacking_transformer_1._visit_count == 5


# Generated at 2022-06-25 22:10:55.032571
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert_raises_regex(NotImplementedError, "No implementation for visit_Module.",
                        DictUnpackingTransformer().visit_Module, None)


# Generated at 2022-06-25 22:11:00.736706
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict1 = ast.Dict()
    dict1.keys.append(ast.Num(n=10))
    dict1.values.append(ast.Num(n=10))
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    dict_unpacking_transformer_1.visit(dict1)
    assert dict1.keys == [ast.Num(n=10)]
    assert dict1.values == [ast.Num(n=10)]


# Generated at 2022-06-25 22:11:02.462631
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()


# Generated at 2022-06-25 22:11:04.833608
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    DictUnpackingTransformer().visit_Dict(
        ast.parse("""{1: 1, **dict_a}""").body[0].value)

# Generated at 2022-06-25 22:11:16.246620
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    ast_int_literal_expr_2 = ast.Num(n=1)
    ast_int_literal_expr_3 = ast.Num(n=1)
    ast_keyword_4 = ast.keyword(arg='a', value=ast.Name(id='a', ctx=ast.Load()))
    ast_keyword_5 = ast.keyword(arg='b', value=ast.Name(id='b', ctx=ast.Load()))
    ast_keyword_6 = ast.keyword(arg=None, value=ast.Name(id='c', ctx=ast.Load()))

# Generated at 2022-06-25 22:11:20.151355
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    assert dict_unpacking_transformer_1._tree_changed == False
    # assert dict_unpacking_transformer_1.target == (3,4)
    # assert dict_unpacking_transformer_1.visit_Module == (3,4)

# Generated at 2022-06-25 22:11:28.528353
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer = DictUnpackingTransformer()
    assert isinstance(dict_unpacking_transformer, DictUnpackingTransformer)

    assert dict_unpacking_transformer._tree_changed == False

# TODO: Unit test for function _split_by_None of class DictUnpackingTransformer

# Generated at 2022-06-25 22:11:30.021043
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:11:41.608196
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_0 = lambda: assert_tree(
        DictUnpackingTransformer().visit(snippet('{1: 1}')),
        snippet('{1: 1}')
    )
    test_1 = lambda: assert_tree(
        DictUnpackingTransformer().visit(snippet('{**{1: 2}}')),
        snippet('_py_backwards_merge_dicts([{}], {1: 2})')
    )
    test_2 = lambda: assert_tree(
        DictUnpackingTransformer().visit(snippet('{**{1: 2}, **{2: 3}}')),
        snippet('_py_backwards_merge_dicts([{}], {1: 2}, {2: 3})')
    )
    test_3 = lambda: assert_tree

# Generated at 2022-06-25 22:11:43.350100
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    in_0 = ast.parse('import a.b')

# Generated at 2022-06-25 22:11:52.218816
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    sample_dict1 = ast.Dict(keys=[ast.Constant(1)], values=[ast.Constant(1)])
    sample_dict2 = ast.Dict(keys=[None], values=[ast.Name(id="dict_a")])
    sample_dict = ast.Dict(keys=[ast.Constant(1), None], values=[ast.Constant(1), ast.Name(id="dict_a")])
    assert DictUnpackingTransformer().visit(sample_dict) == ast.Call(func=ast.Name(id="_py_backwards_merge_dicts"),
                                                                     args=[ast.List(elts=[sample_dict1,
                                                                                           sample_dict2])],
                                                                     keywords=[])

# Generated at 2022-06-25 22:11:55.455471
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    with merge_dicts:
        ast_0 = ast.parse('def _py_backwars_merge_dicts(dicts):')
        d = DictUnpackingTransformer()
        a = d.visit_Module(ast_0)

# Generated at 2022-06-25 22:12:02.794892
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    dict_unpacking_transformer_1.target = (3, 7)
    source_1 = ast.parse('def _py_backwards_merge_dicts(a, b):\n    return dict(a, **b)')  # noqa
    expected_1 = ast.parse('def _py_backwards_merge_dicts(a, b):\n    return dict(a, **b)')  # noqa
    dict_unpacking_transformer_1.visit_Module(source_1)
    assert ast.dump(source_1) == ast.dump(expected_1)




# Generated at 2022-06-25 22:12:11.160264
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Unit test for the case where the dict is not initialized
    dictUnpackingTransformer = DictUnpackingTransformer()
    dict_a = ast.Name(id='dict_a')
    dict_node_0 = ast.Dict(keys=[None], values=[dict_a])
    merged_dict = dictUnpackingTransformer.visit_Dict(dict_node_0)
    print("##### Test 0 #####")
    print("Original dict: ", dict_node_0)
    print("Merged dict: ", merged_dict)
    print("Current tree_changed: ", dictUnpackingTransformer._tree_changed)
    print("")
    assert dictUnpackingTransformer._tree_changed == True
    dictUnpackingTransformer.reset_tree_changed()

    # Unit test for the case where the dict is initialized with a single key-

# Generated at 2022-06-25 22:12:13.221393
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer = DictUnpackingTransformer()
    assert dict_unpacking_transformer.target == (3, 4)



# Generated at 2022-06-25 22:12:19.315433
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    string = """
    {
        'Foo': 42,
        'Bar': {1, 2, 3},
        **x
    }
"""
    expected_string = """
    _py_backwards_merge_dicts([{'Bar': {1, 2, 3}, 'Foo': 42}], x)
"""
    transformation_result = DictUnpackingTransformer().visit(ast.parse(string))  # type: ignore
    assert ast.dump(transformation_result) == expected_string

# Generated at 2022-06-25 22:12:39.285301
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    dict_unpacking_transformer_1._tree_changed = False
    dict_unpacking_transformer_1._visit_children = None
    dict_unpacking_transformer_1._func = None
    dict_unpacking_transformer_1._visit_enabled = False
    dict_unpacking_transformer_1._visit_disabled = False
    dict_unpacking_transformer_1._debug = False
    dict_unpacking_transformer_1.selector = None
    dict_unpacking_transformer_1.generic_visit = None
    dict_unpacking_transformer_1._visit_dynamic = None
    dict_unpacking_transformer_1._visit_static = None
    dict_unpacking_transformer

# Generated at 2022-06-25 22:12:46.944553
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()

    import astor

    source_code_0 = 'a = 1\n'
    module_0 = ast.parse(source_code_0)

    module_0 = dict_unpacking_transformer_1.visit(module_0)

    assert astor.to_source(module_0) == "def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\na = 1\n"


# Generated at 2022-06-25 22:12:55.710309
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    dict_unpacking_transformer_1.parent_stack.append(dict_unpacking_transformer_0)
    source_0 = ast.parse('def f(a):\n    return {1: 1, **a}')
    source_1 = dict_unpacking_transformer_1.visit(source_0)
    source_2 = ast.parse('def f(a):\n    return _py_backwards_merge_dicts([{1: 1}], a)')
    assert ast.dump(source_2, include_attributes=True) == ast.dump(source_1, include_attributes=True)


# Generated at 2022-06-25 22:12:58.763907
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    string = "assert {1, **kwargs}"
    nodes = ast.parse(string)
    dict_unpacking_transformer = DictUnpackingTransformer()
    result = dict_unpacking_transformer.visit(nodes)
    assert (str(result) == "assert _py_backwards_merge_dicts([{1}], kwargs)")

# Generated at 2022-06-25 22:13:03.012477
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_unpacking_transformer_0._tree_changed = True # type: bool
    dict_unpacking_transformer_0.visit_Dict(None)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 22:13:11.501925
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer = DictUnpackingTransformer()
    expected_ast_1 = ast.parse('''
    def f(a, b):
        return _py_backwards_merge_dicts([{1: 1}], b)
    ''').body[0]
    actual_ast_1 = ast.parse('''
    def f(a, b):
        return {1: 1, **b}
    ''').body[0]
    dict_unpacking_transformer.visit(actual_ast_1)
    assert ast.dump(expected_ast_1) == ast.dump(actual_ast_1)


# Generated at 2022-06-25 22:13:13.430928
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from typed_ast import ast3 as ast
    dict_unpacking_transformer_0 = DictUnpackingTransformer()


# Generated at 2022-06-25 22:13:25.193469
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    ast_tree_0 = ast.parse('{\n    "a": 1,\n    **a,\n    "b": 2,\n    **b,\n    "c": 3,\n    **c\n}\n')
    dict_unpacking_transformer_0.visit_Module(ast_tree_0)

# Generated at 2022-06-25 22:13:35.365356
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    node_0 = ast.parse('{1: 1, 2: 2, **dict_a}')
    node_1 = dict_unpacking_transformer_0.visit(node_0)
    assert node_1 == ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(elts=[
                ast.Dict(keys=[ast.Num(n=1), ast.Num(n=2)], values=[ast.Num(n=1), ast.Num(n=2)]),
                ast.Name(id='dict_a')
            ])
        ],
        keywords=[]
    )

# Generated at 2022-06-25 22:13:36.591022
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()


# Generated at 2022-06-25 22:14:06.279233
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-25 22:14:09.907587
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    unparsed_0 = parse("""
s = {1: 1, **{'a': 2}, **{'b': 3}, 4: 4}
""")
    desugared = dict_unpacking_transformer_0(unparsed_0)

# Generated at 2022-06-25 22:14:18.902015
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()

    dict_0 = ast.Dict(keys=[None, ast.Constant(value=1)],
        values=[ast.Constant(value=1), ast.Dict(keys=[], values=[])])
    dict_unpacking_transformer_0.visit(dict_0)

    dict_1 = ast.Dict(keys=[ast.Constant(value=1), None],
        values=[ast.Constant(value=1), ast.Dict(keys=[], values=[])])
    dict_unpacking_transformer_0.visit(dict_1)


# Generated at 2022-06-25 22:14:20.369468
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """def foo():
    return {1: 1, **dict_a}"""

# Generated at 2022-06-25 22:14:24.361034
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    result = dict_unpacking_transformer_0.visit_Module(node)
    assert result.s == "def _py_backwards_merge_dicts(dicts):result={}for dict_ in dicts:result.update(dict_)return result"


# Generated at 2022-06-25 22:14:25.993923
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:14:28.037377
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer = DictUnpackingTransformer()
    assert dict_unpacking_transformer.target == (3, 4)



# Generated at 2022-06-25 22:14:35.226990
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source_code_0 = """
        foo = {1: 2, 3: 4}
    """
    source_code_1 = """
        foo = {1: 2, **{"a": 1, "b": 2}}
    """
    source_code_2 = """
        foo = {1: 2, **{"a": 1, "b": 2}, "c": 3}
    """
    source_code_3 = """
        foo = {"c": 3, **{"a": 1, "b": 2}, "d": 4}
    """
    source_code_4 = """
        foo = {"c": 3, **{"a": 1, "b": 2}, "d": 4, **dict_a, 5: 6}
    """

# Generated at 2022-06-25 22:14:44.860947
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Arrange
    dict_unpacking_transformer_0 = DictUnpackingTransformer()

# Generated at 2022-06-25 22:14:49.122214
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    ast_0 = ast.parse('{1: 1, **dict_a}')
    res = dict_unpacking_transformer_0.visit(ast_0)
    assert (res == ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)'))



# Generated at 2022-06-25 22:16:03.187829
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected_output_0 = """class Foo:
  def bar(self, x):
    return (x * 2)

print((Foo()).bar(10))
"""
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    input_str_0 = """class Foo:
  def bar(self, x):
    return (x * 2)

print((Foo()).bar(10))
"""
    input_ast_0 = ast.parse(input_str_0)
    output_ast_0 = dict_unpacking_transformer_0.visit(input_ast_0)
    output_str_0 = compile(output_ast_0, "<string>", "exec")
    assert output_str_0 == expected_output_0



# Generated at 2022-06-25 22:16:04.288118
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    print("Constructor DictUnpackingTransformer does not have any test case")

# Generated at 2022-06-25 22:16:06.298688
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    

# Generated at 2022-06-25 22:16:12.940442
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("{'a': 'c', 'b': 'c',  **{'a': 'b'}, 'd': 'e', **{'f': 'g'}}")
    expected_tree = ast.parse("{'a': 'c', 'b': 'c', 'd': 'e'} = _py_backwards_merge_dicts([{'a': 'c', 'b': 'c', 'd': 'e'}, {'a': 'b'}, {'f': 'g'}])")
    DictUnpackingTransformer().visit(tree)
    expected_tree._fields = tree._fields
    assert equal_ast(tree, expected_tree)


# Generated at 2022-06-25 22:16:19.745252
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    ast_str = """def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result"""
    expected_0 = ast.parse(ast_str).body[0]
    mod = ast.Module(body=[expected_0])
    expected_0 = expected_0
    actual_0 = dict_unpacking_transformer_0.visit_Module(mod)
    assert ast.dump(expected_0) == ast.dump(actual_0.body[0])


# Generated at 2022-06-25 22:16:22.144382
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer = DictUnpackingTransformer()
    dict_unpacking_transformer.visit_Module(ast.parse("""\
        {1: 1, **dict_a}"""))


# Generated at 2022-06-25 22:16:23.944571
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()


# Generated at 2022-06-25 22:16:25.910141
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    dict_unpacking_transformer_0 = DictUnpackingTransformer()

    ehlo = 'ehlo'

    {2: 3, **{1: ehlo}}


# Generated at 2022-06-25 22:16:27.580462
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    DUT = DictUnpackingTransformer()
    # TODO: add test for visit_Module



# Generated at 2022-06-25 22:16:33.938335
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..parser import parse_string

    input = """{True: True, None: None, 'test': 'test', 0: 0, 1: 1}"""
    expected_output = """\
_py_backwards_merge_dicts([{True: True, 'test': 'test', 0: 0, 1: 1}], {None: None})
"""

    output = str(dict_unpacking_transformer_0.visit(parse_string(input)))
    print("\n".join(f"{i}|{line}" for i, line in enumerate(output.split("\n"))))

    assert output == expected_output
