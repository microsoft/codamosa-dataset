

# Generated at 2022-06-25 22:07:24.376317
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_Dict_0 = module_0.Dict()
    ast_Dict_0.keys = None
    dict_unpacking_transformer_0.visit_Dict(ast_Dict_0)


# Generated at 2022-06-25 22:07:26.369409
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()

# Unit tests for function _split_by_None from class DictUnpackingTransformer

# Generated at 2022-06-25 22:07:33.244252
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    # Test 0
    # _s_t_1 = ast.parse("{1: 1, **dict_a}")  # Fails
    # _a_s_t_1 = dict_unpacking_transformer_1.visit(_s_t_1)
    # self.assertEqual(ast.dump(_a_s_t_1), "_py_backwards_merge_dicts([{1: 1}], dict_a})")

# Generated at 2022-06-25 22:07:39.511389
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    result_0 = dict_unpacking_transformer_0.visit_Module(a_s_t_1)
    pass


# Generated at 2022-06-25 22:07:44.446156
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Empty case
    node_0 = module_0.Dict([], [])
    node_1 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert type(node_1) is module_0.Dict


# Generated at 2022-06-25 22:07:53.848098
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    d_o_m_0 = module_0.Module([], [])
    module_1 = dict_unpacking_transformer_0.visit(d_o_m_0)
    assert module_1 is not None and isinstance(module_1, module_0.Module)

# Generated at 2022-06-25 22:07:58.316187
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_0_1 = dict_unpacking_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:08:02.291975
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([], [])
    dict_unpacking_transformer_0.visit(module_1)


# Generated at 2022-06-25 22:08:05.035681
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Arguments
    test_case_module_0 = None


    module_0 = DictUnpackingTransformer.visit_Module(test_case_module_0)
    assert (module_0 == None)


# Generated at 2022-06-25 22:08:13.853397
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    pairs_0 = [(None, module_0.Name(id='', ctx=module_0.Load())), (None, module_0.Call(func=module_0.Name(id='', ctx=module_0.Load()), args=[], keywords=[]))]
    list_0 = []
    for args in pairs_0:
        list_0.append(module_0.Tuple({'elts': args, 'ctx': module_0.Load()}))
    module_0.Dict(keys=list_0)


# Generated at 2022-06-25 22:08:18.656800
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = ast.parse(inspect.getsource(test_case_0)).body[0].value

    actual = DictUnpackingTransformer.run(var_0)

    expected = None
    assert expected == actual, f'{expected} is expected, but got {actual}'



# Generated at 2022-06-25 22:08:19.599302
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = ast.Dict(keys=[None])

# Generated at 2022-06-25 22:08:23.321361
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_1 = None
    var_0 = None
    var_0 = {'a': 1, 'b': 2, 'c': 3, var_1: 1}


# Generated at 2022-06-25 22:08:31.168915
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source = 'var_0 = {1: 1, \'a\': 2, \'b\': 3, **var_1}'
    expected_result = "_py_backwards_merge_dicts([{\'b\': 3, \'a\': 2, 1: 1}], var_1)"
    expected_result = 'var_0 = %s' % expected_result
    actual_result = transformer.visit(ast.parse(source))
    actual_result = ast.unparse(actual_result)
    assert actual_result == expected_result


# Generated at 2022-06-25 22:08:33.514413
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_1 = {1: 1, **var_0}
    assert var_1 == dict() or var_1 == dict([(1, 1)])


# Generated at 2022-06-25 22:08:40.142936
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Set up context
    case_0 = test_case_0()
    node = ast.parse(dedent("""
        {1: 1, **dict_a}
        
    """))
    expected = ast.parse(dedent("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result""" + """
        _py_backwards_merge_dicts([{1: 1}], dict_a})
        
    """))

    # Exercise SUT
    transformer = DictUnpackingTransformer()
    actual = transformer.visit(node)

    # Verify
    assert transformer._tree_changed == True
    assert ast_equals(actual, expected)


# Generated at 2022-06-25 22:08:41.078634
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert test_case_0() == None

# Generated at 2022-06-25 22:08:41.887737
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-25 22:08:48.502681
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = ast.Dict(keys=[],
                     values=[])
    var_1 = None
    var_2 = ast.copy_location(
        ast.Dict(keys=[],
                 values=[]),
        var_0)
    dict_unpacking_transformer = DictUnpackingTransformer()
    var_3 = dict_unpacking_transformer.visit(var_2)
    assert var_3 == var_1
    assert not dict_unpacking_transformer.tree_changed


# Generated at 2022-06-25 22:08:51.483108
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source_0 = """
{1: 1, **dict_a}
"""
    expected_0 = """
_py_backwards_merge_dicts([{1: 1}], dict_a})
"""


# Generated at 2022-06-25 22:09:08.926823
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = ast.parse('{1: 1, **dict_a}', '', 'eval')
    var_1 = ast.body[0] # ast.Dict
    var_2 = DictUnpackingTransformer.visit_Dict(var_0, var_1) # ast.Call
    assert '_py_backwards_merge_dicts' == var_2.func.id


# Generated at 2022-06-25 22:09:11.553714
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = ast.parse(test_case_0.__doc__)
    DictUnpackingTransformer().visit_Module(var_0)
    assert var_0 == ast.parse(test_case_0.__doc__)


# Generated at 2022-06-25 22:09:18.386167
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = ast.parse('''{1: 1, **dict_a}''').body[0].value
    desired_output = ast.parse('''{1: 1, **_py_backwards_merge_dicts([{1: 1}], dict_a)}''').body[0].value
    actual_output = DictUnpackingTransformer().visit(source)
    assert ast.dump(actual_output) == ast.dump(desired_output)


# Generated at 2022-06-25 22:09:23.828387
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    tree = ast.parse(test_case_0.__code__.co_consts[0])  # type: ignore

    transformer = DictUnpackingTransformer()
    transformer.visit(tree)

    # Unit test for method _split_by_None of class DictUnpackingTransformer
    # Unit test for method _prepare_splitted of class DictUnpackingTransformer
    # Unit test for method _merge_dicts of class DictUnpackingTransformer

# Generated at 2022-06-25 22:09:32.023625
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    method = DictUnpackingTransformer().visit_Dict

# Generated at 2022-06-25 22:09:36.785510
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = None

    var_1 = {'var_1': 1}

    var_2 = {'var_2': 2, **var_0, 'var_1': 1, **var_1}

    var_3 = {'var_3': 3, **var_0, **var_1}


# Generated at 2022-06-25 22:09:45.315572
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test case
    var_0 = None
    merge_dicts_func = merge_dicts.get_body()
    obj_1 = DictUnpackingTransformer(ast.parse(test_case_0.__code__))
    tree = obj_1.visit(ast.Module(body=[ast.Expr(value=merge_dicts_func[0]), ast.Expr(value=var_0)]))
    assert obj_1._tree_changed == False
    assert ast.dump(tree) == ast.dump(ast.Module(body=[ast.Expr(value=merge_dicts_func[0]), ast.Expr(value=var_0)]))


# Generated at 2022-06-25 22:09:50.815896
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = ast.parse(
"""
{1: 1, **dict_a}
""")
    var_1 = ast.parse(
"""
{1: 1, **dict_a}
""")
    var_2 = DictUnpackingTransformer()
    var_3 = var_2.visit(var_0)
    var_4 = ast.dump(var_3)
    var_5 = ast.dump(var_1)
    assert var_4 == var_5

# Generated at 2022-06-25 22:09:53.969134
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert DictUnpackingTransformer.visit_Dict(None, ast.parse('{1: 1, **dict_a}').body[0].value) == '_py_backwards_merge_dicts([{1: 1}], dict_a)'

# Generated at 2022-06-25 22:09:59.886742
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_function = test_case_0
    from ast import dump
    from typing import Dict
    from copy import copy, deepcopy
    test_function_ast = ast.parse(test_function.__code__.co_consts[0])
    test_body_ast = test_function_ast.body
    transformer = DictUnpackingTransformer()
    new_body_ast = deepcopy(test_body_ast)
    transformer.visit(new_body_ast)
    result = dump(new_body_ast)
    print(result)


# Generated at 2022-06-25 22:10:19.291513
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = ast.parse("def _py_backwards_merge_dicts(dicts):\n\tresult = {}\n\tfor dict_ in dicts:\n\t\tresult.update(dict_)\n\treturn result\n")
    var_1 = ast.parse("a = {1: 1, **dict_a}\n")
    var_2 = ast.parse("a = _py_backwards_merge_dicts([{1: 1}], dict_a)\n")
    var_3 = ast.parse("a = {1: 1, **dict_a}")

    f_0 = ast.Module()
    f_1 = ast.Module()
    f_2 = ast.Module()
    f_3 = ast.Module()


# Generated at 2022-06-25 22:10:25.537224
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    sut = DictUnpackingTransformer()
    t = ast.parse('{True: False, False: True}')
    t = sut.visit(t)
    assert isinstance(t, ast.Module)
    assert isinstance(t.body[1], ast.Dict)
    assert len(t.body[1].keys) == 2
    assert isinstance(t.body[1].keys[0], ast.NameConstant)
    assert isinstance(t.body[1].keys[1], ast.NameConstant)
    assert t.body[1].keys[0].value == True
    assert t.body[1].keys[1].value == False



# Generated at 2022-06-25 22:10:29.671237
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Print code of method visit_Dict of class DictUnpackingTransformer."""
    from ._test_utils import rewrite
    import inspect
    import astor
    print(astor.to_source(rewrite(inspect.getsource(DictUnpackingTransformer.visit_Dict),
        DictUnpackingTransformer)))

# Generated at 2022-06-25 22:10:34.488504
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    global var_0
    astree = ast.parse("var_0 = {}")
    transformer = DictUnpackingTransformer()
    transformer.visit(astree)
    exec(compile(astree, filename="<ast>", mode="exec"))
    assert var_0 == {}


# Generated at 2022-06-25 22:10:44.161683
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    visitor = DictUnpackingTransformer()
    node = ast.parse("var_0 = {1: 1, 2: 2, **{3: 3}}")
    result = ast.Module(
        body=[
            ast.Assign(
                targets=[
                    ast.Name(id='var_0', ctx=ast.Store())],
                value=visitor.visit_Dict(node.body[0].value))])


# Generated at 2022-06-25 22:10:53.100405
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = merge_dicts.get_body()
    var_1 = ast.parse('{1: 1, **dict_a}')
    var_2 = DictUnpackingTransformer(var_1)
    (var_3, _) = var_2.transform()
    assert var_3.body[0] == var_0

# Generated at 2022-06-25 22:11:02.452874
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-25 22:11:08.361241
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import round_trip
    from ..cases import case_3x as target_module
    from .base import BaseNodeTransformerTestCase
    class DictUnpackingTransformerTestCase(BaseNodeTransformerTestCase):
        target_module = target_module
        transformer = DictUnpackingTransformer
        transform_target = 'Dict_0'
        expected_code = '{\n    1: 1,\n    **var_0\n}\n'
    round_trip(DictUnpackingTransformerTestCase)

# Generated at 2022-06-25 22:11:09.663112
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = None
    var_0 = DictUnpackingTransformer().visit(var_0)


# Generated at 2022-06-25 22:11:16.572230
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    var_0 = ast.parse("{1: 1, **dict_a}")
    var_0 = DictUnpackingTransformer().visit(var_0)
    assert repr(var_0) == "_py_backwards_merge_dicts([{1: 1}], dict_a)"


# Generated at 2022-06-25 22:11:30.022965
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    # When DictUnpackingTransformer.visit_Dict() is called on a node, the
    #  result is a node of dict statements, with keys and values corresponding
    #  to node.keys and node.values
    node = ast.parse('{"a": 1}').body[0]
    transformed_node = transformer.visit(node)
    assert isinstance(transformed_node, ast.Dict)
    assert transformed_node.keys[0].s == "a"
    assert transformed_node.values[0].n == 1

# Generated at 2022-06-25 22:11:39.169111
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from .. import remove_extra_semicolons

    from ..utils.tree import parse_code_to_ast, tree_to_str

    source_code = '''{1: 1, **dict_a}'''
    tree = parse_code_to_ast(source_code)
    new_tree = DictUnpackingTransformer().visit(tree)
    str_tree = tree_to_str(new_tree)
    assert str_tree == '_py_backwards_merge_dicts([{1: 1}], dict_a)'

# Generated at 2022-06-25 22:11:39.998351
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_0 = None


# Generated at 2022-06-25 22:11:41.340092
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer = DictUnpackingTransformer()


# Generated at 2022-06-25 22:11:42.448834
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None


# Generated at 2022-06-25 22:11:44.484691
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert DictUnpackingTransformer().visit(test_case_0.__ast__) == '_py_backwards_merge_dicts([])'

# Generated at 2022-06-25 22:11:45.654398
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    var_0 = DictUnpackingTransformer()


# Generated at 2022-06-25 22:11:49.361608
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_1 = ast.Module(body=[test_case_0()])
    var_0 = DictUnpackingTransformer()
    var_0.visit(var_1)
    assert var_1.body[1].name == '_py_backwards_merge_dicts'

# Generated at 2022-06-25 22:11:54.345828
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test case for testing the visit_Dict method of class
    DictUnpackingTransformer.
    
    """
    # Creating an object of class DictUnpackingTransformer
    transformer = DictUnpackingTransformer()
    # Creating an object  of class Dict
    var_0 = ast.Dict()
    # Comparing the result with the expected value
    var_1 = transformer.visit_Dict(var_0)
    assert (var_1 == var_0)


# Generated at 2022-06-25 22:11:57.942856
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    arg_0 = ast.Module([test_case_0()])
    obj_0 = DictUnpackingTransformer()
    out_0 = obj_0.visit_Module(arg_0)
    assert out_0 == ast.Module([test_case_0(), merge_dicts.get_body()])  # type: ignore



# Generated at 2022-06-25 22:12:11.237384
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.Module()

    # Type comment
    module_0.body = [
        ast.FunctionDef(
            name='test_case_0',
            args=ast.arguments(),
            body=[ast.Expr(value=ast.Name(id='None', ctx=ast.Store()))],
            decorator_list=[],
            returns=None,
            type_comment=None
        )
    ]
    expected = ast.Module()

    # Type comment

# Generated at 2022-06-25 22:12:17.171214
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    arg_0 = ast.parse("{1: 1, **{2: 2}}")
    arg_1 = ast.parse("_py_backwards_merge_dicts([{1: 1}], {2: 2})")
    arg_2 = arg_0.body[0].value
    arg_0 = arg_1.body[0].body[0].value
    _0 = DictUnpackingTransformer().visit_Dict(arg_2)
    assert _0 == arg_0


# Generated at 2022-06-25 22:12:20.923862
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test for method visit_Dict of class DictUnpackingTransformer"""
    from ..utils.tree import check_equal
    var_0 = ast.Dict(keys=[None], values=[1])
    check_equal(var_0, DictUnpackingTransformer().visit(var_0))

# Generated at 2022-06-25 22:12:30.806448
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    scope = test_case_0.__globals__.copy()
    scope.update(locals())
    input_code = '\nvar_0 = None\n'
    expected_code = '\ndef _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\n\nvar_0 = None\n'
    tree = ast.parse(input_code)
    tree = DictUnpackingTransformer().visit(tree)
    compiled_code = compile(tree, '<test>', 'exec')
    exec(compiled_code, scope)

# Generated at 2022-06-25 22:12:37.606781
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None

    class var_4(var_1):
        pass

    if (var_0 is not None):
        var_2 = {var_0: var_1}
    else:
        var_2 = {"a": var_1}

    var_3 = {
        "b": var_1,
        **{
            "c": var_1,
            **var_0
        }
    }
    var_4().foo(**var_0 or var_1 or var_2 or var_1 or var_1)


# Generated at 2022-06-25 22:12:45.570522
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = u'print(1, None, 1.1)'
    tree = ast.parse(source)
    node = tree.body[0]
    transformer = DictUnpackingTransformer()
    actual_result = ast.dump(transformer.visit(tree))

    expected_result = u'Module(body=[Expr(value=Call(func=Name(id="print", ctx=Load()), args=[Num(n=1), NoneType(), Num(n=1.1)], keywords=[])), Assign(targets=[Name(id="var_0", ctx=Store())], value=None)])'
    assert expected_result == actual_result


# Generated at 2022-06-25 22:12:54.696073
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Input
    inp_ast = ast.parse(inspect.getsource(test_case_0))
    res_as_pairs = (
                       (ast.Str(s='__name__'), ast.Str(s='__main__')),
                       None,
                       (ast.Str(s='var_0'), ast.Name(id='None'))
                   ),

    # Processing
    res_as_ast = DictUnpackingTransformer().visit(inp_ast)

    # Output
    out_as_ast = ast.parse("_py_backwards_merge_dicts([{'__name__': '__main__'}], var_0)")
    assert ast.dump(res_as_ast) == ast.dump(out_as_ast)



# Generated at 2022-06-25 22:12:55.540716
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_16 = None


# Generated at 2022-06-25 22:13:03.661716
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_0 = ast.parse("var_0 = None")
    assert isinstance(var_0, ast.Module)
    var_1 = DictUnpackingTransformer().visit(var_0)
    var_2 = ast.parse("_py_empty = ()\n_py_empty_dict = dict()\n_py_identity_dict = lambda x: dict(((k,v) for k, v in x.items()))\ndef _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\nvar_0 = None")
    assert isinstance(var_2, ast.Module)
    assert var_1 == var_2


# Generated at 2022-06-25 22:13:09.954247
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_1 = ast.Dict(
        keys=[
            ast.Str(s='a'),
            ast.Str(s='b'),
            ast.Str(s='c'),
        ],
        values=[
            ast.Num(n=1),
            ast.Num(n=2),
            ast.Num(n=3),
        ]
    )
    transformer = DictUnpackingTransformer()
    result = transformer.visit(var_1)
    assert isinstance(result, ast.Dict)
    assert len(result.keys) == 3
    assert len(result.values) == 3

# Generated at 2022-06-25 22:13:27.593473
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    source = """{a: 1, b: 2, **c, e: 3, **f}"""
    tree = ast.parse(source)
    DictUnpackingTransformer(source).visit(tree)
    assert ast.dump(tree) == """Module(body=[Assign(targets=[Name(id='var_0', ctx=Store())], value=Dict(keys=[Name(id='a', ctx=Load()), Name(id='b', ctx=Load()), Name(id='e', ctx=Load())], values=[Num(n=1), Num(n=2), Num(n=3)]))])"""


# Generated at 2022-06-25 22:13:31.008923
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    subject = DictUnpackingTransformer()
    body = [var_0]
    node = ast.Module(body)
    res = subject.visit_Module(node)
    assert res.body == [merge_dicts.get_body(), var_0]

# Generated at 2022-06-25 22:13:32.913900
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Test type of object
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)



# Generated at 2022-06-25 22:13:40.245396
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    arg_0 = ast.Module(
        body=[ast.Expr(value=ast.Name(id='__tracebackhide__', ctx=ast.Load()))]
    )
    instance_0 = DictUnpackingTransformer()
    instance_1 = instance_0
    assert isinstance(instance_1, DictUnpackingTransformer)
    assert instance_1.target == (3, 4)
    res_3 = astor.to_source(instance_1.visit_Module(arg_0))

# Generated at 2022-06-25 22:13:44.603348
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse(dedent("""\
    {1: 1, **dict_a}
    """))
    expected = ast.parse(dedent("""\

    _py_backwards_merge_dicts([{1: 1}], dict_a})
    """))
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-25 22:13:45.390521
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-25 22:13:47.667446
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_0 = None

test_DictUnpackingTransformer_visit_Module.__doc__ = (
"""Unit test for method visit_Module of class DictUnpackingTransformer""")
    

# Generated at 2022-06-25 22:13:48.426277
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-25 22:13:52.572682
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_0 = None
    assert isinstance(var_0, ast.Module)
    assert var_0.body == [None]
    var_1 = DictUnpackingTransformer(var_0)
    var_2 = var_1.visit(var_0)
    assert isinstance(var_2, ast.Module)
    assert var_2.body == [None]


# Generated at 2022-06-25 22:13:54.032422
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    var_0 = DictUnpackingTransformer()
    return var_0


# Generated at 2022-06-25 22:14:06.002950
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__name__ == 'DictUnpackingTransformer'


# Generated at 2022-06-25 22:14:08.859739
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_0 = None
    var_1 = ast.Module(body=[var_0])
    var_2 = DictUnpackingTransformer()
    var_3 = var_2.visit_Module(var_1)
    assert var_3 == var_1


# Generated at 2022-06-25 22:14:15.434709
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_0 = ast.Module([ast.Assign([ast.Name(id='var_0', ctx=ast.Store())], ast.Name(id='None', ctx=ast.Load()))])
    assert DictUnpackingTransformer().visit(var_0) == ast.Module([ast.Expr(value=ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'), args=[ast.List(elts=[])], keywords=[]))], [ast.Assign([ast.Name(id='var_0', ctx=ast.Store())], ast.Name(id='None', ctx=ast.Load()))])


# Generated at 2022-06-25 22:14:16.496681
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """Unit test for constructor"""
    var_1 = None


# Generated at 2022-06-25 22:14:26.436333
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_0 = ast.parse('def _py_backwards_merge_dicts(dicts):\n  result = {}\n  for dict_ in dicts:\n    result.update(dict_)\n  return result\n')
    var_1 = ast.parse('def f():\n  var_0 = None\n')
    var_2 = DictUnpackingTransformer()/var_1
    assert var_0.body[0].name == var_2.body[0].name
    assert var_0.body[0].args.args == var_2.body[0].args.args
    assert var_0.body[0].args.vararg == var_2.body[0].args.vararg

# Generated at 2022-06-25 22:14:28.146526
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_0 = None
    var_1 = _py_backwards_merge_dicts([{1: 1}], dict_a)

# Generated at 2022-06-25 22:14:35.130489
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .DictUnpackingTransformer import DictUnpackingTransformer
    import _ast as python_ast
    transformer = DictUnpackingTransformer()
    tree = ast.parse("""\
var_0 = None""")
    expected = ast.parse("""\
_py_backwards_merge_dicts = (lambda dicts:
    (dicts[0] if len(dicts) == 1 else _py_backwards_merge_dicts([dicts[0]] + dicts[1:]))).__get__(0)
var_0 = None""")
    tree_2 = transformer.visit(tree)
    assert ast.dump(tree_2) == ast.dump(expected)



# Generated at 2022-06-25 22:14:39.592024
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = test_case_0.__code__
    exp = test_case_0.__code__
    mod = ast.parse(src)
    transformer = DictUnpackingTransformer()
    res = transformer.visit(mod)
    assert ast.dump(mod) == ast.dump(exp)

# Generated at 2022-06-25 22:14:48.145062
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # We want this transformation only for python 3.4 or higher
    from typed_ast import ast3 as ast
    from typed_ast.transforms.DictUnpackingTransformer import DictUnpackingTransformer
    from typed_ast import python_versions
    from astunparse import unparse

    # Get a Python 3.4 or higher AST

# Generated at 2022-06-25 22:14:52.415242
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    var_0 = ast.Module([merge_dicts.get_body()])
    dict_unpacking_transformer = DictUnpackingTransformer()
    var_1 = ast.Module([merge_dicts.get_body()])
    assert dict_unpacking_transformer.visit_Module(var_0) == var_1


# Generated at 2022-06-25 22:15:08.492929
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Only running this test in Python 3
    if sys.version_info < (3,):
        return

    str_0 = '{1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)

if __name__ == '__main__':
    test_case_0()
    test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:15:10.272096
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()

# Generated at 2022-06-25 22:15:17.290955
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    var_2 = module_0.fix_missing_locations(var_1)
    var_3 = module_0.to_source(var_2)
    var_4 = '_py_backwards_merge_dicts([dict(a=1, b=2), c, dict(e=3)], f)'
    var_5 = var_3 == var_4
    assert var_5 == True


# Generated at 2022-06-25 22:15:19.636264
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:15:22.287824
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer = DictUnpackingTransformer('{a: 1,b: 2, **c, e: 3, **f}')
    assert dict_unpacking_transformer != None


# Generated at 2022-06-25 22:15:23.393747
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    case_0 = test_case_0
    case_0()


# Generated at 2022-06-25 22:15:26.669312
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:15:31.707487
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Create an object of the class you want to test
    dict_unpacking_transformer_0 = DictUnpackingTransformer(None)
    assert dict_unpacking_transformer_0
    # Test the instance of the class FusedOperatorsTransformer
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)

# Generated at 2022-06-25 22:15:32.452491
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:15:41.357092
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    import typed_ast.ast3 as module_1
    str_1 = '{a: 1,b: 2, **c, e: 3, **f}'
    str_2 = '{a: 1,b: 2}'
    str_3 = '{a: 1, e: 3}'
    str_4 = 'dict(c)'
    str_5 = 'dict(f)'
    str_6 = '_py_backwards_merge_dicts([{a: 1,b: 2},dict(c),{a: 1, e: 3},dict(f)])'
    var_0 = module_1.parse(str_1)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_1)
    var_1 = dict_unpacking_transformer_0.visit

# Generated at 2022-06-25 22:15:56.658669
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:16:00.620412
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
    dict_unpacking_transformer_0.write_source(str_0)
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:16:02.785418
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    module_0.Module()
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    assert isinstance(var_1, module_0.Module)


# Generated at 2022-06-25 22:16:08.171035
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    try:
        str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
        var_0 = module_0.parse(str_0)
        dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
        var_1 = dict_unpacking_transformer_0.visit(var_0)
    except Exception as exception_0:
        assert False
    else:
        assert True


# Generated at 2022-06-25 22:16:13.189534
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = '{a: 1, **c, e: 3}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    str_1 = str(var_1)
    assert str_1 == "_py_backwards_merge_dicts([{'a': 1}, c, {'e': 3}])"


# Generated at 2022-06-25 22:16:16.547152
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    assert dict_unpacking_transformer_0.source == str_0


# Generated at 2022-06-25 22:16:18.427558
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    return dict_unpacking_transformer_0


# Generated at 2022-06-25 22:16:25.801115
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = '{a: 1,b: 2, **c, e: 3, **f, g: 5}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    var_2 = module_0.fix_missing_locations(var_1)
    var_3 = module_0.dump(var_2)
    var_4 = '_py_backwards_merge_dicts([{a: 1, b: 2, e: 3, g: 5}], c, f)'
    assert var_3 == var_4


# Generated at 2022-06-25 22:16:26.921128
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:16:30.278854
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:16:57.490367
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a = None
    b = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a, b)
    assert dict_unpacking_transformer_0._tree_changed == False

if __name__ == '__main__':
    test_DictUnpackingTransformer()

# Generated at 2022-06-25 22:17:01.209537
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = '{a: 1,b: 2, **c, e: 3, **f}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    assert (isinstance(var_1, (dict,)))
    assert (isinstance(var_1, (module_0.Module,)))


# Generated at 2022-06-25 22:17:05.254244
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = '{a: a,b: b, **c, e: e, **f}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    assert str(var_1) == '_py_backwards_merge_dicts([{a: a, b: b}, dict([(e, e)])], c, f)'

# Generated at 2022-06-25 22:17:07.525790
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer('<?>')
    assert dict_unpacking_transformer_0

if __name__ == '__main__':
    test_case_0()
    test_DictUnpackingTransformer()

# Generated at 2022-06-25 22:17:09.712993
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    str_2 = '{a: 1,b: 2}'
    var_2 = module_0.parse(str_2)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(str_2)


# Generated at 2022-06-25 22:17:13.034300
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()
    # no error
    # no error
    # no error
    # no error
    # no error
    # no error
    # no error
    # no error
    # no error
    # no error
    # no error
    # no error
    # no error
    # no error
