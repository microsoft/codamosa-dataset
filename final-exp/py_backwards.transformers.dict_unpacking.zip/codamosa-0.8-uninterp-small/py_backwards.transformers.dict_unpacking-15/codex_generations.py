

# Generated at 2022-06-25 22:07:30.425003
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Dict(a_s_t_0.Call())
    dict_unpacking_transformer_0.visit_Dict(a_s_t_0.Dict())


# Generated at 2022-06-25 22:07:39.075406
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Module()
    x_0 = module_0.Expr(value=node_0)
    s_0 = module_0.Return(value=x_0)
    func_0 = module_0.FunctionDef(name='foo', body=[s_0], args=module_0.arguments(), decorator_list=[], returns=None)
    node_0.body = [func_0]
    x_1 = module_0.Name(id='foo', ctx=module_0.Load())
    c_0 = module_0.Call(func=x_1, args=[], keywords=[])
    s_

# Generated at 2022-06-25 22:07:46.161837
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    dict_0 = module_0.Dict(keys=[module_0.Constant(value=1, kind=None), module_0.Name(id='x', ctx=module_0.Load())], values=[module_0.Constant(value=1, kind=None), module_0.Constant(value=2, kind=None)])

    dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:07:55.422130
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[module_0.Constant(value=1), module_0.Constant(value=2), module_0.NameConstant(value=None)], values=[module_0.Constant(value=2), module_0.Constant(value=3), module_0.Constant(value=3)])

# Generated at 2022-06-25 22:07:59.294270
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:08:07.943985
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    class_0 = module_0.Load()
    class_1 = module_0.Load()
    class_2 = (module_0.Name('_py_backwards_merge_dicts', module_0.Load()))
    class_3 = (module_0.Call(func=class_2, args=module_0.List(elts=[], ctx=class_0), keywords=[]))
    class_4 = (module_0.Name('dict', module_0.Load()))

# Generated at 2022-06-25 22:08:13.646767
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Call method for class DictUnpackingTransformer
    # and method visit_Dict for class DictUnpackingTransformer
    assert isinstance(dict_unpacking_transformer_0.visit_Dict(dict()), module_0.Call)

# Generated at 2022-06-25 22:08:24.439438
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0_0 = module_0.Dict(keys=[], values=[])
    union_type_0_0 = dict_unpacking_transformer_0.visit_Dict(dict_0_0)
    assert union_type_0_0 == dict_0_0
    dict_0_1 = module_0.Dict(keys=[None], values=[])
    union_type_0_1 = dict_unpacking_transformer_0.visit_Dict(dict_0_1)
    assert type(union_type_0_1) is module_0.Call

# Generated at 2022-06-25 22:08:34.276899
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    a_s_t_1 = module_0.Dict([module_0.Name(id='a', ctx=module_0.Load(), annotation=None), module_0.Name(id='b', ctx=module_0.Load(), annotation=None)], [module_0.Num(n=1), module_0.Num(n=2)])
    union_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    assert type(union_0) == module_0.Dict


# Generated at 2022-06-25 22:08:40.200607
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    visit_dict_0_0 = dict_unpacking_transformer_1.visit
    visit_dict_0_1 = visit_dict_0_0(module_0.Dict(module_0.Name(id_0='a'),module_0.Name(id_0='b')))

# Generated at 2022-06-25 22:09:00.942927
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[module_0.Name(id='k_f_i_0')], values=[module_0.Name(id='v_f_i_0')])

# Generated at 2022-06-25 22:09:09.503922
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_1 = module_0.Dict(keys=[module_0.Num(n=1), None], values=[module_0.Num(n=1), module_0.Name(id='dict_a', ctx=module_0.Load())])
    call_0 = dict_unpacking_transformer_0.visit_Dict(ast_1)
    assert isinstance(call_0, module_0.Call)
    assert call_0.func.id == '_py_backwards_merge_dicts'


# Generated at 2022-06-25 22:09:19.670096
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.generic_visit = Mock(
        side_effect=dict_unpacking_transformer_0.generic_visit)

    a_s_t_0.parse = Mock(side_effect=lambda x, mode=None: module_0.parse(x, mode))
    dict_0 = module_0.Dict(keys=[module_0.Name(id=1), None],
                           values=[module_0.Num(n=1), module_0.Name(id='dict_a')])
    dict_unpacking_transformer_0.visit(dict_0)
    dict_unpacking_trans

# Generated at 2022-06-25 22:09:25.547528
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    foo = object()
    bar = object()
    baz = object()
    node = {1: foo, b"foobar": bar, None: baz}
    template_0 = DictUnpackingTransformer(node)
    expected_0 = {1: foo, b"foobar": bar, None: baz}
    template_0.visit_Dict()
    assert node == expected_0

if __name__ == '__main__':
    test_case_0()
    test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:09:35.395725
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    
    node_0 = module_0.Dict()
    node_1 = module_0.Num()
    node_1.n = 1
    
    result_0 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert result_0 is node_0
    result_1 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert result_1 is node_0
    
    node_0.keys = [node_1]
    result_2 = dict_unpacking_transformer_0.visit_Dict(node_0)

# Generated at 2022-06-25 22:09:45.275255
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.visit_Dict(None) is None
    assert dict_unpacking_transformer_0.visit_Dict(None) is None
    assert dict_unpacking_transformer_0.visit_Dict(None) is None
    assert dict_unpacking_transformer_0.visit_Dict(None) is None
    assert dict_unpacking_transformer_0.visit_Dict(None) is None
    assert dict_unpacking_transformer_0.visit_Dict(None) is None

# Generated at 2022-06-25 22:09:54.153407
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    abc_0 = module_0.NameConstant(value=None)
    abc_1 = ['ast3_Dict_5']
    abc_2 = ['ast3_Dict_1']
    abc_3 = ['ast3_Call_5']
    abc_4 = ['ast3_Dict_0']
    abc_name_1 = 'x'
    abc_name_0 = '_py_backwards_merge_dicts'
    abc_name_2 = 'd'
    abc_name_3 = 'd'
    abc_name_4 = '_py_backwards_merge_dicts'

# Generated at 2022-06-25 22:10:01.618276
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    keys_0 = [module_0.Name('a', module_0.Load()), module_0.Name('b', module_0.Load())]
    values_0 = [module_0.Name('a', module_0.Load()), module_0.Name('b', module_0.Load())]
    node_0 = module_0.Dict(keys_0, values_0)
    dict_unpacking_transformer_0.visit(node_0)
    node_1 = module_0.Dict(keys_0, values_0)
    node_1 = module_0.Dict(keys_0, values_0)


# Generated at 2022-06-25 22:10:11.904887
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[None], values=[module_0.Num(n=1)])
    module_0.copy_location(dict_0, None)
    module_0.fix_missing_locations(dict_0)
    dict_unpacking_transformer_0.visit(dict_0)
    dict_unpacking_transformer_0.visit_Name(dict_0)
    dict_unpacking_transformer_0.visit_Num(dict_0)
    dict_unpacking_transformer_0.visit_Module(dict_0)

# Generated at 2022-06-25 22:10:21.274233
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Dict()
    dict_0 = dict(a='a', b=1)
    dict_unpacking_transformer_0._split_by_None = lambda x: x
    dict_unpacking_transformer_0._prepare_splitted = lambda x: x
    dict_unpacking_transformer_0._merge_dicts = lambda x: x
    dict_unpacking_transformer_0._tree_changed = True
    result_0 = dict_unpacking_transformer_0.visit_Dict(node_0)
    assert result_0 is not None

    # print(result_0, repr

# Generated at 2022-06-25 22:10:49.281167
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test case data
    module_0 = module_0
    module_0.name = '<string>'
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0)
    dict_unpacking_transformer_0.generic_visit = _generic_visit_fake
    dict_unpacking_transformer_0._tree_changed = true
    dict_unpacking_transformer_0._tree_changed = false
    dict_unpacking_transformer_0._tree_changed = true
    dict_unpacking_transformer_0._tree_changed = true
    dict_unpacking_transformer_0._tree_changed = false
    dict_unpacking_transformer_0._tree_changed = true
    dict_unpacking_transformer_0._tree_changed = false
    dict_unpacking

# Generated at 2022-06-25 22:10:58.473413
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    keys_0 = [module_0.Num(n=1.0), None]
    values_0 = [module_0.Num(n=1.0), module_0.Name(id='dict_a')]
    dict_0 = module_0.Dict(keys=keys_0, values=values_0)

# Generated at 2022-06-25 22:11:04.630486
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[], values=[])
    a_s_t_2 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    assert isinstance(a_s_t_2, module_0.Dict)


# Generated at 2022-06-25 22:11:16.094163
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    a_s_t_1.keys = [None, ast.Name(id='b', ctx=ast.Load())]
    a_s_t_1.values = [ast.Str(s='a', kind=None), ast.Str(s='asd', kind=None)]

    out_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)

# Generated at 2022-06-25 22:11:24.795497
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # test cases
    module_1 = """{1: 1}"""
    module_2 = """{1: 1, **dict_a}"""
    module_3 = """{1: 1, *dict_a}"""
    module_4 = """{1: 1, **dict_a, 2: 2, **dict_b}"""
    module_5 = """{1: 1, **{}, {}: 2}"""
    module_6 = """{1: 1, **{2: 3, 4: 7}, 6: 0}"""
    module_7 = """{**{2: 3}, **{4: 7}, 6: 0}"""
    module_8 = """{**{2: 3}, 4: 7, **{6: 0}}"""

    # test code
    a_s_t_8 = module_0.AST()


# Generated at 2022-06-25 22:11:32.030955
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
        from typed_ast import ast3 as ast
        from typed_ast.ast3 import Dict, Name, Call, List, keyword
        from ..utils.tree import node, tree_to_str
        from .base import BaseNodeTransformer
        from .base import BaseNodeTransformer
        from .base import BaseNodeTransformer
        from .base import BaseNodeTransformer
        from .base import BaseNodeTransformer
        from .base import BaseNodeTransformer
        a_s_t_0 = ast.AST()
        dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:11:40.878485
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.parse('{1: 1, **True}')
    assert dict_unpacking_transformer_0.visit(a_s_t_1) == module_0.parse('_py_backwards_merge_dicts([{1: 1}], True)')


# Generated at 2022-06-25 22:11:43.498946
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:11:52.690353
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    null = None

    # Initialization
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)

    # Visit ast.Dict()
    node_1 = ast.Dict(keys = [], values = [])
    node_2 = dict_unpacking_transformer_1.visit(node_1)

    # Expecting ast.Dict()
    assert isinstance(node_2, ast.Dict)
    assert node_2.lineno == node_1.lineno
    assert node_2.col_offset == node_1.col_offset
    assert isinstance(node_2.keys, list) and len(node_2.keys) == 0

# Generated at 2022-06-25 22:12:00.624714
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:12:19.164033
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_1.body = []

# Generated at 2022-06-25 22:12:28.733609
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = True
    dict_0 = module_0.Dict(keys=[None], values=[module_0.Constant(value=None)])
    dict_1 = module_0.Dict(keys=[module_0.Str(s='val1')], values=[module_0.Constant(value=None)])

# Generated at 2022-06-25 22:12:36.465834
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)
    # Asserts that method visit_Call calls method generic_visit
    assert dict_unpacking_transformer_0.visit_Call(a_s_t_0.Call()) == module_0.Call()
    # Check for attribute tree_changed
    assert dict_unpacking_transformer_0.tree_changed
    # Check for attribute target
    assert dict_unpacking_transformer_0.target == (3, 4)

# Generated at 2022-06-25 22:12:38.144513
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0.AST())
    module_0_0 = module_0.Module()
    module_0_1 = dict_unpacking_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:12:48.088496
# Unit test for constructor of class DictUnpackingTransformer

# Generated at 2022-06-25 22:12:50.858509
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:12:58.884141
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_0 = module_0.parse("{1: 1, **dict_a}")
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0.visit(ast_0)
    assert dict_unpacking_transformer_0._tree_changed == True

# Generated at 2022-06-25 22:13:04.510740
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module([], [])
    module_0_1 = dict_unpacking_transformer_0.visit_Module(module_0_0)
    assert module_0_1 is not module_0_0
    return


# Generated at 2022-06-25 22:13:05.338416
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:13:08.275857
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t = module_0.AST()
    dict_unpacking_transformer = DictUnpackingTransformer(a_s_t)
    return dict_unpacking_transformer
test_DictUnpackingTransformer()


# Generated at 2022-06-25 22:13:27.536394
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()

# Generated at 2022-06-25 22:13:30.970409
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert(dict_unpacking_transformer_0 is not None)



# Generated at 2022-06-25 22:13:35.736794
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Dict()
    node_0.keys = [None]
    node_0.values = [None]
    print(dict_unpacking_transformer_0.visit(node_0))


# Generated at 2022-06-25 22:13:40.508569
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.Module([], [], [])
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0.visit_Module(a_s_t_0), module_0.Module)


# Generated at 2022-06-25 22:13:48.322482
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = True
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed = True
    dict_unpacking_transformer_0._tree_changed = False
    dict_

# Generated at 2022-06-25 22:13:56.263348
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module((module_0.Assign((module_0.Name('foo'), module_0.Dict((module_0.Num(1), module_0.Num(2)), (None, module_0.Name('x'))))),))
    module_2 = dict_unpacking_transformer_0.visit(module_1)
    assert isinstance(module_2, module_0.Module)
    assert len(module_2.body) == 2
    assert isinstance(module_2.body[0], module_0.FunctionDef)

# Generated at 2022-06-25 22:14:05.289837
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    from astor.code_gen import to_source as astor_to_source
    from astunparse import unparse as astunparse_unparse
    from typed_ast import ast3 as typed_ast_ast3
    from typed_ast import convert as typed_ast_convert
    import ast
    import astor
    import logging
    import sys
    original_source = """
import os
"""
    a = typed_ast_convert(ast.parse(original_source), a_s_t_0)
    print(astunparse_unparse(a))
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:14:09.515606
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import sys, os, random
    import astunparse
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([])
    module_2 = dict_unpacking_transformer_0.visit_Module(module_1)
    assert(module_2)


# Generated at 2022-06-25 22:14:15.576282
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = module_0.Module()
    module_2.body = list()
    module_2.body.append(module_1)
    module_3 = dict_unpacking_transformer_0.visit_Module(module_2)
    assert (module_3._fields == ('body',))
    assert (module_3.body is module_2.body)


# Generated at 2022-06-25 22:14:18.975368
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0.Dict([module_0.Num(1), module_0.Num(2)], [module_0.Num(3), module_0.Num(4)], module_0.Load())


# Generated at 2022-06-25 22:14:40.130527
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass



# Generated at 2022-06-25 22:14:48.514320
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    # Source node of type Module
    source_module_0 = None
    # Target node of type Module
    target_module_0 = None
    # Unit test for DictUnpackingTransformer visit_Module
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Module(body=[])
    source_module_0 = ast.Module(body=[])
    target_module_0 = dict_unpacking_transformer_0.visit_Module(source_module_0)
    assert target_module_0 == source_module_0
    # Module(body=[])
    source_module_0 = ast.Module(body=[])
    target_module_0 = dict_unpacking_transformer_0.vis

# Generated at 2022-06-25 22:14:56.529635
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([
        module_0.Expr(module_0.Call(
            func=module_0.Name('print', module_0.Load()),
            args=[module_0.Str('Hello World!')],
            keywords=[]
        ))
    ])

    # function call on the next line
    result = dict_unpacking_transformer_0.visit_Module(module_1)
    assert isinstance(result, module_0.Module)
    assert isinstance(result.body[0], module_0.Expr)
    assert isinstance(result.body[0].value, module_0.Call)

# Generated at 2022-06-25 22:15:01.550957
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    m_0 = module_0.Module()
    module_0.Module()
    mod_0 = module_0.Module()
    mod_0.body = [module_0.parse(merge_dicts(), mode='eval')]
    assert dict_unpacking_transformer_0.visit_Module(m_0) == mod_0


# Generated at 2022-06-25 22:15:08.459068
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict(keys=[], values=[])
    dict_unpacking_transformer_0.visit_Dict(a_s_t_1)
    assert a_s_t_0.NodeTransformer.visit_Dict(dict_unpacking_transformer_0, a_s_t_1) == a_s_t_1

# Generated at 2022-06-25 22:15:12.892037
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    module_1 = module_0.Module(body = [])
    module_1 = dict_unpacking_transformer_0.visit_Module(module_1)
    assert module_1 is not None

    return


# Generated at 2022-06-25 22:15:19.152795
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_0_0.body = [module_0.Expr(value=module_0.Dict(keys=[None, None], values=[module_0.Num(n=1), module_0.Num(n=2)]))]
    module_0_1 = dict_unpacking_transformer_0.visit_Module(module_0_0)
    assert module_0_1.body[0].value.func.id == '_py_backwards_merge_dicts'
    assert module_0_1.body[0].value.args[0].elts[0].keys

# Generated at 2022-06-25 22:15:22.285892
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import ast as module_1
    a_s_t_1 = module_1.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)


# Generated at 2022-06-25 22:15:29.479782
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module(body=[])
    module_0_1 = dict_unpacking_transformer_0.visit(module_0_0, )
    assert module_0_1.__class__.__name__ == 'Module'
    assert module_0_1.body.__class__.__name__ == 'list'
    assert module_0_1.body[0].__class__.__name__ == 'FunctionDef'
    assert module_0_1.body[0].name == '_py_backwards_merge_dicts'
    assert module_0_1.body[0].args.__class

# Generated at 2022-06-25 22:15:39.878418
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    a_s_t_1 = module_0.Module(body=[])
    a_s_t_0.copy_location(a_s_t_1, None)
    a_s_t_0.set_context(a_s_t_1, None)
    a_s_t_0.set_lineno(a_s_t_1, 0)
    a_s_t_0.set_col_offset(a_s_t_1, 0)

    a_s_t_2 = module_0.Expr(value=a_s_t_1)
    a_s_t_0.copy_

# Generated at 2022-06-25 22:16:07.633779
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Test case for method visit_Module of class DictUnpackingTransformer.
    """
    # No arguments are provided, so we should fail with a TypeError
    try:
        DictUnpackingTransformer().visit_Module()
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-25 22:16:11.852926
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_13 = module_0.Module()
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_x_var_14 = dict_unpacking_transformer_1.visit_Module(module_x_var_13)

test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-25 22:16:16.120944
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)



# Generated at 2022-06-25 22:16:20.919518
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert (module_0.Module == type(module_x_var_1))


# Generated at 2022-06-25 22:16:28.844092
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # The code below is generated.
    # Edit it and rerun tests, but only inside the block marked with ### EDIT ###.
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert type(module_x_var_1) == module_0.Module
    assert module_x_var_1.body is not None
    assert len(module_x_var_1.body) == 1
    str_0 = str(module_x_var_1)

# Generated at 2022-06-25 22:16:30.060399
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    try:
        test_case_0()
    except RuntimeError:
        pass


# Generated at 2022-06-25 22:16:31.008415
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()
    assert True


# Generated at 2022-06-25 22:16:31.926594
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:16:34.199607
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    assert dict_unpacking_transformer_0 != None


# Generated at 2022-06-25 22:16:34.968416
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module_0 = test_case_0()