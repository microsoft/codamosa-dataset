

# Generated at 2022-06-25 22:07:34.690488
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # TODO: Enhance assertion
    assert dict_unpacking_transformer_0.visit_Dict(None) is not None

# Generated at 2022-06-25 22:07:43.671313
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict([module_0.Num(int('10', base=2))], [module_0.Num(int('10', base=2))])
    # Should reach the end of the method, so a test for statement coverage.
    dict_unpacking_transformer_0.visit_Dict(a_s_t_1)

# Generated at 2022-06-25 22:07:44.484558
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:07:53.888499
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([], [], [])
    dict_node_0 = module_0.Dict(keys=[], values=[])
    module_1.body.append(dict_node_0)
    module_0.fix_missing_locations(module_1)
    ast_0 = module_1
    module_2 = dict_unpacking_transformer_0.visit(ast_0)
    assert isinstance(module_2, module_0.Module) and module_1.body == module_2.body and module_1.body[0] == module_2.body[0]
    assert module_2.body

# Generated at 2022-06-25 22:07:54.712160
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass


# Generated at 2022-06-25 22:07:59.935775
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    dict_0 = module_0.Dict(keys=[], values=[])
    dict_unpacking_transformer_0.visit_Dict(dict_0)
    list_0 = list(dict_0.keys)

    assert list_0 is not None


# Generated at 2022-06-25 22:08:08.613545
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Call / return is not supported
    from test.test_fixtures.test_case_0 import dict_unpacking_transformer_0
    from test.test_fixtures.test_case_0 import a_s_t_0
    node_0 = module_0.Dict(keys = [], values = [])
    node_1 = dict_unpacking_transformer_0.visit_Dict(node_0)
    if isinstance(node_1, module_0.Dict):
        assert node_1.keys == []
        assert node_1.values == []
    elif isinstance(node_1, module_0.Call):
        assert node_1.func.id == '_py_backwards_merge_dicts'
        assert node_1.args == []
        assert node_1.key

# Generated at 2022-06-25 22:08:17.220510
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    # Test cases
    a_s_t_1 = module_0.Dict()

    try:
        assert(dict_unpacking_transformer_0.visit(a_s_t_1) == None)
    except:
        raise Exception(
            'DictUnpackingTransformer.visit_Dict failed for test case ' +
            '0')
    else:
        print('DictUnpackingTransformer.visit_Dict passed for test case 0')


# Generated at 2022-06-25 22:08:23.720249
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.generic_visit(dict_0)
    dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:08:28.690259
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:08:46.809650
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_1 = module_1.Module()
    str_0 = 'F'
    dict_0 = {str_0: None, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_1.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_1 = {str_0: str_0, str_0: str_0}
    dict_2 = {str_0: None}
    dict_3 = {str_0: dict_2}
    dict_4 = {str_0: dict_3}
    dict_5 = {str_0: dict_1, str_0: dict_1, str_0: dict_1}


# Generated at 2022-06-25 22:08:50.947588
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = dict_unpacking_transformer_0()
    dict_x_var_0 = module_0.Dict(keys=[None, None], values=[None, None])
    dict_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)

# Generated at 2022-06-25 22:08:59.100901
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.Dict()
    a_s_t_2 = dict_unpacking_transformer_0.visit_Dict(a_s_t_1)


# Generated at 2022-06-25 22:09:04.232243
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict()
    dict_unpacking_transformer_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)

# Generated at 2022-06-25 22:09:12.679847
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_2 = module_0.Module()
    dict_1 = {}
    dict_2 = {'name': 'a'}
    dict_3 = {'ctx': module_0.Load()}
    dict_4 = {'key': module_0.Name(**dict_2, **dict_3)}
    dict_5 = {'val': module_0.Num(n=2)}
    dict_6 = {'keyword': module_0.keyword(**dict_4, **dict_5)}
    dict_7 = {'kwargs': module_0.Name(id='kwargs')}

# Generated at 2022-06-25 22:09:13.504695
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert False #TODO, not implemented

# Generated at 2022-06-25 22:09:20.928803
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    global module_0
    from typed_ast import ast3 as module_0
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:09:29.968636
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict()
    arg_name_0, arg_name_1 = str_0, str_0
    func_0 = lambda arg_name_0, arg_name_1: arg_name_0 == arg_name_1
    value_0 = func_0(arg_name_0, arg_name_1)

# Generated at 2022-06-25 22:09:39.627951
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typing as t

    import typed_ast._ast3 as module_0
    import typed_ast.ast3 as module_1

    module_x_var_0 = module_0.Module()
    str_0 = '__name__'
    str_1 = '__main__'
    dict_0 = {str_0: str_1}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_1.Dict(keys=[], values=[])
    call_0 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)

# Generated at 2022-06-25 22:09:49.365505
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_2 = module_0.Module()
    module_x_var_3 = module_0.Dict(keys=[], values=[])
    module_x_var_4 = DictUnpackingTransformer(module_x_var_2)
    module_x_var_5 = module_x_var_4.visit_Dict(module_x_var_3)
    #   (if (isinstance group list) then (Dict (keys=[key for key value in group]), values=[value for key value in group]) else (Call (func=Name (id=dict), args=[group], keywords=[])))
    str_1 = 'D'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    a_s_t_1

# Generated at 2022-06-25 22:10:09.936817
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Set up the context for testing
    module_x_var_0 = ast.Module()
    dict_0 = {'body': [], 'type_ignores': []}
    a_s_t_0 = ast.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = {'keys': [None], 'col_offset': 0, 'lineno': 1, 'values': [None]}
    dict_1 = {'keys': [None], 'col_offset': 0, 'lineno': 1, 'values': [None]}
    dict_unpacking_transformer_1 = DictUnpackingTransformer(dict_0)
    dict_unpacking_transformer_2 = DictUnpackingTransformer(dict_1)


# Generated at 2022-06-25 22:10:18.889990
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)

# Generated at 2022-06-25 22:10:24.574751
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_1.visit_Dict(module_x_var_0)


# Generated at 2022-06-25 22:10:34.393435
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    dict_1 = module_0.Dict(**dict_0)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(dict_1)
    module_x_var_1 = dict_unpacking_transformer_1.visit_Module

# Generated at 2022-06-25 22:10:42.096509
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = DictUnpackingTransformer(None)
    str_0 = 'abc'
    list_0 = [str_0, str_0, str_0]
    module_0.generic_visit(list_0)
    str_1 = 'F'
    dict_0 = {str_1: str_1, None: str_1, str_1: str_1}
    a_s_t_0 = module_0.AST(**dict_0)
    module_0.visit_Dict(a_s_t_0)


# Generated at 2022-06-25 22:10:47.385378
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_1 = module_0.Module()
    str_1 = 'F'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    a_s_t_1 = module_0.AST(**dict_1)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    dict_x_var_0 = module_0.Dict()
    module_x_var_2 = dict_unpacking_transformer_1.visit_Dict(dict_x_var_0)

# Generated at 2022-06-25 22:10:51.533290
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_var_0 = module_0.Module()
    dict_var_0 = module_0.Dict()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(dict_var_0)
    dict_x_var_0 = dict_unpacking_transformer_1.visit_Dict(dict_var_0)

# Generated at 2022-06-25 22:11:00.532422
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = module_0.Dict(keys=['a', None, 'b'], values=[1, 2, 3])
    dict_unpacking_transformer_0 = DictUnpackingTransformer(dict_0)
    dict_unpacking_transformer_0._tree_changed = True
    dict_unpacking_transformer_0._tree_changed
    dict_unpacking_transformer_0._split_by_None(dict_unpacking_transformer_0)
    dict_unpacking_transformer_0._prepare_splitted(dict_unpacking_transformer_0)
    dict_unpacking_transformer_0._merge_dicts(dict_unpacking_transformer_0)
    dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:11:01.386886
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass

# Generated at 2022-06-25 22:11:08.591272
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)


# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 22:11:30.820276
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_0 = {'F': 'F', 'F': 'F', 'F': 'F'}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0.visit_Dict(a_s_t_0)


# Generated at 2022-06-25 22:11:42.411478
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = module_0.Module()
    str_0 = '__doc__'
    str_1 = '__module__'
    str_2 = '__qualname__'
    str_3 = '__annotations__'
    str_4 = '__dict__'
    str_5 = '__init__'
    str_6 = '__new__'
    str_7 = '__module__'
    str_8 = '__dict__'
    str_9 = '__init__'
    str_10 = '__new__'
    str_11 = '__module__'
    str_12 = '__dict__'
    str_13 = '__init__'
    str_14 = '__new__'
    str_15 = '__module__'

# Generated at 2022-06-25 22:11:51.794711
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:11:52.305101
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()

# Generated at 2022-06-25 22:12:00.040891
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict()
    dict_x_var_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)
    dict_0 = {str_0: str_0, str_0: str_0}


# Generated at 2022-06-25 22:12:08.164815
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_2 = module_0.Module()
    list_0 = []
    module_x_var_2.body = list_0
    int_0 = 0
    int_1 = 0
    name_0 = module_0.Name(id='F')
    module_x_var_2.body.append(module_0.Expr(value=name_0))
    const_0 = module_0.Constant(value=int_0)
    const_1 = module_0.Constant(value=int_1)
    int_2 = 0
    str_0 = 'F'
    int_3 = 0
    str_1 = 'F'
    int_4 = 0
    str_2 = 'F'
    int_5 = 0
    str_3 = 'F'
    int

# Generated at 2022-06-25 22:12:14.922590
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:12:22.052568
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    dict_0 = {'x': None, 'y': None}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)

import sys

# Generated at 2022-06-25 22:12:29.732540
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast._ast3 as module_0
    def test_case_0():
        module_x_var_0 = module_0.Module()
        str_0 = 'F'
        dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
        a_s_t_0 = module_0.AST(**dict_0)
        dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
        module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)


# Generated at 2022-06-25 22:12:36.730443
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_4 = module_0.Module()
    str_2 = 'F'
    str_3 = 'F'
    str_4 = 'F'
    dict_1 = {str_2: str_2, str_3: str_3, str_4: str_4,  str_3: 'F'}
    a_s_t_1 = module_0.AST(**dict_1)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_x_var_5 = dict_unpacking_transformer_1.visit_Module(module_x_var_4)

# Generated at 2022-06-25 22:13:17.933802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict(keys=[], values=[])
    set_attr_0 = setattr(dict_x_var_0, 'keys', [])
    set_attr_1 = setattr(dict_x_var_0, 'values', [])
    dict_unpacking_transformer_1 = dict_unpacking_transformer_0.visit_

# Generated at 2022-06-25 22:13:25.818249
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    module_x_var_0 = module_0.Module()
    module_x_var_0.body = []
    str_0 = 'D'
    int_0 = 0
    expr_list_0 = []
    int_1 = 1
    dict_0 = {str_0: str_0}
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_x_var_0)

    dict_unpacking_transformer_0.visit_Dict(dict_unpacking_transformer_0)

# Generated at 2022-06-25 22:13:35.663322
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test for correct parse of inputs
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    module_0 = module_0.Module()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_1 = module_0.AST(**dict_0)
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_

# Generated at 2022-06-25 22:13:44.602682
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_0 = {'abc': 'abc', 'abc': 'abc', 'abc': 'abc'}
    test_DictUnpackingTransformer_visit_Dict_0 = module_0.AST(**dict_0)
    dict_0 = {'abc': 'abc'}
    dict_1 = {'abc': 'abc'}
    dict_0.update(dict_1)
    test_DictUnpackingTransformer_visit_Dict_1 = module_0.Dict(**dict_0)
    dict_2 = {'abc': 'abc'}
    dict_3 = {'abc': 'abc'}
    dict_2.update(dict_3)
    test_DictUnpackingTransformer_visit_Dict_2 = module_0.Dict(**dict_2)
   

# Generated at 2022-06-25 22:13:50.252881
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_2 = module_0.Module()
    str_1 = 'F'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    a_s_t_1 = module_0.AST(**dict_1)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    module_x_var_3 = dict_unpacking_transformer_1.visit_Dict(module_x_var_2)


# Generated at 2022-06-25 22:13:57.059228
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = {}
    dict_x_var_0 = module_0.Dict(**dict_0)
    dict_unpacking_transformer_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)

# Generated at 2022-06-25 22:13:57.802399
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert (1, 2)


# Generated at 2022-06-25 22:14:05.507563
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict()
    dict_unpacking_transformer_1 = dict_unpacking_transformer_0.visit_Dict(dict_x_var_0)

# Generated at 2022-06-25 22:14:13.077960
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_0 = module_0.Dict()
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0._tree_changed
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    dict_x_var_1 = module_0.Dict()
    dict

# Generated at 2022-06-25 22:14:19.881455
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_1 = dict_unpacking_transformer_0.visit_Dict(module_x_var_0)

# Generated at 2022-06-25 22:15:41.593355
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    assert(isinstance(a_s_t_0, module_0.AST))


# Generated at 2022-06-25 22:15:44.560056
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    try:
        test_case_0()
    except NameError as err:
        print('Exception =  %s' % err)

# Generated at 2022-06-25 22:15:49.046021
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST(**{'spec': 'spec', 'body': 'body', 'type_ignores': 'type_ignores'})
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:15:49.725994
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:15:50.379270
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()


# Generated at 2022-06-25 22:15:57.411937
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    assert a_s_t_0 == a_s_t_1, 'AssertionError: assert a_s_t_0 == a_s_t_1'


# Generated at 2022-06-25 22:16:02.499782
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert(module_x_var_1.body == module_x_var_0.body)


# Generated at 2022-06-25 22:16:03.998087
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    try:
        test_case_0()
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 22:16:12.113684
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    str_1 = 'F'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    a_s_t_1 = module_0.AST(**dict_1)
    str_2 = 'F'
    dict_2 = {str_2: str_2, str_2: str_2, str_2: str_2}

# Generated at 2022-06-25 22:16:20.130337
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_x_var_0 = module_0.Module()
    str_0 = 'F'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0._tree_changed
    var_1 = dict_unpacking_transformer_0._ast
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)