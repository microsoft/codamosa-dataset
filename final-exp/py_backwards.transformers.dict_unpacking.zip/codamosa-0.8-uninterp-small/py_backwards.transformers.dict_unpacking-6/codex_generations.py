

# Generated at 2022-06-25 22:07:30.588787
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:07:39.231593
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    d_i_c_t_0 = module_0.Dict()
    d_i_c_t_0.keys = []
    d_i_c_t_0.values = []
    d_i_c_t_0.ctx = None
    d_i_c_t_0.lineno = 0
    d_i_c_t_0.col_offset = 0
    d_i_c_t_0 = dict_unpacking_transformer_0.visit_Dict(d_i_c_t_0)

# Generated at 2022-06-25 22:07:48.150123
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as module_0
    import typed_ast._ast3 as module_1
    import ast as module_2
    import typed_ast._ast3 as module_3
    a_s_t_0 = module_1.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    python_source_0 = ast.parse('def f():\n    {**{}, 1: 2, 3: 4}')
    class_0 = python_source_0.body[0].body[0].value
    module_3.copy_location(dict_unpacking_transformer_0.visit(class_0), class_0)

# Generated at 2022-06-25 22:07:55.951256
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    dict_0_0 = module_0.Dict()
    module_0_0.body = [dict_0_0]
    dict_0_0.keys = [module_0.Num(n=1)]
    dict_0_0.values = [module_0.Num(n=1)]
    dict_unpacking_transformer_0.visit_Dict(node=dict_0_0)


# Generated at 2022-06-25 22:08:04.882648
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_0 = module_0.Dict(
        keys=[
            module_0.Name(id="1"),
            None,
        ],
        values=[
            module_0.Num(n=1),
            module_0.Name(id="dict_a"),
        ],
    )

# Generated at 2022-06-25 22:08:07.262038
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    d_i_c_t_0 = module_0.Dict()
    dict_unpacking_transformer_0.visit_Dict(d_i_c_t_0)
    return None


# Generated at 2022-06-25 22:08:17.176851
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-25 22:08:24.393406
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[module_0.Num(n=1), None], values=[module_0.Num(n=1), module_0.Dict(keys=[], values=[])])
    dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:08:27.864434
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:08:31.923167
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # TODO: add test cases

    # Unreachable code
    return dict_unpacking_transformer_0


# Generated at 2022-06-25 22:08:36.218974
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x_0=module_0.AST()
    y_0=DictUnpackingTransformer(x_0)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 22:08:41.503262
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module((module_0.Expr(module_0.Dict(keys=(module_0.Num(n=1), None), values=(module_0.Num(n=1), module_0.Name(id='a')))),), lineno=1, col_offset=0)
    assert module_1 == dict_unpacking_transformer_0.visit(module_1)

# Generated at 2022-06-25 22:08:48.796527
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Function 'Module' should return Module object
    assert isinstance(
        dict_unpacking_transformer_0.visit_Module(module_0.Module()),
        module_0.Module
    )
    # Function 'Module' should change AST tree
    assert isinstance(
        dict_unpacking_transformer_0.visit_Module(module_0.Module()),
        module_0.Module
    )


# Generated at 2022-06-25 22:08:49.670096
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:08:52.603077
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0 is not None


# Generated at 2022-06-25 22:09:01.822153
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = """
        def foo():
            bar(1, 2, 3)
    """
    node_0 = ast.parse(module_0, '<test>', 'exec')
    node_1 = node_0.body[0]
    dict_unpacking_transformer_0 = DictUnpackingTransformer(node_0)
    setattr(dict_unpacking_transformer_0, '_tree_changed', True)
    node_2 = dict_unpacking_transformer_0.visit_Dict(node_1)
    assert isinstance(node_2, ast.Call)
    module_1 = """
        def foo():
            bar(1, 2, 3)
    """
    node_3 = ast.parse(module_1, '<test>', 'exec')
    assert node_2

# Generated at 2022-06-25 22:09:11.259668
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST({"loop_extra_checks": False, "enable_py3_loop_optimizations": False, "temp_hack_for_missing_kwargs": "func", "temp_hack_for_missing_kwargs_default": False, "compile_for_ast": False, "sort_variables_by_importance": False})
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    b_a_s_t_0 = module_0.AST()
    b_dict_unpacking_transformer_0 = DictUnpackingTransformer(b_a_s_t_0)

# Generated at 2022-06-25 22:09:18.147254
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_0_ret_val_0 = dict_unpacking_transformer_0.visit_Module(module_1)
    assert (isinstance(module_0_ret_val_0, module_0.Module))


# Generated at 2022-06-25 22:09:19.170497
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass


# Generated at 2022-06-25 22:09:28.786763
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    
    list_0 = []
    set_0 = set()
    dict_0 = dict()
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    a_s_t_1 = module_0.AST(
        body=[ module_0.Expr(value= module_0.Dict(keys=[ None ], values=[ module_0.Dict(keys=[ None ], values=[ module_0.Dict(keys=[ None ], values=[ module_0.NameConstant(value=None) ]) ]) ])) ]
    )
    assert dict_unpacking_transformer_0.visit_Module(a_s_t_1) == a_s_t_1

# Generated at 2022-06-25 22:09:39.223894
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_1 = module_0.AST()
    dict_1 = None
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_1)
    var_1 = dict_unpacking_transformer_2.visit_Dict(dict_1)
    dict_unpacking_transformer_3 = DictUnpackingTransformer(a_s_t_1)
    module_x_var_2 = module_0.Module()
    module_x_var_3 = dict_unpacking_transformer_3.visit_Module(module_x_var_2)

# Generated at 2022-06-25 22:09:48.975516
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    print("Started test_DictUnpackingTransformer_visit_Dict")
    module_0 = module_0.AST()
    dict_0 = module_0.Dict()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0)
    v_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    assert(v_0 is dict_0)

    dict_1 = module_0.Dict([
        module_0.Num(1),
        module_0.Num(1),
        
    ])
    dict_unpacking_transformer_1 = DictUnpackingTransformer(module_0)
    v_1 = dict_unpacking_transformer_1.visit_Dict(dict_1)

# Generated at 2022-06-25 22:09:52.971462
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:09:55.457547
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:01.031889
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert not hasattr(dict_unpacking_transformer_0, '_tree_changed')
    module_x_var_0 = module_0.Module()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)
    assert hasattr(dict_unpacking_transformer_0, '_tree_changed')


# Generated at 2022-06-25 22:10:02.590220
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    unit_test_0(test_case_0)


# Generated at 2022-06-25 22:10:13.006781
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test strings
    test_str_0 = "dict_1 = {1: 1, 2: 2, None: {3: 3}, 4: 4, None: {5: 5}, 6: 6}"
    test_str_1 = "dict_2 = {1: 1, 2: 2, **{3: 3}, 4: 4, **{5: 5}, 6: 6}"
    test_str_2 = "dict_3 = {1: 1, 2: 2, **{3: 3}}"
    test_str_3 = "dict_4 = {1: 1, **{2: 2, 3: 3}, 4: 4, **{5: 5}, 6: 6}"

# Generated at 2022-06-25 22:10:16.205638
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:20.962345
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:10:25.127179
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:10:33.819980
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:10:39.602668
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    #
    # Call target method
    #
    arg_0 = None
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Module(arg_0)


# Generated at 2022-06-25 22:10:42.704035
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, DictUnpackingTransformer)


# Generated at 2022-06-25 22:10:49.203296
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[], values=[])
    dict_unpacking_transformer_0.visit_Dict(dict_0)
    dict_unpacking_transformer_0.visit_Module(dict_0)
    dict_unpacking_transformer_0.visit_Module(dict_0)
    dict_0_var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:10:56.781414
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_var_0 = module_0.Module()
    module_x_var_0 = module_0.Module()
    module_x_var_0.body = [merge_dicts.get_body()]
    module_0_var_1 = dict_unpacking_transformer_0.visit_Module(module_0_var_0)
    assert module_0_var_1 == module_x_var_0


# Generated at 2022-06-25 22:11:02.039915
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = dict_unpacking_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:11:06.072350
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_0 = None
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)


# Generated at 2022-06-25 22:11:08.782648
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:11:13.965190
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_var_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:11:16.580985
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:11:29.069575
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:11:36.336518
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    var_2 = (5,6)
    var_3 = (4,5)
    var_4 = [var_2, var_3]
    var_5 = (5,6)
    assert (var_4 != var_5)

# Generated at 2022-06-25 22:11:40.237469
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    #Checking : constructor of class DictUnpackingTransformer
    assert dict_unpacking_transformer_0._ast == a_s_t_0


# Generated at 2022-06-25 22:11:42.102998
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:11:51.559092
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    assert dict_unpacking_transformer_0._tree_changed == True
    assert str(var_1) == "def f():\n    _py_backwards_merge_dicts([{1: 2, 3: 4}], {})\n"

if __name__ == '__main__':
    test_DictUnpackingTransformer_visit_Module()

# Generated at 2022-06-25 22:11:56.763489
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)

# Generated at 2022-06-25 22:11:58.309345
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    with pytest.raises(TypeError):
        var_0 = DictUnpackingTransformer()


# Generated at 2022-06-25 22:12:06.406101
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    assert var_1.body[0].body[0].value.func.id == '_py_backwards_merge_dicts'
    assert var_1.body[0].body[0].value.args[0].elts[0].keys[0].n == 1

# Generated at 2022-06-25 22:12:10.461402
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    var_2 = dict_unpacking_transformer_1._tree_changed
    var_3 = dict_unpacking_transformer_1._ast


# Generated at 2022-06-25 22:12:19.430343
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = '{1: 1, **dict_a}'
    var_0 = module_2.parse(str_0)
    expr_0 = var_0.body[0].value
    assert isinstance(expr_0, module_2.Dict)
    call_0 = dict_unpacking_transformer_0.visit_Dict(expr_0)
    assert isinstance(call_0, module_2.Call)
    assert call_0.func.id == '_py_backwards_merge_dicts'
    args_0 = call_0.args
    assert len(args_0) == 1
    list

# Generated at 2022-06-25 22:12:34.450768
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    var_0 = dict_unpacking_transformer_0.a_s_t
    assert var_0 == a_s_t_0


# Generated at 2022-06-25 22:12:36.843046
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # 1) Assert that get_body() is a non-empty string
    # 2) Assert that the function merge_dicts is defined in the beginning of
    #    the transformed result
    pass

# Generated at 2022-06-25 22:12:41.704798
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:12:42.984166
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert False, "Tests for visit_Dict not implemented."
    pass

# Generated at 2022-06-25 22:12:46.194522
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    del a_s_t_0
    del dict_unpacking_transformer_0

import sys

# Generated at 2022-06-25 22:12:52.227979
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:12:56.968461
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:12:58.143184
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # TODO: improve or remove this test
    pass


# Generated at 2022-06-25 22:13:06.869636
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    var_0 = module_2.parse('{}')
    var_1 = ast.literal_eval(var_0)
    assert type(var_1) == ast.Dict
    var_2 = ast.literal_eval(var_1)
    assert type(var_2) == dict
    var_3 = type(var_2) == dict
    assert var_3
    assert isinstance(var_1, ast.Dict)
    var_4 = isinstance(var_1, ast.Dict)
    assert var_4
    var_5 = isinstance(var_1, ast.Dict, dict)
    assert var_5
    var_6 = type(var_1) == dict
    assert not var_6
    var_7 = type(var_2) == ast.Dict

# Generated at 2022-06-25 22:13:12.294603
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:13:47.941876
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {1: 1, **dict_a}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    assert var_1 == module_2.parse(
        'def f():\n    _py_backwards_merge_dicts([{1: 1}], dict_a)')
    str_1 = 'def f():\n    {1: 1, **dict_a, 2: 2}'
    var_2 = module_2.parse(str_1)
    var_3

# Generated at 2022-06-25 22:13:52.955401
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    assert isinstance(var_1, module_2.Module)

# Generated at 2022-06-25 22:13:55.523158
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:14:03.753777
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {1: 2, **a}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    var_2 = module_2.dump(var_1)

# Generated at 2022-06-25 22:14:09.318466
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_2.Dict()
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)
    var_1 = module_2.List()
    assert isinstance(var_0, module_2.List)
    assert (var_0 == var_1)


# Generated at 2022-06-25 22:14:17.823375
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-25 22:14:22.495458
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'import os\n'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:14:31.627043
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    def assert_node_exists(node: ast.AST, type: type) -> None:
        for child in ast.walk(node):
            if isinstance(child, type):
                return

        assert False, f'Expected node of type {type} is not found'

    def assert_no_change(src: str) -> None:
        node = module_2.parse(src)
        result = DictUnpackingTransformer().visit(node)

        assert str(result) == src

    def assert_merged_dict(src: str) -> None:
        node = module_2.parse(src)
        result = DictUnpackingTransformer().visit(node)

        assert_node_exists(result, ast.Dict)
        assert_node_exists(result, ast.Call)

# Generated at 2022-06-25 22:14:40.902035
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    try:
        assert var_1.body[0].value.func.id == '_py_backwards_merge_dicts'
    except AssertionError as e:
        raise AssertionError(str(var_1) + "\n" + str(e)) from e


# Generated at 2022-06-25 22:14:46.468894
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert dict_unpacking_transformer_0.__class__.__name__ == 'DictUnpackingTransformer'
    assert not (dict_unpacking_transformer_0.tree.__class__.__name__ == 'AST')
    assert dict_unpacking_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:15:57.064582
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    py_tree_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(py_tree_0)
    module_2 = module_2.parse('def f():\n    {**{}, 1: 2, 3: 4}')
    dict_unpacking_transformer_0.visit(module_2)

# Generated at 2022-06-25 22:16:02.180023
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_2.Dict(keys=[module_2.Num(n=1), module_2.Name(id='b')], values=[module_2.Num(n=1), None], lineno=1, col_offset=18)
    var_0 = dict_unpacking_transformer_0.visit_Dict(dict_0)



# Generated at 2022-06-25 22:16:10.288702
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = '{**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(module_0.AST())
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    assert type(var_1) == module_2.Call

# Generated at 2022-06-25 22:16:18.144411
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = '{1: 2, **{3: 4}}'
    var_0 = module_2.parse(str_0)
    var_1 = module_2.Call()
    var_1.func = module_2.Name(id='_py_backwards_merge_dicts', ctx=module_2.Load())

# Generated at 2022-06-25 22:16:19.217082
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert True, "Test case for DictUnpackingTransformer failed."


# Generated at 2022-06-25 22:16:27.201874
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    var_2 = var_1.body[0].body[0]
    var_3 = var_2.value
    var_4 = var_3.func
    var_5 = var_4.id
    assert var_5 == '_py_backwards_merge_dicts'
    var_6 = var_3.args
    assert var_6[0].el

# Generated at 2022-06-25 22:16:32.025849
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    dict_unpacking_transformer_0.visit_Module(var_1)


# Generated at 2022-06-25 22:16:39.573123
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    module_2_1 = dict_unpacking_transformer_0.visit(var_0)
    str_0 = module_2.dump(module_2_1)

# Generated at 2022-06-25 22:16:42.709329
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = DictUnpackingTransformer(AST())
    str_0 = 'def f():\n    {**{}, 1: 2, 3: 4}'
    var_0 = module_2.parse(str_0)
    var_1 = module_0.visit(var_0)
    # No assertion

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:16:43.586223
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass
