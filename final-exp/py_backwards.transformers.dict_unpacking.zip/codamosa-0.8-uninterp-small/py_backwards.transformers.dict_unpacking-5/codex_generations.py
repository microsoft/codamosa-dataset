

# Generated at 2022-06-25 22:07:38.351855
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-25 22:07:47.181601
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_list_0 = module_0.List()
    a_list_0.elts = [None]
    a_list_1 = module_0.List()
    a_list_1.elts = [None]
    a_dict_0 = module_0.Dict()
    a_dict_0.keys = a_list_0
    a_dict_0.values = a_list_1
    a_call_0 = module_0.Call()
    a_call_0.func = module_0.Name()
    a_call_0.func.id = '_py_backwards_merge_dicts'


# Generated at 2022-06-25 22:07:50.723536
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Dict(None)



# Generated at 2022-06-25 22:07:54.240237
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_unpacking_transformer_0.visit_Dict()


# Generated at 2022-06-25 22:07:59.413786
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    node_2 = module_0.parse("{1:1}").body[0].value
    node_1 = dict_unpacking_transformer_0.visit(node_2)
    assert (node_1 == node_2)


# Generated at 2022-06-25 22:08:06.265193
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """ Unit test for method visit_Dict of class DictUnpackingTransformer """
    
    # Set-up mock
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_unpacking_transformer_0.visit_Dict = Mock(return_value='dummy_return')
    
    # Call target method
    result = dict_unpacking_transformer_0.visit_Dict('dummy_dict')
    
    # Verify results
    dict_unpacking_transformer_0.visit_Dict.assert_called_with('dummy_dict')
    assert result == 'dummy_return'

# Generated at 2022-06-25 22:08:15.898895
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test for method visit_Dict of class DictUnpackingTransformer"""
    # default args for DictUnpackingTransformer
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    # default args for Call
    name_0 = module_0.Name()
    list_0 = module_0.List()
    call_2 = module_0.Call(name_0, list_0)
    # default args for List
    list_1 = module_0.List()
    # default args for Module
    module_11 = module_0.Module()
    assert type(dict_unpacking_transformer_1.visit_Dict(call_2)) is module_0.Call

# Generated at 2022-06-25 22:08:22.066325
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    a_s_t_0 = module_0.AST()
    assert dict_unpacking_transformer_0.visit_Dict(a_s_t_0.parse('{1: 2}').body[0]) == a_s_t_0.parse('{1: 2}')


# Generated at 2022-06-25 22:08:28.423146
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Setup
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    dict_0 = module_0.Dict(keys=[None], values=[module_0.Dict(keys=[], values=[])])
    # Exercise
    result = dict_unpacking_transformer_0.visit_Dict(dict_0)

# Generated at 2022-06-25 22:08:35.725529
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    # Inputs
    a_s_t_0_dict_0 = module_0.Dict(
        keys=[],
        values=[]
    )
    # Outputs
    expected_0 = module_0.Dict(
        keys=[],
        values=[]
    )
    # Run test
    actual_0 = dict_unpacking_transformer_0.visit_Dict(a_s_t_0_dict_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 22:08:44.797695
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer = DictUnpackingTransformer(a_s_t_0)
    module_0.Module()
    dict_unpacking_transformer.visit(module_0.Module())

module_0.Module()

# Generated at 2022-06-25 22:08:53.430423
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.parse('def foo():\n  return {1: 1, **dict_a}')
    DictUnpackingTransformer(module_0).visit(module_0)

# Generated at 2022-06-25 22:09:00.279013
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    dict_unpacking_transformer_0.generic_visit(module_1) # type: ignore
    dict_unpacking_transformer_0.visit(module_1) # type: ignore
    dict_unpacking_transformer_0.visit_Module(module_1) # type: ignore


# Generated at 2022-06-25 22:09:06.976356
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    int_0 = 111
    int_1 = 111
    dict_unpacking_transformer_0.set_create_unique_var_names(int_0, int_1)
    str_0 = 'fmt'
    module_0.Str(str_0)
    ast_0 = module_0.parse(str_0)


# Generated at 2022-06-25 22:09:17.934664
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast

    # Create an AST node
    module_1 = ast.Module()

    # Create an AST node #2
    dictionary_1 = ast.Dict()

    # Attach nodes
    module_1.body = [dictionary_1]

    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    result = dict_unpacking_transformer_0.visit_Dict(dictionary_1)

    assert isinstance(result, ast.Dict)
    assert result.keys == []
    assert result.values == []


# Generated at 2022-06-25 22:09:22.656734
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    ast_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(ast_0)
    dict_0 = module_0.Dict([], [])
    dict_unpacking_transformer_0.visit_Dict(dict_0)
    return dict_unpacking_transformer_0


# Generated at 2022-06-25 22:09:25.624262
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_2 = module_0.Dict(keys=[], values=[])
    dict_unpacking_transformer_0.visit_Dict(a_s_t_2)


# Generated at 2022-06-25 22:09:35.519886
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_0_body_0_0 = module_0.Module()
    a_s_t_0_body_0_0.body = [module_0.Expr(module_0.Dict(keys=[], values=[]))]
    a_s_t_0_body_0_0.body.append(module_0.Expr(module_0.Dict(keys=[None, module_0.Num(n=1), module_0.Num(n=2)], values=[module_0.Num(n=1), module_0.Num(n=1), module_0.Num(n=2)])))
   

# Generated at 2022-06-25 22:09:40.946738
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module([])
    try:
        module_2 = dict_unpacking_transformer_0.visit_Module(module_1)
    except:
        module_2 = None
    assert module_2 is not None
    assert False


# Generated at 2022-06-25 22:09:50.581081
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    node_0 = module_0.Dict(
        keys=[
            module_0.Num(
                n=1),
            module_0.Name(
                id='a'),],
        values=[
            module_0.Num(
                n=1),
            module_0.Name(
                id='b'),]
    )

# Generated at 2022-06-25 22:10:00.896819
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module_0 = ast.parse(r'''
    {
        **dict_a,
        1: 1
    }
    ''')
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_unpacking_transformer_0.visit(module_0)
    res_0 = str(module_0)
    assert res_0 == r'''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    module_0 = ast.parse(r'''
    {
        1: 1,
        **dict_a
    }
    ''')
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_unpacking_transformer_0.visit(module_0)
   

# Generated at 2022-06-25 22:10:11.833660
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

# Generated at 2022-06-25 22:10:13.827013
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = test_case_0()
    assert a_s_t_0.print_tree()[0] == ""

# Generated at 2022-06-25 22:10:19.011594
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    ast_0 = module_0.Dict()
    ast_1 = dict_unpacking_transformer_0.visit_Dict(ast_0)
    assert ast_1 == module_0.Name()


# Generated at 2022-06-25 22:10:19.860194
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

# Generated at 2022-06-25 22:10:25.064727
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    node_0 = module_0.Dict(keys=[_], values=[])

    def sideEffect():
        raise Exception()

    node_0.keys = None

    try:
        dict_unpacking_transformer_0.visit_Dict(node_0)
        assert False
    except UnboundLocalError:
        assert True


# Generated at 2022-06-25 22:10:29.709509
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_2 = module_0.AST()
    dict_unpacking_transformer_2 = DictUnpackingTransformer(a_s_t_2)
    ast_3 = module_0.Module()
    ast_3 = dict_unpacking_transformer_2.visit_Module(ast_3)
    assert isinstance(ast_3, module_0.Module)


# Generated at 2022-06-25 22:10:41.051754
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.Module([module_0.Expr(module_0.Dict(keys=[module_0.Str(s='a')], values=[module_0.Num(n=1)], lineno=1, col_offset=1))], lineno=1, col_offset=1)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    # First assert: test that method visit_Module of class DictUnpackingTransformer works as expected
    dict_unpacking_transformer_1.visit_Module(a_s_t_1)
    assert dict_unpacking_transformer_1.tree.body[0].value.func.id == '_py_backwards_merge_dicts'
    # Second assert: test that

# Generated at 2022-06-25 22:10:42.173939
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    global a_s_t_0
    test_case_0()


# Generated at 2022-06-25 22:10:49.494121
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)

    dict_unpacking_transformer_0._tree_changed = True
    xs_s_t_0 = (1, 2)
    dict_unpacking_transformer_0._merge_dicts(xs_s_t_0)

    dict_unpacking_transformer_0._tree_changed = True
    pairs_s_t_0 = (1, 2)
    dict_unpacking_transformer_0._split_by_None(pairs_s_t_0)

    dict_unpacking_transformer_0._tree_changed = True
    splitted_s_t_0 = (1, 2)
    dict_unpacking

# Generated at 2022-06-25 22:10:56.741947
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert (dict_unpacking_transformer_0 is not None)
    a_s_t_1 = compile('dict_unpacking_transformer_0.visit_Dict', '', 'exec')
    exec(a_s_t_1)


# Generated at 2022-06-25 22:11:01.999293
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Node of type AST
    a_s_t_0 = module_0.AST()
    # Ensure that AST is tree-like data structure
    assert(a_s_t_0.node_is_tree)
    # Instance of class DictUnpackingTransformer with argument a_s_t_0
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)


# Generated at 2022-06-25 22:11:05.709621
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    assert isinstance(dict_unpacking_transformer_0, module_0.NodeTransformer)


# Generated at 2022-06-25 22:11:16.796518
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    a_s_t_1.Module(body=[dict_unpacking_transformer_1.merge_dicts_node.body[0]])
    dict_unpacking_transformer_1.generic_visit(a_s_t_1.Module(body=[a_s_t_1.Assign(targets=[a_s_t_1.Name(id='a', ctx=a_s_t_1.Store())], value=a_s_t_1.Num(n=4))]))

# Generated at 2022-06-25 22:11:18.374189
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:11:22.413152
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module(body=[a_s_t_0.Expr(value=a_s_t_0.Num(n=1))])
    module_2 = dict_unpacking_transformer_0.visit_Module(module_1)
    assert isinstance(module_2, module_0.Module)


# Generated at 2022-06-25 22:11:28.022186
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    dict_unpacking_transformer_1 = DictUnpackingTransformer(a_s_t_1)
    assert not dict_unpacking_transformer_0
    assert not dict_unpacking_transformer_1


# Generated at 2022-06-25 22:11:31.675720
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_1 = module_0.Module()
    assert dict_unpacking_transformer_0.visit_Module(module_1) == module_1
    print('passed test for method visit_Module of class DictUnpackingTransformer')


# Generated at 2022-06-25 22:11:35.671838
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a = DictUnpackingTransformer()
    return


# Generated at 2022-06-25 22:11:41.572020
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    dict_unpacking_transformer_0 = DictUnpackingTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    module_0_0.body = [module_0.Expr(value=module_0.Str(s='0'))]
    module_0_1 = dict_unpacking_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:11:46.692948
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('import sys')
    original = ast.dump(module)
    result = DictUnpackingTransformer().visit(module)
    expected = original
    assert ast.dump(result) == expected


# Generated at 2022-06-25 22:11:52.330914
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    import astunparse
    source_code_1 = "a = 1; a++; a"
    root_1 = ast.parse(source_code_1)
    dict_unpacking_transformer_1.visit(root_1)
    assert astunparse.unparse(dict_unpacking_transformer_1.visit(root_1)) \
           == source_code_1


# Generated at 2022-06-25 22:12:00.623124
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    dict_1 = dict(keys=[None], values=['some_expr_1'])
    dict_2 = dict(keys=['some_expr_2'], values=['some_expr_3'])
    dict_3 = dict(keys=None, values=['some_expr_4'])
    dict_4 = dict(keys=['some_expr_5'], values=None)
    dict_5 = dict(keys=[None], values=None)
    dict_6 = dict(keys=[None], values=None)
    dict_7 = dict(keys=[None], values=None)
    dict_8 = dict(keys=[None], values=None)
    dict_9 = dict(keys=[None], values=None)
    dict_10 = dict

# Generated at 2022-06-25 22:12:05.355234
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_module = ast.parse('a = {1:1, 2:2}')
    dict_unpacking_transformer = DictUnpackingTransformer()
    res = dict_unpacking_transformer.visit(test_module)
    code = compile(res, '', 'exec')
    res = {}
    exec(code, res)
    assert res['a'] == {1:1, 2:2}


# Generated at 2022-06-25 22:12:14.203331
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    ast_0 = ast.parse('a: 1')
    ast_0 = dict_unpacking_transformer_0.visit_Module(ast_0)


# Generated at 2022-06-25 22:12:19.049019
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    s = """
            {1: 1, **dict_a}
        """
    expected_result = ast.parse("""
            _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)
    tree = ast.parse(s)
    DictUnpackingTransformer(tree).visit(tree)
    assert ast.dump(tree) == ast.dump(expected_result)

# Generated at 2022-06-25 22:12:28.589615
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_module_0 = ast.Module([ast.Expr(value=ast.Dict(keys=[ast.Name(id='dict_a',
                                                                          ctx=ast.Load()),
                                                                ast.Name(id='dict_b',
                                                                          ctx=ast.Load()),
                                                                None,
                                                                ast.Num(n=1)],
                                                    values=[ast.Str(s='example'),
                                                            ast.Str(s='example'),
                                                            ast.Str(s='example'),
                                                            ast.Num(n=1)]))])

# Generated at 2022-06-25 22:12:37.358241
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()

# Generated at 2022-06-25 22:12:38.091232
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer = DictUnpackingTransformer()

# Generated at 2022-06-25 22:12:41.855088
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    assert dict_unpacking_transformer_0.visit_Module
    assert dict_unpacking_transformer_0.visit_Module.__doc__


# Generated at 2022-06-25 22:12:48.329229
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """
    Performs unit test for method visit_Dict of class DictUnpackingTransformer
    """
    pass  # TODO: implement this test



# Generated at 2022-06-25 22:12:56.823242
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.type_inference_programs import type_inference_programs
    from .context import Context
    import sys
    import io
    import typed_astunparse
    program = type_inference_programs[1]
    fake_stdout = io.StringIO()
    fake_stderr = io.StringIO()
    with Context(stdout=fake_stdout, stderr=fake_stderr, **program.test_args):
        exec(program.test_code, globals())  # nosec
    module_obj = sys.modules[__name__]
    method_obj = getattr(module_obj, "test_case_0")
    source = typed_astunparse.unparse(method_obj.__code__)
    print(source)

# Generated at 2022-06-25 22:13:01.384249
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '{1: 1, 2: 2, 3: 3}'
    expect = '''{1: 1, 2: 2, 3: 3}'''
    actual = snippet(source).compile_ast()
    actual = DictUnpackingTransformer().visit(actual)
    actual = ast.dump(actual, Dumper=ast.Dumper)
    assert actual == expect


# Generated at 2022-06-25 22:13:03.090396
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()


# Generated at 2022-06-25 22:13:11.600917
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0.visit_Dict(
        ast.Dict(
            keys=[
                ast.Num(n=1),
                None,
                ast.Num(n=2)],
            values=[
                ast.Num(n=1),
                ast.Dict(
                    keys=[
                        ast.Num(n=3)],
                    values=[
                        ast.Num(n=4)]),
                ast.Num(n=2)]))
    assert dict_unpacking_transformer_0._tree_changed == True
    dict_unpacking_transformer_0._tree_changed = False
    dict_unpacking_transformer_0.vis

# Generated at 2022-06-25 22:13:14.934706
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import Module, Dict, Name, Num, Str, arguments, arg, Call
    p = DictUnpackingTransformer()
    c = codegen.to_source(p)
    assert c == 'def empty_call():\n    pass\n'


# Generated at 2022-06-25 22:13:16.502687
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()


# Generated at 2022-06-25 22:13:19.261620
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    assert dict_unpacking_transformer_1 is not None


# Generated at 2022-06-25 22:13:26.468502
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = 'def foo():\n    return {}'
    root = ast.parse(source)
    
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_unpacking_transformer_0.visit(root)
    expected = 'def foo():\n    def _py_backwards_merge_dicts(dicts):\n        result = {}\n        for dict_ in dicts:\n            result.update(dict_)\n        return result\n    return {}'
    assert dump_code(root) == expected
    

# Generated at 2022-06-25 22:13:28.262324
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()

# Generated at 2022-06-25 22:13:36.407586
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer = DictUnpackingTransformer()
    assert isinstance(dict_unpacking_transformer, DictUnpackingTransformer)
    assert isinstance(dict_unpacking_transformer, BaseNodeTransformer)

# Unit tests for method _split_by_None in class DictUnpackingTransformer

# Generated at 2022-06-25 22:13:42.572633
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    statement = ast.parse('''
{1: 1, 2: 2, **{3: 3, 4: 4}, **dict_var, 5: 5}
''', mode='eval')
    expected_output = ast.parse('''
_py_backwards_merge_dicts([{1: 1, 2: 2, 5: 5}], {3: 3, 4: 4}, dict_var)
''', mode='eval')
    assert DictUnpackingTransformer().visit(statement) == expected_output


# Generated at 2022-06-25 22:13:45.953949
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()  # type: DictUnpackingTransformer
    with pytest.raises(TypeError, match="'Module' object is not subscriptable"):
        dict_unpacking_transformer_1.visit_Module(Module())


# Generated at 2022-06-25 22:13:53.682036
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test for method visit_Dict of class DictUnpackingTransformer"""
    ast_text = """{1: '1', 2: '2', **{'3': '3'}, **{'4': '4'}}"""
    import ast as py_ast
    ast_tree = py_ast.parse(ast_text)
    expected_tree = py_ast.parse(
        """_py_backwards_merge_dicts([{1: '1', 2: '2'}, {'3': '3'}, {'4': '4'}])""")
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(ast_tree)
    new_text = py_ast.dump(new_tree)
    expected_text = py_ast.dump(expected_tree)
    assert new

# Generated at 2022-06-25 22:13:54.702265
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)

# Generated at 2022-06-25 22:13:56.093943
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()

# Generated at 2022-06-25 22:14:03.276908
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    node_0 = ast.parse('\n1')
    node_0 = dict_unpacking_transformer_0.visit(node_0)
    assert isinstance(node_0, ast.Module)
    assert node_0.body[0] == ast.parse("\ndef _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result")
    assert node_0.body[1] == ast.Expr(value=ast.Num(n=1))



# Generated at 2022-06-25 22:14:07.983169
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_1 = DictUnpackingTransformer()
    test_node_1 = ast.parse('')
    expected_1 = merge_dicts.get_body()
    actual_1 = dict_unpacking_transformer_1.visit(test_node_1)
    assert actual_1 is not None
    assert actual_1.body == expected_1


# Generated at 2022-06-25 22:14:10.371272
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    node = ast.Dict(keys=[None, None], values=[None, None])
    dict_unpacking_transformer_0.visit_Dict(node)

# Generated at 2022-06-25 22:14:11.393481
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()
    assert dut



# Generated at 2022-06-25 22:14:23.911397
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    dict_0_2 = dict_unpacking_transformer_0.visit_Dict(ast.Dict(keys=[None, ast.Str(s='a')], values=[ast.Str(s='b'), ast.Num(n=1)]))

# Generated at 2022-06-25 22:14:25.832308
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3

# Generated at 2022-06-25 22:14:28.485550
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    module_1 = ast.Module([])
    module_1 = dict_unpacking_transformer_0.visit(module_1)

# Generated at 2022-06-25 22:14:33.915724
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    ast_0 = ast.parse('''
        {1: 1, **dict_a}
      ''')
    result_0 = dict_unpacking_transformer_0.visit(ast_0)
    expected_0 = ast.parse('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
       ''')
    assert ast.dump(result_0) == ast.dump(expected_0)

# Generated at 2022-06-25 22:14:35.910981
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    with pytest.raises(TypeError):
        DictUnpackingTransformer()



# Generated at 2022-06-25 22:14:37.540576
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()



# Generated at 2022-06-25 22:14:47.040683
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    code_0 = ast.parse("{1: 1, **{}}")
    ast.dump(dict_unpacking_transformer_0.visit(code_0))
    code_1 = ast.parse("{1: 1, **{2:2}, **{3:3}}")
    ast.dump(dict_unpacking_transformer_0.visit(code_1))
    code_2 = ast.parse("{**{2:2}, **{3:3}, **{4:4}}")
    ast.dump(dict_unpacking_transformer_0.visit(code_2))
    code_3 = ast.parse("{1: 1, **{2:2}, 3:3, **{4:4}}")
    ast

# Generated at 2022-06-25 22:14:55.272481
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-25 22:14:59.926866
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer_visit_Dict_0 = DictUnpackingTransformer()

    # Test 1:
    test_1_source = ast.parse("""{1:1}""")
    test_1_target = ast.parse("""{1:1}""")
    assert dict_unpacking_transformer_visit_Dict_0.visit(test_1_source) == test_1_target

    # Test 2:
    test_2_source = ast.parse("""{}""")
    test_2_target = ast.parse("""{}""")
    assert dict_unpacking_transformer_visit_Dict_0.visit(test_2_source) == test_2_target

    # Test 3:

# Generated at 2022-06-25 22:15:06.494093
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast

    text_0 = """
{1: 1}
"""
    module_0 = ast.parse(text_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer()
    module_1 = dict_unpacking_transformer_0.visit(module_0)
    # should rewrites: {1: 1} to _py_backwards_merge_dicts([{1: 1}])
    assert_compiled_output(module_0, module_1)
    

# Generated at 2022-06-25 22:15:22.416682
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:15:25.897160
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:15:26.585019
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert True


# Generated at 2022-06-25 22:15:36.958325
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    str_1 = 'def _py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\ndef foo():\n  return _py_backwards_merge_dicts([{1: 1}], dict_a])'
    var_1 = module_0.parse(str_1)
    assert dict_unpacking_transformer_0.visit_Module(var_0) == var_1


# Generated at 2022-06-25 22:15:38.904735
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def foo():
        return {1: 1, **dict_a}  # noqa: F821
    

# Generated at 2022-06-25 22:15:41.855780
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit_Module(var_0)


# Generated at 2022-06-25 22:15:48.178695
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:15:54.522217
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)

    # Asserts that method is_tree_changed returns the value True.
    assert dict_unpacking_transformer_0.is_tree_changed(), 'Method is_tree_changed returned value ' + str(dict_unpacking_transformer_0.is_tree_changed()) + ', expected value is True.'


# Generated at 2022-06-25 22:16:00.520126
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    str_1 = 'def foo():\n  return _py_backwards_merge_dicts([{1: 1}], dict_a)'
    var_2 = module_0.parse(str_1)
    assert(var_1 == var_2)

import sys


# Generated at 2022-06-25 22:16:04.287293
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:16:16.992468
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    str_2 = 'def foo():\n  return {1: 1, **dict_a}'
    var_3 = module_0.parse(str_2)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(var_3)


# Generated at 2022-06-25 22:16:18.566833
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    var_1 = DictUnpackingTransformer(module_0.parse('a'))
    test_case_0()

# Generated at 2022-06-25 22:16:23.707837
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    assert str(var_1) == 'def foo():\n  _py_backwards_merge_dicts([{1: 1}], dict_a)'

# Generated at 2022-06-25 22:16:25.030913
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # TODO: write unit tests for constructor of class DictUnpackingTransformer
    pass


# Generated at 2022-06-25 22:16:26.990647
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    var_0: module_0.AST = None
    var_2 = DictUnpackingTransformer.__init__(var_0)


# Generated at 2022-06-25 22:16:27.757240
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:16:31.037150
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_1 = 'def foo():\n  return {1: 1, **dict_a}'
    var_2 = module_0.parse(str_1)
    dict_unpacking_transformer_1 = DictUnpackingTransformer(var_2)
    var_3 = dict_unpacking_transformer_1.visit(var_2)


# Generated at 2022-06-25 22:16:34.037815
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    module_0 = ast.Module([])
    var_1 = DictUnpackingTransformer(module_0)
    assert isinstance(var_1, DictUnpackingTransformer)


# Generated at 2022-06-25 22:16:38.832198
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def foo():
      return {1: 1, **dict_a}
    var_0 = module_0.parse('def foo():\n  return {1: 1, **dict_a}')
    var_1 = DictUnpackingTransformer(var_0).visit(var_0)
    var_2 = module_0.parse('def foo():\n    _py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert var_1 == var_2


# Generated at 2022-06-25 22:16:44.930419
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit_Module(var_0)
    var_2 = (((type(var_1) == module_0.Module) and (hasattr(var_1, 'body') and (type(var_1.body) == list))) and (len(var_1.body) == 3))

# Generated at 2022-06-25 22:17:12.146402
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:17:17.991803
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)

# Generated at 2022-06-25 22:17:18.601598
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_case_0()

# Generated at 2022-06-25 22:17:19.463581
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-25 22:17:26.816592
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    str_0 = 'def foo():\n  return {1: 1, **dict_a}'
    var_0 = module_0.parse(str_0)
    dict_unpacking_transformer_0 = DictUnpackingTransformer(var_0)
    var_1 = dict_unpacking_transformer_0.visit(var_0)
    var_2 = isinstance(var_1, module_0.Module)
    assert var_2
    var_3 = str(var_1)