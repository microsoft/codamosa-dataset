

# Generated at 2022-06-12 03:29:06.558841
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dict_unpacking_transformer = DictUnpackingTransformer()
    node = ast.Dict(keys=[None, ast.Constant(value=1), None],
                    values=[ast.Load(), ast.Load(), ast.Load()])
    result = dict_unpacking_transformer.visit(node)
    expected = ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'),
                        args=[ast.List(elts=[
                            ast.Call(func=ast.Name(id='dict'),
                                     args=[ast.Load()],
                                     keywords=[]),
                            ast.Call(func=ast.Name(id='dict'),
                                     args=[ast.Load()],
                                     keywords=[]),
                            ast.Load()])],
                        keywords=[])
    assert result

# Generated at 2022-06-12 03:29:13.870376
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse
    from ..utils.test_utils import assert_equal_trees

    src = '''
    {
        None: None,
        1: 2,
        **{3: 4}
    }
    '''
    ref = '''
    _py_backwards_merge_dicts([{1: 2}], {3: 4})
    '''
    tree = ast.parse(src) # type: ignore
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_equal_trees(ref, unparse(tree).strip())

# Generated at 2022-06-12 03:29:22.452301
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import config
    from textwrap import dedent
    from ..utils.source import Source
    from ..visitors.codemod import CodemodContext

    ctx = CodemodContext(config.Config(), 'test')
    source = dedent('''\
        {0: 1, **dict_a}
    ''')

    expected = dedent('''\
        _py_backwards_merge_dicts([{0: 1}], dict_a)
    ''')

    transformer = DictUnpackingTransformer()

    node = ast.parse(source)  # type: ignore
    transformer.visit(node)

    assert ast.dump(node) == ast.dump(ast.parse(expected))  # type: ignore
    assert transformer.tree_changed



# Generated at 2022-06-12 03:29:32.689617
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent

    module = dedent("""\
        def f():
            *args, = x
            {1: 2, 3: 4, **x, **y, **z}
            {1: 2, **a}
            {**a, **x}
            {**x}
            {1: 2, 3: 4, **x}
            {a: b, **x}
            {**x, a: b}
            {a: b, **x, c: d}
            {**x, **y, **z}
            {**a}
        """)


# Generated at 2022-06-12 03:29:41.857711
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..type_inference.module import Module
    from ..utils.source import source_to_unicode
    from ..utils.tree import dump
    module = Module(source_to_unicode('''
        a = {1: 1, **dict_a, 3: 3}
    '''))
    DictUnpackingTransformer(module).visit(module.node)
    assert dump(module.node) == source_to_unicode('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        a = _py_backwards_merge_dicts([{1: 1, 3: 3}], dict_a)
    ''')

# Generated at 2022-06-12 03:29:49.028591
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import unittest
    import astunparse

    @snippet
    def _py_backwards_merge_dicts():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

    @snippet
    def dict_unpacking():
        def func():
            ret = {1: 1, **{}}
            return ret

    # type: ast.Call
    merge_dicts = merge_dicts.get_body()[0].body[0]

    class TestVisitModule(unittest.TestCase):
        def test_snippet(self):
            input_ = dict_unpacking.get_body()[0].body[1]
            output = DictUnpackingTransformer

# Generated at 2022-06-12 03:29:59.865167
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .typed_ast_utils import get_dummy_lineno

    result = DictUnpackingTransformer().visit(ast.Dict(
        keys=[ast.Num(n=1, lineno=get_dummy_lineno()),
              None,
              ast.Num(n=2, lineno=get_dummy_lineno())],
        values=[ast.Num(n=1, lineno=get_dummy_lineno()),
                ast.Name(id='a',
                         ctx=ast.Load(),
                         lineno=get_dummy_lineno()),
                ast.Num(n=2, lineno=get_dummy_lineno())],
        lineno=get_dummy_lineno()))

# Generated at 2022-06-12 03:30:01.695288
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assertDictUnpackingTransformer(
        '{1: 1}',
        '_py_backwards_merge_dicts([{1: 1}])')



# Generated at 2022-06-12 03:30:08.868670
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.visitor import NodeVisitor

    ast = source_to_ast('''
        {1: 1, 2: 2+a, **kwargs()}
    ''')
    visitor = NodeVisitor(DictUnpackingTransformer())
    visitor.visit(ast)
    assert ast == source_to_ast('''
        _py_backwards_merge_dicts([{1: 1, 2: 2+a}], kwargs())
    ''')

# Generated at 2022-06-12 03:30:19.031559
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for method visit_Dict of class DictUnpackingTransformer."""
    from ..utils.typed_ast import typed_ast_unparse
    code = """
    {1: 1, **dict_a}
    {1: 1, 'a': 2, **dict_a}
    {1: 1, 'a': 2, **dict_a, **dict_b}
    {**dict_a, **dict_b}
    {1: 1, **dict_a, **dict_b}
    {'a': 2, **dict_a, **dict_b}
    """

# Generated at 2022-06-12 03:30:28.781186
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = """\
        {1: 1, **dict_a}
    """
    expected = """\
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert DictUnpackingTransformer.run_test(src, expected) == 1



# Generated at 2022-06-12 03:30:37.156687
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()
    code = '''{
        **a,
        'a': 1,
        **b,
        'b': 1,
        **c,
        'c': 1,
        **d,
        'd': 1,
        **e
    }'''
    before = ast.parse(code)
    after = ast.parse('''
    _py_backwards_merge_dicts([{'a': 1, 'b': 1, 'c': 1, 'd': 1}], a, b, c, d, e)
    ''')
    assert t.visit(before) == after

# Generated at 2022-06-12 03:30:45.063896
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    source = """
    {**kwargs}
    """
    expected = """
    _py_backwards_merge_dicts([], kwargs)
    """
    tree = ast.parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected


# Generated at 2022-06-12 03:30:56.150726
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .transformer_tests import run_test

    code = """
        {1: 1, **dict_a, 2: 2}
    """
    expected_code = """
        _py_backwards_merge_dicts(
            [{1: 1}, 2: 2],
            dict_a,
        )
    """
    result = run_test(code, [DictUnpackingTransformer])
    if len(result.errors):
        print(result.errors[0])
        assert False

    assert result.code == expected_code

    code = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """

# Generated at 2022-06-12 03:31:03.209771
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    target_code = """
        {1: 1, 2: 2, 3: 3}
    """
    expected_code = """
        {1: 1, 2: 2, 3: 3}
    """
    assert DictUnpackingTransformer().visit(ast.parse(target_code)) \
        == ast.parse(expected_code)
    assert not DictUnpackingTransformer().tree_changed()

    target_code = """
        {**{1: 1}, 2: 2, 3: 3}
    """
    expected_code = """
        _py_backwards_merge_dicts([{1: 1}, {2: 2, 3: 3}])
    """
    assert DictUnpackingTransformer().visit(ast.parse(target_code)) \
        == ast.parse(expected_code)

# Generated at 2022-06-12 03:31:10.326661
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import transform
    import _ast
    from .test_BaseNodeTransformer import C

    code = """\
        {1: 1, **dict_a}
    """
    node = ast.parse(code)
    DictUnpackingTransformer(C).visit(node)
    expected = _ast.parse("""\
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)

    assert transform(expected, [DictUnpackingTransformer]) == node

    code = """\
        {**dict_a, **dict_b}
    """
    node = ast.parse(code)
    DictUnpackingTransformer(C).visit(node)

# Generated at 2022-06-12 03:31:20.963682
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test import generate_testcase_from_function
    from ..utils.test import run_test_local_doctest

    args = [
        dict(
            tree=ast.parse(textwrap.dedent('''\
                {1: 2, 3: 4, 5: 6, **{1: 5}, **{**{1: 5}}, **{3: 5}}
                ''')),
            expected={1: 5, 2: 4, 3: 5, **{1: 5}}),
    ]

    generate_testcase_from_function(
        DictUnpackingTransformer.visit_Dict,
        'DictUnpackingTransformer.visit_Dict',
        'DictUnpackingTransformer',
        args)


# Generated at 2022-06-12 03:31:27.209963
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import compile_source
    from .expect import Expectation

    source = """\
        a = {1: 1, **dict_a}
        """
    expected = """\
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """
    module, infos = compile_source(source, DictUnpackingTransformer)
    Expectation.assert_code_equal(expected, module)
    assert not infos.errors


# Generated at 2022-06-12 03:31:37.890691
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..app import compile_isolated

    tree = compile_isolated('{{**dict_a}}', mode='exec')
    assert len(list(tree.body[1].body)) == 2

    tree = compile_isolated('{{k: 1, **dict_a}}', mode='exec')
    assert len(list(tree.body[1].body)) == 2

    tree = compile_isolated('{{k: 1, **dict_a, **dict_b}}', mode='exec')
    assert len(list(tree.body[1].body)) == 2
    assert len(list(tree.body[1].body[1].value.args)) == 3

    tree = compile_isolated('{{k: 1, **dict_a, **{**dict_b}}}', mode='exec')

# Generated at 2022-06-12 03:31:47.604485
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base_test import BaseNodeTransformerTest
    from .test_utils import make_test, assert_equal_ast
    test = lambda code, expected: \
        assert_equal_ast(DictUnpackingTransformer, code, expected)
    case1_1 = make_test(
            '''{1: 1, 2: 2, 3: 3}''',
            '''{1: 1, 2: 2, 3: 3}''')
    case1_2 = make_test(
            '''{1: 1, 2: 2, 3: 3, **{4: 4, 5: 5}}''',
            '''_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], {4: 4, 5: 5})''')

# Generated at 2022-06-12 03:32:01.586130
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast

    transformer = DictUnpackingTransformer()
    source = '''{1: 1, **dict_a, 2: 2, **dict_b}'''

# Generated at 2022-06-12 03:32:09.083852
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import assert_equal_ast
    from ..testing_utils import assert_bytecode_equal
    
    class Test(DictUnpackingTransformer):
        _tree_changed = False
    
    t = Test()
    
    node = ast.parse("a = {1: 2, 3: 4, **{5:6, 7:8}, **{9:10, 11:12}}")
    t.visit(node)
    
    assert_equal_ast(node, """
        a = _py_backwards_merge_dicts(
            [{1: 2}, {3: 4}],
            {5: 6, 7: 8},
            {9: 10, 11: 12}
        )
    """)
    
    assert t._tree_changed is True
    

# Generated at 2022-06-12 03:32:15.790162
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import transform, compare_trees
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:32:26.520389
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse


# Generated at 2022-06-12 03:32:37.065533
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert_equal(
        compile_str('''
            d = {1: 1, 2: 2, **{3: 3, 4: 4}}
        ''',
        'exec',
        mode='eval'),
        compile_str('''
            d = _py_backwards_merge_dicts([{1: 1, 2: 2}], {3: 3, 4: 4})
        ''',
        'exec',
        mode='eval'))


# Generated at 2022-06-12 03:32:47.081143
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    visitor = DictUnpackingTransformer()
    # def func():
    #     return {1: 2, 3: 4, **dict_a}

# Generated at 2022-06-12 03:32:55.160841
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    node = parse("{1: 1, **{1: 2}, 3: 3, **{3: 4}}")
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-12 03:33:01.404837
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    src = """
    {**a, 1: 2, **b, 0: 1}
    """

    expect_src = """
    _py_backwards_merge_dicts([dict({0: 1}), a, dict({1: 2})], b)
    """

    tree = ast.parse(src)
    transformer.visit(tree)
    assert ast.dump(tree) == expect_src.strip()

# Generated at 2022-06-12 03:33:08.913096
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...fix import cst_to_ast
    from ...fix.fix_dict_unpacking import DictUnpackingTransformer
    from ..utils.tree import ast_to_cst
    from ..utils.set import deep_set_equal

    cst = """\
{1: "1", 2: "2", **{"a": "a", **{"b": "b"}}, **{"a": "A", **{"b": "B"}}}
"""

# Generated at 2022-06-12 03:33:10.431793
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..dump import Dumper
    from astunparse import unparse

# Generated at 2022-06-12 03:33:29.857534
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils import helpers
    from .visitors import DictUnpackingTransformer
    import sys
    class PythonVersion:
        major = sys.version_info[0]
        minor = sys.version_info[1]

    def _unpack(code: str) -> str:
        tree = ast.parse(code)
        transformer = DictUnpackingTransformer(PythonVersion())
        transformed_tree = transformer.visit(tree)
        assert transformed_tree != tree
        return helpers.to_source(transformed_tree)
    # empty dict
    assert _unpack('{}') == '{}'
    # one element without unpacking
    assert _unpack('{1: 2}') == '{1: 2}'
    # one element with unpacking
    assert _un

# Generated at 2022-06-12 03:33:40.169388
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as pyast

    def test(src, expected):
        module = pyast.parse(src)
        assert isinstance(module, pyast.Module)
        assert len(module.body) == 1
        stmt = module.body[0]
        assert isinstance(stmt, pyast.Expr)
        assert isinstance(stmt.value, pyast.Dict)
        DictUnpackingTransformer().visit(module)
        dest = pyast.dump(module)
        assert dest == expected

    test('{1: 1, 2: 2}', '''\
Module(body=[Expr(value=Dict(keys=[
    Num(n=1),
    Num(n=2)], values=[
    Num(n=1),
    Num(n=2)]))])''')


# Generated at 2022-06-12 03:33:50.167615
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    t = DictUnpackingTransformer()
    # input:
    # {**dict_a, **dict_b}
    node = ast.Dict(keys=[None, None], values=[
        ast.Name(id='dict_a', ctx=ast.Load()),
        ast.Name(id='dict_b', ctx=ast.Load())])
    # output:
    # _py_backwards_merge_dicts([], dict_a, dict_b)

# Generated at 2022-06-12 03:34:00.478294
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse("""
    {1: 1, **dict_a}
    """)
    node = module.body[0]
    assert isinstance(node, ast.Expr)
    node = node.value
    assert isinstance(node, ast.Dict)
    assert isinstance(node.keys[0], ast.Num)
    assert isinstance(node.keys[1], ast.Name)  # None
    assert isinstance(node.values[0], ast.Num)
    assert isinstance(node.values[1], ast.Name)

    res = DictUnpackingTransformer().visit(module)
    res = compile(res, __file__, 'exec')

    _py_backwards_merge_dicts = None  # type: callable
    expected = {1: 1}


# Generated at 2022-06-12 03:34:10.862771
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict, Name, Num, Load, parse
    from .base import TransformerTestCase

    class Test(TransformerTestCase):
        def create_transformer(self) -> DictUnpackingTransformer:
            return DictUnpackingTransformer()

    test = Test()

    dict_ = Dict(keys=[None, None],
                 values=[{1: 1}, {2: 2}])
    expected = parse('''
        _py_backwards_merge_dicts([dict([(1, 1)])], dict([(2, 2)]))
    ''')
    test.assert_transform(dict_, expected)

    dict_ = Dict(keys=[Num(1), None, None],
                 values=[Num(2), {3: 3}, {4: 4}])
    expected

# Generated at 2022-06-12 03:34:15.968732
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import test_ast_transformer

    source = '''\
{
    1: 1,
    **p,
    2: 2,
    **q
}
'''
    expected = '''\
_py_backwards_merge_dicts([dict({1: 1}), p, dict({2: 2})], q)
'''
    test_ast_transformer(DictUnpackingTransformer, source, expected)

# Generated at 2022-06-12 03:34:26.090989
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():  # noqa
    from ..utils.test_utils import make_module_from_code
    from ..utils.test_utils import assert_tree_equal
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed

    # Example from class docstring
    input = "{1: 1, **dict_a}"
    expected = "_py_backwards_merge_dicts([{1: 1}], dict_a)"

    module = make_module_from_code(input)
    DictUnpackingTransformer.run_module(module)
    assert_tree_changed(module)
    assert_tree_equal(module, expected)

    # Example from class docstring
    input = "{1: 1, **dict_a, 2: 2, **dict_b}"
   

# Generated at 2022-06-12 03:34:35.304166
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 1, 2: 2, 3: 3, **x, **y}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], x, y)')
    transformer = DictUnpackingTransformer()
    assert transformer.visit(node) == expected  # type: ignore

    node = ast.parse('{1: 1, 2: x, 3: y}')
    assert transformer.visit(node) == node  # type: ignore

    node = ast.parse('{**x, **y}')
    expected = ast.parse('_py_backwards_merge_dicts([{}], x, y)')
    assert transformer.visit(node) == expected  # type: ignore

    node = ast

# Generated at 2022-06-12 03:34:38.863591
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class D:
        def a(self):
            return {1: 1, **{"two": "Two", "three": "Three"}}

    DictUnpackingTransformer().transform(D)
    assert D().a() == {1: 1, "two": "Two", "three": "Three"}

# Generated at 2022-06-12 03:34:43.512455
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    expected = """
    def foo(bar):
        return _py_backwards_merge_dicts([{'a': 1}], bar)"""

    code = """
    def foo(bar):
        return {'a': 1, **bar}"""

    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert expected == astor.to_source(tree)



# Generated at 2022-06-12 03:35:14.214238
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tr = DictUnpackingTransformer()
    source = """
        y = {1: 2, **{3: 4, 5: 6}}
    """
    lines, node = compile_and_parse(source, '<test>', 'exec')
    assert len(lines) == 1
    with tr:
        new_node = tr.visit(node)
    assert isinstance(new_node, ast.Module)
    new_lines = compile_node(new_node)


# Generated at 2022-06-12 03:35:23.271943
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source = dedent('''\
        {
            1: 2,
            **a,
            'b': **c,
            1: [
                *d,
                *e,
            ],
            **f,
            **g,
        }''')
    expected = dedent('''\
        _py_backwards_merge_dicts([{
            1: 2,
            'b': **c,
            1: [
                *d,
                *e,
            ],
        }], a, c, f, g)''')
    tree = ast.parse(source)
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert transformer.get_code(new_tree) == expected

# Generated at 2022-06-12 03:35:27.245329
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse

    transformer = DictUnpackingTransformer()
    code = '{1: 1, **dict_a}'
    expected = "_py_backwards_merge_dicts([{1: 1}], dict_a)"
    assert unparse(transformer.visit(ast.parse(code))) == expected

# Generated at 2022-06-12 03:35:37.601922
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typing as tp
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_print

    import astunparse
    import textwrap

    def assert_output(text, output):
        transformer = DictUnpackingTransformer()
        code = textwrap.dedent(text)
        tree = ast.parse(code)
        transformer.visit(tree)
        assert astunparse.unparse(tree) == textwrap.dedent(output)


# Generated at 2022-06-12 03:35:45.177823
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse
    unpacked = """
    {
        **dict_a,
        1: 1,
    }
    """
    packed = """
    _py_backwards_merge_dicts(
        [dict({1: 1})],
        dict_a,
    )
    """
    unpacked = ast.parse(unpacked)
    packed = ast.parse(packed)
    assert unparse(DictUnpackingTransformer().visit(unpacked)) == \
        unparse(packed)

# Generated at 2022-06-12 03:35:51.192856
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    ast_node = ast.parse("{1: 1, None: dict_, **dict_a, 3: 3}")
    expected_result = ast.parse("_py_backwards_merge_dicts([{1: 1, 3: 3}], dict_, dict_a)")
    transformer.visit(ast_node)
    assert ast.dump(ast_node, include_attributes=True) == ast.dump(expected_result, include_attributes=True)

# Generated at 2022-06-12 03:36:01.250694
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import make_dummy_code_with_ast

    source = """
        x = {1: 1, 2: 2, 3: 3, **d}
        y = {1: 1, 2: 2, 3: 3, 4: 4, **d}
    """

    expected = """
        x = _py_backwards_merge_dicts(
            [{1: 1, 2: 2, 3: 3}], d)
        y = _py_backwards_merge_dicts(
            [{1: 1, 2: 2, 3: 3, 4: 4}], d)
    """

    dummy_code = make_dummy_code_with_ast(source)
    transformer = DictUnpackingTransformer()

    transformer.visit(dummy_code)

# Generated at 2022-06-12 03:36:11.323637
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test 0 - dict without unpacking

    args = dict(keys=[ast.Num(n=1), ast.Str(s='str')],
                values=[ast.Num(n=1), ast.Str(s='str')])

    t = DictUnpackingTransformer()
    test_tree = ast.Dict(**args)
    assert t.visit(test_tree) == test_tree

    # Test 1 - dict with unpacking

    args = dict(keys=[ast.Num(n=1), ast.Str(s='str')],
                values=[ast.Num(n=1), ast.Num(n=2)])


# Generated at 2022-06-12 03:36:19.729187
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    input = """
            d = {'a': 4, **d2}"""
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    d = _py_backwards_merge_dicts([{"a": 4}], d2)
            """

    transformer = DictUnpackingTransformer()
    output = transformer.visit(ast.parse(input))

    assert ast.dump(output) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 03:36:26.273113
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast

    class NodeTransformer(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            node.args = [self.visit(a) for a in node.args]
            return node

        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            node.keys = [self.visit(k) for k in node.keys]
            node.values = [self.visit(v) for v in node.values]
            return node

    class CallTransformer(ast.NodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            if node.id != 'dict':
                return node

# Generated at 2022-06-12 03:37:14.419988
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    def check(before, after):
        t = DictUnpackingTransformer()
        t._tree_changed = False
        result = t.visit(ast.parse(before))
        assert not t._tree_changed

        t = DictUnpackingTransformer()
        t._tree_changed = False
        result = t.visit(ast.parse(after))
        assert t._tree_changed

        assert ast.dump(result) == ast.dump(ast.parse(after))

    s = """
{1: 2, **None}
"""

    check(s, """
_py_backwards_merge_dicts([{1: 2}], None)
""")



# Generated at 2022-06-12 03:37:24.288436
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    def check(x, expected):
        transformer = DictUnpackingTransformer()
        result = transformer.visit(x)
        assert result == expected

    check(ast.Dict(keys=[None, None, None],
                   values=[None, None, None]),
           ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'),
                    args=[ast.List(elts=[ast.Call(
                        func=ast.Name(id='dict'), args=[], keywords=[])] * 3)]))

# Generated at 2022-06-12 03:37:27.209913
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    xs = [
    {1: 1, **{2: 2}, **{3: 3}, 4: 4},
    {**{1: 1}, **{2: 2}, **{3: 3}, **{4: 4}},
    {**{1: 1}, **{2: 2}, 3: 3, **{4: 4}}
    ]

    for x in xs:
        assert x == ast.parse(DictUnpackingTransformer().visit(ast.parse(str(x))))

# Generated at 2022-06-12 03:37:32.632560
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest.mock as mock
    from typed_ast.ast3 import Dict
    from typed_ast.ast3 import Subscript, Name
    from typed_ast.ast3 import Index, List
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import Tuple
    from ..utils.testing import make_call
    def check(
            node: Dict,
            *args,
            expected_result: Union[Call, Dict],
            expected_changed: bool = True
    ) -> None:
        transformer = DictUnpackingTransformer()
        with mock.patch.object(transformer, '_tree_changed', new=False):
            result = transformer.visit_Dict(node)
            assert transformer._tree_changed == expected_changed  # type: ignore
            assert result == expected_

# Generated at 2022-06-12 03:37:42.251328
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.fixtures import line_matches_regexp
    from .testing.utils import do_test, test_pre_3
    from typed_ast.ast3 import parse
    from ..testing.visitor import CollectLinesVisitor

    assert line_matches_regexp(4, DictUnpackingTransformer,
                               test_pre_3.get_body())
    assert line_matches_regexp(5, DictUnpackingTransformer,
                               test_pre_3.get_body())


# Generated at 2022-06-12 03:37:46.883090
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def source():
        {1: 0, 2: 1, 3: 3}

    def expected():
        _py_backwards_merge_dicts([{1: 0, 2: 1, 3: 3}])

    node = ast.parse(source())
    node = DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected())



# Generated at 2022-06-12 03:37:52.257363
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''{1: 1, 2: 2, **{3: 3, 4: 4}}'''
    expected = '''_py_backwards_merge_dicts([{1: 1, 2: 2}], {3: 3, 4: 4})'''

    t = DictUnpackingTransformer()
    t.visit(ast.parse(source))
    assert expected == astunparse.unparse(t.tree)

# Generated at 2022-06-12 03:38:00.516740
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    source = """
        {
            'a': 1,
            **{'b': 'c'},
            'd': {'e': 'f'},
        }
    """

    expected = """
        _py_backwards_merge_dicts([
            {
                'a': 1,
                'd': {'e': 'f'},
            },
            {'b': 'c'}
        ])
    """

    source_node = ast.parse(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(source_node)
    actual = astor.to_source(source_node)

    assert actual.strip() == expected.strip()

# Generated at 2022-06-12 03:38:05.532442
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor  # type: ignore
    from .test_base import generate_test_function
    m = generate_test_function(astor.parse_file('testdata/dict_unpacking.py'))  # type: ignore
    m.body[0] = DictUnpackingTransformer().visit(m.body[0])
    src = astor.to_source(m)
    print(src)

# Generated at 2022-06-12 03:38:15.080621
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse as unparse_ast
    from .util import check_equal

    class DummyNodeTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            return node

    transformer = DictUnpackingTransformer()
    transformer.visit(
        ast.parse(
            "assert {1: 1, **dict_a} == {1: 1, 2: 2}",
            mode='exec'))
    transformed = unparse_ast(transformer._node)
    check_equal(
        transformed,
        "assert _py_backwards_merge_dicts([{1: 1}], dict_a) == {1: 1, 2: 2}")