

# Generated at 2022-06-12 03:29:05.501781
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    in_: ast.AST = ast.parse("""{1: 1, **dict_a}""")
    expected: ast.AST = ast.parse("""_py_backwards_merge_dicts([{1: 1}], dict_a)""")
    xformer = DictUnpackingTransformer()
    actual = xformer.visit(in_)
    assert ast.dump(actual) == ast.dump(expected), f"\n{ast.dump(actual)}"  # type: ignore

# Generated at 2022-06-12 03:29:15.248987
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert '_py_backwards_merge_dicts' in merge_dicts.replace_by_spaces()
    assert DictUnpackingTransformer().visit(ast.parse("""
        {1: 1, **dict_a, 2: 2}
        """)) == ast.parse("""
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
        """)
    assert DictUnpackingTransformer().visit(ast.parse("""
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
        """)) == ast.parse("""
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
        """)

# Generated at 2022-06-12 03:29:23.119614
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.Dict(
        keys=[ast.Num(n=1), None, ast.Name(id='a'), None, ast.Name(id='b')],
        values=[ast.Name(id='x'), ast.Name(id='y'), ast.Name(id='c')])
    obj = DictUnpackingTransformer()
    node = obj.visit(node)  # type: ignore

# Generated at 2022-06-12 03:29:26.018083
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import round_trip

    source = '''{1: 2, **{3: 4}}'''


# Generated at 2022-06-12 03:29:33.169495
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.analyse import find_dict_unpacking
    from ..utils.ast3_parse import ast3_parse
    from ..utils.replace_nodes import replace_nodes

    source = """{1: 2, None: 1}"""
    expected = """{1: 2, **{}}"""
    node = ast3_parse(source)
    assert find_dict_unpacking(node) == 1
    new_node = DictUnpackingTransformer().visit(node)
    assert find_dict_unpacking(new_node) == 0
    assert replace_nodes(new_node) == expected



# Generated at 2022-06-12 03:29:42.819674
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = "{1: 1, **dict_a}"
    tree = ast.parse(code)

    class Visitor(ast.NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Call:
            transformer = DictUnpackingTransformer()
            return transformer.visit(node)

    tree = tree.body[0]
    visitor = Visitor()
    result = visitor.visit(tree)
    assert result.__class__ is ast.Call

    names = [node.id for node in ast.walk(result) if isinstance(node, ast.Name)]
    assert names == ['_py_backwards_merge_dicts', 'dict', 'dict_a']


if __name__ == '__main__':
    test_DictUnpackingTransformer_visit_Dict

# Generated at 2022-06-12 03:29:51.241848
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 2, **{3: 4}}').body[0]
    d = DictUnpackingTransformer()
    new_node = d.visit(node)
    assert isinstance(new_node, ast.Call)
    assert isinstance(new_node.func, ast.Name)
    assert new_node.func.id == '_py_backwards_merge_dicts'
    assert isinstance(new_node.args[0], ast.List)
    assert new_node.args[0].elts == [ast.Dict(keys=[ast.Num(1)], values=[ast.Num(2)]), ast.Dict(keys=[ast.Num(3)], values=[ast.Num(4)])]

# Generated at 2022-06-12 03:30:01.627720
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..tests.fixtures import dict_unpacking_call
    from typed_ast.ast3 import parse
    from .. import transform_snippet
    from ..utils import parse_and_unwrap
    
    def assert_unpacking(py_src: str, unpack_pos: int, unpacked_src: str):
        node = parse_and_unwrap(py_src)
        unpacked_node = parse_and_unwrap(unpacked_src)
        index = py_src.index('{') + unpack_pos
        assert isinstance(node, ast.Dict)
        assert node.keys[unpack_pos] is None
        transform_snippet(DictUnpackingTransformer, node, 2, 5, index)
        assert isinstance(node, ast.Call)

# Generated at 2022-06-12 03:30:12.340512
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class TestDictUnpackingTransformer(DictUnpackingTransformer):
        pass

    tree = ast.parse('d = {1: 1, **{2: 2}, 3: 3, **{4: 4}}')
    TestDictUnpackingTransformer.visit(tree)

# Generated at 2022-06-12 03:30:18.714974
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    x = ast.parse('{1: 2, 3: 3, **a, **b, None: 4}')
    y = ast.parse('_py_backwards_merge_dicts([{1: 2, 3: 3}], a, b, {None: 4})')
    transformer = DictUnpackingTransformer()
    x_new = transformer.visit(x)
    assert ast.dump(y, annotate_fields=False) == ast.dump(x_new, annotate_fields=False)

# Generated at 2022-06-12 03:30:27.415955
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """{a: b, **c, 1: d, **e}"""
    expected = """_py_backwards_merge_dicts([{a: b}, {1: d}], c, e)"""
    assert DictUnpackingTransformer().visit(ast.parse(code)) == ast.parse(expected)



# Generated at 2022-06-12 03:30:32.073427
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    with source('{1: 1, **dict_a}') as s:
        module = ast.parse(s)
        transformer = DictUnpackingTransformer()
        node = transformer.visit(module)
        assert str(node) == '_py_backwards_merge_dicts([{1: 1}], dict_a)'

# Generated at 2022-06-12 03:30:38.683285
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse
    source = """{'a': 1, 0: 'b', **{'c': 2}, 'd': 3}"""
    node = ast.parse(source)
    result = DictUnpackingTransformer().visit(node)
    assert unparse(result) == "_py_backwards_merge_dicts([{'a': 1, 0: 'b'}, {'c': 2}, 'd': 3}])"

# Generated at 2022-06-12 03:30:46.424230
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import test_utils as tu
    import os
    import sys
    main_path = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    sys.path.insert(0, main_path)
    from backwards.backwards_modules import backwards_dict_unpacking
    import astor
    import ast

    node = ast.parse(
        """
        {1:1, **d}
        a = {**{}}
        """)
    new_node = DictUnpackingTransformer().visit(node)

# Generated at 2022-06-12 03:30:56.656015
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import cast
    from typed_ast.ast3 import parse
    from ..tools import assert_code_equal_ast

    source = '''
        {1: 2, None: {3: 4}, **a, None: b, 5: 6}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 2}, dict({3: 4}), dict(a), dict(b)], {5: 6})
    '''
    tree = parse(source)
    expected_tree = parse(expected)

    assert_code_equal_ast(
        cast(ast.expr, DictUnpackingTransformer().visit(tree)),
        cast(ast.expr, expected_tree)
    )



# Generated at 2022-06-12 03:31:06.558260
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse

    node = ast.Dict(keys=[ast.Num(n=1), None, None, ast.Str(s="2")],
                    values=[ast.Num(n=1),
                            ast.Dict(keys=[None], values=[ast.Name(id="dict_a")]),
                            ast.Dict(keys=[None], values=[ast.Name(id="dict_b")]),
                            ast.Num(n=2)])
    result = parse('_py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)')

    transformer = DictUnpackingTransformer()
    transformer.visit(node)
    assert transformer._tree_changed  # pylint: disable=protected-access

# Generated at 2022-06-12 03:31:16.644738
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import require_version

    require_version(DictUnpackingTransformer, (3, 4))

    assert repr(DictUnpackingTransformer().visit(ast.parse('{1: 1, **dict_a}', mode='eval'))) == \
        "Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), " \
        "args=[List(elts=[Dict(keys=[Num(n=1)], values=[Num(n=1)]), " \
        "Name(id='dict_a', ctx=Load())], ctx=Load())], keywords=[])"


# Generated at 2022-06-12 03:31:24.516554
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..testing import assert_conversion
    from ..testing import assert_unchanged


# Generated at 2022-06-12 03:31:27.093796
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.context import Context
    from ..utils.runner import run_all
    from ..utils import tree as ast_tree


# Generated at 2022-06-12 03:31:37.813516
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import Iterable, Optional, Tuple, Union
    from typed_ast import ast3 as ast
    from ..utils.tree import insert_at
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    # Create instances of the necessary classes
    ast_Assign = ast.Assign()
    ast_Assign.lineno = 14
    ast_Assign.col_offset = 0
    ast_Assign.targets = [ast.Name(id='result', ctx=ast.Store())]

# Generated at 2022-06-12 03:31:53.478163
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.unparse import unparse

    for name in (case.name for case in DictUnpackingTransformer.TESTS):
        source, expected_ast, expected_source = [
            case.strip()
            for case in unparse.tests[name].split('\n')[1:-1]
        ]
        ast_ = ast.parse(source)
        node = DictUnpackingTransformer().visit(ast_)
        source_ = unparse(node)
        if source_ != expected_source:
            print(source_)
            return False
    return True


# Generated at 2022-06-12 03:31:58.638012
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse

    class Test:
        def f(self):
            d = {
                1: 1,
                **dict_a,  # type: ignore
                **{},
                **dict_b,  # type: ignore
                **{1: 1},
                **{},
                2: 2
            }


# Generated at 2022-06-12 03:32:07.543746
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from typed_ast import ast3, parse

    source = dedent("""\
        {1: 2, **x, 5: 6, **y, **z}
        """)

    expected_source = dedent("""\
        _py_backwards_merge_dicts([{1: 2, 5: 6}], x, y, z)
        """)

    # Override method visit_Dict of class DictUnpackingTransformer
    # in order to visit AST node of type ast3.Dict
    def visit_Dict(self, node: ast.Dict) -> Union[ast.Dict, ast.Call]:
        self._tree_changed = True

# Generated at 2022-06-12 03:32:16.938067
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def check(node: ast.AST, expected: Union[ast.Dict, ast.Call]) -> None:
        assert DictUnpackingTransformer().visit(node) == expected

    check(ast.Dict(keys=[None], values=[ast.Dict()]),
          ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'),
                   args=[ast.List(elts=[ast.Call(
                       func=ast.Name(id='_py_backwards_merge_dicts'),
                       args=[ast.List(
                           elts=[ast.Call(
                               func=ast.Name(id='dict'),
                               args=[],
                               keywords=[])])],
                       keywords=[])])],
                   keywords=[]))

# Generated at 2022-06-12 03:32:28.007332
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast
    __tracebackhide__ = True

    class MockNodeTransformer(ast.NodeTransformer):
        def generic_visit(self, node):
            return node

    xs = [
        (None, {'a': 1, **{'b': 2, 'c': 3}}),
        (None, {**{'e': 4, 'f': 5}, 'c': 3}),
        (None, {'g': 6, **{'h': 7, 'i': 8}}),
    ]


# Generated at 2022-06-12 03:32:38.280796
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from unittest import TestCase
    from ..utils.helpers import normalize

    class Test(TestCase):
        def test(self):
            assert self

    visitor = DictUnpackingTransformer()
    tree = normalize('''
        {
            a: 1,
            **kwargs,
            b: 2,
            c: 3,
            **kwargs,
            d: 4
        }
    ''')

# Generated at 2022-06-12 03:32:47.549551
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    code = '''
    {1: 1, 2: 2, **a, 3: 3, **b, **d}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, a, b, d])
    '''
    node = ast.parse(code)
    expected_node = ast.parse(expected)
    transformer = DictUnpackingTransformer()
    result = ast.fix_missing_locations(transformer.visit(node))
    assert ast.dump(result) == ast.dump(expected_node)

# vim: set fileencoding=utf-8 ts=4 sw=4 et:

# Generated at 2022-06-12 03:32:55.047232
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from .context import Context
    from .base import BaseNodeTransformer
    
    context = Context()
    
    source = dedent("""\
        {1: 2, None: 1, 3: 4, None: 2, 5: 6}
        """)
    
    expected = dedent("""\
        _py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}], 1, _py_backwards_merge_dicts([{}], 2))
        """)
    
    transformer = DictUnpackingTransformer(context)
    actual = transformer.visit(ast.parse(source))
    assert context.dump(actual) == context.dump(ast.parse(expected))

# Generated at 2022-06-12 03:33:04.772873
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse_all

    def run_test(text: str) -> str:
        node = parse_all(text).body[0]
        return DictUnpackingTransformer().visit(node)

    assert run_test('''{1: 2}''') == '{1: 2}'
    assert run_test('''{1: 2, 3: 4}''') == '{1: 2, 3: 4}'
    assert run_test('''{1: 2, **{3: 4}}''') == '_py_backwards_merge_dicts([{1: 2}], {3: 4})'

# Generated at 2022-06-12 03:33:11.185935
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .transformer import Transformer
    d = {'a': 'b', 'c': 'd', **{'e': 'f'}, 'g': {'h': 'i', **{'j': 'k'}}, **{'l': 'm', **{'n': 'o'}}}

    t = Transformer()
    t.register_transformer(DictUnpackingTransformer)
    result = t.transform_ast(d)


# Generated at 2022-06-12 03:33:34.525919
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ast import parse
    from .transformer import transform

    source = """\
        x = {1: 2, **{4: 5, 'x': 'y'}, 3: 4}
    """

# Generated at 2022-06-12 03:33:44.043075
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, 2: 2, **dict_a}').body[0]

    result = transformer.visit(node)
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[
            ast.Dict(keys=[ast.Num(n=1), ast.Num(n=2)],
                     values=[ast.Num(n=1), ast.Num(n=2)]),
            ast.Name(id='dict_a')
        ])],
        keywords=[])

    assert transformer._tree_changed is True
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 03:33:51.632212
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse
    from astunparse import dump
    from ..utils.test_helpers import assert_equal_with_printing

    source = """\
        {**a, 1: 2, **b, **c}
        """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)  # type: ignore
    assert_equal_with_printing(dump(tree), """\
        _py_backwards_merge_dicts([dict(1=2)], a, b, c)
        """)

# Generated at 2022-06-12 03:33:57.725100
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():  # noqa
    code = {1: 2, 3: 4}
    assert ast.dump(DictUnpackingTransformer().visit(ast.parse(code))) == code

    code = {1: 2, 3: 4, **dict_a}
    result = '_py_backwards_merge_dicts([{1: 2, 3: 4}], dict_a)'
    assert ast.dump(DictUnpackingTransformer().visit(ast.parse(code))) == result

# Generated at 2022-06-12 03:34:08.330070
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import roundtrip

    def test_ok(before, after):
        assert roundtrip(before) == after

    def test_ko(before):
        assert roundtrip(before) == before

    test_ko('{}')
    test_ko('{1: 1}')
    test_ko('{**{}}')
    test_ko('{1: 1, **{}}')
    test_ko('{**{}, **{}}')
    test_ko('{1: 1, **{}, **{}}')
    test_ko('{1: 1, 2: 2, **{}}')
    test_ko('{1: 1, **{}, 2: 2}')
    test_ko('{1: 1, **{}, **{}, 2: 2}')

# Generated at 2022-06-12 03:34:16.015171
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class TestableDictUnpackingTransformer(DictUnpackingTransformer):
        def __init__(self, node, tree_changed=False):
            self._tree_changed = tree_changed

    # 1.
    node = ast.parse('''{1: 'one'}''').body[0]
    transformer = TestableDictUnpackingTransformer(node, True)
    result = transformer.visit_Dict(node)
    result_code = compile(ast.Module([result]), 'result.py', 'exec')
    assert eval(result_code) == {1: 'one'}

    node = ast.parse('''{1: 'one', 2: 'two'}''').body[0]
    transformer = TestableDictUnpackingTransformer(node, True)
    result = transformer.visit_D

# Generated at 2022-06-12 03:34:24.808997
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import assert_equal_ast
    from ..utils.tree import parse_ast

    source = """
d = {1: 1, **{2: 2}, 3: 3, **{}, 4: 4, **{5: 5}, 6: 6}
    """
    expected_result = """
d = _py_backwards_merge_dicts([{1: 1}, {3: 3}, {4: 4}, {6: 6}], {2: 2}, {}, {5: 5})
    """
    tree = parse_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected_result)

# Generated at 2022-06-12 03:34:33.539301
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import defaults

    snippet = """
        {**{1, 2}, 3: 3, **{4, 5}, **{}}  # noqa
    """

    expected = """
        _py_backwards_merge_dicts([{3: 3}, _py_backwards_merge_dicts([{1: 2}, {4: 5}])])
    """

    tree = defaults.PYTHON_PARSER.parse(snippet)  # type: ignore

    DictUnpackingTransformer.run(tree)
    tree = defaults.MANGLER.visit(tree)  # type: ignore
    compiled = defaults.FORMATTER.visit(tree)  # type: ignore

    assert expected == compiled

# Generated at 2022-06-12 03:34:39.944701
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import parse, assert_tree_equal
    from ..utils.tree import dump
    
    x = parse('''
        {
            **a,
            1: 2,
            **b,
            3: 4,
            'a': 5
        }
    ''')
    y = parse('''
        _py_backwards_merge_dicts(
            [
                {
                    1: 2,
                    'a': 5
                }
            ],
            a,
            b
        )
    ''')
    DictUnpackingTransformer().visit(x)
    assert_tree_equal(dump(x), dump(y))

# Generated at 2022-06-12 03:34:48.473557
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from astunparse import unparse
    from .base import BaseNodeTransformer
    
    class DictUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
        
            {1: 1, **dict_a}
            
        To:
        
            _py_backwards_merge_dicts([{1: 1}], dict_a})
        
        """
        target = (3, 4)
    
        def _split_by_None(self, pairs: Iterable[Pair]) -> Splitted:
            """"""
            result = [[]]  # type: Splitted
            for key, value in pairs:
                if key is None:
                    result.append(value)
                    result.append([])

# Generated at 2022-06-12 03:35:35.696307
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import BaseNodeTransformerTestCase, as_ast
    from ..utils.meta import copy_meta

    class DictUnpackingTransformerTestCase(BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer
        transformer_kwargs = {}


# Generated at 2022-06-12 03:35:46.289584
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def check(before: ast.AST, after: ast.AST):
        transformer = DictUnpackingTransformer()
        out = transformer.visit(before)
        assert out == after, out

    input_ = ast.parse('''
        {1: 1, 2: 2, **{3: 3}}
    ''')
    expected = ast.parse('''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], {3: 3})
    ''')
    check(input_, expected)

    input_ = ast.parse('''
        {**a, 1: 1, 2: 2, **{3: 3}, **b}
    ''')

# Generated at 2022-06-12 03:35:50.694305
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert eval(
        compile(  # type: ignore
            ast.parse(
                """{1: 1, 2: 2, **dict_a, **dict_b, 3: 3}""",
                '', 'eval'),
            '', 'exec',
            flags=ast.PyCF_ONLY_AST,
            optimize=0)) == {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6}

# Generated at 2022-06-12 03:35:55.608687
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typedpy_rewriter import compile

    code = """
    def foo():
        return {1: 0, 2: 1, **{}, 3: 3, **{4: 4}, 5: 5, **{}, **{6: 6}, 7: 7}
    """

    expected_code = compile(code)
    result_code = compile(code, [DictUnpackingTransformer])

    assert expected_code == result_code

# Generated at 2022-06-12 03:36:00.953219
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()
    source = """{1: 1, None: dict_a, 2: 2}"""
    expected = """_py_backwards_merge_dicts([dict({1: 1}), dict_a, dict({2: 2})])"""
    dut.assert_transformation(source, expected)



# Generated at 2022-06-12 03:36:04.902562
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''{1: 1, 2: 2, None: 3, 4: 4, None}'''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    

# Generated at 2022-06-12 03:36:11.199213
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as pyast
    node = pyast.parse(
        """
        y = {a: 1, b: 2, c: 3, **w}
        """, mode='eval')
    expected = pyast.parse(
        """
        y = _py_backwards_merge_dicts([{'a': 1, 'b': 2, 'c': 3}], w)
        """, mode='eval')
    assert DictUnpackingTransformer().visit(node) == expected

# Generated at 2022-06-12 03:36:22.007160
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import compile_source
    from ..utils.source import dedent
    from typing import List
    from . import types as t
    from ..utils import pretty_print
    from . import transforms


# Generated at 2022-06-12 03:36:32.499452
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    s = """
{1: 2, 3: 4, 5: 6, **dict_a, 7: 8, 9: 10, 11: 12, **dict_b, 13: 14}
    """
    tree = ast.parse(s)  # type: ignore
    DictUnpackingTransformer().visit(tree)
    assert to_source(tree) == "__tracebackhide__ = True\n\ndef __py_backwards_merge_dicts(dicts):\n    result = {}\n    for dict_ in dicts:\n        result.update(dict_)\n    return result\n\n__py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6, 7: 8, 9: 10, 11: 12, 13: 14}], dict_a, dict_b)"

# Generated at 2022-06-12 03:36:42.681916
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Assign, Tuple, dump
    from .helpers import assert_code_equal
    from . import ast_node_test_case

    class TestCase(ast_node_test_case.ASTNodeTestCase):
        TARGET_CLASS = DictUnpackingTransformer
