

# Generated at 2022-06-12 03:29:04.325898
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    c = DictUnpackingTransformer()
    assert c.visit(ast.parse('{}')) == ast.parse('{}')
    assert c.visit(ast.parse('{1: 2}')) == ast.parse('{1: 2}')
    assert c.visit(ast.parse('{**{1: 2}}')) == ast.parse('dict({1: 2})')
    assert c.visit(ast.parse('{**{1: 2}, **{3: 4}}')) == ast.parse('_py_backwards_merge_dicts([dict({1: 2})], {3: 4})')

# Generated at 2022-06-12 03:29:09.989361
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as pyast
    import unittest
    from pprint import pprint

    def _print_ast(node: pyast.AST) -> None:
        pprint(pyast.dump(node))

    class TestDictUnpackingTransformer(unittest.TestCase):
        def _test_visit_Dict(self, expected: pyast.AST, given: pyast.AST) -> None:
            expected = pyast.Module(body=[pyast.Expr(value=expected)])
            given = pyast.Module(body=[pyast.Expr(value=given)])
            expected = pyast.fix_missing_locations(expected)
            given = pyast.fix_missing_locations(given)

            _print_ast(expected)

            visitor = DictUnpackingTransformer()

# Generated at 2022-06-12 03:29:18.654093
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    import ast

    class Test(unittest.TestCase):
        def test_DictUnpackingTransformer_visit_Dict(self):
            pass

    node = ast.parse('{1: 1, **dict_a}').body[0].value
    transformer = DictUnpackingTransformer()
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    result = transformer.visit(node)  # type: ignore
    assert ast.dump(result, include_attributes=True) == ast.dump(expected, include_attributes=True)


# Generated at 2022-06-12 03:29:21.496674
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    module = ast.parse("{1: 1, 2: 2, **dict_a}")
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-12 03:29:28.821382
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    x = {1: 1, 2: 2, **{3: 3, 4: 4, **{5: 5, 6: 6}}}
    node = ast.parse(src_of(x))
    node = DictUnpackingTransformer().visit(node)
    x = {1: 1, 2: 2, **{3: 3, 4: 4, **{5: 5, 6: 6}}}
    y = compile(node, '<test>', 'eval')
    assert eval(y) == x

# Generated at 2022-06-12 03:29:35.954530
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typedastunparse import unparse
    from ..utils.compiler import compile_snippet
    from ..visitor import ASTNodeVisitor

    class Visitor(ASTNodeVisitor):
        def visit_Dict(self, node):
            return node.__dict__

    snippet = '{1: 1, 2: 2, 3: 3}'
    node_dict = compile_snippet(snippet, 'visit_Dict', Visitor)
    transformed = compile_snippet(node_dict, 'visit_Dict_transformed', Visitor)

    assert transformed == node_dict
    node_dict = compile_snippet('{1: 1, **dict_a}', 'visit_Dict', Visitor)

# Generated at 2022-06-12 03:29:44.035629
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Given
    input_code = """
        some_dict = {1: 2, **other_dict}
    """
    expected_code = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        some_dict = _py_backwards_merge_dicts([{1: 2}], other_dict)
    """

    # When
    actual_code = DictUnpackingTransformer().visit(tk.parse_source(input_code))

    # Then
    assert tk.to_source(actual_code) == expected_code

# Generated at 2022-06-12 03:29:53.983323
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    tr = DictUnpackingTransformer()
    assert isinstance(
        tr.visit(ast.parse('{1: 1, 2: 2, **d}')),
        ast.Call,
    )
    assert isinstance(
        tr.visit(ast.parse('{1: 1, 2: 2, 3: 3, **d}')),
        ast.Call,
    )
    assert isinstance(
        tr.visit(ast.parse('{**d}')),
        ast.Call,
    )
    assert isinstance(
        tr.visit(ast.parse('{**d, 1: 1}')),
        ast.Call,
    )

# Generated at 2022-06-12 03:30:00.694972
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{1: 1, **dict_a, **dict_b}')
    new_tree = DictUnpackingTransformer().visit(tree)
    expected_tree = ast.parse('''
        _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)
    ''')
    assert ast.dump(new_tree, annotate_fields=False) == ast.dump(expected_tree, annotate_fields=False)

# Generated at 2022-06-12 03:30:03.692611
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .fixtures.dict_unpacking import source, expected, get_expected
    from .test_transformers import do_test
    do_test(source, expected, DictUnpackingTransformer, get_expected)

# Generated at 2022-06-12 03:30:18.331515
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Test case 1
    """
    {1:1}
    """
    # Should return ast.Dict(keys=[Constant(1, None)], values=[Constant(1, None)], ctx=Load())
    test_1 = ast.parse("{1:1}")
    result_1 = DictUnpackingTransformer().visit(test_1)
    expected_1 = ast.Dict(keys=[ast.Constant(1, None)], values=[ast.Constant(1, None)], ctx=ast.Load())

    assert result_1.keys == expected_1.keys
    assert result_1.values == expected_1.values
    assert result_1.ctx == expected_1.ctx

    # Test case 2
    """
    {None: d}
    """
    # Should return ast.

# Generated at 2022-06-12 03:30:23.056743
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_source

    input = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'

    assert_source(input, expected, DictUnpackingTransformer.transform)

# Generated at 2022-06-12 03:30:32.379082
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert transform(DictUnpackingTransformer, '{1: 1, 2: 2}') == '{1: 1, 2: 2}'

    assert transform(DictUnpackingTransformer, '{1: 1, **{2: 2}}') == '_py_backwards_merge_dicts([{1: 1}], {2: 2})'

    assert transform(DictUnpackingTransformer, '{1: 1, **a, **b}') == \
        '_py_backwards_merge_dicts([{1: 1}], a, b)'

    assert transform(DictUnpackingTransformer, '{1: 1, **a, **b, **c}') == \
        '_py_backwards_merge_dicts([{1: 1}], a, b, c)'


# Generated at 2022-06-12 03:30:42.386564
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import compare_ast
    from .. import pprint
    from typed_ast import ast3 as ast

    # TODO: Test with complex expressions
    # Test with simple literals
    source = """
        x = {'a' : 0, 'b': 1, 'c': 2}
        y = {**x, 'd': 3, **z}
        """

# Generated at 2022-06-12 03:30:48.379015
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    before = ast.parse(
        '{{1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5, **{6: 6}}}')

    after = ast.parse(
        '{{2: 2, 4: 4, 6: 6, 1: 1, 3: 3, 5: 5}}')

    assert DictUnpackingTransformer(3).visit(before) == after  # type: ignore

# Generated at 2022-06-12 03:30:56.104137
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    _dict = ast.Dict(keys=[None, ast.Constant(value=1)],
                     values=[ast.Dict(keys=[ast.Name(id='a')],
                                      values=[ast.Constant(value=1)]),
                             ast.Constant(value=1)])
    expected_code = """\
{'a': 1, **dict(**{1: 1})}
"""
    result = DictUnpackingTransformer().visit(_dict)
    assert astor.to_source(result).rstrip() == expected_code

# Generated at 2022-06-12 03:30:59.771162
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import parse, get_ast
    from ..utils.tree import ast_equal

    tree = parse("x = {**a}")
    tree = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-12 03:31:07.023135
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import textwrap
    source = textwrap.dedent("""
    {1: 1, 2: 2, **{3: 3, **{4: 4}}}
    """)
    expected = textwrap.dedent("""
    _py_backwards_merge_dicts(
        [{1: 1, 2: 2}, {3: 3}, {4: 4}])
    """)
    result = astunparse.unparse(DictUnpackingTransformer().visit(ast.parse(source)))
    assert result == expected

# Generated at 2022-06-12 03:31:17.265794
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def f():
        return {'a': 1, 'b': 2, **{'c': 3, 'd': 4}, **{'e': 5}}

    node = ast.parse(f.__code__)

# Generated at 2022-06-12 03:31:24.831571
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from doctrans import text_to_ast, ast_to_text
    
    def assert_unchanged(s):
        node = text_to_ast(s)
        node_ = DictUnpackingTransformer().visit(node)
        assert ast_to_text(node_) == s
    
    def assert_transformed(input, output):
        node = text_to_ast(input)
        node_ = DictUnpackingTransformer().visit(node)
        assert ast_to_text(node_) == output
    
    assert_unchanged('''
        {}
    ''')
    
    assert_transformed('''
        {None: {1}}
    ''', '''
        _py_backwards_merge_dicts([{}], {1})
    ''')
    

# Generated at 2022-06-12 03:31:28.166293
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-12 03:31:38.993261
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...testing import transforms_as

# Generated at 2022-06-12 03:31:46.984398
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import os
    import unittest
    from ..testing import load_program_for_testing, assert_program_equivalence
    
    source = """
    {1: 1, 2: 2, 3: 3}
    """
    expected = """
    {1: 1, 2: 2, 3: 3}
    """
    root = load_program_for_testing(source, os.path.join(os.path.dirname(__file__),
                                                         f"{os.path.splitext(__file__)[0]}.py"))
    DictUnpackingTransformer().visit(root)
    assert_program_equivalence(root, expected)


# Generated at 2022-06-12 03:31:50.179514
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import ast
    assert isinstance(DictUnpackingTransformer(), ast.NodeTransformer)

# Unit tests to check behaviour of class DictUnpackingTransformer

# Generated at 2022-06-12 03:31:58.639455
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import _ast as ast
    import asttokens
    source = '''\
a = {1: 2, **b, **c}
'''
    atok = asttokens.ASTTokens(source, parse=True)
    expected = '''\
import _py_backwards_merge_dicts
a = _py_backwards_merge_dicts([{1: 2}], b, c)
'''
    node = atok.tree
    transformed = DictUnpackingTransformer().visit(node)  # type: ignore
    atok.set_ast(transformed)
    actual = atok.get_text()
    assert actual == expected

# Generated at 2022-06-12 03:32:07.544797
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import code_gen
    from ..utils.graph import Graph

    # ast.parse creates incorrect AST for unpacking dict
    correct_ast = ast.parse("""
        {1: 2, **dict_a}
        """).body[0]
    unpacked_dict = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(elts=[
                ast.Dict(
                    keys=[ast.Num(n=1)],
                    values=[ast.Num(n=2)]),
                ast.Name(id='dict_a')
            ])
        ],
        keywords=[])

    transformer = DictUnpackingTransformer()
    assert transformer.visit(correct_ast) == unpacked_dict
    
    # Unit test for

# Generated at 2022-06-12 03:32:08.937000
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__doc__

# Generated at 2022-06-12 03:32:13.000521
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1, **dict_a}')
    visitor = DictUnpackingTransformer()
    new_module = visitor.visit(module)

    assert '_py_backwards_merge_dicts' in ast.dump(new_module)

# Generated at 2022-06-12 03:32:22.523221
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    from ..utils.tree import ast_to_str

    nodes = {'e_none': ast.Name(id='None', ctx=ast.Load()),
             'e_e': ast.Name(id='e', ctx=ast.Load()),
             'e_f': ast.Name(id='f', ctx=ast.Load())}


# Generated at 2022-06-12 03:32:32.825774
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .unpacking_transformer import UnpackingTransformer
    from ..utils.tree import dump_tree, print_tree
    from ..utils.source import Source
    from .. import target
    source = Source("""
source = '''
x = {'a': 1, **dict_a, 'b': 2, *lst_b, **dict_c, 'c': 3, *lst_d, **dict_e}
'''
    """)

    ast_module = source.get_ast(target)
    UnpackingTransformer().visit(ast_module)
    ast_module = DictUnpackingTransformer().visit(ast_module)
    print_tree(ast_module)

# Generated at 2022-06-12 03:32:46.760207
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from textwrap import dedent
    source = dedent("""\
    {1: 1}""")
    expected = dedent("""\
    {1: 1}""")
    transformer = DictUnpackingTransformer()
    node = ast.parse(source)
    transformer.visit(node)
    actual = astor.to_source(node)
    assert expected == actual

    source = dedent("""\
    {1: 1, **{2: 2}}""")
    expected = dedent("""\
    _py_backwards_merge_dicts([{1: 1}], {2: 2})""")
    transformer = DictUnpackingTransformer()
    node = ast.parse(source)
    transformer.visit(node)

# Generated at 2022-06-12 03:32:48.657047
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .simple import transform_simple_module

# Generated at 2022-06-12 03:32:56.561947
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from mypy.types import NoneType
    from ..utils.builder import build

    ast_tree = build(  # noqa
        """
        def foo(x):
            return {1: 1, 2: 2, None: [], *x}
        """
    )
    transformer = DictUnpackingTransformer()
    transformer.visit(ast_tree)
    body = ast_tree.body[0].body  # type: ast.FunctionDef
    assert isinstance(body[0], ast.Return)
    assert isinstance(body[0].value, ast.Call)
    call = body[0].value  # type: ast.Call
    assert call.func.id == '_py_backwards_merge_dicts'
    assert isinstance(call.args[0], ast.List)

    args = call.args

# Generated at 2022-06-12 03:33:04.429394
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as pyast
    from ..treewrapper import TreeWrapper
    from asm_parser import parse_asm

    value = pyast.parse("{1: 1, **{2: 2, **{3: 3}}}")
    node = TreeWrapper(parse_asm(value)).body[0].value.value
    DictUnpackingTransformer().visit(node)

    expected = pyast.parse("_py_backwards_merge_dicts([{1: 1}], {2: 2}, {3: 3})")
    expected = TreeWrapper(parse_asm(expected)).body[0].value.value
    assert node == expected

# Generated at 2022-06-12 03:33:06.894908
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from .test_base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = DictUnpackingTransformer

    test = Test()


# Generated at 2022-06-12 03:33:07.309474
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-12 03:33:15.741603
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    x = ast.Module([
        ast.Expr(
            value=ast.Dict(
                keys=[
                    None,
                    ast.Num(n=2.0)],
                values=[
                    ast.Dict(keys=[], values=[]),
                    ast.Num(n=3.0)]))])


# Generated at 2022-06-12 03:33:19.468298
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3

    code = """\
{1: 1, 2: 2, 3: 3}
"""
    module = ast.parse(code)
    expected_module = ast3.parse(code)

    actual_module = DictUnpackingTransformer().visit(module)

    assert actual_module == expected_module



# Generated at 2022-06-12 03:33:28.335230
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent
        

# Generated at 2022-06-12 03:33:38.001019
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import make_cst, assert_code_equal, assert_ast_equal
    from typed_ast import ast3
    from ..utils.test_utils import assert_nodes_equal

    transformer = DictUnpackingTransformer()

    node = make_cst(code='''
        {'a': 1, **x, 'b': 2, **y, 'c': 3, **z}
    ''')
    expected = make_cst(code='''
        _py_backwards_merge_dicts([{'a': 1, 'b': 2, 'c': 3}], x, y, z)
    ''')
    assert_code_equal(transformer.visit(node), expected)


# Generated at 2022-06-12 03:33:48.814380
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse('dict(a=1)', mode='eval')
    _ = transformer.visit(module)
    assert transformer._tree_changed

# Generated at 2022-06-12 03:33:51.965205
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ...utils.testing import run_example_module

    run_example_module(examples.MERGING_DICT_IN_DICT,
                       dict_unpacking_transformer=DictUnpackingTransformer)

# Generated at 2022-06-12 03:34:02.088158
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Arrange
    input_text = """
        {a: 1, None: [], b: 2, None: {}, c: 3}
    """
    expected_text = """
        a = 1
        b = 2
        c = 3
        _py_backwards_merge_dicts([{'a': a, 'b': b, 'c': c}], [], {}, [])
    """
    trns = DictUnpackingTransformer()
    node = ast.parse(input_text)
    # Act
    trns.visit(node)
    # Assert
    expected_node = ast.parse(expected_text)
    # Use astor.to_source to compare nodes because it compares lineno attrs of
    # nodes, so more precise than == operator.

# Generated at 2022-06-12 03:34:03.639004
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert hasattr(DictUnpackingTransformer, 'target')

# Generated at 2022-06-12 03:34:11.063128
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1, **dict_a, 2: 2}')
    DictUnpackingTransformer().visit(module)
    assert repr(module) == repr(ast.parse("""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        {1: 1, **_py_backwards_merge_dicts([{2: 2}], dict_a)}
    """))



# Generated at 2022-06-12 03:34:12.304142
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class TestTransformer(DictUnpackingTransformer):
        pass

    assert TestTransformer()

# Generated at 2022-06-12 03:34:21.525309
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import unparse
    from .minifier import Minifier
    from .utils import transform_code
    from .smart_lambda import SmartLambdaTransformer

    context = {'dict_a': {'b': 2}}
    code = """
    a = {1: 1, **dict_a}
    """
    expected = """
    dict_a=context['dict_a']
    a=_py_backwards_merge_dicts((dict(((1, 1),)),dict()),dict(dict_a))
    """
    assert transform_code(code, [Minifier, SmartLambdaTransformer,
                                 DictUnpackingTransformer]) == expected
    assert unparse(Minifier.run(code)) == expected



# Generated at 2022-06-12 03:34:22.957050
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)

# Generated at 2022-06-12 03:34:29.395633
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse('{1: 1, **dict_a, 3: 3}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}, dict_a], {3: 3})')
    transformer = DictUnpackingTransformer()
    result = transformer.visit_Module(module)
    assert ast.dump(result, include_attributes=False) == ast.dump(expected, include_attributes=False)


# Generated at 2022-06-12 03:34:37.422647
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse("""
{1: 1, **dict_a, **dict_b}
{**dict_a, **dict_b}
{1: 1, **dict_a, **dict_b, 2: 2}
{**dict_a, **dict_b, 2: 2}
""")

# Generated at 2022-06-12 03:35:01.593420
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import transform
    x = transform(
        '''
        {1:2, 3:4, **dict_a, 5:6, **dict_b, **dict_c, 7:8, **dict_d}
        ''',
        [DictUnpackingTransformer])

    assert x == '''
        _py_backwards_merge_dicts(
            [{1:2, 3:4, 7:8}],
            dict_a,
            {5:6},
            dict_b,
            dict_c,
            dict_d)
        '''

# Generated at 2022-06-12 03:35:02.514739
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-12 03:35:03.255443
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)



# Generated at 2022-06-12 03:35:12.588303
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest

    class MyTest(BaseNodeTransformerTest):
        transformer = DictUnpackingTransformer

        def test_dont_change_dict_without_unpacking(self):
            self.assert_transformation(
                {'a': 1, 'b': 2},
                {'a': 1, 'b': 2}
            )
            self.assert_transformation(
                {'a': 1, 'b': 2, **{'c': 3}},
                {'a': 1, 'b': 2, **{'c': 3}}
            )


# Generated at 2022-06-12 03:35:16.352686
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    with tf.Module() as m:
        x = tf.constant(1)
    m2 = tf.load_module_from_str(str(m))
    x = m2.x
    assert tf.executing_eagerly() == True
    assert x.numpy() == 1

# Generated at 2022-06-12 03:35:20.370647
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    source = {1: 1, **dict_a}
    expected_code = (
        "_py_backwards_merge_dicts([{1: 1}], dict_a})")

    result = DictUnpackingTransformer().visit(source)
    assert expected_code == result

# Generated at 2022-06-12 03:35:28.998449
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 1, 2: 2, 3: 3, **a, 4: 4, **b}')
    result = DictUnpackingTransformer().visit(node)
    assert isinstance(result, ast.Call)
    assert len(result.args) == 1
    assert isinstance(result.args[0], ast.List)
    assert len(result.args[0].elts) == 3
    assert isinstance(result.args[0].elts[0], ast.Dict)
    assert len(result.args[0].elts[0].keys) == 2
    assert result.args[0].elts[0].keys[0] == ast.Num(1)
    assert result.args[0].elts[0].keys[1] == ast.Num(2)

# Generated at 2022-06-12 03:35:37.788270
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    transformed = DictUnpackingTransformer().visit(ast.parse('''
        x = {1: 1}
        y = {**x}
    '''))  # type: ignore
    expected = ast.parse('''
        from typed_ast import ast3 as ast
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        x = {1: 1}
        y = _py_backwards_merge_dicts([{1: 1}], x)
    ''')
    assert_equal(transformed, expected)

# Generated at 2022-06-12 03:35:46.933997
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_ast_eq

    # noinspection PyClassHasNoInit
    class TestNode:
        def __init__(self, head, values):
            self.head = head
            self.values = values

    transformer = DictUnpackingTransformer()
    in_ast = ast.parse('{1: 1, **dict_a, 2: 2, **dict_b}')
    out_ast = ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, '
                        'dict_b)')
    assert_ast_eq(out_ast, transformer.visit(in_ast))



# Generated at 2022-06-12 03:35:56.739220
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    # Empty dict
    dict_expr = ast.Dict(keys=[], values=[])
    visitor = DictUnpackingTransformer()
    result = visitor.visit(dict_expr)
    compare = ast.Dict(keys=[], values=[])
    assert result == compare

    # Dict with unpacking
    dict_expr = ast.Dict(keys=[ast.Num(1), None], values=[ast.Num(1), ast.Name(id='x')])
    result = visitor.visit(dict_expr)

# Generated at 2022-06-12 03:36:27.660017
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None


# Generated at 2022-06-12 03:36:33.406497
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast.parse('{1: 1, **dict_a, 2: 2}'))
    expected = ast.parse('''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    ''')
    assert ast.dump(expected) == ast.dump(result)

# Generated at 2022-06-12 03:36:34.995313
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t is not None

# Generated at 2022-06-12 03:36:44.728245
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source_code = '''\
{1: 1}
{1: 1, 2: 2, 3: 3, **{4: 4, 5: 5}}
{1: 1, 2: 2, 3: 3, **{4: 4, 5: 5}, **{6: 6, 7: 7}}
{**a}
{1: 1, **a, **b, 2: 2, 3: 3, **c}
{1: 1, **a, 2: 2, 3: 3, **b, **c}
'''

# Generated at 2022-06-12 03:36:48.058260
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .. import transform

    @transform(DictUnpackingTransformer)
    def test_dict(a: dict):
        return {1: 1, **a}

    test_dict({'a': 1})



# Generated at 2022-06-12 03:36:54.586237
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast import ast_to_str

    tree = ast.parse('{i: i for i in range(10), **d, 4: 5}')
    tree = DictUnpackingTransformer().visit(tree)
    code = ast_to_str(tree)
    assert code == '_py_backwards_merge_dicts([{0: 0, 1: 1, 2: 2, 3: 3, ' \
                    '4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9}, d], {4: 5})'

# Generated at 2022-06-12 03:37:04.058340
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None

    pairs = [(None, ast.Dict(keys=[ast.Num(1), ast.Num(2)],
                             values=[ast.Num(1), ast.Num(2)])),
             (ast.Num(2), ast.Num(2)),
             (None, ast.Call(
                func=ast.Name(id='dict'),
                args=[ast.Dict(keys=[ast.Num(3), ast.Num(4)],
               values=[ast.Num(3), ast.Num(4)])],
                keywords=[])),
             (ast.Num(4), ast.Num(4))]


# Generated at 2022-06-12 03:37:11.538840
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.fake_ast_nodes import FakeModule
    from .ast_utils import dump_ast, dump_source

    source_str = """
{1: 1, **dict_a}
"""
    source = source_str.strip()
    result_str = """
_py_backwards_merge_dicts([{1: 1}], dict_a)
"""
    result = result_str.strip()

    module = FakeModule.build(source)
    transformer = DictUnpackingTransformer()
    new_module = transformer.visit(module)
    new_source = dump_source(new_module).strip()

    assert result == new_source

# Generated at 2022-06-12 03:37:18.516273
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse  # type: ignore
    from typed_astunparse import unparse  # type: ignore

    source = '''
    {1: 1, None: {**dict_a}, None: {**dict_b}, 2: 2}
    '''
    expected = '''
    _py_backwards_merge_dicts([dict(1=1), dict_a, dict_b], {})[2]
    '''
    module = parse(source)
    transformer = DictUnpackingTransformer()
    module = transformer.visit(module)
    assert unparse(module)[0] == expected

# Generated at 2022-06-12 03:37:27.998285
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test import render_transformed

    code = """
        {1: 1, **dict_a}
    """
    res = render_transformed(code, DictUnpackingTransformer)
    exp = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([dict({1: 1}), dict_a])
    """
    assert res.strip() == exp.strip()

    code = """
        {**dict_a, **{}}
    """
    res = render_transformed(code, DictUnpackingTransformer)

# Generated at 2022-06-12 03:38:45.440707
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None
    def check(expr, expected_expr):
        # type: (str, str) -> None
        expected_tree = ast.parse(expected_expr)
        node = ast.parse(expr)
        tree_changed = DictUnpackingTransformer().visit(node)
        expected_tree.body[0].body[0].body[0].body[0]\
            .value.args[0].elts = sorted(expected_tree.body[0].body[0].body[0]
                                         .body[0].value.args[0].elts,
                                         key=lambda x: x.elts[0].n)

# Generated at 2022-06-12 03:38:46.228799
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    t = DictUnpackingTransformer()
    assert t