

# Generated at 2022-06-12 03:29:05.132979
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from unittest import mock
    import ast

    class Dummy(BaseNodeTransformer):
        def visit_Ignored(self, node):
            return node

    class Node:
        def __init__(self, args):
            self.args = args

        def get_body(self):
            return self.args[0]

    def fake_transform(node):
        return node

    node = Node([
        ast.Dict(keys=[None, 1, 2, None],
                 values=[None, 2, 3, 4])
    ])

    trans = DictUnpackingTransformer(mock.Mock(tree=node,
                                               __class__=Dummy,
                                               generic_visit=fake_transform))

# Generated at 2022-06-12 03:29:14.881309
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:29:19.430189
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''
        {1: 2, **a, 3: 4, **b}
    '''
    expected = '''
        _py_backwards_merge_dicts([dict([(1, 2), (3, 4)]), a, b])
    '''
    DictUnpackingTransformer.test(source, expected)

# Generated at 2022-06-12 03:29:26.693626
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    import ast
    code = """
        {1:2, 3: 4, **a}
    """
    result = """
        _py_backwards_merge_dicts([{1: 2, 3: 4}], a)
    """
    result_tree = ast.parse(result)
    tree = ast.parse(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert astor.to_source(tree) == astor.to_source(result_tree)

# Generated at 2022-06-12 03:29:30.754427
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from .perform_transformation import perform_transformation
    from ..fixers.backward_compatibility import DictUnpackingTransformer
    code = '''{1: 1, **{2: 2, 3: 3}}'''
    fixed_code = perform_transformation(code, [DictUnpackingTransformer])
    assert astor.to_source(ast.parse(fixed_code)) == '''_py_backwards_merge_dicts([{1: 1}], {2: 2, 3: 3})'''



# Generated at 2022-06-12 03:29:40.025451
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import run_on_examples

    examples = (
        """
            {}
        """,
        """
            {**{'key': 1}}
        """,
        """
            {1: 1, **{'key': 1}}
        """,
        """
            {1: 1, **(dict(key=1))}
        """,
        """
            {1: 1, **x}
        """,
    )

# Generated at 2022-06-12 03:29:48.044573
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..main import compile
    from ..utils.serialize import dump_ast


# Generated at 2022-06-12 03:29:53.393864
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_transformer import (transform_and_assert_tree, ast_to_native)
    from astor.codegen import to_source

    code = """
    {}
    """

    transformer = DictUnpackingTransformer()
    module = transform_and_assert_tree(transformer, code)


# Generated at 2022-06-12 03:30:00.813160
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_setup import setup

    source = """{1: 1, None: dict_1, **dict_2, 2: 2, **dict_3}"""
    tree = setup(source)
    DictUnpackingTransformer().visit(tree)

    assert str(tree) == """\
_py_backwards_merge_dicts(
    [{1: 1}, dict_1, dict({2: 2})],
    _py_backwards_merge_dicts(
        [{}],
        dict_2,
        dict_3))"""

# Generated at 2022-06-12 03:30:04.446583
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .helpers import assert_node_equal

    node = ast.parse('{1: 1, **{2: 2}, 3: 3}')
    DictUnpackingTransformer(node).run()
    want = ast.parse(
        '_py_backwards_merge_dicts([{1: 1}], dict({2: 2}), {3: 3})')
    assert_node_equal(want, node)

# Generated at 2022-06-12 03:30:20.280322
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    from typed_ast import ast3

    class TestDictUnpackingTransformer(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.transformer = DictUnpackingTransformer()


# Generated at 2022-06-12 03:30:30.349004
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.node import insert_fields

    class DummyVisitor(ast.NodeVisitor):
        def visit(self, node):
            return node

        def visit_Name(self, node):
            return node

    node = ast.parse('''x = {1: 2, **a, 2: 3}''')
    cls = DummyVisitor()
    cls.visit_Name = DictUnpackingTransformer.visit_Name.__func__  # type: ignore
    cls.visit_Dict = DictUnpackingTransformer.visit_Dict.__func__  # type: ignore
    cls.visit_Module = DictUnpackingTransformer.visit_Module.__func__  # type: ignore
    cls.visit_

# Generated at 2022-06-12 03:30:40.497616
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_unicode
    from ..visitor import to_source
    
    source = source_to_unicode("""
        {1: 2, **a, **b, 3: 4, **c, 5: 6}
    """)
    
    
    expected_source = source_to_unicode("""
        _py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}], a, b, c)
    """)
    
    root_node = ast.parse(source)
    transform = DictUnpackingTransformer()
    new_root = transform.visit(root_node)
    new_source = to_source(new_root)
    
    assert new_source == expected_source

# Generated at 2022-06-12 03:30:41.159085
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:30:42.496467
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import run_local_tests
    run_local_tests(globals())



# Generated at 2022-06-12 03:30:53.187424
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:31:01.828083
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    f = ast.parse('{**{1: 2}, **{3: 4}}')
    t = DictUnpackingTransformer()
    node = t.visit(f)

# Generated at 2022-06-12 03:31:07.473089
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict

    dict1 = Dict(keys=[], values=[])
    dict2 = Dict(keys=['a'], values=[1])
    dict3 = Dict(keys=['a'], values=[1, None])

    assert DictUnpackingTransformer().visit(dict1) == dict1
    assert DictUnpackingTransformer().visit(dict2) == dict2
    assert DictUnpackingTransformer().visit(dict3) == dict2

# Generated at 2022-06-12 03:31:17.845064
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    
    import astor

    source = dedent('''\
    # comment
    
    
    
    # comment
    a = {{1: 1, **dict_a}: 2, 'b': 3 + 6, **dict_b}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # comment
    ''')  # noqa


# Generated at 2022-06-12 03:31:19.768790
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert compile(merge_dicts.get_ast(), '', mode='exec')


# Generated at 2022-06-12 03:31:39.383260
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-12 03:31:46.348337
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
{
    "a": 1,
    "b": 2,
    **c,
    "d": 3,
    **e,
    "f": 4,
}
"""
    expected = """
_py_backwards_merge_dicts([dict({
    "a": 1,
    "b": 2,
}), c, dict({
    "d": 3,
}), e, dict({
    "f": 4,
})])
"""
    result = transform(source, [DictUnpackingTransformer])
    assert_equal(result, expected)

# Generated at 2022-06-12 03:31:55.604403
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse

    source = """
            {1: 2, 3: 4, **y, 5: 6, **z, 7: 8}
    """

    tree = parse(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)

    expected_result_source = """
            _py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6, 7: 8}], y, z)
    """

    expected_result = parse(expected_result_source)
    assert expected_result.body[0].value.elts[0].keys == [
        ast.Num(1),
        ast.Num(3),
        ast.Num(5),
        ast.Num(7),
    ]

# Generated at 2022-06-12 03:31:59.920164
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import xoutil.future.api as future
    from xoutil.future.tests.test_dict_unpacking import test_data

    for source, expected in test_data.items():
        assert future.transform(DictUnpackingTransformer, source) == expected

# Generated at 2022-06-12 03:32:08.289727
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    left = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                    values=[ast.Num(n=1), ast.Name(id='A'), ast.Num(n=3)])
    right = ast.Dict(keys=[ast.Num(n=2), None, ast.Num(n=3)],
                     values=[ast.Num(n=3), ast.Name(id='D'), ast.Num(n=4)])

# Generated at 2022-06-12 03:32:15.485729
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''{1: 10, "2": 20, 3: 30, None: 40, "5": 50}'''
    expected = '''_py_backwards_merge_dicts([{1: 10, "2": 20, 3: 30}], 40, {'5': 50})'''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    result = compile(tree, '<test>', 'eval').co_consts[0]
    assert result == expected



# Generated at 2022-06-12 03:32:26.042327
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test if methods in class DictUnpackingTransformer
    and method visit_Dict in particular works correctly."""

    import astor
    from ..utils.run_in_python_version import run_in_python_version

    class Dummy(DictUnpackingTransformer):
        _tree_changed = False

    code_under_test = """
    def some_func(a):
        return {1: 2, **a}

    """

    for version in (3, 4):
        result = run_in_python_version(
            Dummy,
            code_under_test,
            version=version,
            return_target_ast=True)
        assert result["Dummy"]._tree_changed is True
        code = astor.to_source(result["targets"]["some_func"])
        func

# Generated at 2022-06-12 03:32:36.612612
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from .test_base import BaseTestTransformer

    code = '''\
    {'a': 1, 'b': 2, **{'c': 3, 'd': 4}, 'e': 5}
    '''

    expected_code = '''\
    _py_backwards_merge_dicts([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}], {'e': 5})
    '''

    expected_ast = ast.parse(expected_code)

    test = BaseTestTransformer(code=code, transformer=DictUnpackingTransformer)
    test.test()
    actual_ast = test.module
    assert astor.to_source(actual_ast) == astor.to_source(expected_ast)


# Generated at 2022-06-12 03:32:43.343015
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astmonkey import transformers
    src = '{1: 1, 2: 2, None: {3: 3, 4: 4}, 5: 5}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3, 4: 4}], {5: 5})'

    transformer = transformers.DictUnpackingTransformer()
    result = transformer.visit(ast.parse(src))  # type: ignore
    assert ast.dump(result) == expected



# Generated at 2022-06-12 03:32:51.392236
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseTestTransformer
    from .base import node_factory

    class TestTransformer(BaseTestTransformer):
        transformer = DictUnpackingTransformer

        @node_factory(values=lambda: {1: 1, **{2: 2}},
                      expected=lambda: _py_backwards_merge_dicts([{1: 1}], {2: 2}))
        def test_1(self, values, expected):
            return values

        @node_factory(values=lambda: {**{1: 1}, **{2: 2}},
                      expected=lambda: _py_backwards_merge_dicts([{1: 1}], {2: 2}))
        def test_2(self, values, expected):
            return values


# Generated at 2022-06-12 03:33:11.421512
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Compiler(ast.NodeVisitor):
        def visit(self, node):
            return DictUnpackingTransformer().visit(node)
    

# Generated at 2022-06-12 03:33:19.734146
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():  # TODO: improve this test
    def roundtrip(source):
        code = compile(source, '?', 'exec')
        ast_tree = ast.parse(source)
        DictUnpackingTransformer().visit(ast_tree)
        target = compile(ast_tree, '?', 'exec')
        assert code == target, ast.dump(code)

    roundtrip('{1: 1}')
    roundtrip('{1: 1, 2: 2}')
    roundtrip('{**{1: 1}}')
    roundtrip('{1: 1, **{2: 2}}')
    roundtrip('{1: 1, **{2: 2, 3: 3}}')
    roundtrip('{1: 1, **{2: 2, 3: 3}, 4: 4}')

# Generated at 2022-06-12 03:33:28.547821
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    code = '''\
{1: 1, None: 2}
'''
    res = '''\
_py_backwards_merge_dicts([{1: 1}], 2)
'''
    tree = astor.parse_file(StringIO(code))
    tree = DictUnpackingTransformer().visit(tree)  # type: ignore
    assert astor.to_source(tree) == res

    code = '''\
{None: 1, 2: 2, None: 3}
'''
    res = '''\
_py_backwards_merge_dicts([{}, {2: 2}], 3)
'''
    tree = astor.parse_file(StringIO(code))
    tree = DictUnpackingTransformer().visit(tree)  # type:

# Generated at 2022-06-12 03:33:38.321561
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse, dump
    from ..transformers import NoSpaceTransformer, TransformerPipeline
    from ..utils.comment_remover import CommentRemover
    from ..utils.no_space_ast_printer import NoSpaceAstPrinter
    from ..utils.tree import children
    from funcy import compact

    # Expects

# Generated at 2022-06-12 03:33:47.149187
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """TODO: Add test."""
    dict_a = {'a': 1, 'b': 2}
    dict_b = {'c': 3, 'd': 4}
    node = ast.parse("""
    {'start': 1, **dict_a, 'middle': 2, **dict_b, 'end': 3}
    """)
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(node)
    expected = ast.parse("""
    _py_backwards_merge_dicts([{'start': 1}, dict_a, {'end': 3}, dict_b])
    """)
    assert ast.dump(transformed) == ast.dump(expected)

# Generated at 2022-06-12 03:33:57.371501
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import tree

    def test(input_: str, output: str):
        node = tree(input_)
        node_transformed = DictUnpackingTransformer().visit(node)
        tree_transformed = tree(None, node=node_transformed)
        assert output == tree_transformed

    test('{"a": 1, **{"b":2}, 3: 3}',
         '_py_backwards_merge_dicts([dict(a=1), {3:3}], {"b":2})')

    test('{"a": 1, **{"b":2}}',
         '_py_backwards_merge_dicts([dict(a=1)], {"b":2})')


# Generated at 2022-06-12 03:34:08.041822
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class TestMethods(unittest.TestCase):
        def test_merge_dicts(self):
            DictUnpackingTransformer._merge_dicts_executed = False

            @snippet
            def test_merge_dicts():
                DictUnpackingTransformer._merge_dicts_executed = True
                assert _py_backwards_merge_dicts([dict_a, dict_b]) == {
                    **dict_a, **dict_b}

# Generated at 2022-06-12 03:34:12.702800
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import get_node

    node = get_node(
        """
        {
            "a": 1,
            **dict_a,
            "b": 2,
            **dict_b,
            "c": 3,
        }
        """
    )
    trans = DictUnpackingTransformer()
    assert repr(node) == repr(trans.visit(node))

# Generated at 2022-06-12 03:34:17.085108
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .functional_tests.utils import do_test
    code_before = """
    {1: 1, **dict_a, **dict_b, 2: 2, **dict_c}
    """
    result = do_test(code_before, DictUnpackingTransformer)

# Generated at 2022-06-12 03:34:27.246584
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class TestTransformer(DictUnpackingTransformer):
        def __init__(self, tree: ast.AST):
            self._tree = tree

        def visit(self, node):
            return self._visit(node)


# Generated at 2022-06-12 03:35:21.322216
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astor.codegen import to_source
    from .transformer import Transformer


# Generated at 2022-06-12 03:35:27.328971
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astor.source_repr import source_repr

    source = '''
{1: 1, **dict_a}
'''

    expected = '''
_py_backwards_merge_dicts([{1: 1}], dict_a)
'''

    etalon = ast.dump(ast.parse(expected))
    tree = DictUnpackingTransformer().visit(ast.parse(source))
    assert etalon == ast.dump(tree)
    assert source_repr(tree) == expected



# Generated at 2022-06-12 03:35:33.647318
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.fixtures import (
        test_DictUnpackingTransformer_visit_Dict_initial,
        test_DictUnpackingTransformer_visit_Dict_target
    )
    from ..utils.visitor import compare_ast
    assert compare_ast(
        test_DictUnpackingTransformer_visit_Dict_initial,
        test_DictUnpackingTransformer_visit_Dict_target,
        DictUnpackingTransformer
    )

# Generated at 2022-06-12 03:35:44.609577
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal


# Generated at 2022-06-12 03:35:49.391633
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import ast_tester
    
    code = """
    {1: 1, **dict_a}
    """
    
    expected_code = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    
    ast_tester.run_code_for_module(
        code, expected_code, DictUnpackingTransformer, {})

# Generated at 2022-06-12 03:35:59.285372
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor


# Generated at 2022-06-12 03:36:05.209258
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{None: a, 1: 2, None: b, 3: 4}')
    DictUnpackingTransformer().visit(node)

    expected = ast.parse('''
_py_backwards_merge_dicts([
    dict(None),
    {1: 2},
    dict(b),
    {3: 4}
])
''').body[0]
    assert expected == node.body[0]

# Generated at 2022-06-12 03:36:09.092395
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    expr = ast.parse('{1: 1, **dict_a, 2: 2}')
    assert DictUnpackingTransformer().visit(expr) == ast.parse('_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)')

# Generated at 2022-06-12 03:36:19.775073
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pairs = [(None, ast.Call(func=ast.Num(1), args=[], keywords=[])),
             (None, ast.Call(func=ast.Num(2), args=[], keywords=[])),
             (ast.Name(id='a', ctx=ast.Load()),
              ast.Call(func=ast.Num(3), args=[], keywords=[])),
             (None, ast.Call(func=ast.Num(4), args=[], keywords=[]))]
    keys = [key for key, _ in pairs]
    values = [value for _, value in pairs]
    node = ast.Dict(keys=keys, values=values)
    
    node = DictUnpackingTransformer().visit(node)
    assert isinstance(node, ast.Call)

# Generated at 2022-06-12 03:36:26.101967
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.transformer import run_on_string
    
    code = '''
        {1: 2, **'a', **{}, **b}
    '''
    
    expected_code_no_side_effects = '''
        dict(1, 2)
    '''
    
    expected_code_with_side_effects = '''
        _py_backwards_merge_dicts(
            [{1: 2}], 'a', {}, b
        )
    '''
    
    assert run_on_string(code, DictUnpackingTransformer) == expected_code_no_side_effects
    assert run_on_string(code, DictUnpackingTransformer, side_effects=True) == expected_code_with_side_effects

# Generated at 2022-06-12 03:37:53.164147
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tests = {
        '{1: 1, **dict_a}': '_py_backwards_merge_dicts([{1: 1}], dict_a)',
        '{**dict_a}': 'dict_a',
        '{1: 1, "2": 2}': '{1: 1, "2": 2}',
        '{1: 1, **dict_a, 2: 2, "3": 3, **dict_b}':
            '_py_backwards_merge_dicts([{1: 1, 2: 2, "3": 3}], dict_a, dict_b)',
    }

    for test, expected in tests.items():
        node = ast.parse(test)
        DictUnpackingTransformer().visit(node)
        result = ast.unparse(node)

# Generated at 2022-06-12 03:37:58.749929
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    f = compile('{1: 1, **dict_a}', '<test>', 'exec',
                flags=ast.PyCF_ONLY_AST)   # type: ast.AST
    assert isinstance(f, ast.Module)
    transformer = DictUnpackingTransformer()
    f_ = transformer.visit(f)  # type: ignore
    assert isinstance(f_, ast.Module)



# Generated at 2022-06-12 03:38:08.240991
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from decimal import Decimal

    source = """
    {
        1: [
            2, 3
        ],
        **a,
        4: 5,
        6: [
            7, 8
        ],
        **b,
        9: {10: 11},
        **c,
        'a': Decimal('1.0')
    }
    """
    import typing
    import ast as _ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast27 as typed_ast27


# Generated at 2022-06-12 03:38:16.127248
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import Source

    source = Source("""
        {1: 1, **dict_a}
    """)
    module = source.parse_module()
    transformer = DictUnpackingTransformer(module)
    transformer.visit(module)
    expected = Source("""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)
    assert transformer._tree_changed
    assert str(module) == str(expected)

# Generated at 2022-06-12 03:38:16.937045
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-12 03:38:18.784727
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    node = ast.Module()
    t = DictUnpackingTransformer()
    t.visit(node)
    assert isinstance(node, ast.Module)

# Generated at 2022-06-12 03:38:24.015417
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '{1: 1, **dict_a}'
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)


# Generated at 2022-06-12 03:38:28.131018
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from unittest.mock import patch
    from typing import Callable
    NodeTransformer = Callable[[ast.AST], ast.AST]
    class_name = 'pyson.transform.DictUnpackingTransformer'
    with patch(f'{class_name}.merge_dicts', merge_dicts):
        instance = DictUnpackingTransformer()
        assert isinstance(instance, NodeTransformer)

# Generated at 2022-06-12 03:38:37.316190
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_base import transform
    code1 = '''{1: 2, *[(3, 4)], 5: 6}'''
    res1 = '''
{1: 2, 5: 6}
_py_backwards_merge_dicts([{1: 2, 5: 6}], [{3: 4}])
'''
    assert transform(DictUnpackingTransformer, code1) == res1

    code2 = '''{1: 2, *[(3, 4)], *{5: 6}, *[7]}'''
    res2 = '''
{1: 2}
_py_backwards_merge_dicts([{1: 2}], [{3: 4}], {5: 6}, [7])
'''
    assert transform(DictUnpackingTransformer, code2)

# Generated at 2022-06-12 03:38:43.156150
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .utils import unit_test

    input = """
    {1: 2, **a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    
    _py_backwards_merge_dicts([{1: 2}], a)
    """
    unit_test(input, expected, DictUnpackingTransformer)
