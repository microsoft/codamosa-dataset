

# Generated at 2022-06-12 03:29:04.853846
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class FakeUnparser(ast.NodeVisitor):
        def __init__(self) -> None:
            self._code = ''

        def visit_Dict(self, node: ast.Dict) -> None:
            self._code += '{'
            for key, val in zip(node.keys, node.values):
                if key is not None:
                    self.visit(key)
                    self._code += ':'
                self.visit(val)
                self._code += ','
            self._code += '}'

        def visit_Call(self, node: ast.Call) -> None:
            self._code += '_py_backwards_merge_dicts([{'
            for sub in node.args[0].elts:
                self.visit(sub)
                self._code += ','


# Generated at 2022-06-12 03:29:09.945569
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import get_cases

    cases = get_cases(__file__, 'visit_Dict', 'pyi')
    for case in cases:
        with case.as_output() as output:
            node = DictUnpackingTransformer.run_on_node(case.input)
            if case.has_output():
                assert node == output
            else:
                assert node != case.input

# Generated at 2022-06-12 03:29:19.834373
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    from .utils import transform, dump

    source = '''
    {1: 1, **a, 2: 2, **b}
    '''
    expected = '''
    # BEGIN MERGE_DICTS
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    # END MERGE_DICTS
    
    _py_backwards_merge_dicts([dict({1: 1}), a, dict({2: 2})], b)
    '''
    tree = ast3.parse(source)
    tree = transform(tree, DictUnpackingTransformer)
    assert dump(tree) == expected



# Generated at 2022-06-12 03:29:30.304969
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_base import run_test
    from .test_base import assert_tree_unchanged, assert_tree_changed
    from textwrap import dedent

    source = dedent('''
    {1: 1, **dict_a}
    ''')
    expected = dedent('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    assert_tree_changed(expected, source, DictUnpackingTransformer)


# Generated at 2022-06-12 03:29:39.461728
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from .base import BaseNodeTransformer, get_all_subclasses


# Generated at 2022-06-12 03:29:47.704602
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_structure_equal
    from ..utils.test_utils import generate_source
    from ..utils.test_utils import generate_ast
    from ..utils.test_utils import replace_body
    from ..utils.source_snippet import wrap_in_Module

    example1 = """{1: 1, **{3: 3, **{4: 4}}, **{5: 5, **{6: 6}}}"""

# Generated at 2022-06-12 03:29:58.912543
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Case one
    expr = ast.parse('{1:1}').body[0]  # type: ignore
    assert DictUnpackingTransformer().visit(expr) == expr  # type: ignore
    # Case two
    expr = ast.parse('{1:1, **d}').body[0]  # type: ignore
    assert DictUnpackingTransformer().visit(expr) == \
        ast.parse('_py_backwards_merge_dicts([{1:1}], d)')  # type: ignore
    # Case three
    expr = ast.parse('{1:1, **d, **f, 2:2}').body[0]  # type: ignore

# Generated at 2022-06-12 03:30:08.602144
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:30:16.923725
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()
    code = '{1: 1, **{}, 2: 2, **{}}'
    node = ast.parse(code, mode='eval').body  # type: ignore
    t.visit(node)

    func_name = '_py_backwards_merge_dicts'
    expected = '{func_name}([{{1: 1}}, {}, {{2: 2}}, {}])'.format(
        func_name=func_name, **{str(i): {} for i in range(2)})
    result = astor.to_source(node)
    assert result == expected



# Generated at 2022-06-12 03:30:25.203816
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import round_trip
    code = '''\
        foo({1: 1, 2: 2, **{3: 4, 5: 6}, 7: 8, **{9: 10}})
    '''
    expected = '''\
        foo(
          _py_backwards_merge_dicts(
            [dict({1: 1, 2: 2}), {3: 4, 5: 6}, dict({7: 8})], {9: 10})
        )
    '''
    tree = round_trip(code, DictUnpackingTransformer)
    assert expected == tree.body[0].value.func.value.func.id

# Generated at 2022-06-12 03:30:31.937786
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.tree import dump
    print(dump(DictUnpackingTransformer().visit(merge_dicts.get_ast())))

# Generated at 2022-06-12 03:30:42.046515
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    dict_unpacking_transformer = DictUnpackingTransformer()
    ast_module = ast.parse(textwrap.dedent(
        """
        {1: 1, **dict_a, 2: 2}
        """
    ), '<test>', 'eval')
    dict_unpacking_transformer.visit(ast_module)
    assert astor.to_source(dict_unpacking_transformer.tree) == textwrap.dedent(
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}, dict_a], {2: 2})
        """
    )

# Generated at 2022-06-12 03:30:49.922606
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast.ast3 import parse

    plain_module = '''
    def f():
        return 1 + 1
    '''
    plain_module = parse(plain_module)

    unpacking_module = '''
    def f():
        return {'a': 10, **other_dict, 'b': 20}
    '''
    unpacking_module = parse(unpacking_module)

    assert DictUnpackingTransformer().visit(plain_module) == plain_module
    assert DictUnpackingTransformer().visit(unpacking_module) != unpacking_module


# Generated at 2022-06-12 03:30:59.842650
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .cst_to_ast import cst_to_ast
    from .test_BaseNodeTransformer import patch_module

    cst = """
        {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


        _py_backwards_merge_dicts([dict({1: 1}), dict_a])
    """

    tree = patch_module(cst_to_ast(cst))
    tree = DictUnpackingTransformer().visit(tree)  # type: ignore

# Generated at 2022-06-12 03:31:04.187241
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = """
{1: 1, **dict_a}
"""
    tree = ast.parse(src)

    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed


# Generated at 2022-06-12 03:31:10.214633
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class Visitor:
        def __init__(self):
            self.nodes = []

        def visit(self, node):
            self.nodes.append(node)
            self.generic_visit(node)

    visitor = Visitor()
    node = ast.parse(merge_dicts.get_source())
    DictUnpackingTransformer().visit(node)
    visitor.visit = Visitor.visit.__get__(visitor)
    ast.walk(node, visitor)
    assert len(visitor.nodes) == 2



# Generated at 2022-06-12 03:31:11.224772
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:31:21.616587
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from unittest.mock import Mock
    node = Mock()
    node.body = []
    module = DictUnpackingTransformer().visit_Module(node)
    from .check_ast import (
        check_ast as ca,
        make_call,
        make_name,
        make_lambda,
        make_list,
        is_ast_node
    )
    assert module.body[0] == ca(
        value=make_call(
            func=make_name(id='_py_backwards_merge_dicts'),
            args=[make_list(elts=[make_dict(keys=[], values=[])])],
            keywords=[]),
        expected_type=ast.Call
    )

# Generated at 2022-06-12 03:31:31.465649
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    
    # Setup
    classes = locals()
    ast_tree = ast.parse('{1:1, **dict_a}')
    for node in ast.walk(ast_tree):
        for key, value in list(node._attributes.items()):
            if isinstance(value, list):
                setattr(node, key, [])
    
    
    
    # Run test
    DictUnpackingTransformer(classes).visit(ast_tree)
    
    # Asserting result

# Generated at 2022-06-12 03:31:42.399151
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    x = ast.parse("{1: 1, 'a': 1, 2: None, **dict1, 'b': 1, **dict2}")
    DictUnpackingTransformer().visit(x)

# Generated at 2022-06-12 03:31:59.868373
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .expr_transformer import ExprTransformer
    from ..utils.tree import build

    d = """
        {
            'a': 1,
            **{'b': 2},
            'c': 3,
            **{'d': 4},
            'e': 5,
        }
    """
    d = build(d)
    d = ExprTransformer().visit(d)
    assert d == '_py_backwards_merge_dicts([' \
                '{"a": 1}, {"c": 3}, {"e": 5},' \
                '{"b": 2}, {"d": 4}])'

# Generated at 2022-06-12 03:32:08.234587
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from io import StringIO
    from ..codegen import to_source
    
    # {**dict_a, **dict_b}
    simple_dict = ast.Dict(keys=[None, None],
                           values=[ast.Name(id='dict_a'),
                                   ast.Name(id='dict_b')])
    simple_dict_transformed = DictUnpackingTransformer().visit(simple_dict)
    assert astor.to_source(simple_dict_transformed) == \
        "_py_backwards_merge_dicts([], dict_a, dict_b)"
    
    # {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}

# Generated at 2022-06-12 03:32:17.346631
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def _test_simple(source: str, expected: str) -> None:
        actual = ast.parse(source)
        DictUnpackingTransformer().visit(actual)
        assert_equal(ast.dump(actual), expected)

    # Dict without unpacking
    _test_simple(
        source="""
        {1: 1}
        """,
        expected="""Module(body=[Dict(keys=[Num(n=1)], values=[Num(n=1)])])""")

    # Dict with unpacking

# Generated at 2022-06-12 03:32:19.721687
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:32:28.240606
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test dict unpacking."""
    pyversion = (3, 4)
    code = '{1: 1, **dict_a}'
    expected_code = '''from typed_ast import ast3 as ast
_py_backwards_merge_dicts([{1: 1}], dict_a)
'''
    module, _ = get_ast(pyversion, code, __file__)
    node_transformer = DictUnpackingTransformer(pyversion)
    new_module = node_transformer.visit(module)
    assert compare_ast(new_module, expected_code)



# Generated at 2022-06-12 03:32:38.424938
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    a = ast.parse("{1: 1, 2: 2, 3: 3}")
    b = ast.parse("{1: 1, **{2: 2, 3: 3}}")
    assert isinstance(a.body[0], ast.Expr)
    assert isinstance(b.body[0], ast.Expr)
    assert a.body[0].value == b.body[0].value

    a = ast.parse("{1: 1, 2: 2, **{3: 3}}")
    b = ast.parse("{1: 1, **{2: 2, 3: 3}}")

    assert isinstance(a.body[0], ast.Expr)
    assert isinstance(b.body[0], ast.Expr)
    assert a.body[0].value == b.body[0].value

   

# Generated at 2022-06-12 03:32:46.477427
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    xs = [
        ast.parse('{1: 1, **dict_a}').body[0],
        ast.parse('{1: 1, 2: 2, **dict_a}').body[0],
        ast.parse('{**dict_a}').body[0],
        ast.parse('{1: 1, **{**dict_a}}').body[0],
    ]
    for x in xs:
        assert DictUnpackingTransformer().visit(x) == ast.parse(
            '_py_backwards_merge_dicts([{1: 1}], dict_a)').body[0]

# Generated at 2022-06-12 03:32:54.364239
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.ast_helpers import ast_cmp
    cmp = lambda x, y: ast_cmp(ast.parse(x), ast.parse(y))
    cmp('{}', 'dict()')
    cmp('{1: 1}', '{1: 1}')
    cmp('{1: 1, **dict_a}', '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    cmp('{1: 1, **dict_a, 2: 2}', '_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)')

# Generated at 2022-06-12 03:33:04.082449
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import DictComp, Dict
    from typed_ast.ast3 import Str, Name, Store
    from ..transformer.unpacking import DictUnpackingTransformer

    transformer = DictUnpackingTransformer()
    dict_a = Name(id='dict_a', ctx=Store(), annotation=None)
    dict_b = Name(id='dict_b', ctx=Store(), annotation=None)
    dict_c = Name(id='dict_c', ctx=Store(), annotation=None)
    dict_ = Dict(keys=[None, None, Str(s='b')],
                 values=[dict_a, dict_b, Str(s='2')])

# Generated at 2022-06-12 03:33:09.230494
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1}')
    DictUnpackingTransformer().visit(module)
    assert len(module.body) == 2
    assert isinstance(module.body[0], ast.Expr)
    assert isinstance(module.body[1], ast.Expr)
    assert isinstance(module.body[1].value, ast.Dict)
    assert len(module.body[1].value.values) == 1
    assert len(module.body[1].value.keys) == 1


# Generated at 2022-06-12 03:33:37.444959
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_astunparse import unparse
    from .transformer import transform_code
    from astunparse import unparse as unparse_py2

    src = '''
        def foo():
            return {
                **{}.update({'a': 1}),
                **{1: 2, 'b': 3}.update(),
                **{4: 5},
                **{},
                **{'c': 6}
            }
        '''
    expected = '''
        def foo():
            return {}
        '''.format(unparse(transform_code(src)).strip())
    if sys.version_info >= (3, 8):
        expected = expected.replace('(', '[')
        expected = expected.replace(')', ']')

# Generated at 2022-06-12 03:33:47.396716
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.ast_test import ast_test

    @ast_test
    def test():
        x, y = ({1: 1, 2: 2, 3: 3}, {4: 4, 5: 5})
        # Should be compiled to:
        #   x, y = _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], {4: 4, 5: 5})
        return x, y

    with test:
        code = '''
            x, y = ({1: 1, 2: 2, 3: 3}, {4: 4, 5: 5})
        '''
        assert test.get_ast(code).body[0].value.left.keys == [None, ast.Num(2), ast.Num(3)]

# Generated at 2022-06-12 03:33:51.241772
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    assert str(ast.dump(merge_dicts.get_body())) == str(ast.dump(t.visit_Module(ast.Module([merge_dicts.get_body()]))))


# Generated at 2022-06-12 03:33:57.869131
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse(textwrap.dedent("""
        {1: 1, **dict_a}
        """))
    print(node)
    expected = ast.parse(textwrap.dedent("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """))
    print(expected)
    transformed = DictUnpackingTransformer().visit(node)
    print(transformed)
    assert transformed == expected


# Generated at 2022-06-12 03:34:03.403146
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    merge_dicts_code = merge_dicts.get_body()
    tree = ast.parse('1', '<test>')
    tree = DictUnpackingTransformer().visit(tree)
    import_str = 'import _py_backwards_merge_dicts\n'
    assert astor.to_source(tree).strip() == import_str + merge_dicts_code


# Generated at 2022-06-12 03:34:10.237300
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1:1,2:2,**d}')
    transformer = DictUnpackingTransformer()
    module = transformer.visit(module)
    assert module.body[0].col_offset == 0
    assert module.body[1].col_offset == 0
    assert module.body[2].col_offset == 0
    assert module.body[3].col_offset == 0
    assert module.body[4].col_offset == 0
    assert module.body[5].col_offset == 0

# Generated at 2022-06-12 03:34:18.899751
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTestCase

    source = """
    def foo(dict_a, dict_b):
        dict_a = {**dict_a}
    """

    expected = """
    def foo(dict_a, dict_b):
        dict_a = _py_backwards_merge_dicts([], dict_a)
    """

    class Test(BaseNodeTransformerTestCase):
        @property
        def transformer_class(self):
            return DictUnpackingTransformer

    Test.check(source, expected)
    Test.check(source, expected, target=3)
    Test.check(source, expected, target=3.0)



# Generated at 2022-06-12 03:34:22.348348
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import py2030.utils.ast_converter
    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, **dict_a}')

# Generated at 2022-06-12 03:34:23.332808
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass


# Generated at 2022-06-12 03:34:33.342863
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:35:23.183047
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Given
    unpacking_transformer = DictUnpackingTransformer()
    simple_module = ast.parse('''
a = {1: 1}
b = {2: 2}
c = {3: 3, **a, **b}
''')

    # When
    transformed_module = unpacking_transformer.visit(simple_module)

    # Then
    assert ast.dump(transformed_module) == ast.dump('''
_py_backwards_merge_dicts = _py_backwards_merge_dicts

a = {1: 1}
b = {2: 2}
c = _py_backwards_merge_dicts([{3: 3}, a, b])
''')



# Generated at 2022-06-12 03:35:31.851673
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from typed_ast import ast3
    from .transformer import _ast_to_ast_node

    module_node = ast3.parse('{1: 1, 2: 2, 3: 3, **x}')
    old_dict_node = module_node.body[0].value

    new_node = DictUnpackingTransformer().visit(old_dict_node)

    assert isinstance(new_node, ast3.Call)
    assert astor.to_source(new_node) == \
        '_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], x)'

    assert isinstance(_ast_to_ast_node(new_node), astor.Code)

# Generated at 2022-06-12 03:35:39.227223
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}"""
    expected = """_py_backwards_merge_dicts([dict(1, 1), dict_a, dict(2, 2), dict_b, dict(3, 3)])"""
    node = ast.parse(source)
    new_node = DictUnpackingTransformer().visit(node)
    actual = ast.unparse(new_node).strip()
    assert actual == expected



# Generated at 2022-06-12 03:35:44.424181
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_transformer import transform_in_place
    from typed_ast import parse

    tree = parse("""\
        {1: 2, 3: 4, **other, None: 5}
        """)
    transform_in_place(tree, DictUnpackingTransformer)

# Generated at 2022-06-12 03:35:45.358564
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-12 03:35:47.887682
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from typed_ast import ast3 as ast
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)
    assert isinstance(DictUnpackingTransformer(), ast.NodeTransformer)


# Generated at 2022-06-12 03:35:57.745592
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typing
    import astunparse
    import textwrap
    
    @snippet
    def source_code():
        def example(x, y):
            return {1: 1, **x, 2: 2, **y}
    
    @snippet
    def expected_code():
        def example(x, y):
            return _py_backwards_merge_dicts([{1: 1}, {2: 2}], x, y)
    
    source_code = source_code.get_body()
    expected_code = expected_code.get_body()
    module_node = ast.parse(source_code)
    DictUnpackingTransformer().visit(module_node)
    result_code = astunparse.unparse(module_node)
    assert result_code == textwrap.dedent

# Generated at 2022-06-12 03:36:03.512204
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import assert_matches_source
    from .base import BaseNodeTransformer_UnitTestCase

    class DictUnpackingTransformer_UnitTestCase(BaseNodeTransformer_UnitTestCase):
        @property
        def transformer_class(self):
            return DictUnpackingTransformer

    DictUnpackingTransformer_UnitTestCase.run_tests('test_DictUnpackingTransformer.py', globals())

# Generated at 2022-06-12 03:36:14.033595
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_same_ast
    from .annotations import AnnotatingVisitor
    from .discover_callables import DiscoverCallablesTransformer

    source = '''
    {1: 1, **{2: 2}}
    '''

    expected = '''
    _py_backwards_merge_dicts([{1: 1}, {2: 2}])
    '''

    tree = ast.parse(source)
    tree = DiscoverCallablesTransformer().visit(tree)  # type: ignore
    tree = AnnotatingVisitor().visit(tree)  # type: ignore
    tree = DictUnpackingTransformer().visit(tree)  # type: ignore

    assert_same_ast(tree, expected)



# Generated at 2022-06-12 03:36:23.469331
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""
    a = 1
    b = 2
    c = 3
    """)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(module)
    assert len(result.body) == 5
    assert isinstance(result.body[0], ast.Expr)
    assert isinstance(result.body[0].value, ast.Call)
    assert result.body[0].value.func.id == '_py_backwards_merge_dicts'
    assert isinstance(result.body[1], ast.Assign)
    assert isinstance(result.body[2], ast.Assign)
    assert isinstance(result.body[3], ast.Assign)
    assert isinstance(result.body[4], ast.Assign)


# Generated at 2022-06-12 03:36:57.327516
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Unit tests for visit_Dict

# Generated at 2022-06-12 03:37:07.112038
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.mock import MockNodeTransformer
    from ..utils.source import source

    # General test
    node = ast.parse(
        source("""
            {1: 1, 2: 2, **{"a": "b"}}
            """)
    )
    transformer = MockNodeTransformer(DictUnpackingTransformer())
    result = transformer.visit(node)
    assert transformer.tree_changed
    assert transformer.visited == {'Dict'}
    assert result == ast.parse(
        source("""
            _py_backwards_merge_dicts([{1: 1, 2: 2}], {"a": "b"})
            """)
    ).body[0]

    # Test without unpacking

# Generated at 2022-06-12 03:37:13.227201
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    node = tree.body[0].value
    assert isinstance(node, ast.Dict)
    trans = DictUnpackingTransformer()
    new_node = trans.visit(tree)
    assert_source_equal(expected, new_node)

# Generated at 2022-06-12 03:37:18.316785
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code1 = '''{None: [None]}'''
    code2 = '''{None: [{None: [None]}]}'''
    expected = '''_py_backwards_merge_dicts([], {None: [{None: [None]}]})'''
    assert DictUnpackingTransformer().visit(code1) == '{}'
    assert DictUnpackingTransformer().visit(code2) == expected


# Generated at 2022-06-12 03:37:27.833621
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    transformer = DictUnpackingTransformer()
    tree = source("""
        {1: 2}
        {1: 2, **{3}}
        {1: 2, **dict_a, 2: 3, **dict_b, 4: 5, **dict_c}
        {1: 2, **dict_a, **{2: 3}}
    """)
    transformer.visit(tree)

    func_name = '_py_backwards_merge_dicts'

# Generated at 2022-06-12 03:37:37.081781
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_transformed_ast

# Generated at 2022-06-12 03:37:46.442835
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_converter.utils.testing import compile_src, ast_to_src
    from typed_converter.parser.parser import parser

    for src in (
            '{1, 2, 3, **a, **b}',
            '{1: 2, **a, **b}',
            '{1: 2, 2: 3, **a, **b}',
            '{1: 2, 2: 3, 3: 4, **a}',
            '{None: a, None: b, **c}',
            '{None: 1, None: 2, **a, **b}',
            '{**a}',
            '{1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7, None: a, None: b, **c}'):
        expected

# Generated at 2022-06-12 03:37:47.230318
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-12 03:37:48.684753
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # type: () -> None
    assert DictUnpackingTransformer().__class__ == DictUnpackingTransformer

# Generated at 2022-06-12 03:37:49.530514
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()
