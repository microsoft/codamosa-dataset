

# Generated at 2022-06-12 03:29:06.745504
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Empty dicts are not changed
    class Empty(ast.Dict):
        pass

    assert not DictUnpackingTransformer.visit_Dict(Empty())

    # Dicts without unpacking are not changed
    class Dict(ast.Dict):
        keys = [ast.Num(1), ast.Num(2)]
        values = [ast.Num(1), ast.Num(2)]

    assert not DictUnpackingTransformer.visit_Dict(Dict())

    # Dicts with unpacking are changed
    class DictWithUnpacking(ast.Dict):
        keys = [None, ast.Num(1)]
        values = [ast.Dict(), ast.Num(1)]


# Generated at 2022-06-12 03:29:16.451257
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..run import compile_func
    pairs = [(ast.Num(n=1), ast.Num(n=1)),
             (None, ast.Call(ast.Name(id='dict_a'), [])),
             (ast.Num(n=2), ast.Num(n=2)),
             (ast.Name(id='a'), ast.Name(id='b')),
             (None, ast.Call(ast.Name(id='dict_a1'), [])),
             (None, ast.Call(ast.Name(id='dict_a2'), [])),
             (ast.Constant(value=1),
              ast.List(elts=[ast.Constant(value=1), ast.Name(id='b')]))]

# Generated at 2022-06-12 03:29:17.516736
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    ...



# Generated at 2022-06-12 03:29:22.066133
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import node_to_str

    node = ast.parse('{1: 2, 3: 4, **dict_a}', '<string>', 'eval')
    node = DictUnpackingTransformer().visit(node)  # type: ignore
    assert node_to_str(node) == '_py_backwards_merge_dicts([{1: 2, 3: 4}], dict_a)'

# Generated at 2022-06-12 03:29:31.249219
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_equal_code

    orig_code = """{
    1: 1,
    **{2: 2},
    **{3: 3},
    **{4: 4},
    **{5: 5},
    **{},
    **{6: 6}
    }
    """
    expected_code = """_py_backwards_merge_dicts([
        {1: 1, 2: 2},
        {3: 3, 4: 4},
        {5: 5},
        dict(),
        {6: 6}
        ])
    """
    assert_equal_code(DictUnpackingTransformer, orig_code, expected_code)

# Generated at 2022-06-12 03:29:40.452826
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse  # type: ignore
    from ..utils.tree_compare import tree_compare
    from ..utils.function import get_function_code

    def test_split_by_None(method):
        def test(pairs, expected):
            d = DictUnpackingTransformer()
            d._tree_changed = False
            result = method(d, pairs)
            assert d._tree_changed is True
            assert tree_compare(result, expected)

        test([(ast.Str('a'), ast.Str('b'))], [{'a': 'b'}])
        test([(ast.Str('a'), ast.Str('b')), (None, ast.Num(1))],
             [{'a': 'b'}, 1])

# Generated at 2022-06-12 03:29:48.291032
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()

# Generated at 2022-06-12 03:29:59.272247
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ast import literal_eval as eval
    from .base import BaseNodeTransformer

    class DictUnpackingTransformerTest(DictUnpackingTransformer):
        """
        Test version of DictUnpackingTransformer
        """
        def __init__(self, test_data: dict):
            """
            :param test_data: dict, where keys are original dicts and values are
                expected results
            """
            self._tree_changed = False
            self._test_data = test_data

        def visit_Dict(self, node: ast.Dict) -> ast.Call:
            if node in self._test_data:
                return self.generic_visit(self._test_data[node])
            assert False


# Generated at 2022-06-12 03:30:03.041288
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tc = DictUnpackingTransformer()
    node = ast.parse("{}")
    r = tc.visit(node)
    assert isinstance(r, ast.Module)
    assert '_py_backwards_merge_dicts' in str(r)
    assert 'return list(xs)' in str(r)



# Generated at 2022-06-12 03:30:13.489520
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:30:28.274459
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..types import Native
    from ..utils.snippet import code_to_ast
    from .unpacking import UnpackingTransformer

    transformer = UnpackingTransformer()
    transformer.visit = DictUnpackingTransformer(transformer).visit
    code = {1: 1, 'two': Native(2), **{'three': 3}}
    result = transformer.visit(code_to_ast(code))

# Generated at 2022-06-12 03:30:38.632303
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer(None)

    node = ast.parse('{1: 1, 2: 2, **dict_}').body[0]  # type: ast.Expr
    new_node = transformer.visit_Dict(node)

    assert isinstance(new_node, ast.Call)
    assert isinstance(new_node.func, ast.Name)
    assert new_node.func.id == '_py_backwards_merge_dicts'
    assert len(new_node.args) == 1
    assert len(new_node.args[0].elts) == 2
    assert new_node.args[0].elts[0].keys == [ast.Num(n=1), ast.Num(n=2)]
    assert new_node.args[0].elts[0].values

# Generated at 2022-06-12 03:30:45.637613
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.typing import AST_KEYWORD_ARGUMENTS
    from ..utils.tree import parse, serialize

    class Mock(object):
        pass

    mock = Mock()
    mock.value = 3
    options = {
        'DictUnpackingTransformer': True
    }

# Generated at 2022-06-12 03:30:56.699164
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..transformer.visitor import as_source
    from ..utils.source import dedent

    f = dedent("""
        {1: 2, **a}
    """)

    # No change
    expected = dedent("""
        {1: 2, **a}
    """)
    tree = ast.parse(f)
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    transformer = DictUnpackingTransformer()
    new_node = transformer.visit(node)
    assert as_source(new_node) == expected

    # Simple change
    expected = dedent("""
        _py_backwards_merge_dicts([{1: 2}], a)
    """)

# Generated at 2022-06-12 03:31:02.055561
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..unparser import Unparser

    transformer = DictUnpackingTransformer()
    root = ast.parse('''{1: 1, 2: 2, **dict_a, 3: 3, 4: 4, **dict_b}''')
    transformed = transformer.visit(root)

# Generated at 2022-06-12 03:31:06.716105
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_code_equal
    source = """
    my_dict = {1:1, 2:2, 3:3}
    """
    expected = """
    my_dict = {1:1, 2:2, 3:3}
    """

    tr = DictUnpackingTransformer()
    assert_code_equal(tr.visit(ast.parse(source)), expected)


# Generated at 2022-06-12 03:31:16.884510
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from pprint import pprint
    import textwrap

    # Test version for 3.7
    print('test_DictUnpackingTransformer_visit_Dict')

# Generated at 2022-06-12 03:31:22.467745
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from ..utils.source import source_to_ast
    from ..utils.quotation import quote

    ast_source = quote.code.DICT_UNPACKING_TEST
    ast_source = ast_source.strip('\n')
    tree = source_to_ast(ast_source)
    DictUnpackingTransformer().visit(tree)
    result = astunparse.unparse(tree)
    assert ast_source == result

# Generated at 2022-06-12 03:31:29.989956
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .ast_builder import ASTBuilder as astb
    from .visitor import Visitor

    program = """
    {1: 1, 2: 2, **a, 3: 3, **b, 4: 4, **c}
    """

    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], a, b, c)
    """

    visitor = Visitor()
    visitor.visit(astb.string_build(program))

    result = visitor.modified_source.strip()

    assert result == expected

# Generated at 2022-06-12 03:31:38.897626
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert DictUnpackingTransformer({}).visit_Dict(
        ast.Dict(keys=[ast.Num(1)], values=[ast.Name(id='a')])) == \
        ast.Dict(keys=[ast.Num(1)], values=[ast.Name(id='a')])
    assert DictUnpackingTransformer({}).visit_Dict(
        ast.Dict(keys=[ast.Num(1)], values=[ast.Name(id='a')])) == \
        ast.Dict(keys=[ast.Num(1)], values=[ast.Name(id='a')])



# Generated at 2022-06-12 03:31:52.685688
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{1:1, **a, 2:2, **b}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert result == ast.parse(
        '_py_backwards_merge_dicts([{1: 1, 2: 2}], a, b)')

# Generated at 2022-06-12 03:31:59.463963
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    source = """
    a = {1: 1, **b}
    """
    expected = """
    a = _py_backwards_merge_dicts([{1: 1}], b)
    """
    expected_ast = ast.parse(expected)
    source_ast = ast.parse(source)
    DictUnpackingTransformer().visit(source_ast)
    assert ast.dump(expected_ast) == ast.dump(source_ast)

# Generated at 2022-06-12 03:32:08.033885
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class TestCase:
        source = None  # type: Optional[ast.Module]
        expected = None  # type: Optional[ast.Module]
        inplace = None  # type: None

    cases = [TestCase()]
    cases[-1].source = ast.parse("{1: 1, **dict_a}")
    cases[-1].expected = ast.parse(
        '\n'.join((
            "def _py_backwards_merge_dicts(dicts):",
            "    result = {}",
            "    for dict_ in dicts:",
            "        result.update(dict_)",
            "    return result",
            "_py_backwards_merge_dicts([{1: 1}], dict_a)",
            '')))


# Generated at 2022-06-12 03:32:17.210770
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import compile_source
    from ..transform import transform, DictUnpackingTransformer
    code = '''
        def foo():
            return {\n1: '1',\n**dict_a}
    '''

    tree = compile_source(code, 3, 4)
    transform(tree, DictUnpackingTransformer)


# Generated at 2022-06-12 03:32:28.335401
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert DictUnpackingTransformer().visit_Dict(ast.parse('{1: 1, 2: 2}')) \
        == ast.parse('dict({1: 1, 2: 2})')
    assert DictUnpackingTransformer().visit_Dict(ast.parse('{1: 1, **a}')) \
        == ast.parse('_py_backwards_merge_dicts([dict({1: 1})], a)')
    assert DictUnpackingTransformer().visit_Dict(ast.parse('{1: 1, **a, 2: 2}')) \
        == ast.parse('_py_backwards_merge_dicts([dict({1: 1}), a], dict({2: 2}))')

# Generated at 2022-06-12 03:32:38.496106
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Given a dict node
    node = ast.parse("{1: 1, **{1: 2, 2: 2}, 3: 3}").body[0].value
    assert isinstance(node, ast.Dict)

    # When it is transformed
    transformer = DictUnpackingTransformer()
    transformed_node = transformer.visit(node)

    # Then the result is correct

# Generated at 2022-06-12 03:32:43.293814
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("{1: 1, **{'a': 2}}")
    expected = ast.parse("""
        _py_backwards_merge_dicts((
            {1: 1},
            {'a': 2}))
    """)

    result = DictUnpackingTransformer.run(tree)
    assert ast.dump(expected) == ast.dump(result)

# Generated at 2022-06-12 03:32:51.358962
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_helpers import assert_transformation

    transformer = DictUnpackingTransformer()

    assert_transformation(
        transformer,
        DictUnpackingTransformer.__name__,
        '{1: 1, **{2: 2}, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)',
        '{1: 1, 2: 2, **dict_a}',
    )

# Generated at 2022-06-12 03:32:58.399400
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...tests.fixtures import some_function, assert_equal_ast

    method_name = 'visit_Dict'
    node = ast.parse('{1: 1, **dict_a}')
    tree_changed = getattr(DictUnpackingTransformer(),
                           method_name)(node)

    expected = some_function(globals(), locals(),
        """
        def some_function():
            __py_backwards_merge_dicts([{1: 1}], dict_a)
        """)

    assert_equal_ast(expected, node, check_tree_changed=tree_changed)

# Generated at 2022-06-12 03:33:07.261388
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_transform import transform

    assert transform(
        DictUnpackingTransformer,
        """
        D={1:1}
        """) == """
        D={1:1}


        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        """


# Generated at 2022-06-12 03:33:38.709914
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    import ast


# Generated at 2022-06-12 03:33:48.813437
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # given:
    transformer = DictUnpackingTransformer()
    code = """
    {'a': 'b', 1: 2, 3: 4, 5: 6, 'c': 'd', **some_dict}
    """
    # when:
    node = ast.parse(code)
    result = transformer.visit(node)
    # then:
    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.Expr)
    assert isinstance(result.body[0].value, ast.Call)
    assert isinstance(result.body[0].value.func, ast.Name)
    assert result.body[0].value.func.id == '_py_backwards_merge_dicts'  # type: ignore

# Generated at 2022-06-12 03:33:58.681980
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..ast_transformer_testcase import ASTTransformerTestCase
    from ..utils.another_test_utils import assert_source_equal

    # *** BEGIN TESTS ***

    test_cases = [
        # test case:
        # { **{}, 1: 1 }
        (
            'dict(**{}, one=1)',
            '_py_backwards_merge_dicts([dict()], {}).update({one: 1})'
        )
    ]  # type: List[Tuple[str, str]]

    for code, expected in test_cases:
        proc = ASTTransformerTestCase(code, [
            DictUnpackingTransformer], target=(3, 4))
        proc.run()
        assert_source_equal(proc.result, expected)

# Generated at 2022-06-12 03:34:09.243110
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("{1: 1, 'w': 'k', None: 3, **dict_a}")
    tree = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-12 03:34:14.729675
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from . import transform_source
    source = """
{1: 1, **dict_a}
"""

    expected = """
_py_backwards_merge_dicts([{1: 1}], dict_a)
"""
    result = transform_source(DictUnpackingTransformer, source)
    assert astunparse.unparse(result) == expected

if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-12 03:34:15.870237
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass

# Generated at 2022-06-12 03:34:20.291763
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing_utils import assert_equal_ast
    body = ast.parse("a={1:2, **b}")
    optimizer = DictUnpackingTransformer()
    optimizer.visit(body)
    assert_equal_ast(body, opt.backwards_merge_dicts.__doc__.strip())

# Generated at 2022-06-12 03:34:27.341597
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('''
        {1: 1, 2: 2, **dict_a, None: None, **dict_b}
    ''')
    t = DictUnpackingTransformer()
    node = t.visit(node)

    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, {None: None}, dict_b)
    '''
    assert ast.dump(node) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 03:34:29.087457
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    import astunparse

# Generated at 2022-06-12 03:34:37.304139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class NodeVisitor(ast.NodeVisitor):
        def __init__(self):
            self.data = []

        def visit(self, node):
            self.data.append(node)
            super().visit(node)

        def get_data(self):
            return self.data[1:]

    code = """
    from typing import Dict

    a = {1: 2, **{3: 4}}
    b = {1: 2, **{3: 4}, 5: 6, **{7: 8}}
    """

    transformer = DictUnpackingTransformer()
    visitor = NodeVisitor()

    visitor.visit(transformer.visit(ast.parse(code))) # type: ignore
    assert len(visitor.get_data()) == 14


# Generated at 2022-06-12 03:35:29.106610
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from ..utils.testing import assert_ast_eq

    single_el = '{K: 1}'
    multiple_el = '{K: 1, **{2: 3}}'
    multiple_el_two = '{0: 1, 2: 1, **{3: 4, **{5: 6}}}'

    cases = [single_el, multiple_el, multiple_el_two]

    for case in cases:
        ast_ = ast.parse(dedent(case))
        expected = ast.parse(dedent(
            f'{{K: 1, **_py_backwards_merge_dicts([{single_el}], {{2: 3}})}}'))
        actual = DictUnpackingTransformer().visit(ast_)

# Generated at 2022-06-12 03:35:38.446782
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test visitor of `Dict` node."""

    code = ast.parse('''
        {1: 1, **dict_a, 2: 2}
    ''')

    expected = ast.parse('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}])
    ''')

    DictUnpackingTransformer().visit(code)
    assert ast.dump(code) == ast.dump(expected)



# Generated at 2022-06-12 03:35:46.534634
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    stmt = """{1: 1, 2: 2, **dict1}"""
    expected_stmt = "_py_backwards_merge_dicts([{1: 1, 2: 2}], dict1)"
    expected_stmt = astor.to_source(ast.parse(expected_stmt))

    ast_tree = ast.parse(stmt)
    transformed_tree = DictUnpackingTransformer().visit(ast_tree)  # type: ignore
    result_stmt = astor.to_source(transformed_tree)
    assert expected_stmt in result_stmt

# Generated at 2022-06-12 03:35:49.783297
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    import astor
    import astunparse

    # {a: 1, **kwargs} -> _py_backwards_merge_dicts([{a: 1}], kwargs)
    tree = ast.parse("{a: 1, **kwargs}")
    DictUnpackingTransformer().visit(tree)

    # astor -> astunparse for more appropriate output
    print(astor.to_source(tree))
    print(astunparse.unparse(tree))



# Generated at 2022-06-12 03:35:58.122678
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import check_node_transformation

    check_node_transformation(
        """{1: 1, **dict_a}""",
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """,
        DictUnpackingTransformer,
    )
    check_node_transformation(
        """{1: 1, *dict_a, 2: 2, **dict_b}""",
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a, {2: 2}, dict_b)
        """,
        DictUnpackingTransformer,
    )

# Generated at 2022-06-12 03:36:08.524652
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    x = ast.parse('{1: 1, 2: None, 3: 4, **{5: 6}}')
    assert str(DictUnpackingTransformer(x).visit()) == \
        '_py_backwards_merge_dicts([{1: 1, 2: None, 3: 4}], {5: 6})'

    x = ast.parse('{1: 1, 2: None, **{3: 4, 5: 6}}')
    assert str(DictUnpackingTransformer(x).visit()) == \
        '_py_backwards_merge_dicts([{1: 1}], {3: 4, 5: 6})'

    x = ast.parse('{1: 1, 2: None, 3: 4, **{5: 6}, 7: 8}')

# Generated at 2022-06-12 03:36:14.797806
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None
    """Tests method visit_Dict of class DictUnpackingTransformer."""
    body = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a}')
    actual = DictUnpackingTransformer().visit_Module(body)
    assert expected.body == actual.body

# Generated at 2022-06-12 03:36:23.904013
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    dict_unpacking_transformer = DictUnpackingTransformer()

# Generated at 2022-06-12 03:36:32.251203
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast
    from .base import NodeTransformerTest

    class Test(NodeTransformerTest):
        transformer = DictUnpackingTransformer
        method = 'visit_Dict'

        def test_ok(self):
            node = ast.parse('{1: 1, **dict_a}')
            new_node = ast.parse(
                '_py_backwards_merge_dicts([{1: 1}], dict_a)')
            self.check(node, new_node)

    test = Test()
    test.test_ok()



# Generated at 2022-06-12 03:36:40.955525
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import get_node
    from ..utils.tree import dump_tree

    node = get_node("{1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4}")
    transformed = DictUnpackingTransformer.run_on(node)
    expected = get_node("""
    _py_backwards_merge_dicts([
        {1:1, 2:2, 3:3, 4:4},
        dict_a,
        dict_b,
        dict_c
    ])""")
    assert dump_tree(transformed) == dump_tree(expected)