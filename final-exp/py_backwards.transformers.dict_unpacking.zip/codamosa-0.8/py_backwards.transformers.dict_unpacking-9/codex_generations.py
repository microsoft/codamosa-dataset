

# Generated at 2022-06-12 03:29:08.831997
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .code_to_ast import code_to_ast
    from .ast_to_code import ast_to_code
    from .ast_to_python import ast_to_python
    from ..utils.treetools import transform_tree

    source = """
        {1: 2, 3: 4, **x, 5: 6, **y} = 5
    """

    node = code_to_ast(source)
    transformed = transform_tree(node, DictUnpackingTransformer)
    code = ast_to_code(transformed)

    assert code.strip() == """
        _py_backwards_merge_dicts([{1: 2, 3: 4}, x, {5: 6}], y) = 5
    """.strip()
    assert ast_to_python

# Generated at 2022-06-12 03:29:18.931315
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_tree_transformer import \
        TreeTransformationTestCase, all_supported_versions

    class TestCase(TreeTransformationTestCase):
        transformer = DictUnpackingTransformer


# Generated at 2022-06-12 03:29:21.793978
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    print(DictUnpackingTransformer().visit(ast.parse(
        "dict_a = {'a': 1, 'b': 2}\n"
        "{1: 1, **dict_a, 'c': 3}")))

# Generated at 2022-06-12 03:29:30.918596
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = merge_dicts.get_snippet()
    # Visit module without imports
    module = ast.parse(code)
    DictUnpackingTransformer().visit(module)  # type: ignore
    assert ast.dump(module) == ast.dump(ast.parse(code))
    # Visit module which contains imports (and merge_dicts function)
    module = ast.parse(code+'import typing')
    DictUnpackingTransformer().visit(module)  # type: ignore
    assert ast.dump(module, include_attributes=True) == \
           ast.dump(ast.parse(code+'import typing'), include_attributes=True)


# Generated at 2022-06-12 03:29:39.461058
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    x = ast.parse('{1: 2, 3: 4, **{5: 6}}').body[0].value
    transformer = DictUnpackingTransformer()

    # Test expected dict.
    expected = ast.parse(
        '_py_backwards_merge_dicts([{1: 2, 3: 4}], {5: 6})').body[0].value
    assert transformer.visit(x) == expected

    # Test expected dict returned by generic_visit.
    x = ast.parse('{1: 2, 3: 4}').body[0].value
    expected = ast.parse('{1: 2, 3: 4}').body[0].value
    assert transformer.visit(x) == expected

# Generated at 2022-06-12 03:29:47.704756
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast

    x = ast.Dict(keys=[ast.Num(2), ast.Num(1), None, ast.Num(3)], values=[
                 ast.Num(2), ast.Num(1),
                 ast.Dict(keys=[ast.Num(1), ast.Num(2)], values=[ast.Num(1), ast.Num(2)]),
                 ast.Num(3),
    ])
    DictUnpackingTransformer().visit(x)

# Generated at 2022-06-12 03:29:54.019176
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    ast_dict = ast.parse("{1: 1, None: {2: 2}, 3: 3}")
    res = DictUnpackingTransformer().visit(ast_dict)
    expected_dict = ast.parse("_py_backwards_merge_dicts([{1: 1}, {3: 3}], {2: 2})")
    assert ast.dump(res) == ast.dump(expected_dict)

# Generated at 2022-06-12 03:30:03.286158
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1, **dict_a}')
    mod_dict_unpack_trans = DictUnpackingTransformer()
    mod_dict_unpack_trans.visit(module)

# Generated at 2022-06-12 03:30:12.671102
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import textwrap
    from ..parser import cst_to_ast
    from ..utils.ast_format import ast_format
    code = textwrap.dedent('''
    {1: 2, 3: 4, **dict_a}''')
    expected = textwrap.dedent('''
    _py_backwards_merge_dicts([{1: 2, 3: 4}], dict_a)''')
    node = cst_to_ast.parse_module(code)
    assert ast_format(node) == ast_format(expected)
    node = cst_to_ast.parse_module(expected)
    assert ast_format(node) == ast_format(expected)



# Generated at 2022-06-12 03:30:22.822483
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """
    >>> def test():
    ...     return {1: 1, **dict_a}
    >>> print(DictUnpackingTransformer().visit(ast.parse(test.__doc__)))
    def test():
        return _py_backwards_merge_dicts([{1: 1}], dict_a)
    <BLANKLINE>

    >>> def test():
    ...     return {1: 1, **dict_a, **dict_b, 2: 2}
    >>> print(DictUnpackingTransformer().visit(ast.parse(test.__doc__)))
    def test():
        return _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}])
    <BLANKLINE>
    """
    pass

# Generated at 2022-06-12 03:30:37.674274
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import BaseNodeTestCase
    from .base import transform
    class Test(BaseNodeTestCase):
        
        transformer = DictUnpackingTransformer

    Test.test(
        input={'source': '{1: 1, **dict_a}',
               'inputs': [('dict_a', 'dict_a')]},
        expected={'outputs': ['_py_backwards_merge_dicts([{1: 1}], dict_a)']})

# Generated at 2022-06-12 03:30:45.292569
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("""
        def f():
            return {
                1: 1,
                **x,
                2: 2,
                **y,
                3: 3}
    """)  # type: ast.Module
    transformer = DictUnpackingTransformer()
    transformer.visit(node)

    assert transformer.get_tree_changed() is True

# Generated at 2022-06-12 03:30:56.331472
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from _pytest.monkeypatch import MonkeyPatch
    from ..utils.tree import ast_pprint
    from astmonkey import transformers
    

# Generated at 2022-06-12 03:31:02.652098
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('{1: 1, 2: 2, **{3: 3}, 4: 4}')
    expected = ast.parse('''
    _py_backwards_merge_dicts([{1: 1}], {2: 2}, {3: 3}, {4: 4})
    ''')
    transformer = DictUnpackingTransformer()
    assert transformer.visit(tree) == expected
    assert transformer._tree_changed

# Generated at 2022-06-12 03:31:09.723049
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse("{1: 1, **dict_a}")
    transformer = DictUnpackingTransformer()
    result = transformer.visit(module)
    expected = ast.parse("{}\n{}\n{}".format(
        merge_dicts.get_content(),
        "def _py_backwards_merge_dicts(dicts):",
        "    result = {}",
        "    for dict_ in dicts:",
        "        result.update(dict_)",
        "    return result",
        "_py_backwards_merge_dicts([{1: 1}], dict_a)"
    ))
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-12 03:31:20.412166
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import make_test_function_body
    from ..utils.code_gen import to_source
    from ..utils.ast_helpers import get_body_from_module
    def compile(expr: str) -> str:
        old_expr = expr.replace('{', '{key: value,')
        source = make_test_function_body(old_expr)
        tree = ast.parse(source)
        DictUnpackingTransformer().visit(tree)
        return to_source(get_body_from_module(tree)).replace('key: value,', '')

    assert compile('{}') == '{}'
    assert compile('{1:1}') == '{1:1}'

# Generated at 2022-06-12 03:31:23.472952
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..registry import Registry
    Registry.init()
    t = DictUnpackingTransformer()
    t.visit(ast.parse("""
        {1: 2, **a}
    """))
    assert t._tree_changed

# Generated at 2022-06-12 03:31:34.017907
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..ast_utils import parse_ast

    dut = DictUnpackingTransformer()
    tree = parse_ast(
        '{1: 1, **a, 3: 3, **b, 5: 5}')
    result = dut.visit(tree)
    assert isinstance(result, ast.Expression)
    assert isinstance(result.body, ast.Call)
    func = result.body.func
    args = result.body.args
    assert isinstance(func, ast.Name)
    assert func.id == '_py_backwards_merge_dicts'
    assert isinstance(args[0], ast.List)

    list_body = args[0].elts
    assert len(list_body) == 3

# Generated at 2022-06-12 03:31:44.240945
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def assert_correct_transform(before: str, after: str) -> None:
        before_node = ast.parse(before)  # type: ignore
        after_node = ast.parse(after)  # type: ignore
        assert before_node.body[0].__class__ == after_node.body[0].__class__
        transformer = DictUnpackingTransformer()
        got = transformer.visit(before_node)  # type: ignore
        expected = after_node
        assert ast.dump(expected) == ast.dump(got)


    assert_correct_transform(
        """
        {1: 1, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([dict(1=1)], dict_a)
        """)


# Generated at 2022-06-12 03:31:50.505341
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    try:
        from typed_ast import ast3 as ast
    except ImportError:
        import ast

    from compiler.consts import COMPILER_DIR
    from compiler.nodes.factories import create_keyword, create_dict
    from compiler.transformer.dict_unpacking import DictUnpackingTransformer

    node = create_dict([
        create_keyword('hello', 1),
        create_keyword(None, 2),
        create_keyword('world', 3),
    ])

# Generated at 2022-06-12 03:32:00.214770
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def check(code: str, expected: str) -> None:
        node = ast.parse(code)
        expected = ast.parse(expected)

        transformer = DictUnpackingTransformer()
        result = transformer.visit(node)

        assert result == expected

    code = '{1: 1, **dict_a}'

# Generated at 2022-06-12 03:32:07.968916
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3
    module = typed_ast.ast3.parse('{}')
    module = DictUnpackingTransformer().visit(module)
    module = typed_ast.ast3.fix_missing_locations(module)
    expected = (
        'def _py_backwards_merge_dicts(dicts):\n'
        '    result = {}\n'
        '    for dict_ in dicts:\n'
        '        result.update(dict_)\n'
        '    return result\n'
    )
    assert module.body[0].body[0].body[0].s == expected

# Unit test of method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:32:16.937944
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = textwrap.dedent("""\
        {1: 5, 2: 6, **a, 3: 7, **b, 4: 8}
    """)
    expected = textwrap.dedent("""\
        _py_backwards_merge_dicts(_py_backwards_merge_dicts([{1: 5, 2: 6}], a), _py_backwards_merge_dicts([{3: 7}], b), {4: 8})
    """)
    tree = ast.parse(source)  # type: ignore
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    result = ast.fix_missing_locations(result)
    assert ast.dump(result) == expected

# Generated at 2022-06-12 03:32:27.197756
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for method visit_Dict of class DictUnpackingTransformer."""
    from ..utils.source import source
    from ..utils.visitor import NodeCloner

    node = ast.parse(source('''
        {1: 1, **dict_a}
    '''))

    transformer = DictUnpackingTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed  # nosec

    cloner = NodeCloner()
    node = cloner.visit(node)
    assert node is not None
    assert ast.dump(node) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')



# Generated at 2022-06-12 03:32:36.010431
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import run_transformer_for_module
    from ..testing.fixtures import make_module_for_exprs

    module = make_module_for_exprs([
        '{1: 1, **dict_a}',
        '{1: 1, **dict_a, **dict_b}',
        '{1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4, **dict_c}',
        '{**dict_a}'
    ])
    transformed = run_transformer_for_module(
        DictUnpackingTransformer,
        module)

# Generated at 2022-06-12 03:32:42.743881
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.fixtures import make_fake_node, make_fake_subnode, make_subsubnode
    import astor

    class DummyNode(ast.AST):
        _fields = ()
        _attributes = ()

        def accept(self, visitor):
            visitor.visit(self)

    x = DummyNode()
    y = DummyNode()
    z = DummyNode()
    w = DummyNode()


# Generated at 2022-06-12 03:32:45.829931
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''
    {
        1: 1,
        **x,
        2: 2,
        **y,
        3: 3
    }
    '''


# Generated at 2022-06-12 03:32:48.698786
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    node = ast.parse('{1: 1, 2: 2, **{3: 3, 4: 4}}')
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-12 03:32:56.587793
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import assert_equal, assert_not_equal
    from ..testing.tree import node_of

    dut = DictUnpackingTransformer()

    # Test 1: No unpacking
    source = '{1: 2, 3: 4}'
    expected = '{1: 2, 3: 4}'
    node = node_of(source)

    dut.visit(node)
    assert_equal(node_of(expected), node)

    # Test 2: Single unpacking
    source = '{**{"1": 1}}'
    expected = '_py_backwards_merge_dicts([], {"1": 1})'
    node = node_of(source)

    dut.visit(node)
    assert_equal(node_of(expected), node)

    # Test 3: Multiple

# Generated at 2022-06-12 03:33:06.062090
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from py2stubs3.utils.parse import parse, dump

    def assert_equal(s1, s2):
        assert str(parse(s1)) == str(parse(s2))

    assert_equal('{1: 2, **dict_a}',
                 dump(DictUnpackingTransformer().visit(parse('{1: 2, **dict_a}'))))
    assert_equal('x = {1: 2, **dict_a}',
                 dump(DictUnpackingTransformer().visit(parse('x = {1: 2, **dict_a}'))))
    assert_equal('y = x = {1: 2, **dict_a}',
                 dump(DictUnpackingTransformer().visit(parse('y = x = {1: 2, **dict_a}'))))

# Generated at 2022-06-12 03:33:15.649748
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    pass



# Generated at 2022-06-12 03:33:24.356427
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for method visit_Dict of class DictUnpackingTransformer."""
    from ..utils.fixtures import make_fixture, make_fake_ast
    from ..utils.tree import dump
    from ..utils.testing import TestCase

    source_code_fixture = make_fixture(
        path='dict_unpacking_transformer/source_code_fixture/dict_unpacking.py',
        module='dict_unpacking_transformer.source_code_fixture.dict_unpacking')

    expected_ast = make_fake_ast(
        path='dict_unpacking_transformer/expected_ast_fixture/dict_unpacking.py',
        module='dict_unpacking_transformer.expected_ast_fixture.dict_unpacking')


# Generated at 2022-06-12 03:33:30.292594
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import regenerate_grammar_cases, run_transform
    from ..utils.grammar import parse

    # {1: 1, **dict_a}
    test_cases = [
        (
            '{1: 1, **dict_a}',
            '_py_backwards_merge_dicts([{1: 1}], dict_a)'
        ),
    ]
    regenerate_grammar_cases(
        test_cases,
        parse,
        DictUnpackingTransformer,
        extract_tree_representation=lambda node: repr(node),
    )
    run_transform(DictUnpackingTransformer, test_cases)

# Generated at 2022-06-12 03:33:40.896793
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import round_trip, dump

    assert dump(DictUnpackingTransformer().visit(round_trip(ast.Dict(
        keys=[None, ast.Num(n=1)],
        values=[ast.Dict(keys=[ast.Num(n=3)], values=[ast.Num(n=4)]),
                ast.Dict(keys=[ast.Num(n=5)], values=[ast.Num(n=6)])],
    )))) == '<Module []>'


# Generated at 2022-06-12 03:33:47.646504
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import assert_parsed

    assert_parsed(
        """
            from typing import Dict
            def foo(a: Dict[int, int], **b):
                return {1: 1, **a, 2: 2, **b}
        """, '''
            from typing import Dict

            def foo(a: Dict[int, int], **b):
                return _py_backwards_merge_dicts([{1: 1, 2: 2}, a], b)
        '''
    )

# Generated at 2022-06-12 03:33:57.463938
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import textwrap
    from ..utils import ast_equals

    source = textwrap.dedent("""
    def f(a, b=2, c=3):
        d = {1: 1, **a, 2: 2, **b, 3: 3, **c}
    """)

    expected = textwrap.dedent("""
    def f(a, b=2, c=3):
        d = _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], a, b, c)
    """)

    src = ast.parse(source)
    dest = ast.parse(expected)
    actual = DictUnpackingTransformer().visit(src)

    assert ast_equals(dest, actual)

# Generated at 2022-06-12 03:34:08.090257
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equals
    from ..utils.testing import assert_tree_changed

    # Test for if-branch
    with assert_tree_changed(False):
        node = ast.Dict(keys=[ast.Num(n=1), ast.Num(n=2)],
                              values=[ast.Num(n=3), ast.Num(n=4)])
        transformer = DictUnpackingTransformer()
        result = transformer.visit(node)
        assert_node_equals(result,
            ast.Dict(keys=[ast.Num(n=1), ast.Num(n=2)],
                          values=[ast.Num(n=3), ast.Num(n=4)]))

    # Test for else-branch

# Generated at 2022-06-12 03:34:15.213328
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import ast_assert

    node = ast.parse("{1: 1, 2: 2, None: {3: 3, **dict_a}, 4: 4}")
    result = DictUnpackingTransformer().visit(node)

    ast_assert.ast_equal(
        result,
        # fmt: off
        """
        {
            _py_backwards_merge_dicts(
                [
                    dict(
                        [
                            (1, 1),
                            (2, 2),
                        ]
                    ),
                    dict([(3, 3)]),
                ],
                dict_a,
            ),
            (4, 4),
        }
        """
        # fmt: on
    )

# Generated at 2022-06-12 03:34:24.957801
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert merge_dicts.get_body()[0] == ast.FunctionDef(
        name='_py_backwards_merge_dicts',
        args=ast.arguments(
            posonlyargs=[],
            args=ast.arg(arg='dicts', annotation=None),
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]),
        body=[
            ast.Return(value=ast.Call(
                func=ast.Name(id='result', ctx=ast.Load()),
                args=[], keywords=[],
                starargs=None, kwargs=None)),
        ],
        decorator_list=[],
        returns=None
    )

# Generated at 2022-06-12 03:34:33.714850
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import get_ast_of, assert_equal_ast
    source = """
        x = {1: 2, 3: 4, 5: 6, None: {**some_dict}}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        x = _py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}, some_dict])
    """
    # Run test
    assert_equal_ast(expected, get_ast_of(source, DictUnpackingTransformer))



# Generated at 2022-06-12 03:35:07.004165
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from . import as_source
    from .ast_builder import build_ast
    from .dict_unpacking import DictUnpackingTransformer

    transformer = DictUnpackingTransformer()

    def assert_equal(node: ast3.AST, expected: str) -> None:
        assert as_source(transformer.visit(node)) == expected

    # x = {}
    assert_equal(
        build_ast('''
        x = {}
        '''),
        '''
        x = {}
        '''
    )

    # x = {'foo': 'bar', **z}

# Generated at 2022-06-12 03:35:15.976404
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = compile("{1: 1, 2: 2}", '?', 'single')
    assert type(module).__name__ == 'Module'

    node = ast.parse(module.body[0].expr)  # type: ignore
    assert type(node).__name__ == 'Expression'
    assert type(node.body).__name__ == 'Dict'
    assert node.body.keys == [ast.Num(n=1), ast.Num(n=2)]
    assert node.body.values == [ast.Num(n=1), ast.Num(n=2)]

    obj = DictUnpackingTransformer()
    result = obj.visit(node)

    assert type(result).__name__ == 'Expression'
    assert type(result.body).__name__ == 'Dict'

# Generated at 2022-06-12 03:35:24.084172
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test empty dict
    assert(DictUnpackingTransformer().visit_Dict(ast.Dict()) == ast.Dict())

    # Test dict with one element
    dict_ = ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)])
    assert(DictUnpackingTransformer().visit_Dict(dict_) == dict_)

    # Test dict with two elements
    dict_ = ast.Dict(
        keys=[ast.Num(n=1), ast.Str(s='key')],
        values=[ast.Num(n=1), ast.Name(id='value')])
    assert(DictUnpackingTransformer().visit_Dict(dict_) == dict_)


# Generated at 2022-06-12 03:35:33.845896
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import get_ast, compile_back
    source = """
    class A:
        def f(self):
            {1: 2}
            {1: 2, 3: 4}
            {1: 2, **a}
            {1: 2, 3: 4, **a}
            {1: 2, *a, 3: 4}
            {1: 2, *a, 4: 5, **b}
            {1: 2, 3: 4, *a, 4: 5, **b}
    """

# Generated at 2022-06-12 03:35:40.523561
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .helpers import get_target_nodes

    target = '''
        {1: 1, 2: 2, **dict_a}'''

    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)'''

    transformer = DictUnpackingTransformer()
    transformer.set_target_ver(3, 4)
    assert get_target_nodes(transformer, target) == expected



# Generated at 2022-06-12 03:35:50.307522
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base_tests import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        # noinspection PyMethodParameters
        @snippet
        def source():
            source = """
            {1: 1, **{'a': 2, 'b': 3}, **{'d': 0, 'c': -1}}
            """

        # noinspection PyMethodParameters
        @snippet
        def expected():
            expected = """
            _py_backwards_merge_dicts(
                [{1: 1,
                  'a': 2,
                  'b': 3}],
                {'d': 0,
                 'c': -1})
            """

        transformer = DictUnpackingTransformer

    Test().run()



# Generated at 2022-06-12 03:36:00.155067
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tests = [
        (
            '{1: 1, None: {2: 2, **a}, 3: 3, None: {4: 4, **b}}',
            '_py_backwards_merge_dicts([{1: 1, 3: 3}, {2: 2, 4: 4}, a, b])'
        ),
        (
            '{1, **a, None: {2, **b}, 3}',
            '_py_backwards_merge_dicts([{1, 3}, {2}, a, b])'
        )
    ]
    for test_input, expected_output in tests:
        node = ast.parse(test_input).body[0].value
        expected_node = ast.parse(expected_output).body[0].value
        node_transformer = DictUnpackingTrans

# Generated at 2022-06-12 03:36:08.475076
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    visitor = DictUnpackingTransformer()
    source = \
"""\
d = {'a': 1, 2: 2, **{'c': 3}, **dict_1, 3: 3, **dict_2}
"""  # noqa
    AST = ast.parse(source)
    AST = visitor.visit(AST)
    expected = \
"""\
d = _py_backwards_merge_dicts([{'a': 1, 2: 2, 3: 3}, {'c': 3}], dict_1, dict_2)
"""  # noqa
    assert ast.dump(AST) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 03:36:19.219603
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from .base import BaseNodeTransformer_test_visit_X

    from .test_DictUnpackingTransformer import DictUnpackingTransformer
    BaseNodeTransformer_test_visit_X(
        DictUnpackingTransformer,
        'Dict',
        'node',
        expected_from_ast=
        """
        _py_backwards_merge_dicts([{'a': 'b'}], c)
        """,
        expected_to_ast=
        """
        {"a": "b"}
        """
    )


# Generated at 2022-06-12 03:36:23.679948
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_fixtures.dict_unpacking import *

    # Given
    t = DictUnpackingTransformer()
    code_before = dict_unpacking_single_module
    expected_code = dict_unpacking_single_module_resulted

    # When
    code_after = t.visit(code_before)

    # Then
    assert code_after == expected_code



# Generated at 2022-06-12 03:37:06.140354
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    x = ast.parse('''
        d = {1: 2, **dict_a}
    ''')
    y = ast.parse('''
        _py_backwards_merge_dicts([{1: 2}], dict_a)
    ''')

    t = DictUnpackingTransformer()
    t.visit(x)
    assert ast.dump(x) == ast.dump(y)



# Generated at 2022-06-12 03:37:11.958524
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..codegen import to_source
    from ..utils.codegen import parse

    code = '''
a={'a':1,**{'b':2},**{'c':3},}
'''
    tree = parse(code)
    DictUnpackingTransformer().visit(tree)
    source = to_source(tree)
    assert source == '''\
a=_py_backwards_merge_dicts([{"a":1}, {"b":2}, {"c":3}])
'''

# Generated at 2022-06-12 03:37:22.301206
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict, Name, Call, List
    from .base_test import BaseNodeTransformerTest
    
    class DictUnpackingTransformerTest(BaseNodeTransformerTest):
        transformer = DictUnpackingTransformer
        file = __file__
        def test_1(self):
            self.compare_ast(
                """
                def foo():
                    x = {'a': 1, **{'b': 2}}
                """,
                """
                def foo():
                    x = _py_backwards_merge_dicts([dict({'a': 1})], {'b': 2})
                """
            )


# Generated at 2022-06-12 03:37:28.522400
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_astunparse
    node = ast.parse("""{1: 1, **dict_a}""")
    trans = DictUnpackingTransformer()
    transformed = trans.visit(node)
    assert trans._tree_changed
    assert typed_astunparse.dump(transformed) == inspect.cleandoc("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([dict(1=1)], dict_a)
    """)

# Generated at 2022-06-12 03:37:33.442378
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Given
    code = '{1: 1, **dict_a, 2: 2}'
    before = ast.parse(code)

    # When
    after = DictUnpackingTransformer().visit(before)

    # Then
    expected = ast.parse(
        '_py_backwards_merge_dicts([{1: 1}, dict_a], {2: 2})')
    assert ast.dump(after) == ast.dump(expected)

# Generated at 2022-06-12 03:37:34.621572
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:37:44.568761
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformer
    from .utils import get_assert_equals
    from .visitor import Visitor
    from ..utils.tree import get_node

    assert_equals = get_assert_equals()
    target = (3, 4)

    class DictUnpackingTransformer(BaseNodeTransformer):

        target = target

        def visit_Dict(self, node):
            assert_equals(1, node.lineno)
            assert_equals(1, node.col_offset)
            assert_equals(1, node.end_lineno)
            assert_equals(1, node.end_col_offset)
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-12 03:37:53.721674
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source = '{\n' \
             '  1: 1,\n' \
             '  **dict_a,\n' \
             '  2: 2,\n' \
             '  **dict_b\n' \
             '}'
    node = ast.parse(source)
    node = transformer.visit(node)  # type: ignore
    expected = '_py_backwards_merge_dicts([' \
               '[(Num(n=1), Num(n=1))], dict_a, [(Num(n=2), Num(n=2))], dict_b]' \
               ')'
    assert astor.to_source(node.body[-1]).rstrip() == expected



# Generated at 2022-06-12 03:38:03.201410
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseTestTransformer
    from ..tests.utils import wrap_in_function
    from ..utils.source import Source
    from ..utils.tree import ast_to_source

    test_source_1 = Source("""
        {1: 2}
    """)

    test_source_2 = Source("""
        {1: 2, **dict_a}
    """)

    test_source_3 = Source("""
        {1: 2, 3: 4, **dict_a}
    """)

    test_source_4 = Source("""
        {1: 2, 3: 4, 5: 6, **dict_a}
    """)

    test_source_5 = Source("""
        {1: 2, **dict_a, 3: 4}
    """)

    test_source_6 = Source

# Generated at 2022-06-12 03:38:10.491054
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import dump_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """

    tree = ast.parse(source)  # type: ignore

    target = """
    _py_backwards_merge_dicts(
        [{1: 1, 2: 2}], dict_a, dict_b)
    """

    expected_tree = dump_ast.load(target)
    transformer = DictUnpackingTransformer()
    result_tree = transformer.visit(tree)

    assert dump_ast.dump(expected_tree) == dump_ast.dump(result_tree)