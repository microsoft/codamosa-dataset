

# Generated at 2022-06-12 03:29:05.178813
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import textwrap
    from ..utils.transform import transform
    assert transform(DictUnpackingTransformer, textwrap.dedent("""
        {1: 2}
        """)) == textwrap.dedent("""
        {1: 2}
        """)

    assert transform(DictUnpackingTransformer, textwrap.dedent("""
        {**{}}
        """)) == textwrap.dedent("""
        _py_backwards_merge_dicts([{}])
        """)

    assert transform(DictUnpackingTransformer, textwrap.dedent("""
        {1: 2, **{}}
        """)) == textwrap.dedent("""
        _py_backwards_merge_dicts([{1: 2}], {})
        """)


# Generated at 2022-06-12 03:29:14.933409
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from astunparse import unparse
    from ..parsing.tree import parse
    from ..testing.utils import compare_ast
    parse('''
    def test(dict_a):
        return {1: 1, **dict_a}
    ''')
    # --
    compare_ast(DictUnpackingTransformer().visit(parse('''
    def test(dict_a):
        return {1: 1, **dict_a}
    ''')), parse('''
    def test(dict_a):
        return _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''))
    # --

# Generated at 2022-06-12 03:29:20.893696
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    source = '{1: 1, **{1: 1}, 2: 2, **{2: 2}, 3: 3}'
    expected = '_py_backwards_merge_dicts([dict({1: 1}), dict({2: 2})], {1: 1}, {2: 2}, dict({3: 3}))'

    code = ast.parse(source)
    code = transformer.visit(code)

    assert ast.dump(code) == expected

# Generated at 2022-06-12 03:29:31.319090
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..base import BaseNodeTransformerTest
    from .base import BaseTestAnnotationDictUnpacking
    from .base import BaseTestCodegen
    from .base import BaseTestDictUnpacking
    from .base import BaseTestInlineAnnotation
    from .base import BaseTestTypeComment

    class Test(BaseNodeTransformerTest,
               BaseTestDictUnpacking,
               BaseTestInlineAnnotation,
               BaseTestAnnotationDictUnpacking,
               BaseTestTypeComment,
               BaseTestCodegen):

        TRANSFORMER = DictUnpackingTransformer

        def test_empty_dict(self):
            self.assert_equal(
                ""
                "example = {}",
            )


# Generated at 2022-06-12 03:29:40.501638
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.python_source import Source
    from ..utils.tree import dump

    class DictUnpackingTransformer(DictUnpackingTransformer):
        def _split_by_None(self, pairs: Iterable[Pair]) -> Splitted:
            return splitted

        def _prepare_splitted(self, splitted: Splitted) \
                -> Iterable[Union[ast.Call, ast.Dict]]:
            return prepared

        def _merge_dicts(self, xs: Iterable[Union[ast.Call, ast.Dict]]) \
                -> ast.Call:
            return merge_call

    pairs = [(None, ast.Call(func=ast.Name(id='dict'), args=dict_)),
             (ast.Str(s='key'), ast.Num(n=1))]
    spl

# Generated at 2022-06-12 03:29:48.315338
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .remove_duplicates import RemoveDuplicatesTransformer

    def _run(node):
        visitor = DictUnpackingTransformer()
        node = visitor.visit(node)
        if visitor._tree_changed:
            node = RemoveDuplicatesTransformer().visit(node)
        return node


# Generated at 2022-06-12 03:29:52.887956
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.ast_transformer import wrap

    prepare_code = wrap(DictUnpackingTransformer).prepare_code

    code = '''
{1}
    '''.replace('    ', '')

    prepare_code(code)



# Generated at 2022-06-12 03:30:01.091282
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert compile_fstring(3, 4, '{1: 1, **dict_a}') == '_py_backwards_merge_dicts(dict({1: 1}), dict_a)'
    assert compile_fstring(3, 4, '{**a, **b, **c}') == '_py_backwards_merge_dicts(dict(a), dict(b), dict(c))'
    assert compile_fstring(3, 4, '{1: 1, **dict_a, 2: 2}') == '_py_backwards_merge_dicts(dict({1: 1, 2: 2}), dict_a)'

# Generated at 2022-06-12 03:30:12.045643
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:30:22.497077
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:30:39.469882
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    snippet_1 = '{1: 1, **dict_a}'
    snippet_2 = '{**dict_a, 1: 1}'
    snippet_3 = '{1: 1, 2: 2, **dict_a, 3: 3}'
    snippet_4 = '{**dict_a, 2: 2, 3: 3, 1: 1}'
    snippet_5 = '{**dict_a, 1: 1, 2: 2, 3: 3}'
    snippet_6 = '{**dict_a, **dict_b}'
    snippet_7 = '{1: 1, **dict_a, **dict_b}'
    snippet_8 = '{**dict_a, **dict_b, 1: 1}'

# Generated at 2022-06-12 03:30:41.362251
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert transform_code(DictUnpackingTransformer,
                          '{1: 1, **dict_a}') == '_py_backwards_merge_dicts([{1: 1}], dict_a)'

# Generated at 2022-06-12 03:30:51.553693
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest

    from ..utils.tree import tree
    from ..utils.source import source
    from ..utils.visitor import TreeDebugVisitor
    import typed_ast.ast3 as ast
    from copy import deepcopy
    from darglint.refactor.dict_unpacking import DictUnpackingTransformer

    # Tests
    class TestDictUnpackingTransformer(unittest.TestCase):
        transformer = DictUnpackingTransformer()
        fake_node = ast.Dict(keys=[None], values=[ast.Num(n=1)])
        expected_node = ast.Call(
            func=ast.Name(id='_py_backwards_merge_dicts'),
            args=[ast.List(elts=[ast.Dict(keys=[], values=[])])],
            keywords=[])


# Generated at 2022-06-12 03:31:00.831594
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import get_test_input_output_pair
    from ..utils.misc import get_code
    from ..context import Context
    from .visitors import AddParentRef, AddLineOffset
    from .visitors import LineNumber, StatementAnnotator
    from .visitors import AddOutputAndJupyterMetadata

    transform_function = DictUnpackingTransformer()

    for source, (result, is_changed) in get_test_input_output_pair(__file__, 'visit_Dict'):
        context = Context(source)
        tree = context.get_tree()

        tree = AddParentRef().visit(tree)
        tree = AddLineOffset(source).visit(tree)
        tree = LineNumber().visit(tree)

# Generated at 2022-06-12 03:31:09.380054
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_code_1 = """
{1: 1, **dict_a}
"""
    expected_result_1 = """
_py_backwards_merge_dicts([{1: 1}], dict_a)
"""
    test_code_2 = """
{1: 1, **dict_a, **dict_b}
"""
    expected_result_2 = """
_py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)
"""
    test_code_3 = """
{1: 1, **dict_a, 2: 2, **dict_b}
"""
    expected_result_3 = """
_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)
"""
    test_code

# Generated at 2022-06-12 03:31:20.093000
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.unparse import Unparser
    from .test_suite.test_target import test_main_loop, test_ast_node
    import sys
    import ast

    class Test(metaclass=test_main_loop.TestMainLoop):
        @test_ast_node(args=['{1: 2}'])
        def test_DictUnpackingTransformer_visit_Dict_a(self, node: ast.AST) -> None:
            DictUnpackingTransformer().visit(node)
            Unparser(file=sys.stdout, indentation=' ' * 4).visit(node)


# Generated at 2022-06-12 03:31:25.078829
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.examples import DICT_UNPACKING_EXAMPLES
    for example in DICT_UNPACKING_EXAMPLES:
        source, expected = example
        node = ast.parse(source)
        assert node_equals_ignoring_position(
            DictUnpackingTransformer().visit(node),
            ast.parse(expected))


# Generated at 2022-06-12 03:31:30.083323
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import compile_to_ast, assert_check_ast
    from ..versions import Version
    for version in Version:
        module = compile_to_ast({"a": 1, "b": 2}, version)
        transformer = DictUnpackingTransformer(version)
        result = transformer.visit(module)
        assert_check_ast(result, version)

# Generated at 2022-06-12 03:31:40.964950
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...testing.fixtures import c_program
    from ...testing.transform import assert_transform
    from ...testing.answers import transform_answers as answers
    from .test_calls import CallsInlinerTransformer
    from .test_constants import ConstantsSimplifierTransformer

    assert_transform(DictUnpackingTransformer(), c_program, answers)
    assert_transform(DictUnpackingTransformer(),
                     'a = {1: 2, 3: 4, **foo.get_dict()}',
                     'a = _py_backwards_merge_dicts([{1: 2, 3: 4}], foo.get_dict())')

# Generated at 2022-06-12 03:31:50.270530
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    from typed_ast import ast3 as ast

    class Test(unittest.TestCase):
        @staticmethod
        def node(x: str) -> ast.Dict:
            return ast.parse(x).body[0].value  # type: ignore

        def test_one_item(self):
            x = self.node('{1: 1}')
            self.assertEqual(x, DictUnpackingTransformer().visit(x))  # type: ignore

        def test_two_items(self):
            x = self.node('{1: 1, 2: 2}')
            self.assertEqual(x, DictUnpackingTransformer().visit(x))  # type: ignore


# Generated at 2022-06-12 03:32:06.370762
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import dump, loads
    from .example import code_for_simple_dict_unpacking

    actual = DictUnpackingTransformer().visit(loads(code_for_simple_dict_unpacking))
    dump(actual)

    expected = dump(loads(r"""
    def a():
        b = _py_backwards_merge_dicts([{1: 1}], {2: 2})
    """))

    assert actual == expected



# Generated at 2022-06-12 03:32:15.211365
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    code = '''
    {1: 1, 2: 2, 3: 3, **dict_a, 4: 4, **dict_b, 5: 5, **dict_c}
    '''
    result = '''
    _py_backwards_merge_dicts(
      [
        {1: 1, 2: 2, 3: 3},
        dict_a,
        {4: 4},
        dict_b,
        {5: 5},
        dict_c
      ]
    )
    '''
    tree = ast.parse(code)
    transformer = DictUnpackingTransformer()
    target = transformer.visit(tree)
    assert astunparse.unparse(target) == result

# Generated at 2022-06-12 03:32:25.849223
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''\
{
    1: 2,  # type: ignore
    2: 3,
    **dict_a,
    3: 4,
    **dict_b}
'''
    expected = '''\
{
    1: 2,  # type: ignore
    2: 3,
    **dict_a,
    3: 4,
    **dict_b}
'''
    assert (expected ==
            compile(source, '', 'exec', optimize=0,
                    flags=ast.PyCF_ONLY_AST).body[0].value.body[0].value)
    assert (expected ==
            compile(source, '', 'exec', optimize=1,
                    flags=ast.PyCF_ONLY_AST).body[0].value.body[0].value)

# Generated at 2022-06-12 03:32:36.299663
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import pytest
    from ..utils.testing import assert_programs_equal
    from ..utils.tree import extract_method_code

    # created by snippet merge_dicts
    def merge_dicts(dicts):
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        return _py_backwards_merge_dicts(dicts)

    class TestCase(object):

        @property
        def expected(self):
            return merge_dicts([{1: 1, 2: 2}, dict_a])


# Generated at 2022-06-12 03:32:41.901767
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Given
    code_before = """
    dict_a = {2: 2}
    dict_b = {1: 1, **dict_a}
    """
    code_after = """
    dict_a = {2: 2}
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = ast.parse(code_after)

    # When
    ast_after = DictUnpackingTransformer().visit(ast.parse(code_before))

    # Then
    assert ast.dump(expected_ast) == ast.dump(ast_after)

# Generated at 2022-06-12 03:32:49.696750
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_transform, from_source
    assert_transform(
        DictUnpackingTransformer,
        '{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}',
        '_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)')
    assert_transform(
        DictUnpackingTransformer,
        'dict_a = {1: 1}; {2: 2, **dict_a}',
        from_source('dict_a = {1: 1}\n_py_backwards_merge_dicts([{2: 2}], dict_a)'))

# Generated at 2022-06-12 03:32:53.933955
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()
    t = ast.parse('{1: 1, **dict_a}')
    result = dut.visit(t)
    expected = ast.parse("""
    _py_backwards_merge_dicts([{1: 1}], dict_a})
    """)
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 03:33:03.677263
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..visitor import NodeTransformerVisitor

    code = """{'a': [1, 2, ]}"""
    expected_code = """{'a': [1, 2, ]}"""
    tree = ast.parse(code)
    tree = NodeTransformerVisitor(DictUnpackingTransformer()).visit(tree)
    generated_code = source(tree)
    assert generated_code == expected_code

    code = """{1: 1, }"""
    expected_code = """{1: 1, }"""
    tree = ast.parse(code)
    tree = NodeTransformerVisitor(DictUnpackingTransformer()).visit(tree)
    generated_code = source(tree)
    assert generated_code == expected_code


# Generated at 2022-06-12 03:33:09.963158
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import task_test

    task_test(
        DictUnpackingTransformer,
        """
        {1: 2, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([{'1': 2}], dict_a)
        """,
        """
        _py_backwards_merge_dicts([{'1': 2}], {'2': 3, 3: 4}, dict_a)
        """,
        """
        _py_backwards_merge_dicts([{'1': 2}], {}, {'2': 3, 3: 4}, dict_a)
        """,
    )



# Generated at 2022-06-12 03:33:15.622440
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import transform, assert_equal
    from ..utils.snippet import snippet

    @snippet
    def before():
        {1:1, **{2:2, 3:3}, 4:4}

    @snippet
    def after():
        _py_backwards_merge_dicts([dict({1:1}), {2:2, 3:3}], dict({4:4}))

    assert_equal(transform(before, DictUnpackingTransformer), after)



# Generated at 2022-06-12 03:33:44.970823
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse
    from ..utils.unparse import Unparser

    node = parse(
        """
        {1: 2, **a, None: 1, **b, 2: 3, **c, 4: 5}
        """).body[0]  # type: ast.Expr
    Unparser(node)

    result = DictUnpackingTransformer().visit(node)
    assert isinstance(result, ast.Call)

    Unparser(result)

# Generated at 2022-06-12 03:33:52.496528
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    t = DictUnpackingTransformer()
    node = {1: 1, 2: 2, **{3: 3}, 4: 4, **{5: 5}, 6: 6}
    expected = "__py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3, 4: 4}, {5: 5}, {6: 6}])"
    expected_ast = ast.parse(expected)
    assert astunparse.unparse(t.visit(ast.parse(str(node))), ) == expected

# Generated at 2022-06-12 03:33:56.684054
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert DictUnpackingTransformer().visit(
        ast.parse('{1: 1, 2: 2, **dict_a}')) == \
        ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)')



# Generated at 2022-06-12 03:34:05.150063
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from ..utils.testing import assert_same_ast, transform_module
    from .base import BaseNodeTransformer

    @transform_module
    class TestTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_Dict(self, node: ast3.Dict) -> ast3.Dict:
            node.keys.append(ast3.Constant(1))
            return node

    assert_same_ast(
        TestTransformer,
        """
        {1: 1}
        """,
        """
        {1: 1, 1}
        """
    )


# Generated at 2022-06-12 03:34:12.740766
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''
values = {'a': 1, 'b': 2, **kwargs}
'''
    expected = '''
values = _py_backwards_merge_dicts([{'a': 1, 'b': 2}], kwargs)
'''
    tree = ast.parse(source)
    dict_unpacker = DictUnpackingTransformer()
    dict_unpacker.visit(tree)
    result = tree.body[0]
    assert isinstance(result, ast.Assign)
    assert isinstance(result.value, ast.Call)
    assert ast.dump(result) == expected.strip()

# Generated at 2022-06-12 03:34:23.004060
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # {1: 1, **dict_a, 2: 2}
    node_ = ast.Dict(keys=[
        ast.Constant(value=1),
        None,
        ast.Constant(value=2)],
        values=[
            ast.Constant(value=1),
            ast.Name(id='dict_a'),
            ast.Constant(value=2)])
    # {1: 1, 2: 2}

# Generated at 2022-06-12 03:34:28.799398
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_setup import setup_test_module
    module = setup_test_module("""
{1: 1, **dict_a}
""")
    from .. import compile_restricted
    tree = compile_restricted(module, 4, [])
    from .test_setup import assert_code_equal
    assert_code_equal("""
_py_backwards_merge_dicts([{1: 1}], dict_a})
""", tree)

# Generated at 2022-06-12 03:34:37.142933
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typing as t
    from typed_ast import ast3
    from ..primitives import Tuple
    from ..primitives.list import List

    class Dict(t.Generic[t.Key, t.Value]):
        """Represents a dict."""
        def __init_subclass__(cls):
            super().__init_subclass__()
            cls.__module__ = 'typing'
            cls.__name__ = 'Dict'

        def __init__(self, pairs: t.Iterable[t.Tuple[t.Key, t.Value]] = ()) -> None:
            self._store = dict(pairs)

        def __setitem__(self, key: t.Key, value: t.Value):
            self._store[key] = value


# Generated at 2022-06-12 03:34:42.341971
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_helpers import make_call_test

    src = """
        {1: 1, **{'a': 2}, 3: 3, **{'b': 4}}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 3: 3}, {'a': 2}, {'b': 4}])
    """
    make_call_test(src, expected, DictUnpackingTransformer)

# Generated at 2022-06-12 03:34:49.690089
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = ast.parse("""
{1: 1, 2: 2, 3: 3, **dict_a, **dict_b, 4: 4, 5: 5, 6: 6}
    """)

    expected = ast.parse("""
_py_backwards_merge_dicts(
    [dict([(1, 1), (2, 2), (3, 3)]), dict_a, dict_b, dict([(4, 4), (5, 5), (6, 6)])]
)
    """)

    actual = DictUnpackingTransformer().visit(code)
    actual.body[0].body[0].body[0].lineno = None
    assert actual == expected

# Generated at 2022-06-12 03:35:48.016238
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def run(code: str, expected: str) -> None:
        node_ = ast.parse(code, mode='eval')
        node = DictUnpackingTransformer().visit(node_)
        assert ast.dump(node) == expected

    run(
        code='{1: 1}',
        expected='Dict(keys=[Constant(value=1, kind=None)], ' +
                 'values=[Constant(value=1, kind=None)])',
    )


# Generated at 2022-06-12 03:35:57.886603
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def check(inp, outp):
        assert DictUnpackingTransformer().visit(inp) == outp

    check({1: 1}, {1: 1})
    check({1: 1, **{2: 2, 3: 3}},
          _py_backwards_merge_dicts([{1: 1}], dict_a={2: 2, 3: 3}))
    check({1: 1, **{2: 2}, 3: 3, **{**{4: 4}, 5: 5}},
          _py_backwards_merge_dicts([{1: 1}, {3: 3}], dict_a={2: 2}, dict_b={4: 4, 5: 5}))

# Generated at 2022-06-12 03:36:02.894877
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.asserts import assert_source

    source = '{1: 2, **{3: 4}, 5: 6}'
    expected = '_py_backwards_merge_dicts([{1: 2}, {5: 6}], {3: 4})'
    assert_source(source, expected, DictUnpackingTransformer)



# Generated at 2022-06-12 03:36:13.782885
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''
# comment 1
a = {**{1: 1}, **{2: 2},
# comment 2
b: b,
     **{3: 3}}
c = {**{3: 3}, **{1: 1},
# comment 3
4: 4}
'''
    expected = '''# comment 1
a = _py_backwards_merge_dicts([{1: 1, 2: 2}, dict(b=b)], {3: 3})
c = _py_backwards_merge_dicts([dict(3=3), dict(1=1)], {4: 4})
'''
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert expected == compile(node, '<test>', mode='exec')

# Generated at 2022-06-12 03:36:23.273989
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from python_transpile.test.helper import assert_ast_equal

    code = """\
{1: 1, 2: 2, **dict_a}
    """
    tree = ast.parse(code)

    result = DictUnpackingTransformer().visit(tree)
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)'
    assert_ast_equal(ast.parse(expected), result)

    code = """\
{1: 1, **dict_a, **dict_b, 2: 2}
    """
    tree = ast.parse(code)

    result = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-12 03:36:32.171405
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from .base import NodeTransformer

    class Transformer(NodeTransformer):
        def visit_ListComp(self, node):
            return ast.Name(id="list")

    node = ast.parse(source('''
    [x for x in [1, 2, 3] if x == 2]
    '''))

    expected = source('''
    list([x for x in [1, 2, 3] if x == 2])
    ''')

    new_node = Transformer().visit(node)
    assert source(new_node) == expected

# Generated at 2022-06-12 03:36:42.344882
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as _ast
    source = """{1: 1, **dict_a}"""

# Generated at 2022-06-12 03:36:46.780435
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import dump
    from tests.utils.helpers import build_ast

    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a})'

    transformer = DictUnpackingTransformer()
    result = dump(transformer.visit(build_ast(source)))
    assert result == expected

# Generated at 2022-06-12 03:36:55.932571
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3
    import textwrap
    code = textwrap.dedent(r'''
    def f():
        return {'a': 'x', **{'b': 'y'}, c: 'z', **{'d': 'w'}}
    ''')
    expected = textwrap.dedent(r'''
    def f():
        return _py_backwards_merge_dicts([{'a': 'x'}, {'b': 'y'}, {c: 'z'}, {'d': 'w'}])
    ''')
    actual = typed_ast.ast3.parse(code)
    DictUnpackingTransformer().visit(actual)
    assert typed_ast.ast3.dump(actual) == expected



# Generated at 2022-06-12 03:37:05.341580
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import dump, parse
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    dut = DictUnpackingTransformer()  # type: ignore
    dut.target = (3, 4)

# Generated at 2022-06-12 03:38:42.235597
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = DictUnpackingTransformer
        CODE = '''\
            {
                None: None,
                **dict_a,
                None: None,
                **dict_b,
                **dict_c,
            }
        '''
        EXPECTED = '''\
            _py_backwards_merge_dicts([{}], dict_a, dict_b, dict_c)
        '''

# Generated at 2022-06-12 03:38:48.568397
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    dict_ = ast.parse("{1: 2, 3: 4, **{5: 6}}").body[0].value
    assert transformer.visit(dict_) == ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[
            ast.Dict(keys=[ast.Num(n=1), ast.Num(n=3)],
                     values=[ast.Num(n=2), ast.Num(n=4)]),
            ast.Dict(keys=[ast.Num(n=5)], values=[ast.Num(n=6)])])],
        keywords=[])