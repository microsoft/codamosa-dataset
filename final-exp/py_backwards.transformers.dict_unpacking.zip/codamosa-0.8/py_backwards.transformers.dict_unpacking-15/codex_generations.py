

# Generated at 2022-06-12 03:29:10.667905
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_transformed

    assert_transformed(
        """dict_ = dict(1: {'a': 1})
dict_a = dict()
dict_b = dict()

x = {1: 1, 'a': {'b': {'c': 1}, 'd': 2}, **dict_, (1, 2): 3,
     **dict_a, **dict_b, 'y': 4}""",
        """dict_ = dict(1: {'a': 1})
dict_a = dict()
dict_b = dict()

x = _py_backwards_merge_dicts([{'b': {'c': 1}, 'd': 2}, {1, 3}, {'y': 4}], dict_, dict_a, dict_b)""")


# Generated at 2022-06-12 03:29:20.358598
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Info: DictUnpackingTransformer.visit_Dict
    # Case: Simple case - empty dict
    src = '[{}, {}]'
    expected =('_py_backwards_merge_dicts([{}], {})')
    assert expected in str(ast.parse(src, mode='eval')), \
        f'Code "{src}" has not been modified to "{expected}"'

    # Case: Simple case - one pair
    src = '[{1: 2}, {3: 4}]'
    expected = '_py_backwards_merge_dicts([{1: 2}], {3: 4})'
    assert expected in str(ast.parse(src, mode='eval')), \
        f'Code "{src}" has not been modified to "{expected}"'

    # Case: Simple case - several pairs

# Generated at 2022-06-12 03:29:27.859992
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    module = ast.parse('{1: 2, **a, 3: 4, **b, 5: 6, **c}')
    transformer = DictUnpackingTransformer()
    expected = ast.parse('_py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}], a, b, c)')
    actual = transformer.visit(module)
    assert ast.dump(expected, include_attributes=False) == ast.dump(actual, include_attributes=False)

# Generated at 2022-06-12 03:29:33.370166
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code_before = """
        {1: 1, **dict_a}
        """
    expected_code = """
        _py_backwards_merge_dicts([{1: 1}], dict_a})
        """
    node = ast.parse(code_before)
    node = DictUnpackingTransformer().visit(node)  # type: ignore
    code_after = astor.to_source(node)  # type: ignore
    print(code_after)
    assert code_after == expected_code

# Generated at 2022-06-12 03:29:43.044108
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_cases = {
        '{1: "1", 2: "2", **{3: "3"}}': '_py_backwards_merge_dicts([{1: "1", 2: "2"}], {3: "3"})',
        '{**{}}': 'dict({})',
        '{1: "1", **{}}': '_py_backwards_merge_dicts([{1: "1"}])',
    }
    transformer = DictUnpackingTransformer()
    for code, expected_code in test_cases.items():
        node = ast.parse(code)
        result = transformer.visit(node)  # type: ignore
        expected = ast.parse(expected_code)

# Generated at 2022-06-12 03:29:52.986017
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Test(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            self.maxDiff = None
            super().__init__(*args, **kwargs)

        def _run_visit_Dict(self, body):
            node = ast.Module(body=body)
            transformer = DictUnpackingTransformer()
            transformed = transformer.visit(node)
            return ast.dump(transformed)


# Generated at 2022-06-12 03:30:02.592053
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import make_function, make_dict

    def prepare_test(unpackings: Iterable[Tuple[str, str]]) \
            -> Tuple[str, str]:
        function = 'def f(x): return y'
        full_src = 'y = {%s}' % ', '.join(unpackings)
        return full_src, function

    def prepare_assert(unpackings: Iterable[Tuple[str, str]]) \
            -> str:
        return '_py_backwards_merge_dicts([%s], y)' % (
            ', '.join(["{%s}" % ', '.join(unpacking)
                       for unpacking in unpackings]))


# Generated at 2022-06-12 03:30:09.253054
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
    {
        None: a,
        1: b,
        None: {None: c, 2: d},
        3: e,
        None: f
    }
    """
    target = """
    _py_backwards_merge_dicts([{1: b, 3: e}], a, {2: d}, f)
    """
    assert DictUnpackingTransformer().visit(ast.parse(source)) \
        == ast.parse(target)

# Generated at 2022-06-12 03:30:19.363188
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast_factory import ast_factory

    factory = ast_factory(DictUnpackingTransformer, 3, 4)

# Generated at 2022-06-12 03:30:24.390753
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    result = DictUnpackingTransformer.transform(
        """{1: 1, **{2: 1}}""")

    assert "\n".join(result.split("\n")[1:]).strip() == """\
foo = 1
_py_backwards_merge_dicts([{foo: 1}], {2: 1})"""



# Generated at 2022-06-12 03:30:42.080953
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:30:52.523605
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .test_utils import assert_parses_to, parse_to_ast, assert_roundtrip

# Generated at 2022-06-12 03:31:01.458139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import List, Union

    class Bovine:
        pass

    class Feline:
        pass

    class Animal:
        def __repr__(self) -> str:
            return '{}({})'.format(
                self.__class__.__name__, self.__dict__)

    class Cow(Bovine, Animal):
        def __init__(self, name: str) -> None:
            self.name = name

    class Cat(Feline, Animal):
        def __init__(self, name: str) -> None:
            self.name = name

    class Zoo:
        def __init__(self, animals: List[Animal]) -> None:
            self.animals = animals  # Point of interest


# Generated at 2022-06-12 03:31:06.636346
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_base import get_python_ast
    from ..utils.tree import print_python_ast

    transformer = DictUnpackingTransformer()
    result = transformer.visit(get_python_ast("{1: 1, **dict_a}"))
    assert print_python_ast(result) == "merge_dicts\n_py_backwards_merge_dicts([{1: 1}], dict_a)"

# Generated at 2022-06-12 03:31:16.739936
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    for _from, _to in [
        (
            '''{1: 1, **dict_a, **dict_b}''',
            '''_py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)'''),
        (
            '''{**dict_a, **dict_b}''',
            '''_py_backwards_merge_dicts([], dict_a, dict_b)'''),
        ('{**dict_a}', 'dict(dict_a)'),
        ('{1: 1, **dict_a}', '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    ]:
        tree = ast.parse(_from)
        DictUnpackingTransformer(tree).run()
        assert ast

# Generated at 2022-06-12 03:31:22.596261
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import parse
    from .utils import pretty
    from .utils import render

    code = '''
        {1: 2, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([dict(1=2)], dict_a)
    '''
    node = parse(code)
    actual = pretty(DictUnpackingTransformer().visit(node))
    assert render(actual) == render(expected)



# Generated at 2022-06-12 03:31:29.331911
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import test_utils
    t = test_utils.make_caller(DictUnpackingTransformer)
    # Positive tests
    t('{1: 1, **dict_a}')
    t('{**dict_a}')
    t('{1: 1, 2: 2, **dict_a}')
    t('{**dict_a, 2: 2}')
    t('{1: 1, **dict_a, 2: 2}')
    # Negative tests
    t('{1: 1}')
    t('{}')

# Generated at 2022-06-12 03:31:40.202520
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformerTests
    from ..utils import external

    class DictUnpackingTransformerTests(BaseNodeTransformerTests):
        transformers = [DictUnpackingTransformer]

        @staticmethod
        def _run_call(args: str) -> str:
            return f'_py_backwards_merge_dicts([{args}])'

        @staticmethod
        def _run_dict(args: str) -> str:
            return f'dict({args})'


# Generated at 2022-06-12 03:31:48.770461
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from astpretty import pformat

    source = """\
    {1: 1, 2: 2, 3: 3, **dict_a, 4: 4, 5: 5, **dict_b}
    """
    expected_result = """\
    _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}, {4: 4}, {5: 5}], dict_a, dict_b)
    """

    module = ast.parse(source)
    module = DictUnpackingTransformer().visit(module)
    module_src = unparse(module)
    print(pformat(module))

    assert module_src == expected_result

# Generated at 2022-06-12 03:31:55.245001
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import unit_test_ast

    dict_ = ast.parse(
        """
        {a: 1, b: 2, **c}
        """).body[0]
    expected = ast.parse(
        """
        _py_backwards_merge_dicts([{a: 1, b: 2}], c)
        """).body[0]
    test_dict = unit_test_ast(dict_, DictUnpackingTransformer)
    assert test_dict == expected, test_dict

# Generated at 2022-06-12 03:32:17.037354
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from compiler.ast import Dict, Const, Name
    from ..utils.construct import subbody, ast_from_snippet
    from ..utils.transform import apply_transformers

    node = subbody(['{}'])
    expected = Dict([], [])
    result = DictUnpackingTransformer().visit_Dict(node)
    assert result == expected

    node = subbody(['{None: "a"}'])
    expected = Dict([], [Const("a")])
    result = DictUnpackingTransformer().visit_Dict(node)
    assert result == expected

    node = subbody(['{1: 1, None: "a"}'])
    expected = Dict([Const(1)], [Const(1)])

# Generated at 2022-06-12 03:32:26.182095
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..unparse import unparse

    source = '{1: 1, 2: 2, None: {3: 3, 4: 4}, 5: 5, None: 6}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}, dict({3: 3, 4: 4}), {5: 5}], 6)'
    x = DictUnpackingTransformer()
    x._tree_changed = False
    node = ast.parse(source)
    x.visit(node)
    result = unparse(node)
    assert x._tree_changed is True
    assert result.strip() == expected

# Generated at 2022-06-12 03:32:31.442349
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import check_transformation

    code = '{1: 1, 2: 2, **dict_a, 3: 3, **dict_b}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3}], dict_a, dict_b)'

    check_transformation(code, expected, DictUnpackingTransformer)

# Generated at 2022-06-12 03:32:33.980106
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    x = {1: 1, 2: 2, None: {3: 3}, 4: 4}
    expect = {1: 1, 2: 2, 3: 3, 4: 4}
    assert DictUnpackingTransformer.run(x) == expect

# Generated at 2022-06-12 03:32:42.184942
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test that visit_Dict modifies the input only when there is
    # unpacking.
    test_cases = dict(
        some_dict={'a': 2, 'b': 3},
        some_dict_with_unpacking={'a': 2, **{'b': 3}}
    )

    for test_case in test_cases.keys():
        transformer = DictUnpackingTransformer()
        source = f'{test_case}'
        code = compiler.parse(source)
        transformed_code = transformer.visit(code)
        assert transformer._tree_changed is (test_case == 'some_dict_with_unpacking')

    # Test that visit_Dict replaces unpacking dict with call of
    # function for merging dicts.
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-12 03:32:50.609122
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def transform(snippet: str, *, test_ctx: bool = False) \
            -> Union[ast.Dict, ast.Call]:
        """Transforms snippet by visitor."""
        result = parse_snippet(snippet)
        if test_ctx:
            assert result.body[0].value.value == 1

        visitor = DictUnpackingTransformer()
        return visitor.visit(result)

    def assert_Call(result: ast.Call) -> None:
        """Asserts that result has expected structure."""
        assert isinstance(result, ast.Call)
        assert isinstance(result.func, ast.Name)
        assert result.func.id == '_py_backwards_merge_dicts'
        assert isinstance(result.args[0], ast.List)

# Generated at 2022-06-12 03:32:59.680286
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def test(code: str, expected: str) -> None:
        node = ast.parse(code).body[0]
        transformer = DictUnpackingTransformer()
        result = transformer.visit(node)
        assert ast.dump(result) == expected

    test('{}', 'Dict(keys=[], values=[])\n')
    test('{1: 1}', 'Dict(keys=[Num(n=1)], values=[Num(n=1)])\n')
    test('{1: 1, **a}',
         '_py_backwards_merge_dicts([Dict(keys=[Num(n=1)], values=[Num(n=1)])], a)\n')

# Generated at 2022-06-12 03:33:06.782168
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    src = astor.to_source(ast.parse(r'''
        {1: 'a', **{2: 'b', 3: 'c'}, 'key': 'val'}
    '''))
    expected = astor.to_source(ast.parse(r'''
        _py_backwards_merge_dicts([{1: 'a'}, {'key': 'val'}, {2: 'b', 3: 'c'}])
    '''))

    real = DictUnpackingTransformer().visit(ast.parse(src))
    assert astor.to_source(real) == expected

# Generated at 2022-06-12 03:33:10.326284
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    orig = ast.parse('''
        {1: 2, 3: 4, **{5: 6, 7: 8}}
    ''')

    mod = ast.parse('''
        {1: 2, 3: 4, **{5: 6, 7: 8}}
    ''')
    trans = DictUnpackingTransformer()
    res = trans.visit(mod)

    assert ast.dump(orig, annotate_fields=False) == ast.dump(res, annotate_fields=False)

# Generated at 2022-06-12 03:33:18.957794
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    from ..utils.trees import trees_equal
    from ..utils import visitation

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-12 03:33:49.357526
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, **dict_a}')
    result = transformer.visit(node)
    assert result == ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')

# Generated at 2022-06-12 03:33:59.662933
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dictionary = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                          values=[ast.Num(n=11), ast.Num(n=22), ast.Num(n=33)])
    expected = ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'),
                        args=[ast.List(elts=[ast.Dict(keys=[ast.Num(n=1)],
                                                     values=[ast.Num(n=11)]),
                                            ast.Num(n=22),
                                            ast.Dict(keys=[ast.Num(n=2)],
                                                     values=[ast.Num(n=33)])])],
                        keywords=[])
    visitor = DictUnpackingTransformer(None)

# Generated at 2022-06-12 03:34:06.133744
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    expected = ast.parse(inspect.cleandoc("""
        def f(x):
            return _py_backwards_merge_dicts([dict()], x)
    """))

    tree = ast.parse(inspect.cleandoc("""
        def f(x):
            return {**x}
    """))

    tr = DictUnpackingTransformer()
    res = tr.visit(tree)
    assert ast.dump(res) == ast.dump(expected)

# Generated at 2022-06-12 03:34:14.863319
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test with None in keys
    class TestDict(ast.Dict):
        def _fields(self):
            return ('keys', 'values')
    cases = [
        TestDict(  # type: ignore
            keys=[None, None, None, None, None],
            values=[
                ast.Num(n=1),
                ast.Num(n=2),
                ast.Num(n=3),
                ast.Num(n=4),
                ast.Num(n=5),
            ])
    ]
    for node in cases:
        transformer = DictUnpackingTransformer()
        result = transformer.visit(node)
        assert isinstance(result, ast.Call)
        assert result.func.id == '_py_backwards_merge_dicts'
        assert result.args[0].el

# Generated at 2022-06-12 03:34:25.299997
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTestCase

    class TestCase(BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer

    TestCase.test(code='{**a}',
                  expected_code='_py_backwards_merge_dicts([], a)')

    TestCase.test(code='{1: 1, **a}',
                  expected_code='_py_backwards_merge_dicts([{1: 1}], a)')

    TestCase.test(code='{1: 1, **a, 2: 2, **b, 3: 3}',
                  expected_code='_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], a, b)')

# Generated at 2022-06-12 03:34:34.804706
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse
    from ..utils.unparse import Unparser
    from io import StringIO

    inp = """\
    dict_a = {1: 1, 2: 2}
    dict_b = {3: 3, 4: 4}
    dict_c = {5: 5, 6: 6}
    {1: 1, 2: 2, **dict_a, **dict_b, **dict_c}
    """

    tree = parse(inp, mode='eval')
    Unparser(tree, indent=2)

    assert isinstance(tree, ast.Expression)
    assert isinstance(tree.body, ast.Dict)
    assert tree.body.keys == [None, None, 1, 2, None, None, 5]

# Generated at 2022-06-12 03:34:40.955586
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    import sys
    import astunparse

    class Test(unittest.TestCase):
        pass

    def run(expected_source, source):
        tree = compile(source, '', 'exec', ast.PyCF_ONLY_AST, True)
        tree = DictUnpackingTransformer().visit(tree)  # type: ignore
        actual_source = astunparse.unparse(tree)
        Test("test_DictUnpackingTransformer_visit_Dict", Test).assertEqual(
            expected_source, actual_source)


# Generated at 2022-06-12 03:34:49.649109
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None
    """Unit test for method visit_Dict of class DictUnpackingTransformer."""
    transformer = DictUnpackingTransformer()

    assert transformer.visit(ast.parse('{}')) == ast.parse('{}')

    result = transformer.visit(ast.parse('{1: 1, **x}'))
    expected = ast.parse(merge_dicts('{1: 1}', 'x'))
    assert result == expected

    result = transformer.visit(ast.parse('{1: 1, 2: 2, **x}'))
    expected = ast.parse(merge_dicts('{1: 1, 2: 2}', 'x'))
    assert result == expected


# Generated at 2022-06-12 03:34:55.495898
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("""\
{1: 1, **{2: 2}, 3: 3, **{4: 4}}
""")
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-12 03:35:04.808660
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # pylint: disable=eval-used, expression-not-assigned
    assert eval(DictUnpackingTransformer().visit(ast.parse('{1: 1, 2: 2}'))) \
           == {1: 1, 2: 2}
    assert eval(DictUnpackingTransformer().visit(ast.parse('{1: 1, **{2: 2}}'))) \
           == {1: 1, 2: 2}
    assert eval(DictUnpackingTransformer().visit(
        ast.parse('{1: 1, **{2: 2}, 3: 3, **{4: 4, 5: 5}}'))) \
        == {1: 1, 2: 2, 3: 3, 4: 4, 5: 5}

# Generated at 2022-06-12 03:36:05.713277
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test of method visit_Dict of class DictUnpackingTransformer"""
    transformer = DictUnpackingTransformer()

    d = ast.Dict(keys=[], values=[])
    res = transformer.visit_Dict(d)
    assert isinstance(res, ast.Call)
    assert isinstance(res.func, ast.Name)
    assert res.func.id == '_py_backwards_merge_dicts'
    assert isinstance(res.args, list)
    assert len(res.args) == 1
    assert isinstance(res.args[0], ast.List)
    assert len(res.args[0].elts) == 1
    assert isinstance(res.args[0].elts[0], ast.Dict)


# Generated at 2022-06-12 03:36:16.267242
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import assert_equal_code

    code = """
        def f():
            {1: 1, **dict_a}
            {1: 1, **dict_a, 2: 2, **dict_b}
            {1: 1, **dict_a, 2: 2, **dict_b, **dict_c}
        """
    expected = """
        def f():
            _py_backwards_merge_dicts([{1: 1}], dict_a)
            _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)
            _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b, dict_c)
        """

# Generated at 2022-06-12 03:36:22.166464
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():  # type: ignore
    from typing import List
    from typed_ast import ast3 as ast

    class DummyNodeTransformer(ast.NodeTransformer):
        def __init__(self) -> None:
            pass

    class DummyNodeVisitor(ast.NodeVisitor):
        def __init__(self) -> None:
            pass

    transformer = DictUnpackingTransformer(node_transformer=DummyNodeTransformer(),
                                           node_visitor=DummyNodeVisitor())


# Generated at 2022-06-12 03:36:32.700665
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest

    # Unit test for visit_Dict method of class DictUnpackingTransformer
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from typed_astunparse import unparse

    class TestDictUnpackingTransformer(BaseNodeTransformer):
        """Compiles:

            {1: 1, **dict_a}

        To:

            _py_backwards_merge_dicts([{1: 1}], dict_a})

        """
        target = (3, 4)

        def _split_by_None(self, pairs: Iterable[Pair]) -> Splitted:
            """Splits pairs to lists separated by dict unpacking statements."""
            result = [[]]  # type: Splitted

# Generated at 2022-06-12 03:36:40.058391
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
    {None: None, 'a': 1, None: None, 'b': 2, None: None, 'c': 3, None: None}
    """
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    expected = """
    _py_backwards_merge_dicts(['a', 1], 'b', 2, 'c', 3)
    """
    actual = astor.to_source(tree)
    assert expected == actual



# Generated at 2022-06-12 03:36:49.341766
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .testutils import make_call_function
    from .testutils import make_make_function
    from .testutils import transform, assert_equal_py

    assert_equal_py(
        """\
{x: 1 for x in ({y: 2 for y in [1, 2, 3]}, None, 4)}
""",
        transform(
            """\
{x: 1 for x in ({y: 2 for y in [1, 2, 3]}, None, 4)}
"""))


# Generated at 2022-06-12 03:36:58.154776
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict, Name, Num, Load, parse
    from typed_astunparse import dump

    d = Dict(keys=[None, Name(id='a', ctx=Load()), Name(id='b', ctx=Load())],
             values=[Dict(keys=[Num(n=0), Num(n=1)], values=[Num(n=0), Num(n=1)]),
                     Name(id='d1', ctx=Load()),
                     Name(id='d2', ctx=Load())])
    exp = parse('''
_py_backwards_merge_dicts([dict({0: 0, 1: 1}), d1, dict({2: 2, 3: 3})], d2)
''')

# Generated at 2022-06-12 03:37:05.574189
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
    {1: 1,
     **dict_a,
     2: 2,
     **dict_b,
     3: 3,
     **dict_c,
     4: 4}
    """
    node = ast.parse(source)
    expected_node = ast.parse("""
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b, dict_c)
    """)
    DictUnpackingTransformer().visit(node)
    assert node == expected_node

# Generated at 2022-06-12 03:37:14.843775
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
    dict0 = dict(a=1, b=2)
    dict1 = dict(c=3, d=4)
    final_dict = {5:5, **dict0, **dict1, 6:6}
    """
    expected = """
    dict0 = dict(a=1, b=2)
    dict1 = dict(c=3, d=4)
    final_dict = _py_backwards_merge_dicts(
        [
            {5: 5},
            {'a': 1, 'b': 2},
            _py_backwards_merge_dicts(
                [
                    dict1,
                    {6: 6}
                ]
            )
        ]
    )
    """
    transformer = DictUnpackingTransformer()
    result = transformer.visit

# Generated at 2022-06-12 03:37:24.672568
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse, dump
    code = """
import logging

logging.debug({'name': 'argv', **{'kwarg': 'kwarg_value'}, 'argv': 'argv_value'})
    """

    module = parse(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(module)
