

# Generated at 2022-06-12 03:28:57.692443
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from copy import deepcopy


# Generated at 2022-06-12 03:29:08.413138
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse, dump
    # type: str -> ast.AST
    parse_tree = parse("{1: 1, 2: 2, **{3: 3}, 4: 4}")

    transformer = DictUnpackingTransformer()
    transformer.visit(parse_tree)
    expected_tree = parse("_py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3}], {4: 4})")
    assert dump(parse_tree) == dump(expected_tree)

    parse_tree = parse("{1: 1, **{2: 2}, 3: 3, **{4: 4}}")
    transformer = DictUnpackingTransformer()
    transformer.visit(parse_tree)

# Generated at 2022-06-12 03:29:15.894570
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    program = '''{key: value for key, value in dict_a.items()}'''
    original_tree = ast.parse(program)
    DictUnpackingTransformer().visit(original_tree)
    code = compile(original_tree, '<string>', 'exec')
    local_vars = {'dict_a': dict(a=1, b=2)}
    exec(code, local_vars)
    assert {'a': 1, 'b': 2} == local_vars['_py_backwards_merge_dicts'](
        [], dict_a)

# Generated at 2022-06-12 03:29:23.451760
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:29:32.796814
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    from ..utils.codegen import to_source
    from astor import to_source
    import ast

    snippet = """\
{1: 1, 2: 2, 3: 3, **{4: 4, 5: 5}}
"""
    expected_result = """\
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, {4: 4, 5: 5}])
"""

    class ExampleTransformer(DictUnpackingTransformer):
        def visit_Dict(self, node: ast.Dict):
            return super().visit_Dict(node)

    tree = ast.parse(snippet)
    transformed = ExampleTransformer().visit(tree)
    result = to_source(transformed).strip()
    assert result == expected_result

# Generated at 2022-06-12 03:29:42.402419
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import _compile
    from .. import _meta
    from .test_BaseNodeTransformer import test_BaseNodeTransformer_visit_Dict

    source = """
        {
            1: 1,
            **a,
            b: 1,
            **c
        }
    """

    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}, a, {'b': 1}], c)
    """

    def _compile_and_run(source: str, locals: dict):
        code = _compile(source)

# Generated at 2022-06-12 03:29:51.601413
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import cast, Union

    from typed_ast import ast3 as ast

    from .base import BaseNodeTransformer
    from ..utils.tree import python_to_ast
    from ..utils.snippet import snippet

    @snippet
    def test_non_unpacking():
        {1: 2, 3: 4}

    @snippet
    def test_unpacking():
        {1: 2, **{3: 4}}

    @snippet
    def test_non_unpacking_with_unpacking():
        {1: 2, 3: 4, **{5: 6}}

    @snippet
    def test_unpacking_with_non_unpacking():
        {1: 2, **{3: 4}, 5: 6}


# Generated at 2022-06-12 03:30:01.689664
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tst_utils import assert_ast_ok, parse_ast_pandas
    from .refactoring_tools import RefactoringTool
    from .extract_refactorings import EXTRACT_REFACTORINGS
    

# Generated at 2022-06-12 03:30:07.513761
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None

    # Arrange
    # Act
    transformer = DictUnpackingTransformer()
    assert str(
        transformer.visit(
            ast.parse('''
            {1: 1, **dict_a}
        ''')
        )
    ) == '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''



# Generated at 2022-06-12 03:30:17.909381
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    unit = ast.parse("""x = {1: 2, 3: 4, **a, 5: 6, **b, 7: 8}""")
    unit = DictUnpackingTransformer().visit(unit) # type: ignore
    tree = ast.dump(unit)


# Generated at 2022-06-12 03:30:31.612521
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from ..utils.tree import repr_ast
    from .helper_funcs import get_only_result

    code = "def foo(x):\n" \
           "    try: { 1: x, 2: x + 1, **bar, 4: x + 2 }\n" \
           "    except ValueError: pass"

# Generated at 2022-06-12 03:30:41.795300
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    asttransformer_module = ast.parse(merge_dicts.get_body())  # type: ignore
    code = '''
    def func(a):
        return {"b": 3, **a}
    '''
    expected = '''
    def func(a):
        return _py_backwards_merge_dicts([{'b': 3}], a)
    '''
    expected_ast = ast.parse(expected)  # type: ignore

    m = ast.parse(code)  # type: ignore
    node = m.body[0]
    assert isinstance(node, ast.FunctionDef)
    node = node.body[0]
    assert isinstance(node, ast.Return)

    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)

    assert transformer._

# Generated at 2022-06-12 03:30:51.298165
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    snippet1 = '{1: 1, **dict_a}'
    snippet2 = '{1: 1, **dict_a, 2: 2, **dict_b}'
    snippet3 = '{1: 1, **dict_a, **dict_b}'
    snippet4 = '{1: 1, **dict_a, 2: 2}'
    snippet5 = '{1: 1, 2: 2, **dict_b}'

    snippets = [snippet1, snippet2, snippet3, snippet4, snippet5]
    for snippet in snippets:
        tree = ast.parse(snippet)
        transformer = DictUnpackingTransformer()
        transformed = transformer.visit(tree)
        assert transformer._tree_changed



# Generated at 2022-06-12 03:30:58.679802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_astunparse
    node = ast.parse("{1: 1, 2: 2, **dict_a, 3: 3}").body[0]
    result = DictUnpackingTransformer().visit(node)
    expected = ast.parse(  # noqa: E501
        "_py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}])")
    assert typed_astunparse.unparse(result) == typed_astunparse.unparse(expected)  # noqa: E501

# Generated at 2022-06-12 03:31:08.051268
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .fixtures.base_classes import BaseNodeTransformerTestCase
    from ..utils.pytree import dump
    from ..utils.source import source_to_unicode
    
    
    source = source_to_unicode("{'a': 1, **b, None: 2, None: 3, **c, **d}")
    expected_source = source_to_unicode('''
    def _py_backwards_merge_dicts(dicts):
      result = {}
      for dict_ in dicts:
        result.update(dict_)
      return result


    _py_backwards_merge_dicts([{'a': 1}, b, dict(None=2), dict(None=3), c], d)
    ''')
    tree = ast.parse(source)
    
    Dict

# Generated at 2022-06-12 03:31:18.724918
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformerTestCase

    class DictUnpackingTransformerTestCase(BaseNodeTransformerTestCase):
        transformer = DictUnpackingTransformer

    # Transformer:
    #     {1: 1, 2: 2, **{1: 1, 2: 2, **{1: 1, 2: 2}}, 3: 3}
    # To:
    #     {1: 1, 2: 2, 3: 3, **_py_backwards_merge_dicts([{}, {1: 1, 2: 2, **{1: 1, 2: 2}}], {1: 1, 2: 2})}

# Generated at 2022-06-12 03:31:25.489435
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import sys
    import os
    from .utils import compile_snippet, run_python_snippet
    from io import StringIO

    # Setup
    out = StringIO()
    sys.stdout = out

    # Test
    code = "print({1: 1, **{2: 2, 3: 3}})"
    expected = \
"""def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

print(_py_backwards_merge_dicts([{1: 1}], {2: 2, 3: 3}))
"""

    assert compile_snippet(code, DictUnpackingTransformer) == expected
    run_python_snippet(expected)
    assert out.get

# Generated at 2022-06-12 03:31:27.497624
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast
    from ..testing.transform import assert_transform


# Generated at 2022-06-12 03:31:38.325944
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert str(DictUnpackingTransformer().visit(
        ast.parse('''
            {'a': 1, 'b': 2}
        '''))).strip() == '''
            {'a': 1, 'b': 2}
        '''.strip()

    assert str(DictUnpackingTransformer().visit(
        ast.parse('''
            {'a': 1, **{'b': 2}}
        '''))).strip() == '''
            _py_backwards_merge_dicts(
                [{'a': 1}],
                {'b': 2})
        '''.strip()


# Generated at 2022-06-12 03:31:47.959137
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source_code = """
    a = {1: 1, **dict_a}
    b = {1: 1, 2: 2, **dict_a}
    c = {1: 1, **dict_a, **dict_b}
    d = {1: 1, 2: 2, **dict_a, **dict_b}
    """


# Generated at 2022-06-12 03:32:06.014277
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astor.code_gen import to_source
    from ..utils import source
    from ..testing.utils import fix_whitespace
    
    src = source("""
        from _py_backwards_merge_dicts import _py_backwards_merge_dicts
        
        x = {1: 2, **dict_}
        """)
    
    node = source_to_ast(src)
    result = DictUnpackingTransformer().visit(node)
    result = to_source(result)
    
    expected = source("""
        from _py_backwards_merge_dicts import _py_backwards_merge_dicts
        
        x = _py_backwards_merge_dicts([{1: 2}], dict_)
        """)
    
    assert fix_

# Generated at 2022-06-12 03:32:15.446858
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from tests.utils import get_changed_node

    DictUnpackingTransformer.tree_changed = False

    transformer = DictUnpackingTransformer()
    node = ast.parse('({1: 1, 2: 2, **dict_a})')
    node = transformer.visit(node)
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert transformer.tree_changed

    changed_node = get_changed_node(node)
    assert isinstance(changed_node, ast.Call)
    assert changed_node.func.id == '_py_backwards_merge_dicts'
    assert len(changed_node.args) == 1
    assert isinstance(changed_node.args[0], ast.List)

# Generated at 2022-06-12 03:32:21.860624
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse(
        '{1: 1, **a, 2: 2, **b, 3: **c}'
    ).body[0].value

    expected_node = ast.parse(
        '_py_backwards_merge_dicts([{1: 1, 2: 2}, a, b, {3: c}])'
    ).body[0].value

    node = DictUnpackingTransformer().visit(node)  # type: ignore
    assert node == expected_node

# Generated at 2022-06-12 03:32:32.285310
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    source = """dict_a = {1: 2}
dict_b = {3: 4}
dict_c = {5: 6}
dict_d = {**dict_a}
dict_e = {**dict_a, **dict_b, **dict_c}
dict_f = {**dict_e, 7: 7, **dict_d}
dict_g = {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
dict_h = {None: 1, 2: 2, None: 3, 4: 4, None: 5, 6: 6}"""

# Generated at 2022-06-12 03:32:39.550828
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Tests if visit_Dict works as expected."""
    code = '''
    {1: 34, None: {'a': 1, 'b': dict_a}, 2: dict_b, None, None, dict_c}
    '''
    expected_code = '''
    _py_backwards_merge_dicts([dict({1: 34}), {'a': 1, 'b': dict_a}], dict_b, dict_c)
    '''
    node = ast.parse(code)
    expected = ast.parse(expected_code)
    transformer = DictUnpackingTransformer()
    transformer.visit(node)
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-12 03:32:47.819349
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tester import NodeTestCase
    from ..utils.codegen import to_source
    from .syntax_unpacking import SyntaxUnpackingTransformer

    code = '{1: 1, **dict_a, 2: 2, **dict_b}'
    expected = r"""
    _py_backwards_merge_dicts(
      [dict(1, 1), dict_a],
      2, 2,
      dict_b)
    """
    tree = SyntaxUnpackingTransformer().visit(ast.parse(code))
    tree = DictUnpackingTransformer().visit(tree)
    assert to_source(tree) == expected



# Generated at 2022-06-12 03:32:53.195608
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.snapshot import snapshot
    from .print import PrinterVisitor

    src = """\
{1: 1, 2: 2, None: 3, 4: 4, **{4: 4, None: 5, 6: 6}, 7: 7}
"""
    tree = source_to_ast(src)
    DictUnpackingTransformer().visit(tree)
    print(PrinterVisitor().visit(tree))
    snapshot.assert_match(tree)

# Generated at 2022-06-12 03:33:02.886899
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor  # type: ignore
    import astunparse  # type: ignore

    def test(source, expected):
        result = astunparse.unparse(
            ast.fix_missing_locations(
                DictUnpackingTransformer().visit(
                    ast.parse(source))))
        assert result == expected

    test('''{1: 1, **dict_a}''', '''_py_backwards_merge_dicts([{1: 1}], dict_a)\n''')
    test('''{1: 1, **dict_a, **dict_b}''',
         '''_py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)\n''')

# Generated at 2022-06-12 03:33:06.848662
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from pytest import raises
    from ..utils.builder import build

    builder = build(DictUnpackingTransformer)
    with raises(AssertionError):
        builder('''
        {None: "a"}
        ''')

    builder('''
    {1: 1, **dict_a}
    ''') == '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

# Generated at 2022-06-12 03:33:12.244234
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    class Visitor(ast.NodeVisitor):
        def __init__(self, *args, **kwargs):
            self.nodes = []
            super().__init__(*args, **kwargs)

        def visit_Module(self, node):
            self.nodes.append(node)
            super().generic_visit(node)

    node = ast.parse("""
    dict_a = dict(a=1, b=2)
    dict_b = dict(c=1, d=2)
    dict_c = dict(e=1, f=2)

    x = {1: 1, **dict_a, **dict_b}
    """)
    v = Visitor()
    v.visit(node)

# Generated at 2022-06-12 03:33:42.657673
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for method visit_Dict of class DictUnpackingTransformer
    """
    # Arrange
    dict_unpacking_transformer = DictUnpackingTransformer()


# Generated at 2022-06-12 03:33:52.934519
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    # Given
    tree = ast.parse('''
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b}
    ''')

    # When
    DictUnpackingTransformer().visit(tree)
    source = tree.body[1].value.args[0].elts

    # Then
    assert len(source) == 3

    assert '1' in source[0].keys[0].s
    assert '2' in source[0].keys[1].s
    assert '3' in source[0].keys[2].s

    assert '1' in source[0].values[0].s
    assert '2' in source[0].values[1].s
    assert '3' in source[0].values[2].s


# Generated at 2022-06-12 03:34:03.236155
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from astmonkey import visitors
    from ..test_utils import assert_ast_eq

    code1 = """
{**dict_a}
"""
    expected1 = """
_py_backwards_merge_dicts([], dict_a)
"""
    code2 = """
{'foo': foo, **dict_a, 'bar': 'bar', **dict_b, 'baz': baz}
"""
    expected2 = """
_py_backwards_merge_dicts([{'foo': foo}, {'bar': 'bar'}, {'baz': baz}], dict_a, dict_b)
"""

    for code in [code1, code2]:
        tree = ast.parse(code)
        DictUnpackingTransformer().visit(tree)
        code_transformed = ast

# Generated at 2022-06-12 03:34:08.137936
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Runner(object):
        def run(self, code: str) -> None:
            module = ast.parse(code)
            transformer = DictUnpackingTransformer()
            transformer.visit(module)
            assert transformer._tree_changed

    Runner().run("{1: 2, **{'a': 'b'}}")

# Generated at 2022-06-12 03:34:14.764216
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast, astunparse
    from ..utils.tree import tree_equals
    from ..utils.snippet import snippet

    @snippet
    def s():
        class A:
            def __init__(self, a, b, c):
                pass
        x = A(1, 2, 3)
        y = A(1, 2, 3, **{'c': 4})

    before = ast.parse(s.get_body()).body[1]
    after = ast.parse(s.get_source()).body[1]
    assert tree_equals(after, DictUnpackingTransformer().visit(before))

# Generated at 2022-06-12 03:34:22.538917
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse('{a: 1, b: 2, **c}')
    visitor = DictUnpackingTransformer()
    visitor.visit(tree)
    assert ast.dump(tree) == (
        'Module(body=[_py_backwards_merge_dicts([Dict(keys=[Name(id=\'a\', ctx=Load)], values=[Num(n=1)]), '
        'Dict(keys=[Name(id=\'b\', ctx=Load)], values=[Num(n=2)])], c)])'
    )



# Generated at 2022-06-12 03:34:32.682913
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse

    class MockTransformer:
        def __init__(self):
            self._tree_changed = False

        def generic_visit(self, node):
            return node

    def test(code: str, expected: str):
        output = parse(code)  # type: ignore
        transformer = DictUnpackingTransformer()
        transformer.visit(output)
        assert expected == output.body[0].value.args[0].elts[0].value.keys[0].value

    test('{1: 1, **dict_a}', '1')
    test('{1: 1, **dict_a, **dict_b}', '1')
    test('{1: 1, 2: 2, **dict_a, **dict_b}', '1')

# Generated at 2022-06-12 03:34:40.284520
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    import textwrap
    from nuitka.nodes.AssignNodes import StatementAssignmentVariable
    from nuitka.tree.Building import parseTree
    from nuitka.tree.Extractions import getStatementsFromRoot
    from nuitka.importing.Importing import extractImportsFromTree

    class TestCase(unittest.TestCase):
        def assertEqual(self, f, s):
            if isinstance(s, list):
                self.assertEqual(len(s), len(f))
                for x, y in zip(s, f):
                    self.assertEqual(x, y)
                return
            elif isinstance(s, tuple):
                self.assertEqual(len(s), len(f))

# Generated at 2022-06-12 03:34:48.209411
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
        {1: 2, **dict_a, **dict_b, 3: 3, **dict_c, None: 4, **dict_d}
    """
    expected_code = """
        _py_backwards_merge_dicts(
            [{3: 3}],
            _py_backwards_merge_dicts(
                [dict({1: 2}, **dict_a), dict({None: 4}, **dict_d)],
                _py_backwards_merge_dicts([], dict_b),
            ),
            _py_backwards_merge_dicts([], dict_c),
        )
    """
    assert DictUnpackingTransformer.run(code) == expected_code

# Generated at 2022-06-12 03:34:52.778584
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.codegen import code
    from .. import test_utils

    source = """
        x = {
            1: 1,
            **dict_a
        }
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    actual = test_utils.transform(DictUnpackingTransformer, source)
    assert code(expected) == code(actual)

# Generated at 2022-06-12 03:35:38.964338
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import compare_ast, unparse

    root = ast.parse('{1: 2, **{a: b}, 3: 4, **{c: d}}')
    expected = ast.parse(
        '_py_backwards_merge_dicts([{1: 2}, {3: 4}], {a: b}, {c: d})')

    transformer = DictUnpackingTransformer()
    transformer.visit(root)
    compare_ast(expected, root)
    assert unparse(expected) == unparse(root)

# Generated at 2022-06-12 03:35:49.018792
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import compare_ast

    statements = [
        ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                 values=[ast.Num(n=1),
                         ast.Dict(keys=[ast.Num(n=3), None],
                                  values=[ast.Num(n=1),
                                          ast.Dict(keys=[ast.Num(n=4), None],
                                                   values=[ast.Num(n=1),
                                                           ast.Num(n=4)])]),
                         ast.Num(n=4)]),
        ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)])
    ]

# Generated at 2022-06-12 03:35:54.792243
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse("""\
    {1: 1, **dict_a}
    """)

    expected = ast.parse("""\
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)

    transformer = DictUnpackingTransformer()
    node = transformer.visit(node)

    assert transformer._tree_changed
    assert ast.dump(node) == ast.dump(expected)



# Generated at 2022-06-12 03:36:00.540989
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = ("{1: 2, **{3: 4}}")

    expected = ("_py_backwards_merge_dicts([{1: 2}], {3: 4})")

    nodes = ast.parse(src)
    transformer = DictUnpackingTransformer()
    actual = transformer.visit(nodes)

    assert ast.dump(actual, annotate_fields=False) == expected

# Generated at 2022-06-12 03:36:04.523824
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()
    result = t.visit_Dict(ast.parse('{1: 1, **a}'))
    assert ast.dump(result) == '_py_backwards_merge_dicts([{1: 1}], a)'


# Generated at 2022-06-12 03:36:12.857060
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    s = source('''
{1:1, **{1:1}, 2:2, **{2:2}, **{3:3}}
    ''')
    module = ast.parse(s)

    transformed = DictUnpackingTransformer().visit(module)
    assert transformed is not None
    expected = source('''
_py_backwards_merge_dicts([{1:1}, {2:2}], {1:1}, {2:2}, {3:3})
    ''')
    assert expected == transformed

# Generated at 2022-06-12 03:36:20.132368
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()
    input = ast.parse("{**a, 1: 1, 2: 2, **b}")
    ast.fix_missing_locations(input)
    output = ast.parse("_py_backwards_merge_dicts([dict({1: 1, 2: 2})], a, b)")
    ast.fix_missing_locations(output)
    assert ast.dump(dut.visit(input), annotate_fields=False) \
        == ast.dump(output, annotate_fields=False)

# Generated at 2022-06-12 03:36:26.410277
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ignore_ws, load_example
    from . import Py37Parser

    test_cases = (
        '{**{"a": 1}}',
        '{**a, **{"b": 2}}',
        '{**a, **{"b": 2}, **c}',
        '{"b": 2, **c, **a}',
        '{"a": 1, **{"b": 2, "c": 3}}',
        '{"a": 1, **{"a": 2}}',
        '{"a": 1, **{"b": 2}, "a": 3}',
        '{"a": 1, **{"b": 2}, **{"a": 3}, **{"b": 4}, "a": 5}',
    )


# Generated at 2022-06-12 03:36:34.995495
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    node = ast.parse('''
        {
            1: 1,
            **kwargs,
            2: 2,
            **kwargs,
        }
    ''')
    actual_tree = transformer.visit(node)  # type: ignore
    assert transformer._tree_changed
    expected_tree = ast.parse('''
        _py_backwards_merge_dicts(
            [{1: 1, 2: 2}],
            kwargs,
            kwargs)
    ''')
    assert ast.dump(actual_tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 03:36:44.726676
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..test import parse_and_compile

    snippet = '''
        {1:1, 2:2, **{3:3}}
        {1:1, None:None, 2:2, None:None, 3:3}
        {1:1}
        {**{1:1}}
        {**{1:1}, **{}}
        {None:None, **{1:1}, **{2:2}, None:None, **{}, None:None}
    '''