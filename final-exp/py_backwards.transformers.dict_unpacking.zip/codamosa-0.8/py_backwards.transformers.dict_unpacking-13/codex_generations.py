

# Generated at 2022-06-12 03:29:04.325754
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import compile_isolated
    from ..tests.utils import parse_ast_unparse

    code = '''{1: 2, **{2: 3}, 3: 4, **{}, **{5: 6}}'''
    expected = '''
    _py_backwards_merge_dicts([{1: 2}, {3: 4}], {2: 3}, {}, {5: 6})
    '''
    ast_node = parse_ast_unparse(code)
    transformed = compile_isolated(ast_node, 'name', 'exec')
    assert transformed == parse_ast_unparse(expected)

# Generated at 2022-06-12 03:29:13.916667
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import Source
    from ..utils.ast_compare import ast_compare
    

# Generated at 2022-06-12 03:29:22.255829
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    code = '''{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}'''
    tree = ast.parse(code)
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert tree.body[1].value.func.id == '_py_backwards_merge_dicts'

    keys = [elts.keys[0].n for elts in tree.body[1].value.args[0].elts]
    assert keys == [1, 2, 3]

    tree = ast.parse('{0: 1, 2: 2}')
    transformer.visit(tree)

    assert transformer._tree_changed is False



# Generated at 2022-06-12 03:29:32.469261
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from textwrap import dedent
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_AST_str


# Generated at 2022-06-12 03:29:37.769755
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast import parse_ast
    from ..utils.tree import ast_equal

    trans = DictUnpackingTransformer()
    d = parse_ast("{1: 1, **dict_a}")
    expecting = parse_ast("_py_backwards_merge_dicts([{1:1}], dict_a)")
    assert ast_equal(trans.visit(d), expecting)



# Generated at 2022-06-12 03:29:46.528575
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def run_test(input_code, expected_code):
        node = ast.parse(input_code)
        DictUnpackingTransformer().visit(node)
        actual_code = astor.to_source(node)
        assert actual_code == expected_code

    run_test('{1: 1, **dict_a}',
             '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    run_test('{1: 1, *dict_a}',  # incorrect unpacking, ignored
             '{1: 1, *dict_a}')
    run_test('{1: 1, None: 1, **dict_a}',
             '_py_backwards_merge_dicts([{1: 1}, 1], dict_a)')
    run_test

# Generated at 2022-06-12 03:29:56.587611
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()

    assert ast.dump(ast.parse('{1: "a", 2: "b", **{"a": 3}, 3: "c", **{"b": 4}}')) == \
        ast.dump(t(ast.parse('dict(**_py_backwards_merge_dicts([{1: "a", 2: "b"}], {"a": 3}))\n'
                            'dict(**_py_backwards_merge_dicts([{"b": 4}]))')))

    assert ast.dump(ast.parse('{1: "a", 2: "b", 3: "c"}')) == \
        ast.dump(t(ast.parse('{1: "a", 2: "b", 3: "c"}')))

# Generated at 2022-06-12 03:30:04.718153
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3
    from .test_utils import round_trip, serialize_Node, strip_indent
    module_original = strip_indent('''\
        {
            1: 1,
            **{},
            **dict_src,
            **dict_src,
            **dict_src,
            2: 2,
            **dict_src,
            3: 3,
            **dict_src,
        }
    ''')

# Generated at 2022-06-12 03:30:11.880658
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}')
    expected = ast.parse('''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    ''')
    result = transformer.visit(node)
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 03:30:22.283065
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import test_helpers
    from ..utils.test_helpers import assert_string_ast

    cases = [
        ("{1: 2, **{3: 4}}",
         "_py_backwards_merge_dicts([{1: 2}], {3: 4})"
         ),
        ("{1: 2, **{3: 4}, 5: 6, **{7: 8, **{9: 10}}}",
         "_py_backwards_merge_dicts([{1: 2}, {5: 6}], _py_backwards_merge_dicts([{7: 8}], {9: 10})"
         ),
    ]
    exprs = [test_helpers.build_expr(expr) for _, expr in cases]

# Generated at 2022-06-12 03:30:34.590733
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.Module(body=[merge_dicts.get_body_node(), ast.Expr(
        value=ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'),
                       args=[ast.List(elts=[])],
                       keywords=[]))])
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(node)
    assert transformed.body == [ast.Expr(value=ast.Call(func=ast.Name(id='_py_backwards_merge_dicts'),
                       args=[ast.List(elts=[])],
                       keywords=[]))]


# Generated at 2022-06-12 03:30:43.820292
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # "Merge dicts" tests
    assert '' == transform('')
    assert '{1: 2}' == transform('{1: 2}')
    assert '_py_backwards_merge_dicts([{1: 2}])' == \
        transform('{1: 2, **foo}')

    assert '_py_backwards_merge_dicts([{1: 2}, {3: 4}])' == \
        transform('{1: 2, **foo, **bar}')
    assert '_py_backwards_merge_dicts([{1: 2}, {3: 4}, {5: 6}])' == \
        transform('{1: 2, **foo, **bar, **baz}')


# Generated at 2022-06-12 03:30:50.067260
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source = """\
{'a': 1, 'b': 2, **dict_a, **dict_b}
"""
    expected_result = """\
_py_backwards_merge_dicts([{'a': 1, 'b': 2}, ], dict_a, dict_b)
"""

    result = transformer.run(source)
    assert result == expected_result



# Generated at 2022-06-12 03:30:52.523024
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .samples.dict_unpacking import before, after
    transformer = DictUnpackingTransformer()
    assert transformer.visit(before) == after

# Generated at 2022-06-12 03:31:01.458031
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    assert transformer.target == (3, 4)

    node1 = ast.parse("""\
{**dict_a, **dict_b, **dict_c}
    """)  # type: ast.Module
    expected1 = ast.parse("""\
_py_backwards_merge_dicts([dict_a, dict_b, dict_c])
    """)  # type: ast.Module

    assert transformer.visit(node1) == expected1

    node2 = ast.parse("""\
{1: 2, 3: 4, **dict_a, **dict_b}
    """)  # type: ast.Module

# Generated at 2022-06-12 03:31:09.571369
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """\
        {1: 1, 2: 2, **{3: 3, 4: 4}, 4: 5}
        dict_a = {3: 3}
        a = {1: 2, 3: 4, **{7: 9}, **dict_a}
    """
    expected = """\
        _py_backwards_merge_dicts([{1: 1, 2: 2, 4: 5}], dict({3: 3, 4: 4}))
        dict_a = {3: 3}
        a = _py_backwards_merge_dicts([{1: 2, 3: 4, 7: 9}], dict_a)
    """
    trf = DictUnpackingTransformer()
    actual = trf.transform_code(source)
    assert actual == expected

# Generated at 2022-06-12 03:31:15.853511
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    kwargs = dict(arg1=1, arg2=2, arg3=3, arg4=4)
    code = '{**kwargs, 0: 1, 1: 2}'
    code_transformed = '_py_backwards_merge_dicts([{0: 1, 1: 2}], kwargs)'
    _test_transformer(DictUnpackingTransformer, code, code_transformed, **kwargs)

# Generated at 2022-06-12 03:31:24.106660
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:31:32.982118
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tst_visitor import TSTVisitor

    input_ = '{1: 2, 3: 4, **{5: 6, 7: 8}}'
    output_ = '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result
_py_backwards_merge_dicts([{1: 2, 3: 4}, {5: 6, 7: 8}])'''

    transformer = DictUnpackingTransformer()
    result = TSTVisitor(transformer).visit_source(input_)
    assert output_ == result

# Generated at 2022-06-12 03:31:43.188234
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.dump import dump_prettily

    code_template = '''
    def f(a, b, c):
        return {
            {a}
            {b}
            {c}
        }
    '''


# Generated at 2022-06-12 03:31:59.322311
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..tests.utils import parse_ast
    from ..utils.compat import ast_unparse
    code_in = """
        {1: 1, **dict_a}
    """
    code_out = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code_in)
    DictUnpackingTransformer().visit(tree)
    assert ast_unparse(tree) == code_out

# Generated at 2022-06-12 03:32:05.043883
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.tree import transform
    from ..utils.ast_builder import build_ast

    code = '''{1: 1, **dict_a}'''
    tree = build_ast(code)
    DictUnpackingTransformer.run(tree)
    assert astor.to_source(tree) == '''
_py_backwards_merge_dicts([{1: 1}], dict_a)
'''.strip()



# Generated at 2022-06-12 03:32:14.326875
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    actual = ast.parse('''
{
    1: 2,
    'a': 'b',
    None: _dict_
}
''', '<test>', 'eval')  # type: ast.Expression
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(elts=[
                ast.Dict(keys=[
                    ast.Num(n=1),
                    ast.Str(s='a')],
                     values=[
                    ast.Num(n=2),
                    ast.Str(s='b')])]),
            ast.Name(id='_dict_')],
        keywords=[])
    result = DictUnpackingTransformer()(actual)  # type: ast.Expression

# Generated at 2022-06-12 03:32:23.733558
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    import astor  # type: ignore
    from ..utils.tree import unparse
    from ..compile import compile_source
    from ..utils.source import insert_at as insert_at_source

    source = """
    x = dict(
        a=1,
        **{b: 3},
        c=2,
        **{d: 4},
        e=5,
        **{f: 6}
    )
    """

    tree = ast.parse(source)
    tree = DictUnpackingTransformer().visit(tree)

    # TODO: merge with split_by_None and prepare_splitted

# Generated at 2022-06-12 03:32:33.760333
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..transformer import BaseTransformer, TransformerRecursionError
    from ..converter import BaseConverter
    from ..utils.source import Source
    from ..utils.tree import dump
    
    class TestTransformer(BaseTransformer):
        transformer = TransformerRecursionError(DictUnpackingTransformer)
    
    class TestConverter(BaseConverter):
        transformer_cls = TestTransformer
    
    source_contents = \
        """
        def f():
            return {1: 1, **{2: 2}, 3: 3, **{4: 4}}
        """
    

# Generated at 2022-06-12 03:32:42.107994
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .testing_utils import assert_transformed_ast_equal
    from typed_ast import ast3 as ast

    # simple test
    code = """
    d = {1: 1, **{2: 2, 3: 3}}
    """
    expected = """
    d = _py_backwards_merge_dicts([{1: 1}], {2: 2, 3: 3})
    """
    assert_transformed_ast_equal(code, expected, DictUnpackingTransformer)

    # test with non-unpacking dict
    code = """
    d = {1: 1, 2: 2, **{3: 3, 4: 4}}
    """

# Generated at 2022-06-12 03:32:50.575345
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import Tree, generate_source
    from ..transforms import DictUnpackingTransformer
    from .transformer import TransformerContext
    import ast

    source = '''\
{1: 1, **x, 2: 2, **y}'''

    tree = Tree.parse(source)  # type: ignore
    transformer = DictUnpackingTransformer()
    context = TransformerContext(tree)
    tree = transformer.visit_tree(context)
    source_ = generate_source(tree)
    expected = '''\
_py_backwards_merge_dicts(
    [
        dict(1=1),
        ],
    x,
    dict(2=2),
    y)'''
    assert source_ == expected

    dct = ast.parse(source).body[0].value
    transformer

# Generated at 2022-06-12 03:32:55.427867
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    transformer = DictUnpackingTransformer()
    source = '{1: 1, **dict_a, 2: 2}'
    desired = '_py_backwards_merge_dicts([{1: 1}, dict_a], {2: 2})'

    tree = ast.parse(source)
    transformer.visit(tree)
    result = astor.to_source(tree)
    assert result.strip() == desired


# Generated at 2022-06-12 03:33:05.127882
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Test(DictUnpackingTransformer):
        def __init__(self, pairs: Iterable[Pair]):
            self._pairs = pairs

        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            node.keys, node.values = zip(*self._pairs)
            return super().visit_Dict(node)

    pairs = [
        (None, ast.List(elts=[ast.Num(1), ast.Num(2)])),
        (ast.Str(s='a'), ast.Num(3)),
        (ast.Str(s='b'), ast.Num(4)),
        (None, ast.Name(id='c')),
    ]
    node = ast.Dict(keys=[None], values=[None])

# Generated at 2022-06-12 03:33:09.241941
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from .base import BaseNodeTransformer
    
    source = '{1: 1, **dict_a}'
    expected_source = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    
    assert astor.to_source(node).strip() == expected_source

# Generated at 2022-06-12 03:33:33.110463
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    # Test for case when there is no unpacking
    node = ast.parse('{}')
    expected = ast.parse('{}')
    transformer.visit(node)
    assert node == expected

    # Test for case when there is unpacking
    node = ast.parse('{None: None, 1:1}')
    expected = ast.parse(
        '_py_backwards_merge_dicts([{}, {}], 1)')
    transformed = transformer.visit(node)
    assert transformed == expected

# Generated at 2022-06-12 03:33:40.424227
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_setup import setup
    from typed_ast.ast3 import parse

    snippet = '{1: 1, **a}'
    node = parse(snippet)

    DictUnpackingTransformer(setup()).visit(node)
    assert node.body[0].value.args[0].elts[0].keys[0].n == 1
    assert node.body[0].value.args[0].elts[0].values[0].n == 1
    assert node.body[0].value.args[0].elts[1].id == 'a'

# Generated at 2022-06-12 03:33:49.965542
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astor import dump_tree
    from .unittest_tools import assert_program_equal

    source = """
    class A:
        def f(self):
            d = {1: 1, **dict_a, **dict_b, 2: 2, **dict_c, 3: 3}
            return d
    """
    expected = """
    class A:
        def f(self):
            d = _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
            return d
    """
    actual = dump_tree(DictUnpackingTransformer().visit(ast.parse(source)))
    assert_program_equal(expected, actual)



# Generated at 2022-06-12 03:33:57.014775
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    from .common import common as c

    source_code = "def foo(x, y):\n foo(**{'b': 2}, **{'a': 1})"
    module = parse(source_code)
    DictUnpackingTransformer(c).visit(module)
    assert hasattr(module.body[0].body[0].value, 'args')
    assert module.body[0].body[0].value.func.id == '_py_backwards_merge_dicts'

# Generated at 2022-06-12 03:34:02.517189
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tester import assert_equal

    source = """d1 = {1: 1, 2: 2, **{"a": 3, **{"b": 4}}}"""
    expected = """d1 = _py_backwards_merge_dicts([{1: 1, 2: 2}, {"a": 3, "b": 4}])"""

    assert_equal(DictUnpackingTransformer, source, expected)

# Generated at 2022-06-12 03:34:12.396094
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...compiler.transformer import Context
    from ...compiler.testing import assert_source
    from ...compiler.testing import Problem, Location

    from .base import TransformerUnitTests, run_test_suite

    class Tests(TransformerUnitTests):
        transformer = DictUnpackingTransformer

        def test_compiles_dict_unpack(self):
            input = r'''
            _ = a = {1: 1, **{2: 2}}
            '''

# Generated at 2022-06-12 03:34:22.538407
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    node = ast.Dict(keys=[None, ast.Num(1), None, ast.Num(2), None],
                    values=[ast.Dict(keys=[ast.Num(1)], values=[ast.Num(2)]),
                            ast.Dict(keys=[ast.Num(1)], values=[ast.Num(2)]),
                            ast.Dict(keys=[ast.Num(1)], values=[ast.Num(2)]),
                            ast.Dict(keys=[ast.Num(1)], values=[ast.Num(2)]),
                            ast.Dict(keys=[ast.Num(1)], values=[ast.Num(2)])])
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert astor.to_source(result)

# Generated at 2022-06-12 03:34:30.222457
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''
{1: 2, 3: None, 4: 5, 6: None, 7: 8, 9: None, None: {1: 1}}
    '''
    expected_result = '''
_py_backwards_merge_dicts([{1: 1}, {1: 2, 3: None, 4: 5}, {7: 8}, {9: None}])
    '''
    expected_output = merge_dicts.get_body() + expected_result
    result = DictUnpackingTransformer()._test_transform(source)
    assert expected_output == result

# Generated at 2022-06-12 03:34:37.792704
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import compile_isolated
    from .. import parse

    tree = parse('''
        {1: 1, 2: 2, 3: 3, **dict4, 5: 5}
    ''')
    for version in (3, 4):
        code = compile_isolated(tree, target=(version, 0))._code
        print(code)
        assert '_py_backwards_merge_dicts' in code

    tree = parse('''
        foo({1: 1, 2: 2, 3: 3, **dict4, 5: 5})
    ''')
    for version in (3, 4):
        code = compile_isolated(tree, target=(version, 0))._code
        print(code)
        assert '_py_backwards_merge_dicts' in code


# Generated at 2022-06-12 03:34:46.569265
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    f = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4, **dict_c, 5: 5}
    """
    expected = """def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts([dict({1: 1, 2: 2}), dict_a, dict({3: 3}), dict_b, dict({4: 4}), dict_c, dict({5: 5})])
    """
    expected_tree = ast.parse(expected)
    tree = ast.parse(f)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-12 03:35:26.237237
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from . import DictUnpackingTransformer

    tree = ast.parse(
        '''
        def f():
            return {1: 2, **dict_a, 2: 3}
        ''')
    DictUnpackingTransformer().visit(tree)
    result = astor.to_source(tree)

# Generated at 2022-06-12 03:35:36.240178
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testutils import AssertAst, AssertSnippet
    code = (
        'a = {1: 1, **dict_a}\n'
        'b = {**dict_b, **{\'c\': None}, **dict_c}\n'
        'c = {}\n'
        'd = {**{}, 1: 2}\n'
    )
    expected = (
        '_py_backwards_merge_dicts([{1: 1}], dict_a)\n'
        '_py_backwards_merge_dicts([dict_b, {\'c\': None}], dict_c)\n'
        'dict()\n'
        '_py_backwards_merge_dicts([{1: 2}])\n'
    )
    AssertSnippet

# Generated at 2022-06-12 03:35:44.056150
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import unittest
    from . import _BaseTest

    class Test(unittest.TestCase, _BaseTest):
        transformer = DictUnpackingTransformer
        expects = merge_dicts() + """
_py_backwards_merge_dicts([{0: 1, 2: 3}], {4: 5})"""

        def test_in(self):
            src = """
{0: 1, 2: 3, **{4: 5}}"""
            self.compare(src)

    unittest.main()

# Generated at 2022-06-12 03:35:46.009570
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source  = """{1: 2, None: 10, 3: 4, None: 20, 5: 6}"""

# Generated at 2022-06-12 03:35:50.482050
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    before = ast.parse("""
        {1: 1, 2: 2, 3: 3, 4: 4, **a, 5: 5}
    """)
    after = ast.parse("""
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], a, {5: 5})
    """)
    assert before.body[0] == after.body[0]

# Generated at 2022-06-12 03:35:57.982391
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..testing_utils import assert_output
    input_ = '{1: 1, **dict_a}'
    expected_ = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    expected_code = merge_dicts.get_code() + expected_
    tree = ast.parse(input_)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    output_code = astor.to_source(tree).strip()
    assert_output(output_code, expected_code)

# Generated at 2022-06-12 03:36:07.497570
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    node = ast.parse("{1:a, 2:b, **{3:c, 4:d}, 5:e, 6:f, **{7:g, 8:h}}")
    expected = ast.parse("_py_backwards_merge_dicts([{1: a, 2: b, 5: e, 6: f}, {3: c, 4: d}, {7: g, 8: h}])")
    assert DictUnpackingTransformer().visit(node) == expected
    assert astor.to_source(DictUnpackingTransformer().visit(node)) \
           == astor.to_source(expected)
test_DictUnpackingTransformer_visit_Dict()

# Generated at 2022-06-12 03:36:11.237796
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 1, None: {2: 2}, 3: 3}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert transformer._tree_changed
    assert isinstance(result, ast.Call)

# Generated at 2022-06-12 03:36:22.041218
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast


# Generated at 2022-06-12 03:36:32.591156
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    code = """
            thing = {'a': 1, **y}
            """
    expected = """
               thing = _py_backwards_merge_dicts([{'a': 1}], y)
               """
    ast = source_to_ast(code)
    DictUnpackingTransformer().visit(ast)
    assert ast_to_source(ast) == expected

    code = """
            thing = {'a': 1, **y, **z}
            """
    expected = """
               thing = _py_backwards_merge_dicts([{'a': 1}], y, z)
               """
    ast = source_to_ast(code)
    DictUnpackingTransformer().visit(ast)

# Generated at 2022-06-12 03:37:29.383483
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    node_before = ast.parse("""
{
    1: 1,
    **{},
    **{1: 1},
    **{2: 2},
    **{2: 3},
    3: 3,
}
""".strip())
    node_after = ast.parse("""
_py_backwards_merge_dicts([dict({1: 1}), dict({2: 2}), dict({2: 3})],
                            dict({1: 1}))
""".strip())
    transformer = DictUnpackingTransformer()
    node_after = transformer.visit(node_before)
    assert node_before != node_after
    assert ast.dump(node_before, include_attributes=False) != ast.dump(node_after, include_attributes=False)

# Generated at 2022-06-12 03:37:36.614499
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_transform_result
    from textwrap import dedent
    
    source = dedent('''
        {1: 1}
        ''')

    expected = dedent('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([dict([(1, 1)])])
        ''').strip()

    assert_transform_result(DictUnpackingTransformer, source, expected)



# Generated at 2022-06-12 03:37:41.305271
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    def test(tree):
        assert isinstance(tree, ast.Module)
        assert tree.body[0].body[0].name == '_py_backwards_merge_dicts'

    tr = DictUnpackingTransformer()
    test(tr.visit(ast.parse('{}')))
    test(tr.visit(ast.parse('1')))



# Generated at 2022-06-12 03:37:48.782595
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import round_trip
    t = DictUnpackingTransformer()
    assert round_trip(t, """
        {1: 1, **dict_a}
    """) == """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    assert round_trip(t, """
        {1: 1, 2: 2, **dict_a}
    """) == """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """

    assert round_trip(t, """
        {**dict_a}
    """) == """
        dict_a
    """


# Generated at 2022-06-12 03:37:52.534910
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .fixtures import DictUnpackingTransformer_visit_Module as testcase
    testcase.run_in_out_test()
    #print('input',testcase.input)
    #print('expected',testcase.expected)
    #print('output',testcase.output)

# Generated at 2022-06-12 03:37:59.138575
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    P = DictUnpackingTransformer().visit_Dict

    assert P(ast.parse('{}').body[0]) == ast.parse('{}').body[0]

    assert P(ast.parse('{**x}').body[0]) == ast.parse('{}').body[0]

    assert P(ast.parse('{**x, **y, z: 1}').body[0]) == ast.parse(
        '_py_backwards_merge_dicts([], x, y, {z: 1})').body[0]

# Generated at 2022-06-12 03:38:08.751582
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse("{1: 1, **dict_a}")
    result = DictUnpackingTransformer().visit(node)

# Generated at 2022-06-12 03:38:16.584640
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    pairs = [(ast.Name(id='blah') if random.randint(0, 1) else None,
              ast.Str(s='a')) for _ in range(100)]
    splitted = transformer._split_by_None(pairs)
    for i, item in enumerate(splitted):
        if isinstance(item, list):
            assert sum(1 for key, _ in item if key is None) == 0
        else:
            assert i == 0 or isinstance(splitted[i - 1], list)
            assert i == len(splitted) - 1 or isinstance(splitted[i + 1], list)

# Generated at 2022-06-12 03:38:17.099777
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-12 03:38:24.510964
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    def do_test(tree: ast.Module, expected: ast.Module) -> None:
        assert DictUnpackingTransformer().visit(tree) == expected

    foo = ast.Name(id='foo', ctx=ast.Load())
    bar = ast.Name(id='bar', ctx=ast.Load())
    dict_b = ast.Name(id='dict_b', ctx=ast.Load())
    dict_a = ast.Name(id='dict_a', ctx=ast.Load())
