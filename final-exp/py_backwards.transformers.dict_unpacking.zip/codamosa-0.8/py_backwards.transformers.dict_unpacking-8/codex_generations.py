

# Generated at 2022-06-12 03:29:06.226399
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typing as t
    import astunparse
    import asttokens

    source = 'd = {1: 2, **{3: 4}, 5: 6, **{7: 8}, 9: 10}'
    lines = [x.strip() for x in merge_dicts.get_body().split('\n')]
    expected = '''
d = _py_backwards_merge_dicts([
    {1: 2},
    {3: 4},
    {5: 6},
    {7: 8},
],
    {9: 10})'''.lstrip().strip()
    expected = lines + expected.split('\n')

    console = asttokens.ASTTokens(source, parse=True)
    original = console.tree
    result = DictUnpackingTransformer().visit(original)
   

# Generated at 2022-06-12 03:29:15.941280
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    class DummyTransformer(BaseNodeTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node
    code = "\n".join([
        "def foo(a, b, c):",
        "    return {1:1, 2:2, **a, **b, 5:5, **c, 6:6}"])
    expected = "\n".join([
        "def foo(a, b, c):",
        "    return _py_backwards_merge_dicts([], {1: 1, 2: 2}, a, b, {5: 5}, c, {6: 6})"
    ])
    expected_ast = ast.parse(expected)
    code

# Generated at 2022-06-12 03:29:23.472341
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def test(stmt: ast.AST, expected: ast.AST) -> None:
        tr = DictUnpackingTransformer()
        result = tr.visit(stmt)
        assert ast.dump(result) == ast.dump(expected)
    

# Generated at 2022-06-12 03:29:24.486115
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass



# Generated at 2022-06-12 03:29:33.505093
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.codegen import to_source
    from ..editing import fix_missing_locations

    source = """
{1: 1, **{"a": b, "c": d}, **a, 2: 3, **{"b": c}, **b, **c}
"""
    expected = """
_py_backwards_merge_dicts([{1: 1}, {'a': b, 'c': d}, a], {2: 3}, {'b': c}, b, c)
"""

    tree = ast.parse(source)
    fix_missing_locations(tree)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert to_source(new_tree).strip() == expected.strip()
    assert transformer._tree_changed



# Generated at 2022-06-12 03:29:43.209591
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse
    from .typing import BuiltinTransformer

    module = """
    {1: 1}
    {1: 1, **dict_a}
    {1: 1, **dict_a, **dict_b}
    {1: 1, **None}
    {1: 1, None: None}
    {None: 1}
    """


# Generated at 2022-06-12 03:29:53.128950
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # case 1
    node_1 = ast.Dict(keys=[None],
                      values=[ast.Name(id='a')])
    expected_1 = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[ast.Call(
            func=ast.Name(id='dict'),
            args=[],
            keywords=[])])],
        keywords=[])

    # case 2
    node_2 = ast.Dict(keys=[None, None],
                      values=[ast.Name(id='a'), ast.Name(id='b')])

# Generated at 2022-06-12 03:29:55.728179
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '{1: 2, **a}'
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)


# Generated at 2022-06-12 03:30:01.690417
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import fix_missing_locations
    
    transformer = DictUnpackingTransformer()
    module = ast.parse('{1: 1, **dict_a}')
    module = transformer.visit(module)
    expected = ast.parse('''
        _py_backwards_merge_dicts(
            [{1: 1}],
            dict_a)
        ''')
    assert fix_missing_locations(expected) == module


# Generated at 2022-06-12 03:30:02.382709
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:30:17.807933
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_program

    assert_program(
        DictUnpackingTransformer,
        {1: 1, **{2: 2}},
        """_py_backwards_merge_dicts([{1: 1}], {2: 2})"""
    )

    assert_program(
        DictUnpackingTransformer,
        {1: 1, 2: 2, 3: 3, **{4: 4}},
        """_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], {4: 4})"""
    )


# Generated at 2022-06-12 03:30:23.944459
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    result = ast.parse('{1: 1}').body
    inserted = merge_dicts.get_body()[0]
    should_be = ast.Module(body=[inserted, result[0]])
    transformer = DictUnpackingTransformer()

    actual = transformer.visit(ast.parse('{1: 1}'))

    assert ast.dump(actual) == ast.dump(should_be)


# Generated at 2022-06-12 03:30:33.380199
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import assert_sequence_equal
    from ..testing.visitor import NodeCounter, DictNodeVisitor

    @snippet
    def snippets_to_test():
        # snippet 0
        result = {1: 1, 2: 2, **dict_a}

        # snippet 1
        result = {1: 1, **dict_a, 2: 2}

        # snippet 2
        result = {**dict_a, 1: 2}

        # snippet 3
        result = {1: 2, **dict_a}

        # snippet 4
        result = {1: 2, **dict_a, 2: 2}

        # snippet 5
        result = {1: 2, **dict_a, **dict_b}

        # snippet 6

# Generated at 2022-06-12 03:30:41.092306
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    line = "{1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4}"
    expected = ("_py_backwards_merge_dicts("
                "[{1: 1}, dict_a, {2: 2}, dict_b, {3: 3}], dict_c, {4: 4})")
    tree = ast.parse(line)
    transformed = DictUnpackingTransformer().visit(tree)
    assert astor.to_source(transformed).strip() == expected

# Generated at 2022-06-12 03:30:43.802950
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('''\
{1:a, None: b, **c, **d}''')

    new_tree = DictUnpackingTransformer().visit(tree)


# Generated at 2022-06-12 03:30:54.601050
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:31:02.595367
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_base import check_node

    # 1. Valid, when we find unpacking operator
    source = '''
        d = {1: 1, **dict_a}
    '''

    expected = '''
        d = _py_backwards_merge_dicts(
            [{1: 1}],
            dict_a
        )
    '''
    check_node(source, expected, DictUnpackingTransformer)

    # 2. Valid, when we find unpacking operator with default value
    source = '''
        d = {1: 1, 2: 2, **dict_a, 3: 3}
    '''


# Generated at 2022-06-12 03:31:04.929743
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import roundtrip_unparse
    assert len(list(roundtrip_unparse(merge_dicts.get_body()))) == 1


# Generated at 2022-06-12 03:31:09.644843
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.example import example
    from .. import run_transformation
    code = '{1: 2, **{3: 5}}'
    tree = example(code)
    new_tree = run_transformation(tree, DictUnpackingTransformer)
    assert new_tree != tree
    assert compile(tree, '', 'eval').eval() == compile(new_tree, '', 'eval').eval() == {1: 2, 3: 5}

# Generated at 2022-06-12 03:31:20.363932
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..exceptions import TranspileError
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast_tree
    from ..utils import unindent
    from .base import _GenericTransformerVisitor


# Generated at 2022-06-12 03:31:45.041706
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import fix_missing_locations
    from ..tests.utils import assert_equal_ast
    node = ast.parse('''
        x = {1: 2, **a}
    ''')
    DictUnpackingTransformer().visit(node)
    node = fix_missing_locations(node)
    assert_equal_ast(
        node,
        '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        x = _py_backwards_merge_dicts([{1: 2}], a)
        '''
    )


# Generated at 2022-06-12 03:31:51.728043
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing_utils import assert_equal_ignoring_locations
    assert_equal_ignoring_locations(
        """
        def f(a, b):
            dict_a = {'a': 1}
            {1: 1, **dict_a}
        """,
        """
        def f(a, b):
            dict_a = {'a': 1}
            _py_backwards_merge_dicts([{1: 1}], dict_a)
        """,
        [DictUnpackingTransformer]
    )



# Generated at 2022-06-12 03:31:58.246577
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for method visit_Dict of class DictUnpackingTransformer."""
    transpiler = DictUnpackingTransformer()
    assert transpiler.visit(
        ast.parse('{1: 2, 3: 4, None: 5, 6: 7, None: 8, 9: 10}')) == \
           ast.parse('_py_backwards_merge_dicts([{1: 2, 3: 4}, 5, {6: 7}, 8, '
                     '{9: 10}])')

# Generated at 2022-06-12 03:32:07.310593
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_program


# Generated at 2022-06-12 03:32:16.731403
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as py_ast

    def Dict(*args):
        """This function is needed to prevent calling of visit_Dict method."""
        return py_ast.Dict(keys=[], values=[])

    transformer = DictUnpackingTransformer()
    result = transformer.visit(
        py_ast.Expr(value=Dict(
            [py_ast.Num(1), py_ast.Num(2)],
            [py_ast.Num(1), py_ast.Num(2)],
            None,
            [py_ast.Num(3), py_ast.Num(4)],
            [py_ast.Num(5), py_ast.Num(6)],
            None,
            [py_ast.Num(7), py_ast.Num(8)]
        )))
    assert transformer._tree

# Generated at 2022-06-12 03:32:26.180927
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert ast.dump(
        DictUnpackingTransformer().visit(ast.parse(
            """
            {1: 1, 2: 2, 'a': 1, **a, 3: 3, 5: 5, **{6: 6}, 7: 7}
            """)),
        annotate_fields=False) == ast.dump(
            ast.parse(
                """
                _py_backwards_merge_dicts([
                    {1: 1,
                     2: 2,
                     'a': 1,
                     3: 3,
                     5: 5,
                     7: 7},
                    a,
                    {6: 6}
                ])
                """))



# Generated at 2022-06-12 03:32:36.717459
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    def test(before, after):
        expected = astor.to_source(ast.parse(after))
        actual = astor.to_source(DictUnpackingTransformer().visit(
            ast.parse(before)))
        assert actual == expected

    test('{1: 1}', '{1: 1}')
    test('{1: 1, **dict_a}', '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    test('{1: 1, **dict_a, **dict_b}', '_py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)')

# Generated at 2022-06-12 03:32:46.666626
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:32:54.602481
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, **dict_a, 2: 2}')
    ast.fix_missing_locations(node)
    node = transformer.visit(node)

# Generated at 2022-06-12 03:33:03.675202
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast_format import dump

    code = '{\n  1: 1,\n  **{1: 1},\n  2: 2,\n  **{2: 2},\n  **{3: 3}\n}'
    expected = ('_py_backwards_merge_dicts([{\n  1: 1,\n  2: 2\n}, {\n'
                '  1: 1\n}, {\n  2: 2\n}, {\n  3: 3\n}])')

    tree = ast.parse(code)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert dump(new_tree) == dump(ast.parse(expected))

# Generated at 2022-06-12 03:33:29.881118
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None

    source = """\
    {
        1: 1,
        2: 2,
        3: 3,
        **dict_a,
        4: 4,
        5: 5,
        **dict_b,
    }
    """

    expected_code = """\
    _py_backwards_merge_dicts([{
        1: 1,
        2: 2,
        3: 3,
    }], dict_a, {
        4: 4,
        5: 5,
    }, dict_b)
    """

    module = ast.parse(source)
    DictUnpackingTransformer().visit(module)
    assert_source(module, expected_code)


# Generated at 2022-06-12 03:33:38.204544
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseTestTransformer
    from .base import assert_node_equals

    code = """
        _ = dict(a=1, **{1: 2, 'c': 3})
    """

    tree = ast.parse(code)  # type: ignore
    DictUnpackingTransformer(verbose=True).visit(tree)
    expected = """
        _ = _py_backwards_merge_dicts([dict({'a': 1}), {1: 2, 'c': 3})
    """.strip().lstrip()
    assert_node_equals(expected, tree)



# Generated at 2022-06-12 03:33:44.313345
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """\
    {1: 1, 2: 2, **a}
    """
    expected_source = """\
    _py_backwards_merge_dicts([{1: 1, 2: 2}], a)
    """
    transformer = DictUnpackingTransformer()
    expected_tree = ast.parse(expected_source)
    tree = transformer.visit(ast.parse(source))
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 03:33:54.499927
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import should_transform_equal
    should_transform_equal(
        DictUnpackingTransformer,
        """
            {1: 2, 3: 4, **dict_a}
        """,
        """
            _py_backwards_merge_dicts([{1: 2, 3: 4}], dict_a)
        """)

    should_transform_equal(
        DictUnpackingTransformer,
        """
            {1: 2, 3: 4, **dict_a,
             **dict_b,
             **dict_c}
        """,
        """
            _py_backwards_merge_dicts([{1: 2, 3: 4}],
                                     dict_a,
                                     dict_b,
                                     dict_c)
        """)

# Generated at 2022-06-12 03:34:05.051028
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    import astunparse

    class Test(unittest.TestCase):
        def setUp(self):
            self.transformer = DictUnpackingTransformer()

        def test_no_unpacking_visit_Dict(self):
            before = ast.parse("{1: 1, 2: '2'}")
            after = ast.parse("{1: 1, 2: '2'}")
            node = self.transformer.visit(before)
            self.assertEqual(astunparse.unparse(after).strip(),
                             astunparse.unparse(node).strip())

        def test_simple_unpacking_visit_Dict(self):
            before = ast.parse("{1: 1, **{2: '2'}}")

# Generated at 2022-06-12 03:34:05.691677
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    pass

# Generated at 2022-06-12 03:34:10.016537
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('''{**{1: 2}, **{3: 4}}''')
    expected = ast.parse('''_py_backwards_merge_dicts([{1: 2}, {3: 4}])''')
    assert DictUnpackingTransformer.run(node) == expected



# Generated at 2022-06-12 03:34:19.084439
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    transformer = DictUnpackingTransformer()
    code = '{1: 1, 2: 2, 3: 3, **dict_a}'
    tree = ast.parse(code)

    new_tree = transformer.visit(tree)
    func_def = new_tree.body[0]
    assert isinstance(func_def, ast.FunctionDef)
    assert func_def.name == '_py_backwards_merge_dicts'
    assert new_tree.body[1] is None
    expr = new_tree.body[2]
    assert isinstance(expr, ast.Expr)
    expr_value = expr.value
    assert isinstance(expr_value, ast.Call)
    call_func = expr_value.func
    assert isinstance(call_func, ast.Name)
    assert call_

# Generated at 2022-06-12 03:34:29.442690
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-12 03:34:37.447415
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...unittest import compile_code

    code = "a = {**{}}"
    python_version = '3.8'
    assert compile_code(code, python_version) == "", \
        "Empty dict should be optimized out"

    code = "a = {**{}, 1: 2}"
    python_version = '3.8'
    assert compile_code(code, python_version) == "a = {1: 2}", \
        "Dict unpacking should be optimized out"

    code = "a = {**{}, 1: 2, **{}}"
    python_version = '3.8'
    assert compile_code(code, python_version) == "a = {1: 2}", \
        "Dict unpacking should be optimized out"


# Generated at 2022-06-12 03:35:38.401359
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse(textwrap.dedent("""
        {1: 1, **a, 2: 2, **b, 3: 3, **c, 4: 4}"""))
    module = ast.Module(body=[node])

    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-12 03:35:44.375367
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts(
        [{1: 1}], dict_a, {2: 2}, dict_b
    );
    """
    assert transformer.transform(source) == expected

# Generated at 2022-06-12 03:35:53.566274
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_source
    from typed_ast import ast3 as ast
    from .unpacking import UnpackingTransformer
    from .string_formatting import StringFormattingTransformer

    code = '''
    def update_all(source, **kwargs):
        for key, value in kwargs.items():
            source[key] = value

    update_all(source,
        key1="value1",
        key2="value2",
        **{'key3': 'value3'},
        **{'key4': 'value4'}
    )
    '''

# Generated at 2022-06-12 03:36:01.531169
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..generator import generate_source_code_from_tree
    from ..tests.snippets import dict_unpacking
    lines = dict_unpacking.strip().split('\n')
    assert lines[0].startswith('{')
    assert lines[0].endswith(',')
    assert lines[1].startswith('**')
    tree = ast.parse(dict_unpacking)
    DictUnpackingTransformer().visit(tree)  # type: ignore
    result = generate_source_code_from_tree(tree).split('\n')
    # TODO: check result

# Generated at 2022-06-12 03:36:11.660371
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import pytest  # type: ignore
    from .fixtures import BACKWARDS_MERGE_DICTS

    def check(left, right):
        '''Sorts lists of pairs, because order of pairs doesn't matter for call
        _py_backwards_merge_dicts.'''
        left = sorted(left)
        right = sorted(right)
        assert left == right

    x = DictUnpackingTransformer()
    check(x._split_by_None([(None, 'a')]), [['a']])
    check(x._split_by_None([(ast.Num(123), 'a')]), [[(ast.Num(123), 'a')]])
    check(x._split_by_None([(None, 'a'), (None, 'b')]), [['a', 'b']])
   

# Generated at 2022-06-12 03:36:21.970762
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    """Test for method visit_Module of class DictUnpackingTransformer"""
    # Test with wrong format of Module. Test must fail
    source = """
    x = {1: 2, 3: 4, **{5: 6}}
    """

    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    code = compile(tree, filename="<ast>", mode="exec")
    locals = {}
    exec(code, {}, locals)
    module = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and node.targets[0].id == 'x':
            module = node

    assert isinstance(module, ast.Module)


# Generated at 2022-06-12 03:36:29.181103
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected = ast.parse("""
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        {1: 1}
    """)
    expected = expected.body[1]

    module = ast.parse("{1: 1}")
    module.body[0] = DictUnpackingTransformer().visit(module.body[0])
    assert ast.dump(module.body[0]) == ast.dump(expected)


# Generated at 2022-06-12 03:36:32.658943
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer
    assert hasattr(transformer, 'visit_Dict')
    assert transformer.target == (3, 4)



# Generated at 2022-06-12 03:36:39.278956
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import run_with_both_versions

    source = """
    assert {1: 2, **dict(a=3)} == {1: 2, 'a': 3}
    assert {1: 2, **dict(a=3), 3: 4, **dict(b=5)} == {1: 2, 'a': 3, 3: 4, 'b': 5}
    """
    run_with_both_versions(
        DictUnpackingTransformer, code=source)

# Generated at 2022-06-12 03:36:40.603862
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert len(dir(DictUnpackingTransformer())) == 15

# Generated at 2022-06-12 03:37:24.326037
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse(
"""{
    1: 1,
    **dict_a
}""")  # type: ast.AST

    result = ast.parse(
"""
_py_backwards_merge_dicts([{1: 1}], dict_a)
""")  # type: ast.AST

    assert DictUnpackingTransformer().visit(node) == result

# Generated at 2022-06-12 03:37:30.224118
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # noinspection PyUnresolvedReferences
    from ..testing import assert_type_match
    from typed_ast.ast3 import parse

    def test(code: str, expected: Optional[str]) -> None:
        result = DictUnpackingTransformer(parse(code)).node
        assert_type_match(result, expected)  # type: ignore

    test("{'a': 1, **d1}", "_py_backwards_merge_dicts([{'a': 1}], d1)")
    test("{'a': 1, **d1, **d2}", "_py_backwards_merge_dicts([{'a': 1}], d1, d2)")

# Generated at 2022-06-12 03:37:33.091707
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    node = ast.parse(""),
    transformer.visit_Dict(ast.parse("{1: 1, **a}"))
    assert transformer._tree_changed == True
    transforme

# Generated at 2022-06-12 03:37:36.380795
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    source = """{1: 1, **dict_a, 2: 2}"""
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-12 03:37:45.826259
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import test_utils
    from mypy_extensions import NoReturn

    test_utils.assert_program_equal(
        DictUnpackingTransformer().visit(test_utils.parse_string(
            '''
            {1: 1, **b, 2: 2}
            '''
        )),
        test_utils.parse_string(
            '''
            _py_backwards_merge_dicts(
                [{1: 1, 2: 2}],
                b,
            )
            '''
        ),
    )


# Generated at 2022-06-12 03:37:54.954175
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class TestTransformer(DictUnpackingTransformer):
        code = None

        def __init__(self):
            self.node = None

        def visit(self, node: ast.AST) -> ast.AST:
            self.node = node
            return super().visit(node)

        def create_node(self, code: str) -> None:
            self.code = code
            self.node = ast.parse(code).body[0].value

        def check_output(self, code: str) -> None:
            assert ast.dump(self.node) == ast.dump(ast.parse(code))[:-1]


# Generated at 2022-06-12 03:37:56.946438
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    class obj:
        pass
    
    DictUnpackingTransformer()
    x = obj()
    assert isinstance(x, obj)

# Generated at 2022-06-12 03:37:59.021723
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_program

    source = """
{1: 2, 3: 4}
"""


# Generated at 2022-06-12 03:38:06.529242
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tr = DictUnpackingTransformer()
    source = '''{1: 1, 2: 2, 3: 3, **dict_a, 4: 4, **dict_b, 5: 5}'''
    expected = '''
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, dict_a, {4: 4}, dict_b, {5: 5}])
'''.lstrip()

    tree = ast.parse(source)
    new_tree = tr.visit(tree)  # type: ignore
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 03:38:11.333905
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse("{1: 1, 2: 2, **dict_a}")
    actual = ast.dump(DictUnpackingTransformer().visit(node))
    expected = ast.dump(ast.parse("_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)"))
    assert actual == expected