

# Generated at 2022-06-12 03:29:04.325524
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse
    from .type_stub_visitor import TypeStubVisitor
    from ..utils.tree_processing import TreeProcessor
    from ..utils.unification import Unifier
    from ..utils.unification import ANY
    # given:
    node = ast.parse("""{1: 1, **dict_a}""")
    # when:
    DictUnpackingTransformer(TreeProcessor(Unifier()), TypeStubVisitor()).visit(node)  # type: ignore
    # then:

# Generated at 2022-06-12 03:29:12.075745
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .cst import cst

    original = cst("""
    {
        1: 2,
        3: 4,
        **d,
        5: 6,
        **e,
        7: 8,
        **f
    }""")

    expected = cst("""
    _py_backwards_merge_dicts([
        {1: 2, 3: 4},
        d,
        {5: 6},
        e,
        {7: 8}
    ], f)""")

    assert original.body[0] == expected
    assert original.body[0].body[0] == expected.body[0]

# Generated at 2022-06-12 03:29:19.434604
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as pyast
    t = DictUnpackingTransformer()
    # Remove last comma, so it's an invalid dict
    input_tree = ast.parse("{'a': 1, **b,}").body[0]
    output_tree = t.visit(input_tree)
    assert_equal(
        pyast.dump(output_tree),
        '_py_backwards_merge_dicts(['
            'Dict(keys=[Str(s="a")], values=[Num(n=1)])'
        ', b])'
    )



# Generated at 2022-06-12 03:29:27.068841
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_transformation
    from ..utils.typed_ast import ast3_dump

    expected = """
    def foo():
        return _py_backwards_merge_dicts([{'a': 1, 'b': 2}, dict_1], dict_2)
    """
    actual = """
    def foo():
        return {'a': 1, 'b': 2, **dict_1, **dict_2}
    """
    assert_transformation(DictUnpackingTransformer, actual, ast3_dump, expected)


# Generated at 2022-06-12 03:29:33.439525
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.examples import DICT_UNPACKING_EXAMPLE

    xs = [
        (None, ast.Call(func=ast.Name(id='a'), args=[], keywords=[])),
        (ast.Str(s='key'), ast.Str(s='value1')),
        (ast.Str(s='key'), ast.Str(s='value2')),
    ]

# Generated at 2022-06-12 03:29:43.127119
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    simple_case = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                           values=[ast.Num(n=1), ast.Dict(keys=[], values=[]), ast.Num(n=2)])
    example = astunparse.unparse(simple_case)
    expected = '_py_backwards_merge_dicts([{1: 1}, {}, {2: 2}])'
    assert DictUnpackingTransformer.run(example) == expected

    example = astunparse.unparse(ast.Dict(keys=[None, None],
                                          values=[ast.Dict(keys=[], values=[]),
                                                  ast.Dict(keys=[], values=[])]))

# Generated at 2022-06-12 03:29:53.030062
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import dump_tree

    expected = {'a': 'a', 'b': 'b'}

    module = ast.parse("""
        {None: b, a: a, None: {1: 1, None: {None: c, **dict_b}, **dict_a}, None: c}
    """)

    result = DictUnpackingTransformer().visit(module).body[-1].value

    dump_tree(result, True)


# Generated at 2022-06-12 03:29:59.625157
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import parse
    from ..utils.tree import tree_to_str
    from ..utils.example import example

    source = example('dict_unpacking_99.py')
    tree = parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    new_code = tree_to_str(new_tree)

    assert new_code == example('dict_unpacking_99_new.py')

# Generated at 2022-06-12 03:30:05.787515
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import canonical
    from .. import ast3
    from .base import BaseNodeTransformerTestCase
    from .default import DefaultTransformer
    from .unpacking_to_tuples import UnpackingTransformer
    from .dict_unpacking import DictUnpackingTransformer
    from .builtins import BuiltinTransformer
    from .inline_functions import InlineFunctionTransformer

    class Test(BaseNodeTransformerTestCase):
        transformer = DefaultTransformer([
            UnpackingTransformer,
            DictUnpackingTransformer,
            BuiltinTransformer,
            InlineFunctionTransformer,
        ], [])

        target = (3, 6)
        mode = 'eval'
        # Test cases


# Generated at 2022-06-12 03:30:15.366318
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.simplify_ast import simplify_ast

    code_str = '{1: None, None, **d1, 2: None, **d2, 3: None, **d3}'
    expected_code_str = '_py_backwards_merge_dicts([{1: None, 2: None, 3: None}], d1, d2, d3)'
    code = ast.parse(code_str)
    simplified = simplify_ast(code, 3)
    expected_code = ast.parse(expected_code_str, '<string>')

    transformer = DictUnpackingTransformer()
    result = transformer.visit(simplified)
    assert ast.dump(result) == ast.dump(expected_code)

# Generated at 2022-06-12 03:30:28.823700
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import NodeTransformer

    module = ast.Module([
        ast.Expr(
            value=ast.Dict(
                keys=[ast.Num(n=1), None, ast.Num(n=2)],
                values=[
                    ast.Num(n=1),
                    ast.Dict(keys=[ast.Str(s='a')], values=[ast.Num(n=1)]),
                    ast.Num(n=2)])),
    ])

    NodeTransformer(DictUnpackingTransformer).visit(module)
    result = ast_to_str(module)


# Generated at 2022-06-12 03:30:39.471546
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    transformer = DictUnpackingTransformer()
    node = ast.Module([ast.Expr( value=ast.Dict(
        keys = [ast.Num(n=1), None, ast.Num(n=2)],
        values = [ast.Num(n=1), ast.Call(func=ast.Name('unpack_dict', ast.Load), 
                                         args=[], keywords=[]), ast.Num(n=3)]
    ))])
    transformer.generic_visit(node)

# Generated at 2022-06-12 03:30:41.699965
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astor.code_gen import to_source
    from typed_astunparse import unparse
    from ..sql import top_level_transformer, _py_backwards_merge_dicts
    

# Generated at 2022-06-12 03:30:50.215479
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_astunparse
    import textwrap

    node = ast.parse(textwrap.dedent("""
    {1: 2, 1: 2, **{}, **{1: 2}, **{1: 2}, **{1: 2}}
    """))
    DictUnpackingTransformer().visit(node)
    expected = textwrap.dedent("""
    _py_backwards_merge_dicts([dict({1: 2, 1: 2}), {1: 2}, {1: 2}, {1: 2}])
    """)
    print(typed_astunparse.unparse(node))
    assert typed_astunparse.unparse(node) == expected

# Generated at 2022-06-12 03:30:59.482851
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    snippet = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected_snippet = """
        _py_backwards_merge_dicts(
            [{1: 1}, dict_a, {2: 2}],
            dict_b)
    """

    tree = ast.parse(snippet)
    node = tree.body[0].value
    assert isinstance(node, ast.Dict)

    transformed = DictUnpackingTransformer().visit(tree)
    transformed_node = transformed.body[0].value
    assert isinstance(transformed_node, ast.Call)

    assert expected_snippet == astor.to_source(transformed)

# Generated at 2022-06-12 03:31:08.879181
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Tests for method visit_Dict of class DictUnpackingTransformer."""
    from typed_ast import ast3
    
    def _merge_dicts(dict_1, dict_2, dict_3):
        result = {}
        for dict_ in (dict_1, dict_2, dict_3):
            result.update(dict_)
        return result
    _merge_dicts = ast3.parse(_merge_dicts.__code__.co_consts[0]).body[0]
    
    def _unpack(**kwargs):
        ...
    
    def test_no_unpacking_in_dict():
        node = ast3.parse('{1: 2}').body[0]
        expected_node = node
    

# Generated at 2022-06-12 03:31:19.533679
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Source:
        a = 1
        b = 2
        c = 3
        d = 4

        def f(self):
            return {
                0: 1,
                **Source.dict_a(),
                **Source.dict_b(),
                **Source.dict_c(),
                **Source.dict_d(),
                **None,
                10: 10
            }

        @classmethod
        def dict_a(cls):
            return {
                1: cls.a,
                2: cls.b
            }

        @classmethod
        def dict_b(cls):
            return {
                3: cls.c,
                4: cls.d
            }


# Generated at 2022-06-12 03:31:25.784040
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_in_working_dir, should_raise

    compiled_body = assert_in_working_dir(compile, """
    def test():
        return {1: 1, **{'a': 2, **{3: 1}}}
    """,
        mode='exec',
    )
    test = compiled_body.co_consts[0]
    assert test is not None

    tree = DictUnpackingTransformer().visit(test.body[0].value)  # type: ignore
    assert isinstance(tree, ast.Call)  # type: ignore
    assert isinstance(tree.func, ast.Name)  # type: ignore
    assert tree.func.id == '_py_backwards_merge_dicts'
    assert isinstance(tree.args[0], ast.List) 

# Generated at 2022-06-12 03:31:35.043532
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.example import example
    from ..utils.testing import assert_contains_code
    from ..utils.ast import ast_equals

    code = example(1)
    tree = ast.parse(code)
    DictUnpackingTransformer(tree_changed=False).visit(tree)
    assert tree.body
    assert_contains_code(tree, '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_contains_code(tree, "dict(__vars__)")
    assert_contains_code(tree, "for __k, __v in __vars__.items()")

# Generated at 2022-06-12 03:31:43.234948
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    code = '''
{'a': 1, **dict_a, 'b': 2, **dict_b}
'''
    expected_code = '''
_py_backwards_merge_dicts([{'a': 1, 'b': 2}], dict_a, dict_b)
'''
    expected_tree = ast.parse(expected_code)
    tree = ast.parse(code)

    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert compare_ast(tree, expected_tree)



# Generated at 2022-06-12 03:31:53.525952
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import get_ast

    code = "{1: 1, **{2: 2, **{3: 3}}}".format_map(vars())
    ast_tree = get_ast(code)
    result = ast.dump(DictUnpackingTransformer().visit(ast_tree), include_attributes=True)
    expected_result = ast.dump(get_ast(
        "{}.format_map(vars())".format_map(vars())), include_attributes=True)
    assert result == expected_result

# Generated at 2022-06-12 03:32:03.795714
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast
    from ..utils.parse_text import parse_text

    # type: ignore
    def test(code, expected):
        root = parse_text(code)
        node = root.body[0].value
        assert isinstance(node, ast.Dict)
        transformed_node = DictUnpackingTransformer().visit(node)
        result_code = codegen.to_source(transformed_node)
        assert result_code == expected

    test("{1: 1, **a, 2: 2}", "_py_backwards_merge_dicts([{1: 1, 2: 2}], a)")
    test("{**a}", "_py_backwards_merge_dicts([{}], a)")

# Generated at 2022-06-12 03:32:08.987289
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''
        {a: 1, b: 2, c: 3, **d}
    '''

    expected = '''
        _py_backwards_merge_dicts([dict([(a, 1), (b, 2), (c, 3)])], d)
    '''

    result = DictUnpackingTransformer().visit(ast.parse(source))

    assert ast.dump(result) == ast.dump(ast.parse(expected))


# Generated at 2022-06-12 03:32:10.268109
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor


# Generated at 2022-06-12 03:32:18.121600
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from collections import OrderedDict
    from io import StringIO
    from typed_astunparse import unparse
    from ..utils.ast import ast_equal

    pairs = [('a', 1), ('b', 2), None, ('c', 3), None, ('d', 4), ('e', 5)]
    ast_dict = ast.Dict(keys=[ast.Str(s=k) if k is not None else None
                              for k, _ in pairs],
                       values=[ast.Num(n=v) for _, v in pairs])
    expected = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
        ('d', 4),
        ('e', 5)
    ])

    string_io = StringIO()

# Generated at 2022-06-12 03:32:29.061888
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    transformer = DictUnpackingTransformer()
    node = ast.Module([
        ast.Dict(keys=[None, ast.Num(1)],
                 values=[ast.Dict(keys=[], values=[]), ast.Dict(keys=[],
                                                                 values=[])])
    ])

# Generated at 2022-06-12 03:32:30.433736
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import doctest
    doctest.testmod()
    

# Generated at 2022-06-12 03:32:39.040906
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from collections import OrderedDict
    from ..utils.tree import assert_tree


# Generated at 2022-06-12 03:32:43.874881
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    transformer.visit_Dict(ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                                    values=[ast.Num(n=1), ast.Num(n=2),
                                            ast.Num(n=2)]))
    assert transformer._tree_changed is True

# Generated at 2022-06-12 03:32:49.666539
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    # This test doesn't check whether merges dicts in a right order

    code = '''
    def f():
        return {0: 0, **x}
    '''

    expected = '''
    def f():
        return _py_backwards_merge_dicts([{0: 0}], x)
    '''

    result = DictUnpackingTransformer().transform_source(code)
    print(astunparse.unparse(result))
    assert astunparse.unparse(result) == expected

# Generated at 2022-06-12 03:33:06.593674
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    assert transformer.visit(ast.parse("a = {1: 2}")) == ast.parse("a = {1: 2}")
    assert transformer.visit(ast.parse("a = {1: 2, **{}}")) == ast.parse("a = _py_backwards_merge_dicts([{1: 2}], {})")
    assert transformer.visit(ast.parse("a = {1: 2, **{4: 5}}")) == ast.parse("a = _py_backwards_merge_dicts([{1: 2}], {4: 5})")

# Generated at 2022-06-12 03:33:11.743669
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import roundtrip, roundtrip
    from ..utils.tree import ast_to_text
    import astor

    result = roundtrip(
        """{'a': 2, **{1: 1}}""")
    assert ast_to_text(result) == ast_to_text(
        """
_py_backwards_merge_dicts([{'a': 2}], {1: 1})
""")
    result = roundtrip(
        """{'a': 2, **{1: 1}, **{2: 3}}""")
    assert ast_to_text(result) == ast_to_text(
        """
_py_backwards_merge_dicts([{'a': 2}, {1: 1}], {2: 3})
""")

# Generated at 2022-06-12 03:33:20.119555
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import cast

    from typed_ast.ast3 import Dict, Call, Num, Name, List, parse

    tree = cast(Dict, parse('{1: 1, **dict_a}'))
    transformer = DictUnpackingTransformer()
    result = transformer.visit_Dict(tree)

    assert isinstance(result, Call)
    assert result.func.id == '_py_backwards_merge_dicts'
    assert len(result.args) == 1
    assert isinstance(result.args[0], List)
    assert len(result.args[0].elts) == 2
    assert isinstance(result.args[0].elts[0], Dict)
    assert len(result.args[0].elts[0].keys) == 1

# Generated at 2022-06-12 03:33:28.805705
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse, dump
    from typed_ast import ast3
    from codec.ast import dumps
    unpacking_transformer = DictUnpackingTransformer()

    def compile_dict(node: ast3.Dict) -> ast3.Call:
        module = ast3.parse(f'd = {dumps(node)}')
        module = unpacking_transformer.visit(module)  # type: ignore
        call = cast(ast3.Call, module.body[0].value)  # type: ignore
        return call

    # empty dict
    d = {}  # type: Dict[int, int]
    expected = ast3.parse('_py_backwards_merge_dicts([{}])').body[0].value

# Generated at 2022-06-12 03:33:38.616793
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    buf = io.StringIO()
    with redirect_stdout(buf):
        from typed_ast import ast3
        from ..utils.tree import parse
        print(parse("x = {1: 1, **d}"))
        print(parse("x = {1: 1, 2: 2, **d}"))
        print(parse("x = {1: 1, 2: 2, **d, 1: 2}"))
    result = buf.getvalue()

# Generated at 2022-06-12 03:33:48.725410
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .unpacking import UnpackingTransformer
    from .keywords import KeywordsTransformer
    from .base import BaseNodeTransformer

    def transform(code, target):
        tree = ast.parse(code)
        tree = UnpackingTransformer(target).visit(tree)
        tree = KeywordsTransformer(target).visit(tree)
        tree = DictUnpackingTransformer(target).visit(tree)
        return tree

    code = """
        {1: 2, **{5: 6}, **{}, **{7: 8}, 3: 4}
    """
    parsed = transform(code, (3, 4))
    expected = """
        _py_backwards_merge_dicts([{1: 2}, {}, {7: 8}, {3: 4}], {5: 6})
    """

# Generated at 2022-06-12 03:33:58.634228
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()
    given = ast.Dict(keys=[None, ast.Num(1), ast.Num(2)],
                     values=[ast.Num(1), ast.Num(2), ast.Num(3)])
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(elts=[
                ast.Dict(keys=[ast.Num(1), ast.Num(2)], values=[ast.Num(2), ast.Num(3)]),
                ast.Num(1)
            ])
        ],
        keywords=[])
    actual = dut.visit(given)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-12 03:34:09.243487
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree

    dict_node = ast.Dict(keys=[
        ast.Num(n=1),
        ast.Num(n=2),
        ast.Name(id='a', ctx=ast.Load()),
        None
    ], values=[
        ast.Num(n=1),
        ast.Num(n=2),
        ast.Name(id='b', ctx=ast.Load()),
        ast.Str(s='dict_a')
    ])


# Generated at 2022-06-12 03:34:16.397640
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test import (make_fixture_test_case_class,
                              make_fixture_test_case)

    TestCase = make_fixture_test_case_class(DictUnpackingTransformer,
                                            __file__)

    test_merge_dicts = make_fixture_test_case(__file__, 'test_merge_dicts')

    test_merge_dicts(TestCase)

    test_merge_dicts_call_with_dict_module = make_fixture_test_case(
        __file__, 'test_merge_dicts_call_with_dict_module'
    )

    test_merge_dicts_call_with_dict_module(TestCase)

    test_merge_dicts_call_with_dict_module_

# Generated at 2022-06-12 03:34:26.471659
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...utils.source import source_to_ast

    # Example from comment before visit_Dict method
    source = '''{1: 1, **dict_a}'''
    ast_node = source_to_ast(source)
    transformed = DictUnpackingTransformer().visit(ast_node)
    expected = '''
result = _py_backwards_merge_dicts([dict({1:1})], dict_a)
'''.strip()
    assert astor.to_source(transformed) == expected

    # Simple case
    source = '''{a: b, c: d}'''
    ast_node = source_to_ast(source)
    transformed = DictUnpackingTransformer().visit(ast_node)
    assert astor.to_source(transformed) == source

    # Simple

# Generated at 2022-06-12 03:34:45.772844
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = "{1: 2, 3: 4, **{5: 6}}"
    expected = "print(_py_backwards_merge_dicts([{1: 2, 3: 4}], {5: 6}))"

    actual = str(DictUnpackingTransformer().visit(ast.parse(source)))
    assert expected in actual

# Generated at 2022-06-12 03:34:50.489635
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..transformer import Transformer
    from ..utils.source import source_to_ast

    code = \
        """
        {1: 2, 3: 4, 'a': 1.0, **result, 'b': 2.0, c: 3}
        """
    root = source_to_ast(code)
    root = Transformer(DictUnpackingTransformer).visit(root)
    assert code in ast.dump(root)

# Generated at 2022-06-12 03:34:54.751944
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .test_utils import round_trip_transformer_as_py
    code = "{1: 1, **dict_a}"
    result = ast.parse(code)
    DictUnpackingTransformer().visit(result)
    transformed = round_trip_transformer_as_py(code, DictUnpackingTransformer)
    assert transformed == "_py_backwards_merge_dicts([{1: 1}], dict_a)"

# Generated at 2022-06-12 03:35:01.465892
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 1, **dict_a, **dict_b, 2: 2, **dict_c}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    expected = ast.parse('''
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b, dict_c)
    ''')
    assert ast.dump(result) == ast.dump(expected)



# Generated at 2022-06-12 03:35:07.003839
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import node_to_str
    source = "f({0: 0, 'b': 'B', **A, None: None, **B})"
    expected = "f(_py_backwards_merge_dicts([{0: 0, 'b': 'B'}, A], B))"
    module = ast.parse(source)
    module = DictUnpackingTransformer().visit(module)
    assert node_to_str(module) == expected

# Generated at 2022-06-12 03:35:12.587603
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import typed_astunparse
    from astunparse import unparse

    code = """
    {1: 1, **dict_a}
    """

    expected_code = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = typed_ast.ast3.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert unparse(tree) == expected_code

# Generated at 2022-06-12 03:35:22.008322
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    filename = inspect.getsourcefile(lambda: 0)
    node = ast.parse("""
    {1: 1, **dict_a}
    {1: 1, **dict_a, **dict_b}
    {1: 1, **dict_a, 2: 2, **dict_b}
    """)
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a})
    _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b})
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b})
    """

    result = transformer.visit(node)
    assert ast.fix_missing_

# Generated at 2022-06-12 03:35:31.190441
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from .utils import assert_transform_result
    assert_transform_result(
        DictUnpackingTransformer,
        """
            {1: 1, **dict_a}
        """,
        """
            _py_backwards_merge_dicts([{1: 1}], dict_a)
        """,
    )
    assert_transform_result(
        DictUnpackingTransformer,
        """
            {1: 1, **dict_a, 2: 2, **dict_b}
        """,
        """
            _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
        """,
    )

# Generated at 2022-06-12 03:35:41.716584
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..compiler import compile_
    import astor

    source = """
        a = {1: 1, 2: 2, **d, 4: 4, **e, **f}
    """
    expected = """
        a = _py_backwards_merge_dicts([{1: 1, 2: 2, 4: 4}], d, e, f)
    """

    tree = ast.parse(source)
    compiled = compile_(source, 3)
    compiled = ast.parse(compiled)

    expected = ast.parse(expected)  # type: ignore

    transformer = DictUnpackingTransformer()
    compiled = transformer.visit(compiled)  # type: ignore

    assert astor.to_source(expected) == astor.to_source(compiled)

# Generated at 2022-06-12 03:35:51.711154
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    test_cases = {
        ast.Dict(keys=[ast.Num(n=1), None, ast.Str(s='two')],
                 values=[ast.Num(n=1), ast.Dict(keys=[], values=[]), ast.Num(n=2)]):
            '_py_backwards_merge_dicts([{1: 1}, {}, {\'two\': 2}])',

        ast.Dict(keys=[None], values=[ast.Dict(keys=[], values=[])]):
            '_py_backwards_merge_dicts([dict()])'
    }

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-12 03:36:32.039102
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from ast import dump

    test_cases = (
        """
        {**d, 1: 2}
        """,
        """
        {'a': 1, **d, 2: 3}
        """,
        """
        {'a': 1, **d, 'b': 2, **d, 'c': 3}
        """,
        """
        {'a': 1, **d, 'b': 2, **d}
        """,
        """
        {**d, 'b': 2}
        """,
    )

    for test_case in test_cases:
        module = ast.parse(test_case)
        DictUnpackingTransformer().visit(module)
        # print(dump(module))
        print(unparse(module))



# Generated at 2022-06-12 03:36:42.034495
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    import test.test_utils.code_gen as code_gen

    src = code_gen.single('{1: 1, 2: 2, **a, **b, 3: 3}',
                          prolog=['import typing'],
                          epilog=['a: typing.Dict[str, int]',
                                  'b: typing.Dict[str, int]'])
    tree = ast3.parse(src)  # type: ast3.AST

    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)


# Generated at 2022-06-12 03:36:51.279164
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .test_utils import assert_transform, to_string


# Generated at 2022-06-12 03:37:00.398508
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    import astor
    import astunparse

    code = '''\
{i: 2 * i for i in range(5) if i != 3},\
'''

    tree = ast.parse(code)
    before = ast.dump(tree)

    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    new_tree = transformer.visit(tree)
    after = ast.dump(new_tree)

    print('Before:\n{}\nAfter:\n{}'.format(before, after))


# Generated at 2022-06-12 03:37:09.922455
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict, Name, Call, Module, Assign, Num, Subscript
    from typed_astunparse import unparse
    from .test_helpers import assert_code_equal, compile_and_decompile

    t = DictUnpackingTransformer()

# Generated at 2022-06-12 03:37:16.417421
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    x = ast.parse('''
{1: 2, 3: 4, None: {5: 6}, 7: 8, None: {9: 10}}
''')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(x)
    expected = ast.parse('''
_py_backwards_merge_dicts([{1: 2, 3: 4}, {5: 6}, {7: 8}, {9: 10}])
''')
    assert transformer._tree_changed
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 03:37:16.912854
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:37:26.644104
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node_1 = ast.Dict(keys=[], values=[])
    node_2 = ast.Dict(keys=[ast.Name(id='None')], values=[ast.Name(id='a')])
    node_3 = ast.Dict(keys=[ast.Num(n=1), ast.Name(id='None')],
                      values=[ast.Num(n=2), ast.Name(id='a')])
    node_4 = ast.Dict(keys=[ast.Name(id='None'), ast.Num(n=2)],
                      values=[ast.Name(id='a'), ast.Num(n=3)])

# Generated at 2022-06-12 03:37:34.739920
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import node_to_str
    from .mock_module_1 import module_1
    from .mock_module_2 import module_2

    class Dummy(ast.AST):
        fields = ('value',)

    test_dict_1 = ast.Dict(
        keys=(ast.Num(n=1), None),
        values=(ast.Num(n=1), Dummy(value=ast.Name(id='dict_a'))))

# Generated at 2022-06-12 03:37:44.703975
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.visitor import dump
    from .base import BaseNodeTransformer

    class SomeTransformer(BaseNodeTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return ast.Dict(keys=[ast.Constant(value=None)] * len(node.keys),
                            values=node.keys)

    class Dumper(BaseNodeTransformer):
        def visit_Dict(self, node: ast.Dict) -> Union[ast.Dict, ast.Call]:
            return ast.Dict(keys=node.values, values=node.keys)
