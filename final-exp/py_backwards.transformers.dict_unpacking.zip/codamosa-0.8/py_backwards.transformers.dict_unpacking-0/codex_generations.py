

# Generated at 2022-06-12 03:28:54.897303
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:28:55.524678
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    ...

# Generated at 2022-06-12 03:28:58.787751
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse('print()')
    transformer.visit(module)
    assert_equal(module.body[0], merge_dicts.get_body()[0])


# Generated at 2022-06-12 03:29:04.946081
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import check

    # data
    code = """{1: 2, **{3: 4}, 5: 6}"""
    code_expected = """_py_backwards_merge_dicts([{1: 2}, {5: 6}], dict({3: 4}))"""

    # check
    check(DictUnpackingTransformer, code, code_expected)

# Generated at 2022-06-12 03:29:14.710423
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..tree_helpers import get_ast, dump
    from .custom_assert import custom_assert

    class DummyDictUnpackingTransformer(DictUnpackingTransformer):
        _tree_changed = None

        def __init__(self):
            self._tree_changed = False

        def visit_Dict(self, node):
            super().visit_Dict(node)
            self.__class__._tree_changed = self._tree_changed
            return node

    transformer = DummyDictUnpackingTransformer()

    def compare(before, after):
        tree = get_ast(before)
        transformed = transformer.visit(tree)
        custom_assert(transformed, get_ast(after))
        custom_assert.is_true(transformer._tree_changed)


# Generated at 2022-06-12 03:29:21.742972
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import BaseNodeTransformerTestCase
    
    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = DictUnpackingTransformer
        EXAMPLE = '''
        a = {1: 1, **dict_a}
        '''
        EXPECTED = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
    
        a = _py_backwards_merge_dicts([{1: 1}], dict_a)
        '''

    Test.run()

# Generated at 2022-06-12 03:29:25.139194
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import transformer
    from ..utils.fixtures import dict_unpacking
    transformer = transformer(DictUnpackingTransformer)
    transformer.module(dict_unpacking)

# Generated at 2022-06-12 03:29:33.909120
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_program

    source = '''
    a = {1: 1}
    b = {**a}
    c = {**b}
    d = {2: 2, **b}
    e = {3: 3, **b, **c}
    f = {**a, **a}
    '''

# Generated at 2022-06-12 03:29:38.780981
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse
    from ..utils.tree_builder import build
    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    result = DictUnpackingTransformer().visit(build(source))
    assert unparse(result) == expected

# Generated at 2022-06-12 03:29:47.265443
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.test import compile_to_unparseable, compile_to
    from .utils import transform

    source = "f(1, **{1:2})"
    assert compile_to_unparseable(source)
    assert compile_to(source, DictUnpackingTransformer) == \
        "f(1, **_py_backwards_merge_dicts([{1: 2}], ))"

    source = "{1: 1, **dict_a, **dict_b, 2: 2}"
    assert compile_to_unparseable(source)
    result = compile_to(source, DictUnpackingTransformer)
    assert result == "_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)"


# Generated at 2022-06-12 03:29:53.876033
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse(
        "a = {1: 1, **{2: 2}}")

# Generated at 2022-06-12 03:30:02.660248
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    unpacking_dict = ast.parse_piece('{1: 2, **dict_a}')  # type: ast.Dict

    # No unpacking
    assert transformer.visit(  # type: ignore
        ast.parse_piece('{1: 2}')) == ast.parse_piece('{1: 2}')

    # One unpacking
    assert transformer.visit(  # type: ignore
        unpacking_dict) == ast.parse_piece('''
_py_backwards_merge_dicts([{1: 2}], dict_a)
'''.strip())

    # Several unpacking

# Generated at 2022-06-12 03:30:06.766265
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dut = DictUnpackingTransformer()
    node = ast.parse('{k: v}')  # type: ignore
    assert dut.visit(node) == ast.parse('_py_backwards_merge_dicts([{k: v}])')  # type: ignore


# Generated at 2022-06-12 03:30:17.254585
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast_for_source
    from ..transformers.base import BaseNodeTransformer
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer

    source = '''
        dict_a = {1: 2} 
        dict_b = {1: 1, **dict_a}'''

# Generated at 2022-06-12 03:30:27.416199
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import assert_equal_ignore_ws, parse

    def _test(source, expected):
        node = parse(source, 'exec')
        new_node = DictUnpackingTransformer().visit(node)
        assert isinstance(new_node, ast.Module)
        assert_equal_ignore_ws(expected, ast.dump(new_node))

    _test('''
        a = {1: 2, **{3: 4}}
    ''', '''
        _py_backwards_merge_dicts([{1: 2}], {3: 4})
    ''')

# Generated at 2022-06-12 03:30:33.616855
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = '''
    def f():
        return {1: 1, 2: 2}
    '''
    expected_code = '''
    _py_backwards_merge_dicts = lambda x, *xs: 0
    def f():
        return {1: 1, 2: 2}
    '''
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)
    assert DictUnpackingTransformer().visit(tree) == expected_tree


# Generated at 2022-06-12 03:30:43.176936
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    body = [ast.Expr(value=ast.Dict(
        keys=[ast.Num(n=1), None],
        values=[ast.Num(n=1), ast.Dict(keys=[], values=[])]))]
    expected = merge_dicts.get_body() + [
        ast.Expr(ast.Call(
            func=ast.Name(id='_py_backwards_merge_dicts'),
            args=[ast.List(elts=[
                ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)]),
                ast.Dict(keys=[], values=[])])],
                keywords=[]))]
    assert DictUnpackingTransformer().visit(ast.Module(body=body)) == \
           ast.Module(body=expected)

# Generated at 2022-06-12 03:30:45.486412
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert ast.dump(
        DictUnpackingTransformer().visit(
            ast.parse(""))) == "Module(body=[])"



# Generated at 2022-06-12 03:30:52.421210
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = "def test(): pass"
    tree = ast.parse(code)
    transformer = DictUnpackingTransformer()

    new_tree = transformer.visit(tree)
    function_definitions = [
        node for node in new_tree.body
        if isinstance(node, ast.FunctionDef)]

    assert len(function_definitions) == 1
    function_definition = function_definitions[0]
    assert function_definition.name == 'test'


# Generated at 2022-06-12 03:30:58.552871
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import transform_and_compare
    from ..utils.tree import ast_to_text

    expected = ast_to_text(ast.parse('_py_backwards_merge_dicts([{1: 3}], dict_a)'))
    transform_and_compare(
        DictUnpackingTransformer,
        {1: 3, **ast.Name(id='dict_a', ctx=ast.Load())},
        expected)

# Generated at 2022-06-12 03:31:07.842076
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    class DummyTransformer(BaseNodeTransformer):
        def visit_Dict(self, node):
            return super().visit_Dict(node)

    transformer = DictUnpackingTransformer(DummyTransformer())
    code = '''{}'''
    result = transformer.visit(ast.parse(code))
    assert str(result) == '<modal_transformer.DictUnpackingTransformer object at 0x7f12e7aa8b70>'



# Generated at 2022-06-12 03:31:11.524669
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{}')
    DictUnpackingTransformer().visit(module)
    assert isinstance(module.body[0], ast.FunctionDef)
    assert module.body[0].name == '_py_backwards_merge_dicts'


# Generated at 2022-06-12 03:31:15.353576
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse("{1:1, **{'a': 2}, 2: 3}")
    assert compile(DictUnpackingTransformer().visit(node),
                   '<string>', 'exec')


# Generated at 2022-06-12 03:31:20.045045
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2}], {})')
    actual = DictUnpackingTransformer().visit(ast.parse('{1: 1, 2: 2}'))
    assert ast.dump(expected) == ast.dump(actual)



# Generated at 2022-06-12 03:31:29.750934
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
        {1: 1, **dict_a, 2: 2, 3: 3, **dict_b, 4: 4}
    """

    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    """

    module = ast.parse(source)
    module = DictUnpackingTransformer().visit(module)
    module = DictUnpackingTransformer().visit(module)
    module = DictUnpackingTransformer().visit(module)
    module = DictUnpackingTransformer().visit(module)
    module = DictUnpackingTransformer().visit(module)
    module = DictUnpackingTransformer().visit(module)
    module = DictUnpackingTrans

# Generated at 2022-06-12 03:31:40.633459
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import compile_isolated

    src = '''
        a = {1: 2, 2: 3, **{3: 4, 5: 6}}
        b = {1: 2, 2: 3, **{3: 4}}
        c = {1: 2, **{3: 4}, 2: 3}
        d = {1: 2, **{3: 4}, **{5: 6}}
    '''


# Generated at 2022-06-12 03:31:49.951731
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    m = ast.parse('assert a == {1: 2, **b} + {4: 5, **{6: 7}}')
    DictUnpackingTransformer().visit(m)

# Generated at 2022-06-12 03:32:00.057259
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from unittest.mock import patch
    from ..utils.testing import assert_programs_equal

    DictUnpackingTransformer._tree_changed = False

    node = ast.Dict(keys=[None,
                          ast.Str(s='hello'),
                          ast.Num(n=9)],
                   values=[ast.Dict(keys=[ast.Str(s='q')],
                                    values=[ast.Num(n=9)]),
                           ast.Num(n=1),
                           ast.Num(n=2)])

# Generated at 2022-06-12 03:32:08.342830
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import Dict, Any
    import astunparse

    def transform(s: str) -> str:
        return astunparse.unparse(
            DictUnpackingTransformer().visit(ast.parse(s)))

    assert transform('{1: 1}') == '{1: 1}'
    assert transform('{1: 1, 2: 2}') == '{1: 1, 2: 2}'
    assert transform('{1: 1, **{2: 2}}') == '_py_backwards_merge_dicts([{1: 1}], {2: 2})'
    assert transform('{1: 1, **{2: 2}, **{3: 3}}') == '_py_backwards_merge_dicts([{1: 1}], {2: 2}, {3: 3})'
   

# Generated at 2022-06-12 03:32:17.419461
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest


# Generated at 2022-06-12 03:32:31.766827
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    def perform(source: str) -> str:
        tree = ast.parse(source)
        transformer.visit(tree)
        return ast.fix_missing_locations(tree).body[0].value.s

    # case: no unpacking
    source = '[1, 2, 3]'
    expected = '[1, 2, 3]'
    assert perform(source) == expected


    # case: no unpacking, but has comments
    source = '[1, 2, 3]  # foo'
    expected = '[1, 2, 3]  # foo'
    assert perform(source) == expected


    # case: unpacking with two key-value pairs
    source = '{1: 2, **dict_a}'

# Generated at 2022-06-12 03:32:39.317337
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astor.code_gen import to_source
    from ..utils.fixtures import DictUnpacking
    from ..utils.source import split_module_from_code
    from ..visitor import Visitor

    DictUnpacking.source = DictUnpacking.source.format(
        dict_a=to_source(DictUnpacking.dict_a),
        dict_b=to_source(DictUnpacking.dict_b))
    node_module, _ = split_module_from_code(DictUnpacking.source)
    node_module.body.insert(0, merge_dicts.get_body())

    visitor = Visitor()
    visitor.visit(node_module)
    assert visitor.result == DictUnpacking.target


# Generated at 2022-06-12 03:32:48.792341
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    trans = DictUnpackingTransformer(module=None)

    # Test with not more than one None in keys.
    x = ast.Dict(keys=[None, None, None],
                 values=[ast.Num(1), ast.Num(2), ast.Num(3)])
    assert isinstance(trans.visit(x), ast.Call)  # type: ignore
    x = ast.Dict(keys=[None, None, None],
                 values=[ast.Num(1), ast.Num(2), ast.Num(3)])
    assert isinstance(trans.visit(x), ast.Call)  # type: ignore
    x = ast.Dict(keys=[None, None],
                 values=[ast.Num(1), ast.Num(2), ast.Num(3)])

# Generated at 2022-06-12 03:32:52.929437
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree1 = ast.parse("""{**dict_a}""")
    DictUnpackingTransformer().visit(tree1)

    tree2 = ast.parse("""{**dict_a}""")
    insert_at(0, tree2, merge_dicts.get_body())

    assert ast.dump(tree1) == ast.dump(tree2)



# Generated at 2022-06-12 03:32:59.678657
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src_code = """
    def foo():
        x = {1: 1, **dict_a, 2: 2, **dict_b}
    """

    expected_src_code = """
    def foo():
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    """

    assert expected_src_code == BaseNodeTransformer.to_source(
        src_code=src_code,
        node_transformer_class=DictUnpackingTransformer,
    )

# Generated at 2022-06-12 03:33:06.782249
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
        {1: 1, 2: 2, **a}
    """
    old_tree = ast.parse(source)

    new_tree = DictUnpackingTransformer().visit(old_tree)

    new_source = compile(new_tree, '<ast>', 'exec')
    exec(new_source)
    assert locals()['__dict_comp_result'] == {1: 1, 2: 2, 5: 5, 6: 6}

    # Test that transformers does not change the AST if there is no changes
    # in tree.
    assert DictUnpackingTransformer().visit(new_tree) == new_tree

# Generated at 2022-06-12 03:33:08.924092
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_base import TestBase
    from .test_base import run_test_on_input
    return run_test_on_input(__file__, 'def x():\n a = {1:1, **{2:2}}\n')



# Generated at 2022-06-12 03:33:17.665744
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class T(DictUnpackingTransformer):
        _tree_changed = False
        _transformed = None

    node = ast.Dict(
        keys=[None, ast.Num(n=1), None, None, ast.Num(n=2), None, None, None],
        values=[
            ast.Name(id='dict_a'),
            ast.Num(n=1),
            ast.Name(id='dict_b'),
            ast.Name(id='dict_c'),
            ast.Num(n=2),
            ast.Name(id='dict_d'),
            ast.Name(id='dict_e'),
            ast.Name(id='dict_f')
        ]
    )

    T.visit(node)

    assert T._tree_changed

# Generated at 2022-06-12 03:33:18.778795
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:33:26.813078
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.tree import dump_tree
    from textwrap import dedent

    code = dedent('''
    import time
    import datetime
    {a: 2, **{b: 3}}
    ''').strip()

    expected = dedent('''
    import time
    import datetime
    _py_backwards_merge_dicts([{a: 2}], {b: 3})
    ''').strip()

    tree = ast.parse(code)
    tree = DictUnpackingTransformer().visit(tree)
    assert expected == astor.to_source(tree).strip()
    assert 'Dict' not in dump_tree(tree)

# Generated at 2022-06-12 03:33:37.628081
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.example import example

    with example('{1: 2, **foo, 3: 4}') as (source, module):
        DictUnpackingTransformer.transform(module)
        print(source.eval())



# Generated at 2022-06-12 03:33:47.550838
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:33:57.823575
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import dis
    import inspect
    import textwrap
    import astor

    module = ast.parse(textwrap.dedent('''\
        {'a': 1, **{'b': 2}, 'c': 3, **{'d': 4}}
    '''))

    func = ast.parse(textwrap.dedent('''\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
    '''))

    DictUnpackingTransformer().visit(module)

    output = astor.to_source(module)

# Generated at 2022-06-12 03:34:08.472609
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Test with dict unpacking
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    source_ = '''
        {1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5, **{6: 6}, 7: 7, **{8: 8}}
    '''
    expected_ = '''
        _py_backwards_merge_dicts([{1: 1, 3: 3, 5: 5, 7: 7}], {2: 2}, {4: 4}, {6: 6}, {8: 8})
    '''
    tree = source(source_, '3.7')
    out = str(DictUnpackingTransformer().visit(tree))
    assert compare_ast(out, expected_)
    # Test with dict unpacking

# Generated at 2022-06-12 03:34:16.051565
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class MockDict(Mock):
        keys = [None, ast.Num(1), ast.Num(2), None, ast.Num(3)]
        values = [ast.Num(1), ast.Num(1), ast.Num(1), ast.Num(1), ast.Num(1)]

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-12 03:34:22.909345
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    source = """{1: 1, 3: 3, None: {4: 4}, 2: 2, None: {5: 5}, None: {6: 6}}"""
    expected = """\
_py_backwards_merge_dicts([{1: 1, 3: 3, 2: 2}, {4: 4}, {5: 5}, {6: 6}])"""
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-12 03:34:32.307077
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.example import example_module

    a = example_module('{1: 1, 2: 2, **{3: 3, **{4: 4, 5: 5}}}')
    assert str(a) == '{1: 1, 2: 2, 3: 3, 4: 4, 5: 5}'

    a = example_module('{**{1: 1}, **{2: 2, 3: 3}, **{4: 4}}')
    assert str(a) == '{1: 1, 2: 2, 3: 3, 4: 4}'

    a = example_module('{1: 1, **{**{2: 2}}}')
    assert str(a) == '{1: 1, 2: 2}'

# Generated at 2022-06-12 03:34:35.360941
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import expect_equal

    code = '''
    {'foo': x, **a, 'bar': y}
    '''
    expect_equal(
        DictUnpackingTransformer,
        code,
        '''
        _py_backwards_merge_dicts([{'foo': x, 'bar': y}], a)
        ''')

# Generated at 2022-06-12 03:34:43.691505
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse("""{1: 1, **dict_a, 2: 2}""")
    DictUnpackingTransformer().visit(module)


# Generated at 2022-06-12 03:34:52.183865
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .misc import do_test


# Generated at 2022-06-12 03:35:14.254491
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test visit_Dict method of class DictUnpackingTransformer."""
    tree = ast.parse(
        """
d = {'a': 1, 'b': 2, **c}
        """
    )
    new_tree = DictUnpackingTransformer().visit(tree)  # type: ignore
    assert ast.dump(tree) != ast.dump(new_tree)

# Generated at 2022-06-12 03:35:19.981729
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from . import run_transformer
    from ..utils.snippet import snippet
    snippet = snippet('4.4') + '\n' + merge_dicts.get_body()
    code = '{1: 1, **dict_a}\n'
    expected = '{\n    1: 1\n}\n'
    run_transformer(DictUnpackingTransformer, snippet, code, expected)

# Generated at 2022-06-12 03:35:28.494178
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from .test_utils import assert_equal_with_printing, round_trip

    # expr = "{1: 2, **{3}}"
    expr = "{1: 2, **{3}}"
    actual = round_trip(expr)
    assert_equal_with_printing(
        actual, unparse(DictUnpackingTransformer().visit(actual)))

    # expr = "{4: 5, 6: 7, **{8: 9}, **other_dict}"
    expr = "{4: 5, 6: 7, **{8: 9}, **other_dict}"
    actual = round_trip(expr)
    assert_equal_with_printing(
        actual, unparse(DictUnpackingTransformer().visit(actual)))

    # expr = "{1: 2, **{3

# Generated at 2022-06-12 03:35:38.202220
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from compile_ast import compile_ast

    original_code = '''\
{1: 2, ** {3: 4, None: 5}}
'''
    expected_code = '''\
_py_backwards_merge_dicts([{1: 2}, {3: 4}], dict({5}))
'''
    expected_ast = \
        ast.parse(expected_code)
    assert expected_ast.body[0].body[0].value == \
        ast.parse(expected_code).body[0].value
    transformed_ast = DictUnpackingTransformer().visit(
        ast.parse(original_code))
    assert compile_ast(expected_ast) == compile_ast(transformed_ast)

# Generated at 2022-06-12 03:35:48.262510
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:35:54.024763
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from ..codegen import to_source
    from ..utils.tree import get_tree

    code = '''
    def func(a, b):
        return {1: 1, **a, 2: 2, **b}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    def func(a, b):
        return _py_backwards_merge_dicts(
            [{1: 1}, {2: 2}],
            a,
            b)
    '''
    tree = get_tree(code)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-12 03:36:04.192229
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """\
    a = {1: 1, 2: 2}
    b = {**a}
    c = {3: 3, 4: 4, **a}
    d = {5: 5, 6: 6, **b, 7: 7}
    e = {8: 8, 9: 9, **a, 10: 10, **b}
    """

# Generated at 2022-06-12 03:36:15.052478
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    import astunparse
    
    t = DictUnpackingTransformer()
    
    def tt(*pairs):
        d = ast3.Dict(keys=[k for k, _ in pairs], values=[v for _, v in pairs])
        t.visit(d)
        return astunparse.unparse(d)
    
    # ordinary dicts
    assert tt((1, 2)) == '{1: 2}'
    assert tt((1, 2), (3, 4)) == '{1: 2, 3: 4}'
    
    # single unpacking
    assert tt((1, 2), (None, 3)) == '_py_backwards_merge_dicts([{1: 2}], 3)'
    
    # multiple unpacking
    assert t

# Generated at 2022-06-12 03:36:24.067917
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    # {1: 1, **dict_a}
    result = transformer.visit(
        ast.parse("{1: 1, **dict_a}").body[0].value)
    assert result == ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a)").body[0].value
    # {1: 1, **dict_a, **dict_b, 2: 2}
    result = transformer.visit(
        ast.parse("{1: 1, **dict_a, **dict_b, 2: 2}").body[0].value)

# Generated at 2022-06-12 03:36:30.930264
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_pyast
    from typed_ast import ast3 as ast
    source = '''
        d = {1: 1, **d1}
    '''
    expected = '''
        d = _py_backwards_merge_dicts([{1, 1}], d1)
    '''
    assert_equal_pyast(ast.parse(source), ast.parse(expected),
                       DictUnpackingTransformer)

# Generated at 2022-06-12 03:37:43.013620
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_astunparse import unparse
    from ..utils.fixtures import basic_fixtures


# Generated at 2022-06-12 03:37:47.940441
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """def f():
        {1: 'a', None: [{2: 'b'}], **{3: 'c'}}"""
    transpiled, _ = DictUnpackingTransformer().visit(ast.parse(code))
    expected = """
    def f():
        _py_backwards_merge_dicts([{1: 'a'}, dict({2: 'b'})], {3: 'c'})
    """
    assert ast.dump(transpiled) == expected

# Generated at 2022-06-12 03:37:57.674256
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    snippet = """\
        {1: 2, 3: 4, **None, **{"a": 5, "b": 1, **None, **{"d": 8}}}
        """
    compiler = DictUnpackingTransformer()
    compiler.visit(ast.parse(snippet))  # type: ignore
    expected = """\
        _py_backwards_merge_dicts([{1: 2, 3: 4}], {'a': 5, 'b': 1}, {'d': 8})
        """
    assert compiler._patched_code == expected

    snippet = """\
        {1: 2, 3: 4, **None, **{"a": 5, "b": 1, **None, **{"d": 8}}, **{"m": "n"}}
        """
    compiler = DictUnpackingTransformer()
   

# Generated at 2022-06-12 03:38:05.377065
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Arrange
    from ..utils.tree import parse_ast
    from ..utils.source import dedent

    source = dedent('''
        {1: 2, **{3: 4}, 5: 6}
        ''')
    tree = parse_ast(source)

    transformer = DictUnpackingTransformer()

    # Act
    transformer.visit(tree)

    # Assert
    expected = dedent('''
        _py_backwards_merge_dicts([{1: 2}], {3: 4}
                                            , {5: 6})
        ''')
    assert transformer.as_string(tree).strip() == expected


# Generated at 2022-06-12 03:38:10.670284
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .fixtures import DictUnpackingTransformer_visit_Dict

    bytecode = DictUnpackingTransformer_visit_Dict['bytecode']
    tree = DictUnpackingTransformer_visit_Dict['tree']

    # TODO: implement
    res = DictUnpackingTransformer().visit(tree)
    res = compile(res, '', 'exec')
    assert bytecode == res.co_code

# Generated at 2022-06-12 03:38:18.817862
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from inline_modules.utils.ast_util import node_to_string
    from inline_modules.parser import parse_py

    code_snippet = '''
    {
        **{'a': 1},
        'a': 2,
        **{'b': 1}
    }
    '''

    expected = '''
    _py_backwards_merge_dicts(
        [
            dict({'a': 1}),
            {'a': 2},
            dict({'b': 1})
        ]
    )
'''

    node = parse_py(code_snippet)
    result = DictUnpackingTransformer().visit_Module(node)
    assert node_to_string(result) == expected

# Generated at 2022-06-12 03:38:21.650614
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from .cst import parse
    from .cst import unparse
    example = "{1: 1, 2: 2, **b}"
    parsed = parse(example)
    transformed = DictUnpackingTransformer().visit(parsed)
    unparsed = unparse(transformed)
    print(astor.to_source(transformed))



# Generated at 2022-06-12 03:38:26.782920
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.astdump import ast_dump

    code = '''{None: dict_a, **dict_b}'''

    expected_code = '''
        _py_backwards_merge_dicts([dict()], dict_b)'''

    expected_node = ast_dump(expected_code)
    actual_node = DictUnpackingTransformer().visit(ast_dump(code))

    assert expected_node == actual_node

# Generated at 2022-06-12 03:38:34.809465
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    @snippet
    def test():
        assert ({1: 2, **{3: 4}} == {1: 2, 3: 4})
        assert ({1: 2, **{3: 4}, **{5: 6}} == {1: 2, 3: 4, 5: 6})
        assert ({1: 2, **{3: 4}, **{5: 6}, 7: 8} == {1: 2, 3: 4, 5: 6, 7: 8})
        assert ({1: 2, **{3: 4}, 5: 6, **{7: 8}} == {
            1: 2, 3: 4, 5: 6, 7: 8})

    test.check()
    assert test.failed_implementations == []

# Generated at 2022-06-12 03:38:39.665902
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # Given
    transformer = DictUnpackingTransformer()
    node = ast.parse('a = {1: 1, None: add(1, 2)}')  # type: ast.Module
    # When
    actual = transformer.visit(node)
    # Then
    assert actual.body[1].value.func.id == '_py_backwards_merge_dicts'

