

# Generated at 2022-06-12 03:29:04.553852
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformerUnitTest
    from ... import run_python_module
    from ..._test_utils.params import params_from_ast

    # Testing method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:29:14.262555
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseTestTransformer
    
    class TestDictUnpackingTransformer(BaseTestTransformer):
        Transformer = DictUnpackingTransformer

# Generated at 2022-06-12 03:29:22.615701
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    code = '{1: 1, 2: 2, **a, **b, 3: 3, **c}'
    tree = ast.parse(code)

    new_tree = transformer.visit(tree)

    # Note: `ast.dump` is stable only in version 3.8+

# Generated at 2022-06-12 03:29:32.725340
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    import astor

    from ..utils.testing import get_node

    class TestDictUnpackingTransformer(unittest.TestCase):
        def test_simple(self):
            node = get_node('{1: 1, **dict_a}')  # type: ast.Dict
            
            transformer = DictUnpackingTransformer()
            result = transformer.visit(node)  # type: ast.Call
            self.assertEqual(astor.to_source(result),
                             '_py_backwards_merge_dicts([{1: 1}], dict_a)')

        def test_3_dicts_2_unpackings(self):
            node = get_node('{1: 1, 3: 3, **dict_a, **dict_b}')
            


# Generated at 2022-06-12 03:29:42.307001
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:29:46.228806
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    source_str = """
        {1: 2, **c, 3: 4}
        """
    source_ast = ast.parse(source_str)
    expected_str = """
        _py_backwards_merge_dicts([{1: 2, 3: 4}], c)
        """
    expected_ast = ast.parse(expected_str)

    transformed_ast = transformer.visit(source_ast)
    assert ast.dump(transformed_ast) == ast.dump(expected_ast)
    assert transformer._tree_changed == True

# Generated at 2022-06-12 03:29:55.824812
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils import codegen

    old_code = """\
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4, **dict_c, 5: 5}
        """
    new_code = """\
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4, 5: 5}], dict_a, dict_b, dict_c)
        """
    transformer = DictUnpackingTransformer()
    old_node = codegen.to_module(old_code)
    new_node = codegen.to_module(new_code)
    assert transformer.visit(old_node) == new_node

# Generated at 2022-06-12 03:30:03.668988
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    f = '''{1: 1, **dict_a, 2: 2, **dict_b}'''
    node = ast.parse(f).body[0]
    assert isinstance(node, ast.Expr)
    result = transformer.visit(node)
    assert isinstance(result, ast.Call)
    assert isinstance(result.func, ast.Name)
    assert result.func.id == '_py_backwards_merge_dicts'
    assert len(result.args) == 1
    assert isinstance(result.args[0], ast.List)
    assert len(result.args[0].elts) == 3



# Generated at 2022-06-12 03:30:14.199978
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tree = ast.parse("{1: 1, 2: 2, 3: 3, **{1: 1, 2: 2, 3: 3}}")
    DictUnpackingTransformer().visit(tree)
    expected_tree = ast.parse(
        "def _py_backwards_merge_dicts(dicts):\n"
        "    result = {}\n"
        "    for dict_ in dicts:\n"
        "        result.update(dict_)\n"
        "    return result\n"
        "_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], {1: 1, 2: 2, 3: 3})")
    assert ast.dump(tree) == ast.dump(expected_tree)

# TODO: add test case for this method


# Generated at 2022-06-12 03:30:24.584190
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:30:36.897386
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.node import print_ast
    from ..utils.compare import equal_ast_except_names

    tree = ast.parse("""
    {1: 1, None: 2, 3: 3, None: None, 4: None, None: {}}
    """)
    expected = ast.parse("""
    _py_backwards_merge_dicts([{1: 1, 3: 3, 4: None}], 2, None, {})
    """)
    result = DictUnpackingTransformer().visit(tree)

    assert equal_ast_except_names(expected, result)

# Generated at 2022-06-12 03:30:44.936630
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .utils import assert_equal_ast

    snippet1 = '{1, **dict_a, **dict_b, 2, **dict_c}'
    snippet2 = '{1, 2, **dict_a, **dict_b, **dict_c}'
    snippet3 = '{**dict_a}'
    snippet4 = '{**dict_a, **dict_b}'
    snippet5 = '{**dict_a, **dict_b, **dict_c}'

    expected1 = '{1, **_py_backwards_merge_dicts([{2}], dict_a, dict_b, dict_c)}'
    expected2 = '{1, 2, **_py_backwards_merge_dicts([], dict_a, dict_b, dict_c)}'
    expected3

# Generated at 2022-06-12 03:30:54.741521
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = '''
    {1: 2, None: [1], 2: 3, None: {3: [3]} }
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 2, 2: 3}, dict([1]), {3: [3]}])
    '''
    tree = ast.parse(src)
    DictUnpackingTransformer()(tree)
    result = compile(tree, filename='', mode='exec')
    exec(result)
    assert _py_backwards_merge_dicts([{1: 2, 2: 3}, {1}, {3: [3]}]) == {1: 3, 2: 3, 3: [3]}

# Generated at 2022-06-12 03:31:02.644758
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    from .test_BaseNodeTransformer import NodeTransformerTestCase
    source = """{
    1: 1,
    **{'x': "a"},
    2: 2,
    **{'y': "b"},
    3: 3,
    **{'z': "c"},
    4: 4,
}
"""
    expected = """{
    1: 1,
    2: 2,
    3: 3,
    4: 4,
}
"""
    tree = parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    actual = compile(tree, '<test>', 'exec')
    actual = dict(actual.co_names, **actual.co_consts)

# Generated at 2022-06-12 03:31:03.630536
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:31:10.108414
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    source = '''
    {1: a, **b, 2: c, **d, 3: e}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: a, 2: c}, b, {3: e, 2: c}, d, {3: e}])
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert astor.to_source(new_tree).strip() == expected.strip()



# Generated at 2022-06-12 03:31:18.371491
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    assert transformer.visit_Dict(
        ast.parse('{1: 1, **{2: 2}, 3: 3}').body[0].value) == \
        ast.parse('_py_backwards_merge_dicts(list({1: 1}.items()), {2: 2}, {3: 3})').body[0].value
    assert transformer.visit_Dict(
        ast.parse('{1: 1}').body[0].value) == \
        ast.parse('dict({1: 1})').body[0].value



# Generated at 2022-06-12 03:31:25.378586
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Callable:
        def __call__(self, obj: ast.AST) -> ast.AST:
            return obj
    transformer = DictUnpackingTransformer(Callable())

    def to_ast(text: str) -> ast.AST:
        return ast.parse(text).body[0].value

    assert transformer.visit_Dict(to_ast('{}')) == to_ast('{}')
    assert transformer.visit_Dict(to_ast('{1: 1}')) == to_ast('{1: 1}')
    assert transformer.visit_Dict(to_ast('{1: 1, **_}')) == to_ast(
        '_py_backwards_merge_dicts([{1: 1}], _)')

# Generated at 2022-06-12 03:31:33.398384
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """
    {1: 1, **dict1, **dict2}
    """
    expected_code = """
    _py_backwards_merge_dicts([{1: 1}], dict1, dict2)
    """
    wrapped, tree = parser.suite(code)
    assert isinstance(tree, ast.Module)
    transformer = DictUnpackingTransformer()
    replaced = transformer.visit(tree)  # type: ignore
    assert transformer._tree_changed is True
    assert generator.to_source(replaced) == expected_code

# Generated at 2022-06-12 03:31:43.512915
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    for code in [
            '{1: 2, **{3: 4}}',
            '{1: 2, **{3: 4}, 5: 7}',
            '{None: 2, **{3: 4}, 5: 7}',
    ]:
        node = ast.parse(code)
        DictUnpackingTransformer().visit(node)

# Generated at 2022-06-12 03:31:58.365694
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import compile, dump
    code = ''
    with open(__file__) as f:
        for line in f:
            if line.startswith('# Unit test for method visit_Dict'):
                break
            code += line

    module = compile(code, 4)
    # print(dump(module))

    assert dump(module) == \
"""_py_backwards_merge_dicts([{'a': 1, 'b': 2}],
                             {'c': 3, 'd': 4})
"""

# Generated at 2022-06-12 03:32:07.348381
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    ref = ast.parse("""
    def foo(bar):
        return {**bar, 'baz': 'qux'}
    """)
    t = DictUnpackingTransformer()
    ref = t.visit(ref)

# Generated at 2022-06-12 03:32:15.290895
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import test_utils
    from .. import utils

    code = """
        {1: 2,
         None: dict_a,
         None: dict_b,
         'd': 4}
    """

    expected = """
        _py_backwards_merge_dicts([dict({1: 2, 'd': 4})], dict_a, dict_b)
    """

    tree = test_utils.build_ast(code)

    transformer = DictUnpackingTransformer(utils.get_context())
    transformer.visit(tree)
    result = test_utils.unparse_ast(tree)

    assert result == expected

# Generated at 2022-06-12 03:32:25.944390
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast import compare_ast
    from ..utils.snippet import snippet_to_ast
    
    snippet_ = '\n'.join(snippet())
    code = '{{1: 2}}'
    expected = ast.parse(code)
    result = snippet_to_ast(DictUnpackingTransformer, snippet_, code)
    assert compare_ast(expected, result)

    snippet_ = '\n'.join(snippet())
    code = '{{1: 2, **{3: 4}}}'
    expected = ast.parse('_py_backwards_merge_dicts([{1: 2}], {3: 4})')
    result = snippet_to_ast(DictUnpackingTransformer, snippet_, code)
    assert compare_ast(expected, result)


# Generated at 2022-06-12 03:32:36.435262
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:32:46.337046
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTester
    from .base import assert_equal_ignoring_locations
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Dict
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import NameConstant
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import List
    from ..utils.tree import insert_at
    from astmonkey.transformers import InlineTransformer
    from astmonkey import transformers
    import copy
    import textwrap
    import re
    original_tree = parse(textwrap.dedent("""\
    {
        1: 1,
        **a
    }
    """))
    # (1) Ensure that node is of type ast

# Generated at 2022-06-12 03:32:54.227924
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import transform, expect
    from . import DictUnpackingTransformer, get_root


# Generated at 2022-06-12 03:32:57.346063
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_code = "{1: 1, **{2: 2, 3: 3}}"
    expected_code = "(_py_backwards_merge_dicts([{1: 1}], {2: 2, 3: 3}))"
    actual_code = str(transform_module(test_code, DictUnpackingTransformer))
    assert actual_code == expected_code

# Generated at 2022-06-12 03:33:06.552866
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.converter import convert
    from typed_ast.ast3 import parse

    src_tree = parse(
        "a = {1: 1, **b, f(a): f('c'), **d, g(): g(), **{'e': 'f'}, 'g': 'h'}")
    src_tree = convert(src_tree)

    result = DictUnpackingTransformer().visit(src_tree)
    assert result.body[0].value.func.id == '_py_backwards_merge_dicts'
    assert result.body[0].value.args[0].elts[0].keys[0].n == 1
    assert result.body[0].value.args[0].elts[0].values[0].n == 1

# Generated at 2022-06-12 03:33:11.743963
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import assert_ast_equal

    ast_node = ast.Dict(keys=[ast.Num(n=1), None, None, None, ast.Num(n=2)],
                        values=[ast.Num(n=1),
                                ast.Dict(keys=[ast.Num(n=2)],
                                         values=[ast.Num(n=2)]),
                                ast.Name(id='dict_a'),
                                ast.Dict(keys=[ast.Num(n=3)],
                                         values=[ast.Num(n=3)]),
                                ast.Num(n=3)])


# Generated at 2022-06-12 03:33:40.382669
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    stmt = ast.parse('{**x}')
    tree = DictUnpackingTransformer().visit(stmt)
    assert isinstance(tree, ast.Call)
    assert (ast.dump_ast(tree) == """
    Call(
        func=Name(
            id='_py_backwards_merge_dicts',
            ctx=Load()),
        args=[
            List(
                elts=[
                    Dict(
                        keys=[],
                        values=[
                            Name(
                                id='x',
                                ctx=Load())])])],
        keywords=[])
    """)

    stmt = ast.parse('{1: 2, **x}')
    tree = DictUnpackingTransformer().visit(stmt)
    assert isinstance(tree, ast.Call)

# Generated at 2022-06-12 03:33:50.364206
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest

    import astunparse

    class TestDictUnpackingTransformerVisitDict(unittest.TestCase):
        def _check(self, before, after):
            self.assertEqual(astunparse.unparse(after), astunparse.unparse(
                DictUnpackingTransformer().visit(
                    ast.parse(before))))

        def test_simple(self):
            self._check(
                """
{**a}
                """,
                """
_py_backwards_merge_dicts([dict(a)])
                """
            )


# Generated at 2022-06-12 03:34:00.665411
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def check(code, expected):
        node = ast.parse(code)
        node_ = DictUnpackingTransformer().visit(node)
        code_ = unparse(node_)
        assert code_ == expected

    # This is the main case for testing:
    check('{1: 2, **dict_1}',
          'dicts = _py_backwards_merge_dicts([{1: 2}], dict_1)\n')

    # These are corner cases:
    check('{1: 2, **dict_1, **dict_2}',
          'dicts = _py_backwards_merge_dicts([{1: 2}], dict_1, dict_2)\n')

# Generated at 2022-06-12 03:34:11.024452
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import Iterable, Union

    from typed_ast.ast3 import Module, Dict, Call, Name, List

    from .test_utils import round_trip_text

    def _check(
            text: str,
            expected_text: str) -> None:
        node = round_trip_text(text)
        assert isinstance(node, Module)
        node = DictUnpackingTransformer().visit(node)  # type: ignore
        assert isinstance(node, Module)
        assert round_trip_text(str(node)) == expected_text

    _check(
        '[**x, y]',
        '[*_py_backwards_merge_lists([], x), y]')

# Generated at 2022-06-12 03:34:16.901894
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import tree
    from .. import snippet

    node = tree('''
        {1: 2, **{3: 4}, 5: 6, **{7: 8}}
    ''')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert snippet(result) == '''
        _py_backwards_merge_dicts([{1: 2, 5: 6}], {3: 4}, {7: 8})
    '''


# Generated at 2022-06-12 03:34:27.059505
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def result_ast(xs):
        return inspect.getsource(xs).strip()

    def result_src(xs):
        return astor.to_source(xs).strip()


# Generated at 2022-06-12 03:34:34.045115
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse("{1:1, **dict_a}")
    result = DictUnpackingTransformer.run(node)
    assert result == (
        "def _py_backwards_merge_dicts(dicts):\n"
        "    result = {}\n"
        "    for dict_ in dicts:\n"
        "        result.update(dict_)\n"
        "    return result\n"
        "_py_backwards_merge_dicts([{1: 1}], dict_a)"
    )


# Generated at 2022-06-12 03:34:39.892074
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.parse('{1: 2, **{1: 2, 2: 3}}')
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-12 03:34:48.435617
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    #Test that original code is returned if unpacking operator is not used
    original_ast = ast.parse("a = {'a': 'b', 'c': 'd'}")
    node = original_ast.body[0].value
    assert type(node) == ast.Dict
    transformer = DictUnpackingTransformer()
    transformed_ast = transformer.visit(original_ast)
    transformed_node = transformed_ast.body[0].value
    assert type(transformed_node) == ast.Dict
    assert astunparse.unparse(transformed_node) == "{'a': 'b', 'c': 'd'}"
    #Test that call of function for merging dicts is created if unpacking operator is used

# Generated at 2022-06-12 03:34:54.532970
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.utils import assert_node_equals

    source = """
    dict_ = dict(
        a=1,
        **dict_a,
        **dict_b,
        c=2,
        **dict_c,
        **dict_d,
        e=3,
        **dict_e)
    """
    expected = """
    dict_ = _py_backwards_merge_dicts([{'e': 3}, dict_e, {'c': 2}, dict_d, dict_c, dict_b], dict_a)
    """
    assert_node_equals(source, expected)

# Generated at 2022-06-12 03:36:00.109321
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import Iterable
    from typed_ast import ast3 as ast
    from ..utils.ast_visitor import AstVisitor, visit_tree
    from ..utils.tree import insert_at

    source_code = """
{'a': 1, **kwargs, 'b': 3}
"""

    #
    # Compiles to:
    #
    expected_code = """
_py_backwards_merge_dicts([{'a': 1}], kwargs, {'b': 3})
"""

    node = ast.parse(source_code)

    # Set up mock objects
    class MockKwArgs(object):
        def __init__(self, name):
            self.id = name


# Generated at 2022-06-12 03:36:07.592201
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert ast.dump(DictUnpackingTransformer().visit(
        ast.parse('{1: "Hello", None: 1, 3: 3}', mode='eval'))) == \
        "Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), " \
        "args=[List(elts=[Dict(keys=[Num(n=1), None, Num(n=3)], values=" \
        "[Str(s='Hello'), Num(n=1), Num(n=3)]), Num(n=1)])], keywords=[])"

# Generated at 2022-06-12 03:36:11.323487
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    module = ast.parse("{1: 2, 3: 4, **a, **b}")
    assert ("_py_backwards_merge_dicts("
            "[{1: 2, 3: 4}], "
            "a, "
            "b)") in repr(module)

# Generated at 2022-06-12 03:36:22.076072
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    import astunparse
    from .test_data import DICT_COMPREHENSION, DICT_LITERAL, DICT_LITERAL_UNPACKING, DICT_LITERAL_MERGED
    from .test_data import DICT_COMPREHENSION_UNPACKING, DICT_COMPREHENSION_MERGED
    from .test_data import DICT_COMPREHENSION_UNPACKING_DOUBLE, DICT_COMPREHENSION_MERGED_DOUBLE
    from .test_data import DICT_COMPREHENSION_UNPACKING_TWICE, DICT_COMPREHENSION_MERGED_TWICE
    from .test_data import DICT_COMPREHENSION_UNPACKING

# Generated at 2022-06-12 03:36:32.580977
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed
    from ..utils.testing import assert_transformed_ast
    ast_tree = """
        {1: 1, **dict_a, **dict_b, 2: 2, 3: 3, 4: 4, 5: 5}
    """
    expected_result = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4, 5: 5}], dict_a, dict_b)
    """
    assert_transformed(ast_tree, expected_result, DictUnpackingTransformer)
    assert_transformed_ast(ast_tree, expected_result, DictUnpackingTransformer)
    ast_tree = """
        {**dict_a, **dict_b}
    """

# Generated at 2022-06-12 03:36:42.764656
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def _test_against(before, after, check_ast=True):
        node = ast.parse(before)
        node = DictUnpackingTransformer().visit(node)
        after_ = ast.parse(after)
        if check_ast:
            assert ast.dump(node, False) == ast.dump(after_, False)
        assert compile(node, '', 'exec') == compile(after_, '', 'exec')

    _test_against('{"x": 1}', '{"x": 1}')
    _test_against('{"x": 1, **{"y": 2}}', '_py_backwards_merge_dicts([{"x": 1}], {"y": 2})')


# Generated at 2022-06-12 03:36:48.866569
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """{1:1, *{}, **{}}"""
    target = """_py_backwards_merge_dicts([{1: 1}], {}, {})"""

    def _test(source: str, target: str):
        node = ast.parse(source)
        node = DictUnpackingTransformer().visit(node)
        target_node = ast.parse(target)
        assert ast.dump(node) == ast.dump(target_node)

    _test(source, target)

# Generated at 2022-06-12 03:36:56.340177
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse

    dict_unpacking_transformer = DictUnpackingTransformer()
    tree = ast.parse(
        """{
            1: 1,
            **{2: 2},
            3: 3,
            **{4: 4},
        }"""
    )
    tree = dict_unpacking_transformer.visit(tree)  # type: ignore
    output = unparse(tree, version='3.7')
    assert output == \
        """\
_py_backwards_merge_dicts([{1: 1}, {3: 3}], {2: 2}, {4: 4})
"""


# Generated at 2022-06-12 03:37:05.419998
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    source = """
        {**a, 1: 2, 3: 4, 5: 6, None: 7, 8: 9, None: 10,
         11: 12, **b, 13: 14, 15: 16, **c, 17: 18, 19: 20}
    """
    tree = ast.parse(source)
    result = transformer.visit(tree)
    expected = """
        _py_backwards_merge_dicts([dict(), {1: 2, 3: 4, 5: 6}, 7,
         {8: 9}, 10, {11: 12}, b, {13: 14, 15: 16}, c, {17: 18, 19: 20})
    """
    assert ast.dump(result) == expected

# Generated at 2022-06-12 03:37:10.667382
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..compiler import compile

    code = '''\
{
    1: 1,
    **{},
    **{
        "a": 1,
        1: 2.0
    }
}'''
    expected = '''\
_py_backwards_merge_dicts([{1: 1}], {}, {1: 2.0, 'a': 1})'''
    assert compile(code) == expected



# Generated at 2022-06-12 03:38:40.134163
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    input_ = ast.parse(
        """
        {1: 2, 3: 4, 5: 6, 7: 8, 9: 10, None: 11, 12: 13, 14: 15}
        """
    )
    output = transformer.visit(input_)

# Generated at 2022-06-12 03:38:47.794030
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Test the method `visit_Dict` of class `DictUnpackingTransformer`."""
    from .third_party_code import ast_of
    from .third_party_code import print_ast
    from .third_party_code.ast_tool import find_expr
