

# Generated at 2022-06-12 03:29:02.601574
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    stmt = ast.parse('{1: 2, **dicta, 3: 4, **dictb}')
    assert isinstance(stmt, ast.Module)
    assert len(stmt.body) == 1
    assert isinstance(stmt.body[0], ast.Expr)
    assert isinstance(stmt.body[0].value, ast.Dict)

    expected_stmt = ast.parse('_py_backwards_merge_dicts([{1: 2, 3: 4}], dicta, dictb)')
    assert isinstance(expected_stmt, ast.Module)
    assert len(expected_stmt.body) == 1
    assert isinstance(expected_stmt.body[0], ast.Expr)
    assert isinstance(expected_stmt.body[0].value, ast.Call)

# Generated at 2022-06-12 03:29:08.194077
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import runpy
    module = runpy.run_module(__name__)
    assert module['dict_'] == {'a': 1, 'b': 1, 'c': 1, 'd': 1}

# ============================
# Unit tests for visit_Dict
# ============================

dict_ = {'a': 1, **{'b': 1}, 'c': 1, **{}, 'd': 1}

# Generated at 2022-06-12 03:29:18.365423
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert transformer.visit(
        ast.parse('{1: 1, 2: 2, 3: 3, **a, 4: 4, **b, 5: 5, **c}')) == ast.parse(
        '''
_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, dict(4=4), dict(5=5)], a, b, c)
        ''')

    assert transformer.visit(
        ast.parse('{1: 1, **a, 2: 2, **b, 3: 3, **c}')) == ast.parse(
        '''
_py_backwards_merge_dicts([dict(1=1), dict(2=2), dict(3=3)], a, b, c)
        ''')



# Generated at 2022-06-12 03:29:28.572732
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_tree

    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, 2: 2, 3: 3, **{4: 4, 5: 5}, 6: 6, 7: 7}')
    result = transformer.visit_Module(node)

    assert transformer._tree_changed

# Generated at 2022-06-12 03:29:35.817814
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    nodes = []
    nodes.append(ast.Dict(keys=[None, None, None],
                          values=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)]))
    nodes.append(ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                          values=[ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)]))
    nodes.append(ast.Dict(keys=[None, None, None],
                          values=[ast.Dict(keys=[],
                                           values=[]),
                                  ast.Num(n=2),
                                  ast.Num(n=3)]))
    expected = []

# Generated at 2022-06-12 03:29:43.570835
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    tree = ast.parse("""
    {1: 1, **dict_a}
    """)
    expected = [ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[
            ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)]),
            ast.Name(id='dict_a')])],
        keywords=[])]
    assert list(ast.walk(transformer.visit(tree)))[-1:] == expected



# Generated at 2022-06-12 03:29:46.981437
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    b2t = DictUnpackingTransformer()
    c = b2t.visit(ast.parse('{1: 1, **dict_a}').body[0])
    assert(c.__repr__().startswith('Call'))



# Generated at 2022-06-12 03:29:58.074749
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    source = '{1: 2, None: 3}'
    real_result = '_py_backwards_merge_dicts([{1: 2}], 3)'
    actual_result = transformer.visit(ast.parse(source))
    assert transformer._tree_changed
    assert compile(actual_result, '<test>', 'single').co_consts[0] == \
        compile(real_result, '<test>', 'single').co_consts[0]

    transformer._tree_changed = False
    source = '{1: 2}'
    real_result = '{1: 2}'
    actual_result = transformer.visit(ast.parse(source))
    assert not transformer._tree_changed

# Generated at 2022-06-12 03:30:02.160126
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    input_ = """{1: 1, **{2: 2}, 3: 3, **{4: 4}}"""
    expected = """_py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}], {4: 4})"""
    actual = ast.dump(ast.parse(input_))
    assert actual == expected



# Generated at 2022-06-12 03:30:08.460615
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = "{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}"
    expected = "_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)"
    module = ast.parse(source)
    DictUnpackingTransformer().visit(module)  # type: ignore
    assert_equal(expected, astor.to_source(module).strip())



# Generated at 2022-06-12 03:30:27.497365
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-12 03:30:36.845410
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_helpers import parse, assert_node_equality
    from .test_helpers import wrap_pass
    code = '''\
        {1: 2, **dict_a, None: dict_b, 3: 4, **dict_c}'''
    expected = '''\
        _py_backwards_merge_dicts([
            {1: 2, 3: 4},
            dict_a,
            dict_b,
            dict_c
        ])'''
    transformer = wrap_pass(DictUnpackingTransformer(), code)
    ast_ = parse(code)
    ast_.body = transformer.visit_and_replace(ast_.body)
    assert_node_equality(ast_, expected)

# Generated at 2022-06-12 03:30:44.883222
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest

    from ast_unparse import unparse
    from ..utils.mock_node import MockNode

    class DictUnpackingTransformerTest(unittest.TestCase):
        def test_transform_dict_with_single_unpacking_passed_as_key(self):
            trans = DictUnpackingTransformer()
            result = trans.visit_Dict(MockNode({},
                [(MockNode(1, []), MockNode(2, [])),
                 (None, MockNode(3, []))]))

            self.assertTrue(result.func.id == '_py_backwards_merge_dicts')
            self.assertEqual(
                unparse(result),
                '_py_backwards_merge_dicts([{1: 2}], dict(3))')

# Generated at 2022-06-12 03:30:56.008767
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.asserts import assert_parses_and_transforms

    def _test(before, after, **kwargs):
        assert_parses_and_transforms(
            before,
            __name__ + '.DictUnpackingTransformer.visit_Dict',
            after,
            transformer=DictUnpackingTransformer(**kwargs),
            expected_tree_changed=True)

    _test('{1: 1, 2: 2, **{3: 3, 4: 4}, 5: 5, **{6: 6}}',
          '_py_backwards_merge_dicts([{1: 1, 2: 2, 5: 5}, {3: 3, 4: 4}, {6: 6}])')


# Generated at 2022-06-12 03:31:02.813707
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from source import source
    from ..utils.source import assert_transformation

    assert_transformation(
        DictUnpackingTransformer,
        {1: 2, 3: 4, **dict_b, None: dict_c, **dict_d},
        """
            def foo():
                return _py_backwards_merge_dicts(
                    [{1: 2, 3: 4}],
                    dict_b,
                    None,
                    dict_c,
                    None,
                    dict_d)
        """,
        {'dict_b': source('dict(b=1)'), 'dict_c': source('dict(c=2)'),
         'dict_d': source('dict(d=1)')}
    )

# Generated at 2022-06-12 03:31:08.453767
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import untokenize

    source = '''{1: 2, **a, 3: 4, **b, 5: 6, **c, 7: 8}'''
    expected = '''_py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6, 7: 8}], a, b, c)'''

    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    transformed = untokenize(tree).decode('utf-8')

    assert transformed == expected

# Generated at 2022-06-12 03:31:10.698131
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .fixtures import DictUnpackingTransformer

    DictUnpackingTransformer({1: 2, **{3: 4, 5: 6}})

# Generated at 2022-06-12 03:31:21.236745
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from py_backwards.transformers.base import BaseNodeTransformer
    from typed_ast.ast3 import Name

# Generated at 2022-06-12 03:31:30.958145
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    # Normal case
    # {1: 1, 2: 2, **dict_a}
    # →
    # _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    normal = ast.parse('{1: 1, 2: 2, **dict_a}').body[0]  # type: ignore
    result = transformer.visit_Dict(normal)  # type: ignore
    assert isinstance(result, ast.Call)
    assert result.func.id == '_py_backwards_merge_dicts'
    assert len(result.args) == 1
    assert len(result.args[0].elts) == 1
    assert isinstance(result.args[0].elts[0], ast.Dict)

# Generated at 2022-06-12 03:31:41.941569
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing_utils import mock

    node = mock.Mock(
        keys=[ast.Num(n=1.0), ast.Num(n=2.0), None, ast.Num(n=3.0), None, None],
        values=[ast.Num(n=1.0), ast.Num(n=2.0), ast.Num(n=3.0),
                 ast.Num(n=4.0), ast.Num(n=5.0), ast.Num(n=6.0)])

    transformer = DictUnpackingTransformer()
    node_ = transformer.visit_Dict(node)
    assert transformer._tree_changed


# Generated at 2022-06-12 03:32:01.224864
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..ast_parser import parse
    from ..ast_transformer import AstTransformer
    from ..utils.ast_visitor import print_ast
    from os import path
    from .assert_transformer import TransformAssertion
    from ..utils.visitor import get_visitor_ast

    class TestAstTransformer(AstTransformer):
        transformer = DictUnpackingTransformer

    with open(path.join(path.dirname(__file__), 'test_dict_unpacking.py')) as f:
        src = f.read()


# Generated at 2022-06-12 03:32:08.875493
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    def _get_node(s: str) -> ast.Dict:
        return ast.parse(s).body[0].value

    s = """{'a': 1, **{'b': 2, 'c': 3}, 'd': 4, **{'e': 5}}"""
    node = _get_node(s)
    expected = """_py_backwards_merge_dicts([{'d': 4}],
                                            {'b': 2, 'c': 3},
                                            {'a': 1},
                                            {'e': 5})"""
    expected = _get_node(expected)
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == ast.dump(expected)


# Generated at 2022-06-12 03:32:17.642122
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # {**{}, **{}, **{}} -> _py_backwards_merge_dicts([{}, {}, {}])
    assert (DictUnpackingTransformer().visit(ast.parse("{**{}, **{}, **{}}"))
            == ast.parse("_py_backwards_merge_dicts([{}, {}, {}])"))

    # {**{}, **{}, 1: 2} -> _py_backwards_merge_dicts([{}, {}], {1: 2})
    assert (DictUnpackingTransformer().visit(ast.parse("{**{}, **{}, 1: 2}"))
            == ast.parse("_py_backwards_merge_dicts([{}, {}], {1: 2})"))

    # {**{}, **{}, 1: 2, **d}

# Generated at 2022-06-12 03:32:28.637016
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class Tester(BaseNodeTransformer):
        """Emulates ``visit_Dict`` method of ``DictUnpackingTransformer`` class.

        To simplify tests, ``visit`` method has been overridden to replace target
        call of ``DictUnpackingTransformer`` ``visit_Dict`` method by this.
        """
        def visit_Dict(self, node: ast.Dict) -> Union[ast.Dict, ast.Call]:
            return DictUnpackingTransformer.visit_Dict(self, node)


# Generated at 2022-06-12 03:32:32.825420
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert "result = {}\nfor dict_ in dicts:\n    result.update(dict_)\nreturn result" in merge_dicts.get_body()

    from typed_ast.ast3 import parse, Dict, Name, Call, List
    from .base import do_test

# Generated at 2022-06-12 03:32:39.229368
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from lahja.ast.transformers import DictUnpackingTransformer
    from lahja.ast.utils import transform, dump_ast
    
    transformer = DictUnpackingTransformer()
    expected = ast3.parse(
    """
    _py_backwards_merge_dicts([{0: 2}], {1: 1})
    """)

    initial = ast3.parse(
    """
    {0: 2, **{1: 1}}
    """)

    assert transform(initial, transformer) == expected
    assert dump_ast(transform(initial, transformer)) == dump_ast(expected)

# Generated at 2022-06-12 03:32:48.458293
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import ast_to_str

    test_cases = [
        ({1: 2, **{3: 4}},
         '_py_backwards_merge_dicts([{1: 2}], {3: 4})'),

        ({1: 2, **{3: 4}, 'a': 'b'},
         '_py_backwards_merge_dicts([{1: 2}, {3: 4}, {\'a\': \'b\'}],)')
    ]

    transformer = DictUnpackingTransformer()
    for code, solution in test_cases:
        node = ast.parse(code_to_test.format(code))
        transformer.visit(node)  # type: ignore
        assert ast_to_str(node) == solution

# Generated at 2022-06-12 03:32:56.449196
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    key, value = ast.parse('a: b').body[0].value.keys[0], \
                 ast.parse('a: b').body[0].value.values[0]
    dict_expr = ast.parse('{a: b, **c, **d, **{e: f}}').body[0].value
    prepared = DictUnpackingTransformer().visit(dict_expr)
    assert isinstance(prepared, ast.Call)
    assert prepared.func.id == '_py_backwards_merge_dicts'
    assert len(prepared.args) == 1
    assert len(prepared.keywords) == 0
    assert isinstance(prepared.args[0], ast.List)
    assert len(prepared.args[0].elts) == 3

# Generated at 2022-06-12 03:33:06.064229
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    class DummyVisitor(ast.NodeVisitor):
        pass

    visitor = DictUnpackingTransformer(DummyVisitor())

# Generated at 2022-06-12 03:33:11.309122
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source, sourcerange
    from ..utils.visitor import TreeRebuilder
    from ..utils.tokenize import tokens
    import astor

    source_code = source('''
        {1: 1, 2: 2, **d, **e}
    ''')
    # tokens(source_code)
    tree = ast.parse(source_code)
    tree = TreeRebuilder().visit(tree)
    tree = DictUnpackingTransformer().visit(tree)
    print(astor.to_source(tree))

    source_code = source('''
        {1: 1, **d, 2: 2, **e}
    ''')
    # tokens(source_code)
    tree = ast.parse(source_code)
    tree = TreeRebuilder().vis

# Generated at 2022-06-12 03:33:33.925814
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert inspect.isclass(DictUnpackingTransformer)



# Generated at 2022-06-12 03:33:38.796717
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import compile_restricted
    original = '''
d1 = {1: 1, **d2}
'''
    expected = '''
d1 = _py_backwards_merge_dicts([{1: 1}], d2)
'''
    transform = DictUnpackingTransformer()
    code = compile_restricted(original, transform)
    assert code == expected

# Generated at 2022-06-12 03:33:39.837185
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer

# Generated at 2022-06-12 03:33:45.495806
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
        {'a': 1, **d}
    """
    expected = """
        _py_backwards_merge_dicts([{'a': 1}], d)
    """
    tree = ast.parse(source)
    expected_tree = ast.parse(expected)
    assert (DictUnpackingTransformer().visit(tree) ==
            expected_tree.body[0].value)



# Generated at 2022-06-12 03:33:46.944459
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-12 03:33:57.194072
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    ast_dict1 = ast.Dict(
        keys=[
            ast.Str(s='a'),
            ast.Str(s='b'),
            ast.Str(s='c')
        ],
        values=[
            ast.Num(n=1),
            ast.Num(n=2),
            ast.Num(n=3)
        ]
    )
    ast_dict2 = ast.Dict(
        keys=[
            ast.Str(s='a'),
            ast.Str(s='b'),
            ast.Str(s='c')
        ],
        values=[
            ast.Num(n=4),
            ast.Num(n=5)
        ]
    )

# Generated at 2022-06-12 03:34:07.898362
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..snippets import expr
    from ..transpiler import Transpiler

    original = """
        {
            1: 1,
            'a': 2,
            **{
                'b': 3,
            },
            **{
                **{
                    **{
                        **{
                            **{
                                'c': 4,
                            },
                        },
                    },
                },
            },
            **{
                **{
                    **{
                        'd': 5,
                    },
                },
            },
            'e': 6,
            **{
                'f': 7,
            },
            'g': 8,
        }
    """

# Generated at 2022-06-12 03:34:15.782099
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .misc import TestCase
    from ..utils import as_str
    from ..utils.test_utils import assert_code_equal


# Generated at 2022-06-12 03:34:25.884000
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    code = '''
        def foo(a):
            return {
                1: 1,
                **a,
                2: 2
            }
        '''

    tree = ast.parse(code)
    transformed = DictUnpackingTransformer().visit(tree)  # type: ignore
    updated_ast = ast.dump(transformed)

# Generated at 2022-06-12 03:34:33.061514
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from astunparse import unparse

    m = merge_dicts.get_ast()
    x = ast.parse("{1: 1, **{}, **{2: 2}, **{3: 3}}")
    assert unparse(DictUnpackingTransformer.run(x)) == \
        '_py_backwards_merge_dicts([dict(), {3: 3}, {1: 1}])'
    assert astor.to_source(DictUnpackingTransformer.run(m)) == \
        merge_dicts.get_source()

# Generated at 2022-06-12 03:34:53.181367
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import apply_transformer

    source = """{1: 1, **dict_a}"""
    expected = """def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

_py_backwards_merge_dicts([{1: 1}], dict_a)"""

    result = apply_transformer(source, DictUnpackingTransformer)

    from ..utils.test import check_code
    check_code(expected, result)



# Generated at 2022-06-12 03:35:01.999765
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_astunparse

    module_object = ast.parse(
        '''
        _py_backwards_merge_dicts = {0}
        def f(a, b, **c):
            dict_a = {'a': a}
            dict_b = {'b': b}
            print({'a': 1, **dict_a, 'b': 2, **dict_b})
        '''
    ).body[1]

    module_object.body[2].value.args[0].value.keys[2] = None
    module_object.body[2].value.args[0].value.values[1] = ast.Name(id='dict_a')
    module_object.body[2].value.args[0].value.keys[4] = None

# Generated at 2022-06-12 03:35:03.114134
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    tr = DictUnpackingTransformer()
    assert tr is not None

# Generated at 2022-06-12 03:35:06.287716
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .base import BaseNodeTransformer
    transformer = DictUnpackingTransformer.__new__(DictUnpackingTransformer)
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)


# Generated at 2022-06-12 03:35:08.167573
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer().visit(ast.parse('{1: 1, **{}}'))  # type: ignore

# Generated at 2022-06-12 03:35:11.336982
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast
    import astor

    node = ast.parse('{1: 1, **dict_a}')
    node = DictUnpackingTransformer().visit(node)
    print(astor.to_source(node))

# Generated at 2022-06-12 03:35:18.219241
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()
    target = {}
    dictionary = {**target, '1': 1}
    assert transformer.visit(ast.parse(
        '{\n'
        '    **{},\n'
        '    "1": 1\n'
        '}').body[0]) == ast.parse(
            '_py_backwards_merge_dicts(\n'
            '    [{}],\n'
            '    {"1": 1}\n'
            ')').body[0]

# Generated at 2022-06-12 03:35:24.086171
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module(): # TODO: add this to test suite
    import astunparse
    import functools

    class DictUnpackingTransformer(DictUnpackingTransformer):
        def __init__(self):
            self._tree_changed = False

        def _tree_changed(self, value: bool):
            self._tree_changed = value

    d = DictUnpackingTransformer()
    node = d.visit(ast.parse('''{**{}}'''))
    if not d._tree_changed:
        raise AssertionError('tree is not changed')

# Generated at 2022-06-12 03:35:25.026894
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-12 03:35:25.994225
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-12 03:36:01.576942
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert len(list(ast.parse('{1: 1, **{2: 2}, **{3: 3}}.keys()').body)) == 1
    assert '_py_backwards_merge_dicts' not in globals()
    DictUnpackingTransformer().visit(ast.parse('{1: 1, **{2: 2}, **{3: 3}}'))
    assert '_py_backwards_merge_dicts' in globals()
    assert len(list(ast.parse('{1: 1, **{2: 2}, **{3: 3}}.keys()').body)) == 3

# Generated at 2022-06-12 03:36:08.662207
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    source = ast.parse('''
    {'a': 1, **{'b': 2}, 'c': 3, **{'d': 4}}
    ''')  # type: ast.AST

    expected = ast.parse('''
    _py_backwards_merge_dicts([{'a': 1}, {'c': 3}], {'b': 2}, {'d': 4})
    ''')  # type: ast.AST

    assert transformer.visit(source) == expected

# Generated at 2022-06-12 03:36:10.417709
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer(target=(3, 5))
    assert transformer is not None



# Generated at 2022-06-12 03:36:21.358225
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # prepare environment for test
    source = '''
        var_a = {1: 2, 3: 4, **dict_b}
        var_b = {**dict_a, 'foo': 'bar'}
        var_c = {**dict_a, **dict_b}
        var_d = {1: 2, **dict_a, 3: 4}
        '''

# Generated at 2022-06-12 03:36:22.110582
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    _ = DictUnpackingTransformer()

# Generated at 2022-06-12 03:36:30.883248
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree_builder import tree
    import astor

    @tree
    def tree():
        x = {
            'a': 1,
            **{
                'b': 2,
                'c': 3,
            }
        }

    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(tree)  # type: ignore

    expected_source = '''
    x = _py_backwards_merge_dicts([{'a': 1}], {'b': 2, 'c': 3})
    '''

    assert astor.to_source(transformed).strip() == expected_source


# Generated at 2022-06-12 03:36:40.997592
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = dedent(
        """
        {
            1: 1,
            **dict_a,
            2: 2,
            **dict_b,
            3: 3,
            **dict_c,
            4: 4,
            **dict_d,
        }
        """
    )

    expected = dedent(
        """
        _py_backwards_merge_dicts(
            [
                {
                    1: 1,
                    2: 2,
                    3: 3,
                    4: 4,
                },
                dict_a,
                dict_b,
                dict_c,
                dict_d,
            ]
        )
        """
    )

    tree = ast.parse(code)
    transformer = DictUnpackingTransformer()

# Generated at 2022-06-12 03:36:41.534498
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-12 03:36:45.939580
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_tree_equal
    from ..utils.ast_builder import build

    transformer = DictUnpackingTransformer()
    tree = build("""
    {1: 1, **dict_a}
    """)
    assert_tree_equal(
        transformer.visit(tree),
        tree
    )
    assert transformer.tree_changed

# Generated at 2022-06-12 03:36:51.459624
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert '_py_backwards_merge_dicts' not in merge_dicts.get_body()
    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast.parse(merge_dicts.get_body()))
    assert '_py_backwards_merge_dicts' in result.body[0].body
    assert isinstance(result.body[0], ast.FunctionDef)


# Generated at 2022-06-12 03:37:55.433663
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dump_and_restore_ast(
        '{1: 1, 2: 2, 3: 3, **{4: 4, 5: 5}, **{6: 6, 7: 7}, 8: 8}')



# Generated at 2022-06-12 03:38:04.389127
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astunparse import dump
    from .example import example1
    from .call_chain_transformer import CallChainTransformer
    from .import_transformer import ImportTransformer

    node = example1()
    node = CallChainTransformer().visit(node)
    node = ImportTransformer(
        aliases={'builtins': '_six_moves_builtins'}).visit(node)
    node = DictUnpackingTransformer().visit(node)
    result = dump(node)


# Generated at 2022-06-12 03:38:09.116222
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # python3 -m unittest test_DictUnpackingTransformer.py
    from .base import BaseNodeTransformerTest
    from .test_dict_unpacking import test_data

    class DictUnpackingTransformerTest(BaseNodeTransformerTest):
        transformer = DictUnpackingTransformer

    DictUnpackingTransformerTest().run_tests(test_data)

# Generated at 2022-06-12 03:38:15.986725
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for method visit_Dict of class DictUnpackingTransformer."""
    from ..utils.testing import assert_source

    node = ast.parse("""
        {1: 1, **a, 2: 2, **b, 3: 3, **c}
        """)
    transformer = DictUnpackingTransformer()
    transformer.visit(node)

    assert_source(transformer, """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], a, b, c)
        """)

# Generated at 2022-06-12 03:38:16.834213
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-12 03:38:22.787358
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    module = ast.parse("a = {1: 2, 'a': 'b', **{'c': 3}, 4: 6}")

    transformer = DictUnpackingTransformer()
    result = transformer.visit(module)

    assert isinstance(result, ast.Module)
    assert len(result.body) == 2
    assert isinstance(result.body[0], ast.FunctionDef)
    assert isinstance(result.body[1], ast.Assign)
    assert result.body[1].targets[0].id == 'a'

    value = result.body[1].value
    assert isinstance(value, ast.Call)
    assert value.func.id == '_py_backwards_merge_dicts'
    assert len(value.args) == 2

# Generated at 2022-06-12 03:38:29.483873
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..transformer import Transformer
    code = """
    def f():
        a = {1: 2, **{}}
    
    """
    transformer = Transformer(DictUnpackingTransformer)
    transformed = transformer.transform_source(code)
    mod = compile(transformed, filename='<string>', mode='exec')
    ns = {}
    exec(mod, ns)
    assert ns['f'].__code__.co_filename == code.strip()
    assert ns['f'].__code__.co_name == 'f'
    assert ns['f'].__code__.co_firstlineno == 2

# Generated at 2022-06-12 03:38:33.589349
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_transformers import run_transformers_on_single_test
    run_transformers_on_single_test(
        {'test_dict_unpacking_compile.test_dict_unpacking'},
        DictUnpackingTransformer,
        expected_file='dict_unpacking_ast')

# Generated at 2022-06-12 03:38:42.313380
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.ast import get_ast, dump_ast
    
    code = """
    {None: a, None: b, None: c, d: e, f: g, h: i}
    """
    module = get_ast(code)
    DictUnpackingTransformer().visit(module)
    expected = """
    _py_backwards_merge_dicts([{'f': g, 'h': i}], a, b, c)
    """
    assert dump_ast(module) == expected

    code = """
    {a: b, None: c, d: e, None: f, g: h, None: i}
    """
    module = get_ast(code)
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-12 03:38:43.437743
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)