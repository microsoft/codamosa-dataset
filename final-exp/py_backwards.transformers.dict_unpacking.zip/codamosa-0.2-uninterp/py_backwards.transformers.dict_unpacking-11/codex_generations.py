

# Generated at 2022-06-17 23:57:33.623097
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

    # Test that visitor works correctly
    TestVisitor().visit(tree)

# Generated at 2022-06-17 23:57:42.752040
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    """

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return DictUnpackingTransformer().visit(node)

    tree = source_to_ast(source)
    Visitor().visit(tree)
    result = ast_to_source(tree)
    assert result == expected

# Generated at 2022-06-17 23:57:52.560834
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-17 23:58:04.369257
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

    # Test that visitor works correctly
    class TestVisitor(NodeVisitor):
        def __init__(self):
            self.visited = []



# Generated at 2022-06-17 23:58:14.037708
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:58:22.461707
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import print_ast

    code = """
    {1: 1, **dict_a}
    """
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert source(tree) == """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """


# Generated at 2022-06-17 23:58:27.655703
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, **dict_a}')
    result = transformer.visit(node)
    assert_equal(ast_to_str(result), '_py_backwards_merge_dicts([{1: 1}], dict_a)')

# Generated at 2022-06-17 23:58:39.878695
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def merge_dicts():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

    @snippet
    def test_snippet():
        {1: 1, **dict_a}


# Generated at 2022-06-17 23:58:46.668605
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module = parse_ast(source)
    DictUnpackingTransformer().visit(module)
    assert_equal_source(expected, module)

# Generated at 2022-06-17 23:58:55.392412
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-17 23:59:14.568326
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:59:22.655278
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import make_call_test
    from ..utils.tree import ast_to_str

    make_call_test(DictUnpackingTransformer, 'visit_Dict',
                   '{1: 1, **dict_a}',
                   '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    make_call_test(DictUnpackingTransformer, 'visit_Dict',
                   '{1: 1, **dict_a, 2: 2, **dict_b}',
                   '_py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])')


# Generated at 2022-06-17 23:59:28.161085
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)



# Generated at 2022-06-17 23:59:39.593529
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)])

    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    tree = source_to_ast(source)
    tree = DictUnpackingTransformer().visit(tree)
    tree = Visitor().visit(tree)

# Generated at 2022-06-17 23:59:51.184338
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source
    from ..utils.compare import compare_ast

    source_ = source('''
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, {4: 4}])
    ''')

    tree = ast_from_source(source_)
    tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(tree), dump(ast_from_source(expected)))

# Generated at 2022-06-17 23:59:54.552749
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert ast_to_source(new_tree) == expected
    print_ast(new_tree)



# Generated at 2022-06-18 00:00:02.736897
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)

    code = '''
        {1: 1, 2: 2, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpacking

# Generated at 2022-06-18 00:00:09.776744
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump


# Generated at 2022-06-18 00:00:18.868724
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import get_ast_node

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = get_ast_node(code, ast.Dict)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_equal_ast(result, parse_snippet(expected))

    code = """
        {1: 1, 2: 2, **dict_a}
    """

# Generated at 2022-06-18 00:00:28.917253
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    assert_equal_ast(DictUnpackingTransformer, code, expected)

    code = '{1: 1, 2: 2, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)'
    assert_equal_ast(DictUnpackingTransformer, code, expected)

    code = '{1: 1, **dict_a, 2: 2}'

# Generated at 2022-06-18 00:00:41.667565
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def test_snippet():
        def test_function():
            return {1: 1, **{2: 2}, 3: 3, **{4: 4}}

    tree = ast.parse(source(test_snippet))
    DictUnpackingTransformer().visit(tree)
    print_tree(tree)
    assert source(tree) == source(test_snippet)



# Generated at 2022-06-18 00:00:51.778662
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def __init__(self):
            self.result = []

        def visit_Call(self, node):
            self.result.append(node)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4}
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    visitor = TestVisitor()
    visitor.visit(tree)
    assert len(visitor.result) == 3

# Generated at 2022-06-18 00:00:59.344917
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert_equal_tree(tree, expected)
    assert_equal_source(tree, expected)
    assert_equal_code(tree, expected)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:01:10.547763
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_source
    from ..utils.test_utils import assert_equal_source_with_code
    from ..utils.test_utils import assert_equal_source_with_source

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, **dict_a}")),
        ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a)"))

# Generated at 2022-06-18 00:01:19.166549
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:01:29.188539
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse_source(source)
    expected_tree = parse_source(expected)

    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)

    assert_equal_ast(tree, expected_tree)
    assert_equal_source(tree, expected_tree)



# Generated at 2022-06-18 00:01:36.030689
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast

    source = source('''
    {1: 1, **dict_a}
    ''')
    expected = source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    tree = ast.parse(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:01:43.212006
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected))



# Generated at 2022-06-18 00:01:48.417450
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:01:56.542468
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_ = source_to_ast(source)
    NodeTransformerVisitor(DictUnpackingTransformer).visit(ast_)
    assert ast_to_source(ast_) == expected

# Generated at 2022-06-18 00:02:13.349248
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import parse_snippet_as_module

    code = '{1: 1, **dict_a}'
    expected = parse_snippet_as_module(
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    assert_equal_ast(DictUnpackingTransformer().visit(parse_ast(code)),
                     expected)



# Generated at 2022-06-18 00:02:24.382334
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source

# Generated at 2022-06-18 00:02:31.740909
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse
    from ..utils.source import get_source
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse(source)
    DictUnpackingTransformer().visit(tree)
    actual = get_source(tree)
    assert compare_ast(actual, expected)

# Generated at 2022-06-18 00:02:37.924966
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-18 00:02:44.880524
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, = parse(source)  # type: ignore
    DictUnpackingTransformer().visit(module)  # type: ignore
    actual = dump(module)

    result = compare_ast(expected, actual)
    assert result is None, result

# Generated at 2022-06-18 00:02:49.516385
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, code, expected)



# Generated at 2022-06-18 00:02:55.140699
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:03:05.689491
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse('{1: 1, **dict_a}')),
        ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    )

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse('{1: 1, **dict_a, 2: 2}')),
        ast.parse('_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)')
    )



# Generated at 2022-06-18 00:03:14.091576
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, = parse(source)
    DictUnpackingTransformer().visit(module)
    actual = dump(module)

    assert compare_ast(actual, expected)

# Generated at 2022-06-18 00:03:19.482333
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:03:46.772683
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from ..utils.ast_helpers import get_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = get_ast(code)
    DictUnpackingTransformer().visit(tree)
    result = astor.to_source(tree)
    assert result == expected



# Generated at 2022-06-18 00:03:47.688931
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:57.449130
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:03:58.291463
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:06.823086
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_node_equal

    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    {1: 1, **dict_a}
    ''')
    DictUnpackingTransformer().visit(node)
    assert_node_equal(node, expected)


# Generated at 2022-06-18 00:04:07.613495
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:08.571294
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:09.250280
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:20.666454
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_names
    from ..utils.test_utils import get_ast_node_attr
    from ..utils.test_utils import get_ast_node_attrs
    from ..utils.test_utils import get_ast_node_attr_value
    from ..utils.test_utils import get_ast_node_attr_values
    from ..utils.test_utils import get_ast_node_attr_values_by_name
    from ..utils.test_utils import get_ast_node_attr_value_by_name
   

# Generated at 2022-06-18 00:04:27.880525
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    {1: 1, **dict_a}
    ''')

    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)

    assert_equal_ast(new_tree, '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')


# Generated at 2022-06-18 00:04:43.925376
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:44.868954
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:52.930266
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import assert_equal_code

    code = """
    {1: 1, **dict_a}
    """
    expected_code = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = parse_snippet(expected_code)
    ast_ = parse_ast(code)
    DictUnpackingTransformer().visit(ast_)


# Generated at 2022-06-18 00:04:54.271502
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:59.673686
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    code = '''
        {1: 1, 2: 2, **dict_a}
    '''

    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''

    assert_equal_ast(code, expected, DictUnpackingTransformer)



# Generated at 2022-06-18 00:05:09.413617
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.compat import ast_parse

    class Visitor(NodeVisitor):
        def visit_Call(self, node: ast.Call) -> None:
            if node.func.id == '_py_backwards_merge_dicts':
                assert len(node.args) == 1
                assert isinstance(node.args[0], ast.List)
                assert len(node.args[0].elts) == 2
                assert isinstance(node.args[0].elts[0], ast.Dict)
                assert isinstance(node.args[0].elts[1], ast.Name)

    tree = ast_parse(source('''
        {1: 1, **dict_a}
    '''))
   

# Generated at 2022-06-18 00:05:11.869235
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-18 00:05:19.344546
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_tree_unchanged
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_not_equal_to_string
    from ..utils.testing import assert_tree_equal_to_string
    from ..utils.testing import assert_tree_not_equal_to_string
    from ..utils.testing import assert_tree_equal_to_string
    from ..utils.testing import assert_tree_not_equal_to_string
    from ..utils.testing import assert_tree_equal_to_string
    from ..utils.testing import assert_tree_not_equal_to_string
    from ..utils.testing import assert_tree_equal_to_string


# Generated at 2022-06-18 00:05:20.457645
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:22.040919
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:57.797423
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast
    from ..utils.unparse import Unparser

    source_ = """
    {1: 1, **dict_a}
    """
    expected_ = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module = get_ast(source(source_))
    DictUnpackingTransformer().visit(module)
    Unparser(module)
    assert source(source_) == expected_

# Generated at 2022-06-18 00:06:09.116346
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_tree_with_source
    from ..utils.test_utils import assert_equal_tree_with_code
    from ..utils.test_utils import assert_equal_tree_with_ast
    from ..utils.test_utils import assert_equal_tree_with_tree
    from ..utils.test_utils import assert_equal_tree_with_tree_with_source
    from ..utils.test_utils import assert_equal_tree_with_tree_with_code
    from ..utils.test_utils import assert_equal_tree_with_

# Generated at 2022-06-18 00:06:11.622134
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert source == merge_dicts + source

# Generated at 2022-06-18 00:06:13.485643
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:14.255012
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:24.536087
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.ast_helpers import get_ast

    class Visitor(NodeVisitor):
        def visit_Call(self, node: ast.Call) -> None:
            if node.func.id == '_py_backwards_merge_dicts':
                assert len(node.args) == 1
                assert isinstance(node.args[0], ast.List)
                assert len(node.args[0].elts) == 2
                assert isinstance(node.args[0].elts[0], ast.Dict)
                assert isinstance(node.args[0].elts[1], ast.Name)
                assert node.args[0].elts[1].id == 'dict_a'


# Generated at 2022-06-18 00:06:33.133646
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_with_imports
    from ..utils.test_utils import get_ast_as_string_with_imports_and_merge_dicts
    from ..utils.test_utils import get_ast_as_string_with_imports_and_merge_dicts_and_backwards_merge_dicts

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_

# Generated at 2022-06-18 00:06:41.007758
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_lineno
    from ..utils.test_utils import get_ast_node_col_offset

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module = parse_

# Generated at 2022-06-18 00:06:48.092561
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:06:58.244878
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = """
    def f():
        {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    def f():
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert_tree_