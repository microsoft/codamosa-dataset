

# Generated at 2022-06-17 23:57:30.493861
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)



# Generated at 2022-06-17 23:57:38.828716
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:57:47.544694
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source
    from ..utils.compare_ast import compare_ast

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected_ = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast_from_source(source_)
    DictUnpackingTransformer().visit(module)
    assert compare_ast(dump(module), expected_)

# Generated at 2022-06-17 23:57:55.143322
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import get_ast_node

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """

    source_ast = parse_ast(source)
    expected_ast = parse_snippet(expected)

    transformer = DictUnpackingTransformer()
    result_ast = transformer.visit(source_ast)


# Generated at 2022-06-17 23:58:03.567633
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    code = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    tree = ast.parse(code)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(new_tree), dump(ast.parse(expected)))



# Generated at 2022-06-17 23:58:12.666323
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    transformer = DictUnpackingTransformer()
    tree = source_to_ast(source)
    transformer.visit(tree)
    result = ast_to_source(tree)
    assert result == expected



# Generated at 2022-06-17 23:58:19.275098
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from .unpacking import UnpackingTransformer

    source = source('''
        {1: 1, **dict_a}
    ''')
    node = ast.parse(source)
    node = UnpackingTransformer().visit(node)
    node = DictUnpackingTransformer().visit(node)
    assert dump(node) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-17 23:58:30.133931
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def __init__(self):
            self.result = []

        def visit_Call(self, node: ast.Call):
            self.result.append(node)

    source = """
        {1: 1, **dict_a}
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    visitor = TestVisitor()
    visitor.visit(tree)
    assert len(visitor.result) == 1

# Generated at 2022-06-17 23:58:37.163700
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-17 23:58:43.982879
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = '''
    {1: 1, **dict_a, 2: 2, **dict_b}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)
    '''
    tree = parse_

# Generated at 2022-06-17 23:58:55.913868
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.ast_helpers import get_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> None:
            assert isinstance(node, ast.Dict)
            assert not any(key is None for key in node.keys)

    source = source('''
        {1: 2, **{3: 4}}
    ''')
    tree = get_ast(source)
    DictUnpackingTransformer().visit(tree)
    Visitor().visit(tree)

# Generated at 2022-06-17 23:59:04.620742
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast_and_code
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_code
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import code_to_ast_and_source
    from ..utils.source import ast_and_code_to_source
    from ..utils.source import ast_and_source_to_code
    from ..utils.source import source_and_code_to_ast
    from ..utils.source import source_and_ast_to_code
    from ..utils.source import code_and_ast_to_source

# Generated at 2022-06-17 23:59:13.688871
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source

    source_ = """
    {1: 1, 2: 2, **{3: 3}, 4: 4, **{5: 5}}
    """
    expected_ = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3}, {4: 4}, {5: 5}])
    """
    module = ast_from_source(source(source_))
    DictUnpackingTransformer().visit(module)
    assert dump(module) == source(expected_)

# Generated at 2022-06-17 23:59:19.818528
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert source == expected

# Generated at 2022-06-17 23:59:29.686260
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:59:36.337840
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-17 23:59:42.655633
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:59:53.966310
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_not_equal_ast
    from ..utils.test_utils import assert_not_equal_source

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    """

    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(expected, new_tree)
   

# Generated at 2022-06-18 00:00:00.610750
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:00:06.939247
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.unparse import Unparser
    from ..utils.visitor import dump

    source_ = """
    {1: 1, **dict_a}
    """
    expected_ = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module = source(source_)
    DictUnpackingTransformer().visit(module)
    Unparser(module)
    dump(module)
    assert source(expected_) == module

# Generated at 2022-06-18 00:00:19.828820
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = '''
    {1: 1, 2: 2, **a, 3: 3, **b, 4: 4}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2}, a, {3: 3}, b, {4: 4}])
    '''
    ast_node = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(ast_node)
    assert ast_to_source(ast_node) == expected

# Generated at 2022-06-18 00:00:28.787507
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:00:35.428930
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    source = source('''
    {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    print(dump(tree))
    assert dump(tree) == source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:00:43.394723
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import assert_equal_source

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    node = parse_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert_equal_ast(node, expected)

    source = '''
        {1: 1, 2: 2, **dict_a}
    '''

# Generated at 2022-06-18 00:00:50.003545
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree

    source = '''
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    '''

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert print_tree(tree) == expected

# Generated at 2022-06-18 00:00:58.406939
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_unchanged

    # Test 1
    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_tree_changed(DictUnpackingTransformer, node)
    assert_node_equal(DictUnpackingTransformer(node), expected)

    # Test 2
    node = ast.parse('{1: 1, 2: 2, **dict_a}')

# Generated at 2022-06-18 00:01:05.960288
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:01:17.775090
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_factory import ast_call, ast_dict

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:28.240669
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_code_with_tree

    # Test 1
    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, expected)
    assert_equal_source(new_tree, expected)

# Generated at 2022-06-18 00:01:32.657629
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:01:48.658291
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import tree_to_str
    from ..utils.source import source_to_str
    from ..utils.ast import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert tree_to_str(tree) == expected
    assert source_to_str(tree) == expected



# Generated at 2022-06-18 00:01:58.620462
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.tree import ast_parse

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast_parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_tree_equal(tree, expected)

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = ast_parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_

# Generated at 2022-06-18 00:02:05.008208
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}], dict_b)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:02:12.028546
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(source)
    new_module = DictUnpackingTransformer().visit(module)
    assert compare_ast(dump(new_module), dump(ast.parse(expected)))

# Generated at 2022-06-18 00:02:19.639790
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, _ = DictUnpackingTransformer().transform(source)
    assert compare_ast(dump(module), dump(expected))

# Generated at 2022-06-18 00:02:31.382198
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_lines
    from ..utils.testing import assert_equal_code_with_merge_dicts
    from ..utils.testing import assert_equal_source_with_merge_dicts
    from ..utils.testing import assert_equal_tree_with_merge_dicts
    from ..utils.testing import assert_equal_lines_with_merge_dicts

    # Test for dict without unpacking

# Generated at 2022-06-18 00:02:36.845499
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:02:45.061276
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test_utils import assert_ast_equal

    transformer = DictUnpackingTransformer()
    node = ast.parse('''{1: 1, **dict_a}''')
    expected = ast.parse('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    assert_ast_equal(transformer.visit(node), expected)

# Generated at 2022-06-18 00:02:50.131858
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equals

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)
    assert_node_equals(node, expected)



# Generated at 2022-06-18 00:02:58.548498
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_class = DictUnpackingTransformer

        def test_simple(self):
            source = '''
                {1: 1, **dict_a}
            '''
            expected = '''
                _py_backwards_merge_dicts([{1: 1}], dict_a)
            '''
            tree = source_to_ast(source)
            new_tree = self.transform(tree)
            print_tree(new_tree)
            self.assertTrue(compare_ast(new_tree, expected), msg=expected)


# Generated at 2022-06-18 00:03:25.466446
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast

    code = """
    {1: 1, **dict_a}
    """
    expected_code = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = parse_ast(expected_code)
    assert_equal_ast(DictUnpackingTransformer().visit(parse_ast(code)),
                     expected_ast)
    assert_equal_code(DictUnpackingTransformer().visit(parse_ast(code)),
                      expected_code)

# Generated at 2022-06-18 00:03:31.335497
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    code = '''
    {1: 1, 2: 2, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, code, expected)

# Generated at 2022-06-18 00:03:38.329396
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def __init__(self):
            self.count = 0

        def visit_Dict(self, node):
            self.count += 1

    source = """
    {1: 1, **dict_a}
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    visitor = Visitor()
    visitor.visit(tree)
    assert visitor.count == 1

# Generated at 2022-06-18 00:03:47.980605
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    # Test 1
    node = parse_ast("{1: 1, **dict_a}")
    result = DictUnpackingTransformer().visit(node)
    expected = parse_ast("_py_backwards_merge_dicts([{1: 1}], dict_a)")
    assert_equal_ast(result, expected)

    # Test 2
    node = parse_ast("{1: 1, **dict_a, 2: 2, **dict_b}")
    result = DictUnpackingTransformer().visit(node)
    expected = parse_ast("_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)")

# Generated at 2022-06-18 00:03:55.907151
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:04:07.186818
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from ..utils.test_utils import assert_equal_ast

    transformer = DictUnpackingTransformer()
    assert_equal_ast(
        transformer.visit(ast3.parse('{1: 1, **dict_a}')),
        ast3.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)'))
    assert_equal_ast(
        transformer.visit(ast3.parse('{1: 1, **dict_a, 2: 2, **dict_b}')),
        ast3.parse('_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)'))

# Generated at 2022-06-18 00:04:12.036176
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_factory import ast_call, ast_dict
    from ..utils.compare_ast import compare_ast

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected_ = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(source_)
    DictUnpackingTransformer().visit(module)
    actual = dump(module)

    assert compare_ast(expected_, actual)



# Generated at 2022-06-18 00:04:18.860793
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal

    node = ast.parse("""
        {1: 1, **dict_a}
    """)
    expected = ast.parse("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)

    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_node_equal(result, expected)



# Generated at 2022-06-18 00:04:25.877571
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source

    source_ = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected_ = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, {4: 4}])
    """

    module = ast_from_source(source_)
    DictUnpackingTransformer().visit(module)
    assert source(dump(module)) == source(expected_)

# Generated at 2022-06-18 00:04:30.056328
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse_ast
    from ..utils.source import source
    from ..utils.compare import compare_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    module = parse_ast(code)
    DictUnpackingTransformer().visit(module)
    compare_ast(module, expected)


# Generated at 2022-06-18 00:05:25.620400
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast import parse

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = parse(source_)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == expected

# Generated at 2022-06-18 00:05:31.323162
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.ast_helpers import get_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = get_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()



# Generated at 2022-06-18 00:05:36.043814
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_code_equal

    code = '''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    '''
    assert_code_equal(DictUnpackingTransformer().visit(ast.parse(code)),
                      ast.parse(expected))

# Generated at 2022-06-18 00:05:47.203708
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """
    tree = parse_ast(source)
    DictUn

# Generated at 2022-06-18 00:05:56.029641
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import transform_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    ast_tree = parse_ast(code)
    new_ast_tree = transform_ast(ast_tree, DictUnpackingTransformer)
    assert_equal_ast(new_ast_tree, expected)

# Generated at 2022-06-18 00:06:00.340741
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:06:10.534471
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_tree_code
    from ..utils.testing import assert_equal_tree_source
    from ..utils.testing import assert_equal_tree_ast
    from ..utils.testing import assert_equal_tree_code_ast
    from ..utils.testing import assert_equal_tree_source_ast
    from ..utils.testing import assert_equal_tree_source_code
    from ..utils.testing import assert_equal_tree_source_code_ast
    from ..utils.testing import assert_equal_tree_source_code_ast_tree
    from ..utils.testing import assert_equal_

# Generated at 2022-06-18 00:06:16.947441
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(code)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(new_tree), expected)



# Generated at 2022-06-18 00:06:26.962139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed

    # Test case 1
    node = ast.parse('{1: 1, **dict_a}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_equal_ast(result, '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_tree_changed(transformer)

    # Test case 2
    node = ast.parse('{1: 1, **dict_a, 2: 2, **dict_b}')
    transformer = DictUnpackingTransformer()


# Generated at 2022-06-18 00:06:32.169787
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)