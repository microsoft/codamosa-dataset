

# Generated at 2022-06-17 23:57:21.911407
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast

    code = """
        {1: 1, 2: 2, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = source_to_ast(code)
    tree = DictUnpackingTransformer().visit(tree)
    actual = dump(tree)
    compare_ast(expected, actual)



# Generated at 2022-06-17 23:57:25.628222
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

# Generated at 2022-06-17 23:57:35.826273
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node):
            return node

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    node = Visitor().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-17 23:57:44.391276
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.tree import ast_to_source
    from ..utils.tree import ast_to_code
    from ..utils.tree import compare_ast

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert compare_ast(ast_to_source(new_tree), expected)
    assert source_

# Generated at 2022-06-17 23:57:48.912901
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)])

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    node = TestVisitor().visit(node)
    node = DictUnpackingTransformer().visit(node)
    result = ast

# Generated at 2022-06-17 23:57:55.872877
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import ast_to_str_with_source
    from ..utils.tree import ast_to_source
    from ..utils.tree import ast_to_source_with_source
    from ..utils.tree import get_source_of_node
    from ..utils.tree import get_source_of_node_with_source
    from ..utils.tree import get_source_of_node_with_source_from_source
    from ..utils.tree import get_source_of_node_from_source
    from ..utils.tree import get_source_of_node_from_source_with_source
    from ..utils.tree import get_source_of_node_from_source_with_source_with_source

# Generated at 2022-06-17 23:58:03.957901
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump
    from ..utils.source import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == dump(source_to_ast(expected))
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:58:14.727877
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast
    from ..utils.tree import to_src
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=2)])

    node = get_ast('''
        {1: 2, **{3: 4}}
    ''')
    result = TestTransformer().visit(node)
    assert to_src(result) == '{1: 2}'



# Generated at 2022-06-17 23:58:23.049120
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            node.keys.append(ast.Name(id='a'))
            node.values.append(ast.Num(n=1))
            return node

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 'a': 1}], dict_a)
    '''
    node = source_to_ast(source)

# Generated at 2022-06-17 23:58:34.548432
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_asts

    class Visitor(NodeVisitor):
        def visit_Dict(self, node):
            return node

    source = """
    {1: 1, 2: 2, **{3: 3, 4: 4}, 5: 5, **{6: 6, 7: 7}}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3, 4: 4}, {5: 5}], {6: 6, 7: 7})
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-17 23:58:50.088442
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    class Test(metaclass=source):
        a = {1: 2, **{3: 4}}

    node = ast.parse(Test.source)
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-17 23:58:58.974262
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:59:09.785197
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(new_tree, expected)

    source = '''
    {1: 1, 2: 2, **dict_a}
    '''

# Generated at 2022-06-17 23:59:19.687564
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """

# Generated at 2022-06-17 23:59:29.573843
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    source = source('''
    {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    source = source('''
    {1: 1, **dict_a, 2: 2, **dict_b}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-17 23:59:40.336169
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.visitor import NodeTransformer

    class DictUnpackingTransformerTest(NodeTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return DictUnpackingTransformer().visit(node)

    class DictUnpackingTransformerTestVisitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> None:
            assert node.keys == [None, None, ast.Str(s='a')]

# Generated at 2022-06-17 23:59:48.576960
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:59:58.391130
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_snippet_with_merge_dicts

    source = '{1: 1, **dict_a}'
    expected = get_ast_from_snippet_with_merge_dicts(
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_equal_ast(DictUnpackingTransformer().visit(parse_ast(source)),
                     expected)

    source = '{1: 1, **dict_a, 2: 2, **dict_b}'
    expected = get_ast_from

# Generated at 2022-06-18 00:00:07.301552
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """
    tree = parse_ast(source)
    DictUn

# Generated at 2022-06-18 00:00:17.148411
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return DictUnpackingTransformer().visit(node)

    tree = source_to_ast(source)
    Visitor().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:00:37.229396
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    code = '''
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    '''

# Generated at 2022-06-18 00:00:45.472001
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(new_tree, ast.parse(expected))

# Generated at 2022-06-18 00:00:53.769800
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast

    def test(code: str, expected: str) -> None:
        tree = ast.parse(code)
        transformer = DictUnpackingTransformer()
        result = transformer.visit(tree)
        assert compare_ast(result, ast.parse(expected))

    test(
        code="""
        {1: 1, **dict_a}
        """,
        expected="""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)


# Generated at 2022-06-18 00:01:01.041419
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """

# Generated at 2022-06-18 00:01:08.687939
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:01:15.920017
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:01:22.924670
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import parse

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected_source = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    node = parse(source_)
    DictUnpackingTransformer().visit(node)
    assert source(node) == expected_source



# Generated at 2022-06-18 00:01:28.779139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert source == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')



# Generated at 2022-06-18 00:01:39.383340
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import compare_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    transform_and_compare(DictUnpackingTransformer, source, expected)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """
    transform_and_compare(DictUnpackingTransformer, source, expected)


# Generated at 2022-06-18 00:01:45.315978
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump

    code = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(code)
    DictUnpackingTransformer().visit(module)
    assert dump(module) == expected



# Generated at 2022-06-18 00:02:12.945953
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import ast_to_source
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    """

    ast_ = source_to_ast(source)
    node = DictUnpackingTransformer().visit(ast_)
    code = ast_to_source(node)
    assert code == expected

    ast_ = code_to_ast(code)
    node = D

# Generated at 2022-06-18 00:02:24.339372
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_source

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            node = DictUnpackingTransformer().visit(node)
            return self.generic_visit(node)

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    Visitor().visit(tree)
    result = ast_to_source(tree)
    compare

# Generated at 2022-06-18 00:02:31.740706
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:02:39.701484
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse('{1: 1, **dict_a}')),
        ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)'))

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse('{1: 1, **dict_a, 2: 2}')),
        ast.parse('_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)'))

    assert_equal_ast

# Generated at 2022-06-18 00:02:46.938159
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, = parse(source)
    DictUnpackingTransformer().visit(module)
    actual = dump(module)

    assert compare_ast(actual, expected)

# Generated at 2022-06-18 00:02:56.641560
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import parse_to_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b, dict_c)
    """
    tree = parse_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, get_ast(expected))

# Generated at 2022-06-18 00:03:07.592487
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert source == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    source = source('''
        {1: 1, **dict_a, 2: 2, **dict_b}
    ''')
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-18 00:03:18.857283
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = """
        {1: 1, **dict_a}
    """

    expected_ast = ast.parse("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)

    expected_source = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    transformer = DictUnpackingTransformer()
    assert_tree_changed(transformer, source)
    assert_equal_ast(transformer, source, expected_ast)

# Generated at 2022-06-18 00:03:23.676982
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal

    tree = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert_tree_equal(result, expected)

    tree = ast.parse('{1: 1, 2: 2, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)

# Generated at 2022-06-18 00:03:29.585638
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    actual = ast_to_source(tree)
    assert actual == expected

    # Check that the tree is valid
    NodeVisitor().visit(tree)

# Generated at 2022-06-18 00:04:11.809578
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import get_node

    node = get_node('''
        {1: 1, **dict_a, 2: 2, **dict_b}
    ''')

    expected = get_node('''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    ''')

    assert_tree_not_equal(node, expected)
    assert_tree_equal(DictUnpackingTransformer().visit(node), expected)

# Generated at 2022-06-18 00:04:18.976408
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:04:25.984362
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    code = '''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    '''
    tree = source_to_ast(code)
    tree = DictUnpackingTransformer().visit(tree)
    actual = dump(tree)
    compare_ast(expected, actual)

# Generated at 2022-06-18 00:04:31.397845
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import ast_to_source
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import source_to_code

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    result = ast_to_source(node)
    assert result == expected

    node = code_to_ast(source)
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-18 00:04:36.767585
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:04:45.359977
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(ast_to_source(tree), expected)



# Generated at 2022-06-18 00:04:51.615545
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_visitor import TestVisitor
    from ..utils.test_utils import assert_equal_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    tree = ast.parse(source)
    TestVisitor.visit(tree, DictUnpackingTransformer)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:05:03.237103
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_code_with_imports
    from ..utils.testing import assert_equal_code_with_imports_and_run
    from ..utils.testing import assert_equal_code_with_run

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse('{1: 1, **dict_a}')),
        ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)'))


# Generated at 2022-06-18 00:05:15.380975
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """

# Generated at 2022-06-18 00:05:24.831796
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import round_trip

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse_ast(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    assert round_trip(source) == expected



# Generated at 2022-06-18 00:06:57.751936
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast_and_code

    source = """
        {1: 1, **dict_a}
    """
    expected_ast = """
        Module(body=[Expr(value=Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), args=[List(elts=[Dict(keys=[Num(n=1)], values=[Num(n=1)]), Name(id='dict_a', ctx=Load())], ctx=Load())], keywords=[]))])
    """
    expected_code = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    ast

# Generated at 2022-06-18 00:07:06.803280
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, 2: 2, **{3: 3, 4: 4}, 5: 5, **{6: 6, 7: 7}}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3, 4: 4}, {5: 5}, {6: 6, 7: 7}])
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert ast_to_source(new_tree) == expected

# Generated at 2022-06-18 00:07:15.524778
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            node.keys.append(None)
            return node

    source = '''
    {1: 1, 2: 2}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2}])
    '''
    tree = source_to_ast(source)
    Visitor().visit(tree)
    DictUnpackingTransformer().visit(tree)
    result = ast_to_source(tree)