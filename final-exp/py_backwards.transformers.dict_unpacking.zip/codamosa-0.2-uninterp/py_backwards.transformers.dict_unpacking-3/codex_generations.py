

# Generated at 2022-06-17 23:57:32.237020
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-17 23:57:36.416918
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.transform import transform

    code = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    tree = transform(DictUnpackingTransformer, code)
    assert dump(tree) == dump(expected)

# Generated at 2022-06-17 23:57:42.000699
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:57:51.215730
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    code = source('''
    {1: 1, **dict_a}
    ''')
    expected = source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    tree = ast.parse(code)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(new_tree), dump(ast.parse(expected)))

# Generated at 2022-06-17 23:58:02.779826
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_snippet_with_imports
    from ..utils.test_utils import get_ast_from_snippet_with_imports_and_merge_dicts

    # Test 1
    code = '{1: 1, 2: 2, **dict_a}'
    expected = get_ast_from_snippet_with_imports_and_merge_dicts(code)
    actual = parse_ast(code, DictUnpackingTransformer)
    assert_equal_ast(actual, expected)

    # Test 2

# Generated at 2022-06-17 23:58:11.541237
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_source_equal(tree, expected)



# Generated at 2022-06-17 23:58:17.026325
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal

    tree = ast.parse('''
        {1: 1, **dict_a}
    ''')
    expected = ast.parse('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    DictUnpackingTransformer().visit(tree)
    assert_node_equal(tree, expected)



# Generated at 2022-06-17 23:58:24.389168
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_source(tree, expected)

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """
    tree = parse_ast(source)
    DictUn

# Generated at 2022-06-17 23:58:30.319440
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert source == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-17 23:58:38.770938
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(new_tree) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-17 23:58:50.767022
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_program

    assert_program(
        {1: 1, **{2: 2}},
        {1: 1, **{2: 2}},
        DictUnpackingTransformer
    )



# Generated at 2022-06-17 23:58:59.928315
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:59:01.026830
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-17 23:59:01.782892
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-17 23:59:11.568449
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_source

    source = get_source(__file__, 'test_DictUnpackingTransformer_visit_Module')
    expected = get_ast_as_string(__file__, 'test_DictUnpackingTransformer_visit_Module.expected')
    tree = get_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(expected, new_tree)

# Generated at 2022-06-17 23:59:18.449746
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-17 23:59:23.740739
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:59:24.906176
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-17 23:59:26.000691
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-17 23:59:33.155872
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_exception
    from ..utils.test_utils import assert_equal_code_with_exception_msg
    from ..utils.test_utils import assert_equal_code_with_exception_msg_re
    from ..utils.test_utils import assert_equal_code_with_exception_re
    from ..utils.test_utils import assert_equal_code_with_exception_re_msg
    from ..utils.test_utils import assert_equal_code_with_exception_re_msg_re
    from ..utils.test_utils import assert_equal_code_with

# Generated at 2022-06-17 23:59:36.288306
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-17 23:59:37.288051
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-17 23:59:38.229196
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-17 23:59:39.214198
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-17 23:59:43.180791
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal

    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse(
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    DictUnpackingTransformer().visit(node)
    assert_node_equal(node, expected)



# Generated at 2022-06-17 23:59:51.136626
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeTransformerVisitor

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(code)
    NodeTransformerVisitor(DictUnpackingTransformer()).visit(tree)
    assert dump(tree) == source(expected)

# Generated at 2022-06-17 23:59:57.572283
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_transformed_code

    assert_transformed_code(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a}
        """,
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)

# Generated at 2022-06-18 00:00:05.714249
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:00:17.148848
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.tree import print_tree
    from ..utils.tree import tree_to_str
    from ..utils.tree import tree_to_source
    from ..utils.tree import tree_to_code

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    print_tree(tree)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    print_tree(tree)

# Generated at 2022-06-18 00:00:28.440804
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_tree_unchanged
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_not_equal_by_source
    from ..utils.testing import assert_tree_equal_by_source

    assert_tree_unchanged(DictUnpackingTransformer, '{}')
    assert_tree_unchanged(DictUnpackingTransformer, '{1: 1}')
    assert_tree_unchanged(DictUnpackingTransformer, '{1: 1, 2: 2}')
    assert_tree_unchanged(DictUnpackingTransformer, '{1: 1, 2: 2, **{}}')

# Generated at 2022-06-18 00:00:33.601539
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:00:42.234807
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import dump
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer

    class Dumper(BaseNodeTransformer):
        def visit_Dict(self, node):
            return ast.Str(s=dump(node))


# Generated at 2022-06-18 00:00:44.195966
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:00:45.160753
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:00:52.875808
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def merge_dicts():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

    class DictUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
        
            {1: 1, **dict_a}
            
        To:
        
            _py_backwards_merge_dicts([{1: 1}], dict_a})
        
        """
        target = (3, 4)


# Generated at 2022-06-18 00:00:59.764121
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:01:09.544986
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:01:10.546930
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:11.497971
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-18 00:01:21.287604
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:01:30.952593
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:41.141649
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_attr
    from ..utils.test_utils import get_ast_node_attr_value
    from ..utils.test_utils import get_ast_node_attr_type
    from ..utils.test_utils import get_ast_node_attr_name
    from ..utils.test_utils import get_ast_node_attr_value_type
    from ..utils.test_utils import get_

# Generated at 2022-06-18 00:01:47.651702
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast_tree(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(expected, new_tree)



# Generated at 2022-06-18 00:01:57.746815
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    
    @snippet
    def merge_dicts():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
    
    @snippet
    def test_code():
        {1: 1, **dict_a}
    

# Generated at 2022-06-18 00:01:59.006844
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:09.534816
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_with_imports
    from ..utils.test_utils import get_ast_as_string_with_imports_and_merge_dicts
    from ..utils.test_utils import get_ast_as_string_with_imports_and_merge_dicts_and_dict_unpacking

    source = '''
        def f(a):
            return {1: 1, **a}
    '''

# Generated at 2022-06-18 00:02:10.418651
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:11.434161
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:20.623622
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_source(tree, expected)


# Generated at 2022-06-18 00:02:30.608834
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:02:52.394818
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:02:59.671492
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    # Test 1
    tree = ast.parse('''
        {1: 1, **dict_a}
    ''')
    expected_tree = ast.parse('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    assert_tree_equal(tree, expected_tree)

    # Test 2
    tree = ast.parse('''
        {1: 1, **dict_a, **dict_b}
    ''')
    expected_tree = ast

# Generated at 2022-06-18 00:03:09.169471
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        def func():
            {1: 1, **dict_a}

    tree = ast.parse(code.get_body())
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)

    @snippet
    def expected():
        def func():
            _py_backwards_merge_dicts([{1: 1}], dict_a)

    expected_tree = ast.parse(expected.get_body())
    assert ast_to_str(tree) == ast_to_str(expected_tree)



# Generated at 2022-06-18 00:03:17.336551
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(source)
    new_module = DictUnpackingTransformer().visit(module)
    assert compare_ast(dump(new_module), dump(ast.parse(expected)))

# Generated at 2022-06-18 00:03:25.857652
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
    def foo():
        return {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    def foo():
        return _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:03:34.470453
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:03:45.872847
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """

# Generated at 2022-06-18 00:03:56.884677
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_equal_ast(get_ast_as_string(tree), expected)

# Generated at 2022-06-18 00:03:57.407917
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:08.538379
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    tree = ast.parse("""
        {1: 1, **dict_a}
    """)
    assert_tree_not_changed(tree, DictUnpackingTransformer)

    tree = ast.parse("""
        {1: 1, **dict_a, 2: 2}
    """)
    assert_tree_changed(tree, DictUnpackingTransformer)
    assert_equal_ast(tree, """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """)


# Generated at 2022-06-18 00:04:52.894613
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree
    from ..utils.testing import assert_equal_code_with_tree
    from ..utils.testing import assert_equal_tree_with_code
    from ..utils.testing import assert_equal_code_with_source
    from ..utils.testing import assert_equal_source_with_code
    from ..utils.testing import assert_equal_tree_with_source
    from ..utils.testing import assert_equal_source_with_tree
    from ..utils.testing import assert_equal_code_with_source_and_tree
    from ..utils.testing import assert_equal_source_with_code_and_tree

# Generated at 2022-06-18 00:05:03.471874
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import get_ast_tree
    from ..utils.test_utils import get_source_code
    from ..utils.test_utils import get_source_code_for_ast_node
    from ..utils.test_utils import get_source_code_for_ast_node_module
    from ..utils.test_utils import get_source_code_for_ast_node_module_with_imports
    from ..utils.test_utils import get_source_code_for_ast_node_module_with_imports_and_comments
    from ..utils.test_utils import get_source_code_for_ast_node_module_with_imports_and_comments_and_blank

# Generated at 2022-06-18 00:05:04.445495
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:16.391370
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_code

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse('{1: 1, **dict_a}')),
        ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)'))

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse('{1: 1, **dict_a, 2: 2}')),
        ast.parse('_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)'))


# Generated at 2022-06-18 00:05:17.546127
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:28.853819
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_with_imports

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = parse_ast(code)
    node = DictUnpackingTransformer().visit(node)

# Generated at 2022-06-18 00:05:35.983229
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected_code = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    expected_ast = parse_ast(expected_code)
    node = parse_ast(code)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_equal_ast(result, expected_ast)
    assert_equal_code(result, expected_code)



# Generated at 2022-06-18 00:05:47.105150
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, code, expected)

    code = '''
        {1: 1, 2: 2, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, code, expected)


# Generated at 2022-06-18 00:05:48.227515
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:50.790405
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:07:11.073273
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    dump(tree)

# Generated at 2022-06-18 00:07:11.911113
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:07:12.692581
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()