

# Generated at 2022-06-17 23:57:32.047596
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

# Generated at 2022-06-17 23:57:35.853224
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert source == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-17 23:57:42.527416
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:57:53.057359
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_ast
    from ..utils.source import ast_to_source

    @snippet
    def before():
        {1: 1, **dict_a}

    @snippet
    def after():
        _py_backwards_merge_dicts([{1: 1}], dict_a)

    node = source_to_ast(before.get_source())
    DictUnpackingTransformer().visit(node)
    assert compare_ast(node, source_to_ast(after.get_source()))

# Generated at 2022-06-17 23:58:03.120152
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert_equal_ast(tree, parse(expected))
    assert_equal_source(tree, expected)



# Generated at 2022-06-17 23:58:15.148201
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_tree = source_to_ast(source)
    print_tree(ast_tree)
    assert get_ast_node_name(ast_tree.body[0]) == 'Dict'
    DictUnpackingTransformer().visit(ast_tree)
    print_tree(ast_tree)

# Generated at 2022-06-17 23:58:21.431006
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeTransformerVisitor

    source_ = source('''
    {1: 1, **dict_a}
    ''')
    expected = source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source_)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(tree)
    assert dump(tree) == dump(ast.parse(expected))

# Generated at 2022-06-17 23:58:26.757785
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)



# Generated at 2022-06-17 23:58:33.315398
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import expect_equal
    from . import run_transformer

    source_ = source('''
        def f(a, b):
            return {1: 1, 2: 2, **a, 3: 3, **b}
    ''')
    expect = source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        def f(a, b):
            return _py_backwards_merge_dicts([{1: 1, 2: 2}, a, {3: 3}], b)
    ''')

# Generated at 2022-06-17 23:58:39.725427
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-17 23:58:52.238040
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compat import parse

    code = source('''
        {1: 1, **dict_a}
    ''')
    tree = parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-17 23:59:03.230812
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse_ast, dump_ast
    from ..utils.source import source


# Generated at 2022-06-17 23:59:14.055798
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
    {1: 1, 2: 2, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)

    code = '''
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b}
    '''

# Generated at 2022-06-17 23:59:19.727124
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast import dump_ast

    source = """
    {1: 1, **dict_a}
    """

    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert dump_ast(tree) == expected

# Generated at 2022-06-17 23:59:26.715553
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:59:33.501535
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def __init__(self):
            self.result = []

        def visit_Call(self, node: ast.Call):
            self.result.append(node)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    visitor = Visitor()
    visitor.visit(tree)
    assert len(visitor.result) == 1

# Generated at 2022-06-17 23:59:42.908083
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import code_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_code
    from ..utils.source import code_equal
    from ..utils.source import ast_equal

    source = """
    {1: 1, **dict_a}
    """
    expected_source = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    ast_node = source_to_ast(source)
    expected_ast = source_to_ast(expected_source)

    transformer = DictUnpackingTransformer()
    new_ast = transformer.visit(ast_node)


# Generated at 2022-06-17 23:59:53.260047
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class DictUnpackingTransformerTest(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return DictUnpackingTransformer().visit(node)

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformerTest().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:00:01.714853
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected_ = source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    tree = ast.parse(source_)
    DictUnpackingTransformer().visit(tree)
    actual = dump(tree)
    compare_ast(actual, expected_)

# Generated at 2022-06-18 00:00:08.061967
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump_ast
    from ..utils.tree import ast_to_tree

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast_to_tree(source_to_ast(source))
    DictUnpackingTransformer().visit(tree)
    assert dump_ast(tree) == expected



# Generated at 2022-06-18 00:00:18.722637
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compiler import compile_snippet

    snippet = source(DictUnpackingTransformer.visit_Dict)
    assert snippet == source(test_DictUnpackingTransformer_visit_Dict)

    tree = compile_snippet(snippet)
    assert dump(tree) == dump(compile_snippet(source(test_DictUnpackingTransformer_visit_Dict)))

# Generated at 2022-06-18 00:00:26.446037
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def test():
        {1: 1, **dict_a}

    tree = ast.parse(test.get_body())
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree) == """
    def test():
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

# Generated at 2022-06-18 00:00:33.554935
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:00:41.152694
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:00:47.189002
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)



# Generated at 2022-06-18 00:00:54.125990
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:01:01.234049
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    tree = parse_ast

# Generated at 2022-06-18 00:01:09.589330
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, 2: 2, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert ast_to_source(new_tree) == expected

# Generated at 2022-06-18 00:01:21.010149
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = get_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_tree

# Generated at 2022-06-18 00:01:25.945134
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import assert_tree_unchanged

    # Test case 1
    tree = ast.parse("""
        {1: 1, **dict_a}
    """)
    expected = ast.parse("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)
    assert_tree_equal(DictUnpackingTransformer().visit(tree), expected)
    assert_tree_changed(DictUnpackingTransformer().visit(tree))

    # Test case 2

# Generated at 2022-06-18 00:01:46.311104
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    node = source_

# Generated at 2022-06-18 00:01:56.614577
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    code = """
        {1: 1, **dict_a}
    """
    expected_code = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast_tree(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected_code)

    code = """
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """

# Generated at 2022-06-18 00:02:07.010859
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string
   

# Generated at 2022-06-18 00:02:14.360786
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_with_imports

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
   

# Generated at 2022-06-18 00:02:23.676230
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compat import parse

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse(code)
    DictUnpackingTransformer().visit(tree)
    assert source(tree) == expected
    assert dump(tree) == expected

# Generated at 2022-06-18 00:02:32.241985
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    source_ast = parse_ast(source)
    expected_ast = parse_ast(expected)
    transformer = DictUnpackingTransformer()
    result_ast = transformer.visit(source_ast)
    assert_equal_ast(result_ast, expected_ast)

# Generated at 2022-06-18 00:02:40.067521
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    from ..utils.source import source
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.tree import print_tree

# Generated at 2022-06-18 00:02:48.848737
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(result, parse_ast(expected))
    assert_equal_source(result, expected)


# Generated at 2022-06-18 00:02:55.140032
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    actual = DictUnpackingTransformer().visit(source_to_ast(source))
    assert ast.dump(actual) == ast.dump(source_to_ast(expected))



# Generated at 2022-06-18 00:03:05.689303
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    # Test for empty module
    module = ast.parse('')
    transformer = DictUnpackingTransformer()
    assert_tree_not_changed(transformer, module)

    # Test for module with dict unpacking
    module = ast.parse('{1: 1, **dict_a}')
    transformer = DictUnpackingTransformer()
    assert_tree_changed(transformer, module)

# Generated at 2022-06-18 00:03:20.444428
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:27.781367
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:03:36.106214
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = parse_ast(code)
    DictUnpackingTransformer().visit(node)
    assert_equal_ast(node, expected)

# Generated at 2022-06-18 00:03:45.402378
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b, dict_c)
    """
    tree = parse(source)
    DictUnpackingTransformer().visit(tree)
    assert expected == tree.body[0].value.s

# Generated at 2022-06-18 00:03:54.756911
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import source
    from ..utils.compare import compare_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    print_tree(tree)
    assert compare_ast(tree, expected) == True
    assert source(tree) == expected

# Generated at 2022-06-18 00:03:55.719539
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:07.030512
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        before='''
            {1: 1, **dict_a}
        ''',
        after='''
            _py_backwards_merge_dicts([{1: 1}], dict_a)
        ''')

    assert_transformed_ast(
        DictUnpackingTransformer,
        before='''
            {1: 1, **dict_a, 2: 2, **dict_b}
        ''',
        after='''
            _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)
        ''')


# Generated at 2022-06-18 00:04:12.550847
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            node.keys = [None, ast.Str(s='a'), None, ast.Str(s='b')]
            node.values = [ast.Num(n=1), ast.Num(n=2), ast.Num(n=3), ast.Num(n=4)]
            return node

    source = '{}'
    expected = '_py_backwards_merge_dicts([{}, {\'a\': 2}, {}, {\'b\': 4}])'


# Generated at 2022-06-18 00:04:13.748730
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:23.642290
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_func_body
    from ..utils.test_utils import get_func_body_str
    from ..utils.test_utils import get_func_body_str_no_ws
    from ..utils.test_utils import get_func_body_str_no_ws_or_nl
    from ..utils.test_utils import get_func_body_str_no_ws_or_nl_or_cmt

    # Test 1
    # Test case:
    #   {1: 1, **dict_a}
    # Expected result:
    #   _py_backwards_merge_dicts([{1: 1}], dict_a)

# Generated at 2022-06-18 00:04:43.522115
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:44.480753
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:52.614261
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import get_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = get_ast(source)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_

# Generated at 2022-06-18 00:04:57.158949
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast import parse

    source_ = source('''
    {1: 1, **dict_a}
    ''')
    node = parse(source_)
    DictUnpackingTransformer().visit(node)
    assert dump(node) == source('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:04:58.620252
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:08.255741
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import get_tree
    from ..utils.testing import get_tree_string
    from ..utils.testing import get_tree_string_from_tree
    from ..utils.testing import get_tree_string_from_tree_string
    from ..utils.testing import get_tree_string_from_tree_string_and_transformer
    from ..utils.testing import get_tree_string_from_tree_and_transformer
    from ..utils.testing import get_tree_string_from_tree_string_and_transformer_class
    from ..utils.testing import get_tree_string_from_tree_and_transformer_class
    from ..utils.testing import get_tree_string_from_tree_string_and_transformer_instance

# Generated at 2022-06-18 00:05:09.927153
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:18.847212
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_after_transformation

    code = '''
    {1: 1, **dict_a}
    '''
    expected_code = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    module = parse_ast(code)
    expected_module = parse_ast(expected_code)
    transformer = Dict

# Generated at 2022-06-18 00:05:20.081340
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:30.369434
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import expect_equal

    source = source('''
    {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-18 00:06:09.479566
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast_tree(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)



# Generated at 2022-06-18 00:06:13.457189
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.ast_helpers import get_ast

    source = '''
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    '''
    tree = get_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-18 00:06:20.546773
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump_tree

    source = """
        {1: 1, **dict_a}
        """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """
    tree = ast.parse(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(expected, new_tree)
    assert dump_tree(new_tree) == dump_tree(ast.parse(expected))



# Generated at 2022-06-18 00:06:21.746321
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-18 00:06:28.835912
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:06:36.035424
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_node_equals
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import get_ast_node
    from ..utils.testing import get_ast_tree

    tree = get_ast_tree('{1: 1, **dict_a}')
    node = get_ast_node(tree, ast.Dict)
    expected = get_ast_tree('_py_backwards_merge_dicts([{1: 1}], dict_a)')

    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_node_equals(result, expected)

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:36.626305
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:37.252180
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:47.187215
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:06:55.259576
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_helpers import get_ast

    source_ = source('''
        {1: 1, 2: 2, **dict_a}
    ''')
    tree = get_ast(source_)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    ''')