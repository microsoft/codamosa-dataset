

# Generated at 2022-06-17 23:57:35.880683
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import ast_to_source
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import source_to_code
    from ..utils.source import code_to_source
    from ..utils.source import source_to_code
    from ..utils.source import code_to_source
    from ..utils.source import source_to_code
    from ..utils.source import code_to_source
    from ..utils.source import source_to_code
    from ..utils.source import code_to_source
    from ..utils.source import source_to_code
    from ..utils.source import code_to_source

# Generated at 2022-06-17 23:57:43.117611
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, 2: 2, **{3: 3, 4: 4}, 5: 5, **{6: 6, 7: 7}, 8: 8}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3, 4: 4}, {5: 5}, {6: 6, 7: 7}, {8: 8}])
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-17 23:57:46.787507
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:57:50.057702
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:57:56.941867
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_equal

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert_tree_equal(tree, expected)



# Generated at 2022-06-17 23:58:04.986419
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    result = ast_to_source(tree)
    compare_source(result, expected)



# Generated at 2022-06-17 23:58:09.092235
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    node = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(node)
    assert ast_to_source(node) == expected

# Generated at 2022-06-17 23:58:19.131318
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    {1: 1, **dict_a}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = parse_ast_tree('''
    {1: 1, **dict_a, 2: 2, **dict_b}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-17 23:58:30.133248
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast_equal
    from ..utils.testing import assert_transformed_source_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import get_ast_from_source

    source = """
    {1: 1, **dict_a}
    """

# Generated at 2022-06-17 23:58:38.309271
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:58:51.098866
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-17 23:59:01.221713
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(print_ast(tree), expected)



# Generated at 2022-06-17 23:59:10.841281
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    @snippet
    def before():
        {1: 1, **dict_a}

    @snippet
    def after():
        _py_backwards_merge_dicts([{1: 1}], dict_a)

    transformer = DictUnpackingTransformer()
    node = source_to_ast(before.get_source())
    transformer.visit(node)
    assert ast_to_source(node) == after.get_source()



# Generated at 2022-06-17 23:59:15.555404
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, _ = DictUnpackingTransformer().transform(source)
    assert compare_ast(dump(module), dump(expected))

# Generated at 2022-06-17 23:59:23.145811
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Call(self, node: ast.Call) -> None:
            assert node.func.id == '_py_backwards_merge_dicts'
            assert len(node.args) == 1
            assert len(node.args[0].elts) == 3
            assert isinstance(node.args[0].elts[0], ast.Dict)
            assert isinstance(node.args[0].elts[1], ast.Call)
            assert isinstance(node.args[0].elts[2], ast.Dict)


# Generated at 2022-06-17 23:59:30.704581
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)



# Generated at 2022-06-17 23:59:38.229480
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import expect_equal

    code = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    expect_equal(dump(tree), source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''))

# Generated at 2022-06-17 23:59:44.970612
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_code

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-17 23:59:52.287918
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:59:55.416821
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test_utils import assert_ast_equal

    transformer = DictUnpackingTransformer()
    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_ast_equal(transformer.visit(node), expected)

# Generated at 2022-06-18 00:00:12.450010
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    source_ = """
        {1: 1, **dict_a}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source(source_)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == expected_



# Generated at 2022-06-18 00:00:19.418153
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast, ast_to_source
    from ..utils.testing import assert_equal_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert_equal_ast(ast_to_source(node), expected)

# Generated at 2022-06-18 00:00:25.790954
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(expected, new_tree)
    assert_equal_source(expected, new_tree)
    assert_tree_changed(transformer)


# Generated at 2022-06-18 00:00:33.791470
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet
    from ..utils.tree import ast_to_source
    from .base import BaseNodeTransformer

    @snippet
    def source():
        {1: 1, **dict_a}

    @snippet
    def expected():
        _py_backwards_merge_dicts([{1: 1}], dict_a)

    tree = source_to_ast(source())
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_source(tree) == expected()

# Generated at 2022-06-18 00:00:42.395802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a, 2: 2, **dict_b}',
        '_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)')


# Generated at 2022-06-18 00:00:51.797884
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    def check(before: ast.AST, after: ast.AST, *,
              tree_changed: bool = True) -> None:
        transformer = DictUnpackingTransformer()
        assert_equal_ast(transformer.visit(before), after)
        if tree_changed:
            assert_tree_changed(transformer)
        else:
            assert_tree_not_changed(transformer)

    check(
        before=ast.parse('{1: 1, **dict_a}'),
        after=ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)'),
    )


# Generated at 2022-06-18 00:00:56.394469
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert source(tree) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:01:03.817473
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.source import source_to_ast
    from ..utils.ast_utils import dump_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(dump_ast(tree), expected)



# Generated at 2022-06-18 00:01:15.252992
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from ..utils.ast_helpers import get_ast_from_source
    from ..utils.source import get_source_from_ast
    from ..utils.source import get_source_from_tree
    from ..utils.source import get_source_from_node

    source = '''
    {1: 1, **dict_a}
    '''
    tree = get_ast_from_source(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:01:22.348394
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)



# Generated at 2022-06-18 00:02:07.340246
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.unparse import Unparser
    from ..utils.visitor import NodeVisitor

    class DictVisitor(NodeVisitor):
        def __init__(self):
            self.dicts = []

        def visit_Dict(self, node):
            self.dicts.append(node)


# Generated at 2022-06-18 00:02:14.375556
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, **dict_a}")),
        ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a)")
    )

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, 2: 2, **dict_a}")),
        ast.parse("_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)")
    )


# Generated at 2022-06-18 00:02:25.045731
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_source(tree) == expected

    # Check that transformer didn't change anything
    visitor = NodeVisitor()
    visitor.visit(tree)
    assert visitor

# Generated at 2022-06-18 00:02:35.684399
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast


# Generated at 2022-06-18 00:02:46.260173
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_ = source_to_ast(source)
    print_tree(ast_)
    print()
    print_visitor(ast_, DictUnpackingTransformer)
    print()
    print_tree(ast_)
    print()
    print(compare_ast(ast_, source_to_ast(expected)))

# Generated at 2022-06-18 00:02:52.008881
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal

    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_node_equal(result, expected)



# Generated at 2022-06-18 00:02:59.515364
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node):
            return node

    class TestCase:
        def __init__(self, source_code, expected_ast):
            self.source_code = source_code
            self.expected_ast = expected_ast


# Generated at 2022-06-18 00:03:09.657778
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)
    assert_tree_changed(DictUnpackingTransformer, source)

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """

# Generated at 2022-06-18 00:03:16.705496
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse_ast
    from ..utils.source import source

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert source(tree) == expected



# Generated at 2022-06-18 00:03:25.858516
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visit
    from ..utils.compare import compare_ast
    from .base import BaseNodeTransformer

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    print_tree(tree)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    print_visit(new_tree)
    compare_ast(expected, new_tree)


# Generated at 2022-06-18 00:04:30.316478
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert source(tree) == expected



# Generated at 2022-06-18 00:04:38.682293
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_with_imports
    from ..utils.test_utils import get_ast_as_string_with_imports_and_merge_dicts

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

# Generated at 2022-06-18 00:04:48.695919
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = '''
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(new_tree, expected)


# Generated at 2022-06-18 00:04:49.324573
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:50.001597
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:00.143225
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_value

    code = """
        {1: 1, **dict_a}
    """
    tree = parse_ast_tree(code)
    node = get_ast_node(tree, 'Dict')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_equal_ast(result, """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)


# Generated at 2022-06-18 00:05:10.141891
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node_by_path
    from ..utils.test_utils import get_ast_node_by_line_col

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse_ast(source)
    node = get_ast_node_by_path(tree, 'body', 0, 'value')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_equal_ast(result, expected)



# Generated at 2022-06-18 00:05:17.020582
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_utils import get_ast

    code = source("""
        {1: 1, **dict_a}
    """)
    expected = source("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)
    tree = get_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == expected

# Generated at 2022-06-18 00:05:19.194101
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-18 00:05:20.317519
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:21.605693
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_by_path
    from ..utils.test_utils import get_ast_node_by_path_and_class
    from ..utils.test_utils import get_ast_nodes_by_class
    from ..utils.test_utils import get_ast_node_by_class

    source = '''
        {1: 1, **dict_a}
    '''

# Generated at 2022-06-18 00:06:29.874267
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    node = parse_ast(code)
    DictUnpackingTransformer().visit(node)
    assert_equal_ast(get_ast_as_string(node), expected)



# Generated at 2022-06-18 00:06:34.560174
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:06:35.161514
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:43.596340
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_unchanged

    # Test for simple dict
    node = ast.parse('{1: 1}')
    assert_tree_unchanged(node, DictUnpackingTransformer)

    # Test for dict with unpacking
    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_tree_changed(node, DictUnpackingTransformer, expected)

    # Test for dict with unpacking and two dicts

# Generated at 2022-06-18 00:06:49.398141
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import get_ast_node

    tree = parse_ast_tree('''
    {1: 1, **dict_a}
    ''')
    node = get_ast_node(tree, ast.Dict)
    transformer = DictUnpackingTransformer()
    new_node = transformer.visit(node)
    assert_equal_ast(new_node, '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')



# Generated at 2022-06-18 00:06:57.993938
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:07:07.883691
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_tree

    # Test 1
    source = """
        {1: 1, **dict_a}
    """
    expected_source = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

# Generated at 2022-06-18 00:07:08.713134
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:07:09.480409
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None