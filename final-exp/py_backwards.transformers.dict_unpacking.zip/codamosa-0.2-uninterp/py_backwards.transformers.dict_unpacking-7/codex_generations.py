

# Generated at 2022-06-17 23:57:33.097011
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:57:42.303088
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import source
    from ..utils.compare import compare_trees
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer

    @snippet
    def before():
        {1: 1, **dict_a}

    @snippet
    def after():
        _py_backwards_merge_dicts([{1: 1}], dict_a)

    source_ = source(before)
    tree = ast.parse(source_)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed
    source_ = source(after)


# Generated at 2022-06-17 23:57:53.436477
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_snippet_with_imports

    assert_equal_ast(
        DictUnpackingTransformer().visit(parse_ast(
            get_ast_from_snippet_with_imports(
                """
                {1: 1, **dict_a}
                """))),
        get_ast_from_snippet(
            """
            _py_backwards_merge_dicts([{1: 1}], dict_a)
            """))


# Generated at 2022-06-17 23:58:02.823071
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(new_tree), dump(expected))

# Generated at 2022-06-17 23:58:14.901467
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}',
        '_py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}], dict_a, dict_b)')

# Generated at 2022-06-17 23:58:23.178870
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast
    from ..utils.testing import assert_transformed_source

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, 2: 2, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)')


# Generated at 2022-06-17 23:58:34.670958
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer().visit(parse_ast(code)),
                     parse_ast(expected))

    code = '''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}], dict_a, dict_b)
    '''


# Generated at 2022-06-17 23:58:43.115361
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    assert_transformed_ast_equal(
        DictUnpackingTransformer,
        {1: 1, **{2: 2}},
        '_py_backwards_merge_dicts([{1: 1}], {2: 2})')

    assert_transformed_ast_equal(
        DictUnpackingTransformer,
        {1: 1, **{2: 2}, **{3: 3}},
        '_py_backwards_merge_dicts([{1: 1}], {2: 2}, {3: 3})')


# Generated at 2022-06-17 23:58:53.622228
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare_ast import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return ast.Dict(keys=[None] + node.keys, values=node.values)

    source_ = """
        {1: 1, 2: 2}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}])
    """
    module = source(source_)
    module = Visitor().visit(module)
    module = DictUnpackingTransformer().visit(module)
    assert compare_ast(module, expected_)

# Generated at 2022-06-17 23:59:01.841136
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-17 23:59:18.220857
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)

    source = """
        {1: 1, 2: 2, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-17 23:59:25.403095
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source

    source_ = """
    {1: 1, **dict_a}
    """
    expected_ = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = ast_from_source(source_)
    DictUnpackingTransformer().visit(node)
    assert source(dump(node)) == expected_

# Generated at 2022-06-17 23:59:30.327817
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_ = source_to_ast(source)
    DictUnpackingTransformer().visit(ast_)
    assert ast_to_source(ast_) == expected

# Generated at 2022-06-17 23:59:37.818422
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-17 23:59:42.812532
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    transformer = DictUnpackingTransformer()
    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = source_to_ast(source)
    transformer.visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-17 23:59:52.471797
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, = parse(source)  # type: ignore
    DictUnpackingTransformer().visit(module)  # type: ignore
    actual = dump(module)

    result = compare_ast(expected, actual)
    assert result is None, result



# Generated at 2022-06-17 23:59:58.153073
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:00:01.810502
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-18 00:00:09.160617
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, {4: 4}])
    """

    node = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(node)
    assert ast_to_source(node) == expected

# Generated at 2022-06-18 00:00:13.398178
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast import parse

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    node = parse(source)
    DictUnpackingTransformer().visit(node)
    assert dump(node) == expected

# Generated at 2022-06-18 00:00:35.631040
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    node = ast.parse('''{1: 1, **dict_a}''')
    expected = ast.parse('''_py_backwards_merge_dicts([{1: 1}], dict_a)''')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_tree_changed(transformer)
    assert_node_equal(result, expected)

    node = ast.parse('''{1: 1, **dict_a, 2: 2, **dict_b}''')

# Generated at 2022-06-18 00:00:43.490618
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_unchanged
    from ..utils.testing import assert_tree_changed

    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_tree_changed(DictUnpackingTransformer, node, expected)

    node = ast.parse('{1: 1, **dict_a, 2: 2, **dict_b}')

# Generated at 2022-06-18 00:00:48.889007
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')



# Generated at 2022-06-18 00:00:53.135470
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert source == expected

# Generated at 2022-06-18 00:00:59.345728
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source
    from ..utils.compare_ast import compare_ast

    source_ = """
        {1: 1, **dict_a}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module = ast_from_source(source(source_))
    DictUnpackingTransformer().visit(module)
    assert compare_ast(dump(module), source(expected_))

# Generated at 2022-06-18 00:01:10.547969
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_of_snippet
    from ..utils.test_utils import get_source_of_snippet
    from ..utils.test_utils import get_source_of_node
    from ..utils.test_utils import get_ast_of_node

    source = get_source_of_snippet(test_DictUnpackingTransformer_visit_Dict)
    expected_source = get_source_of_snippet(
        test_DictUnpackingTransformer_visit_Dict, 'expected')

# Generated at 2022-06-18 00:01:18.065550
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import parse, dump

    code = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    tree = parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == expected


# Generated at 2022-06-18 00:01:24.635101
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test import transform
    from ..utils.test import assert_equal_ast

    code = '''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    '''
    assert_equal_ast(transform(code, DictUnpackingTransformer), expected)

# Generated at 2022-06-18 00:01:30.180853
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse

    transformer = DictUnpackingTransformer()
    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    assert transformer.visit(parse(source)) == parse(expected)

# Generated at 2022-06-18 00:01:38.500675
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(ast_to_source(tree), expected)



# Generated at 2022-06-18 00:01:59.276863
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, **dict_a}")),
        ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a)"))

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, **dict_a, 2: 2}")),
        ast.parse("_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)"))


# Generated at 2022-06-18 00:02:09.742740
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import get_ast_of_snippet
    from ..utils.test_utils import get_ast_of_snippet_with_transformer

    # Test 1
    code = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    assert_equal_ast(
        get_ast_of_snippet_with_transformer(
            code, DictUnpackingTransformer),
        parse_snippet(expected))

    # Test 2

# Generated at 2022-06-18 00:02:20.377206
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compat import to_tuple

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source_)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == dump(ast.parse(expected))

    source_ = source('''
        {1: 1, 2: 2, **dict_a}
    ''')

# Generated at 2022-06-18 00:02:32.116987
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.ast_helpers import get_ast

    def test(code: str, expected: str) -> None:
        node = get_ast(code)
        transformer = DictUnpackingTransformer()
        new_node = transformer.visit(node)
        assert to_source(new_node) == expected

    test('{1: 1, **dict_a}',
         '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    test('{1: 1, 2: 2, **dict_a}',
         '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)')

# Generated at 2022-06-18 00:02:39.485035
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected_source = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = parse_ast(expected_source)
    node = parse_ast(source)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_equal_ast(result, expected_ast)
    assert_equal_source(result, expected_source)



# Generated at 2022-06-18 00:02:44.994391
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    result = ast_to_source(tree)
    assert result == expected

# Generated at 2022-06-18 00:02:53.422659
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)


# Generated at 2022-06-18 00:02:58.441787
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    tree = parse_ast("""
        {1: 1, **dict_a}
    """)

    result = DictUnpackingTransformer().visit(tree)
    expected = parse_ast("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)

    assert_equal_ast(result, expected)



# Generated at 2022-06-18 00:03:07.064929
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(source)
    new_module = DictUnpackingTransformer().visit(module)
    assert compare_ast(dump(new_module), dump(ast.parse(expected)))

# Generated at 2022-06-18 00:03:15.265654
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:03:48.435257
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = '''
    {1: 1, **dict_a, 2: 2}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)
    '''
    tree = parse_ast(source)
    DictUn

# Generated at 2022-06-18 00:03:55.946939
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, _ = DictUnpackingTransformer().transform(source)
    assert compare_ast(dump(module), dump(expected))

# Generated at 2022-06-18 00:04:03.073562
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:04:10.322064
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    ast_ = source_to_ast(source)
    expected_ast = snippet_to_ast(expected)
    assert DictUnpackingTransformer().visit(ast_) == expected_ast
    assert ast_to_source(ast_) == expected

# Generated at 2022-06-18 00:04:19.328012
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:04:26.466306
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected_code = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = parse_ast(expected_code)
    ast_ = parse_ast(code)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast_)
    assert_equal_ast(result, expected_ast)
    assert_equal_code(result, expected_code)

# Generated at 2022-06-18 00:04:30.595232
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source(code))
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(new_tree), source(expected))

# Generated at 2022-06-18 00:04:38.701802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_not_equal_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)
    assert_equal_code(DictUnpackingTransformer, source, expected)
    assert_equal_source(DictUnpackingTransformer, source, expected)
    assert_not_equal_source(DictUnpackingTransformer, source, '{1: 1, **dict_a}')


# Generated at 2022-06-18 00:04:45.818134
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)



# Generated at 2022-06-18 00:04:53.718743
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.source_helpers import source_to_ast
    from ..utils.tree import ast_to_tree
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer

    source = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
   

# Generated at 2022-06-18 00:06:48.311938
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:06:57.376624
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert source == source('''
        from ..utils.snippet import snippet

        @snippet
        def merge_dicts():
            def _py_backwards_merge_dicts(dicts):
                result = {}
                for dict_ in dicts:
                    result.update(dict_)
                return result


        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:07:04.502255
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:07:11.982169
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump
    from ..utils.compare_ast import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(tree), expected)



# Generated at 2022-06-18 00:07:18.412490
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    code = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """
    tree = parse_ast(code)
    DictUn