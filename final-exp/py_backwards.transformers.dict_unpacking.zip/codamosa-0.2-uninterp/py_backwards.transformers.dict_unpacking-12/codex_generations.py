

# Generated at 2022-06-17 23:57:25.163725
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visit
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visit
    from .base import BaseNodeTransformer

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)

# Generated at 2022-06-17 23:57:33.528276
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast

    tree = source("""
        {1: 1, **dict_a}
    """)

    expected = source("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)

    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert compare_ast(expected, new_tree)
    assert transformer.tree_changed



# Generated at 2022-06-17 23:57:41.421578
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:57:52.698799
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node):
            return node

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    actual = ast_to_source(tree)
    assert compare_ast(actual, expected)

    tree = source_to_ast(source)

# Generated at 2022-06-17 23:58:04.508967
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_node
    from ..utils.source import source_to_code
    from ..utils.source import node_to_source

    source = """
    {1: 1, **dict_a}
    """
    node = source_to_node(source)
    DictUnpackingTransformer().visit(node)
    code = source_to_code(node)
    assert code == """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_node(code)
    DictUnpackingTransformer().visit(node)
    code = source_to_code(node)

# Generated at 2022-06-17 23:58:13.350975
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import transform_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    new_tree = transform_ast(tree, DictUnpackingTransformer)
    assert_equal_ast(new_tree, expected)

# Generated at 2022-06-17 23:58:19.907622
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(
        DictUnpackingTransformer().visit(parse_ast(source)),
        parse_ast(expected))



# Generated at 2022-06-17 23:58:27.887047
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_equal_code

    @snippet
    def before():
        def f():
            return {1: 1, **dict_a}

    @snippet
    def after():
        def f():
            return _py_backwards_merge_dicts([{1: 1}], dict_a)

    source_ = source(before)
    tree = ast.parse(source_)
    DictUnpackingTransformer().visit(tree)
    assert_equal_code(dump(tree), after)



# Generated at 2022-06-17 23:58:37.708844
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:58:45.295549
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal

    code = """
    {1: 1, **dict_a}
    """
    expected_code = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

# Generated at 2022-06-17 23:59:03.735023
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import print_ast

    source_ = """
        {1: 1, **dict_a}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module, = get_ast(source(source_))
    DictUnpackingTransformer().visit(module)
    actual_ = print_ast(module)
    compare_asts(expected_, actual_)



# Generated at 2022-06-17 23:59:12.492111
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.ast_helpers import get_ast

    source_ = """
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    """
    tree = get_ast(source(source_))
    DictUnpackingTransformer().visit(tree)
    assert source(tree) == source(expected)

# Generated at 2022-06-17 23:59:21.672394
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> None:
            print(node)


# Generated at 2022-06-17 23:59:31.192393
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast

    transformer = DictUnpackingTransformer()

    # Test that no changes are made if there is no dict unpacking
    source = '{1: 1}'
    expected = get_ast(source)
    actual = transformer.visit(get_ast(source))
    assert_tree_not_changed(actual, transformer)
    assert_equal_ast(actual, expected)

    # Test that dict unpacking is replaced by function call
    source = '{1: 1, **dict_a}'

# Generated at 2022-06-17 23:59:41.302200
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class DictUnpackingTransformerTest(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return DictUnpackingTransformer().visit(node)

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = source_to_ast(source)
    DictUnpackingTransformerTest().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:59:51.321928
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast

    @snippet
    def before():
        {1: 1, **dict_a}

    @snippet
    def after():
        _py_backwards_merge_dicts([{1: 1}], dict_a)

    assert compare_ast(DictUnpackingTransformer().visit(source_to_ast(before)),
                       source_to_ast(after))

# Generated at 2022-06-18 00:00:00.568392
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_for_ast

    source = get_source('''
        {1: 1, **dict_a}
    ''')
    expected = get_source_for_ast('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    assert_equal_ast(DictUnpackingTransformer().visit(get_ast(source)),
                     get_ast(expected))

    source = get_source('''
        {1: 1, **dict_a, **dict_b}
    ''')
    expected = get_source_

# Generated at 2022-06-18 00:00:07.401638
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    result = ast_to_source(node)
    assert result == expected

# Generated at 2022-06-18 00:00:15.470720
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:00:22.308906
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:00:34.096512
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:00:39.531551
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:00:43.676690
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert print_ast(tree) == expected



# Generated at 2022-06-18 00:00:49.079036
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import print_ast

    source_ = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source(source_)
    DictUnpackingTransformer().visit(tree)
    assert print_ast(tree) == expected



# Generated at 2022-06-18 00:00:57.571888
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test import assert_equal

    node = ast.Dict(keys=[None, ast.Num(n=1), None, ast.Num(n=2)],
                    values=[ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)]),
                            ast.Dict(keys=[ast.Num(n=2)], values=[ast.Num(n=2)]),
                            ast.Dict(keys=[ast.Num(n=3)], values=[ast.Num(n=3)]),
                            ast.Dict(keys=[ast.Num(n=4)], values=[ast.Num(n=4)])])

# Generated at 2022-06-18 00:01:07.267013
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = get_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:01:18.651836
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    # Test 1
    node = ast.parse("{1: 1, 2: 2, 3: 3}")
    assert_tree_not_changed(node, DictUnpackingTransformer)

    # Test 2
    node = ast.parse("{1: 1, **{2: 2, 3: 3}}")
    expected = ast.parse("_py_backwards_merge_dicts([{1: 1}], {2: 2, 3: 3})")
    assert_tree_changed(node, DictUnpackingTransformer)

# Generated at 2022-06-18 00:01:24.817996
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:01:32.505085
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:01:39.154459
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:01:58.305613
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    class Visitor(NodeVisitor):
        def visit_Dict(self, node):
            return DictUnpackingTransformer().visit(node)

    ast_ = source_to_ast(source)
    Visitor().visit(ast_)
    assert ast_to_source(ast_) == expected

# Generated at 2022-06-18 00:02:04.888461
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(source)
    new_module = DictUnpackingTransformer().visit(module)
    assert compare_ast(dump(new_module), dump(ast.parse(expected)))

# Generated at 2022-06-18 00:02:13.056931
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return DictUnpackingTransformer().visit(node)

    ast_ = source_to_ast(source)
    Visitor().visit(ast_)
    result = ast_to_source(ast_)
    assert result == expected

# Generated at 2022-06-18 00:02:18.195285
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)



# Generated at 2022-06-18 00:02:29.928343
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse

    # Test 1
    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    # Test 2
    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = parse(source)
    DictUnpackingTransformer().vis

# Generated at 2022-06-18 00:02:35.878476
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:02:44.501905
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(tree), expected)



# Generated at 2022-06-18 00:02:48.349435
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(code, expected, DictUnpackingTransformer)

# Generated at 2022-06-18 00:02:55.739873
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(source)
    DictUnpackingTransformer().visit(module)
    assert compare_ast(dump(module), expected)



# Generated at 2022-06-18 00:03:03.570468
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    print_tree(tree)
    assert compare_ast(tree, expected)



# Generated at 2022-06-18 00:03:32.403531
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:03:44.447627
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.tree import compare_ast

    # Test for simple case
    node = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                    values=[ast.Num(n=1), ast.Name(id='dict_a'), ast.Num(n=2)])

# Generated at 2022-06-18 00:03:52.115898
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.ast_helpers import get_ast_node
    from ..utils.tree import to_src

    src = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = get_ast_node(src)
    DictUnpackingTransformer().visit(node)
    assert to_src(node) == expected

# Generated at 2022-06-18 00:04:01.119774
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, = parse(source)  # type: ignore
    DictUnpackingTransformer().visit(module)  # type: ignore
    actual = dump(module)

    result = compare_ast(expected, actual)
    assert result is None, result

# Generated at 2022-06-18 00:04:10.142474
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    visitor = DictUnpackingTransformer()
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

    # Test that visitor does not change tree if it does not contain dict unpacking
    source = """
    {1: 1}
    """
    tree = source_to_ast(source)
    visitor = DictUnpackingTransformer()
    visitor.visit(tree)

# Generated at 2022-06-18 00:04:21.429980
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_equal_ast
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return DictUnpackingTransformer().visit(node)

    assert_equal_ast(
        TestTransformer().visit(ast.parse("{1: 1, **dict_a}")),
        ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a)"))


# Generated at 2022-06-18 00:04:26.710030
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeTransformerVisitor

    source_ = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source(source_)
    node = NodeTransformerVisitor(DictUnpackingTransformer()).visit(node)
    assert dump(node) == expected

# Generated at 2022-06-18 00:04:30.420978
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import tree_to_str

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert tree_to_str(tree) == expected

# Generated at 2022-06-18 00:04:37.476758
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, = parse(source)
    DictUnpackingTransformer().visit(module)
    actual = dump(module)

    assert compare_ast(expected, actual)

# Generated at 2022-06-18 00:04:45.724397
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast_tree(code)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(expected, new_tree)
    assert transformer._tree_changed



# Generated at 2022-06-18 00:05:33.890482
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)



# Generated at 2022-06-18 00:05:42.268494
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """

    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:05:47.203459
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert source(tree) == expected

# Generated at 2022-06-18 00:05:54.879203
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast

    code = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)
    assert compare_ast(ast_to_str(node), expected)

# Generated at 2022-06-18 00:06:00.331545
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.source import source_to_ast

    source = """
        {1: 1, 2: 2, **dict_a, 3: 3, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    ast_ = source_to_ast(source)
    DictUnpackingTransformer().visit(ast_)
    assert_equal_ast(ast_, expected)

# Generated at 2022-06-18 00:06:10.533987
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import transform_and_compare

    transform_and_compare(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)

    transform_and_compare(
        DictUnpackingTransformer,
        """
        {1: 1, 2: 2, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
        """)


# Generated at 2022-06-18 00:06:20.295350
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)


# Generated at 2022-06-18 00:06:26.734768
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)



# Generated at 2022-06-18 00:06:35.010867
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, source, expected)
    assert_equal_source(DictUnpackingTransformer, source, expected)

    source = '''
        {1: 1, 2: 2, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''


# Generated at 2022-06-18 00:06:43.377741
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = source('''
    {1: 1, **dict_a}
    ''')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    code = source('''
    {1: 1, 2: 2, **dict_a}
    ''')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)