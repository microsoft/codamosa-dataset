

# Generated at 2022-06-17 23:57:32.272329
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(source)
    new_module = DictUnpackingTransformer().visit(module)
    assert compare_ast(dump(new_module), dump(ast.parse(expected)))

# Generated at 2022-06-17 23:57:40.164808
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump_ast
    from ..utils.ast_compare import compare_ast

    transformer = DictUnpackingTransformer()
    node = ast.parse("""
    {1: 1, 2: 2, **dict_a}
    """)
    expected = ast.parse("""
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """)
    result = transformer.visit(node)
    assert compare_ast(result, expected)
    assert transformer._tree_changed



# Generated at 2022-06-17 23:57:51.826569
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_by_path
    from ..utils.test_utils import get_ast_node_by_type
    from ..utils.test_utils import get_ast_nodes_by_type
    from ..utils.test_utils import get_ast_nodes_by_type_and_path
    from ..utils.test_utils import get_ast_nodes_by_type_and_value
    from ..utils.test_utils import get_ast_nodes_by_type_and_value_and_path

# Generated at 2022-06-17 23:58:01.203501
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.snippet import snippet

    with snippet():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

    with snippet():
        def f():
            return {1: 1, **{2: 2}}

    node = source.parse(f)
    DictUnpackingTransformer().visit(node)
    assert dump(node) == dump(source.parse(f))

# Generated at 2022-06-17 23:58:06.068544
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:58:16.620935
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = DictUnpackingTransformer
        NODE = ast3.Dict

        def test_simple(self):
            node = self.NODE(keys=[None, None, None], values=[1, 2, 3])
            expected = ast3.Call(
                func=ast3.Name(id='_py_backwards_merge_dicts'),
                args=[ast3.List(elts=[1, 2, 3])],
                keywords=[])
            self.assertEqual(self.transform(node), expected)

        def test_simple_with_keys(self):
            node = self.NODE(keys=[1, None, 2], values=[1, 2, 3])


# Generated at 2022-06-17 23:58:24.075391
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return ast.Dict(keys=[ast.Num(n=1)], values=[ast.Num(n=1)])

    class TestTransformer(DictUnpackingTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return Visitor().visit(node)

    source = '''
    {1: 1, **dict_a}
    '''

# Generated at 2022-06-17 23:58:30.959149
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-17 23:58:41.335597
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert tree_to_str(tree) == expected

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """

# Generated at 2022-06-17 23:58:49.550281
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    node = parse_ast(source)
    DictUnpackingTransformer().visit(node)
    assert_equal_ast(expected, node)



# Generated at 2022-06-17 23:59:03.762681
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    from .base import BaseNodeTransformer
    from ..utils.tree import tree_to_str
    from ..utils.snippet import snippet
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_tree

# Generated at 2022-06-17 23:59:09.422402
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-17 23:59:19.359953
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet

    @snippet
    def source():
        def f():
            return {1: 1, **dict_a}

    node = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(node)
    assert ast_to_source(node) == '''
        def f():
            return _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

    # Test that transformer is idempotent
    node = source_to_ast(source)
    transformer.visit(node)

# Generated at 2022-06-17 23:59:25.403148
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module = source.get_ast(code)
    DictUnpackingTransformer().visit(module)
    assert dump(module) == expected

# Generated at 2022-06-17 23:59:32.916960
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_with_imports
    from ..utils.test_utils import get_ast_as_string_with_imports_and_renames
    from ..utils.test_utils import get_ast_as_string_with_imports_and_renames_and_locals
    from ..utils.test_utils import get_ast_as_string_with_imports_and_renames_and_locals_and_globals
    from ..utils.test_utils import get_ast_as_string_with_imports_and_renames_and_locals_and_gl

# Generated at 2022-06-17 23:59:42.785099
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    transformer = DictUnpackingTransformer()

    # Test case 1
    tree = ast.parse('{1: 1, **dict_a}')
    expected_tree = ast.parse(
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_tree_equal(transformer.visit(tree), expected_tree)
    assert_tree_changed(transformer)

    # Test case 2
    tree = ast.parse('{1: 1, 2: 2, **dict_a}')

# Generated at 2022-06-17 23:59:53.964574
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import get_ast
    from ..utils.testing import get_source

    source = """
        {1: 1, 2: 2, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = get_ast(source)
    transformer = DictUnpacking

# Generated at 2022-06-17 23:59:59.326807
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert expected == astor.to_source(tree)

# Generated at 2022-06-18 00:00:06.507469
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse
    from ..utils.test_utils import round_trip

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, parse(expected))
    assert_equal_ast(round_trip(tree), parse(expected))

# Generated at 2022-06-18 00:00:17.965401
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, source, expected)

    source = '''
        {1: 1, **dict_a, 2: 2, **dict_b}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)
    '''
    assert_equal_ast(DictUnpackingTransformer, source, expected)


# Generated at 2022-06-18 00:00:31.024983
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_ = source_to_ast(source)
    DictUnpackingTransformer().visit(ast_)
    assert ast_.body[0].body[0].value.s == expected

# Generated at 2022-06-18 00:00:39.724701
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:00:47.038622
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-18 00:00:54.003426
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:00:58.106499
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    code = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, code, expected)



# Generated at 2022-06-18 00:01:08.336451
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    module = parse_ast(source)
    DictUnpackingTransformer().visit(module)
    assert_equal_ast(expected, module)



# Generated at 2022-06-18 00:01:15.921261
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:01:23.643093
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
    def foo():
        return {1: 1, **dict_a}
    '''
    expected = '''
    def foo():
        return _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    module = parse_ast(code)
    DictUnpackingTransformer().visit(module)
    assert_equal_ast(expected, module)



# Generated at 2022-06-18 00:01:29.751940
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    transformer = DictUnpackingTransformer()
    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    result = transformer.visit(source_)
    assert expected == result

# Generated at 2022-06-18 00:01:35.904125
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_code_equal

    code = '''
        {1: 1, **dict_a, 2: 2, **dict_b}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    '''

    transformer = DictUnpackingTransformer()
    tree = transformer.visit(ast.parse(code))
    assert_code_equal(expected, tree)

# Generated at 2022-06-18 00:01:59.452055
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:02:04.456094
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-18 00:02:13.217230
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast_is
    from ..utils.testing import assert_transformed_source_is

    assert_transformed_ast_is(
        DictUnpackingTransformer,
        {1: 1, **{2: 2}},
        {1: 1, 2: 2})

    assert_transformed_ast_is(
        DictUnpackingTransformer,
        {1: 1, **{2: 2}, 3: 3, **{4: 4}},
        _py_backwards_merge_dicts([{1: 1, 3: 3}, {2: 2}, {4: 4}]))


# Generated at 2022-06-18 00:02:20.376837
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.ast_helpers import get_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    node = get_ast(source)
    DictUnpackingTransformer().visit(node)
    assert to_source(node) == expected



# Generated at 2022-06-18 00:02:31.069296
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer

    @snippet
    def source():
        {1: 1, **dict_a}

    @snippet
    def expected():
        _py_backwards_merge_dicts([{1: 1}], dict_a)

    tree = ast.parse(source.get_source())
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert to_source(new_tree) == expected.get_source()

# Generated at 2022-06-18 00:02:39.089294
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import code_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import code_equal

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    code = source_to_code(node)
    node = code_to_ast(code)
    node = DictUnpackingTransformer().visit(node)
    result = ast_to_source(node)

    assert code_

# Generated at 2022-06-18 00:02:48.447166
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast
    from ..utils.testing import assert_transformed_code
    from ..utils.testing import assert_transformed_source

    assert_transformed_ast(
        DictUnpackingTransformer,
        {'a': 1, **{'b': 2, **{'c': 3}}},
        {'a': 1, **{'b': 2, **{'c': 3}}},
        {'a': 1, **{'b': 2, **{'c': 3}}},
    )

    assert_transformed_code(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)',
    )

    assert_transformed_

# Generated at 2022-06-18 00:02:56.132488
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node):
            return node

    visitor = Visitor()
    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(visitor.visit(tree)) == expected

# Generated at 2022-06-18 00:03:03.670365
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:03:12.115676
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_value
    from ..utils.test_utils import get_ast_node_key
    from ..utils.test_utils import get_ast_node_args
    from ..utils.test_utils import get_ast_node_keywords
    from ..utils.test_utils import get_ast_node_elts
    from ..utils.test_utils import get_ast_node_keys
    from ..utils.test_utils import get_ast_node_values


# Generated at 2022-06-18 00:03:52.931352
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        {
            'before': """
                {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
            """,
            'after': """
                _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, {4: 4}])
            """
        })

# Generated at 2022-06-18 00:04:03.447175
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class DictUnpackingTransformerTest(NodeVisitor):
        def __init__(self):
            self.transformer = DictUnpackingTransformer()

        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return self.transformer.visit_Dict(node)

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

    tree = source_to_ast(source)
    DictUnpackingTransformerTest().visit(tree)
   

# Generated at 2022-06-18 00:04:09.562753
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer().visit(parse_ast(code)),
                     parse_ast(expected))

# Generated at 2022-06-18 00:04:19.492086
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(ast_to_source(tree), expected)



# Generated at 2022-06-18 00:04:27.389953
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.source import source_to_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)

    source = """
        {1: 1, **dict_a, **dict_b}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a, dict_b)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)


# Generated at 2022-06-18 00:04:37.099815
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_unchanged
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_equal_to_string
    from ..utils.testing import assert_tree_not_equal_to_string
    from ..utils.testing import assert_tree_equal_to_file
    from ..utils.testing import assert_tree_not_equal_to_file
    from ..utils.testing import assert_tree_equal_to_file_content
    from ..utils.testing import assert_tree_not_equal_to_file_content
    from ..utils.testing import assert_tree_equal_to_snippet
    from ..utils.testing import assert_tree_not_

# Generated at 2022-06-18 00:04:44.568169
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:04:52.685708
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump

    code = source('''
        {1: 1, **dict_a}
    ''')
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)
    assert dump(node) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    code = source('''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    ''')
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)

# Generated at 2022-06-18 00:04:58.831985
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal

    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    DictUnpackingTransformer().visit(node)
    assert_node_equal(node, expected)



# Generated at 2022-06-18 00:05:08.450567
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    assert_tree_changed(transformer, tree)
    assert_equal_ast(tree, expected)

    source = '''
    {1: 1, 2: 2, **dict_a}
    '''

# Generated at 2022-06-18 00:06:32.461335
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import source
    from ..utils.compare import compare_ast

    source_ = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    """

    tree = ast.parse(source_)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(ast.parse(expected), tree)
    assert source(tree) == expected

# Generated at 2022-06-18 00:06:38.110826
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer

    @snippet
    def test_dict_unpacking():
        {1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5}

    node = test_dict_unpacking.get_ast()
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.Expr)
    assert isinstance(node.body[0].value, ast.Dict)

    transformer = DictUnpackingTransformer()
    node = transformer.visit(node)


# Generated at 2022-06-18 00:06:47.085176
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b, dict_c)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:06:57.679409
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.tree import ast_to_source
    from ..utils.tree import ast_to_code

    source = """
    {1: 1, **dict_a}
    """

    expected_source = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    expected_ast = source_to_ast(expected_source)
    expected_code = source_to_code(expected_source)

    ast_ = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    new_ast = transformer.visit(ast_)
    new_code = ast_to_code(new_ast)

    assert new_ast == expected

# Generated at 2022-06-18 00:07:05.831499
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    module = parse_ast(code)
    DictUnpackingTransformer().visit(module)
    assert_equal_ast(get_ast_node(expected), module)



# Generated at 2022-06-18 00:07:12.548852
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_helpers import get_ast

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    node = get_ast(source_)
    DictUnpackingTransformer().visit(node)
    assert dump(node) == expected



# Generated at 2022-06-18 00:07:18.227734
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = '''
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b, dict_c)
    '''
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:07:25.067482
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    NodeTransformerVisitor(DictUnpackingTransformer()).visit(tree)
    assert ast_to_source(tree) == expected