

# Generated at 2022-06-17 23:57:29.682567
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source_ = '''
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    '''
    expected_ = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    '''

    module, _ = source.parse(source_)
    DictUnpackingTransformer().visit(module)
    actual = dump(module)

    compare_ast(expected_, actual)

# Generated at 2022-06-17 23:57:35.316640
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast
    from ..utils.tree import to_src
    from ..utils.source import Source
    from .base import BaseNodeTransformer

    source = Source("""
        {1: 1, **dict_a}
    """)
    tree = get_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert to_src(tree) == """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

# Generated at 2022-06-17 23:57:44.075347
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    # Test 1
    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)
    assert_tree_changed(tree)

    # Test 2
    source = '{1: 1, 2: 2, **dict_a}'

# Generated at 2022-06-17 23:57:53.750458
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    # Test case 1
    code = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    ast_ = parse_ast(code)
    DictUnpackingTransformer().visit(ast_)
    assert_equal_ast(ast_, expected)

    # Test case 2
    code = '{1: 1, **dict_a, 2: 2, **dict_b}'
    expected = '_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)'
    ast_ = parse_ast(code)
    DictUnpacking

# Generated at 2022-06-17 23:58:03.326806
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    """
    ast_ = source_to_ast(source)
    DictUnpackingTransformer().visit(ast_)
    assert ast_.body[0].body[0].value.s == expected

# Generated at 2022-06-17 23:58:12.810473
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected_ = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, = ast.parse(source_)
    DictUnpackingTransformer().visit(module)
    actual = dump(module)

    compare_ast(expected_, actual)

# Generated at 2022-06-17 23:58:22.882062
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            node.keys = [None] + node.keys
            return node

    source = '''
    {1: 1, 2: 2}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2}])
    '''
    tree = source_to_ast(source)
    tree = Visitor().visit(tree)
    tree = DictUnpackingTransformer().visit(tree)
    assert compare_

# Generated at 2022-06-17 23:58:28.921857
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-17 23:58:37.708352
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import dump
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(tree), expected)

# Generated at 2022-06-17 23:58:44.207598
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source

# Generated at 2022-06-17 23:58:56.899560
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def __init__(self):
            self.result = None

        def visit_Dict(self, node):
            self.result = node

    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    visitor = TestVisitor()
    visitor.visit(node)
    assert isinstance(visitor.result, ast.Call)

# Generated at 2022-06-17 23:59:04.911621
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)

    code = '''
        {1: 1, 2: 2, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpacking

# Generated at 2022-06-17 23:59:15.527298
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test_utils import assert_ast_equal


# Generated at 2022-06-17 23:59:23.125225
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class TestVisitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            node.keys.append(None)
            node.values.append(ast.Num(n=1))
            return node

    source = """
    {1: 1, 2: 2}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], 1)
    """

    tree = source_to_ast(source)
    TestVisitor().visit(tree)
    DictUnpackingTransformer().vis

# Generated at 2022-06-17 23:59:31.999320
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_factory import ast_call, ast_dict, ast_list, ast_name

    transformer = DictUnpackingTransformer()
    node = ast_dict([ast_name('a'), ast_name('b')], [1, 2])
    expected = ast_call(
        ast_name('_py_backwards_merge_dicts'),
        [ast_list([ast_dict([ast_name('a'), ast_name('b')], [1, 2])])])
    assert dump(transformer.visit(node)) == dump(expected)

    node = ast_dict([ast_name('a'), None, ast_name('b')], [1, 2, 3])

# Generated at 2022-06-17 23:59:39.404669
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:59:44.226250
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.ast_helpers import get_ast

    source = """
    {1: 2, **{3: 4}, 5: 6, **{7: 8}}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 2}, {5: 6}], {3: 4}, {7: 8})
    """

    tree = get_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-17 23:59:48.767398
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> None:
            assert node.keys == [None, ast.Num(1), ast.Num(2)]
            assert node.values == [ast.Name(id='a'), ast.Num(1), ast.Num(2)]

    source = '{**a, 1: 1, 2: 2}'
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    Visitor().visit(tree)

# Generated at 2022-06-17 23:59:53.788537
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = source_to_ast(source)
    NodeTransformerVisitor(DictUnpackingTransformer).visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:00:00.163579
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source

    source = get_source(DictUnpackingTransformer, 'visit_Dict')
    expected = get_source(DictUnpackingTransformer, 'visit_Dict', 'expected')
    tree = get_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:00:11.312773
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    code = """
        {1: 1, **dict_a}
    """
    tree = parse_ast_tree(code)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(
        new_tree,
        parse_ast_tree("""
            _py_backwards_merge_dicts([{1: 1}], dict_a)
        """))

# Generated at 2022-06-18 00:00:19.968062
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_code_with_merge_dicts

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, **dict_a}")),
        ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a)"))

    assert_equal_source(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, **dict_a}")),
        "_py_backwards_merge_dicts([{1: 1}], dict_a)")

    assert_equal_

# Generated at 2022-06-18 00:00:29.543737
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

    source = """
        {1: 1, 2: 2, **dict_a}
    """

# Generated at 2022-06-18 00:00:36.907206
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-18 00:00:40.513365
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_source(DictUnpackingTransformer, source, expected)



# Generated at 2022-06-18 00:00:50.946933
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_transformed_ast


# Generated at 2022-06-18 00:00:56.597218
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:01:03.708663
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import get_ast
    from ..utils.unparse import Unparser

    source_ = """
    {1: 1, **dict_a}
    """
    expected_ = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = get_ast(source(source_))
    DictUnpackingTransformer().visit(tree)
    Unparser(tree)

    assert source(expected_) == Unparser(tree).result

# Generated at 2022-06-18 00:01:15.205580
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class DictUnpackingTransformerTest(NodeVisitor):
        def __init__(self):
            self.transformer = DictUnpackingTransformer()

        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return self.transformer.visit_Dict(node)

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformerTest().visit(tree)
    assert ast_to

# Generated at 2022-06-18 00:01:22.346749
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:01:37.160122
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import transform_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    tree = transform_ast(tree, DictUnpackingTransformer)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:01:43.674251
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(new_tree, expected)

# Generated at 2022-06-18 00:01:53.945624
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return ast.Dict(keys=[None, None, None], values=[node, node, node])

    class Test(DictUnpackingTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return Visitor().visit(node)

    source_ = source('''
        {1: 1, 2: 2, 3: 3}
    ''')

# Generated at 2022-06-18 00:01:58.426539
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    node = ast.parse(source)
    node = DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-18 00:02:09.067466
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import parse_ast

    # Test 1
    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(tree, parse_ast(expected))
    assert_equal_source(tree, expected)

    #

# Generated at 2022-06-18 00:02:17.643107
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump

    source = source('''
    {1: 1, **dict_a}
    ''')
    expected = source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    tree = ast.parse(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(expected, new_tree)

# Generated at 2022-06-18 00:02:29.364614
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def merge_dicts():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

    class DictUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
        
            {1: 1, **dict_a}
            
        To:
        
            _py_backwards_merge_dicts([{1: 1}], dict_a})
        
        """
        target = (3, 4)


# Generated at 2022-06-18 00:02:37.611363
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b, {3: 3}])
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)

    source

# Generated at 2022-06-18 00:02:48.350139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import code_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_code
    from ..utils.source import code_equal
    from ..utils.source import ast_equal

    source = """
    {1: 1, 2: 2, 3: 3, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    code = ast_to_code(tree)

# Generated at 2022-06-18 00:02:57.975015
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast

    source_ = """
        {1: 1, **dict_a}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse(source_)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(new_tree, expected_)

    source_ = """
        {1: 1, 2: 2, **dict_a}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = parse(source_)
   

# Generated at 2022-06-18 00:03:19.853977
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import parse
    from ..utils.compare import compare_ast

    source_ = '''
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    '''
    expected_ = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    '''
    tree = parse(source_(source_))
    tree = DictUnpackingTransformer().visit(tree)
    compare_ast(tree, source_(expected_))

# Generated at 2022-06-18 00:03:28.029600
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source
    from ..utils.compare_ast import compare_ast

    source_ = source('''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    ''')
    expected_ = source('''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    ''')

    module = ast_from_source(source_)
    new_module = DictUnpackingTransformer().visit(module)
    assert compare_ast(new_module, ast_from_source(expected_))

# Generated at 2022-06-18 00:03:35.946065
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> None:
            print(ast_to_source(node))

    source = """
    {1: 1, 2: 2, **{3: 3, 4: 4}, 5: 5, **{6: 6, 7: 7}}
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    Visitor().visit(tree)

# Generated at 2022-06-18 00:03:47.192895
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    code = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b, {3: 3}])
    """
    tree = parse

# Generated at 2022-06-18 00:03:58.292099
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = '''
    {1: 1, **dict_a, 2: 2, **dict_b}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a, {2: 2}, dict_b)
    '''
    tree = parse_

# Generated at 2022-06-18 00:04:09.254041
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import tree_to_str
    from ..utils.visitor import NodeVisitor
    from ..utils.source import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert tree_to_str(tree) == expected

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """

# Generated at 2022-06-18 00:04:14.862710
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    transformer = DictUnpackingTransformer()
    result = transformer.visit(source("""
    {1: 1, **dict_a}
    """))
    assert source(result) == """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

# Generated at 2022-06-18 00:04:24.516908
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """

    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert_equal_ast(result, expected)
    assert_equal_source(result, expected)
    assert_tree_changed(transformer)

   

# Generated at 2022-06-18 00:04:35.591604
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source

    source = '''
        {1: 1, **dict_a}
    '''
    expected_source = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    expected_ast = parse_source(expected_source)
    ast_ = parse_ast(source)
    ast_ = DictUnpackingTransformer().visit(ast_)
    assert_equal_ast(ast_, expected_ast)

# Generated at 2022-06-18 00:04:43.838746
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    actual = DictUnpackingTransformer().visit(source_to_ast(source))
    assert ast.dump(actual) == ast.dump(source_to_ast(expected))



# Generated at 2022-06-18 00:05:19.384805
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import assert_code_equal

    # {1: 1, **dict_a}
    node = ast.Dict(keys=[ast.Num(1), None], values=[ast.Num(1), ast.Name(id='dict_a')])
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(elts=[
                ast.Dict(keys=[ast.Num(1)], values=[ast.Num(1)]),
                ast.Name(id='dict_a')
            ])
        ],
        keywords=[])
    assert_

# Generated at 2022-06-18 00:05:29.875491
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.test_utils import assert_equal_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b, dict_c)
    """
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(tree)

# Generated at 2022-06-18 00:05:34.921490
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(tree, expected)

# Generated at 2022-06-18 00:05:41.052842
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:05:46.642881
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_code_equal

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_code_equal(DictUnpackingTransformer().visit(ast.parse(code)),
                      ast.parse(expected))



# Generated at 2022-06-18 00:05:57.422011
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, source, expected)
    assert_tree_changed(DictUnpackingTransformer, source)

    source = '''
        {1: 1, 2: 2, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''

# Generated at 2022-06-18 00:06:08.505227
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from ..utils.unparse import Unparser

    source = source('''
    {1: 1, 2: 2, **dict_a}
    ''')
    expected = source('''
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    ''')

    module, = parse(source)  # type: ignore
    DictUnpackingTransformer().visit(module)  # type: ignore
    Unparser(module)

    module, = parse(expected)  # type: ignore
    expected, = dump(module)

    assert compare_ast(module, expected)

# Generated at 2022-06-18 00:06:14.309571
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.source import source_to_ast

    class DictUnpackingTransformerTest(NodeVisitor):
        def __init__(self):
            self.result = None

        def visit_Dict(self, node: ast.Dict) -> ast.Call:
            transformer = DictUnpackingTransformer()
            self.result = transformer.visit(node)
            return self.result

    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    visitor = DictUnpackingTransformerTest()

# Generated at 2022-06-18 00:06:24.621103
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, 2: 2, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)')


# Generated at 2022-06-18 00:06:31.418156
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

