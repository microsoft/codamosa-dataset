

# Generated at 2022-06-17 23:57:29.561946
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert source == source('''
        from typing import Dict
        def _py_backwards_merge_dicts(dicts: List[Dict]) -> Dict:
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-17 23:57:35.177238
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert source == expected



# Generated at 2022-06-17 23:57:42.899282
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, = parse(source)  # type: ignore
    DictUnpackingTransformer().visit(module)  # type: ignore
    actual = dump(module)

    result = compare_ast(expected, actual)
    assert result is None, result



# Generated at 2022-06-17 23:57:49.697854
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_code_equal

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_code_equal(DictUnpackingTransformer().visit(ast.parse(code)),
                      ast.parse(expected))



# Generated at 2022-06-17 23:57:55.806784
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-17 23:58:05.457341
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.ast_helpers import get_ast

    class Visitor(NodeVisitor):
        def visit_Call(self, node: ast.Call) -> None:
            if node.func.id == '_py_backwards_merge_dicts':
                assert len(node.args) == 1
                assert isinstance(node.args[0], ast.List)
                assert len(node.args[0].elts) == 2
                assert isinstance(node.args[0].elts[0], ast.Dict)
                assert isinstance(node.args[0].elts[1], ast.Name)
                assert node.args[0].elts[1].id == 'dict_a'


# Generated at 2022-06-17 23:58:11.301690
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    assert DictUnpackingTransformer().visit(source) == expected

# Generated at 2022-06-17 23:58:18.475316
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.snippet import snippet
    from ..utils.ast_helpers import get_ast

    @snippet
    def test_snippet():
        def f():
            return {1: 1, **{2: 2}, 3: 3, **{4: 4}}

    test_ast = get_ast(test_snippet.get_body())
    DictUnpackingTransformer().visit(test_ast)

# Generated at 2022-06-17 23:58:23.367994
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import visit_Module
    from ..utils.ast_helpers import get_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    module = get_ast(source)
    visit_Module(module, DictUnpackingTransformer())
    assert source == '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

# Generated at 2022-06-17 23:58:29.296968
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

# Generated at 2022-06-17 23:58:41.964715
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(ast_to_source(tree), expected)



# Generated at 2022-06-17 23:58:48.696020
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = parse(source)
    DictUnpackingTransformer().visit(node)
    assert expected == node.body[0].value.s

# Generated at 2022-06-17 23:58:55.782081
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)

# Generated at 2022-06-17 23:59:03.065764
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.ast_helpers import get_ast_node_name

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-17 23:59:12.297498
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-17 23:59:20.420028
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> None:
            node = DictUnpackingTransformer().visit(node)
            assert ast_to_source(node) == expected

    Visitor().visit(source_to_ast(source))

# Generated at 2022-06-17 23:59:27.687665
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:59:32.802966
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def test():
        def f():
            return {1: 1, **{2: 2}}


# Generated at 2022-06-17 23:59:40.699270
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast

    code = source('''
    {1: 1, **dict_a}
    ''')
    expected = source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(code)
    DictUnpackingTransformer().visit(module)
    actual = dump(module)

    assert compare_ast(expected, actual)



# Generated at 2022-06-17 23:59:51.040780
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.tree import parse
    from ..utils.source import dedent

    source = dedent('''
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    ''')
    expected = dedent('''
    _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, {4: 4}])
    ''')

    tree = parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert_tree_equal(tree, expected)

# Generated at 2022-06-18 00:00:08.446112
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:00:15.981228
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(source)
    DictUnpackingTransformer().visit(module)
    actual = dump(module)

    assert compare_ast(expected, actual)



# Generated at 2022-06-18 00:00:23.860918
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-18 00:00:30.912898
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    node = ast.parse('{1: 1, 2: 2, **dict_a, 3: 3, **dict_b}')
    expected = ast.parse(
        '_py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)')

    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_tree_changed(transformer)
    assert_node_equal(expected, result)

    node = ast.parse('{1: 1, 2: 2, 3: 3}')

# Generated at 2022-06-18 00:00:36.461333
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(code, expected, DictUnpackingTransformer)

# Generated at 2022-06-18 00:00:43.724547
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert_equal_ast(result, expected)
    assert_tree_changed(transformer)

    source = '''
        {1: 1, 2: 2, **dict_a}
    '''

# Generated at 2022-06-18 00:00:52.119621
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        {
            'before': """
                {1: 1, **dict_a}
            """,
            'after': """
                _py_backwards_merge_dicts([{1: 1}], dict_a)
            """
        }
    )

    assert_transformed_ast(
        DictUnpackingTransformer,
        {
            'before': """
                {1: 1, **dict_a, 2: 2, **dict_b}
            """,
            'after': """
                _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)
            """
        }
    )

    assert_

# Generated at 2022-06-18 00:00:59.104872
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from .base import BaseNodeTransformer
    from .unpacking import UnpackingTransformer

    source = source('''
        {1: 1, **dict_a}
    ''')
    node = ast.parse(source)
    node = UnpackingTransformer().visit(node)
    node = DictUnpackingTransformer().visit(node)
    node = BaseNodeTransformer().visit(node)
    assert dump(node) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:01:10.260990
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    code = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """

# Generated at 2022-06-18 00:01:17.725332
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

# Generated at 2022-06-18 00:01:44.543195
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(print_tree(tree), expected)

# Generated at 2022-06-18 00:01:52.853408
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node):
            return node

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_ = source_to_ast(source)
    visitor = Visitor()
    visitor.visit(ast_)
    assert ast_to_source(ast_) == expected

# Generated at 2022-06-18 00:01:58.699877
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.ast_builder import build_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = build_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:02:09.269269
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import assert_code_equal

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_with_merge_dicts = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_with_mer

# Generated at 2022-06-18 00:02:18.684408
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(tree)
    result = ast_to_source(tree)

    compare_ast(result, expected)

# Generated at 2022-06-18 00:02:26.481056
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

# Generated at 2022-06-18 00:02:36.440391
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, source, expected)

    source = '''
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    '''

# Generated at 2022-06-18 00:02:47.462396
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    transformer = DictUnpackingTransformer()
    node = ast.Dict(keys=[None, ast.Num(1), None, ast.Num(2)],
                    values=[ast.Dict(keys=[ast.Num(1)], values=[ast.Num(1)]),
                            ast.Dict(keys=[ast.Num(2)], values=[ast.Num(2)]),
                            ast.Dict(keys=[ast.Num(3)], values=[ast.Num(3)]),
                            ast.Dict(keys=[ast.Num(4)], values=[ast.Num(4)])])

# Generated at 2022-06-18 00:02:57.714496
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import parse_snippet_as_module
    from ..utils.test_utils import parse_snippet_as_module_with_imports
    from ..utils.test_utils import parse_snippet_as_module_with_imports_and_merge_dicts


# Generated at 2022-06-18 00:03:08.708853
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_asts

    class TestVisitor(NodeVisitor):
        def __init__(self):
            self.dict_unpacking_transformer = DictUnpackingTransformer()

        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return self.dict_unpacking_transformer.visit_Dict(node)

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

# Generated at 2022-06-18 00:03:56.645507
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:04:07.810686
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

    source = '''
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    '''

# Generated at 2022-06-18 00:04:11.403012
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compat import parse

    code = source('''
        {1: 1, **dict_a}
    ''')
    tree = parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:04:18.008139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'

    transformer = DictUnpackingTransformer()
    result = transformer.visit(parse_ast(code))
    assert_equal_ast(result, expected)

# Generated at 2022-06-18 00:04:23.950741
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-18 00:04:29.747189
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.source_code import SourceCode
    from ..utils.compiler import compile_ast

    source_code = SourceCode("""
        {1: 1, **dict_a}
    """)
    tree = ast.parse(source_code.get_source())
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree) == """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert compile_ast(tree)


# Generated at 2022-06-18 00:04:38.657783
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> None:
            assert node.keys == [ast.Num(n=1), None, ast.Num(n=2)]
            assert node.values == [ast.Num(n=1), ast.Name(id='dict_a'), ast.Num(n=2)]

    source = '{1: 1, **dict_a, 2: 2}'
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:04:48.695693
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """

    tree = source_to_ast(source)
    visitor = NodeVisitor()
    visitor.visit(tree)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    actual = ast_to_source(tree)
    compare_ast(actual, expected)

# Generated at 2022-06-18 00:04:57.759896
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_with_imports
    from ..utils.test_utils import get_ast_as_string_with_imports_and_merge_dicts

    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'

    tree = parse_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, expected)


# Generated at 2022-06-18 00:05:06.098139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast_and_back
    from ..utils.source import source_to_ast_and_back_and_compare
    from ..utils.source import source_to_ast_and_back_and_compare_with_original
    from ..utils.source import source_to_ast_and_back_and_compare_with_original_and_print

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

# Generated at 2022-06-18 00:07:17.640618
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    # Test for dict without unpacking
    source = '{1: 1}'
    tree = ast.parse(source)
    assert_tree_not_changed(DictUnpackingTransformer, tree)
    assert_equal_source(source, tree)

    # Test for dict with unpacking
    source = '{1: 1, **dict_a}'
    tree = ast.parse(source)
    assert_tree_changed(DictUnpackingTransformer, tree)
    assert_equal_source('_py_backwards_merge_dicts([{1: 1}], dict_a)', tree)