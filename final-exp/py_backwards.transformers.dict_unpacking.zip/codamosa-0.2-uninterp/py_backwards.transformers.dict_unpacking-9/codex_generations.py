

# Generated at 2022-06-17 23:57:36.827042
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
        {1: 1, **dict_a}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = parse_ast_tree('''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-17 23:57:45.012801
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_snippet_with_merge_dicts

    snippet_1 = """
    {1: 1, **dict_a}
    """

    snippet_2 = """
    {1: 1, 2: 2, **dict_a}
    """

    snippet_3 = """
    {1: 1, 2: 2, **dict_a, 3: 3}
    """

    snippet_4 = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b}
    """


# Generated at 2022-06-17 23:57:48.788199
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.testing import assert_equal_ast

    source = '''
    {1: 1, **dict_a, 2: 2, **dict_b}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    '''
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(tree)
    assert_equal_ast(ast_to_source(tree), expected)

# Generated at 2022-06-17 23:57:55.873328
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.tree import print_tree
    from ..utils.tree import tree_to_str
    from ..utils.tree import tree_to_code
    from ..utils.tree import tree_to_source
    from ..utils.tree import tree_to_ast
    from ..utils.tree import tree_to_source_code

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    print_tree(tree)
    assert tree_to_str(tree) == source

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-17 23:58:04.259269
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, {4: 4}])
    '''

    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-17 23:58:13.308262
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.tree import parse
    from ..utils.source import source
    from ..utils.compare import compare_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse(code)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(new_tree, parse(expected))
    assert source(new_tree) == expected



# Generated at 2022-06-17 23:58:23.504779
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """
   

# Generated at 2022-06-17 23:58:34.707330
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_ = source_to_ast(source)
    expected_ast = snippet_to_ast(expected)
    transformer = DictUnpackingTransformer()
    new_ast = transformer.visit(ast_)
    assert ast_to_source(new_ast) == ast_to_source(expected_ast)



# Generated at 2022-06-17 23:58:43.135758
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import transform_and_compile

    tree = parse_ast_tree('''
        {1: 1, **dict_a}
    ''')
    expected_tree = parse_ast_tree('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, expected_tree)

    code = '''
        {1: 1, **dict_a}
    '''

# Generated at 2022-06-17 23:58:53.653282
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source


# Generated at 2022-06-17 23:59:08.386595
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-17 23:59:17.297293
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compat import parse

    code = """
    def f():
        return {1: 1, **dict_a}
    """
    module = parse(code)
    DictUnpackingTransformer().visit(module)
    assert dump(module) == source("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    def f():
        return _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)


# Generated at 2022-06-17 23:59:25.591217
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = '''
        {1: 2, **{3: 4}, 5: 6, **{7: 8}}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 2}, {5: 6}], {3: 4}, {7: 8})
    '''
    node = parse_ast(code)
    DictUnpackingTransformer().visit(node)
    assert_equal_ast(expected, node)

# Generated at 2022-06-17 23:59:31.019803
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:59:41.453286
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_str
    from ..utils.source import source_to_ast_and_back
    from ..utils.source import source_to_ast_and_back_and_compare
    from ..utils.source import source_to_ast_and_back_and_compare_with_black
    from ..utils.source import source_to_ast_and_back_and_compare_with_isort
    from ..utils.source import source_to_ast_and_back_and_compare

# Generated at 2022-06-17 23:59:43.261254
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-17 23:59:49.273174
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)



# Generated at 2022-06-17 23:59:57.616916
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:00:06.012421
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    node = parse_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert_node_equal(node, expected)


# Generated at 2022-06-18 00:00:17.498481
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    transformer = DictUnpackingTransformer()
    assert_equal_ast(
        transformer.visit(parse_ast("{1: 1, **dict_a}")),
        parse_ast("_py_backwards_merge_dicts([{1: 1}], dict_a)"))
    assert_equal_ast(
        transformer.visit(parse_ast("{1: 1, **dict_a, 2: 2, **dict_b}")),
        parse_ast("_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)"))

# Generated at 2022-06-18 00:00:29.982921
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import assert_tree_changed_by_transformer
    from ..utils.testing import assert_tree_not_changed_by_transformer
    from ..utils.testing import assert_tree_changed_by_transformer_class
    from ..utils.testing import assert_tree_not_changed_by_transformer_class

    # Test 1
    tree = ast.parse("""
        {1: 1, **dict_a}
    """)

# Generated at 2022-06-18 00:00:38.540779
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump

    source_ = """
    {1: 1, **dict_a}
    """
    expected_ = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source(source_, 'exec')
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == expected_

# Generated at 2022-06-18 00:00:44.775392
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.ast_factory import ast_call, ast_name, ast_dict, ast_list, ast_str
    from ..utils.transformer import Transformer

    class Visitor(NodeVisitor):
        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id == '_py_backwards_merge_dicts':
                return node.args[0].elts[0]
            return node

    class Transformer(Transformer):
        def visit_Dict(self, node):
            if node.keys[0] is None:
                return node.values[0]
            return node


# Generated at 2022-06-18 00:00:45.692408
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:00:54.477487
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_from_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_tree = get_ast(source)
    DictUnpackingTransformer().visit(ast_tree)

# Generated at 2022-06-18 00:01:00.045878
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(expected, dump(new_tree))

# Generated at 2022-06-18 00:01:01.265675
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:05.665045
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """
    tree = parse_ast(source)
    DictUn

# Generated at 2022-06-18 00:01:13.602078
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_program

    program = """
    {1: 1, **dict_a}
    """

    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    assert_program(program, expected, DictUnpackingTransformer)



# Generated at 2022-06-18 00:01:24.177090
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-18 00:01:34.684618
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')



# Generated at 2022-06-18 00:01:45.073643
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name

    tree = parse_ast_tree('''
    {1: 1, **dict_a}
    ''')
    node = get_ast_node(tree, 'Dict')
    transformer = DictUnpackingTransformer()
    new_node = transformer.visit(node)
    assert_equal_ast(new_node, '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    assert get_ast_node_name(new_node) == 'Call'
    assert transformer._tree_

# Generated at 2022-06-18 00:01:51.447464
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def merge_dicts():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

    class DictUnpackingTransformer(BaseNodeTransformer):
        """Compiles:
        
            {1: 1, **dict_a}
            
        To:
        
            _py_backwards_merge_dicts([{1: 1}], dict_a})
        
        """
        target = (3, 4)


# Generated at 2022-06-18 00:01:59.499135
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        {'a': 1, **{'b': 2}},
        {'a': 1, **{'b': 2}},
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        """
    )


# Generated at 2022-06-18 00:02:09.844959
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_equal_ast(get_ast_as_string(tree), expected)

# Generated at 2022-06-18 00:02:10.662693
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:19.728446
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:02:31.465343
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    source_ast = parse_ast(source)
    expected_ast = parse_ast(expected)
    transformer = DictUnpackingTransformer()
    result_ast = transformer.visit(source_ast)
    assert_equal_ast(result_ast, expected_ast)

# Generated at 2022-06-18 00:02:40.764293
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    tree = parse_ast("""
    def f():
        return {1: 1, **dict_a}
    """)
    expected = parse_ast("""
    def f():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        return _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert_equal_ast(result, expected)

# Generated at 2022-06-18 00:02:41.694615
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:01.979052
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_source

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_source(DictUnpackingTransformer, source, expected)


# Generated at 2022-06-18 00:03:09.802510
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump

    source = source('''
    {1: 1, **dict_a}
    ''')

    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert dump(node) == source('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:03:10.915838
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-18 00:03:12.447914
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:14.188810
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:15.104001
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:21.187957
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected
    print_ast(tree)

# Generated at 2022-06-18 00:03:27.124539
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:03:36.893918
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = """
    {1: 1, **dict_a}
    """
    expected_source = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = ast.parse(expected_source)
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)


# Generated at 2022-06-18 00:03:46.998670
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    ast_tree = source_to_ast(source)
    print_tree(ast_tree)
    transformer = DictUnpackingTransformer()
    new_ast_tree = transformer.visit(ast_tree)
    print_tree(new_ast_tree)
    compare_ast(new_ast_tree, expected)

# Generated at 2022-06-18 00:04:24.557552
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast
    from ..utils.unparse import Unparser

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    actual = Unparser(tree).unparse()
    compare_ast(expected, actual)

# Generated at 2022-06-18 00:04:35.592111
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_with_imports

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(get_ast_as_string(tree), expected)
    assert_equal_ast(get_ast_as_string_with_imports(tree), expected)



# Generated at 2022-06-18 00:04:43.837392
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        def f():
            return {1: 1, **{2: 2}}

    node = ast.parse(code.get_body())
    transformer = DictUnpackingTransformer()
    transformer.visit(node)

# Generated at 2022-06-18 00:04:51.497903
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    """
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:04:57.525356
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, code, expected)



# Generated at 2022-06-18 00:05:06.029208
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
        {1: 1, **dict_a}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = parse_ast_tree('''
        {1: 1, 2: 2, **dict_a}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-18 00:05:17.449733
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(code)
    expected_tree = ast.parse(expected)
    transformer = DictUnpackingTransformer()
    result_tree = transformer.visit(tree)

# Generated at 2022-06-18 00:05:27.231268
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:05:28.188631
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:29.391092
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:30.054630
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:30.520675
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:36.587673
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_lineno
    from ..utils.test_utils import get_ast_node_col_offset

    tree = parse_ast_tree('''
        {1: 1, **dict_a}
    ''')
    node = get_ast_node(tree, 'Dict')
    transformer = DictUnpackingTransformer()
    new_node = transformer.visit(node)

# Generated at 2022-06-18 00:06:37.225574
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:42.659412
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:06:43.667411
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:48.313193
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-18 00:06:58.312435
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import code_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_code

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    code = ast_to_code(node)
    assert code == expected

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """

# Generated at 2022-06-18 00:06:59.058724
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:07:06.698764
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

