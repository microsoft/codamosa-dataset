

# Generated at 2022-06-17 23:57:19.947798
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source

    source_ = """
        {1: 1, **dict_a}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source(source_)
    DictUnpackingTransformer().visit(node)
    assert source(expected_) == node

# Generated at 2022-06-17 23:57:23.399559
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module = source_to_ast(source)
    visitor = NodeVisitor(DictUnpackingTransformer())
    visitor.visit(module)
    assert ast_to_source(module) == expected

# Generated at 2022-06-17 23:57:34.231975
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast


# Generated at 2022-06-17 23:57:43.253656
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert_equal_ast(tree, parse_ast(expected))
    assert_equal_source(tree, expected)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """

# Generated at 2022-06-17 23:57:52.015542
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    '''
    node = parse_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert_equal_ast(node, expected)

# Generated at 2022-06-17 23:58:00.189986
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(tree, expected)



# Generated at 2022-06-17 23:58:06.151486
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test import transform_and_compare

    @snippet
    def before():
        def f():
            return {1: 1, **dict_a}

    @snippet
    def after():
        def f():
            return _py_backwards_merge_dicts([{1: 1}], dict_a)

    transform_and_compare(ast.parse(before()), ast.parse(after()))



# Generated at 2022-06-17 23:58:13.577411
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected_ = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    node = ast_from_source(source_)
    DictUnpackingTransformer().visit(node)
    assert dump(node) == expected_

# Generated at 2022-06-17 23:58:21.611802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected_source = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = source_to_ast(expected_source)

    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(tree)
    assert compare_ast(tree, expected_ast)
    assert ast_to_source(tree) == expected_source

# Generated at 2022-06-17 23:58:27.280111
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_node_equal

    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    {1: 1, **dict_a}
    ''')
    DictUnpackingTransformer().visit(node)
    assert_node_equal(node, expected)



# Generated at 2022-06-17 23:58:41.368168
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    class Visitor(NodeTransformerVisitor):
        transformer = DictUnpackingTransformer

    visitor = Visitor()
    tree = source_to_ast(source)
    visitor.visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-17 23:58:52.502339
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_parsed_ast_is
    from ..utils.testing import assert_transformed_ast_is
    from ..utils.testing import assert_tree_changed

    assert_parsed_ast_is(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '''
        Module(
            body=[
                Expr(
                    value=Dict(
                        keys=[
                            Num(n=1),
                            Name(id='dict_a', ctx=Load())
                        ],
                        values=[
                            Num(n=1),
                            Name(id='dict_a', ctx=Load())
                        ]
                    )
                )
            ]
        )
        '''
    )


# Generated at 2022-06-17 23:59:03.230342
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import assert_tree_unchanged

    # Test with empty module
    module = ast.parse('')
    assert_tree_equal(DictUnpackingTransformer().visit(module), module)
    assert_tree_unchanged(DictUnpackingTransformer(), module)

    # Test with module with dict unpacking
    module = ast.parse('{1: 1, **dict_a}')

# Generated at 2022-06-17 23:59:14.054465
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_equal_code
    from ..utils.testing import assert_equal_code_with_imports
    from ..utils.testing import assert_equal_code_with_imports_and_prefix
    from ..utils.testing import assert_equal_code_with_imports_and_prefix_and_suffix
    from ..utils.testing import assert_equal_code_with_imports_and_prefix_and_suffix_and_indent
    from ..utils.testing import assert_equal_code_with_imports_and_prefix_and_suffix_and_indent_and_newline
    from ..utils.testing import assert_equal_code_with_imports_and_prefix_and_

# Generated at 2022-06-17 23:59:20.039115
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-17 23:59:29.905261
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_factory import ast_call, ast_dict, ast_name, ast_list

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    node = ast.parse(source_)
    node = DictUnpackingTransformer().visit(node)
    assert dump(node) == expected

    source_ = source('''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    ''')

# Generated at 2022-06-17 23:59:39.261340
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:59:49.708923
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    {1: 1, **dict_a}
    ''')

    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)

    assert_equal_ast(new_tree, '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')



# Generated at 2022-06-17 23:59:58.977413
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from ..utils.transform import transform
    from ..utils.snippet import snippet

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = transform(DictUnpackingTransformer, source)
    assert compare_ast(dump(tree), dump(expected))

# Generated at 2022-06-18 00:00:06.821974
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = get_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)


# Generated at 2022-06-18 00:00:13.967685
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:00:14.702936
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:00:15.311150
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:00:25.777263
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.compat import ast_parse

    source_ = source('''
        {1: 1, **dict_a}
        {1: 1, **dict_a, **dict_b}
        {1: 1, **dict_a, 2: 2, **dict_b}
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    ''')
    module = ast_parse(source_)
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-18 00:00:36.503708
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import get_ast
    from ..utils.testing import get_tree
    from ..utils.testing import get_tree_str
    from ..utils.testing import get_tree_str_from_ast

    tree = get_tree('''
        {1: 1, **dict_a}
    ''')
    expected = get_tree('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    assert_tree_equal(DictUnpackingTransformer().visit(tree), expected)

   

# Generated at 2022-06-18 00:00:47.522604
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet

# Generated at 2022-06-18 00:00:55.482696
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:00:55.961856
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:00:56.581466
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:05.618221
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:01:13.118230
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:22.968037
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import dump_ast
    from ..utils.compare import compare_ast
    from ..utils.snippet import snippet

    @snippet
    def before():
        {1: 1, **dict_a}

    @snippet
    def after():
        _py_backwards_merge_dicts([{1: 1}], dict_a)

    ast_before = source_to_ast(before.get_source())
    ast_after = source_to_ast(after.get_source())
    transformer = DictUnpackingTransformer()
    transformer.visit(ast_before)
    assert compare_ast(ast_before, ast_after)

# Generated at 2022-06-18 00:01:23.912749
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:29.508931
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, code, expected)



# Generated at 2022-06-18 00:01:37.676269
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:01:47.009988
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string

    code = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert get_ast_as_string(tree) == expected

# Generated at 2022-06-18 00:01:56.138578
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_tree_equal
    from ..utils.tree import tree

    module = tree('''
    {1: 1, **dict_a}
    ''')
    expected = tree('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    DictUnpackingTransformer().visit(module)
    assert_tree_equal(module, expected)


# Generated at 2022-06-18 00:02:06.974512
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

    tree = source_to_ast(source)
    TestVisitor().visit(tree)

# Generated at 2022-06-18 00:02:11.205277
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)

# Generated at 2022-06-18 00:02:18.953811
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import transform_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse_ast(source)
    tree = transform_ast(tree, DictUnpackingTransformer)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:02:31.871603
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:32.728172
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:38.400400
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:02:40.010775
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:49.718589
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(new_tree, ast.parse(expected))
    assert_equal_source(new_tree, expected)


# Generated at 2022-06-18 00:02:50.729433
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:51.685401
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:52.684558
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:59.795825
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_as_string
    from ..utils.test_utils import get_source_as_string_with_comments
    from ..utils.test_utils import get_source_as_string_without_comments
    from ..utils.test_utils import get_source_as_string_without_comments_and_docstrings
    from ..utils.test_utils import get_source_as_string_without_docstrings
    from ..utils.test_utils import get_source_without_comments
    from ..utils.test_utils import get_source_without_comments_

# Generated at 2022-06-18 00:03:07.291039
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import parse_ast_tree

    tree = parse_ast_tree('''
        {1: 1, **dict_a}
    ''')
    expected = parse_ast_tree('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert_tree_equal(tree, expected)



# Generated at 2022-06-18 00:03:37.451159
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, 2: 2, **a, 3: 3, **b, 4: 4, **c}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, a, {3: 3}, b, {4: 4}], c)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:03:45.513509
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''

    transformer = DictUnpackingTransformer()
    tree = source_to_ast(source)
    transformer.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:03:46.413552
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:47.400922
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:57.185459
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:03:58.012902
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:58.894507
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:09.644408
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_by_path
    from ..utils.test_utils import get_ast_node_by_path_and_class
    from ..utils.test_utils import get_ast_node_by_path_and_class_and_attr
    from ..utils.test_utils import get_ast_node_by_path_and_class_and_attrs
    from ..utils.test_utils import get_ast_node_by_path_and_class_and_attrs_and_value
    from ..utils.test_utils import get_

# Generated at 2022-06-18 00:04:11.852828
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:20.681073
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        def test_dict_unpacking(self):
            tree = source("""
            {1: 1, **dict_a}
            """)
            expected = source("""
            _py_backwards_merge_dicts([{1: 1}], dict_a)
            """)
            self.check_transformation(tree, expected, DictUnpackingTransformer)

    test = Test()
    test.test_dict_unpacking()

# Generated at 2022-06-18 00:05:19.535595
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    # Test 1
    node = ast.parse('{1: 1, **dict_a}')
    result = DictUnpackingTransformer().visit(node)
    assert_tree_changed(result)
    assert_node_equal(result, ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)'))

    # Test 2
    node = ast.parse('{1: 1, **dict_a, 2: 2, **dict_b}')

# Generated at 2022-06-18 00:05:29.999975
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_code_equal
    from ..testing import assert_tree_equal
    from ..testing import assert_tree_not_equal
    from ..testing import assert_tree_changed
    from ..testing import assert_tree_not_changed
    from ..testing import assert_code_not_equal

    # Test for empty dict
    assert_tree_not_changed(DictUnpackingTransformer, '{}')

    # Test for dict without unpacking
    assert_tree_not_changed(DictUnpackingTransformer, '{1: 1}')

    # Test for dict with unpacking
    assert_tree_changed(DictUnpackingTransformer, '{1: 1, **dict_a}')

# Generated at 2022-06-18 00:05:30.853344
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:36.177640
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source_ = """
    {1: 1, **dict_a}
    """
    expected_ = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module, _ = source.parse_module(source_)
    new_module = DictUnpackingTransformer().visit(module)
    assert compare_ast(expected_, dump(new_module))

# Generated at 2022-06-18 00:05:38.458862
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-18 00:05:47.955108
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    # Test 1: no dict unpacking
    source = """
    def f():
        return {1: 1}
    """
    expected = """
    def f():
        return {1: 1}
    """
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_not_changed(tree, new_tree)
    assert_equal_ast(expected, new_tree)

    # Test 2: dict unpacking
    source = """
    def f():
        return {1: 1, **{2: 2}}
    """

# Generated at 2022-06-18 00:05:50.488670
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:51.415104
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:05:59.600974
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import get_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = get_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, expected)
    assert_equal_source(new_tree, expected)
    assert_tree_changed(transformer)

    tree = get_ast(source)

# Generated at 2022-06-18 00:06:09.078973
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compat import parse

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = parse(source)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')