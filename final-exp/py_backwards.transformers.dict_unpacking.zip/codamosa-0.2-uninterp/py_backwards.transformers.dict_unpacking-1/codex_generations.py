

# Generated at 2022-06-17 23:57:32.047583
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    actual = DictUnpackingTransformer().visit(source_to_ast(source))
    assert ast.dump(actual) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-17 23:57:40.388962
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compat import parse

    code = source('''
        {1: 1, **dict_a}
    ''')
    tree = parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-17 23:57:48.223567
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected



# Generated at 2022-06-17 23:57:53.158133
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compat import parse

    source_ = source(merge_dicts)
    tree = parse(source_)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source(merge_dicts)


# Generated at 2022-06-17 23:58:04.709190
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """
    tree = parse_ast

# Generated at 2022-06-17 23:58:08.512045
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert ast_to_source(new_tree) == expected

# Generated at 2022-06-17 23:58:18.670139
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """\
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """\
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.expr:
            return DictUnpackingTransformer().visit(node)  # type: ignore

    tree = source_to_ast(source)
    Visitor().visit(tree)

# Generated at 2022-06-17 23:58:29.729502
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import get_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = get_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)



# Generated at 2022-06-17 23:58:40.866889
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert_tree_changed(transformer)

# Generated at 2022-06-17 23:58:52.237085
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_for_source
    from ..utils.test_utils import get_source_for_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    node = parse_ast(source)
    result = DictUnpackingTransformer().visit(node)
    assert_equal_ast(result, get_ast_for_source(expected))
    assert_equal_ast(node, get_ast_for_source(source))


# Generated at 2022-06-17 23:59:11.279849
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source

    source_ = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    node = ast_from_source(source(source_))
    DictUnpackingTransformer().visit(node)
    assert dump(node) == source(expected_)

# Generated at 2022-06-17 23:59:18.130801
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source

    source_ = source('''
        {1: 1, **dict_a}
    ''')
    expected_ = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast_from_source(source_)
    DictUnpackingTransformer().visit(module)
    assert dump(module) == expected_

# Generated at 2022-06-17 23:59:28.672258
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_from_snippet
    from ..utils.test_utils import get_ast_from_snippet_with_backend

    snippet_1 = """
        {1: 1, **dict_a}
    """
    snippet_2 = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    snippet_3 = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    snippet_4 = """
        {1: 1, **dict_a, **dict_b, 2: 2, **dict_c}
    """
    snippet_5

# Generated at 2022-06-17 23:59:36.580815
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import dump
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump(tree), expected)



# Generated at 2022-06-17 23:59:41.982185
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        {'a': 1, **{'b': 2}},
        {'a': 1, **{'b': 2}},
        """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        """
    )

# Generated at 2022-06-17 23:59:52.018645
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.tree import ast_to_str
    from ..utils.ast_helpers import get_ast_of_snippet
    from ..utils.test_utils import assert_ast_equal

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = get_ast_of_snippet(source)
    DictUnpackingTransformer().visit(tree)
    assert_ast_equal(astor.to_source(tree), expected)



# Generated at 2022-06-18 00:00:00.999054
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast_and_code
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_code
    from ..utils.source import ast_and_code_to_source
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import code_to_ast_and_source

    source = """
        {1: 1, **dict_a}
    """

# Generated at 2022-06-18 00:00:06.088857
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_equal

    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse(
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_node_equal(result, expected)

# Generated at 2022-06-18 00:00:14.924615
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert ast_to_source(new_tree) == expected

# Generated at 2022-06-18 00:00:20.834394
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source

    source_ = source('''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    ''')

    node = ast_from_source(source_)
    DictUnpackingTransformer().visit(node)
    assert dump(node) == expected

# Generated at 2022-06-18 00:00:37.669511
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    source_ = source('''
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    ''')
    expected_ = source('''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    ''')

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return DictUnpackingTransformer().visit(node)

    actual_ = dump(Visitor().visit(source_.ast))
    compare_

# Generated at 2022-06-18 00:00:44.347780
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class TestNodeVisitor(NodeVisitor):
        def __init__(self):
            self.nodes = []

        def visit_Dict(self, node: ast.Dict):
            self.nodes.append(node)

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-18 00:00:52.435111
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_from_snippet

    transformer = DictUnpackingTransformer()
    assert_equal_ast(
        transformer.visit(parse_ast(get_ast_from_snippet(merge_dicts))),
        get_ast_from_snippet(merge_dicts))

    assert_equal_ast(
        transformer.visit(parse_ast(get_ast_from_snippet(
            '{1: 1, **dict_a}'))),
        get_ast_from_snippet(
            '_py_backwards_merge_dicts([{1: 1}], dict_a)'))

    assert_equal

# Generated at 2022-06-18 00:00:58.220907
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert to_source(node) == expected



# Generated at 2022-06-18 00:01:09.544826
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    # Test for dict without unpacking
    source = '{1: 1}'
    expected = '{1: 1}'
    tree = ast.parse(source)
    assert_tree_not_changed(tree, DictUnpackingTransformer)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)

    # Test for dict with unpacking
    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    tree = ast.parse(source)

# Generated at 2022-06-18 00:01:17.425036
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:01:25.133761
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """

    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer())
    visitor.visit(tree)
    print_tree(tree)
    assert compare_ast(tree, expected)

# Generated at 2022-06-18 00:01:35.823413
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.test_utils import assert_ast_equal

    node = ast.Dict(keys=[None, ast.Num(1), None, ast.Num(2)],
                    values=[ast.Dict(keys=[ast.Num(1)], values=[ast.Num(1)]),
                            ast.Dict(keys=[ast.Num(2)], values=[ast.Num(2)]),
                            ast.Dict(keys=[ast.Num(3)], values=[ast.Num(3)]),
                            ast.Dict(keys=[ast.Num(4)], values=[ast.Num(4)])])

# Generated at 2022-06-18 00:01:44.860717
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare_ast import compare_ast

    class Visitor(NodeVisitor):
        def visit_Dict(self, node):
            return node

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    actual = source(NodeVisitor().visit(tree))
    compare_ast(actual, expected)

# Generated at 2022-06-18 00:01:49.790562
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.tree import parse_tree

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_tree(source)
    DictUnpackingTransformer().visit(tree)
    assert_tree_equal(tree, expected)



# Generated at 2022-06-18 00:02:05.962204
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    actual = DictUnpackingTransformer().visit(source_to_ast(source))
    assert expected == ast.dump(actual)

# Generated at 2022-06-18 00:02:13.977759
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, code, expected)
    assert_tree_changed(DictUnpackingTransformer, code)

    code = '''
        {1: 1, 2: 2, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    '''

# Generated at 2022-06-18 00:02:24.674630
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a, 2: 2, **dict_b}',
        '_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)')


# Generated at 2022-06-18 00:02:34.822648
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.tree import assert_equal_ast
    from ..utils.tree import assert_equal_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(tree)
    assert_equal_ast(result, source_to_ast(expected))
    assert_equal_source(ast_to_source(result), expected)



# Generated at 2022-06-18 00:02:41.198128
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert DictUnpackingTransformer().visit(source_to_ast(source)) == \
        source_to_ast(expected)

# Generated at 2022-06-18 00:02:50.671965
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    result = ast_to_source(node)
    assert result == expected

    # Check that transformer works correctly with multiple unpacking statements
    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """

# Generated at 2022-06-18 00:02:57.219712
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    visitor = NodeVisitor(DictUnpackingTransformer())
    visitor.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:03:08.226863
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

    class Visitor(NodeVisitor):
        def __init__(self):
            self.calls = []

        def visit_Call(self, node: ast.Call):
            self.calls.append(node)

    visitor = Visitor()
    visitor.visit(node)

# Generated at 2022-06-18 00:03:16.430819
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast, source_to_code
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert source_to_code(tree) == expected



# Generated at 2022-06-18 00:03:24.171109
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = parse_ast(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:03:55.946769
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast
    from ..utils.tree import ast_to_text

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(source)
    DictUnpackingTransformer().visit(module)
    actual = ast_to_text(module)

    assert compare_ast(expected, actual)

# Generated at 2022-06-18 00:04:07.222807
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """

# Generated at 2022-06-18 00:04:12.630750
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast
    from ..utils.testing import assert_transformed_source

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, 2: 2, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)')


# Generated at 2022-06-18 00:04:22.504604
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    # Test case 1
    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse('_py_backwards_merge_dicts([{1: 1}], dict_a)')
    assert_tree_equal(DictUnpackingTransformer().visit(node), expected)

    # Test case 2
    node = ast.parse('{1: 1, **dict_a, 2: 2, **dict_b, 3: 3}')

# Generated at 2022-06-18 00:04:27.814494
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import print_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node) == expected

# Generated at 2022-06-18 00:04:36.275088
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    code = """
        {1: 1, **dict_a}
    """
    tree = parse_ast_tree(code)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    expected_code = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_tree = parse_ast_tree(expected_code)
    assert_equal_ast(expected_tree, new_tree)



# Generated at 2022-06-18 00:04:45.601623
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

# Generated at 2022-06-18 00:04:53.519807
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_ast

# Generated at 2022-06-18 00:05:00.569049
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.compare import compare_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    result = ast_to_source(tree)
    compare_source(result, expected)



# Generated at 2022-06-18 00:05:07.019395
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import to_source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer

    @snippet
    def source():
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}

    @snippet
    def expected():
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)

    node = ast.parse(source())
    DictUnpackingTransformer().visit(node)
    assert to_source(node) == expected()

# Generated at 2022-06-18 00:05:59.524668
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_factory import ast_call, ast_dict, ast_name, ast_list

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:10.087530
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name

    tree = parse_ast_tree('''
    {1: 1, **dict_a, 2: 2, **dict_b}
    ''')
    node = get_ast_node(tree, 'Dict')
    transformer = DictUnpackingTransformer()
    new_node = transformer.visit(node)
    assert_equal_ast(
        new_node,
        '''
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
        '''
    )

    tree

# Generated at 2022-06-18 00:06:19.494701
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class TestVisitor(NodeVisitor):
        def __init__(self):
            self.result = None

        def visit_Dict(self, node):
            self.result = node

    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    ast_ = source_to_ast(source)
    DictUnpackingTransformer().visit(ast_)
    visitor = TestVisitor()
    visitor.visit(ast_)
    assert ast_to_source(visitor.result) == expected

# Generated at 2022-06-18 00:06:29.623320
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_factory import ast_factory
    from ..utils.tree import assert_ast_equal

    # Test for simple case
    node = ast_factory(
        """
        {1: 1, 2: 2, **dict_a}
        """)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    expected = ast_factory(
        """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
        """)
    assert_ast_equal(result, expected)

    # Test for case with empty dicts

# Generated at 2022-06-18 00:06:33.212624
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, source, expected)

# Generated at 2022-06-18 00:06:41.100963
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(DictUnpackingTransformer, code, expected)

    code = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b, {3: 3}])
    """
    assert_equal_ast(DictUnpackingTransformer, code, expected)

    code

# Generated at 2022-06-18 00:06:48.674461
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast


# Generated at 2022-06-18 00:06:55.036221
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:07:06.130522
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_tree_code
    from ..utils.test_utils import assert_equal_tree_source
    from ..utils.test_utils import assert_equal_tree_ast
    from ..utils.test_utils import assert_equal_tree_tree
    from ..utils.test_utils import assert_equal_code_tree
    from ..utils.test_utils import assert_equal_source_tree
    from ..utils.test_utils import assert_equal_ast_tree
    from ..utils.test_utils import assert_equal_tree_tree

# Generated at 2022-06-18 00:07:14.926094
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    code = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}, dict_b])
    """
    tree = parse_ast(code)
    DictUn