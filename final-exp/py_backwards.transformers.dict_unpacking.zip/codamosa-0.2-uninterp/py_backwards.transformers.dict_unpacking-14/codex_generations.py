

# Generated at 2022-06-17 23:57:22.167761
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.compiler import compile_snippet

    class Visitor(NodeVisitor):
        def __init__(self):
            self.calls = []

        def visit_Call(self, node):
            self.calls.append(node)

    tree = compile_snippet(source(
        """
        {1: 1, **dict_a}
        """
    ))
    visitor = Visitor()
    visitor.visit(tree)
    assert len(visitor.calls) == 1
    assert visitor.calls[0].func.id == '_py_backwards_merge_dicts'
    assert visitor.calls[0].args[0].elts[0].keys[0].n == 1


# Generated at 2022-06-17 23:57:32.718392
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import assert_code_equal

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(code)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_

# Generated at 2022-06-17 23:57:40.660983
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compat import to_tuple

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == expected
    assert to_tuple(tree) == to_tuple(ast.parse(expected))



# Generated at 2022-06-17 23:57:52.166038
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import assert_tree_changed_by_transformer
    from ..utils.testing import assert_tree_not_changed_by_transformer
    from ..utils.testing import assert_tree_changed_by_transformer_class
    from ..utils.testing import assert_tree_not_changed_by_transformer_class
    from ..utils.testing import assert_tree_changed_by_transformer_instance
    from ..utils.testing import assert_tree_not_changed_by_transformer_instance
    from ..utils.testing import assert_tree_changed_by_transformer_instance_class

# Generated at 2022-06-17 23:58:03.997340
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.tree import dump
    from ..utils.visitor import dump_visit
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_node = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    result = transformer.visit(ast_node)

# Generated at 2022-06-17 23:58:15.908028
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import NodeVisitor
    from ..utils.compat import ast_parse

    class Visitor(NodeVisitor):
        def visit_Call(self, node: ast.Call) -> None:
            assert isinstance(node.func, ast.Name)
            assert node.func.id == '_py_backwards_merge_dicts'
            assert len(node.args) == 1
            assert isinstance(node.args[0], ast.List)
            assert len(node.args[0].elts) == 2
            assert isinstance(node.args[0].elts[0], ast.Dict)
            assert len(node.args[0].elts[0].keys) == 1

# Generated at 2022-06-17 23:58:22.782559
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)

# Generated at 2022-06-17 23:58:29.298678
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_node_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal

    node = ast.parse('{1: 1, **dict_a}')
    expected = ast.parse(merge_dicts() + '{1: 1, **dict_a}')
    assert_tree_not_equal(node, expected)
    assert_tree_equal(DictUnpackingTransformer().visit(node), expected)



# Generated at 2022-06-17 23:58:34.546174
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.visitor import print_visitor
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    print_tree(tree)
    print_visitor(DictUnpackingTransformer, tree)
    compare_ast

# Generated at 2022-06-17 23:58:43.036529
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_with_imports
    from ..utils.test_utils import get_ast_as_string_with_imports_and_merge_dicts
    from ..utils.test_utils import get_ast_as_string_with_imports_and_merge_dicts_and_backwards_merge_dicts

    code = '''
        {1: 1, **dict_a}
    '''
    expected_code = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    expected_

# Generated at 2022-06-17 23:58:53.194119
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeTransformerVisitor

    source_ = source('''
    {1: 1, **dict_a}
    ''')
    expected = source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    actual = dump(NodeTransformerVisitor(DictUnpackingTransformer).visit(source_))
    assert actual == expected

# Generated at 2022-06-17 23:58:59.360922
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        '{1: 1, **dict_a}',
        '_py_backwards_merge_dicts([{1: 1}], dict_a)')

# Generated at 2022-06-17 23:59:05.470324
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import parse

    source_ = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = parse(source(source_))

    DictUnpackingTransformer().visit(node)

    assert source(node) == source(expected)

# Generated at 2022-06-17 23:59:10.840341
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    code = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert_equal_ast(DictUnpackingTransformer, code, expected)

# Generated at 2022-06-17 23:59:20.458945
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = '''
    {1: 2, **{3: 4}}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 2}], {3: 4})
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(expected, new_tree)

# Generated at 2022-06-17 23:59:30.151209
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import ast_to_source
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import ast_to_code

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    code = ast_to_code(node)
    assert code == expected


# Generated at 2022-06-17 23:59:40.814535
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, parse(expected))
    assert_equal_source(tree, expected)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b}
    """

# Generated at 2022-06-17 23:59:52.565703
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import assert_tree_changed_by_count
    from ..utils.testing import assert_tree_changed_by_count_in_line
    from ..utils.testing import assert_tree_changed_by_count_in_line_and_column
    from ..utils.testing import assert_tree_changed_by_count_in_line_and_column_and_offset
    from ..utils.testing import assert_tree_changed_by_count_in_line_and_column_and_offset_and_text
    from ..utils.testing import assert_tree_changed_by_count_in_line_and_column_and_offset_and_text_

# Generated at 2022-06-18 00:00:00.352247
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:00:08.778939
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import print_tree
    from ..utils.source import source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer
    from ..utils.source import source
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.tree import print_tree
    from ..utils.snippet import snippet
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.tree import print_tree

# Generated at 2022-06-18 00:00:20.640481
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import expect_equal

    source = source('''
    {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-18 00:00:21.658367
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:00:29.107387
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.ast_builder import ast_from_source

    source_ = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)
    """
    node = ast_from_source(source(source_))
    DictUnpackingTransformer().visit(node)
    assert dump(node) == source(expected_)

# Generated at 2022-06-18 00:00:36.503983
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast_to_source(node).strip() == expected.strip()



# Generated at 2022-06-18 00:00:47.521089
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import get_ast

    code = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    ast_ = get_ast(code)
    transformer = DictUnpackingTransformer()
    assert_tree_changed(transformer, ast_)

# Generated at 2022-06-18 00:00:56.796152
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import code_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_code
    from ..utils.source import code_equal

    source = """
    {1: 1, **dict_a}
    """
    expected_source = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = code_to_ast(expected_source)
    node = source_to_ast(source)
    node = DictUnpackingTransformer().visit(node)
    assert code_equal(ast_to_code(node), expected_source)
    assert ast_to_

# Generated at 2022-06-18 00:01:00.801759
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    print(dump(tree))

# Generated at 2022-06-18 00:01:07.860941
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump

    source_ = """
        {1: 1, **dict_a}
    """
    expected_ = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source(source_)
    DictUnpackingTransformer().visit(node)
    assert dump(node) == expected_

# Generated at 2022-06-18 00:01:19.169592
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node_at_line
    from ..utils.test_utils import get_ast_node_at_pos

    source = '''
        {1: 1, **dict_a}
        '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
        '''
    module = parse_ast(source)
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-18 00:01:23.860346
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = ast.parse(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(tree, expected)

    source

# Generated at 2022-06-18 00:01:39.847142
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import get_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = get_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:01:48.797939
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    {1: 1, **dict_a}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = parse_ast_tree('''
    {1: 1, 2: 2, **dict_a}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-18 00:01:50.258658
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:51.900843
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:52.813556
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:01:59.294612
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    node = ast.parse(source)
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-18 00:02:05.302136
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(ast.parse(expected), tree)



# Generated at 2022-06-18 00:02:13.714025
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    {1: 1, **dict_a}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = parse_ast_tree('''
    {1: 1, **dict_a, 2: 2, **dict_b}
    ''')
    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)

# Generated at 2022-06-18 00:02:21.330986
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump_ast
    from ..utils.compare_ast import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(dump_ast(new_tree), expected)



# Generated at 2022-06-18 00:02:22.224190
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:37.534109
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:47.597849
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    {1: 1, **dict_a}
    ''')

    transformer = DictUnpackingTransformer()
    new_tree = transformer.visit(tree)

    assert_equal_ast(new_tree, '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')



# Generated at 2022-06-18 00:02:49.662387
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:50.678847
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:02:56.672261
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:03:05.784802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare import compare_ast
    from ..utils.unparse import Unparser

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    actual = Unparser(tree).unparse()

    assert compare_ast(ast.parse(expected), ast.parse(actual))

# Generated at 2022-06-18 00:03:16.508064
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_by_path
    from ..utils.test_utils import get_ast_node_by_paths
    from ..utils.test_utils import get_ast_nodes_by_type
    from ..utils.test_utils import get_ast_nodes_by_types
    from ..utils.test_utils import get_ast_node_by_type
    from ..utils.test_utils import get_ast_node_by_types
    from ..utils.test_utils import get_ast_node_by_value

# Generated at 2022-06-18 00:03:17.421274
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:18.267388
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:03:23.197211
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import dump
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast
    from ..utils.source import ast_to_source

    source = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, {4: 4}])
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(ast_to_source(tree), expected)

# Generated at 2022-06-18 00:03:57.932682
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast
    from ..utils.visitor import print_ast

    code = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    module = get_ast(code)
    DictUnpackingTransformer().visit(module)
    assert source(module) == expected

# Generated at 2022-06-18 00:04:08.429558
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_equal_source

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(expected, tree)
    assert_equal_source(expected, tree)


# Generated at 2022-06-18 00:04:12.996419
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source

    source = source('''
        {1: 1, **dict_a}
    ''')
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)
    assert source == merge_dicts.get_source() + source

# Generated at 2022-06-18 00:04:21.606378
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:04:29.150118
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node_at_line
    from ..utils.test_utils import get_ast_node_at_pos
    from ..utils.test_utils import get_ast_node_at_pos_in_func
    from ..utils.test_utils import get_ast_node_at_pos_in_class
    from ..utils.test_utils import get_ast_node_at_pos_in_method
    from ..utils.test_utils import get_ast_node_at_pos_in_lambda
    from ..utils.test_utils import get_ast_node_at_pos_in_genexpr
    from ..utils.test_utils import get_ast_node_at_

# Generated at 2022-06-18 00:04:38.346053
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        {
            'before': '''
                {1: 1, **dict_a}
            ''',
            'after': '''
                _py_backwards_merge_dicts([{1: 1}], dict_a)
            '''
        })

    assert_transformed_ast(
        DictUnpackingTransformer,
        {
            'before': '''
                {1: 1, 2: 2, **dict_a}
            ''',
            'after': '''
                _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
            '''
        })


# Generated at 2022-06-18 00:04:48.377610
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_helpers import get_ast_of_snippet
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def test_snippet():
        def f():
            return {1: 1, **{2: 2}, **{3: 3}, 4: 4}

    expected_ast = get_ast_of_snippet(test_snippet)

# Generated at 2022-06-18 00:04:49.200667
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:04:55.568627
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    actual = dump(tree)

    assert compare_ast(expected, actual)

# Generated at 2022-06-18 00:05:03.995201
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:05:59.735184
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:10.322748
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.testing import assert_node_equal

    node = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                    values=[ast.Num(n=1), ast.Name(id='a'), ast.Num(n=2)])

# Generated at 2022-06-18 00:06:11.011454
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:20.829703
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        {
            'before': '''
                {1: 1, **dict_a}
            ''',
            'after': '''
                _py_backwards_merge_dicts([{1: 1}], dict_a)
            ''',
        }
    )

    assert_transformed_ast(
        DictUnpackingTransformer,
        {
            'before': '''
                {1: 1, 2: 2, **dict_a}
            ''',
            'after': '''
                _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
            ''',
        }
    )

    assert_transformed_ast

# Generated at 2022-06-18 00:06:21.746675
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-18 00:06:32.334717
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_source
    from ..utils.test_utils import get_source_as_ast
    from ..utils.test_utils import get_source_as_string
    from ..utils.test_utils import get_source_as_source
    from ..utils.test_utils import get_source_as_ast_and_source
    from ..utils.test_utils import get_source_as_ast_and_string
    from ..utils.test_utils import get_source_as_ast_and_source_and_string
    from ..utils.test_utils import get_source_as_source_and_

# Generated at 2022-06-18 00:06:36.552290
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:06:45.709682
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    tree = source_to_ast(source)
    NodeTransformerVisitor(DictUnpackingTransformer()).visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:06:56.669982
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def source():
        {1: 1, **dict_a}

    @snippet
    def expected():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result

        _py_backwards_merge_dicts([{1: 1}], dict_a)

    source_tree = ast.parse(source.get_body())
    expected_tree = ast.parse(expected.get_body())
    transformer = DictUnpackingTransformer()
    result_tree = transformer.visit(source_tree)
    assert ast

# Generated at 2022-06-18 00:07:01.340315
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.testing import assert_transformation
    assert_transformation(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)