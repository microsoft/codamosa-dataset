

# Generated at 2022-06-17 23:57:34.655534
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_as_string
    from ..utils.test_utils import get_ast_as_string_after_transformation

    code = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
   

# Generated at 2022-06-17 23:57:40.893462
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-17 23:57:50.804673
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(ast_to_source(tree), expected)



# Generated at 2022-06-17 23:57:58.898287
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_code
    from ..utils.test_utils import get_source

    source = get_source(__file__, 'test_DictUnpackingTransformer_visit_Dict')
    tree = get_ast(source)
    transformer = DictUnpackingTransformer()
    tree = transformer.visit(tree)
    code = get_code(tree)
    assert_equal_ast(code, source)

# Generated at 2022-06-17 23:58:07.112763
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.testing import assert_ast_equal

    node = ast.Dict(keys=[ast.Num(n=1), None, ast.Num(n=2)],
                    values=[ast.Num(n=1), ast.Name(id='dict_a'), ast.Num(n=2)])

# Generated at 2022-06-17 23:58:17.514095
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node_at_line
    from ..utils.test_utils import get_ast_node_at_offset
    from ..utils.test_utils import get_ast_node_at_lineno
    from ..utils.test_utils import get_ast_node_at_col_offset
    from ..utils.test_utils import get_ast_node_at_pos
    from ..utils.test_utils import get_ast_node_at_pos_end
    from ..utils.test_utils import get_ast_node_at_pos_range
    from ..utils.test_utils import get_ast_node_at_pos_range_end

# Generated at 2022-06-17 23:58:27.493329
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from ..utils.ast_compare import compare_ast

    node = ast.Dict(keys=[ast.Num(n=1), None, ast.Str(s='a')],
                    values=[ast.Num(n=1), ast.Dict(keys=[], values=[]),
                            ast.Num(n=2)])

# Generated at 2022-06-17 23:58:39.765085
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a}
        """,
        """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """)

    assert_transformed_ast(
        DictUnpackingTransformer,
        """
        {1: 1, **dict_a, 2: 2, **dict_b}
        """,
        """
        _py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a, dict_b)
        """)


# Generated at 2022-06-17 23:58:50.977699
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, **dict_a}")),
        ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a)"))

    assert_equal_ast(
        DictUnpackingTransformer().visit(ast.parse("{1: 1, **dict_a, 2: 2}")),
        ast.parse("_py_backwards_merge_dicts([{1: 1}, {2: 2}], dict_a)"))


# Generated at 2022-06-17 23:59:01.109140
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3, 4: 4}], dict_a, dict_b)
    """
    node = parse_ast(source)
    DictUnpackingTransformer().visit(node)
    assert_equal_ast(node, expected)

# Generated at 2022-06-17 23:59:17.952792
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.ast_builder import build_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = build_ast(source)
    DictUnpackingTransformer().visit(node)
    result = astor.to_source(node)
    assert result == expected

# Generated at 2022-06-17 23:59:24.079678
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_tree_unchanged
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal

    assert_tree_unchanged(DictUnpackingTransformer, '{}')
    assert_tree_unchanged(DictUnpackingTransformer, '{1: 1}')
    assert_tree_unchanged(DictUnpackingTransformer, '{1: 1, 2: 2}')
    assert_tree_unchanged(DictUnpackingTransformer, '{**{}}')
    assert_tree_unchanged(DictUnpackingTransformer, '{**{1: 1}}')

# Generated at 2022-06-17 23:59:32.310546
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor
    from ..utils.source import source_to_ast

    source = '''
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    '''

    ast_ = source_to_ast(source)
    DictUnpackingTransformer().visit(ast_)
    assert ast_to_source(ast_) == expected

    ast_ = source_to_ast(source)
   

# Generated at 2022-06-17 23:59:42.388649
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import parse_snippet_as_module
    from ..utils.test_utils import parse_snippet_as_module_with_imports
    from ..utils.test_utils import parse_snippet_as_module_with_imports_and_functions
    from ..utils.test_utils import parse_snippet_as_module_with_imports_and_functions_and_classes

    transformer = DictUnpackingTransformer()


# Generated at 2022-06-17 23:59:50.997025
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, 2: 2, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    """
    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-17 23:59:56.041506
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    assert expected == DictUnpackingTransformer().visit(source_to_ast(source))

# Generated at 2022-06-18 00:00:06.457856
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class DictUnpackingVisitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> None:
            if None not in node.keys:
                return

            pairs = zip(node.keys, node.values)
            splitted = DictUnpackingTransformer._split_by_None(pairs)
            prepared = DictUnpackingTransformer._prepare_splitted(splitted)
            result = DictUnpackingTransformer._merge_dicts(prepared)
            assert ast_to_source(result) == ast_to_source(node)

    source = snippet

# Generated at 2022-06-18 00:00:17.065841
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node):
            return node

    source_ = source('''
    {1: 1, **dict_a}
    ''')
    node = ast.parse(source_)
    DictUnpackingTransformer().visit(node)
    visitor = Visitor()
    visitor.visit(node)
    assert dump(visitor.result) == dump(ast.parse('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''))

# Generated at 2022-06-18 00:00:21.071517
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:00:27.398293
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(print_tree(tree), expected)



# Generated at 2022-06-18 00:00:44.492679
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = '''
    {1: 1, **dict_a}
    '''
    expected = '''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected



# Generated at 2022-06-18 00:00:52.530949
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_asts

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    actual = ast_to_source(tree)
    assert compare_asts(expected, actual)


# Generated at 2022-06-18 00:01:00.100897
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.ast import compare_asts, dump
    from ..utils.snippet import snippet_to_ast

    snippet_ast = snippet_to_ast(merge_dicts)
    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    expected_ast = source_to_ast(expected)
    expected_ast.body.insert(0, snippet_ast.body[0])
    ast_ = source_to_ast(source)
    DictUnpackingTransformer().visit(ast_)
    assert compare_asts(ast_, expected_ast)

# Generated at 2022-06-18 00:01:08.644717
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

# Generated at 2022-06-18 00:01:15.443606
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')
    tree = ast.parse(code)
    DictUnpackingTransformer().visit(tree)
    assert dump(tree) == expected



# Generated at 2022-06-18 00:01:25.451194
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    visitor = Visitor()
    transformer = DictUnpackingTransformer()
    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    node = source_to_ast(source)
    node = transformer.visit(node)
    node = visitor.visit(node)
    result = ast_to_source(node)
    assert result == expected

# Generated at 2022-06-18 00:01:32.036691
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = source_to_ast(source)
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-18 00:01:38.688355
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_transformed_ast

    assert_transformed_ast(
        DictUnpackingTransformer,
        {
            '_py_backwards_merge_dicts': merge_dicts.get_body(),
        },
        {
            'before': """
                {1: 1, **dict_a}
            """,
            'after': """
                _py_backwards_merge_dicts([{1: 1}], dict_a)
            """
        }
    )

# Generated at 2022-06-18 00:01:43.165463
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    assert_equal_ast(code, expected, DictUnpackingTransformer)

# Generated at 2022-06-18 00:01:48.658771
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = '''
        {1: 1, **dict_a}
    '''
    expected = '''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    '''
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_source(expected, tree)



# Generated at 2022-06-18 00:02:19.384708
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """
    tree = parse_ast

# Generated at 2022-06-18 00:02:27.880366
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
    {1: 1, **dict_a}
    ''')
    expected = source('''
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    tree = ast.parse(source)
    new_tree = DictUnpackingTransformer().visit(tree)
    assert compare_ast(new_tree, ast.parse(expected))

# Generated at 2022-06-18 00:02:34.631800
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """
    {1: 1, 2: 2, **dict_a, 3: 3, **dict_b, 4: 4}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2}, dict_a, {3: 3}, dict_b, {4: 4}])
    """
    ast_tree = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(ast_tree)
    assert ast_to_source(ast_tree) == expected

# Generated at 2022-06-18 00:02:43.498503
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeTransformerVisitor

    source = """\
    {1: 1, **dict_a}
    """
    expected = """\
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    ast_ = source_to_ast(source)
    visitor = NodeTransformerVisitor(DictUnpackingTransformer)
    visitor.visit(ast_)
    assert ast_to_source(ast_) == expected

# Generated at 2022-06-18 00:02:50.293928
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)



# Generated at 2022-06-18 00:02:56.100659
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.visitor import dump

    code = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module = ast.parse(code)
    DictUnpackingTransformer().visit(module)
    assert dump(module) == expected

# Generated at 2022-06-18 00:03:02.662078
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:03:11.589557
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    source = '{1: 1, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    assert_equal_ast(DictUnpackingTransformer, source, expected)

    source = '{1: 1, 2: 2, **dict_a}'
    expected = '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)'
    assert_equal_ast(DictUnpackingTransformer, source, expected)

    source = '{1: 1, **dict_a, 2: 2, **dict_b}'

# Generated at 2022-06-18 00:03:21.109626
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source
    from ..utils.visitor import NodeVisitor
    from ..utils.compare import compare_ast

    class DictUnpackingTransformerTestVisitor(NodeVisitor):
        def __init__(self):
            self.result = []

        def visit_Call(self, node: ast.Call):
            self.result.append(node)

    source = """
    {1: 1, **dict_a}
    """
    expected_source = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    visitor = DictUnpackingTransformerTestVis

# Generated at 2022-06-18 00:03:29.002751
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed

    transformer = DictUnpackingTransformer()
    assert_tree_not_changed(transformer, '{}')
    assert_tree_not_changed(transformer, '{1: 1}')
    assert_tree_not_changed(transformer, '{1: 1, 2: 2}')
    assert_tree_not_changed(transformer, '{1: 1, 2: 2, 3: 3}')
    assert_tree_not_changed(transformer, '{1: 1, 2: 2, 3: 3, 4: 4}')

# Generated at 2022-06-18 00:04:19.384715
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import print_tree
    from ..utils.compare import compare_ast
    from ..utils.snippet import snippet

    @snippet
    def before():
        {1: 1, **dict_a}

    @snippet
    def after():
        _py_backwards_merge_dicts([{1: 1}], dict_a)

    ast_before = source_to_ast(before.get_source())
    ast_after = source_to_ast(after.get_source())
    transformer = DictUnpackingTransformer()
    ast_transformed = transformer.visit(ast_before)
    assert compare_ast(ast_after, ast_transformed)
    print_tree(ast_transformed)

# Generated at 2022-06-18 00:04:24.085548
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_equal_ast
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed

    node = ast.parse('{1: 1, **dict_a}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_tree_changed(transformer)
    assert_equal_ast(result, '_py_backwards_merge_dicts([{1: 1}], dict_a)')

    node = ast.parse('{1: 1, 2: 2, **dict_a}')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)
    assert_tree_changed(transformer)

# Generated at 2022-06-18 00:04:30.539402
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str
    from .base import BaseNodeTransformer
    from .dict_unpacking import DictUnpackingTransformer

    class DummyTransformer(BaseNodeTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    class DummyTransformer2(BaseNodeTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node

    class DummyTransformer3(BaseNodeTransformer):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return node


# Generated at 2022-06-18 00:04:38.704171
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_code_equal
    from ..utils.testing import assert_tree_equal
    from ..utils.testing import assert_tree_not_equal
    from ..utils.testing import assert_tree_changed
    from ..utils.testing import assert_tree_not_changed
    from ..utils.testing import assert_code_not_equal

    transformer = DictUnpackingTransformer()

    assert_tree_not_changed(transformer, '{}')
    assert_tree_not_changed(transformer, '{1: 1}')
    assert_tree_not_changed(transformer, '{1: 1, 2: 2}')
    assert_tree_not_changed(transformer, '{1: 1, **{}}')

# Generated at 2022-06-18 00:04:47.111943
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.compare_ast import compare_ast

    source = source('''
        {1: 1, **dict_a}
    ''')
    expected = source('''
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    ''')

    module, = parse(source)  # type: ignore
    DictUnpackingTransformer().visit(module)  # type: ignore
    actual = dump(module)

    result = compare_ast(expected, actual)
    assert result is None, result

# Generated at 2022-06-18 00:04:52.323743
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import parse_ast

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(code)
    tree = DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)



# Generated at 2022-06-18 00:05:03.394372
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.compare import compare_ast
    from ..utils.source import source_to_ast_str
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_source_str

    source = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert compare_ast(ast_to_source_str(tree), expected)

    source = """
        {1: 1, **dict_a, 2: 2, **dict_b}
    """

# Generated at 2022-06-18 00:05:12.994785
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_ast
    from ..utils.tree import ast_to_source

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b)
    """

    tree = source_to_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-18 00:05:19.012137
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeVisitor

    class Visitor(NodeVisitor):
        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return DictUnpackingTransformer().visit(node)

    code = """
        {1: 1, **dict_a}
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = source.parse(code)
    Visitor().visit(tree)
    assert dump(tree) == expected



# Generated at 2022-06-18 00:05:29.571276
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import parse_ast

    source = """
    {1: 1, **dict_a}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    tree = parse_ast(source)
    DictUnpackingTransformer().visit(tree)
    assert_equal_ast(tree, expected)
    assert_equal_source(tree, expected)

    source = """
    {1: 1, **dict_a, 2: 2, **dict_b, 3: 3}
    """