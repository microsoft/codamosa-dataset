

# Generated at 2022-06-21 17:35:12.780281
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # type: () -> None
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:35:21.484050
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    # Concrete code
    code = """
        {1: 1, **dict_a}
    """
    # Abstract syntax tree
    actual = ast.parse(code)
    # Abstract syntax tree after transformation
    expected = ast.parse("""
        _py_backwards_merge_dicts([{1: 1}], dict_a)
    """)
    # Transformation itself
    transformer = DictUnpackingTransformer()
    actual.body[0] = transformer.visit(actual.body[0])
    # Assertion
    assert transformer._tree_changed
    assert astor.to_source(actual) == astor.to_source(expected)


# Generated at 2022-06-21 17:35:25.885737
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    m = ast.parse('{1: 1, **dict_a, 2: 2, **dict_b}', mode='eval')
    t = DictUnpackingTransformer()
    result = t.visit(m)
    assert ast.dump(result) == '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a, dict_b)'

# Generated at 2022-06-21 17:35:31.854264
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:35:36.065322
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    script = astor.code_to_ast('{1: 1, **dict_a}')
    script = DictUnpackingTransformer().visit(script)
    expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
    assert expected == astor.to_source(script)

# Generated at 2022-06-21 17:35:38.874448
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """\
        {1: 1, **dict_a}
        """
    assert DictUnpackingTransformer().visit(ast.parse(code)) == \
        ast.parse("_py_backwards_merge_dicts([{1: 1}], dict_a)")

# Generated at 2022-06-21 17:35:43.176700
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Unit test for method visit_Dict of class DictUnpackingTransformer"""
    import astor    # type: ignore
    tree = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer.run(tree)
    assert astor.to_source(tree) == '''\
_py_backwards_merge_dicts([{1: 1}], dict_a)'''    # noqa: WPS421

# Generated at 2022-06-21 17:35:53.563504
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    transformer = DictUnpackingTransformer()

    node = ast.parse('''{1: 1, 2: 2, 3: 3}''')
    result = transformer.visit(node)
    expected = ast.parse('''{1: 1, 2: 2, 3: 3}''')
    assert ast.dump(result) == ast.dump(expected)

    node = ast.parse('''{1: 1, **dict_a}''')
    result = transformer.visit(node)
    expected = ast.parse('''_py_backwards_merge_dicts([{1: 1}], dict_a})''')
    assert ast.dump(result) == ast.dump(expected)

    node = ast.parse('''{**dict_a, 1: 1}''')
    result = transformer.vis

# Generated at 2022-06-21 17:36:00.766819
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """
    >>> from typed_ast import ast3 as ast
    >>> code = '''
    ... {1: 1, 2: 2, **dict_a}
    ... '''
    >>> tree = ast.parse(code)
    >>> DictUnpackingTransformer().visit(tree)
    >>> ast.dump(tree)
    "Module(body=[Expr(value=Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), args=[List(elts=[Dict(keys=[Num(n=1), Num(n=2)], values=[Num(n=1), Num(n=2)]), Name(id='dict_a', ctx=Load())], ctx=Load())], keywords=[], starargs=None, kwargs=None))])"
    """
    pass

# Generated at 2022-06-21 17:36:11.442300
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Class under test
    module = ast.parse('a = {1: 2, **{3: 4}}')
    transformer = DictUnpackingTransformer()
    module = transformer.visit(module)
    # Expected result
    expected = pytest.approx(
        ast.parse(
            '''
            def _py_backwards_merge_dicts(dicts):
            ...
            a = _py_backwards_merge_dicts(
                [dict({1: 2}), {3: 4}])
            '''))
    # Assert
    assert ast.dump(module, include_attributes=True) == \
        ast.dump(expected, include_attributes=True)
    assert transformer._tree_changed

# Generated at 2022-06-21 17:36:16.230440
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None) is not None

# Generated at 2022-06-21 17:36:17.580910
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass



# Generated at 2022-06-21 17:36:19.593846
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .test_utils import run_test_on_module

    run_test_on_module(DictUnpackingTransformer)

# Generated at 2022-06-21 17:36:27.868514
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from textwrap import dedent

    mod = ast.parse(dedent("""\
        def f(a, b):
            c = d
            return {
                **e,
                1: 2,
                **f,
                3: 4,
                **g,
            }"""))

    assert type(DictUnpackingTransformer().visit(mod)) == ast.Module


# Generated at 2022-06-21 17:36:39.859772
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    from ..tests.test_utils import assert_tree_equal, check_tree_changed
    from ..utils.tree import get_body

    raw_source = """
        {a: b, **c}
        """
    expected_source = """
        _py_backwards_merge_dicts([{'a': b}], c)
        """
    node = ast.parse(raw_source)
    transformed = DictUnpackingTransformer().visit(node)
    assert_tree_equal(expected_source, transformed)
    check_tree_changed(node, transformed, DictUnpackingTransformer)
    get_body(node)[0].body = transformed.body
    assert_tree_equal(raw_source, astunparse.unparse(node))
    print('OK')



# Generated at 2022-06-21 17:36:48.153469
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    src = '''
    d = {1: 2, **{}}
    '''
    expected = '''
    _py_backwards_merge_dicts(dict({1: 2}), dict({}))
    '''
    module = ast.parse(src)
    DictUnpackingTransformer().visit(module)
    assert astor.to_source(module).strip() == expected


# Generated at 2022-06-21 17:36:51.700666
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(None).__class__ is DictUnpackingTransformer


# Generated at 2022-06-21 17:36:55.729858
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """{}"""
    node = ast.parse(code)   

    # Act
    transformed = DictUnpackingTransformer().visit(node)

    # Assert

# Generated at 2022-06-21 17:37:00.947882
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    source = """
        {1: 1, **dict_a}
        """
    expected = """
        _py_backwards_merge_dicts([dict({1: 1})], dict_a)
        """
    result = DictUnpackingTransformer().visit(ast.parse(source))
    assert astor.to_source(result) == expected

# Generated at 2022-06-21 17:37:10.803848
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Arrange
    node = ast.parse('{1: 1, **{2: 2}}')
    expected = ast.parse('''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    {1: 1, **_py_backwards_merge_dicts([{1: 1}], {2: 2})}
    ''')

    # Act
    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)

    # Assert
    assert ast.dump(expected) == ast.dump(result)

# Generated at 2022-06-21 17:37:16.490035
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer

# Generated at 2022-06-21 17:37:20.769518
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse(
        "print(foo)"
    )
    node = module.body[0]
    transformer = DictUnpackingTransformer()
    transformer.visit(node)


# Generated at 2022-06-21 17:37:23.484938
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    d = DictUnpackingTransformer()
    assert isinstance(d, DictUnpackingTransformer)

# Generated at 2022-06-21 17:37:33.793989
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str

    expected = (
        '_py_backwards_merge_dicts([{1: 1}, {2: 2, 3: 3}], None, None, None, '
        '{4: 4, 5: 5})'
    )
    node = ast.parse(
        '{1: 1, **None, **None, 2: 2, 3: 3, **None, 4: 4, 5: 5, **None}').body[0]

    transformer = DictUnpackingTransformer()
    result = transformer.visit(node)

    assert tree_to_str(result) == expected



# Generated at 2022-06-21 17:37:40.685854
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from .transformer import Transformer
    from ..utils.testing import assert_code_equal

    code = '{x: 1, y: 2, **z, **k}'
    expected = """
        _py_backwards_merge_dicts([{x: 1, y: 2}, z, k])
    """
    actual = Transformer(DictUnpackingTransformer).transform_source(code)
    assert_code_equal(expected, actual)

# Generated at 2022-06-21 17:37:49.336306
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from astunparse import unparse
    from .test_base import BaseNodeTransformerTest

    class _(BaseNodeTransformerTest):
        transformer = DictUnpackingTransformer

        def test_inline(self):
            before = '{1: 2, **dict_a}'
            after = '_py_backwards_merge_dicts([{1: 2}], dict_a)'
            self.assertTransformedEquals(before, after)

        def test_dict_with_default_arguments(self):
            before = '{1, 2, **dict_a}'
            after = '_py_backwards_merge_dicts([{1: 2}], dict_a)'
            self.assertTransformedEquals(before, after)

        def test_multiple_keyword_arguments(self):
            before

# Generated at 2022-06-21 17:37:59.571831
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    source_code = """
            x = {1: 2, **dict_a}
            """
    expected_code = """
            def _py_backwards_merge_dicts(dicts):
                result = {}
                for dict_ in dicts:
                    result.update(dict_)
                return result
            
            x = _py_backwards_merge_dicts([{1: 2}], dict_a)
            """
    transformer = DictUnpackingTransformer()
    node = compile(source_code, '<test>', 'exec', ast.PyCF_ONLY_AST)
    result_node = transformer.visit(node)
    result_code = astor.to_source(result_node).strip()

    assert result_code == expected_code


# Generated at 2022-06-21 17:38:01.388479
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse('{}')
    DictUnpackingTransformer().visit(tree)
    expected = ast.parse(merge_dicts.trimmed().rstrip())
    ast.fix_missing_locations(expected)
    assert tree == expected


# Generated at 2022-06-21 17:38:04.304787
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """{1: 1, **{a: b}, 2: 2}"""
    expected = """_py_backwards_merge_dicts([{1: 1}, {2: 2}], {a: b})"""

    node = ast.parse(source)
    new_node = DictUnpackingTransformer().visit(node)  # type: ignore
    assert ast.dump(new_node) == expected

# Generated at 2022-06-21 17:38:10.387532
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Test for case with dict unpacking statement
    try:
        DictUnpackingTransformer()
    except Exception as e:
        print(e)
        assert False
    # Test for case without dict unpacking statement
    try:
        DictUnpackingTransformer()
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-21 17:38:26.022932
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as std_ast
    from mypy_extensions import NoReturn
    from ..utils.snippet import snippet
    from ..utils import assert_equal_ast
    from ..utils.ast_factory import ast_call
    from ..utils.test_utils import assert_unchanged
    from .test_base import BaseNodeTransformerTestCase, skip

    @skip
    def test_simple_unpacking(self):
        @snippet
        def before():
            {'b': 1, **{'a': 2}}
        @snippet
        def after():
            {'b': 1, 'a': 2}

        self._test(before, after)


# Generated at 2022-06-21 17:38:26.896682
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer.target == (3, 4)

# Generated at 2022-06-21 17:38:27.579402
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-21 17:38:36.352335
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import unittest
    import astor

    class Test(unittest.TestCase):
        def test_simple(self):
            src = '{1: 1, **dict_a}'
            expected = '_py_backwards_merge_dicts([{1: 1}], dict_a)'
            result = astor.to_source(DictUnpackingTransformer().visit(
                ast.parse(src)))
            self.assertEqual(result, expected)

        def test_multiple_dicts(self):
            src = '{1: 1, **dict_a, 2: 2, **dict_b}'
            expected = '_py_backwards_merge_dicts([{1: 1}], dict_a, ' \
                       '{2: 2}, dict_b)'
            result = astor

# Generated at 2022-06-21 17:38:39.312674
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    src = """
    a = {1: 1, 2: 2}
    """
    expect = """
    (merge_dicts)
    a = {1: 1, 2: 2}
    """
    output = DictUnpackingTransformer().visit(ast.parse(src))
    assert str(output) == expect



# Generated at 2022-06-21 17:38:46.948477
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import from_code

    out = from_code(source='''
        {1: 2, 3: 4, **{5: 6, 7: 8}, **{9: 10}}
    ''', transformer=DictUnpackingTransformer)
    assert out == '''
        _py_backwards_merge_dicts([{1: 2, 3: 4}], {5: 6, 7: 8}), {9: 10}))
    '''

# Generated at 2022-06-21 17:38:51.676386
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from  ..utils.tree import parse

    assert DictUnpackingTransformer().visit(  # type: ignore
        parse("{1: 1, **dict_a}")) == parse(  # type: ignore
        "_py_backwards_merge_dicts([{1: 1}], dict_a)")

# Generated at 2022-06-21 17:39:01.955375
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    class NoChangeTransformer(BaseNodeTransformer):
        target = (3, 4)

        def visit_Dict(self, node: ast.Dict) -> ast.Dict:
            return ast.Dict(keys=[], values=[])

    module = ast.parse('''\
x = {**a, **b, **c}
y = {1: 2, **b, 2: 4}
z = {**a, **c, 1: 2}''')

    NoChangeTransformer().visit(module)

# Generated at 2022-06-21 17:39:05.793032
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # type: () -> None
    from ..testing import assert_transformation_result

    transformer = DictUnpackingTransformer(None)
    assert isinstance(transformer, DictUnpackingTransformer)

# Generated at 2022-06-21 17:39:09.977530
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer.from_code('''
{1: 1, **{2: 3}, **{3: 4}}
''')
    assert transformer.transformed == '''
_py_backwards_merge_dicts([{1: 1}], {2: 3}, {3: 4})
'''

# Generated at 2022-06-21 17:39:28.078583
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """{1: 1, 2: 2, **dict_a}"""
    expected = """{1: 1, 2: 2, **_py_backwards_merge_dicts(dict_a)}"""
    actual = DictUnpackingTransformer().visit_Dict(ast.parse(code).body[0])
    assert ast.dump(actual) == expected

# Generated at 2022-06-21 17:39:29.095906
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:39:38.942566
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    x = DictUnpackingTransformer()
    tree = ast.parse("{'a': 1, **b, 'c': 2, **d}")
    x.visit(tree)

# Generated at 2022-06-21 17:39:49.772917
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import get_transformed_module
    from .base import get_parsed_module

    test_case = """
    x = {1: 1, 2: 2, **y}
    z = {**dict_a, **dict_b}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    x = _py_backwards_merge_dicts([dict({1: 1, 2: 2}), y])
    z = _py_backwards_merge_dicts([dict_a, dict_b])
    """

# Generated at 2022-06-21 17:39:51.057574
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transpile_file('dict_unpacking_transformer.py')

# Generated at 2022-06-21 17:40:02.082024
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from hypothesis import given, assume, settings
    from hypothesis import strategies as st, example
    from ..utils.tree import assert_code
    from ..utils.source import get_ast

    class_name = 'DictUnpackingTransformer'
    module = get_ast(DictUnpackingTransformer)
    transformer = module[class_name]
    dummy_code = '{1: 1, **d}'

    @given(st.booleans())
    def test_presence_of_function(is_present):
        code = dummy_code
        if is_present:
            code += "\ndef _py_backwards_merge_dicts(dicts): return None"

        new_code = source_to_src(
            transformer.visit(
                ast.parse(code)))

# Generated at 2022-06-21 17:40:05.797570
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """{1: 1, **dict_a}"""

    expected = """_py_backwards_merge_dicts([{1: 1}], dict_a})"""

    result = DictUnpackingTransformer(source).result
    assert expected in result, result

# Generated at 2022-06-21 17:40:06.628269
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-21 17:40:16.266803
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    """Tests visit_Dict() of DictUnpackingTransformer."""
    src = """
        foo = {1: 1, **a, 2: 2}
        bar = foo()
    """
    expected = """
        _py_backwards_merge_dicts([{1: 1}, 2: 2], a)
        foo = _py_backwards_merge_dicts([{1: 1}, 2: 2], a)
        bar = foo()
    """
    transformed = DictUnpackingTransformer().visit(ast.parse(src))
    assert expected == astor.to_source(transformed)



# Generated at 2022-06-21 17:40:20.385336
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    transformer._tree_changed = False
    node = ast.Module([], [])
    expected = ast.Module([merge_dicts.get_body()], [])

    actual = transformer.visit_Module(node)

    assert actual == expected



# Generated at 2022-06-21 17:40:58.112835
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import BaseNodeTransformer
    from ..parser import parse_ast

    code = '''
    def fn(x, y):
        if x:
            res = {**x, 1: 2, **y}
        else:
            res = {1: 2, **y, **x}
        return res
    
    '''

    transformer = DictUnpackingTransformer(None)
    ast_obj = parse_ast(code)
    ast_obj2 = transformer.visit(ast_obj)
    ast_obj3 = BaseNodeTransformer.run_all(ast_obj)

    assert ast_obj != ast_obj2
    assert ast_obj2 == ast_obj3

# Generated at 2022-06-21 17:41:09.093835
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .unpacking import UnpackingTransformer
    from .base import NodeTransformerMixin
    from ..utils.test_utils import transform_compare, transform_compare_tree, DummyTestCase
    from ..utils.test_utils import transform_compare_source as tc
    from ..utils.test_utils import compare_source as c
    from ..utils.test_utils import dump_tree
    from ..utils.test_utils import disable_no_value_for_parameter
    from ..utils.test_utils import disable_untyped_decorator_warning

    before = """
        x = {1: 2, **{}}
        y = {1: 2, **{3: 4}}
        z = {1: 2, **{3: 4}, **{5: 6}, 7: 8}
    """

# Generated at 2022-06-21 17:41:20.088493
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    transformer = DictUnpackingTransformer()

    module_node = ast3.parse("""
a = {**{**{}, 'a': 1}, 'b': 2}
    """)

    module_node = transformer.visit(module_node)

    assert transformer._tree_changed == True

# Generated at 2022-06-21 17:41:26.346965
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    source = """
        a = 'aaa'
        b = 'bbb'
        c = 'ccc'
        d = 'ddd'
        e = {1: a, 3: b, **c, **{2: 3, 4: d}}
    """
    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result


        a = 'aaa'
        b = 'bbb'
        c = 'ccc'
        d = 'ddd'
        e = _py_backwards_merge_dicts([{1: a, 3: b}, dict(c), dict(2=3, 4=d)])
    """
    t = D

# Generated at 2022-06-21 17:41:38.307620
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1, **dict_a}')
    assert str(module) == "Module(body=[Dict(keys=[Num(n=1)], values=[Num(n=1)])])"
    transformer = DictUnpackingTransformer()
    module = transformer.visit(module)
    assert str(module) == "Module(\n    body=[\n        Expr(value=Call(\n            func=Name(id='_py_backwards_merge_dicts', ctx=Load()), args=[List(elts=[Dict(keys=[Num(n=1)], values=[Num(n=1)])], ctx=Load())], keywords=[])),\n    ],\n)"

# Generated at 2022-06-21 17:41:50.268862
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node = ast.Dict(
        keys=[None, ast.Str(s='a'), None],
        values=[ast.Dict(keys=[None, ast.Str(s='b')], values=[
            ast.Dict(keys=[None], values=[ast.Dict(keys=[], values=[])]),
            ast.Str(s='c')]),
            ast.Str(s='d'),
            ast.Dict(keys=[None], values=[ast.Dict(keys=[], values=[])])])
    _res = DictUnpackingTransformer().visit(node)  # type: ignore
    assert isinstance(_res, ast.Call)

# Generated at 2022-06-21 17:41:57.551367
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert ast_print(ast.parse('{1: 2}')) == ast_print(
        DictUnpackingTransformer().visit(ast.parse('{1: 2}')))
    assert ast_print(ast.parse('{1: 2, **{"a": "b"}}')) == ast_print(
        DictUnpackingTransformer().visit(ast.parse('{1: 2, **{"a": "b"}}')))

# Generated at 2022-06-21 17:42:07.283185
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.source import source

    source = source(DictUnpackingTransformer, 'src')
    ast_ = ast.parse(source)

    transformed = DictUnpackingTransformer().visit(ast_)

    from ..utils.ast_helper import ast_to_source
    from ..utils.source import source

    expected = source(DictUnpackingTransformer, 'dst')
    assert ast_to_source(transformed) == expected


# Generated at 2022-06-21 17:42:08.212426
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-21 17:42:21.173105
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3
    class ModuleVisitor:
        def __init__(self, assert_equal_to):
            self.assert_equal_to = assert_equal_to
            self.content = None

        def visit_Module(self, node):
            self.content = node.body
            return self.assert_equal_to()
    empty_body = []
    module_visitor = ModuleVisitor(
        assert_equal_to=lambda: ast3.Module(empty_body)
        )

# Generated at 2022-06-21 17:43:26.888528
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer(): # type: ignore
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)



# Generated at 2022-06-21 17:43:34.492258
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    x = ast.Module(body=[])
    dct = ast.Dict(keys=[None], values=['y'])
    z = ast.Dict(keys=['z'], values=['z'])

# Generated at 2022-06-21 17:43:45.476898
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from pytypeutils import utils as ptu
    from collections import OrderedDict

    source = """
y = b
x = 2
a = 3

d = {a: 1, x: 2, **z}
"""
    expected = """
y = b
x = 2
a = 3

d = _py_backwards_merge_dicts([{a: 1, x: 2}], z)
"""

    tree = ptu.parse(source)
    assert tree.body
    assert tree.body[-1].value
    assert isinstance(tree.body[-1].value, ast.Dict)

    DictUnpackingTransformer().visit(tree)

    ast.fix_missing_locations(tree)

# Generated at 2022-06-21 17:43:46.905543
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None

# Generated at 2022-06-21 17:43:47.916359
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    return DictUnpackingTransformer()

# Generated at 2022-06-21 17:43:50.009101
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:43:58.535795
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    transformer = DictUnpackingTransformer()

    node = ast.Dict(
        keys=[None, ast.Str(s='b')],
        values=[ast.Num(n=1), ast.Num(n=2)],
    )
    expected = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[
            ast.Call(
                func=ast.Name(id='dict'),
                args=[ast.Num(n=1)],
                keywords=[]
            ),
            ast.Dict(
                keys=[ast.Str(s='b')],
                values=[ast.Num(n=2)],
            ),
        ])],
        keywords=[]
    )

    actual = transformer.visit(node)

   

# Generated at 2022-06-21 17:44:02.970182
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    input = """
        {1: 1, 2: a, 3: b, **c}
    """
    expected_output = """
        _py_backwards_merge_dicts([{1: 1, 2: a, 3: b}], c)
    """

    assert run_as_module(input) == run_as_module(expected_output)

# Generated at 2022-06-21 17:44:11.971116
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    module = ast.parse('import pickle', mode='eval')
    module_ = transformer.visit(module)
    expected_module_ = ast.parse('import pickle\nfrom pprint import pprint\n'
                                 'from typing import Any, Dict\n\n\n'
                                 'def _py_backwards_merge_dicts(dicts):\n'
                                 '    result = {}\n'
                                 '    for dict_ in dicts:\n'
                                 '        result.update(dict_)\n'
                                 '    return result', mode='eval')
    assert module_ == expected_module_


# Generated at 2022-06-21 17:44:22.189269
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
