

# Generated at 2022-06-21 17:35:17.947460
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # type: () -> None
    insert_at(0, merge_dicts.get_body())
    assert merge_dicts.get_body() == merge_dicts.snippet
    assert merge_dicts.get_body() in merge_dicts.snippet



# Generated at 2022-06-21 17:35:19.836562
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer.__name__ == 'DictUnpackingTransformer'

# Generated at 2022-06-21 17:35:29.650161
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_helpers import assert_equal_source

    from ..utils.source import Source

    source = Source("""
    def my_func(a, b, c):
        return {1: 2, **a, 3: 4, **b, 5: 6, **c}
    """)

    expected = Source("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result


    def my_func(a, b, c):
        return _py_backwards_merge_dicts([{1: 2, 3: 4, 5: 6}], a, b, c)
    """)

    transformer = DictUnpackingTransformer()

# Generated at 2022-06-21 17:35:30.361479
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-21 17:35:41.905002
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from . import test_utils

    # Setup
    dict_a = ast.Name(id='dict_a')
    dict_b = ast.Name(id='dict_b')
    dict_c = ast.Name(id='dict_c')
    dict_d = ast.Name(id='dict_d')

    with_unpacking = ast.Dict(
        keys=[ast.Num(1), None, ast.Num(2), None, ast.Num(3)],
        values=[ast.Num(10), dict_a, ast.Num(20), dict_b, dict_c])


# Generated at 2022-06-21 17:35:52.760189
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = """
    x = {1: 1, 2: 2, **dict_a}
    y = {**dict_b, **dict_c, **dict_d, **dict_e}
    z = {**dict_f, 2: 2, 1: 1}
    """
    expected = """
    x = _py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)
    y = _py_backwards_merge_dicts([{}], dict_b, dict_c, dict_d, dict_e)
    z = _py_backwards_merge_dicts([{2: 2, 1: 1}], dict_f)
    """
    assert expected == transform(src, [DictUnpackingTransformer])

# Generated at 2022-06-21 17:35:57.544283
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    actual = ast.parse("{1: 1, 2: 2, **dict_a, 3: 3}")
    expected = ast.parse("""\
{
    _py_backwards_merge_dicts(
        [dict({: 1, 2: 2}), dict_a],
        dict({: 3})
    )
}""")
    actual = DictUnpackingTransformer().visit(actual)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-21 17:36:02.680662
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing.modify_testcase import ModifyTestCase
    testcase = ModifyTestCase('{a: 1, **b, c: 2}')
    testcase.assert_output_lines('_py_backwards_merge_dicts([{a: 1}, {c: 2}], b)')

# Generated at 2022-06-21 17:36:12.534021
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert "def _py_backwards_merge_dicts(dicts):" in merge_dicts.get_body()

    source = """
    {1: 2, **{3: 4}}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([{1: 2}], {3: 4})
    """
    tree = ast.parse(source)
    transform = DictUnpackingTransformer()
    new_tree = transform.visit(tree)
    assert ast.dump(new_tree) == expected

    source = """
    {**{1: 2}}
    """

# Generated at 2022-06-21 17:36:13.912865
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:36:24.470906
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer.visit(
        ast.parse('a = {1: 1, **a}', mode='eval')), ast.Expression)

# Generated at 2022-06-21 17:36:29.390106
# Unit test for method visit_Module of class DictUnpackingTransformer

# Generated at 2022-06-21 17:36:39.581686
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    # type: () -> None
    tree = ast.parse('{a: 1, **c, **b, d: 2}')
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert transformer.changed
    assert transformer.tree_changed
    assert ast.dump(tree) == textwrap.dedent('''\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{'a': 1, 'd': 2}], c, b)''')

# Generated at 2022-06-21 17:36:51.655983
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    mod = ast.parse('{**dict_1}')
    transformer = DictUnpackingTransformer()
    new_mod = transformer.visit(mod)  # type: ignore
    expected = ast.Module(body=[
        merge_dicts.get_ast(),  # type: ignore
        ast.Expr(value=ast.Call(
            func=ast.Name(id='_py_backwards_merge_dicts'),
            args=[ast.List(elts=[
                ast.Call(func=ast.Name(id='dict'), args=[], keywords=[]),
                ast.Name(id='dict_1')
            ])],
            keywords=[]))
    ])
    assert ast.dump(new_mod) == ast.dump(expected)



# Generated at 2022-06-21 17:36:54.548299
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer is not None
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:36:58.796929
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor  # type: ignore
    from ..utils.tree import find, find_all
    from ..utils.ast_helpers import get_code

    # Arrange

# Generated at 2022-06-21 17:37:11.473416
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1, **dict_a}')
    assert ast.dump(module, include_attributes=False) == (
        "Module(body=[Dict(keys=[Constant(value=1, kind=None), None], values="
        "[Constant(value=1, kind=None), Name(id='dict_a', ctx=Load())])])"
    )

    transformer = DictUnpackingTransformer()
    module = transformer.visit(module)

# Generated at 2022-06-21 17:37:23.509836
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from copy import deepcopy
    from typed_ast import ast3 as ast

    snippet = """{1: 1, **a, 2: 2}"""
    parser = ast.parse(snippet)
    node = parser.body[0].value
    new_node = DictUnpackingTransformer().visit(deepcopy(node))  # type: ignore
    expected_node = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[
            ast.List(elts=[ast.Dict(
                keys=[ast.Num(n=1), ast.Num(n=2)],
                values=[ast.Num(n=1), ast.Num(n=2)])]),
            ast.Name(id='a')
        ],
        keywords=[],
    )


# Generated at 2022-06-21 17:37:33.648823
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    expected = ast.Module(
        body=[
            merge_dicts.get_body(),
            ast.Expr(value=ast.Call(
                func=ast.Name(id='print'),
                args=[ast.List(elts=[ast.Num(1),
                                     ast.Num(2),
                                     ast.Num(3)])],
                keywords=[])),
            ast.Expr(value=ast.Call(
                func=ast.Name(id='print'),
                args=[ast.List(elts=[ast.Num(2),
                                     ast.Num(3),
                                     ast.Num(4)])],
                keywords=[]))
        ])

    result = ast.parse(
        """
        print({1, 2, 3})
        print([2, 3, 4])
        """)

    transformer

# Generated at 2022-06-21 17:37:44.343212
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """

x = 5
{3: 7, **{a: b, **c}, **d, 1: 2}
{3: 7, **{a: b, **c}, **d, **e, 1: 2}

"""
    expected = """

x = 5
_py_backwards_merge_dicts([{1: 2, 3: 7}], {a: b, **c}, d)
_py_backwards_merge_dicts([{1: 2, 3: 7}], {a: b, **c}, d, e)

"""
    import typed_astunparse
    mod = typed_ast.ast3.parse(source)  # type: ignore
    transformed = DictUnpackingTransformer().visit(mod)  # type: ignore
    assert typed_astunparse.dump

# Generated at 2022-06-21 17:37:59.846884
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_equal_AST

    node = ast.parse("""{None: x, 1: 2, 3: 4, None: y}""")
    expected = ast.parse("""_py_backwards_merge_dicts([{1: 2, 3: 4}], y)""")
    assert_equal_AST(node, expected, DictUnpackingTransformer)



# Generated at 2022-06-21 17:38:02.718331
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor

    module_src = """{1: 1, 2: 2, **dict_a, 3: 3}"""
    module_expected = """_py_backwards_merge_dicts(((1, 1), (2, 2), dict_a, 3))"""
    module = ast.parse(module_src)
    DictUnpackingTransformer().visit(module)
    assert astor.to_source(module).strip() == module_expected



# Generated at 2022-06-21 17:38:14.683760
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .conftest import assert_transformed, assert_not_transformed

    assert_transformed(
        DictUnpackingTransformer,
        """
        a = {1: 1, **b}
        """,
        """
        _py_backwards_merge_dicts([{1: 1}], b)
        """,
        """
        a = _py_backwards_merge_dicts([{1: 1}], b)
        """)


# Generated at 2022-06-21 17:38:16.363545
# Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:38:25.621201
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer._split_by_None([
        (None, None),
        (None, None),
        (None, None),
    ]) == [None, None, None]

    assert DictUnpackingTransformer._split_by_None([
        (None, None),
        (None, 1),
        (None, 2),
        (None, None),
        (None, None),
    ]) == [None, None, None, 1, 2, None, None]

    assert DictUnpackingTransformer._split_by_None([
        (None, 1),
        (None, 2),
        (None, 3),
        (None, None),
        (None, 4),
        (None, 5),
    ]) == [None, 1, 2, 3, None, None, 4, 5]


# Generated at 2022-06-21 17:38:27.129970
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # type: () -> None
    assert DictUnpackingTransformer.__init__.__annotations__ == {
        'self': DictUnpackingTransformer
    }

# Generated at 2022-06-21 17:38:33.271887
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transpiler = DictUnpackingTransformer()
    module = ast.parse("def f():\n\t{'x': 1, **dict_a, **dict_b}")
    transpiler.visit(module)

# Generated at 2022-06-21 17:38:38.821963
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ..utils.fake_ast import fake_ast_from_source

    source = '{1: 1, **dict_a}'
    module = fake_ast_from_source(source)

    DictUnpackingTransformer().visit(module)
    result = astor.to_source(module)

# Generated at 2022-06-21 17:38:50.056292
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_transformer_support import get_visitor, parse_ast_tree, assert_tree
    visitor = get_visitor(DictUnpackingTransformer)
    tree = parse_ast_tree('''{1: 1, **{'a': 0}, 2: 2, **{'b': 0}, 3: 3}''')
    result = tree.body[0].value  # type: ast.Expr
    expected = parse_ast_tree('''
_py_backwards_merge_dicts([None], {'a': 0}))
    ''')
    visitor.visit(result)
    assert_tree(result.value, expected.body[0].value)



# Generated at 2022-06-21 17:39:00.637815
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()
    assert t.visit(ast.parse("{1: 1}")) == ast.parse("{1: 1}")
    assert t.visit(ast.parse("{1: 1, *{2: 2}}")) == ast.parse("_py_backwards_merge_dicts(dict(1=1), {2: 2})")  # noqa
    assert t.visit(ast.parse("{1: 1, 2: 2, *{3: 3}}")) == ast.parse("_py_backwards_merge_dicts([{1: 1, 2: 2}], {3: 3})")  # noqa

# Generated at 2022-06-21 17:39:56.004067
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = [
        ast.Dict(keys=[ast.Name(id='a'), None, ast.Name(id='b'), ast.Name(id='c')],
                 values=[ast.Num(1),
                         ast.Dict(keys=None, values=[ast.Num(2)]),
                         ast.Num(3),
                         ast.Num(4)]),
        ast.Dict(keys=[None],
                 values=[ast.Dict(keys=[ast.Name(id='a'), None],
                                  values=[ast.Num(1),
                                          ast.Dict(keys=None, values=[ast.Num(2)])])])
    ]

# Generated at 2022-06-21 17:40:04.298819
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected = ast.parse("""
        import sys
        __all__ = ['_py_backwards_merge_dicts']

        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
    """)

    # Actual
    actual = DictUnpackingTransformer.run_py2(ast.parse("""
        import sys
    """))

    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-21 17:40:09.944746
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    node = ast.parse('{1:1, **{"a": 1}}')
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == '\n'.join([
        "def _py_backwards_merge_dicts(dicts):",
        "    result = {}",
        "    for dict_ in dicts:",
        "        result.update(dict_)",
        "    return result",
        "",
        "_py_backwards_merge_dicts([{1: 1}, {'a': 1}])",
        ""
    ])

# Generated at 2022-06-21 17:40:14.282951
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("""{1: 1, **dict_a}""")
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit_Module(tree)
    assert transformer._tree_changed

# Generated at 2022-06-21 17:40:22.380678
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from astunparse import unparse
    from . import fix_missing_locations

    # Check that function definition is added to the module.

    module = ast.parse('''{1: 2}''', mode='eval')
    fix_missing_locations(module)
    module = DictUnpackingTransformer().visit(module)
    assert unparse(module) == '''def _py_backwards_merge_dicts(dicts):
    result = {}
    for dict_ in dicts:
        result.update(dict_)
    return result

dict({1: 2})'''


# Generated at 2022-06-21 17:40:34.064086
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.test_utils import assert_equal_source
    from ..utils.source_repr import source_repr

    DictUnpackingTransformer()  # type: ignore

    assert_equal_source(
        DictUnpackingTransformer().visit(source_repr("""
            {1: 2, **{3: 4}, 5: 6, **{6: 5, 7: 8}, None: None}
        """)),
        source_repr("""
            _py_backwards_merge_dicts([{1: 2}, {3: 4}, {5: 6}, {7: 8}],
                                      {6: 5})
        """)
    )


# Generated at 2022-06-21 17:40:41.781349
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
        {1: 2, 9: 1, **{3: 9, 5: 6}}
    """
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    _py_backwards_merge_dicts([dict([(1, 2), (9, 1)]), dict([(3, 9), (5, 6)])])
    """
    from typed_ast import ast3 as ast
    from ..trees import Module
    from .utils import assert_backtransformed

    module = Module(ast.parse(source))
    DictUnpackingTransformer().visit_Module(module)
    assert_backtransformed(module, expected)

# Generated at 2022-06-21 17:40:51.217367
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 1, **{1: 1, **{1: 1}}}')
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-21 17:41:00.145660
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    r"""
    Given:
        {
            1: 1,
            **{a: a},
            **{b: b},
            3: 3,
            4: 4
        }
    Expected:
        _py_backwards_merge_dicts([{1: 1}, {3: 3, 4: 4}], {a: a}, {b: b})
    """
    code = '{1: 1, **{a: a}, **{b: b}, 3: 3, 4: 4}'
    root = ast.parse(code)
    DictUnpackingTransformer().visit(root)
    expected = """_py_backwards_merge_dicts([{1: 1, 3: 3, 4: 4}, {a: a}, {b: b}])"""

# Generated at 2022-06-21 17:41:09.916153
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import BaseTestTransformer
    from ..utils import simplify_ast

    class Test(BaseTestTransformer):
        transformer = DictUnpackingTransformer
        function_name = '_py_backwards_merge_dicts'

        @property
        def target(self) -> int:
            return (3, 4)

        def _test(self, before: ast.AST, after: ast.AST) -> None:
            before = simplify_ast(before)
            after = simplify_ast(after)
            self.assertEqual(before, after)

    Test('''\
        {1: 1}
    ''').test('''\
        {1: 1}
    ''')

# Generated at 2022-06-21 17:41:37.654103
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    node = ast.parse('{1: 1, 2: 2, **a, **b, 3: 3}')
    result = DictUnpackingTransformer().visit(node)

    assert ast.dump(result) == ast.dump(ast.parse('''
        _py_backwards_merge_dicts([dict(a), dict(b), {1: 1, 2: 2, 3: 3}])
    '''))



# Generated at 2022-06-21 17:41:46.733091
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_astunparse, astor
    from ..utils.test_node_transformer import TestNodeTransformer
    from ..utils.test_utils import T

    def check(python_code: str):
        test_node_transformer = TestNodeTransformer(
            python_code,
            [DictUnpackingTransformer],
            expected_change='add_module_imports')
        test_node_transformer.verify()


# Generated at 2022-06-21 17:41:59.414524
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    tr_ = DictUnpackingTransformer

    # Check that call of _py_backwards_merge_dicts is created for simple case
    test_pairs = zip([ast.Num(n=1), ast.Num(n=2), None, ast.Num(n=3)],
                     [ast.Num(n=1), ast.Num(n=2), ast.Num(n=3), ast.Num(n=1)])
    splitted = tr_._split_by_None(test_pairs)
    prepared = tr_._prepare_splitted(splitted)
    assert isinstance(tr_._merge_dicts(prepared), ast.Call)

    # Check that we do nothing for complicated case

# Generated at 2022-06-21 17:42:09.743330
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # import ast
    # import astor
    # import sys
    try:
        ast.Dict
    except AttributeError:
        return
    t = DictUnpackingTransformer()
    tree = ast.parse(
            '{\n'
            '1: 1,\n'
            '**dict_a,\n'
            '2: 3,\n'
            '**dict_b,\n'
            '**dict_c,\n'
            '*args,\n'
            '3: 5,\n'
            '**dict_d}')

    t.visit(tree)
    # print(astor.to_source(tree))
    # print(astor.dump(tree))


# Line Comments

# Generated at 2022-06-21 17:42:21.495997
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typing import cast

    from typed_ast import ast3 as ast

    from .base import BaseNodeTransformerTestCase


    class Test(BaseNodeTransformerTestCase):
        TRANSFORMER = DictUnpackingTransformer
        PARSE = ast.parse

        def test_merges_dicts_with_unpacking(self):
            source = """
            {1: 1, **{"2": 2}}
            """
            self.assert_transformed(
                source,
                """
            _py_backwards_merge_dicts([{1: 1}], {"2": 2})
            """)

        def test_merges_dicts_with_multiple_unpacking(self):
            source = """
            {1: 1, **{"2": 2}, 3: 3, **{"4": 4}}
            """
            self

# Generated at 2022-06-21 17:42:23.474887
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transform = DictUnpackingTransformer()
    assert transform is not None

# Generated at 2022-06-21 17:42:27.622328
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
{1: 1, **dict_a}
"""
    tree = ast.parse(source)
    DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 17:42:30.802443
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    try:
        assert transformer.target == (3, 4)
        assert transformer.visit_Dict
    except AssertionError:
        print('ERROR: DictUnpackingTransformer')
        return False
    return True

# Generated at 2022-06-21 17:42:39.709764
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = """{1: 2, **{3: 4}, 5: 6, **{7: 8}}"""
    node = ast.parse(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(node)

    expected = """
_py_backwards_merge_dicts(
    [{1: 2}, {5: 6}],
    {3: 4},
    {7: 8}
)"""
    assert expected.strip() == ast.dump(node.body[0].value).strip()



# Generated at 2022-06-21 17:42:51.698015
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..transform import Transformation
    from ..ast_utils import dump
    from textwrap import dedent

    transformer = Transformation(
        (3, 4),
        DictUnpackingTransformer
    )

    def assert_transform(s_in: str, s_out: str) -> None:
        t_in = ast.parse(dedent(s_in))
        t_out = ast.parse(dedent(s_out))
        transformer.visit(t_in)
        assert dump(t_in) == dump(t_out)

    assert_transform(
        '''
        {1: 1, 2: None}
        ''',
        '''
        {1: 1, 2: None}
        '''
    )

# Generated at 2022-06-21 17:43:41.953357
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ast import literal_eval
    from textwrap import dedent

    expr = """{1: 1, **{2: 2, 3: 3}, 4: 4}"""
    expect = """{1: 1, 2: 2, 3: 3, 4: 4}"""
    ret = literal_eval(expr)
    assert ret == literal_eval(expect)

    code = dedent(f"""
    def f():
        return {expr}
    """)
    node = ast.parse(code)
    node = DictUnpackingTransformer().visit(node)
    ret = compile(node, '', 'exec')
    
    glob = {}
    loc = {}
    exec(ret, glob, loc)

    assert loc['f']() == literal_eval(expect)

# Generated at 2022-06-21 17:43:43.378421
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-21 17:43:54.992621
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .. import TransformerError, compile_
    from ..utils import transformations
    from ..utils.tree import dump
    from .base import BaseNodeTransformerTest

    class TestDictUnpackingTransformer(BaseNodeTransformerTest):
        transformer = DictUnpackingTransformer

        @staticmethod
        def transform(code: str, **kwargs) -> str:
            return compile_(code, DictUnpackingTransformer, **kwargs)

    # Should work on dictionary with no unpacking.
    assert dump(
        transformations.transform(ast.parse('{10: 20}'), TestDictUnpackingTransformer)) == dump({10: 20})

    # Should work on dictionary with unpacking.

# Generated at 2022-06-21 17:44:02.654440
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    transformer = DictUnpackingTransformer()
    assert transformer.visit(ast.parse('{1: 1, **dict_a}')) == \
        ast.parse(
            'def _py_backwards_merge_dicts(dicts):\n'
            '    result = {}\n'
            '    for dict_ in dicts:\n'
            '        result.update(dict_)\n'
            '    return result\n'
            '\n'
            '_py_backwards_merge_dicts([{1: 1}], dict_a)')

# Generated at 2022-06-21 17:44:10.766252
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    input = """
    {1: 2, **{3: 4}}
    """
    output = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 2}, {3: 4}])
    """
    tree = ast.parse(input)
    DictUnpackingTransformer().visit(tree)
    assert astunparse.unparse(tree) == output.lstrip()



# Generated at 2022-06-21 17:44:18.532511
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.base import ParsedNode
    from astunparse import unparse

    parsed = ParsedNode.parse('''{1: 1, **dict_a, 2: 2}''')
    assert isinstance(parsed.body[0].value, ast.Dict)

    transpiled = DictUnpackingTransformer().visit(parsed)
    assert unparse(transpiled) == '''\
_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)'''


# Generated at 2022-06-21 17:44:21.489722
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse(merge_dicts())
    transformer = DictUnpackingTransformer()
    res = transformer.visit(module)

    assert ast.dump(res) == ast.dump(module)

# Generated at 2022-06-21 17:44:31.682665
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    assert transform({1: 1, 2: 2, **{'a': 3, 'b': 4}}) == {'a': 3, 'b': 4, 1: 1, 2: 2}
    assert transform({'a': 1, **{'b': 2, 'c': 3}, **{'d': 4}}) == {'d': 4, 'a': 1, 'b': 2, 'c': 3}
    assert transform({1: 1, **{'b': 2, **{'c': 3}}, **{'d': 4}}) == {'d': 4, 'b': 2, 1: 1, 'c': 3}
    assert transform({1: 1, **{'b': 2}, 3: 3, **{'d': 4}}) == {'d': 4, 'b': 2, 1: 1, 3: 3}


# Generated at 2022-06-21 17:44:37.614743
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    assert t.visit(ast.parse('a')) == ast.parse('import _py_backwards_merge_dicts as _py_backwards_merge_dicts\na'
)


# Generated at 2022-06-21 17:44:47.841662
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from tests.utils import parse, round_trip

    tree = parse('{1: 1, **{"a": 1, "b": 2}}')
    print(ast.dump(tree))

    DictUnpackingTransformer().visit(tree)
    print(ast.dump(tree))

    tree = round_trip(tree)
    print(ast.dump(tree))
