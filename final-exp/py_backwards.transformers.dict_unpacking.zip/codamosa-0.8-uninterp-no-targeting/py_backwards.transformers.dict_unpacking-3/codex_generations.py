

# Generated at 2022-06-21 17:35:13.982970
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    from .helpers import make_module

    @make_module
    def test():
        def test():
            return {1: 1, **{1: 1}, 2: 2, **{2: 2}}

    assert test() == {1: 1, 1: 1, 2: 2, 2: 2}

# Generated at 2022-06-21 17:35:23.549578
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    instance = DictUnpackingTransformer()
    simple_dict = ast.Dict(keys=[ast.Num(1), ast.Num(2)],
                           values=[ast.Num(1), ast.Num(2)])

    assert isinstance(instance.visit(simple_dict), ast.Dict)

    dict_with_unpacking = ast.Dict(keys=[ast.Num(1), None, ast.Num(2)],
                                   values=[ast.Num(1), ast.Name(id='a'),
                                           ast.Num(2)])


# Generated at 2022-06-21 17:35:27.980683
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal
    from ..utils.tree import parse
    
    a = '''def func():
    {1: 2, **b}
    '''
    
    b = '''def func():
    _py_backwards_merge_dicts([{1: 2}], b)
    '''
    
    assert_equal(b, DictUnpackingTransformer.run(a))


# Generated at 2022-06-21 17:35:41.135881
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import assert_end_to_end
    ft = DictUnpackingTransformer(target=(3, 4))

# Generated at 2022-06-21 17:35:52.690391
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .helpers import _source_to_ast, _ast_to_source

    source = '{a: 1, b: 2, **c, d: 3, **e}'
    expected = (
        '_py_backwards_merge_dicts([{a: 1, b: 2, d: 3}], c, e)')

    ast_ = _source_to_ast(source)
    assert isinstance(ast_, ast.Module)
    assert len(ast_.body) == 1
    assert isinstance(ast_.body[0], ast.Expr)
    expr = ast_.body[0].value
    assert isinstance(expr, ast.Dict)
    assert len(expr.keys) == 4
    assert isinstance(expr.keys[0], ast.Name)
    assert expr.keys[0].id

# Generated at 2022-06-21 17:35:54.357927
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert isinstance(transformer, DictUnpackingTransformer)


# Generated at 2022-06-21 17:35:55.181092
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:36:01.818738
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    test_code_1 = ast.parse('{1: 1, **dict_a}')
    test_exp_1 = ast.parse(
        '''\
_py_backwards_merge_dicts([{1: 1}], dict_a)'''
    )

    test_code_2 = ast.parse('{1: 1, **dict_a, **dict_b, 2: 2}')
    test_exp_2 = ast.parse(
        '''\
_py_backwards_merge_dicts([{1: 1}, dict_a, {2: 2}], dict_b)'''
    )

    t = DictUnpackingTransformer()
    assert t.visit(test_code_1) == test_exp_1

# Generated at 2022-06-21 17:36:09.808448
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    source = """
        {},""".strip()

    expected = """
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        {},""".strip()

    result = DictUnpackingTransformer().visit(ast.parse(source))
    text = astor.to_source(result)
    assert text == expected


# Generated at 2022-06-21 17:36:18.113948
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import convert

    code = '''
    {1: 2, **a, **b}
    '''
    expected = '''
    _py_backwards_merge_dicts(
        [{1: 2}],
        a,
        b
    )
    '''
    tree = convert(code)
    DictUnpackingTransformer().visit(tree)
    assert str(tree) == expected

# Generated at 2022-06-21 17:36:31.283923
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..builder import build

    tree = b"""
    {1: 1, **dict_a}
    """
    expected = b"""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    _py_backwards_merge_dicts([{1: 1}], dict_a)
    """
    node = build(tree)
    result = DictUnpackingTransformer().visit(node)
    assert expected == astunparse.unparse(result)

# Generated at 2022-06-21 17:36:32.730789
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-21 17:36:38.572534
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import Source
    from ..utils.ast_builder import ast_from
    from ..utils.compare import compare_asts

    source = Source("""
    {1: 1, 2: 2}
    """)
    expected = Source("""
    {1: 1, 2: 2}
    """)

    actual = ast_from(source.read(), DictUnpackingTransformer)
    compare_asts(expected, actual)



# Generated at 2022-06-21 17:36:51.320014
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as _ast3

    def _transformer_result(source_ast):
        transformer = DictUnpackingTransformer()
        return transformer.visit(source_ast)

    # TODO: generate all cases automatically

# Generated at 2022-06-21 17:37:02.122317
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..compile import compile_snippet
    from ast import dump
    from itertools import chain

    class Dict(dict):
        def __hash__(self):
            return 0

    keys = chain(range(10), [Dict()])
    values = chain(range(10), [Dict()])
    pairs = zip(keys, values)
    assert len(list(pairs)) == 10

    tree = compile_snippet('{1: 1, **dict_a}', '<test>', 'exec')

# Generated at 2022-06-21 17:37:12.585092
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from .transformers import DictUnpackingTransformer as DUT

    code = '''
        {1: 2, 3: 4, **{5:6, 7:8}}
    '''

    t = ast3.parse(code)
    assert isinstance(t, ast3.Module)
    t = DUT().visit(t)

    assert '_py_backwards_merge_dicts' in t.body[0].value.id
    assert isinstance(t.body[1], ast3.Expr)
    assert isinstance(t.body[1].value, ast3.Call)
    assert t.body[1].value.func.id == '_py_backwards_merge_dicts'
    args = t.body[1].value.args
    assert len

# Generated at 2022-06-21 17:37:23.589128
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = dedent('''
        {
            'a': 1, 
            **{
                'a': 2, 
                'b': 2,
            },
            'c': 3, 
            **{
                'd': 4, 
                'e': 5,
            },
            'f': 6, 
        }
    ''')
    expected_code = dedent('''
        _py_backwards_merge_dicts([{
            'a': 1,
            'c': 3,
            'f': 6,
        }, {
            'a': 2,
            'b': 2,
        }, {
            'd': 4,
            'e': 5,
        }])
    ''')
    node = ast.parse(code)
    DictUnpackingTransformer().vis

# Generated at 2022-06-21 17:37:34.857981
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .._unparser import Unparser
    from ..utils.tree import parse
    from ..utils.testutils import stringify
    from ..utils.compat import StringIO

# Generated at 2022-06-21 17:37:44.389000
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import transform
    from .values import ValueInliner
    ast_tree = transform({'a': 1, **{'b': 2}}, [DictUnpackingTransformer, ValueInliner])
    assert ast.dump(ast_tree) == \
        "Module(body=[Dict(keys=[Str(s='a')], values=[Num(n=1)]), " \
        "Call(func=Name(id='_py_backwards_merge_dicts', ctx=Load()), " \
        "args=[List(elts=[Dict(keys=[Str(s='b')], values=[Num(n=2)])])], " \
        "keywords=[])])"



# Generated at 2022-06-21 17:37:45.873529
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:37:56.124102
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.test_utils import transform_and_cmp
    code_org = """{1: 1, **{2: 2, **{3: 3}}}"""

    code_ref = """_py_backwards_merge_dicts([{1: 1}], dict({2: 2}), dict({3: 3}))"""

    transform_and_cmp(DictUnpackingTransformer, code_org, code_ref)



# Generated at 2022-06-21 17:37:57.392751
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert merge_dicts.get_result() == \
        DictUnpackingTransformer.visit_Module(None, merge_dicts.get_tree())


# Generated at 2022-06-21 17:37:57.970744
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:04.418937
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from c3 import DictUnpackingTransformer
    module = ast.parse('{1: 1, **dict_a}')
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-21 17:38:08.954110
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..testing import assert_module_equal

    module = ast.parse('{1: 2, **D}')
    module = DictUnpackingTransformer().visit(module)

# Generated at 2022-06-21 17:38:10.758496
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:38:14.888313
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = '''\
{1:1, **{2:2}}
'''
    expected = '''\
_py_backwards_merge_dicts([{1: 1}], {2: 2})
'''
    result = source.translate(DictUnpackingTransformer())
    assert result == expected

# Generated at 2022-06-21 17:38:16.796999
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().target == (3, 4)


# Generated at 2022-06-21 17:38:17.842157
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()



# Generated at 2022-06-21 17:38:26.393802
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.testing import assert_node_unchanged

    pairs = {1: 10, 2: 20, None: ast.Dict(keys=[], values=[]), 3: 30}
    node = ast.Dict(keys=list(pairs.keys()), values=list(pairs.values()))
    assert_node_unchanged(node, DictUnpackingTransformer)


# Generated at 2022-06-21 17:38:33.788520
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()


# Generated at 2022-06-21 17:38:36.780024
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    i = DictUnpackingTransformer({"foo": "bar"})
    assert i.tree_changed == False


transformer = DictUnpackingTransformer

# Generated at 2022-06-21 17:38:48.896451
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ...tests import case

    for v in range(3, 6):
        module = ast.parse(
            """
            a = {1: 2, **dict()}
            b = {1: 2, **None, 3: 4}
            c = {1: 2, **None, 3: 4, **dict()}
            d = {1: 2, **{}}
            e = {1: 2, **None, 3: 4, **{}}
            """)

# Generated at 2022-06-21 17:38:50.108119
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:39:00.738281
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    code = '''
    assert {1: 2, **{}} == {1: 2}
    assert {**{}, **{1: 2}} == {1: 2}
    assert {1: 2, **{}, 3: 4} == {1: 2, 3: 4}
    assert {1: 2, **{}, 3: 4, **{5: 6}} == {1: 2, 3: 4, 5: 6}
    assert {1: 2, **{}, 3: 4, **{5: 6}, **{}} == {1: 2, 3: 4, 5: 6}
    '''
    node = ast.parse(code)
    result = DictUnpackingTransformer().visit(node)
    code = compile(result, '', mode='exec')
    exec(code)



# Generated at 2022-06-21 17:39:10.958701
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..utils.tree import dump

    node = ast.Dict(keys=[ast.Num(n=1), ast.Num(n=2), None],
                    values=[ast.Num(n=1), ast.Num(n=2), ast.Dict(keys=[], values=[])])
    expected_node = ast.Call(
        func=ast.Name(id='_py_backwards_merge_dicts'),
        args=[ast.List(elts=[ast.Dict(keys=[ast.Num(n=1), ast.Num(n=2)],
                                      values=[ast.Num(n=1), ast.Num(n=2)]),
                             ast.Dict(keys=[], values=[])])],
        keywords=[])

# Generated at 2022-06-21 17:39:16.233188
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    # Given
    node = ast.parse("""
    # python-dex: disable
    {
    }
    """, '<test>', mode='eval')
    # When
    Transform = DictUnpackingTransformer()
    output = Transform(node)

    # Then
    assert output is node
    assert merge_dicts.get_body() == [n.body[0] for n in output.body]



# Generated at 2022-06-21 17:39:28.000984
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astor
    from ast import parse
    from ..utils.fixtures import tree_for_transformer_test

    @tree_for_transformer_test('DictUnpackingTransformer')
    def get_tree():
        return parse("""
        {1: 1, **{2: 2}, 3: 3, **{4: 4}}
        """)

    def get_expected_tree():
        return parse("""
        _py_backwards_merge_dicts([{1: 1, 3: 3}], {2: 2}, {4: 4})
        """)

    from ..utils.tests import transform_for_transformer_test
    tree = transform_for_transformer_test(get_tree())
    expected_tree = get_expected_tree()
    assert astor.to_source(tree) == astor

# Generated at 2022-06-21 17:39:29.054544
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is not None

# Generated at 2022-06-21 17:39:31.670423
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .test_utils import make_module, assert_equal

    code = """{**dict_, 1: 2}"""

# Generated at 2022-06-21 17:40:06.120594
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    from typed_ast.ast3 import Name
    from ast_utils.visitor import ASTVisitor

    tree = astor.parse(
        """
        def func():
            a = {1: 1}
            b = {2: 2, **a}
            return b
        """)

    visitor = ASTVisitor()
    visitor.register_transformer(DictUnpackingTransformer())
    visitor.visit(tree)
    assert astor.to_source(tree) == \
        """
        def func():
            return _py_backwards_merge_dicts(dict(1=1), dict(2=2))
        """

    # Check that no more name nodes with name `_py_backwards_merge_dicts` are
    # left

# Generated at 2022-06-21 17:40:08.733312
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert issubclass(DictUnpackingTransformer, BaseNodeTransformer)
    assert isinstance(DictUnpackingTransformer((3,3)), BaseNodeTransformer)

# Generated at 2022-06-21 17:40:20.039794
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    ast_module = ast.parse(textwrap.dedent('''
        {  # before: ast.Dict
            1: 1,  # before: (ast.Num, ast.Num)
            None: {"a": 10},  # before: (ast.Name, ast.Dict)
            "b": 20,  # before: (ast.Str, ast.Num)
            None: {"c": 30},  # before: (ast.Name, ast.Dict)
        }
    '''))  # type: ast.Module
    DictUnpackingTransformer().visit(ast_module)
    assert ast_module.body[0].body[0].targets[0].id == '_py_backwards_merge_dicts'
    assert ast_module.body[0].body[0].value.elts

# Generated at 2022-06-21 17:40:21.506519
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer()

# Generated at 2022-06-21 17:40:31.592432
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    class MockModule(ast.AST):
        body = ()

    class MockDict(ast.AST):
        keys = ()
        values = ()

    module = MockModule()
    dict_ = MockDict()
    module.body = [dict_, dict_, dict_]
    transformer = DictUnpackingTransformer()
    result = transformer.visit_Module(module)
    assert result is module
    expected_body = [
        ast.Expr(merge_dicts.get_body()[0]),  # type: ignore
        dict_,
        dict_,
        dict_,
    ]
    assert result.body == expected_body
    assert transformer._tree_changed


# Generated at 2022-06-21 17:40:35.159859
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import astunparse
    # test that constructor of class DictUnpackingTransformer exists
    instance = DictUnpackingTransformer()
    del instance


# Generated at 2022-06-21 17:40:36.665273
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass


# Generated at 2022-06-21 17:40:49.390108
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3
    from compiler.transformer import ChainTransformer
    import ast

    chain_transformer = ChainTransformer(
        [DictUnpackingTransformer(),
         ast.PyTreeTransformer()])

    module = chain_transformer.visit(ast3.parse(
        "{1: 1, 2: 2, **{3: 4, 5: 5}, 6: 6, 7: 7}"))


# Generated at 2022-06-21 17:40:54.266017
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import ast as pyast
    transformer = DictUnpackingTransformer()

    tree = pyast.Module([pyast.Expr(pyast.Dict(keys=[None, pyast.Num(n=33)],
                                               values=[pyast.Dict(keys=[None], values=[pyast.Dict(keys=[], values=[])]),
                                                       pyast.Call(func=pyast.Name(id='dict'), args=[pyast.Dict(keys=[pyast.Name(id='a')], values=[pyast.Num(n=4)])], keywords=[])]))])

# Generated at 2022-06-21 17:41:00.145489
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.testing import string_from_module
    
    module = ast.parse('''{}''')
    DictUnpackingTransformer().visit(module)
    
    expected = \
        '''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        
        {}
        '''
    
    assert string_from_module(module) == expected.lstrip()


# Generated at 2022-06-21 17:41:46.774978
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .test_utils import roundtrip
    source = """
    {1: 1, 2: 2, 3: 3, None: 4, None: 5, **globals()}
    """
    expected = """
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}, 4, 5], globals())
    """
    tree = roundtrip(source, transformer=DictUnpackingTransformer)
    assert str(tree) == expected


# Generated at 2022-06-21 17:41:52.804872
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    dict_unpacking_transformer = DictUnpackingTransformer()
    dict_unpacking_transformer.visit_Module(
        ast.parse("")
    ) == ast.parse(merge_dicts.snippet)



# Generated at 2022-06-21 17:42:00.280022
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.source import source_to_node
    from ..utils.source import node_to_source

    source = """
    {**{'a': 1}, 'b': 2, **{'c': 3}}
    """
    node = source_to_node(source)
    assert isinstance(node, ast.Module)
    t = DictUnpackingTransformer()
    result = t.visit(node)  # type: ignore
    expected = """
    _py_backwards_merge_dicts([{'b': 2}], {'a': 1}, {'c': 3})
    """
    assert node_to_source(result) == expected

# Generated at 2022-06-21 17:42:07.750288
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor

    node = ast.parse('{1, **a}')
    DictUnpackingTransformer().visit(node)
    assert astor.to_source(node) == \
        "def _py_backwards_merge_dicts(dicts):\n" \
        "    result = {}\n" \
        "    for dict_ in dicts:\n" \
        "        result.update(dict_)\n" \
        "    return result\n" \
        "\n" \
        "dict(_py_backwards_merge_dicts([{1: 1}], a))\n"


# Generated at 2022-06-21 17:42:18.114371
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()

    pairs = [(ast.Num(1), ast.Num(1)), None, (None, ast.Num(2))]
    splitted = transformer._split_by_None(pairs)

    assert len(splitted) == 3
    for group in splitted:
        if isinstance(group, list):
            assert len(group) == 1
        else:
            assert isinstance(group, ast.Num)



# Generated at 2022-06-21 17:42:19.070552
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:42:22.965064
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer(None)
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-21 17:42:31.233761
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""
        def f(a, b):
            {1: 1, **a, 2: 2}
        """)
    transformer = DictUnpackingTransformer()
    transformer.visit(module)
    assert transformer._tree_changed is True
    result = ast.fix_missing_locations(module)
    expected = ast.parse("""
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result

    def f(a, b):
        _py_backwards_merge_dicts([{1: 1}, a], {2: 2})
    """)
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-21 17:42:35.680530
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    """
    Constructor for class DictUnpackingTransformer must
    be able to initialize its members to expected values.
    """
    transformer = DictUnpackingTransformer()
    assert transformer._tree_changed

# Generated at 2022-06-21 17:42:43.191112
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    t = DictUnpackingTransformer()

    source = ast.parse("{**a, **b, *args, 2: b, 2: a}")
    expected = ast.parse("_py_backwards_merge_dicts([{2: a}, _py_backwards_merge_dicts([{2: b}, a, b], *args)])")

    t.visit(source)
    assert ast.dump(source) == ast.dump(expected)

    source = ast.parse("{**a, **b, 2: a, 2: b}")
    expected = ast.parse("_py_backwards_merge_dicts([{2: b, 2: a}, a, b])")

    t.visit(source)
    assert ast.dump(source) == ast.dump(expected)

    source

# Generated at 2022-06-21 17:44:09.650464
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()


# Generated at 2022-06-21 17:44:21.136807
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ... import transform
    from ...types import Dict, DictKeys
    
    code = "{1: 1, 2: 2}"
    tree = ast.parse(code)
    node = tree.body[0].value
    assert isinstance(node, ast.Dict)

    result = transform(tree, DictUnpackingTransformer)
    print(result.body)
    result_node = result.body[1].value
    assert isinstance(result_node, ast.Dict)

    code = "{1: 1, **dict_a, **dict_b}"
    tree = ast.parse(code)
    node = tree.body[0].value
    assert isinstance(node, ast.Dict)
    print(node)

    result = transform(tree, DictUnpackingTransformer)

# Generated at 2022-06-21 17:44:29.696506
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse

    parsed = ast.parse("""
        {1: 2, **dict_a, **dict_b, 3: 4, 5: 6, **dict_c}
    """)
    expected = ast.parse("""
        _py_backwards_merge_dicts([{1: 2, None: dict_a, None: dict_b, 3: 4}, {5: 6, None: dict_c}])
    """)

    transformer = DictUnpackingTransformer()
    result = transformer.visit(parsed)

    assert astunparse.unparse(expected) == astunparse.unparse(result)

# Generated at 2022-06-21 17:44:35.295971
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    expected = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    {1: 1, **{2: 2}, **{3: 3}}
    """
    expected = dedent(expected).strip()

    node = ast.parse("{1: 1, **{2: 2}, **{3: 3}}")
    t = DictUnpackingTransformer()
    t.visit(node)
    assert astor.to_source(node).strip() == expected

# Generated at 2022-06-21 17:44:36.313755
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:44:38.912102
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    dut = DictUnpackingTransformer()

    assert isinstance(dut, DictUnpackingTransformer)
    assert isinstance(dut, BaseNodeTransformer)


# Generated at 2022-06-21 17:44:44.683395
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """{1: 1, 2: 2, **{3: 3}, **{4: 4}}"""
    expected = """
injected code
_py_backwards_merge_dicts([{1: 1, 2: 2}, {3: 3}, {4: 4}])
"""
    tree = ast.parse(source)  # type: ignore
    DictUnpackingTransformer().visit(tree)  # type: ignore
    result = compile(tree, '<test>', 'exec')
    exec(result)  # type: ignore
    assert _py_backwards_merge_dicts.__doc__ == merge_dicts.__doc__

# Generated at 2022-06-21 17:44:53.615725
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    from ..utils.source import source
    from .remove_passes import RemovePassesTransformer
    from .remove_literals import RemoveLiteralsTransformer
    source = source(
        """
        x = {1: 2, **y}
        z = {1: 2, 3: 4}
        """
    )
    tree = ast.parse(source)
    tree = RemoveLiteralsTransformer().visit(tree) # type: ignore
    tree = DictUnpackingTransformer().visit(tree) # type: ignore
    tree = RemovePassesTransformer().visit(tree) # type: ignore
    print(ast.dump(tree))

# Generated at 2022-06-21 17:44:56.729686
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import BaseNodeTransformerTest
    from typed_ast import ast3 as ast

    # Input
    def f():
        return {1: 2, 3: 4}

    node = ast.parse(f.__code__.co_consts[0])

# Generated at 2022-06-21 17:45:05.193487
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    t = DictUnpackingTransformer()
    assert t.visit(ast.parse('''{1: 1, **{2: 2}, 3: 3, **{4: 4}, **{5: 5}}''')) == \
        ast.parse(r'''
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}, {2: 2}, {3: 3}, {4: 4}, {5: 5}])
        ''')