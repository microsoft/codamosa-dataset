

# Generated at 2022-06-21 17:35:18.212790
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..testing.utils import compile_snippet

    # Test that merge_dicts is inserted at the top of the module.
    result = compile_snippet(DictUnpackingTransformer, """
        {}
    """)
    assert result.body[0].body[0].value.id == '_py_backwards_merge_dicts'


# Unit tests for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:35:26.999221
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    dut = DictUnpackingTransformer()
    source = dedent('''
    {1: 1, 2: 2, 3: 3, **dict_a, 4: 4}
    ''')

    expected = dedent('''
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, {4: 4})
    ''')
    tree = ast.parse(source)
    dut.visit(tree)
    assert unparse(tree) == expected

# Generated at 2022-06-21 17:35:41.133043
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    code = '''
        if True:
            a = {1: 2, **dict_a, **dict_b, 2: 1}
    '''
    expected = '''
    import dask.optimization
    expected = {1: 2, **_py_backwards_merge_dicts([{}], dict_a), **_py_backwards_merge_dicts([{}], dict_b), 2: 1}
    assert expected == dask.optimization.DictUnpackingTransformer().visit({1: 2, **dict_a, **dict_b, 2: 1})
    '''
    expected = expected.format(code)

# Generated at 2022-06-21 17:35:52.680112
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast

    from typed_astunparse import unparse
    from typed_ast import (
        Dict, DictUnpack, Call, Name, List)
    from src.python.transformers.dict_unpacking import (
        DictUnpackingTransformer)

    def test(x, y):
        return x == y


# Generated at 2022-06-21 17:36:00.100106
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    input_source = """\
x = {1: 2, 3: 4}
y = {1: 2, None: v}
z = {1: 2, None: v, 4: 5, None: c}
w = {1: 2, None: v, 4: 5, None: c, 6: 7}
t = {1: 2, None: v, 6: 7, 4: 5, None: c}
"""

# Generated at 2022-06-21 17:36:09.847165
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.simplify_ast import simplify_ast

    code = """
        {
            1: 1,
            'x': x,
            **dict_a
        }
    """
    expected = """
        _py_backwards_merge_dicts(
            [{1: 1}, {'x': x}], 
            dict_a)
    """
    node = ast.parse(code)
    DictUnpackingTransformer().visit(node)
    simplified = simplify_ast(node)
    assert simplified == ast.parse(expected)



# Generated at 2022-06-21 17:36:21.492006
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import dict_unpacking
    from ..utils import normalize_code

    code = """
    x = {1: 1, **dict_a}
    """

    expected_code = """
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    
    x = _py_backwards_merge_dicts([{1: 1}], dict_a})
    """

    ast_tree = dict_unpacking(ast.parse(code))

    actual_code = normalize_code(astor.to_source(ast_tree))
    expected_code = normalize_code(expected_code)

# Generated at 2022-06-21 17:36:23.412659
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:36:33.324705
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("""
        {1: 1, **dict_a}
        [{2: 2, **dict_b}, {3: 3, **dict_c}]
    """)
    DictUnpackingTransformer().visit(module)

# Generated at 2022-06-21 17:36:36.627550
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .unpack_asserts import assert_equivalent
    from .unpack_test_fixture import visit_Dict_test_cases

    for node, expected in visit_Dict_test_cases:
        assert_equivalent(expected, DictUnpackingTransformer().visit(node))

# Generated at 2022-06-21 17:36:52.595722
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..utils.python import compile_snippet
    from ..utils.tree import convert_node_to_str
    source = '''
{
    None: {
        1: 2,
        2: 3,
    },
    None: [
        1, 2, 3,
    ],
    None: (1, 2, 3),
    4: 5,
    6: None,
    'a': {
        1: 2,
        2: 3,
        **None
    },
    'b': [
        1, 2, 3,
        **None
    ],
    'c': (1, 2, 3,
          **None),
}
'''

# Generated at 2022-06-21 17:37:01.265987
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():

    Transformer = DictUnpackingTransformer.get_transformer(
        target=(3, 4), merge_dicts=merge_dicts)
    node = ast.parse('{1:1, **{1:1}}')
    node = Transformer().visit(node)

# Generated at 2022-06-21 17:37:11.753518
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    # Test case 1: empty dict
    assert DictUnpackingTransformer(ast.parse('{}')).code == '{}'

    # Test case 2: simple dict
    result = DictUnpackingTransformer(ast.parse('''
        {1: 2}
    ''')).code
    assert result == '{1: 2}'

    # Test case 3: dict with unpacking
    result = DictUnpackingTransformer(ast.parse('''
        {1: 1, **{2: 2}, 3: 3, **{4: 4}, 5: 5}
    ''')).code
    assert '_py_backwards_merge_dicts' in result
    assert '{1: 1}' in result
    assert '{2: 2}' in result
    assert '{3: 3}' in result


# Generated at 2022-06-21 17:37:16.117410
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    src = dedent('''\
    {1:1, None:k, **a}
    ''')
    expected = dedent('''\
    _py_backwards_merge_dicts([{1: 1}, k], a)
    ''')
    tree = ast.parse(src)
    new_tree = DictUnpackingTransformer().visit(tree)
    new_src = Code(new_tree).source
    assert new_src == expected

# Generated at 2022-06-21 17:37:24.634143
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as std_ast
    import unittest
    import doctest
    doctest.testmod()
    import typed_ast.ast3 as typed_ast
    from typed_ast.ast3 import dump
    from typed_ast.compat import BytesIO
    import astunparse

    def _test(code, expected_output):
        actual_ast = typed_ast.parse(code)
        actual_ast = typed_ast.ast3.fix_missing_locations(actual_ast)
        expected_ast = typed_ast.parse(expected_output)
        expected_ast = typed_ast.ast3.fix_missing_locations(expected_ast)
        assert typed_ast.ast3.dump(actual_ast) == typed_ast.ast3.dump(expected_ast)
        DictUnpackingTransformer().vis

# Generated at 2022-06-21 17:37:33.498954
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = """
    {'a': 1, 'b': 2, **{'c': 3, 'd': 4}, 'e': 5, **{'f': 6, 'g': 7}}
    """
    node = ast.parse(source)
    expected = """
    _py_backwards_merge_dicts([{'a': 1, 'b': 2}, dict({'c': 3, 'd': 4}), {'e': 5}], dict({'f': 6, 'g': 7}))
    """
    DictUnpackingTransformer().visit(node)
    assert ast.dump(node) == expected

# Generated at 2022-06-21 17:37:35.595499
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), BaseNodeTransformer)

# Generated at 2022-06-21 17:37:37.610279
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
  from ..utils.source import source

# Generated at 2022-06-21 17:37:38.543772
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    transformer = DictUnpackingTransformer()
    assert transformer

# Generated at 2022-06-21 17:37:39.470771
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:37:53.916310
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import ast as python_ast
    import ccompiler.ast as c_ast
    import ccompiler.utils.log as log
    import ccompiler.utils.visitor as visitor
    import ccompiler.utils.serializer as serializer

    log.DEBUG_LOGGING = False

    src = """
x = {1: 1, **dict_a}
y = {1: 1, 2: 2, **dict_b, 3: 3}
z = {1: 1, **dict_c, 2: 2, 3: 3, **dict_d, 4: 4, **dict_e}
"""


# Generated at 2022-06-21 17:37:55.157379
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    trans = DictUnpackingTransformer()
    assert trans is not None

# Generated at 2022-06-21 17:38:02.769983
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .base import BaseTestTransformer
    from ..utils.snippet import code_equal


# Generated at 2022-06-21 17:38:14.724015
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast import ast3 as ast
    from ..visitor import GenericASTTraversal
    from .base import BaseNodeTransformer

    # No dict unpacking
    tree = ast.parse("{'a': 1, 'b': 2}")
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == 'Dict(keys=[Str(s="a"), Str(s="b")], values=[Num(n=1), Num(n=2)])'

    # Simple dict unpacking
    tree = ast.parse("{'a': 1, **{'b': 2}}")
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)

# Generated at 2022-06-21 17:38:24.375678
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    result = DictUnpackingTransformer().visit(ast.parse('{1: 1, **dict_a}'))
    assert isinstance(result, ast.Module)
    assert len(result.body) == 2
    assert isinstance(result.body[0], ast.FunctionDef)
    assert isinstance(result.body[1], ast.Expr)
    call = result.body[1].value
    assert isinstance(call, ast.Call)
    assert call.func.id == '_py_backwards_merge_dicts'
    assert len(call.args) == 1
    assert isinstance(call.args[0], ast.List)
    assert len(call.args[0].elts) == 2



# Generated at 2022-06-21 17:38:31.535921
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .base import CodeLike

    t = DictUnpackingTransformer()

    def trans(code):
        return t.visit(ast.parse(code))

    def test(code, expected):
        assert expected == CodeLike(trans(code))

    test('{k:v}', '{k: v}')
    test('{1: 1, **dict_a}', 'dict()')
    test('{1: 1, **dict_a, 2: 2}', '{2: 2}')
    test('{1: 1, **dict_a, 2: 2, **dict_b}', 'dict()')
    test('{**dict_a}', 'dict()')
    test('{**dict_a, **dict_b}', 'dict()')



# Generated at 2022-06-21 17:38:32.106303
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    pass

# Generated at 2022-06-21 17:38:35.247409
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils import build_ast
    from ..utils.ast_helpers import to_code
    transformer = DictUnpackingTransformer()
    src = '''
{1: 1, **{2: 2}}
    '''

# Generated at 2022-06-21 17:38:37.808658
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('''{**{1: 2}, **dict_a}''')
    transformer = DictUnpackingTransformer()
    result = transformer.visit(module)

# Generated at 2022-06-21 17:38:50.385694
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import Dict, Name, Str, parse
    from ..utils.source import source_to_function
    from ..utils.tree import tree_to_str
    
    source = """\
    def foo():
        return {1: 1, **dict_a}
    """

    expected = """\
    def foo():
        return _py_backwards_merge_dicts([{1: 1}], dict_a)
    """

    node = parse(source)
    expected = parse(expected)
    
    def foo():
        return {1: 1, **{'b': 2}}

    f = source_to_function(source)
    assert f() == foo()

    node = DictUnpackingTransformer().visit(node)
    assert tree_to_str(node) == tree_

# Generated at 2022-06-21 17:39:13.355992
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.tree import tostring
    from .base import BaseNodeTransformerTest
    from .dict_unpacking import DictUnpackingTransformer

    transformer = DictUnpackingTransformer()
    visitor = BaseNodeTransformerTest.visit(transformer)

    tree = ast.Module([
        ast.Expr(ast.Dict(keys=[ast.Constant(1, kind=None), ast.Constant(1, kind=None), ast.Name(id='__builtins__', ctx=ast.Load())],
                          values=[ast.Constant(None, kind=None), ast.Constant(None, kind=None), ast.Dict(keys=[], values=[])]))
    ])

# Generated at 2022-06-21 17:39:18.453106
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .common import compile_to_function
    from .test_merge_dicts import test_merge_dicts

    x = {
        'a': 1,
        'b': 2,
        **{'c': 3, 'd': 4}
    }
    compile_to_function(x)
    test_merge_dicts()



# Generated at 2022-06-21 17:39:23.650544
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    assert DictUnpackingTransformer({3, 4}).visit_Module(ast.parse(
        'class A:\n'
        '    a = {**a}\n'
    )) == merge_dicts.get_ast()  # type: ignore



# Generated at 2022-06-21 17:39:32.629473
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test = """
    {1: 1, 2: 2}
    {1: 1, **{2: 2}}
    {1: 1, 2: 2, **{3: 3}}
    {**{1: 1}, 2: 2}
    {**{1: 1}, 2: 2, **{3: 3}}
    {**{1: 1}, **{2: 2}, **{3: 3}}
    """

# Generated at 2022-06-21 17:39:40.924303
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_code = """
        {x: 1, y: 2, **dict_1}
    """
    splitted_result_code = """
        {x: 1, y: 2}
    """
    merged_result_code = """
        dict_1
    """
    expected_code = """
        _py_backwards_merge_dicts([{x: 1, y: 2}], dict_1)
    """

    context = merge_dicts.get_context()
    node = ast.parse(test_code)
    result = DictUnpackingTransformer().visit(node)

    assert ast.dump(result) == expected_code
    # Unit test for method visit_Dict of class DictUnpackingTransformer

# Generated at 2022-06-21 17:39:42.051233
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer() is DictUnpackingTransformer()

# Generated at 2022-06-21 17:39:45.537395
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    source = dedent("""
    {'name': 'python', **{'version': '3.7'}}
    """)

    expected = dedent("""
    _py_backwards_merge_dicts([{'name': 'python'}], {'version': '3.7'})
    """)

    ast_tree = ast.parse(source)
    result = DictUnpackingTransformer().visit(ast_tree)
    result = ast.fix_missing_locations(result)

    assert ast.dump(result) == AST_DUMP_EQUALITY.format(expected)

# Generated at 2022-06-21 17:39:46.396921
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert bool(DictUnpackingTransformer())

# Generated at 2022-06-21 17:39:54.608949
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from typed_ast.ast3 import parse
    
    visitor = DictUnpackingTransformer()
    
    code = '{None, None, 1: 2, 3: 4, None, None, 5: 6}'
    node = parse(code)
    visitor.visit(node)
    assert '_py_backwards_merge_dicts' in code

    code = '{1: 2, 3: 4, None, None, 5: 6}'
    node = parse(code)
    visitor.visit(node)
    assert '_py_backwards_merge_dicts' in code

# Generated at 2022-06-21 17:40:03.840033
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from .utils import assert_ast, parse_ast
    code = \
        """\
        {1: 1, **dict_a}
        """
    expected = \
        """\
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 1}], dict_a)
        """
    assert_ast(
        DictUnpackingTransformer,
        code,
        expected)


# Generated at 2022-06-21 17:40:23.406980
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import unittest
    from typed_ast.ast3 import parse
    from ..utils.tree import to_ast, to_source

    class Test(unittest.TestCase):
        maxDiff = None

        def test(self):
            code = '''
                _py_backwards_merge_dicts = __dict_merge_group_dicts_py_backwards_merge_dicts()
                dict_a = {1: 1, 2: 2}
                dict_b = {3: 3, **dict_a}
                dict_c = {4: 4, **dict_b}
                dict_d = _py_backwards_merge_dicts([{5: 5}], dict_c)
                '''

# Generated at 2022-06-21 17:40:25.583083
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), DictUnpackingTransformer)

# Generated at 2022-06-21 17:40:36.033904
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..utils.test_utils import dumps_ast
    ast_from = [
        'a = {1: 1, **{2: 2}}',
        'a = {1: 1, **{2: 2}, 3: 3, **{4: 4}}',
        'a = {1: 1, **{2: 2}, **{3: 3}}',
        'a = {1: 1, **{2: 2}, 3: 3}',
        'a = {1: 1, 2: 2, **{3: 3}, **{4: 4}}',
        'a = {1: 1, 2: 2, 3: 3, **{4: 4}, 5: 5}'
    ]

# Generated at 2022-06-21 17:40:37.079069
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert isinstance(DictUnpackingTransformer(), ast.NodeTransformer)

# Generated at 2022-06-21 17:40:38.151907
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    import astunparse
    import astor


# Generated at 2022-06-21 17:40:49.588424
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    import astunparse
    import io
    import astor

    source = io.StringIO("""{1: 1, **dict_a}""")
    expected = io.StringIO("""
from typed_ast import ast3 as ast
from builtins import dict
dict_a = dict()
from six import print_
print_({1: 1, **dict_a})
    """)
    module = ast.parse(source.read())  # type: ignore
    transformer = DictUnpackingTransformer()
    transformer.visit(module)
    print(astunparse.unparse(module))
    print(astor.to_source(module))
    assert astunparse.unparse(module) == expected.read()

# Generated at 2022-06-21 17:40:54.462801
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from src.compiler import compile_call_expression, compile_expression
    from ..utils.source import source_for
    import astor

    source = source_for('{1: 1, **dict_a}').source
    compiled = compile_call_expression(source)
    assert astor.to_source(compiled) == '_py_backwards_merge_dicts([{1: 1}], dict_a)'

    source = source_for('{1: 1, 2: 2, **dict_a}').source
    compiled = compile_call_expression(source)
    assert astor.to_source(compiled) == '_py_backwards_merge_dicts([{1: 1, 2: 2}], dict_a)'


# Generated at 2022-06-21 17:41:01.841815
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import astor
    code = '''
    def f():
        a = {1: 1, **dict_a}
    '''
    tree = astor.parse_file(code)
    transformer = DictUnpackingTransformer()
    transformer.visit(tree)
    expected = '''
    def _py_backwards_merge_dicts(dicts):
        result = {}
        for dict_ in dicts:
            result.update(dict_)
        return result
    def f():
        a = _py_backwards_merge_dicts([{'1': 1}], dict_a)
    '''
    assert astor.to_source(tree) == expected

# Generated at 2022-06-21 17:41:02.652998
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:41:04.754723
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    test_input = """
{1: 1, **a}
"""

# Generated at 2022-06-21 17:41:34.145359
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    import typed_ast.ast3 as ast

    t = DictUnpackingTransformer()
    code = '1'
    module = ast.parse(code)
    result = t.visit(module)

# Generated at 2022-06-21 17:41:40.438425
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from .tests_fixtures.dict_unpacking import (
        DictUnpackingTransformer_visit_Dict as input
    )
    from .tests_fixtures.dict_unpacking import (
        DictUnpackingTransformer_visit_Dict as expected
    )

    transformer = DictUnpackingTransformer()
    output = transformer.visit(input)

    assert ast.dump(output, annotate_fields=False) == \
        ast.dump(expected, annotate_fields=False)

# Generated at 2022-06-21 17:41:47.069469
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..testing.utils import get_ast
    from ..testing.visitor import check_transformer
    from .snippet import _py_backwards_merge_dicts
    
    code = '{1: 1, **dict_a}'
    ast_tree = get_ast(code)
    expected = merge_dicts.get_body() + [_py_backwards_merge_dicts.get_body()]
    assert check_transformer(ast_tree, DictUnpackingTransformer, expected)

# Generated at 2022-06-21 17:41:53.150046
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    tree = ast.parse("""\
{1: 1, **{2: 2}, **{3: 3}, **{4: 4}, **{5: 5}}
""")

# Generated at 2022-06-21 17:42:00.213650
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    def prep_code(code):
        module = ast.parse(code)
        DictUnpackingTransformer().visit(module)
        return module

    module = prep_code('''
        a = {1: 1, **dict_a}
        b = {}
    ''')
    assert '_py_backwards_merge_dicts' in ast.dump(module)

    module = prep_code('''
        a = {1: 1, 2: 2}
        b = {}
    ''')
    assert '_py_backwards_merge_dicts' not in ast.dump(module)



# Generated at 2022-06-21 17:42:10.196142
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing import assert_raises
    
    source = '''\
    {a: b, **x, c: d, **y}'''
    expected = '''\
    _py_backwards_merge_dicts([dict(), dict(a=b, c=d)], x, y)'''
    tree = ast.parse(source)
    tree = DictUnpackingTransformer().visit(tree)
    assert expected == tree.body[0].body[0].value.s
    
    source = '''\
    {**x, **y}'''
    expected = '''\
    _py_backwards_merge_dicts([dict(), dict()], x, y)'''
    tree = ast.parse(source)
    tree = DictUnpackingTransformer().visit(tree)

# Generated at 2022-06-21 17:42:19.662240
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    from ..testing_utils import assert_ast_nodes_equal

    node = ast.parse("""
    {1:1, **dict_a, 2: 2, **dict_b, 3: 3, **dict_c}
    """.strip())
    
    transformed = ast.fix_missing_locations(
        DictUnpackingTransformer().visit(node))
    
    expected = ast.parse("""
    _py_backwards_merge_dicts([{1: 1, 2: 2, 3: 3}], dict_a, dict_b, dict_c)
    """.strip())
    
    assert_ast_nodes_equal(expected, transformed)

# Generated at 2022-06-21 17:42:24.990041
# Unit test for method visit_Dict of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Dict():
    node, expected = DictUnpackingTransformer.example_to_test(
        DictUnpackingTransformer, 'dict')
    DictUnpackingTransformer(node).run()
    assert ast.dump(node) == expected

# Generated at 2022-06-21 17:42:29.375986
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer(0)._split_by_None([
        (1, 2), (None, 3), (4, 5), (None, 6), (7, 8)]) == [
            [(1, 2)], 3, [(4, 5)], 6, [(7, 8)]]

# Generated at 2022-06-21 17:42:31.923005
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    DictUnpackingTransformer()

# Generated at 2022-06-21 17:43:41.720862
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse("")
    node = ast.Dict(keys=[ast.Name(id='input')],
                    values=[ast.Dict(keys=[None, ast.Name(id='key')],
                                     values=[ast.Num(n=1), ast.Num(n=2)])])
    module.body.append(node)

    expected = ast.parse("")
    module.body[0:0] = merge_dicts.get_body()

# Generated at 2022-06-21 17:43:51.632749
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from ..testing import run_local_tests

    ex = """\
        {1: 2, **dict_a}
    """
    expected = """\
        def _py_backwards_merge_dicts(dicts):
            result = {};
            for dict_ in dicts:
                result.update(dict_)
            return result
        _py_backwards_merge_dicts([{1: 2}], dict_a)
    """
    tree = ast.parse(ex)
    result = DictUnpackingTransformer().visit(tree)
    assert expected == result



# Generated at 2022-06-21 17:44:00.523569
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import parse
    from .transformer_test import should_not_change, should_change
    transformer = DictUnpackingTransformer()
    should_not_change(transformer, '{}')
    should_not_change(transformer, '{1: 1}')
    should_change(transformer, '{1: 1, **x}')
    should_change(transformer, '{1: 1, *x}')
    should_change(transformer, '{1: 1, **x, **y}')
    should_change(transformer, '{1: 1, **x, *y}')
    should_change(transformer, '{1: 1, **x, **y, **z}')

# Generated at 2022-06-21 17:44:06.544627
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.Module([ast.Dict(keys=[None, ast.Num(n=1)], values=[ast.Name(id='dict_a'), ast.Num(n=1)])])
    module_ = DictUnpackingTransformer().visit(module)
    assert isinstance(module_, ast.Module)
    assert len(module_.body) == 2
    assert isinstance(module_.body[0], ast.Expr)
    assert codegen.to_source(module_.body[1]) == '_py_backwards_merge_dicts([dict(1=1)], dict_a)'

# Generated at 2022-06-21 17:44:12.082025
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    module = ast.parse('{1: 2, **{3: 4}}')
    transformer = DictUnpackingTransformer()
    transformed = transformer.visit(module)
    assert ast.dump(transformed) != ast.dump(module)

    module = ast.parse(merge_dicts)
    transformed = transformer.visit(module)
    assert ast.dump(transformed) == ast.dump(module)


# Generated at 2022-06-21 17:44:13.598051
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    assert DictUnpackingTransformer().visitor_name == "DictUnpackingTransformer"

# Generated at 2022-06-21 17:44:23.211672
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-21 17:44:30.468882
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    code = """
    a = {}
    b = {a: a}
    """
    result = DictUnpackingTransformer().visit(ast.parse(code))
    assert str(result) == """
    def _py_backwards_merge_dicts():
        def _py_backwards_merge_dicts(dicts):
            result = {}
            for dict_ in dicts:
                result.update(dict_)
            return result
    a = {}
    b = {a: a}
    """

# Generated at 2022-06-21 17:44:36.752017
# Unit test for method visit_Module of class DictUnpackingTransformer
def test_DictUnpackingTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.fixtures import module
    from .unpacking import UnpackingTransformer

    unpacked = ast.parse("""
    {
        **dict1,
        **dict2,
        3: 3,
        **{4: 4},
        **dict3,
    }
    """)

    result = UnpackingTransformer().visit(unpacked)
    assert str(result) == """
    _py_backwards_merge_dicts([{}, {}], dict1, dict2, _py_backwards_merge_dicts([{3: 3}], {4: 4}, dict3))
    """


# Generated at 2022-06-21 17:44:38.951519
# Unit test for constructor of class DictUnpackingTransformer
def test_DictUnpackingTransformer():
    data = DictUnpackingTransformer()
    assert DictUnpackingTransformer.__doc__ == DictUnpackingTransformer.__init__.__doc__